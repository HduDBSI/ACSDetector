package test_inputs2;

public class TestMethods2 {

	public void print2() {
		// TODO Auto-generated method stub
		
	}

}
