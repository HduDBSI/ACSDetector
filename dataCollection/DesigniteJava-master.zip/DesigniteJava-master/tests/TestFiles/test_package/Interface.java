package test_package;

interface Interface {
    void initialiseVariable(int value);
    void start();
}
