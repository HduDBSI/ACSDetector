package test_package;

public class NestedClass {
	class InnerClass {
		
	}
}
