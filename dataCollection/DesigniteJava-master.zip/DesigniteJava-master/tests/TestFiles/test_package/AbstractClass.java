package test_package;

public abstract class AbstractClass {
	 abstract void abstractMethod();
}
