package test_package;

class DefaultClass {

}
