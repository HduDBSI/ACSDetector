package test_package;

public class TestClass {
	public void method() {
		
	}
}
