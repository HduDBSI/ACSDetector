package metricsPackage;

public interface InterfaceChild1 extends InterfaceParent {

}
