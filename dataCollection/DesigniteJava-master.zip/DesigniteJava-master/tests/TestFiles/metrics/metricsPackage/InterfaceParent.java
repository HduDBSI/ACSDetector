package metricsPackage;

public interface InterfaceParent {

}
