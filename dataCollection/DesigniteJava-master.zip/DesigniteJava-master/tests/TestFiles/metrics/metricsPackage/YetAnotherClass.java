package metricsPackage;

public class YetAnotherClass {
}
