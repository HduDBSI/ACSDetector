package metricsPackage;

public class ForeignClass3 {

}
