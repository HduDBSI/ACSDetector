package metricsPackage;

public class ForeignClass5 {
	
	public static String ERROR = "error";
}
