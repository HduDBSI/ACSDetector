package metricsPackage;

public class AnotherClass extends YetAnotherClass{

}
