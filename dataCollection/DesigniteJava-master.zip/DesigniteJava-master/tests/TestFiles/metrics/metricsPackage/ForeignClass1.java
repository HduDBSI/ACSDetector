package metricsPackage;

public class ForeignClass1 {

	private TestMetricsClass cl = new TestMetricsClass();
}
