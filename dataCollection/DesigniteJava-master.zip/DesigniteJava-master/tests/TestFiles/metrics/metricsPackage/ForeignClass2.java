package metricsPackage;

public class ForeignClass2 {

}
