package metricsPackage;

public interface InterfaceGrandChild extends InterfaceChild1 {

}
