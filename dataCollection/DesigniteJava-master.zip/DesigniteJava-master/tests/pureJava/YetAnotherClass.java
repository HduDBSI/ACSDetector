public class YetAnotherClass {
}
