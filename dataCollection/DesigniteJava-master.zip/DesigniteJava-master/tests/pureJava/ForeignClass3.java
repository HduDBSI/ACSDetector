public class ForeignClass3 {
}
