public class AnotherClass extends YetAnotherClass {
}
