public class ForeignClass4 {
  public static int func(){
    TestMetricsClass cl=new TestMetricsClass();
    return 0;
  }
}
