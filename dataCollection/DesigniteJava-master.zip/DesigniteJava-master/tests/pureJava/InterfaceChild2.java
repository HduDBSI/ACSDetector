public interface InterfaceChild2 extends InterfaceParent {
}
