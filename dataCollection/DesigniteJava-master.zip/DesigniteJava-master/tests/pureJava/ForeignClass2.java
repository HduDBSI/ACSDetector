public class ForeignClass2 {
}
