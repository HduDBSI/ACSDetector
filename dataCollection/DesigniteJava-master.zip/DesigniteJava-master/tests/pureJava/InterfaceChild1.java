public interface InterfaceChild1 extends InterfaceParent {
}
