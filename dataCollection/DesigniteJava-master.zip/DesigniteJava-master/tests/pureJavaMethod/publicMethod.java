public <A extends Object>void publicMethod(String parameter1,int parameter2,ForeignClass2 parameter3,A e,List<? extends A> myList){
  ForeignClass3 fc3=new ForeignClass3();
  int num=ForeignClass4.func();
  String[] s=new String[1];
  if (true) {
    for (int i=0; i < 5; i++) {
      for (      String b : bar) {
      }
    }
  }
 else   if (true || false) {
    while (false) {
      do {
      }
 while (false);
    }
  }
 else {
switch (foo) {
case "foo":
      break;
case "bar":
    break;
default :
}
}
}
