public void foo(){
  int field3=5;
  field1="bar";
  String random="random";
  for (  String word : field2) {
    if (bool) {
      this.field3++;
      field1="rab";
      ForeignClass4.func();
      ForeignClass5.ERROR $missing$;
    }
  }
}
