public void method2(){
  field3++;
}
