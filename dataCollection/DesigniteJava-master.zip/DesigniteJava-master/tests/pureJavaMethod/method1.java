public void method1(){
  field1++;
  field2++;
}
