public void method3(){
  method1();
  field3++;
}
