public static int func(){
  TestMetricsClass cl=new TestMetricsClass();
  return 0;
}
