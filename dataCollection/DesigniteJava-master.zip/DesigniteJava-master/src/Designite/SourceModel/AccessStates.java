package Designite.SourceModel;

public enum AccessStates {

	PUBLIC, PROTECTED, DEFAULT, PRIVATE
	
}
