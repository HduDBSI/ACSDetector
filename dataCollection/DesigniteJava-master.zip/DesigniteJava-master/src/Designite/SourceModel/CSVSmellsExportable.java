package Designite.SourceModel;

public interface CSVSmellsExportable {
	
	void exportSmellsToCSV();
	
}
