package Designite.metrics;

public interface MetricExtractor {
	
	void extractMetrics();
}
