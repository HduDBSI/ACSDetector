package Designite.utils.models;

public interface Vertex {
	
}
