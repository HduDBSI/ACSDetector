/** 
 * Stop all threads related to this client.  No further calls may be made using this client. 
 */
public void stop(){
  if (LOG.isDebugEnabled()) {
    LOG.debug("Stopping client");
  }
synchronized (putLock) {
    if (!running.compareAndSet(true,false)) {
      return;
    }
  }
  for (  Connection conn : connections.values()) {
    conn.interrupt();
    conn.interruptConnectingThread();
  }
synchronized (emptyCondition) {
    while (!connections.isEmpty()) {
      try {
        emptyCondition.wait();
      }
 catch (      InterruptedException e) {
        LOG.trace("Interrupted while waiting on all connections to be closed.");
        Thread.currentThread().interrupt();
      }
    }
  }
  clientExcecutorFactory.unrefAndCleanup();
}
