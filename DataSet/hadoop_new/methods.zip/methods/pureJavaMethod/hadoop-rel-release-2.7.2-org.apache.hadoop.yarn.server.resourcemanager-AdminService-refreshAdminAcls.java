private RefreshAdminAclsResponse refreshAdminAcls(boolean checkRMHAState) throws YarnException, IOException {
  String argName="refreshAdminAcls";
  UserGroupInformation user=checkAcls(argName);
  if (checkRMHAState) {
    checkRMStatus(user.getShortUserName(),argName,"refresh Admin ACLs.");
  }
  Configuration conf=getConfiguration(new Configuration(false),YarnConfiguration.YARN_SITE_CONFIGURATION_FILE);
  authorizer.setAdmins(getAdminAclList(conf),UserGroupInformation.getCurrentUser());
  RMAuditLogger.logSuccess(user.getShortUserName(),argName,"AdminService");
  return recordFactory.newRecordInstance(RefreshAdminAclsResponse.class);
}
