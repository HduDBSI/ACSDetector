@Override public short getDefaultReplication(Path f){
  throw new NotInMountpointException(f,"getDefaultReplication");
}
