private PermissionStatus getPermissionStatus(CloudBlobWrapper blob){
  String permissionMetadataValue=getMetadataAttribute(blob,PERMISSION_METADATA_KEY,OLD_PERMISSION_METADATA_KEY);
  if (permissionMetadataValue != null) {
    return PermissionStatusJsonSerializer.fromJSONString(permissionMetadataValue);
  }
 else {
    return defaultPermissionNoBlobMetadata();
  }
}
