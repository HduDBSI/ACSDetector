@Override public FileStatus[] listStatus(Path f) throws IOException {
  throw new UnsupportedOperationException(UNSUPPORTED);
}
