@Override boolean removeStorage(DatanodeStorageInfo storage){
  int dnIndex=findStorageInfo(storage);
  if (dnIndex < 0) {
    return false;
  }
  assert getPrevious(dnIndex) == null && getNext(dnIndex) == null : "Block is still in the list and must be removed first.";
  int lastNode=numNodes() - 1;
  setStorageInfo(dnIndex,getStorageInfo(lastNode));
  setNext(dnIndex,getNext(lastNode));
  setPrevious(dnIndex,getPrevious(lastNode));
  setStorageInfo(lastNode,null);
  setNext(lastNode,null);
  setPrevious(lastNode,null);
  return true;
}
