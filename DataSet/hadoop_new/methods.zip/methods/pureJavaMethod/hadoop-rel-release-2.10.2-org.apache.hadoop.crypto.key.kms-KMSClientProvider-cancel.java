@Override public void cancel(Token<?> token,Configuration conf) throws IOException {
  LOG.debug("Canceling delegation token {}",token);
  KeyProvider keyProvider=KMSUtil.createKeyProvider(conf,KeyProviderFactory.KEY_PROVIDER_PATH);
  try {
    if (!(keyProvider instanceof KeyProviderDelegationTokenExtension.DelegationTokenExtension)) {
      throw new IOException(String.format("keyProvider %s cannot cancel token [%s]",keyProvider == null ? "null" : keyProvider.getClass(),token));
    }
    ((KeyProviderDelegationTokenExtension.DelegationTokenExtension)keyProvider).cancelDelegationToken(token);
  }
  finally {
    if (keyProvider != null) {
      keyProvider.close();
    }
  }
}
