/** 
 * Log in a user using the given subject
 * @param subject the subject to use when logging in a user, or null tocreate a new subject. If subject is not null, the creator of subject is responsible for renewing credentials.
 * @throws IOException if login fails
 */
@InterfaceAudience.Public @InterfaceStability.Evolving public static void loginUserFromSubject(Subject subject) throws IOException {
  setLoginUser(createLoginUser(subject));
}
