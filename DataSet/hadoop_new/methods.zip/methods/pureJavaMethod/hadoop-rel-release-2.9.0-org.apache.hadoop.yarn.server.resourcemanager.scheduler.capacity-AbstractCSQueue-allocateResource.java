void allocateResource(Resource clusterResource,Resource resource,String nodePartition){
  try {
    writeLock.lock();
    queueUsage.incUsed(nodePartition,resource);
    ++numContainers;
    CSQueueUtils.updateQueueStatistics(resourceCalculator,clusterResource,this,labelManager,nodePartition);
  }
  finally {
    writeLock.unlock();
  }
}
