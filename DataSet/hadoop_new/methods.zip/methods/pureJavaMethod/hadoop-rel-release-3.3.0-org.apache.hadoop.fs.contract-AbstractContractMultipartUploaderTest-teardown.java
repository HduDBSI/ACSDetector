@Override public void teardown() throws Exception {
  if (mpu != null && activeUpload != null) {
    try {
      mpu.abort(activeUploadPath,activeUpload);
    }
 catch (    FileNotFoundException ignored) {
    }
catch (    Exception e) {
      LOG.info("in teardown",e);
    }
  }
  cleanupWithLogger(LOG,mpu,mpu2);
  super.teardown();
}
