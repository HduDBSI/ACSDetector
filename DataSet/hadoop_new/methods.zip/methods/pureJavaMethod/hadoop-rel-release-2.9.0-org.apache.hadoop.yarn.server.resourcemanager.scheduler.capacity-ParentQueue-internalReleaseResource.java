private void internalReleaseResource(Resource clusterResource,FiCaSchedulerNode node,Resource releasedResource){
  try {
    writeLock.lock();
    super.releaseResource(clusterResource,releasedResource,node.getPartition());
    if (LOG.isDebugEnabled()) {
      LOG.debug("completedContainer " + this + ", cluster="+ clusterResource);
    }
  }
  finally {
    writeLock.unlock();
  }
}
