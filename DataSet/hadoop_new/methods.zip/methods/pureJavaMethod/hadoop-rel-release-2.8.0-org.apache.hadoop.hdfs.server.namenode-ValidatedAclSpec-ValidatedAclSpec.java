/** 
 * Creates a ValidatedAclSpec by pre-validating and sorting the given ACL entries.  Pre-validation checks that it does not exceed the maximum entries.  This check is performed before modifying the ACL, and it's actually insufficient for enforcing the maximum number of entries. Transformation logic can create additional entries automatically,such as the mask and some of the default entries, so we also need additional checks during transformation.  The up-front check is still valuable here so that we don't run a lot of expensive transformation logic while holding the namesystem lock for an attacker who intentionally sent a huge ACL spec.
 * @param aclSpec List<AclEntry> containing unvalidated input ACL spec
 * @throws AclException if validation fails
 */
public ValidatedAclSpec(List<AclEntry> aclSpec) throws AclException {
  Collections.sort(aclSpec,ACL_ENTRY_COMPARATOR);
  checkMaxEntries(new ScopedAclEntries(aclSpec));
  this.aclSpec=aclSpec;
}
