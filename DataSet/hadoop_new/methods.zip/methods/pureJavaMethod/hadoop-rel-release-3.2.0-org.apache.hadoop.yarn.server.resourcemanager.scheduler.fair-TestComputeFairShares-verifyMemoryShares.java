/** 
 * Check that a given list of shares have been assigned to this.scheds.
 */
private void verifyMemoryShares(int... shares){
  Assert.assertEquals(scheds.size(),shares.length);
  for (int i=0; i < shares.length; i++) {
    Assert.assertEquals(shares[i],scheds.get(i).getFairShare().getMemorySize());
  }
}
