@Override public <T extends BaseRecord>int remove(Class<T> clazz,Query<T> query) throws StateStoreUnavailableException {
  verifyDriverReady();
  if (query == null) {
    return 0;
  }
  long start=Time.monotonicNow();
  StateStoreMetrics metrics=getMetrics();
  int removed=0;
  try {
    final QueryResult<T> result=get(clazz);
    final List<T> existingRecords=result.getRecords();
    final List<T> recordsToRemove=filterMultiple(query,existingRecords);
    boolean success=true;
    for (    T recordToRemove : recordsToRemove) {
      String path=getPathForClass(clazz);
      String primaryKey=getPrimaryKey(recordToRemove);
      String recordToRemovePath=path + "/" + primaryKey;
      if (remove(recordToRemovePath)) {
        removed++;
      }
 else {
        LOG.error("Cannot remove record {}",recordToRemovePath);
        success=false;
      }
    }
    if (!success) {
      LOG.error("Cannot remove records {} query {}",clazz,query);
      if (metrics != null) {
        metrics.addFailure(monotonicNow() - start);
      }
    }
  }
 catch (  IOException e) {
    LOG.error("Cannot remove records {} query {}",clazz,query,e);
    if (metrics != null) {
      metrics.addFailure(monotonicNow() - start);
    }
  }
  if (removed > 0 && metrics != null) {
    metrics.addRemove(monotonicNow() - start);
  }
  return removed;
}
