@Override public boolean complete(String src,String clientName,ExtendedBlock last,long fileId) throws IOException {
  return clientProto.complete(src,clientName,last,fileId);
}
