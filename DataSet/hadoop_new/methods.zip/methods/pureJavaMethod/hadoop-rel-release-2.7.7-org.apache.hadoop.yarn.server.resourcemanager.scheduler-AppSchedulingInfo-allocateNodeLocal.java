/** 
 * The  {@link ResourceScheduler} is allocating data-local resources to theapplication.
 * @param allocatedContainers resources allocated to the application
 */
synchronized private void allocateNodeLocal(SchedulerNode node,Priority priority,ResourceRequest nodeLocalRequest,Container container,List<ResourceRequest> resourceRequests){
  decResourceRequest(node.getNodeName(),priority,nodeLocalRequest);
  ResourceRequest rackLocalRequest=requests.get(priority).get(node.getRackName());
  decResourceRequest(node.getRackName(),priority,rackLocalRequest);
  ResourceRequest offRackRequest=requests.get(priority).get(ResourceRequest.ANY);
  decrementOutstanding(offRackRequest);
  resourceRequests.add(cloneResourceRequest(nodeLocalRequest));
  resourceRequests.add(cloneResourceRequest(rackLocalRequest));
  resourceRequests.add(cloneResourceRequest(offRackRequest));
}
