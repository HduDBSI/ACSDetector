LevelDBMetadataMap(String baseDir) throws IOException {
  File dbDir=new File(baseDir);
  if (dbDir.exists()) {
    FileUtils.deleteDirectory(dbDir);
  }
  if (!dbDir.mkdirs()) {
    throw new IOException("Failed to mkdir on " + dbDir);
  }
  try {
    dirChildMap=new LevelDBStore(new File(dbDir,"dirChildMap"));
    dirMap=new LevelDBStore(new File(dbDir,"dirMap"));
  }
 catch (  IOException e) {
    LOG.error("Failed to open LevelDBs",e);
    IOUtils.cleanup(null,this);
  }
}
