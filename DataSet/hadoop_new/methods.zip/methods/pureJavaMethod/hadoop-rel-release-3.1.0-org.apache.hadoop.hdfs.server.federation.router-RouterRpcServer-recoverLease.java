@Override public boolean recoverLease(String src,String clientName) throws IOException {
  checkOperation(OperationCategory.WRITE);
  final List<RemoteLocation> locations=getLocationsForPath(src,true);
  RemoteMethod method=new RemoteMethod("recoverLease",new Class<?>[]{String.class,String.class},new RemoteParam(),clientName);
  Object result=rpcClient.invokeSequential(locations,method,Boolean.class,Boolean.TRUE);
  return (boolean)result;
}
