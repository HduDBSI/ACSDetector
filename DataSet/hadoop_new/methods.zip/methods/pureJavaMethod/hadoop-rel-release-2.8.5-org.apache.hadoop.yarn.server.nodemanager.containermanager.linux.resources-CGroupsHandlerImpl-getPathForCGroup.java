@Override public String getPathForCGroup(CGroupController controller,String cGroupId){
  return new StringBuffer(getControllerPath(controller)).append('/').append(cGroupPrefix).append("/").append(cGroupId).toString();
}
