@Before public void setUp() throws IOException {
  originalOut=System.err;
  memOut=new ByteArrayOutputStream();
  filterOut=new FilterOut(memOut);
  capturedOut=new PrintStream(filterOut);
  System.setErr(capturedOut);
  InputStream is=ThreadUtil.getResourceAsStream("log4j-kmsaudit.properties");
  PropertyConfigurator.configure(is);
  IOUtils.closeStream(is);
  Configuration conf=new Configuration();
  this.kmsAudit=new KMSAudit(conf);
}
