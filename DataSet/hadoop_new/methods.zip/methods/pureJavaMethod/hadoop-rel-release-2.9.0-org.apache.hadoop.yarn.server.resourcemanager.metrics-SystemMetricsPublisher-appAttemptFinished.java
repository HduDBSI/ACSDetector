void appAttemptFinished(RMAppAttempt appAttempt,RMAppAttemptState appAttemtpState,RMApp app,long finishedTime);
