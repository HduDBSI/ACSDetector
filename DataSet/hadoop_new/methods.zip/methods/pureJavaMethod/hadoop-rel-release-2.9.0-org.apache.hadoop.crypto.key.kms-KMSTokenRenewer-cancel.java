@Override public void cancel(Token<?> token,Configuration conf) throws IOException {
  LOG.debug("Canceling delegation token {}",token);
  KeyProvider keyProvider=KMSUtil.createKeyProvider(conf,KeyProviderFactory.KEY_PROVIDER_PATH);
  try {
    if (!(keyProvider instanceof KeyProviderDelegationTokenExtension.DelegationTokenExtension)) {
      LOG.warn("keyProvider {} cannot cancel dt.",keyProvider == null ? "null" : keyProvider.getClass());
      return;
    }
    ((KeyProviderDelegationTokenExtension.DelegationTokenExtension)keyProvider).cancelDelegationToken(token);
  }
  finally {
    if (keyProvider != null) {
      keyProvider.close();
    }
  }
}
