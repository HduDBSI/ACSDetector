@InterfaceStability.Unstable @InterfaceAudience.LimitedPrivate({"HDFS"}) public final void abortResponse(Throwable t) throws IOException {
  if (responseWaitCount.getAndSet(-1) > 0) {
    doResponse(t);
  }
}
