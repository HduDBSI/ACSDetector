Root(INodeDirectory other){
  super(other,false,Arrays.stream(other.getFeatures()).filter(feature -> feature instanceof AclFeature || feature instanceof XAttrFeature || feature instanceof DirectoryWithQuotaFeature).map(feature -> {
    if (feature instanceof DirectoryWithQuotaFeature) {
      final QuotaCounts quota=((DirectoryWithQuotaFeature)feature).getSpaceAllowed();
      return new DirectoryWithQuotaFeature.Builder().nameSpaceQuota(quota.getNameSpace()).storageSpaceQuota(quota.getStorageSpace()).typeQuotas(quota.getTypeSpaces()).build();
    }
 else {
      return feature;
    }
  }
).toArray(Feature[]::new));
}
