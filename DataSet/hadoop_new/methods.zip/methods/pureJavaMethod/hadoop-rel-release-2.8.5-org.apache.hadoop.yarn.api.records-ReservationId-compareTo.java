@Override public int compareTo(ReservationId other){
  if (this.getClusterTimestamp() - other.getClusterTimestamp() == 0) {
    return Long.compare(getId(),other.getId());
  }
 else {
    return Long.compare(getClusterTimestamp(),other.getClusterTimestamp());
  }
}
