/** 
 * a Unix command to get a given netgroup's user list 
 */
public static String[] getUsersForNetgroupCommand(final String netgroup){
  return new String[]{"getent","netgroup",netgroup};
}
