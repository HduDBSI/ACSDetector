/** 
 * test  {@link ArrayWritable} constructor with null
 */
@Test public void testNullArgument(){
  try {
    Class<? extends Writable> valueClass=null;
    new ArrayWritable(valueClass);
    fail("testNullArgument error !!!");
  }
 catch (  IllegalArgumentException exp) {
  }
catch (  Exception e) {
    fail("testNullArgument error !!!");
  }
}
