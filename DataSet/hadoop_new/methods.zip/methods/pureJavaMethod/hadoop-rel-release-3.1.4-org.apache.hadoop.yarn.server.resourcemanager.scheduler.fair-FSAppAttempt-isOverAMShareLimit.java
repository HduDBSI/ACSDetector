/** 
 * Whether the AM container for this app is over maxAMShare limit.
 */
private boolean isOverAMShareLimit(){
  if (!isAmRunning() && !getUnmanagedAM()) {
    PendingAsk ask=appSchedulingInfo.getNextPendingAsk();
    if (ask != null && (ask.getCount() == 0 || !getQueue().canRunAppAM(ask.getPerAllocationResource()))) {
      return true;
    }
  }
  return false;
}
