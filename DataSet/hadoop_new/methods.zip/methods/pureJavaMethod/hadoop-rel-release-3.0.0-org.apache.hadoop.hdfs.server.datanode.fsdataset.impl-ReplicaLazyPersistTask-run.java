@Override public void run(){
  boolean succeeded=false;
  final FsDatasetImpl dataset=(FsDatasetImpl)datanode.getFSDataset();
  try (FsVolumeReference ref=this.targetVolume){
    int smallBufferSize=DFSUtilClient.getSmallBufferSize(EMPTY_HDFS_CONF);
    FsVolumeImpl volume=(FsVolumeImpl)ref.getVolume();
    File[] targetFiles=volume.copyBlockToLazyPersistLocation(bpId,blockId,genStamp,replicaInfo,smallBufferSize,conf);
    dataset.onCompleteLazyPersist(bpId,blockId,creationTime,targetFiles,volume);
    succeeded=true;
  }
 catch (  Exception e) {
    FsDatasetImpl.LOG.warn("LazyWriter failed to async persist RamDisk block pool id: " + bpId + "block Id: "+ blockId,e);
  }
 finally {
    if (!succeeded) {
      dataset.onFailLazyPersist(bpId,blockId);
    }
  }
}
