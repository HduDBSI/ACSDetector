/** 
 * Open a DataOutputStream to a DataNode so that it can be written to. This happens when a file is created and each time a new block is allocated. Must get block ID and the IDs of the destinations from the namenode. Returns the list of target datanodes.
 */
private LocatedBlock nextBlockOutputStream() throws IOException {
  LocatedBlock lb=null;
  DatanodeInfo[] nodes=null;
  StorageType[] storageTypes=null;
  int count=dfsClient.getConf().nBlockWriteRetry;
  boolean success=false;
  ExtendedBlock oldBlock=block.getCurrentBlock();
  do {
    hasError=false;
    lastException.set(null);
    errorIndex=-1;
    success=false;
    DatanodeInfo[] excluded=getExcludedNodes();
    lb=locateFollowingBlock(excluded.length > 0 ? excluded : null,oldBlock);
    block.setCurrentBlock(lb.getBlock());
    block.setNumBytes(0);
    bytesSent=0;
    accessToken=lb.getBlockToken();
    nodes=lb.getLocations();
    storageTypes=lb.getStorageTypes();
    success=createBlockOutputStream(nodes,storageTypes,0L,false);
    if (!success) {
      DFSClient.LOG.info("Abandoning " + block);
      dfsClient.namenode.abandonBlock(block.getCurrentBlock(),fileId,src,dfsClient.clientName);
      block.setCurrentBlock(null);
      DFSClient.LOG.info("Excluding datanode " + nodes[errorIndex]);
      excludedNodes.put(nodes[errorIndex],nodes[errorIndex]);
    }
  }
 while (!success && --count >= 0);
  if (!success) {
    throw new IOException("Unable to create new block.");
  }
  return lb;
}
