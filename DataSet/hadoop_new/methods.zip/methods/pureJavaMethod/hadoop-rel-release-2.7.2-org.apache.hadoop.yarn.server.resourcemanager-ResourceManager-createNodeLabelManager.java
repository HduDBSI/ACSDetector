protected RMNodeLabelsManager createNodeLabelManager() throws InstantiationException, IllegalAccessException {
  return new RMNodeLabelsManager();
}
