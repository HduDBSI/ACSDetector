/** 
 * On putting the node in service, check if the node has excess replicas. If there are any excess replicas, call processExtraRedundancyBlock(). Process extra redundancy blocks only when active NN is out of safe mode.
 */
void processExtraRedundancyBlocksOnInService(final DatanodeDescriptor srcNode){
  if (!isPopulatingReplQueues()) {
    return;
  }
  final Iterator<BlockInfo> it=srcNode.getBlockIterator();
  int numExtraRedundancy=0;
  while (it.hasNext()) {
    final BlockInfo block=it.next();
    if (block.isDeleted()) {
      continue;
    }
    int expectedReplication=this.getExpectedRedundancyNum(block);
    NumberReplicas num=countNodes(block);
    if (shouldProcessExtraRedundancy(num,expectedReplication)) {
      processExtraRedundancyBlock(block,(short)expectedReplication,null,null);
      numExtraRedundancy++;
    }
  }
  LOG.info("Invalidated {} extra redundancy blocks on {} after " + "it is in service",numExtraRedundancy,srcNode);
}
