@Override public Resource getResourceUsage(){
  return Resources.subtract(getCurrentConsumption(),getPreemptedResources());
}
