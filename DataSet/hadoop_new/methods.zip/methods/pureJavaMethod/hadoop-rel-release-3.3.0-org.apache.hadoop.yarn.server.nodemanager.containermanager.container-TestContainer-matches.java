@Override public boolean matches(LocalizationEvent e){
  ContainerLocalizationRequestEvent evt=(ContainerLocalizationRequestEvent)e;
  final HashSet<LocalResourceRequest> expected=new HashSet<LocalResourceRequest>(resources);
  for (  Collection<LocalResourceRequest> rc : evt.getRequestedResources().values()) {
    for (    LocalResourceRequest rsrc : rc) {
      if (!expected.remove(rsrc)) {
        return false;
      }
    }
  }
  return expected.isEmpty();
}
