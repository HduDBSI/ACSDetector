private void initializePriorityDigraph(){
  LOG.debug("Initializing priority preemption directed graph:");
  for (  String q1 : preemptionContext.getLeafQueueNames()) {
    for (    String q2 : preemptionContext.getLeafQueueNames()) {
      if (q1.compareTo(q2) < 0) {
        TempQueuePerPartition tq1=preemptionContext.getQueueByPartition(q1,RMNodeLabelsManager.NO_LABEL);
        TempQueuePerPartition tq2=preemptionContext.getQueueByPartition(q2,RMNodeLabelsManager.NO_LABEL);
        List<TempQueuePerPartition> path1=getPathToRoot(tq1);
        List<TempQueuePerPartition> path2=getPathToRoot(tq2);
        int i=path1.size() - 1;
        int j=path2.size() - 1;
        while (path1.get(i).queueName.equals(path2.get(j).queueName)) {
          i--;
          j--;
        }
        int p1=path1.get(i).relativePriority;
        int p2=path2.get(j).relativePriority;
        if (p1 < p2) {
          priorityDigraph.put(q2,q1,true);
          LOG.debug("- Added priority ordering edge: {} >> {}",q2,q1);
        }
 else         if (p2 < p1) {
          priorityDigraph.put(q1,q2,true);
          LOG.debug("- Added priority ordering edge: {} >> {}",q1,q2);
        }
      }
    }
  }
}
