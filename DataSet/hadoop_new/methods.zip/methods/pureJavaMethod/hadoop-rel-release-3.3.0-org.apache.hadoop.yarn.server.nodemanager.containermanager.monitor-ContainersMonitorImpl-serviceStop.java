@Override protected void serviceStop() throws Exception {
  if (containersMonitorEnabled) {
    stopped=true;
    this.monitoringThread.interrupt();
    try {
      this.monitoringThread.join();
    }
 catch (    InterruptedException e) {
      LOG.info("ContainersMonitorImpl monitoring thread interrupted");
    }
    if (this.oomListenerThread != null) {
      this.oomListenerThread.stopListening();
      try {
        this.oomListenerThread.join();
      }
  finally {
        this.oomListenerThread=null;
      }
    }
  }
  super.serviceStop();
}
