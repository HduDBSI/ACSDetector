/** 
 * Process an array of datanode commands
 * @param cmds an array of datanode commands
 * @return true if further processing may be required or false otherwise. 
 */
boolean processCommand(DatanodeCommand[] cmds){
  if (cmds != null) {
    for (    DatanodeCommand cmd : cmds) {
      try {
        if (bpos.processCommandFromActor(cmd,this) == false) {
          return false;
        }
      }
 catch (      IOException ioe) {
        LOG.warn("Error processing datanode Command",ioe);
      }
    }
  }
  return true;
}
