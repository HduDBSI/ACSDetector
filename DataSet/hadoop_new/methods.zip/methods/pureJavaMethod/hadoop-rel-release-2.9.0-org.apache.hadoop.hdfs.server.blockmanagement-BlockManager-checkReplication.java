/** 
 * Check replication of the blocks in the collection. If any block is needed replication, insert it into the replication queue. Otherwise, if the block is more than the expected replication factor, process it as an over replicated block.
 */
public void checkReplication(BlockCollection bc){
  for (  BlockInfo block : bc.getBlocks()) {
    final short expected=getExpectedReplicaNum(block);
    final NumberReplicas n=countNodes(block);
    final int pending=pendingReplications.getNumReplicas(block);
    if (!hasEnoughEffectiveReplicas(block,n,pending)) {
      neededReplications.add(block,n.liveReplicas() + pending,n.readOnlyReplicas(),n.outOfServiceReplicas(),expected);
    }
 else     if (n.liveReplicas() > expected) {
      processOverReplicatedBlock(block,expected,null,null);
    }
  }
}
