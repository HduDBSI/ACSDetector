@Override public boolean isOfType(StorageDirType type){
  if ((this == IMAGE_AND_EDITS) && (type == IMAGE || type == EDITS))   return true;
  return this == type;
}
