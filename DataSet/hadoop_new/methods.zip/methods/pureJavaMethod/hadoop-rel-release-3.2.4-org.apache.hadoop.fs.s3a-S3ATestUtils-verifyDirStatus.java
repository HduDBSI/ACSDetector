/** 
 * Verify the status entry of a directory matches that expected.
 * @param status status entry to check
 * @param replication replication factor
 * @param modTime modified time
 * @param accessTime access time
 * @param owner owner
 * @param group user group
 * @param permission permission.
 */
public static void verifyDirStatus(FileStatus status,int replication,long modTime,long accessTime,String owner,String group,FsPermission permission){
  String details=status.toString();
  assertTrue("Is a dir: " + details,status.isDirectory());
  assertEquals("zero length: " + details,0,status.getLen());
  assertEquals("Mod time: " + details,modTime,status.getModificationTime());
  assertEquals("Replication value: " + details,replication,status.getReplication());
  assertEquals("Access time: " + details,accessTime,status.getAccessTime());
  assertEquals("Owner: " + details,owner,status.getOwner());
  assertEquals("Group: " + details,group,status.getGroup());
  assertEquals("Permission: " + details,permission,status.getPermission());
}
