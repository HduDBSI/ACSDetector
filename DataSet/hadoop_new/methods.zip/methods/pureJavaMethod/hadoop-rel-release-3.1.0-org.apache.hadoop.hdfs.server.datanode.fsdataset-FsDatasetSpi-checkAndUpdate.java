/** 
 * Check whether the in-memory block record matches the block on the disk, and, in case that they are not matched, update the record or mark it as corrupted.
 */
void checkAndUpdate(String bpid,ScanInfo info) throws IOException ;
