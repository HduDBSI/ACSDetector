/** 
 * Get block at the specified position. Fetch it from the namenode if not cached.
 * @param offset block corresponding to this offset in file is returned
 * @return located block
 * @throws IOException
 */
private LocatedBlock getBlockAt(long offset) throws IOException {
synchronized (infoLock) {
    assert (locatedBlocks != null) : "locatedBlocks is null";
    final LocatedBlock blk;
    if (offset < 0 || offset >= getFileLength()) {
      throw new IOException("offset < 0 || offset >= getFileLength(), offset=" + offset + ", locatedBlocks="+ locatedBlocks);
    }
 else     if (offset >= locatedBlocks.getFileLength()) {
      blk=locatedBlocks.getLastLocatedBlock();
    }
 else {
      int targetBlockIdx=locatedBlocks.findBlock(offset);
      if (targetBlockIdx < 0) {
        targetBlockIdx=LocatedBlocks.getInsertIndex(targetBlockIdx);
        final LocatedBlocks newBlocks=dfsClient.getLocatedBlocks(src,offset);
        assert (newBlocks != null) : "Could not find target position " + offset;
        locatedBlocks.insertRange(targetBlockIdx,newBlocks.getLocatedBlocks());
      }
      blk=locatedBlocks.get(targetBlockIdx);
    }
    return blk;
  }
}
