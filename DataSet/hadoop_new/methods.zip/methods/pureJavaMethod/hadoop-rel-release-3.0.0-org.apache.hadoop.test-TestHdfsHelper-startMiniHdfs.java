private static synchronized MiniDFSCluster startMiniHdfs(Configuration conf) throws Exception {
  if (MINI_DFS == null) {
    if (System.getProperty("hadoop.log.dir") == null) {
      System.setProperty("hadoop.log.dir",new File(TEST_DIR_ROOT,"hadoop-log").getAbsolutePath());
    }
    if (System.getProperty("test.build.data") == null) {
      System.setProperty("test.build.data",new File(TEST_DIR_ROOT,"hadoop-data").getAbsolutePath());
    }
    conf=new Configuration(conf);
    HadoopUsersConfTestHelper.addUserConf(conf);
    conf.set("fs.hdfs.impl.disable.cache","true");
    conf.set("dfs.block.access.token.enable","false");
    conf.set("dfs.permissions","true");
    conf.set("hadoop.security.authentication","simple");
    conf.setBoolean(DFSConfigKeys.DFS_NAMENODE_ACLS_ENABLED_KEY,true);
    conf.setBoolean(DFSConfigKeys.DFS_NAMENODE_XATTRS_ENABLED_KEY,true);
    FileSystemTestHelper helper=new FileSystemTestHelper();
    final String jceksPath=JavaKeyStoreProvider.SCHEME_NAME + "://file" + new Path(helper.getTestRootDir(),"test.jks").toUri();
    conf.set(CommonConfigurationKeysPublic.HADOOP_SECURITY_KEY_PROVIDER_PATH,jceksPath);
    MiniDFSCluster.Builder builder=new MiniDFSCluster.Builder(conf);
    int totalDataNodes=ERASURE_CODING_POLICY.getNumDataUnits() + ERASURE_CODING_POLICY.getNumParityUnits();
    builder.numDataNodes(totalDataNodes);
    MiniDFSCluster miniHdfs=builder.build();
    final String testkey="testkey";
    DFSTestUtil.createKey(testkey,miniHdfs,conf);
    DistributedFileSystem fileSystem=miniHdfs.getFileSystem();
    fileSystem.enableErasureCodingPolicy(ERASURE_CODING_POLICY.getName());
    fileSystem.getClient().setKeyProvider(miniHdfs.getNameNode().getNamesystem().getProvider());
    fileSystem.mkdirs(new Path("/tmp"));
    fileSystem.mkdirs(new Path("/user"));
    fileSystem.setPermission(new Path("/tmp"),FsPermission.valueOf("-rwxrwxrwx"));
    fileSystem.setPermission(new Path("/user"),FsPermission.valueOf("-rwxrwxrwx"));
    fileSystem.mkdirs(ENCRYPTION_ZONE);
    fileSystem.createEncryptionZone(ENCRYPTION_ZONE,testkey);
    fileSystem.create(ENCRYPTED_FILE).close();
    fileSystem.mkdirs(ERASURE_CODING_DIR);
    fileSystem.setErasureCodingPolicy(ERASURE_CODING_DIR,ERASURE_CODING_POLICY.getName());
    fileSystem.create(ERASURE_CODING_FILE).close();
    MINI_DFS=miniHdfs;
  }
  return MINI_DFS;
}
