@Test public void checkCoProcessorOff() throws Exception, InterruptedException {
  Configuration hbaseConf=util.getConfiguration();
  TableName table=BaseTableRW.getTableName(hbaseConf,FlowRunTableRW.TABLE_NAME_CONF_NAME,FlowRunTableRW.DEFAULT_TABLE_NAME);
  Connection conn=null;
  conn=ConnectionFactory.createConnection(hbaseConf);
  Admin admin=conn.getAdmin();
  if (admin == null) {
    throw new IOException("Can't check tables since admin is null");
  }
  if (admin.tableExists(table)) {
    util.waitUntilAllRegionsAssigned(table);
    checkCoprocessorExists(table,true);
  }
  table=BaseTableRW.getTableName(hbaseConf,FlowActivityTableRW.TABLE_NAME_CONF_NAME,FlowActivityTableRW.DEFAULT_TABLE_NAME);
  if (admin.tableExists(table)) {
    util.waitUntilAllRegionsAssigned(table);
    checkCoprocessorExists(table,false);
  }
  table=BaseTableRW.getTableName(hbaseConf,EntityTableRW.TABLE_NAME_CONF_NAME,EntityTableRW.DEFAULT_TABLE_NAME);
  if (admin.tableExists(table)) {
    util.waitUntilAllRegionsAssigned(table);
    checkCoprocessorExists(table,false);
  }
}
