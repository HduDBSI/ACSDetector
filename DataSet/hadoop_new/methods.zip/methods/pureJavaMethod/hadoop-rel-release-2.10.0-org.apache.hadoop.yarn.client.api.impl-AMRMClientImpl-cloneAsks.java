private List<ResourceRequest> cloneAsks(){
  List<ResourceRequest> askList=new ArrayList<ResourceRequest>(ask.size());
  for (  ResourceRequest r : ask) {
    askList.add(ResourceRequest.clone(r));
  }
  return askList;
}
