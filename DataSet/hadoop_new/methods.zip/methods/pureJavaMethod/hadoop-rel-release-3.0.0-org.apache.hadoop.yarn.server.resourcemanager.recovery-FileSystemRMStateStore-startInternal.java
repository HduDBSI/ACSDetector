@Override protected synchronized void startInternal() throws Exception {
  fsConf=new Configuration(getConfig());
  String scheme=fsWorkingPath.toUri().getScheme();
  if (scheme == null) {
    scheme=FileSystem.getDefaultUri(fsConf).getScheme();
  }
  if (scheme != null) {
    String disableCacheName=String.format("fs.%s.impl.disable.cache",scheme);
    fsConf.setBoolean(disableCacheName,true);
  }
  fs=fsWorkingPath.getFileSystem(fsConf);
  mkdirsWithRetries(rmDTSecretManagerRoot);
  mkdirsWithRetries(rmAppRoot);
  mkdirsWithRetries(amrmTokenSecretManagerRoot);
  mkdirsWithRetries(reservationRoot);
}
