@Override public void transition(ComponentInstance instance,ComponentInstanceEvent event){
  if (!instance.component.getCancelUpgradeStatus().isCompleted()) {
    return;
  }
  instance.upgradeInProgress.set(true);
  instance.setContainerState(ContainerState.UPGRADING);
  instance.component.decContainersReady(false);
  Component.UpgradeStatus upgradeStatus=instance.component.getUpgradeStatus();
  instance.reInitHelper(upgradeStatus);
}
