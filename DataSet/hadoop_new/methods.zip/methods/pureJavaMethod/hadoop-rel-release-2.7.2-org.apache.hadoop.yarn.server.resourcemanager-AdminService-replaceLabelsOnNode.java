@Override public ReplaceLabelsOnNodeResponse replaceLabelsOnNode(ReplaceLabelsOnNodeRequest request) throws YarnException, IOException {
  String argName="replaceLabelsOnNode";
  final String msg="set node to labels.";
  UserGroupInformation user=checkAcls(argName);
  checkRMStatus(user.getShortUserName(),argName,msg);
  ReplaceLabelsOnNodeResponse response=recordFactory.newRecordInstance(ReplaceLabelsOnNodeResponse.class);
  try {
    rmContext.getNodeLabelManager().replaceLabelsOnNode(request.getNodeToLabels());
    RMAuditLogger.logSuccess(user.getShortUserName(),argName,"AdminService");
    return response;
  }
 catch (  IOException ioe) {
    throw logAndWrapException(ioe,user.getShortUserName(),argName,msg);
  }
}
