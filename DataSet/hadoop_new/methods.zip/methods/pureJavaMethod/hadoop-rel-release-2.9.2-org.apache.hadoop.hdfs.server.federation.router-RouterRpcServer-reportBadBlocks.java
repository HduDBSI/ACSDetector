@Override public void reportBadBlocks(LocatedBlock[] blocks) throws IOException {
  clientProto.reportBadBlocks(blocks);
}
