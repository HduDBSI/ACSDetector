@Test public void testClusterWithJTClientProvider() throws Exception {
  Configuration conf=new Configuration();
  try {
    conf.set(MRConfig.FRAMEWORK_NAME,"classic");
    conf.set(JTConfig.JT_IPC_ADDRESS,"local");
    new Cluster(conf);
    fail("Cluster with classic Framework name should not use " + "local JT address");
  }
 catch (  IOException e) {
    assertTrue(e.getMessage().contains("Cannot initialize Cluster. Please check"));
  }
}
