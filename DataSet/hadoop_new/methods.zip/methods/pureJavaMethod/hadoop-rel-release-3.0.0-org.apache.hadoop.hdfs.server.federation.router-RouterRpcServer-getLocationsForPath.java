/** 
 * Get the possible locations of a path in the federated cluster.
 * @param path Path to check.
 * @param failIfLocked Fail the request if locked (top mount point).
 * @return Prioritized list of locations in the federated cluster.
 * @throws IOException If the location for this path cannot be determined.
 */
private List<RemoteLocation> getLocationsForPath(String path,boolean failIfLocked) throws IOException {
  try {
    final PathLocation location=this.subclusterResolver.getDestinationForPath(path);
    if (location == null) {
      throw new IOException("Cannot find locations for " + path + " in "+ this.subclusterResolver);
    }
    return location.getDestinations();
  }
 catch (  IOException ioe) {
    if (this.rpcMonitor != null) {
      this.rpcMonitor.routerFailureStateStore();
    }
    throw ioe;
  }
}
