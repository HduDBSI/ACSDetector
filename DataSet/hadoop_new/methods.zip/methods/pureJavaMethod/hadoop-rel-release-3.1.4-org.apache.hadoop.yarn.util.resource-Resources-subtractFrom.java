public static Resource subtractFrom(Resource lhs,Resource rhs){
  int maxLength=ResourceUtils.getNumberOfKnownResourceTypes();
  for (int i=0; i < maxLength; i++) {
    try {
      ResourceInformation rhsValue=rhs.getResourceInformation(i);
      ResourceInformation lhsValue=lhs.getResourceInformation(i);
      long convertedRhs=(rhsValue.getUnits().equals(lhsValue.getUnits())) ? rhsValue.getValue() : UnitsConversionUtil.convert(rhsValue.getUnits(),lhsValue.getUnits(),rhsValue.getValue());
      lhs.setResourceValue(i,lhsValue.getValue() - convertedRhs);
    }
 catch (    ResourceNotFoundException ye) {
      LOG.warn("Resource is missing:" + ye.getMessage());
      continue;
    }
  }
  return lhs;
}
