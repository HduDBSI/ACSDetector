private long fetchLocatedBlocksAndGetLastBlockLength(boolean refresh) throws IOException {
  LocatedBlocks newInfo=locatedBlocks;
  if (locatedBlocks == null || refresh) {
    newInfo=dfsClient.getLocatedBlocks(src,0);
  }
  DFSClient.LOG.debug("newInfo = {}",newInfo);
  if (newInfo == null) {
    throw new IOException("Cannot open filename " + src);
  }
  if (locatedBlocks != null) {
    Iterator<LocatedBlock> oldIter=locatedBlocks.getLocatedBlocks().iterator();
    Iterator<LocatedBlock> newIter=newInfo.getLocatedBlocks().iterator();
    while (oldIter.hasNext() && newIter.hasNext()) {
      if (!oldIter.next().getBlock().equals(newIter.next().getBlock())) {
        throw new IOException("Blocklist for " + src + " has changed!");
      }
    }
  }
  locatedBlocks=newInfo;
  long lastBlkBeingWrittenLength=getLastBlockLength();
  fileEncryptionInfo=locatedBlocks.getFileEncryptionInfo();
  return lastBlkBeingWrittenLength;
}
