@Override public void setPinning(ExtendedBlock block) throws IOException {
  if (!blockPinningEnabled) {
    return;
  }
  ReplicaInfo r=getBlockReplica(block);
  r.setPinning(localFS);
}
