public void traverseDirectory() throws IOException {
  if (context.shouldUseIterator()) {
    try (DurationInfo ignored=new DurationInfo(LOG,"Building listing using iterator mode for %s",sourcePathRoot)){
      traverseDirectoryLegacy();
    }
   }
 else {
    try (DurationInfo ignored=new DurationInfo(LOG,"Building listing using multi threaded approach for %s",sourcePathRoot)){
      traverseDirectoryMultiThreaded();
    }
   }
}
