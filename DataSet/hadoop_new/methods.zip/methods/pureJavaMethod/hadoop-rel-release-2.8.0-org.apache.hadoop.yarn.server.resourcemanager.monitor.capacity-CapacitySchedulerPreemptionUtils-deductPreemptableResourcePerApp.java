private static void deductPreemptableResourcePerApp(CapacitySchedulerPreemptionContext context,Resource totalPartitionResource,Collection<TempAppPerPartition> tas,Resource res,String partition){
  for (  TempAppPerPartition ta : tas) {
    ta.deductActuallyToBePreempted(context.getResourceCalculator(),totalPartitionResource,res,partition);
  }
}
