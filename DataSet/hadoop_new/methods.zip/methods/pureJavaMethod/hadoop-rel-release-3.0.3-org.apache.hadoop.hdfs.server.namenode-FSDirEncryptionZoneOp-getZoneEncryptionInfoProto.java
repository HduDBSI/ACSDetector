private static ZoneEncryptionInfoProto getZoneEncryptionInfoProto(final INodesInPath iip) throws IOException {
  final XAttr fileXAttr=FSDirXAttrOp.unprotectedGetXAttrByPrefixedName(iip.getLastINode(),iip.getPathSnapshotId(),CRYPTO_XATTR_ENCRYPTION_ZONE);
  if (fileXAttr == null) {
    throw new IOException("Could not find reencryption XAttr for file " + iip.getPath());
  }
  try {
    return ZoneEncryptionInfoProto.parseFrom(fileXAttr.getValue());
  }
 catch (  InvalidProtocolBufferException e) {
    throw new IOException("Could not parse file encryption info for " + "inode " + iip.getPath(),e);
  }
}
