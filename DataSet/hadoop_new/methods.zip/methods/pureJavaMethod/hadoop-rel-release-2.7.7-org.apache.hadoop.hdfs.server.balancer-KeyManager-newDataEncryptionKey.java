@Override public DataEncryptionKey newDataEncryptionKey(){
  if (encryptDataTransfer) {
synchronized (this) {
      if (encryptionKey == null || encryptionKey.expiryDate < timer.now()) {
        LOG.debug("Generating new data encryption key because current key " + (encryptionKey == null ? "is null." : "expired on " + encryptionKey.expiryDate));
        encryptionKey=blockTokenSecretManager.generateDataEncryptionKey();
      }
      return encryptionKey;
    }
  }
 else {
    return null;
  }
}
