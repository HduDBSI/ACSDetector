@Override public long renew(Token<?> token,Configuration conf) throws IOException {
  LOG.debug("Renewing delegation token {}",token);
  KeyProvider keyProvider=KMSUtil.createKeyProvider(conf,KeyProviderFactory.KEY_PROVIDER_PATH);
  try {
    if (!(keyProvider instanceof KeyProviderDelegationTokenExtension.DelegationTokenExtension)) {
      LOG.warn("keyProvider {} cannot renew dt.",keyProvider == null ? "null" : keyProvider.getClass());
      return 0;
    }
    return ((KeyProviderDelegationTokenExtension.DelegationTokenExtension)keyProvider).renewDelegationToken(token);
  }
  finally {
    if (keyProvider != null) {
      keyProvider.close();
    }
  }
}
