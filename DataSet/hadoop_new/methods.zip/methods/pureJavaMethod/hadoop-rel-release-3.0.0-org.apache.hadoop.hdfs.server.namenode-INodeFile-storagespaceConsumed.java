/** 
 * Compute size consumed by all blocks of the current file, including blocks in its snapshots. Use preferred block size for the last block if it is under construction.
 */
public final QuotaCounts storagespaceConsumed(BlockStoragePolicy bsp){
  if (isStriped()) {
    return storagespaceConsumedStriped();
  }
 else {
    return storagespaceConsumedContiguous(bsp);
  }
}
