@Override public void createEncryptionZone(String src,String keyName) throws IOException {
  clientProto.createEncryptionZone(src,keyName);
}
