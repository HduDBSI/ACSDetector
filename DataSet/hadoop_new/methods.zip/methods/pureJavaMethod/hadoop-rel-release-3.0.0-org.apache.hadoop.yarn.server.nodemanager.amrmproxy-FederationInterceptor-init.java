/** 
 * Initializes the instance using specified context.
 */
@Override public void init(AMRMProxyApplicationContext appContext){
  super.init(appContext);
  LOG.info("Initializing Federation Interceptor");
  Configuration conf=appContext.getConf();
  if (conf == null) {
    conf=getConf();
  }
 else {
    setConf(conf);
  }
  try {
    this.appOwner=UserGroupInformation.createProxyUser(appContext.getUser(),UserGroupInformation.getCurrentUser());
  }
 catch (  Exception ex) {
    throw new YarnRuntimeException(ex);
  }
  this.homeSubClusterId=SubClusterId.newInstance(YarnConfiguration.getClusterId(conf));
  this.homeRM=createHomeRMProxy(appContext);
  this.federationFacade=FederationStateStoreFacade.getInstance();
  this.subClusterResolver=this.federationFacade.getSubClusterResolver();
  this.policyInterpreter=null;
  this.uamPool.init(conf);
  this.uamPool.start();
}
