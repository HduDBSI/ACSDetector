/** 
 * Sends client SASL negotiation for general-purpose handshake.
 * @param addr connection address
 * @param underlyingOut connection output stream
 * @param underlyingIn connection input stream
 * @param accessToken connection block access token
 * @param datanodeId ID of destination DataNode
 * @return new pair of streams, wrapped after SASL negotiation
 * @throws IOException for any error
 */
private IOStreamPair getSaslStreams(InetAddress addr,OutputStream underlyingOut,InputStream underlyingIn,Token<BlockTokenIdentifier> accessToken,DatanodeID datanodeId) throws IOException {
  Map<String,String> saslProps=saslPropsResolver.getClientProperties(addr);
  String userName=buildUserName(accessToken);
  char[] password=buildClientPassword(accessToken);
  CallbackHandler callbackHandler=new SaslClientCallbackHandler(userName,password);
  return doSaslHandshake(underlyingOut,underlyingIn,userName,saslProps,callbackHandler);
}
