private static long buildPermissionStatus(INodeAttributes n,final SaverContext.DeduplicationMap<String> stringMap){
  long userId=stringMap.getId(n.getUserName());
  long groupId=stringMap.getId(n.getGroupName());
  return ((userId & USER_GROUP_STRID_MASK) << USER_STRID_OFFSET) | ((groupId & USER_GROUP_STRID_MASK) << GROUP_STRID_OFFSET) | n.getFsPermissionShort();
}
