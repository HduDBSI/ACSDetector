@Test public void testSpecialCharSymlinks() throws IOException {
  File shellFile=null;
  File tempFile=null;
  String badSymlink=Shell.WINDOWS ? "foo@zz_#!-+bar.cmd" : "foo@zz%_#*&!-+= bar()";
  File symLinkFile=null;
  try {
    shellFile=Shell.appendScriptExtension(tmpDir,"hello");
    tempFile=Shell.appendScriptExtension(tmpDir,"temp");
    String timeoutCommand=Shell.WINDOWS ? "@echo \"hello\"" : "echo \"hello\"";
    PrintWriter writer=new PrintWriter(new FileOutputStream(shellFile));
    FileUtil.setExecutable(shellFile,true);
    writer.println(timeoutCommand);
    writer.close();
    Map<Path,List<String>> resources=new HashMap<Path,List<String>>();
    Path path=new Path(shellFile.getAbsolutePath());
    resources.put(path,Arrays.asList(badSymlink));
    FileOutputStream fos=new FileOutputStream(tempFile);
    Map<String,String> env=new HashMap<String,String>();
    List<String> commands=new ArrayList<String>();
    if (Shell.WINDOWS) {
      commands.add("cmd");
      commands.add("/c");
      commands.add("\"" + badSymlink + "\"");
    }
 else {
      commands.add("/bin/sh ./\\\"" + badSymlink + "\\\"");
    }
    DefaultContainerExecutor executor=new DefaultContainerExecutor();
    executor.setConf(conf);
    executor.writeLaunchEnv(fos,env,resources,commands,new Path(localLogDir.getAbsolutePath()),tempFile.getName());
    fos.flush();
    fos.close();
    FileUtil.setExecutable(tempFile,true);
    Shell.ShellCommandExecutor shexc=new Shell.ShellCommandExecutor(new String[]{tempFile.getAbsolutePath()},tmpDir);
    shexc.execute();
    assertEquals(shexc.getExitCode(),0);
    assert (shexc.getOutput().contains("hello"));
    symLinkFile=new File(tmpDir,badSymlink);
  }
  finally {
    if (shellFile != null && shellFile.exists()) {
      shellFile.delete();
    }
    if (tempFile != null && tempFile.exists()) {
      tempFile.delete();
    }
    if (symLinkFile != null && symLinkFile.exists()) {
      symLinkFile.delete();
    }
  }
}
