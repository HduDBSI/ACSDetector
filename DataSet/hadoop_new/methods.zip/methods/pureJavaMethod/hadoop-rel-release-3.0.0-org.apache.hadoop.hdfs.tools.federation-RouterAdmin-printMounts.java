private static void printMounts(List<MountTable> entries){
  System.out.println("Mount Table Entries:");
  System.out.println(String.format("%-25s %-25s","Source","Destinations"));
  for (  MountTable entry : entries) {
    StringBuilder destBuilder=new StringBuilder();
    for (    RemoteLocation location : entry.getDestinations()) {
      if (destBuilder.length() > 0) {
        destBuilder.append(",");
      }
      destBuilder.append(String.format("%s->%s",location.getNameserviceId(),location.getDest()));
    }
    System.out.println(String.format("%-25s %-25s",entry.getSourcePath(),destBuilder.toString()));
  }
}
