void interruptThread();
