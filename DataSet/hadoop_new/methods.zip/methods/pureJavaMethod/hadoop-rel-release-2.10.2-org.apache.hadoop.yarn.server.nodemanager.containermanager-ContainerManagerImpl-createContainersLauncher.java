protected AbstractContainersLauncher createContainersLauncher(Context ctxt,ContainerExecutor exec){
  Class<? extends AbstractContainersLauncher> containersLauncherClass=ctxt.getConf().getClass(YarnConfiguration.NM_CONTAINERS_LAUNCHER_CLASS,ContainersLauncher.class,AbstractContainersLauncher.class);
  AbstractContainersLauncher launcher;
  try {
    launcher=ReflectionUtils.newInstance(containersLauncherClass,ctxt.getConf());
    launcher.init(ctxt,this.dispatcher,exec,dirsHandler,this);
  }
 catch (  Exception e) {
    throw new RuntimeException(e);
  }
  return launcher;
}
