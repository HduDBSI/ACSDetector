public static ImmutableList<AclEntry> loadAclEntries(AclFeatureProto proto,final StringTable stringTable){
  ImmutableList.Builder<AclEntry> b=ImmutableList.builder();
  for (  int v : proto.getEntriesList()) {
    b.add(AclEntryStatusFormat.toAclEntry(v,stringTable));
  }
  return b.build();
}
