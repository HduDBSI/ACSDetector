private static void copyEditLogSegmentsToSharedDir(FSNamesystem fsns,Collection<URI> sharedEditsDirs,NNStorage newSharedStorage,Configuration conf) throws IOException {
  Preconditions.checkArgument(!sharedEditsDirs.isEmpty(),"No shared edits specified");
  List<URI> sharedEditsUris=new ArrayList<URI>(sharedEditsDirs);
  FSEditLog newSharedEditLog=new FSEditLog(conf,newSharedStorage,sharedEditsUris);
  newSharedEditLog.initJournalsForWrite();
  newSharedEditLog.recoverUnclosedStreams();
  FSEditLog sourceEditLog=fsns.getFSImage().editLog;
  long fromTxId=fsns.getFSImage().getMostRecentCheckpointTxId();
  Collection<EditLogInputStream> streams=null;
  try {
    streams=sourceEditLog.selectInputStreams(fromTxId + 1,0);
    newSharedEditLog.setNextTxId(fromTxId + 1);
    for (    EditLogInputStream stream : streams) {
      LOG.debug("Beginning to copy stream " + stream + " to shared edits");
      FSEditLogOp op;
      boolean segmentOpen=false;
      while ((op=stream.readOp()) != null) {
        if (LOG.isTraceEnabled()) {
          LOG.trace("copying op: " + op);
        }
        if (!segmentOpen) {
          newSharedEditLog.startLogSegment(op.txid,false,fsns.getEffectiveLayoutVersion());
          segmentOpen=true;
        }
        newSharedEditLog.logEdit(op);
        if (op.opCode == FSEditLogOpCodes.OP_END_LOG_SEGMENT) {
          newSharedEditLog.endCurrentLogSegment(false);
          LOG.debug("ending log segment because of END_LOG_SEGMENT op in " + stream);
          segmentOpen=false;
        }
      }
      if (segmentOpen) {
        LOG.debug("ending log segment because of end of stream in " + stream);
        newSharedEditLog.logSync();
        newSharedEditLog.endCurrentLogSegment(false);
        segmentOpen=false;
      }
    }
  }
  finally {
    if (streams != null) {
      FSEditLog.closeAllStreams(streams);
    }
  }
}
