/** 
 * create a hdfs file status from an iip.
 * @param fsd FSDirectory
 * @param iip The INodesInPath containing the INodeFile and its ancestors
 * @return HdfsFileStatus without locations or storage policy
 */
static HdfsFileStatus createFileStatusForEditLog(FSDirectory fsd,INodesInPath iip) throws IOException {
  return createFileStatus(fsd,iip,null,HdfsConstants.BLOCK_STORAGE_POLICY_ID_UNSPECIFIED,false);
}
