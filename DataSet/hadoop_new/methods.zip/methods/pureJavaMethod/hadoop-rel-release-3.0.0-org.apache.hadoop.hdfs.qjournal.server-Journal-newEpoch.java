/** 
 * Try to create a new epoch for this journal.
 * @param nsInfo the namespace, which is verified for consistency or used toformat, if the Journal has not yet been written to.
 * @param epoch the epoch to start
 * @return the status information necessary to begin recovery
 * @throws IOException if the node has already made a promise to anotherwriter with a higher epoch number, if the namespace is inconsistent, or if a disk error occurs.
 */
synchronized NewEpochResponseProto newEpoch(NamespaceInfo nsInfo,long epoch) throws IOException {
  checkFormatted();
  storage.checkConsistentNamespace(nsInfo);
  if (epoch <= getLastPromisedEpoch()) {
    throw new IOException("Proposed epoch " + epoch + " <= last promise "+ getLastPromisedEpoch());
  }
  updateLastPromisedEpoch(epoch);
  abortCurSegment();
  NewEpochResponseProto.Builder builder=NewEpochResponseProto.newBuilder();
  EditLogFile latestFile=scanStorageForLatestEdits();
  if (latestFile != null) {
    builder.setLastSegmentTxId(latestFile.getFirstTxId());
  }
  return builder.build();
}
