@Override public Object invoke(Object proxy,Method method,Object[] args) throws Throwable {
  final boolean isRpc=isRpcInvocation(proxyDescriptor.getProxy());
  final int callId=isRpc ? Client.nextCallId() : RpcConstants.INVALID_CALL_ID;
  final Call call=newCall(method,args,isRpc,callId);
  while (true) {
    final CallReturn c=call.invokeOnce();
    final CallReturn.State state=c.getState();
    if (state == CallReturn.State.ASYNC_INVOKED) {
      return null;
    }
 else     if (c.getState() != CallReturn.State.RETRY) {
      return c.getReturnValue();
    }
  }
}
