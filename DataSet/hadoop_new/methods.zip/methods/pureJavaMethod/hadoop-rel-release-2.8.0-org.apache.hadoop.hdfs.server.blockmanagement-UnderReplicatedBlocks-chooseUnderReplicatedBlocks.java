/** 
 * Get a list of block lists to be replicated. The index of block lists represents its replication priority. Iterates each block list in priority order beginning with the highest priority list. Iterators use a bookmark to resume where the previous iteration stopped. Returns when the block count is met or iteration reaches the end of the lowest priority list, in which case bookmarks for each block list are reset to the heads of their respective lists.
 * @param blocksToProcess - number of blocks to fetch from underReplicatedblocks.
 * @return Return a list of block lists to be replicated. The block list indexrepresents its replication priority.
 */
synchronized List<List<BlockInfo>> chooseUnderReplicatedBlocks(int blocksToProcess){
  final List<List<BlockInfo>> blocksToReplicate=new ArrayList<>(LEVEL);
  int count=0;
  int priority=0;
  for (; count < blocksToProcess && priority < LEVEL; priority++) {
    if (priority == QUEUE_WITH_CORRUPT_BLOCKS) {
      continue;
    }
    final Iterator<BlockInfo> i=priorityQueues.get(priority).getBookmark();
    final List<BlockInfo> blocks=new LinkedList<>();
    blocksToReplicate.add(blocks);
    for (; count < blocksToProcess && i.hasNext(); count++) {
      blocks.add(i.next());
    }
  }
  if (priority == LEVEL) {
    for (    LightWeightLinkedSet<BlockInfo> q : priorityQueues) {
      q.resetBookmark();
    }
  }
  return blocksToReplicate;
}
