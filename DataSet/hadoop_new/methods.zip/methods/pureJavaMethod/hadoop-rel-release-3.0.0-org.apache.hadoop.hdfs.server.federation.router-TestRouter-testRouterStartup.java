private static void testRouterStartup(Configuration routerConfig) throws InterruptedException, IOException {
  Router router=new Router();
  assertEquals(STATE.NOTINITED,router.getServiceState());
  router.init(routerConfig);
  assertEquals(STATE.INITED,router.getServiceState());
  router.start();
  assertEquals(STATE.STARTED,router.getServiceState());
  router.stop();
  assertEquals(STATE.STOPPED,router.getServiceState());
  router.close();
}
