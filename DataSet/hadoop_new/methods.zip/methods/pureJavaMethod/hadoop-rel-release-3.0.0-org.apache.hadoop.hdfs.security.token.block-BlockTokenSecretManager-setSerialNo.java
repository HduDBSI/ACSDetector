@VisibleForTesting public synchronized void setSerialNo(int serialNo){
  this.serialNo=(serialNo % intRange) + (nnRangeStart);
}
