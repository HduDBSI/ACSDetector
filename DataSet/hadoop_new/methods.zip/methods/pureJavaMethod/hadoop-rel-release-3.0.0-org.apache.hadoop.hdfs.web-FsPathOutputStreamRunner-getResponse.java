@Override FSDataOutputStream getResponse(final HttpURLConnection conn) throws IOException {
  return new FSDataOutputStream(new BufferedOutputStream(conn.getOutputStream(),bufferSize),statistics){
    @Override public void close() throws IOException {
      try {
        super.close();
      }
  finally {
        try {
          validateResponse(op,conn,true);
        }
  finally {
          conn.disconnect();
        }
      }
    }
  }
;
}
