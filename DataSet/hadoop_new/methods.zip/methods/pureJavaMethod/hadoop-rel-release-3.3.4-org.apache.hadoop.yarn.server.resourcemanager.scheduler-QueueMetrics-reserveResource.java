public void reserveResource(String partition,String user,Resource res){
  if (partition == null || partition.equals(RMNodeLabelsManager.NO_LABEL)) {
    internalReserveResources(partition,user,res);
  }
  QueueMetrics partitionQueueMetrics=getPartitionQueueMetrics(partition);
  if (partitionQueueMetrics != null) {
    partitionQueueMetrics.internalReserveResources(partition,user,res);
    QueueMetrics partitionMetrics=getPartitionMetrics(partition);
    if (partitionMetrics != null) {
      partitionMetrics.incrReserveResources(res);
    }
  }
}
