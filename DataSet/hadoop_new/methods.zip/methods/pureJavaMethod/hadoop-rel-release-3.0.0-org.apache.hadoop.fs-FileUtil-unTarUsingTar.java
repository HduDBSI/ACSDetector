private static void unTarUsingTar(File inFile,File untarDir,boolean gzipped) throws IOException {
  StringBuffer untarCommand=new StringBuffer();
  if (gzipped) {
    untarCommand.append(" gzip -dc '");
    untarCommand.append(FileUtil.makeShellPath(inFile));
    untarCommand.append("' | (");
  }
  untarCommand.append("cd '");
  untarCommand.append(FileUtil.makeShellPath(untarDir));
  untarCommand.append("' ; ");
  untarCommand.append("tar -xf ");
  if (gzipped) {
    untarCommand.append(" -)");
  }
 else {
    untarCommand.append(FileUtil.makeShellPath(inFile));
  }
  String[] shellCmd={"bash","-c",untarCommand.toString()};
  ShellCommandExecutor shexec=new ShellCommandExecutor(shellCmd);
  shexec.execute();
  int exitcode=shexec.getExitCode();
  if (exitcode != 0) {
    throw new IOException("Error untarring file " + inFile + ". Tar process exited with exit code "+ exitcode);
  }
}
