/** 
 * Create FileStatus for an given INodeFile.
 * @param iip The INodesInPath containing the INodeFile and its ancestors
 */
static HdfsFileStatus createFileStatusForEditLog(FSDirectory fsd,String fullPath,byte[] path,byte storagePolicy,int snapshot,boolean isRawPath,INodesInPath iip) throws IOException {
  INodeAttributes nodeAttrs=getINodeAttributes(fsd,fullPath,path,iip.getLastINode(),snapshot);
  return createFileStatus(fsd,path,nodeAttrs,storagePolicy,snapshot,isRawPath,iip);
}
