/** 
 * Check if native-bzip2 code is loaded & initialized correctly and  can be loaded for this job.
 * @param conf configuration
 * @return <code>true</code> if native-bzip2 is loaded & initialized and can be loaded for this job, else <code>false</code>
 */
public static synchronized boolean isNativeBzip2Loaded(Configuration conf){
  String libname=conf.get("io.compression.codec.bzip2.library","system-native");
  if (!bzip2LibraryName.equals(libname)) {
    nativeBzip2Loaded=false;
    bzip2LibraryName=libname;
    if (libname.equals("java-builtin")) {
      LOG.info("Using pure-Java version of bzip2 library");
    }
 else     if (NativeCodeLoader.isNativeCodeLoaded()) {
      try {
        Bzip2Compressor.initSymbols(libname);
        Bzip2Decompressor.initSymbols(libname);
        nativeBzip2Loaded=true;
        LOG.info("Successfully loaded & initialized native-bzip2 library " + libname);
      }
 catch (      Throwable t) {
        LOG.warn("Failed to load/initialize native-bzip2 library " + libname + ", will use pure-Java version");
      }
    }
  }
  return nativeBzip2Loaded;
}
