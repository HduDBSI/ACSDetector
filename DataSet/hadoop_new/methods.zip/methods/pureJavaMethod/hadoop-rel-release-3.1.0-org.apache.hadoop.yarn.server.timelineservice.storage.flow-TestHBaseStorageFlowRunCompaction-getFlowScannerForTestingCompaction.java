private FlowScanner getFlowScannerForTestingCompaction(){
  FlowScanner fs=new FlowScanner(null,null,FlowScannerOperation.MAJOR_COMPACTION);
  assertNotNull(fs);
  return fs;
}
