/** 
 * Simple http server. Server should send answer with status 200
 */
@BeforeClass public static void start() throws Exception {
  server=new Server(0);
  Context context=new Context();
  context.setContextPath("/foo");
  server.setHandler(context);
  context.addServlet(new ServletHolder(TestServlet.class),"/bar");
  server.getConnectors()[0].setHost("localhost");
  server.start();
  originalPort=server.getConnectors()[0].getLocalPort();
  LOG.info("Running embedded servlet container at: http://localhost:" + originalPort);
}
