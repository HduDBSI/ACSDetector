@Override protected void completedContainerInternal(RMContainer rmContainer,ContainerStatus containerStatus,RMContainerEventType event){
  Container container=rmContainer.getContainer();
  ContainerId containerId=container.getId();
  FiCaSchedulerApp application=getCurrentAttemptForContainer(container.getId());
  ApplicationId appId=containerId.getApplicationAttemptId().getApplicationId();
  if (application == null) {
    LOG.info("Container " + container + " of"+ " finished application "+ appId+ " completed with event "+ event);
    return;
  }
  FiCaSchedulerNode node=getNode(container.getNodeId());
  if (null == node) {
    LOG.info("Container " + container + " of"+ " removed node "+ container.getNodeId()+ " completed with event "+ event);
    return;
  }
  LeafQueue queue=(LeafQueue)application.getQueue();
  queue.completedContainer(getClusterResource(),application,node,rmContainer,containerStatus,event,null,true);
}
