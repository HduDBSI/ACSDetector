private ReplicationWork scheduleReplication(BlockInfo block,int priority){
  if (block.isDeleted() || !block.isCompleteOrCommitted()) {
    neededReplications.remove(block,priority);
    return null;
  }
  short requiredReplication=getExpectedReplicaNum(block);
  List<DatanodeDescriptor> containingNodes=new ArrayList<>();
  List<DatanodeStorageInfo> liveReplicaNodes=new ArrayList<>();
  NumberReplicas numReplicas=new NumberReplicas();
  DatanodeDescriptor srcNode=chooseSourceDatanode(block,containingNodes,liveReplicaNodes,numReplicas,priority);
  if (srcNode == null) {
    LOG.debug("Block " + block + " cannot be repl from any node");
    return null;
  }
  assert liveReplicaNodes.size() >= numReplicas.liveReplicas();
  int pendingNum=pendingReplications.getNumReplicas(block);
  if (hasEnoughEffectiveReplicas(block,numReplicas,pendingNum,requiredReplication)) {
    neededReplications.remove(block,priority);
    blockLog.debug("BLOCK* Removing {} from neededReplications as" + " it has enough replicas",block);
    return null;
  }
  final int additionalReplRequired;
  if (numReplicas.liveReplicas() < requiredReplication) {
    additionalReplRequired=requiredReplication - numReplicas.liveReplicas() - pendingNum;
  }
 else {
    additionalReplRequired=1;
  }
  final BlockCollection bc=getBlockCollection(block);
  return new ReplicationWork(block,bc,srcNode,containingNodes,liveReplicaNodes,additionalReplRequired,priority);
}
