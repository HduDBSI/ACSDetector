LocalizerRunner(LocalizerContext context,String localizerId){
  super("LocalizerRunner for " + localizerId);
  this.context=context;
  this.localizerId=localizerId;
  this.pending=Collections.synchronizedList(new ArrayList<LocalizerResourceRequestEvent>());
  this.scheduled=new HashMap<LocalResourceRequest,LocalizerResourceRequestEvent>();
}
