/** 
 * Delete the block file and meta file from the disk synchronously, adjust dfsUsed statistics accordingly.
 */
void deleteSync(FsVolumeReference volumeRef,ReplicaInfo replicaToDelete,ExtendedBlock block,String trashDirectory){
  LOG.info("Deleting " + block.getLocalBlock() + " replica "+ replicaToDelete);
  ReplicaFileDeleteTask deletionTask=new ReplicaFileDeleteTask(volumeRef,replicaToDelete,block,trashDirectory);
  deletionTask.run();
}
