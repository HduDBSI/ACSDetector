@Override public String toString(){
  final StringBuilder sb=new StringBuilder("SemaphoredDelegatingExecutor{");
  sb.append("permitCount=").append(getPermitCount());
  sb.append(", available=").append(getAvailablePermits());
  sb.append(", waiting=").append(getWaitingCount());
  sb.append('}');
  return sb.toString();
}
