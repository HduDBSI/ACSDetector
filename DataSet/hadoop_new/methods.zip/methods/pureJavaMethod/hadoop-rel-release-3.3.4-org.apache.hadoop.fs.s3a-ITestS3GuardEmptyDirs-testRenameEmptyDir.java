/** 
 * Rename an empty directory, verify that the empty dir marker moves in both S3Guard and in the S3A FS.
 */
@Test public void testRenameEmptyDir() throws Throwable {
  S3AFileSystem fs=getFileSystem();
  Path basePath=path(getMethodName());
  Path sourceDir=new Path(basePath,"AAA-source");
  String sourceDirMarker=fs.pathToKey(sourceDir) + "/";
  Path destDir=new Path(basePath,"BBB-dest");
  String destDirMarker=fs.pathToKey(destDir) + "/";
  mkdirs(sourceDir);
  span();
  fs.getObjectMetadata(sourceDirMarker);
  S3AFileStatus srcStatus=getEmptyDirStatus(sourceDir);
  assertEquals("Must be an empty dir: " + srcStatus,Tristate.TRUE,srcStatus.isEmptyDirectory());
  assertRenameOutcome(fs,sourceDir,destDir,true);
  S3AFileStatus destStatus=getEmptyDirStatus(destDir);
  assertEquals("Must be an empty dir: " + destStatus,Tristate.TRUE,destStatus.isEmptyDirectory());
  intercept(FileNotFoundException.class,() -> getEmptyDirStatus(sourceDir));
  intercept(FileNotFoundException.class,() -> Invoker.once("HEAD",sourceDirMarker,() -> {
    span();
    ObjectMetadata md=fs.getObjectMetadata(sourceDirMarker);
    return String.format("Object %s of length %d",sourceDirMarker,md.getInstanceLength());
  }
));
  S3AFileStatus baseStatus=getEmptyDirStatus(basePath);
  assertEquals("Must not be an empty dir: " + baseStatus,Tristate.FALSE,baseStatus.isEmptyDirectory());
  span();
  fs.getObjectMetadata(destDirMarker);
}
