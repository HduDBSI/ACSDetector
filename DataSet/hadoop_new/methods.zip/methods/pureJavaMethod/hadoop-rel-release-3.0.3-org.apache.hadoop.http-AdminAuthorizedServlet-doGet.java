@Override protected void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
  if (HttpServer2.hasAdministratorAccess(getServletContext(),request,response)) {
    super.doGet(request,response);
  }
}
