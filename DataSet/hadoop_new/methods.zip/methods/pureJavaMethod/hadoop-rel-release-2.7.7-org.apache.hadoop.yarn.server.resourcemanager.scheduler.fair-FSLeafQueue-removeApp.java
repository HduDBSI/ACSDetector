/** 
 * Removes the given app from this queue.
 * @return whether or not the app was runnable
 */
public boolean removeApp(FSAppAttempt app){
  boolean runnable=false;
  writeLock.lock();
  try {
    runnable=runnableApps.remove(app);
    if (!runnable) {
      if (!removeNonRunnableApp(app)) {
        throw new IllegalStateException("Given app to remove " + app + " does not exist in queue "+ this);
      }
    }
  }
  finally {
    writeLock.unlock();
  }
  if (runnable && app.isAmRunning() && app.getAMResource() != null) {
    Resources.subtractFrom(amResourceUsage,app.getAMResource());
  }
  return runnable;
}
