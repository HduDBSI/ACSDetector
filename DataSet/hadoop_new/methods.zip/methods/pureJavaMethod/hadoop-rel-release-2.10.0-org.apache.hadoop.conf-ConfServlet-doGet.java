@Override public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
  if (!HttpServer2.isInstrumentationAccessAllowed(getServletContext(),request,response)) {
    return;
  }
  String format=parseAccecptHeader(request);
  if (FORMAT_XML.equals(format)) {
    response.setContentType("text/xml; charset=utf-8");
  }
 else   if (FORMAT_JSON.equals(format)) {
    response.setContentType("application/json; charset=utf-8");
  }
  String name=request.getParameter("name");
  Writer out=response.getWriter();
  try {
    writeResponse(getConfFromContext(),out,format,name);
  }
 catch (  BadFormatException bfe) {
    response.sendError(HttpServletResponse.SC_BAD_REQUEST,bfe.getMessage());
  }
catch (  IllegalArgumentException iae) {
    response.sendError(HttpServletResponse.SC_NOT_FOUND,iae.getMessage());
  }
  out.close();
}
