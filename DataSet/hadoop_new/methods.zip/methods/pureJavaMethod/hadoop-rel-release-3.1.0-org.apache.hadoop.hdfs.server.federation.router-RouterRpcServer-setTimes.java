@Override public void setTimes(String src,long mtime,long atime) throws IOException {
  checkOperation(OperationCategory.WRITE);
  final List<RemoteLocation> locations=getLocationsForPath(src,true);
  RemoteMethod method=new RemoteMethod("setTimes",new Class<?>[]{String.class,long.class,long.class},new RemoteParam(),mtime,atime);
  rpcClient.invokeSequential(locations,method);
}
