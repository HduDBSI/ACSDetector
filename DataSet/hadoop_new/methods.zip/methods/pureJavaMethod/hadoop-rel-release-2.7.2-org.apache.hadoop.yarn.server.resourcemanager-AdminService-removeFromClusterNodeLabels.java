@Override public RemoveFromClusterNodeLabelsResponse removeFromClusterNodeLabels(RemoveFromClusterNodeLabelsRequest request) throws YarnException, IOException {
  String argName="removeFromClusterNodeLabels";
  final String msg="remove labels.";
  UserGroupInformation user=checkAcls(argName);
  checkRMStatus(user.getShortUserName(),argName,msg);
  RemoveFromClusterNodeLabelsResponse response=recordFactory.newRecordInstance(RemoveFromClusterNodeLabelsResponse.class);
  try {
    rmContext.getNodeLabelManager().removeFromClusterNodeLabels(request.getNodeLabels());
    RMAuditLogger.logSuccess(user.getShortUserName(),argName,"AdminService");
    return response;
  }
 catch (  IOException ioe) {
    throw logAndWrapException(ioe,user.getShortUserName(),argName,msg);
  }
}
