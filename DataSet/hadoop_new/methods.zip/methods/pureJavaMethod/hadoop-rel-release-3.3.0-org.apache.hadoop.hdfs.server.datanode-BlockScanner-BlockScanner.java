public BlockScanner(DataNode datanode,Configuration conf){
  this.datanode=datanode;
  this.conf=new Conf(conf);
  if (isEnabled()) {
    LOG.info("Initialized block scanner with targetBytesPerSec {}",this.conf.targetBytesPerSec);
  }
 else {
    LOG.info("Disabled block scanner.");
  }
}
