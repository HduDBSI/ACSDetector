@Override public int compare(TempAppPerPartition ta1,TempAppPerPartition ta2){
  Priority p1=Priority.newInstance(ta1.getPriority());
  Priority p2=Priority.newInstance(ta2.getPriority());
  if (!p1.equals(p2)) {
    return p1.compareTo(p2);
  }
  return ta1.getApplicationId().compareTo(ta2.getApplicationId());
}
