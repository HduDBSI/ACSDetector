@VisibleForTesting public PlacementRule getUserGroupMappingPlacementRule() throws IOException {
  try {
    readLock.lock();
    UserGroupMappingPlacementRule ugRule=new UserGroupMappingPlacementRule();
    ugRule.initialize(this);
    return ugRule;
  }
  finally {
    readLock.unlock();
  }
}
