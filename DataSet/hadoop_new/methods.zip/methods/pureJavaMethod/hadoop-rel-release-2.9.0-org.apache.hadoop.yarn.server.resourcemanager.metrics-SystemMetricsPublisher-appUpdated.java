void appUpdated(RMApp app,long updatedTime);
