@Override public void transition(RMAppImpl app,RMAppEvent event){
  app.handler.handle(new AppAddedSchedulerEvent(app.applicationId,app.submissionContext.getQueue(),app.user,app.submissionContext.getReservationID()));
}
