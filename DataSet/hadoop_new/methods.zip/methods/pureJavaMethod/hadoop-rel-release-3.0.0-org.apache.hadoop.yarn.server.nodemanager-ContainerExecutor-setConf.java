@Override public void setConf(Configuration conf){
  this.conf=conf;
  if (conf != null) {
    whitelistVars=conf.get(YarnConfiguration.NM_ENV_WHITELIST,YarnConfiguration.DEFAULT_NM_ENV_WHITELIST).split(",");
  }
}
