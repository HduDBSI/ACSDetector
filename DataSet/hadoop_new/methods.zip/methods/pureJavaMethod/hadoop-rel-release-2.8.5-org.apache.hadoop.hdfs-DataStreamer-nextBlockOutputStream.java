/** 
 * Open a DataStreamer to a DataNode so that it can be written to. This happens when a file is created and each time a new block is allocated. Must get block ID and the IDs of the destinations from the namenode. Returns the list of target datanodes.
 */
protected LocatedBlock nextBlockOutputStream() throws IOException {
  LocatedBlock lb;
  DatanodeInfo[] nodes;
  StorageType[] storageTypes;
  int count=dfsClient.getConf().getNumBlockWriteRetry();
  boolean success;
  final ExtendedBlock oldBlock=block.getCurrentBlock();
  do {
    errorState.reset();
    lastException.clear();
    success=false;
    DatanodeInfo[] excluded=getExcludedNodes();
    lb=locateFollowingBlock(excluded.length > 0 ? excluded : null,oldBlock);
    block.setCurrentBlock(lb.getBlock());
    block.setNumBytes(0);
    bytesSent=0;
    accessToken=lb.getBlockToken();
    nodes=lb.getLocations();
    storageTypes=lb.getStorageTypes();
    success=createBlockOutputStream(nodes,storageTypes,0L,false);
    if (!success) {
      LOG.warn("Abandoning " + block);
      dfsClient.namenode.abandonBlock(block.getCurrentBlock(),stat.getFileId(),src,dfsClient.clientName);
      block.setCurrentBlock(null);
      final DatanodeInfo badNode=nodes[errorState.getBadNodeIndex()];
      LOG.warn("Excluding datanode " + badNode);
      excludedNodes.put(badNode,badNode);
    }
  }
 while (!success && --count >= 0);
  if (!success) {
    throw new IOException("Unable to create new block.");
  }
  return lb;
}
