/** 
 * Returns list of groups for a user.
 * @param user get groups for this user
 * @return list of groups for a given user
 */
@Override public synchronized List<String> getGroups(String user) throws IOException {
  Set<String> groupSet=new TreeSet<String>();
  List<String> groups=null;
  for (  GroupMappingServiceProvider provider : providersList) {
    try {
      groups=provider.getGroups(user);
    }
 catch (    Exception e) {
      LOG.warn("Unable to get groups for user {} via {} because: {}",user,provider.getClass().getSimpleName(),e.toString());
      LOG.debug("Stacktrace: ",e);
    }
    if (groups != null && !groups.isEmpty()) {
      groupSet.addAll(groups);
      if (!combined)       break;
    }
  }
  List<String> results=new ArrayList<String>(groupSet.size());
  results.addAll(groupSet);
  return results;
}
