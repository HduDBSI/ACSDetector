private static void publishContainerEndEvent(final TimelineClient timelineClient,ContainerStatus container,String domainId,UserGroupInformation ugi){
  final TimelineEntity entity=new TimelineEntity();
  entity.setEntityId(container.getContainerId().toString());
  entity.setEntityType(DSEntity.DS_CONTAINER.toString());
  entity.setDomainId(domainId);
  entity.addPrimaryFilter("user",ugi.getShortUserName());
  TimelineEvent event=new TimelineEvent();
  event.setTimestamp(System.currentTimeMillis());
  event.setEventType(DSEvent.DS_CONTAINER_END.toString());
  event.addEventInfo("State",container.getState().name());
  event.addEventInfo("Exit Status",container.getExitStatus());
  entity.addEvent(event);
  try {
    ugi.doAs(new PrivilegedExceptionAction<TimelinePutResponse>(){
      @Override public TimelinePutResponse run() throws Exception {
        return timelineClient.putEntities(entity);
      }
    }
);
  }
 catch (  Exception e) {
    LOG.error("Container end event could not be published for " + container.getContainerId().toString(),e instanceof UndeclaredThrowableException ? e.getCause() : e);
  }
}
