@Override public String getMessage(){
  String msg=super.getMessage();
  if (msg != null) {
    return msg;
  }
  return getResolvedPath().toString();
}
