private void testEnvHelper(boolean inheritParentEnv) throws Exception {
  Map<String,String> customEnv=new HashMap<>();
  customEnv.put("AAA" + System.currentTimeMillis(),"AAA");
  customEnv.put("BBB" + System.currentTimeMillis(),"BBB");
  customEnv.put("CCC" + System.currentTimeMillis(),"CCC");
  Shell.ShellCommandExecutor command=new ShellCommandExecutor(new String[]{"env"},null,customEnv,0L,inheritParentEnv);
  command.execute();
  String[] varsArr=command.getOutput().split("\n");
  Map<String,String> vars=new HashMap<>();
  for (  String var : varsArr) {
    int eqIndex=var.indexOf('=');
    vars.put(var.substring(0,eqIndex),var.substring(eqIndex + 1));
  }
  Map<String,String> expectedEnv=new HashMap<>();
  expectedEnv.putAll(customEnv);
  if (inheritParentEnv) {
    expectedEnv.putAll(System.getenv());
  }
  assertEquals(expectedEnv,vars);
}
