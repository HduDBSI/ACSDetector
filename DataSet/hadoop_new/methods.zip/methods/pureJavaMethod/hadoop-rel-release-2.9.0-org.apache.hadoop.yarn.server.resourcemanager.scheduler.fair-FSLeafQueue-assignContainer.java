@Override public Resource assignContainer(FSSchedulerNode node){
  Resource assigned=none();
  if (LOG.isDebugEnabled()) {
    LOG.debug("Node " + node.getNodeName() + " offered to queue: "+ getName()+ " fairShare: "+ getFairShare());
  }
  if (!assignContainerPreCheck(node)) {
    return assigned;
  }
  for (  FSAppAttempt sched : fetchAppsWithDemand(true)) {
    if (SchedulerAppUtils.isPlaceBlacklisted(sched,node,LOG)) {
      continue;
    }
    assigned=sched.assignContainer(node);
    if (!assigned.equals(none())) {
      if (LOG.isDebugEnabled()) {
        LOG.debug("Assigned container in queue:" + getName() + " "+ "container:"+ assigned);
      }
      break;
    }
  }
  return assigned;
}
