/** 
 * Instantiate.
 * @param conf configuration to read.
 */
public S3ARetryPolicy(Configuration conf){
  Preconditions.checkArgument(conf != null,"Null configuration");
  this.configuration=conf;
  int limit=conf.getInt(RETRY_LIMIT,RETRY_LIMIT_DEFAULT);
  long interval=conf.getTimeDuration(RETRY_INTERVAL,RETRY_INTERVAL_DEFAULT,TimeUnit.MILLISECONDS);
  baseExponentialRetry=exponentialBackoffRetry(limit,interval,TimeUnit.MILLISECONDS);
  LOG.debug("Retrying on recoverable AWS failures {} times with an" + " initial interval of {}ms",limit,interval);
  retryIdempotentCalls=new FailNonIOEs(new IdempotencyRetryFilter(baseExponentialRetry));
  throttlePolicy=createThrottleRetryPolicy(conf);
  connectivityFailure=baseExponentialRetry;
  Map<Class<? extends Exception>,RetryPolicy> policyMap=createExceptionMap();
  retryPolicy=retryByException(retryIdempotentCalls,policyMap);
}
