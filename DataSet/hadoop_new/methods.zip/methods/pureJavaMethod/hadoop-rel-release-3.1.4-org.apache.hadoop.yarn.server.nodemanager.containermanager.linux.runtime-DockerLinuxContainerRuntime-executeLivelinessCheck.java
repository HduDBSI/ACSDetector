private void executeLivelinessCheck(ContainerRuntimeContext ctx) throws ContainerExecutionException {
  String procFs=ctx.getExecutionAttribute(PROCFS);
  if (procFs == null || procFs.isEmpty()) {
    procFs=DEFAULT_PROCFS;
  }
  String pid=ctx.getExecutionAttribute(PID);
  if (!new File(procFs + File.separator + pid).exists()) {
    String msg="Liveliness check failed for PID: " + pid + ". Container may have already completed.";
    throw new ContainerExecutionException(msg,PrivilegedOperation.ResultCode.INVALID_CONTAINER_PID.getValue());
  }
}
