@Override public boolean recoverLease(String src,String clientName) throws IOException {
  return clientProto.recoverLease(src,clientName);
}
