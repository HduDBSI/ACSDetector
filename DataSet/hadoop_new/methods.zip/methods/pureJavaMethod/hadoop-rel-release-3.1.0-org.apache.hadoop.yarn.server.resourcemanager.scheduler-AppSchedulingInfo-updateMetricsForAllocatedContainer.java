private void updateMetricsForAllocatedContainer(NodeType type,SchedulerNode node,Container containerAllocated){
  QueueMetrics metrics=queue.getMetrics();
  if (pending) {
    pending=false;
    metrics.runAppAttempt(applicationId,user);
  }
  updateMetrics(applicationId,type,node,containerAllocated,user,queue);
}
