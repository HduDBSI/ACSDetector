public void run(){
  try {
    appLogAggregator.run();
  }
  finally {
    appLogAggregators.remove(appId);
    closeFileSystems(userUgi);
  }
}
