private void deleteTempFile(Path tempPath){
  try {
    if (tempPath != null && fs.exists(tempPath)) {
      fs.delete(tempPath,false);
    }
  }
 catch (  IOException ignore) {
  }
}
