@Override protected void processPath(PathData item) throws IOException {
  out.println("# file: " + item);
  out.println("# owner: " + item.stat.getOwner());
  out.println("# group: " + item.stat.getGroup());
  FsPermission perm=item.stat.getPermission();
  if (perm.getStickyBit()) {
    out.println("# flags: --" + (perm.getOtherAction().implies(FsAction.EXECUTE) ? "t" : "T"));
  }
  AclStatus aclStatus=item.fs.getAclStatus(item.path);
  List<AclEntry> entries=perm.getAclBit() ? aclStatus.getEntries() : Collections.<AclEntry>emptyList();
  ScopedAclEntries scopedEntries=new ScopedAclEntries(AclUtil.getAclFromPermAndEntries(perm,entries));
  printAclEntriesForSingleScope(aclStatus,perm,scopedEntries.getAccessEntries());
  printAclEntriesForSingleScope(aclStatus,perm,scopedEntries.getDefaultEntries());
  out.println();
}
