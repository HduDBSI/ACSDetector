private static GetUserMappingsProtocol createNNProxyWithGetUserMappingsProtocol(InetSocketAddress address,Configuration conf,UserGroupInformation ugi) throws IOException {
  GetUserMappingsProtocolPB proxy=(GetUserMappingsProtocolPB)createNameNodeProxy(address,conf,ugi,GetUserMappingsProtocolPB.class);
  return new GetUserMappingsProtocolClientSideTranslatorPB(proxy);
}
