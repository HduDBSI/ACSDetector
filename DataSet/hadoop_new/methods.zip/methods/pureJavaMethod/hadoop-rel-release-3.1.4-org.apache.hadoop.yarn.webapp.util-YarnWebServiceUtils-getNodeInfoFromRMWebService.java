/** 
 * Utility function to get NodeInfo by calling RM WebService.
 * @param conf the configuration
 * @param nodeId the nodeId
 * @return a JSONObject which contains the NodeInfo
 * @throws ClientHandlerException if there is an errorprocessing the response.
 * @throws UniformInterfaceException if the response statusis 204 (No Content).
 */
public static JSONObject getNodeInfoFromRMWebService(Configuration conf,String nodeId) throws ClientHandlerException, UniformInterfaceException {
  try {
    return WebAppUtils.execOnActiveRM(conf,YarnWebServiceUtils::getNodeInfoFromRM,nodeId);
  }
 catch (  Exception e) {
    if (e instanceof ClientHandlerException) {
      throw ((ClientHandlerException)e);
    }
 else     if (e instanceof UniformInterfaceException) {
      throw ((UniformInterfaceException)e);
    }
 else {
      throw new RuntimeException(e);
    }
  }
}
