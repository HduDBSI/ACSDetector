public void interruptThread(){
  Thread thread=writer.get();
  if (thread != null && thread != Thread.currentThread() && thread.isAlive()) {
    thread.interrupt();
  }
}
