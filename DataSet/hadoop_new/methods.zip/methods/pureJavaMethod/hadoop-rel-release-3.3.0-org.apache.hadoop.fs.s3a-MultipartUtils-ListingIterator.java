ListingIterator(AmazonS3 s3,Invoker invoker,String bucketName,int maxKeys,@Nullable String prefix) throws IOException {
  this.s3=s3;
  this.bucketName=bucketName;
  this.maxKeys=maxKeys;
  this.prefix=prefix;
  this.invoker=invoker;
  requestNextBatch();
}
