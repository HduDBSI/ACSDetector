private void codecTestMapFile(Class<? extends CompressionCodec> clazz,CompressionType type,int records) throws Exception {
  FileSystem fs=FileSystem.get(conf);
  LOG.info("Creating MapFiles with " + records + " records using codec "+ clazz.getSimpleName());
  Path path=new Path(GenericTestUtils.getTempPath(clazz.getSimpleName() + "-" + type+ "-"+ records));
  LOG.info("Writing " + path);
  createMapFile(conf,fs,path,clazz.newInstance(),type,records);
  MapFile.Reader reader=new MapFile.Reader(path,conf);
  Text key1=new Text("002");
  assertNotNull(reader.get(key1,new Text()));
  Text key2=new Text("004");
  assertNotNull(reader.get(key2,new Text()));
}
