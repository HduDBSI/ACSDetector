private boolean requestNextBatch(){
  while (!meetEnd) {
    if (continueListStatus()) {
      return true;
    }
  }
  return false;
}
