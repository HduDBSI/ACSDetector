TestContext(Configuration conf,int numNameServices) throws Exception {
  this.numNameServices=numNameServices;
  File basedir=new File(GenericTestUtils.getRandomizedTempPath());
  MiniDFSCluster.Builder bld=new MiniDFSCluster.Builder(conf,basedir).numDataNodes(1).storagesPerDatanode(1);
  if (numNameServices > 1) {
    bld.nnTopology(MiniDFSNNTopology.simpleFederatedTopology(numNameServices));
  }
  cluster=bld.build();
  cluster.waitActive();
  dfs=new DistributedFileSystem[numNameServices];
  for (int i=0; i < numNameServices; i++) {
    dfs[i]=cluster.getFileSystem(i);
  }
  bpids=new String[numNameServices];
  for (int i=0; i < numNameServices; i++) {
    bpids[i]=cluster.getNamesystem(i).getBlockPoolId();
  }
  datanode=cluster.getDataNodes().get(0);
  blockScanner=datanode.getBlockScanner();
  for (int i=0; i < numNameServices; i++) {
    dfs[i].mkdirs(new Path("/test"));
  }
  data=datanode.getFSDataset();
  volumes=data.getFsVolumeReferences();
}
