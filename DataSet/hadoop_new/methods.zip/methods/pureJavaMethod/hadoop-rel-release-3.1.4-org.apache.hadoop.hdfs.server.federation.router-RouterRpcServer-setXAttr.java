@Override public void setXAttr(String src,XAttr xAttr,EnumSet<XAttrSetFlag> flag) throws IOException {
  clientProto.setXAttr(src,xAttr,flag);
}
