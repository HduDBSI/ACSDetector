@Override protected synchronized void removeRMDelegationTokenState(RMDelegationTokenIdentifier rmDTIdentifier) throws Exception {
  String nodeRemovePath=getLeafDelegationTokenNodePath(rmDTIdentifier.getSequenceNumber(),false);
  int splitIndex=delegationTokenNodeSplitIndex;
  if (!exists(nodeRemovePath)) {
    ZnodeSplitInfo alternatePathInfo=getAlternateDTPath(rmDTIdentifier.getSequenceNumber());
    if (alternatePathInfo != null) {
      nodeRemovePath=alternatePathInfo.path;
      splitIndex=alternatePathInfo.splitIndex;
    }
 else {
      return;
    }
  }
  if (LOG.isDebugEnabled()) {
    LOG.debug("Removing RMDelegationToken_" + rmDTIdentifier.getSequenceNumber());
  }
  zkManager.safeDelete(nodeRemovePath,zkAcl,fencingNodePath);
  checkRemoveParentZnode(nodeRemovePath,splitIndex);
}
