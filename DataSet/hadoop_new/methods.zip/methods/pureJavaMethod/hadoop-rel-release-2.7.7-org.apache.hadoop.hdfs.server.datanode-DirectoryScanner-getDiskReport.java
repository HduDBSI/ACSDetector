/** 
 * Get the lists of blocks on the disks in the dataset, sorted by blockId. The returned map contains one entry per blockpool, keyed by the blockpool ID.
 * @return a map of sorted arrays of block information
 */
private Map<String,ScanInfo[]> getDiskReport(){
  final List<? extends FsVolumeSpi> volumes=dataset.getVolumes();
  ScanInfoPerBlockPool[] dirReports=new ScanInfoPerBlockPool[volumes.size()];
  Map<Integer,Future<ScanInfoPerBlockPool>> compilersInProgress=new HashMap<Integer,Future<ScanInfoPerBlockPool>>();
  for (int i=0; i < volumes.size(); i++) {
    if (isValid(dataset,volumes.get(i))) {
      ReportCompiler reportCompiler=new ReportCompiler(datanode,volumes.get(i));
      Future<ScanInfoPerBlockPool> result=reportCompileThreadPool.submit(reportCompiler);
      compilersInProgress.put(i,result);
    }
  }
  for (  Entry<Integer,Future<ScanInfoPerBlockPool>> report : compilersInProgress.entrySet()) {
    try {
      dirReports[report.getKey()]=report.getValue().get();
      if (dirReports[report.getKey()] == null) {
        dirReports=null;
        break;
      }
    }
 catch (    Exception ex) {
      LOG.error("Error compiling report",ex);
      throw new RuntimeException(ex);
    }
  }
  ScanInfoPerBlockPool list=new ScanInfoPerBlockPool();
  if (dirReports != null) {
    for (int i=0; i < volumes.size(); i++) {
      if (isValid(dataset,volumes.get(i))) {
        list.addAll(dirReports[i]);
      }
    }
  }
  return list.toSortedArrays();
}
