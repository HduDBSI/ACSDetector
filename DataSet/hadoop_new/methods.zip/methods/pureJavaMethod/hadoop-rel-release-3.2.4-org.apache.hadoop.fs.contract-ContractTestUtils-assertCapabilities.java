/** 
 * Custom assert to test  {@link StreamCapabilities}.
 * @param stream The stream to test for StreamCapabilities
 * @param shouldHaveCapabilities The array of expected capabilities
 * @param shouldNotHaveCapabilities The array of unexpected capabilities
 */
public static void assertCapabilities(Object stream,String[] shouldHaveCapabilities,String[] shouldNotHaveCapabilities){
  assertTrue("Stream should be instanceof StreamCapabilities",stream instanceof StreamCapabilities);
  StreamCapabilities source=(StreamCapabilities)stream;
  if (shouldHaveCapabilities != null) {
    for (    String shouldHaveCapability : shouldHaveCapabilities) {
      assertTrue("Should have capability: " + shouldHaveCapability,source.hasCapability(shouldHaveCapability));
    }
  }
  if (shouldNotHaveCapabilities != null) {
    for (    String shouldNotHaveCapability : shouldNotHaveCapabilities) {
      assertFalse("Should not have capability: " + shouldNotHaveCapability,source.hasCapability(shouldNotHaveCapability));
    }
  }
}
