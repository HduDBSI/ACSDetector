@Override public Boolean get(){
  return (volume.getReservedForRbw() == 0);
}
