public NamenodeBeanMetrics(Router router){
  this.router=router;
  try {
    StandardMBean bean=new StandardMBean(this,FSNamesystemMBean.class);
    this.fsBeanName=MBeans.register("NameNode","FSNamesystem",bean);
    LOG.info("Registered FSNamesystem MBean: {}",this.fsBeanName);
  }
 catch (  NotCompliantMBeanException e) {
    throw new RuntimeException("Bad FSNamesystem MBean setup",e);
  }
  try {
    StandardMBean bean=new StandardMBean(this,FSNamesystemMBean.class);
    this.fsStateBeanName=MBeans.register("NameNode","FSNamesystemState",bean);
    LOG.info("Registered FSNamesystemState MBean: {}",this.fsStateBeanName);
  }
 catch (  NotCompliantMBeanException e) {
    throw new RuntimeException("Bad FSNamesystemState MBean setup",e);
  }
  try {
    StandardMBean bean=new StandardMBean(this,NameNodeMXBean.class);
    this.nnInfoBeanName=MBeans.register("NameNode","NameNodeInfo",bean);
    LOG.info("Registered NameNodeInfo MBean: {}",this.nnInfoBeanName);
  }
 catch (  NotCompliantMBeanException e) {
    throw new RuntimeException("Bad NameNodeInfo MBean setup",e);
  }
  try {
    StandardMBean bean=new StandardMBean(this,NameNodeStatusMXBean.class);
    this.nnStatusBeanName=MBeans.register("NameNode","NameNodeStatus",bean);
    LOG.info("Registered NameNodeStatus MBean: {}",this.nnStatusBeanName);
  }
 catch (  NotCompliantMBeanException e) {
    throw new RuntimeException("Bad NameNodeStatus MBean setup",e);
  }
}
