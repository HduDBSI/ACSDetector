/** 
 * Resolve the short name of the Path given the URI, parent provided. This FileStatus reference will not contain a valid Path until it is resolved by this method.
 * @param defaultUri FileSystem to fully qualify HDFS path.
 * @param parent Parent path of this element.
 * @return Reference to this instance.
 */
public final FileStatus makeQualified(URI defaultUri,Path parent){
  setPath(getFullPath(parent).makeQualified(defaultUri,null));
  return this;
}
