@Override public Map<NodeId,LogAggregationReport> getLogAggregationReportsForApp(){
  try {
    this.readLock.lock();
    if (!isLogAggregationFinished() && isAppInFinalState(this) && systemClock.getTime() > this.logAggregationStartTime + this.logAggregationStatusTimeout) {
      for (      Entry<NodeId,LogAggregationReport> output : logAggregationStatus.entrySet()) {
        if (!output.getValue().getLogAggregationStatus().equals(LogAggregationStatus.TIME_OUT) && !output.getValue().getLogAggregationStatus().equals(LogAggregationStatus.SUCCEEDED) && !output.getValue().getLogAggregationStatus().equals(LogAggregationStatus.FAILED)) {
          output.getValue().setLogAggregationStatus(LogAggregationStatus.TIME_OUT);
        }
      }
    }
    return Collections.unmodifiableMap(logAggregationStatus);
  }
  finally {
    this.readLock.unlock();
  }
}
