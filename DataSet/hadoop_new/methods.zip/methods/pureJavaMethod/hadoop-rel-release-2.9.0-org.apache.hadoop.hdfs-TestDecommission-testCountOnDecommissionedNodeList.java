/** 
 * Fetching Live DataNodes by passing removeDecommissionedNode value as false- returns LiveNodeList with Node in Decommissioned state true - returns LiveNodeList without Node in Decommissioned state
 * @throws InterruptedException
 */
@Test public void testCountOnDecommissionedNodeList() throws IOException {
  getConf().setInt(DFSConfigKeys.DFS_HEARTBEAT_INTERVAL_KEY,1);
  getConf().setInt(DFSConfigKeys.DFS_NAMENODE_HEARTBEAT_RECHECK_INTERVAL_KEY,1);
  try {
    startCluster(1,1);
    ArrayList<ArrayList<DatanodeInfo>> namenodeDecomList=new ArrayList<ArrayList<DatanodeInfo>>(1);
    namenodeDecomList.add(0,new ArrayList<DatanodeInfo>(1));
    ArrayList<DatanodeInfo> decommissionedNode=namenodeDecomList.get(0);
    takeNodeOutofService(0,null,0,decommissionedNode,AdminStates.DECOMMISSIONED);
    FSNamesystem ns=getCluster().getNamesystem(0);
    DatanodeManager datanodeManager=ns.getBlockManager().getDatanodeManager();
    List<DatanodeDescriptor> live=new ArrayList<DatanodeDescriptor>();
    datanodeManager.fetchDatanodes(live,null,false);
    assertTrue(1 == live.size());
    datanodeManager.fetchDatanodes(live,null,true);
    assertTrue(0 == live.size());
  }
  finally {
    shutdownCluster();
  }
}
