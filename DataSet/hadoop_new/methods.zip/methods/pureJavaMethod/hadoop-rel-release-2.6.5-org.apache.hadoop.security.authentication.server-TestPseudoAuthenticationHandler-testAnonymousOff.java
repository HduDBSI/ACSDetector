@Test public void testAnonymousOff() throws Exception {
  PseudoAuthenticationHandler handler=new PseudoAuthenticationHandler();
  try {
    Properties props=new Properties();
    props.setProperty(PseudoAuthenticationHandler.ANONYMOUS_ALLOWED,"false");
    handler.init(props);
    HttpServletRequest request=Mockito.mock(HttpServletRequest.class);
    HttpServletResponse response=Mockito.mock(HttpServletResponse.class);
    handler.authenticate(request,response);
    Assert.fail();
  }
 catch (  AuthenticationException ex) {
  }
catch (  Exception ex) {
    Assert.fail();
  }
 finally {
    handler.destroy();
  }
}
