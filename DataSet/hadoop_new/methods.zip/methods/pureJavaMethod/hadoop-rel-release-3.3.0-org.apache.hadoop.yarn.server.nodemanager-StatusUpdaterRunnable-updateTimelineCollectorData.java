private void updateTimelineCollectorData(NodeHeartbeatResponse response){
  Map<ApplicationId,AppCollectorData> incomingCollectorsMap=response.getAppCollectors();
  if (incomingCollectorsMap == null) {
    LOG.debug("No collectors to update RM");
    return;
  }
  Map<ApplicationId,AppCollectorData> knownCollectors=context.getKnownCollectors();
  for (  Map.Entry<ApplicationId,AppCollectorData> entry : incomingCollectorsMap.entrySet()) {
    ApplicationId appId=entry.getKey();
    AppCollectorData collectorData=entry.getValue();
    Application application=context.getApplications().get(appId);
    if (application != null) {
      AppCollectorData existingData=knownCollectors.get(appId);
      if (AppCollectorData.happensBefore(existingData,collectorData)) {
        LOG.debug("Sync a new collector address: {} for application: {}" + " from RM.",collectorData.getCollectorAddr(),appId);
        NMTimelinePublisher nmTimelinePublisher=context.getNMTimelinePublisher();
        if (nmTimelinePublisher != null) {
          nmTimelinePublisher.setTimelineServiceAddress(application.getAppId(),collectorData.getCollectorAddr());
        }
        knownCollectors.put(appId,collectorData);
      }
    }
    context.getRegisteringCollectors().remove(entry.getKey());
  }
}
