@Override public boolean fitsIn(Resource smaller,Resource bigger){
  int maxLength=ResourceUtils.getNumberOfKnownResourceTypes();
  for (int i=0; i < maxLength; i++) {
    ResourceInformation sResourceInformation=smaller.getResourceInformation(i);
    ResourceInformation bResourceInformation=bigger.getResourceInformation(i);
    if (sResourceInformation.getValue() > bResourceInformation.getValue()) {
      return false;
    }
  }
  return true;
}
