private void loadResources(Properties properties,ArrayList<Resource> resources,boolean quiet){
  if (loadDefaults) {
    for (    String resource : defaultResources) {
      loadResource(properties,new Resource(resource,false),quiet);
    }
  }
  for (int i=0; i < resources.size(); i++) {
    Resource ret=loadResource(properties,resources.get(i),quiet);
    if (ret != null) {
      resources.set(i,ret);
    }
  }
}
