@Test public void testDefaultFsUris() throws Exception {
  final Configuration conf=new Configuration();
  conf.set("fs.defaultfs.impl",DefaultFs.class.getName());
  final URI defaultUri=URI.create("defaultfs://host");
  FileSystem.setDefaultUri(conf,defaultUri);
  FileSystem fs=null;
  final FileSystem defaultFs=FileSystem.get(conf);
  assertEquals(defaultUri,defaultFs.getUri());
  fs=FileSystem.get(URI.create("defaultfs:/"),conf);
  assertSame(defaultFs,fs);
  fs=FileSystem.get(URI.create("defaultfs:///"),conf);
  assertSame(defaultFs,fs);
  fs=FileSystem.get(URI.create("defaultfs://host"),conf);
  assertSame(defaultFs,fs);
  fs=FileSystem.get(URI.create("defaultfs://host2"),conf);
  assertNotSame(defaultFs,fs);
  fs=FileSystem.get(URI.create("/"),conf);
  assertSame(defaultFs,fs);
  try {
    fs=FileSystem.get(URI.create("//host"),conf);
    fail("got fs with auth but no scheme");
  }
 catch (  UnsupportedFileSystemException e) {
  }
  try {
    fs=FileSystem.get(URI.create("//host2"),conf);
    fail("got fs with auth but no scheme");
  }
 catch (  UnsupportedFileSystemException e) {
  }
}
