@Override public boolean isReadyForDownStream(Component component){
  if (hasCompletedSuccessfully(component)) {
    return true;
  }
  return false;
}
