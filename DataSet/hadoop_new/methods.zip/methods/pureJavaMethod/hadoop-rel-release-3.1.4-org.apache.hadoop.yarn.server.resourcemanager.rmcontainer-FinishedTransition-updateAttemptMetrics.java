private static void updateAttemptMetrics(RMContainerImpl container){
  Resource resource=container.getContainer().getResource();
  RMApp app=container.rmContext.getRMApps().get(container.getApplicationAttemptId().getApplicationId());
  if (app != null) {
    RMAppAttempt rmAttempt=app.getCurrentAppAttempt();
    if (rmAttempt != null) {
      long usedMillis=container.finishTime - container.creationTime;
      rmAttempt.getRMAppAttemptMetrics().updateAggregateAppResourceUsage(resource,usedMillis);
      if (ContainerExitStatus.PREEMPTED == container.finishedStatus.getExitStatus()) {
        rmAttempt.getRMAppAttemptMetrics().updatePreemptionInfo(resource,container);
        rmAttempt.getRMAppAttemptMetrics().updateAggregatePreemptedAppResourceUsage(resource,usedMillis);
      }
    }
  }
}
