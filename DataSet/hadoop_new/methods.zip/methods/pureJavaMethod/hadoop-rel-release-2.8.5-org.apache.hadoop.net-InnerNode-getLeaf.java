/** 
 * get <i>leafIndex</i> leaf of this subtree  if it is not in the <i>excludedNode</i>
 * @param leafIndex an indexed leaf of the node
 * @param excludedNode an excluded node (can be null)
 * @return
 */
Node getLeaf(int leafIndex,Node excludedNode){
  int count=0;
  boolean isLeaf=excludedNode == null || !(excludedNode instanceof InnerNode);
  int numOfExcludedLeaves=isLeaf ? 1 : ((InnerNode)excludedNode).getNumOfLeaves();
  if (isLeafParent()) {
    if (isLeaf) {
      if (excludedNode != null && childrenMap.containsKey(excludedNode.getName())) {
        int excludedIndex=children.indexOf(excludedNode);
        if (excludedIndex != -1 && leafIndex >= 0) {
          leafIndex=leafIndex >= excludedIndex ? leafIndex + 1 : leafIndex;
        }
      }
    }
    if (leafIndex < 0 || leafIndex >= this.getNumOfChildren()) {
      return null;
    }
    return children.get(leafIndex);
  }
 else {
    for (int i=0; i < children.size(); i++) {
      InnerNode child=(InnerNode)children.get(i);
      if (excludedNode == null || excludedNode != child) {
        int numOfLeaves=child.getNumOfLeaves();
        if (excludedNode != null && child.isAncestor(excludedNode)) {
          numOfLeaves-=numOfExcludedLeaves;
        }
        if (count + numOfLeaves > leafIndex) {
          return child.getLeaf(leafIndex - count,excludedNode);
        }
 else {
          count=count + numOfLeaves;
        }
      }
 else {
        excludedNode=null;
      }
    }
    return null;
  }
}
