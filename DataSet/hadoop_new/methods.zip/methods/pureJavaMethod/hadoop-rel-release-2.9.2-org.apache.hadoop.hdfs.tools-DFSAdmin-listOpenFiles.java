/** 
 * Command to list all the open files currently managed by NameNode. Usage: hdfs dfsadmin -listOpenFiles
 * @throws IOException
 */
public int listOpenFiles() throws IOException {
  DistributedFileSystem dfs=getDFS();
  RemoteIterator<OpenFileEntry> openFilesRemoteIterator;
  try {
    openFilesRemoteIterator=dfs.listOpenFiles();
    printOpenFiles(openFilesRemoteIterator);
  }
 catch (  IOException ioe) {
    System.out.println("List open files failed.");
    throw ioe;
  }
  return 0;
}
