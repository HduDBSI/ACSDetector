private void testConstructorFailures(String userName){
  try {
    UserGroupInformation.createRemoteUser(userName);
    fail("user:" + userName + " wasn't invalid");
  }
 catch (  IllegalArgumentException e) {
    String expect=(userName == null || userName.isEmpty()) ? "Null user" : "Illegal principal name " + userName;
    assertTrue("Did not find " + expect + " in "+ e,e.toString().contains(expect));
  }
}
