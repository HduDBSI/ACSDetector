@Override public Writable call(RPC.Server server,String protocol,Writable writableRequest,long receiveTime) throws Exception {
  RpcProtobufRequest request=(RpcProtobufRequest)writableRequest;
  RequestHeaderProto rpcRequest=request.getRequestHeader();
  String methodName=rpcRequest.getMethodName();
  String protoName=rpcRequest.getDeclaringClassProtocolName();
  long clientVersion=rpcRequest.getClientProtocolVersion();
  if (server.verbose)   LOG.info("Call: protocol=" + protocol + ", method="+ methodName);
  ProtoClassProtoImpl protocolImpl=getProtocolImpl(server,protoName,clientVersion);
  BlockingService service=(BlockingService)protocolImpl.protocolImpl;
  MethodDescriptor methodDescriptor=service.getDescriptorForType().findMethodByName(methodName);
  if (methodDescriptor == null) {
    String msg="Unknown method " + methodName + " called on "+ protocol+ " protocol.";
    LOG.warn(msg);
    throw new RpcNoSuchMethodException(msg);
  }
  Message prototype=service.getRequestPrototype(methodDescriptor);
  Message param=request.getValue(prototype);
  Message result;
  Call currentCall=Server.getCurCall().get();
  try {
    server.rpcDetailedMetrics.init(protocolImpl.protocolClass);
    currentCallInfo.set(new CallInfo(server,methodName));
    currentCall.setDetailedMetricsName(methodName);
    result=service.callBlockingMethod(methodDescriptor,null,param);
    if (currentCallback.get() != null) {
      currentCall.deferResponse();
      currentCallback.set(null);
      return null;
    }
  }
 catch (  ServiceException e) {
    Exception exception=(Exception)e.getCause();
    currentCall.setDetailedMetricsName(exception.getClass().getSimpleName());
    throw (Exception)e.getCause();
  }
catch (  Exception e) {
    currentCall.setDetailedMetricsName(e.getClass().getSimpleName());
    throw e;
  }
 finally {
    currentCallInfo.set(null);
  }
  return RpcWritable.wrap(result);
}
