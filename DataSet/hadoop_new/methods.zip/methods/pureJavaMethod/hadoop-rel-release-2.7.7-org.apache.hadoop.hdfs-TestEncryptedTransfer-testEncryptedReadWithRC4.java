@Test public void testEncryptedReadWithRC4() throws IOException {
  testEncryptedRead("rc4","",false,false);
}
