void doRead(SelectionKey key) throws InterruptedException {
  int count;
  Connection c=(Connection)key.attachment();
  if (c == null) {
    return;
  }
  c.setLastContact(Time.now());
  try {
    count=c.readAndProcess();
  }
 catch (  InterruptedException ieo) {
    LOG.info(Thread.currentThread().getName() + ": readAndProcess caught InterruptedException",ieo);
    throw ieo;
  }
catch (  Exception e) {
    LOG.info(Thread.currentThread().getName() + ": readAndProcess from client " + c+ " threw exception ["+ e+ "]",e);
    count=-1;
  }
  if (count < 0 || c.shouldClose()) {
    closeConnection(c);
    c=null;
  }
 else {
    c.setLastContact(Time.now());
  }
}
