private void getQueuePlacementPolicy(AllocationFileParser allocationFileParser) throws AllocationConfigurationException {
  if (allocationFileParser.getQueuePlacementPolicy().isPresent()) {
    QueuePlacementPolicy.fromXml(allocationFileParser.getQueuePlacementPolicy().get(),scheduler);
  }
 else {
    QueuePlacementPolicy.fromConfiguration(scheduler);
  }
}
