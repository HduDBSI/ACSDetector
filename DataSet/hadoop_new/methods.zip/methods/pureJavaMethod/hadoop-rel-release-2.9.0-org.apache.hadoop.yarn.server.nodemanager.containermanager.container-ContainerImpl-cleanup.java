@SuppressWarnings("unchecked") public void cleanup(){
  Map<LocalResourceVisibility,Collection<LocalResourceRequest>> rsrc=resourceSet.getAllResourcesByVisibility();
  dispatcher.getEventHandler().handle(new ContainerLocalizationCleanupEvent(this,rsrc));
}
