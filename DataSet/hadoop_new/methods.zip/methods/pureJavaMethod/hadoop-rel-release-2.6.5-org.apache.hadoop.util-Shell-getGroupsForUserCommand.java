/** 
 * a Unix command to get a given user's groups list. If the OS is not WINDOWS, the command will get the user's primary group first and finally get the groups list which includes the primary group. i.e. the user's primary group will be included twice.
 */
public static String[] getGroupsForUserCommand(final String user){
  if (WINDOWS) {
    return new String[]{getWinUtilsPath(),"groups","-F","\"" + user + "\""};
  }
 else {
    String quotedUser=bashQuote(user);
    return new String[]{"bash","-c","id -gn " + quotedUser + "; id -Gn "+ quotedUser};
  }
}
