public MountTableResolver(Configuration conf,StateStoreService store){
  this.router=null;
  this.stateStore=store;
  registerCacheExternal();
  initDefaultNameService(conf);
}
