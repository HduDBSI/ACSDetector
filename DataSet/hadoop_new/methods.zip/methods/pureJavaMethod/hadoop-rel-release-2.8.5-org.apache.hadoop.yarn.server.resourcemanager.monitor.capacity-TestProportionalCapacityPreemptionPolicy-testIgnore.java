@Test public void testIgnore(){
  ProportionalCapacityPreemptionPolicy policy=buildPolicy(Q_DATA_FOR_IGNORE);
  policy.editSchedule();
  verify(mDisp,never()).handle(isA(ContainerPreemptEvent.class));
}
