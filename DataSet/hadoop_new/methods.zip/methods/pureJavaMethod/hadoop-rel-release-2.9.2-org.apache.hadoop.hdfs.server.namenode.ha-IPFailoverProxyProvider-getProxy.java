@Override public synchronized NNProxyInfo<T> getProxy(){
  return createProxyIfNeeded(nnProxyInfo);
}
