StripedReconstructor(ErasureCodingWorker worker,StripedReconstructionInfo stripedReconInfo){
  this.erasureCodingWorker=worker;
  this.datanode=worker.getDatanode();
  this.conf=worker.getConf();
  this.ecPolicy=stripedReconInfo.getEcPolicy();
  liveBitSet=new BitSet(ecPolicy.getNumDataUnits() + ecPolicy.getNumParityUnits());
  for (int i=0; i < stripedReconInfo.getLiveIndices().length; i++) {
    liveBitSet.set(stripedReconInfo.getLiveIndices()[i]);
  }
  blockGroup=stripedReconInfo.getBlockGroup();
  stripedReader=new StripedReader(this,datanode,conf,stripedReconInfo);
  cachingStrategy=CachingStrategy.newDefaultStrategy();
  positionInBlock=0L;
}
