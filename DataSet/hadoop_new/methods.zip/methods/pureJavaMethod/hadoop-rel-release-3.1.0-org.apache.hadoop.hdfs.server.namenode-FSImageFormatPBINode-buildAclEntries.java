private static AclFeatureProto.Builder buildAclEntries(AclFeature f,final SaverContext.DeduplicationMap<String> map){
  AclFeatureProto.Builder b=AclFeatureProto.newBuilder();
  for (int pos=0, e; pos < f.getEntriesSize(); pos++) {
    e=f.getEntryAt(pos);
    int nameId=map.getId(AclEntryStatusFormat.getName(e));
    int v=((nameId & ACL_ENTRY_NAME_MASK) << ACL_ENTRY_NAME_OFFSET) | (AclEntryStatusFormat.getType(e).ordinal() << ACL_ENTRY_TYPE_OFFSET) | (AclEntryStatusFormat.getScope(e).ordinal() << ACL_ENTRY_SCOPE_OFFSET)| (AclEntryStatusFormat.getPermission(e).ordinal());
    b.addEntries(v);
  }
  return b;
}
