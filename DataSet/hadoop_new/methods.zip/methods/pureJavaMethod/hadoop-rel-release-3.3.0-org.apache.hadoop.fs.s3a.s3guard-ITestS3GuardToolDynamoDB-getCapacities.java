private DDBCapacities getCapacities() throws IOException {
  return DDBCapacities.extractCapacities(getMetadataStore().getDiagnostics());
}
