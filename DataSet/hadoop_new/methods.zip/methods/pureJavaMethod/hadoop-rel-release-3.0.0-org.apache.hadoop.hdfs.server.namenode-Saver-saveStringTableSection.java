private void saveStringTableSection(FileSummary.Builder summary) throws IOException {
  OutputStream out=sectionOutputStream;
  StringTableSection.Builder b=StringTableSection.newBuilder().setNumEntry(saverContext.stringMap.size());
  b.build().writeDelimitedTo(out);
  for (  Entry<String,Integer> e : saverContext.stringMap.entrySet()) {
    StringTableSection.Entry.Builder eb=StringTableSection.Entry.newBuilder().setId(e.getValue()).setStr(e.getKey());
    eb.build().writeDelimitedTo(out);
  }
  commitSection(summary,SectionName.STRING_TABLE);
}
