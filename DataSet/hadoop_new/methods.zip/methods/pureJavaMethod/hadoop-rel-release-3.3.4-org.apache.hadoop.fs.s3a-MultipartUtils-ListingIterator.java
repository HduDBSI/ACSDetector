ListingIterator(final StoreContext storeContext,AmazonS3 s3,@Nullable String prefix,int maxKeys) throws IOException {
  this.storeContext=storeContext;
  this.s3=s3;
  this.requestFactory=storeContext.getRequestFactory();
  this.maxKeys=maxKeys;
  this.prefix=prefix;
  this.invoker=storeContext.getInvoker();
  this.auditSpan=storeContext.getActiveAuditSpan();
  requestNextBatch();
}
