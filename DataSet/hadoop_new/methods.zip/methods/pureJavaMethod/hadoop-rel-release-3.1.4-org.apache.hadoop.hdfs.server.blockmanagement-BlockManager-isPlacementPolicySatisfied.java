@Override public boolean isPlacementPolicySatisfied(){
  return true;
}
