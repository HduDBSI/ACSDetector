/** 
 * Analyze storage directories for a specific block pool. Recover from previous transitions if required. Perform fs state transition if necessary depending on the namespace info. Read storage info. <br> This method should be synchronized between multiple DN threads.  Only the first DN thread does DN level storage dir recoverTransitionRead.
 * @param datanode DataNode
 * @param nsInfo Namespace info of namenode corresponding to the block pool
 * @param dataDirs Storage directories
 * @param startOpt startup option
 * @throws IOException on error
 */
void recoverTransitionRead(DataNode datanode,NamespaceInfo nsInfo,Collection<StorageLocation> dataDirs,StartupOption startOpt) throws IOException {
  if (this.initialized) {
    LOG.info("DataNode version: " + HdfsConstants.DATANODE_LAYOUT_VERSION + " and NameNode layout version: "+ nsInfo.getLayoutVersion());
    this.storageDirs=new ArrayList<StorageDirectory>(dataDirs.size());
    this.initialized=true;
  }
  if (addStorageLocations(datanode,nsInfo,dataDirs,startOpt).isEmpty()) {
    throw new IOException("All specified directories are failed to load.");
  }
}
