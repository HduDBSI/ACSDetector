@Override public void preTransition(ContainerImpl op,org.apache.hadoop.yarn.server.nodemanager.containermanager.container.ContainerState beforeState,ContainerEvent eventToBeProcessed){
  if (!states.containsKey(op.getContainerId())) {
    states.put(op.getContainerId(),new ArrayList<>());
    states.get(op.getContainerId()).add(beforeState);
    events.put(op.getContainerId(),new ArrayList<>());
  }
}
