@Retries.RetryTranslated public UploadIterator(final StoreContext storeContext,AmazonS3 s3,int maxKeys,@Nullable String prefix) throws IOException {
  lister=new ListingIterator(storeContext,s3,prefix,maxKeys);
  requestNextBatch();
}
