@Override public void transition(RMAppAttemptImpl appAttempt,RMAppAttemptEvent event){
  if (event.getType() == RMAppAttemptEventType.LAUNCHED || event.getType() == RMAppAttemptEventType.REGISTERED) {
    appAttempt.launchAMEndTime=System.currentTimeMillis();
    long delay=appAttempt.launchAMEndTime - appAttempt.launchAMStartTime;
    ClusterMetrics.getMetrics().addAMLaunchDelay(delay);
  }
  appAttempt.updateAMLaunchDiagnostics(AMState.LAUNCHED.getDiagnosticMessage());
  appAttempt.attemptLaunched();
}
