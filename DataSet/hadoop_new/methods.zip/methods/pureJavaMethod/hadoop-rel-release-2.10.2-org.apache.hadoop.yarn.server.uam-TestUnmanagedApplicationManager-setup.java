@Before public void setup(){
  conf.set(YarnConfiguration.RM_CLUSTER_ID,"subclusterId");
  callback=new CountingCallback();
  attemptId=ApplicationAttemptId.newInstance(ApplicationId.newInstance(0,1),1);
  uam=new TestableUnmanagedApplicationManager(conf,attemptId.getApplicationId(),null,"submitter","appNameSuffix",true,"rm");
}
