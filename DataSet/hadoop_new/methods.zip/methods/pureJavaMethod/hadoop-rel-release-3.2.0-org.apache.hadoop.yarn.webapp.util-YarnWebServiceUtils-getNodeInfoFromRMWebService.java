/** 
 * Utility function to get NodeInfo by calling RM WebService.
 * @param conf the configuration
 * @param nodeId the nodeId
 * @return a JSONObject which contains the NodeInfo
 * @throws ClientHandlerException if there is an errorprocessing the response.
 * @throws UniformInterfaceException if the response statusis 204 (No Content).
 */
public static JSONObject getNodeInfoFromRMWebService(Configuration conf,String nodeId) throws ClientHandlerException, UniformInterfaceException {
  Client webServiceClient=Client.create();
  String webAppAddress=WebAppUtils.getRMWebAppURLWithScheme(conf);
  WebResource webResource=webServiceClient.resource(webAppAddress);
  ClientResponse response=null;
  try {
    response=webResource.path("ws").path("v1").path("cluster").path("nodes").path(nodeId).accept(MediaType.APPLICATION_JSON).get(ClientResponse.class);
    return response.getEntity(JSONObject.class);
  }
  finally {
    if (response != null) {
      response.close();
    }
    webServiceClient.destroy();
  }
}
