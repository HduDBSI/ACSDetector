private void killUnFinishedApplication(ApplicationId appId) throws IOException {
  ApplicationReport application=null;
  try {
    application=resMgrDelegate.getApplicationReport(appId);
  }
 catch (  YarnException e) {
    throw new IOException(e);
  }
  if (Apps.isApplicationFinalState(application.getYarnApplicationState())) {
    return;
  }
  killApplication(appId);
}
