@Override public void getMetrics(MetricsCollector collector,boolean all){
  DecayRpcScheduler scheduler=delegate.get();
  if (scheduler != null) {
    scheduler.getMetrics(collector,all);
  }
}
