/** 
 * Increase resource of a list of containers on this NodeManager.
 */
@Override @Deprecated public IncreaseContainersResourceResponse increaseContainersResource(IncreaseContainersResourceRequest requests) throws YarnException, IOException {
  ContainerUpdateResponse resp=updateContainer(ContainerUpdateRequest.newInstance(requests.getContainersToIncrease()));
  return IncreaseContainersResourceResponse.newInstance(resp.getSuccessfullyUpdatedContainers(),resp.getFailedRequests());
}
