/** 
 * Moves the application with the given ID to the given queue.
 */
private void moveApplicationAcrossQueues(String applicationId,String queue) throws YarnException, IOException {
  ApplicationId appId=ApplicationId.fromString(applicationId);
  ApplicationReport appReport=client.getApplicationReport(appId);
  if (Apps.isApplicationFinalState(appReport.getYarnApplicationState())) {
    sysout.println("Application " + applicationId + " has already finished ");
  }
 else {
    sysout.println("Moving application " + applicationId + " to queue "+ queue);
    client.moveApplicationAcrossQueues(appId,queue);
    sysout.println("Successfully completed move.");
  }
}
