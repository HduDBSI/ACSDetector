@Override public int compare(TempAppPerPartition ta1,TempAppPerPartition ta2){
  if (ta1.getUser().equals(ta2.getUser())) {
    AbstractComparatorOrderingPolicy<FiCaSchedulerApp> acop=(AbstractComparatorOrderingPolicy<FiCaSchedulerApp>)ta1.getFiCaSchedulerApp().getCSLeafQueue().getOrderingPolicy();
    return acop.getComparator().compare(ta1.getFiCaSchedulerApp(),ta2.getFiCaSchedulerApp());
  }
 else {
    Resource usedByUser1=ta1.getTempUserPerPartition().getUsedDeductAM();
    Resource usedByUser2=ta2.getTempUserPerPartition().getUsedDeductAM();
    if (Resources.equals(usedByUser1,usedByUser2)) {
      return ta1.getApplicationId().compareTo(ta2.getApplicationId());
    }
    if (Resources.lessThan(rc,clusterRes,usedByUser1,usedByUser2)) {
      return -1;
    }
 else {
      return 1;
    }
  }
}
