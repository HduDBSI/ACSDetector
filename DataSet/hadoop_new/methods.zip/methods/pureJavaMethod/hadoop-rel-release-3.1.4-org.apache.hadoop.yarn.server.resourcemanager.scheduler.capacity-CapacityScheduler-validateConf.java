private void validateConf(Configuration conf){
  CapacitySchedulerConfigValidator.validateMemoryAllocation(conf);
  CapacitySchedulerConfigValidator.validateVCores(conf);
}
