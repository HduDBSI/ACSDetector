@Override public RefreshQueuesResponse refreshQueues(RefreshQueuesRequest request) throws YarnException, StandbyException {
  String argName="refreshQueues";
  UserGroupInformation user=checkAcls(argName);
  if (!isRMActive()) {
    RMAuditLogger.logFailure(user.getShortUserName(),argName,adminAcl.toString(),"AdminService","ResourceManager is not active. Can not refresh queues.");
    throwStandbyException();
  }
  RefreshQueuesResponse response=recordFactory.newRecordInstance(RefreshQueuesResponse.class);
  try {
    rmContext.getScheduler().reinitialize(getConfig(),this.rmContext);
    ReservationSystem rSystem=rmContext.getReservationSystem();
    if (rSystem != null) {
      rSystem.reinitialize(getConfig(),rmContext);
    }
    RMAuditLogger.logSuccess(user.getShortUserName(),argName,"AdminService");
    return response;
  }
 catch (  IOException ioe) {
    LOG.info("Exception refreshing queues ",ioe);
    RMAuditLogger.logFailure(user.getShortUserName(),argName,adminAcl.toString(),"AdminService","Exception refreshing queues");
    throw RPCUtil.getRemoteException(ioe);
  }
}
