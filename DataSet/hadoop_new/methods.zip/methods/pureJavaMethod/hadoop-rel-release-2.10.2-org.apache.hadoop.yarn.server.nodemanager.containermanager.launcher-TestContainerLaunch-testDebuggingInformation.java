@Test public void testDebuggingInformation() throws IOException {
  File shellFile=null;
  File tempFile=null;
  Configuration conf=new YarnConfiguration();
  try {
    shellFile=Shell.appendScriptExtension(tmpDir,"hello");
    tempFile=Shell.appendScriptExtension(tmpDir,"temp");
    String testCommand=Shell.WINDOWS ? "@echo \"hello\"" : "echo \"hello\"";
    PrintWriter writer=new PrintWriter(new FileOutputStream(shellFile));
    FileUtil.setExecutable(shellFile,true);
    writer.println(testCommand);
    writer.close();
    Map<Path,List<String>> resources=new HashMap<Path,List<String>>();
    Map<String,String> env=new HashMap<String,String>();
    List<String> commands=new ArrayList<String>();
    if (Shell.WINDOWS) {
      commands.add("cmd");
      commands.add("/c");
      commands.add("\"" + shellFile.getAbsolutePath() + "\"");
    }
 else {
      commands.add("/bin/sh \\\"" + shellFile.getAbsolutePath() + "\\\"");
    }
    boolean[] debugLogsExistArray={false,true};
    for (    boolean debugLogsExist : debugLogsExistArray) {
      conf.setBoolean(YarnConfiguration.NM_LOG_CONTAINER_DEBUG_INFO,debugLogsExist);
      FileOutputStream fos=new FileOutputStream(tempFile);
      ContainerExecutor exec=new DefaultContainerExecutor();
      exec.setConf(conf);
      LinkedHashSet<String> nmVars=new LinkedHashSet<>();
      exec.writeLaunchEnv(fos,env,resources,commands,new Path(localLogDir.getAbsolutePath()),"user",tempFile.getName(),nmVars);
      fos.flush();
      fos.close();
      FileUtil.setExecutable(tempFile,true);
      Shell.ShellCommandExecutor shexc=new Shell.ShellCommandExecutor(new String[]{tempFile.getAbsolutePath()},tmpDir);
      shexc.execute();
      assertEquals(shexc.getExitCode(),0);
      File directorInfo=new File(localLogDir,ContainerExecutor.DIRECTORY_CONTENTS);
      File scriptCopy=new File(localLogDir,tempFile.getName());
      Assert.assertEquals("Directory info file missing",debugLogsExist,directorInfo.exists());
      Assert.assertEquals("Copy of launch script missing",debugLogsExist,scriptCopy.exists());
      if (debugLogsExist) {
        Assert.assertTrue("Directory info file size is 0",directorInfo.length() > 0);
        Assert.assertTrue("Size of copy of launch script is 0",scriptCopy.length() > 0);
      }
    }
  }
  finally {
    if (shellFile != null && shellFile.exists()) {
      shellFile.delete();
    }
    if (tempFile != null && tempFile.exists()) {
      tempFile.delete();
    }
  }
}
