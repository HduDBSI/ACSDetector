public void reserveResource(String user,Resource res){
  reservedContainers.incr();
  reservedMB.incr(res.getMemorySize());
  reservedVCores.incr(res.getVirtualCores());
  if (queueMetricsForCustomResources != null) {
    queueMetricsForCustomResources.increaseReserved(res);
    registerCustomResources(queueMetricsForCustomResources.getReservedValues(),RESERVED_RESOURCE_METRIC_PREFIX,RESERVED_RESOURCE_METRIC_DESC);
  }
  QueueMetrics userMetrics=getUserMetrics(user);
  if (userMetrics != null) {
    userMetrics.reserveResource(user,res);
  }
  if (parent != null) {
    parent.reserveResource(user,res);
  }
}
