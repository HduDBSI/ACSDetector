@Override public Resource divideAndCeil(Resource numerator,float denominator){
  return Resources.createResource(divideAndCeil(numerator.getMemorySize(),denominator),divideAndCeil(numerator.getVirtualCores(),denominator));
}
