@Override public TimelineWriteResponse write(TimelineCollectorContext context,TimelineDomain domain) throws IOException {
  return null;
}
