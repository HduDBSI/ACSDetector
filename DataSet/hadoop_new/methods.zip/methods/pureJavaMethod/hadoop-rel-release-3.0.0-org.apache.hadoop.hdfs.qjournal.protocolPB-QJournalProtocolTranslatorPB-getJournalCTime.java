@Override public Long getJournalCTime(String journalId,String nameServiceId) throws IOException {
  try {
    GetJournalCTimeRequestProto.Builder req=GetJournalCTimeRequestProto.newBuilder().setJid(convertJournalId(journalId));
    if (nameServiceId != null) {
      req.setNameServiceId(nameServiceId);
    }
    GetJournalCTimeResponseProto response=rpcProxy.getJournalCTime(NULL_CONTROLLER,req.build());
    return response.getResultCTime();
  }
 catch (  ServiceException e) {
    throw ProtobufHelper.getRemoteException(e);
  }
}
