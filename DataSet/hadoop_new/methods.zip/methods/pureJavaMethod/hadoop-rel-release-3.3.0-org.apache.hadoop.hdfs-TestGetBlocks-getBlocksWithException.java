private void getBlocksWithException(NamenodeProtocol namenode,DatanodeInfo datanode,long size,long minBlockSize) throws IOException {
  boolean getException=false;
  try {
    namenode.getBlocks(datanode,size,minBlockSize);
  }
 catch (  RemoteException e) {
    getException=true;
    assertTrue(e.getClassName().contains("IllegalArgumentException"));
  }
  assertTrue(getException);
}
