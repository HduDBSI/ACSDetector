private HttpURLConnection createConnection(final URL url,String method) throws IOException {
  HttpURLConnection conn;
  try {
    final String doAsUser=getDoAsUser();
    conn=getActualUgi().doAs(new PrivilegedExceptionAction<HttpURLConnection>(){
      @Override public HttpURLConnection run() throws Exception {
        DelegationTokenAuthenticatedURL authUrl=new DelegationTokenAuthenticatedURL(configurator);
        return authUrl.openConnection(url,authToken,doAsUser);
      }
    }
);
  }
 catch (  IOException ex) {
    if (ex instanceof SocketTimeoutException) {
      LOG.warn("Failed to connect to {}:{}",url.getHost(),url.getPort());
    }
    throw ex;
  }
catch (  UndeclaredThrowableException ex) {
    throw new IOException(ex.getUndeclaredThrowable());
  }
catch (  Exception ex) {
    throw new IOException(ex);
  }
  conn.setUseCaches(false);
  conn.setRequestMethod(method);
  if (method.equals(HTTP_POST) || method.equals(HTTP_PUT)) {
    conn.setDoOutput(true);
  }
  conn=configureConnection(conn);
  return conn;
}
