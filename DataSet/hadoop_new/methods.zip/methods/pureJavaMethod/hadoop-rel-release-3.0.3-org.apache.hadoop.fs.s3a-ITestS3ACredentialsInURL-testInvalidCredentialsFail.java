/** 
 * Set up some invalid credentials, verify login is rejected.
 * @throws Throwable
 */
@Test public void testInvalidCredentialsFail() throws Throwable {
  Configuration conf=new Configuration();
  String fsname=conf.getTrimmed(TEST_FS_S3A_NAME,"");
  Assume.assumeNotNull(fsname);
  assumeS3GuardState(false,conf);
  URI original=new URI(fsname);
  URI testURI=createUriWithEmbeddedSecrets(original,"user","//");
  conf.set(TEST_FS_S3A_NAME,testURI.toString());
  try {
    fs=S3ATestUtils.createTestFileSystem(conf);
    FileStatus status=fs.getFileStatus(new Path("/"));
    fail("Expected an AccessDeniedException, got " + status);
  }
 catch (  AccessDeniedException e) {
  }
}
