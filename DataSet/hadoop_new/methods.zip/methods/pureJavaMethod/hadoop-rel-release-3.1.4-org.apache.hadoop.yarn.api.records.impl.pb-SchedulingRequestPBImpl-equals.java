@Override public boolean equals(Object other){
  if (other == null) {
    return false;
  }
  if (other instanceof SchedulingRequest) {
    if (this == other) {
      return true;
    }
    SchedulingRequest that=(SchedulingRequest)other;
    if (getAllocationRequestId() != that.getAllocationRequestId()) {
      return false;
    }
    if (!getAllocationTags().equals(that.getAllocationTags())) {
      return false;
    }
    if (!getPriority().equals(that.getPriority())) {
      return false;
    }
    if (!getExecutionType().equals(that.getExecutionType())) {
      return false;
    }
    if (!getResourceSizing().equals(that.getResourceSizing())) {
      return false;
    }
    return getPlacementConstraint().equals(that.getPlacementConstraint());
  }
  return false;
}
