/** 
 * Get the list of pending uploads for this job attempt.
 * @param context job context
 * @param suppressExceptions should exceptions be swallowed?
 * @return a list of pending uploads. If exceptions are being swallowed,then this may not match the actual set of pending operations
 * @throws IOException Any IO failure which wasn't swallowed.
 */
protected ActiveCommit listPendingUploads(JobContext context,boolean suppressExceptions) throws IOException {
  try (DurationInfo ignored=new DurationInfo(LOG,"Listing pending uploads")){
    Path wrappedJobAttemptPath=getJobAttemptPath(context);
    final FileSystem attemptFS=wrappedJobAttemptPath.getFileSystem(context.getConfiguration());
    return ActiveCommit.fromStatusList(attemptFS,listAndFilter(attemptFS,wrappedJobAttemptPath,false,HIDDEN_FILE_FILTER));
  }
 catch (  FileNotFoundException e) {
    maybeIgnore(suppressExceptions,"Pending upload directory not found",e);
  }
catch (  IOException e) {
    maybeIgnore(suppressExceptions,"Listing pending uploads",e);
  }
  return ActiveCommit.empty();
}
