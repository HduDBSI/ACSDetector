@Override public int compare(Schedulable s1,Schedulable s2){
  int res=compareDemand(s1,s2);
  Resource resourceUsage1=s1.getResourceUsage();
  Resource resourceUsage2=s2.getResourceUsage();
  if (res == 0) {
    res=compareMinShareUsage(s1,s2,resourceUsage1,resourceUsage2);
  }
  if (res == 0) {
    res=compareFairShareUsage(s1,s2,resourceUsage1,resourceUsage2);
  }
  if (res == 0) {
    res=(int)Math.signum(s1.getStartTime() - s2.getStartTime());
  }
  if (res == 0) {
    res=s1.getName().compareTo(s2.getName());
  }
  return res;
}
