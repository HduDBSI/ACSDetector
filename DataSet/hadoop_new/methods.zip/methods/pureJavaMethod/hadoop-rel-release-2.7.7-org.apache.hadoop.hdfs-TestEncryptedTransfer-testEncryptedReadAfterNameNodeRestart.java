@Test public void testEncryptedReadAfterNameNodeRestart() throws IOException {
  testEncryptedRead("","",false,true);
}
