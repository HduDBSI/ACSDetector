@Override public Boolean get(){
  try {
    Mockito.verify(mockNN).blockReport(Mockito.eq(datanodeRegistration),Mockito.eq(POOL_ID),Mockito.any(),Mockito.any());
    return true;
  }
 catch (  Throwable t) {
    LOG.info("waiting on block report: " + t.getMessage());
    return false;
  }
}
