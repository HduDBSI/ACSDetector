/** 
 * Create a new encryption zone. <p/> Called while holding the FSDirectory lock.
 */
XAttr createEncryptionZone(INodesInPath srcIIP,CipherSuite suite,CryptoProtocolVersion version,String keyName) throws IOException {
  assert dir.hasWriteLock();
  if (srcIIP.getLastINode() == null) {
    throw new FileNotFoundException("cannot find " + srcIIP.getPath());
  }
  if (dir.isNonEmptyDirectory(srcIIP)) {
    throw new IOException("Attempt to create an encryption zone for a non-empty directory.");
  }
  INode srcINode=srcIIP.getLastINode();
  if (!srcINode.isDirectory()) {
    throw new IOException("Attempt to create an encryption zone for a file.");
  }
  if (hasCreatedEncryptionZone() && encryptionZones.get(srcINode.getId()) != null) {
    throw new IOException("Directory " + srcIIP.getPath() + " is already an encryption zone.");
  }
  final HdfsProtos.ZoneEncryptionInfoProto proto=PBHelperClient.convert(suite,version,keyName);
  final XAttr ezXAttr=XAttrHelper.buildXAttr(CRYPTO_XATTR_ENCRYPTION_ZONE,proto.toByteArray());
  final List<XAttr> xattrs=Lists.newArrayListWithCapacity(1);
  xattrs.add(ezXAttr);
  FSDirXAttrOp.unprotectedSetXAttrs(dir,srcIIP,xattrs,EnumSet.of(XAttrSetFlag.CREATE));
  return ezXAttr;
}
