@Override public void reinitialize(Configuration newConf,RMContext rmContext) throws IOException {
  try {
    writeLock.lock();
    Configuration configuration=new Configuration(newConf);
    CapacitySchedulerConfiguration oldConf=this.conf;
    this.conf=csConfProvider.loadConfiguration(configuration);
    validateConf(this.conf);
    try {
      LOG.info("Re-initializing queues...");
      refreshMaximumAllocation(this.conf.getMaximumAllocation());
      reinitializeQueues(this.conf);
    }
 catch (    Throwable t) {
      this.conf=oldConf;
      refreshMaximumAllocation(this.conf.getMaximumAllocation());
      throw new IOException("Failed to re-init queues : " + t.getMessage(),t);
    }
    this.isLazyPreemptionEnabled=this.conf.getLazyPreemptionEnabled();
    offswitchPerHeartbeatLimit=this.conf.getOffSwitchPerHeartbeatLimit();
  }
  finally {
    writeLock.unlock();
  }
}
