@Override public RefreshNodesResponse refreshNodes(RefreshNodesRequest request) throws YarnException, StandbyException {
  String argName="refreshNodes";
  final String msg="refresh nodes.";
  UserGroupInformation user=checkAcls("refreshNodes");
  checkRMStatus(user.getShortUserName(),argName,msg);
  try {
    Configuration conf=getConfiguration(new Configuration(false),YarnConfiguration.YARN_SITE_CONFIGURATION_FILE);
    rmContext.getNodesListManager().refreshNodes(conf);
    RMAuditLogger.logSuccess(user.getShortUserName(),argName,"AdminService");
    return recordFactory.newRecordInstance(RefreshNodesResponse.class);
  }
 catch (  IOException ioe) {
    throw logAndWrapException(ioe,user.getShortUserName(),argName,msg);
  }
}
