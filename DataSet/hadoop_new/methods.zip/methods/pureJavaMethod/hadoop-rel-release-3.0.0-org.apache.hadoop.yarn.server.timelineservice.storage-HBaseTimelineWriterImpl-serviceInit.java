/** 
 * initializes the hbase connection to write to the entity table.
 */
@Override protected void serviceInit(Configuration conf) throws Exception {
  super.serviceInit(conf);
  Configuration hbaseConf=HBaseTimelineStorageUtils.getTimelineServiceHBaseConf(conf);
  conn=ConnectionFactory.createConnection(hbaseConf);
  entityTable=new EntityTable().getTableMutator(hbaseConf,conn);
  appToFlowTable=new AppToFlowTable().getTableMutator(hbaseConf,conn);
  applicationTable=new ApplicationTable().getTableMutator(hbaseConf,conn);
  flowRunTable=new FlowRunTable().getTableMutator(hbaseConf,conn);
  flowActivityTable=new FlowActivityTable().getTableMutator(hbaseConf,conn);
  subApplicationTable=new SubApplicationTable().getTableMutator(hbaseConf,conn);
}
