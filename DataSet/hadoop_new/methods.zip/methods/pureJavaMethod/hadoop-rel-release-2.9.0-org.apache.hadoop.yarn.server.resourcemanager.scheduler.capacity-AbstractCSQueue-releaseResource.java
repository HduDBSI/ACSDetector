protected void releaseResource(Resource clusterResource,Resource resource,String nodePartition){
  try {
    writeLock.lock();
    queueUsage.decUsed(nodePartition,resource);
    CSQueueUtils.updateQueueStatistics(resourceCalculator,clusterResource,this,labelManager,nodePartition);
    --numContainers;
  }
  finally {
    writeLock.unlock();
  }
}
