/** 
 * For a given absolute path, create all ancestors as directories along the path. All ancestors inherit their parent's permission plus an implicit u+wx permission. This is used by create() and addSymlink() for implicitly creating all directories along the path. For example, path="/foo/bar/spam", "/foo" is an existing directory, "/foo/bar" is not existing yet, the function will create directory bar.
 * @return a INodesInPath with all the existing and newly createdancestor directories created. Or return null if there are errors.
 */
static INodesInPath createAncestorDirectories(FSDirectory fsd,INodesInPath iip,PermissionStatus permission) throws IOException {
  return createParentDirectories(fsd,iip,permission,true);
}
