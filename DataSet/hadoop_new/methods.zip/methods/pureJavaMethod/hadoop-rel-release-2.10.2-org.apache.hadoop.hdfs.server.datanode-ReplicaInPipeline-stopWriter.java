/** 
 * Interrupt the writing thread and wait until it dies
 * @throws IOException the waiting is interrupted
 */
public void stopWriter(long xceiverStopTimeout) throws IOException {
  while (true) {
    Thread thread=writer.get();
    if ((thread == null) || (thread == Thread.currentThread()) || (!thread.isAlive())) {
      if (writer.compareAndSet(thread,null) == true) {
        return;
      }
      continue;
    }
    thread.interrupt();
    try {
      thread.join(xceiverStopTimeout);
      if (thread.isAlive()) {
        final String msg="Join on writer thread " + thread + " timed out";
        DataNode.LOG.warn(msg + "\n" + StringUtils.getStackTrace(thread));
        throw new IOException(msg);
      }
    }
 catch (    InterruptedException e) {
      throw new IOException("Waiting for writer thread is interrupted.");
    }
  }
}
