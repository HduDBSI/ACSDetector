@Override public DatanodeStorageInfo chooseReplicaToDelete(Collection<DatanodeStorageInfo> moreThanOne,Collection<DatanodeStorageInfo> exactlyOne,List<StorageType> excessTypes,Map<String,List<DatanodeStorageInfo>> rackMap){
  Collection<DatanodeStorageInfo> chooseFrom=!moreThanOne.isEmpty() ? moreThanOne : exactlyOne;
  List<DatanodeStorageInfo> l=Lists.newArrayList(chooseFrom);
  return l.get(DFSUtil.getRandom().nextInt(l.size()));
}
