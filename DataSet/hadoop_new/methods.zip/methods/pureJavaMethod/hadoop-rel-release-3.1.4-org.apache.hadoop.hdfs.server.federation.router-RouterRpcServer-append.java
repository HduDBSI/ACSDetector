@Override public LastBlockWithStatus append(String src,final String clientName,final EnumSetWritable<CreateFlag> flag) throws IOException {
  return clientProto.append(src,clientName,flag);
}
