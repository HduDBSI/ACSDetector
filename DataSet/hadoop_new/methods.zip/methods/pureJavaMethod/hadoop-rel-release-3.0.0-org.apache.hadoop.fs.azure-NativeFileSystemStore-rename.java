void rename(String srcKey,String dstKey,boolean acquireLease,SelfRenewingLease existingLease) throws IOException ;
