/** 
 * @param file          File being scanned and validated.
 * @param maxTxIdToScan Maximum Tx ID to try to scan.The scan returns after reading this or a higher ID. The file portion beyond this ID is potentially being updated.
 * @return Result of the validation
 * @throws IOException
 */
static FSEditLogLoader.EditLogValidation scanEditLog(File file,long maxTxIdToScan,boolean verifyVersion) throws IOException {
  EditLogFileInputStream in;
  try {
    in=new EditLogFileInputStream(file);
    in.getVersion(verifyVersion);
  }
 catch (  LogHeaderCorruptException e) {
    LOG.warn("Log file " + file + " has no valid header",e);
    return new FSEditLogLoader.EditLogValidation(0,HdfsServerConstants.INVALID_TXID,true);
  }
  try {
    return FSEditLogLoader.scanEditLog(in,maxTxIdToScan);
  }
  finally {
    IOUtils.closeStream(in);
  }
}
