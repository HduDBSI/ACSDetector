@Test public void testDiffOption(){
  testSnapshotDiffOption(true);
}
