@Override public void transition(LocalizedResource rsrc,ResourceEvent event){
  ResourceLocalizedEvent locEvent=(ResourceLocalizedEvent)event;
  rsrc.localPath=Path.getPathWithoutSchemeAndAuthority(locEvent.getLocation());
  rsrc.size=locEvent.getSize();
  for (  ContainerId container : rsrc.ref) {
    rsrc.dispatcher.getEventHandler().handle(new ContainerResourceLocalizedEvent(container,rsrc.rsrc,rsrc.localPath));
  }
}
