public Resource getAllocatedResources(){
  return BuilderUtils.newResource(allocatedMB.value(),(int)allocatedVCores.value());
}
