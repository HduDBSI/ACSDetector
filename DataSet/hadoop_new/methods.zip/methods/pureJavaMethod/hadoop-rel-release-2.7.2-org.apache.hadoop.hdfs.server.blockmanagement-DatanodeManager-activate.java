void activate(final Configuration conf){
  decomManager.activate(conf);
  heartbeatManager.activate(conf);
}
