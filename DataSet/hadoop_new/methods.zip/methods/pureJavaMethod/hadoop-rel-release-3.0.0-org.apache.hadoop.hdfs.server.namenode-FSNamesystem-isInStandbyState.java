public boolean isInStandbyState(){
  if (haContext == null || haContext.getState() == null) {
    return haEnabled;
  }
  return HAServiceState.STANDBY == haContext.getState().getServiceState();
}
