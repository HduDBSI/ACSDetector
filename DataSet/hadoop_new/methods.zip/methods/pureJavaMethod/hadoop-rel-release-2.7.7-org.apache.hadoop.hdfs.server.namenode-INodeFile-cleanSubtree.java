@Override public QuotaCounts cleanSubtree(BlockStoragePolicySuite bsps,final int snapshot,int priorSnapshotId,final BlocksMapUpdateInfo collectedBlocks,final List<INode> removedINodes){
  FileWithSnapshotFeature sf=getFileWithSnapshotFeature();
  if (sf != null) {
    return sf.cleanFile(bsps,this,snapshot,priorSnapshotId,collectedBlocks,removedINodes);
  }
  QuotaCounts counts=new QuotaCounts.Builder().build();
  if (snapshot == CURRENT_STATE_ID) {
    if (priorSnapshotId == NO_SNAPSHOT_ID) {
      computeQuotaUsage(bsps,counts,false);
      destroyAndCollectBlocks(bsps,collectedBlocks,removedINodes);
    }
 else {
      FileUnderConstructionFeature uc=getFileUnderConstructionFeature();
      if (uc != null) {
        uc.cleanZeroSizeBlock(this,collectedBlocks);
      }
    }
  }
  return counts;
}
