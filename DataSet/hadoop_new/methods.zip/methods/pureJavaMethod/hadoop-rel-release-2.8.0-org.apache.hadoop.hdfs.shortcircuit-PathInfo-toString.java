@Override public String toString(){
  return "PathInfo{path=" + path + ", state="+ state+ "}";
}
