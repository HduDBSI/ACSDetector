@SuppressWarnings("unchecked") public void appAttemptFinished(RMAppAttempt appAttempt,RMAppAttemptState appAttemtpState,RMApp app,long finishedTime){
  if (publishSystemMetrics) {
    ContainerId container=(appAttempt.getMasterContainer() == null) ? null : appAttempt.getMasterContainer().getId();
    dispatcher.getEventHandler().handle(new AppAttemptFinishedEvent(appAttempt.getAppAttemptId(),appAttempt.getTrackingUrl(),appAttempt.getOriginalTrackingUrl(),appAttempt.getDiagnostics(),app.getFinalApplicationStatus(),RMServerUtils.createApplicationAttemptState(appAttemtpState),finishedTime,container));
  }
}
