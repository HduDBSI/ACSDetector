@SuppressWarnings("unchecked") public void appFinished(RMApp app,RMAppState state,long finishedTime){
  if (publishSystemMetrics) {
    dispatcher.getEventHandler().handle(new ApplicationFinishedEvent(app.getApplicationId(),app.getDiagnostics().toString(),app.getFinalApplicationStatus(),RMServerUtils.createApplicationState(state),app.getCurrentAppAttempt() == null ? null : app.getCurrentAppAttempt().getAppAttemptId(),finishedTime,app.getRMAppMetrics()));
  }
}
