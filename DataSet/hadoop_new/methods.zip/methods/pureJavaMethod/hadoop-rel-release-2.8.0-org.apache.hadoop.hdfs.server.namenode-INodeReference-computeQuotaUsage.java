@Override public final QuotaCounts computeQuotaUsage(BlockStoragePolicySuite bsps,byte blockStoragePolicyId,boolean useCache,int lastSnapshotId){
  Preconditions.checkState(lastSnapshotId == Snapshot.CURRENT_STATE_ID || this.lastSnapshotId >= lastSnapshotId);
  final INode referred=this.getReferredINode().asReference().getReferredINode();
  int id=lastSnapshotId != Snapshot.CURRENT_STATE_ID ? lastSnapshotId : this.lastSnapshotId;
  return referred.computeQuotaUsage(bsps,blockStoragePolicyId,false,id);
}
