/** 
 * Combine the posterior diff and collect blocks for deletion. 
 */
abstract QuotaCounts combinePosteriorAndCollectBlocks(final BlockStoragePolicySuite bsps,final N currentINode,final D posterior,final BlocksMapUpdateInfo collectedBlocks,final List<INode> removedINodes);
