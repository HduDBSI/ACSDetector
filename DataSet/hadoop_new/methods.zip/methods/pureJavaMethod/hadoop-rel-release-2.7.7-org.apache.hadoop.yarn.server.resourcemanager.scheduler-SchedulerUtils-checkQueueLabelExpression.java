/** 
 * Check queue label expression, check if node label in queue's node-label-expression existed in clusterNodeLabels if rmContext != null
 */
public static boolean checkQueueLabelExpression(Set<String> queueLabels,String labelExpression,RMContext rmContext){
  if (labelExpression == null) {
    return true;
  }
  for (  String str : labelExpression.split("&&")) {
    str=str.trim();
    if (!str.trim().isEmpty()) {
      if (queueLabels == null) {
        return false;
      }
 else {
        if (!queueLabels.contains(str) && !queueLabels.contains(RMNodeLabelsManager.ANY)) {
          return false;
        }
      }
      if (null != rmContext) {
        RMNodeLabelsManager nlm=rmContext.getNodeLabelManager();
        if (nlm != null && !nlm.containsNodeLabel(str)) {
          return false;
        }
      }
    }
  }
  return true;
}
