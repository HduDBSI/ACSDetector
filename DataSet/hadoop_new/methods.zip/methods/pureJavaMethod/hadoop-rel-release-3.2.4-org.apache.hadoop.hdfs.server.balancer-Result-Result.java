Result(ExitStatus exitStatus,long bytesLeftToMove,long bytesBeingMoved,long bytesAlreadyMoved,long blocksMoved){
  this.exitStatus=exitStatus;
  this.bytesLeftToMove=bytesLeftToMove;
  this.bytesBeingMoved=bytesBeingMoved;
  this.bytesAlreadyMoved=bytesAlreadyMoved;
  this.blocksMoved=blocksMoved;
}
