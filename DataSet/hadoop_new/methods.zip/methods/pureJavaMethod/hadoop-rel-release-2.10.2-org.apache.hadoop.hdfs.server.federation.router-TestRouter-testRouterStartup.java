private static void testRouterStartup(Configuration routerConfig) throws InterruptedException, IOException {
  Router router=new Router();
  assertEquals(STATE.NOTINITED,router.getServiceState());
  assertEquals(RouterServiceState.UNINITIALIZED,router.getRouterState());
  router.init(routerConfig);
  if (routerConfig.getBoolean(RBFConfigKeys.DFS_ROUTER_SAFEMODE_ENABLE,RBFConfigKeys.DFS_ROUTER_SAFEMODE_ENABLE_DEFAULT)) {
    assertEquals(RouterServiceState.SAFEMODE,router.getRouterState());
  }
 else {
    assertEquals(RouterServiceState.INITIALIZING,router.getRouterState());
  }
  assertEquals(STATE.INITED,router.getServiceState());
  router.start();
  if (routerConfig.getBoolean(RBFConfigKeys.DFS_ROUTER_SAFEMODE_ENABLE,RBFConfigKeys.DFS_ROUTER_SAFEMODE_ENABLE_DEFAULT)) {
    assertEquals(RouterServiceState.SAFEMODE,router.getRouterState());
  }
 else {
    assertEquals(RouterServiceState.RUNNING,router.getRouterState());
  }
  assertEquals(STATE.STARTED,router.getServiceState());
  router.stop();
  assertEquals(RouterServiceState.SHUTDOWN,router.getRouterState());
  assertEquals(STATE.STOPPED,router.getServiceState());
  router.close();
}
