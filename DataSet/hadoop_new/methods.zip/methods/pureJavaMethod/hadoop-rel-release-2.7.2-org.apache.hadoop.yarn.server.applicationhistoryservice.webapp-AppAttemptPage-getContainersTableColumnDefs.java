protected String getContainersTableColumnDefs(){
  StringBuilder sb=new StringBuilder();
  return sb.append("[\n").append("{'sType':'string', 'aTargets': [0]").append(", 'mRender': parseHadoopID }]").toString();
}
