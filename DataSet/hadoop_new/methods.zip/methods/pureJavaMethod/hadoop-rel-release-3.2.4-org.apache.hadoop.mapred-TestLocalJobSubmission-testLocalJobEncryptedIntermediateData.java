/** 
 * test the local job submission with intermediate data encryption enabled.
 * @throws IOException
 */
@Test public void testLocalJobEncryptedIntermediateData() throws IOException {
  config=MRJobConfUtil.initEncryptedIntermediateConfigsForTesting(config);
  final String[] args={"-m","1","-r","1","-mt","1","-rt","1"};
  int res=-1;
  try {
    SpillCallBackPathsFinder spillInjector=(SpillCallBackPathsFinder)IntermediateEncryptedStream.setSpillCBInjector(new SpillCallBackPathsFinder());
    res=ToolRunner.run(config,new SleepJob(),args);
    Assert.assertTrue("No spill occurred",spillInjector.getEncryptedSpilledFiles().size() > 0);
  }
 catch (  Exception e) {
    LOG.error("Job failed with {}",e.getLocalizedMessage(),e);
    fail("Job failed");
  }
  assertEquals("dist job res is not 0:",0,res);
}
