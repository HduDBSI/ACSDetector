@Override public QuotaCounts computeQuotaUsage(BlockStoragePolicySuite bsps,byte blockStoragePolicyId,QuotaCounts counts,boolean useCache,int lastSnapshotId){
  counts.addNameSpace(1);
  return counts;
}
