/** 
 * Computes a normalizedGuaranteed capacity based on active queues.
 * @param clusterResource the total amount of resources in the cluster
 * @param queues the list of queues to consider
 * @param ignoreGuar ignore guarantee.
 */
private void resetCapacity(Resource clusterResource,Collection<TempQueuePerPartition> queues,boolean ignoreGuar){
  Resource activeCap=Resource.newInstance(0,0);
  if (ignoreGuar) {
    for (    TempQueuePerPartition q : queues) {
      q.normalizedGuarantee=1.0f / queues.size();
    }
  }
 else {
    for (    TempQueuePerPartition q : queues) {
      Resources.addTo(activeCap,q.getGuaranteed());
    }
    for (    TempQueuePerPartition q : queues) {
      q.normalizedGuarantee=Resources.divide(rc,clusterResource,q.getGuaranteed(),activeCap);
    }
  }
}
