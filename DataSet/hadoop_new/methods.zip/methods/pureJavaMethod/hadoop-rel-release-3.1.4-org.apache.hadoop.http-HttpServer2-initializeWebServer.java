private void initializeWebServer(String name,String hostName,Configuration conf,String[] pathSpecs) throws IOException {
  Preconditions.checkNotNull(webAppContext);
  int maxThreads=conf.getInt(HTTP_MAX_THREADS_KEY,-1);
  QueuedThreadPool threadPool=(QueuedThreadPool)webServer.getThreadPool();
  threadPool.setDaemon(true);
  if (maxThreads != -1) {
    threadPool.setMaxThreads(maxThreads);
  }
  SessionHandler handler=webAppContext.getSessionHandler();
  handler.setHttpOnly(true);
  handler.getSessionCookieConfig().setSecure(true);
  ContextHandlerCollection contexts=new ContextHandlerCollection();
  RequestLog requestLog=HttpRequestLog.getRequestLog(name);
  handlers.addHandler(contexts);
  if (requestLog != null) {
    RequestLogHandler requestLogHandler=new RequestLogHandler();
    requestLogHandler.setRequestLog(requestLog);
    handlers.addHandler(requestLogHandler);
  }
  handlers.addHandler(webAppContext);
  final String appDir=getWebAppsPath(name);
  addDefaultApps(contexts,appDir,conf);
  webServer.setHandler(handlers);
  Map<String,String> xFrameParams=new HashMap<>();
  xFrameParams.put(X_FRAME_ENABLED,String.valueOf(this.xFrameOptionIsEnabled));
  xFrameParams.put(X_FRAME_VALUE,this.xFrameOption.toString());
  addGlobalFilter("safety",QuotingInputFilter.class.getName(),xFrameParams);
  final FilterInitializer[] initializers=getFilterInitializers(conf);
  if (initializers != null) {
    conf=new Configuration(conf);
    conf.set(BIND_ADDRESS,hostName);
    for (    FilterInitializer c : initializers) {
      c.initFilter(this,conf);
    }
  }
  addDefaultServlets();
  if (pathSpecs != null) {
    for (    String path : pathSpecs) {
      LOG.info("adding path spec: " + path);
      addFilterPathMapping(path,webAppContext);
    }
  }
}
