@Override public Set<NodeLabel> getNodeLabelsForHeartbeat(){
  return getValueForHeartbeat();
}
