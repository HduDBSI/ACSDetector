private LocalResourceTrackerState loadTrackerState(TrackerState ts){
  LocalResourceTrackerState result=new LocalResourceTrackerState();
  result.localizedResources.addAll(ts.localizedResources.values());
  for (  Map.Entry<Path,LocalResourceProto> entry : ts.inProgressMap.entrySet()) {
    result.inProgressResources.put(entry.getValue(),entry.getKey());
  }
  return result;
}
