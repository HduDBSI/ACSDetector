List<XAttr> getXAttrs(final String src,List<XAttr> xAttrs) throws IOException {
  final String operationName="getXAttrs";
  checkOperation(OperationCategory.READ);
  readLock();
  try {
    checkOperation(OperationCategory.READ);
    return FSDirXAttrOp.getXAttrs(dir,src,xAttrs);
  }
 catch (  AccessControlException e) {
    logAuditEvent(false,operationName,src);
    throw e;
  }
 finally {
    readUnlock(operationName);
  }
}
