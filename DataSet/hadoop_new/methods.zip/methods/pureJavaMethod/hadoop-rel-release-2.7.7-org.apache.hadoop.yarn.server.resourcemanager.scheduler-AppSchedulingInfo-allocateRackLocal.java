/** 
 * The  {@link ResourceScheduler} is allocating data-local resources to theapplication.
 * @param allocatedContainers resources allocated to the application
 */
synchronized private void allocateRackLocal(SchedulerNode node,Priority priority,ResourceRequest rackLocalRequest,Container container,List<ResourceRequest> resourceRequests){
  decResourceRequest(node.getRackName(),priority,rackLocalRequest);
  ResourceRequest offRackRequest=requests.get(priority).get(ResourceRequest.ANY);
  decrementOutstanding(offRackRequest);
  resourceRequests.add(cloneResourceRequest(rackLocalRequest));
  resourceRequests.add(cloneResourceRequest(offRackRequest));
}
