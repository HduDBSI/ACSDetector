/** 
 * Create the AWS credentials from the providers and the URI.
 * @param binding Binding URI, may contain user:pass login details
 * @param conf filesystem configuration
 * @return a credentials provider list
 * @throws IOException Problems loading the providers (including readingsecrets from credential files).
 */
public static AWSCredentialProviderList createAWSCredentialProviderSet(URI binding,Configuration conf) throws IOException {
  AWSCredentialProviderList credentials=new AWSCredentialProviderList();
  Class<?>[] awsClasses;
  try {
    awsClasses=conf.getClasses(AWS_CREDENTIALS_PROVIDER);
  }
 catch (  RuntimeException e) {
    Throwable c=e.getCause() != null ? e.getCause() : e;
    throw new IOException("From option " + AWS_CREDENTIALS_PROVIDER + ' '+ c,c);
  }
  if (awsClasses.length == 0) {
    S3xLoginHelper.Login creds=getAWSAccessKeys(binding,conf);
    credentials.add(new BasicAWSCredentialsProvider(creds.getUser(),creds.getPassword()));
    credentials.add(new EnvironmentVariableCredentialsProvider());
    credentials.add(InstanceProfileCredentialsProvider.getInstance());
  }
 else {
    for (    Class<?> aClass : awsClasses) {
      credentials.add(createAWSCredentialProvider(conf,aClass));
    }
  }
  LOG.debug("For URI {}, using credentials {}",S3xLoginHelper.toString(binding),credentials);
  return credentials;
}
