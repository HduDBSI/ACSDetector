@Override public synchronized RecoveredDeletionServiceState loadDeletionServiceState() throws IOException {
  RecoveredDeletionServiceState result=new RecoveredDeletionServiceState();
  result.tasks=new ArrayList<DeletionServiceDeleteTaskProto>(deleteTasks.values());
  return result;
}
