@Test(expected=IOException.class) public void testTruncatedFSImage() throws IOException {
  File truncatedFile=folder.newFile();
  PrintStream output=new PrintStream(NullOutputStream.NULL_OUTPUT_STREAM);
  copyPartOfFile(originalFsimage,truncatedFile);
  new FileDistributionCalculator(new Configuration(),0,0,output).visit(new RandomAccessFile(truncatedFile,"r"));
}
