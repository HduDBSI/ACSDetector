@Override public void recover() throws YarnException, IOException {
  super.recoverFromStore();
}
