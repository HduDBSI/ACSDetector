/** 
 * Stop the root queue if there are running child queues.
 */
@Test public void testValidateCSConfigStopANonLeafQueueInvalid(){
  Configuration oldConfig=CapacitySchedulerConfigGeneratorForTest.createBasicCSConfiguration();
  Configuration newConfig=new Configuration(oldConfig);
  newConfig.set("yarn.scheduler.capacity.root.state","STOPPED");
  RMContext rmContext=prepareRMContext();
  try {
    CapacitySchedulerConfigValidator.validateCSConfiguration(oldConfig,newConfig,rmContext);
    fail("There are child queues in running state");
  }
 catch (  IOException e) {
    Assert.assertTrue(e.getCause().getMessage().contains("The parent queue:root cannot be STOPPED"));
  }
}
