/** 
 * Check whether the in-memory block record matches the block on the disk, and, in case that they are not matched, update the record or mark it as corrupted.
 */
void checkAndUpdate(String bpid,long blockId,File diskFile,File diskMetaFile,FsVolumeSpi vol) throws IOException ;
