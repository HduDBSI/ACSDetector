/** 
 * Pull properties and values from filename.
 * @param filename XML filename
 * @return HashMap containing <Property,Value> entries from XML file
 */
private HashMap<String,String> extractPropertiesFromXml(String filename){
  if (filename == null) {
    return null;
  }
  Configuration conf=new Configuration(false);
  conf.setAllowNullValueProperties(true);
  conf.addResource(filename);
  HashMap<String,String> retVal=new HashMap<String,String>();
  Iterator<Map.Entry<String,String>> kvItr=conf.iterator();
  while (kvItr.hasNext()) {
    Map.Entry<String,String> entry=kvItr.next();
    String key=entry.getKey();
    if (xmlPropsToSkipCompare != null) {
      if (xmlPropsToSkipCompare.contains(key)) {
        if (xmlDebug) {
          System.out.println("  Skipping Full Key: " + key);
        }
        continue;
      }
    }
    boolean skipPrefix=false;
    if (xmlPrefixToSkipCompare != null) {
      for (      String xmlPrefix : xmlPrefixToSkipCompare) {
        if (key.startsWith(xmlPrefix)) {
          skipPrefix=true;
          break;
        }
      }
    }
    if (skipPrefix) {
      if (xmlDebug) {
        System.out.println("  Skipping Prefix Key: " + key);
      }
      continue;
    }
    if (conf.onlyKeyExists(key)) {
      retVal.put(key,null);
      if (xmlDebug) {
        System.out.println("  XML Key,Null Value: " + key);
      }
    }
 else {
      String value=conf.get(key);
      if (value != null) {
        retVal.put(key,entry.getValue());
        if (xmlDebug) {
          System.out.println("  XML Key,Valid Value: " + key);
        }
      }
    }
    kvItr.remove();
  }
  return retVal;
}
