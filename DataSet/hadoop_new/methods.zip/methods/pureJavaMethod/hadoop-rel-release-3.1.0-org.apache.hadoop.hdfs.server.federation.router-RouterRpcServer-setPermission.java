@Override public void setPermission(String src,FsPermission permissions) throws IOException {
  checkOperation(OperationCategory.WRITE);
  final List<RemoteLocation> locations=getLocationsForPath(src,true);
  RemoteMethod method=new RemoteMethod("setPermission",new Class<?>[]{String.class,FsPermission.class},new RemoteParam(),permissions);
  if (isPathAll(src)) {
    rpcClient.invokeConcurrent(locations,method);
  }
 else {
    rpcClient.invokeSequential(locations,method);
  }
}
