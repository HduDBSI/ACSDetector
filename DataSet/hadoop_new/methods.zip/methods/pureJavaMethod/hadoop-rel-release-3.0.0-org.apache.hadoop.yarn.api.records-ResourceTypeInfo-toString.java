@Override public String toString(){
  StringBuilder sb=new StringBuilder();
  sb.append(this.getName());
  if (!this.getDefaultUnit().isEmpty()) {
    sb.append(" (unit=").append(this.getDefaultUnit()).append(")");
  }
  return sb.toString();
}
