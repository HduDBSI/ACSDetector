@Test public void testLongLivedReadClientAfterRestart() throws IOException {
  FileChecksum checksum=writeUnencryptedAndThenRestartEncryptedCluster();
  assertEquals(PLAIN_TEXT,DFSTestUtil.readFile(fs,TEST_PATH));
  assertEquals(checksum,fs.getFileChecksum(TEST_PATH));
  cluster.restartNameNode();
  assertTrue(cluster.restartDataNode(0));
  assertEquals(PLAIN_TEXT,DFSTestUtil.readFile(fs,TEST_PATH));
  assertEquals(checksum,fs.getFileChecksum(TEST_PATH));
}
