@Override public Token<?>[] addDelegationTokens(final String renewer,Credentials credentials) throws IOException {
  Token<?>[] tokens=super.addDelegationTokens(renewer,credentials);
  return HdfsKMSUtil.addDelegationTokensForKeyProvider(this,renewer,credentials,uri,tokens);
}
