@Override public boolean setReplication(String src,short replication) throws IOException {
  return clientProto.setReplication(src,replication);
}
