@Override public void setUp() throws IOException {
  super.setUp();
  interceptor=new TestableFederationInterceptor();
  stateStore=new MemoryFederationStateStore();
  stateStore.init(getConf());
  FederationStateStoreFacade.getInstance().reinitialize(stateStore,getConf());
  testAppId=1;
  attemptId=getApplicationAttemptId(testAppId);
  interceptor.init(new AMRMProxyApplicationContextImpl(null,getConf(),attemptId,"test-user",null,null));
}
