@Override public Object run() throws IOException, URISyntaxException {
  UserGroupInformation ugi=UserGroupInformation.getCurrentUser();
  String doAsUserName=ugi.getUserName();
  assertEquals(doAsUserName,"user@HADOOP.COM");
  FileContext viewFS=FileContext.getFileContext(FsConstants.VIEWFS_URI,conf);
  FileStatus stat=viewFS.getFileStatus(new Path("/internalDir"));
  assertEquals(userUgi.getShortUserName(),stat.getOwner());
  return null;
}
