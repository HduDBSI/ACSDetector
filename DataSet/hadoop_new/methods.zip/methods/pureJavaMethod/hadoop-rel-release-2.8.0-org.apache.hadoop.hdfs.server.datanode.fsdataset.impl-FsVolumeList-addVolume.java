/** 
 * Dynamically add new volumes to the existing volumes that this DN manages.
 * @param ref       a reference to the new FsVolumeImpl instance.
 */
void addVolume(FsVolumeReference ref){
  FsVolumeImpl volume=(FsVolumeImpl)ref.getVolume();
  volumes.add(volume);
  if (blockScanner != null) {
    blockScanner.addVolumeScanner(ref);
  }
 else {
    IOUtils.cleanup(FsDatasetImpl.LOG,ref);
  }
  removeVolumeFailureInfo(new File(volume.getBasePath()));
  FsDatasetImpl.LOG.info("Added new volume: " + volume.getStorageID());
}
