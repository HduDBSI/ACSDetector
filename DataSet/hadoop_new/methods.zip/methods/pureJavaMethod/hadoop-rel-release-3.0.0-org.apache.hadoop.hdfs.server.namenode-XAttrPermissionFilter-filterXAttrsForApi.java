static List<XAttr> filterXAttrsForApi(FSPermissionChecker pc,List<XAttr> xAttrs,boolean isRawPath){
  assert xAttrs != null : "xAttrs can not be null";
  if (xAttrs.isEmpty()) {
    return xAttrs;
  }
  List<XAttr> filteredXAttrs=Lists.newArrayListWithCapacity(xAttrs.size());
  final boolean isSuperUser=pc.isSuperUser();
  for (  XAttr xAttr : xAttrs) {
    if (xAttr.getNameSpace() == XAttr.NameSpace.USER) {
      filteredXAttrs.add(xAttr);
    }
 else     if (xAttr.getNameSpace() == XAttr.NameSpace.TRUSTED && isSuperUser) {
      filteredXAttrs.add(xAttr);
    }
 else     if (xAttr.getNameSpace() == XAttr.NameSpace.RAW && isSuperUser && isRawPath) {
      filteredXAttrs.add(xAttr);
    }
 else     if (XAttrHelper.getPrefixedName(xAttr).equals(SECURITY_XATTR_UNREADABLE_BY_SUPERUSER)) {
      filteredXAttrs.add(xAttr);
    }
  }
  return filteredXAttrs;
}
