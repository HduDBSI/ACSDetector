JournalMetrics(Journal journal){
  this.journal=journal;
  syncsQuantiles=new MutableQuantiles[QUANTILE_INTERVALS.length];
  for (int i=0; i < syncsQuantiles.length; i++) {
    int interval=QUANTILE_INTERVALS[i];
    syncsQuantiles[i]=registry.newQuantiles("syncs" + interval + "s","Journal sync time","ops","latencyMicros",interval);
  }
}
