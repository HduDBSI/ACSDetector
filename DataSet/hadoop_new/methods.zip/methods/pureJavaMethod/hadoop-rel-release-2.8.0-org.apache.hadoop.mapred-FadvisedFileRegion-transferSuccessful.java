/** 
 * Call when the transfer completes successfully so we can advise the OS that we don't need the region to be cached anymore.
 */
public void transferSuccessful(){
  if (manageOsCache && getCount() > 0) {
    try {
      NativeIO.POSIX.getCacheManipulator().posixFadviseIfPossible(identifier,fd,getPosition(),getCount(),POSIX_FADV_DONTNEED);
    }
 catch (    Throwable t) {
      LOG.warn("Failed to manage OS cache for " + identifier,t);
    }
  }
}
