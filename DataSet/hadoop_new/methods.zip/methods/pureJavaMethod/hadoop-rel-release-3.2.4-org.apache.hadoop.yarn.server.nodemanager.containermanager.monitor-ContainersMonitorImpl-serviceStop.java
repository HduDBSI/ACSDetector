@Override protected void serviceStop() throws Exception {
  stopped=true;
  if (containersMonitorEnabled) {
    this.monitoringThread.interrupt();
    try {
      this.monitoringThread.join();
    }
 catch (    InterruptedException e) {
      LOG.info("ContainersMonitorImpl monitoring thread interrupted");
    }
    if (this.oomListenerThread != null) {
      this.oomListenerThread.stopListening();
      try {
        this.oomListenerThread.join();
      }
  finally {
        this.oomListenerThread=null;
      }
    }
  }
  if (logMonitorEnabled) {
    this.logMonitorThread.interrupt();
    try {
      this.logMonitorThread.join();
    }
 catch (    InterruptedException e) {
    }
  }
  super.serviceStop();
}
