/** 
 * Write out the wrapper script for the container launch script.
 * @param launchDst the script to launch
 * @param pidFile the file that will hold the PID
 * @param pout the stream to use to write out the wrapper script
 */
protected abstract void writeLocalWrapperScript(Path launchDst,Path pidFile,PrintStream pout);
