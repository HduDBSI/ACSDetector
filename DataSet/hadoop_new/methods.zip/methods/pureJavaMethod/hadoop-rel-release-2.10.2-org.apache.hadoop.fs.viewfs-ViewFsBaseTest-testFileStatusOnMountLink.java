@Test(expected=FileNotFoundException.class) public void testFileStatusOnMountLink() throws IOException {
  Assert.assertTrue("Slash should appear as dir",fcView.getFileStatus(new Path("/")).isDirectory());
  checkFileStatus(fcView,"/",fileType.isDir);
  checkFileStatus(fcView,"/user",fileType.isDir);
  checkFileStatus(fcView,"/data",fileType.isDir);
  checkFileStatus(fcView,"/internalDir",fileType.isDir);
  checkFileStatus(fcView,"/internalDir/linkToDir2",fileType.isDir);
  checkFileStatus(fcView,"/internalDir/internalDir2/linkToDir3",fileType.isDir);
  checkFileStatus(fcView,"/linkToAFile",fileType.isFile);
  fcView.getFileStatus(new Path("/danglingLink"));
}
