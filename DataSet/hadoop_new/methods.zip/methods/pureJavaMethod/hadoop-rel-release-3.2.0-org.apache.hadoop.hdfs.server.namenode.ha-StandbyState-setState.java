@Override public void setState(HAContext context,HAState s) throws ServiceFailedException {
  if (s == NameNode.ACTIVE_STATE) {
    setStateInternal(context,s);
    return;
  }
  super.setState(context,s);
}
