private static SortedSet<String> parseProtectedDirectories(final Collection<String> protectedDirs){
  return new TreeSet<>(normalizePaths(protectedDirs,FS_PROTECTED_DIRECTORIES));
}
