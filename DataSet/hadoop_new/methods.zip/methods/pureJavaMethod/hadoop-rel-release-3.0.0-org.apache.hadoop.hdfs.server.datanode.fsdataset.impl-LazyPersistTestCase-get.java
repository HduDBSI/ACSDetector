@Override public Boolean get(){
  try {
    LocatedBlocks locatedBlocks=client.getLocatedBlocks(path.toString(),0,fileLength);
    for (    LocatedBlock locatedBlock : locatedBlocks.getLocatedBlocks()) {
      if (locatedBlock.getStorageTypes()[0] != storageType) {
        return false;
      }
    }
    return true;
  }
 catch (  IOException ioe) {
    LOG.warn("Exception got in ensureFileReplicasOnStorageType()",ioe);
    return false;
  }
}
