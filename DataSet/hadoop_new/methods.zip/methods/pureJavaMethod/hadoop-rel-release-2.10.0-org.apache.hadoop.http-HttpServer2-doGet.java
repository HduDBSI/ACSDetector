@Override public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
  if (!HttpServer2.isInstrumentationAccessAllowed(getServletContext(),request,response)) {
    return;
  }
  response.setContentType("text/plain; charset=UTF-8");
  try (PrintStream out=new PrintStream(response.getOutputStream(),false,"UTF-8")){
    ReflectionUtils.printThreadInfo(out,"");
  }
   ReflectionUtils.logThreadInfo(LOG,"jsp requested",1);
}
