Root(INodeDirectory other){
  super(other,false,Lists.newArrayList(Iterables.filter(Arrays.asList(other.getFeatures()),new Predicate<Feature>(){
    @Override public boolean apply(    Feature input){
      if (AclFeature.class.isInstance(input) || XAttrFeature.class.isInstance(input)) {
        return true;
      }
      return false;
    }
  }
)).toArray(new Feature[0]));
}
