/** 
 * Subtract Container's resources to the accumulated Utilization.
 * @param container Container.
 */
@Override public void subtractContainerResource(Container container){
  ContainersMonitor.ContainerManagerUtils.decreaseResourceUtilization(getContainersMonitor(),this.containersAllocation,container.getResource());
}
