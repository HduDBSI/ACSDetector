@Private public HostsFileReader(String includesFile,InputStream inFileInputStream,String excludesFile,InputStream exFileInputStream) throws IOException {
  HostDetails hostDetails=new HostDetails(includesFile,Collections.<String>emptySet(),excludesFile,Collections.<String>emptySet());
  current=new AtomicReference<>(hostDetails);
  refresh(inFileInputStream,exFileInputStream);
}
