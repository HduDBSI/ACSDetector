private void deleteUnnecessaryFakeDirectories(Path f) throws IOException {
  while (true) {
    try {
      String key=pathToKey(f);
      if (key.isEmpty()) {
        break;
      }
      S3AFileStatus status=getFileStatus(f);
      if (status.isDirectory() && status.isEmptyDirectory()) {
        if (LOG.isDebugEnabled()) {
          LOG.debug("Deleting fake directory " + key + "/");
        }
        s3.deleteObject(bucket,key + "/");
        statistics.incrementWriteOps(1);
      }
    }
 catch (    FileNotFoundException|AmazonServiceException e) {
    }
    if (f.isRoot()) {
      break;
    }
    f=f.getParent();
  }
}
