/** 
 * Handle an IOE on a read by attempting to re-open the stream. The filesystem's readException count will be incremented.
 * @param ioe exception caught.
 * @param length length of data being attempted to read
 * @throws IOException any exception thrown on the re-open attempt.
 */
private void onReadFailure(IOException ioe,int length) throws IOException {
  LOG.info("Got exception while trying to read from stream {}" + " trying to recover: " + ioe,uri);
  LOG.debug("While trying to read from stream {}",uri,ioe);
  streamStatistics.readException();
  reopen("failure recovery",pos,length);
}
