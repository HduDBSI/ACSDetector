/** 
 * Recompute the internal variables used by the scheduler - per-job weights, fair shares, deficits, minimum slot allocations, and amount of used and required resources per job.
 */
@VisibleForTesting @Override public void update(){
  long start=getClock().getTime();
  FSQueue rootQueue=queueMgr.getRootQueue();
  writeLock.lock();
  try {
    rootQueue.updateDemand();
    rootQueue.update(getClusterResource());
    updateRootQueueMetrics();
  }
  finally {
    writeLock.unlock();
  }
  readLock.lock();
  try {
    if (shouldAttemptPreemption()) {
      for (      FSLeafQueue queue : queueMgr.getLeafQueues()) {
        queue.updateStarvedApps();
      }
    }
    if (LOG.isDebugEnabled()) {
      if (--updatesToSkipForDebug < 0) {
        updatesToSkipForDebug=UPDATE_DEBUG_FREQUENCY;
        dumpSchedulerState();
      }
    }
  }
  finally {
    readLock.unlock();
  }
  long duration=getClock().getTime() - start;
  fsOpDurations.addUpdateCallDuration(duration);
  fsOpDurations.addUpdateThreadRunDuration(duration);
}
