/** 
 * Remove a node Update node counter and rack counter if necessary
 * @param node node to be removed; can be null
 */
public void remove(Node node){
  if (node == null)   return;
  if (node instanceof InnerNode) {
    throw new IllegalArgumentException("Not allow to remove an inner node: " + NodeBase.getPath(node));
  }
  LOG.info("Removing a node: " + NodeBase.getPath(node));
  netlock.writeLock().lock();
  try {
    if (clusterMap.remove(node)) {
      InnerNode rack=(InnerNode)getNode(node.getNetworkLocation());
      if (rack == null) {
        numOfRacks--;
      }
    }
    LOG.debug("NetworkTopology became:\n{}",this);
  }
  finally {
    netlock.writeLock().unlock();
  }
}
