/** 
 * Closes this output stream and releases any system  resources associated with this stream.
 */
@Override public void close() throws IOException {
synchronized (this) {
    if (closed) {
      IOException e=lastException.getAndSet(null);
      if (e == null)       return;
 else       throw e;
    }
    try {
      flushBuffer();
      if (currentPacket != null) {
        waitAndQueueCurrentPacket();
      }
      if (bytesCurBlock != 0) {
        currentPacket=createPacket(0,0,bytesCurBlock,currentSeqno++);
        currentPacket.lastPacketInBlock=true;
        currentPacket.syncBlock=shouldSyncBlock;
      }
      flushInternal();
      ExtendedBlock lastBlock=streamer.getBlock();
      closeThreads(false);
      completeFile(lastBlock);
    }
 catch (    ClosedChannelException e) {
    }
 finally {
      closed=true;
    }
  }
  dfsClient.endFileLease(fileId);
}
