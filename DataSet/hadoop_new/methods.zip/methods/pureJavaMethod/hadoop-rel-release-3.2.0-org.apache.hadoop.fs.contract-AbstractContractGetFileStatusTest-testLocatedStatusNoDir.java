@Test public void testLocatedStatusNoDir() throws Throwable {
  describe("test the LocatedStatus call on a path which is not present");
  intercept(FileNotFoundException.class,() -> getFileSystem().listLocatedStatus(path("missing")));
}
