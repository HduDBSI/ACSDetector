/** 
 * Get the possible locations of a path in the federated cluster.
 * @param path Path to check.
 * @param failIfLocked Fail the request if locked (top mount point).
 * @param needQuotaVerify If need to do the quota verification.
 * @return Prioritized list of locations in the federated cluster.
 * @throws IOException If the location for this path cannot be determined.
 */
protected List<RemoteLocation> getLocationsForPath(String path,boolean failIfLocked,boolean needQuotaVerify) throws IOException {
  try {
    final PathLocation location=this.subclusterResolver.getDestinationForPath(path);
    if (location == null) {
      throw new IOException("Cannot find locations for " + path + " in "+ this.subclusterResolver.getClass().getSimpleName());
    }
    if (opCategory.get() == OperationCategory.WRITE) {
      if (isPathReadOnly(path)) {
        if (this.rpcMonitor != null) {
          this.rpcMonitor.routerFailureReadOnly();
        }
        throw new IOException(path + " is in a read only mount point");
      }
      if (this.router.isQuotaEnabled() && needQuotaVerify) {
        RouterQuotaUsage quotaUsage=this.router.getQuotaManager().getQuotaUsage(path);
        if (quotaUsage != null) {
          quotaUsage.verifyNamespaceQuota();
          quotaUsage.verifyStoragespaceQuota();
        }
      }
    }
    Set<String> disabled=namenodeResolver.getDisabledNamespaces();
    List<RemoteLocation> locs=new ArrayList<>();
    for (    RemoteLocation loc : location.getDestinations()) {
      if (!disabled.contains(loc.getNameserviceId())) {
        locs.add(loc);
      }
    }
    return locs;
  }
 catch (  IOException ioe) {
    if (this.rpcMonitor != null) {
      this.rpcMonitor.routerFailureStateStore();
    }
    throw ioe;
  }
}
