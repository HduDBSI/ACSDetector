/** 
 * readFields peeks at the first byte of the DataInput and determines if it was written using WritableUtils ("Legacy") or Protobuf. We can do this because we know the first field is the Expiry date. In the case of the legacy buffer, the expiry date is a VInt, so the size (which should always be >1) is encoded in the first byte - which is always negative due to this encoding. However, there are sometimes null BlockTokenIdentifier written so we also need to handle the case there the first byte is also 0. In the case of protobuf, the first byte is a type tag for the expiry date which is written as <code>(field_number << 3 |  wire_type</code>. So as long as the field_number  is less than 16, but also positive, then we know we have a Protobuf.
 * @param in <code>DataInput</code> to deserialize this object from.
 * @throws IOException
 */
@Override public void readFields(DataInput in) throws IOException {
  this.cache=null;
  final DataInputStream dis=(DataInputStream)in;
  if (!dis.markSupported()) {
    throw new IOException("Could not peek first byte.");
  }
  dis.mark(1);
  final byte firstByte=dis.readByte();
  dis.reset();
  if (firstByte <= 0) {
    readFieldsLegacy(dis);
  }
 else {
    readFieldsProtobuf(dis);
  }
}
