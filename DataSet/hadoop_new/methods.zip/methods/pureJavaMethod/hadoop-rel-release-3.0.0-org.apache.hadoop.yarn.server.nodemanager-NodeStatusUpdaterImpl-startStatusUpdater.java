protected void startStatusUpdater(){
  statusUpdaterRunnable=new StatusUpdaterRunnable();
  statusUpdater=new Thread(statusUpdaterRunnable,"Node Status Updater");
  statusUpdater.start();
}
