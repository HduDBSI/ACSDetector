/** 
 * Add, put, and offer follow the same pattern: 1. Get the assigned priorityLevel from the call by scheduler 2. Get the nth sub-queue matching this priorityLevel 3. delegate the call to this sub-queue. But differ in how they handle overflow: - Add will move on to the next queue, throw on last queue overflow - Put will move on to the next queue, block on last queue overflow - Offer does not attempt other queues on overflow
 */
@Override public boolean add(E e){
  final int priorityLevel=e.getPriorityLevel();
  if (!offerQueues(priorityLevel,e,true)) {
    CallQueueOverflowException ex;
    if (serverFailOverEnabled) {
      ex=CallQueueOverflowException.FAILOVER;
    }
 else     if (priorityLevel == queues.size() - 1) {
      ex=CallQueueOverflowException.DISCONNECT;
    }
 else {
      ex=CallQueueOverflowException.KEEPALIVE;
    }
    throw ex;
  }
  return true;
}
