@Override public void checkAndUpdate(String bpid,long blockId,File diskFile,File diskMetaFile,FsVolumeSpi vol){
}
