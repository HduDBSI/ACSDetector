/** 
 * Get the status of the docker container. This runs a docker inspect to get the status. If the container no longer exists, docker inspect throws an exception and the nonexistent status is returned.
 * @param containerId                 the id of the container.
 * @param privilegedOperationExecutor the privileged operations executor.
 * @return a {@link DockerContainerStatus} representing the current status.
 */
public static DockerContainerStatus getContainerStatus(String containerId,PrivilegedOperationExecutor privilegedOperationExecutor,Context nmContext){
  try {
    DockerContainerStatus dockerContainerStatus;
    String currentContainerStatus=executeStatusCommand(containerId,privilegedOperationExecutor,nmContext);
    if (currentContainerStatus == null) {
      dockerContainerStatus=DockerContainerStatus.UNKNOWN;
    }
 else     if (currentContainerStatus.equals(DockerContainerStatus.CREATED.getName())) {
      dockerContainerStatus=DockerContainerStatus.CREATED;
    }
 else     if (currentContainerStatus.equals(DockerContainerStatus.RUNNING.getName())) {
      dockerContainerStatus=DockerContainerStatus.RUNNING;
    }
 else     if (currentContainerStatus.equals(DockerContainerStatus.STOPPED.getName())) {
      dockerContainerStatus=DockerContainerStatus.STOPPED;
    }
 else     if (currentContainerStatus.equals(DockerContainerStatus.RESTARTING.getName())) {
      dockerContainerStatus=DockerContainerStatus.RESTARTING;
    }
 else     if (currentContainerStatus.equals(DockerContainerStatus.REMOVING.getName())) {
      dockerContainerStatus=DockerContainerStatus.REMOVING;
    }
 else     if (currentContainerStatus.equals(DockerContainerStatus.DEAD.getName())) {
      dockerContainerStatus=DockerContainerStatus.DEAD;
    }
 else     if (currentContainerStatus.equals(DockerContainerStatus.EXITED.getName())) {
      dockerContainerStatus=DockerContainerStatus.EXITED;
    }
 else     if (currentContainerStatus.equals(DockerContainerStatus.NONEXISTENT.getName())) {
      dockerContainerStatus=DockerContainerStatus.NONEXISTENT;
    }
 else {
      dockerContainerStatus=DockerContainerStatus.UNKNOWN;
    }
    if (LOG.isDebugEnabled()) {
      LOG.debug("Container Status: " + dockerContainerStatus.getName() + " ContainerId: "+ containerId);
    }
    return dockerContainerStatus;
  }
 catch (  ContainerExecutionException e) {
    if (LOG.isDebugEnabled()) {
      LOG.debug("Container Status: " + DockerContainerStatus.NONEXISTENT.getName() + " ContainerId: "+ containerId);
    }
    return DockerContainerStatus.NONEXISTENT;
  }
}
