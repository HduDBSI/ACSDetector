@VisibleForTesting long evictOldStartTimes(long minStartTime) throws IOException {
  LOG.info("Searching for start times to evict earlier than " + minStartTime);
  long batchSize=0;
  long totalCount=0;
  long startTimesCount=0;
  WriteBatch writeBatch=null;
  ReadOptions readOptions=new ReadOptions();
  readOptions.fillCache(false);
  try (DBIterator iterator=starttimedb.iterator(readOptions)){
    iterator.seekToFirst();
    writeBatch=starttimedb.createWriteBatch();
    while (iterator.hasNext()) {
      Map.Entry<byte[],byte[]> current=iterator.next();
      byte[] entityKey=current.getKey();
      byte[] entityValue=current.getValue();
      long startTime=readReverseOrderedLong(entityValue,0);
      if (startTime < minStartTime) {
        ++batchSize;
        ++startTimesCount;
        writeBatch.delete(entityKey);
        if (batchSize >= writeBatchSize) {
          LOG.debug("Preparing to delete a batch of {} old start times",batchSize);
          starttimedb.write(writeBatch);
          LOG.debug("Deleted batch of {}. Total start times deleted" + " so far this cycle: {}",batchSize,startTimesCount);
          IOUtils.cleanupWithLogger(LOG,writeBatch);
          writeBatch=starttimedb.createWriteBatch();
          batchSize=0;
        }
      }
      ++totalCount;
    }
    LOG.debug("Preparing to delete a batch of {} old start times",batchSize);
    starttimedb.write(writeBatch);
    LOG.debug("Deleted batch of {}. Total start times deleted so far" + " this cycle: {}",batchSize,startTimesCount);
    LOG.info("Deleted " + startTimesCount + "/"+ totalCount+ " start time entities earlier than "+ minStartTime);
  }
  finally {
    IOUtils.cleanupWithLogger(LOG,writeBatch);
  }
  return startTimesCount;
}
