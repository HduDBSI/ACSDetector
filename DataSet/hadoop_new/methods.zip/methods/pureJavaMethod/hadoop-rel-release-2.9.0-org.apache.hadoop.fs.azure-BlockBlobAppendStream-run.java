@Override public void run(){
  try {
    command.dump();
    long startTime=System.nanoTime();
    command.execute();
    command.setCompleted();
    LOG.debug("command finished for {} ms",TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startTime));
  }
 catch (  InterruptedException ie) {
    Thread.currentThread().interrupt();
  }
catch (  Exception ex) {
    LOG.debug("Encountered exception during execution of command for Blob :" + " {} Exception : {}",key,ex);
    firstError.compareAndSet(null,new AzureException(ex));
  }
}
