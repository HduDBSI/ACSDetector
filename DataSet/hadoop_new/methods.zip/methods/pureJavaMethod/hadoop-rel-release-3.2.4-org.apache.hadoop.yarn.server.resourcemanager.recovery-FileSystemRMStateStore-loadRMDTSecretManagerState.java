private void loadRMDTSecretManagerState(RMState rmState) throws Exception {
  checkAndResumeUpdateOperation(rmDTSecretManagerRoot);
  FileStatus[] childNodes=listStatusWithRetries(rmDTSecretManagerRoot);
  for (  FileStatus childNodeStatus : childNodes) {
    assert childNodeStatus.isFile();
    String childNodeName=childNodeStatus.getPath().getName();
    if (checkAndRemovePartialRecordWithRetries(childNodeStatus.getPath())) {
      continue;
    }
    if (childNodeName.startsWith(DELEGATION_TOKEN_SEQUENCE_NUMBER_PREFIX)) {
      rmState.rmSecretManagerState.dtSequenceNumber=Integer.parseInt(childNodeName.split("_")[1]);
      continue;
    }
    Path childNodePath=getNodePath(rmDTSecretManagerRoot,childNodeName);
    byte[] childData=readFileWithRetries(childNodePath,childNodeStatus.getLen());
    ByteArrayInputStream is=new ByteArrayInputStream(childData);
    try (DataInputStream fsIn=new DataInputStream(is)){
      if (childNodeName.startsWith(DELEGATION_KEY_PREFIX)) {
        DelegationKey key=new DelegationKey();
        key.readFields(fsIn);
        rmState.rmSecretManagerState.masterKeyState.add(key);
        if (LOG.isDebugEnabled()) {
          LOG.debug("Loaded delegation key: keyId=" + key.getKeyId() + ", expirationDate="+ key.getExpiryDate());
        }
      }
 else       if (childNodeName.startsWith(DELEGATION_TOKEN_PREFIX)) {
        RMDelegationTokenIdentifierData identifierData=RMStateStoreUtils.readRMDelegationTokenIdentifierData(fsIn);
        RMDelegationTokenIdentifier identifier=identifierData.getTokenIdentifier();
        long renewDate=identifierData.getRenewDate();
        rmState.rmSecretManagerState.delegationTokenState.put(identifier,renewDate);
        if (LOG.isDebugEnabled()) {
          LOG.debug("Loaded RMDelegationTokenIdentifier: " + identifier + " renewDate="+ renewDate);
        }
      }
 else {
        LOG.warn("Unknown file for recovering RMDelegationTokenSecretManager");
      }
    }
   }
}
