private void loadPermissionInfo(){
  IOException e=null;
  try {
    String output=FileUtil.execCommand(new File(getPath().toUri()),Shell.getGetPermissionCommand());
    StringTokenizer t=new StringTokenizer(output,Shell.TOKEN_SEPARATOR_REGEX);
    String permission=t.nextToken();
    if (permission.length() > FsPermission.MAX_PERMISSION_LENGTH) {
      permission=permission.substring(0,FsPermission.MAX_PERMISSION_LENGTH);
    }
    setPermission(FsPermission.valueOf(permission));
    t.nextToken();
    String owner=t.nextToken();
    if (Shell.WINDOWS) {
      int i=owner.indexOf('\\');
      if (i != -1)       owner=owner.substring(i + 1);
    }
    setOwner(owner);
    setGroup(t.nextToken());
  }
 catch (  Shell.ExitCodeException ioe) {
    if (ioe.getExitCode() != 1) {
      e=ioe;
    }
 else {
      setPermission(null);
      setOwner(null);
      setGroup(null);
    }
  }
catch (  IOException ioe) {
    e=ioe;
  }
 finally {
    if (e != null) {
      throw new RuntimeException("Error while running command to get " + "file permissions : " + StringUtils.stringifyException(e));
    }
  }
}
