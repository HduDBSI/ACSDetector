@Override public void teardown() throws Exception {
  MultipartUploader uploader=getUploader(1);
  if (uploader != null) {
    if (activeUpload != null) {
      abortUploadQuietly(activeUpload,activeUploadPath);
    }
    try {
      Path teardown=getContract().getTestPath();
      LOG.info("Teardown: aborting outstanding uploads under {}",teardown);
      CompletableFuture<Integer> f=uploader.abortUploadsUnderPath(teardown);
      f.get();
      LOG.info("Statistics {}",ioStatisticsSourceToString(uploader));
    }
 catch (    Exception e) {
      LOG.warn("Exeception in teardown",e);
    }
  }
  cleanupWithLogger(LOG,uploader0,uploader1);
  super.teardown();
}
