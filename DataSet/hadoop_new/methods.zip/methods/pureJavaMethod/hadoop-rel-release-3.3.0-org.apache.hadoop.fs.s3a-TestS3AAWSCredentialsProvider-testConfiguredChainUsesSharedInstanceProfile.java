@Test public void testConfiguredChainUsesSharedInstanceProfile() throws Exception {
  URI uri1=new URI("s3a://bucket1"), uri2=new URI("s3a://bucket2");
  Configuration conf=new Configuration(false);
  List<Class<?>> expectedClasses=Arrays.asList(InstanceProfileCredentialsProvider.class);
  conf.set(AWS_CREDENTIALS_PROVIDER,buildClassListString(expectedClasses));
  AWSCredentialProviderList list1=createAWSCredentialProviderSet(uri1,conf);
  AWSCredentialProviderList list2=createAWSCredentialProviderSet(uri2,conf);
  assertCredentialProviders(expectedClasses,list1);
  assertCredentialProviders(expectedClasses,list2);
}
