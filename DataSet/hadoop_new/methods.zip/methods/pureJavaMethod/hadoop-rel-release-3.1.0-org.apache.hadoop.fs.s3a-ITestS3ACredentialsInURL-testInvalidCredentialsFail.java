/** 
 * Set up some invalid credentials, verify login is rejected.
 */
@Test public void testInvalidCredentialsFail() throws Throwable {
  Configuration conf=new Configuration();
  conf.unset(AWS_CREDENTIALS_PROVIDER);
  String fsname=conf.getTrimmed(TEST_FS_S3A_NAME,"");
  Assume.assumeNotNull(fsname);
  assumeS3GuardState(false,conf);
  URI original=new URI(fsname);
  URI testURI=createUriWithEmbeddedSecrets(original,"user","//");
  conf.set(TEST_FS_S3A_NAME,testURI.toString());
  LambdaTestUtils.intercept(AccessDeniedException.class,() -> {
    fs=S3ATestUtils.createTestFileSystem(conf);
    return fs.getFileStatus(new Path("/"));
  }
);
}
