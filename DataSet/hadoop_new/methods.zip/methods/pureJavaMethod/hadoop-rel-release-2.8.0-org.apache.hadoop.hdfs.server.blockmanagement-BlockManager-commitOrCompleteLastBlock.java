/** 
 * Commit the last block of the file and mark it as complete if it has meets the minimum replication requirement
 * @param bc block collection
 * @param commitBlock - contains client reported block length and generation
 * @param iip - INodes in path to bc
 * @return true if the last block is changed to committed state.
 * @throws IOException if the block does not have at least a minimal numberof replicas reported from data-nodes.
 */
public boolean commitOrCompleteLastBlock(BlockCollection bc,Block commitBlock,INodesInPath iip) throws IOException {
  if (commitBlock == null)   return false;
  BlockInfo lastBlock=bc.getLastBlock();
  if (lastBlock == null)   return false;
  if (lastBlock.isComplete())   return false;
  final boolean b=commitBlock(lastBlock,commitBlock);
  if (countNodes(lastBlock).liveReplicas() >= minReplication) {
    if (b) {
      addExpectedReplicasToPending(lastBlock,bc);
    }
    completeBlock(lastBlock,iip,false);
  }
  return b;
}
