@Override public Boolean get(){
  return ns.getCompleteBlocksTotal() > 0;
}
