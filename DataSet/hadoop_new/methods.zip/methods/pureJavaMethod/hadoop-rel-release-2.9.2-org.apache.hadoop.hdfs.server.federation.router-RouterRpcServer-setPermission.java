@Override public void setPermission(String src,FsPermission permissions) throws IOException {
  clientProto.setPermission(src,permissions);
}
