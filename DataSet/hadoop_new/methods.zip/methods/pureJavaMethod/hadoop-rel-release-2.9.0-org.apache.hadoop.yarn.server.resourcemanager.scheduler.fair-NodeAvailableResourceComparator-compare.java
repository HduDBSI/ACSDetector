@Override public int compare(FSSchedulerNode n1,FSSchedulerNode n2){
  return RESOURCE_CALCULATOR.compare(getClusterResource(),n2.getUnallocatedResource(),n1.getUnallocatedResource());
}
