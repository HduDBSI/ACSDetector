@Override public boolean truncate(String src,long newLength,String clientName) throws IOException {
  return clientProto.truncate(src,newLength,clientName);
}
