@Override public void markContainerForPreemption(ApplicationAttemptId aid,RMContainer cont){
  LOG.debug("{}: appAttempt:{} container:{}",SchedulerEventType.MARK_CONTAINER_FOR_PREEMPTION,aid,cont);
  FiCaSchedulerApp app=getApplicationAttempt(aid);
  if (app != null) {
    app.markContainerForPreemption(cont.getContainerId());
  }
}
