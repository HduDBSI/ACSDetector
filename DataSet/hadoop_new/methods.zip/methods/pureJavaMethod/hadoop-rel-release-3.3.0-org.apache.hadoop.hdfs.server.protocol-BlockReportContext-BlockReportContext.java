public BlockReportContext(int totalRpcs,int curRpc,long reportId,long leaseId,boolean sorted){
  this.totalRpcs=totalRpcs;
  this.curRpc=curRpc;
  this.reportId=reportId;
  this.leaseId=leaseId;
  this.sorted=sorted;
}
