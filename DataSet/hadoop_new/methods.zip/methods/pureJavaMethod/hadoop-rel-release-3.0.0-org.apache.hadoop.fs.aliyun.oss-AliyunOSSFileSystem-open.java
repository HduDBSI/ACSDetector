@Override public FSDataInputStream open(Path path,int bufferSize) throws IOException {
  final FileStatus fileStatus=getFileStatus(path);
  if (fileStatus.isDirectory()) {
    throw new FileNotFoundException("Can't open " + path + " because it is a directory");
  }
  return new FSDataInputStream(new AliyunOSSInputStream(getConf(),store,pathToKey(path),fileStatus.getLen(),statistics));
}
