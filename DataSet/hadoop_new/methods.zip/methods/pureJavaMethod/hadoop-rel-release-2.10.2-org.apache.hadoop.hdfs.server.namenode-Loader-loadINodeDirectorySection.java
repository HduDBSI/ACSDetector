void loadINodeDirectorySection(InputStream in) throws IOException {
  final List<INodeReference> refList=parent.getLoaderContext().getRefList();
  ArrayList<INode> inodeList=new ArrayList<>();
  while (true) {
    INodeDirectorySection.DirEntry e=INodeDirectorySection.DirEntry.parseDelimitedFrom(in);
    if (e == null) {
      break;
    }
    INodeDirectory p=dir.getInode(e.getParent()).asDirectory();
    for (    long id : e.getChildrenList()) {
      INode child=dir.getInode(id);
      if (addToParent(p,child)) {
        if (child.isFile()) {
          inodeList.add(child);
        }
        if (inodeList.size() >= DIRECTORY_ENTRY_BATCH_SIZE) {
          addToCacheAndBlockMap(inodeList);
          inodeList.clear();
        }
      }
 else {
        LOG.warn("Failed to add the inode " + child.getId() + "to the directory "+ p.getId());
      }
    }
    for (    int refId : e.getRefChildrenList()) {
      INodeReference ref=refList.get(refId);
      if (addToParent(p,ref)) {
        if (ref.isFile()) {
          inodeList.add(ref);
        }
        if (inodeList.size() >= DIRECTORY_ENTRY_BATCH_SIZE) {
          addToCacheAndBlockMap(inodeList);
          inodeList.clear();
        }
      }
 else {
        LOG.warn("Failed to add the inode reference " + ref.getId() + " to the directory "+ p.getId());
      }
    }
  }
  addToCacheAndBlockMap(inodeList);
}
