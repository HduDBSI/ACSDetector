/** 
 * Clear and re-create storage directory. <p> Removes contents of the current directory and creates an empty directory. This does not fully format storage directory.  It cannot write the version file since it should be written last after   all other storage type dependent files are written. Derived storage is responsible for setting specific storage values and writing the version file to disk.
 * @throws IOException
 */
public void clearDirectory() throws IOException {
  File curDir=this.getCurrentDir();
  if (curDir.exists()) {
    File[] files=FileUtil.listFiles(curDir);
    LOG.info("Will remove files: " + Arrays.toString(files));
    if (!(FileUtil.fullyDelete(curDir)))     throw new IOException("Cannot remove current directory: " + curDir);
  }
  if (!curDir.mkdirs())   throw new IOException("Cannot create directory " + curDir);
}
