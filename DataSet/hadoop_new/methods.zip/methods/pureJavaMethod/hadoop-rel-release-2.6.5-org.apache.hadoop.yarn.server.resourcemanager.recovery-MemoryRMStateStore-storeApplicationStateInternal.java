@Override public void storeApplicationStateInternal(ApplicationId appId,ApplicationStateData appStateData) throws Exception {
  ApplicationState appState=new ApplicationState(appStateData.getSubmitTime(),appStateData.getStartTime(),appStateData.getApplicationSubmissionContext(),appStateData.getUser());
  state.appState.put(appId,appState);
}
