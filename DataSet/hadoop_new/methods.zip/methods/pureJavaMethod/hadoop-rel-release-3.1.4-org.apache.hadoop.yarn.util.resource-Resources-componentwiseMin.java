public static Resource componentwiseMin(Resource lhs,Resource rhs){
  Resource ret=createResource(0);
  int maxLength=ResourceUtils.getNumberOfKnownResourceTypes();
  for (int i=0; i < maxLength; i++) {
    try {
      ResourceInformation rhsValue=rhs.getResourceInformation(i);
      ResourceInformation lhsValue=lhs.getResourceInformation(i);
      long convertedRhs=(rhsValue.getUnits().equals(lhsValue.getUnits())) ? rhsValue.getValue() : UnitsConversionUtil.convert(rhsValue.getUnits(),lhsValue.getUnits(),rhsValue.getValue());
      ResourceInformation outInfo=lhsValue.getValue() < convertedRhs ? lhsValue : rhsValue;
      ret.setResourceInformation(i,outInfo);
    }
 catch (    ResourceNotFoundException ye) {
      LOG.warn("Resource is missing:" + ye.getMessage());
      continue;
    }
  }
  return ret;
}
