@VisibleForTesting public String findRedirectUrl() throws ServletException {
  String addr=null;
  if (proxyUriBases.size() == 1) {
    addr=proxyUriBases.values().iterator().next();
  }
 else   if (rmUrls != null) {
    for (    String url : rmUrls) {
      String host=proxyUriBases.get(url);
      if (isValidUrl(host)) {
        addr=host;
        break;
      }
    }
  }
  if (addr == null) {
    throw new ServletException("Could not determine the proxy server for redirection");
  }
  return addr;
}
