public static MD5Hash doGetUrl(URL url,List<File> localPaths,Storage dstStorage,boolean getChecksum) throws IOException {
  return Util.doGetUrl(url,localPaths,dstStorage,getChecksum,timeout);
}
