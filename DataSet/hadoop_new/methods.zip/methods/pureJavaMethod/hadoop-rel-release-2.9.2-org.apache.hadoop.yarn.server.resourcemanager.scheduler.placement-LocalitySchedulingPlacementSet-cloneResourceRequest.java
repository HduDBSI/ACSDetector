public ResourceRequest cloneResourceRequest(ResourceRequest request){
  ResourceRequest newRequest=ResourceRequest.newBuilder().priority(request.getPriority()).allocationRequestId(request.getAllocationRequestId()).resourceName(request.getResourceName()).capability(request.getCapability()).numContainers(1).relaxLocality(request.getRelaxLocality()).nodeLabelExpression(request.getNodeLabelExpression()).build();
  return newRequest;
}
