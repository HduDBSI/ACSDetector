public IPFailoverProxyProvider(Configuration conf,URI uri,Class<T> xface,HAProxyFactory<T> factory){
  this.xface=xface;
  this.nameNodeUri=uri;
  this.factory=factory;
  this.conf=new Configuration(conf);
  int maxRetries=this.conf.getInt(HdfsClientConfigKeys.Failover.CONNECTION_RETRIES_KEY,HdfsClientConfigKeys.Failover.CONNECTION_RETRIES_DEFAULT);
  this.conf.setInt(CommonConfigurationKeysPublic.IPC_CLIENT_CONNECT_MAX_RETRIES_KEY,maxRetries);
  int maxRetriesOnSocketTimeouts=this.conf.getInt(HdfsClientConfigKeys.Failover.CONNECTION_RETRIES_ON_SOCKET_TIMEOUTS_KEY,HdfsClientConfigKeys.Failover.CONNECTION_RETRIES_ON_SOCKET_TIMEOUTS_DEFAULT);
  this.conf.setInt(CommonConfigurationKeysPublic.IPC_CLIENT_CONNECT_MAX_RETRIES_ON_SOCKET_TIMEOUTS_KEY,maxRetriesOnSocketTimeouts);
}
