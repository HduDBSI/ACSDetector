@Override public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
  if (!HttpServer2.isInstrumentationAccessAllowed(getServletContext(),request,response)) {
    return;
  }
  String format=request.getParameter("format");
  Collection<MetricsContext> allContexts=ContextFactory.getFactory().getAllContexts();
  if ("json".equals(format)) {
    response.setContentType("application/json; charset=utf-8");
    PrintWriter out=response.getWriter();
    try {
      out.print(new JSON().toJSON(makeMap(allContexts)));
    }
  finally {
      out.close();
    }
  }
 else {
    PrintWriter out=response.getWriter();
    try {
      printMap(out,makeMap(allContexts));
    }
  finally {
      out.close();
    }
  }
}
