public void createTable(Admin admin,Configuration hbaseConf) throws IOException {
  TableName table=getTableName(hbaseConf);
  if (admin.tableExists(table)) {
    throw new IOException("Table " + table.getNameAsString() + " already exists.");
  }
  HTableDescriptor appToFlowTableDescp=new HTableDescriptor(table);
  HColumnDescriptor mappCF=new HColumnDescriptor(AppToFlowColumnFamily.MAPPING.getBytes());
  mappCF.setBloomFilterType(BloomType.ROWCOL);
  appToFlowTableDescp.addFamily(mappCF);
  admin.createTable(appToFlowTableDescp);
  LOG.info("Status of table creation for " + table.getNameAsString() + "="+ admin.tableExists(table));
}
