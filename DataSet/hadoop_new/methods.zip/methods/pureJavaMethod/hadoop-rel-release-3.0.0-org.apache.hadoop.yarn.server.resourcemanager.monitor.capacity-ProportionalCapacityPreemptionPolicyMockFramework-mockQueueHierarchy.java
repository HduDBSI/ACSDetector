/** 
 * Format is: <pre> root (<partition-name-1>=[guaranteed max used pending (reserved)],<partition-name-2>=..); -A(...); --A1(...); --A2(...); -B... </pre> ";" splits queues, and there should no empty lines, no extra spaces For each queue, it has configurations to specify capacities (to each partition), format is: <pre> -<queueName> (<labelName1>=[guaranteed max used pending], \ <labelName2>=[guaranteed max used pending]) {key1=value1,key2=value2};  // Additional configs </pre>
 */
@SuppressWarnings({"unchecked","rawtypes"}) private ParentQueue mockQueueHierarchy(String queueExprs){
  String[] queueExprArray=queueExprs.split(";");
  ParentQueue rootQueue=null;
  for (int idx=0; idx < queueExprArray.length; idx++) {
    String q=queueExprArray[idx];
    CSQueue queue;
    if (isParent(queueExprArray,idx)) {
      ParentQueue parentQueue=mock(ParentQueue.class);
      queue=parentQueue;
      List<CSQueue> children=new ArrayList<CSQueue>();
      when(parentQueue.getChildQueues()).thenReturn(children);
      QueueOrderingPolicy policy=mock(QueueOrderingPolicy.class);
      when(policy.getConfigName()).thenReturn(CapacitySchedulerConfiguration.QUEUE_PRIORITY_UTILIZATION_ORDERING_POLICY);
      when(parentQueue.getQueueOrderingPolicy()).thenReturn(policy);
    }
 else {
      LeafQueue leafQueue=mock(LeafQueue.class);
      final TreeSet<FiCaSchedulerApp> apps=new TreeSet<>(new Comparator<FiCaSchedulerApp>(){
        @Override public int compare(        FiCaSchedulerApp a1,        FiCaSchedulerApp a2){
          if (a1.getPriority() != null && !a1.getPriority().equals(a2.getPriority())) {
            return a1.getPriority().compareTo(a2.getPriority());
          }
          int res=a1.getApplicationId().compareTo(a2.getApplicationId());
          return res;
        }
      }
);
      when(leafQueue.getApplications()).thenReturn(apps);
      when(leafQueue.getAllApplications()).thenReturn(apps);
      OrderingPolicy<FiCaSchedulerApp> so=mock(OrderingPolicy.class);
      when(so.getPreemptionIterator()).thenAnswer(new Answer(){
        public Object answer(        InvocationOnMock invocation){
          return apps.descendingIterator();
        }
      }
);
      when(leafQueue.getOrderingPolicy()).thenReturn(so);
      Map<String,TreeSet<RMContainer>> ignorePartitionContainers=new HashMap<>();
      when(leafQueue.getIgnoreExclusivityRMContainers()).thenReturn(ignorePartitionContainers);
      queue=leafQueue;
    }
    ReentrantReadWriteLock lock=new ReentrantReadWriteLock();
    when(queue.getReadLock()).thenReturn(lock.readLock());
    setupQueue(queue,q,queueExprArray,idx);
    if (queue.getQueueName().equals(ROOT)) {
      rootQueue=(ParentQueue)queue;
    }
  }
  return rootQueue;
}
