void setLastBlock(BlockInfo blk){
  blk.setBlockCollectionId(this.getId());
  setBlock(numBlocks() - 1,blk);
}
