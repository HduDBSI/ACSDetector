private void deleteTempFile(Path tempPath){
  try {
    if (tempPath != null) {
      fs.delete(tempPath,false);
    }
  }
 catch (  IOException ioe) {
    LOG.debug("Exception received while deleting temp files",ioe);
  }
}
