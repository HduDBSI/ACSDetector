public static String getDefaultRealmProtected(){
  String realmString=null;
  try {
    realmString=getDefaultRealm();
  }
 catch (  RuntimeException rte) {
  }
catch (  Exception e) {
  }
  return realmString;
}
