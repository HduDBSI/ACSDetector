/** 
 * Compare a value in a given unit with a value in another unit. The return value is equivalent to the value returned by compareTo.
 * @param unitA  first unit
 * @param valueA first value
 * @param unitB  second unit
 * @param valueB second value
 * @return +1, 0 or -1 depending on whether the relationship is greater than,equal to or lesser than
 */
public static int compare(String unitA,long valueA,String unitB,long valueB){
  if (unitA == null || unitB == null || !KNOWN_UNITS.contains(unitA) || !KNOWN_UNITS.contains(unitB)) {
    throw new IllegalArgumentException("Units cannot be null");
  }
  if (!KNOWN_UNITS.contains(unitA)) {
    throw new IllegalArgumentException("Unknown unit '" + unitA + "'");
  }
  if (!KNOWN_UNITS.contains(unitB)) {
    throw new IllegalArgumentException("Unknown unit '" + unitB + "'");
  }
  if (unitA.equals(unitB)) {
    return Long.compare(valueA,valueB);
  }
  Converter unitAC=getConverter(unitA);
  Converter unitBC=getConverter(unitB);
  int unitAPos=SORTED_UNITS.indexOf(unitA);
  int unitBPos=SORTED_UNITS.indexOf(unitB);
  try {
    long tmpA=valueA;
    long tmpB=valueB;
    if (unitAPos < unitBPos) {
      tmpB=convert(unitB,unitA,valueB);
    }
 else {
      tmpA=convert(unitA,unitB,valueA);
    }
    return Long.compare(tmpA,tmpB);
  }
 catch (  IllegalArgumentException ie) {
    BigInteger tmpA=BigInteger.valueOf(valueA);
    BigInteger tmpB=BigInteger.valueOf(valueB);
    if (unitAPos < unitBPos) {
      tmpB=tmpB.multiply(BigInteger.valueOf(unitBC.numerator));
      tmpB=tmpB.multiply(BigInteger.valueOf(unitAC.denominator));
      tmpB=tmpB.divide(BigInteger.valueOf(unitBC.denominator));
      tmpB=tmpB.divide(BigInteger.valueOf(unitAC.numerator));
    }
 else {
      tmpA=tmpA.multiply(BigInteger.valueOf(unitAC.numerator));
      tmpA=tmpA.multiply(BigInteger.valueOf(unitBC.denominator));
      tmpA=tmpA.divide(BigInteger.valueOf(unitAC.denominator));
      tmpA=tmpA.divide(BigInteger.valueOf(unitBC.numerator));
    }
    return tmpA.compareTo(tmpB);
  }
}
