/** 
 * Constructor for a mount table entry with multiple destinations.
 * @param src Source path in the mount entry.
 * @param destinations Nameservice destinations of the mount point.
 * @throws IOException
 */
public static MountTable newInstance(final String src,final Map<String,String> destinations) throws IOException {
  MountTable record=newInstance();
  record.setSourcePath(normalizeFileSystemPath(src));
  final List<RemoteLocation> locations=new LinkedList<>();
  for (  Entry<String,String> entry : destinations.entrySet()) {
    String nsId=entry.getKey();
    String path=normalizeFileSystemPath(entry.getValue());
    RemoteLocation location=new RemoteLocation(nsId,path,src);
    locations.add(location);
  }
  record.setDestinations(locations);
  UserGroupInformation ugi=NameNode.getRemoteUser();
  record.setOwnerName(ugi.getShortUserName());
  String group=ugi.getGroups().isEmpty() ? ugi.getShortUserName() : ugi.getPrimaryGroupName();
  record.setGroupName(group);
  record.setMode(new FsPermission(RouterPermissionChecker.MOUNT_TABLE_PERMISSION_DEFAULT));
  RouterQuotaUsage quota=new RouterQuotaUsage.Builder().fileAndDirectoryCount(RouterQuotaUsage.QUOTA_USAGE_COUNT_DEFAULT).quota(HdfsConstants.QUOTA_RESET).spaceConsumed(RouterQuotaUsage.QUOTA_USAGE_COUNT_DEFAULT).spaceQuota(HdfsConstants.QUOTA_RESET).build();
  record.setQuota(quota);
  record.validate();
  return record;
}
