@Override public void transition(RMAppImpl app,RMAppEvent event){
  app.handler.handle(new AppAddedSchedulerEvent(app.user,app.submissionContext,false));
  app.sendATSCreateEvent();
}
