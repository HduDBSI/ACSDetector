@Override public QuotaCounts cleanSubtree(BlockStoragePolicySuite bsps,final int snapshotId,int priorSnapshotId,final BlocksMapUpdateInfo collectedBlocks,final List<INode> removedINodes){
  if (snapshotId == Snapshot.CURRENT_STATE_ID && priorSnapshotId == Snapshot.NO_SNAPSHOT_ID) {
    destroyAndCollectBlocks(bsps,collectedBlocks,removedINodes);
  }
  return new QuotaCounts.Builder().nameSpace(1).build();
}
