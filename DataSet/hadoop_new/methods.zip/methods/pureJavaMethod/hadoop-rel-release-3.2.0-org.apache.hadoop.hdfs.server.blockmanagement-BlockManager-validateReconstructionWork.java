private boolean validateReconstructionWork(BlockReconstructionWork rw){
  BlockInfo block=rw.getBlock();
  int priority=rw.getPriority();
  if (block.isDeleted() || !block.isCompleteOrCommitted()) {
    neededReconstruction.remove(block,priority);
    rw.resetTargets();
    return false;
  }
  NumberReplicas numReplicas=countNodes(block);
  final short requiredRedundancy=getExpectedLiveRedundancyNum(block,numReplicas);
  final int pendingNum=pendingReconstruction.getNumReplicas(block);
  if (hasEnoughEffectiveReplicas(block,numReplicas,pendingNum)) {
    neededReconstruction.remove(block,priority);
    rw.resetTargets();
    blockLog.debug("BLOCK* Removing {} from neededReconstruction as" + " it has enough replicas",block);
    return false;
  }
  DatanodeStorageInfo[] targets=rw.getTargets();
  if ((numReplicas.liveReplicas() >= requiredRedundancy) && (!isPlacementPolicySatisfied(block))) {
    if (!isInNewRack(rw.getSrcNodes(),targets[0].getDatanodeDescriptor())) {
      return false;
    }
    rw.setNotEnoughRack();
  }
  rw.addTaskToDatanode(numReplicas);
  DatanodeStorageInfo.incrementBlocksScheduled(targets);
  pendingReconstruction.increment(block,DatanodeStorageInfo.toDatanodeDescriptors(targets));
  blockLog.debug("BLOCK* block {} is moved from neededReconstruction to " + "pendingReconstruction",block);
  int numEffectiveReplicas=numReplicas.liveReplicas() + pendingNum;
  if (numEffectiveReplicas + targets.length >= requiredRedundancy) {
    neededReconstruction.remove(block,priority);
  }
  return true;
}
