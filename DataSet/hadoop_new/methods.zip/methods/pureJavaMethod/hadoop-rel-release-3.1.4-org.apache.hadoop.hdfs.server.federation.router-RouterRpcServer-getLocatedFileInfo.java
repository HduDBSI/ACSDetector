@Override public HdfsLocatedFileStatus getLocatedFileInfo(String src,boolean needBlockToken) throws IOException {
  return clientProto.getLocatedFileInfo(src,needBlockToken);
}
