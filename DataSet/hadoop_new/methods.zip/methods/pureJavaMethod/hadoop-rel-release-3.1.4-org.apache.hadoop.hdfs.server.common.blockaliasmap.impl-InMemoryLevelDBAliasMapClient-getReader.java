@Override public Reader<FileRegion> getReader(Reader.Options opts,String blockPoolID) throws IOException {
  if (this.blockPoolID == null) {
    this.blockPoolID=aliasMap.getBlockPoolId();
  }
  if (blockPoolID != null && this.blockPoolID != null && !this.blockPoolID.equals(blockPoolID)) {
    return null;
  }
  return new LevelDbReader();
}
