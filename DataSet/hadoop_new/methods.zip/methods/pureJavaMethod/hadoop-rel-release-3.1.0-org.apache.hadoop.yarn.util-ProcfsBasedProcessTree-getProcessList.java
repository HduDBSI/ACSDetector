/** 
 * Get the list of all processes in the system.
 */
private List<String> getProcessList(){
  List<String> processList=Collections.emptyList();
  FileFilter procListFileFilter=new AndFileFilter(DirectoryFileFilter.INSTANCE,new RegexFileFilter(numberPattern));
  File dir=new File(procfsDir);
  File[] processDirs=dir.listFiles(procListFileFilter);
  if (ArrayUtils.isNotEmpty(processDirs)) {
    processList=new ArrayList<String>(processDirs.length);
    for (    File processDir : processDirs) {
      processList.add(processDir.getName());
    }
  }
  return processList;
}
