private String determineRegion(String bucketName) throws IOException {
  return getFileSystem().getBucketLocation(bucketName);
}
