/** 
 * Opens an FSDataInputStream at the indicated Path. if status contains an S3AFileStatus reference, it is used and so a HEAD request to the store is avoided.
 * @param file the file to open
 * @param options configuration options if opened with the builder API.
 * @param providedStatus optional file status.
 * @throws IOException IO failure.
 */
@Retries.RetryTranslated private FSDataInputStream open(final Path file,final Optional<Configuration> options,final Optional<S3AFileStatus> providedStatus) throws IOException {
  entryPoint(INVOCATION_OPEN);
  final Path path=qualify(file);
  S3AFileStatus fileStatus=extractOrFetchSimpleFileStatus(path,providedStatus);
  S3AReadOpContext readContext;
  if (options.isPresent()) {
    Configuration o=options.get();
    S3AInputPolicy policy=S3AInputPolicy.getPolicy(o.get(INPUT_FADVISE,inputPolicy.toString()));
    long readAheadRange2=o.getLong(READAHEAD_RANGE,readAhead);
    readContext=createReadContext(fileStatus,policy,changeDetectionPolicy,readAheadRange2);
  }
 else {
    readContext=createReadContext(fileStatus,inputPolicy,changeDetectionPolicy,readAhead);
  }
  LOG.debug("Opening '{}'",readContext);
  return new FSDataInputStream(new S3AInputStream(readContext,createObjectAttributes(fileStatus),s3));
}
