/** 
 * The  {@link ResourceScheduler} is allocating data-local resources to theapplication.
 * @param allocatedContainers resources allocated to the application
 */
synchronized private void allocateOffSwitch(SchedulerNode node,Priority priority,ResourceRequest offSwitchRequest,Container container,List<ResourceRequest> resourceRequests){
  decrementOutstanding(offSwitchRequest);
  resourceRequests.add(cloneResourceRequest(offSwitchRequest));
}
