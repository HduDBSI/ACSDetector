private static ConnectionConfigurator newSslConnConfigurator(final int connectTimeout,final int readTimeout,Configuration conf) throws IOException, GeneralSecurityException {
  final SSLFactory factory;
  final SSLSocketFactory sf;
  final HostnameVerifier hv;
  factory=new SSLFactory(SSLFactory.Mode.CLIENT,conf);
  factory.init();
  sf=factory.createSSLSocketFactory();
  hv=factory.getHostnameVerifier();
  return new ConnectionConfigurator(){
    @Override public HttpURLConnection configure(    HttpURLConnection conn) throws IOException {
      if (conn instanceof HttpsURLConnection) {
        HttpsURLConnection c=(HttpsURLConnection)conn;
        c.setSSLSocketFactory(sf);
        c.setHostnameVerifier(hv);
      }
      URLConnectionFactory.setTimeouts(conn,connectTimeout,readTimeout);
      return conn;
    }
  }
;
}
