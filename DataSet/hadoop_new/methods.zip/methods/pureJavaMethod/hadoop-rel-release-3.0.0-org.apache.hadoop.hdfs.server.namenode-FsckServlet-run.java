@Override public Object run() throws Exception {
  NameNode nn=NameNodeHttpServer.getNameNodeFromContext(context);
  final FSNamesystem namesystem=nn.getNamesystem();
  final BlockManager bm=namesystem.getBlockManager();
  final int totalDatanodes=namesystem.getNumberOfDatanodes(DatanodeReportType.LIVE);
  new NamenodeFsck(conf,nn,bm.getDatanodeManager().getNetworkTopology(),pmap,out,totalDatanodes,remoteAddress).fsck();
  return null;
}
