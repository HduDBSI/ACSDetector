@Private @VisibleForTesting public int dumpAContainersLogs(String appId,String containerId,String nodeId,String jobOwner) throws IOException {
  Path remoteRootLogDir=new Path(getConf().get(YarnConfiguration.NM_REMOTE_APP_LOG_DIR,YarnConfiguration.DEFAULT_NM_REMOTE_APP_LOG_DIR));
  String suffix=LogAggregationUtils.getRemoteNodeLogDirSuffix(getConf());
  Path remoteAppLogDir=LogAggregationUtils.getRemoteAppLogDir(remoteRootLogDir,ConverterUtils.toApplicationId(appId),jobOwner,suffix);
  RemoteIterator<FileStatus> nodeFiles;
  try {
    Path qualifiedLogDir=FileContext.getFileContext(getConf()).makeQualified(remoteAppLogDir);
    nodeFiles=FileContext.getFileContext(qualifiedLogDir.toUri(),getConf()).listStatus(remoteAppLogDir);
  }
 catch (  FileNotFoundException fnf) {
    logDirNotExist(remoteAppLogDir.toString());
    return -1;
  }
  boolean foundContainerLogs=false;
  while (nodeFiles.hasNext()) {
    FileStatus thisNodeFile=nodeFiles.next();
    String fileName=thisNodeFile.getPath().getName();
    if (fileName.contains(LogAggregationUtils.getNodeString(nodeId)) && !fileName.endsWith(LogAggregationUtils.TMP_FILE_SUFFIX)) {
      AggregatedLogFormat.LogReader reader=null;
      try {
        reader=new AggregatedLogFormat.LogReader(getConf(),thisNodeFile.getPath());
        if (dumpAContainerLogs(containerId,reader,System.out,thisNodeFile.getModificationTime()) > -1) {
          foundContainerLogs=true;
        }
      }
  finally {
        if (reader != null) {
          reader.close();
        }
      }
    }
  }
  if (!foundContainerLogs) {
    containerLogNotFound(containerId);
    return -1;
  }
  return 0;
}
