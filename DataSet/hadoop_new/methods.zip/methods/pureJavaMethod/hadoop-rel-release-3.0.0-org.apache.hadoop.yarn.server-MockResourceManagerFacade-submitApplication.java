@Override public SubmitApplicationResponse submitApplication(SubmitApplicationRequest request) throws YarnException, IOException {
  validateRunning();
  ApplicationId appId=null;
  if (request.getApplicationSubmissionContext() != null) {
    appId=request.getApplicationSubmissionContext().getApplicationId();
  }
  LOG.info("Application submitted: " + appId);
  applicationMap.add(appId);
  return SubmitApplicationResponse.newInstance();
}
