private void mountCGroupController(CGroupController controller) throws ResourceHandlerException {
  String existingMountPath=getControllerPath(controller);
  String requestedMountPath=new File(cGroupsMountConfig.getMountPath(),controller.getName()).getAbsolutePath();
  if (existingMountPath == null || !requestedMountPath.equals(existingMountPath)) {
    try {
      rwLock.writeLock().lock();
      String mountOptions;
      if (existingMountPath != null) {
        mountOptions=Joiner.on(',').join(parsedMtab.get(existingMountPath));
      }
 else {
        mountOptions=controller.getName();
      }
      String cGroupKV=mountOptions + "=" + requestedMountPath;
      PrivilegedOperation.OperationType opType=PrivilegedOperation.OperationType.MOUNT_CGROUPS;
      PrivilegedOperation op=new PrivilegedOperation(opType);
      op.appendArgs(cGroupPrefix,cGroupKV);
      LOG.info("Mounting controller " + controller.getName() + " at "+ requestedMountPath);
      privilegedOperationExecutor.executePrivilegedOperation(op,false);
      controllerPaths.put(controller,requestedMountPath);
    }
 catch (    PrivilegedOperationException e) {
      LOG.error("Failed to mount controller: " + controller.getName());
      throw new ResourceHandlerException("Failed to mount controller: " + controller.getName());
    }
 finally {
      rwLock.writeLock().unlock();
    }
  }
 else {
    LOG.info("CGroup controller already mounted at: " + existingMountPath);
  }
}
