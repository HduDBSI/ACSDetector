@Override public boolean fitsIn(Resource smaller,Resource bigger){
  int maxLength=ResourceUtils.getNumberOfKnownResourceTypes();
  for (int i=0; i < maxLength; i++) {
    ResourceInformation sResourceInformation=smaller.getResourceInformation(i);
    ResourceInformation bResourceInformation=bigger.getResourceInformation(i);
    long sResourceValue=UnitsConversionUtil.convert(sResourceInformation.getUnits(),bResourceInformation.getUnits(),sResourceInformation.getValue());
    if (sResourceValue > bResourceInformation.getValue()) {
      return false;
    }
  }
  return true;
}
