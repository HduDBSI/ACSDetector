public BZip2CompressionInputStream(InputStream in,long start,long end,READ_MODE readMode) throws IOException {
  super(in,start,end);
  needsReset=false;
  bufferedIn=new BufferedInputStream(super.in);
  this.startingPos=super.getPos();
  this.readMode=readMode;
  long numSkipped=0;
  if (this.startingPos == 0) {
    bufferedIn=readStreamHeader();
  }
 else   if (this.readMode == READ_MODE.BYBLOCK && this.startingPos <= HEADER_LEN + SUB_HEADER_LEN) {
    numSkipped=HEADER_LEN + SUB_HEADER_LEN + 1 - this.startingPos;
    long skipBytes=numSkipped;
    while (skipBytes > 0) {
      long s=bufferedIn.skip(skipBytes);
      if (s > 0) {
        skipBytes-=s;
      }
 else {
        if (bufferedIn.read() == -1) {
          break;
        }
 else {
          skipBytes--;
        }
      }
    }
  }
  input=new CBZip2InputStream(bufferedIn,readMode);
  if (this.isHeaderStripped) {
    input.updateReportedByteCount(HEADER_LEN);
  }
  if (this.isSubHeaderStripped) {
    input.updateReportedByteCount(SUB_HEADER_LEN);
  }
  if (numSkipped > 0) {
    input.updateReportedByteCount((int)numSkipped);
  }
  if (!(this.readMode == READ_MODE.BYBLOCK && this.startingPos == 0)) {
    this.updatePos(false);
  }
}
