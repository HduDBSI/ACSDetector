protected void createReleaseCache(){
  new Timer().schedule(new TimerTask(){
    @Override public void run(){
      for (      SchedulerApplication<T> app : applications.values()) {
        T attempt=app.getCurrentAppAttempt();
synchronized (attempt) {
          for (          ContainerId containerId : attempt.getPendingRelease()) {
            RMAuditLogger.logFailure(app.getUser(),AuditConstants.RELEASE_CONTAINER,"Unauthorized access or invalid container","Scheduler","Trying to release container not owned by app or with invalid id.",attempt.getApplicationId(),containerId);
          }
          attempt.getPendingRelease().clear();
        }
      }
      LOG.info("Release request cache is cleaned up");
    }
  }
,nmExpireInterval);
}
