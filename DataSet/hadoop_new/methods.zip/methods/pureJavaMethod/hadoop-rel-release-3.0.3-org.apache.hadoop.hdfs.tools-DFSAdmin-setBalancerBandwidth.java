/** 
 * Command to ask the active namenode to set the balancer bandwidth. Usage: hdfs dfsadmin -setBalancerBandwidth bandwidth
 * @param argv List of of command line parameters.
 * @param idx The index of the command that is being processed.
 * @exception IOException 
 */
public int setBalancerBandwidth(String[] argv,int idx) throws IOException {
  long bandwidth;
  int exitCode=-1;
  try {
    bandwidth=StringUtils.TraditionalBinaryPrefix.string2long(argv[idx]);
  }
 catch (  NumberFormatException nfe) {
    System.err.println("NumberFormatException: " + nfe.getMessage());
    System.err.println("Usage: hdfs dfsadmin" + " [-setBalancerBandwidth <bandwidth in bytes per second>]");
    return exitCode;
  }
  if (bandwidth < 0) {
    System.err.println("Bandwidth should be a non-negative integer");
    return exitCode;
  }
  FileSystem fs=getFS();
  if (!(fs instanceof DistributedFileSystem)) {
    System.err.println("FileSystem is " + fs.getUri());
    return exitCode;
  }
  DistributedFileSystem dfs=(DistributedFileSystem)fs;
  try {
    dfs.setBalancerBandwidth(bandwidth);
    System.out.println("Balancer bandwidth is set to " + bandwidth);
  }
 catch (  IOException ioe) {
    System.err.println("Balancer bandwidth is set failed.");
    throw ioe;
  }
  exitCode=0;
  return exitCode;
}
