private static void createContainerLogInLocalDir(Path appLogsDir,ContainerId containerId,FileSystem fs,String fileName,String content) throws IOException {
  Path containerLogsDir=new Path(appLogsDir,containerId.toString());
  if (fs.exists(containerLogsDir)) {
    fs.delete(containerLogsDir,true);
  }
  assertTrue(fs.mkdirs(containerLogsDir));
  Writer writer=new FileWriter(new File(containerLogsDir.toString(),fileName));
  writer.write(content);
  writer.close();
}
