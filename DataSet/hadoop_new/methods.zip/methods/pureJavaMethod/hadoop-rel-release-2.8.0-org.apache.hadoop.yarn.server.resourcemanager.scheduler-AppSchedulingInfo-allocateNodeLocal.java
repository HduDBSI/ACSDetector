/** 
 * The  {@link ResourceScheduler} is allocating data-local resources to theapplication.
 */
private synchronized void allocateNodeLocal(SchedulerNode node,Priority priority,ResourceRequest nodeLocalRequest,List<ResourceRequest> resourceRequests){
  decResourceRequest(node.getNodeName(),priority,nodeLocalRequest);
  ResourceRequest rackLocalRequest=resourceRequestMap.get(priority).get(node.getRackName());
  decResourceRequest(node.getRackName(),priority,rackLocalRequest);
  ResourceRequest offRackRequest=resourceRequestMap.get(priority).get(ResourceRequest.ANY);
  decrementOutstanding(offRackRequest);
  resourceRequests.add(cloneResourceRequest(nodeLocalRequest));
  resourceRequests.add(cloneResourceRequest(rackLocalRequest));
  resourceRequests.add(cloneResourceRequest(offRackRequest));
}
