/** 
 * Internal version of  {@link #getFileStatus(Path)}.
 * @param f The path we want information from
 * @param needEmptyDirectoryFlag if true, implementation will calculatea TRUE or FALSE value for  {@link S3AFileStatus#isEmptyDirectory()}
 * @return a S3AFileStatus object
 * @throws FileNotFoundException when the path does not exist
 * @throws IOException on other problems.
 */
@VisibleForTesting S3AFileStatus innerGetFileStatus(final Path f,boolean needEmptyDirectoryFlag) throws IOException {
  incrementStatistic(INVOCATION_GET_FILE_STATUS);
  final Path path=qualify(f);
  String key=pathToKey(path);
  LOG.debug("Getting path status for {}  ({})",path,key);
  PathMetadata pm=metadataStore.get(path,needEmptyDirectoryFlag);
  Set<Path> tombstones=Collections.EMPTY_SET;
  if (pm != null) {
    if (pm.isDeleted()) {
      throw new FileNotFoundException("Path " + f + " is recorded as "+ "deleted by S3Guard");
    }
    FileStatus msStatus=pm.getFileStatus();
    if (needEmptyDirectoryFlag && msStatus.isDirectory()) {
      if (pm.isEmptyDirectory() != Tristate.UNKNOWN) {
        return S3AFileStatus.fromFileStatus(msStatus,pm.isEmptyDirectory());
      }
 else {
        DirListingMetadata children=metadataStore.listChildren(path);
        if (children != null) {
          tombstones=children.listTombstones();
        }
        LOG.debug("MetadataStore doesn't know if {} is empty, using S3.",path);
      }
    }
 else {
      return S3AFileStatus.fromFileStatus(msStatus,pm.isEmptyDirectory());
    }
    try {
      S3AFileStatus s3FileStatus=s3GetFileStatus(path,key,StatusProbeEnum.ALL,tombstones,true);
      return S3Guard.putAndReturn(metadataStore,s3FileStatus,instrumentation);
    }
 catch (    FileNotFoundException e) {
      return S3AFileStatus.fromFileStatus(msStatus,Tristate.TRUE);
    }
  }
 else {
    return S3Guard.putAndReturn(metadataStore,s3GetFileStatus(path,key,StatusProbeEnum.ALL,tombstones,needEmptyDirectoryFlag),instrumentation);
  }
}
