@Private public int dumpAllContainersLogs(ContainerLogsRequest options) throws IOException {
  LogAggregationFileController fc=null;
  try {
    fc=this.getFileController(options.getAppId(),options.getAppOwner());
  }
 catch (  IOException ex) {
    System.err.println(ex);
  }
  boolean foundAnyLogs=false;
  if (fc != null) {
    foundAnyLogs=fc.readAggregatedLogs(options,null);
  }
  if (!foundAnyLogs) {
    emptyLogDir(LogAggregationUtils.getRemoteAppLogDir(conf,options.getAppId(),options.getAppOwner()).toString());
    return -1;
  }
  return 0;
}
