@Override public void createSymlink(String target,String link,FsPermission dirPerms,boolean createParent) throws IOException {
  clientProto.createSymlink(target,link,dirPerms,createParent);
}
