@Override public Map<String,byte[]> getXAttrs(Path path,final List<String> names) throws IOException {
  final Path absF=fixRelativePart(path);
  return new FileSystemLinkResolver<Map<String,byte[]>>(){
    @Override public Map<String,byte[]> doCall(    final Path p) throws IOException {
      return dfs.getXAttrs(getPathName(p),names);
    }
    @Override public Map<String,byte[]> next(    final FileSystem fs,    final Path p) throws IOException, UnresolvedLinkException {
      return fs.getXAttrs(p,names);
    }
  }
.resolve(this,absF);
}
