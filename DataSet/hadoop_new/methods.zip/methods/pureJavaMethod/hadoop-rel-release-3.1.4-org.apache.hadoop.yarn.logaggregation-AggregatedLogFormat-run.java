@Override public FSDataOutputStream run() throws Exception {
  fc=FileContext.getFileContext(remoteAppLogFile.toUri(),conf);
  fc.setUMask(APP_LOG_FILE_UMASK);
  return fc.create(remoteAppLogFile,EnumSet.of(CreateFlag.CREATE,CreateFlag.OVERWRITE),new Options.CreateOpts[]{});
}
