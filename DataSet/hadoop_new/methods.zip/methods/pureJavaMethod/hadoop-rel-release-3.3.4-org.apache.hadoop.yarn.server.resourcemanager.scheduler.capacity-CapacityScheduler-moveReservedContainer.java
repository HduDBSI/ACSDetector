/** 
 * Try to move a reserved container to a targetNode. If the targetNode is reserved by another application (other than this one). The previous reservation will be cancelled.
 * @param toBeMovedContainer reserved container will be moved
 * @param targetNode targetNode
 * @return true if move succeeded. Return false if the targetNode is reserved bya different container or move failed because of any other reasons.
 */
public boolean moveReservedContainer(RMContainer toBeMovedContainer,FiCaSchedulerNode targetNode){
  writeLock.lock();
  try {
    LOG.debug("Trying to move container={} to node={}",toBeMovedContainer,targetNode.getNodeID());
    FiCaSchedulerNode sourceNode=getNode(toBeMovedContainer.getNodeId());
    if (null == sourceNode) {
      LOG.debug("Failed to move reservation, cannot find source node={}",toBeMovedContainer.getNodeId());
      return false;
    }
    if (getNode(targetNode.getNodeID()) != targetNode) {
      LOG.debug("Failed to move reservation, node updated or removed," + " moving cancelled.");
      return false;
    }
    if (targetNode.getReservedContainer() != null) {
      LOG.debug("Target node's reservation status changed," + " moving cancelled.");
      return false;
    }
    FiCaSchedulerApp app=getApplicationAttempt(toBeMovedContainer.getApplicationAttemptId());
    if (null == app) {
      LOG.debug("Cannot find to-be-moved container's application={}",toBeMovedContainer.getApplicationAttemptId());
      return false;
    }
    return app.moveReservation(toBeMovedContainer,sourceNode,targetNode);
  }
  finally {
    writeLock.unlock();
  }
}
