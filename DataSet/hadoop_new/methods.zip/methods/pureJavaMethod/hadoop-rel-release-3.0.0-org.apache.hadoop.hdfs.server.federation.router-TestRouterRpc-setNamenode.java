protected void setNamenode(NamenodeContext nn) throws IOException, URISyntaxException {
  this.namenode=nn;
  this.nnProtocol=nn.getClient().getNamenode();
  this.nnFS=nn.getFileSystem();
}
