/** 
 * Tell all datanodes to use a new, non-persistent bandwidth value for dfs.datanode.balance.bandwidthPerSec.
 * @param bandwidth Balancer bandwidth in bytes per second for all datanodes.
 * @throws IOException
 */
@Override public void setBalancerBandwidth(long bandwidth) throws IOException {
  checkNNStartup();
  namesystem.setBalancerBandwidth(bandwidth);
}
