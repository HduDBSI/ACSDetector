private synchronized void reserveQueueSpace(int size) throws LoggerTooFarBehindException {
  Preconditions.checkArgument(size >= 0);
  if (queuedEditsSizeBytes + size > queueSizeLimitBytes && queuedEditsSizeBytes > 0) {
    throw new LoggerTooFarBehindException();
  }
  queuedEditsSizeBytes+=size;
}
