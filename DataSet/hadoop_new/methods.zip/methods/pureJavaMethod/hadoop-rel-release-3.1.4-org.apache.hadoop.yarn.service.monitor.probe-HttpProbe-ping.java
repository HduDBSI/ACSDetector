@Override public ProbeStatus ping(ComponentInstance instance){
  ProbeStatus status=super.ping(instance);
  if (!status.isSuccess()) {
    return status;
  }
  String ip=instance.getContainerStatus().getIPs().get(0);
  HttpURLConnection connection=null;
  try {
    URL url=new URL(urlString.replace(HOST_TOKEN,ip));
    connection=getConnection(url,this.timeout);
    int rc=connection.getResponseCode();
    if (rc < min || rc > max) {
      String error="Probe " + url + " error code: "+ rc;
      log.info(error);
      status.fail(this,new IOException(error));
    }
 else {
      status.succeed(this);
    }
  }
 catch (  Throwable e) {
    String error="Probe " + urlString + " failed for IP "+ ip+ ": "+ e;
    log.info(error,e);
    status.fail(this,new IOException(error,e));
  }
 finally {
    if (connection != null) {
      connection.disconnect();
    }
  }
  return status;
}
