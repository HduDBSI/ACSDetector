void notifyNamenodeReceivedBlock(ExtendedBlock block,String delHint,String storageUuid,boolean isOnTransientStorage){
  notifyNamenodeBlock(block,BlockStatus.RECEIVED_BLOCK,delHint,storageUuid,isOnTransientStorage);
}
