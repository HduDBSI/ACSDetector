private static boolean canSatisfySingleConstraint(ApplicationId applicationId,SingleConstraint singleConstraint,SchedulerNode schedulerNode,AllocationTagsManager tagsManager) throws InvalidAllocationTagsQueryException {
  Iterator<TargetExpression> expIt=singleConstraint.getTargetExpressions().iterator();
  while (expIt.hasNext()) {
    TargetExpression currentExp=expIt.next();
    if (currentExp.getTargetType().equals(TargetType.ALLOCATION_TAG)) {
      if (!canSatisfySingleConstraintExpression(applicationId,singleConstraint,currentExp,schedulerNode,tagsManager)) {
        return false;
      }
    }
 else     if (currentExp.getTargetType().equals(TargetType.NODE_ATTRIBUTE)) {
      if (!canSatisfyNodeConstraintExpression(singleConstraint,currentExp,schedulerNode)) {
        return false;
      }
    }
  }
  return true;
}
