private void testClose(FsDatasetSpi<?> dataSet,ExtendedBlock[] blocks) throws IOException {
  long newGS=blocks[FINALIZED].getGenerationStamp() + 1;
  dataSet.recoverClose(blocks[FINALIZED],newGS,blocks[FINALIZED].getNumBytes());
  blocks[FINALIZED].setGenerationStamp(newGS);
  try {
    dataSet.recoverClose(blocks[TEMPORARY],blocks[TEMPORARY].getGenerationStamp() + 1,blocks[TEMPORARY].getNumBytes());
    Assert.fail("Should not have recovered close a temporary replica " + blocks[TEMPORARY]);
  }
 catch (  ReplicaNotFoundException e) {
    Assert.assertTrue(e.getMessage().startsWith(ReplicaNotFoundException.UNFINALIZED_AND_NONRBW_REPLICA));
  }
  newGS=blocks[RBW].getGenerationStamp() + 1;
  dataSet.recoverClose(blocks[RBW],newGS,blocks[RBW].getNumBytes());
  blocks[RBW].setGenerationStamp(newGS);
  try {
    dataSet.recoverClose(blocks[RWR],blocks[RWR].getGenerationStamp() + 1,blocks[RBW].getNumBytes());
    Assert.fail("Should not have recovered close an RWR replica" + blocks[RWR]);
  }
 catch (  ReplicaNotFoundException e) {
    Assert.assertTrue(e.getMessage().startsWith(ReplicaNotFoundException.UNFINALIZED_AND_NONRBW_REPLICA));
  }
  try {
    dataSet.recoverClose(blocks[RUR],blocks[RUR].getGenerationStamp() + 1,blocks[RUR].getNumBytes());
    Assert.fail("Should not have recovered close an RUR replica" + blocks[RUR]);
  }
 catch (  ReplicaNotFoundException e) {
    Assert.assertTrue(e.getMessage().startsWith(ReplicaNotFoundException.UNFINALIZED_AND_NONRBW_REPLICA));
  }
  try {
    dataSet.recoverClose(blocks[NON_EXISTENT],blocks[NON_EXISTENT].getGenerationStamp(),blocks[NON_EXISTENT].getNumBytes());
    Assert.fail("Should not have recovered close a non-existent replica " + blocks[NON_EXISTENT]);
  }
 catch (  ReplicaNotFoundException e) {
    Assert.assertTrue(e.getMessage().startsWith(ReplicaNotFoundException.NON_EXISTENT_REPLICA));
  }
}
