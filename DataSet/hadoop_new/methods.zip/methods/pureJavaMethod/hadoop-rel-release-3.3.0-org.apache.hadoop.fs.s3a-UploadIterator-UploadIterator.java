@Retries.RetryTranslated public UploadIterator(AmazonS3 s3,Invoker invoker,String bucketName,int maxKeys,@Nullable String prefix) throws IOException {
  lister=new ListingIterator(s3,invoker,bucketName,maxKeys,prefix);
  requestNextBatch();
}
