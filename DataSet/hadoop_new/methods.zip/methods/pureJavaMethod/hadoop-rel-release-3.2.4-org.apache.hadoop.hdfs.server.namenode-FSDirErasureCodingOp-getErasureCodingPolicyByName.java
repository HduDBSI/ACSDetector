/** 
 * Check if the ecPolicyName is valid, return the corresponding EC policy if is, including the REPLICATION EC policy.
 * @param fsn namespace
 * @param ecPolicyName name of EC policy to be checked
 * @return an erasure coding policy if ecPolicyName is valid
 * @throws IOException
 */
static ErasureCodingPolicy getErasureCodingPolicyByName(final FSNamesystem fsn,final String ecPolicyName) throws IOException {
  assert fsn.hasReadLock();
  ErasureCodingPolicy ecPolicy=fsn.getErasureCodingPolicyManager().getErasureCodingPolicyByName(ecPolicyName);
  if (ecPolicy == null) {
    throw new HadoopIllegalArgumentException("The given erasure coding " + "policy " + ecPolicyName + " does not exist.");
  }
  return ecPolicy;
}
