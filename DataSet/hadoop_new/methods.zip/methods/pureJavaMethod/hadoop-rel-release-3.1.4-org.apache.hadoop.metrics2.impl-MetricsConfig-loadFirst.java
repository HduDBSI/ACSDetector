/** 
 * Load configuration from a list of files until the first successful load
 * @param conf  the configuration object
 * @param files the list of filenames to try
 * @return  the configuration object
 */
static MetricsConfig loadFirst(String prefix,String... fileNames){
  for (  String fname : fileNames) {
    try {
      PropertiesConfiguration pcf=new PropertiesConfiguration();
      FileHandler fh=new FileHandler(pcf);
      fh.setFileName(fname);
      fh.load();
      Configuration cf=pcf.interpolatedConfiguration();
      LOG.info("loaded properties from " + fname);
      LOG.debug(toString(cf));
      MetricsConfig mc=new MetricsConfig(cf,prefix);
      LOG.debug(mc.toString());
      return mc;
    }
 catch (    ConfigurationException e) {
      if (e.getMessage().startsWith("Could not locate")) {
        continue;
      }
      throw new MetricsConfigException(e);
    }
  }
  LOG.warn("Cannot locate configuration: tried " + Joiner.on(",").join(fileNames));
  return new MetricsConfig(new PropertiesConfiguration(),prefix);
}
