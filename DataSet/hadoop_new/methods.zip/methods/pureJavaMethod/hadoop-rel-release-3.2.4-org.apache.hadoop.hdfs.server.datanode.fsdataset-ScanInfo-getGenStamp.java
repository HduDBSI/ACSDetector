public long getGenStamp(){
  return metaFile != null ? Block.getGenerationStamp(fullMetaFile()) : HdfsConstants.GRANDFATHER_GENERATION_STAMP;
}
