@Override public void abandonBlock(ExtendedBlock b,long fileId,String src,String holder) throws IOException {
  checkOperation(OperationCategory.WRITE);
  RemoteMethod method=new RemoteMethod("abandonBlock",new Class<?>[]{ExtendedBlock.class,long.class,String.class,String.class},b,fileId,new RemoteParam(),holder);
  rpcClient.invokeSingle(b,method);
}
