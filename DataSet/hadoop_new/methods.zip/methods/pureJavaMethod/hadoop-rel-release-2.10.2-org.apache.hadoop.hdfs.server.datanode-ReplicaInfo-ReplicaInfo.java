/** 
 * Copy constructor.
 * @param from where to copy from
 */
ReplicaInfo(ReplicaInfo from){
  this(from,from.getVolume(),from.getDir());
}
