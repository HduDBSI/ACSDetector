/** 
 * Start a list of containers on this NodeManager.
 */
@Override public StartContainersResponse startContainers(StartContainersRequest requests) throws YarnException, IOException {
  UserGroupInformation remoteUgi=getRemoteUgi();
  NMTokenIdentifier nmTokenIdentifier=selectNMTokenIdentifier(remoteUgi);
  authorizeUser(remoteUgi,nmTokenIdentifier);
  List<ContainerId> succeededContainers=new ArrayList<ContainerId>();
  Map<ContainerId,SerializedException> failedContainers=new HashMap<ContainerId,SerializedException>();
synchronized (this.context) {
    for (    StartContainerRequest request : requests.getStartContainerRequests()) {
      ContainerId containerId=null;
      try {
        if (request.getContainerToken() == null || request.getContainerToken().getIdentifier() == null) {
          throw new IOException(INVALID_CONTAINERTOKEN_MSG);
        }
        ContainerTokenIdentifier containerTokenIdentifier=BuilderUtils.newContainerTokenIdentifier(request.getContainerToken());
        verifyAndGetContainerTokenIdentifier(request.getContainerToken(),containerTokenIdentifier);
        containerId=containerTokenIdentifier.getContainerID();
        if (amrmProxyEnabled && containerTokenIdentifier.getContainerType().equals(ContainerType.APPLICATION_MASTER)) {
          this.getAMRMProxyService().processApplicationStartRequest(request);
        }
        performContainerPreStartChecks(nmTokenIdentifier,request,containerTokenIdentifier);
        startContainerInternal(containerTokenIdentifier,request);
        succeededContainers.add(containerId);
      }
 catch (      YarnException e) {
        failedContainers.put(containerId,SerializedException.newInstance(e));
      }
catch (      InvalidToken ie) {
        failedContainers.put(containerId,SerializedException.newInstance(ie));
        throw ie;
      }
catch (      IOException e) {
        throw RPCUtil.getRemoteException(e);
      }
    }
    return StartContainersResponse.newInstance(getAuxServiceMetaData(),succeededContainers,failedContainers);
  }
}
