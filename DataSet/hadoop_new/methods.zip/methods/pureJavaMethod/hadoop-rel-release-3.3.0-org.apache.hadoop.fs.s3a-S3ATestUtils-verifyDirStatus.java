/** 
 * Verify the status entry of a directory matches that expected.
 * @param status status entry to check
 * @param replication replication factor
 * @param owner owner
 */
public static void verifyDirStatus(S3AFileStatus status,int replication,String owner){
  String details=status.toString();
  assertTrue("Is a dir: " + details,status.isDirectory());
  assertEquals("zero length: " + details,0,status.getLen());
  assertTrue("Mod time: " + details,status.getModificationTime() > 0);
  assertEquals("Replication value: " + details,replication,status.getReplication());
  assertEquals("Access time: " + details,0,status.getAccessTime());
  assertEquals("Owner: " + details,owner,status.getOwner());
  assertEquals("Group: " + details,owner,status.getGroup());
  assertEquals("Permission: " + details,FsPermission.getDefault(),status.getPermission());
}
