/** 
 * Get  {@link LogAggregationFileController} to read the aggregated logsfor this application.
 * @param appId the ApplicationId
 * @param appOwner the Application Owner
 * @return the LogAggregationFileController instance
 * @throws IOException if can not find any log aggregation file controller
 */
public LogAggregationFileController getFileControllerForRead(ApplicationId appId,String appOwner) throws IOException {
  StringBuilder diagnosticsMsg=new StringBuilder();
  if (LogAggregationUtils.isOlderPathEnabled(conf)) {
    for (    LogAggregationFileController fileController : controllers) {
      try {
        Path remoteAppLogDir=fileController.getOlderRemoteAppLogDir(appId,appOwner);
        if (LogAggregationUtils.getNodeFiles(conf,remoteAppLogDir,appId,appOwner).hasNext()) {
          return fileController;
        }
      }
 catch (      Exception ex) {
        diagnosticsMsg.append(ex.getMessage() + "\n");
        continue;
      }
    }
  }
  for (  LogAggregationFileController fileController : controllers) {
    try {
      Path remoteAppLogDir=fileController.getRemoteAppLogDir(appId,appOwner);
      if (LogAggregationUtils.getNodeFiles(conf,remoteAppLogDir,appId,appOwner).hasNext()) {
        return fileController;
      }
    }
 catch (    Exception ex) {
      diagnosticsMsg.append(ex.getMessage() + "\n");
      continue;
    }
  }
  throw new IOException(diagnosticsMsg.toString());
}
