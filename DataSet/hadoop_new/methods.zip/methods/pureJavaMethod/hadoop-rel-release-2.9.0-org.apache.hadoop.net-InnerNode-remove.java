/** 
 * Remove node <i>n</i> from the subtree of this node
 * @param n node to be deleted
 * @return true if the node is deleted; false otherwise
 */
boolean remove(Node n);
