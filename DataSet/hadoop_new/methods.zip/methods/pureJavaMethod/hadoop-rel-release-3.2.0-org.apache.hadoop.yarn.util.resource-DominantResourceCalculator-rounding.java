private Resource rounding(Resource r,Resource stepFactor,boolean roundUp){
  Resource ret=Resource.newInstance(r);
  int maxLength=ResourceUtils.getNumberOfKnownResourceTypes();
  for (int i=0; i < maxLength; i++) {
    ResourceInformation rResourceInformation=r.getResourceInformation(i);
    ResourceInformation stepFactorResourceInformation=stepFactor.getResourceInformation(i);
    long rValue=rResourceInformation.getValue();
    long stepFactorValue=stepFactorResourceInformation.getValue();
    long value=rValue;
    if (stepFactorValue != 0) {
      value=roundUp ? roundUp(rValue,stepFactorValue) : roundDown(rValue,stepFactorValue);
    }
    ResourceInformation.copy(rResourceInformation,ret.getResourceInformation(i));
    ret.getResourceInformation(i).setValue(value);
  }
  return ret;
}
