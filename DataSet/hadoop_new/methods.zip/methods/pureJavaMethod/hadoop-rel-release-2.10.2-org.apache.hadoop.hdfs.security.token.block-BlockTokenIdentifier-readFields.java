@Override public void readFields(DataInput in) throws IOException {
  this.cache=null;
  if (in instanceof DataInputStream) {
    final DataInputStream dis=(DataInputStream)in;
    this.cache=IOUtils.readFullyToByteArray(dis);
    dis.reset();
  }
  expiryDate=WritableUtils.readVLong(in);
  keyId=WritableUtils.readVInt(in);
  userId=WritableUtils.readString(in);
  blockPoolId=WritableUtils.readString(in);
  blockId=WritableUtils.readVLong(in);
  int length=WritableUtils.readVIntInRange(in,0,AccessMode.class.getEnumConstants().length);
  for (int i=0; i < length; i++) {
    modes.add(WritableUtils.readEnum(in,AccessMode.class));
  }
  try {
    int handshakeMsgLen=WritableUtils.readVInt(in);
    if (handshakeMsgLen != 0) {
      handshakeMsg=new byte[handshakeMsgLen];
      in.readFully(handshakeMsg);
    }
  }
 catch (  EOFException eof) {
  }
}
