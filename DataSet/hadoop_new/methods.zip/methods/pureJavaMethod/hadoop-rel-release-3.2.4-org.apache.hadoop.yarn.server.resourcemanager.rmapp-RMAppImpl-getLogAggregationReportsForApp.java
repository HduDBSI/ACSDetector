@Override public Map<NodeId,LogAggregationReport> getLogAggregationReportsForApp(){
  return logAggregation.getLogAggregationReportsForApp(this);
}
