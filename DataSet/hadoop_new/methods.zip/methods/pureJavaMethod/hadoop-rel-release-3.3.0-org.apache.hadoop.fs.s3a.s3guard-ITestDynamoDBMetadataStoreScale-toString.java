@Override public String toString(){
  final StringBuilder sb=new StringBuilder("ExecutionOutcome{");
  sb.append("completed=").append(completed);
  sb.append(", skipped=").append(skipped);
  sb.append(", throttled=").append(throttled);
  sb.append(", exception count=").append(exceptions.size());
  sb.append('}');
  return sb.toString();
}
