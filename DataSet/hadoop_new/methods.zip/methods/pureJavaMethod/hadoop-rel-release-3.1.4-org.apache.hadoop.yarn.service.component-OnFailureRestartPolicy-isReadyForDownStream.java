@Override public boolean isReadyForDownStream(Component dependentComponent){
  if (dependentComponent.getNumReadyInstances() + dependentComponent.getNumSucceededInstances() + dependentComponent.getNumFailedInstances() < dependentComponent.getNumDesiredInstances()) {
    return false;
  }
  return true;
}
