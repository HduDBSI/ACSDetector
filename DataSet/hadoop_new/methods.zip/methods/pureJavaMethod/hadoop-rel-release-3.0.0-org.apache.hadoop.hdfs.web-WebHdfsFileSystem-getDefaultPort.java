@Override protected int getDefaultPort(){
  return HdfsClientConfigKeys.DFS_NAMENODE_HTTP_PORT_DEFAULT;
}
