PendingBlockInfo(DatanodeDescriptor[] targets){
  this.timeStamp=monotonicNow();
  this.targets=targets == null ? new ArrayList<DatanodeDescriptor>() : new ArrayList<>(Arrays.asList(targets));
}
