@Override public void updateNodeToLabelsMappings(Map<NodeId,Set<String>> nodeToLabels) throws IOException {
  NodeToLabelOp op=new NodeToLabelOp();
  writeToLog(op.setNodeToLabels(nodeToLabels));
}
