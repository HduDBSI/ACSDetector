LocalizerRunner(LocalizerContext context,String localizerId){
  super("LocalizerRunner for " + localizerId);
  this.context=context;
  this.localizerId=localizerId;
  this.pending=Collections.synchronizedList(new ArrayList<LocalizerResourceRequestEvent>());
  this.scheduled=new HashMap<>();
  tokenFileName=String.format(ContainerExecutor.TOKEN_FILE_NAME_FMT,localizerId + Long.toHexString(System.currentTimeMillis()));
}
