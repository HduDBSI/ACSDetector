public BZip2CompressionInputStream(InputStream in,long start,long end,READ_MODE readMode) throws IOException {
  super(in,start,end);
  needsReset=false;
  bufferedIn=new BufferedInputStream(super.in);
  this.startingPos=super.getPos();
  this.readMode=readMode;
  if (this.startingPos == 0) {
    bufferedIn=readStreamHeader();
  }
  input=new CBZip2InputStream(bufferedIn,readMode);
  if (this.isHeaderStripped) {
    input.updateReportedByteCount(HEADER_LEN);
  }
  if (this.isSubHeaderStripped) {
    input.updateReportedByteCount(SUB_HEADER_LEN);
  }
  this.updatePos(false);
}
