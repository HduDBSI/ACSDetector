void getVolumeMap(ReplicaMap volumeMap,final RamDiskReplicaTracker lazyWriteReplicaMap) throws IOException {
  if (lazypersistDir.exists()) {
    int numRecovered=moveLazyPersistReplicasToFinalized(lazypersistDir);
    FsDatasetImpl.LOG.info("Recovered " + numRecovered + " replicas from "+ lazypersistDir);
  }
  boolean success=readReplicasFromCache(volumeMap,lazyWriteReplicaMap);
  if (!success) {
    addToReplicasMap(volumeMap,finalizedDir,lazyWriteReplicaMap,true);
    addToReplicasMap(volumeMap,rbwDir,lazyWriteReplicaMap,false);
  }
}
