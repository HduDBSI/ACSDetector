@Override public AbstractConstraint parse() throws PlacementConstraintParseException {
  PlacementConstraint.AbstractConstraint placementConstraints=null;
  String op=nextToken();
  if (op.equalsIgnoreCase(IN) || op.equalsIgnoreCase(NOT_IN)) {
    String scope=nextToken();
    scope=parseScope(scope);
    Set<TargetExpression> targetExpressions=new HashSet<>();
    while (hasMoreTokens()) {
      String tag=nextToken();
      TargetExpression t=parseNameSpace(tag);
      targetExpressions.add(t);
    }
    TargetExpression[] targetArr=targetExpressions.toArray(new TargetExpression[targetExpressions.size()]);
    if (op.equalsIgnoreCase(IN)) {
      placementConstraints=PlacementConstraints.targetIn(scope,targetArr);
    }
 else {
      placementConstraints=PlacementConstraints.targetNotIn(scope,targetArr);
    }
  }
 else {
    throw new PlacementConstraintParseException("expecting " + IN + " or "+ NOT_IN+ ", but get "+ op);
  }
  return placementConstraints;
}
