@VisibleForTesting static Map<CGroupController,String> initializeControllerPathsFromMtab(Map<String,Set<String>> parsedMtab) throws ResourceHandlerException {
  Map<CGroupController,String> ret=new HashMap<>();
  for (  CGroupController controller : CGroupController.values()) {
    String subsystemName=controller.getName();
    String controllerPath=findControllerInMtab(subsystemName,parsedMtab);
    if (controllerPath != null) {
      ret.put(controller,controllerPath);
    }
  }
  return ret;
}
