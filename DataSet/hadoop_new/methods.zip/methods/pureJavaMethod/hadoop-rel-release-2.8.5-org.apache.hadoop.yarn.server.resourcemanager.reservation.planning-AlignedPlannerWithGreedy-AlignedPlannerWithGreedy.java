public AlignedPlannerWithGreedy(int smoothnessFactor){
  List<ReservationAgent> listAlg=new LinkedList<ReservationAgent>();
  ReservationAgent algAligned=new IterativePlanner(new StageEarliestStartByDemand(),new StageAllocatorLowCostAligned(smoothnessFactor),false);
  listAlg.add(algAligned);
  ReservationAgent algGreedy=new IterativePlanner(new StageEarliestStartByJobArrival(),new StageAllocatorGreedy(),false);
  listAlg.add(algGreedy);
  planner=new TryManyReservationAgents(listAlg);
}
