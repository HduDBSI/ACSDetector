@Override public void setConf(Configuration conf){
  this.conf=conf;
  if (conf != null) {
    whitelistVars.clear();
    whitelistVars.addAll(Arrays.asList(conf.get(YarnConfiguration.NM_ENV_WHITELIST,YarnConfiguration.DEFAULT_NM_ENV_WHITELIST).split(",")));
    String confDir=ApplicationConstants.Environment.HADOOP_CONF_DIR.key();
    if (!whitelistVars.contains(confDir)) {
      whitelistVars.add(confDir);
    }
  }
}
