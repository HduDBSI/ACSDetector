@Override public Iterator<InetSocketAddress> iterator(){
  return new HostIterator(allDNs.entries());
}
