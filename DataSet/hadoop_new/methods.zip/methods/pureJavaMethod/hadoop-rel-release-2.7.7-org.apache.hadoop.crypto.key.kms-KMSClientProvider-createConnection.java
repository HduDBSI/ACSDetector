private HttpURLConnection createConnection(final URL url,String method) throws IOException {
  HttpURLConnection conn;
  try {
    UserGroupInformation currentUgi=UserGroupInformation.getCurrentUser();
    final String doAsUser=(currentUgi.getAuthenticationMethod() == UserGroupInformation.AuthenticationMethod.PROXY) ? currentUgi.getShortUserName() : null;
    conn=actualUgi.doAs(new PrivilegedExceptionAction<HttpURLConnection>(){
      @Override public HttpURLConnection run() throws Exception {
        DelegationTokenAuthenticatedURL authUrl=new DelegationTokenAuthenticatedURL(configurator);
        return authUrl.openConnection(url,authToken,doAsUser);
      }
    }
);
  }
 catch (  IOException ex) {
    throw ex;
  }
catch (  UndeclaredThrowableException ex) {
    throw new IOException(ex.getUndeclaredThrowable());
  }
catch (  Exception ex) {
    throw new IOException(ex);
  }
  conn.setUseCaches(false);
  conn.setRequestMethod(method);
  if (method.equals(HTTP_POST) || method.equals(HTTP_PUT)) {
    conn.setDoOutput(true);
  }
  conn=configureConnection(conn);
  return conn;
}
