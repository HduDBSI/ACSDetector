public DFSck(Configuration conf,PrintStream out) throws IOException {
  super(conf);
  this.ugi=UserGroupInformation.getCurrentUser();
  this.out=out;
  this.connectionFactory=URLConnectionFactory.newDefaultURLConnectionFactory(conf);
  this.isSpnegoEnabled=UserGroupInformation.isSecurityEnabled();
}
