/** 
 * Delete a path from the name space Update the count at each ancestor directory with quota
 * @param fsd the FSDirectory instance
 * @param iip the inodes resolved from the path
 * @param reclaimContext used to collect blocks and inodes to be removed
 * @param mtime the time the inode is removed
 * @return true if there are inodes deleted
 */
private static boolean unprotectedDelete(FSDirectory fsd,INodesInPath iip,ReclaimContext reclaimContext,long mtime){
  assert fsd.hasWriteLock();
  INode targetNode=iip.getLastINode();
  if (targetNode == null) {
    return false;
  }
  final int latestSnapshot=iip.getLatestSnapshotId();
  targetNode.recordModification(latestSnapshot);
  long removed=fsd.removeLastINode(iip);
  if (removed == -1) {
    return false;
  }
  final INodeDirectory parent=targetNode.getParent();
  parent.updateModificationTime(mtime,latestSnapshot);
  if (!targetNode.isInLatestSnapshot(latestSnapshot)) {
    targetNode.destroyAndCollectBlocks(reclaimContext);
  }
 else {
    targetNode.cleanSubtree(reclaimContext,CURRENT_STATE_ID,latestSnapshot);
  }
  if (NameNode.stateChangeLog.isDebugEnabled()) {
    NameNode.stateChangeLog.debug("DIR* FSDirectory.unprotectedDelete: " + iip.getPath() + " is removed");
  }
  return true;
}
