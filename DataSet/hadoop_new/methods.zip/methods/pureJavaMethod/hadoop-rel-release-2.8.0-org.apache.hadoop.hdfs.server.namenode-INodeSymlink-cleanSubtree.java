@Override public void cleanSubtree(ReclaimContext reclaimContext,final int snapshotId,int priorSnapshotId){
  if (snapshotId == Snapshot.CURRENT_STATE_ID && priorSnapshotId == Snapshot.NO_SNAPSHOT_ID) {
    destroyAndCollectBlocks(reclaimContext);
  }
}
