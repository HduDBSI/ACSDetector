public synchronized void refreshCallQueue(Configuration conf){
  String prefix=getQueueClassPrefix();
  callQueue.swapQueue(getSchedulerClass(prefix,conf),getQueueClass(prefix,conf),maxQueueSize,prefix,conf);
}
