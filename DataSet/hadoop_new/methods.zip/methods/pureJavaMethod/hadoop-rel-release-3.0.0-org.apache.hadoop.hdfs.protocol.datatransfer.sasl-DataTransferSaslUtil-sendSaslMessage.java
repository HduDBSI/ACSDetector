/** 
 * Sends a SASL negotiation message.
 * @param out stream to receive message
 * @param status negotiation status
 * @param payload to send
 * @param message to send
 * @throws IOException for any error
 */
public static void sendSaslMessage(OutputStream out,DataTransferEncryptorStatus status,byte[] payload,String message) throws IOException {
  DataTransferEncryptorMessageProto.Builder builder=DataTransferEncryptorMessageProto.newBuilder();
  builder.setStatus(status);
  if (payload != null) {
    builder.setPayload(ByteString.copyFrom(payload));
  }
  if (message != null) {
    builder.setMessage(message);
  }
  DataTransferEncryptorMessageProto proto=builder.build();
  proto.writeDelimitedTo(out);
  out.flush();
}
