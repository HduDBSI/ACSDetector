@Override public boolean truncate(String src,long newLength,String clientName) throws IOException {
  checkOperation(OperationCategory.WRITE);
  final List<RemoteLocation> locations=getLocationsForPath(src,true);
  RemoteMethod method=new RemoteMethod("truncate",new Class<?>[]{String.class,long.class,String.class},new RemoteParam(),newLength,clientName);
  return ((Boolean)rpcClient.invokeSequential(locations,method,Boolean.class,Boolean.TRUE)).booleanValue();
}
