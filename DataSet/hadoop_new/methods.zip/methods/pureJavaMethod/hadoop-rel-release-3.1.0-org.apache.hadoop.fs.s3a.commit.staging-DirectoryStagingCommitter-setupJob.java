@Override public void setupJob(JobContext context) throws IOException {
  super.setupJob(context);
  Path outputPath=getOutputPath();
  FileSystem fs=getDestFS();
  if (getConflictResolutionMode(context,fs.getConf()) == ConflictResolution.FAIL && fs.exists(outputPath)) {
    LOG.debug("Failing commit by task attempt {} to write" + " to existing output path {}",context.getJobID(),getOutputPath());
    throw new PathExistsException(outputPath.toString(),E_DEST_EXISTS);
  }
}
