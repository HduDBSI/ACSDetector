/** 
 * Get the status of the docker container. This runs a docker inspect to get the status. If the container no longer exists, docker inspect throws an exception and the nonexistent status is returned.
 * @param containerId                 the id of the container.
 * @param privilegedOperationExecutor the privileged operations executor.
 * @return a {@link DockerContainerStatus} representing the current status.
 */
public static DockerContainerStatus getContainerStatus(String containerId,PrivilegedOperationExecutor privilegedOperationExecutor,Context nmContext){
  try {
    String currentContainerStatus=executeStatusCommand(containerId,privilegedOperationExecutor,nmContext);
    DockerContainerStatus dockerContainerStatus=parseContainerStatus(currentContainerStatus);
    if (LOG.isDebugEnabled()) {
      LOG.debug("Container Status: " + dockerContainerStatus.getName() + " ContainerId: "+ containerId);
    }
    return dockerContainerStatus;
  }
 catch (  ContainerExecutionException e) {
    if (LOG.isDebugEnabled()) {
      LOG.debug("Container Status: " + DockerContainerStatus.NONEXISTENT.getName() + " ContainerId: "+ containerId);
    }
    return DockerContainerStatus.NONEXISTENT;
  }
}
