/** 
 * Add replicas under the given directory to the volume map
 * @param volumeMap the replicas map
 * @param dir an input directory
 * @param lazyWriteReplicaMap Map of replicas on transientstorage.
 * @param isFinalized true if the directory has finalized replicas;false if the directory has rbw replicas
 */
void addToReplicasMap(ReplicaMap volumeMap,File dir,final RamDiskReplicaTracker lazyWriteReplicaMap,boolean isFinalized) throws IOException {
  File files[]=FileUtil.listFiles(dir);
  for (  File file : files) {
    if (file.isDirectory()) {
      addToReplicasMap(volumeMap,file,lazyWriteReplicaMap,isFinalized);
    }
    if (isFinalized && FsDatasetUtil.isUnlinkTmpFile(file)) {
      file=recoverTempUnlinkedBlock(file);
      if (file == null) {
        continue;
      }
    }
    if (!Block.isBlockFilename(file))     continue;
    long genStamp=FsDatasetUtil.getGenerationStampFromFile(files,file);
    long blockId=Block.filename2id(file.getName());
    Block block=new Block(blockId,file.length(),genStamp);
    addReplicaToReplicasMap(block,volumeMap,lazyWriteReplicaMap,isFinalized);
  }
}
