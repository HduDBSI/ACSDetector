/** 
 * Return the timeout that clients should use when writing to datanodes.
 * @param numNodes the number of nodes in the pipeline.
 */
int getDatanodeWriteTimeout(int numNodes){
  final int t=dfsClientConf.getDatanodeSocketWriteTimeout();
  return t > 0 ? t + HdfsConstants.WRITE_TIMEOUT_EXTENSION * numNodes : 0;
}
