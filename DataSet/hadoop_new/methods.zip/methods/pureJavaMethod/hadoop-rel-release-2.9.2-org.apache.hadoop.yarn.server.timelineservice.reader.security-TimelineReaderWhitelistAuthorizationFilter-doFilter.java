@Override public void doFilter(ServletRequest request,ServletResponse response,FilterChain chain) throws IOException, ServletException {
  if (isWhitelistReadAuthEnabled) {
    UserGroupInformation callerUGI=TimelineReaderWebServicesUtils.getCallerUserGroupInformation((HttpServletRequest)request,true);
    if (callerUGI == null) {
      String msg="Unable to obtain user name, user not authenticated";
      throw new AuthorizationException(msg);
    }
    if (!(adminAclList.isUserAllowed(callerUGI) || allowedUsersAclList.isUserAllowed(callerUGI))) {
      String userName=callerUGI.getShortUserName();
      String msg="User " + userName + " is not allowed to read TimelineService V2 data.";
      Response.status(Status.FORBIDDEN).entity(msg).build();
      throw new ForbiddenException("user " + userName + " is not allowed to read TimelineService V2 data");
    }
  }
  if (chain != null) {
    chain.doFilter(request,response);
  }
}
