@Override public Resource multiplyAndNormalizeUp(Resource r,double by,Resource stepFactor){
  return this.multiplyAndNormalize(r,by,stepFactor,true);
}
