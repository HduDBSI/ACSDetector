/** 
 * Closes the socket ignoring  {@link IOException}
 * @param sock the Socket to close
 */
public static void closeSocket(Socket sock){
  if (sock != null) {
    try {
      sock.close();
    }
 catch (    IOException ignored) {
    }
  }
}
