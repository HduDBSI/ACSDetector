@Override public void run(){
  try {
    running=true;
    result=fs.rename(srcPath,dstPath);
  }
 catch (  Exception e) {
  }
}
