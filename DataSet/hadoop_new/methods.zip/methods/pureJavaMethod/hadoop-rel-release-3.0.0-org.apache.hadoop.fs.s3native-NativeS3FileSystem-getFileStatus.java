@Override public FileStatus getFileStatus(Path f) throws IOException {
  throw new UnsupportedOperationException(UNSUPPORTED);
}
