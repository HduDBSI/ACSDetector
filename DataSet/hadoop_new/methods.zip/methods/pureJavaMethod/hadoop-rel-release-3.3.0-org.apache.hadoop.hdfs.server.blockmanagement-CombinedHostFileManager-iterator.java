@Override public Iterator<InetSocketAddress> iterator(){
  return new HostIterator(Collections2.filter(allDNs.entries(),new Predicate<java.util.Map.Entry<InetAddress,DatanodeAdminProperties>>(){
    public boolean apply(    java.util.Map.Entry<InetAddress,DatanodeAdminProperties> entry){
      return entry.getValue().getAdminState().equals(AdminStates.DECOMMISSIONED);
    }
  }
));
}
