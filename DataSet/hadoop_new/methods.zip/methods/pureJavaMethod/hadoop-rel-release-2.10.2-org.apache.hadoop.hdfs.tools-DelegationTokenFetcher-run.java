@Override public Object run() throws Exception {
  if (print) {
    DelegationTokenIdentifier id=new DelegationTokenSecretManager(0,0,0,0,null).createIdentifier();
    for (    Token<?> token : readTokens(tokenFile,conf)) {
      DataInputStream in=new DataInputStream(new ByteArrayInputStream(token.getIdentifier()));
      id.readFields(in);
      System.out.println("Token (" + id + ") for "+ token.getService());
    }
    return null;
  }
  if (renew) {
    for (    Token<?> token : readTokens(tokenFile,conf)) {
      if (token.isManaged()) {
        long result=token.renew(conf);
        if (LOG.isDebugEnabled()) {
          LOG.debug("Renewed token for " + token.getService() + " until: "+ new Date(result));
        }
      }
    }
  }
 else   if (cancel) {
    for (    Token<?> token : readTokens(tokenFile,conf)) {
      if (token.isManaged()) {
        token.cancel(conf);
        if (LOG.isDebugEnabled()) {
          LOG.debug("Cancelled token for " + token.getService());
        }
      }
    }
  }
 else {
    if (webUrl != null) {
      Credentials creds=DelegationUtilsClient.getDTfromRemote(connectionFactory,new URI(webUrl),renewer,null);
      creds.writeTokenStorageFile(tokenFile,conf);
      for (      Token<?> token : creds.getAllTokens()) {
        System.out.println("Fetched token via " + webUrl + " for "+ token.getService()+ " into "+ tokenFile);
      }
    }
 else {
      FileSystem fs=FileSystem.get(conf);
      Credentials cred=new Credentials();
      Token<?> tokens[]=fs.addDelegationTokens(renewer,cred);
      cred.writeTokenStorageFile(tokenFile,conf);
      for (      Token<?> token : tokens) {
        System.out.println("Fetched token for " + token.getService() + " into "+ tokenFile);
      }
    }
  }
  return null;
}
