void appFinished(RMApp app,RMAppState state,long finishedTime);
