private void parseConfAndFindOtherNN() throws IOException {
  Configuration conf=getConf();
  nsId=DFSUtil.getNamenodeNameServiceId(conf);
  if (!HAUtil.isHAEnabled(conf,nsId)) {
    throw new HadoopIllegalArgumentException("HA is not enabled for this namenode.");
  }
  nnId=HAUtil.getNameNodeId(conf,nsId);
  NameNode.initializeGenericKeys(conf,nsId,nnId);
  if (!HAUtil.usesSharedEditsDir(conf)) {
    throw new HadoopIllegalArgumentException("Shared edits storage is not enabled for this namenode.");
  }
  remoteNNs=RemoteNameNodeInfo.getRemoteNameNodes(conf,nsId);
  List<RemoteNameNodeInfo> remove=new ArrayList<RemoteNameNodeInfo>(remoteNNs.size());
  for (  RemoteNameNodeInfo info : remoteNNs) {
    InetSocketAddress address=info.getIpcAddress();
    LOG.info("Found nn: " + info.getNameNodeID() + ", ipc: "+ info.getIpcAddress());
    if (address.getPort() == 0 || address.getAddress().isAnyLocalAddress()) {
      LOG.error("Could not determine valid IPC address for other NameNode (" + info.getNameNodeID() + ") , got: "+ address);
      remove.add(info);
    }
  }
  remoteNNs.removeAll(remove);
  Preconditions.checkArgument(!remoteNNs.isEmpty(),"Could not find any valid namenodes!");
  dirsToFormat=FSNamesystem.getNamespaceDirs(conf);
  editUrisToFormat=FSNamesystem.getNamespaceEditsDirs(conf,false);
  sharedEditsUris=FSNamesystem.getSharedEditsDirs(conf);
}
