@Override public void concat(String trg,String[] src) throws IOException {
  clientProto.concat(trg,src);
}
