private boolean deleteFiles(){
  return fileIoProvider.delete(volume,blockFile) && (fileIoProvider.delete(volume,metaFile) || !fileIoProvider.exists(volume,metaFile));
}
