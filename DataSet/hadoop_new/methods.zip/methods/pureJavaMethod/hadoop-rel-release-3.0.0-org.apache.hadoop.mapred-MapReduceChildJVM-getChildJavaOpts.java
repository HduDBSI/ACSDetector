private static String getChildJavaOpts(JobConf jobConf,boolean isMapTask){
  return jobConf.getTaskJavaOpts(isMapTask ? TaskType.MAP : TaskType.REDUCE);
}
