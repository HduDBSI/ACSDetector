@Test public void testLocatedStatusNoDir() throws Throwable {
  describe("test the LocatedStatus call on a path which is not present");
  try {
    RemoteIterator<LocatedFileStatus> iterator=getFileSystem().listLocatedStatus(path("missing"));
    fail("Expected an exception, got an iterator: " + iterator);
  }
 catch (  FileNotFoundException expected) {
  }
}
