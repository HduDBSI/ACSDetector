@Override public Boolean get(){
  String holder=NameNodeAdapter.getLeaseHolderForPath(cluster.getNameNode(),path);
  return holder.startsWith(HdfsServerConstants.NAMENODE_LEASE_HOLDER);
}
