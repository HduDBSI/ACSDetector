public void reserveResource(String user,Resource res){
  reservedContainers.incr();
  reservedMB.incr(res.getMemorySize());
  reservedVCores.incr(res.getVirtualCores());
  QueueMetrics userMetrics=getUserMetrics(user);
  if (userMetrics != null) {
    userMetrics.reserveResource(user,res);
  }
  if (parent != null) {
    parent.reserveResource(user,res);
  }
}
