@Override public CorruptFileBlocks listCorruptFileBlocks(String path,String cookie) throws IOException {
  return clientProto.listCorruptFileBlocks(path,cookie);
}
