@Deprecated @Override public boolean rename(final String src,final String dst) throws IOException {
  return clientProto.rename(src,dst);
}
