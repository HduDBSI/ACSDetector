/** 
 * Accepts an inet address and return true if address is in the list.
 * @param address
 * @return true if address is part of the list
 */
public boolean includes(InetAddress address){
  if (all) {
    return true;
  }
  if (address == null) {
    throw new IllegalArgumentException("address is null.");
  }
  if (inetAddresses != null && inetAddresses.contains(address)) {
    return true;
  }
  if (cidrAddresses != null) {
    String ipAddress=address.getHostAddress();
    for (    SubnetUtils.SubnetInfo cidrAddress : cidrAddresses) {
      if (cidrAddress.isInRange(ipAddress)) {
        return true;
      }
    }
  }
  return false;
}
