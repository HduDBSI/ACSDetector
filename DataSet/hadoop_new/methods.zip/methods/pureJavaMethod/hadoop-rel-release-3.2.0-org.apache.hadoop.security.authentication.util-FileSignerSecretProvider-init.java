@Override public void init(Properties config,ServletContext servletContext,long tokenValidity) throws Exception {
  String signatureSecretFile=config.getProperty(AuthenticationFilter.SIGNATURE_SECRET_FILE,null);
  Reader reader=null;
  if (signatureSecretFile != null) {
    try {
      StringBuilder sb=new StringBuilder();
      reader=new InputStreamReader(new FileInputStream(signatureSecretFile),Charsets.UTF_8);
      int c=reader.read();
      while (c > -1) {
        sb.append((char)c);
        c=reader.read();
      }
      secret=sb.toString().getBytes(Charset.forName("UTF-8"));
    }
 catch (    IOException ex) {
      throw new RuntimeException("Could not read signature secret file: " + signatureSecretFile);
    }
 finally {
      if (reader != null) {
        try {
          reader.close();
        }
 catch (        IOException e) {
        }
      }
    }
  }
  secrets=new byte[][]{secret};
}
