@Private @Unstable public class SubmitApplicationResponsePBImpl extends SubmitApplicationResponse {
  SubmitApplicationResponseProto proto=SubmitApplicationResponseProto.getDefaultInstance();
  SubmitApplicationResponseProto.Builder builder=null;
  boolean viaProto=false;
  public SubmitApplicationResponsePBImpl(){
    builder=SubmitApplicationResponseProto.newBuilder();
  }
  public SubmitApplicationResponsePBImpl(  SubmitApplicationResponseProto proto){
    this.proto=proto;
    viaProto=true;
  }
  public SubmitApplicationResponseProto getProto(){
    proto=viaProto ? proto : builder.build();
    viaProto=true;
    return proto;
  }
  @Override public int hashCode(){
    return getProto().hashCode();
  }
  @Override public boolean equals(  Object other){
    if (other == null)     return false;
    if (other.getClass().isAssignableFrom(this.getClass())) {
      return this.getProto().equals(this.getClass().cast(other).getProto());
    }
    return false;
  }
  @Override public String toString(){
    return TextFormat.shortDebugString(getProto());
  }
}
