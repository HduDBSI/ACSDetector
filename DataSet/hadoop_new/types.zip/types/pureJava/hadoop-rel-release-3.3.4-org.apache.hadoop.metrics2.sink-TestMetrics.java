/** 
 * Example metric pojo.
 */
@Metrics(about="Test Metrics",context="dfs") private static class TestMetrics {
  private String id;
  TestMetrics(){
    this("1");
  }
  TestMetrics(  String id){
    this.id=id;
  }
  @Metric(value={"testTag",""},type=Type.TAG) String testTag1(){
    return "testTagValue" + id;
  }
  @Metric private MutableCounterLong numBucketCreateFails;
}
