/** 
 * Wrapper for a client proxy as well as its associated service ID. This is simply used as a tuple-like return type for created NN proxy.
 */
public static class ProxyAndInfo<PROXYTYPE> {
  private final PROXYTYPE proxy;
  private final Text dtService;
  private final InetSocketAddress address;
  public ProxyAndInfo(  PROXYTYPE proxy,  Text dtService,  InetSocketAddress address){
    this.proxy=proxy;
    this.dtService=dtService;
    this.address=address;
  }
  public PROXYTYPE getProxy(){
    return proxy;
  }
  public Text getDelegationTokenService(){
    return dtService;
  }
  public InetSocketAddress getAddress(){
    return address;
  }
}
