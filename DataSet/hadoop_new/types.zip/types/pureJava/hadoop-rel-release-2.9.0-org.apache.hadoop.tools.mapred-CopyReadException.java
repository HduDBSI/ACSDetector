/** 
 * Special subclass of IOException. This is used to distinguish read-operation failures from other kinds of IOExceptions. The failure to read from source is dealt with specially, in the CopyMapper. Such failures may be skipped if the DistCpOptions indicate so. Write failures are intolerable, and amount to CopyMapper failure.
 */
@SuppressWarnings("serial") public static class CopyReadException extends IOException {
  public CopyReadException(  Throwable rootCause){
    super(rootCause);
  }
}
