/** 
 * This exception class contains the http error code, requestId and error message, it is thrown when AzureADAuthenticator failed to get the Azure Active Directory token.
 */
@InterfaceAudience.LimitedPrivate("authorization-subsystems") @InterfaceStability.Unstable public static class HttpException extends IOException {
  private final int httpErrorCode;
  private final String requestId;
  private final String url;
  private final String contentType;
  private final String body;
  /** 
 * Gets Http error status code.
 * @return  http error code.
 */
  public int getHttpErrorCode(){
    return this.httpErrorCode;
  }
  /** 
 * Gets http request id .
 * @return  http request id.
 */
  public String getRequestId(){
    return this.requestId;
  }
  protected HttpException(  final int httpErrorCode,  final String requestId,  final String message,  final String url,  final String contentType,  final String body){
    super(message);
    this.httpErrorCode=httpErrorCode;
    this.requestId=requestId;
    this.url=url;
    this.contentType=contentType;
    this.body=body;
  }
  public String getUrl(){
    return url;
  }
  public String getContentType(){
    return contentType;
  }
  public String getBody(){
    return body;
  }
  @Override public String getMessage(){
    final StringBuilder sb=new StringBuilder();
    sb.append("HTTP Error ");
    sb.append(httpErrorCode);
    if (!url.isEmpty()) {
      sb.append("; url='").append(url).append('\'').append(' ');
    }
    sb.append(super.getMessage());
    if (!requestId.isEmpty()) {
      sb.append("; requestId='").append(requestId).append('\'');
    }
    if (!contentType.isEmpty()) {
      sb.append("; contentType='").append(contentType).append('\'');
    }
    if (!body.isEmpty()) {
      sb.append("; response '").append(body).append('\'');
    }
    return sb.toString();
  }
}
