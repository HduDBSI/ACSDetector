/** 
 * SecretManager for ContainerTokens. Extended by both RM and NM and hence is present in yarn-server-common package.
 */
public class BaseContainerTokenSecretManager extends SecretManager<ContainerTokenIdentifier> {
  private static Log LOG=LogFactory.getLog(BaseContainerTokenSecretManager.class);
  protected int serialNo=new SecureRandom().nextInt();
  protected final ReadWriteLock readWriteLock=new ReentrantReadWriteLock();
  protected final Lock readLock=readWriteLock.readLock();
  protected final Lock writeLock=readWriteLock.writeLock();
  /** 
 * THE masterKey. ResourceManager should persist this and recover it on restart instead of generating a new key. The NodeManagers get it from the ResourceManager and use it for validating container-tokens.
 */
  protected MasterKeyData currentMasterKey;
  protected final long containerTokenExpiryInterval;
  public BaseContainerTokenSecretManager(  Configuration conf){
    this.containerTokenExpiryInterval=conf.getInt(YarnConfiguration.RM_CONTAINER_ALLOC_EXPIRY_INTERVAL_MS,YarnConfiguration.DEFAULT_RM_CONTAINER_ALLOC_EXPIRY_INTERVAL_MS);
  }
  protected MasterKeyData createNewMasterKey(){
    this.writeLock.lock();
    try {
      return new MasterKeyData(serialNo++,generateSecret());
    }
  finally {
      this.writeLock.unlock();
    }
  }
  @Private public MasterKey getCurrentKey(){
    this.readLock.lock();
    try {
      return this.currentMasterKey.getMasterKey();
    }
  finally {
      this.readLock.unlock();
    }
  }
  @Override public byte[] createPassword(  ContainerTokenIdentifier identifier){
    if (LOG.isDebugEnabled()) {
      LOG.debug("Creating password for " + identifier.getContainerID() + " for user "+ identifier.getUser()+ " to be run on NM "+ identifier.getNmHostAddress());
    }
    this.readLock.lock();
    try {
      return createPassword(identifier.getBytes(),this.currentMasterKey.getSecretKey());
    }
  finally {
      this.readLock.unlock();
    }
  }
  @Override public byte[] retrievePassword(  ContainerTokenIdentifier identifier) throws SecretManager.InvalidToken {
    this.readLock.lock();
    try {
      return retrievePasswordInternal(identifier,this.currentMasterKey);
    }
  finally {
      this.readLock.unlock();
    }
  }
  protected byte[] retrievePasswordInternal(  ContainerTokenIdentifier identifier,  MasterKeyData masterKey) throws org.apache.hadoop.security.token.SecretManager.InvalidToken {
    if (LOG.isDebugEnabled()) {
      LOG.debug("Retrieving password for " + identifier.getContainerID() + " for user "+ identifier.getUser()+ " to be run on NM "+ identifier.getNmHostAddress());
    }
    return createPassword(identifier.getBytes(),masterKey.getSecretKey());
  }
  /** 
 * Used by the RPC layer.
 */
  @Override public ContainerTokenIdentifier createIdentifier(){
    return new ContainerTokenIdentifier();
  }
}
