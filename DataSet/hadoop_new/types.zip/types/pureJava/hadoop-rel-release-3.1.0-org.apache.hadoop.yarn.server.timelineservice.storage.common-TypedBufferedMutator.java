/** 
 * To be used to wrap an actual  {@link BufferedMutator} in a type safe manner.
 * @param < T > The class referring to the table to be written to.
 */
public class TypedBufferedMutator<T extends BaseTable<T>> {
  private final BufferedMutator bufferedMutator;
  /** 
 * @param bufferedMutator the mutator to be wrapped for delegation. Shall notbe null.
 */
  public TypedBufferedMutator(  BufferedMutator bufferedMutator){
    this.bufferedMutator=bufferedMutator;
  }
  public TableName getName(){
    return bufferedMutator.getName();
  }
  public Configuration getConfiguration(){
    return bufferedMutator.getConfiguration();
  }
  public void mutate(  Mutation mutation) throws IOException {
    bufferedMutator.mutate(mutation);
  }
  public void mutate(  List<? extends Mutation> mutations) throws IOException {
    bufferedMutator.mutate(mutations);
  }
  public void close() throws IOException {
    bufferedMutator.close();
  }
  public void flush() throws IOException {
    bufferedMutator.flush();
  }
  public long getWriteBufferSize(){
    return bufferedMutator.getWriteBufferSize();
  }
}
