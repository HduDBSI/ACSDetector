public abstract class AbstractProviderService implements ProviderService, YarnServiceConstants {
  protected static final Logger log=LoggerFactory.getLogger(AbstractProviderService.class);
  public abstract void processArtifact(  AbstractLauncher launcher,  ComponentInstance compInstance,  SliderFileSystem fileSystem,  Service service,  ContainerLaunchService.ComponentLaunchContext compLaunchCtx) throws IOException ;
  public Map<String,String> buildContainerTokens(  ComponentInstance instance,  Container container,  ContainerLaunchService.ComponentLaunchContext compLaunchContext){
    Map<String,String> globalTokens=instance.getComponent().getScheduler().globalTokens;
    Map<String,String> tokensForSubstitution=ProviderUtils.initCompTokensForSubstitute(instance,container,compLaunchContext);
    tokensForSubstitution.putAll(globalTokens);
    return tokensForSubstitution;
  }
  public void buildContainerEnvironment(  AbstractLauncher launcher,  Service service,  ComponentInstance instance,  SliderFileSystem fileSystem,  Configuration yarnConf,  Container container,  ContainerLaunchService.ComponentLaunchContext compLaunchContext,  Map<String,String> tokensForSubstitution) throws IOException, SliderException {
    launcher.putEnv(ServiceUtils.buildEnvMap(compLaunchContext.getConfiguration(),tokensForSubstitution));
    launcher.setEnv("WORK_DIR",ApplicationConstants.Environment.PWD.$());
    launcher.setEnv("LOG_DIR",ApplicationConstants.LOG_DIR_EXPANSION_VAR);
    if (System.getenv(HADOOP_USER_NAME) != null) {
      launcher.setEnv(HADOOP_USER_NAME,System.getenv(HADOOP_USER_NAME));
    }
    launcher.setEnv("LANG","en_US.UTF-8");
    launcher.setEnv("LC_ALL","en_US.UTF-8");
    launcher.setEnv("LANGUAGE","en_US.UTF-8");
    for (    Entry<String,String> entry : launcher.getEnv().entrySet()) {
      tokensForSubstitution.put($(entry.getKey()),entry.getValue());
    }
  }
  public void buildContainerLaunchCommand(  AbstractLauncher launcher,  Service service,  ComponentInstance instance,  SliderFileSystem fileSystem,  Configuration yarnConf,  Container container,  ContainerLaunchService.ComponentLaunchContext compLaunchContext,  Map<String,String> tokensForSubstitution) throws IOException, SliderException {
    String launchCommand=compLaunchContext.getLaunchCommand();
    if (!StringUtils.isEmpty(launchCommand)) {
      launchCommand=ProviderUtils.substituteStrWithTokens(launchCommand,tokensForSubstitution);
      CommandLineBuilder operation=new CommandLineBuilder();
      operation.add(launchCommand);
      operation.addOutAndErrFiles(OUT_FILE,ERR_FILE);
      launcher.addCommand(operation.build());
    }
  }
  public void buildContainerRetry(  AbstractLauncher launcher,  Configuration yarnConf,  ContainerLaunchService.ComponentLaunchContext compLaunchContext,  ComponentInstance instance){
    ComponentRestartPolicy restartPolicy=instance.getComponent().getRestartPolicyHandler();
    if (restartPolicy.allowContainerRetriesForInstance(instance)) {
      launcher.setRetryContext(YarnServiceConf.getInt(CONTAINER_RETRY_MAX,DEFAULT_CONTAINER_RETRY_MAX,compLaunchContext.getConfiguration(),yarnConf),YarnServiceConf.getInt(CONTAINER_RETRY_INTERVAL,DEFAULT_CONTAINER_RETRY_INTERVAL,compLaunchContext.getConfiguration(),yarnConf),YarnServiceConf.getLong(CONTAINER_FAILURES_VALIDITY_INTERVAL,DEFAULT_CONTAINER_FAILURES_VALIDITY_INTERVAL,compLaunchContext.getConfiguration(),yarnConf));
    }
  }
  public void buildContainerLaunchContext(  AbstractLauncher launcher,  Service service,  ComponentInstance instance,  SliderFileSystem fileSystem,  Configuration yarnConf,  Container container,  ContainerLaunchService.ComponentLaunchContext compLaunchContext) throws IOException, SliderException {
    processArtifact(launcher,instance,fileSystem,service,compLaunchContext);
    ServiceContext context=instance.getComponent().getScheduler().getContext();
    Map<String,String> tokensForSubstitution=buildContainerTokens(instance,container,compLaunchContext);
    buildContainerEnvironment(launcher,service,instance,fileSystem,yarnConf,container,compLaunchContext,tokensForSubstitution);
    ProviderUtils.createConfigFileAndAddLocalResource(launcher,fileSystem,compLaunchContext,tokensForSubstitution,instance,context);
    ProviderUtils.handleStaticFilesForLocalization(launcher,fileSystem,compLaunchContext);
    buildContainerLaunchCommand(launcher,service,instance,fileSystem,yarnConf,container,compLaunchContext,tokensForSubstitution);
    buildContainerRetry(launcher,yarnConf,compLaunchContext,instance);
  }
}
