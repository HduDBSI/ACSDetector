/** 
 * Unit tests for NodeQueueLoadMonitor.
 */
public class TestNodeQueueLoadMonitor {
  private final static int DEFAULT_MAX_QUEUE_LENGTH=200;
static class FakeNodeId extends NodeId {
    final String host;
    final int port;
    public FakeNodeId(    String host,    int port){
      this.host=host;
      this.port=port;
    }
    @Override public String getHost(){
      return host;
    }
    @Override public int getPort(){
      return port;
    }
    @Override protected void setHost(    String host){
    }
    @Override protected void setPort(    int port){
    }
    @Override protected void build(){
    }
    @Override public String toString(){
      return host + ":" + port;
    }
  }
  @Test public void testWaitTimeSort(){
    NodeQueueLoadMonitor selector=new NodeQueueLoadMonitor(NodeQueueLoadMonitor.LoadComparator.QUEUE_WAIT_TIME);
    selector.updateNode(createRMNode("h1",1,15,10));
    selector.updateNode(createRMNode("h2",2,5,10));
    selector.updateNode(createRMNode("h3",3,10,10));
    selector.computeTask.run();
    List<NodeId> nodeIds=selector.selectNodes();
    System.out.println("1-> " + nodeIds);
    Assert.assertEquals("h2:2",nodeIds.get(0).toString());
    Assert.assertEquals("h3:3",nodeIds.get(1).toString());
    Assert.assertEquals("h1:1",nodeIds.get(2).toString());
    selector.updateNode(createRMNode("h3",3,2,10));
    selector.computeTask.run();
    nodeIds=selector.selectNodes();
    System.out.println("2-> " + nodeIds);
    Assert.assertEquals("h3:3",nodeIds.get(0).toString());
    Assert.assertEquals("h2:2",nodeIds.get(1).toString());
    Assert.assertEquals("h1:1",nodeIds.get(2).toString());
    selector.updateNode(createRMNode("h4",4,-1,10));
    selector.computeTask.run();
    nodeIds=selector.selectNodes();
    System.out.println("3-> " + nodeIds);
    Assert.assertEquals("h3:3",nodeIds.get(0).toString());
    Assert.assertEquals("h2:2",nodeIds.get(1).toString());
    Assert.assertEquals("h1:1",nodeIds.get(2).toString());
    selector.updateNode(createRMNode("h2",2,1,10,NodeState.DECOMMISSIONING));
    selector.computeTask.run();
    nodeIds=selector.selectNodes();
    Assert.assertEquals(2,nodeIds.size());
    Assert.assertEquals("h3:3",nodeIds.get(0).toString());
    Assert.assertEquals("h1:1",nodeIds.get(1).toString());
    selector.updateNode(createRMNode("h2",2,1,10,NodeState.RUNNING));
    selector.computeTask.run();
    nodeIds=selector.selectNodes();
    Assert.assertEquals("h2:2",nodeIds.get(0).toString());
    Assert.assertEquals("h3:3",nodeIds.get(1).toString());
    Assert.assertEquals("h1:1",nodeIds.get(2).toString());
  }
  @Test public void testQueueLengthSort(){
    NodeQueueLoadMonitor selector=new NodeQueueLoadMonitor(NodeQueueLoadMonitor.LoadComparator.QUEUE_LENGTH);
    selector.updateNode(createRMNode("h1",1,-1,15));
    selector.updateNode(createRMNode("h2",2,-1,5));
    selector.updateNode(createRMNode("h3",3,-1,10));
    selector.computeTask.run();
    List<NodeId> nodeIds=selector.selectNodes();
    System.out.println("1-> " + nodeIds);
    Assert.assertEquals("h2:2",nodeIds.get(0).toString());
    Assert.assertEquals("h3:3",nodeIds.get(1).toString());
    Assert.assertEquals("h1:1",nodeIds.get(2).toString());
    selector.updateNode(createRMNode("h3",3,-1,2));
    selector.computeTask.run();
    nodeIds=selector.selectNodes();
    System.out.println("2-> " + nodeIds);
    Assert.assertEquals("h3:3",nodeIds.get(0).toString());
    Assert.assertEquals("h2:2",nodeIds.get(1).toString());
    Assert.assertEquals("h1:1",nodeIds.get(2).toString());
    selector.updateNode(createRMNode("h4",4,-1,20));
    selector.computeTask.run();
    nodeIds=selector.selectNodes();
    System.out.println("3-> " + nodeIds);
    Assert.assertEquals("h3:3",nodeIds.get(0).toString());
    Assert.assertEquals("h2:2",nodeIds.get(1).toString());
    Assert.assertEquals("h1:1",nodeIds.get(2).toString());
    Assert.assertEquals("h4:4",nodeIds.get(3).toString());
    selector.updateNode(createRMNode("h3",3,-1,DEFAULT_MAX_QUEUE_LENGTH));
    selector.computeTask.run();
    nodeIds=selector.selectNodes();
    System.out.println("4-> " + nodeIds);
    Assert.assertEquals(3,nodeIds.size());
    Assert.assertEquals("h2:2",nodeIds.get(0).toString());
    Assert.assertEquals("h1:1",nodeIds.get(1).toString());
    Assert.assertEquals("h4:4",nodeIds.get(2).toString());
    selector.updateNode(createRMNode("h2",2,-1,5,NodeState.DECOMMISSIONING));
    selector.computeTask.run();
    nodeIds=selector.selectNodes();
    Assert.assertEquals(2,nodeIds.size());
    Assert.assertEquals("h1:1",nodeIds.get(0).toString());
    Assert.assertEquals("h4:4",nodeIds.get(1).toString());
    selector.updateNode(createRMNode("h2",2,-1,5,NodeState.RUNNING));
    selector.computeTask.run();
    nodeIds=selector.selectNodes();
    Assert.assertEquals(3,nodeIds.size());
    Assert.assertEquals("h2:2",nodeIds.get(0).toString());
    Assert.assertEquals("h1:1",nodeIds.get(1).toString());
    Assert.assertEquals("h4:4",nodeIds.get(2).toString());
  }
  @Test public void testContainerQueuingLimit(){
    NodeQueueLoadMonitor selector=new NodeQueueLoadMonitor(NodeQueueLoadMonitor.LoadComparator.QUEUE_LENGTH);
    selector.updateNode(createRMNode("h1",1,-1,15));
    selector.updateNode(createRMNode("h2",2,-1,5));
    selector.updateNode(createRMNode("h3",3,-1,10));
    selector.initThresholdCalculator(0,6,100);
    QueueLimitCalculator calculator=selector.getThresholdCalculator();
    ContainerQueuingLimit containerQueuingLimit=calculator.createContainerQueuingLimit();
    Assert.assertEquals(6,containerQueuingLimit.getMaxQueueLength());
    Assert.assertEquals(-1,containerQueuingLimit.getMaxQueueWaitTimeInMs());
    selector.computeTask.run();
    containerQueuingLimit=calculator.createContainerQueuingLimit();
    Assert.assertEquals(10,containerQueuingLimit.getMaxQueueLength());
    Assert.assertEquals(-1,containerQueuingLimit.getMaxQueueWaitTimeInMs());
    selector.updateNode(createRMNode("h1",1,-1,110));
    selector.updateNode(createRMNode("h2",2,-1,120));
    selector.updateNode(createRMNode("h3",3,-1,130));
    selector.updateNode(createRMNode("h4",4,-1,140));
    selector.updateNode(createRMNode("h5",5,-1,150));
    selector.updateNode(createRMNode("h6",6,-1,160));
    selector.computeTask.run();
    containerQueuingLimit=calculator.createContainerQueuingLimit();
    Assert.assertEquals(100,containerQueuingLimit.getMaxQueueLength());
    selector.updateNode(createRMNode("h1",1,-1,1));
    selector.updateNode(createRMNode("h2",2,-1,2));
    selector.updateNode(createRMNode("h3",3,-1,3));
    selector.updateNode(createRMNode("h4",4,-1,4));
    selector.updateNode(createRMNode("h5",5,-1,5));
    selector.updateNode(createRMNode("h6",6,-1,6));
    selector.computeTask.run();
    containerQueuingLimit=calculator.createContainerQueuingLimit();
    Assert.assertEquals(6,containerQueuingLimit.getMaxQueueLength());
  }
  /** 
 * Tests selection of local node from NodeQueueLoadMonitor. This test covers selection of node based on queue limit and blacklisted nodes.
 */
  @Test public void testSelectLocalNode(){
    NodeQueueLoadMonitor selector=new NodeQueueLoadMonitor(NodeQueueLoadMonitor.LoadComparator.QUEUE_LENGTH);
    RMNode h1=createRMNode("h1",1,-1,2,5);
    RMNode h2=createRMNode("h2",2,-1,5,5);
    RMNode h3=createRMNode("h3",3,-1,4,5);
    selector.addNode(null,h1);
    selector.addNode(null,h2);
    selector.addNode(null,h3);
    selector.updateNode(h1);
    selector.updateNode(h2);
    selector.updateNode(h3);
    Set<String> blacklist=new HashSet<>();
    RMNode node=selector.selectLocalNode("h1",blacklist);
    Assert.assertEquals("h1",node.getHostName());
    blacklist.add("h1");
    node=selector.selectLocalNode("h1",blacklist);
    Assert.assertNull(node);
    node=selector.selectLocalNode("h2",blacklist);
    Assert.assertNull(node);
    node=selector.selectLocalNode("h3",blacklist);
    Assert.assertEquals("h3",node.getHostName());
  }
  /** 
 * Tests selection of rack local node from NodeQueueLoadMonitor. This test covers selection of node based on queue limit and blacklisted nodes.
 */
  @Test public void testSelectRackLocalNode(){
    NodeQueueLoadMonitor selector=new NodeQueueLoadMonitor(NodeQueueLoadMonitor.LoadComparator.QUEUE_LENGTH);
    RMNode h1=createRMNode("h1",1,"rack1",-1,2,5);
    RMNode h2=createRMNode("h2",2,"rack2",-1,5,5);
    RMNode h3=createRMNode("h3",3,"rack2",-1,4,5);
    selector.addNode(null,h1);
    selector.addNode(null,h2);
    selector.addNode(null,h3);
    selector.updateNode(h1);
    selector.updateNode(h2);
    selector.updateNode(h3);
    Set<String> blacklist=new HashSet<>();
    RMNode node=selector.selectRackLocalNode("rack1",blacklist);
    Assert.assertEquals("h1",node.getHostName());
    blacklist.add("h1");
    node=selector.selectRackLocalNode("rack1",blacklist);
    Assert.assertNull(node);
    node=selector.selectRackLocalNode("rack2",blacklist);
    Assert.assertEquals("h3",node.getHostName());
    blacklist.add("h3");
    node=selector.selectRackLocalNode("rack2",blacklist);
    Assert.assertNull(node);
  }
  /** 
 * Tests selection of any node from NodeQueueLoadMonitor. This test covers selection of node based on queue limit and blacklisted nodes.
 */
  @Test public void testSelectAnyNode(){
    NodeQueueLoadMonitor selector=new NodeQueueLoadMonitor(NodeQueueLoadMonitor.LoadComparator.QUEUE_LENGTH);
    RMNode h1=createRMNode("h1",1,"rack1",-1,2,5);
    RMNode h2=createRMNode("h2",2,"rack2",-1,5,5);
    RMNode h3=createRMNode("h3",3,"rack2",-1,4,10);
    selector.addNode(null,h1);
    selector.addNode(null,h2);
    selector.addNode(null,h3);
    selector.updateNode(h1);
    selector.updateNode(h2);
    selector.updateNode(h3);
    selector.computeTask.run();
    Assert.assertEquals(2,selector.getSortedNodes().size());
    Set<String> blacklist=new HashSet<>();
    RMNode node=selector.selectAnyNode(blacklist);
    Assert.assertTrue(node.getHostName().equals("h1") || node.getHostName().equals("h3"));
    blacklist.add("h1");
    node=selector.selectAnyNode(blacklist);
    Assert.assertEquals("h3",node.getHostName());
    blacklist.add("h3");
    node=selector.selectAnyNode(blacklist);
    Assert.assertNull(node);
  }
  private RMNode createRMNode(  String host,  int port,  int waitTime,  int queueLength){
    return createRMNode(host,port,waitTime,queueLength,DEFAULT_MAX_QUEUE_LENGTH);
  }
  private RMNode createRMNode(  String host,  int port,  int waitTime,  int queueLength,  NodeState state){
    return createRMNode(host,port,"default",waitTime,queueLength,DEFAULT_MAX_QUEUE_LENGTH,state);
  }
  private RMNode createRMNode(  String host,  int port,  int waitTime,  int queueLength,  int queueCapacity){
    return createRMNode(host,port,"default",waitTime,queueLength,queueCapacity,NodeState.RUNNING);
  }
  private RMNode createRMNode(  String host,  int port,  String rack,  int waitTime,  int queueLength,  int queueCapacity){
    return createRMNode(host,port,rack,waitTime,queueLength,queueCapacity,NodeState.RUNNING);
  }
  private RMNode createRMNode(  String host,  int port,  String rack,  int waitTime,  int queueLength,  int queueCapacity,  NodeState state){
    RMNode node1=Mockito.mock(RMNode.class);
    NodeId nID1=new FakeNodeId(host,port);
    Mockito.when(node1.getHostName()).thenReturn(host);
    Mockito.when(node1.getRackName()).thenReturn(rack);
    Mockito.when(node1.getNodeID()).thenReturn(nID1);
    Mockito.when(node1.getState()).thenReturn(state);
    OpportunisticContainersStatus status1=Mockito.mock(OpportunisticContainersStatus.class);
    Mockito.when(status1.getEstimatedQueueWaitTime()).thenReturn(waitTime);
    Mockito.when(status1.getWaitQueueLength()).thenReturn(queueLength);
    Mockito.when(status1.getOpportQueueCapacity()).thenReturn(queueCapacity);
    Mockito.when(node1.getOpportunisticContainersStatus()).thenReturn(status1);
    return node1;
  }
}
