@InterfaceAudience.Private @InterfaceStability.Unstable public class ResourceHandlerException extends YarnException {
  private static final long serialVersionUID=1L;
  public ResourceHandlerException(){
    super();
  }
  public ResourceHandlerException(  String message){
    super(message);
  }
  public ResourceHandlerException(  Throwable cause){
    super(cause);
  }
  public ResourceHandlerException(  String message,  Throwable cause){
    super(message,cause);
  }
}
