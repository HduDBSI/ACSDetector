public class GpuResourcePlugin implements ResourcePlugin {
  private GpuResourceHandlerImpl gpuResourceHandler=null;
  private GpuNodeResourceUpdateHandler resourceDiscoverHandler=null;
  private DockerCommandPlugin dockerCommandPlugin=null;
  @Override public synchronized void initialize(  Context context) throws YarnException {
    resourceDiscoverHandler=new GpuNodeResourceUpdateHandler();
    GpuDiscoverer.getInstance().initialize(context.getConf());
    dockerCommandPlugin=GpuDockerCommandPluginFactory.createGpuDockerCommandPlugin(context.getConf());
  }
  @Override public synchronized ResourceHandler createResourceHandler(  Context context,  CGroupsHandler cGroupsHandler,  PrivilegedOperationExecutor privilegedOperationExecutor){
    if (gpuResourceHandler == null) {
      gpuResourceHandler=new GpuResourceHandlerImpl(context,cGroupsHandler,privilegedOperationExecutor);
    }
    return gpuResourceHandler;
  }
  @Override public synchronized NodeResourceUpdaterPlugin getNodeResourceHandlerInstance(){
    return resourceDiscoverHandler;
  }
  @Override public void cleanup() throws YarnException {
  }
  public DockerCommandPlugin getDockerCommandPluginInstance(){
    return dockerCommandPlugin;
  }
  @Override public NMResourceInfo getNMResourceInfo() throws YarnException {
    GpuDeviceInformation gpuDeviceInformation=GpuDiscoverer.getInstance().getGpuDeviceInformation();
    GpuResourceAllocator gpuResourceAllocator=gpuResourceHandler.getGpuAllocator();
    List<GpuDevice> totalGpus=gpuResourceAllocator.getAllowedGpusCopy();
    List<AssignedGpuDevice> assignedGpuDevices=gpuResourceAllocator.getAssignedGpusCopy();
    return new NMGpuResourceInfo(gpuDeviceInformation,totalGpus,assignedGpuDevices);
  }
}
