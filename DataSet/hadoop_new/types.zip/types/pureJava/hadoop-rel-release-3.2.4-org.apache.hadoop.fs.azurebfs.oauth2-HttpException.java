/** 
 * This exception class contains the http error code, requestId and error message, it is thrown when AzureADAuthenticator failed to get the Azure Active Directory token.
 */
@InterfaceAudience.LimitedPrivate("authorization-subsystems") @InterfaceStability.Unstable public static class HttpException extends IOException {
  private int httpErrorCode;
  private String requestId;
  /** 
 * Gets Http error status code.
 * @return  http error code.
 */
  public int getHttpErrorCode(){
    return this.httpErrorCode;
  }
  /** 
 * Gets http request id .
 * @return  http request id.
 */
  public String getRequestId(){
    return this.requestId;
  }
  protected HttpException(  int httpErrorCode,  String requestId,  String message){
    super(message);
    this.httpErrorCode=httpErrorCode;
    this.requestId=requestId;
  }
}
