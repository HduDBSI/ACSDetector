/** 
 * Implementation of <code>UpdateContainerRequest</code>.
 */
public class UpdateContainerRequestPBImpl extends UpdateContainerRequest {
  private YarnServiceProtos.UpdateContainerRequestProto proto=YarnServiceProtos.UpdateContainerRequestProto.getDefaultInstance();
  private YarnServiceProtos.UpdateContainerRequestProto.Builder builder=null;
  private boolean viaProto=false;
  private ContainerId existingContainerId=null;
  private Resource targetCapability=null;
  public UpdateContainerRequestPBImpl(){
    builder=YarnServiceProtos.UpdateContainerRequestProto.newBuilder();
  }
  public UpdateContainerRequestPBImpl(  YarnServiceProtos.UpdateContainerRequestProto proto){
    this.proto=proto;
    viaProto=true;
  }
  public YarnServiceProtos.UpdateContainerRequestProto getProto(){
    mergeLocalToProto();
    proto=viaProto ? proto : builder.build();
    viaProto=true;
    return proto;
  }
  @Override public int getContainerVersion(){
    YarnServiceProtos.UpdateContainerRequestProtoOrBuilder p=viaProto ? proto : builder;
    if (!p.hasContainerVersion()) {
      return 0;
    }
    return p.getContainerVersion();
  }
  @Override public void setContainerVersion(  int containerVersion){
    maybeInitBuilder();
    builder.setContainerVersion(containerVersion);
  }
  @Override public ContainerId getContainerId(){
    YarnServiceProtos.UpdateContainerRequestProtoOrBuilder p=viaProto ? proto : builder;
    if (this.existingContainerId != null) {
      return this.existingContainerId;
    }
    if (p.hasContainerId()) {
      this.existingContainerId=ProtoUtils.convertFromProtoFormat(p.getContainerId());
    }
    return this.existingContainerId;
  }
  @Override public void setContainerId(  ContainerId containerId){
    maybeInitBuilder();
    if (containerId == null) {
      builder.clearContainerId();
    }
    this.existingContainerId=containerId;
  }
  @Override public Resource getCapability(){
    YarnServiceProtos.UpdateContainerRequestProtoOrBuilder p=viaProto ? proto : builder;
    if (this.targetCapability != null) {
      return this.targetCapability;
    }
    if (p.hasCapability()) {
      this.targetCapability=ProtoUtils.convertFromProtoFormat(p.getCapability());
    }
    return this.targetCapability;
  }
  @Override public void setCapability(  Resource capability){
    maybeInitBuilder();
    if (capability == null) {
      builder.clearCapability();
    }
    this.targetCapability=capability;
  }
  @Override public ExecutionType getExecutionType(){
    YarnServiceProtos.UpdateContainerRequestProtoOrBuilder p=viaProto ? proto : builder;
    if (!p.hasExecutionType()) {
      return null;
    }
    return ProtoUtils.convertFromProtoFormat(p.getExecutionType());
  }
  @Override public void setExecutionType(  ExecutionType execType){
    maybeInitBuilder();
    if (execType == null) {
      builder.clearExecutionType();
      return;
    }
    builder.setExecutionType(ProtoUtils.convertToProtoFormat(execType));
  }
  @Override public ContainerUpdateType getContainerUpdateType(){
    YarnServiceProtos.UpdateContainerRequestProtoOrBuilder p=viaProto ? proto : builder;
    if (!p.hasUpdateType()) {
      return null;
    }
    return ProtoUtils.convertFromProtoFormat(p.getUpdateType());
  }
  @Override public void setContainerUpdateType(  ContainerUpdateType updateType){
    maybeInitBuilder();
    if (updateType == null) {
      builder.clearUpdateType();
      return;
    }
    builder.setUpdateType(ProtoUtils.convertToProtoFormat(updateType));
  }
  private void mergeLocalToProto(){
    if (viaProto) {
      maybeInitBuilder();
    }
    mergeLocalToBuilder();
    proto=builder.build();
    viaProto=true;
  }
  private void maybeInitBuilder(){
    if (viaProto || builder == null) {
      builder=YarnServiceProtos.UpdateContainerRequestProto.newBuilder(proto);
    }
    viaProto=false;
  }
  private void mergeLocalToBuilder(){
    if (this.existingContainerId != null) {
      builder.setContainerId(ProtoUtils.convertToProtoFormat(this.existingContainerId));
    }
    if (this.targetCapability != null) {
      builder.setCapability(ProtoUtils.convertToProtoFormat(this.targetCapability));
    }
  }
}
