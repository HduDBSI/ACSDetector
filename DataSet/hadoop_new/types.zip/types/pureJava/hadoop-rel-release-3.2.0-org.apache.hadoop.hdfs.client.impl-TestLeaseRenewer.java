public class TestLeaseRenewer {
  private final String FAKE_AUTHORITY="hdfs://nn1/";
  private final UserGroupInformation FAKE_UGI_A=UserGroupInformation.createUserForTesting("myuser",new String[]{"group1"});
  private final UserGroupInformation FAKE_UGI_B=UserGroupInformation.createUserForTesting("myuser",new String[]{"group1"});
  private DFSClient MOCK_DFSCLIENT;
  private LeaseRenewer renewer;
  /** 
 * Cause renewals often so test runs quickly. 
 */
  private static final long FAST_GRACE_PERIOD=100L;
  @Before public void setupMocksAndRenewer() throws IOException {
    MOCK_DFSCLIENT=createMockClient();
    renewer=LeaseRenewer.getInstance(FAKE_AUTHORITY,FAKE_UGI_A,MOCK_DFSCLIENT);
    renewer.setGraceSleepPeriod(FAST_GRACE_PERIOD);
  }
  private DFSClient createMockClient(){
    final DfsClientConf mockConf=Mockito.mock(DfsClientConf.class);
    Mockito.doReturn((int)FAST_GRACE_PERIOD).when(mockConf).getHdfsTimeout();
    DFSClient mock=Mockito.mock(DFSClient.class);
    Mockito.doReturn(true).when(mock).isClientRunning();
    Mockito.doReturn(mockConf).when(mock).getConf();
    Mockito.doReturn("myclient").when(mock).getClientName();
    return mock;
  }
  @Test public void testInstanceSharing() throws IOException {
    LeaseRenewer lr=LeaseRenewer.getInstance(FAKE_AUTHORITY,FAKE_UGI_A,MOCK_DFSCLIENT);
    LeaseRenewer lr2=LeaseRenewer.getInstance(FAKE_AUTHORITY,FAKE_UGI_A,MOCK_DFSCLIENT);
    Assert.assertSame(lr,lr2);
    LeaseRenewer lr3=LeaseRenewer.getInstance(FAKE_AUTHORITY,FAKE_UGI_B,MOCK_DFSCLIENT);
    Assert.assertNotSame(lr,lr3);
    LeaseRenewer lr4=LeaseRenewer.getInstance("someOtherAuthority",FAKE_UGI_B,MOCK_DFSCLIENT);
    Assert.assertNotSame(lr,lr4);
    Assert.assertNotSame(lr3,lr4);
  }
  @Test public void testRenewal() throws Exception {
    final AtomicInteger leaseRenewalCount=new AtomicInteger();
    Mockito.doAnswer(new Answer<Boolean>(){
      @Override public Boolean answer(      InvocationOnMock invocation) throws Throwable {
        leaseRenewalCount.incrementAndGet();
        return true;
      }
    }
).when(MOCK_DFSCLIENT).renewLease();
    DFSOutputStream mockStream=Mockito.mock(DFSOutputStream.class);
    long fileId=123L;
    renewer.put(MOCK_DFSCLIENT);
    long failTime=Time.monotonicNow() + 5000;
    while (Time.monotonicNow() < failTime && leaseRenewalCount.get() == 0) {
      Thread.sleep(50);
    }
    if (leaseRenewalCount.get() == 0) {
      Assert.fail("Did not renew lease at all!");
    }
    renewer.closeClient(MOCK_DFSCLIENT);
  }
  /** 
 * Regression test for HDFS-2810. In this bug, the LeaseRenewer has handles to several DFSClients with the same name, the first of which has no files open. Previously, this was causing the lease to not get renewed.
 */
  @Test public void testManyDfsClientsWhereSomeNotOpen() throws Exception {
    final DFSClient mockClient1=createMockClient();
    Mockito.doReturn(false).when(mockClient1).renewLease();
    assertSame(renewer,LeaseRenewer.getInstance(FAKE_AUTHORITY,FAKE_UGI_A,mockClient1));
    long fileId=456L;
    renewer.put(mockClient1);
    final DFSClient mockClient2=createMockClient();
    Mockito.doReturn(true).when(mockClient2).renewLease();
    assertSame(renewer,LeaseRenewer.getInstance(FAKE_AUTHORITY,FAKE_UGI_A,mockClient2));
    renewer.put(mockClient2);
    GenericTestUtils.waitFor(new Supplier<Boolean>(){
      @Override public Boolean get(){
        try {
          Mockito.verify(mockClient1,Mockito.atLeastOnce()).renewLease();
          Mockito.verify(mockClient2,Mockito.atLeastOnce()).renewLease();
          return true;
        }
 catch (        AssertionError err) {
          LeaseRenewer.LOG.warn("Not yet satisfied",err);
          return false;
        }
catch (        IOException e) {
          throw new RuntimeException(e);
        }
      }
    }
,100,10000);
    renewer.closeClient(mockClient1);
    renewer.closeClient(mockClient2);
  }
  @Test public void testThreadName() throws Exception {
    Assert.assertFalse("Renewer not initially running",renewer.isRunning());
    renewer.put(MOCK_DFSCLIENT);
    Assert.assertTrue("Renewer should have started running",renewer.isRunning());
    String threadName=renewer.getDaemonName();
    Assert.assertEquals("LeaseRenewer:myuser@hdfs://nn1/",threadName);
    renewer.closeClient(MOCK_DFSCLIENT);
    renewer.setEmptyTime(Time.monotonicNow());
    long failTime=Time.monotonicNow() + 5000;
    while (renewer.isRunning() && Time.monotonicNow() < failTime) {
      Thread.sleep(50);
    }
    Assert.assertFalse(renewer.isRunning());
  }
}
