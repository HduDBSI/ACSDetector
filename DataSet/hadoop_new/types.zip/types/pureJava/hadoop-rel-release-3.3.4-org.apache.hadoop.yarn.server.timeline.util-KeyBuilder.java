/** 
 * A string builder utility for building timeline server leveldb keys. 
 */
public static class KeyBuilder {
  /** 
 * Maximum subkeys that can be added to construct a key. 
 */
  private static final int MAX_NUMBER_OF_KEY_ELEMENTS=10;
  private byte[][] b;
  private boolean[] useSeparator;
  private int index;
  private int length;
  public KeyBuilder(  int size){
    b=new byte[size][];
    useSeparator=new boolean[size];
    index=0;
    length=0;
  }
  public static KeyBuilder newInstance(){
    return new KeyBuilder(MAX_NUMBER_OF_KEY_ELEMENTS);
  }
  /** 
 * Instantiate a new key build with the given maximum subkes.
 * @param size maximum subkeys that can be added to this key builder
 * @return a newly constructed key builder 
 */
  public static KeyBuilder newInstance(  final int size){
    return new KeyBuilder(size);
  }
  public KeyBuilder add(  String s){
    return add(s.getBytes(UTF_8),true);
  }
  public KeyBuilder add(  byte[] t){
    return add(t,false);
  }
  public KeyBuilder add(  byte[] t,  boolean sep){
    b[index]=t;
    useSeparator[index]=sep;
    length+=t.length;
    if (sep) {
      length++;
    }
    index++;
    return this;
  }
  /** 
 * Builds a byte array without the final string delimiter. 
 */
  public byte[] getBytes(){
    int bytesLength=length;
    if (useSeparator[index - 1]) {
      bytesLength=length - 1;
    }
    byte[] bytes=new byte[bytesLength];
    int curPos=0;
    for (int i=0; i < index; i++) {
      System.arraycopy(b[i],0,bytes,curPos,b[i].length);
      curPos+=b[i].length;
      if (i < index - 1 && useSeparator[i]) {
        bytes[curPos++]=0x0;
      }
    }
    return bytes;
  }
  /** 
 * Builds a byte array including the final string delimiter. 
 */
  public byte[] getBytesForLookup(){
    byte[] bytes=new byte[length];
    int curPos=0;
    for (int i=0; i < index; i++) {
      System.arraycopy(b[i],0,bytes,curPos,b[i].length);
      curPos+=b[i].length;
      if (useSeparator[i]) {
        bytes[curPos++]=0x0;
      }
    }
    return bytes;
  }
}
