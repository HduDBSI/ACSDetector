public class DefaultClientProvider extends AbstractClientProvider {
  public DefaultClientProvider(){
  }
  @Override public void validateArtifact(  Artifact artifact,  FileSystem fileSystem){
  }
  @Override protected void validateConfigFile(  ConfigFile configFile,  FileSystem fileSystem) throws IOException {
    if (Paths.get(configFile.getDestFile()).isAbsolute()) {
      throw new IllegalArgumentException("Dest_file must not be absolute path: " + configFile.getDestFile());
    }
  }
}
