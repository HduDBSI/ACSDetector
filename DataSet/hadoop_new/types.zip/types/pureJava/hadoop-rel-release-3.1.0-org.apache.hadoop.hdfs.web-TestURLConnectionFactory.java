public final class TestURLConnectionFactory {
  @Test public void testConnConfiguratior() throws IOException {
    final URL u=new URL("http://localhost");
    final List<HttpURLConnection> conns=Lists.newArrayList();
    URLConnectionFactory fc=new URLConnectionFactory(new ConnectionConfigurator(){
      @Override public HttpURLConnection configure(      HttpURLConnection conn) throws IOException {
        Assert.assertEquals(u,conn.getURL());
        conns.add(conn);
        return conn;
      }
    }
);
    fc.openConnection(u);
    Assert.assertEquals(1,conns.size());
  }
  @Test public void testSSLInitFailure() throws Exception {
    Configuration conf=new Configuration();
    conf.set(SSLFactory.SSL_HOSTNAME_VERIFIER_KEY,"foo");
    GenericTestUtils.LogCapturer logs=GenericTestUtils.LogCapturer.captureLogs(LoggerFactory.getLogger(URLConnectionFactory.class));
    URLConnectionFactory.newDefaultURLConnectionFactory(conf);
    Assert.assertTrue("Expected log for ssl init failure not found!",logs.getOutput().contains("Cannot load customized ssl related configuration"));
  }
}
