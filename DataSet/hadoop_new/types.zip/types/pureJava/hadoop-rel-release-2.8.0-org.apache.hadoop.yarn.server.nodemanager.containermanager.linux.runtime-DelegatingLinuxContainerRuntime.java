@InterfaceAudience.Private @InterfaceStability.Unstable public class DelegatingLinuxContainerRuntime implements LinuxContainerRuntime {
  private static final Log LOG=LogFactory.getLog(DelegatingLinuxContainerRuntime.class);
  private DefaultLinuxContainerRuntime defaultLinuxContainerRuntime;
  private DockerLinuxContainerRuntime dockerLinuxContainerRuntime;
  @Override public void initialize(  Configuration conf) throws ContainerExecutionException {
    PrivilegedOperationExecutor privilegedOperationExecutor=PrivilegedOperationExecutor.getInstance(conf);
    defaultLinuxContainerRuntime=new DefaultLinuxContainerRuntime(privilegedOperationExecutor);
    defaultLinuxContainerRuntime.initialize(conf);
    dockerLinuxContainerRuntime=new DockerLinuxContainerRuntime(privilegedOperationExecutor);
    dockerLinuxContainerRuntime.initialize(conf);
  }
  private LinuxContainerRuntime pickContainerRuntime(  Container container){
    Map<String,String> env=container.getLaunchContext().getEnvironment();
    LinuxContainerRuntime runtime;
    if (DockerLinuxContainerRuntime.isDockerContainerRequested(env)) {
      runtime=dockerLinuxContainerRuntime;
    }
 else {
      runtime=defaultLinuxContainerRuntime;
    }
    if (LOG.isInfoEnabled()) {
      LOG.info("Using container runtime: " + runtime.getClass().getSimpleName());
    }
    return runtime;
  }
  @Override public void prepareContainer(  ContainerRuntimeContext ctx) throws ContainerExecutionException {
    Container container=ctx.getContainer();
    LinuxContainerRuntime runtime=pickContainerRuntime(container);
    runtime.prepareContainer(ctx);
  }
  @Override public void launchContainer(  ContainerRuntimeContext ctx) throws ContainerExecutionException {
    Container container=ctx.getContainer();
    LinuxContainerRuntime runtime=pickContainerRuntime(container);
    runtime.launchContainer(ctx);
  }
  @Override public void signalContainer(  ContainerRuntimeContext ctx) throws ContainerExecutionException {
    Container container=ctx.getContainer();
    LinuxContainerRuntime runtime=pickContainerRuntime(container);
    runtime.signalContainer(ctx);
  }
  @Override public void reapContainer(  ContainerRuntimeContext ctx) throws ContainerExecutionException {
    Container container=ctx.getContainer();
    LinuxContainerRuntime runtime=pickContainerRuntime(container);
    runtime.reapContainer(ctx);
  }
}
