@Private @Unstable @ProtocolInfo(protocolName="org.apache.hadoop.yarn.api.ContainerManagementProtocolPB",protocolVersion=1) public interface ContainerManagementProtocolPB extends ContainerManagementProtocolService.BlockingInterface {
  SignalContainerResponseProto signalToContainer(  RpcController arg0,  SignalContainerRequestProto proto) throws ServiceException ;
}
