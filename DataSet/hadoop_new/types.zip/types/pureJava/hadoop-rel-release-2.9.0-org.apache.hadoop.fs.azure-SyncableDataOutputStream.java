/** 
 * Support the Syncable interface on top of a DataOutputStream. This allows passing the sync/hflush/hsync calls through to the wrapped stream passed in to the constructor. This is required for HBase when wrapping a PageBlobOutputStream used as a write-ahead log.
 */
public class SyncableDataOutputStream extends DataOutputStream implements Syncable, StreamCapabilities {
  public SyncableDataOutputStream(  OutputStream out){
    super(out);
  }
  /** 
 * Get a reference to the wrapped output stream.
 * @return the underlying output stream
 */
  @InterfaceAudience.LimitedPrivate({"HDFS"}) public OutputStream getOutStream(){
    return out;
  }
  @Override public boolean hasCapability(  String capability){
    if (out instanceof StreamCapabilities) {
      return ((StreamCapabilities)out).hasCapability(capability);
    }
    return false;
  }
  @Override public void sync() throws IOException {
  }
  @Override public void hflush() throws IOException {
    if (out instanceof Syncable) {
      ((Syncable)out).hflush();
    }
 else {
      out.flush();
    }
  }
  @Override public void hsync() throws IOException {
    if (out instanceof Syncable) {
      ((Syncable)out).hsync();
    }
 else {
      out.flush();
    }
  }
}
