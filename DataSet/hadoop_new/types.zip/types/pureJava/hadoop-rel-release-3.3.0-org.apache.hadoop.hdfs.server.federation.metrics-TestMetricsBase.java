/** 
 * Test the basic metrics functionality.
 */
public class TestMetricsBase {
  private StateStoreService stateStore;
  private MembershipStore membershipStore;
  private RouterStore routerStore;
  private Router router;
  private Configuration routerConfig;
  private List<MembershipState> activeMemberships;
  private List<MembershipState> standbyMemberships;
  private List<MountTable> mockMountTable;
  private List<RouterState> mockRouters;
  private List<String> nameservices;
  @Before public void setupBase() throws Exception {
    if (router == null) {
      routerConfig=new RouterConfigBuilder().stateStore().metrics().http().build();
      router=new Router();
      router.init(routerConfig);
      router.setRouterId("routerId");
      router.start();
      stateStore=router.getStateStore();
      membershipStore=stateStore.getRegisteredRecordStore(MembershipStore.class);
      routerStore=stateStore.getRegisteredRecordStore(RouterStore.class);
      waitStateStore(stateStore,10000);
      createFixtures();
      stateStore.refreshCaches(true);
      Thread.sleep(1000);
    }
  }
  @After public void tearDownBase() throws IOException {
    if (router != null) {
      router.stop();
      router.close();
      router=null;
    }
  }
  private void createFixtures() throws IOException {
    clearAllRecords(stateStore);
    nameservices=new ArrayList<>();
    nameservices.add(NAMESERVICES[0]);
    nameservices.add(NAMESERVICES[1]);
    activeMemberships=new ArrayList<>();
    standbyMemberships=new ArrayList<>();
    for (    String nameservice : nameservices) {
      MembershipState namenode1=createMockRegistrationForNamenode(nameservice,NAMENODES[0],FederationNamenodeServiceState.ACTIVE);
      NamenodeHeartbeatRequest request1=NamenodeHeartbeatRequest.newInstance(namenode1);
      assertTrue(membershipStore.namenodeHeartbeat(request1).getResult());
      activeMemberships.add(namenode1);
      MembershipState namenode2=createMockRegistrationForNamenode(nameservice,NAMENODES[1],FederationNamenodeServiceState.STANDBY);
      NamenodeHeartbeatRequest request2=NamenodeHeartbeatRequest.newInstance(namenode2);
      assertTrue(membershipStore.namenodeHeartbeat(request2).getResult());
      standbyMemberships.add(namenode2);
    }
    mockMountTable=createMockMountTable(nameservices);
    synchronizeRecords(stateStore,mockMountTable,MountTable.class);
    long t1=Time.now();
    mockRouters=new ArrayList<>();
    RouterState router1=RouterState.newInstance("router1",t1,RouterServiceState.RUNNING);
    router1.setStateStoreVersion(StateStoreVersion.newInstance(t1 - 1000,t1 - 2000));
    RouterHeartbeatRequest heartbeatRequest=RouterHeartbeatRequest.newInstance(router1);
    assertTrue(routerStore.routerHeartbeat(heartbeatRequest).getStatus());
    GetRouterRegistrationRequest getRequest=GetRouterRegistrationRequest.newInstance("router1");
    GetRouterRegistrationResponse getResponse=routerStore.getRouterRegistration(getRequest);
    RouterState routerState1=getResponse.getRouter();
    mockRouters.add(routerState1);
    long t2=Time.now();
    RouterState router2=RouterState.newInstance("router2",t2,RouterServiceState.RUNNING);
    router2.setStateStoreVersion(StateStoreVersion.newInstance(t2 - 6000,t2 - 7000));
    heartbeatRequest.setRouter(router2);
    assertTrue(routerStore.routerHeartbeat(heartbeatRequest).getStatus());
    getRequest.setRouterId("router2");
    getResponse=routerStore.getRouterRegistration(getRequest);
    RouterState routerState2=getResponse.getRouter();
    mockRouters.add(routerState2);
  }
  protected Router getRouter(){
    return router;
  }
  protected List<MountTable> getMockMountTable(){
    return mockMountTable;
  }
  protected List<MembershipState> getActiveMemberships(){
    return activeMemberships;
  }
  protected List<MembershipState> getStandbyMemberships(){
    return standbyMemberships;
  }
  protected List<String> getNameservices(){
    return nameservices;
  }
  protected List<RouterState> getMockRouters(){
    return mockRouters;
  }
  protected StateStoreService getStateStore(){
    return stateStore;
  }
  @Test public void testObserverMetrics() throws Exception {
    mockObserver();
    RBFMetrics metrics=router.getMetrics();
    String jsonString=metrics.getNameservices();
    JSONObject jsonObject=new JSONObject(jsonString);
    Map<String,String> map=getNameserviceStateMap(jsonObject);
    assertTrue("Cannot find ns0 in: " + jsonString,map.containsKey("ns0"));
    assertEquals("OBSERVER",map.get("ns0"));
  }
  public static Map<String,String> getNameserviceStateMap(  JSONObject jsonObject) throws JSONException {
    Map<String,String> map=new TreeMap<>();
    Iterator<?> keys=jsonObject.keys();
    while (keys.hasNext()) {
      String key=(String)keys.next();
      JSONObject json=jsonObject.getJSONObject(key);
      String nsId=json.getString("nameserviceId");
      String state=json.getString("state");
      map.put(nsId,state);
    }
    return map;
  }
  private void mockObserver() throws IOException {
    String ns="ns0";
    String nn="nn0";
    createRegistration(ns,nn,ROUTERS[1],FederationNamenodeServiceState.OBSERVER);
    assertTrue(stateStore.loadCache(MembershipStore.class,true));
    membershipStore.loadCache(true);
    MembershipNamenodeResolver resolver=(MembershipNamenodeResolver)router.getNamenodeResolver();
    resolver.loadCache(true);
  }
  private MembershipState createRegistration(  String ns,  String nn,  String routerId,  FederationNamenodeServiceState state) throws IOException {
    MembershipState record=MembershipState.newInstance(routerId,ns,nn,"testcluster","testblock-" + ns,"testrpc-" + ns + nn,"testservice-" + ns + nn,"testlifeline-" + ns + nn,"http","testweb-" + ns + nn,state,false);
    NamenodeHeartbeatRequest request=NamenodeHeartbeatRequest.newInstance(record);
    NamenodeHeartbeatResponse response=membershipStore.namenodeHeartbeat(request);
    assertTrue(response.getResult());
    return record;
  }
}
