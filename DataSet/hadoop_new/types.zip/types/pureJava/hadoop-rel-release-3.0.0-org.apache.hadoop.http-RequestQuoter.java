public static class RequestQuoter extends HttpServletRequestWrapper {
  private final HttpServletRequest rawRequest;
  public RequestQuoter(  HttpServletRequest rawRequest){
    super(rawRequest);
    this.rawRequest=rawRequest;
  }
  /** 
 * Return the set of parameter names, quoting each name.
 */
  @SuppressWarnings("unchecked") @Override public Enumeration<String> getParameterNames(){
    return new Enumeration<String>(){
      private Enumeration<String> rawIterator=rawRequest.getParameterNames();
      @Override public boolean hasMoreElements(){
        return rawIterator.hasMoreElements();
      }
      @Override public String nextElement(){
        return HtmlQuoting.quoteHtmlChars(rawIterator.nextElement());
      }
    }
;
  }
  /** 
 * Unquote the name and quote the value.
 */
  @Override public String getParameter(  String name){
    return HtmlQuoting.quoteHtmlChars(rawRequest.getParameter(HtmlQuoting.unquoteHtmlChars(name)));
  }
  @Override public String[] getParameterValues(  String name){
    String unquoteName=HtmlQuoting.unquoteHtmlChars(name);
    String[] unquoteValue=rawRequest.getParameterValues(unquoteName);
    if (unquoteValue == null) {
      return null;
    }
    String[] result=new String[unquoteValue.length];
    for (int i=0; i < result.length; ++i) {
      result[i]=HtmlQuoting.quoteHtmlChars(unquoteValue[i]);
    }
    return result;
  }
  @SuppressWarnings("unchecked") @Override public Map<String,String[]> getParameterMap(){
    Map<String,String[]> result=new HashMap<>();
    Map<String,String[]> raw=rawRequest.getParameterMap();
    for (    Map.Entry<String,String[]> item : raw.entrySet()) {
      String[] rawValue=item.getValue();
      String[] cookedValue=new String[rawValue.length];
      for (int i=0; i < rawValue.length; ++i) {
        cookedValue[i]=HtmlQuoting.quoteHtmlChars(rawValue[i]);
      }
      result.put(HtmlQuoting.quoteHtmlChars(item.getKey()),cookedValue);
    }
    return result;
  }
  /** 
 * Quote the url so that users specifying the HOST HTTP header can't inject attacks.
 */
  @Override public StringBuffer getRequestURL(){
    String url=rawRequest.getRequestURL().toString();
    return new StringBuffer(HtmlQuoting.quoteHtmlChars(url));
  }
  /** 
 * Quote the server name so that users specifying the HOST HTTP header can't inject attacks.
 */
  @Override public String getServerName(){
    return HtmlQuoting.quoteHtmlChars(rawRequest.getServerName());
  }
}
