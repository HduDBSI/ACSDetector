/** 
 * FsckResult of checking, plus overall DFS statistics.
 */
@VisibleForTesting static class Result {
  final List<String> missingIds=new ArrayList<String>();
  long missingSize=0L;
  long corruptFiles=0L;
  long corruptBlocks=0L;
  long excessiveReplicas=0L;
  long missingReplicas=0L;
  long decommissionedReplicas=0L;
  long decommissioningReplicas=0L;
  long enteringMaintenanceReplicas=0L;
  long inMaintenanceReplicas=0L;
  long numUnderMinReplicatedBlocks=0L;
  long numOverReplicatedBlocks=0L;
  long numUnderReplicatedBlocks=0L;
  long numMisReplicatedBlocks=0L;
  long numMinReplicatedBlocks=0L;
  long totalBlocks=0L;
  long numExpectedReplicas=0L;
  long totalOpenFilesBlocks=0L;
  long totalFiles=0L;
  long totalOpenFiles=0L;
  long totalDirs=0L;
  long totalSymlinks=0L;
  long totalSize=0L;
  long totalOpenFilesSize=0L;
  long totalReplicas=0L;
  final short replication;
  final int minReplication;
  Result(  Configuration conf){
    this.replication=(short)conf.getInt(DFSConfigKeys.DFS_REPLICATION_KEY,DFSConfigKeys.DFS_REPLICATION_DEFAULT);
    this.minReplication=(short)conf.getInt(DFSConfigKeys.DFS_NAMENODE_REPLICATION_MIN_KEY,DFSConfigKeys.DFS_NAMENODE_REPLICATION_MIN_DEFAULT);
  }
  /** 
 * DFS is considered healthy if there are no missing blocks.
 */
  boolean isHealthy(){
    return ((missingIds.size() == 0) && (corruptBlocks == 0));
  }
  /** 
 * Add a missing block name, plus its size. 
 */
  void addMissing(  String id,  long size){
    missingIds.add(id);
    missingSize+=size;
  }
  /** 
 * Return the actual replication factor. 
 */
  float getReplicationFactor(){
    if (totalBlocks == 0)     return 0.0f;
    return (float)(totalReplicas) / (float)totalBlocks;
  }
  @Override public String toString(){
    StringBuilder res=new StringBuilder();
    res.append("Status: ").append((isHealthy() ? "HEALTHY" : "CORRUPT")).append("\n Total size:\t").append(totalSize).append(" B");
    if (totalOpenFilesSize != 0) {
      res.append(" (Total open files size: ").append(totalOpenFilesSize).append(" B)");
    }
    res.append("\n Total dirs:\t").append(totalDirs).append("\n Total files:\t").append(totalFiles);
    res.append("\n Total symlinks:\t\t").append(totalSymlinks);
    if (totalOpenFiles != 0) {
      res.append(" (Files currently being written: ").append(totalOpenFiles).append(")");
    }
    res.append("\n Total blocks (validated):\t").append(totalBlocks);
    if (totalBlocks > 0) {
      res.append(" (avg. block size ").append((totalSize / totalBlocks)).append(" B)");
    }
    if (totalOpenFilesBlocks != 0) {
      res.append(" (Total open file blocks (not validated): ").append(totalOpenFilesBlocks).append(")");
    }
    if (corruptFiles > 0 || numUnderMinReplicatedBlocks > 0) {
      res.append("\n  ********************************");
      if (numUnderMinReplicatedBlocks > 0) {
        res.append("\n  UNDER MIN REPL'D BLOCKS:\t").append(numUnderMinReplicatedBlocks);
        if (totalBlocks > 0) {
          res.append(" (").append(((float)(numUnderMinReplicatedBlocks * 100) / (float)totalBlocks)).append(" %)");
        }
        res.append("\n  ").append(DFSConfigKeys.DFS_NAMENODE_REPLICATION_MIN_KEY + ":\t").append(minReplication);
      }
      if (corruptFiles > 0) {
        res.append("\n  CORRUPT FILES:\t").append(corruptFiles);
        if (missingSize > 0) {
          res.append("\n  MISSING BLOCKS:\t").append(missingIds.size()).append("\n  MISSING SIZE:\t\t").append(missingSize).append(" B");
        }
        if (corruptBlocks > 0) {
          res.append("\n  CORRUPT BLOCKS: \t").append(corruptBlocks);
        }
      }
      res.append("\n  ********************************");
    }
    res.append("\n Minimally replicated blocks:\t").append(numMinReplicatedBlocks);
    if (totalBlocks > 0) {
      res.append(" (").append(((float)(numMinReplicatedBlocks * 100) / (float)totalBlocks)).append(" %)");
    }
    res.append("\n Over-replicated blocks:\t").append(numOverReplicatedBlocks);
    if (totalBlocks > 0) {
      res.append(" (").append(((float)(numOverReplicatedBlocks * 100) / (float)totalBlocks)).append(" %)");
    }
    res.append("\n Under-replicated blocks:\t").append(numUnderReplicatedBlocks);
    if (totalBlocks > 0) {
      res.append(" (").append(((float)(numUnderReplicatedBlocks * 100) / (float)totalBlocks)).append(" %)");
    }
    res.append("\n Mis-replicated blocks:\t\t").append(numMisReplicatedBlocks);
    if (totalBlocks > 0) {
      res.append(" (").append(((float)(numMisReplicatedBlocks * 100) / (float)totalBlocks)).append(" %)");
    }
    res.append("\n Default replication factor:\t").append(replication).append("\n Average block replication:\t").append(getReplicationFactor()).append("\n Corrupt blocks:\t\t").append(corruptBlocks).append("\n Missing replicas:\t\t").append(missingReplicas);
    if (totalReplicas > 0) {
      res.append(" (").append(((float)(missingReplicas * 100) / (float)numExpectedReplicas)).append(" %)");
    }
    if (decommissionedReplicas > 0) {
      res.append("\n DecommissionedReplicas:\t").append(decommissionedReplicas);
    }
    if (decommissioningReplicas > 0) {
      res.append("\n DecommissioningReplicas:\t").append(decommissioningReplicas);
    }
    if (enteringMaintenanceReplicas > 0) {
      res.append("\n EnteringMaintenanceReplicas:\t").append(enteringMaintenanceReplicas);
    }
    if (inMaintenanceReplicas > 0) {
      res.append("\n InMaintenanceReplicas:\t").append(inMaintenanceReplicas);
    }
    return res.toString();
  }
}
