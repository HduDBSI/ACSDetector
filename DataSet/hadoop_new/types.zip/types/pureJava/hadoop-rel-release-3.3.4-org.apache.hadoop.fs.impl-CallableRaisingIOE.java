/** 
 * This is a callable which only raises an IOException.
 * @param < R > return type
 * @deprecated use {@link org.apache.hadoop.util.functional.CallableRaisingIOE}
 */
@FunctionalInterface public interface CallableRaisingIOE<R> {
  R apply() throws IOException ;
}
