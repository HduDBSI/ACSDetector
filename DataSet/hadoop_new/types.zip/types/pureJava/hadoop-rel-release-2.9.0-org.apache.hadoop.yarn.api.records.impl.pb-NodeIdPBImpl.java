@Private @Unstable public class NodeIdPBImpl extends NodeId {
  NodeIdProto proto=null;
  NodeIdProto.Builder builder=null;
  public NodeIdPBImpl(){
    builder=NodeIdProto.newBuilder();
  }
  public NodeIdPBImpl(  NodeIdProto proto){
    this.proto=proto;
  }
  public NodeIdProto getProto(){
    return proto;
  }
  @Override public String getHost(){
    Preconditions.checkNotNull(proto);
    return proto.getHost();
  }
  @Override protected void setHost(  String host){
    Preconditions.checkNotNull(builder);
    builder.setHost(host);
  }
  @Override public int getPort(){
    Preconditions.checkNotNull(proto);
    return proto.getPort();
  }
  @Override protected void setPort(  int port){
    Preconditions.checkNotNull(builder);
    builder.setPort(port);
  }
  @Override protected void build(){
    proto=builder.build();
    builder=null;
  }
}
