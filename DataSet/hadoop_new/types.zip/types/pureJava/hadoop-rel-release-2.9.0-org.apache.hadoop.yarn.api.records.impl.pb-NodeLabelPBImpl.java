public class NodeLabelPBImpl extends NodeLabel {
  NodeLabelProto proto=NodeLabelProto.getDefaultInstance();
  NodeLabelProto.Builder builder=null;
  boolean viaProto=false;
  public NodeLabelPBImpl(){
    builder=NodeLabelProto.newBuilder();
  }
  public NodeLabelPBImpl(  NodeLabelProto proto){
    this.proto=proto;
    viaProto=true;
  }
  public NodeLabelProto getProto(){
    mergeLocalToProto();
    proto=viaProto ? proto : builder.build();
    viaProto=true;
    return proto;
  }
  private void mergeLocalToProto(){
    if (viaProto)     maybeInitBuilder();
    proto=builder.build();
    viaProto=true;
  }
  @Override public boolean equals(  Object other){
    if (other == null)     return false;
    if (other.getClass().isAssignableFrom(this.getClass())) {
      return this.getProto().equals(this.getClass().cast(other).getProto());
    }
    return false;
  }
  private void maybeInitBuilder(){
    if (viaProto || builder == null) {
      builder=NodeLabelProto.newBuilder(proto);
    }
    viaProto=false;
  }
  @Override public int hashCode(){
    return getProto().hashCode();
  }
  @Override public String getName(){
    NodeLabelProtoOrBuilder p=viaProto ? proto : builder;
    if (!p.hasName()) {
      return null;
    }
    return (p.getName());
  }
  @Override public void setName(  String name){
    maybeInitBuilder();
    if (name == null) {
      builder.clearName();
      return;
    }
    builder.setName(name);
  }
  @Override public boolean isExclusive(){
    NodeLabelProtoOrBuilder p=viaProto ? proto : builder;
    return p.getIsExclusive();
  }
  @Override public void setExclusivity(  boolean isExclusive){
    maybeInitBuilder();
    builder.setIsExclusive(isExclusive);
  }
}
