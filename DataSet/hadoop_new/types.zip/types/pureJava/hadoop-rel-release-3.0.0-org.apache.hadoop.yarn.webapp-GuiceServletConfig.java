/** 
 * GuiceServletConfig is a wrapper class to have a static Injector instance instead of having the instance inside test classes. This allow us to use Jersey test framework after 1.13. Please check test cases to know how to use this class: e.g. TestRMWithCSRFFilter.java
 */
public class GuiceServletConfig extends GuiceServletContextListener {
  private static Injector internalInjector=null;
  @Override protected Injector getInjector(){
    return internalInjector;
  }
  public static Injector setInjector(  Injector in){
    internalInjector=in;
    return internalInjector;
  }
}
