public class TestRMEmbeddedElector extends ClientBaseWithFixes {
  private static final Log LOG=LogFactory.getLog(TestRMEmbeddedElector.class.getName());
  private static final String RM1_NODE_ID="rm1";
  private static final int RM1_PORT_BASE=10000;
  private static final String RM2_NODE_ID="rm2";
  private static final int RM2_PORT_BASE=20000;
  private Configuration conf;
  private AtomicBoolean callbackCalled;
  private void setConfForRM(  String rmId,  String prefix,  String value){
    conf.set(HAUtil.addSuffix(prefix,rmId),value);
  }
  private void setRpcAddressForRM(  String rmId,  int base){
    setConfForRM(rmId,YarnConfiguration.RM_ADDRESS,"0.0.0.0:" + (base + YarnConfiguration.DEFAULT_RM_PORT));
    setConfForRM(rmId,YarnConfiguration.RM_SCHEDULER_ADDRESS,"0.0.0.0:" + (base + YarnConfiguration.DEFAULT_RM_SCHEDULER_PORT));
    setConfForRM(rmId,YarnConfiguration.RM_ADMIN_ADDRESS,"0.0.0.0:" + (base + YarnConfiguration.DEFAULT_RM_ADMIN_PORT));
    setConfForRM(rmId,YarnConfiguration.RM_RESOURCE_TRACKER_ADDRESS,"0.0.0.0:" + (base + YarnConfiguration.DEFAULT_RM_RESOURCE_TRACKER_PORT));
    setConfForRM(rmId,YarnConfiguration.RM_WEBAPP_ADDRESS,"0.0.0.0:" + (base + YarnConfiguration.DEFAULT_RM_WEBAPP_PORT));
    setConfForRM(rmId,YarnConfiguration.RM_WEBAPP_HTTPS_ADDRESS,"0.0.0.0:" + (base + YarnConfiguration.DEFAULT_RM_WEBAPP_HTTPS_PORT));
  }
  @Before public void setup() throws IOException {
    conf=new YarnConfiguration();
    conf.setBoolean(YarnConfiguration.RM_HA_ENABLED,true);
    conf.setBoolean(YarnConfiguration.AUTO_FAILOVER_ENABLED,true);
    conf.setBoolean(YarnConfiguration.AUTO_FAILOVER_EMBEDDED,true);
    conf.set(YarnConfiguration.RM_CLUSTER_ID,"yarn-test-cluster");
    conf.set(YarnConfiguration.RM_ZK_ADDRESS,hostPort);
    conf.setInt(YarnConfiguration.RM_ZK_TIMEOUT_MS,2000);
    conf.set(YarnConfiguration.RM_HA_IDS,RM1_NODE_ID + "," + RM2_NODE_ID);
    conf.set(YarnConfiguration.RM_HA_ID,RM1_NODE_ID);
    setRpcAddressForRM(RM1_NODE_ID,RM1_PORT_BASE);
    setRpcAddressForRM(RM2_NODE_ID,RM2_PORT_BASE);
    conf.setLong(YarnConfiguration.CLIENT_FAILOVER_SLEEPTIME_BASE_MS,100L);
    callbackCalled=new AtomicBoolean(false);
  }
  /** 
 * Test that tries to see if there is a deadlock between (a) the thread stopping the RM (b) thread processing the ZK event asking RM to transition to active The test times out if there is a deadlock.
 */
  @Test(timeout=10000) public void testDeadlockShutdownBecomeActive() throws InterruptedException {
    MockRM rm=new MockRMWithElector(conf,1000);
    rm.start();
    LOG.info("Waiting for callback");
    while (!callbackCalled.get())     ;
    LOG.info("Stopping RM");
    rm.stop();
    LOG.info("Stopped RM");
  }
private class MockRMWithElector extends MockRM {
    private long delayMs=0;
    MockRMWithElector(    Configuration conf){
      super(conf);
    }
    MockRMWithElector(    Configuration conf,    long delayMs){
      this(conf);
      this.delayMs=delayMs;
    }
    @Override protected AdminService createAdminService(){
      return new AdminService(MockRMWithElector.this,getRMContext()){
        @Override protected EmbeddedElectorService createEmbeddedElectorService(){
          return new EmbeddedElectorService(getRMContext()){
            @Override public void becomeActive() throws ServiceFailedException {
              try {
                callbackCalled.set(true);
                LOG.info("Callback called. Sleeping now");
                Thread.sleep(delayMs);
                LOG.info("Sleep done");
              }
 catch (              InterruptedException e) {
                e.printStackTrace();
              }
              super.becomeActive();
            }
          }
;
        }
      }
;
    }
  }
}
