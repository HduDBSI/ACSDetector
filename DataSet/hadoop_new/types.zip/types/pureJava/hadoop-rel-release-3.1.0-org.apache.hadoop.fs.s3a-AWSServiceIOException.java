/** 
 * A specific exception from AWS operations. The exception must always be created with an  {@link AmazonServiceException}. The attributes of this exception can all be directly accessed.
 */
@InterfaceAudience.Public @InterfaceStability.Evolving public class AWSServiceIOException extends AWSClientIOException {
  /** 
 * Instantiate.
 * @param operation operation which triggered this
 * @param cause the underlying cause
 */
  public AWSServiceIOException(  String operation,  AmazonServiceException cause){
    super(operation,cause);
  }
  public AmazonServiceException getCause(){
    return (AmazonServiceException)super.getCause();
  }
  public String getRequestId(){
    return getCause().getRequestId();
  }
  public String getServiceName(){
    return getCause().getServiceName();
  }
  public String getErrorCode(){
    return getCause().getErrorCode();
  }
  public int getStatusCode(){
    return getCause().getStatusCode();
  }
  public String getRawResponseContent(){
    return getCause().getRawResponseContent();
  }
  public boolean isRetryable(){
    return getCause().isRetryable();
  }
}
