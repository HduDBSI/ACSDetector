@XmlRootElement(name="scheduler") @XmlAccessorType(XmlAccessType.FIELD) public class SchedulerTypeInfo {
  protected SchedulerInfo schedulerInfo;
  public SchedulerTypeInfo(){
  }
  public SchedulerTypeInfo(  final SchedulerInfo scheduler){
    this.schedulerInfo=scheduler;
  }
}
