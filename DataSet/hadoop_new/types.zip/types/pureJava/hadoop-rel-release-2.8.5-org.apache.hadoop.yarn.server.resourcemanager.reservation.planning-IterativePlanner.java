/** 
 * A planning algorithm consisting of two main phases. The algorithm iterates over the job stages in descending order. For each stage, the algorithm: 1. Determines an interval [stageArrivalTime, stageDeadline) in which the stage is allocated. 2. Computes an allocation for the stage inside the interval. For ANY and ALL jobs, phase 1 sets the allocation window of each stage to be [jobArrival, jobDeadline]. For ORDER and ORDER_NO_GAP jobs, the deadline of each stage is set as succcessorStartTime - the starting time of its succeeding stage (or jobDeadline if it is the last stage). The phases are set using the two functions: 1. setAlgEarliestStartTime 2. setAlgComputeStageAllocation
 */
public class IterativePlanner extends PlanningAlgorithm {
  private RLESparseResourceAllocation planModifications;
  private Map<Long,Resource> planLoads;
  private Resource capacity;
  private long step;
  private ReservationRequestInterpreter jobType;
  private long jobArrival;
  private long jobDeadline;
  private StageEarliestStart algStageEarliestStart=null;
  private StageAllocator algStageAllocator=null;
  private final boolean allocateLeft;
  public IterativePlanner(  StageEarliestStart algEarliestStartTime,  StageAllocator algStageAllocator,  boolean allocateLeft){
    this.allocateLeft=allocateLeft;
    setAlgStageEarliestStart(algEarliestStartTime);
    setAlgStageAllocator(algStageAllocator);
  }
  @Override public RLESparseResourceAllocation computeJobAllocation(  Plan plan,  ReservationId reservationId,  ReservationDefinition reservation,  String user) throws PlanningException {
    initialize(plan,reservationId,reservation);
    RLESparseResourceAllocation allocations=new RLESparseResourceAllocation(plan.getResourceCalculator());
    StageProvider stageProvider=new StageProvider(allocateLeft,reservation);
    ReservationRequest currentReservationStage;
    long stageDeadline=stepRoundDown(reservation.getDeadline(),step);
    long successorStartingTime=-1;
    long predecessorEndTime=stepRoundDown(reservation.getArrival(),step);
    long stageArrivalTime=-1;
    while (stageProvider.hasNext()) {
      currentReservationStage=stageProvider.next();
      validateInputStage(plan,currentReservationStage);
      if (allocateLeft) {
        stageArrivalTime=predecessorEndTime;
      }
 else {
        stageArrivalTime=reservation.getArrival();
        if (jobType == ReservationRequestInterpreter.R_ORDER || jobType == ReservationRequestInterpreter.R_ORDER_NO_GAP) {
          stageArrivalTime=computeEarliestStartingTime(plan,reservation,stageProvider.getCurrentIndex(),currentReservationStage,stageDeadline);
        }
        stageArrivalTime=stepRoundUp(stageArrivalTime,step);
        stageArrivalTime=Math.max(stageArrivalTime,reservation.getArrival());
      }
      Map<ReservationInterval,Resource> curAlloc=computeStageAllocation(plan,currentReservationStage,stageArrivalTime,stageDeadline,user,reservationId);
      if (curAlloc == null) {
        if (jobType == ReservationRequestInterpreter.R_ANY) {
          continue;
        }
        throw new PlanningException("The request cannot be satisfied");
      }
      Long stageStartTime=findEarliestTime(curAlloc);
      Long stageEndTime=findLatestTime(curAlloc);
      for (      Entry<ReservationInterval,Resource> entry : curAlloc.entrySet()) {
        allocations.addInterval(entry.getKey(),entry.getValue());
      }
      if (jobType == ReservationRequestInterpreter.R_ANY) {
        break;
      }
      if (jobType == ReservationRequestInterpreter.R_ORDER || jobType == ReservationRequestInterpreter.R_ORDER_NO_GAP) {
        if (jobType == ReservationRequestInterpreter.R_ORDER_NO_GAP && successorStartingTime != -1 && ((allocateLeft && predecessorEndTime < stageStartTime) || (!allocateLeft && (stageEndTime < successorStartingTime))) || (!isNonPreemptiveAllocation(curAlloc))) {
          throw new PlanningException("The allocation found does not respect ORDER_NO_GAP");
        }
        if (allocateLeft) {
          predecessorEndTime=stageEndTime;
        }
 else {
          successorStartingTime=stageStartTime;
          stageDeadline=stageStartTime;
        }
      }
    }
    if (allocations.isEmpty()) {
      throw new PlanningException("The request cannot be satisfied");
    }
    return allocations;
  }
  protected void initialize(  Plan plan,  ReservationId reservationId,  ReservationDefinition reservation) throws PlanningException {
    capacity=plan.getTotalCapacity();
    step=plan.getStep();
    jobType=reservation.getReservationRequests().getInterpreter();
    jobArrival=stepRoundUp(reservation.getArrival(),step);
    jobDeadline=stepRoundDown(reservation.getDeadline(),step);
    planModifications=new RLESparseResourceAllocation(plan.getResourceCalculator());
    if (this.algStageAllocator instanceof StageAllocatorLowCostAligned) {
      planLoads=getAllLoadsInInterval(plan,jobArrival,jobDeadline);
      ReservationAllocation oldRes=plan.getReservationById(reservationId);
      if (oldRes != null) {
        planModifications=RLESparseResourceAllocation.merge(plan.getResourceCalculator(),plan.getTotalCapacity(),planModifications,oldRes.getResourcesOverTime(),RLEOperator.subtract,jobArrival,jobDeadline);
      }
    }
  }
  private Map<Long,Resource> getAllLoadsInInterval(  Plan plan,  long startTime,  long endTime){
    Map<Long,Resource> loads=new HashMap<Long,Resource>();
    for (long t=startTime; t < endTime; t+=step) {
      Resource load=plan.getTotalCommittedResources(t);
      loads.put(t,load);
    }
    return loads;
  }
  private void validateInputStage(  Plan plan,  ReservationRequest rr) throws ContractValidationException {
    if (rr.getConcurrency() < 1) {
      throw new ContractValidationException("Gang Size should be >= 1");
    }
    if (rr.getNumContainers() <= 0) {
      throw new ContractValidationException("Num containers should be > 0");
    }
    if (rr.getNumContainers() % rr.getConcurrency() != 0) {
      throw new ContractValidationException("Parallelism must be an exact multiple of gang size");
    }
    if (Resources.greaterThan(plan.getResourceCalculator(),capacity,rr.getCapability(),plan.getMaximumAllocation())) {
      throw new ContractValidationException("Individual capability requests should not exceed cluster's " + "maxAlloc");
    }
  }
  private boolean isNonPreemptiveAllocation(  Map<ReservationInterval,Resource> curAlloc){
    Set<Long> endPoints=new HashSet<Long>(2 * curAlloc.size());
    for (    Entry<ReservationInterval,Resource> entry : curAlloc.entrySet()) {
      ReservationInterval interval=entry.getKey();
      Resource resource=entry.getValue();
      if (Resources.equals(resource,Resource.newInstance(0,0))) {
        continue;
      }
      Long left=interval.getStartTime();
      Long right=interval.getEndTime();
      if (!endPoints.contains(left)) {
        endPoints.add(left);
      }
 else {
        endPoints.remove(left);
      }
      if (!endPoints.contains(right)) {
        endPoints.add(right);
      }
 else {
        endPoints.remove(right);
      }
    }
    return (endPoints.size() == 2);
  }
  protected long computeEarliestStartingTime(  Plan plan,  ReservationDefinition reservation,  int index,  ReservationRequest currentReservationStage,  long stageDeadline){
    return algStageEarliestStart.setEarliestStartTime(plan,reservation,index,currentReservationStage,stageDeadline);
  }
  protected Map<ReservationInterval,Resource> computeStageAllocation(  Plan plan,  ReservationRequest rr,  long stageArrivalTime,  long stageDeadline,  String user,  ReservationId oldId) throws PlanningException {
    return algStageAllocator.computeStageAllocation(plan,planLoads,planModifications,rr,stageArrivalTime,stageDeadline,user,oldId);
  }
  public IterativePlanner setAlgStageEarliestStart(  StageEarliestStart alg){
    this.algStageEarliestStart=alg;
    return this;
  }
  public IterativePlanner setAlgStageAllocator(  StageAllocator alg){
    this.algStageAllocator=alg;
    return this;
  }
  /** 
 * Helper class that provide a list of ReservationRequests and iterates forward or backward depending whether we are allocating left-to-right or right-to-left.
 */
public static class StageProvider {
    private final boolean allocateLeft;
    private ListIterator<ReservationRequest> li;
    public StageProvider(    boolean allocateLeft,    ReservationDefinition reservation){
      this.allocateLeft=allocateLeft;
      int startingIndex;
      if (allocateLeft) {
        startingIndex=0;
      }
 else {
        startingIndex=reservation.getReservationRequests().getReservationResources().size();
      }
      li=reservation.getReservationRequests().getReservationResources().listIterator(startingIndex);
    }
    public boolean hasNext(){
      if (allocateLeft) {
        return li.hasNext();
      }
 else {
        return li.hasPrevious();
      }
    }
    public ReservationRequest next(){
      if (allocateLeft) {
        return li.next();
      }
 else {
        return li.previous();
      }
    }
    public int getCurrentIndex(){
      if (allocateLeft) {
        return li.nextIndex() - 1;
      }
 else {
        return li.previousIndex() + 1;
      }
    }
  }
}
