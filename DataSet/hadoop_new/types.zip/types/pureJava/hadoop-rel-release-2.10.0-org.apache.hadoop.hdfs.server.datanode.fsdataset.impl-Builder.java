/** 
 * Used for creating instances of ReservedSpaceCalculator.
 */
public static class Builder {
  private final Configuration conf;
  private DF usage;
  private StorageType storageType;
  public Builder(  Configuration conf){
    this.conf=conf;
  }
  public Builder setUsage(  DF newUsage){
    this.usage=newUsage;
    return this;
  }
  public Builder setStorageType(  StorageType newStorageType){
    this.storageType=newStorageType;
    return this;
  }
  ReservedSpaceCalculator build(){
    try {
      Class<? extends ReservedSpaceCalculator> clazz=conf.getClass(DFS_DATANODE_DU_RESERVED_CALCULATOR_KEY,DFS_DATANODE_DU_RESERVED_CALCULATOR_DEFAULT,ReservedSpaceCalculator.class);
      Constructor constructor=clazz.getConstructor(Configuration.class,DF.class,StorageType.class);
      return (ReservedSpaceCalculator)constructor.newInstance(conf,usage,storageType);
    }
 catch (    Exception e) {
      throw new IllegalStateException("Error instantiating ReservedSpaceCalculator",e);
    }
  }
}
