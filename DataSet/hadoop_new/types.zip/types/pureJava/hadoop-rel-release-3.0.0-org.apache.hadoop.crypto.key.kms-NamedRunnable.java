/** 
 * A <code>Runnable</code> which takes a string name.
 */
private abstract static class NamedRunnable implements Runnable {
  final String name;
  private AtomicBoolean canceled=new AtomicBoolean(false);
  private NamedRunnable(  String keyName){
    this.name=keyName;
  }
  public void cancel(){
    canceled.set(true);
  }
  public boolean isCanceled(){
    return canceled.get();
  }
}
