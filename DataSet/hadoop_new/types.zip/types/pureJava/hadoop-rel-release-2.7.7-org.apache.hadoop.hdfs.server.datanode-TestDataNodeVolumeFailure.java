/** 
 * Fine-grain testing of block files and locations after volume failure.
 */
public class TestDataNodeVolumeFailure {
  final private int block_size=512;
  MiniDFSCluster cluster=null;
  private Configuration conf;
  final int dn_num=2;
  final int blocks_num=30;
  final short repl=2;
  File dataDir=null;
  File data_fail=null;
  File failedDir=null;
  private FileSystem fs;
private class BlockLocs {
    public int num_files=0;
    public int num_locs=0;
  }
  final Map<String,BlockLocs> block_map=new HashMap<String,BlockLocs>();
  @Before public void setUp() throws Exception {
    conf=new HdfsConfiguration();
    conf.setLong(DFSConfigKeys.DFS_BLOCK_SIZE_KEY,block_size);
    conf.setInt(DFSConfigKeys.DFS_DATANODE_FAILED_VOLUMES_TOLERATED_KEY,1);
    cluster=new MiniDFSCluster.Builder(conf).numDataNodes(dn_num).build();
    cluster.waitActive();
    fs=cluster.getFileSystem();
    dataDir=new File(cluster.getDataDirectory());
  }
  @After public void tearDown() throws Exception {
    if (data_fail != null) {
      FileUtil.setWritable(data_fail,true);
    }
    if (failedDir != null) {
      FileUtil.setWritable(failedDir,true);
    }
    if (cluster != null) {
      cluster.shutdown();
    }
  }
  @Test public void testVolumeFailure() throws Exception {
    System.out.println("Data dir: is " + dataDir.getPath());
    String filename="/test.txt";
    Path filePath=new Path(filename);
    int filesize=block_size * blocks_num;
    DFSTestUtil.createFile(fs,filePath,filesize,repl,1L);
    DFSTestUtil.waitReplication(fs,filePath,repl);
    System.out.println("file " + filename + "(size "+ filesize+ ") is created and replicated");
    data_fail=new File(dataDir,"data3");
    failedDir=MiniDFSCluster.getFinalizedDir(dataDir,cluster.getNamesystem().getBlockPoolId());
    if (failedDir.exists() && !deteteBlocks(failedDir)) {
      throw new IOException("Could not delete hdfs directory '" + failedDir + "'");
    }
    data_fail.setReadOnly();
    failedDir.setReadOnly();
    System.out.println("Deleteing " + failedDir.getPath() + "; exist="+ failedDir.exists());
    triggerFailure(filename,filesize);
    DataNode dn=cluster.getDataNodes().get(1);
    String bpid=cluster.getNamesystem().getBlockPoolId();
    DatanodeRegistration dnR=dn.getDNRegistrationForBP(bpid);
    Map<DatanodeStorage,BlockListAsLongs> perVolumeBlockLists=dn.getFSDataset().getBlockReports(bpid);
    StorageBlockReport[] reports=new StorageBlockReport[perVolumeBlockLists.size()];
    int reportIndex=0;
    for (    Map.Entry<DatanodeStorage,BlockListAsLongs> kvPair : perVolumeBlockLists.entrySet()) {
      DatanodeStorage dnStorage=kvPair.getKey();
      BlockListAsLongs blockList=kvPair.getValue();
      reports[reportIndex++]=new StorageBlockReport(dnStorage,blockList);
    }
    cluster.getNameNodeRpc().blockReport(dnR,bpid,reports,new BlockReportContext(1,0,System.nanoTime()));
    verify(filename,filesize);
    System.out.println("creating file test1.txt");
    Path fileName1=new Path("/test1.txt");
    DFSTestUtil.createFile(fs,fileName1,filesize,repl,1L);
    DFSTestUtil.waitReplication(fs,fileName1,repl);
    System.out.println("file " + fileName1.getName() + " is created and replicated");
  }
  /** 
 * Test that DataStorage and BlockPoolSliceStorage remove the failed volume after failure.
 */
  @Test(timeout=150000) public void testFailedVolumeBeingRemovedFromDataNode() throws InterruptedException, IOException, TimeoutException {
    Path file1=new Path("/test1");
    DFSTestUtil.createFile(fs,file1,1024,(short)2,1L);
    DFSTestUtil.waitReplication(fs,file1,(short)2);
    File dn0Vol1=new File(dataDir,"data" + (2 * 0 + 1));
    DataNodeTestUtils.injectDataDirFailure(dn0Vol1);
    DataNode dn0=cluster.getDataNodes().get(0);
    long lastDiskErrorCheck=dn0.getLastDiskErrorCheck();
    dn0.checkDiskErrorAsync();
    while (dn0.getLastDiskErrorCheck() == lastDiskErrorCheck) {
      Thread.sleep(100);
    }
    DataStorage storage=dn0.getStorage();
    assertEquals(1,storage.getNumStorageDirs());
    for (int i=0; i < storage.getNumStorageDirs(); i++) {
      Storage.StorageDirectory sd=storage.getStorageDir(i);
      assertFalse(sd.getRoot().getAbsolutePath().startsWith(dn0Vol1.getAbsolutePath()));
    }
    final String bpid=cluster.getNamesystem().getBlockPoolId();
    BlockPoolSliceStorage bpsStorage=storage.getBPStorage(bpid);
    assertEquals(1,bpsStorage.getNumStorageDirs());
    for (int i=0; i < bpsStorage.getNumStorageDirs(); i++) {
      Storage.StorageDirectory sd=bpsStorage.getStorageDir(i);
      assertFalse(sd.getRoot().getAbsolutePath().startsWith(dn0Vol1.getAbsolutePath()));
    }
    FsDatasetSpi<? extends FsVolumeSpi> data=dn0.getFSDataset();
    for (    FsVolumeSpi volume : data.getVolumes()) {
      assertNotEquals(new File(volume.getBasePath()).getAbsoluteFile(),dn0Vol1.getAbsoluteFile());
    }
    for (    ReplicaInfo replica : FsDatasetTestUtil.getReplicas(data,bpid)) {
      assertNotNull(replica.getVolume());
      assertNotEquals(new File(replica.getVolume().getBasePath()).getAbsoluteFile(),dn0Vol1.getAbsoluteFile());
    }
    String[] dataDirStrs=dn0.getConf().get(DFSConfigKeys.DFS_DATANODE_DATA_DIR_KEY).split(",");
    assertEquals(1,dataDirStrs.length);
    assertFalse(dataDirStrs[0].contains(dn0Vol1.getAbsolutePath()));
  }
  /** 
 * Test that there are under replication blocks after vol failures
 */
  @Test public void testUnderReplicationAfterVolFailure() throws Exception {
    assumeTrue(!Path.WINDOWS);
    cluster.startDataNodes(conf,1,true,null,null);
    cluster.waitActive();
    final BlockManager bm=cluster.getNamesystem().getBlockManager();
    Path file1=new Path("/test1");
    DFSTestUtil.createFile(fs,file1,1024,(short)3,1L);
    DFSTestUtil.waitReplication(fs,file1,(short)3);
    File dn1Vol1=new File(dataDir,"data" + (2 * 0 + 1));
    File dn2Vol1=new File(dataDir,"data" + (2 * 1 + 1));
    DataNodeTestUtils.injectDataDirFailure(dn1Vol1,dn2Vol1);
    Path file2=new Path("/test2");
    DFSTestUtil.createFile(fs,file2,1024,(short)3,1L);
    DFSTestUtil.waitReplication(fs,file2,(short)3);
    int underReplicatedBlocks=BlockManagerTestUtil.checkHeartbeatAndGetUnderReplicatedBlocksCount(cluster.getNamesystem(),bm);
    assertTrue("There is no under replicated block after volume failure",underReplicatedBlocks > 0);
  }
  /** 
 * verifies two things: 1. number of locations of each block in the name node matches number of actual files 2. block files + pending block equals to total number of blocks that a file has  including the replication (HDFS file has 30 blocks, repl=2 - total 60
 * @param fn - file name
 * @param fs - file size
 * @throws IOException
 */
  private void verify(  String fn,  int fs) throws IOException {
    int totalReal=countRealBlocks(block_map);
    System.out.println("countRealBlocks counted " + totalReal + " blocks");
    int totalNN=countNNBlocks(block_map,fn,fs);
    System.out.println("countNNBlocks counted " + totalNN + " blocks");
    for (    String bid : block_map.keySet()) {
      BlockLocs bl=block_map.get(bid);
      assertEquals("Num files should match num locations",bl.num_files,bl.num_locs);
    }
    assertEquals("Num physical blocks should match num stored in the NN",totalReal,totalNN);
    FSNamesystem fsn=cluster.getNamesystem();
    BlockManagerTestUtil.getComputedDatanodeWork(fsn.getBlockManager());
    long underRepl=fsn.getUnderReplicatedBlocks();
    long pendRepl=fsn.getPendingReplicationBlocks();
    long totalRepl=underRepl + pendRepl;
    System.out.println("underreplicated after = " + underRepl + " and pending repl ="+ pendRepl+ "; total underRepl = "+ totalRepl);
    System.out.println("total blocks (real and replicating):" + (totalReal + totalRepl) + " vs. all files blocks "+ blocks_num * 2);
    assertEquals("Incorrect total block count",totalReal + totalRepl,blocks_num * repl);
  }
  /** 
 * go to each block on the 2nd DataNode until it fails...
 * @param path
 * @param size
 * @throws IOException
 */
  private void triggerFailure(  String path,  long size) throws IOException {
    NamenodeProtocols nn=cluster.getNameNodeRpc();
    List<LocatedBlock> locatedBlocks=nn.getBlockLocations(path,0,size).getLocatedBlocks();
    for (    LocatedBlock lb : locatedBlocks) {
      DatanodeInfo dinfo=lb.getLocations()[1];
      ExtendedBlock b=lb.getBlock();
      try {
        accessBlock(dinfo,lb);
      }
 catch (      IOException e) {
        System.out.println("Failure triggered, on block: " + b.getBlockId() + "; corresponding volume should be removed by now");
        break;
      }
    }
  }
  /** 
 * simulate failure delete all the block files
 * @param dir
 * @throws IOException
 */
  private boolean deteteBlocks(  File dir){
    File[] fileList=dir.listFiles();
    for (    File f : fileList) {
      if (f.getName().startsWith(Block.BLOCK_FILE_PREFIX)) {
        if (!f.delete())         return false;
      }
    }
    return true;
  }
  /** 
 * try to access a block on a data node. If fails - throws exception
 * @param datanode
 * @param lblock
 * @throws IOException
 */
  private void accessBlock(  DatanodeInfo datanode,  LocatedBlock lblock) throws IOException {
    InetSocketAddress targetAddr=null;
    ExtendedBlock block=lblock.getBlock();
    targetAddr=NetUtils.createSocketAddr(datanode.getXferAddr());
    BlockReader blockReader=new BlockReaderFactory(new DFSClient.Conf(conf)).setInetSocketAddress(targetAddr).setBlock(block).setFileName(BlockReaderFactory.getFileName(targetAddr,"test-blockpoolid",block.getBlockId())).setBlockToken(lblock.getBlockToken()).setStartOffset(0).setLength(-1).setVerifyChecksum(true).setClientName("TestDataNodeVolumeFailure").setDatanodeInfo(datanode).setCachingStrategy(CachingStrategy.newDefaultStrategy()).setClientCacheContext(ClientContext.getFromConf(conf)).setConfiguration(conf).setRemotePeerFactory(new RemotePeerFactory(){
      @Override public Peer newConnectedPeer(      InetSocketAddress addr,      Token<BlockTokenIdentifier> blockToken,      DatanodeID datanodeId) throws IOException {
        Peer peer=null;
        Socket sock=NetUtils.getDefaultSocketFactory(conf).createSocket();
        try {
          sock.connect(addr,HdfsServerConstants.READ_TIMEOUT);
          sock.setSoTimeout(HdfsServerConstants.READ_TIMEOUT);
          peer=TcpPeerServer.peerFromSocket(sock);
        }
  finally {
          if (peer == null) {
            IOUtils.closeSocket(sock);
          }
        }
        return peer;
      }
    }
).build();
    blockReader.close();
  }
  /** 
 * Count datanodes that have copies of the blocks for a file put it into the map
 * @param map
 * @param path
 * @param size
 * @return
 * @throws IOException
 */
  private int countNNBlocks(  Map<String,BlockLocs> map,  String path,  long size) throws IOException {
    int total=0;
    NamenodeProtocols nn=cluster.getNameNodeRpc();
    List<LocatedBlock> locatedBlocks=nn.getBlockLocations(path,0,size).getLocatedBlocks();
    for (    LocatedBlock lb : locatedBlocks) {
      String blockId="" + lb.getBlock().getBlockId();
      DatanodeInfo[] dn_locs=lb.getLocations();
      BlockLocs bl=map.get(blockId);
      if (bl == null) {
        bl=new BlockLocs();
      }
      total+=dn_locs.length;
      bl.num_locs+=dn_locs.length;
      map.put(blockId,bl);
    }
    return total;
  }
  /** 
 * look for real blocks by counting *.meta files in all the storage dirs 
 * @param map
 * @return
 */
  private int countRealBlocks(  Map<String,BlockLocs> map){
    int total=0;
    final String bpid=cluster.getNamesystem().getBlockPoolId();
    for (int i=0; i < dn_num; i++) {
      for (int j=0; j <= 1; j++) {
        File storageDir=cluster.getInstanceStorageDir(i,j);
        File dir=MiniDFSCluster.getFinalizedDir(storageDir,bpid);
        if (dir == null) {
          System.out.println("dir is null for dn=" + i + " and data_dir="+ j);
          continue;
        }
        List<File> res=MiniDFSCluster.getAllBlockMetadataFiles(dir);
        if (res == null) {
          System.out.println("res is null for dir = " + dir + " i="+ i+ " and j="+ j);
          continue;
        }
        for (        File f : res) {
          String s=f.getName();
          assertNotNull("Block file name should not be null",s);
          String bid=s.substring(s.indexOf("_") + 1,s.lastIndexOf("_"));
          BlockLocs val=map.get(bid);
          if (val == null) {
            val=new BlockLocs();
          }
          val.num_files++;
          map.put(bid,val);
        }
        total+=res.size();
      }
    }
    return total;
  }
}
