/** 
 * Interface to query streams for supported capabilities.
 */
@InterfaceAudience.Public @InterfaceStability.Evolving public interface StreamCapabilities {
  /** 
 * Capabilities that a stream can support and be queried for.
 */
  enum StreamCapability {  /** 
 * Stream hflush capability to flush out the data in client's buffer. Streams with this capability implement  {@link Syncable} and support{@link Syncable#hflush()}.
 */
  HFLUSH("hflush"),   /** 
 * Stream hsync capability to flush out the data in client's buffer and the disk device. Streams with this capability implement  {@link Syncable}and support  {@link Syncable#hsync()}.
 */
  HSYNC("hsync");   private final String capability;
  StreamCapability(  String value){
    this.capability=value;
  }
  public final String getValue(){
    return capability;
  }
}
  /** 
 * Query the stream for a specific capability.
 * @param capability string to query the stream support for.
 * @return True if the stream supports capability.
 */
  boolean hasCapability(  String capability);
}
