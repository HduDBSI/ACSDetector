/** 
 * Test delete operation.
 */
public class ITestAzureBlobFileSystemDelete extends AbstractAbfsIntegrationTest {
  private static final int REDUCED_RETRY_COUNT=1;
  private static final int REDUCED_MAX_BACKOFF_INTERVALS_MS=5000;
  public ITestAzureBlobFileSystemDelete() throws Exception {
    super();
  }
  @Test public void testDeleteRoot() throws Exception {
    final AzureBlobFileSystem fs=getFileSystem();
    fs.mkdirs(new Path("/testFolder0"));
    fs.mkdirs(new Path("/testFolder1"));
    fs.mkdirs(new Path("/testFolder2"));
    touch(new Path("/testFolder1/testfile"));
    touch(new Path("/testFolder1/testfile2"));
    touch(new Path("/testFolder1/testfile3"));
    Path root=new Path("/");
    FileStatus[] ls=fs.listStatus(root);
    assertEquals(3,ls.length);
    fs.delete(root,true);
    ls=fs.listStatus(root);
    assertEquals("listing size",0,ls.length);
  }
  @Test() public void testOpenFileAfterDelete() throws Exception {
    final AzureBlobFileSystem fs=getFileSystem();
    Path testfile=new Path("/testFile");
    touch(testfile);
    assertDeleted(fs,testfile,false);
    intercept(FileNotFoundException.class,() -> fs.open(testfile));
  }
  @Test public void testEnsureFileIsDeleted() throws Exception {
    final AzureBlobFileSystem fs=getFileSystem();
    Path testfile=new Path("testfile");
    touch(testfile);
    assertDeleted(fs,testfile,false);
    assertPathDoesNotExist(fs,"deleted",testfile);
  }
  @Test public void testDeleteDirectory() throws Exception {
    final AzureBlobFileSystem fs=getFileSystem();
    Path dir=new Path("testfile");
    fs.mkdirs(dir);
    fs.mkdirs(new Path("testfile/test1"));
    fs.mkdirs(new Path("testfile/test1/test2"));
    assertDeleted(fs,dir,true);
    assertPathDoesNotExist(fs,"deleted",dir);
  }
  @Test public void testDeleteFirstLevelDirectory() throws Exception {
    final AzureBlobFileSystem fs=getFileSystem();
    final List<Future<Void>> tasks=new ArrayList<>();
    ExecutorService es=Executors.newFixedThreadPool(10);
    for (int i=0; i < 1000; i++) {
      final Path fileName=new Path("/test/" + i);
      Callable<Void> callable=new Callable<Void>(){
        @Override public Void call() throws Exception {
          touch(fileName);
          return null;
        }
      }
;
      tasks.add(es.submit(callable));
    }
    for (    Future<Void> task : tasks) {
      task.get();
    }
    es.shutdownNow();
    Path dir=new Path("/test");
    fs.registerListener(new TracingHeaderValidator(fs.getAbfsStore().getAbfsConfiguration().getClientCorrelationId(),fs.getFileSystemId(),FSOperationType.DELETE,false,0));
    intercept(FileAlreadyExistsException.class,() -> fs.delete(dir,false));
    fs.registerListener(null);
    assertDeleted(fs,dir,true);
    assertPathDoesNotExist(fs,"deleted",dir);
  }
  @Test public void testDeleteIdempotency() throws Exception {
    Assume.assumeTrue(DEFAULT_DELETE_CONSIDERED_IDEMPOTENT);
    AbfsConfiguration abfsConfig=TestAbfsConfigurationFieldsValidation.updateRetryConfigs(getConfiguration(),REDUCED_RETRY_COUNT,REDUCED_MAX_BACKOFF_INTERVALS_MS);
    final AzureBlobFileSystem fs=getFileSystem();
    AbfsClient abfsClient=fs.getAbfsStore().getClient();
    AbfsClient testClient=TestAbfsClient.createTestClientFromCurrentContext(abfsClient,abfsConfig);
    AbfsRestOperation op=mock(AbfsRestOperation.class);
    when(op.isARetriedRequest()).thenReturn(true);
    AbfsHttpOperation http404Op=mock(AbfsHttpOperation.class);
    when(http404Op.getStatusCode()).thenReturn(HTTP_NOT_FOUND);
    when(op.getResult()).thenReturn(http404Op);
    when(op.hasResult()).thenReturn(true);
    Assertions.assertThat(testClient.deleteIdempotencyCheckOp(op).getResult().getStatusCode()).describedAs("Delete is considered idempotent by default and should return success.").isEqualTo(HTTP_OK);
    AbfsHttpOperation http400Op=mock(AbfsHttpOperation.class);
    when(http400Op.getStatusCode()).thenReturn(HTTP_BAD_REQUEST);
    when(op.getResult()).thenReturn(http400Op);
    when(op.hasResult()).thenReturn(true);
    Assertions.assertThat(testClient.deleteIdempotencyCheckOp(op).getResult().getStatusCode()).describedAs("Idempotency check to happen only for HTTP 404 response.").isEqualTo(HTTP_BAD_REQUEST);
  }
  @Test public void testDeleteIdempotencyTriggerHttp404() throws Exception {
    final AzureBlobFileSystem fs=getFileSystem();
    AbfsClient client=TestAbfsClient.createTestClientFromCurrentContext(fs.getAbfsStore().getClient(),this.getConfiguration());
    intercept(AbfsRestOperationException.class,() -> fs.getAbfsStore().delete(new Path("/NonExistingPath"),false,getTestTracingContext(fs,false)));
    intercept(AbfsRestOperationException.class,() -> client.deletePath("/NonExistingPath",false,null,getTestTracingContext(fs,true)));
    AbfsClient mockClient=TestAbfsClient.getMockAbfsClient(fs.getAbfsStore().getClient(),this.getConfiguration());
    AzureBlobFileSystemStore mockStore=mock(AzureBlobFileSystemStore.class);
    mockStore=TestMockHelpers.setClassField(AzureBlobFileSystemStore.class,mockStore,"client",mockClient);
    mockStore=TestMockHelpers.setClassField(AzureBlobFileSystemStore.class,mockStore,"abfsPerfTracker",TestAbfsPerfTracker.getAPerfTrackerInstance(this.getConfiguration()));
    doCallRealMethod().when(mockStore).delete(new Path("/NonExistingPath"),false,getTestTracingContext(fs,false));
    AbfsRestOperation idempotencyRetOp=TestAbfsClient.getRestOp(DeletePath,mockClient,HTTP_METHOD_DELETE,TestAbfsClient.getTestUrl(mockClient,"/NonExistingPath"),TestAbfsClient.getTestRequestHeaders(mockClient));
    idempotencyRetOp.hardSetResult(HTTP_OK);
    doReturn(idempotencyRetOp).when(mockClient).deleteIdempotencyCheckOp(any());
    TracingContext tracingContext=getTestTracingContext(fs,false);
    when(mockClient.deletePath("/NonExistingPath",false,null,tracingContext)).thenCallRealMethod();
    Assertions.assertThat(mockClient.deletePath("/NonExistingPath",false,null,tracingContext).getResult().getStatusCode()).describedAs("Idempotency check reports successful " + "delete. 200OK should be returned").isEqualTo(idempotencyRetOp.getResult().getStatusCode());
    mockStore.delete(new Path("/NonExistingPath"),false,getTestTracingContext(fs,false));
  }
}
