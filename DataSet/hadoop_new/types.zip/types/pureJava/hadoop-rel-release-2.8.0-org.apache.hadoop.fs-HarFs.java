public class HarFs extends DelegateToFileSystem {
  HarFs(  final URI theUri,  final Configuration conf) throws IOException, URISyntaxException {
    super(theUri,new HarFileSystem(),conf,"har",false);
  }
  @Override public int getUriDefaultPort(){
    return -1;
  }
}
