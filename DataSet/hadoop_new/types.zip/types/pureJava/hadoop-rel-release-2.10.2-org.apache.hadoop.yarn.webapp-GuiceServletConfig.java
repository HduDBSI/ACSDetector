public class GuiceServletConfig extends GuiceServletContextListener {
  @Override protected Injector getInjector(){
    return injector;
  }
}
