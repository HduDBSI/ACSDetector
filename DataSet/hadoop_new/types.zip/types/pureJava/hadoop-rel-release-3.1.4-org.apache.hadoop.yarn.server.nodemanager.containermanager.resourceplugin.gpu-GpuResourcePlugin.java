public class GpuResourcePlugin implements ResourcePlugin {
  private static final Logger LOG=LoggerFactory.getLogger(GpuResourcePlugin.class);
  private final GpuNodeResourceUpdateHandler resourceDiscoverHandler;
  private final GpuDiscoverer gpuDiscoverer;
  private GpuResourceHandlerImpl gpuResourceHandler=null;
  private DockerCommandPlugin dockerCommandPlugin=null;
  public GpuResourcePlugin(  GpuNodeResourceUpdateHandler resourceDiscoverHandler,  GpuDiscoverer gpuDiscoverer){
    this.resourceDiscoverHandler=resourceDiscoverHandler;
    this.gpuDiscoverer=gpuDiscoverer;
  }
  @Override public void initialize(  Context context) throws YarnException {
    this.gpuDiscoverer.initialize(context.getConf());
    this.dockerCommandPlugin=GpuDockerCommandPluginFactory.createGpuDockerCommandPlugin(context.getConf());
  }
  @Override public ResourceHandler createResourceHandler(  Context context,  CGroupsHandler cGroupsHandler,  PrivilegedOperationExecutor privilegedOperationExecutor){
    if (gpuResourceHandler == null) {
      gpuResourceHandler=new GpuResourceHandlerImpl(context,cGroupsHandler,privilegedOperationExecutor,gpuDiscoverer);
    }
    return gpuResourceHandler;
  }
  @Override public NodeResourceUpdaterPlugin getNodeResourceHandlerInstance(){
    return resourceDiscoverHandler;
  }
  @Override public void cleanup() throws YarnException {
  }
  public DockerCommandPlugin getDockerCommandPluginInstance(){
    return dockerCommandPlugin;
  }
  @Override public synchronized NMResourceInfo getNMResourceInfo() throws YarnException {
    GpuDeviceInformation gpuDeviceInformation=gpuDiscoverer.getGpuDeviceInformation();
    checkGpuResourceHandler();
    GpuResourceAllocator gpuResourceAllocator=gpuResourceHandler.getGpuAllocator();
    List<GpuDevice> totalGpus=gpuResourceAllocator.getAllowedGpus();
    List<AssignedGpuDevice> assignedGpuDevices=gpuResourceAllocator.getAssignedGpus();
    return new NMGpuResourceInfo(gpuDeviceInformation,totalGpus,assignedGpuDevices);
  }
  private void checkGpuResourceHandler() throws YarnException {
    if (gpuResourceHandler == null) {
      String errorMsg="Linux Container Executor is not configured for the NodeManager. " + "To fully enable GPU feature on the node also set " + YarnConfiguration.NM_CONTAINER_EXECUTOR + " properly.";
      LOG.warn(errorMsg);
      throw new YarnException(errorMsg);
    }
  }
  @Override public String toString(){
    return GpuResourcePlugin.class.getName();
  }
}
