public class SubmarineRuntimeException extends RuntimeException {
  public SubmarineRuntimeException(  String s){
    super(s);
  }
  public SubmarineRuntimeException(  String message,  Throwable cause){
    super(message,cause);
  }
}
