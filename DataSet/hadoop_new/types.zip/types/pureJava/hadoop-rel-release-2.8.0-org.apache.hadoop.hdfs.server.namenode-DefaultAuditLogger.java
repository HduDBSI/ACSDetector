/** 
 * Default AuditLogger implementation; used when no access logger is defined in the config file. It can also be explicitly listed in the config file.
 */
@VisibleForTesting static class DefaultAuditLogger extends HdfsAuditLogger {
  private static final ThreadLocal<StringBuilder> STRING_BUILDER=new ThreadLocal<StringBuilder>(){
    @Override protected StringBuilder initialValue(){
      return new StringBuilder();
    }
  }
;
  private boolean isCallerContextEnabled;
  private int callerContextMaxLen;
  private int callerSignatureMaxLen;
  private boolean logTokenTrackingId;
  private Set<String> debugCmdSet=new HashSet<String>();
  @Override public void initialize(  Configuration conf){
    isCallerContextEnabled=conf.getBoolean(HADOOP_CALLER_CONTEXT_ENABLED_KEY,HADOOP_CALLER_CONTEXT_ENABLED_DEFAULT);
    callerContextMaxLen=conf.getInt(HADOOP_CALLER_CONTEXT_MAX_SIZE_KEY,HADOOP_CALLER_CONTEXT_MAX_SIZE_DEFAULT);
    callerSignatureMaxLen=conf.getInt(HADOOP_CALLER_CONTEXT_SIGNATURE_MAX_SIZE_KEY,HADOOP_CALLER_CONTEXT_SIGNATURE_MAX_SIZE_DEFAULT);
    logTokenTrackingId=conf.getBoolean(DFSConfigKeys.DFS_NAMENODE_AUDIT_LOG_TOKEN_TRACKING_ID_KEY,DFSConfigKeys.DFS_NAMENODE_AUDIT_LOG_TOKEN_TRACKING_ID_DEFAULT);
    debugCmdSet.addAll(Arrays.asList(conf.getTrimmedStrings(DFSConfigKeys.DFS_NAMENODE_AUDIT_LOG_DEBUG_CMDLIST)));
  }
  @Override public void logAuditEvent(  boolean succeeded,  String userName,  InetAddress addr,  String cmd,  String src,  String dst,  FileStatus status,  CallerContext callerContext,  UserGroupInformation ugi,  DelegationTokenSecretManager dtSecretManager){
    if (auditLog.isDebugEnabled() || (auditLog.isInfoEnabled() && !debugCmdSet.contains(cmd))) {
      final StringBuilder sb=STRING_BUILDER.get();
      src=escapeJava(src);
      dst=escapeJava(dst);
      sb.setLength(0);
      sb.append("allowed=").append(succeeded).append("\t");
      sb.append("ugi=").append(userName).append("\t");
      sb.append("ip=").append(addr).append("\t");
      sb.append("cmd=").append(cmd).append("\t");
      sb.append("src=").append(src).append("\t");
      sb.append("dst=").append(dst).append("\t");
      if (null == status) {
        sb.append("perm=null");
      }
 else {
        sb.append("perm=");
        sb.append(status.getOwner()).append(":");
        sb.append(status.getGroup()).append(":");
        sb.append(status.getPermission());
      }
      if (logTokenTrackingId) {
        sb.append("\t").append("trackingId=");
        String trackingId=null;
        if (ugi != null && dtSecretManager != null && ugi.getAuthenticationMethod() == AuthenticationMethod.TOKEN) {
          for (          TokenIdentifier tid : ugi.getTokenIdentifiers()) {
            if (tid instanceof DelegationTokenIdentifier) {
              DelegationTokenIdentifier dtid=(DelegationTokenIdentifier)tid;
              trackingId=dtSecretManager.getTokenTrackingId(dtid);
              break;
            }
          }
        }
        sb.append(trackingId);
      }
      sb.append("\t").append("proto=");
      sb.append(Server.getProtocol());
      if (isCallerContextEnabled && callerContext != null && callerContext.isContextValid()) {
        sb.append("\t").append("callerContext=");
        if (callerContext.getContext().length() > callerContextMaxLen) {
          sb.append(callerContext.getContext().substring(0,callerContextMaxLen));
        }
 else {
          sb.append(callerContext.getContext());
        }
        if (callerContext.getSignature() != null && callerContext.getSignature().length > 0 && callerContext.getSignature().length <= callerSignatureMaxLen) {
          sb.append(":");
          sb.append(new String(callerContext.getSignature(),CallerContext.SIGNATURE_ENCODING));
        }
      }
      logAuditMessage(sb.toString());
    }
  }
  @Override public void logAuditEvent(  boolean succeeded,  String userName,  InetAddress addr,  String cmd,  String src,  String dst,  FileStatus status,  UserGroupInformation ugi,  DelegationTokenSecretManager dtSecretManager){
    this.logAuditEvent(succeeded,userName,addr,cmd,src,dst,status,null,ugi,dtSecretManager);
  }
  public void logAuditMessage(  String message){
    auditLog.info(message);
  }
}
