/** 
 * IOException equivalent of an  {@link AmazonClientException}.
 */
public class AWSClientIOException extends IOException {
  private final String operation;
  public AWSClientIOException(  String operation,  SdkBaseException cause){
    super(cause);
    Preconditions.checkArgument(operation != null,"Null 'operation' argument");
    Preconditions.checkArgument(cause != null,"Null 'cause' argument");
    this.operation=operation;
  }
  public AmazonClientException getCause(){
    return (AmazonClientException)super.getCause();
  }
  @Override public String getMessage(){
    return operation + ": " + getCause().getMessage();
  }
}
