/** 
 * Contains allowed and denied devices Denied devices will be useful for cgroups devices module to do blacklisting
 */
static class GpuAllocation {
  private Set<GpuDevice> allowed=Collections.emptySet();
  private Set<GpuDevice> denied=Collections.emptySet();
  GpuAllocation(  Set<GpuDevice> allowed,  Set<GpuDevice> denied){
    if (allowed != null) {
      this.allowed=ImmutableSet.copyOf(allowed);
    }
    if (denied != null) {
      this.denied=ImmutableSet.copyOf(denied);
    }
  }
  public Set<GpuDevice> getAllowedGPUs(){
    return allowed;
  }
  public Set<GpuDevice> getDeniedGPUs(){
    return denied;
  }
}
