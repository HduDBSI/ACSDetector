@Private @Unstable public class PreemptionResourceRequestPBImpl extends PreemptionResourceRequest {
  PreemptionResourceRequestProto proto=PreemptionResourceRequestProto.getDefaultInstance();
  PreemptionResourceRequestProto.Builder builder=null;
  boolean viaProto=false;
  private ResourceRequest rr;
  public PreemptionResourceRequestPBImpl(){
    builder=PreemptionResourceRequestProto.newBuilder();
  }
  public PreemptionResourceRequestPBImpl(  PreemptionResourceRequestProto proto){
    this.proto=proto;
    viaProto=true;
  }
  public synchronized PreemptionResourceRequestProto getProto(){
    mergeLocalToProto();
    proto=viaProto ? proto : builder.build();
    viaProto=true;
    return proto;
  }
  @Override public int hashCode(){
    return getProto().hashCode();
  }
  @Override public boolean equals(  Object other){
    if (other == null)     return false;
    if (other.getClass().isAssignableFrom(this.getClass())) {
      return this.getProto().equals(this.getClass().cast(other).getProto());
    }
    return false;
  }
  @Override public String toString(){
    return TextFormat.shortDebugString(getProto());
  }
  private void mergeLocalToProto(){
    if (viaProto)     maybeInitBuilder();
    mergeLocalToBuilder();
    proto=builder.build();
    viaProto=true;
  }
  private void mergeLocalToBuilder(){
    if (rr != null) {
      builder.setResource(convertToProtoFormat(rr));
    }
  }
  private void maybeInitBuilder(){
    if (viaProto || builder == null) {
      builder=PreemptionResourceRequestProto.newBuilder(proto);
    }
    viaProto=false;
  }
  @Override public synchronized ResourceRequest getResourceRequest(){
    PreemptionResourceRequestProtoOrBuilder p=viaProto ? proto : builder;
    if (rr != null) {
      return rr;
    }
    if (!p.hasResource()) {
      return null;
    }
    rr=convertFromProtoFormat(p.getResource());
    return rr;
  }
  @Override public synchronized void setResourceRequest(  final ResourceRequest rr){
    maybeInitBuilder();
    if (null == rr) {
      builder.clearResource();
    }
    this.rr=rr;
  }
  private ResourceRequestPBImpl convertFromProtoFormat(  ResourceRequestProto p){
    return new ResourceRequestPBImpl(p);
  }
  private ResourceRequestProto convertToProtoFormat(  ResourceRequest t){
    return ((ResourceRequestPBImpl)t).getProto();
  }
}
