/** 
 * {@link PolicyProvider} for YARN NodeManager protocols.
 */
@InterfaceAudience.Private @InterfaceStability.Unstable public class NMPolicyProvider extends PolicyProvider {
  private static NMPolicyProvider nmPolicyProvider=null;
  private NMPolicyProvider(){
  }
  @InterfaceAudience.Private @InterfaceStability.Unstable public static NMPolicyProvider getInstance(){
    if (nmPolicyProvider == null) {
synchronized (NMPolicyProvider.class) {
        if (nmPolicyProvider == null) {
          nmPolicyProvider=new NMPolicyProvider();
        }
      }
    }
    return nmPolicyProvider;
  }
  private static final Service[] NODE_MANAGER_SERVICES=new Service[]{new Service(YarnConfiguration.YARN_SECURITY_SERVICE_AUTHORIZATION_CONTAINER_MANAGEMENT_PROTOCOL,ContainerManagementProtocolPB.class),new Service(YarnConfiguration.YARN_SECURITY_SERVICE_AUTHORIZATION_RESOURCE_LOCALIZER,LocalizationProtocolPB.class),new Service(YarnConfiguration.YARN_SECURITY_SERVICE_AUTHORIZATION_COLLECTOR_NODEMANAGER_PROTOCOL,CollectorNodemanagerProtocolPB.class),new Service(YarnConfiguration.YARN_SECURITY_SERVICE_AUTHORIZATION_APPLICATIONMASTER_NODEMANAGER_PROTOCOL,ApplicationMasterProtocolPB.class)};
  @Override public Service[] getServices(){
    return NODE_MANAGER_SERVICES;
  }
}
