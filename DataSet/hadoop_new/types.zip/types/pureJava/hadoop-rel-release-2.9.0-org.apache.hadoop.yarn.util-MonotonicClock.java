/** 
 * A monotonic clock from some arbitrary time base in the past, counting in milliseconds, and not affected by settimeofday or similar system clock changes. This is appropriate to use when computing how much longer to wait for an interval to expire. This function can return a negative value and it must be handled correctly by callers. See the documentation of System#nanoTime for caveats.
 */
@Public @Evolving public class MonotonicClock implements Clock {
  /** 
 * Get current time from some arbitrary time base in the past, counting in milliseconds, and not affected by settimeofday or similar system clock changes.
 * @return a monotonic clock that counts in milliseconds.
 */
  public long getTime(){
    return Time.monotonicNow();
  }
}
