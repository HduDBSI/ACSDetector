public interface NodeResourceMonitor extends Service {
}
