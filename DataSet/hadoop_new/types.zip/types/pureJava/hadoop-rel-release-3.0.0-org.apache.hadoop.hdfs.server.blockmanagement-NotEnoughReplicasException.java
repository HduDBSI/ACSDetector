@InterfaceAudience.Private public static class NotEnoughReplicasException extends Exception {
  private static final long serialVersionUID=1L;
  NotEnoughReplicasException(  String msg){
    super(msg);
  }
}
