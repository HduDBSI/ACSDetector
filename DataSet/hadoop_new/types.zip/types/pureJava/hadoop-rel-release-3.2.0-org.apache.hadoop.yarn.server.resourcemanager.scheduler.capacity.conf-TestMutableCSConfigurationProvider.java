/** 
 * Tests  {@link MutableCSConfigurationProvider}.
 */
public class TestMutableCSConfigurationProvider {
  private MutableCSConfigurationProvider confProvider;
  private RMContext rmContext;
  private SchedConfUpdateInfo goodUpdate;
  private SchedConfUpdateInfo badUpdate;
  private CapacityScheduler cs;
  private AdminService adminService;
  private static final UserGroupInformation TEST_USER=UserGroupInformation.createUserForTesting("testUser",new String[]{});
  @Before public void setUp(){
    cs=mock(CapacityScheduler.class);
    rmContext=mock(RMContext.class);
    when(rmContext.getScheduler()).thenReturn(cs);
    when(cs.getConfiguration()).thenReturn(new CapacitySchedulerConfiguration());
    adminService=mock(AdminService.class);
    when(rmContext.getRMAdminService()).thenReturn(adminService);
    confProvider=new MutableCSConfigurationProvider(rmContext);
    goodUpdate=new SchedConfUpdateInfo();
    Map<String,String> goodUpdateMap=new HashMap<>();
    goodUpdateMap.put("goodKey","goodVal");
    QueueConfigInfo goodUpdateInfo=new QueueConfigInfo("root.a",goodUpdateMap);
    goodUpdate.getUpdateQueueInfo().add(goodUpdateInfo);
    badUpdate=new SchedConfUpdateInfo();
    Map<String,String> badUpdateMap=new HashMap<>();
    badUpdateMap.put("badKey","badVal");
    QueueConfigInfo badUpdateInfo=new QueueConfigInfo("root.a",badUpdateMap);
    badUpdate.getUpdateQueueInfo().add(badUpdateInfo);
  }
  @Test public void testInMemoryBackedProvider() throws Exception {
    Configuration conf=new Configuration();
    conf.set(YarnConfiguration.SCHEDULER_CONFIGURATION_STORE_CLASS,YarnConfiguration.MEMORY_CONFIGURATION_STORE);
    confProvider.init(conf);
    assertNull(confProvider.loadConfiguration(conf).get("yarn.scheduler.capacity.root.a.goodKey"));
    confProvider.logAndApplyMutation(TEST_USER,goodUpdate);
    confProvider.confirmPendingMutation(true);
    assertEquals("goodVal",confProvider.loadConfiguration(conf).get("yarn.scheduler.capacity.root.a.goodKey"));
    assertNull(confProvider.loadConfiguration(conf).get("yarn.scheduler.capacity.root.a.badKey"));
    confProvider.logAndApplyMutation(TEST_USER,badUpdate);
    confProvider.confirmPendingMutation(false);
    assertNull(confProvider.loadConfiguration(conf).get("yarn.scheduler.capacity.root.a.badKey"));
  }
  @Test public void testHDFSBackedProvider() throws Exception {
    File testSchedulerConfigurationDir=new File(TestMutableCSConfigurationProvider.class.getResource("").getPath() + TestMutableCSConfigurationProvider.class.getSimpleName());
    FileUtils.deleteDirectory(testSchedulerConfigurationDir);
    testSchedulerConfigurationDir.mkdirs();
    Configuration conf=new Configuration(false);
    conf.set(YarnConfiguration.SCHEDULER_CONFIGURATION_STORE_CLASS,YarnConfiguration.FS_CONFIGURATION_STORE);
    conf.set(YarnConfiguration.SCHEDULER_CONFIGURATION_FS_PATH,testSchedulerConfigurationDir.getAbsolutePath());
    writeConf(conf,testSchedulerConfigurationDir.getAbsolutePath());
    confProvider.init(conf);
    assertNull(confProvider.loadConfiguration(conf).get("yarn.scheduler.capacity.root.a.goodKey"));
    confProvider.logAndApplyMutation(TEST_USER,goodUpdate);
    confProvider.confirmPendingMutation(true);
    assertEquals("goodVal",confProvider.loadConfiguration(conf).get("yarn.scheduler.capacity.root.a.goodKey"));
    assertNull(confProvider.loadConfiguration(conf).get("yarn.scheduler.capacity.root.a.badKey"));
    confProvider.logAndApplyMutation(TEST_USER,badUpdate);
    confProvider.confirmPendingMutation(false);
    assertNull(confProvider.loadConfiguration(conf).get("yarn.scheduler.capacity.root.a.badKey"));
  }
  private void writeConf(  Configuration conf,  String storePath) throws IOException {
    FileSystem fileSystem=FileSystem.get(new Configuration(conf));
    String schedulerConfigurationFile=YarnConfiguration.CS_CONFIGURATION_FILE + "." + System.currentTimeMillis();
    try (FSDataOutputStream outputStream=fileSystem.create(new Path(storePath,schedulerConfigurationFile))){
      conf.writeXml(outputStream);
    }
   }
}
