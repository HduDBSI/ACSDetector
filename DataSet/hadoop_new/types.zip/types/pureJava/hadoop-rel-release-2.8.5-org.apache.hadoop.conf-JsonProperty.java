static class JsonProperty {
  String key;
  public String getKey(){
    return key;
  }
  public void setKey(  String key){
    this.key=key;
  }
  public String getValue(){
    return value;
  }
  public void setValue(  String value){
    this.value=value;
  }
  public boolean getIsFinal(){
    return isFinal;
  }
  public void setIsFinal(  boolean isFinal){
    this.isFinal=isFinal;
  }
  public String getResource(){
    return resource;
  }
  public void setResource(  String resource){
    this.resource=resource;
  }
  String value;
  boolean isFinal;
  String resource;
}
