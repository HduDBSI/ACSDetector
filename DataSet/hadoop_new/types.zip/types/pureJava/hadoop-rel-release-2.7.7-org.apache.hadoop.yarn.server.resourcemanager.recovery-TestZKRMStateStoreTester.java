class TestZKRMStateStoreTester implements RMStateStoreHelper {
  ZooKeeper client;
  TestZKRMStateStoreInternal store;
  String workingZnode="/jira/issue/3077/rmstore";
class TestZKRMStateStoreInternal extends ZKRMStateStore {
    public TestZKRMStateStoreInternal(    Configuration conf,    String workingZnode) throws Exception {
      init(conf);
      start();
      assertEquals(workingZnode,znodeWorkingPath);
    }
    @Override public ZooKeeper getNewZooKeeper() throws IOException {
      return client;
    }
    public String getVersionNode(){
      return znodeWorkingPath + "/" + ROOT_ZNODE_NAME+ "/"+ VERSION_NODE;
    }
    public Version getCurrentVersion(){
      return CURRENT_VERSION_INFO;
    }
    public String getAppNode(    String appId){
      return workingZnode + "/" + ROOT_ZNODE_NAME+ "/"+ RM_APP_ROOT+ "/"+ appId;
    }
  }
  public RMStateStore getRMStateStore(  ZooKeeper zk) throws Exception {
    YarnConfiguration conf=new YarnConfiguration();
    conf.set(YarnConfiguration.RM_ZK_ADDRESS,hostPort);
    conf.set(YarnConfiguration.ZK_RM_STATE_STORE_PARENT_PATH,workingZnode);
    if (null == zk) {
      this.client=createClient();
    }
 else {
      this.client=zk;
    }
    this.store=new TestZKRMStateStoreInternal(conf,workingZnode);
    return this.store;
  }
  public String getWorkingZNode(){
    return workingZnode;
  }
  public RMStateStore getRMStateStore() throws Exception {
    return getRMStateStore(null);
  }
  @Override public boolean isFinalStateValid() throws Exception {
    List<String> nodes=client.getChildren(store.znodeWorkingPath,false);
    return nodes.size() == 1;
  }
  @Override public void writeVersion(  Version version) throws Exception {
    client.setData(store.getVersionNode(),((VersionPBImpl)version).getProto().toByteArray(),-1);
  }
  @Override public Version getCurrentVersion() throws Exception {
    return store.getCurrentVersion();
  }
  public boolean appExists(  RMApp app) throws Exception {
    Stat node=client.exists(store.getAppNode(app.getApplicationId().toString()),false);
    return node != null;
  }
}
