/** 
 * Exception caused in a container runtime impl. 'Runtime' is not used in the class name to avoid confusion with a java RuntimeException
 */
@InterfaceAudience.Private @InterfaceStability.Unstable public class ContainerExecutionException extends YarnException {
  private static final long serialVersionUID=1L;
  private static final int EXIT_CODE_UNSET=-1;
  private static final String OUTPUT_UNSET="<unknown>";
  private int exitCode;
  private String output;
  private String errorOutput;
  public ContainerExecutionException(  String message){
    super(message);
    exitCode=EXIT_CODE_UNSET;
    output=OUTPUT_UNSET;
    errorOutput=OUTPUT_UNSET;
  }
  public ContainerExecutionException(  Throwable throwable){
    super(throwable);
    exitCode=EXIT_CODE_UNSET;
    output=OUTPUT_UNSET;
    errorOutput=OUTPUT_UNSET;
  }
  public ContainerExecutionException(  String message,  int exitCode,  String output,  String errorOutput){
    super(message);
    this.exitCode=exitCode;
    this.output=output;
    this.errorOutput=errorOutput;
  }
  public ContainerExecutionException(  Throwable cause,  int exitCode,  String output,  String errorOutput){
    super(cause);
    this.exitCode=exitCode;
    this.output=output;
    this.errorOutput=errorOutput;
  }
  public int getExitCode(){
    return exitCode;
  }
  public String getOutput(){
    return output;
  }
  public String getErrorOutput(){
    return errorOutput;
  }
}
