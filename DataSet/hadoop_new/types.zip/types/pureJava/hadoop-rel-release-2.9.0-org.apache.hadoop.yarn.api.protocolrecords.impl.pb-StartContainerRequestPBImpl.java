@Private @Unstable public class StartContainerRequestPBImpl extends StartContainerRequest {
  StartContainerRequestProto proto=StartContainerRequestProto.getDefaultInstance();
  StartContainerRequestProto.Builder builder=null;
  boolean viaProto=false;
  private ContainerLaunchContext containerLaunchContext=null;
  private Token containerToken=null;
  public StartContainerRequestPBImpl(){
    builder=StartContainerRequestProto.newBuilder();
  }
  public StartContainerRequestPBImpl(  StartContainerRequestProto proto){
    this.proto=proto;
    viaProto=true;
  }
  public StartContainerRequestProto getProto(){
    mergeLocalToProto();
    proto=viaProto ? proto : builder.build();
    viaProto=true;
    return proto;
  }
  @Override public int hashCode(){
    return getProto().hashCode();
  }
  @Override public boolean equals(  Object other){
    if (other == null)     return false;
    if (other.getClass().isAssignableFrom(this.getClass())) {
      return this.getProto().equals(this.getClass().cast(other).getProto());
    }
    return false;
  }
  @Override public String toString(){
    return TextFormat.shortDebugString(getProto());
  }
  private void mergeLocalToBuilder(){
    if (this.containerLaunchContext != null) {
      builder.setContainerLaunchContext(convertToProtoFormat(this.containerLaunchContext));
    }
    if (this.containerToken != null) {
      builder.setContainerToken(convertToProtoFormat(this.containerToken));
    }
  }
  private void mergeLocalToProto(){
    if (viaProto)     maybeInitBuilder();
    mergeLocalToBuilder();
    proto=builder.build();
    viaProto=true;
  }
  private void maybeInitBuilder(){
    if (viaProto || builder == null) {
      builder=StartContainerRequestProto.newBuilder(proto);
    }
    viaProto=false;
  }
  @Override public ContainerLaunchContext getContainerLaunchContext(){
    StartContainerRequestProtoOrBuilder p=viaProto ? proto : builder;
    if (this.containerLaunchContext != null) {
      return this.containerLaunchContext;
    }
    if (!p.hasContainerLaunchContext()) {
      return null;
    }
    this.containerLaunchContext=convertFromProtoFormat(p.getContainerLaunchContext());
    return this.containerLaunchContext;
  }
  @Override public void setContainerLaunchContext(  ContainerLaunchContext containerLaunchContext){
    maybeInitBuilder();
    if (containerLaunchContext == null)     builder.clearContainerLaunchContext();
    this.containerLaunchContext=containerLaunchContext;
  }
  @Override public Token getContainerToken(){
    StartContainerRequestProtoOrBuilder p=viaProto ? proto : builder;
    if (this.containerToken != null) {
      return this.containerToken;
    }
    if (!p.hasContainerToken()) {
      return null;
    }
    this.containerToken=convertFromProtoFormat(p.getContainerToken());
    return this.containerToken;
  }
  @Override public void setContainerToken(  Token containerToken){
    maybeInitBuilder();
    if (containerToken == null) {
      builder.clearContainerToken();
    }
    this.containerToken=containerToken;
  }
  private ContainerLaunchContextPBImpl convertFromProtoFormat(  ContainerLaunchContextProto p){
    return new ContainerLaunchContextPBImpl(p);
  }
  private ContainerLaunchContextProto convertToProtoFormat(  ContainerLaunchContext t){
    return ((ContainerLaunchContextPBImpl)t).getProto();
  }
  private TokenPBImpl convertFromProtoFormat(  TokenProto containerProto){
    return new TokenPBImpl(containerProto);
  }
  private TokenProto convertToProtoFormat(  Token container){
    return ((TokenPBImpl)container).getProto();
  }
}
