/** 
 * This tests InterDataNodeProtocol for block handling. 
 */
public class TestNamenodeCapacityReport {
  private static final Log LOG=LogFactory.getLog(TestNamenodeCapacityReport.class);
  /** 
 * The following test first creates a file. It verifies the block information from a datanode. Then, it updates the block with new information and verifies again. 
 */
  @Test public void testVolumeSize() throws Exception {
    Configuration conf=new HdfsConfiguration();
    MiniDFSCluster cluster=null;
    long reserved=10000;
    conf.setLong(DFSConfigKeys.DFS_DATANODE_DU_RESERVED_KEY,reserved);
    try {
      cluster=new MiniDFSCluster.Builder(conf).build();
      cluster.waitActive();
      final FSNamesystem namesystem=cluster.getNamesystem();
      final DatanodeManager dm=cluster.getNamesystem().getBlockManager().getDatanodeManager();
      final List<DatanodeDescriptor> live=new ArrayList<DatanodeDescriptor>();
      final List<DatanodeDescriptor> dead=new ArrayList<DatanodeDescriptor>();
      dm.fetchDatanodes(live,dead,false);
      assertTrue(live.size() == 1);
      long used, remaining, configCapacity, nonDFSUsed, bpUsed;
      float percentUsed, percentRemaining, percentBpUsed;
      for (      final DatanodeDescriptor datanode : live) {
        used=datanode.getDfsUsed();
        remaining=datanode.getRemaining();
        nonDFSUsed=datanode.getNonDfsUsed();
        configCapacity=datanode.getCapacity();
        percentUsed=datanode.getDfsUsedPercent();
        percentRemaining=datanode.getRemainingPercent();
        bpUsed=datanode.getBlockPoolUsed();
        percentBpUsed=datanode.getBlockPoolUsedPercent();
        LOG.info("Datanode configCapacity " + configCapacity + " used "+ used+ " non DFS used "+ nonDFSUsed+ " remaining "+ remaining+ " perentUsed "+ percentUsed+ " percentRemaining "+ percentRemaining);
        assertTrue(configCapacity == (used + remaining + nonDFSUsed));
        assertTrue(percentUsed == DFSUtil.getPercentUsed(used,configCapacity));
        assertTrue(percentRemaining == DFSUtil.getPercentRemaining(remaining,configCapacity));
        assertTrue(percentBpUsed == DFSUtil.getPercentUsed(bpUsed,configCapacity));
      }
      DF df=new DF(new File(cluster.getDataDirectory()),conf);
      int numOfDataDirs=2;
      long diskCapacity=numOfDataDirs * df.getCapacity();
      reserved*=numOfDataDirs;
      configCapacity=namesystem.getCapacityTotal();
      used=namesystem.getCapacityUsed();
      nonDFSUsed=namesystem.getNonDfsUsedSpace();
      remaining=namesystem.getCapacityRemaining();
      percentUsed=namesystem.getPercentUsed();
      percentRemaining=namesystem.getPercentRemaining();
      bpUsed=namesystem.getBlockPoolUsedSpace();
      percentBpUsed=namesystem.getPercentBlockPoolUsed();
      LOG.info("Data node directory " + cluster.getDataDirectory());
      LOG.info("Name node diskCapacity " + diskCapacity + " configCapacity "+ configCapacity+ " reserved "+ reserved+ " used "+ used+ " remaining "+ remaining+ " nonDFSUsed "+ nonDFSUsed+ " remaining "+ remaining+ " percentUsed "+ percentUsed+ " percentRemaining "+ percentRemaining+ " bpUsed "+ bpUsed+ " percentBpUsed "+ percentBpUsed);
      assertTrue(configCapacity == diskCapacity - reserved);
      assertTrue(configCapacity == (used + remaining + nonDFSUsed));
      assertTrue(percentUsed == DFSUtil.getPercentUsed(used,configCapacity));
      assertTrue(percentBpUsed == DFSUtil.getPercentUsed(bpUsed,configCapacity));
      assertTrue(percentRemaining == ((float)remaining * 100.0f) / (float)configCapacity);
    }
  finally {
      if (cluster != null) {
        cluster.shutdown();
      }
    }
  }
  private static final float EPSILON=0.0001f;
  @Test public void testXceiverCount() throws Exception {
    Configuration conf=new HdfsConfiguration();
    conf.setInt(DFS_CLIENT_BLOCK_WRITE_LOCATEFOLLOWINGBLOCK_RETRIES_KEY,1);
    MiniDFSCluster cluster=null;
    final int nodes=8;
    final int fileCount=5;
    final short fileRepl=3;
    try {
      cluster=new MiniDFSCluster.Builder(conf).numDataNodes(nodes).build();
      cluster.waitActive();
      final FSNamesystem namesystem=cluster.getNamesystem();
      final DatanodeManager dnm=namesystem.getBlockManager().getDatanodeManager();
      List<DataNode> datanodes=cluster.getDataNodes();
      final DistributedFileSystem fs=cluster.getFileSystem();
      triggerHeartbeats(datanodes);
      int expectedTotalLoad=nodes;
      int expectedInServiceNodes=nodes;
      int expectedInServiceLoad=nodes;
      checkClusterHealth(nodes,namesystem,expectedTotalLoad,expectedInServiceNodes,expectedInServiceLoad);
      for (int i=0; i < nodes / 2; i++) {
        DataNode dn=datanodes.get(i);
        DatanodeDescriptor dnd=dnm.getDatanode(dn.getDatanodeId());
        dn.shutdown();
        DFSTestUtil.setDatanodeDead(dnd);
        BlockManagerTestUtil.checkHeartbeat(namesystem.getBlockManager());
        dnm.getDecomManager().startDecommission(dnd);
        expectedInServiceNodes--;
        assertEquals(expectedInServiceNodes,namesystem.getNumLiveDataNodes());
        assertEquals(expectedInServiceNodes,getNumDNInService(namesystem));
        dnm.getDecomManager().stopDecommission(dnd);
        assertEquals(expectedInServiceNodes,getNumDNInService(namesystem));
      }
      cluster.restartDataNodes();
      cluster.waitActive();
      datanodes=cluster.getDataNodes();
      expectedInServiceNodes=nodes;
      assertEquals(nodes,datanodes.size());
      checkClusterHealth(nodes,namesystem,expectedTotalLoad,expectedInServiceNodes,expectedInServiceLoad);
      DFSOutputStream[] streams=new DFSOutputStream[fileCount];
      for (int i=0; i < fileCount; i++) {
        streams[i]=(DFSOutputStream)fs.create(new Path("/f" + i),fileRepl).getWrappedStream();
        streams[i].write("1".getBytes());
        streams[i].hsync();
        expectedTotalLoad+=2 * fileRepl;
        expectedInServiceLoad+=2 * fileRepl;
      }
      triggerHeartbeats(datanodes);
      checkClusterHealth(nodes,namesystem,expectedTotalLoad,expectedInServiceNodes,expectedInServiceLoad);
      for (int i=0; i < fileRepl; i++) {
        expectedInServiceNodes--;
        DatanodeDescriptor dnd=dnm.getDatanode(datanodes.get(i).getDatanodeId());
        expectedInServiceLoad-=dnd.getXceiverCount();
        dnm.getDecomManager().startDecommission(dnd);
        DataNodeTestUtils.triggerHeartbeat(datanodes.get(i));
        Thread.sleep(100);
        checkClusterHealth(nodes,namesystem,expectedTotalLoad,expectedInServiceNodes,expectedInServiceLoad);
      }
      for (int i=0; i < fileCount; i++) {
        int decomm=0;
        for (        DatanodeInfo dni : streams[i].getPipeline()) {
          DatanodeDescriptor dnd=dnm.getDatanode(dni);
          expectedTotalLoad-=2;
          if (dnd.isDecommissionInProgress() || dnd.isDecommissioned()) {
            decomm++;
          }
 else {
            expectedInServiceLoad-=2;
          }
        }
        try {
          streams[i].close();
        }
 catch (        IOException ioe) {
          if (decomm < fileRepl) {
            throw ioe;
          }
        }
        triggerHeartbeats(datanodes);
        checkClusterHealth(nodes,namesystem,expectedTotalLoad,expectedInServiceNodes,expectedInServiceLoad);
      }
      for (int i=0; i < nodes; i++) {
        DataNode dn=datanodes.get(i);
        dn.shutdown();
        DatanodeDescriptor dnDesc=dnm.getDatanode(dn.getDatanodeId());
        DFSTestUtil.setDatanodeDead(dnDesc);
        BlockManagerTestUtil.checkHeartbeat(namesystem.getBlockManager());
        assertEquals(nodes - 1 - i,namesystem.getNumLiveDataNodes());
        if (i >= fileRepl) {
          expectedInServiceNodes--;
        }
        assertEquals(expectedInServiceNodes,getNumDNInService(namesystem));
        double expectedXceiverAvg=(i == nodes - 1) ? 0.0 : 1.0;
        assertEquals((double)expectedXceiverAvg,getInServiceXceiverAverage(namesystem),EPSILON);
      }
      checkClusterHealth(0,namesystem,0.0,0,0.0);
    }
  finally {
      if (cluster != null) {
        cluster.shutdown();
      }
    }
  }
  private static void checkClusterHealth(  int numOfLiveNodes,  FSNamesystem namesystem,  double expectedTotalLoad,  int expectedInServiceNodes,  double expectedInServiceLoad){
    assertEquals(numOfLiveNodes,namesystem.getNumLiveDataNodes());
    assertEquals(expectedInServiceNodes,getNumDNInService(namesystem));
    assertEquals(expectedTotalLoad,namesystem.getTotalLoad(),EPSILON);
    if (expectedInServiceNodes != 0) {
      assertEquals(expectedInServiceLoad / expectedInServiceNodes,getInServiceXceiverAverage(namesystem),EPSILON);
    }
 else {
      assertEquals(0.0,getInServiceXceiverAverage(namesystem),EPSILON);
    }
  }
  private static int getNumDNInService(  FSNamesystem fsn){
    return fsn.getBlockManager().getDatanodeManager().getFSClusterStats().getNumDatanodesInService();
  }
  private static double getInServiceXceiverAverage(  FSNamesystem fsn){
    return fsn.getBlockManager().getDatanodeManager().getFSClusterStats().getInServiceXceiverAverage();
  }
  private void triggerHeartbeats(  List<DataNode> datanodes) throws IOException, InterruptedException {
    for (    DataNode dn : datanodes) {
      DataNodeTestUtils.triggerHeartbeat(dn);
    }
    Thread.sleep(100);
  }
}
