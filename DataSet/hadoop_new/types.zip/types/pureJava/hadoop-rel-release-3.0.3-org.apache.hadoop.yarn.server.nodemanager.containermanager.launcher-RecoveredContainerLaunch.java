/** 
 * This is a ContainerLaunch which has been recovered after an NM restart (for rolling upgrades).
 */
public class RecoveredContainerLaunch extends ContainerLaunch {
  private static final Logger LOG=LoggerFactory.getLogger(RecoveredContainerLaunch.class);
  public RecoveredContainerLaunch(  Context context,  Configuration configuration,  Dispatcher dispatcher,  ContainerExecutor exec,  Application app,  Container container,  LocalDirsHandlerService dirsHandler,  ContainerManagerImpl containerManager){
    super(context,configuration,dispatcher,exec,app,container,dirsHandler,containerManager);
    this.containerAlreadyLaunched.set(true);
  }
  /** 
 * Wait on the process specified in pid file and return its exit code
 */
  @SuppressWarnings("unchecked") @Override public Integer call(){
    int retCode=ExitCode.LOST.getExitCode();
    ContainerId containerId=container.getContainerId();
    String appIdStr=containerId.getApplicationAttemptId().getApplicationId().toString();
    String containerIdStr=containerId.toString();
    dispatcher.getEventHandler().handle(new ContainerEvent(containerId,ContainerEventType.CONTAINER_LAUNCHED));
    boolean notInterrupted=true;
    try {
      File pidFile=locatePidFile(appIdStr,containerIdStr);
      if (pidFile != null) {
        String pidPathStr=pidFile.getPath();
        pidFilePath=new Path(pidPathStr);
        exec.activateContainer(containerId,pidFilePath);
        retCode=exec.reacquireContainer(new ContainerReacquisitionContext.Builder().setContainer(container).setUser(container.getUser()).setContainerId(containerId).build());
      }
 else {
        LOG.warn("Unable to locate pid file for container " + containerIdStr);
      }
    }
 catch (    InterruptedException|InterruptedIOException e) {
      LOG.warn("Interrupted while waiting for exit code from " + containerId);
      notInterrupted=false;
    }
catch (    IOException e) {
      LOG.error("Unable to recover container " + containerIdStr,e);
    }
 finally {
      if (notInterrupted) {
        this.completed.set(true);
        exec.deactivateContainer(containerId);
        try {
          getContext().getNMStateStore().storeContainerCompleted(containerId,retCode);
        }
 catch (        IOException e) {
          LOG.error("Unable to set exit code for container " + containerId);
        }
      }
    }
    if (retCode != 0) {
      LOG.warn("Recovered container exited with a non-zero exit code " + retCode);
      this.dispatcher.getEventHandler().handle(new ContainerExitEvent(containerId,ContainerEventType.CONTAINER_EXITED_WITH_FAILURE,retCode,"Container exited with a non-zero exit code " + retCode));
      return retCode;
    }
    LOG.info("Recovered container " + containerId + " succeeded");
    dispatcher.getEventHandler().handle(new ContainerEvent(containerId,ContainerEventType.CONTAINER_EXITED_WITH_SUCCESS));
    return 0;
  }
  private File locatePidFile(  String appIdStr,  String containerIdStr){
    String pidSubpath=getPidFileSubpath(appIdStr,containerIdStr);
    for (    String dir : getContext().getLocalDirsHandler().getLocalDirsForRead()) {
      File pidFile=new File(dir,pidSubpath);
      if (pidFile.exists()) {
        return pidFile;
      }
    }
    return null;
  }
}
