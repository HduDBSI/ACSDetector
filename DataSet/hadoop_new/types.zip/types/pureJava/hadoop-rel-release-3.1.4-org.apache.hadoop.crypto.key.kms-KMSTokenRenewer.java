/** 
 * The KMS implementation of  {@link TokenRenewer}.
 */
public static class KMSTokenRenewer extends TokenRenewer {
  private static final Logger LOG=LoggerFactory.getLogger(KMSTokenRenewer.class);
  @Override public boolean handleKind(  Text kind){
    return kind.equals(TOKEN_KIND);
  }
  @Override public boolean isManaged(  Token<?> token) throws IOException {
    return true;
  }
  @Override public long renew(  Token<?> token,  Configuration conf) throws IOException {
    LOG.debug("Renewing delegation token {}",token);
    KeyProvider keyProvider=createKeyProvider(token,conf);
    try {
      if (!(keyProvider instanceof KeyProviderDelegationTokenExtension.DelegationTokenExtension)) {
        throw new IOException(String.format("keyProvider %s cannot renew token [%s]",keyProvider == null ? "null" : keyProvider.getClass(),token));
      }
      return ((KeyProviderDelegationTokenExtension.DelegationTokenExtension)keyProvider).renewDelegationToken(token);
    }
  finally {
      if (keyProvider != null) {
        keyProvider.close();
      }
    }
  }
  @Override public void cancel(  Token<?> token,  Configuration conf) throws IOException {
    LOG.debug("Canceling delegation token {}",token);
    KeyProvider keyProvider=createKeyProvider(token,conf);
    try {
      if (!(keyProvider instanceof KeyProviderDelegationTokenExtension.DelegationTokenExtension)) {
        throw new IOException(String.format("keyProvider %s cannot cancel token [%s]",keyProvider == null ? "null" : keyProvider.getClass(),token));
      }
      ((KeyProviderDelegationTokenExtension.DelegationTokenExtension)keyProvider).cancelDelegationToken(token);
    }
  finally {
      if (keyProvider != null) {
        keyProvider.close();
      }
    }
  }
  private static KeyProvider createKeyProvider(  Token<?> token,  Configuration conf) throws IOException {
    String service=token.getService().toString();
    URI uri;
    if (service != null && service.startsWith(SCHEME_NAME + ":/")) {
      LOG.debug("Creating key provider with token service value {}",service);
      uri=URI.create(service);
    }
 else {
      uri=KMSUtil.getKeyProviderUri(conf);
    }
    return (uri != null) ? KMSUtil.createKeyProviderFromUri(conf,uri) : null;
  }
}
