@InterfaceAudience.LimitedPrivate({"YARN","MapReduce"}) public class BadRequestException extends WebApplicationException {
  private static final long serialVersionUID=1L;
  public BadRequestException(){
    super(Status.BAD_REQUEST);
  }
  public BadRequestException(  java.lang.Throwable cause){
    super(cause,Status.BAD_REQUEST);
  }
  public BadRequestException(  String msg){
    super(new Exception(msg),Status.BAD_REQUEST);
  }
}
