/** 
 * {@link ReservationListResponsePBImpl} is the implementation of the{@link ReservationListResponse} which captures  the list of reservationsthat the user has queried.
 */
public class ReservationListResponsePBImpl extends ReservationListResponse {
  private ReservationListResponseProto proto=ReservationListResponseProto.getDefaultInstance();
  private ReservationListResponseProto.Builder builder=null;
  private boolean viaProto=false;
  private List<ReservationAllocationState> reservations;
  public ReservationListResponsePBImpl(){
    builder=ReservationListResponseProto.newBuilder();
  }
  public ReservationListResponsePBImpl(  ReservationListResponseProto proto){
    this.proto=proto;
    viaProto=true;
  }
  public ReservationListResponseProto getProto(){
    if (viaProto) {
      mergeLocalToProto();
    }
 else {
      proto=builder.build();
    }
    viaProto=true;
    return proto;
  }
  private void maybeInitBuilder(){
    if (viaProto || builder == null) {
      builder=ReservationListResponseProto.newBuilder(proto);
    }
    viaProto=false;
  }
  @Override public List<ReservationAllocationState> getReservationAllocationState(){
    initReservations();
    mergeLocalToProto();
    return this.reservations;
  }
  @Override public void setReservationAllocationState(  List<ReservationAllocationState> newReservations){
    if (newReservations == null) {
      builder.clearReservations();
      return;
    }
    reservations=newReservations;
    mergeLocalToProto();
  }
  private void mergeLocalToBuilder(){
    if (this.reservations != null) {
      int size=reservations.size();
      builder.clearReservations();
      for (int i=0; i < size; i++) {
        builder.addReservations(i,convertToProtoFormat(reservations.get(i)));
      }
    }
  }
  private void mergeLocalToProto(){
    if (viaProto) {
      maybeInitBuilder();
    }
    mergeLocalToBuilder();
    proto=builder.build();
    viaProto=true;
  }
  private ReservationAllocationStatePBImpl convertFromProtoFormat(  ReservationAllocationStateProto p){
    return new ReservationAllocationStatePBImpl(p);
  }
  private ReservationAllocationStateProto convertToProtoFormat(  ReservationAllocationState r){
    return ((ReservationAllocationStatePBImpl)r).getProto();
  }
  private void initReservations(){
    if (this.reservations != null) {
      return;
    }
    ReservationListResponseProtoOrBuilder p=viaProto ? proto : builder;
    List<ReservationAllocationStateProto> reservationProtos=p.getReservationsList();
    reservations=new ArrayList<>();
    for (    ReservationAllocationStateProto r : reservationProtos) {
      reservations.add(convertFromProtoFormat(r));
    }
  }
  @Override public String toString(){
    return TextFormat.shortDebugString(getProto());
  }
  @Override public boolean equals(  Object other){
    if (other == null) {
      return false;
    }
    if (other.getClass().isAssignableFrom(this.getClass())) {
      return this.getProto().equals(this.getClass().cast(other).getProto());
    }
    return false;
  }
  @Override public int hashCode(){
    return getProto().hashCode();
  }
}
