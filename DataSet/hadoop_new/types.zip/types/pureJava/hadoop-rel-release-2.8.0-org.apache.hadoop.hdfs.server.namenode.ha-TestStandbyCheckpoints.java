public class TestStandbyCheckpoints {
  private static final int NUM_DIRS_IN_LOG=200000;
  protected MiniDFSCluster cluster;
  protected NameNode nn0, nn1;
  protected FileSystem fs;
  private final Random random=new Random();
  protected File tmpOivImgDir;
  private static final Log LOG=LogFactory.getLog(TestStandbyCheckpoints.class);
  @SuppressWarnings("rawtypes") @Before public void setupCluster() throws Exception {
    Configuration conf=setupCommonConfig();
    conf.setInt(DFSConfigKeys.DFS_NAMENODE_NUM_CHECKPOINTS_RETAINED_KEY,1);
    conf.setInt(DFSConfigKeys.DFS_NAMENODE_NUM_EXTRA_EDITS_RETAINED_KEY,0);
    int retryCount=0;
    while (true) {
      try {
        int basePort=10060 + random.nextInt(100) * 2;
        MiniDFSNNTopology topology=new MiniDFSNNTopology().addNameservice(new MiniDFSNNTopology.NSConf("ns1").addNN(new MiniDFSNNTopology.NNConf("nn1").setHttpPort(basePort)).addNN(new MiniDFSNNTopology.NNConf("nn2").setHttpPort(basePort + 1)));
        cluster=new MiniDFSCluster.Builder(conf).nnTopology(topology).numDataNodes(1).build();
        cluster.waitActive();
        nn0=cluster.getNameNode(0);
        nn1=cluster.getNameNode(1);
        fs=HATestUtil.configureFailoverFs(cluster,conf);
        cluster.transitionToActive(0);
        ++retryCount;
        break;
      }
 catch (      BindException e) {
        LOG.info("Set up MiniDFSCluster failed due to port conflicts, retry " + retryCount + " times");
      }
    }
  }
  protected Configuration setupCommonConfig(){
    tmpOivImgDir=Files.createTempDir();
    Configuration conf=new Configuration();
    conf.setInt(DFSConfigKeys.DFS_NAMENODE_CHECKPOINT_CHECK_PERIOD_KEY,1);
    conf.setInt(DFSConfigKeys.DFS_NAMENODE_CHECKPOINT_TXNS_KEY,5);
    conf.setInt(DFSConfigKeys.DFS_HA_TAILEDITS_PERIOD_KEY,1);
    conf.set(DFSConfigKeys.DFS_NAMENODE_LEGACY_OIV_IMAGE_DIR_KEY,tmpOivImgDir.getAbsolutePath());
    conf.setBoolean(DFSConfigKeys.DFS_IMAGE_COMPRESS_KEY,true);
    conf.set(DFSConfigKeys.DFS_IMAGE_COMPRESSION_CODEC_KEY,SlowCodec.class.getCanonicalName());
    CompressionCodecFactory.setCodecClasses(conf,ImmutableList.<Class>of(SlowCodec.class));
    return conf;
  }
  @After public void shutdownCluster() throws IOException {
    if (cluster != null) {
      cluster.shutdown();
      cluster=null;
    }
  }
  @Test(timeout=300000) public void testSBNCheckpoints() throws Exception {
    JournalSet standbyJournalSet=NameNodeAdapter.spyOnJournalSet(nn1);
    doEdits(0,10);
    HATestUtil.waitForStandbyToCatchUp(nn0,nn1);
    HATestUtil.waitForCheckpoint(cluster,1,ImmutableList.of(12));
    GenericTestUtils.waitFor(new Supplier<Boolean>(){
      @Override public Boolean get(){
        if (tmpOivImgDir.list().length > 0) {
          return true;
        }
 else {
          return false;
        }
      }
    }
,1000,60000);
    assertEquals("One file is expected",1,tmpOivImgDir.list().length);
    HATestUtil.waitForCheckpoint(cluster,0,ImmutableList.of(12));
    Mockito.verify(standbyJournalSet,Mockito.never()).purgeLogsOlderThan(Mockito.anyLong());
  }
  /** 
 * Test for the case when both of the NNs in the cluster are in the standby state, and thus are both creating checkpoints and uploading them to each other. In this circumstance, they should receive the error from the other node indicating that the other node already has a checkpoint for the given txid, but this should not cause an abort, etc.
 */
  @Test(timeout=300000) public void testBothNodesInStandbyState() throws Exception {
    doEdits(0,10);
    cluster.transitionToStandby(0);
    HATestUtil.waitForCheckpoint(cluster,1,ImmutableList.of(12));
    HATestUtil.waitForCheckpoint(cluster,0,ImmutableList.of(12));
    assertEquals(12,nn0.getNamesystem().getFSImage().getMostRecentCheckpointTxId());
    assertEquals(12,nn1.getNamesystem().getFSImage().getMostRecentCheckpointTxId());
    List<File> dirs=Lists.newArrayList();
    dirs.addAll(FSImageTestUtil.getNameNodeCurrentDirs(cluster,0));
    dirs.addAll(FSImageTestUtil.getNameNodeCurrentDirs(cluster,1));
    FSImageTestUtil.assertParallelFilesAreIdentical(dirs,ImmutableSet.<String>of());
  }
  /** 
 * Test for the case when the SBN is configured to checkpoint based on a time period, but no transactions are happening on the active. Thus, it would want to save a second checkpoint at the same txid, which is a no-op. This test makes sure this doesn't cause any problem.
 */
  @Test(timeout=300000) public void testCheckpointWhenNoNewTransactionsHappened() throws Exception {
    cluster.getConfiguration(1).setInt(DFSConfigKeys.DFS_NAMENODE_CHECKPOINT_PERIOD_KEY,0);
    cluster.restartNameNode(1);
    nn1=cluster.getNameNode(1);
    FSImage spyImage1=NameNodeAdapter.spyOnFsImage(nn1);
    Thread.sleep(1000);
    Mockito.verify(spyImage1,Mockito.never()).saveNamespace((FSNamesystem)Mockito.anyObject());
    HATestUtil.waitForStandbyToCatchUp(nn0,nn1);
    Thread.sleep(2000);
    Mockito.verify(spyImage1,Mockito.times(1)).saveNamespace((FSNamesystem)Mockito.anyObject(),Mockito.eq(NameNodeFile.IMAGE),(Canceler)Mockito.anyObject());
  }
  /** 
 * Test cancellation of ongoing checkpoints when failover happens mid-checkpoint. 
 */
  @Test(timeout=120000) public void testCheckpointCancellation() throws Exception {
    cluster.transitionToStandby(0);
    URI sharedUri=cluster.getSharedEditsDir(0,1);
    File sharedDir=new File(sharedUri.getPath(),"current");
    File tmpDir=new File(MiniDFSCluster.getBaseDirectory(),"testCheckpointCancellation-tmp");
    FSNamesystem fsn=cluster.getNamesystem(0);
    FSImageTestUtil.createAbortedLogWithMkdirs(tmpDir,NUM_DIRS_IN_LOG,3,fsn.getFSDirectory().getLastInodeId() + 1);
    String fname=NNStorage.getInProgressEditsFileName(3);
    new File(tmpDir,fname).renameTo(new File(sharedDir,fname));
    cluster.getConfiguration(1).setInt(DFSConfigKeys.DFS_NAMENODE_CHECKPOINT_PERIOD_KEY,0);
    cluster.restartNameNode(1);
    nn1=cluster.getNameNode(1);
    cluster.transitionToActive(0);
    boolean canceledOne=false;
    for (int i=0; i < 10 && !canceledOne; i++) {
      doEdits(i * 10,i * 10 + 10);
      cluster.transitionToStandby(0);
      cluster.transitionToActive(1);
      cluster.transitionToStandby(1);
      cluster.transitionToActive(0);
      canceledOne=StandbyCheckpointer.getCanceledCount() > 0;
    }
    assertTrue(canceledOne);
  }
  /** 
 * Test cancellation of ongoing checkpoints when failover happens mid-checkpoint during image upload from standby to active NN.
 */
  @Test(timeout=60000) public void testCheckpointCancellationDuringUpload() throws Exception {
    cluster.getConfiguration(0).setInt(DFSConfigKeys.DFS_NAMENODE_CHECKPOINT_TXNS_KEY,1000);
    cluster.getConfiguration(0).setBoolean(DFSConfigKeys.DFS_IMAGE_COMPRESS_KEY,false);
    cluster.getConfiguration(1).setBoolean(DFSConfigKeys.DFS_IMAGE_COMPRESS_KEY,false);
    cluster.getConfiguration(1).setLong(DFSConfigKeys.DFS_IMAGE_TRANSFER_RATE_KEY,100);
    cluster.restartNameNode(0);
    cluster.restartNameNode(1);
    nn0=cluster.getNameNode(0);
    nn1=cluster.getNameNode(1);
    cluster.transitionToActive(0);
    doEdits(0,100);
    HATestUtil.waitForStandbyToCatchUp(nn0,nn1);
    HATestUtil.waitForCheckpoint(cluster,1,ImmutableList.of(104));
    cluster.transitionToStandby(0);
    cluster.transitionToActive(1);
    cluster.shutdown();
    cluster=null;
    GenericTestUtils.waitFor(new Supplier<Boolean>(){
      @Override public Boolean get(){
        ThreadMXBean threadBean=ManagementFactory.getThreadMXBean();
        ThreadInfo[] threads=threadBean.getThreadInfo(threadBean.getAllThreadIds(),1);
        for (        ThreadInfo thread : threads) {
          if (thread.getThreadName().startsWith("TransferFsImageUpload")) {
            return false;
          }
        }
        return true;
      }
    }
,1000,30000);
    assertEquals(0,nn0.getFSImage().getMostRecentCheckpointTxId());
  }
  /** 
 * Make sure that clients will receive StandbyExceptions even when a checkpoint is in progress on the SBN, and therefore the StandbyCheckpointer thread will have FSNS lock. Regression test for HDFS-4591.
 */
  @Test(timeout=300000) public void testStandbyExceptionThrownDuringCheckpoint() throws Exception {
    FSImage spyImage1=NameNodeAdapter.spyOnFsImage(nn1);
    DelayAnswer answerer=new DelayAnswer(LOG);
    Mockito.doAnswer(answerer).when(spyImage1).saveNamespace(Mockito.any(FSNamesystem.class),Mockito.eq(NameNodeFile.IMAGE),Mockito.any(Canceler.class));
    doEdits(0,1000);
    nn0.getRpcServer().rollEditLog();
    answerer.waitForCall();
    assertTrue("SBN is not performing checkpoint but it should be.",answerer.getFireCount() == 1 && answerer.getResultCount() == 0);
    ThreadUtil.sleepAtLeastIgnoreInterrupts(1000);
    try {
      nn1.getRpcServer().getFileInfo("/");
      fail("Should have thrown StandbyException, but instead succeeded.");
    }
 catch (    StandbyException se) {
      GenericTestUtils.assertExceptionContains("is not supported",se);
    }
    assertEquals(0,cluster.getNamesystem(1).getPendingDataNodeMessageCount());
    doCreate();
    Thread.sleep(1000);
    assertTrue(cluster.getNamesystem(1).getPendingDataNodeMessageCount() > 0);
    assertTrue("SBN should have still been checkpointing.",answerer.getFireCount() == 1 && answerer.getResultCount() == 0);
    answerer.proceed();
    answerer.waitForResult();
    assertTrue("SBN should have finished checkpointing.",answerer.getFireCount() == 1 && answerer.getResultCount() == 1);
  }
  @Test(timeout=300000) public void testReadsAllowedDuringCheckpoint() throws Exception {
    FSImage spyImage1=NameNodeAdapter.spyOnFsImage(nn1);
    DelayAnswer answerer=new DelayAnswer(LOG);
    Mockito.doAnswer(answerer).when(spyImage1).saveNamespace(Mockito.any(FSNamesystem.class),Mockito.any(NameNodeFile.class),Mockito.any(Canceler.class));
    doEdits(0,1000);
    nn0.getRpcServer().rollEditLog();
    answerer.waitForCall();
    assertTrue("SBN is not performing checkpoint but it should be.",answerer.getFireCount() == 1 && answerer.getResultCount() == 0);
    ThreadUtil.sleepAtLeastIgnoreInterrupts(1000);
    Thread t=new Thread(){
      @Override public void run(){
        try {
          nn1.getRpcServer().restoreFailedStorage("false");
        }
 catch (        IOException e) {
          e.printStackTrace();
        }
      }
    }
;
    t.start();
    ThreadUtil.sleepAtLeastIgnoreInterrupts(1000);
    assertFalse(nn1.getNamesystem().getFsLockForTests().hasQueuedThreads());
    assertFalse(nn1.getNamesystem().getFsLockForTests().isWriteLocked());
    assertTrue(nn1.getNamesystem().getCpLockForTests().hasQueuedThreads());
    String pageContents=DFSTestUtil.urlGet(new URL("http://" + nn1.getHttpAddress().getHostName() + ":"+ nn1.getHttpAddress().getPort()+ "/jmx"));
    assertTrue(pageContents.contains("NumLiveDataNodes"));
    assertTrue("SBN should have still been checkpointing.",answerer.getFireCount() == 1 && answerer.getResultCount() == 0);
    answerer.proceed();
    answerer.waitForResult();
    assertTrue("SBN should have finished checkpointing.",answerer.getFireCount() == 1 && answerer.getResultCount() == 1);
    t.join();
  }
  private void doEdits(  int start,  int stop) throws IOException {
    for (int i=start; i < stop; i++) {
      Path p=new Path("/test" + i);
      fs.mkdirs(p);
    }
  }
  private void doCreate() throws IOException {
    Path p=new Path("/testFile");
    fs.delete(p,false);
    FSDataOutputStream out=fs.create(p,(short)1);
    out.write(42);
    out.close();
  }
  /** 
 * A codec which just slows down the saving of the image significantly by sleeping a few milliseconds on every write. This makes it easy to catch the standby in the middle of saving a checkpoint.
 */
public static class SlowCodec extends GzipCodec {
    @Override public CompressionOutputStream createOutputStream(    OutputStream out) throws IOException {
      CompressionOutputStream ret=super.createOutputStream(out);
      CompressionOutputStream spy=Mockito.spy(ret);
      Mockito.doAnswer(new GenericTestUtils.SleepAnswer(5)).when(spy).write(Mockito.<byte[]>any(),Mockito.anyInt(),Mockito.anyInt());
      return spy;
    }
  }
}
