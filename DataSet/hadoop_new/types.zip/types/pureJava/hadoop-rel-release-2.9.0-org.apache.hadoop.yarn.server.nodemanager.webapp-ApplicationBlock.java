public static class ApplicationBlock extends HtmlBlock implements YarnWebParams {
  private final Context nmContext;
  private final Configuration conf;
  private final RecordFactory recordFactory;
  @Inject public ApplicationBlock(  Context nmContext,  Configuration conf){
    this.conf=conf;
    this.nmContext=nmContext;
    this.recordFactory=RecordFactoryProvider.getRecordFactory(this.conf);
  }
  @Override protected void render(  Block html){
    ApplicationId applicationID;
    try {
      applicationID=ApplicationId.fromString($(APPLICATION_ID));
    }
 catch (    IllegalArgumentException e) {
      html.p()._("Invalid Application Id " + $(APPLICATION_ID))._();
      return;
    }
    DIV<Hamlet> div=html.div("#content");
    Application app=this.nmContext.getApplications().get(applicationID);
    if (app == null) {
      div.h1("Unknown application with id " + applicationID + ". Application might have been completed")._();
      return;
    }
    AppInfo info=new AppInfo(app);
    info("Application's information")._("ApplicationId",info.getId())._("ApplicationState",info.getState())._("User",info.getUser());
    TABLE<Hamlet> containersListBody=html._(InfoBlock.class).table("#containers");
    for (    String containerIdStr : info.getContainers()) {
      containersListBody.tr().td().a(url("container",containerIdStr),containerIdStr)._()._();
    }
    containersListBody._();
  }
}
