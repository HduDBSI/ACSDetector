/** 
 * A special extension of  {@link TestImpl} RPC server with {@link TestImpl#ping()} testing the audit logs.
 */
private class MyTestRPCServer extends TestRpcBase.PBServerImpl {
  @Override public TestProtos.EmptyResponseProto ping(  RpcController unused,  TestProtos.EmptyRequestProto request) throws ServiceException {
    byte[] clientId=Server.getClientId();
    Assert.assertNotNull(clientId);
    Assert.assertEquals(ClientId.BYTE_LENGTH,clientId.length);
    testSuccessLogFormat(true);
    testFailureLogFormat(true);
    return TestProtos.EmptyResponseProto.newBuilder().build();
  }
}
