private static class WriteOperation {
  private final Future<Void> task;
  private final long startOffset;
  private final long length;
  WriteOperation(  final Future<Void> task,  final long startOffset,  final long length){
    Preconditions.checkNotNull(task,"task");
    Preconditions.checkArgument(startOffset >= 0,"startOffset");
    Preconditions.checkArgument(length >= 0,"length");
    this.task=task;
    this.startOffset=startOffset;
    this.length=length;
  }
}
