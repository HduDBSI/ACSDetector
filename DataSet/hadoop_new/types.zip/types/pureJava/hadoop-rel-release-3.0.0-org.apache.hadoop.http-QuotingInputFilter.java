/** 
 * A Servlet input filter that quotes all HTML active characters in the parameter names and values. The goal is to quote the characters to make all of the servlets resistant to cross-site scripting attacks. It also sets X-FRAME-OPTIONS in the header to mitigate clickjacking attacks.
 */
public static class QuotingInputFilter implements Filter {
  private FilterConfig config;
public static class RequestQuoter extends HttpServletRequestWrapper {
    private final HttpServletRequest rawRequest;
    public RequestQuoter(    HttpServletRequest rawRequest){
      super(rawRequest);
      this.rawRequest=rawRequest;
    }
    /** 
 * Return the set of parameter names, quoting each name.
 */
    @SuppressWarnings("unchecked") @Override public Enumeration<String> getParameterNames(){
      return new Enumeration<String>(){
        private Enumeration<String> rawIterator=rawRequest.getParameterNames();
        @Override public boolean hasMoreElements(){
          return rawIterator.hasMoreElements();
        }
        @Override public String nextElement(){
          return HtmlQuoting.quoteHtmlChars(rawIterator.nextElement());
        }
      }
;
    }
    /** 
 * Unquote the name and quote the value.
 */
    @Override public String getParameter(    String name){
      return HtmlQuoting.quoteHtmlChars(rawRequest.getParameter(HtmlQuoting.unquoteHtmlChars(name)));
    }
    @Override public String[] getParameterValues(    String name){
      String unquoteName=HtmlQuoting.unquoteHtmlChars(name);
      String[] unquoteValue=rawRequest.getParameterValues(unquoteName);
      if (unquoteValue == null) {
        return null;
      }
      String[] result=new String[unquoteValue.length];
      for (int i=0; i < result.length; ++i) {
        result[i]=HtmlQuoting.quoteHtmlChars(unquoteValue[i]);
      }
      return result;
    }
    @SuppressWarnings("unchecked") @Override public Map<String,String[]> getParameterMap(){
      Map<String,String[]> result=new HashMap<>();
      Map<String,String[]> raw=rawRequest.getParameterMap();
      for (      Map.Entry<String,String[]> item : raw.entrySet()) {
        String[] rawValue=item.getValue();
        String[] cookedValue=new String[rawValue.length];
        for (int i=0; i < rawValue.length; ++i) {
          cookedValue[i]=HtmlQuoting.quoteHtmlChars(rawValue[i]);
        }
        result.put(HtmlQuoting.quoteHtmlChars(item.getKey()),cookedValue);
      }
      return result;
    }
    /** 
 * Quote the url so that users specifying the HOST HTTP header can't inject attacks.
 */
    @Override public StringBuffer getRequestURL(){
      String url=rawRequest.getRequestURL().toString();
      return new StringBuffer(HtmlQuoting.quoteHtmlChars(url));
    }
    /** 
 * Quote the server name so that users specifying the HOST HTTP header can't inject attacks.
 */
    @Override public String getServerName(){
      return HtmlQuoting.quoteHtmlChars(rawRequest.getServerName());
    }
  }
  @Override public void init(  FilterConfig config) throws ServletException {
    this.config=config;
  }
  @Override public void destroy(){
  }
  @Override public void doFilter(  ServletRequest request,  ServletResponse response,  FilterChain chain) throws IOException, ServletException {
    HttpServletRequestWrapper quoted=new RequestQuoter((HttpServletRequest)request);
    HttpServletResponse httpResponse=(HttpServletResponse)response;
    String mime=inferMimeType(request);
    if (mime == null) {
      httpResponse.setContentType("text/plain; charset=utf-8");
    }
 else     if (mime.startsWith("text/html")) {
      httpResponse.setContentType("text/html; charset=utf-8");
    }
 else     if (mime.startsWith("application/xml")) {
      httpResponse.setContentType("text/xml; charset=utf-8");
    }
    if (Boolean.valueOf(this.config.getInitParameter(X_FRAME_ENABLED))) {
      httpResponse.addHeader("X-FRAME-OPTIONS",this.config.getInitParameter(X_FRAME_VALUE));
    }
    chain.doFilter(quoted,httpResponse);
  }
  /** 
 * Infer the mime type for the response based on the extension of the request URI. Returns null if unknown.
 */
  private String inferMimeType(  ServletRequest request){
    String path=((HttpServletRequest)request).getRequestURI();
    ServletContextHandler.Context sContext=(ServletContextHandler.Context)config.getServletContext();
    String mime=sContext.getMimeType(path);
    return (mime == null) ? null : mime;
  }
}
