public class DefaultProviderService extends AbstractProviderService {
  @Override public void processArtifact(  AbstractLauncher launcher,  ComponentInstance compInstance,  SliderFileSystem fileSystem,  Service service) throws IOException {
  }
}
