/** 
 * Wraps up object listing into a remote iterator which will ask for more listing data if needed. This is a complex operation, especially the process to determine if there are more entries remaining. If there are no more results remaining in the (filtered) results of the current listing request, then another request is made <i>and those results filtered</i> before the iterator can declare that there is more data available. The need to filter the results precludes the iterator from simply declaring that if the  {@link ObjectListingIterator#hasNext()}is true then there are more results. Instead the next batch of results must be retrieved and filtered. What does this mean? It means that remote requests to retrieve new batches of object listings are made in the  {@link #hasNext()} call;the  {@link #next()} call simply returns the filtered results of the lastlisting processed. However, do note that  {@link #next()} calls{@link #hasNext()} during its operation. This is critical to ensurethat a listing obtained through a sequence of  {@link #next()} willcomplete with the same set of results as a classic {@code while(it.hasNext()} loop.Thread safety: None.
 */
class FileStatusListingIterator implements RemoteIterator<S3AFileStatus>, IOStatisticsSource {
  /** 
 * Source of objects. 
 */
  private final ObjectListingIterator source;
  /** 
 * Filter of paths from API call. 
 */
  private final PathFilter filter;
  /** 
 * Filter of entries from file status. 
 */
  private final FileStatusAcceptor acceptor;
  /** 
 * request batch size. 
 */
  private int batchSize;
  /** 
 * Iterator over the current set of results. 
 */
  private ListIterator<S3AFileStatus> statusBatchIterator;
  private final Map<Path,S3AFileStatus> providedStatus;
  private Iterator<S3AFileStatus> providedStatusIterator;
  /** 
 * Create an iterator over file status entries.
 * @param source the listing iterator from a listObjects call.
 * @param filter the filter on which paths to accept
 * @param acceptor the class/predicate to decide which entries to acceptin the listing based on the full file status.
 * @param providedStatus the provided list of file status, which may containitems that are not listed from source.
 * @throws IOException IO Problems
 */
  @Retries.RetryTranslated FileStatusListingIterator(  ObjectListingIterator source,  PathFilter filter,  FileStatusAcceptor acceptor,  @Nullable RemoteIterator<S3AFileStatus> providedStatus) throws IOException {
    this.source=source;
    this.filter=filter;
    this.acceptor=acceptor;
    this.providedStatus=new HashMap<>();
    for (; providedStatus != null && providedStatus.hasNext(); ) {
      final S3AFileStatus status=providedStatus.next();
      Path path=status.getPath();
      if (filter.accept(path) && acceptor.accept(status)) {
        this.providedStatus.put(path,status);
      }
    }
    requestNextBatch();
  }
  /** 
 * Report whether or not there is new data available. If there is data in the local filtered list, return true. Else: request more data util that condition is met, or there is no more remote listing data. Lastly, return true if the  {@code providedStatusIterator}has left items.
 * @return true if a call to {@link #next()} will succeed.
 * @throws IOException
 */
  @Override @Retries.RetryTranslated public boolean hasNext() throws IOException {
    return sourceHasNext() || providedStatusIterator.hasNext();
  }
  @Retries.RetryTranslated private boolean sourceHasNext() throws IOException {
    if (statusBatchIterator.hasNext() || requestNextBatch()) {
      return true;
    }
 else {
      if (providedStatusIterator == null) {
        LOG.debug("Start iterating the provided status.");
        providedStatusIterator=providedStatus.values().iterator();
      }
      return false;
    }
  }
  @Override @Retries.RetryTranslated public S3AFileStatus next() throws IOException {
    final S3AFileStatus status;
    if (sourceHasNext()) {
      status=statusBatchIterator.next();
      S3AFileStatus provided=providedStatus.remove(status.getPath());
      if (provided != null) {
        LOG.debug("Removed and returned the status from provided file status {}",status);
        return provided;
      }
    }
 else {
      if (providedStatusIterator.hasNext()) {
        status=providedStatusIterator.next();
        LOG.debug("Returning provided file status {}",status);
      }
 else {
        throw new NoSuchElementException();
      }
    }
    return status;
  }
  /** 
 * Try to retrieve another batch. Note that for the initial batch, {@link ObjectListingIterator} does not generate a request;it simply returns the initial set.
 * @return true if a new batch was created.
 * @throws IOException IO problems
 */
  @Retries.RetryTranslated private boolean requestNextBatch() throws IOException {
    while (source.hasNext()) {
      if (buildNextStatusBatch(source.next())) {
        return true;
      }
 else {
        LOG.debug("All entries in batch were filtered...continuing");
      }
    }
    return false;
  }
  /** 
 * Build the next status batch from a listing.
 * @param objects the next object listing
 * @return true if this added any entries after filtering
 */
  private boolean buildNextStatusBatch(  S3ListResult objects){
    int added=0, ignored=0;
    List<S3AFileStatus> stats=new ArrayList<>(objects.getObjectSummaries().size() + objects.getCommonPrefixes().size());
    for (    S3ObjectSummary summary : objects.getObjectSummaries()) {
      String key=summary.getKey();
      Path keyPath=getStoreContext().getContextAccessors().keyToPath(key);
      if (LOG.isDebugEnabled()) {
        LOG.debug("{}: {}",keyPath,stringify(summary));
      }
      if (acceptor.accept(keyPath,summary) && filter.accept(keyPath)) {
        S3AFileStatus status=createFileStatus(keyPath,summary,listingOperationCallbacks.getDefaultBlockSize(keyPath),getStoreContext().getUsername(),summary.getETag(),null,isCSEEnabled);
        LOG.debug("Adding: {}",status);
        stats.add(status);
        added++;
      }
 else {
        LOG.debug("Ignoring: {}",keyPath);
        ignored++;
      }
    }
    for (    String prefix : objects.getCommonPrefixes()) {
      Path keyPath=getStoreContext().getContextAccessors().keyToPath(prefix);
      if (acceptor.accept(keyPath,prefix) && filter.accept(keyPath)) {
        S3AFileStatus status=new S3AFileStatus(Tristate.FALSE,keyPath,getStoreContext().getUsername());
        LOG.debug("Adding directory: {}",status);
        added++;
        stats.add(status);
      }
 else {
        LOG.debug("Ignoring directory: {}",keyPath);
        ignored++;
      }
    }
    batchSize=stats.size();
    statusBatchIterator=stats.listIterator();
    boolean hasNext=statusBatchIterator.hasNext();
    LOG.debug("Added {} entries; ignored {}; hasNext={}; hasMoreObjects={}",added,ignored,hasNext,objects.isTruncated());
    return hasNext;
  }
  /** 
 * Get the number of entries in the current batch.
 * @return a number, possibly zero.
 */
  public int getBatchSize(){
    return batchSize;
  }
  /** 
 * Return any IOStatistics provided by the underlying stream.
 * @return IO stats from the inner stream.
 */
  @Override public IOStatistics getIOStatistics(){
    return source.getIOStatistics();
  }
  @Override public String toString(){
    return new StringJoiner(", ",FileStatusListingIterator.class.getSimpleName() + "[","]").add(source.toString()).toString();
  }
}
