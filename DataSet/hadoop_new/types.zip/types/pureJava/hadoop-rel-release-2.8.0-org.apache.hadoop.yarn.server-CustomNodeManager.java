public class CustomNodeManager extends NodeManager {
  protected NodeStatus nodeStatus;
  public void setNodeStatus(  NodeStatus status){
    this.nodeStatus=status;
  }
  /** 
 * Hook to allow modification/replacement of NodeStatus
 * @param currentStatus Current status.
 * @return New node status.
 */
  protected NodeStatus getSimulatedNodeStatus(  NodeStatus currentStatus){
    if (nodeStatus == null) {
      return currentStatus;
    }
 else {
      nodeStatus.setResponseId(nodeStatus.getResponseId() + 1);
      return nodeStatus;
    }
  }
  @Override protected void doSecureLogin() throws IOException {
  }
  @Override protected NodeStatusUpdater createNodeStatusUpdater(  Context context,  Dispatcher dispatcher,  NodeHealthCheckerService healthChecker){
    return new NodeStatusUpdaterImpl(context,dispatcher,healthChecker,metrics){
      @Override protected NodeStatus getNodeStatus(      int responseId) throws IOException {
        return getSimulatedNodeStatus(super.getNodeStatus(responseId));
      }
    }
;
  }
}
