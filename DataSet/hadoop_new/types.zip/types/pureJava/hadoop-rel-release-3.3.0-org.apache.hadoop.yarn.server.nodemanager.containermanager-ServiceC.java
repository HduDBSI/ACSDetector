static class ServiceC extends LightService {
  public ServiceC(){
    super("C",'C',66,ByteBuffer.wrap("C".getBytes()));
  }
  @Override public ByteBuffer getMetaData(){
    ClassLoader loader=Thread.currentThread().getContextClassLoader();
    try {
      URL[] urls=((URLClassLoader)loader).getURLs();
      String joinedString=Arrays.stream(urls).map(URL::toString).collect(Collectors.joining(","));
      return ByteBuffer.wrap(joinedString.getBytes());
    }
 catch (    ClassCastException e) {
      return super.meta;
    }
  }
}
