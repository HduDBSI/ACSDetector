public class FifoCandidatesSelector extends PreemptionCandidatesSelector {
  private static final Log LOG=LogFactory.getLog(FifoCandidatesSelector.class);
  private PreemptableResourceCalculator preemptableAmountCalculator;
  private boolean allowQueuesBalanceAfterAllQueuesSatisfied;
  FifoCandidatesSelector(  CapacitySchedulerPreemptionContext preemptionContext,  boolean includeReservedResource,  boolean allowQueuesBalanceAfterAllQueuesSatisfied){
    super(preemptionContext);
    this.allowQueuesBalanceAfterAllQueuesSatisfied=allowQueuesBalanceAfterAllQueuesSatisfied;
    preemptableAmountCalculator=new PreemptableResourceCalculator(preemptionContext,includeReservedResource,allowQueuesBalanceAfterAllQueuesSatisfied);
  }
  @Override public Map<ApplicationAttemptId,Set<RMContainer>> selectCandidates(  Map<ApplicationAttemptId,Set<RMContainer>> selectedCandidates,  Resource clusterResource,  Resource totalPreemptionAllowed){
    Map<ApplicationAttemptId,Set<RMContainer>> curCandidates=new HashMap<>();
    preemptableAmountCalculator.computeIdealAllocation(clusterResource,totalPreemptionAllowed);
    CapacitySchedulerPreemptionUtils.deductPreemptableResourcesBasedSelectedCandidates(preemptionContext,selectedCandidates);
    List<RMContainer> skippedAMContainerlist=new ArrayList<>();
    for (    String queueName : preemptionContext.getLeafQueueNames()) {
      if (preemptionContext.getQueueByPartition(queueName,RMNodeLabelsManager.NO_LABEL).preemptionDisabled) {
        if (LOG.isDebugEnabled()) {
          LOG.debug("skipping from queue=" + queueName + " because it's a non-preemptable queue");
        }
        continue;
      }
      LeafQueue leafQueue=preemptionContext.getQueueByPartition(queueName,RMNodeLabelsManager.NO_LABEL).leafQueue;
      Map<String,Resource> resToObtainByPartition=CapacitySchedulerPreemptionUtils.getResToObtainByPartitionForLeafQueue(preemptionContext,queueName,clusterResource);
      try {
        leafQueue.getReadLock().lock();
        Map<String,TreeSet<RMContainer>> ignorePartitionExclusivityContainers=leafQueue.getIgnoreExclusivityRMContainers();
        for (        String partition : resToObtainByPartition.keySet()) {
          if (ignorePartitionExclusivityContainers.containsKey(partition)) {
            TreeSet<RMContainer> rmContainers=ignorePartitionExclusivityContainers.get(partition);
            for (            RMContainer c : rmContainers.descendingSet()) {
              if (CapacitySchedulerPreemptionUtils.isContainerAlreadySelected(c,selectedCandidates)) {
                continue;
              }
              boolean preempted=CapacitySchedulerPreemptionUtils.tryPreemptContainerAndDeductResToObtain(rc,preemptionContext,resToObtainByPartition,c,clusterResource,selectedCandidates,curCandidates,totalPreemptionAllowed,false);
              if (!preempted) {
                continue;
              }
            }
          }
        }
        Resource skippedAMSize=Resource.newInstance(0,0);
        Iterator<FiCaSchedulerApp> desc=leafQueue.getOrderingPolicy().getPreemptionIterator();
        while (desc.hasNext()) {
          FiCaSchedulerApp fc=desc.next();
          if (resToObtainByPartition.isEmpty()) {
            break;
          }
          preemptFrom(fc,clusterResource,resToObtainByPartition,skippedAMContainerlist,skippedAMSize,selectedCandidates,curCandidates,totalPreemptionAllowed);
        }
        Resource maxAMCapacityForThisQueue=Resources.multiply(leafQueue.getEffectiveCapacity(RMNodeLabelsManager.NO_LABEL),leafQueue.getMaxAMResourcePerQueuePercent());
        preemptAMContainers(clusterResource,selectedCandidates,curCandidates,skippedAMContainerlist,resToObtainByPartition,skippedAMSize,maxAMCapacityForThisQueue,totalPreemptionAllowed);
      }
  finally {
        leafQueue.getReadLock().unlock();
      }
    }
    return curCandidates;
  }
  /** 
 * As more resources are needed for preemption, saved AMContainers has to be rescanned. Such AMContainers can be preemptionCandidates based on resToObtain, but maxAMCapacityForThisQueue resources will be still retained.
 * @param clusterResource
 * @param preemptMap
 * @param skippedAMContainerlist
 * @param skippedAMSize
 * @param maxAMCapacityForThisQueue
 */
  private void preemptAMContainers(  Resource clusterResource,  Map<ApplicationAttemptId,Set<RMContainer>> preemptMap,  Map<ApplicationAttemptId,Set<RMContainer>> curCandidates,  List<RMContainer> skippedAMContainerlist,  Map<String,Resource> resToObtainByPartition,  Resource skippedAMSize,  Resource maxAMCapacityForThisQueue,  Resource totalPreemptionAllowed){
    for (    RMContainer c : skippedAMContainerlist) {
      if (resToObtainByPartition.isEmpty()) {
        break;
      }
      if (Resources.lessThanOrEqual(rc,clusterResource,skippedAMSize,maxAMCapacityForThisQueue)) {
        break;
      }
      boolean preempted=CapacitySchedulerPreemptionUtils.tryPreemptContainerAndDeductResToObtain(rc,preemptionContext,resToObtainByPartition,c,clusterResource,preemptMap,curCandidates,totalPreemptionAllowed,false);
      if (preempted) {
        Resources.subtractFrom(skippedAMSize,c.getAllocatedResource());
      }
    }
    skippedAMContainerlist.clear();
  }
  /** 
 * Given a target preemption for a specific application, select containers to preempt (after unreserving all reservation for that app).
 */
  private void preemptFrom(  FiCaSchedulerApp app,  Resource clusterResource,  Map<String,Resource> resToObtainByPartition,  List<RMContainer> skippedAMContainerlist,  Resource skippedAMSize,  Map<ApplicationAttemptId,Set<RMContainer>> selectedContainers,  Map<ApplicationAttemptId,Set<RMContainer>> curCandidates,  Resource totalPreemptionAllowed){
    ApplicationAttemptId appId=app.getApplicationAttemptId();
    List<RMContainer> reservedContainers=new ArrayList<>(app.getReservedContainers());
    for (    RMContainer c : reservedContainers) {
      if (CapacitySchedulerPreemptionUtils.isContainerAlreadySelected(c,selectedContainers)) {
        continue;
      }
      if (resToObtainByPartition.isEmpty()) {
        return;
      }
      CapacitySchedulerPreemptionUtils.tryPreemptContainerAndDeductResToObtain(rc,preemptionContext,resToObtainByPartition,c,clusterResource,selectedContainers,curCandidates,totalPreemptionAllowed,false);
      if (!preemptionContext.isObserveOnly()) {
        preemptionContext.getRMContext().getDispatcher().getEventHandler().handle(new ContainerPreemptEvent(appId,c,SchedulerEventType.KILL_RESERVED_CONTAINER));
      }
    }
    List<RMContainer> liveContainers=new ArrayList<>(app.getLiveContainers());
    sortContainers(liveContainers);
    for (    RMContainer c : liveContainers) {
      if (resToObtainByPartition.isEmpty()) {
        return;
      }
      if (CapacitySchedulerPreemptionUtils.isContainerAlreadySelected(c,selectedContainers)) {
        continue;
      }
      if (null != preemptionContext.getKillableContainers() && preemptionContext.getKillableContainers().contains(c.getContainerId())) {
        continue;
      }
      if (c.isAMContainer()) {
        skippedAMContainerlist.add(c);
        Resources.addTo(skippedAMSize,c.getAllocatedResource());
        continue;
      }
      CapacitySchedulerPreemptionUtils.tryPreemptContainerAndDeductResToObtain(rc,preemptionContext,resToObtainByPartition,c,clusterResource,selectedContainers,curCandidates,totalPreemptionAllowed,false);
    }
  }
  public boolean getAllowQueuesBalanceAfterAllQueuesSatisfied(){
    return allowQueuesBalanceAfterAllQueuesSatisfied;
  }
}
