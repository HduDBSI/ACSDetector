@Private @VisibleForTesting class AssignedRequests {
  private final Map<ContainerId,TaskAttemptId> containerToAttemptMap=new HashMap<ContainerId,TaskAttemptId>();
  @VisibleForTesting final LinkedHashMap<TaskAttemptId,Container> maps=new LinkedHashMap<TaskAttemptId,Container>();
  @VisibleForTesting final LinkedHashMap<TaskAttemptId,Container> reduces=new LinkedHashMap<TaskAttemptId,Container>();
  @VisibleForTesting final Set<TaskAttemptId> preemptionWaitingReduces=new HashSet<TaskAttemptId>();
  void add(  Container container,  TaskAttemptId tId){
    LOG.info("Assigned container " + container.getId().toString() + " to "+ tId);
    containerToAttemptMap.put(container.getId(),tId);
    if (tId.getTaskId().getTaskType().equals(TaskType.MAP)) {
      maps.put(tId,container);
    }
 else {
      reduces.put(tId,container);
    }
  }
  @SuppressWarnings("unchecked") void preemptReduce(  int toPreempt){
    List<TaskAttemptId> reduceList=new ArrayList<TaskAttemptId>(reduces.keySet());
    Collections.sort(reduceList,new Comparator<TaskAttemptId>(){
      @Override public int compare(      TaskAttemptId o1,      TaskAttemptId o2){
        return Float.compare(getJob().getTask(o1.getTaskId()).getAttempt(o1).getProgress(),getJob().getTask(o2.getTaskId()).getAttempt(o2).getProgress());
      }
    }
);
    for (int i=0; i < toPreempt && reduceList.size() > 0; i++) {
      TaskAttemptId id=reduceList.remove(0);
      LOG.info("Preempting " + id);
      preemptionWaitingReduces.add(id);
      eventHandler.handle(new TaskAttemptKillEvent(id,RAMPDOWN_DIAGNOSTIC));
    }
  }
  boolean remove(  TaskAttemptId tId){
    ContainerId containerId=null;
    if (tId.getTaskId().getTaskType().equals(TaskType.MAP)) {
      containerId=maps.remove(tId).getId();
    }
 else {
      containerId=reduces.remove(tId).getId();
      if (containerId != null) {
        boolean preempted=preemptionWaitingReduces.remove(tId);
        if (preempted) {
          LOG.info("Reduce preemption successful " + tId);
        }
      }
    }
    if (containerId != null) {
      containerToAttemptMap.remove(containerId);
      return true;
    }
    return false;
  }
  TaskAttemptId get(  ContainerId cId){
    return containerToAttemptMap.get(cId);
  }
  ContainerId get(  TaskAttemptId tId){
    Container taskContainer;
    if (tId.getTaskId().getTaskType().equals(TaskType.MAP)) {
      taskContainer=maps.get(tId);
    }
 else {
      taskContainer=reduces.get(tId);
    }
    if (taskContainer == null) {
      return null;
    }
 else {
      return taskContainer.getId();
    }
  }
}
