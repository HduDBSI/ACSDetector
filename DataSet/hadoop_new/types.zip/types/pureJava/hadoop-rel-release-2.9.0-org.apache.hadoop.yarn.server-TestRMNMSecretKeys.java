public class TestRMNMSecretKeys {
  private static final String KRB5_CONF="java.security.krb5.conf";
  private static final File KRB5_CONF_ROOT_DIR=new File(System.getProperty("test.build.dir","target/test-dir"),UUID.randomUUID().toString());
  @BeforeClass public static void setup() throws IOException {
    KRB5_CONF_ROOT_DIR.mkdir();
    File krb5ConfFile=new File(KRB5_CONF_ROOT_DIR,"krb5.conf");
    krb5ConfFile.createNewFile();
    String content="[libdefaults]\n" + "    default_realm = APACHE.ORG\n" + "    udp_preference_limit = 1\n"+ "    extra_addresses = 127.0.0.1\n"+ "[realms]\n"+ "    APACHE.ORG = {\n"+ "        admin_server = localhost:88\n"+ "        kdc = localhost:88\n}\n"+ "[domain_realm]\n"+ "    localhost = APACHE.ORG";
    writeFile(content,krb5ConfFile);
    System.setProperty(KRB5_CONF,krb5ConfFile.getAbsolutePath());
  }
  private static void writeFile(  String content,  File file) throws IOException {
    FileOutputStream outputStream=new FileOutputStream(file);
    FileChannel fc=outputStream.getChannel();
    ByteBuffer buffer=ByteBuffer.wrap(content.getBytes(StandardCharsets.UTF_8));
    fc.write(buffer);
    outputStream.close();
  }
  @AfterClass public static void tearDown() throws IOException {
    KRB5_CONF_ROOT_DIR.delete();
  }
  @Test(timeout=1000000) public void testNMUpdation() throws Exception {
    YarnConfiguration conf=new YarnConfiguration();
    validateRMNMKeyExchange(conf);
    conf.set(CommonConfigurationKeysPublic.HADOOP_SECURITY_AUTHENTICATION,"kerberos");
    UserGroupInformation.setConfiguration(conf);
    validateRMNMKeyExchange(conf);
  }
  private void validateRMNMKeyExchange(  YarnConfiguration conf) throws Exception {
    final DrainDispatcher dispatcher=new DrainDispatcher();
    ResourceManager rm=new ResourceManager(){
      @Override protected void doSecureLogin() throws IOException {
      }
      @Override protected Dispatcher createDispatcher(){
        return dispatcher;
      }
      @Override protected void startWepApp(){
      }
    }
;
    rm.init(conf);
    rm.start();
    String containerToken="Container Token : ";
    String nmToken="NM Token : ";
    MockNM nm=new MockNM("host:1234",3072,rm.getResourceTrackerService());
    RegisterNodeManagerResponse registrationResponse=nm.registerNode();
    MasterKey containerTokenMasterKey=registrationResponse.getContainerTokenMasterKey();
    Assert.assertNotNull(containerToken + "Registration should cause a key-update!",containerTokenMasterKey);
    MasterKey nmTokenMasterKey=registrationResponse.getNMTokenMasterKey();
    Assert.assertNotNull(nmToken + "Registration should cause a key-update!",nmTokenMasterKey);
    dispatcher.await();
    NodeHeartbeatResponse response=nm.nodeHeartbeat(true);
    Assert.assertNull(containerToken + "First heartbeat after registration shouldn't get any key updates!",response.getContainerTokenMasterKey());
    Assert.assertNull(nmToken + "First heartbeat after registration shouldn't get any key updates!",response.getNMTokenMasterKey());
    dispatcher.await();
    response=nm.nodeHeartbeat(true);
    Assert.assertNull(containerToken + "Even second heartbeat after registration shouldn't get any key updates!",response.getContainerTokenMasterKey());
    Assert.assertNull(nmToken + "Even second heartbeat after registration shouldn't get any key updates!",response.getContainerTokenMasterKey());
    dispatcher.await();
    rm.getRMContext().getContainerTokenSecretManager().rollMasterKey();
    rm.getRMContext().getNMTokenSecretManager().rollMasterKey();
    response=nm.nodeHeartbeat(true);
    Assert.assertNotNull(containerToken + "Heartbeats after roll-over and before activation should not err out.",response.getContainerTokenMasterKey());
    Assert.assertNotNull(nmToken + "Heartbeats after roll-over and before activation should not err out.",response.getNMTokenMasterKey());
    Assert.assertEquals(containerToken + "Roll-over should have incremented the key-id only by one!",containerTokenMasterKey.getKeyId() + 1,response.getContainerTokenMasterKey().getKeyId());
    Assert.assertEquals(nmToken + "Roll-over should have incremented the key-id only by one!",nmTokenMasterKey.getKeyId() + 1,response.getNMTokenMasterKey().getKeyId());
    dispatcher.await();
    response=nm.nodeHeartbeat(true);
    Assert.assertNull(containerToken + "Second heartbeat after roll-over shouldn't get any key updates!",response.getContainerTokenMasterKey());
    Assert.assertNull(nmToken + "Second heartbeat after roll-over shouldn't get any key updates!",response.getNMTokenMasterKey());
    dispatcher.await();
    rm.getRMContext().getContainerTokenSecretManager().activateNextMasterKey();
    rm.getRMContext().getNMTokenSecretManager().activateNextMasterKey();
    response=nm.nodeHeartbeat(true);
    Assert.assertNull(containerToken + "Activation shouldn't cause any key updates!",response.getContainerTokenMasterKey());
    Assert.assertNull(nmToken + "Activation shouldn't cause any key updates!",response.getNMTokenMasterKey());
    dispatcher.await();
    response=nm.nodeHeartbeat(true);
    Assert.assertNull(containerToken + "Even second heartbeat after activation shouldn't get any key updates!",response.getContainerTokenMasterKey());
    Assert.assertNull(nmToken + "Even second heartbeat after activation shouldn't get any key updates!",response.getNMTokenMasterKey());
    dispatcher.await();
    rm.stop();
  }
}
