public class ReservationUpdateResponsePBImpl extends ReservationUpdateResponse {
  ReservationUpdateResponseProto proto=ReservationUpdateResponseProto.getDefaultInstance();
  ReservationUpdateResponseProto.Builder builder=null;
  boolean viaProto=false;
  public ReservationUpdateResponsePBImpl(){
    builder=ReservationUpdateResponseProto.newBuilder();
  }
  public ReservationUpdateResponsePBImpl(  ReservationUpdateResponseProto proto){
    this.proto=proto;
    viaProto=true;
  }
  public ReservationUpdateResponseProto getProto(){
    proto=viaProto ? proto : builder.build();
    viaProto=true;
    return proto;
  }
  @Override public int hashCode(){
    return getProto().hashCode();
  }
  @Override public boolean equals(  Object other){
    if (other == null)     return false;
    if (other.getClass().isAssignableFrom(this.getClass())) {
      return this.getProto().equals(this.getClass().cast(other).getProto());
    }
    return false;
  }
  @Override public String toString(){
    return TextFormat.shortDebugString(getProto());
  }
}
