/** 
 * Take dir tack ID from the spsDirsToBeTraveresed queue and collect child ID's to process for satisfy the policy.
 */
private class SPSPathIdProcessor implements Runnable {
  private static final int MAX_RETRY_COUNT=3;
  @Override public void run(){
    LOG.info("Starting SPSPathIdProcessor!.");
    Long startINode=null;
    int retryCount=0;
    while (ctxt.isRunning()) {
      try {
        if (!ctxt.isInSafeMode()) {
          if (startINode == null) {
            retryCount=0;
            startINode=ctxt.getNextSPSPath();
          }
          if (startINode == null) {
            Thread.sleep(3000);
          }
 else {
            ctxt.scanAndCollectFiles(startINode);
            DirPendingWorkInfo dirPendingWorkInfo=pendingWorkForDirectory.get(startINode);
            if (dirPendingWorkInfo != null && dirPendingWorkInfo.isDirWorkDone()) {
              try {
                ctxt.removeSPSHint(startINode);
              }
 catch (              FileNotFoundException e) {
                startINode=null;
              }
              pendingWorkForDirectory.remove(startINode);
            }
          }
          startINode=null;
        }
      }
 catch (      Throwable t) {
        String reClass=t.getClass().getName();
        if (InterruptedException.class.getName().equals(reClass)) {
          LOG.info("SPSPathIdProcessor thread is interrupted. Stopping..");
          break;
        }
        LOG.warn("Exception while scanning file inodes to satisfy the policy",t);
        try {
          Thread.sleep(3000);
        }
 catch (        InterruptedException e) {
          LOG.info("Interrupted while waiting in SPSPathIdProcessor",t);
          break;
        }
        retryCount++;
        if (retryCount >= MAX_RETRY_COUNT) {
          LOG.warn("Skipping this inode {} due to too many retries.",startINode);
          startINode=null;
        }
      }
    }
  }
}
