private static final class TestApplicationManagerEventDispatcher implements EventHandler<RMAppManagerEvent> {
  List<RMAppManagerEvent> events=Lists.newArrayList();
  @Override public void handle(  RMAppManagerEvent event){
    LOG.info("Handling app manager event: " + event);
    events.add(event);
  }
}
