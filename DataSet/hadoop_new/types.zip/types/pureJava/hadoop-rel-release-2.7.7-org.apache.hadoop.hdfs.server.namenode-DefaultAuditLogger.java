/** 
 * Default AuditLogger implementation; used when no access logger is defined in the config file. It can also be explicitly listed in the config file.
 */
private static class DefaultAuditLogger extends HdfsAuditLogger {
  private boolean logTokenTrackingId;
  @Override public void initialize(  Configuration conf){
    logTokenTrackingId=conf.getBoolean(DFSConfigKeys.DFS_NAMENODE_AUDIT_LOG_TOKEN_TRACKING_ID_KEY,DFSConfigKeys.DFS_NAMENODE_AUDIT_LOG_TOKEN_TRACKING_ID_DEFAULT);
  }
  @Override public void logAuditEvent(  boolean succeeded,  String userName,  InetAddress addr,  String cmd,  String src,  String dst,  FileStatus status,  UserGroupInformation ugi,  DelegationTokenSecretManager dtSecretManager){
    if (auditLog.isInfoEnabled()) {
      final StringBuilder sb=auditBuffer.get();
      sb.setLength(0);
      sb.append("allowed=").append(succeeded).append("\t");
      sb.append("ugi=").append(userName).append("\t");
      sb.append("ip=").append(addr).append("\t");
      sb.append("cmd=").append(cmd).append("\t");
      sb.append("src=").append(src).append("\t");
      sb.append("dst=").append(dst).append("\t");
      if (null == status) {
        sb.append("perm=null");
      }
 else {
        sb.append("perm=");
        sb.append(status.getOwner()).append(":");
        sb.append(status.getGroup()).append(":");
        sb.append(status.getPermission());
      }
      if (logTokenTrackingId) {
        sb.append("\t").append("trackingId=");
        String trackingId=null;
        if (ugi != null && dtSecretManager != null && ugi.getAuthenticationMethod() == AuthenticationMethod.TOKEN) {
          for (          TokenIdentifier tid : ugi.getTokenIdentifiers()) {
            if (tid instanceof DelegationTokenIdentifier) {
              DelegationTokenIdentifier dtid=(DelegationTokenIdentifier)tid;
              trackingId=dtSecretManager.getTokenTrackingId(dtid);
              break;
            }
          }
        }
        sb.append(trackingId);
      }
      sb.append("\t").append("proto=");
      sb.append(NamenodeWebHdfsMethods.isWebHdfsInvocation() ? "webhdfs" : "rpc");
      logAuditMessage(sb.toString());
    }
  }
  public void logAuditMessage(  String message){
    auditLog.info(message);
  }
}
