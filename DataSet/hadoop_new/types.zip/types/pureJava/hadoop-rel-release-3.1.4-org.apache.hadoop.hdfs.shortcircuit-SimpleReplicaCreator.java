private static class SimpleReplicaCreator implements ShortCircuitReplicaCreator {
  private final int blockId;
  private final ShortCircuitCache cache;
  private final TestFileDescriptorPair pair;
  SimpleReplicaCreator(  int blockId,  ShortCircuitCache cache,  TestFileDescriptorPair pair){
    this.blockId=blockId;
    this.cache=cache;
    this.pair=pair;
  }
  @Override public ShortCircuitReplicaInfo createShortCircuitReplicaInfo(){
    try {
      ExtendedBlockId key=new ExtendedBlockId(blockId,"test_bp1");
      return new ShortCircuitReplicaInfo(new ShortCircuitReplica(key,pair.getFileInputStreams()[0],pair.getFileInputStreams()[1],cache,Time.monotonicNow(),null));
    }
 catch (    IOException e) {
      throw new RuntimeException(e);
    }
  }
}
