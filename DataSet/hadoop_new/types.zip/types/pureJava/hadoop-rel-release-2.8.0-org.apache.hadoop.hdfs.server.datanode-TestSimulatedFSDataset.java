/** 
 * this class tests the methods of the  SimulatedFSDataset.
 */
public class TestSimulatedFSDataset {
  Configuration conf=null;
  static final String bpid="BP-TEST";
  static final int NUMBLOCKS=20;
  static final int BLOCK_LENGTH_MULTIPLIER=79;
  static final long FIRST_BLK_ID=1;
  @Before public void setUp() throws Exception {
    conf=new HdfsConfiguration();
    SimulatedFSDataset.setFactory(conf);
  }
  static long blockIdToLen(  long blkid){
    return blkid * BLOCK_LENGTH_MULTIPLIER;
  }
  static int addSomeBlocks(  SimulatedFSDataset fsdataset) throws IOException {
    return addSomeBlocks(fsdataset,false);
  }
  static int addSomeBlocks(  SimulatedFSDataset fsdataset,  boolean negativeBlkID) throws IOException {
    return addSomeBlocks(fsdataset,FIRST_BLK_ID,negativeBlkID);
  }
  static int addSomeBlocks(  SimulatedFSDataset fsdataset,  long startingBlockId,  boolean negativeBlkID) throws IOException {
    int bytesAdded=0;
    for (long i=startingBlockId; i < startingBlockId + NUMBLOCKS; ++i) {
      long blkID=negativeBlkID ? i * -1 : i;
      ExtendedBlock b=new ExtendedBlock(bpid,blkID,0,0);
      ReplicaInPipelineInterface bInfo=fsdataset.createRbw(StorageType.DEFAULT,b,false).getReplica();
      ReplicaOutputStreams out=bInfo.createStreams(true,DataChecksum.newDataChecksum(DataChecksum.Type.CRC32,512));
      try {
        OutputStream dataOut=out.getDataOut();
        assertEquals(0,fsdataset.getLength(b));
        for (int j=1; j <= blockIdToLen(i); ++j) {
          dataOut.write(j);
          assertEquals(j,bInfo.getBytesOnDisk());
          bytesAdded++;
        }
      }
  finally {
        out.close();
      }
      b.setNumBytes(blockIdToLen(i));
      fsdataset.finalizeBlock(b);
      assertEquals(blockIdToLen(i),fsdataset.getLength(b));
    }
    return bytesAdded;
  }
  static void readSomeBlocks(  SimulatedFSDataset fsdataset,  boolean negativeBlkID) throws IOException {
    for (long i=FIRST_BLK_ID; i <= NUMBLOCKS; ++i) {
      long blkID=negativeBlkID ? i * -1 : i;
      ExtendedBlock b=new ExtendedBlock(bpid,blkID,0,0);
      assertTrue(fsdataset.isValidBlock(b));
      assertEquals(blockIdToLen(i),fsdataset.getLength(b));
      checkBlockDataAndSize(fsdataset,b,blockIdToLen(i));
    }
  }
  @Test public void testFSDatasetFactory(){
    final Configuration conf=new Configuration();
    FsDatasetSpi.Factory<?> f=FsDatasetSpi.Factory.getFactory(conf);
    assertEquals(FsDatasetFactory.class,f.getClass());
    assertFalse(f.isSimulated());
    SimulatedFSDataset.setFactory(conf);
    FsDatasetSpi.Factory<?> s=FsDatasetSpi.Factory.getFactory(conf);
    assertEquals(SimulatedFSDataset.Factory.class,s.getClass());
    assertTrue(s.isSimulated());
  }
  @Test public void testGetMetaData() throws IOException {
    final SimulatedFSDataset fsdataset=getSimulatedFSDataset();
    ExtendedBlock b=new ExtendedBlock(bpid,FIRST_BLK_ID,5,0);
    try {
      assertTrue(fsdataset.getMetaDataInputStream(b) == null);
      assertTrue("Expected an IO exception",false);
    }
 catch (    IOException e) {
    }
    addSomeBlocks(fsdataset);
    b=new ExtendedBlock(bpid,FIRST_BLK_ID,0,0);
    InputStream metaInput=fsdataset.getMetaDataInputStream(b);
    DataInputStream metaDataInput=new DataInputStream(metaInput);
    short version=metaDataInput.readShort();
    assertEquals(BlockMetadataHeader.VERSION,version);
    DataChecksum checksum=DataChecksum.newDataChecksum(metaDataInput);
    assertEquals(DataChecksum.Type.NULL,checksum.getChecksumType());
    assertEquals(0,checksum.getChecksumSize());
  }
  @Test public void testStorageUsage() throws IOException {
    final SimulatedFSDataset fsdataset=getSimulatedFSDataset();
    assertEquals(fsdataset.getDfsUsed(),0);
    assertEquals(fsdataset.getRemaining(),fsdataset.getCapacity());
    int bytesAdded=addSomeBlocks(fsdataset);
    assertEquals(bytesAdded,fsdataset.getDfsUsed());
    assertEquals(fsdataset.getCapacity() - bytesAdded,fsdataset.getRemaining());
  }
  static void checkBlockDataAndSize(  SimulatedFSDataset fsdataset,  ExtendedBlock b,  long expectedLen) throws IOException {
    InputStream input=fsdataset.getBlockInputStream(b);
    long lengthRead=0;
    int data;
    while ((data=input.read()) != -1) {
      assertEquals(SimulatedFSDataset.simulatedByte(b.getLocalBlock(),lengthRead),(byte)(data & SimulatedFSDataset.BYTE_MASK));
      lengthRead++;
    }
    assertEquals(expectedLen,lengthRead);
  }
  @Test public void testWriteRead() throws IOException {
    testWriteRead(false);
    testWriteRead(true);
  }
  private void testWriteRead(  boolean negativeBlkID) throws IOException {
    final SimulatedFSDataset fsdataset=getSimulatedFSDataset();
    addSomeBlocks(fsdataset,negativeBlkID);
    readSomeBlocks(fsdataset,negativeBlkID);
  }
  @Test public void testGetBlockReport() throws IOException {
    SimulatedFSDataset fsdataset=getSimulatedFSDataset();
    BlockListAsLongs blockReport=fsdataset.getBlockReport(bpid);
    assertEquals(0,blockReport.getNumberOfBlocks());
    addSomeBlocks(fsdataset);
    blockReport=fsdataset.getBlockReport(bpid);
    assertEquals(NUMBLOCKS,blockReport.getNumberOfBlocks());
    for (    Block b : blockReport) {
      assertNotNull(b);
      assertEquals(blockIdToLen(b.getBlockId()),b.getNumBytes());
    }
  }
  @Test public void testInjectionEmpty() throws IOException {
    SimulatedFSDataset fsdataset=getSimulatedFSDataset();
    BlockListAsLongs blockReport=fsdataset.getBlockReport(bpid);
    assertEquals(0,blockReport.getNumberOfBlocks());
    int bytesAdded=addSomeBlocks(fsdataset);
    blockReport=fsdataset.getBlockReport(bpid);
    assertEquals(NUMBLOCKS,blockReport.getNumberOfBlocks());
    for (    Block b : blockReport) {
      assertNotNull(b);
      assertEquals(blockIdToLen(b.getBlockId()),b.getNumBytes());
    }
    SimulatedFSDataset sfsdataset=getSimulatedFSDataset();
    sfsdataset.injectBlocks(bpid,blockReport);
    blockReport=sfsdataset.getBlockReport(bpid);
    assertEquals(NUMBLOCKS,blockReport.getNumberOfBlocks());
    for (    Block b : blockReport) {
      assertNotNull(b);
      assertEquals(blockIdToLen(b.getBlockId()),b.getNumBytes());
      assertEquals(blockIdToLen(b.getBlockId()),sfsdataset.getLength(new ExtendedBlock(bpid,b)));
    }
    assertEquals(bytesAdded,sfsdataset.getDfsUsed());
    assertEquals(sfsdataset.getCapacity() - bytesAdded,sfsdataset.getRemaining());
  }
  @Test public void testInjectionNonEmpty() throws IOException {
    SimulatedFSDataset fsdataset=getSimulatedFSDataset();
    BlockListAsLongs blockReport=fsdataset.getBlockReport(bpid);
    assertEquals(0,blockReport.getNumberOfBlocks());
    int bytesAdded=addSomeBlocks(fsdataset);
    blockReport=fsdataset.getBlockReport(bpid);
    assertEquals(NUMBLOCKS,blockReport.getNumberOfBlocks());
    for (    Block b : blockReport) {
      assertNotNull(b);
      assertEquals(blockIdToLen(b.getBlockId()),b.getNumBytes());
    }
    fsdataset=null;
    SimulatedFSDataset sfsdataset=getSimulatedFSDataset();
    bytesAdded+=addSomeBlocks(sfsdataset,NUMBLOCKS + 1,false);
    sfsdataset.getBlockReport(bpid);
    assertEquals(NUMBLOCKS,blockReport.getNumberOfBlocks());
    sfsdataset.getBlockReport(bpid);
    assertEquals(NUMBLOCKS,blockReport.getNumberOfBlocks());
    sfsdataset.injectBlocks(bpid,blockReport);
    blockReport=sfsdataset.getBlockReport(bpid);
    assertEquals(NUMBLOCKS * 2,blockReport.getNumberOfBlocks());
    for (    Block b : blockReport) {
      assertNotNull(b);
      assertEquals(blockIdToLen(b.getBlockId()),b.getNumBytes());
      assertEquals(blockIdToLen(b.getBlockId()),sfsdataset.getLength(new ExtendedBlock(bpid,b)));
    }
    assertEquals(bytesAdded,sfsdataset.getDfsUsed());
    assertEquals(sfsdataset.getCapacity() - bytesAdded,sfsdataset.getRemaining());
    conf.setLong(SimulatedFSDataset.CONFIG_PROPERTY_CAPACITY,10);
    try {
      sfsdataset=getSimulatedFSDataset();
      sfsdataset.addBlockPool(bpid,conf);
      sfsdataset.injectBlocks(bpid,blockReport);
      assertTrue("Expected an IO exception",false);
    }
 catch (    IOException e) {
    }
  }
  public void checkInvalidBlock(  ExtendedBlock b){
    final SimulatedFSDataset fsdataset=getSimulatedFSDataset();
    assertFalse(fsdataset.isValidBlock(b));
    try {
      fsdataset.getLength(b);
      assertTrue("Expected an IO exception",false);
    }
 catch (    IOException e) {
    }
    try {
      fsdataset.getBlockInputStream(b);
      assertTrue("Expected an IO exception",false);
    }
 catch (    IOException e) {
    }
    try {
      fsdataset.finalizeBlock(b);
      assertTrue("Expected an IO exception",false);
    }
 catch (    IOException e) {
    }
  }
  @Test public void testInValidBlocks() throws IOException {
    final SimulatedFSDataset fsdataset=getSimulatedFSDataset();
    ExtendedBlock b=new ExtendedBlock(bpid,FIRST_BLK_ID,5,0);
    checkInvalidBlock(b);
    addSomeBlocks(fsdataset);
    b=new ExtendedBlock(bpid,NUMBLOCKS + 99,5,0);
    checkInvalidBlock(b);
  }
  @Test public void testInvalidate() throws IOException {
    final SimulatedFSDataset fsdataset=getSimulatedFSDataset();
    int bytesAdded=addSomeBlocks(fsdataset);
    Block[] deleteBlocks=new Block[2];
    deleteBlocks[0]=new Block(1,0,0);
    deleteBlocks[1]=new Block(2,0,0);
    fsdataset.invalidate(bpid,deleteBlocks);
    checkInvalidBlock(new ExtendedBlock(bpid,deleteBlocks[0]));
    checkInvalidBlock(new ExtendedBlock(bpid,deleteBlocks[1]));
    long sizeDeleted=blockIdToLen(1) + blockIdToLen(2);
    assertEquals(bytesAdded - sizeDeleted,fsdataset.getDfsUsed());
    assertEquals(fsdataset.getCapacity() - bytesAdded + sizeDeleted,fsdataset.getRemaining());
    for (int i=3; i <= NUMBLOCKS; ++i) {
      Block b=new Block(i,0,0);
      assertTrue(fsdataset.isValidBlock(new ExtendedBlock(bpid,b)));
    }
  }
  private SimulatedFSDataset getSimulatedFSDataset(){
    SimulatedFSDataset fsdataset=new SimulatedFSDataset(null,conf);
    fsdataset.addBlockPool(bpid,conf);
    return fsdataset;
  }
  @Test public void testConcurrentAddBlockPool() throws InterruptedException, IOException {
    final String[] bpids={"BP-TEST1-","BP-TEST2-"};
    final SimulatedFSDataset fsdataset=new SimulatedFSDataset(null,conf);
class AddBlockPoolThread extends Thread {
      private int id;
      private IOException ioe;
      public AddBlockPoolThread(      int id){
        super();
        this.id=id;
      }
      public void test() throws InterruptedException, IOException {
        this.join();
        if (ioe != null) {
          throw ioe;
        }
      }
      public void run(){
        for (int i=0; i < 10000; i++) {
          String newbpid=bpids[id] + i;
          fsdataset.addBlockPool(newbpid,conf);
          ExtendedBlock block=new ExtendedBlock(newbpid,1);
          try {
            fsdataset.createTemporary(StorageType.DEFAULT,block);
          }
 catch (          IOException ioe) {
            this.ioe=ioe;
          }
          assert (fsdataset.getReplicaString(newbpid,1) != "null");
        }
      }
    }
    ;
    AddBlockPoolThread t1=new AddBlockPoolThread(0);
    AddBlockPoolThread t2=new AddBlockPoolThread(1);
    t1.start();
    t2.start();
    t1.test();
    t2.test();
  }
}
