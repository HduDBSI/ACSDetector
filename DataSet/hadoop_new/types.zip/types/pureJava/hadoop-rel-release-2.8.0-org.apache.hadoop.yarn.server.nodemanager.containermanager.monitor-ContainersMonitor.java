public interface ContainersMonitor extends Service, EventHandler<ContainersMonitorEvent>, ResourceView {
  public ResourceUtilization getContainersUtilization();
}
