@Private @Unstable public class GetClusterMetricsResponsePBImpl extends GetClusterMetricsResponse {
  GetClusterMetricsResponseProto proto=GetClusterMetricsResponseProto.getDefaultInstance();
  GetClusterMetricsResponseProto.Builder builder=null;
  boolean viaProto=false;
  private YarnClusterMetrics yarnClusterMetrics=null;
  public GetClusterMetricsResponsePBImpl(){
    builder=GetClusterMetricsResponseProto.newBuilder();
  }
  public GetClusterMetricsResponsePBImpl(  GetClusterMetricsResponseProto proto){
    this.proto=proto;
    viaProto=true;
  }
  public GetClusterMetricsResponseProto getProto(){
    mergeLocalToProto();
    proto=viaProto ? proto : builder.build();
    viaProto=true;
    return proto;
  }
  @Override public int hashCode(){
    return getProto().hashCode();
  }
  @Override public boolean equals(  Object other){
    if (other == null)     return false;
    if (other.getClass().isAssignableFrom(this.getClass())) {
      return this.getProto().equals(this.getClass().cast(other).getProto());
    }
    return false;
  }
  @Override public String toString(){
    return TextFormat.shortDebugString(getProto());
  }
  private void mergeLocalToBuilder(){
    if (this.yarnClusterMetrics != null) {
      builder.setClusterMetrics(convertToProtoFormat(this.yarnClusterMetrics));
    }
  }
  private void mergeLocalToProto(){
    if (viaProto)     maybeInitBuilder();
    mergeLocalToBuilder();
    proto=builder.build();
    viaProto=true;
  }
  private void maybeInitBuilder(){
    if (viaProto || builder == null) {
      builder=GetClusterMetricsResponseProto.newBuilder(proto);
    }
    viaProto=false;
  }
  @Override public YarnClusterMetrics getClusterMetrics(){
    GetClusterMetricsResponseProtoOrBuilder p=viaProto ? proto : builder;
    if (this.yarnClusterMetrics != null) {
      return this.yarnClusterMetrics;
    }
    if (!p.hasClusterMetrics()) {
      return null;
    }
    this.yarnClusterMetrics=convertFromProtoFormat(p.getClusterMetrics());
    return this.yarnClusterMetrics;
  }
  @Override public void setClusterMetrics(  YarnClusterMetrics clusterMetrics){
    maybeInitBuilder();
    if (clusterMetrics == null)     builder.clearClusterMetrics();
    this.yarnClusterMetrics=clusterMetrics;
  }
  private YarnClusterMetricsPBImpl convertFromProtoFormat(  YarnClusterMetricsProto p){
    return new YarnClusterMetricsPBImpl(p);
  }
  private YarnClusterMetricsProto convertToProtoFormat(  YarnClusterMetrics t){
    return ((YarnClusterMetricsPBImpl)t).getProto();
  }
}
