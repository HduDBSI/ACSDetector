/** 
 * Just a typed wrapper around  {@link BufferedMutator} used to ensure thatcolumns can write only to the table mutator for the right table.
 */
public interface TypedBufferedMutator<T> extends BufferedMutator {
}
