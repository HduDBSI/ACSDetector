/** 
 * Exception which Hadoop's AWSCredentialsProvider implementations should throw when there is a problem with the credential setup. This is a subclass of  {@link AmazonClientException} which sets{@link #isRetryable()} to false, so as to fail fast.
 */
public class CredentialInitializationException extends AmazonClientException {
  public CredentialInitializationException(  String message,  Throwable t){
    super(message,t);
  }
  public CredentialInitializationException(  String message){
    super(message);
  }
  /** 
 * This exception is not going to go away if you try calling it again.
 * @return false, always.
 */
  @Override public boolean isRetryable(){
    return false;
  }
}
