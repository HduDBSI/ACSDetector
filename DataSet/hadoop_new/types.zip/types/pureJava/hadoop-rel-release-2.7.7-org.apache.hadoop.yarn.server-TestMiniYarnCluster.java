public class TestMiniYarnCluster {
  @Test public void testTimelineServiceStartInMiniCluster() throws Exception {
    Configuration conf=new YarnConfiguration();
    int numNodeManagers=1;
    int numLocalDirs=1;
    int numLogDirs=1;
    boolean enableAHS;
    conf.setBoolean(YarnConfiguration.TIMELINE_SERVICE_ENABLED,false);
    enableAHS=false;
    MiniYARNCluster cluster=null;
    try {
      cluster=new MiniYARNCluster(TestMiniYarnCluster.class.getSimpleName(),numNodeManagers,numLocalDirs,numLogDirs,numLogDirs,enableAHS);
      cluster.init(conf);
      cluster.start();
      Assert.assertNull("Timeline Service should not have been started",cluster.getApplicationHistoryServer());
    }
  finally {
      if (cluster != null) {
        cluster.stop();
      }
    }
    conf.setBoolean(YarnConfiguration.TIMELINE_SERVICE_ENABLED,true);
    enableAHS=false;
    cluster=null;
    try {
      cluster=new MiniYARNCluster(TestMiniYarnCluster.class.getSimpleName(),numNodeManagers,numLocalDirs,numLogDirs,numLogDirs,enableAHS);
      cluster.init(conf);
      String hostname=MiniYARNCluster.getHostname();
      Assert.assertEquals(hostname + ":0",conf.get(YarnConfiguration.TIMELINE_SERVICE_ADDRESS));
      Assert.assertEquals(hostname + ":0",conf.get(YarnConfiguration.TIMELINE_SERVICE_WEBAPP_ADDRESS));
      cluster.start();
      int wait=0;
      while (cluster.getApplicationHistoryServer() == null && wait < 20) {
        Thread.sleep(500);
        wait++;
      }
      Assert.assertNotNull("Timeline Service should have been started",cluster.getApplicationHistoryServer());
    }
  finally {
      if (cluster != null) {
        cluster.stop();
      }
    }
    conf.setBoolean(YarnConfiguration.TIMELINE_SERVICE_ENABLED,false);
    enableAHS=true;
    cluster=null;
    try {
      cluster=new MiniYARNCluster(TestMiniYarnCluster.class.getSimpleName(),numNodeManagers,numLocalDirs,numLogDirs,numLogDirs,enableAHS);
      cluster.init(conf);
      cluster.start();
      int wait=0;
      while (cluster.getApplicationHistoryServer() == null && wait < 20) {
        Thread.sleep(500);
        wait++;
      }
      Assert.assertNotNull("Timeline Service should have been started",cluster.getApplicationHistoryServer());
    }
  finally {
      if (cluster != null) {
        cluster.stop();
      }
    }
  }
}
