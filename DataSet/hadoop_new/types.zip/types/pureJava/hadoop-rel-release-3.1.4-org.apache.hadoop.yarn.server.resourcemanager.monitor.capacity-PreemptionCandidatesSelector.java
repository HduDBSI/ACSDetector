public abstract class PreemptionCandidatesSelector {
  protected CapacitySchedulerPreemptionContext preemptionContext;
  protected ResourceCalculator rc;
  private long maximumKillWaitTime=-1;
  PreemptionCandidatesSelector(  CapacitySchedulerPreemptionContext preemptionContext){
    this.preemptionContext=preemptionContext;
    this.rc=preemptionContext.getResourceCalculator();
  }
  /** 
 * Get preemption candidates from computed resource sharing and already selected candidates.
 * @param selectedCandidates already selected candidates from previous policies
 * @param clusterResource total resource
 * @param totalPreemptedResourceAllowed how many resources allowed to bepreempted in this round. Should be updated(in-place set) after the call
 * @return merged selected candidates.
 */
  public abstract Map<ApplicationAttemptId,Set<RMContainer>> selectCandidates(  Map<ApplicationAttemptId,Set<RMContainer>> selectedCandidates,  Resource clusterResource,  Resource totalPreemptedResourceAllowed);
  /** 
 * Compare by reversed priority order first, and then reversed containerId order.
 * @param containers list of containers to sort for.
 */
  @VisibleForTesting static void sortContainers(  List<RMContainer> containers){
    Collections.sort(containers,new Comparator<RMContainer>(){
      @Override public int compare(      RMContainer a,      RMContainer b){
        int schedKeyComp=b.getAllocatedSchedulerKey().compareTo(a.getAllocatedSchedulerKey());
        if (schedKeyComp != 0) {
          return schedKeyComp;
        }
        return b.getContainerId().compareTo(a.getContainerId());
      }
    }
);
  }
  public long getMaximumKillWaitTimeMs(){
    if (maximumKillWaitTime > 0) {
      return maximumKillWaitTime;
    }
    return preemptionContext.getDefaultMaximumKillWaitTimeout();
  }
  public void setMaximumKillWaitTime(  long maximumKillWaitTime){
    this.maximumKillWaitTime=maximumKillWaitTime;
  }
}
