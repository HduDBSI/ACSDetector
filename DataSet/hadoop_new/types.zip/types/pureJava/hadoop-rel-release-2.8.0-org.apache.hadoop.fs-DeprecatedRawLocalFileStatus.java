@Deprecated static class DeprecatedRawLocalFileStatus extends FileStatus {
  private boolean isPermissionLoaded(){
    return !super.getOwner().isEmpty();
  }
  private static long getLastAccessTime(  File f) throws IOException {
    long accessTime;
    try {
      accessTime=Files.readAttributes(f.toPath(),BasicFileAttributes.class).lastAccessTime().toMillis();
    }
 catch (    NoSuchFileException e) {
      throw new FileNotFoundException("File " + f + " does not exist");
    }
    return accessTime;
  }
  DeprecatedRawLocalFileStatus(  File f,  long defaultBlockSize,  FileSystem fs) throws IOException {
    super(f.length(),f.isDirectory(),1,defaultBlockSize,f.lastModified(),getLastAccessTime(f),null,null,null,new Path(f.getPath()).makeQualified(fs.getUri(),fs.getWorkingDirectory()));
  }
  @Override public FsPermission getPermission(){
    if (!isPermissionLoaded()) {
      loadPermissionInfo();
    }
    return super.getPermission();
  }
  @Override public String getOwner(){
    if (!isPermissionLoaded()) {
      loadPermissionInfo();
    }
    return super.getOwner();
  }
  @Override public String getGroup(){
    if (!isPermissionLoaded()) {
      loadPermissionInfo();
    }
    return super.getGroup();
  }
  private void loadPermissionInfo(){
    IOException e=null;
    try {
      String output=FileUtil.execCommand(new File(getPath().toUri()),Shell.getGetPermissionCommand());
      StringTokenizer t=new StringTokenizer(output,Shell.TOKEN_SEPARATOR_REGEX);
      String permission=t.nextToken();
      if (permission.length() > FsPermission.MAX_PERMISSION_LENGTH) {
        permission=permission.substring(0,FsPermission.MAX_PERMISSION_LENGTH);
      }
      setPermission(FsPermission.valueOf(permission));
      t.nextToken();
      String owner=t.nextToken();
      if (Shell.WINDOWS) {
        int i=owner.indexOf('\\');
        if (i != -1)         owner=owner.substring(i + 1);
      }
      setOwner(owner);
      setGroup(t.nextToken());
    }
 catch (    Shell.ExitCodeException ioe) {
      if (ioe.getExitCode() != 1) {
        e=ioe;
      }
 else {
        setPermission(null);
        setOwner(null);
        setGroup(null);
      }
    }
catch (    IOException ioe) {
      e=ioe;
    }
 finally {
      if (e != null) {
        throw new RuntimeException("Error while running command to get " + "file permissions : " + StringUtils.stringifyException(e));
      }
    }
  }
  @Override public void write(  DataOutput out) throws IOException {
    if (!isPermissionLoaded()) {
      loadPermissionInfo();
    }
    super.write(out);
  }
}
