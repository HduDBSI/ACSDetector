/** 
 * Used to read bytes into a user-supplied ByteBuffer
 */
protected class ByteBufferStrategy implements ReaderStrategy {
  final ByteBuffer buf;
  ByteBufferStrategy(  ByteBuffer buf){
    this.buf=buf;
  }
  @Override public int doRead(  BlockReader blockReader,  int off,  int len) throws IOException {
    ByteBuffer tmpBuf=buf.duplicate();
    tmpBuf.limit(tmpBuf.position() + len);
    int nRead=blockReader.read(tmpBuf);
    updateReadStatistics(readStatistics,nRead,blockReader);
    dfsClient.updateFileSystemReadStats(blockReader.getNetworkDistance(),nRead);
    if (nRead > 0) {
      buf.position(buf.position() + nRead);
    }
    return nRead;
  }
  @Override public int copyFrom(  ByteBuffer src,  int offset,  int length){
    ByteBuffer writeSlice=src.duplicate();
    int remaining=Math.min(buf.remaining(),writeSlice.remaining());
    writeSlice.limit(writeSlice.position() + remaining);
    buf.put(writeSlice);
    return remaining;
  }
}
