class AMRMClientCallback extends AMRMClientAsync.AbstractCallbackHandler {
  @Override public void onContainersAllocated(  List<Container> containers){
    LOG.info(containers.size() + " containers allocated. ");
    for (    Container container : containers) {
      Component comp=componentsById.get(container.getAllocationRequestId());
      ComponentEvent event=new ComponentEvent(comp.getName(),CONTAINER_ALLOCATED).setContainer(container);
      dispatcher.getEventHandler().handle(event);
      try {
        Collection<AMRMClient.ContainerRequest> requests=amRMClient.getMatchingRequests(container.getAllocationRequestId());
        LOG.info("[COMPONENT {}]: remove {} outstanding container requests " + "for allocateId " + container.getAllocationRequestId(),comp.getName(),requests.size());
        if (requests.iterator().hasNext()) {
          AMRMClient.ContainerRequest request=requests.iterator().next();
          amRMClient.removeContainerRequest(request);
        }
      }
 catch (      Exception e) {
        LOG.error("Exception when removing the matching requests. ",e);
      }
    }
  }
  @Override public void onContainersReceivedFromPreviousAttempts(  List<Container> containers){
    LOG.info("Containers recovered after AM registered: {}",containers);
    if (containers == null || containers.isEmpty()) {
      return;
    }
    for (    Container container : containers) {
      ComponentInstance compInstance;
synchronized (unRecoveredInstances) {
        compInstance=unRecoveredInstances.remove(container.getId());
      }
      if (compInstance != null) {
        Component component=componentsById.get(container.getAllocationRequestId());
        ComponentEvent event=new ComponentEvent(component.getName(),CONTAINER_RECOVERED).setInstance(compInstance).setContainerId(container.getId()).setContainer(container);
        component.handle(event);
      }
 else {
        LOG.info("Not waiting to recover container {}, releasing",container.getId());
        amRMClient.releaseAssignedContainer(container.getId());
      }
    }
  }
  @Override public void onContainersCompleted(  List<ContainerStatus> statuses){
    for (    ContainerStatus status : statuses) {
      ContainerId containerId=status.getContainerId();
      ComponentInstance instance=liveInstances.get(status.getContainerId());
      if (instance == null) {
        LOG.warn("Container {} Completed. No component instance exists. exitStatus={}. diagnostics={} ",containerId,status.getExitStatus(),status.getDiagnostics());
        continue;
      }
      ComponentEvent event=new ComponentEvent(instance.getCompName(),CONTAINER_COMPLETED).setStatus(status).setInstance(instance).setContainerId(containerId);
      dispatcher.getEventHandler().handle(event);
    }
  }
  @Override public void onContainersUpdated(  List<UpdatedContainer> containers){
  }
  @Override public void onShutdownRequest(){
  }
  @Override public void onNodesUpdated(  List<NodeReport> updatedNodes){
    StringBuilder str=new StringBuilder();
    str.append("Nodes updated info: ").append(System.lineSeparator());
    for (    NodeReport report : updatedNodes) {
      str.append(report.getNodeId()).append(", state = ").append(report.getNodeState()).append(", healthDiagnostics = ").append(report.getHealthReport()).append(System.lineSeparator());
    }
    LOG.warn(str.toString());
  }
  @Override public float getProgress(){
    long total=0;
    for (    org.apache.hadoop.yarn.service.api.records.Component component : app.getComponents()) {
      total+=component.getNumberOfContainers();
    }
    if (total == 0) {
      return 100;
    }
    return Math.max((float)liveInstances.size() / total * 100,100);
  }
  @Override public void onError(  Throwable e){
    LOG.error("Error in AMRMClient callback handler ",e);
  }
  @Override public void onRequestsRejected(  List<RejectedSchedulingRequest> rejectedSchedulingRequests){
    LOG.error("Error in AMRMClient callback handler. Following scheduling " + "requests were rejected: {}",rejectedSchedulingRequests);
  }
}
