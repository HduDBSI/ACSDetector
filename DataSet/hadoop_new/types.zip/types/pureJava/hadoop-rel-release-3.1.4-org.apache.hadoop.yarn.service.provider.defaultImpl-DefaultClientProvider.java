public class DefaultClientProvider extends AbstractClientProvider {
  public DefaultClientProvider(){
  }
  @Override public void validateArtifact(  Artifact artifact,  String compName,  FileSystem fileSystem){
  }
  @Override @VisibleForTesting public void validateConfigFile(  ConfigFile configFile,  String compName,  FileSystem fileSystem) throws IOException {
    if (Paths.get(configFile.getDestFile()).isAbsolute()) {
      throw new IllegalArgumentException(String.format(RestApiErrorMessages.ERROR_CONFIGFILE_DEST_FILE_FOR_COMP_NOT_ABSOLUTE,compName,"no",configFile.getDestFile()));
    }
  }
}
