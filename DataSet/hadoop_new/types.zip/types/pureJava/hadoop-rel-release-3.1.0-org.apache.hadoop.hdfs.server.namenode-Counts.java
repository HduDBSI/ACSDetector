/** 
 * Counters for quota counts. 
 */
public static class Counts extends EnumCounters<Quota> {
  /** 
 * @return a new counter with the given namespace and storagespace usages. 
 */
  public static Counts newInstance(  long namespace,  long storagespace){
    final Counts c=new Counts();
    c.set(NAMESPACE,namespace);
    c.set(STORAGESPACE,storagespace);
    return c;
  }
  public static Counts newInstance(){
    return newInstance(0,0);
  }
  Counts(){
    super(Quota.class);
  }
}
