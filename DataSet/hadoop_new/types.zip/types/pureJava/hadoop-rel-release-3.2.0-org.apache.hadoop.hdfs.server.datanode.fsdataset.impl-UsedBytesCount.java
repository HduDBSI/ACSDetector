private class UsedBytesCount {
  private final AtomicLong usedBytes=new AtomicLong(0);
  private final PageRounder rounder=new PageRounder();
  /** 
 * Try to reserve more bytes.
 * @param count    The number of bytes to add.  We will round thisup to the page size.
 * @return         The new number of usedBytes if we succeeded;-1 if we failed.
 */
  long reserve(  long count){
    count=rounder.roundUp(count);
    while (true) {
      long cur=usedBytes.get();
      long next=cur + count;
      if (next > maxBytes) {
        return -1;
      }
      if (usedBytes.compareAndSet(cur,next)) {
        return next;
      }
    }
  }
  /** 
 * Release some bytes that we're using.
 * @param count    The number of bytes to release.  We will round thisup to the page size.
 * @return         The new number of usedBytes.
 */
  long release(  long count){
    count=rounder.roundUp(count);
    return usedBytes.addAndGet(-count);
  }
  /** 
 * Release some bytes that we're using rounded down to the page size.
 * @param count    The number of bytes to release.  We will round thisdown to the page size.
 * @return         The new number of usedBytes.
 */
  long releaseRoundDown(  long count){
    count=rounder.roundDown(count);
    return usedBytes.addAndGet(-count);
  }
  long get(){
    return usedBytes.get();
  }
}
