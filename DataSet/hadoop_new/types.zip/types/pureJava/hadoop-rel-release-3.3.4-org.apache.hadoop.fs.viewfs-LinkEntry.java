/** 
 * An internal class representing the ViewFileSystem mount table link entries and their attributes.
 * @see LinkType
 */
private static class LinkEntry {
  private final String src;
  private final String target;
  private final LinkType linkType;
  private final String settings;
  private final UserGroupInformation ugi;
  private final Configuration config;
  LinkEntry(  String src,  String target,  LinkType linkType,  String settings,  UserGroupInformation ugi,  Configuration config){
    this.src=src;
    this.target=target;
    this.linkType=linkType;
    this.settings=settings;
    this.ugi=ugi;
    this.config=config;
  }
  String getSrc(){
    return src;
  }
  String getTarget(){
    return target;
  }
  LinkType getLinkType(){
    return linkType;
  }
  boolean isLinkType(  LinkType type){
    return this.linkType == type;
  }
  String getSettings(){
    return settings;
  }
  UserGroupInformation getUgi(){
    return ugi;
  }
  Configuration getConfig(){
    return config;
  }
}
