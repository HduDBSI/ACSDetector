/** 
 * Support session credentials for authenticating with Aliyun.
 */
public class AliyunCredentialsProvider implements CredentialsProvider {
  private Credentials credentials=null;
  public AliyunCredentialsProvider(  Configuration conf) throws IOException {
    String accessKeyId;
    String accessKeySecret;
    String securityToken;
    try {
      accessKeyId=AliyunOSSUtils.getValueWithKey(conf,ACCESS_KEY_ID);
      accessKeySecret=AliyunOSSUtils.getValueWithKey(conf,ACCESS_KEY_SECRET);
    }
 catch (    IOException e) {
      throw new InvalidCredentialsException(e);
    }
    try {
      securityToken=AliyunOSSUtils.getValueWithKey(conf,SECURITY_TOKEN);
    }
 catch (    IOException e) {
      securityToken=null;
    }
    if (StringUtils.isEmpty(accessKeyId) || StringUtils.isEmpty(accessKeySecret)) {
      throw new InvalidCredentialsException("AccessKeyId and AccessKeySecret should not be null or empty.");
    }
    if (StringUtils.isNotEmpty(securityToken)) {
      credentials=new DefaultCredentials(accessKeyId,accessKeySecret,securityToken);
    }
 else {
      credentials=new DefaultCredentials(accessKeyId,accessKeySecret);
    }
  }
  @Override public void setCredentials(  Credentials creds){
    if (creds == null) {
      throw new InvalidCredentialsException("Credentials should not be null.");
    }
    credentials=creds;
  }
  @Override public Credentials getCredentials(){
    if (credentials == null) {
      throw new InvalidCredentialsException("Invalid credentials");
    }
    return credentials;
  }
}
