/** 
 * An interface for the elements in a  {@link Diff}. 
 */
public static interface Element<K> extends Comparable<K> {
  /** 
 * @return the key of this object. 
 */
  public K getKey();
}
