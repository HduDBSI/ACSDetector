private static class Entry {
  private byte[] content;
  private HashMap<String,String> metadata;
  private boolean isPageBlob;
  @SuppressWarnings("unused") private long length;
  public Entry(  byte[] content,  HashMap<String,String> metadata,  boolean isPageBlob,  long length){
    this.content=content;
    this.metadata=metadata;
    this.isPageBlob=isPageBlob;
    this.length=length;
  }
}
