@Private @Unstable public class URLPBImpl extends URL {
  URLProto proto=URLProto.getDefaultInstance();
  URLProto.Builder builder=null;
  boolean viaProto=false;
  public URLPBImpl(){
    builder=URLProto.newBuilder();
  }
  public URLPBImpl(  URLProto proto){
    this.proto=proto;
    viaProto=true;
  }
  public URLProto getProto(){
    proto=viaProto ? proto : builder.build();
    viaProto=true;
    return proto;
  }
  @Override public int hashCode(){
    return getProto().hashCode();
  }
  @Override public boolean equals(  Object other){
    if (other == null)     return false;
    if (other.getClass().isAssignableFrom(this.getClass())) {
      return this.getProto().equals(this.getClass().cast(other).getProto());
    }
    return false;
  }
  @Override public String toString(){
    return TextFormat.shortDebugString(getProto());
  }
  private void maybeInitBuilder(){
    if (viaProto || builder == null) {
      builder=URLProto.newBuilder(proto);
    }
    viaProto=false;
  }
  @Override public String getFile(){
    URLProtoOrBuilder p=viaProto ? proto : builder;
    if (!p.hasFile()) {
      return null;
    }
    return (p.getFile());
  }
  @Override public void setFile(  String file){
    maybeInitBuilder();
    if (file == null) {
      builder.clearFile();
      return;
    }
    builder.setFile((file));
  }
  @Override public String getScheme(){
    URLProtoOrBuilder p=viaProto ? proto : builder;
    if (!p.hasScheme()) {
      return null;
    }
    return (p.getScheme());
  }
  @Override public void setScheme(  String scheme){
    maybeInitBuilder();
    if (scheme == null) {
      builder.clearScheme();
      return;
    }
    builder.setScheme((scheme));
  }
  @Override public String getUserInfo(){
    URLProtoOrBuilder p=viaProto ? proto : builder;
    if (!p.hasUserInfo()) {
      return null;
    }
    return (p.getUserInfo());
  }
  @Override public void setUserInfo(  String userInfo){
    maybeInitBuilder();
    if (userInfo == null) {
      builder.clearUserInfo();
      return;
    }
    builder.setUserInfo((userInfo));
  }
  @Override public String getHost(){
    URLProtoOrBuilder p=viaProto ? proto : builder;
    if (!p.hasHost()) {
      return null;
    }
    return (p.getHost());
  }
  @Override public void setHost(  String host){
    maybeInitBuilder();
    if (host == null) {
      builder.clearHost();
      return;
    }
    builder.setHost((host));
  }
  @Override public int getPort(){
    URLProtoOrBuilder p=viaProto ? proto : builder;
    return (p.getPort());
  }
  @Override public void setPort(  int port){
    maybeInitBuilder();
    builder.setPort((port));
  }
}
