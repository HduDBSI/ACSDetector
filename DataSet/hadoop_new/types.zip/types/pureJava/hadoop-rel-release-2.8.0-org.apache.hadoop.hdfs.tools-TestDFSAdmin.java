/** 
 * set/clrSpaceQuote are tested in  {@link org.apache.hadoop.hdfs.TestQuota}.
 */
public class TestDFSAdmin {
  private Configuration conf=null;
  private MiniDFSCluster cluster;
  private DFSAdmin admin;
  private DataNode datanode;
  private final ByteArrayOutputStream out=new ByteArrayOutputStream();
  private final ByteArrayOutputStream err=new ByteArrayOutputStream();
  private static final PrintStream OLD_OUT=System.out;
  private static final PrintStream OLD_ERR=System.err;
  @Before public void setUp() throws Exception {
    conf=new Configuration();
    conf.setInt(IPC_CLIENT_CONNECT_MAX_RETRIES_KEY,3);
    restartCluster();
    admin=new DFSAdmin();
  }
  private void redirectStream(){
    System.setOut(new PrintStream(out));
    System.setErr(new PrintStream(err));
  }
  private void resetStream(){
    out.reset();
    err.reset();
  }
  @After public void tearDown() throws Exception {
    try {
      System.out.flush();
      System.err.flush();
    }
  finally {
      System.setOut(OLD_OUT);
      System.setErr(OLD_ERR);
    }
    if (cluster != null) {
      cluster.shutdown();
      cluster=null;
    }
    resetStream();
  }
  private void restartCluster() throws IOException {
    if (cluster != null) {
      cluster.shutdown();
    }
    cluster=new MiniDFSCluster.Builder(conf).numDataNodes(2).build();
    cluster.waitActive();
    datanode=cluster.getDataNodes().get(0);
  }
  private List<String> getReconfigureStatus(  String nodeType,  String address) throws IOException {
    ByteArrayOutputStream bufOut=new ByteArrayOutputStream();
    PrintStream outStream=new PrintStream(bufOut);
    ByteArrayOutputStream bufErr=new ByteArrayOutputStream();
    PrintStream errStream=new PrintStream(bufErr);
    admin.getReconfigurationStatus(nodeType,address,outStream,errStream);
    List<String> outputs=Lists.newArrayList();
    scanIntoList(bufOut,outputs);
    return outputs;
  }
  private static void scanIntoList(  final ByteArrayOutputStream baos,  final List<String> list){
    final Scanner scanner=new Scanner(baos.toString());
    while (scanner.hasNextLine()) {
      list.add(scanner.nextLine());
    }
    scanner.close();
  }
  @Test(timeout=30000) public void testGetDatanodeInfo() throws Exception {
    redirectStream();
    final DFSAdmin dfsAdmin=new DFSAdmin(conf);
    for (int i=0; i < cluster.getDataNodes().size(); i++) {
      resetStream();
      final DataNode dn=cluster.getDataNodes().get(i);
      final String addr=String.format("%s:%d",dn.getXferAddress().getHostString(),dn.getIpcPort());
      final int ret=ToolRunner.run(dfsAdmin,new String[]{"-getDatanodeInfo",addr});
      assertEquals(0,ret);
      final List<String> outs=Lists.newArrayList();
      scanIntoList(out,outs);
      assertEquals("One line per DataNode like: Uptime: XXX, Software version: x.y.z," + " Config version: core-x.y.z,hdfs-x",1,outs.size());
      assertThat(outs.get(0),is(allOf(containsString("Uptime:"),containsString("Software version"),containsString("Config version"))));
    }
  }
  /** 
 * Test that if datanode is not reachable, some DFSAdmin commands will fail elegantly with non-zero ret error code along with exception error message.
 */
  @Test(timeout=60000) public void testDFSAdminUnreachableDatanode() throws Exception {
    redirectStream();
    final DFSAdmin dfsAdmin=new DFSAdmin(conf);
    for (    String command : new String[]{"-getDatanodeInfo","-evictWriters","-getBalancerBandwidth"}) {
      final String dnDataAddr=datanode.getXferAddress().getHostString() + ":" + datanode.getXferPort();
      resetStream();
      final List<String> outs=Lists.newArrayList();
      final int ret=ToolRunner.run(dfsAdmin,new String[]{command,dnDataAddr});
      assertEquals(-1,ret);
      scanIntoList(out,outs);
      assertTrue("Unexpected " + command + " stdout: "+ out,outs.isEmpty());
      assertTrue("Unexpected " + command + " stderr: "+ err,err.toString().contains("Exception"));
    }
  }
  @Test(timeout=30000) public void testPrintTopology() throws Exception {
    redirectStream();
    final Configuration dfsConf=new HdfsConfiguration();
    final File baseDir=new File(PathUtils.getTestDir(getClass()),GenericTestUtils.getMethodName());
    dfsConf.set(MiniDFSCluster.HDFS_MINIDFS_BASEDIR,baseDir.getAbsolutePath());
    final int numDn=4;
    final String[] racks={"/d1/r1","/d1/r2","/d2/r1","/d2/r2"};
    try (MiniDFSCluster miniCluster=new MiniDFSCluster.Builder(dfsConf).numDataNodes(numDn).racks(racks).build()){
      miniCluster.waitActive();
      assertEquals(numDn,miniCluster.getDataNodes().size());
      final DFSAdmin dfsAdmin=new DFSAdmin(dfsConf);
      resetStream();
      final int ret=ToolRunner.run(dfsAdmin,new String[]{"-printTopology"});
      final List<String> outs=Lists.newArrayList();
      scanIntoList(out,outs);
      assertEquals(0,ret);
      assertEquals("There should be three lines per Datanode: the 1st line is" + " rack info, 2nd node info, 3rd empty line. The total" + " should be as a result of 3 * numDn.",12,outs.size());
      assertThat(outs.get(0),is(allOf(containsString("Rack:"),containsString("/d1/r1"))));
      assertThat(outs.get(3),is(allOf(containsString("Rack:"),containsString("/d1/r2"))));
      assertThat(outs.get(6),is(allOf(containsString("Rack:"),containsString("/d2/r1"))));
      assertThat(outs.get(9),is(allOf(containsString("Rack:"),containsString("/d2/r2"))));
    }
   }
  /** 
 * Test reconfiguration and check the status outputs.
 * @param expectedSuccuss set true if the reconfiguration task should success.
 * @throws IOException
 * @throws InterruptedException
 */
  private void testGetReconfigurationStatus(  boolean expectedSuccuss) throws IOException, InterruptedException {
    ReconfigurationUtil ru=mock(ReconfigurationUtil.class);
    datanode.setReconfigurationUtil(ru);
    List<ReconfigurationUtil.PropertyChange> changes=new ArrayList<>();
    File newDir=new File(cluster.getDataDirectory(),"data_new");
    if (expectedSuccuss) {
      newDir.mkdirs();
    }
 else {
      newDir.createNewFile();
    }
    changes.add(new ReconfigurationUtil.PropertyChange(DFS_DATANODE_DATA_DIR_KEY,newDir.toString(),datanode.getConf().get(DFS_DATANODE_DATA_DIR_KEY)));
    changes.add(new ReconfigurationUtil.PropertyChange("randomKey","new123","old456"));
    when(ru.parseChangedProperties(any(Configuration.class),any(Configuration.class))).thenReturn(changes);
    final int port=datanode.getIpcPort();
    final String address="localhost:" + port;
    assertThat(admin.startReconfiguration("datanode",address),is(0));
    List<String> outputs=null;
    int count=100;
    while (count > 0) {
      outputs=getReconfigureStatus("datanode",address);
      if (!outputs.isEmpty() && outputs.get(0).contains("finished")) {
        break;
      }
      count--;
      Thread.sleep(100);
    }
    assertTrue(count > 0);
    if (expectedSuccuss) {
      assertThat(outputs.size(),is(4));
    }
 else {
      assertThat(outputs.size(),is(6));
    }
    List<StorageLocation> locations=DataNode.getStorageLocations(datanode.getConf());
    if (expectedSuccuss) {
      assertThat(locations.size(),is(1));
      assertThat(locations.get(0).getFile(),is(newDir));
      assertTrue(new File(newDir,Storage.STORAGE_DIR_CURRENT).isDirectory());
    }
 else {
      assertTrue(locations.isEmpty());
    }
    int offset=1;
    if (expectedSuccuss) {
      assertThat(outputs.get(offset),containsString("SUCCESS: Changed property " + DFS_DATANODE_DATA_DIR_KEY));
    }
 else {
      assertThat(outputs.get(offset),containsString("FAILED: Change property " + DFS_DATANODE_DATA_DIR_KEY));
    }
    assertThat(outputs.get(offset + 1),is(allOf(containsString("From:"),containsString("data1"),containsString("data2"))));
    assertThat(outputs.get(offset + 2),is(not(anyOf(containsString("data1"),containsString("data2")))));
    assertThat(outputs.get(offset + 2),is(allOf(containsString("To"),containsString("data_new"))));
  }
  @Test(timeout=30000) public void testGetReconfigurationStatus() throws IOException, InterruptedException {
    testGetReconfigurationStatus(true);
    restartCluster();
    testGetReconfigurationStatus(false);
  }
  private List<String> getReconfigurationAllowedProperties(  String nodeType,  String address) throws IOException {
    ByteArrayOutputStream bufOut=new ByteArrayOutputStream();
    PrintStream outStream=new PrintStream(bufOut);
    ByteArrayOutputStream bufErr=new ByteArrayOutputStream();
    PrintStream errStream=new PrintStream(bufErr);
    admin.getReconfigurableProperties(nodeType,address,outStream,errStream);
    List<String> outputs=Lists.newArrayList();
    scanIntoList(bufOut,outputs);
    return outputs;
  }
  @Test(timeout=30000) public void testGetReconfigAllowedProperties() throws IOException {
    final int port=datanode.getIpcPort();
    final String address="localhost:" + port;
    List<String> outputs=getReconfigurationAllowedProperties("datanode",address);
    assertEquals(3,outputs.size());
    assertEquals(DFSConfigKeys.DFS_DATANODE_DATA_DIR_KEY,outputs.get(1));
  }
  private static String scanIntoString(  final ByteArrayOutputStream baos){
    final StrBuilder sb=new StrBuilder();
    final Scanner scanner=new Scanner(baos.toString());
    while (scanner.hasNextLine()) {
      sb.appendln(scanner.nextLine());
    }
    scanner.close();
    return sb.toString();
  }
  @Test(timeout=120000) public void testReportCommand() throws Exception {
    redirectStream();
    final Configuration dfsConf=new HdfsConfiguration();
    dfsConf.setInt(DFSConfigKeys.DFS_NAMENODE_HEARTBEAT_RECHECK_INTERVAL_KEY,500);
    dfsConf.setLong(DFSConfigKeys.DFS_HEARTBEAT_INTERVAL_KEY,1);
    final Path baseDir=new Path(PathUtils.getTestDir(getClass()).getAbsolutePath(),GenericTestUtils.getMethodName());
    dfsConf.set(MiniDFSCluster.HDFS_MINIDFS_BASEDIR,baseDir.toString());
    final int numDn=3;
    try (MiniDFSCluster miniCluster=new MiniDFSCluster.Builder(dfsConf).numDataNodes(numDn).build()){
      miniCluster.waitActive();
      assertEquals(numDn,miniCluster.getDataNodes().size());
      final DFSAdmin dfsAdmin=new DFSAdmin(dfsConf);
      final DFSClient client=miniCluster.getFileSystem().getClient();
      resetStream();
      assertEquals(0,ToolRunner.run(dfsAdmin,new String[]{"-report"}));
      verifyNodesAndCorruptBlocks(numDn,numDn,0,client);
      final List<DataNode> datanodes=miniCluster.getDataNodes();
      final DataNode last=datanodes.get(datanodes.size() - 1);
      last.shutdown();
      miniCluster.setDataNodeDead(last.getDatanodeId());
      assertEquals(0,ToolRunner.run(dfsAdmin,new String[]{"-report"}));
      verifyNodesAndCorruptBlocks(numDn,numDn - 1,0,client);
      final short replFactor=1;
      final long fileLength=512L;
      final FileSystem fs=miniCluster.getFileSystem();
      final Path file=new Path(baseDir,"/corrupted");
      DFSTestUtil.createFile(fs,file,fileLength,replFactor,12345L);
      DFSTestUtil.waitReplication(fs,file,replFactor);
      final ExtendedBlock block=DFSTestUtil.getFirstBlock(fs,file);
      final int blockFilesCorrupted=miniCluster.corruptBlockOnDataNodes(block);
      assertEquals("Fail to corrupt all replicas for block " + block,replFactor,blockFilesCorrupted);
      try {
        IOUtils.copyBytes(fs.open(file),new IOUtils.NullOutputStream(),conf,true);
        fail("Should have failed to read the file with corrupted blocks.");
      }
 catch (      ChecksumException ignored) {
      }
      fs.setReplication(file,(short)(replFactor + 1));
      GenericTestUtils.waitFor(new Supplier<Boolean>(){
        @Override public Boolean get(){
          LocatedBlocks blocks=null;
          try {
            miniCluster.triggerBlockReports();
            blocks=client.getNamenode().getBlockLocations(file.toString(),0,Long.MAX_VALUE);
          }
 catch (          IOException e) {
            return false;
          }
          return blocks != null && blocks.get(0).isCorrupt();
        }
      }
,1000,60000);
      BlockManagerTestUtil.updateState(miniCluster.getNameNode().getNamesystem().getBlockManager());
      resetStream();
      assertEquals(0,ToolRunner.run(dfsAdmin,new String[]{"-report"}));
      verifyNodesAndCorruptBlocks(numDn,numDn - 1,1,client);
    }
   }
  private void verifyNodesAndCorruptBlocks(  final int numDn,  final int numLiveDn,  final int numCorruptBlocks,  final DFSClient client) throws IOException {
    final String outStr=scanIntoString(out);
    final String expectedLiveNodesStr=String.format("Live datanodes (%d)",numLiveDn);
    final String expectedCorruptedBlocksStr=String.format("Blocks with corrupt replicas: %d",numCorruptBlocks);
    assertThat(outStr,is(allOf(containsString(expectedLiveNodesStr),containsString(expectedCorruptedBlocksStr))));
    assertEquals(numDn,client.getDatanodeStorageReport(DatanodeReportType.ALL).length);
    assertEquals(numLiveDn,client.getDatanodeStorageReport(DatanodeReportType.LIVE).length);
    assertEquals(numDn - numLiveDn,client.getDatanodeStorageReport(DatanodeReportType.DEAD).length);
    assertEquals(numCorruptBlocks,client.getCorruptBlocksCount());
  }
}
