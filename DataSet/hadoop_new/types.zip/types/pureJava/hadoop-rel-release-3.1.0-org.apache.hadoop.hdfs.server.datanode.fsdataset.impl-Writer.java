private static class Writer extends Daemon {
  private volatile boolean keepRunning;
  private final DFSClient localClient;
  private int filesCreated=0;
  private int numFailures=0;
  byte[] data;
  Writer(  DFSClient client,  int blockSize) throws IOException {
    localClient=client;
    keepRunning=true;
    filesCreated=0;
    numFailures=0;
    data=new byte[blockSize * 2];
  }
  @Override public void run(){
    while (keepRunning) {
      OutputStream os=null;
      try {
        String filename="/file-" + rand.nextLong();
        os=localClient.create(filename,false);
        os.write(data,0,rand.nextInt(data.length));
        IOUtils.closeQuietly(os);
        os=null;
        localClient.delete(filename,false);
        Thread.sleep(50);
        ++filesCreated;
      }
 catch (      IOException ioe) {
        ++numFailures;
      }
catch (      InterruptedException ie) {
        return;
      }
 finally {
        if (os != null) {
          IOUtils.closeQuietly(os);
        }
      }
    }
  }
  public void stopWriter(){
    keepRunning=false;
  }
  public int getFilesCreated(){
    return filesCreated;
  }
  public int getNumFailures(){
    return numFailures;
  }
}
