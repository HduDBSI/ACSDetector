public class TestHAAppend {
  static final int COUNT=5;
  static FSDataOutputStream createAndHflush(  FileSystem fs,  Path file,  byte[] data,  int length) throws IOException {
    FSDataOutputStream out=fs.create(file,false,4096,(short)3,1024);
    out.write(data,0,length);
    out.hflush();
    return out;
  }
  /** 
 * Test to verify the processing of PendingDataNodeMessageQueue in case of append. One block will marked as corrupt if the OP_ADD, OP_UPDATE_BLOCKS comes in one edit log segment and OP_CLOSE edit comes in next log segment which is loaded during failover. Regression test for HDFS-3605.
 */
  @Test public void testMultipleAppendsDuringCatchupTailing() throws Exception {
    Configuration conf=new Configuration();
    conf.set(DFSConfigKeys.DFS_HA_TAILEDITS_PERIOD_KEY,"5000");
    conf.setInt(DFSConfigKeys.DFS_HA_LOGROLL_PERIOD_KEY,-1);
    MiniDFSCluster cluster=new MiniDFSCluster.Builder(conf).nnTopology(MiniDFSNNTopology.simpleHATopology()).numDataNodes(3).build();
    FileSystem fs=null;
    try {
      cluster.transitionToActive(0);
      fs=HATestUtil.configureFailoverFs(cluster,conf);
      Path fileToAppend=new Path("/FileToAppend");
      Path fileToTruncate=new Path("/FileToTruncate");
      final byte[] data=new byte[1 << 16];
      DFSUtil.getRandom().nextBytes(data);
      final int[] appendPos=AppendTestUtil.randomFilePartition(data.length,COUNT);
      final int[] truncatePos=AppendTestUtil.randomFilePartition(data.length,1);
      FSDataOutputStream out=createAndHflush(fs,fileToAppend,data,appendPos[0]);
      FSDataOutputStream out4Truncate=createAndHflush(fs,fileToTruncate,data,data.length);
      cluster.getNameNode(0).getRpcServer().rollEditLog();
      cluster.getNameNode(1).getNamesystem().getEditLogTailer().doTailEdits();
      out.close();
      out4Truncate.close();
      for (int i=0; i < COUNT; i++) {
        int end=i < COUNT - 1 ? appendPos[i + 1] : data.length;
        out=fs.append(fileToAppend);
        out.write(data,appendPos[i],end - appendPos[i]);
        out.close();
      }
      boolean isTruncateReady=fs.truncate(fileToTruncate,truncatePos[0]);
      cluster.triggerBlockReports();
      cluster.shutdownNameNode(0);
      cluster.transitionToActive(1);
      int rc=ToolRunner.run(new DFSck(cluster.getConfiguration(1)),new String[]{"/","-files","-blocks"});
      assertEquals(0,rc);
      assertEquals("CorruptBlocks should be empty.",0,cluster.getNameNode(1).getNamesystem().getCorruptReplicaBlocks());
      AppendTestUtil.checkFullFile(fs,fileToAppend,data.length,data,fileToAppend.toString());
      if (!isTruncateReady) {
        TestFileTruncate.checkBlockRecovery(fileToTruncate,cluster.getFileSystem(1));
      }
      AppendTestUtil.checkFullFile(fs,fileToTruncate,truncatePos[0],data,fileToTruncate.toString());
    }
  finally {
      if (null != cluster) {
        cluster.shutdown();
      }
      if (null != fs) {
        fs.close();
      }
    }
  }
}
