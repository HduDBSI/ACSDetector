public class TestNameNodeRpcServer {
  @Test public void testNamenodeRpcBindAny() throws IOException {
    Configuration conf=new HdfsConfiguration();
    conf.set(DFS_NAMENODE_RPC_BIND_HOST_KEY,"0.0.0.0");
    MiniDFSCluster cluster=null;
    try {
      cluster=new MiniDFSCluster.Builder(conf).build();
      cluster.waitActive();
      assertEquals("0.0.0.0",((NameNodeRpcServer)cluster.getNameNodeRpc()).getClientRpcServer().getListenerAddress().getHostName());
    }
  finally {
      if (cluster != null) {
        cluster.shutdown();
      }
      conf.unset(DFS_NAMENODE_RPC_BIND_HOST_KEY);
    }
  }
  /** 
 * Get the preferred DataNode location for the first block of the given file.
 * @param fs The file system to use
 * @param p The path to use
 * @return the preferred host to get the data
 */
  private static String getPreferredLocation(  DistributedFileSystem fs,  Path p) throws IOException {
    LocatedBlocks blocks=fs.getClient().getLocatedBlocks(p.toUri().getPath(),0);
    return blocks.get(0).getLocations()[0].getHostName();
  }
  static final int ITERATIONS_TO_USE=20;
  /** 
 * A test to make sure that if an authorized user adds "clientIp:" to their caller context, it will be used to make locality decisions on the NN.
 */
  @Test public void testNamenodeRpcClientIpProxy() throws IOException {
    Configuration conf=new HdfsConfiguration();
    conf.set(DFS_NAMENODE_IP_PROXY_USERS,"fake_joe");
    final String[] racks=new String[]{"/rack1","/rack2","/rack3"};
    final String[] hosts=new String[]{"node1","node2","node3"};
    MiniDFSCluster cluster=null;
    final CallerContext original=CallerContext.getCurrent();
    try {
      cluster=new MiniDFSCluster.Builder(conf).racks(racks).hosts(hosts).numDataNodes(hosts.length).build();
      cluster.waitActive();
      DistributedFileSystem fs=cluster.getFileSystem();
      final Path fooName=fs.makeQualified(new Path("/foo"));
      FSDataOutputStream stream=fs.create(fooName);
      stream.write("Hello world!\n".getBytes(StandardCharsets.UTF_8));
      stream.close();
      StringBuilder contextStr=new StringBuilder("test,").append(CallerContext.CLIENT_IP_STR).append(CallerContext.Builder.KEY_VALUE_SEPARATOR).append(hosts[0]);
      CallerContext.setCurrent(new CallerContext.Builder(contextStr.toString()).build());
      for (int trial=0; trial < ITERATIONS_TO_USE; ++trial) {
        String host=getPreferredLocation(fs,fooName);
        if (!hosts[0].equals(host)) {
          break;
        }
 else         if (trial == ITERATIONS_TO_USE - 1) {
          assertNotEquals("Failed to get non-node1",hosts[0],host);
        }
      }
      UserGroupInformation joe=UserGroupInformation.createUserForTesting("fake_joe",new String[]{"fake_group"});
      DistributedFileSystem joeFs=(DistributedFileSystem)DFSTestUtil.getFileSystemAs(joe,conf);
      for (int trial=0; trial < ITERATIONS_TO_USE; ++trial) {
        String host=getPreferredLocation(joeFs,fooName);
        assertEquals("Trial " + trial + " failed",hosts[0],host);
      }
    }
  finally {
      CallerContext.setCurrent(original);
      if (cluster != null) {
        cluster.shutdown();
      }
      conf.unset(DFS_NAMENODE_IP_PROXY_USERS);
    }
  }
}
