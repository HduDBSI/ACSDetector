public class TestShuffleScheduler {
  @SuppressWarnings("rawtypes") @Test public void testTipFailed() throws Exception {
    JobConf job=new JobConf();
    job.setNumMapTasks(2);
    TaskStatus status=new TaskStatus(){
      @Override public boolean getIsMap(){
        return false;
      }
      @Override public void addFetchFailedMap(      TaskAttemptID mapTaskId){
      }
    }
;
    Progress progress=new Progress();
    TaskAttemptID reduceId=new TaskAttemptID("314159",0,TaskType.REDUCE,0,0);
    ShuffleSchedulerImpl scheduler=new ShuffleSchedulerImpl(job,status,reduceId,null,progress,null,null,null);
    JobID jobId=new JobID();
    TaskID taskId1=new TaskID(jobId,TaskType.REDUCE,1);
    scheduler.tipFailed(taskId1);
    Assert.assertEquals("Progress should be 0.5",0.5f,progress.getProgress(),0.0f);
    Assert.assertFalse(scheduler.waitUntilDone(1));
    TaskID taskId0=new TaskID(jobId,TaskType.REDUCE,0);
    scheduler.tipFailed(taskId0);
    Assert.assertEquals("Progress should be 1.0",1.0f,progress.getProgress(),0.0f);
    Assert.assertTrue(scheduler.waitUntilDone(1));
  }
  @SuppressWarnings("rawtypes") @Test public <K,V>void TestAggregatedTransferRate() throws Exception {
    JobConf job=new JobConf();
    job.setNumMapTasks(10);
    TaskUmbilicalProtocol mockUmbilical=mock(TaskUmbilicalProtocol.class);
    Reporter mockReporter=mock(Reporter.class);
    FileSystem mockFileSystem=mock(FileSystem.class);
    Class<? extends org.apache.hadoop.mapred.Reducer> combinerClass=job.getCombinerClass();
    @SuppressWarnings("unchecked") CombineOutputCollector<K,V> mockCombineOutputCollector=(CombineOutputCollector<K,V>)mock(CombineOutputCollector.class);
    org.apache.hadoop.mapreduce.TaskAttemptID mockTaskAttemptID=mock(org.apache.hadoop.mapreduce.TaskAttemptID.class);
    LocalDirAllocator mockLocalDirAllocator=mock(LocalDirAllocator.class);
    CompressionCodec mockCompressionCodec=mock(CompressionCodec.class);
    Counter mockCounter=mock(Counter.class);
    TaskStatus mockTaskStatus=mock(TaskStatus.class);
    Progress mockProgress=mock(Progress.class);
    MapOutputFile mockMapOutputFile=mock(MapOutputFile.class);
    Task mockTask=mock(Task.class);
    @SuppressWarnings("unchecked") MapOutput<K,V> output=mock(MapOutput.class);
    ShuffleConsumerPlugin.Context<K,V> context=new ShuffleConsumerPlugin.Context<K,V>(mockTaskAttemptID,job,mockFileSystem,mockUmbilical,mockLocalDirAllocator,mockReporter,mockCompressionCodec,combinerClass,mockCombineOutputCollector,mockCounter,mockCounter,mockCounter,mockCounter,mockCounter,mockCounter,mockTaskStatus,mockProgress,mockProgress,mockTask,mockMapOutputFile,null);
    TaskStatus status=new TaskStatus(){
      @Override public boolean getIsMap(){
        return false;
      }
      @Override public void addFetchFailedMap(      TaskAttemptID mapTaskId){
      }
    }
;
    Progress progress=new Progress();
    ShuffleSchedulerImpl<K,V> scheduler=new ShuffleSchedulerImpl<K,V>(job,status,null,null,progress,context.getShuffledMapsCounter(),context.getReduceShuffleBytes(),context.getFailedShuffleCounter());
    TaskAttemptID attemptID0=new TaskAttemptID(new org.apache.hadoop.mapred.TaskID(new JobID("test",0),TaskType.MAP,0),0);
    long bytes=(long)40 * 1024 * 1024;
    scheduler.copySucceeded(attemptID0,new MapHost(null,null),bytes,60000,100000,output);
    Assert.assertEquals(copyMessage(1,1,1),progress.toString());
    TaskAttemptID attemptID1=new TaskAttemptID(new org.apache.hadoop.mapred.TaskID(new JobID("test",0),TaskType.MAP,1),1);
    bytes=(long)50 * 1024 * 1024;
    scheduler.copySucceeded(attemptID1,new MapHost(null,null),bytes,0,50000,output);
    Assert.assertEquals(copyMessage(2,1,1),progress.toString());
    TaskAttemptID attemptID2=new TaskAttemptID(new org.apache.hadoop.mapred.TaskID(new JobID("test",0),TaskType.MAP,2),2);
    bytes=(long)110 * 1024 * 1024;
    scheduler.copySucceeded(attemptID2,new MapHost(null,null),bytes,25000,80000,output);
    Assert.assertEquals(copyMessage(3,2,2),progress.toString());
    TaskAttemptID attemptID3=new TaskAttemptID(new org.apache.hadoop.mapred.TaskID(new JobID("test",0),TaskType.MAP,3),3);
    bytes=(long)100 * 1024 * 1024;
    scheduler.copySucceeded(attemptID3,new MapHost(null,null),bytes,100000,300000,output);
    Assert.assertEquals(copyMessage(4,0.5,1),progress.toString());
    TaskAttemptID attemptID4=new TaskAttemptID(new org.apache.hadoop.mapred.TaskID(new JobID("test",0),TaskType.MAP,4),4);
    bytes=(long)50 * 1024 * 1024;
    scheduler.copySucceeded(attemptID4,new MapHost(null,null),bytes,350000,400000,output);
    Assert.assertEquals(copyMessage(5,1,1),progress.toString());
    TaskAttemptID attemptID5=new TaskAttemptID(new org.apache.hadoop.mapred.TaskID(new JobID("test",0),TaskType.MAP,5),5);
    bytes=(long)50 * 1024 * 1024;
    scheduler.copySucceeded(attemptID5,new MapHost(null,null),bytes,450000,500000,output);
    Assert.assertEquals(copyMessage(6,1,1),progress.toString());
    TaskAttemptID attemptID6=new TaskAttemptID(new org.apache.hadoop.mapred.TaskID(new JobID("test",0),TaskType.MAP,6),6);
    bytes=(long)20 * 1024 * 1024;
    scheduler.copySucceeded(attemptID6,new MapHost(null,null),bytes,320000,340000,output);
    Assert.assertEquals(copyMessage(7,1,1),progress.toString());
    TaskAttemptID attemptID7=new TaskAttemptID(new org.apache.hadoop.mapred.TaskID(new JobID("test",0),TaskType.MAP,7),7);
    bytes=(long)30 * 1024 * 1024;
    scheduler.copySucceeded(attemptID7,new MapHost(null,null),bytes,290000,350000,output);
    Assert.assertEquals(copyMessage(8,0.5,1),progress.toString());
    TaskAttemptID attemptID8=new TaskAttemptID(new org.apache.hadoop.mapred.TaskID(new JobID("test",0),TaskType.MAP,8),8);
    bytes=(long)50 * 1024 * 1024;
    scheduler.copySucceeded(attemptID8,new MapHost(null,null),bytes,400000,450000,output);
    Assert.assertEquals(copyMessage(9,1,1),progress.toString());
    TaskAttemptID attemptID9=new TaskAttemptID(new org.apache.hadoop.mapred.TaskID(new JobID("test",0),TaskType.MAP,9),9);
    bytes=(long)500 * 1024 * 1024;
    scheduler.copySucceeded(attemptID9,new MapHost(null,null),bytes,0,500000,output);
    Assert.assertEquals(copyMessage(10,1,2),progress.toString());
  }
  @SuppressWarnings("rawtypes") @Test public <K,V>void TestSucceedAndFailedCopyMap() throws Exception {
    JobConf job=new JobConf();
    job.setNumMapTasks(2);
    TaskUmbilicalProtocol mockUmbilical=mock(TaskUmbilicalProtocol.class);
    Reporter mockReporter=mock(Reporter.class);
    FileSystem mockFileSystem=mock(FileSystem.class);
    Class<? extends org.apache.hadoop.mapred.Reducer> combinerClass=job.getCombinerClass();
    @SuppressWarnings("unchecked") CombineOutputCollector<K,V> mockCombineOutputCollector=(CombineOutputCollector<K,V>)mock(CombineOutputCollector.class);
    org.apache.hadoop.mapreduce.TaskAttemptID mockTaskAttemptID=mock(org.apache.hadoop.mapreduce.TaskAttemptID.class);
    LocalDirAllocator mockLocalDirAllocator=mock(LocalDirAllocator.class);
    CompressionCodec mockCompressionCodec=mock(CompressionCodec.class);
    Counter mockCounter=mock(Counter.class);
    TaskStatus mockTaskStatus=mock(TaskStatus.class);
    Progress mockProgress=mock(Progress.class);
    MapOutputFile mockMapOutputFile=mock(MapOutputFile.class);
    Task mockTask=mock(Task.class);
    @SuppressWarnings("unchecked") MapOutput<K,V> output=mock(MapOutput.class);
    ShuffleConsumerPlugin.Context<K,V> context=new ShuffleConsumerPlugin.Context<K,V>(mockTaskAttemptID,job,mockFileSystem,mockUmbilical,mockLocalDirAllocator,mockReporter,mockCompressionCodec,combinerClass,mockCombineOutputCollector,mockCounter,mockCounter,mockCounter,mockCounter,mockCounter,mockCounter,mockTaskStatus,mockProgress,mockProgress,mockTask,mockMapOutputFile,null);
    TaskStatus status=new TaskStatus(){
      @Override public boolean getIsMap(){
        return false;
      }
      @Override public void addFetchFailedMap(      TaskAttemptID mapTaskId){
      }
    }
;
    Progress progress=new Progress();
    ShuffleSchedulerImpl<K,V> scheduler=new ShuffleSchedulerImpl<K,V>(job,status,null,null,progress,context.getShuffledMapsCounter(),context.getReduceShuffleBytes(),context.getFailedShuffleCounter());
    MapHost host1=new MapHost("host1",null);
    TaskAttemptID failedAttemptID=new TaskAttemptID(new org.apache.hadoop.mapred.TaskID(new JobID("test",0),TaskType.MAP,0),0);
    TaskAttemptID succeedAttemptID=new TaskAttemptID(new org.apache.hadoop.mapred.TaskID(new JobID("test",0),TaskType.MAP,1),1);
    scheduler.hostFailed(host1.getHostName());
    long bytes=(long)500 * 1024 * 1024;
    scheduler.copySucceeded(succeedAttemptID,host1,bytes,0,500000,output);
    scheduler.copyFailed(failedAttemptID,host1,true,false);
  }
  private static String copyMessage(  int attemptNo,  double rate1,  double rate2){
    int attemptZero=attemptNo - 1;
    return String.format("copy task(attempt_test_0000_m_%06d_%d succeeded at %1.2f MB/s)" + " Aggregated copy rate(%d of 10 at %1.2f MB/s)",attemptZero,attemptZero,rate1,attemptNo,rate2);
  }
}
