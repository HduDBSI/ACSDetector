/** 
 * Example metric pojo.
 */
@Metrics(about="Test Metrics",context="dfs") private static class TestMetrics {
  @Metric private MutableCounterLong numBucketCreateFails;
}
