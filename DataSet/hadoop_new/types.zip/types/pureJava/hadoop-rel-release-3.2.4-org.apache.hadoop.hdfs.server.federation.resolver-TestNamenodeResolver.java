/** 
 * Test the basic  {@link ActiveNamenodeResolver} functionality.
 */
public class TestNamenodeResolver {
  private static StateStoreService stateStore;
  private static ActiveNamenodeResolver namenodeResolver;
  @BeforeClass public static void create() throws Exception {
    Configuration conf=getStateStoreConfiguration();
    conf.setLong(RBFConfigKeys.FEDERATION_STORE_MEMBERSHIP_EXPIRATION_MS,TimeUnit.SECONDS.toMillis(5));
    stateStore=newStateStore(conf);
    assertNotNull(stateStore);
    namenodeResolver=new MembershipNamenodeResolver(conf,stateStore);
    namenodeResolver.setRouterId(ROUTERS[0]);
  }
  @AfterClass public static void destroy() throws Exception {
    stateStore.stop();
    stateStore.close();
  }
  @Before public void setup() throws IOException, InterruptedException {
    stateStore.loadDriver();
    waitStateStore(stateStore,10000);
    boolean cleared=clearRecords(stateStore,MembershipState.class);
    assertTrue(cleared);
  }
  @Test public void testStateStoreDisconnected() throws Exception {
    NamenodeStatusReport report=createNamenodeReport(NAMESERVICES[0],NAMENODES[0],HAServiceState.ACTIVE);
    assertTrue(namenodeResolver.registerNamenode(report));
    stateStore.closeDriver();
    assertFalse(stateStore.isDriverReady());
    stateStore.refreshCaches(true);
    List<? extends FederationNamenodeContext> nns=namenodeResolver.getNamenodesForBlockPoolId(NAMESERVICES[0]);
    assertNull(nns);
    verifyException(namenodeResolver,"registerNamenode",StateStoreUnavailableException.class,new Class[]{NamenodeStatusReport.class},new Object[]{report});
  }
  /** 
 * Verify the first registration on the resolver.
 * @param nsId Nameservice identifier.
 * @param nnId Namenode identifier within the nemeservice.
 * @param resultsCount Number of results expected.
 * @param state Expected state for the first one.
 * @throws IOException If we cannot get the namenodes.
 */
  private void verifyFirstRegistration(  String nsId,  String nnId,  int resultsCount,  FederationNamenodeServiceState state) throws IOException {
    List<? extends FederationNamenodeContext> namenodes=namenodeResolver.getNamenodesForNameserviceId(nsId);
    if (resultsCount == 0) {
      assertNull(namenodes);
    }
 else {
      assertEquals(resultsCount,namenodes.size());
      if (namenodes.size() > 0) {
        FederationNamenodeContext namenode=namenodes.get(0);
        assertEquals(state,namenode.getState());
        assertEquals(nnId,namenode.getNamenodeId());
      }
    }
  }
  @Test public void testRegistrationExpired() throws InterruptedException, IOException {
    NamenodeStatusReport report=createNamenodeReport(NAMESERVICES[0],NAMENODES[0],HAServiceState.ACTIVE);
    assertTrue(namenodeResolver.registerNamenode(report));
    stateStore.refreshCaches(true);
    verifyFirstRegistration(NAMESERVICES[0],NAMENODES[0],1,FederationNamenodeServiceState.ACTIVE);
    Thread.sleep(6000);
    stateStore.refreshCaches(true);
    verifyFirstRegistration(NAMESERVICES[0],NAMENODES[0],0,FederationNamenodeServiceState.ACTIVE);
    assertTrue(namenodeResolver.registerNamenode(report));
    stateStore.refreshCaches(true);
    verifyFirstRegistration(NAMESERVICES[0],NAMENODES[0],1,FederationNamenodeServiceState.ACTIVE);
  }
  @Test public void testRegistrationNamenodeSelection() throws InterruptedException, IOException {
    assertTrue(namenodeResolver.registerNamenode(createNamenodeReport(NAMESERVICES[0],NAMENODES[0],HAServiceState.ACTIVE)));
    Thread.sleep(100);
    assertTrue(namenodeResolver.registerNamenode(createNamenodeReport(NAMESERVICES[0],NAMENODES[1],HAServiceState.STANDBY)));
    stateStore.refreshCaches(true);
    verifyFirstRegistration(NAMESERVICES[0],NAMENODES[0],2,FederationNamenodeServiceState.ACTIVE);
    assertTrue(namenodeResolver.registerNamenode(createNamenodeReport(NAMESERVICES[0],NAMENODES[0],HAServiceState.ACTIVE)));
    Thread.sleep(6000);
    assertTrue(namenodeResolver.registerNamenode(createNamenodeReport(NAMESERVICES[0],NAMENODES[1],HAServiceState.STANDBY)));
    stateStore.refreshCaches(true);
    verifyFirstRegistration(NAMESERVICES[0],NAMENODES[1],1,FederationNamenodeServiceState.STANDBY);
    assertTrue(namenodeResolver.registerNamenode(createNamenodeReport(NAMESERVICES[0],NAMENODES[0],HAServiceState.ACTIVE)));
    Thread.sleep(100);
    assertTrue(namenodeResolver.registerNamenode(createNamenodeReport(NAMESERVICES[0],NAMENODES[1],null)));
    stateStore.refreshCaches(true);
    verifyFirstRegistration(NAMESERVICES[0],NAMENODES[0],2,FederationNamenodeServiceState.ACTIVE);
    assertTrue(namenodeResolver.registerNamenode(createNamenodeReport(NAMESERVICES[0],NAMENODES[1],HAServiceState.STANDBY)));
    Thread.sleep(1000);
    assertTrue(namenodeResolver.registerNamenode(createNamenodeReport(NAMESERVICES[0],NAMENODES[0],null)));
    stateStore.refreshCaches(true);
    verifyFirstRegistration(NAMESERVICES[0],NAMENODES[1],2,FederationNamenodeServiceState.STANDBY);
    assertTrue(namenodeResolver.registerNamenode(createNamenodeReport(NAMESERVICES[0],NAMENODES[0],null)));
    Thread.sleep(100);
    assertTrue(namenodeResolver.registerNamenode(createNamenodeReport(NAMESERVICES[0],NAMENODES[1],HAServiceState.STANDBY)));
    Thread.sleep(100);
    assertTrue(namenodeResolver.registerNamenode(createNamenodeReport(NAMESERVICES[0],NAMENODES[2],HAServiceState.ACTIVE)));
    stateStore.refreshCaches(true);
    verifyFirstRegistration(NAMESERVICES[0],NAMENODES[2],3,FederationNamenodeServiceState.ACTIVE);
    assertTrue(namenodeResolver.registerNamenode(createNamenodeReport(NAMESERVICES[0],NAMENODES[0],HAServiceState.STANDBY)));
    assertTrue(namenodeResolver.registerNamenode(createNamenodeReport(NAMESERVICES[0],NAMENODES[2],HAServiceState.STANDBY)));
    Thread.sleep(1500);
    assertTrue(namenodeResolver.registerNamenode(createNamenodeReport(NAMESERVICES[0],NAMENODES[1],HAServiceState.STANDBY)));
    stateStore.refreshCaches(true);
    verifyFirstRegistration(NAMESERVICES[0],NAMENODES[1],3,FederationNamenodeServiceState.STANDBY);
  }
}
