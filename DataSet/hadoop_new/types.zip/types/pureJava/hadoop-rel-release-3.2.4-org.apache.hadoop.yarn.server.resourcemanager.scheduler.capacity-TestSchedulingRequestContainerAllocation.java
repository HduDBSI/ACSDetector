/** 
 * Test Container Allocation with SchedulingRequest.
 */
@RunWith(Parameterized.class) public class TestSchedulingRequestContainerAllocation {
  private static final int GB=1024;
  private YarnConfiguration conf;
  private String placementConstraintHandler;
  RMNodeLabelsManager mgr;
  @Parameters public static Collection<Object[]> placementConstarintHandlers(){
    Object[][] params=new Object[][]{{YarnConfiguration.PROCESSOR_RM_PLACEMENT_CONSTRAINTS_HANDLER},{YarnConfiguration.SCHEDULER_RM_PLACEMENT_CONSTRAINTS_HANDLER}};
    return Arrays.asList(params);
  }
  public TestSchedulingRequestContainerAllocation(  String placementConstraintHandler){
    this.placementConstraintHandler=placementConstraintHandler;
  }
  @Before public void setUp() throws Exception {
    conf=new YarnConfiguration();
    conf.setClass(YarnConfiguration.RM_SCHEDULER,CapacityScheduler.class,ResourceScheduler.class);
    conf.set(YarnConfiguration.RM_PLACEMENT_CONSTRAINTS_HANDLER,this.placementConstraintHandler);
    mgr=new NullRMNodeLabelsManager();
    mgr.init(conf);
  }
  @Test(timeout=30000L) public void testIntraAppAntiAffinity() throws Exception {
    Configuration csConf=TestUtils.getConfigurationWithMultipleQueues(conf);
    MockRM rm1=new MockRM(csConf){
      @Override public RMNodeLabelsManager createNodeLabelManager(){
        return mgr;
      }
    }
;
    rm1.getRMContext().setNodeLabelManager(mgr);
    rm1.start();
    MockNM[] nms=new MockNM[4];
    RMNode[] rmNodes=new RMNode[4];
    for (int i=0; i < 4; i++) {
      nms[i]=rm1.registerNode("192.168.0." + i + ":1234",10 * GB);
      rmNodes[i]=rm1.getRMContext().getRMNodes().get(nms[i].getNodeId());
    }
    RMApp app1=rm1.submitApp(1 * GB,"app","user",null,"c");
    MockAM am1=MockRM.launchAndRegisterAM(app1,rm1,nms[0]);
    am1.allocateIntraAppAntiAffinity(ResourceSizing.newInstance(10,Resource.newInstance(1024,1)),Priority.newInstance(1),1L,ImmutableSet.of("mapper"),"mapper");
    List<Container> allocated=waitForAllocation(4,3000,am1,nms);
    Assert.assertEquals(4,allocated.size());
    Assert.assertEquals(4,getContainerNodesNum(allocated));
    am1.allocateIntraAppAntiAffinity(ResourceSizing.newInstance(10,Resource.newInstance(2048,1)),Priority.newInstance(2),1L,ImmutableSet.of("reducer"),"reducer");
    allocated=waitForAllocation(4,3000,am1,nms);
    Assert.assertEquals(4,allocated.size());
    Assert.assertEquals(4,getContainerNodesNum(allocated));
    am1.allocateIntraAppAntiAffinity(ResourceSizing.newInstance(10,Resource.newInstance(2048,1)),Priority.newInstance(3),1L,ImmutableSet.of("reducer2"),"mapper");
    boolean caughtException=false;
    try {
      allocated=waitForAllocation(1,3000,am1,nms);
    }
 catch (    Exception e) {
      caughtException=true;
    }
    Assert.assertTrue(caughtException);
    rm1.close();
  }
  @Test(timeout=30000L) public void testIntraAppAntiAffinityWithMultipleTags() throws Exception {
    Configuration csConf=TestUtils.getConfigurationWithMultipleQueues(conf);
    MockRM rm1=new MockRM(csConf){
      @Override public RMNodeLabelsManager createNodeLabelManager(){
        return mgr;
      }
    }
;
    rm1.getRMContext().setNodeLabelManager(mgr);
    rm1.start();
    MockNM[] nms=new MockNM[4];
    RMNode[] rmNodes=new RMNode[4];
    for (int i=0; i < 4; i++) {
      nms[i]=rm1.registerNode("192.168.0." + i + ":1234",10 * GB);
      rmNodes[i]=rm1.getRMContext().getRMNodes().get(nms[i].getNodeId());
    }
    RMApp app1=rm1.submitApp(1 * GB,"app","user",null,"c");
    MockAM am1=MockRM.launchAndRegisterAM(app1,rm1,nms[0]);
    am1.allocateIntraAppAntiAffinity(ResourceSizing.newInstance(2,Resource.newInstance(1024,1)),Priority.newInstance(1),1L,ImmutableSet.of("tag_1_1","tag_1_2"),"tag_1_1","tag_1_2");
    List<Container> allocated=waitForAllocation(2,3000,am1,nms);
    Assert.assertEquals(2,allocated.size());
    Assert.assertEquals(2,getContainerNodesNum(allocated));
    am1.allocateIntraAppAntiAffinity(ResourceSizing.newInstance(1,Resource.newInstance(1024,1)),Priority.newInstance(2),1L,ImmutableSet.of("tag_2_1","tag_2_2"),"tag_1_1","tag_1_2");
    List<Container> allocated1=waitForAllocation(1,3000,am1,nms);
    Assert.assertEquals(1,allocated1.size());
    allocated.addAll(allocated1);
    Assert.assertEquals(3,getContainerNodesNum(allocated));
    am1.allocateIntraAppAntiAffinity(ResourceSizing.newInstance(1,Resource.newInstance(1024,1)),Priority.newInstance(3),1L,ImmutableSet.of("tag_3"),"tag_1_1","tag_1_2","tag_2_1","tag_2_2");
    allocated1=waitForAllocation(1,3000,am1,nms);
    Assert.assertEquals(1,allocated1.size());
    allocated.addAll(allocated1);
    Assert.assertEquals(4,getContainerNodesNum(allocated));
    rm1.close();
  }
  /** 
 * This UT covers some basic end-to-end inter-app anti-affinity constraint tests. For comprehensive tests over different namespace types, see more in TestPlacementConstraintsUtil.
 * @throws Exception
 */
  @Test(timeout=30000L) public void testInterAppAntiAffinity() throws Exception {
    Configuration csConf=TestUtils.getConfigurationWithMultipleQueues(conf);
    MockRM rm1=new MockRM(csConf){
      @Override public RMNodeLabelsManager createNodeLabelManager(){
        return mgr;
      }
    }
;
    rm1.getRMContext().setNodeLabelManager(mgr);
    rm1.start();
    MockNM[] nms=new MockNM[4];
    RMNode[] rmNodes=new RMNode[4];
    for (int i=0; i < 4; i++) {
      nms[i]=rm1.registerNode("192.168.0." + i + ":1234",10 * GB);
      rmNodes[i]=rm1.getRMContext().getRMNodes().get(nms[i].getNodeId());
    }
    RMApp app1=rm1.submitApp(1 * GB,"app","user",null,"c");
    MockAM am1=MockRM.launchAndRegisterAM(app1,rm1,nms[0]);
    am1.allocateIntraAppAntiAffinity(ResourceSizing.newInstance(3,Resource.newInstance(1024,1)),Priority.newInstance(1),1L,ImmutableSet.of("mapper"),"mapper");
    List<Container> allocated=waitForAllocation(3,3000,am1,nms);
    Assert.assertEquals(3,allocated.size());
    Assert.assertEquals(3,getContainerNodesNum(allocated));
    System.out.println("Mappers on HOST0: " + rmNodes[0].getAllocationTagsWithCount().get("mapper"));
    System.out.println("Mappers on HOST1: " + rmNodes[1].getAllocationTagsWithCount().get("mapper"));
    System.out.println("Mappers on HOST2: " + rmNodes[2].getAllocationTagsWithCount().get("mapper"));
    RMApp app2=rm1.submitApp(1 * GB,"app","user",null,"c");
    MockAM am2=MockRM.launchAndRegisterAM(app2,rm1,nms[0]);
    TargetApplicationsNamespace.All allNs=new TargetApplicationsNamespace.All();
    am2.allocateAppAntiAffinity(ResourceSizing.newInstance(3,Resource.newInstance(1024,1)),Priority.newInstance(1),1L,allNs.toString(),ImmutableSet.of("foo"),"mapper");
    List<Container> allocated1=waitForAllocation(3,3000,am2,nms);
    Assert.assertEquals(3,allocated1.size());
    Assert.assertEquals(1,getContainerNodesNum(allocated1));
    allocated.addAll(allocated1);
    Assert.assertEquals(4,getContainerNodesNum(allocated));
    CapacityScheduler cs=(CapacityScheduler)rm1.getResourceScheduler();
    FiCaSchedulerApp schedulerApp2=cs.getApplicationAttempt(am2.getApplicationAttemptId());
    Assert.assertTrue(schedulerApp2.getLiveContainers().stream().allMatch(rmContainer -> {
      if (!rmContainer.getContainer().getNodeId().equals(rmNodes[0])) {
        return !rmContainer.getAllocationTags().contains("mapper");
      }
      return true;
    }
));
    RMApp app3=rm1.submitApp(1 * GB,"app","user",null,"c");
    MockAM am3=MockRM.launchAndRegisterAM(app3,rm1,nms[0]);
    am3.allocateAppAntiAffinity(ResourceSizing.newInstance(3,Resource.newInstance(1024,1)),Priority.newInstance(1),1L,allNs.toString(),ImmutableSet.of("mapper"),"mapper");
    allocated1=waitForAllocation(1,3000,am3,nms);
    Assert.assertEquals(1,allocated1.size());
    allocated.addAll(allocated1);
    Assert.assertEquals(4,getContainerNodesNum(allocated));
    rm1.close();
  }
  @Test public void testSchedulingRequestDisabledByDefault() throws Exception {
    Configuration csConf=TestUtils.getConfigurationWithMultipleQueues(new Configuration());
    MockRM rm1=new MockRM(csConf){
      @Override public RMNodeLabelsManager createNodeLabelManager(){
        return mgr;
      }
    }
;
    rm1.getRMContext().setNodeLabelManager(mgr);
    rm1.start();
    MockNM[] nms=new MockNM[4];
    RMNode[] rmNodes=new RMNode[4];
    for (int i=0; i < 4; i++) {
      nms[i]=rm1.registerNode("192.168.0." + i + ":1234",10 * GB);
      rmNodes[i]=rm1.getRMContext().getRMNodes().get(nms[i].getNodeId());
    }
    RMApp app1=rm1.submitApp(1 * GB,"app","user",null,"c");
    MockAM am1=MockRM.launchAndRegisterAM(app1,rm1,nms[0]);
    boolean caughtException=false;
    try {
      am1.allocateIntraAppAntiAffinity(ResourceSizing.newInstance(2,Resource.newInstance(1024,1)),Priority.newInstance(1),1L,ImmutableSet.of("tag_1_1","tag_1_2"),"tag_1_1","tag_1_2");
    }
 catch (    Exception e) {
      caughtException=true;
    }
    Assert.assertTrue(caughtException);
    rm1.close();
  }
  @Test(timeout=30000L) public void testSchedulingRequestWithNullConstraint() throws Exception {
    Configuration csConf=TestUtils.getConfigurationWithMultipleQueues(conf);
    MockRM rm1=new MockRM(csConf){
      @Override public RMNodeLabelsManager createNodeLabelManager(){
        return mgr;
      }
    }
;
    rm1.getRMContext().setNodeLabelManager(mgr);
    rm1.start();
    MockNM[] nms=new MockNM[4];
    RMNode[] rmNodes=new RMNode[4];
    for (int i=0; i < 4; i++) {
      nms[i]=rm1.registerNode("192.168.0." + i + ":1234",10 * GB);
      rmNodes[i]=rm1.getRMContext().getRMNodes().get(nms[i].getNodeId());
    }
    RMApp app1=rm1.submitApp(1 * GB,"app","user",null,"c");
    MockAM am1=MockRM.launchAndRegisterAM(app1,rm1,nms[0]);
    CapacityScheduler cs=(CapacityScheduler)rm1.getResourceScheduler();
    PlacementConstraint constraint=targetNotIn("node",allocationTag("t1")).build();
    SchedulingRequest sc=SchedulingRequest.newInstance(0,Priority.newInstance(1),ExecutionTypeRequest.newInstance(ExecutionType.GUARANTEED),ImmutableSet.of("t1"),ResourceSizing.newInstance(1,Resource.newInstance(1024,1)),constraint);
    AllocateRequest request=AllocateRequest.newBuilder().schedulingRequests(ImmutableList.of(sc)).build();
    am1.allocate(request);
    List<Container> allocated=waitForAllocation(1,3000,am1,nms);
    Assert.assertEquals(1,allocated.size());
    sc=SchedulingRequest.newInstance(1,Priority.newInstance(1),ExecutionTypeRequest.newInstance(ExecutionType.GUARANTEED),ImmutableSet.of("t2"),ResourceSizing.newInstance(2,Resource.newInstance(1024,1)),null);
    AllocateRequest request1=AllocateRequest.newBuilder().schedulingRequests(ImmutableList.of(sc)).build();
    am1.allocate(request1);
    allocated=waitForAllocation(2,3000,am1,nms);
    Assert.assertEquals(2,allocated.size());
    rm1.close();
  }
  private static void doNodeHeartbeat(  MockNM... nms) throws Exception {
    for (    MockNM nm : nms) {
      nm.nodeHeartbeat(true);
    }
  }
  public static List<Container> waitForAllocation(  int allocNum,  int timeout,  MockAM am,  MockNM... nms) throws Exception {
    final List<Container> result=new ArrayList<>();
    GenericTestUtils.waitFor(() -> {
      try {
        AllocateResponse response=am.schedule();
        List<Container> allocated=response.getAllocatedContainers();
        System.out.println("Expecting allocation: " + allocNum + ", actual allocation: "+ allocated.size());
        for (        Container c : allocated) {
          System.out.println("Container " + c.getId().toString() + " is allocated on node: "+ c.getNodeId().toString()+ ", allocation tags: "+ String.join(",",c.getAllocationTags()));
        }
        result.addAll(allocated);
        if (result.size() == allocNum) {
          return true;
        }
        doNodeHeartbeat(nms);
      }
 catch (      Exception e) {
        e.printStackTrace();
      }
      return false;
    }
,500,timeout);
    return result;
  }
  private static SchedulingRequest schedulingRequest(  int requestId,  int containers,  int cores,  int mem,  PlacementConstraint constraint,  String... tags){
    return schedulingRequest(1,requestId,containers,cores,mem,ExecutionType.GUARANTEED,constraint,tags);
  }
  private static SchedulingRequest schedulingRequest(  int priority,  long allocReqId,  int containers,  int cores,  int mem,  ExecutionType execType,  PlacementConstraint constraint,  String... tags){
    return SchedulingRequest.newBuilder().priority(Priority.newInstance(priority)).allocationRequestId(allocReqId).allocationTags(new HashSet<>(Arrays.asList(tags))).executionType(ExecutionTypeRequest.newInstance(execType,true)).resourceSizing(ResourceSizing.newInstance(containers,Resource.newInstance(mem,cores))).placementConstraintExpression(constraint).build();
  }
  public static int getContainerNodesNum(  List<Container> containers){
    Set<NodeId> nodes=new HashSet<>();
    if (containers != null) {
      containers.forEach(c -> nodes.add(c.getNodeId()));
    }
    return nodes.size();
  }
  @Test(timeout=30000L) public void testInterAppCompositeConstraints() throws Exception {
    MockRM rm=new MockRM(conf);
    try {
      rm.start();
      MockNM nm1=rm.registerNode("192.168.0.1:1234",100 * GB,100);
      MockNM nm2=rm.registerNode("192.168.0.2:1234",100 * GB,100);
      MockNM nm3=rm.registerNode("192.168.0.3:1234",100 * GB,100);
      MockNM nm4=rm.registerNode("192.168.0.4:1234",100 * GB,100);
      MockNM nm5=rm.registerNode("192.168.0.5:1234",100 * GB,100);
      RMApp app1=rm.submitApp(1 * GB,ImmutableSet.of("hbase"));
      MockAM am1=MockRM.launchAndRegisterAM(app1,rm,nm1);
      PlacementConstraint pc=targetNotIn("node",allocationTag("hbase-master")).build();
      am1.addSchedulingRequest(ImmutableList.of(schedulingRequest(1,2,1,2048,pc,"hbase-master")));
      List<Container> allocated=waitForAllocation(2,3000,am1,nm1,nm2);
      Assert.assertEquals(2,allocated.size());
      Assert.assertEquals(2,getContainerNodesNum(allocated));
      pc=targetNotIn("node",allocationTag("hbase-rs")).build();
      am1.addSchedulingRequest(ImmutableList.of(schedulingRequest(2,4,1,1024,pc,"hbase-rs")));
      allocated=waitForAllocation(4,3000,am1,nm1,nm2,nm3,nm4,nm5);
      Assert.assertEquals(4,allocated.size());
      Assert.assertEquals(4,getContainerNodesNum(allocated));
      RMApp app2=rm.submitApp(1 * GB,ImmutableSet.of("web-server"));
      MockAM am2=MockRM.launchAndRegisterAM(app2,rm,nm2);
      pc=and(targetIn("node",allocationTagWithNamespace(new TargetApplicationsNamespace.All().toString(),"hbase-master")),targetNotIn("node",allocationTag("ws-inst"))).build();
      am2.addSchedulingRequest(ImmutableList.of(schedulingRequest(1,2,1,2048,pc,"ws-inst")));
      allocated=waitForAllocation(2,3000,am2,nm1,nm2,nm3,nm4,nm5);
      Assert.assertEquals(2,allocated.size());
      Assert.assertEquals(2,getContainerNodesNum(allocated));
      ConcurrentMap<NodeId,RMNode> rmNodes=rm.getRMContext().getRMNodes();
      for (      Container c : allocated) {
        RMNode rmNode=rmNodes.get(c.getNodeId());
        Assert.assertNotNull(rmNode);
        Assert.assertTrue("If ws-inst is allocated to a node," + " this node should have inherited the ws-inst tag ",rmNode.getAllocationTagsWithCount().get("ws-inst") == 1);
        Assert.assertTrue("ws-inst should be co-allocated to " + "hbase-master nodes",rmNode.getAllocationTagsWithCount().get("hbase-master") == 1);
      }
      RMApp app3=rm.submitApp(1 * GB,ImmutableSet.of("ws-servants"));
      MockAM am3=MockRM.launchAndRegisterAM(app3,rm,nm3);
      pc=and(targetIn("node",allocationTagWithNamespace(new TargetApplicationsNamespace.AppTag("web-server").toString(),"ws-inst")),cardinality("node",0,2,"ws-servant")).build();
      am3.addSchedulingRequest(ImmutableList.of(schedulingRequest(1,10,1,512,pc,"ws-servant")));
      allocated=waitForAllocation(6,10000,am3,nm1,nm2,nm3,nm4,nm5);
      Assert.assertEquals(6,allocated.size());
      Assert.assertEquals(2,getContainerNodesNum(allocated));
      for (      Container c : allocated) {
        RMNode rmNode=rmNodes.get(c.getNodeId());
        Assert.assertNotNull(rmNode);
        Assert.assertTrue("Node has ws-servant allocated must have 3 instances",rmNode.getAllocationTagsWithCount().get("ws-servant") == 3);
        Assert.assertTrue("Every ws-servant container should be co-allocated" + " with ws-inst",rmNode.getAllocationTagsWithCount().get("ws-inst") == 1);
      }
    }
  finally {
      rm.stop();
    }
  }
  @Test(timeout=30000L) public void testMultiAllocationTagsConstraints() throws Exception {
    MockRM rm=new MockRM(conf);
    try {
      rm.start();
      MockNM nm1=rm.registerNode("192.168.0.1:1234",10 * GB,10);
      MockNM nm2=rm.registerNode("192.168.0.2:1234",10 * GB,10);
      MockNM nm3=rm.registerNode("192.168.0.3:1234",10 * GB,10);
      MockNM nm4=rm.registerNode("192.168.0.4:1234",10 * GB,10);
      MockNM nm5=rm.registerNode("192.168.0.5:1234",10 * GB,10);
      RMApp app1=rm.submitApp(1 * GB,ImmutableSet.of("server1"));
      doNodeHeartbeat(nm1);
      RMAppAttempt attempt1=app1.getCurrentAppAttempt();
      MockAM am1=rm.sendAMLaunched(attempt1.getAppAttemptId());
      am1.registerAppAttempt();
      String[] server1Ports=new String[]{"port_6000","port_7000","port_8000"};
      PlacementConstraint pc=targetNotIn("node",allocationTagWithNamespace(AllocationTagNamespaceType.ALL.toString(),server1Ports)).build();
      am1.addSchedulingRequest(ImmutableList.of(schedulingRequest(1,2,1,1024,pc,server1Ports)));
      List<Container> allocated=waitForAllocation(2,3000,am1,nm1,nm2,nm3,nm4,nm5);
      Assert.assertEquals(2,allocated.size());
      Assert.assertEquals(2,getContainerNodesNum(allocated));
      String[] server2Ports=new String[]{"port_6000"};
      RMApp app2=rm.submitApp(1 * GB,ImmutableSet.of("server2"));
      doNodeHeartbeat(nm2);
      RMAppAttempt app2attempt1=app2.getCurrentAppAttempt();
      MockAM am2=rm.sendAMLaunched(app2attempt1.getAppAttemptId());
      am2.registerAppAttempt();
      pc=targetNotIn("node",allocationTagWithNamespace(AllocationTagNamespaceType.ALL.toString(),server2Ports)).build();
      am2.addSchedulingRequest(ImmutableList.of(schedulingRequest(1,3,1,1024,pc,server2Ports)));
      allocated=waitForAllocation(3,3000,am2,nm1,nm2,nm3,nm4,nm5);
      Assert.assertEquals(3,allocated.size());
      Assert.assertEquals(3,getContainerNodesNum(allocated));
      ConcurrentMap<NodeId,RMNode> rmNodes=rm.getRMContext().getRMNodes();
      for (      Container c : allocated) {
        RMNode rmNode=rmNodes.get(c.getNodeId());
        Assert.assertNotNull(rmNode);
        Assert.assertTrue("server2 should not co-allocate to server1 as" + " they both need to use port 6000",rmNode.getAllocationTagsWithCount().get("port_6000") == 1);
        Assert.assertFalse(rmNode.getAllocationTagsWithCount().containsKey("port_7000"));
        Assert.assertFalse(rmNode.getAllocationTagsWithCount().containsKey("port_8000"));
      }
    }
  finally {
      rm.stop();
    }
  }
  @Test(timeout=30000L) public void testInterAppConstraintsWithNamespaces() throws Exception {
    MockRM rm=new MockRM(conf);
    try {
      rm.start();
      MockNM nm1=rm.registerNode("192.168.0.1:1234:",100 * GB,100);
      MockNM nm2=rm.registerNode("192.168.0.2:1234",100 * GB,100);
      MockNM nm3=rm.registerNode("192.168.0.3:1234",100 * GB,100);
      MockNM nm4=rm.registerNode("192.168.0.4:1234",100 * GB,100);
      MockNM nm5=rm.registerNode("192.168.0.5:1234",100 * GB,100);
      ApplicationId app5Id=null;
      Map<ApplicationId,List<Container>> allocMap=new HashMap<>();
      for (int i=0; i < 10; i++) {
        String applicationTag=i < 5 ? "former5" : "latter5";
        RMApp app=rm.submitApp(1 * GB,ImmutableSet.of(applicationTag));
        doNodeHeartbeat(nm1,nm2,nm3,nm4,nm5);
        RMAppAttempt attempt=app.getCurrentAppAttempt();
        MockAM am=rm.sendAMLaunched(attempt.getAppAttemptId());
        am.registerAppAttempt();
        PlacementConstraint pc=targetNotIn("node",allocationTag("foo")).build();
        am.addSchedulingRequest(ImmutableList.of(schedulingRequest(1,3,1,1024,pc,"foo")));
        List<Container> allocated=waitForAllocation(3,3000,am,nm1,nm2,nm3,nm4,nm5);
        if (i == 5) {
          app5Id=am.getApplicationAttemptId().getApplicationId();
        }
        allocMap.put(am.getApplicationAttemptId().getApplicationId(),allocated);
      }
      Assert.assertNotNull(app5Id);
      Assert.assertEquals(3,getContainerNodesNum(allocMap.get(app5Id)));
      RMApp app1=rm.submitApp(1 * GB,ImmutableSet.of("xyz"));
      doNodeHeartbeat(nm1);
      RMAppAttempt attempt1=app1.getCurrentAppAttempt();
      MockAM am1=rm.sendAMLaunched(attempt1.getAppAttemptId());
      am1.registerAppAttempt();
      PlacementConstraint pc=targetIn("node",allocationTagWithNamespace(new TargetApplicationsNamespace.AppID(app5Id).toString(),"foo")).build();
      am1.addSchedulingRequest(ImmutableList.of(schedulingRequest(1,3,1,1024,pc,"foo")));
      List<Container> allocated=waitForAllocation(3,3000,am1,nm1,nm2,nm3,nm4,nm5);
      ConcurrentMap<NodeId,RMNode> rmNodes=rm.getRMContext().getRMNodes();
      List<Container> app5Alloc=allocMap.get(app5Id);
      for (      Container c : allocated) {
        RMNode rmNode=rmNodes.get(c.getNodeId());
        Assert.assertNotNull(rmNode);
        Assert.assertTrue("This app is affinity with app-id/app5/foo " + "containers",app5Alloc.stream().anyMatch(c5 -> c5.getNodeId() == c.getNodeId()));
      }
      RMApp app2=rm.submitApp(1 * GB);
      doNodeHeartbeat(nm2);
      RMAppAttempt app2attempt1=app2.getCurrentAppAttempt();
      MockAM am2=rm.sendAMLaunched(app2attempt1.getAppAttemptId());
      am2.registerAppAttempt();
      pc=targetNotIn("node",allocationTagWithNamespace(new TargetApplicationsNamespace.AppTag("xyz").toString(),"foo")).build();
      am2.addSchedulingRequest(ImmutableList.of(schedulingRequest(1,2,1,1024,pc,"foo")));
      allocated=waitForAllocation(2,3000,am2,nm1,nm2,nm3,nm4,nm5);
      Assert.assertEquals(2,allocated.size());
      for (      Container c : app5Alloc) {
        Assert.assertNotEquals(c.getNodeId(),allocated.iterator().next().getNodeId());
      }
      RMApp app3=rm.submitApp(1 * GB);
      doNodeHeartbeat(nm3);
      RMAppAttempt app3attempt1=app3.getCurrentAppAttempt();
      MockAM am3=rm.sendAMLaunched(app3attempt1.getAppAttemptId());
      am3.registerAppAttempt();
      pc=cardinality("node",new TargetApplicationsNamespace.NotSelf().toString(),1,1,"foo").build();
      am3.addSchedulingRequest(ImmutableList.of(schedulingRequest(1,1,1,1024,pc,"foo")));
      allocated=waitForAllocation(1,3000,am3,nm1,nm2,nm3,nm4,nm5);
      Assert.assertEquals(1,allocated.size());
      Assert.assertTrue(rmNodes.get(allocated.iterator().next().getNodeId()).getAllocationTagsWithCount().get("foo") == 2);
    }
  finally {
      rm.stop();
    }
  }
}
