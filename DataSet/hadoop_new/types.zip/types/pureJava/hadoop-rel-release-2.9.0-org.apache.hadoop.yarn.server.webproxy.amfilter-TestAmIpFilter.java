private class TestAmIpFilter extends AmIpFilter {
  private Set<String> proxyAddresses=null;
  protected Set<String> getProxyAddresses(){
    if (proxyAddresses == null) {
      proxyAddresses=new HashSet<String>();
    }
    proxyAddresses.add(proxyHost);
    return proxyAddresses;
  }
}
