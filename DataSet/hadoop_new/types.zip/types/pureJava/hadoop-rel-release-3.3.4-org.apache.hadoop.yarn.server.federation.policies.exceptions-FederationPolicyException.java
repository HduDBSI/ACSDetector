/** 
 * Generic policy exception.
 */
public class FederationPolicyException extends YarnException {
  public FederationPolicyException(  String s){
    super(s);
  }
  public FederationPolicyException(  Throwable t){
    super(t);
  }
}
