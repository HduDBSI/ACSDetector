protected class Emptier implements Runnable {
  private Configuration conf;
  private long emptierInterval;
  Emptier(  Configuration conf,  long emptierInterval) throws IOException {
    this.conf=conf;
    this.emptierInterval=emptierInterval;
    if (emptierInterval > deletionInterval || emptierInterval <= 0) {
      LOG.info("The configured checkpoint interval is " + (emptierInterval / MSECS_PER_MINUTE) + " minutes."+ " Using an interval of "+ (deletionInterval / MSECS_PER_MINUTE)+ " minutes that is used for deletion instead");
      this.emptierInterval=deletionInterval;
    }
    LOG.info("Namenode trash configuration: Deletion interval = " + (deletionInterval / MSECS_PER_MINUTE) + " minutes, Emptier interval = "+ (emptierInterval / MSECS_PER_MINUTE)+ " minutes.");
  }
  @Override public void run(){
    if (emptierInterval == 0)     return;
    long now=Time.now();
    long end;
    while (true) {
      end=ceiling(now,emptierInterval);
      try {
        Thread.sleep(end - now);
      }
 catch (      InterruptedException e) {
        break;
      }
      try {
        now=Time.now();
        if (now >= end) {
          Collection<FileStatus> trashRoots;
          trashRoots=fs.getTrashRoots(true);
          for (          FileStatus trashRoot : trashRoots) {
            if (!trashRoot.isDirectory())             continue;
            try {
              TrashPolicyDefault trash=new TrashPolicyDefault(fs,conf);
              trash.deleteCheckpoint(trashRoot.getPath());
              trash.createCheckpoint(trashRoot.getPath(),new Date(now));
            }
 catch (            IOException e) {
              LOG.warn("Trash caught: " + e + ". Skipping "+ trashRoot.getPath()+ ".");
            }
          }
        }
      }
 catch (      Exception e) {
        LOG.warn("RuntimeException during Trash.Emptier.run(): ",e);
      }
    }
    try {
      fs.close();
    }
 catch (    IOException e) {
      LOG.warn("Trash cannot close FileSystem: ",e);
    }
  }
  private long ceiling(  long time,  long interval){
    return floor(time,interval) + interval;
  }
  private long floor(  long time,  long interval){
    return (time / interval) * interval;
  }
  @VisibleForTesting protected long getEmptierInterval(){
    return this.emptierInterval / MSECS_PER_MINUTE;
  }
}
