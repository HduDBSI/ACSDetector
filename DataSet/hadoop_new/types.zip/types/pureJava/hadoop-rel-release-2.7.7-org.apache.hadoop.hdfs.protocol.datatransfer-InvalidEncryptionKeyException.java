/** 
 * Encryption key verification failed.
 */
@InterfaceAudience.Private @InterfaceStability.Evolving public class InvalidEncryptionKeyException extends IOException {
  private static final long serialVersionUID=0l;
  public InvalidEncryptionKeyException(){
    super();
  }
  public InvalidEncryptionKeyException(  String msg){
    super(msg);
  }
}
