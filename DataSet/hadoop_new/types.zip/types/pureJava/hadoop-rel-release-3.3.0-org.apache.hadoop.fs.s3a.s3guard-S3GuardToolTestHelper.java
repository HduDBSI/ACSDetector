/** 
 * Helper class for tests which make CLI invocations of the S3Guard tools. That's  {@link AbstractS3GuardToolTestBase} and others.
 */
public final class S3GuardToolTestHelper {
  private static final Logger LOG=LoggerFactory.getLogger(S3GuardToolTestHelper.class);
  private S3GuardToolTestHelper(){
  }
  /** 
 * Execute a command, returning the buffer if the command actually completes. If an exception is raised the output is logged before the exception is rethrown.
 * @param cmd command
 * @param args argument list
 * @throws Exception on any failure
 */
  public static String exec(  S3GuardTool cmd,  String... args) throws Exception {
    return expectExecResult(0,cmd,args);
  }
  /** 
 * Execute a command, returning the buffer if the command actually completes. If an exception is raised which doesn't provide the exit code the output is logged before the exception is rethrown.
 * @param expectedResult the expected result
 * @param cmd command
 * @param args argument list
 * @throws Exception on any failure
 */
  public static String expectExecResult(  final int expectedResult,  final S3GuardTool cmd,  final String... args) throws Exception {
    ByteArrayOutputStream buf=new ByteArrayOutputStream();
    try {
      exec(expectedResult,"",cmd,buf,args);
      return buf.toString();
    }
 catch (    AssertionError e) {
      throw e;
    }
catch (    Exception e) {
      LOG.error("Command {} failed: \n{}",cmd,buf);
      throw e;
    }
  }
  /** 
 * Execute a command, saving the output into the buffer.
 * @param expectedResult expected result of the command.
 * @param errorText error text to include in the assertion.
 * @param cmd command
 * @param buf buffer to use for tool output (not SLF4J output)
 * @param args argument list
 * @throws Exception on any failure other than exception whichimplements ExitCodeProvider and whose exit code matches that expected
 */
  public static void exec(  final int expectedResult,  final String errorText,  final S3GuardTool cmd,  final ByteArrayOutputStream buf,  final String... args) throws Exception {
    LOG.info("exec {}",(Object)args);
    int r;
    try (PrintStream out=new PrintStream(buf)){
      r=cmd.run(args,out);
      out.flush();
    }
 catch (    Exception ex) {
      if (ex instanceof ExitCodeProvider) {
        final ExitCodeProvider ec=(ExitCodeProvider)ex;
        if (ec.getExitCode() == expectedResult) {
          return;
        }
      }
      throw ex;
    }
    if (expectedResult != r) {
      String message=errorText.isEmpty() ? "" : (errorText + ": ") + "Command " + cmd+ " failed\n"+ buf;
      assertEquals(message,expectedResult,r);
    }
  }
}
