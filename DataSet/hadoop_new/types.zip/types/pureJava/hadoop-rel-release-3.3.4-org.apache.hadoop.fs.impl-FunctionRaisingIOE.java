/** 
 * Function of arity 1 which may raise an IOException.
 * @param < T > type of arg1
 * @param < R > type of return value.
 * @deprecated use {@link org.apache.hadoop.util.functional.FunctionRaisingIOE}
 */
@FunctionalInterface public interface FunctionRaisingIOE<T,R> {
  R apply(  T t) throws IOException ;
}
