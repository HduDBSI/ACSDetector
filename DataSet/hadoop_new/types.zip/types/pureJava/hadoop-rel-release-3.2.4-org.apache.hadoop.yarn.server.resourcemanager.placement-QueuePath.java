public class QueuePath {
  private String parentQueue;
  private String leafQueue;
  public QueuePath(  final String leafQueue){
    this.leafQueue=leafQueue;
  }
  public QueuePath(  final String parentQueue,  final String leafQueue){
    this.parentQueue=parentQueue;
    this.leafQueue=leafQueue;
  }
  public String getParentQueue(){
    return parentQueue;
  }
  public String getLeafQueue(){
    return leafQueue;
  }
  public boolean hasParentQueue(){
    return parentQueue != null;
  }
  @Override public String toString(){
    return parentQueue + DOT + leafQueue;
  }
}
