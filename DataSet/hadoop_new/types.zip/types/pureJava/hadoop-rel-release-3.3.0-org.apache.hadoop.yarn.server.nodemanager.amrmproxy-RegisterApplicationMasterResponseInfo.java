protected static class RegisterApplicationMasterResponseInfo<T> {
  private RegisterApplicationMasterResponse response;
  private T testContext;
  RegisterApplicationMasterResponseInfo(  RegisterApplicationMasterResponse response,  T testContext){
    this.response=response;
    this.testContext=testContext;
  }
  public RegisterApplicationMasterResponse getResponse(){
    return response;
  }
  public T getTestContext(){
    return testContext;
  }
}
