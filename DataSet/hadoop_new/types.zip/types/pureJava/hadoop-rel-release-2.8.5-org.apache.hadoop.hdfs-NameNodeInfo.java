/** 
 * Stores the information related to a namenode in the cluster
 */
public static class NameNodeInfo {
  final NameNode nameNode;
  final Configuration conf;
  final String nameserviceId;
  final String nnId;
  StartupOption startOpt;
  NameNodeInfo(  NameNode nn,  String nameserviceId,  String nnId,  StartupOption startOpt,  Configuration conf){
    this.nameNode=nn;
    this.nameserviceId=nameserviceId;
    this.nnId=nnId;
    this.startOpt=startOpt;
    this.conf=conf;
  }
  public void setStartOpt(  StartupOption startOpt){
    this.startOpt=startOpt;
  }
}
