@InterfaceAudience.Private @InterfaceStability.Unstable public interface MemoryResourceHandler extends ResourceHandler {
  /** 
 * check whether a container is under OOM.
 * @param containerId the id of the container
 * @return empty if the status is unknown, true is the container is under oom,false otherwise
 */
  Optional<Boolean> isUnderOOM(  ContainerId containerId);
}
