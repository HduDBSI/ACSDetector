@Private @Unstable public class GetApplicationReportResponsePBImpl extends GetApplicationReportResponse {
  GetApplicationReportResponseProto proto=GetApplicationReportResponseProto.getDefaultInstance();
  GetApplicationReportResponseProto.Builder builder=null;
  boolean viaProto=false;
  private ApplicationReport applicationReport=null;
  public GetApplicationReportResponsePBImpl(){
    builder=GetApplicationReportResponseProto.newBuilder();
  }
  public GetApplicationReportResponsePBImpl(  GetApplicationReportResponseProto proto){
    this.proto=proto;
    viaProto=true;
  }
  public GetApplicationReportResponseProto getProto(){
    mergeLocalToProto();
    proto=viaProto ? proto : builder.build();
    viaProto=true;
    return proto;
  }
  @Override public int hashCode(){
    return getProto().hashCode();
  }
  @Override public boolean equals(  Object other){
    if (other == null)     return false;
    if (other.getClass().isAssignableFrom(this.getClass())) {
      return this.getProto().equals(this.getClass().cast(other).getProto());
    }
    return false;
  }
  @Override public String toString(){
    return TextFormat.shortDebugString(getProto());
  }
  private void mergeLocalToBuilder(){
    if (this.applicationReport != null) {
      builder.setApplicationReport(convertToProtoFormat(this.applicationReport));
    }
  }
  private void mergeLocalToProto(){
    if (viaProto)     maybeInitBuilder();
    mergeLocalToBuilder();
    proto=builder.build();
    viaProto=true;
  }
  private void maybeInitBuilder(){
    if (viaProto || builder == null) {
      builder=GetApplicationReportResponseProto.newBuilder(proto);
    }
    viaProto=false;
  }
  @Override public ApplicationReport getApplicationReport(){
    GetApplicationReportResponseProtoOrBuilder p=viaProto ? proto : builder;
    if (this.applicationReport != null) {
      return this.applicationReport;
    }
    if (!p.hasApplicationReport()) {
      return null;
    }
    this.applicationReport=convertFromProtoFormat(p.getApplicationReport());
    return this.applicationReport;
  }
  @Override public void setApplicationReport(  ApplicationReport applicationMaster){
    maybeInitBuilder();
    if (applicationMaster == null)     builder.clearApplicationReport();
    this.applicationReport=applicationMaster;
  }
  private ApplicationReportPBImpl convertFromProtoFormat(  ApplicationReportProto p){
    return new ApplicationReportPBImpl(p);
  }
  private ApplicationReportProto convertToProtoFormat(  ApplicationReport t){
    return ((ApplicationReportPBImpl)t).getProto();
  }
}
