public class FpgaResourcePlugin implements ResourcePlugin {
  private static final Log LOG=LogFactory.getLog(FpgaResourcePlugin.class);
  private ResourceHandler fpgaResourceHandler=null;
  private AbstractFpgaVendorPlugin vendorPlugin=null;
  private FpgaNodeResourceUpdateHandler fpgaNodeResourceUpdateHandler=null;
  private AbstractFpgaVendorPlugin createFpgaVendorPlugin(  Configuration conf){
    String vendorPluginClass=conf.get(YarnConfiguration.NM_FPGA_VENDOR_PLUGIN,YarnConfiguration.DEFAULT_NM_FPGA_VENDOR_PLUGIN);
    LOG.info("Using FPGA vendor plugin: " + vendorPluginClass);
    try {
      Class<?> schedulerClazz=Class.forName(vendorPluginClass);
      if (AbstractFpgaVendorPlugin.class.isAssignableFrom(schedulerClazz)) {
        return (AbstractFpgaVendorPlugin)ReflectionUtils.newInstance(schedulerClazz,conf);
      }
 else {
        throw new YarnRuntimeException("Class: " + vendorPluginClass + " not instance of "+ AbstractFpgaVendorPlugin.class.getCanonicalName());
      }
    }
 catch (    ClassNotFoundException e) {
      throw new YarnRuntimeException("Could not instantiate FPGA vendor plugin: " + vendorPluginClass,e);
    }
  }
  @Override public void initialize(  Context context) throws YarnException {
    this.vendorPlugin=createFpgaVendorPlugin(context.getConf());
    FpgaDiscoverer.getInstance().setResourceHanderPlugin(vendorPlugin);
    FpgaDiscoverer.getInstance().initialize(context.getConf());
    fpgaNodeResourceUpdateHandler=new FpgaNodeResourceUpdateHandler();
  }
  @Override public ResourceHandler createResourceHandler(  Context nmContext,  CGroupsHandler cGroupsHandler,  PrivilegedOperationExecutor privilegedOperationExecutor){
    if (fpgaResourceHandler == null) {
      fpgaResourceHandler=new FpgaResourceHandlerImpl(nmContext,cGroupsHandler,privilegedOperationExecutor,vendorPlugin);
    }
    return fpgaResourceHandler;
  }
  @Override public NodeResourceUpdaterPlugin getNodeResourceHandlerInstance(){
    return fpgaNodeResourceUpdateHandler;
  }
  @Override public void cleanup() throws YarnException {
  }
  @Override public DockerCommandPlugin getDockerCommandPluginInstance(){
    return null;
  }
  @Override public NMResourceInfo getNMResourceInfo() throws YarnException {
    return null;
  }
  @Override public String toString(){
    return FpgaResourcePlugin.class.getName();
  }
}
