private static class Pair {
  String key;
  String value;
  Pair(  String k,  String v){
    key=k;
    value=v;
  }
}
