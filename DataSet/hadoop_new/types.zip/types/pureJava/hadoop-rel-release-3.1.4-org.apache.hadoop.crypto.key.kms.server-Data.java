private static class Data {
  private final UserGroupInformation ugi;
  private final String method;
  private final String url;
  private final String remoteClientAddress;
  private Data(  UserGroupInformation ugi,  String method,  String url,  String remoteClientAddress){
    this.ugi=ugi;
    this.method=method;
    this.url=url;
    this.remoteClientAddress=remoteClientAddress;
  }
}
