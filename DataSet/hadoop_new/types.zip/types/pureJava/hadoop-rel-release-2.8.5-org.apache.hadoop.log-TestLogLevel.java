public class TestLogLevel extends TestCase {
  static final PrintStream out=System.out;
  public void testDynamicLogLevel() throws Exception {
    String logName=TestLogLevel.class.getName();
    Log testlog=LogFactory.getLog(logName);
    if (testlog instanceof Log4JLogger) {
      Logger log=((Log4JLogger)testlog).getLogger();
      log.debug("log.debug1");
      log.info("log.info1");
      log.error("log.error1");
      Assert.assertNotEquals("Get default Log Level which shouldn't be ERROR.",Level.ERROR,log.getEffectiveLevel());
      HttpServer2 server=new HttpServer2.Builder().setName("..").addEndpoint(new URI("http://localhost:0")).setFindPort(true).build();
      server.start();
      String authority=NetUtils.getHostPortString(server.getConnectorAddress(0));
      URL url=new URL("http://" + authority + "/logLevel?log="+ logName+ "&level="+ Level.ERROR);
      out.println("*** Connecting to " + url);
      URLConnection connection=url.openConnection();
      connection.connect();
      BufferedReader in=new BufferedReader(new InputStreamReader(connection.getInputStream()));
      for (String line; (line=in.readLine()) != null; out.println(line))       ;
      in.close();
      log.debug("log.debug2");
      log.info("log.info2");
      log.error("log.error2");
      assertEquals("Try setting log level: ERROR from servlet.",Level.ERROR,log.getEffectiveLevel());
      String[] args={"-setlevel",authority,logName,Level.DEBUG.toString()};
      LogLevel.main(args);
      log.debug("log.debug3");
      log.info("log.info3");
      log.error("log.error3");
      assertEquals("Try setting log level: DEBUG via command line",Level.DEBUG,log.getEffectiveLevel());
      String[] args2={"-setlevel",authority,logName,"Info"};
      LogLevel.main(args2);
      log.debug("log.debug4");
      log.info("log.info4");
      log.error("log.error4");
      assertEquals("Try setting log level: Info via command line.",Level.INFO,log.getEffectiveLevel());
      URL newUrl=new URL("http://" + authority + "/logLevel?log="+ logName+ "&level="+ "Error");
      out.println("*** Connecting to " + newUrl);
      connection=newUrl.openConnection();
      connection.connect();
      BufferedReader in2=new BufferedReader(new InputStreamReader(connection.getInputStream()));
      for (String line; (line=in2.readLine()) != null; out.println(line))       ;
      in2.close();
      log.debug("log.debug5");
      log.info("log.info5");
      log.error("log.error5");
      assertEquals("Try setting log level: Error via servlet.",Level.ERROR,log.getEffectiveLevel());
    }
 else {
      out.println(testlog.getClass() + " not tested.");
    }
  }
}
