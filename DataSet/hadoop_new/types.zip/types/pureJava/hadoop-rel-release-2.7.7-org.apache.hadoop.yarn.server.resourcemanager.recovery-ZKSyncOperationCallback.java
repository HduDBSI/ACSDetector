static class ZKSyncOperationCallback implements AsyncCallback.VoidCallback {
  @Override public void processResult(  int rc,  String path,  Object ctx){
    if (rc == Code.OK.intValue()) {
      LOG.info("ZooKeeper sync operation succeeded. path: " + path);
    }
 else {
      LOG.fatal("ZooKeeper sync operation failed. Waiting for session " + "timeout. path: " + path);
    }
  }
}
