public static class KeyParser {
  private final byte[] b;
  private int offset;
  public KeyParser(  final byte[] b,  final int offset){
    this.b=b;
    this.offset=offset;
  }
  /** 
 * Returns a string from the offset until the next string delimiter. 
 */
  public String getNextString() throws IOException {
    if (offset >= b.length) {
      throw new IOException("tried to read nonexistent string from byte array");
    }
    int i=0;
    while (offset + i < b.length && b[offset + i] != 0x0) {
      i++;
    }
    String s=new String(b,offset,i,UTF_8);
    offset=offset + i + 1;
    return s;
  }
  /** 
 * Moves current position until after the next end of string marker. 
 */
  public void skipNextString() throws IOException {
    if (offset >= b.length) {
      throw new IOException("tried to read nonexistent string from byte array");
    }
    while (offset < b.length && b[offset] != 0x0) {
      ++offset;
    }
    ++offset;
  }
  /** 
 * Read the next 8 bytes in the byte buffer as a long. 
 */
  public long getNextLong() throws IOException {
    if (offset + 8 >= b.length) {
      throw new IOException("byte array ran out when trying to read long");
    }
    long value=readReverseOrderedLong(b,offset);
    offset+=8;
    return value;
  }
  public int getOffset(){
    return offset;
  }
  /** 
 * Returns a copy of the remaining bytes. 
 */
  public byte[] getRemainingBytes(){
    byte[] bytes=new byte[b.length - offset];
    System.arraycopy(b,offset,bytes,0,b.length - offset);
    return bytes;
  }
}
