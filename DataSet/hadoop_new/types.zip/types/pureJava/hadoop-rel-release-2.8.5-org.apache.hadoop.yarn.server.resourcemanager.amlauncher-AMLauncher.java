/** 
 * The launch of the AM itself.
 */
public class AMLauncher implements Runnable {
  private static final Log LOG=LogFactory.getLog(AMLauncher.class);
  private ContainerManagementProtocol containerMgrProxy;
  private final RMAppAttempt application;
  private final Configuration conf;
  private final AMLauncherEventType eventType;
  private final RMContext rmContext;
  private final Container masterContainer;
  @SuppressWarnings("rawtypes") private final EventHandler handler;
  public AMLauncher(  RMContext rmContext,  RMAppAttempt application,  AMLauncherEventType eventType,  Configuration conf){
    this.application=application;
    this.conf=conf;
    this.eventType=eventType;
    this.rmContext=rmContext;
    this.handler=rmContext.getDispatcher().getEventHandler();
    this.masterContainer=application.getMasterContainer();
  }
  private void connect() throws IOException {
    ContainerId masterContainerID=masterContainer.getId();
    containerMgrProxy=getContainerMgrProxy(masterContainerID);
  }
  private void launch() throws IOException, YarnException {
    connect();
    ContainerId masterContainerID=masterContainer.getId();
    ApplicationSubmissionContext applicationContext=application.getSubmissionContext();
    LOG.info("Setting up container " + masterContainer + " for AM "+ application.getAppAttemptId());
    ContainerLaunchContext launchContext=createAMContainerLaunchContext(applicationContext,masterContainerID);
    StartContainerRequest scRequest=StartContainerRequest.newInstance(launchContext,masterContainer.getContainerToken());
    List<StartContainerRequest> list=new ArrayList<StartContainerRequest>();
    list.add(scRequest);
    StartContainersRequest allRequests=StartContainersRequest.newInstance(list);
    StartContainersResponse response=containerMgrProxy.startContainers(allRequests);
    if (response.getFailedRequests() != null && response.getFailedRequests().containsKey(masterContainerID)) {
      Throwable t=response.getFailedRequests().get(masterContainerID).deSerialize();
      parseAndThrowException(t);
    }
 else {
      LOG.info("Done launching container " + masterContainer + " for AM "+ application.getAppAttemptId());
    }
  }
  private void cleanup() throws IOException, YarnException {
    connect();
    ContainerId containerId=masterContainer.getId();
    List<ContainerId> containerIds=new ArrayList<ContainerId>();
    containerIds.add(containerId);
    StopContainersRequest stopRequest=StopContainersRequest.newInstance(containerIds);
    StopContainersResponse response=containerMgrProxy.stopContainers(stopRequest);
    if (response.getFailedRequests() != null && response.getFailedRequests().containsKey(containerId)) {
      Throwable t=response.getFailedRequests().get(containerId).deSerialize();
      parseAndThrowException(t);
    }
  }
  protected ContainerManagementProtocol getContainerMgrProxy(  final ContainerId containerId){
    final NodeId node=masterContainer.getNodeId();
    final InetSocketAddress containerManagerConnectAddress=NetUtils.createSocketAddrForHost(node.getHost(),node.getPort());
    final YarnRPC rpc=getYarnRPC();
    UserGroupInformation currentUser=UserGroupInformation.createRemoteUser(containerId.getApplicationAttemptId().toString());
    String user=rmContext.getRMApps().get(containerId.getApplicationAttemptId().getApplicationId()).getUser();
    org.apache.hadoop.yarn.api.records.Token token=rmContext.getNMTokenSecretManager().createNMToken(containerId.getApplicationAttemptId(),node,user);
    currentUser.addToken(ConverterUtils.convertFromYarn(token,containerManagerConnectAddress));
    return NMProxy.createNMProxy(conf,ContainerManagementProtocol.class,currentUser,rpc,containerManagerConnectAddress);
  }
  @VisibleForTesting protected YarnRPC getYarnRPC(){
    return YarnRPC.create(conf);
  }
  private ContainerLaunchContext createAMContainerLaunchContext(  ApplicationSubmissionContext applicationMasterContext,  ContainerId containerID) throws IOException {
    ContainerLaunchContext container=applicationMasterContext.getAMContainerSpec();
    setupTokens(container,containerID);
    return container;
  }
  @Private @VisibleForTesting protected void setupTokens(  ContainerLaunchContext container,  ContainerId containerID) throws IOException {
    Map<String,String> environment=container.getEnvironment();
    environment.put(ApplicationConstants.APPLICATION_WEB_PROXY_BASE_ENV,application.getWebProxyBase());
    ApplicationId applicationId=application.getAppAttemptId().getApplicationId();
    environment.put(ApplicationConstants.APP_SUBMIT_TIME_ENV,String.valueOf(rmContext.getRMApps().get(applicationId).getSubmitTime()));
    environment.put(ApplicationConstants.MAX_APP_ATTEMPTS_ENV,String.valueOf(rmContext.getRMApps().get(applicationId).getMaxAppAttempts()));
    Credentials credentials=new Credentials();
    DataInputByteBuffer dibb=new DataInputByteBuffer();
    ByteBuffer tokens=container.getTokens();
    if (tokens != null) {
      dibb.reset(tokens);
      credentials.readTokenStorageStream(dibb);
      tokens.rewind();
    }
    Token<AMRMTokenIdentifier> amrmToken=createAndSetAMRMToken();
    if (amrmToken != null) {
      credentials.addToken(amrmToken.getService(),amrmToken);
    }
    DataOutputBuffer dob=new DataOutputBuffer();
    credentials.writeTokenStorageToStream(dob);
    container.setTokens(ByteBuffer.wrap(dob.getData(),0,dob.getLength()));
  }
  @VisibleForTesting protected Token<AMRMTokenIdentifier> createAndSetAMRMToken(){
    Token<AMRMTokenIdentifier> amrmToken=this.rmContext.getAMRMTokenSecretManager().createAndGetAMRMToken(application.getAppAttemptId());
    ((RMAppAttemptImpl)application).setAMRMToken(amrmToken);
    return amrmToken;
  }
  @SuppressWarnings("unchecked") public void run(){
switch (eventType) {
case LAUNCH:
      try {
        LOG.info("Launching master" + application.getAppAttemptId());
        launch();
        handler.handle(new RMAppAttemptEvent(application.getAppAttemptId(),RMAppAttemptEventType.LAUNCHED));
      }
 catch (      Exception ie) {
        String message="Error launching " + application.getAppAttemptId() + ". Got exception: "+ StringUtils.stringifyException(ie);
        LOG.info(message);
        handler.handle(new RMAppAttemptEvent(application.getAppAttemptId(),RMAppAttemptEventType.LAUNCH_FAILED,message));
      }
    break;
case CLEANUP:
  try {
    LOG.info("Cleaning master " + application.getAppAttemptId());
    cleanup();
  }
 catch (  IOException ie) {
    LOG.info("Error cleaning master ",ie);
  }
catch (  YarnException e) {
    StringBuilder sb=new StringBuilder("Container ");
    sb.append(masterContainer.getId().toString());
    sb.append(" is not handled by this NodeManager");
    if (!e.getMessage().contains(sb.toString())) {
      LOG.info("Error cleaning master ",e);
    }
  }
break;
default :
LOG.warn("Received unknown event-type " + eventType + ". Ignoring.");
break;
}
}
private void parseAndThrowException(Throwable t) throws YarnException, IOException {
if (t instanceof YarnException) {
throw (YarnException)t;
}
 else if (t instanceof InvalidToken) {
throw (InvalidToken)t;
}
 else {
throw (IOException)t;
}
}
}
