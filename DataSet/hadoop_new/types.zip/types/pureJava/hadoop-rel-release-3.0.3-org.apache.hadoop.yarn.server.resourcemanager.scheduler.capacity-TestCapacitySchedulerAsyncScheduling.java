public class TestCapacitySchedulerAsyncScheduling {
  private final int GB=1024;
  private YarnConfiguration conf;
  RMNodeLabelsManager mgr;
  private NMHeartbeatThread nmHeartbeatThread=null;
  @Before public void setUp() throws Exception {
    conf=new YarnConfiguration();
    conf.setClass(YarnConfiguration.RM_SCHEDULER,CapacityScheduler.class,ResourceScheduler.class);
    conf.setBoolean(CapacitySchedulerConfiguration.SCHEDULE_ASYNCHRONOUSLY_ENABLE,true);
    mgr=new NullRMNodeLabelsManager();
    mgr.init(conf);
  }
  @Test(timeout=300000) public void testSingleThreadAsyncContainerAllocation() throws Exception {
    testAsyncContainerAllocation(1);
  }
  @Test(timeout=300000) public void testTwoThreadsAsyncContainerAllocation() throws Exception {
    testAsyncContainerAllocation(2);
  }
  @Test(timeout=300000) public void testThreeThreadsAsyncContainerAllocation() throws Exception {
    testAsyncContainerAllocation(3);
  }
  public void testAsyncContainerAllocation(  int numThreads) throws Exception {
    conf.setInt(CapacitySchedulerConfiguration.SCHEDULE_ASYNCHRONOUSLY_MAXIMUM_THREAD,numThreads);
    conf.setInt(CapacitySchedulerConfiguration.SCHEDULE_ASYNCHRONOUSLY_PREFIX + ".scheduling-interval-ms",100);
    final RMNodeLabelsManager mgr=new NullRMNodeLabelsManager();
    mgr.init(conf);
    MockRM rm=new MockRM(TestUtils.getConfigurationWithMultipleQueues(conf)){
      @Override public RMNodeLabelsManager createNodeLabelManager(){
        return mgr;
      }
    }
;
    rm.getRMContext().setNodeLabelManager(mgr);
    rm.start();
    List<MockNM> nms=new ArrayList<>();
    for (int i=0; i < 10; i++) {
      nms.add(rm.registerNode("127.0.0." + i + ":1234",20 * GB));
    }
    keepNMHeartbeat(nms,1000);
    List<MockAM> ams=new ArrayList<>();
    int totalAsked=3 * GB;
    for (int i=0; i < 3; i++) {
      RMApp rmApp=rm.submitApp(1024,"app","user",null,false,Character.toString((char)(i % 34 + 97)),1,null,null,false);
      MockAM am=MockRM.launchAMWhenAsyncSchedulingEnabled(rmApp,rm);
      am.registerAppAttempt();
      ams.add(am);
    }
    for (int i=0; i < 3; i++) {
      ams.get(i).allocate("*",1024,20 * (i + 1),new ArrayList<>());
      totalAsked+=20 * (i + 1) * GB;
    }
    int waitTime=15000;
    while (waitTime > 0) {
      if (rm.getResourceScheduler().getRootQueueMetrics().getAllocatedMB() == totalAsked) {
        break;
      }
      Thread.sleep(50);
      waitTime-=50;
    }
    Assert.assertEquals(rm.getResourceScheduler().getRootQueueMetrics().getAllocatedMB(),totalAsked);
    waitTime=2000;
    while (waitTime > 0) {
      Assert.assertEquals(rm.getResourceScheduler().getRootQueueMetrics().getAllocatedMB(),totalAsked);
      waitTime-=50;
      Thread.sleep(50);
    }
    rm.close();
  }
  @Test(timeout=30000) public void testCommitProposalForFailedAppAttempt() throws Exception {
    Configuration disableAsyncConf=new Configuration(conf);
    disableAsyncConf.setBoolean(CapacitySchedulerConfiguration.SCHEDULE_ASYNCHRONOUSLY_ENABLE,false);
    final MockRM rm=new MockRM(disableAsyncConf);
    rm.start();
    final MockNM nm1=rm.registerNode("192.168.0.1:1234",9 * GB);
    final MockNM nm2=rm.registerNode("192.168.0.2:2234",9 * GB);
    List<MockNM> nmLst=new ArrayList<>();
    nmLst.add(nm1);
    nmLst.add(nm2);
    while (((CapacityScheduler)rm.getRMContext().getScheduler()).getNodeTracker().nodeCount() < 2) {
      Thread.sleep(10);
    }
    Assert.assertEquals(2,((AbstractYarnScheduler)rm.getRMContext().getScheduler()).getNodeTracker().nodeCount());
    CapacityScheduler scheduler=(CapacityScheduler)rm.getRMContext().getScheduler();
    SchedulerNode sn1=scheduler.getSchedulerNode(nm1.getNodeId());
    SchedulerNode sn2=scheduler.getSchedulerNode(nm2.getNodeId());
    RMApp app=rm.submitApp(200,"app","user",null,false,"default",YarnConfiguration.DEFAULT_RM_AM_MAX_ATTEMPTS,null,null,true,true);
    MockAM am=MockRM.launchAndRegisterAM(app,rm,nm1);
    FiCaSchedulerApp schedulerApp=scheduler.getApplicationAttempt(am.getApplicationAttemptId());
    allocateAndLaunchContainers(am,nm2,rm,1,Resources.createResource(5 * GB),0,2);
    Assert.assertEquals(1,sn1.getNumContainers());
    Assert.assertEquals(1,sn2.getNumContainers());
    scheduler.handle(new AppAttemptRemovedSchedulerEvent(am.getApplicationAttemptId(),RMAppAttemptState.KILLED,true));
    while (sn1.getCopiedListOfRunningContainers().size() == 1) {
      Thread.sleep(100);
    }
    while (sn1.getCopiedListOfRunningContainers().size() == 0) {
      nm1.nodeHeartbeat(true);
      Thread.sleep(100);
    }
    Resource reservedResource=Resources.createResource(5 * GB);
    Container container=Container.newInstance(ContainerId.newContainerId(am.getApplicationAttemptId(),3),sn2.getNodeID(),sn2.getHttpAddress(),reservedResource,Priority.newInstance(0),null);
    RMContainer rmContainer=new RMContainerImpl(container,SchedulerRequestKey.create(ResourceRequest.newInstance(Priority.newInstance(0),"*",reservedResource,1)),am.getApplicationAttemptId(),sn2.getNodeID(),"user",rm.getRMContext());
    SchedulerContainer reservedContainer=new SchedulerContainer(schedulerApp,scheduler.getNode(sn2.getNodeID()),rmContainer,"",false);
    ContainerAllocationProposal reservedForAttempt1Proposal=new ContainerAllocationProposal(reservedContainer,null,reservedContainer,NodeType.OFF_SWITCH,NodeType.OFF_SWITCH,SchedulingMode.RESPECT_PARTITION_EXCLUSIVITY,reservedResource);
    List<ContainerAllocationProposal> reservedProposals=new ArrayList<>();
    reservedProposals.add(reservedForAttempt1Proposal);
    ResourceCommitRequest request=new ResourceCommitRequest(null,reservedProposals,null);
    scheduler.tryCommit(scheduler.getClusterResource(),request);
    Assert.assertNull("Outdated proposal should not be accepted!",sn2.getReservedContainer());
    rm.stop();
  }
  @Test(timeout=30000) public void testCommitOutdatedReservedProposal() throws Exception {
    Configuration disableAsyncConf=new Configuration(conf);
    disableAsyncConf.setBoolean(CapacitySchedulerConfiguration.SCHEDULE_ASYNCHRONOUSLY_ENABLE,false);
    final MockRM rm=new MockRM(disableAsyncConf);
    rm.start();
    final MockNM nm1=rm.registerNode("127.0.0.1:1234",9 * GB);
    final MockNM nm2=rm.registerNode("127.0.0.2:2234",9 * GB);
    int waitTime=1000;
    while (waitTime > 0 && ((AbstractYarnScheduler)rm.getRMContext().getScheduler()).getNodeTracker().nodeCount() < 2) {
      waitTime-=10;
      Thread.sleep(10);
    }
    Assert.assertEquals(2,((AbstractYarnScheduler)rm.getRMContext().getScheduler()).getNodeTracker().nodeCount());
    YarnScheduler scheduler=rm.getRMContext().getScheduler();
    final SchedulerNode sn1=((CapacityScheduler)scheduler).getSchedulerNode(nm1.getNodeId());
    final SchedulerNode sn2=((CapacityScheduler)scheduler).getSchedulerNode(nm2.getNodeId());
    RMApp app=rm.submitApp(200,"app","user",null,"default");
    final MockAM am=MockRM.launchAndRegisterAM(app,rm,nm1);
    RMApp app2=rm.submitApp(200,"app","user",null,"default");
    final MockAM am2=MockRM.launchAndRegisterAM(app2,rm,nm1);
    allocateAndLaunchContainers(am,nm1,rm,1,Resources.createResource(5 * GB),0,2);
    allocateAndLaunchContainers(am,nm2,rm,1,Resources.createResource(5 * GB),0,3);
    Assert.assertEquals(3,sn1.getNumContainers());
    Assert.assertEquals(1,sn2.getNumContainers());
    ResourceRequest rr2=ResourceRequest.newInstance(Priority.newInstance(0),"*",Resources.createResource(5 * GB),1);
    am.allocate(Arrays.asList(rr2),null);
    nm1.nodeHeartbeat(true);
    waitTime=1000;
    while (waitTime > 0 && sn1.getReservedContainer() == null) {
      waitTime-=10;
      Thread.sleep(10);
    }
    Assert.assertNotNull(sn1.getReservedContainer());
    final CapacityScheduler cs=(CapacityScheduler)scheduler;
    final CapacityScheduler spyCs=Mockito.spy(cs);
    final AtomicBoolean isFirstReserve=new AtomicBoolean(true);
    final AtomicBoolean isChecked=new AtomicBoolean(false);
    Mockito.doAnswer(new Answer<Object>(){
      public Object answer(      InvocationOnMock invocation) throws Exception {
        ResourceCommitRequest request=(ResourceCommitRequest)invocation.getArguments()[1];
        if (request.getContainersToReserve().size() > 0 && isFirstReserve.compareAndSet(true,false)) {
          RMContainer killableContainer=sn2.getCopiedListOfRunningContainers().get(0);
          cs.completedContainer(killableContainer,ContainerStatus.newInstance(killableContainer.getContainerId(),ContainerState.COMPLETE,"",ContainerExitStatus.KILLED_BY_RESOURCEMANAGER),RMContainerEventType.KILL);
          Assert.assertEquals(0,sn2.getCopiedListOfRunningContainers().size());
          cs.handle(new NodeUpdateSchedulerEvent(sn2.getRMNode()));
          int waitTime=1000;
          while (waitTime > 0 && sn2.getCopiedListOfRunningContainers().size() == 0) {
            waitTime-=10;
            Thread.sleep(10);
          }
          Assert.assertEquals(1,sn2.getCopiedListOfRunningContainers().size());
          Assert.assertNull(sn1.getReservedContainer());
          ResourceRequest rr3=ResourceRequest.newInstance(Priority.newInstance(0),"*",Resources.createResource(5 * GB),1);
          am2.allocate(Arrays.asList(rr3),null);
          cs.handle(new NodeUpdateSchedulerEvent(sn1.getRMNode()));
          waitTime=1000;
          while (waitTime > 0 && sn1.getReservedContainer() == null) {
            waitTime-=10;
            Thread.sleep(10);
          }
          Assert.assertNotNull(sn1.getReservedContainer());
          try {
            cs.tryCommit((Resource)invocation.getArguments()[0],(ResourceCommitRequest)invocation.getArguments()[1]);
          }
 catch (          Exception e) {
            e.printStackTrace();
            Assert.fail();
          }
          isChecked.set(true);
        }
 else {
          cs.tryCommit((Resource)invocation.getArguments()[0],(ResourceCommitRequest)invocation.getArguments()[1]);
        }
        return null;
      }
    }
).when(spyCs).tryCommit(Mockito.any(Resource.class),Mockito.any(ResourceCommitRequest.class));
    spyCs.handle(new NodeUpdateSchedulerEvent(sn1.getRMNode()));
    waitTime=1000;
    while (waitTime > 0 && !isChecked.get()) {
      waitTime-=10;
      Thread.sleep(10);
    }
    rm.stop();
  }
  @Test(timeout=30000) public void testNodeResourceOverAllocated() throws Exception {
    Configuration disableAsyncConf=new Configuration(conf);
    disableAsyncConf.setBoolean(CapacitySchedulerConfiguration.SCHEDULE_ASYNCHRONOUSLY_ENABLE,false);
    final MockRM rm=new MockRM(disableAsyncConf);
    rm.start();
    final MockNM nm1=rm.registerNode("127.0.0.1:1234",9 * GB);
    final MockNM nm2=rm.registerNode("127.0.0.2:1234",9 * GB);
    List<MockNM> nmLst=new ArrayList<>();
    nmLst.add(nm1);
    nmLst.add(nm2);
    while (((CapacityScheduler)rm.getRMContext().getScheduler()).getNodeTracker().nodeCount() < 2) {
      Thread.sleep(10);
    }
    Assert.assertEquals(2,((AbstractYarnScheduler)rm.getRMContext().getScheduler()).getNodeTracker().nodeCount());
    CapacityScheduler scheduler=(CapacityScheduler)rm.getRMContext().getScheduler();
    SchedulerNode sn1=scheduler.getSchedulerNode(nm1.getNodeId());
    RMApp app=rm.submitApp(200,"app","user",null,false,"default",YarnConfiguration.DEFAULT_RM_AM_MAX_ATTEMPTS,null,null,true,true);
    MockAM am=MockRM.launchAndRegisterAM(app,rm,nm1);
    FiCaSchedulerApp schedulerApp=scheduler.getApplicationAttempt(am.getApplicationAttemptId());
    Resource containerResource=Resources.createResource(5 * GB);
    am.allocate(Arrays.asList(ResourceRequest.newInstance(Priority.newInstance(0),"*",containerResource,2)),null);
    for (int containerNo=2; containerNo <= 3; containerNo++) {
      Container container=Container.newInstance(ContainerId.newContainerId(am.getApplicationAttemptId(),containerNo),sn1.getNodeID(),sn1.getHttpAddress(),containerResource,Priority.newInstance(0),null);
      RMContainer rmContainer=new RMContainerImpl(container,SchedulerRequestKey.create(ResourceRequest.newInstance(Priority.newInstance(0),"*",containerResource,1)),am.getApplicationAttemptId(),sn1.getNodeID(),"user",rm.getRMContext());
      SchedulerContainer newContainer=new SchedulerContainer(schedulerApp,scheduler.getNode(sn1.getNodeID()),rmContainer,"",true);
      ContainerAllocationProposal newContainerProposal=new ContainerAllocationProposal(newContainer,null,null,NodeType.OFF_SWITCH,NodeType.OFF_SWITCH,SchedulingMode.RESPECT_PARTITION_EXCLUSIVITY,containerResource);
      List<ContainerAllocationProposal> newProposals=new ArrayList<>();
      newProposals.add(newContainerProposal);
      ResourceCommitRequest request=new ResourceCommitRequest(newProposals,null,null);
      scheduler.tryCommit(scheduler.getClusterResource(),request);
    }
    Assert.assertTrue("Node resource is Over-allocated!",sn1.getUnallocatedResource().getMemorySize() > 0);
    rm.stop();
  }
  /** 
 * Make sure scheduler skips NMs which haven't heartbeat for a while.
 * @throws Exception
 */
  @Test public void testAsyncSchedulerSkipNoHeartbeatNMs() throws Exception {
    int heartbeatInterval=100;
    conf.setInt(CapacitySchedulerConfiguration.SCHEDULE_ASYNCHRONOUSLY_MAXIMUM_THREAD,1);
    conf.setInt(CapacitySchedulerConfiguration.SCHEDULE_ASYNCHRONOUSLY_PREFIX + ".scheduling-interval-ms",100);
    conf.setInt(YarnConfiguration.RM_NM_HEARTBEAT_INTERVAL_MS,heartbeatInterval);
    final RMNodeLabelsManager mgr=new NullRMNodeLabelsManager();
    mgr.init(conf);
    MockRM rm=new MockRM(TestUtils.getConfigurationWithMultipleQueues(conf)){
      @Override public RMNodeLabelsManager createNodeLabelManager(){
        return mgr;
      }
    }
;
    CapacityScheduler cs=(CapacityScheduler)rm.getResourceScheduler();
    rm.getRMContext().setNodeLabelManager(mgr);
    rm.start();
    List<MockNM> nms=new ArrayList<>();
    for (int i=0; i < 10; i++) {
      nms.add(rm.registerNode("127.0.0." + i + ":1234",20 * GB));
    }
    List<MockAM> ams=new ArrayList<>();
    keepNMHeartbeat(nms,heartbeatInterval);
    for (int i=0; i < 3; i++) {
      RMApp rmApp=rm.submitApp(1024,"app","user",null,false,Character.toString((char)(i % 34 + 97)),1,null,null,false);
      MockAM am=MockRM.launchAMWhenAsyncSchedulingEnabled(rmApp,rm);
      am.registerAppAttempt();
      ams.add(am);
    }
    pauseNMHeartbeat();
    Thread.sleep(heartbeatInterval * 3);
    for (int i=0; i < 3; i++) {
      ams.get(i).allocate("*",1024,20 * (i + 1),new ArrayList<>());
    }
    for (int i=0; i < 5; i++) {
      nms.get(i).nodeHeartbeat(true);
    }
    Thread.sleep(2000);
    for (int i=0; i < 9; i++) {
      if (i < 5) {
        Assert.assertTrue(checkNumNonAMContainersOnNode(cs,nms.get(i)) > 0);
      }
 else {
        Assert.assertTrue(checkNumNonAMContainersOnNode(cs,nms.get(i)) == 0);
      }
    }
    rm.close();
  }
public static class NMHeartbeatThread extends Thread {
    private List<MockNM> mockNMS;
    private int interval;
    private volatile boolean shouldStop=false;
    public NMHeartbeatThread(    List<MockNM> mockNMs,    int interval){
      this.mockNMS=mockNMs;
      this.interval=interval;
    }
    public void run(){
      while (true) {
        if (shouldStop) {
          break;
        }
        for (        MockNM nm : mockNMS) {
          try {
            nm.nodeHeartbeat(true);
          }
 catch (          Exception e) {
            e.printStackTrace();
          }
        }
        try {
          Thread.sleep(interval);
        }
 catch (        InterruptedException e) {
          e.printStackTrace();
        }
      }
    }
    public void setShouldStop(){
      shouldStop=true;
    }
  }
  private void keepNMHeartbeat(  List<MockNM> mockNMs,  int interval){
    if (nmHeartbeatThread != null) {
      nmHeartbeatThread.setShouldStop();
      nmHeartbeatThread=null;
    }
    nmHeartbeatThread=new NMHeartbeatThread(mockNMs,interval);
    nmHeartbeatThread.start();
  }
  private void pauseNMHeartbeat(){
    if (nmHeartbeatThread != null) {
      nmHeartbeatThread.setShouldStop();
      nmHeartbeatThread=null;
    }
  }
  private int checkNumNonAMContainersOnNode(  CapacityScheduler cs,  MockNM nm){
    SchedulerNode node=cs.getNode(nm.getNodeId());
    int nonAMContainer=0;
    for (    RMContainer c : node.getCopiedListOfRunningContainers()) {
      if (!c.isAMContainer()) {
        nonAMContainer++;
      }
    }
    return nonAMContainer;
  }
  private void allocateAndLaunchContainers(  MockAM am,  MockNM nm,  MockRM rm,  int nContainer,  Resource resource,  int priority,  int startContainerId) throws Exception {
    am.allocate(Arrays.asList(ResourceRequest.newInstance(Priority.newInstance(priority),"*",resource,nContainer)),null);
    ContainerId lastContainerId=ContainerId.newContainerId(am.getApplicationAttemptId(),startContainerId + nContainer - 1);
    Assert.assertTrue(rm.waitForState(nm,lastContainerId,RMContainerState.ALLOCATED));
    am.allocate(null,null);
    CapacityScheduler cs=(CapacityScheduler)rm.getResourceScheduler();
    for (int cId=startContainerId; cId < startContainerId + nContainer; cId++) {
      ContainerId containerId=ContainerId.newContainerId(am.getApplicationAttemptId(),cId);
      RMContainer rmContainer=cs.getRMContainer(containerId);
      if (rmContainer != null) {
        rmContainer.handle(new RMContainerEvent(containerId,RMContainerEventType.LAUNCHED));
      }
 else {
        Assert.fail("Cannot find RMContainer");
      }
      rm.waitForState(nm,ContainerId.newContainerId(am.getApplicationAttemptId(),cId),RMContainerState.RUNNING);
    }
  }
}
