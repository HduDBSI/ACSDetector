static class ResourceRequestInfo<T> {
  ResourceRequest remoteRequest;
  LinkedHashSet<T> containerRequests;
  ResourceRequestInfo(  Long allocationRequestId,  Priority priority,  String resourceName,  Resource capability,  boolean relaxLocality){
    remoteRequest=ResourceRequest.newBuilder().priority(priority).resourceName(resourceName).capability(capability).numContainers(0).allocationRequestId(allocationRequestId).relaxLocality(relaxLocality).build();
    containerRequests=new LinkedHashSet<T>();
  }
}
