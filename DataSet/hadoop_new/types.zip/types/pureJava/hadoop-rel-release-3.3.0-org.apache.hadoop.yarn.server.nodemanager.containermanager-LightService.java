static class LightService extends AuxiliaryService implements Service {
  private final char idef;
  private final int expected_appId;
  private int remaining_init;
  private int remaining_stop;
  private ByteBuffer meta=null;
  private ArrayList<Integer> stoppedApps;
  private ContainerId containerId;
  private Resource resource;
  LightService(  String name,  char idef,  int expected_appId){
    this(name,idef,expected_appId,null);
  }
  LightService(  String name,  char idef,  int expected_appId,  ByteBuffer meta){
    super(name);
    this.idef=idef;
    this.expected_appId=expected_appId;
    this.meta=meta;
    this.stoppedApps=new ArrayList<Integer>();
  }
  @SuppressWarnings("unchecked") public ArrayList<Integer> getAppIdsStopped(){
    return (ArrayList<Integer>)this.stoppedApps.clone();
  }
  @Override protected void serviceInit(  Configuration conf) throws Exception {
    remaining_init=conf.getInt(idef + ".expected.init",0);
    remaining_stop=conf.getInt(idef + ".expected.stop",0);
    super.serviceInit(conf);
  }
  @Override protected void serviceStop() throws Exception {
    assertEquals(0,remaining_init);
    assertEquals(0,remaining_stop);
    super.serviceStop();
  }
  @Override public void initializeApplication(  ApplicationInitializationContext context){
    ByteBuffer data=context.getApplicationDataForService();
    assertEquals(idef,data.getChar());
    assertEquals(expected_appId,data.getInt());
    assertEquals(expected_appId,context.getApplicationId().getId());
  }
  @Override public void stopApplication(  ApplicationTerminationContext context){
    stoppedApps.add(context.getApplicationId().getId());
  }
  @Override public ByteBuffer getMetaData(){
    return meta;
  }
  @Override public void initializeContainer(  ContainerInitializationContext initContainerContext){
    containerId=initContainerContext.getContainerId();
    resource=initContainerContext.getResource();
  }
  @Override public void stopContainer(  ContainerTerminationContext stopContainerContext){
    containerId=stopContainerContext.getContainerId();
    resource=stopContainerContext.getResource();
  }
}
