/** 
 * The KMS implementation of  {@link TokenRenewer}.
 */
public static class KMSTokenRenewer extends TokenRenewer {
  private static final Logger LOG=LoggerFactory.getLogger(KMSTokenRenewer.class);
  @Override public boolean handleKind(  Text kind){
    return kind.equals(TOKEN_KIND);
  }
  @Override public boolean isManaged(  Token<?> token) throws IOException {
    return true;
  }
  @Override public long renew(  Token<?> token,  Configuration conf) throws IOException {
    LOG.debug("Renewing delegation token {}",token);
    KeyProvider keyProvider=KMSUtil.createKeyProvider(conf,KeyProviderFactory.KEY_PROVIDER_PATH);
    try {
      if (!(keyProvider instanceof KeyProviderDelegationTokenExtension.DelegationTokenExtension)) {
        LOG.warn("keyProvider {} cannot renew dt.",keyProvider == null ? "null" : keyProvider.getClass());
        return 0;
      }
      return ((KeyProviderDelegationTokenExtension.DelegationTokenExtension)keyProvider).renewDelegationToken(token);
    }
  finally {
      if (keyProvider != null) {
        keyProvider.close();
      }
    }
  }
  @Override public void cancel(  Token<?> token,  Configuration conf) throws IOException {
    LOG.debug("Canceling delegation token {}",token);
    KeyProvider keyProvider=KMSUtil.createKeyProvider(conf,KeyProviderFactory.KEY_PROVIDER_PATH);
    try {
      if (!(keyProvider instanceof KeyProviderDelegationTokenExtension.DelegationTokenExtension)) {
        LOG.warn("keyProvider {} cannot cancel dt.",keyProvider == null ? "null" : keyProvider.getClass());
        return;
      }
      ((KeyProviderDelegationTokenExtension.DelegationTokenExtension)keyProvider).cancelDelegationToken(token);
    }
  finally {
      if (keyProvider != null) {
        keyProvider.close();
      }
    }
  }
}
