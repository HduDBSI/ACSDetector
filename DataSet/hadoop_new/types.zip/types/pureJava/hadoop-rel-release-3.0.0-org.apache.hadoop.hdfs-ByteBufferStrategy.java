/** 
 * Used to read bytes into a user-supplied ByteBuffer. Note it's not thread-safe and the behavior is not defined if concurrently operated. When read operation is performed, the position of the underlying byte buffer will move forward as stated in ByteBufferReadable#read(ByteBuffer buf) method.
 */
class ByteBufferStrategy implements ReaderStrategy {
  private final DFSClient dfsClient;
  private final ReadStatistics readStatistics;
  private final ByteBuffer readBuf;
  private final int targetLength;
  /** 
 * The constructor.
 * @param readBuf target buffer to read into
 * @param readStatistics statistics counter
 */
  ByteBufferStrategy(  ByteBuffer readBuf,  ReadStatistics readStatistics,  DFSClient dfsClient){
    this.readBuf=readBuf;
    this.targetLength=readBuf.remaining();
    this.readStatistics=readStatistics;
    this.dfsClient=dfsClient;
  }
  @Override public ByteBuffer getReadBuffer(){
    return readBuf;
  }
  @Override public int readFromBlock(  BlockReader blockReader) throws IOException {
    return readFromBlock(blockReader,readBuf.remaining());
  }
  @Override public int readFromBlock(  BlockReader blockReader,  int length) throws IOException {
    ByteBuffer tmpBuf=readBuf.duplicate();
    tmpBuf.limit(tmpBuf.position() + length);
    int nRead=blockReader.read(tmpBuf);
    if (nRead > 0) {
      readBuf.position(readBuf.position() + nRead);
      updateReadStatistics(readStatistics,nRead,blockReader);
      dfsClient.updateFileSystemReadStats(blockReader.getNetworkDistance(),nRead);
    }
    return nRead;
  }
  @Override public int getTargetLength(){
    return targetLength;
  }
  @Override public int readFromBuffer(  ByteBuffer src){
    return readFromBuffer(src,src.remaining());
  }
  @Override public int readFromBuffer(  ByteBuffer src,  int length){
    ByteBuffer dup=src.duplicate();
    int newLen=Math.min(readBuf.remaining(),dup.remaining());
    newLen=Math.min(newLen,length);
    dup.limit(dup.position() + newLen);
    readBuf.put(dup);
    return newLen;
  }
}
