class PurgableSource implements MetricsSource {
  int nextKey=0;
  String lastKeyName=null;
  @Override public void getMetrics(  MetricsCollector collector,  boolean all){
    MetricsRecordBuilder rb=collector.addRecord("purgablesource").setContext("test");
    lastKeyName="key" + nextKey++;
    rb.addGauge(info(lastKeyName,"desc"),1);
  }
}
