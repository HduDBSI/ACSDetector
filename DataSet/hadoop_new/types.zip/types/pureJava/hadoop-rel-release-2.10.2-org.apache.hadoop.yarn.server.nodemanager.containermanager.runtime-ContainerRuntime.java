/** 
 * An abstraction for various container runtime implementations. Examples include Process Tree, Docker, Appc runtimes etc. These implementations are meant for low-level OS container support - dependencies on higher-level node manager constructs should be avoided.
 */
@InterfaceAudience.Private @InterfaceStability.Unstable public interface ContainerRuntime {
  /** 
 * Prepare a container to be ready for launch.
 * @param ctx the {@link ContainerRuntimeContext}
 * @throws ContainerExecutionException if an error occurs while preparingthe container
 */
  void prepareContainer(  ContainerRuntimeContext ctx) throws ContainerExecutionException ;
  /** 
 * Launch a container.
 * @param ctx the {@link ContainerRuntimeContext}
 * @throws ContainerExecutionException if an error occurs while launchingthe container
 */
  void launchContainer(  ContainerRuntimeContext ctx) throws ContainerExecutionException ;
  /** 
 * Signal a container. Signals may be a request to terminate, a status check, etc.
 * @param ctx the {@link ContainerRuntimeContext}
 * @throws ContainerExecutionException if an error occurs while signalingthe container
 */
  void signalContainer(  ContainerRuntimeContext ctx) throws ContainerExecutionException ;
  /** 
 * Perform any container cleanup that may be required.
 * @param ctx the {@link ContainerRuntimeContext}
 * @throws ContainerExecutionException if an error occurs while reapingthe container
 */
  void reapContainer(  ContainerRuntimeContext ctx) throws ContainerExecutionException ;
  /** 
 * Return the host and ip of the container
 * @param container the {@link Container}
 * @throws ContainerExecutionException if an error occurs while getting the ipand hostname
 */
  String[] getIpAndHost(  Container container) throws ContainerExecutionException ;
}
