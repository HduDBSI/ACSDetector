/** 
 * Class compares Resource by memory then cpu in reverse order
 */
static class ResourceReverseMemoryThenCpuComparator implements Comparator<Resource>, Serializable {
  static final long serialVersionUID=12345L;
  @Override public int compare(  Resource arg0,  Resource arg1){
    long mem0=arg0.getMemorySize();
    long mem1=arg1.getMemorySize();
    long cpu0=arg0.getVirtualCores();
    long cpu1=arg1.getVirtualCores();
    if (mem0 == mem1) {
      if (cpu0 == cpu1) {
        return 0;
      }
      if (cpu0 < cpu1) {
        return 1;
      }
      return -1;
    }
    if (mem0 < mem1) {
      return 1;
    }
    return -1;
  }
}
