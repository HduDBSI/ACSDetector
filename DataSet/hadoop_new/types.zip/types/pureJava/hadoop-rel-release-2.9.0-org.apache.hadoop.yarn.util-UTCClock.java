/** 
 * Implementation of  {@link Clock} that gives the current UTC time inmilliseconds.
 */
@Public @Evolving public class UTCClock implements Clock {
  private final TimeZone utcZone=TimeZone.getTimeZone("UTC");
  public long getTime(){
    return Calendar.getInstance(utcZone).getTimeInMillis();
  }
}
