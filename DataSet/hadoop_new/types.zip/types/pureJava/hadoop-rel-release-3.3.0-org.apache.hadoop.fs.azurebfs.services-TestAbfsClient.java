/** 
 * Test useragent of abfs client.
 */
public final class TestAbfsClient {
  private static final String ACCOUNT_NAME="bogusAccountName.dfs.core.windows.net";
  private static final String FS_AZURE_USER_AGENT_PREFIX="Partner Service";
  private final Pattern userAgentStringPattern;
  public TestAbfsClient(){
    StringBuilder regEx=new StringBuilder();
    regEx.append("^");
    regEx.append(APN_VERSION);
    regEx.append(SINGLE_WHITE_SPACE);
    regEx.append(CLIENT_VERSION);
    regEx.append(SINGLE_WHITE_SPACE);
    regEx.append("\\(");
    regEx.append(System.getProperty(JAVA_VENDOR).replaceAll(SINGLE_WHITE_SPACE,EMPTY_STRING));
    regEx.append(SINGLE_WHITE_SPACE);
    regEx.append("JavaJRE");
    regEx.append(SINGLE_WHITE_SPACE);
    regEx.append(System.getProperty(JAVA_VERSION));
    regEx.append(SEMICOLON);
    regEx.append(SINGLE_WHITE_SPACE);
    regEx.append(System.getProperty(OS_NAME).replaceAll(SINGLE_WHITE_SPACE,EMPTY_STRING));
    regEx.append(SINGLE_WHITE_SPACE);
    regEx.append(System.getProperty(OS_VERSION));
    regEx.append(FORWARD_SLASH);
    regEx.append(System.getProperty(OS_ARCH));
    regEx.append(SEMICOLON);
    regEx.append("([a-zA-Z].*; )?");
    regEx.append("([a-zA-Z].*; )?");
    regEx.append(" ?");
    regEx.append(".+");
    regEx.append(FORWARD_SLASH);
    regEx.append(".+");
    regEx.append("\\)");
    regEx.append("( .*)?");
    regEx.append("$");
    this.userAgentStringPattern=Pattern.compile(regEx.toString());
  }
  private String getUserAgentString(  AbfsConfiguration config,  boolean includeSSLProvider) throws MalformedURLException {
    AbfsClient client=new AbfsClient(new URL("https://azure.com"),null,config,null,(AccessTokenProvider)null,null);
    String sslProviderName=null;
    if (includeSSLProvider) {
      sslProviderName=DelegatingSSLSocketFactory.getDefaultFactory().getProviderName();
    }
    return client.initializeUserAgent(config,sslProviderName);
  }
  @Test public void verifybBasicInfo() throws Exception {
    final Configuration configuration=new Configuration();
    configuration.addResource(TEST_CONFIGURATION_FILE_NAME);
    AbfsConfiguration abfsConfiguration=new AbfsConfiguration(configuration,ACCOUNT_NAME);
    verifybBasicInfo(getUserAgentString(abfsConfiguration,false));
  }
  private void verifybBasicInfo(  String userAgentStr){
    assertThat(userAgentStr).describedAs("User-Agent string [" + userAgentStr + "] should be of the pattern: "+ this.userAgentStringPattern.pattern()).matches(this.userAgentStringPattern).describedAs("User-Agent string should contain java vendor").contains(System.getProperty(JAVA_VENDOR).replaceAll(SINGLE_WHITE_SPACE,EMPTY_STRING)).describedAs("User-Agent string should contain java version").contains(System.getProperty(JAVA_VERSION)).describedAs("User-Agent string should contain  OS name").contains(System.getProperty(OS_NAME).replaceAll(SINGLE_WHITE_SPACE,EMPTY_STRING)).describedAs("User-Agent string should contain OS version").contains(System.getProperty(OS_VERSION)).describedAs("User-Agent string should contain OS arch").contains(System.getProperty(OS_ARCH));
  }
  @Test public void verifyUserAgentPrefix() throws IOException, IllegalAccessException {
    final Configuration configuration=new Configuration();
    configuration.addResource(TEST_CONFIGURATION_FILE_NAME);
    configuration.set(ConfigurationKeys.FS_AZURE_USER_AGENT_PREFIX_KEY,FS_AZURE_USER_AGENT_PREFIX);
    AbfsConfiguration abfsConfiguration=new AbfsConfiguration(configuration,ACCOUNT_NAME);
    String userAgentStr=getUserAgentString(abfsConfiguration,false);
    verifybBasicInfo(userAgentStr);
    assertThat(userAgentStr).describedAs("User-Agent string should contain " + FS_AZURE_USER_AGENT_PREFIX).contains(FS_AZURE_USER_AGENT_PREFIX);
    configuration.unset(ConfigurationKeys.FS_AZURE_USER_AGENT_PREFIX_KEY);
    abfsConfiguration=new AbfsConfiguration(configuration,ACCOUNT_NAME);
    userAgentStr=getUserAgentString(abfsConfiguration,false);
    verifybBasicInfo(userAgentStr);
    assertThat(userAgentStr).describedAs("User-Agent string should not contain " + FS_AZURE_USER_AGENT_PREFIX).doesNotContain(FS_AZURE_USER_AGENT_PREFIX);
  }
  @Test public void verifyUserAgentWithoutSSLProvider() throws Exception {
    final Configuration configuration=new Configuration();
    configuration.addResource(TEST_CONFIGURATION_FILE_NAME);
    configuration.set(ConfigurationKeys.FS_AZURE_SSL_CHANNEL_MODE_KEY,DelegatingSSLSocketFactory.SSLChannelMode.Default_JSSE.name());
    AbfsConfiguration abfsConfiguration=new AbfsConfiguration(configuration,ACCOUNT_NAME);
    String userAgentStr=getUserAgentString(abfsConfiguration,true);
    verifybBasicInfo(userAgentStr);
    assertThat(userAgentStr).describedAs("User-Agent string should contain sslProvider").contains(DelegatingSSLSocketFactory.getDefaultFactory().getProviderName());
    userAgentStr=getUserAgentString(abfsConfiguration,false);
    verifybBasicInfo(userAgentStr);
    assertThat(userAgentStr).describedAs("User-Agent string should not contain sslProvider").doesNotContain(DelegatingSSLSocketFactory.getDefaultFactory().getProviderName());
  }
  @Test public void verifyUserAgentClusterName() throws Exception {
    final String clusterName="testClusterName";
    final Configuration configuration=new Configuration();
    configuration.addResource(TEST_CONFIGURATION_FILE_NAME);
    configuration.set(FS_AZURE_CLUSTER_NAME,clusterName);
    AbfsConfiguration abfsConfiguration=new AbfsConfiguration(configuration,ACCOUNT_NAME);
    String userAgentStr=getUserAgentString(abfsConfiguration,false);
    verifybBasicInfo(userAgentStr);
    assertThat(userAgentStr).describedAs("User-Agent string should contain cluster name").contains(clusterName);
    configuration.unset(FS_AZURE_CLUSTER_NAME);
    abfsConfiguration=new AbfsConfiguration(configuration,ACCOUNT_NAME);
    userAgentStr=getUserAgentString(abfsConfiguration,false);
    verifybBasicInfo(userAgentStr);
    assertThat(userAgentStr).describedAs("User-Agent string should not contain cluster name").doesNotContain(clusterName).describedAs("User-Agent string should contain UNKNOWN as cluster name config is absent").contains(DEFAULT_VALUE_UNKNOWN);
  }
  @Test public void verifyUserAgentClusterType() throws Exception {
    final String clusterType="testClusterType";
    final Configuration configuration=new Configuration();
    configuration.addResource(TEST_CONFIGURATION_FILE_NAME);
    configuration.set(FS_AZURE_CLUSTER_TYPE,clusterType);
    AbfsConfiguration abfsConfiguration=new AbfsConfiguration(configuration,ACCOUNT_NAME);
    String userAgentStr=getUserAgentString(abfsConfiguration,false);
    verifybBasicInfo(userAgentStr);
    assertThat(userAgentStr).describedAs("User-Agent string should contain cluster type").contains(clusterType);
    configuration.unset(FS_AZURE_CLUSTER_TYPE);
    abfsConfiguration=new AbfsConfiguration(configuration,ACCOUNT_NAME);
    userAgentStr=getUserAgentString(abfsConfiguration,false);
    verifybBasicInfo(userAgentStr);
    assertThat(userAgentStr).describedAs("User-Agent string should not contain cluster type").doesNotContain(clusterType).describedAs("User-Agent string should contain UNKNOWN as cluster type config is absent").contains(DEFAULT_VALUE_UNKNOWN);
  }
}
