public class TestNodeManagerMetrics {
  static final int GiB=1024;
  private NodeManagerMetrics metrics;
  @Before public void setup(){
    DefaultMetricsSystem.initialize("NodeManager");
    metrics=NodeManagerMetrics.create();
  }
  @After public void tearDown(){
    DefaultMetricsSystem.shutdown();
  }
  @Test public void testReferenceOfSingletonJvmMetrics(){
    JvmMetrics jvmMetrics=JvmMetrics.initSingleton("NodeManagerModule",null);
    Assert.assertEquals("NodeManagerMetrics should reference the singleton" + " JvmMetrics instance",jvmMetrics,metrics.getJvmMetrics());
  }
  @Test public void testNames(){
    Resource total=Records.newRecord(Resource.class);
    total.setMemorySize(8 * GiB);
    total.setVirtualCores(16);
    Resource resource=Records.newRecord(Resource.class);
    resource.setMemorySize(512);
    resource.setVirtualCores(2);
    Resource largerResource=Records.newRecord(Resource.class);
    largerResource.setMemorySize(1024);
    largerResource.setVirtualCores(2);
    Resource smallerResource=Records.newRecord(Resource.class);
    smallerResource.setMemorySize(256);
    smallerResource.setVirtualCores(1);
    metrics.addResource(total);
    for (int i=10; i-- > 0; ) {
      metrics.launchedContainer();
      metrics.allocateContainer(resource);
    }
    metrics.initingContainer();
    metrics.endInitingContainer();
    metrics.runningContainer();
    metrics.endRunningContainer();
    metrics.completedContainer();
    metrics.releaseContainer(resource);
    metrics.failedContainer();
    metrics.releaseContainer(resource);
    metrics.killedContainer();
    metrics.releaseContainer(resource);
    metrics.initingContainer();
    metrics.runningContainer();
    metrics.changeContainer(resource,largerResource);
    metrics.changeContainer(resource,smallerResource);
    Assert.assertTrue(!metrics.containerLaunchDuration.changed());
    metrics.addContainerLaunchDuration(1);
    Assert.assertTrue(metrics.containerLaunchDuration.changed());
    checkMetrics(10,1,1,1,1,1,4,7,4,13,3);
    metrics.addResource(total);
    MetricsRecordBuilder rb=getMetrics("NodeManagerMetrics");
    assertGauge("AvailableGB",12,rb);
    assertGauge("AvailableVCores",19,rb);
  }
  public static void checkMetrics(  int launched,  int completed,  int failed,  int killed,  int initing,  int running,  int allocatedGB,  int allocatedContainers,  int availableGB,  int allocatedVCores,  int availableVCores){
    MetricsRecordBuilder rb=getMetrics("NodeManagerMetrics");
    assertCounter("ContainersLaunched",launched,rb);
    assertCounter("ContainersCompleted",completed,rb);
    assertCounter("ContainersFailed",failed,rb);
    assertCounter("ContainersKilled",killed,rb);
    assertGauge("ContainersIniting",initing,rb);
    assertGauge("ContainersRunning",running,rb);
    assertGauge("AllocatedGB",allocatedGB,rb);
    assertGauge("AllocatedVCores",allocatedVCores,rb);
    assertGauge("AllocatedContainers",allocatedContainers,rb);
    assertGauge("AvailableGB",availableGB,rb);
    assertGauge("AvailableVCores",availableVCores,rb);
  }
}
