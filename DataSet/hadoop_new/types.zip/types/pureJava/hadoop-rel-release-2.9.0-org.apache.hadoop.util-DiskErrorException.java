public static class DiskErrorException extends IOException {
  public DiskErrorException(  String msg){
    super(msg);
  }
  public DiskErrorException(  String msg,  Throwable cause){
    super(msg,cause);
  }
}
