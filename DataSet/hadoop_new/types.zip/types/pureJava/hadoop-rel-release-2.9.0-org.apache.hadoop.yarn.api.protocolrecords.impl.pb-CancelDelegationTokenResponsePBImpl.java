@Private @Unstable public class CancelDelegationTokenResponsePBImpl extends CancelDelegationTokenResponse {
  CancelDelegationTokenResponseProto proto=CancelDelegationTokenResponseProto.getDefaultInstance();
  public CancelDelegationTokenResponsePBImpl(){
  }
  public CancelDelegationTokenResponsePBImpl(  CancelDelegationTokenResponseProto proto){
    this.proto=proto;
  }
  public CancelDelegationTokenResponseProto getProto(){
    return proto;
  }
  @Override public int hashCode(){
    return getProto().hashCode();
  }
  @Override public boolean equals(  Object other){
    if (other == null)     return false;
    if (other.getClass().isAssignableFrom(this.getClass())) {
      return this.getProto().equals(this.getClass().cast(other).getProto());
    }
    return false;
  }
  @Override public String toString(){
    return TextFormat.shortDebugString(getProto());
  }
}
