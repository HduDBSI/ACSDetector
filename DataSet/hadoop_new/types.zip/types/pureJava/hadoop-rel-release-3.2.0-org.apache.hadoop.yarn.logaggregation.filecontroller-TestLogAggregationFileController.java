private static class TestLogAggregationFileController extends LogAggregationFileController {
  @Override public void initInternal(  Configuration conf){
    String remoteDirStr=String.format(YarnConfiguration.LOG_AGGREGATION_REMOTE_APP_LOG_DIR_FMT,this.fileControllerName);
    this.remoteRootLogDir=new Path(conf.get(remoteDirStr));
    String suffix=String.format(YarnConfiguration.LOG_AGGREGATION_REMOTE_APP_LOG_DIR_SUFFIX_FMT,this.fileControllerName);
    this.remoteRootLogDirSuffix=conf.get(suffix);
  }
  @Override public void closeWriter(){
  }
  @Override public void write(  LogKey logKey,  LogValue logValue) throws IOException {
  }
  @Override public void postWrite(  LogAggregationFileControllerContext record) throws Exception {
  }
  @Override public void initializeWriter(  LogAggregationFileControllerContext context) throws IOException {
  }
  @Override public boolean readAggregatedLogs(  ContainerLogsRequest logRequest,  OutputStream os) throws IOException {
    return false;
  }
  @Override public List<ContainerLogMeta> readAggregatedLogsMeta(  ContainerLogsRequest logRequest) throws IOException {
    return null;
  }
  @Override public void renderAggregatedLogsBlock(  Block html,  ViewContext context){
  }
  @Override public String getApplicationOwner(  Path aggregatedLogPath,  ApplicationId appId) throws IOException {
    return null;
  }
  @Override public Map<ApplicationAccessType,String> getApplicationAcls(  Path aggregatedLogPath,  ApplicationId appId) throws IOException {
    return null;
  }
}
