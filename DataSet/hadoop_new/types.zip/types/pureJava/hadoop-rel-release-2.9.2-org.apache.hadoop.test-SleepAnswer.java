/** 
 * An Answer implementation which sleeps for a random number of milliseconds between 0 and a configurable value before delegating to the real implementation of the method. This can be useful for drawing out race conditions.
 */
public static class SleepAnswer implements Answer<Object> {
  private final int minSleepTime;
  private final int maxSleepTime;
  private static Random r=new Random();
  public SleepAnswer(  int maxSleepTime){
    this(0,maxSleepTime);
  }
  public SleepAnswer(  int minSleepTime,  int maxSleepTime){
    this.minSleepTime=minSleepTime;
    this.maxSleepTime=maxSleepTime;
  }
  @Override public Object answer(  InvocationOnMock invocation) throws Throwable {
    boolean interrupted=false;
    try {
      Thread.sleep(r.nextInt(maxSleepTime) + minSleepTime);
    }
 catch (    InterruptedException ie) {
      interrupted=true;
    }
    try {
      return invocation.callRealMethod();
    }
  finally {
      if (interrupted) {
        Thread.currentThread().interrupt();
      }
    }
  }
}
