/** 
 * A RemoteIterator that fetches elements in batches.
 */
public abstract class BatchedRemoteIterator<K,E> implements RemoteIterator<E> {
public interface BatchedEntries<E> {
    public E get(    int i);
    public int size();
    public boolean hasMore();
  }
public static class BatchedListEntries<E> implements BatchedEntries<E> {
    private final List<E> entries;
    private final boolean hasMore;
    public BatchedListEntries(    List<E> entries,    boolean hasMore){
      this.entries=entries;
      this.hasMore=hasMore;
    }
    public E get(    int i){
      return entries.get(i);
    }
    public int size(){
      return entries.size();
    }
    public boolean hasMore(){
      return hasMore;
    }
  }
  private K prevKey;
  private BatchedEntries<E> entries;
  private int idx;
  public BatchedRemoteIterator(  K prevKey){
    this.prevKey=prevKey;
    this.entries=null;
    this.idx=-1;
  }
  /** 
 * Perform the actual remote request.
 * @param prevKey The key to send.
 * @return A list of replies.
 */
  public abstract BatchedEntries<E> makeRequest(  K prevKey) throws IOException ;
  private void makeRequest() throws IOException {
    idx=0;
    entries=null;
    entries=makeRequest(prevKey);
    if (entries.size() == 0) {
      entries=null;
    }
  }
  private void makeRequestIfNeeded() throws IOException {
    if (idx == -1) {
      makeRequest();
    }
 else     if ((entries != null) && (idx >= entries.size())) {
      if (!entries.hasMore()) {
        entries=null;
      }
 else {
        makeRequest();
      }
    }
  }
  @Override public boolean hasNext() throws IOException {
    makeRequestIfNeeded();
    return (entries != null);
  }
  /** 
 * Return the next list key associated with an element.
 */
  public abstract K elementToPrevKey(  E element);
  @Override public E next() throws IOException {
    makeRequestIfNeeded();
    if (entries == null) {
      throw new NoSuchElementException();
    }
    E entry=entries.get(idx++);
    prevKey=elementToPrevKey(entry);
    return entry;
  }
}
