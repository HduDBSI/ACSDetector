@SuppressWarnings("serial") static class TraverseAccessControlException extends AccessControlException {
  TraverseAccessControlException(  IOException ioe){
    super(ioe);
  }
  public void throwCause() throws UnresolvedPathException, ParentNotDirectoryException, AccessControlException {
    Throwable ioe=getCause();
    if (ioe instanceof UnresolvedPathException) {
      throw (UnresolvedPathException)ioe;
    }
    if (ioe instanceof ParentNotDirectoryException) {
      throw (ParentNotDirectoryException)ioe;
    }
    throw this;
  }
}
