@Private @Unstable public class RenewDelegationTokenResponsePBImpl extends RenewDelegationTokenResponse {
  RenewDelegationTokenResponseProto proto=RenewDelegationTokenResponseProto.getDefaultInstance();
  RenewDelegationTokenResponseProto.Builder builder=null;
  boolean viaProto=false;
  public RenewDelegationTokenResponsePBImpl(){
    this.builder=RenewDelegationTokenResponseProto.newBuilder();
  }
  public RenewDelegationTokenResponsePBImpl(  RenewDelegationTokenResponseProto proto){
    this.proto=proto;
    this.viaProto=true;
  }
  public RenewDelegationTokenResponseProto getProto(){
    proto=viaProto ? proto : builder.build();
    viaProto=true;
    return proto;
  }
  @Override public int hashCode(){
    return getProto().hashCode();
  }
  @Override public boolean equals(  Object other){
    if (other == null)     return false;
    if (other.getClass().isAssignableFrom(this.getClass())) {
      return this.getProto().equals(this.getClass().cast(other).getProto());
    }
    return false;
  }
  @Override public String toString(){
    return TextFormat.shortDebugString(getProto());
  }
  private void maybeInitBuilder(){
    if (viaProto || builder == null) {
      builder=RenewDelegationTokenResponseProto.newBuilder(proto);
    }
    viaProto=false;
  }
  @Override public long getNextExpirationTime(){
    RenewDelegationTokenResponseProtoOrBuilder p=viaProto ? proto : builder;
    return p.getNewExpiryTime();
  }
  @Override public void setNextExpirationTime(  long expTime){
    maybeInitBuilder();
    builder.setNewExpiryTime(expTime);
  }
}
