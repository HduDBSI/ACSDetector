class TestZKRMStateStoreTester implements RMStateStoreHelper {
  TestZKRMStateStoreInternal store;
  String workingZnode;
class TestZKRMStateStoreInternal extends ZKRMStateStore {
    public TestZKRMStateStoreInternal(    Configuration conf,    String workingZnode) throws Exception {
      setResourceManager(new ResourceManager());
      init(conf);
      start();
      assertTrue(znodeWorkingPath.equals(workingZnode));
    }
    public String getVersionNode(){
      return znodeWorkingPath + "/" + ROOT_ZNODE_NAME+ "/"+ VERSION_NODE;
    }
    public Version getCurrentVersion(){
      return CURRENT_VERSION_INFO;
    }
    public String getAppNode(    String appId){
      return workingZnode + "/" + ROOT_ZNODE_NAME+ "/"+ RM_APP_ROOT+ "/"+ appId;
    }
    /** 
 * Emulating retrying createRootDir not to raise NodeExist exception
 * @throws Exception
 */
    public void testRetryingCreateRootDir() throws Exception {
      create(znodeWorkingPath);
    }
  }
  public RMStateStore getRMStateStore() throws Exception {
    YarnConfiguration conf=new YarnConfiguration();
    workingZnode="/jira/issue/3077/rmstore";
    conf.set(YarnConfiguration.RM_ZK_ADDRESS,curatorTestingServer.getConnectString());
    conf.set(YarnConfiguration.ZK_RM_STATE_STORE_PARENT_PATH,workingZnode);
    this.store=new TestZKRMStateStoreInternal(conf,workingZnode);
    return this.store;
  }
  @Override public boolean isFinalStateValid() throws Exception {
    return 1 == curatorFramework.getChildren().forPath(store.znodeWorkingPath).size();
  }
  @Override public void writeVersion(  Version version) throws Exception {
    curatorFramework.setData().withVersion(-1).forPath(store.getVersionNode(),((VersionPBImpl)version).getProto().toByteArray());
  }
  @Override public Version getCurrentVersion() throws Exception {
    return store.getCurrentVersion();
  }
  public boolean appExists(  RMApp app) throws Exception {
    return null != curatorFramework.checkExists().forPath(store.getAppNode(app.getApplicationId().toString()));
  }
}
