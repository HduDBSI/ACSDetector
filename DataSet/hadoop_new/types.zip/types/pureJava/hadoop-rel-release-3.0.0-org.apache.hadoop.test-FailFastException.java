/** 
 * An exception which triggers a fast exist from the {@link #eventually(int,Callable,Callable)} and{@link #await(int,Callable,Callable,TimeoutHandler)} loops.
 */
public static class FailFastException extends Exception {
  public FailFastException(  String detailMessage){
    super(detailMessage);
  }
  public FailFastException(  String message,  Throwable cause){
    super(message,cause);
  }
  /** 
 * Instantiate from a format string.
 * @param format format string
 * @param args arguments to format
 * @return an instance with the message string constructed.
 */
  public static FailFastException newInstance(  String format,  Object... args){
    return new FailFastException(String.format(format,args));
  }
}
