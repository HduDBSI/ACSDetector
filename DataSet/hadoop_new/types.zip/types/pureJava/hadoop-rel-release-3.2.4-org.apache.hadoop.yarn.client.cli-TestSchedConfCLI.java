/** 
 * Class for testing  {@link SchedConfCLI}.
 */
public class TestSchedConfCLI extends JerseyTestBase {
  private SchedConfCLI cli;
  private static MockRM rm;
  private static String userName;
  private static final File CONF_FILE=new File(new File("target","test-classes"),YarnConfiguration.CS_CONFIGURATION_FILE);
  private static final File OLD_CONF_FILE=new File(new File("target","test-classes"),YarnConfiguration.CS_CONFIGURATION_FILE + ".tmp");
  public TestSchedConfCLI(){
    super(new WebAppDescriptor.Builder("org.apache.hadoop.yarn.server.resourcemanager.webapp").contextListenerClass(GuiceServletConfig.class).filterClass(com.google.inject.servlet.GuiceFilter.class).contextPath("jersey-guice-filter").servletPath("/").build());
  }
  @Before public void setUp(){
    cli=new SchedConfCLI();
  }
private static class WebServletModule extends ServletModule {
    @Override protected void configureServlets(){
      bind(JAXBContextResolver.class);
      bind(RMWebServices.class);
      bind(GenericExceptionHandler.class);
      Configuration conf=new YarnConfiguration();
      conf.setClass(YarnConfiguration.RM_SCHEDULER,CapacityScheduler.class,ResourceScheduler.class);
      conf.set(YarnConfiguration.SCHEDULER_CONFIGURATION_STORE_CLASS,YarnConfiguration.MEMORY_CONFIGURATION_STORE);
      try {
        userName=UserGroupInformation.getCurrentUser().getShortUserName();
      }
 catch (      IOException ioe) {
        throw new RuntimeException("Unable to get current user name " + ioe.getMessage(),ioe);
      }
      CapacitySchedulerConfiguration csConf=new CapacitySchedulerConfiguration(new Configuration(false),false);
      setupQueueConfiguration(csConf);
      try {
        if (CONF_FILE.exists()) {
          if (!CONF_FILE.renameTo(OLD_CONF_FILE)) {
            throw new RuntimeException("Failed to rename conf file");
          }
        }
        FileOutputStream out=new FileOutputStream(CONF_FILE);
        csConf.writeXml(out);
        out.close();
      }
 catch (      IOException e) {
        throw new RuntimeException("Failed to write XML file",e);
      }
      rm=new MockRM(conf);
      bind(ResourceManager.class).toInstance(rm);
      serve("/*").with(GuiceContainer.class);
      filter("/*").through(TestRMCustomAuthFilter.class);
    }
  }
  /** 
 * Custom filter which sets the Remote User for testing purpose.
 */
@Singleton public static class TestRMCustomAuthFilter extends AuthenticationFilter {
    @Override public void init(    FilterConfig filterConfig){
    }
    @Override public void doFilter(    ServletRequest request,    ServletResponse response,    FilterChain filterChain) throws IOException, ServletException {
      HttpServletRequest httpRequest=(HttpServletRequest)request;
      HttpServletResponse httpResponse=(HttpServletResponse)response;
      httpRequest=new HttpServletRequestWrapper(httpRequest){
        public String getAuthType(){
          return null;
        }
        public String getRemoteUser(){
          return userName;
        }
        public Principal getUserPrincipal(){
          return new Principal(){
            @Override public String getName(){
              return userName;
            }
          }
;
        }
      }
;
      doFilter(filterChain,httpRequest,httpResponse);
    }
  }
  private static void setupQueueConfiguration(  CapacitySchedulerConfiguration config){
    config.setQueues(CapacitySchedulerConfiguration.ROOT,new String[]{"testqueue"});
    String a=CapacitySchedulerConfiguration.ROOT + ".testqueue";
    config.setCapacity(a,100f);
    config.setMaximumCapacity(a,100f);
  }
  @Test(timeout=10000) public void testFormatSchedulerConf() throws Exception {
    try {
      super.setUp();
      GuiceServletConfig.setInjector(Guice.createInjector(new WebServletModule()));
      ResourceScheduler scheduler=rm.getResourceScheduler();
      MutableConfigurationProvider provider=((MutableConfScheduler)scheduler).getMutableConfProvider();
      SchedConfUpdateInfo schedUpdateInfo=new SchedConfUpdateInfo();
      HashMap<String,String> globalUpdates=new HashMap<>();
      globalUpdates.put("schedKey1","schedVal1");
      schedUpdateInfo.setGlobalParams(globalUpdates);
      provider.logAndApplyMutation(UserGroupInformation.getCurrentUser(),schedUpdateInfo);
      rm.getRMContext().getRMAdminService().refreshQueues();
      provider.confirmPendingMutation(true);
      Configuration schedulerConf=provider.getConfiguration();
      assertEquals("schedVal1",schedulerConf.get("schedKey1"));
      int exitCode=cli.formatSchedulerConf("",resource());
      assertEquals(0,exitCode);
      schedulerConf=provider.getConfiguration();
      assertNull(schedulerConf.get("schedKey1"));
    }
  finally {
      if (rm != null) {
        rm.stop();
      }
      CONF_FILE.delete();
      if (OLD_CONF_FILE.exists()) {
        if (!OLD_CONF_FILE.renameTo(CONF_FILE)) {
          throw new RuntimeException("Failed to re-copy old" + " configuration file");
        }
      }
      super.tearDown();
    }
  }
  @Test(timeout=10000) public void testInvalidConf() throws Exception {
    ByteArrayOutputStream sysErrStream=new ByteArrayOutputStream();
    PrintStream sysErr=new PrintStream(sysErrStream);
    System.setErr(sysErr);
    executeCommand(sysErrStream,"-add","root.a:=confVal");
    executeCommand(sysErrStream,"-update","root.a:=confVal");
    executeCommand(sysErrStream,"-add","root.a:confKey=confVal=conf");
    executeCommand(sysErrStream,"-update","root.a:confKey=confVal=c");
  }
  private void executeCommand(  ByteArrayOutputStream sysErrStream,  String op,  String queueConf) throws Exception {
    int exitCode=cli.run(new String[]{op,queueConf});
    assertNotEquals("Should return an error code",0,exitCode);
    assertTrue(sysErrStream.toString().contains("Specify configuration key " + "value as confKey=confVal."));
  }
  @Test(timeout=10000) public void testAddQueues(){
    SchedConfUpdateInfo schedUpdateInfo=new SchedConfUpdateInfo();
    cli.addQueues("root.a:a1=aVal1,a2=aVal2,a3=",schedUpdateInfo);
    Map<String,String> paramValues=new HashMap<>();
    List<QueueConfigInfo> addQueueInfo=schedUpdateInfo.getAddQueueInfo();
    paramValues.put("a1","aVal1");
    paramValues.put("a2","aVal2");
    paramValues.put("a3",null);
    validateQueueConfigInfo(addQueueInfo,0,"root.a",paramValues);
    schedUpdateInfo=new SchedConfUpdateInfo();
    cli.addQueues("root.b:b1=bVal1;root.c:c1=cVal1",schedUpdateInfo);
    addQueueInfo=schedUpdateInfo.getAddQueueInfo();
    assertEquals(2,addQueueInfo.size());
    paramValues.clear();
    paramValues.put("b1","bVal1");
    validateQueueConfigInfo(addQueueInfo,0,"root.b",paramValues);
    paramValues.clear();
    paramValues.put("c1","cVal1");
    validateQueueConfigInfo(addQueueInfo,1,"root.c",paramValues);
  }
  @Test(timeout=10000) public void testRemoveQueues(){
    SchedConfUpdateInfo schedUpdateInfo=new SchedConfUpdateInfo();
    cli.removeQueues("root.a;root.b;root.c.c1",schedUpdateInfo);
    List<String> removeInfo=schedUpdateInfo.getRemoveQueueInfo();
    assertEquals(3,removeInfo.size());
    assertEquals("root.a",removeInfo.get(0));
    assertEquals("root.b",removeInfo.get(1));
    assertEquals("root.c.c1",removeInfo.get(2));
  }
  @Test(timeout=10000) public void testUpdateQueues(){
    SchedConfUpdateInfo schedUpdateInfo=new SchedConfUpdateInfo();
    Map<String,String> paramValues=new HashMap<>();
    cli.updateQueues("root.a:a1=aVal1,a2=aVal2,a3=",schedUpdateInfo);
    List<QueueConfigInfo> updateQueueInfo=schedUpdateInfo.getUpdateQueueInfo();
    paramValues.put("a1","aVal1");
    paramValues.put("a2","aVal2");
    paramValues.put("a3",null);
    validateQueueConfigInfo(updateQueueInfo,0,"root.a",paramValues);
    schedUpdateInfo=new SchedConfUpdateInfo();
    cli.updateQueues("root.b:b1=bVal1;root.c:c1=cVal1",schedUpdateInfo);
    updateQueueInfo=schedUpdateInfo.getUpdateQueueInfo();
    assertEquals(2,updateQueueInfo.size());
    paramValues.clear();
    paramValues.put("b1","bVal1");
    validateQueueConfigInfo(updateQueueInfo,0,"root.b",paramValues);
    paramValues.clear();
    paramValues.put("c1","cVal1");
    validateQueueConfigInfo(updateQueueInfo,1,"root.c",paramValues);
  }
  private void validateQueueConfigInfo(  List<QueueConfigInfo> updateQueueInfo,  int index,  String queuename,  Map<String,String> paramValues){
    QueueConfigInfo updateInfo=updateQueueInfo.get(index);
    assertEquals(queuename,updateInfo.getQueue());
    Map<String,String> params=updateInfo.getParams();
    assertEquals(paramValues.size(),params.size());
    paramValues.forEach((k,v) -> assertEquals(v,params.get(k)));
  }
  @Test(timeout=10000) public void testGlobalUpdate(){
    SchedConfUpdateInfo schedUpdateInfo=new SchedConfUpdateInfo();
    cli.globalUpdates("schedKey1=schedVal1,schedKey2=schedVal2",schedUpdateInfo);
    Map<String,String> paramValues=new HashMap<>();
    paramValues.put("schedKey1","schedVal1");
    paramValues.put("schedKey2","schedVal2");
    validateGlobalParams(schedUpdateInfo,paramValues);
  }
  private void validateGlobalParams(  SchedConfUpdateInfo schedUpdateInfo,  Map<String,String> paramValues){
    Map<String,String> globalInfo=schedUpdateInfo.getGlobalParams();
    assertEquals(paramValues.size(),globalInfo.size());
    paramValues.forEach((k,v) -> assertEquals(v,globalInfo.get(k)));
  }
}
