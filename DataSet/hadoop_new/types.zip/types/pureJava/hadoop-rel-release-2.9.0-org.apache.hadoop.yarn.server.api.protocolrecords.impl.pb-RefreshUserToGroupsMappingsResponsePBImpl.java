@Private @Unstable public class RefreshUserToGroupsMappingsResponsePBImpl extends RefreshUserToGroupsMappingsResponse {
  RefreshUserToGroupsMappingsResponseProto proto=RefreshUserToGroupsMappingsResponseProto.getDefaultInstance();
  RefreshUserToGroupsMappingsResponseProto.Builder builder=null;
  boolean viaProto=false;
  public RefreshUserToGroupsMappingsResponsePBImpl(){
    builder=RefreshUserToGroupsMappingsResponseProto.newBuilder();
  }
  public RefreshUserToGroupsMappingsResponsePBImpl(  RefreshUserToGroupsMappingsResponseProto proto){
    this.proto=proto;
    viaProto=true;
  }
  public RefreshUserToGroupsMappingsResponseProto getProto(){
    proto=viaProto ? proto : builder.build();
    viaProto=true;
    return proto;
  }
  @Override public int hashCode(){
    return getProto().hashCode();
  }
  @Override public boolean equals(  Object other){
    if (other == null)     return false;
    if (other.getClass().isAssignableFrom(this.getClass())) {
      return this.getProto().equals(this.getClass().cast(other).getProto());
    }
    return false;
  }
  @Override public String toString(){
    return TextFormat.shortDebugString(getProto());
  }
}
