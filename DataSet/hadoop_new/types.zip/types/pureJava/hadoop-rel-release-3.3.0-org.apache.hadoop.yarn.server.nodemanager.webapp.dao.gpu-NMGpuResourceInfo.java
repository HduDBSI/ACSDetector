/** 
 * Gpu device information return to client when {@link org.apache.hadoop.yarn.server.nodemanager.webapp.NMWebServices#getNMResourceInfo(String)}is invoked.
 */
public class NMGpuResourceInfo extends NMResourceInfo {
  GpuDeviceInformation gpuDeviceInformation;
  List<GpuDevice> totalGpuDevices;
  List<AssignedGpuDevice> assignedGpuDevices;
  public NMGpuResourceInfo(  GpuDeviceInformation gpuDeviceInformation,  List<GpuDevice> totalGpuDevices,  List<AssignedGpuDevice> assignedGpuDevices){
    this.gpuDeviceInformation=gpuDeviceInformation;
    this.totalGpuDevices=totalGpuDevices;
    this.assignedGpuDevices=assignedGpuDevices;
  }
  public GpuDeviceInformation getGpuDeviceInformation(){
    return gpuDeviceInformation;
  }
  public void setGpuDeviceInformation(  GpuDeviceInformation gpuDeviceInformation){
    this.gpuDeviceInformation=gpuDeviceInformation;
  }
  public List<GpuDevice> getTotalGpuDevices(){
    return totalGpuDevices;
  }
  public void setTotalGpuDevices(  List<GpuDevice> totalGpuDevices){
    this.totalGpuDevices=totalGpuDevices;
  }
  public List<AssignedGpuDevice> getAssignedGpuDevices(){
    return assignedGpuDevices;
  }
  public void setAssignedGpuDevices(  List<AssignedGpuDevice> assignedGpuDevices){
    this.assignedGpuDevices=assignedGpuDevices;
  }
}
