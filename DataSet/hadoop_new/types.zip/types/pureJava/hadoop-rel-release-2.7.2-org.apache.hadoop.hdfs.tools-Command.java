interface Command {
  String getName();
  String getShortUsage();
  String getLongUsage();
  int run(  Configuration conf,  List<String> args) throws IOException ;
}
