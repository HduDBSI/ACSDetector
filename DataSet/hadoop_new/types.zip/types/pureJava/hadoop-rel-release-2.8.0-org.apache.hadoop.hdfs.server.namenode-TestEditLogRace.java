/** 
 * This class tests various synchronization bugs in FSEditLog rolling and namespace saving.
 */
@RunWith(Parameterized.class) public class TestEditLogRace {
static {
    GenericTestUtils.setLogLevel(FSEditLog.LOG,Level.ALL);
  }
  @Parameters public static Collection<Object[]> data(){
    Collection<Object[]> params=new ArrayList<Object[]>();
    params.add(new Object[]{false});
    params.add(new Object[]{true});
    return params;
  }
  private static boolean useAsyncEditLog;
  public TestEditLogRace(  boolean useAsyncEditLog){
    TestEditLogRace.useAsyncEditLog=useAsyncEditLog;
  }
  private static final Log LOG=LogFactory.getLog(TestEditLogRace.class);
  static final int NUM_THREADS=16;
  /** 
 * The number of times to roll the edit log during the test. Since this tests for a race condition, higher numbers are more likely to find a bug if it exists, but the test will take longer.
 */
  static final int NUM_ROLLS=30;
  /** 
 * The number of times to save the fsimage and create an empty edit log.
 */
  static final int NUM_SAVE_IMAGE=30;
  private final List<Transactions> workers=new ArrayList<Transactions>();
  private static final int NUM_DATA_NODES=1;
  /** 
 * Several of the test cases work by introducing a sleep into an operation that is usually fast, and then verifying that another operation blocks for at least this amount of time. This value needs to be significantly longer than the average time for an fsync() or enterSafeMode().
 */
  private static final int BLOCK_TIME=4;
static class Transactions implements Runnable {
    final NamenodeProtocols nn;
    final MiniDFSCluster cluster;
    FileSystem fs;
    short replication=3;
    long blockSize=64;
    volatile boolean stopped=false;
    volatile Thread thr;
    final AtomicReference<Throwable> caught;
    Transactions(    MiniDFSCluster cluster,    AtomicReference<Throwable> caught){
      this.cluster=cluster;
      this.nn=cluster.getNameNodeRpc();
      try {
        this.fs=cluster.getFileSystem();
      }
 catch (      IOException e) {
        caught.set(e);
      }
      this.caught=caught;
    }
    @Override public void run(){
      thr=Thread.currentThread();
      FsPermission p=new FsPermission((short)0777);
      int i=0;
      while (!stopped) {
        try {
          String dirname="/thr-" + thr.getId() + "-dir-"+ i;
          if (i % 2 == 0) {
            Path dirnamePath=new Path(dirname);
            fs.mkdirs(dirnamePath);
            fs.delete(dirnamePath,true);
          }
 else {
            nn.mkdirs(dirname,p,true);
            nn.delete(dirname,true);
          }
        }
 catch (        SafeModeException sme) {
        }
catch (        Throwable e) {
          if (e instanceof RemoteException && ((RemoteException)e).getClassName().contains("SafeModeException")) {
            return;
          }
          LOG.warn("Got error in transaction thread",e);
          caught.compareAndSet(null,e);
          break;
        }
        i++;
      }
    }
    public void stop(){
      stopped=true;
    }
    public Thread getThread(){
      return thr;
    }
  }
  private void startTransactionWorkers(  MiniDFSCluster cluster,  AtomicReference<Throwable> caughtErr){
    for (int i=0; i < NUM_THREADS; i++) {
      Transactions trans=new Transactions(cluster,caughtErr);
      new Thread(trans,"TransactionThread-" + i).start();
      workers.add(trans);
    }
  }
  private void stopTransactionWorkers(){
    for (    Transactions worker : workers) {
      worker.stop();
    }
    for (    Transactions worker : workers) {
      Thread thr=worker.getThread();
      try {
        if (thr != null)         thr.join();
      }
 catch (      InterruptedException ignored) {
      }
    }
  }
  /** 
 * Tests rolling edit logs while transactions are ongoing.
 */
  @Test public void testEditLogRolling() throws Exception {
    Configuration conf=getConf();
    final MiniDFSCluster cluster=new MiniDFSCluster.Builder(conf).numDataNodes(NUM_DATA_NODES).build();
    FileSystem fileSys=null;
    AtomicReference<Throwable> caughtErr=new AtomicReference<Throwable>();
    try {
      cluster.waitActive();
      fileSys=cluster.getFileSystem();
      final NamenodeProtocols nn=cluster.getNameNode().getRpcServer();
      FSImage fsimage=cluster.getNamesystem().getFSImage();
      StorageDirectory sd=fsimage.getStorage().getStorageDir(0);
      startTransactionWorkers(cluster,caughtErr);
      long previousLogTxId=1;
      for (int i=0; i < NUM_ROLLS && caughtErr.get() == null; i++) {
        try {
          Thread.sleep(20);
        }
 catch (        InterruptedException e) {
        }
        LOG.info("Starting roll " + i + ".");
        CheckpointSignature sig=nn.rollEditLog();
        long nextLog=sig.curSegmentTxId;
        String logFileName=NNStorage.getFinalizedEditsFileName(previousLogTxId,nextLog - 1);
        previousLogTxId+=verifyEditLogs(cluster.getNamesystem(),fsimage,logFileName,previousLogTxId);
        assertEquals(previousLogTxId,nextLog);
        File expectedLog=NNStorage.getInProgressEditsFile(sd,previousLogTxId);
        assertTrue("Expect " + expectedLog + " to exist",expectedLog.exists());
      }
    }
  finally {
      stopTransactionWorkers();
      if (caughtErr.get() != null) {
        throw new RuntimeException(caughtErr.get());
      }
      if (fileSys != null)       fileSys.close();
      if (cluster != null)       cluster.shutdown();
    }
  }
  private long verifyEditLogs(  FSNamesystem namesystem,  FSImage fsimage,  String logFileName,  long startTxId) throws IOException {
    long numEdits=-1;
    for (    StorageDirectory sd : fsimage.getStorage().dirIterable(NameNodeDirType.EDITS)) {
      File editFile=new File(sd.getCurrentDir(),logFileName);
      System.out.println("Verifying file: " + editFile);
      FSEditLogLoader loader=new FSEditLogLoader(namesystem,startTxId);
      long numEditsThisLog=loader.loadFSEdits(new EditLogFileInputStream(editFile),startTxId);
      System.out.println("Number of edits: " + numEditsThisLog);
      assertTrue(numEdits == -1 || numEditsThisLog == numEdits);
      numEdits=numEditsThisLog;
    }
    assertTrue(numEdits != -1);
    return numEdits;
  }
  /** 
 * Tests saving fs image while transactions are ongoing.
 */
  @Test public void testSaveNamespace() throws Exception {
    Configuration conf=getConf();
    MiniDFSCluster cluster=null;
    FileSystem fileSys=null;
    AtomicReference<Throwable> caughtErr=new AtomicReference<Throwable>();
    try {
      cluster=new MiniDFSCluster.Builder(conf).numDataNodes(NUM_DATA_NODES).build();
      cluster.waitActive();
      fileSys=cluster.getFileSystem();
      final FSNamesystem namesystem=cluster.getNamesystem();
      FSImage fsimage=namesystem.getFSImage();
      FSEditLog editLog=fsimage.getEditLog();
      startTransactionWorkers(cluster,caughtErr);
      for (int i=0; i < NUM_SAVE_IMAGE && caughtErr.get() == null; i++) {
        try {
          Thread.sleep(20);
        }
 catch (        InterruptedException ignored) {
        }
        LOG.info("Save " + i + ": entering safe mode");
        namesystem.enterSafeMode(false);
        long logStartTxId=fsimage.getStorage().getMostRecentCheckpointTxId() + 1;
        verifyEditLogs(namesystem,fsimage,NNStorage.getInProgressEditsFileName(logStartTxId),logStartTxId);
        LOG.info("Save " + i + ": saving namespace");
        namesystem.saveNamespace();
        LOG.info("Save " + i + ": leaving safemode");
        long savedImageTxId=fsimage.getStorage().getMostRecentCheckpointTxId();
        verifyEditLogs(namesystem,fsimage,NNStorage.getFinalizedEditsFileName(logStartTxId,savedImageTxId),logStartTxId);
        assertEquals(fsimage.getStorage().getMostRecentCheckpointTxId(),editLog.getLastWrittenTxId() - 1);
        namesystem.leaveSafeMode();
        LOG.info("Save " + i + ": complete");
      }
    }
  finally {
      stopTransactionWorkers();
      if (caughtErr.get() != null) {
        throw new RuntimeException(caughtErr.get());
      }
      if (fileSys != null)       fileSys.close();
      if (cluster != null)       cluster.shutdown();
    }
  }
  private Configuration getConf(){
    Configuration conf=new HdfsConfiguration();
    conf.setBoolean(DFSConfigKeys.DFS_NAMENODE_EDITS_ASYNC_LOGGING,useAsyncEditLog);
    FileSystem.setDefaultUri(conf,"hdfs://localhost:0");
    conf.set(DFSConfigKeys.DFS_NAMENODE_HTTP_ADDRESS_KEY,"0.0.0.0:0");
    conf.setBoolean(DFSConfigKeys.DFS_PERMISSIONS_ENABLED_KEY,false);
    return conf;
  }
  /** 
 * The logSync() method in FSEditLog is unsynchronized whiel syncing so that other threads can concurrently enqueue edits while the prior sync is ongoing. This test checks that the log is saved correctly if the saveImage occurs while the syncing thread is in the unsynchronized middle section. This replicates the following manual test proposed by Konstantin: I start the name-node in debugger. I do -mkdir and stop the debugger in logSync() just before it does flush. Then I enter safe mode with another client I start saveNamepsace and stop the debugger in FSImage.saveFSImage() -> FSEditLog.createEditLogFile() -> EditLogFileOutputStream.create() -> after truncating the file but before writing LAYOUT_VERSION into it. Then I let logSync() run. Then I terminate the name-node. After that the name-node wont start, since the edits file is broken.
 */
  @Test public void testSaveImageWhileSyncInProgress() throws Exception {
    Configuration conf=getConf();
    NameNode.initMetrics(conf,NamenodeRole.NAMENODE);
    DFSTestUtil.formatNameNode(conf);
    final FSNamesystem namesystem=FSNamesystem.loadFromDisk(conf);
    try {
      FSImage fsimage=namesystem.getFSImage();
      FSEditLog editLog=fsimage.getEditLog();
      JournalAndStream jas=editLog.getJournals().get(0);
      EditLogFileOutputStream spyElos=spy((EditLogFileOutputStream)jas.getCurrentStream());
      jas.setCurrentStreamForTests(spyElos);
      final AtomicReference<Throwable> deferredException=new AtomicReference<Throwable>();
      final CountDownLatch waitToEnterFlush=new CountDownLatch(1);
      final Thread doAnEditThread=new Thread(){
        @Override public void run(){
          try {
            LOG.info("Starting mkdirs");
            namesystem.mkdirs("/test",new PermissionStatus("test","test",new FsPermission((short)00755)),true);
            LOG.info("mkdirs complete");
          }
 catch (          Throwable ioe) {
            LOG.fatal("Got exception",ioe);
            deferredException.set(ioe);
            waitToEnterFlush.countDown();
          }
        }
      }
;
      Answer<Void> blockingFlush=new Answer<Void>(){
        @Override public Void answer(        InvocationOnMock invocation) throws Throwable {
          LOG.info("Flush called");
          if (useAsyncEditLog || Thread.currentThread() == doAnEditThread) {
            LOG.info("edit thread: Telling main thread we made it to flush section...");
            waitToEnterFlush.countDown();
            LOG.info("edit thread: sleeping for " + BLOCK_TIME + "secs");
            Thread.sleep(BLOCK_TIME * 1000);
            LOG.info("Going through to flush. This will allow the main thread to continue.");
          }
          invocation.callRealMethod();
          LOG.info("Flush complete");
          return null;
        }
      }
;
      doAnswer(blockingFlush).when(spyElos).flush();
      doAnEditThread.start();
      LOG.info("Main thread: waiting to enter flush...");
      waitToEnterFlush.await();
      assertNull(deferredException.get());
      LOG.info("Main thread: detected that logSync is in unsynchronized section.");
      LOG.info("Trying to enter safe mode.");
      LOG.info("This should block for " + BLOCK_TIME + "sec, since flush will sleep that long");
      long st=Time.now();
      namesystem.setSafeMode(SafeModeAction.SAFEMODE_ENTER);
      long et=Time.now();
      LOG.info("Entered safe mode");
      assertTrue(et - st > (BLOCK_TIME - 1) * 1000);
      namesystem.saveNamespace();
      LOG.info("Joining on edit thread...");
      doAnEditThread.join();
      assertNull(deferredException.get());
      assertEquals(3,verifyEditLogs(namesystem,fsimage,NNStorage.getFinalizedEditsFileName(1,3),1));
      assertEquals(1,verifyEditLogs(namesystem,fsimage,NNStorage.getInProgressEditsFileName(4),4));
    }
  finally {
      LOG.info("Closing nn");
      if (namesystem != null)       namesystem.close();
    }
  }
  /** 
 * Most of the FSNamesystem methods have a synchronized section where they update the name system itself and write to the edit log, and then unsynchronized, they call logSync. This test verifies that, if an operation has written to the edit log but not yet synced it, we wait for that sync before entering safe mode.
 */
  @Test public void testSaveRightBeforeSync() throws Exception {
    Configuration conf=getConf();
    NameNode.initMetrics(conf,NamenodeRole.NAMENODE);
    DFSTestUtil.formatNameNode(conf);
    final FSNamesystem namesystem=FSNamesystem.loadFromDisk(conf);
    try {
      FSImage fsimage=namesystem.getFSImage();
      final FSEditLog editLog=fsimage.getEditLog();
      final AtomicReference<Throwable> deferredException=new AtomicReference<Throwable>();
      final CountDownLatch sleepingBeforeSync=new CountDownLatch(1);
      final Thread doAnEditThread=new Thread(){
        @Override public void run(){
          try {
            LOG.info("Starting setOwner");
            namesystem.writeLock();
            try {
              editLog.logSetOwner("/","test","test");
            }
  finally {
              namesystem.writeUnlock();
            }
            sleepingBeforeSync.countDown();
            LOG.info("edit thread: sleeping for " + BLOCK_TIME + "secs");
            Thread.sleep(BLOCK_TIME * 1000);
            editLog.logSync();
            LOG.info("edit thread: logSync complete");
          }
 catch (          Throwable ioe) {
            LOG.fatal("Got exception",ioe);
            deferredException.set(ioe);
            sleepingBeforeSync.countDown();
          }
        }
      }
;
      doAnEditThread.setDaemon(true);
      doAnEditThread.start();
      LOG.info("Main thread: waiting to just before logSync...");
      sleepingBeforeSync.await(200,TimeUnit.MILLISECONDS);
      assertNull(deferredException.get());
      LOG.info("Main thread: detected that logSync about to be called.");
      LOG.info("Trying to enter safe mode.");
      long st=Time.now();
      namesystem.setSafeMode(SafeModeAction.SAFEMODE_ENTER);
      long et=Time.now();
      LOG.info("Entered safe mode after " + (et - st) + "ms");
      assertTrue(et - st < (BLOCK_TIME / 2) * 1000);
      namesystem.saveNamespace();
      LOG.info("Joining on edit thread...");
      doAnEditThread.join();
      assertNull(deferredException.get());
      assertEquals(3,verifyEditLogs(namesystem,fsimage,NNStorage.getFinalizedEditsFileName(1,3),1));
      assertEquals(1,verifyEditLogs(namesystem,fsimage,NNStorage.getInProgressEditsFileName(4),4));
    }
  finally {
      LOG.info("Closing nn");
      if (namesystem != null)       namesystem.close();
    }
  }
}
