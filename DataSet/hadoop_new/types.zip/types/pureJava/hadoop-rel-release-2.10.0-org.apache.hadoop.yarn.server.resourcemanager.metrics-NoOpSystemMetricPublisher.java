/** 
 * This class does nothing when any of the methods are invoked on SystemMetricsPublisher.
 */
public class NoOpSystemMetricPublisher implements SystemMetricsPublisher {
  @Override public void appCreated(  RMApp app,  long createdTime){
  }
  @Override public void appFinished(  RMApp app,  RMAppState state,  long finishedTime){
  }
  @Override public void appACLsUpdated(  RMApp app,  String appViewACLs,  long updatedTime){
  }
  @Override public void appAttemptRegistered(  RMAppAttempt appAttempt,  long registeredTime){
  }
  @Override public void appAttemptFinished(  RMAppAttempt appAttempt,  RMAppAttemptState appAttemtpState,  RMApp app,  long finishedTime){
  }
  @Override public void containerCreated(  RMContainer container,  long createdTime){
  }
  @Override public void containerFinished(  RMContainer container,  long finishedTime){
  }
  @Override public void appUpdated(  RMApp app,  long currentTimeMillis){
  }
  @Override public void appStateUpdated(  RMApp app,  YarnApplicationState appState,  long updatedTime){
  }
}
