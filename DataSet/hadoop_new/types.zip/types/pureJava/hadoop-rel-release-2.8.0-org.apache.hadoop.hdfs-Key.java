private static class Key {
  final DatanodeID dnID;
  final boolean isDomain;
  Key(  DatanodeID dnID,  boolean isDomain){
    this.dnID=dnID;
    this.isDomain=isDomain;
  }
  @Override public boolean equals(  Object o){
    if (!(o instanceof Key)) {
      return false;
    }
    Key other=(Key)o;
    return dnID.equals(other.dnID) && isDomain == other.isDomain;
  }
  @Override public int hashCode(){
    return dnID.hashCode() ^ (isDomain ? 1 : 0);
  }
}
