private class CustomNodeManager extends NodeManager {
  @Override protected void doSecureLogin() throws IOException {
  }
}
