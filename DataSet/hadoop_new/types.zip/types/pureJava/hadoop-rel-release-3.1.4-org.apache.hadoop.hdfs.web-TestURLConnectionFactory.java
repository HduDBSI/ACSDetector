public final class TestURLConnectionFactory {
  @Test public void testConnConfiguratior() throws IOException {
    final URL u=new URL("http://localhost");
    final List<HttpURLConnection> conns=Lists.newArrayList();
    URLConnectionFactory fc=new URLConnectionFactory(new ConnectionConfigurator(){
      @Override public HttpURLConnection configure(      HttpURLConnection conn) throws IOException {
        Assert.assertEquals(u,conn.getURL());
        conns.add(conn);
        return conn;
      }
    }
);
    fc.openConnection(u);
    Assert.assertEquals(1,conns.size());
  }
  @Test public void testSSLInitFailure() throws Exception {
    Configuration conf=new Configuration();
    conf.set(SSLFactory.SSL_HOSTNAME_VERIFIER_KEY,"foo");
    GenericTestUtils.LogCapturer logs=GenericTestUtils.LogCapturer.captureLogs(LoggerFactory.getLogger(URLConnectionFactory.class));
    URLConnectionFactory.newDefaultURLConnectionFactory(conf);
    Assert.assertTrue("Expected log for ssl init failure not found!",logs.getOutput().contains("Cannot load customized ssl related configuration"));
  }
  @Test public void testSSLFactoryCleanup() throws Exception {
    String baseDir=GenericTestUtils.getTempPath(TestURLConnectionFactory.class.getSimpleName());
    File base=new File(baseDir);
    FileUtil.fullyDelete(base);
    base.mkdirs();
    String keystoreDir=new File(baseDir).getAbsolutePath();
    String sslConfDir=KeyStoreTestUtil.getClasspathDir(TestURLConnectionFactory.class);
    Configuration conf=new Configuration();
    KeyStoreTestUtil.setupSSLConfig(keystoreDir,sslConfDir,conf,false,true);
    Configuration sslConf=KeyStoreTestUtil.getSslConfig();
    sslConf.set("fs.defaultFS","swebhdfs://localhost");
    FileSystem fs=FileSystem.get(sslConf);
    ThreadGroup threadGroup=Thread.currentThread().getThreadGroup();
    while (threadGroup.getParent() != null) {
      threadGroup=threadGroup.getParent();
    }
    Thread[] threads=new Thread[threadGroup.activeCount()];
    threadGroup.enumerate(threads);
    Thread reloaderThread=null;
    for (    Thread thread : threads) {
      if ((thread.getName() != null) && (thread.getName().contains("Truststore reloader thread"))) {
        reloaderThread=thread;
      }
    }
    Assert.assertTrue("Reloader is not alive",reloaderThread.isAlive());
    fs.close();
    boolean reloaderStillAlive=true;
    for (int i=0; i < 10; i++) {
      reloaderStillAlive=reloaderThread.isAlive();
      if (!reloaderStillAlive) {
        break;
      }
      Thread.sleep(1000);
    }
    Assert.assertFalse("Reloader is still alive",reloaderStillAlive);
  }
}
