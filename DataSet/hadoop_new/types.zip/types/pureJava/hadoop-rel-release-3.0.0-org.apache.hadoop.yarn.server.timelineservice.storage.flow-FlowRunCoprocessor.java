/** 
 * Coprocessor for flow run table.
 */
public class FlowRunCoprocessor extends BaseRegionObserver {
  private static final Logger LOG=LoggerFactory.getLogger(FlowRunCoprocessor.class);
  private Region region;
  /** 
 * generate a timestamp that is unique per row in a region this is per region.
 */
  private final TimestampGenerator timestampGenerator=new TimestampGenerator();
  @Override public void start(  CoprocessorEnvironment e) throws IOException {
    if (e instanceof RegionCoprocessorEnvironment) {
      RegionCoprocessorEnvironment env=(RegionCoprocessorEnvironment)e;
      this.region=env.getRegion();
    }
  }
  @Override public void prePut(  ObserverContext<RegionCoprocessorEnvironment> e,  Put put,  WALEdit edit,  Durability durability) throws IOException {
    Map<String,byte[]> attributes=put.getAttributesMap();
    List<Tag> tags=new ArrayList<>();
    if ((attributes != null) && (attributes.size() > 0)) {
      for (      Map.Entry<String,byte[]> attribute : attributes.entrySet()) {
        Tag t=HBaseTimelineStorageUtils.getTagFromAttribute(attribute);
        tags.add(t);
      }
      byte[] tagByteArray=Tag.fromList(tags);
      NavigableMap<byte[],List<Cell>> newFamilyMap=new TreeMap<>(Bytes.BYTES_COMPARATOR);
      for (      Map.Entry<byte[],List<Cell>> entry : put.getFamilyCellMap().entrySet()) {
        List<Cell> newCells=new ArrayList<>(entry.getValue().size());
        for (        Cell cell : entry.getValue()) {
          long cellTimestamp=getCellTimestamp(cell.getTimestamp(),tags);
          newCells.add(CellUtil.createCell(CellUtil.cloneRow(cell),CellUtil.cloneFamily(cell),CellUtil.cloneQualifier(cell),cellTimestamp,KeyValue.Type.Put,CellUtil.cloneValue(cell),tagByteArray));
        }
        newFamilyMap.put(entry.getKey(),newCells);
      }
      put.setFamilyCellMap(newFamilyMap);
    }
  }
  /** 
 * Determines if the current cell's timestamp is to be used or a new unique cell timestamp is to be used. The reason this is done is to inadvertently overwrite cells when writes come in very fast. But for metric cells, the cell timestamp signifies the metric timestamp. Hence we don't want to overwrite it.
 * @param timestamp
 * @param tags
 * @return cell timestamp
 */
  private long getCellTimestamp(  long timestamp,  List<Tag> tags){
    if (timestamp == HConstants.LATEST_TIMESTAMP) {
      return timestampGenerator.getUniqueTimestamp();
    }
 else {
      return timestamp;
    }
  }
  @Override public void preGetOp(  ObserverContext<RegionCoprocessorEnvironment> e,  Get get,  List<Cell> results) throws IOException {
    Scan scan=new Scan(get);
    scan.setMaxVersions();
    RegionScanner scanner=null;
    try {
      scanner=new FlowScanner(e.getEnvironment(),scan,region.getScanner(scan),FlowScannerOperation.READ);
      scanner.next(results);
      e.bypass();
    }
  finally {
      if (scanner != null) {
        scanner.close();
      }
    }
  }
  @Override public RegionScanner preScannerOpen(  ObserverContext<RegionCoprocessorEnvironment> e,  Scan scan,  RegionScanner scanner) throws IOException {
    scan.setMaxVersions();
    return scanner;
  }
  @Override public RegionScanner postScannerOpen(  ObserverContext<RegionCoprocessorEnvironment> e,  Scan scan,  RegionScanner scanner) throws IOException {
    return new FlowScanner(e.getEnvironment(),scan,scanner,FlowScannerOperation.READ);
  }
  @Override public InternalScanner preFlush(  ObserverContext<RegionCoprocessorEnvironment> c,  Store store,  InternalScanner scanner) throws IOException {
    if (LOG.isDebugEnabled()) {
      if (store != null) {
        LOG.debug("preFlush store = " + store.getColumnFamilyName() + " flushableSize="+ store.getFlushableSize()+ " flushedCellsCount="+ store.getFlushedCellsCount()+ " compactedCellsCount="+ store.getCompactedCellsCount()+ " majorCompactedCellsCount="+ store.getMajorCompactedCellsCount()+ " memstoreFlushSize="+ store.getMemstoreFlushSize()+ " memstoreSize="+ store.getMemStoreSize()+ " size="+ store.getSize()+ " storeFilesCount="+ store.getStorefilesCount());
      }
    }
    return new FlowScanner(c.getEnvironment(),scanner,FlowScannerOperation.FLUSH);
  }
  @Override public void postFlush(  ObserverContext<RegionCoprocessorEnvironment> c,  Store store,  StoreFile resultFile){
    if (LOG.isDebugEnabled()) {
      if (store != null) {
        LOG.debug("postFlush store = " + store.getColumnFamilyName() + " flushableSize="+ store.getFlushableSize()+ " flushedCellsCount="+ store.getFlushedCellsCount()+ " compactedCellsCount="+ store.getCompactedCellsCount()+ " majorCompactedCellsCount="+ store.getMajorCompactedCellsCount()+ " memstoreFlushSize="+ store.getMemstoreFlushSize()+ " memstoreSize="+ store.getMemStoreSize()+ " size="+ store.getSize()+ " storeFilesCount="+ store.getStorefilesCount());
      }
    }
  }
  @Override public InternalScanner preCompact(  ObserverContext<RegionCoprocessorEnvironment> e,  Store store,  InternalScanner scanner,  ScanType scanType,  CompactionRequest request) throws IOException {
    FlowScannerOperation requestOp=FlowScannerOperation.MINOR_COMPACTION;
    if (request != null) {
      requestOp=(request.isMajor() ? FlowScannerOperation.MAJOR_COMPACTION : FlowScannerOperation.MINOR_COMPACTION);
      LOG.info("Compactionrequest= " + request.toString() + " "+ requestOp.toString()+ " RegionName="+ e.getEnvironment().getRegion().getRegionInfo().getRegionNameAsString());
    }
    return new FlowScanner(e.getEnvironment(),scanner,requestOp);
  }
}
