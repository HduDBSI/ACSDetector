public class TestTaskHeartbeatHandler {
  @SuppressWarnings({"rawtypes","unchecked"}) @Test public void testTimeout() throws InterruptedException {
    EventHandler mockHandler=mock(EventHandler.class);
    Clock clock=new SystemClock();
    TaskHeartbeatHandler hb=new TaskHeartbeatHandler(mockHandler,clock,1);
    Configuration conf=new Configuration();
    conf.setInt(MRJobConfig.TASK_TIMEOUT,10);
    conf.setLong(MRJobConfig.TASK_PROGRESS_REPORT_INTERVAL,5);
    conf.setInt(MRJobConfig.TASK_TIMEOUT_CHECK_INTERVAL_MS,10);
    hb.init(conf);
    hb.start();
    try {
      ApplicationId appId=ApplicationId.newInstance(0l,5);
      JobId jobId=MRBuilderUtils.newJobId(appId,4);
      TaskId tid=MRBuilderUtils.newTaskId(jobId,3,TaskType.MAP);
      TaskAttemptId taid=MRBuilderUtils.newTaskAttemptId(tid,2);
      hb.register(taid);
      Thread.sleep(100);
      verify(mockHandler,times(2)).handle(any(Event.class));
    }
  finally {
      hb.stop();
    }
  }
  /** 
 * Test if the final heartbeat timeout is set correctly when task progress report interval is set bigger than the task timeout in the configuration.
 */
  @Test public void testTaskTimeoutConfigSmallerThanTaskProgressReportInterval(){
    testTaskTimeoutWrtProgressReportInterval(1000L,5000L);
  }
  /** 
 * Test if the final heartbeat timeout is set correctly when task progress report interval is set smaller than the task timeout in the configuration.
 */
  @Test public void testTaskTimeoutConfigBiggerThanTaskProgressReportInterval(){
    testTaskTimeoutWrtProgressReportInterval(5000L,1000L);
  }
  /** 
 * Test if the final heartbeat timeout is set correctly when task progress report interval is not set in the configuration.
 */
  @Test public void testTaskTimeoutConfigWithoutTaskProgressReportInterval(){
    final long taskTimeoutConfiged=2000L;
    final Configuration conf=new Configuration();
    conf.setLong(MRJobConfig.TASK_TIMEOUT,taskTimeoutConfiged);
    final long expectedTimeout=taskTimeoutConfiged;
    verifyTaskTimeoutConfig(conf,expectedTimeout);
  }
  /** 
 * Test if task timeout is set properly in response to the configuration of the task progress report interval.
 */
  private static void testTaskTimeoutWrtProgressReportInterval(  long timeoutConfig,  long taskreportInterval){
    final Configuration conf=new Configuration();
    conf.setLong(MRJobConfig.TASK_TIMEOUT,timeoutConfig);
    conf.setLong(MRJobConfig.TASK_PROGRESS_REPORT_INTERVAL,taskreportInterval);
    final long expectedTimeout=Math.max(timeoutConfig,taskreportInterval * 2);
    verifyTaskTimeoutConfig(conf,expectedTimeout);
  }
  /** 
 * Verify task timeout is set as expected in TaskHeartBeatHandler with given configuration.
 * @param conf the configuration
 * @param expectedTimeout expected timeout value
 */
  private static void verifyTaskTimeoutConfig(  final Configuration conf,  final long expectedTimeout){
    final TaskHeartbeatHandler hb=new TaskHeartbeatHandler(null,new SystemClock(),1);
    hb.init(conf);
    Assert.assertTrue("The value of the task timeout is incorrect.",hb.getTaskTimeOut() == expectedTimeout);
  }
}
