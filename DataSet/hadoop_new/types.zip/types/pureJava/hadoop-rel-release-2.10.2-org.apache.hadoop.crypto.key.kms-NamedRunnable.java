/** 
 * A <code>Runnable</code> which takes a string name.
 */
private abstract static class NamedRunnable implements Runnable {
  final String name;
  private NamedRunnable(  String keyName){
    this.name=keyName;
  }
}
