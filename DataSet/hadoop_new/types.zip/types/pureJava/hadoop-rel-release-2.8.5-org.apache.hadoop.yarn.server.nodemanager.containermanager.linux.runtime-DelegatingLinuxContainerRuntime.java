@InterfaceAudience.Private @InterfaceStability.Unstable public class DelegatingLinuxContainerRuntime implements LinuxContainerRuntime {
  private static final Log LOG=LogFactory.getLog(DelegatingLinuxContainerRuntime.class);
  private DefaultLinuxContainerRuntime defaultLinuxContainerRuntime;
  private DockerLinuxContainerRuntime dockerLinuxContainerRuntime;
  private EnumSet<LinuxContainerRuntimeConstants.RuntimeType> allowedRuntimes=EnumSet.noneOf(LinuxContainerRuntimeConstants.RuntimeType.class);
  @Override public void initialize(  Configuration conf) throws ContainerExecutionException {
    String[] configuredRuntimes=conf.getTrimmedStrings(YarnConfiguration.LINUX_CONTAINER_RUNTIME_ALLOWED_RUNTIMES,YarnConfiguration.DEFAULT_LINUX_CONTAINER_RUNTIME_ALLOWED_RUNTIMES);
    for (    String configuredRuntime : configuredRuntimes) {
      try {
        allowedRuntimes.add(LinuxContainerRuntimeConstants.RuntimeType.valueOf(configuredRuntime.toUpperCase()));
      }
 catch (      IllegalArgumentException e) {
        throw new ContainerExecutionException("Invalid runtime set in " + YarnConfiguration.LINUX_CONTAINER_RUNTIME_ALLOWED_RUNTIMES + " : "+ configuredRuntime);
      }
    }
    if (isRuntimeAllowed(LinuxContainerRuntimeConstants.RuntimeType.DOCKER)) {
      dockerLinuxContainerRuntime=new DockerLinuxContainerRuntime(PrivilegedOperationExecutor.getInstance(conf));
      dockerLinuxContainerRuntime.initialize(conf);
    }
    if (isRuntimeAllowed(LinuxContainerRuntimeConstants.RuntimeType.DEFAULT)) {
      defaultLinuxContainerRuntime=new DefaultLinuxContainerRuntime(PrivilegedOperationExecutor.getInstance(conf));
      defaultLinuxContainerRuntime.initialize(conf);
    }
  }
  @Override public boolean useWhitelistEnv(  Map<String,String> env){
    try {
      LinuxContainerRuntime runtime=pickContainerRuntime(env);
      return runtime.useWhitelistEnv(env);
    }
 catch (    ContainerExecutionException e) {
      LOG.debug("Unable to determine runtime");
      return false;
    }
  }
  private LinuxContainerRuntime pickContainerRuntime(  Container container) throws ContainerExecutionException {
    return pickContainerRuntime(container.getLaunchContext().getEnvironment());
  }
  @VisibleForTesting LinuxContainerRuntime pickContainerRuntime(  Map<String,String> environment) throws ContainerExecutionException {
    LinuxContainerRuntime runtime;
    if (dockerLinuxContainerRuntime != null && DockerLinuxContainerRuntime.isDockerContainerRequested(environment)) {
      runtime=dockerLinuxContainerRuntime;
    }
 else     if (defaultLinuxContainerRuntime != null && !DockerLinuxContainerRuntime.isDockerContainerRequested(environment)) {
      runtime=defaultLinuxContainerRuntime;
    }
 else {
      throw new ContainerExecutionException("Requested runtime not allowed.");
    }
    if (LOG.isDebugEnabled()) {
      LOG.debug("Using container runtime: " + runtime.getClass().getSimpleName());
    }
    return runtime;
  }
  @Override public void prepareContainer(  ContainerRuntimeContext ctx) throws ContainerExecutionException {
    Container container=ctx.getContainer();
    LinuxContainerRuntime runtime=pickContainerRuntime(container);
    runtime.prepareContainer(ctx);
  }
  @Override public void launchContainer(  ContainerRuntimeContext ctx) throws ContainerExecutionException {
    Container container=ctx.getContainer();
    LinuxContainerRuntime runtime=pickContainerRuntime(container);
    runtime.launchContainer(ctx);
  }
  @Override public void signalContainer(  ContainerRuntimeContext ctx) throws ContainerExecutionException {
    Container container=ctx.getContainer();
    LinuxContainerRuntime runtime=pickContainerRuntime(container);
    runtime.signalContainer(ctx);
  }
  @Override public void reapContainer(  ContainerRuntimeContext ctx) throws ContainerExecutionException {
    Container container=ctx.getContainer();
    LinuxContainerRuntime runtime=pickContainerRuntime(container);
    runtime.reapContainer(ctx);
  }
  @VisibleForTesting boolean isRuntimeAllowed(  LinuxContainerRuntimeConstants.RuntimeType runtimeType){
    return allowedRuntimes.contains(runtimeType);
  }
}
