/** 
 * A  {@link org.apache.hadoop.io.compress.DecompressorStream} which workswith 'block-based' based compression algorithms, as opposed to  'stream-based' compression algorithms.
 */
@InterfaceAudience.Public @InterfaceStability.Evolving public class BlockDecompressorStream extends DecompressorStream {
  private int originalBlockSize=0;
  private int noUncompressedBytes=0;
  /** 
 * Create a  {@link BlockDecompressorStream}.
 * @param in input stream
 * @param decompressor decompressor to use
 * @param bufferSize size of buffer
 * @throws IOException
 */
  public BlockDecompressorStream(  InputStream in,  Decompressor decompressor,  int bufferSize) throws IOException {
    super(in,decompressor,bufferSize);
  }
  /** 
 * Create a  {@link BlockDecompressorStream}.
 * @param in input stream
 * @param decompressor decompressor to use
 * @throws IOException
 */
  public BlockDecompressorStream(  InputStream in,  Decompressor decompressor) throws IOException {
    super(in,decompressor);
  }
  protected BlockDecompressorStream(  InputStream in) throws IOException {
    super(in);
  }
  @Override protected int decompress(  byte[] b,  int off,  int len) throws IOException {
    if (noUncompressedBytes == originalBlockSize) {
      try {
        originalBlockSize=rawReadInt();
      }
 catch (      IOException ioe) {
        return -1;
      }
      noUncompressedBytes=0;
      if (originalBlockSize == 0) {
        eof=true;
        return -1;
      }
    }
    int n=0;
    while ((n=decompressor.decompress(b,off,len)) == 0) {
      if (decompressor.finished() || decompressor.needsDictionary()) {
        if (noUncompressedBytes >= originalBlockSize) {
          eof=true;
          return -1;
        }
      }
      if (decompressor.needsInput()) {
        int m;
        try {
          m=getCompressedData();
        }
 catch (        EOFException e) {
          eof=true;
          return -1;
        }
        decompressor.setInput(buffer,0,m);
      }
    }
    noUncompressedBytes+=n;
    return n;
  }
  @Override protected int getCompressedData() throws IOException {
    checkStream();
    int len=rawReadInt();
    if (len > buffer.length) {
      buffer=new byte[len];
    }
    int n=0, off=0;
    while (n < len) {
      int count=in.read(buffer,off + n,len - n);
      if (count < 0) {
        throw new EOFException("Unexpected end of block in input stream");
      }
      n+=count;
    }
    return len;
  }
  @Override public void resetState() throws IOException {
    originalBlockSize=0;
    noUncompressedBytes=0;
    super.resetState();
  }
  private int rawReadInt() throws IOException {
    int b1=in.read();
    int b2=in.read();
    int b3=in.read();
    int b4=in.read();
    if ((b1 | b2 | b3| b4) < 0)     throw new EOFException();
    return ((b1 << 24) + (b2 << 16) + (b3 << 8)+ (b4 << 0));
  }
}
