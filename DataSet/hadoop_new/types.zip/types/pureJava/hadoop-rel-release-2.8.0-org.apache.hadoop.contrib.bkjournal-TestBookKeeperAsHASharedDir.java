/** 
 * Integration test to ensure that the BookKeeper JournalManager works for HDFS Namenode HA
 */
@RunWith(Parameterized.class) public class TestBookKeeperAsHASharedDir {
  static final Log LOG=LogFactory.getLog(TestBookKeeperAsHASharedDir.class);
  private static BKJMUtil bkutil;
  static int numBookies=3;
  private static final String TEST_FILE_DATA="HA BookKeeperJournalManager";
  @Parameters public static Collection<Object[]> data(){
    Collection<Object[]> params=new ArrayList<Object[]>();
    params.add(new Object[]{Boolean.FALSE});
    params.add(new Object[]{Boolean.TRUE});
    return params;
  }
  private static boolean useAsyncEditLog;
  public TestBookKeeperAsHASharedDir(  Boolean async){
    useAsyncEditLog=async;
  }
  private static Configuration getConf(){
    Configuration conf=new Configuration();
    conf.setInt(DFSConfigKeys.DFS_HA_TAILEDITS_PERIOD_KEY,1);
    conf.setBoolean(DFSConfigKeys.DFS_NAMENODE_EDITS_ASYNC_LOGGING,useAsyncEditLog);
    return conf;
  }
  @BeforeClass public static void setupBookkeeper() throws Exception {
    bkutil=new BKJMUtil(numBookies);
    bkutil.start();
  }
  @Before public void clearExitStatus(){
    ExitUtil.resetFirstExitException();
  }
  @AfterClass public static void teardownBookkeeper() throws Exception {
    bkutil.teardown();
  }
  /** 
 * Test simple HA failover usecase with BK
 */
  @Test public void testFailoverWithBK() throws Exception {
    MiniDFSCluster cluster=null;
    try {
      Configuration conf=getConf();
      conf.set(DFSConfigKeys.DFS_NAMENODE_SHARED_EDITS_DIR_KEY,BKJMUtil.createJournalURI("/hotfailover").toString());
      BKJMUtil.addJournalManagerDefinition(conf);
      cluster=new MiniDFSCluster.Builder(conf).nnTopology(MiniDFSNNTopology.simpleHATopology()).numDataNodes(0).manageNameDfsSharedDirs(false).build();
      NameNode nn1=cluster.getNameNode(0);
      NameNode nn2=cluster.getNameNode(1);
      cluster.waitActive();
      cluster.transitionToActive(0);
      Path p=new Path("/testBKJMfailover");
      FileSystem fs=HATestUtil.configureFailoverFs(cluster,conf);
      fs.mkdirs(p);
      cluster.shutdownNameNode(0);
      cluster.transitionToActive(1);
      assertTrue(fs.exists(p));
    }
  finally {
      if (cluster != null) {
        cluster.shutdown();
      }
    }
  }
  /** 
 * Test HA failover, where BK, as the shared storage, fails. Once it becomes available again, a standby can come up. Verify that any write happening after the BK fail is not available on the standby.
 */
  @Test public void testFailoverWithFailingBKCluster() throws Exception {
    int ensembleSize=numBookies + 1;
    BookieServer newBookie=bkutil.newBookie();
    assertEquals("New bookie didn't start",ensembleSize,bkutil.checkBookiesUp(ensembleSize,10));
    BookieServer replacementBookie=null;
    MiniDFSCluster cluster=null;
    try {
      Configuration conf=getConf();
      conf.set(DFSConfigKeys.DFS_NAMENODE_SHARED_EDITS_DIR_KEY,BKJMUtil.createJournalURI("/hotfailoverWithFail").toString());
      conf.setInt(BookKeeperJournalManager.BKJM_BOOKKEEPER_ENSEMBLE_SIZE,ensembleSize);
      conf.setInt(BookKeeperJournalManager.BKJM_BOOKKEEPER_QUORUM_SIZE,ensembleSize);
      BKJMUtil.addJournalManagerDefinition(conf);
      cluster=new MiniDFSCluster.Builder(conf).nnTopology(MiniDFSNNTopology.simpleHATopology()).numDataNodes(0).manageNameDfsSharedDirs(false).checkExitOnShutdown(false).build();
      NameNode nn1=cluster.getNameNode(0);
      NameNode nn2=cluster.getNameNode(1);
      cluster.waitActive();
      cluster.transitionToActive(0);
      Path p1=new Path("/testBKJMFailingBKCluster1");
      Path p2=new Path("/testBKJMFailingBKCluster2");
      FileSystem fs=HATestUtil.configureFailoverFs(cluster,conf);
      fs.mkdirs(p1);
      newBookie.shutdown();
      assertEquals("New bookie didn't stop",numBookies,bkutil.checkBookiesUp(numBookies,10));
      try {
        fs.mkdirs(p2);
        fail("mkdirs should result in the NN exiting");
      }
 catch (      RemoteException re) {
        assertTrue(re.getClassName().contains("ExitException"));
      }
      cluster.shutdownNameNode(0);
      try {
        cluster.transitionToActive(1);
        fail("Shouldn't have been able to transition with bookies down");
      }
 catch (      ExitException ee) {
        assertTrue("Should shutdown due to required journal failure",ee.getMessage().contains("starting log segment 3 failed for required journal"));
      }
      replacementBookie=bkutil.newBookie();
      assertEquals("Replacement bookie didn't start",ensembleSize,bkutil.checkBookiesUp(ensembleSize,10));
      cluster.transitionToActive(1);
      assertTrue(fs.exists(p1));
      assertFalse(fs.exists(p2));
    }
  finally {
      newBookie.shutdown();
      if (replacementBookie != null) {
        replacementBookie.shutdown();
      }
      if (cluster != null) {
        cluster.shutdown();
      }
    }
  }
  /** 
 * Test that two namenodes can't continue as primary
 */
  @Test public void testMultiplePrimariesStarted() throws Exception {
    Path p1=new Path("/testBKJMMultiplePrimary");
    MiniDFSCluster cluster=null;
    try {
      Configuration conf=getConf();
      conf.set(DFSConfigKeys.DFS_NAMENODE_SHARED_EDITS_DIR_KEY,BKJMUtil.createJournalURI("/hotfailoverMultiple").toString());
      BKJMUtil.addJournalManagerDefinition(conf);
      cluster=new MiniDFSCluster.Builder(conf).nnTopology(MiniDFSNNTopology.simpleHATopology()).numDataNodes(0).manageNameDfsSharedDirs(false).checkExitOnShutdown(false).build();
      NameNode nn1=cluster.getNameNode(0);
      NameNode nn2=cluster.getNameNode(1);
      cluster.waitActive();
      cluster.transitionToActive(0);
      FileSystem fs=HATestUtil.configureFailoverFs(cluster,conf);
      fs.mkdirs(p1);
      nn1.getRpcServer().rollEditLog();
      cluster.transitionToActive(1);
      fs=cluster.getFileSystem(0);
      try {
        System.out.println("DMS: > *************");
        boolean foo=fs.delete(p1,true);
        System.out.println("DMS: < ************* " + foo);
        fail("Log update on older active should cause it to exit");
      }
 catch (      RemoteException re) {
        assertTrue(re.getClassName().contains("ExitException"));
      }
    }
  finally {
      if (cluster != null) {
        cluster.shutdown();
      }
    }
  }
  /** 
 * Use NameNode INTIALIZESHAREDEDITS to initialize the shared edits. i.e. copy the edits log segments to new bkjm shared edits.
 * @throws Exception
 */
  @Test public void testInitializeBKSharedEdits() throws Exception {
    MiniDFSCluster cluster=null;
    try {
      Configuration conf=getConf();
      HAUtil.setAllowStandbyReads(conf,true);
      MiniDFSNNTopology topology=MiniDFSNNTopology.simpleHATopology();
      cluster=new MiniDFSCluster.Builder(conf).nnTopology(topology).numDataNodes(0).build();
      cluster.waitActive();
      cluster.shutdownNameNodes();
      File shareddir=new File(cluster.getSharedEditsDir(0,1));
      assertTrue("Initial Shared edits dir not fully deleted",FileUtil.fullyDelete(shareddir));
      assertCanNotStartNamenode(cluster,0);
      assertCanNotStartNamenode(cluster,1);
      Configuration nn1Conf=cluster.getConfiguration(0);
      Configuration nn2Conf=cluster.getConfiguration(1);
      nn1Conf.set(DFSConfigKeys.DFS_NAMENODE_SHARED_EDITS_DIR_KEY,BKJMUtil.createJournalURI("/initializeSharedEdits").toString());
      nn2Conf.set(DFSConfigKeys.DFS_NAMENODE_SHARED_EDITS_DIR_KEY,BKJMUtil.createJournalURI("/initializeSharedEdits").toString());
      BKJMUtil.addJournalManagerDefinition(nn1Conf);
      BKJMUtil.addJournalManagerDefinition(nn2Conf);
      assertFalse(NameNode.initializeSharedEdits(nn1Conf));
      assertCanStartHANameNodes(cluster,conf,"/testBKJMInitialize");
    }
  finally {
      if (cluster != null) {
        cluster.shutdown();
      }
    }
  }
  private void assertCanNotStartNamenode(  MiniDFSCluster cluster,  int nnIndex){
    try {
      cluster.restartNameNode(nnIndex,false);
      fail("Should not have been able to start NN" + (nnIndex) + " without shared dir");
    }
 catch (    IOException ioe) {
      LOG.info("Got expected exception",ioe);
      GenericTestUtils.assertExceptionContains("storage directory does not exist or is not accessible",ioe);
    }
  }
  private void assertCanStartHANameNodes(  MiniDFSCluster cluster,  Configuration conf,  String path) throws ServiceFailedException, IOException, URISyntaxException, InterruptedException {
    cluster.restartNameNode(0,false);
    cluster.restartNameNode(1,true);
    cluster.getNameNode(0).getRpcServer().transitionToActive(new StateChangeRequestInfo(RequestSource.REQUEST_BY_USER));
    FileSystem fs=null;
    try {
      Path newPath=new Path(path);
      fs=HATestUtil.configureFailoverFs(cluster,conf);
      assertTrue(fs.mkdirs(newPath));
      HATestUtil.waitForStandbyToCatchUp(cluster.getNameNode(0),cluster.getNameNode(1));
      assertTrue(NameNodeAdapter.getFileInfo(cluster.getNameNode(1),newPath.toString(),false).isDir());
    }
  finally {
      if (fs != null) {
        fs.close();
      }
    }
  }
  /** 
 * NameNode should load the edits correctly if the applicable edits are present in the BKJM.
 */
  @Test public void testNameNodeMultipleSwitchesUsingBKJM() throws Exception {
    MiniDFSCluster cluster=null;
    try {
      Configuration conf=getConf();
      conf.set(DFSConfigKeys.DFS_NAMENODE_SHARED_EDITS_DIR_KEY,BKJMUtil.createJournalURI("/correctEditLogSelection").toString());
      BKJMUtil.addJournalManagerDefinition(conf);
      cluster=new MiniDFSCluster.Builder(conf).nnTopology(MiniDFSNNTopology.simpleHATopology()).numDataNodes(0).manageNameDfsSharedDirs(false).build();
      NameNode nn1=cluster.getNameNode(0);
      NameNode nn2=cluster.getNameNode(1);
      cluster.waitActive();
      cluster.transitionToActive(0);
      nn1.getRpcServer().rollEditLog();
      cluster.transitionToStandby(0);
      cluster.transitionToActive(1);
      nn2.getRpcServer().rollEditLog();
      nn2.getRpcServer().rollEditLog();
      cluster.transitionToStandby(1);
      cluster.transitionToActive(0);
    }
  finally {
      if (cluster != null) {
        cluster.shutdown();
      }
    }
  }
}
