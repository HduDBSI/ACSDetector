/** 
 * FsckResult of checking, plus overall DFS statistics.
 */
@VisibleForTesting static class Result {
  final List<String> missingIds=new ArrayList<String>();
  long missingSize=0L;
  long corruptFiles=0L;
  long corruptBlocks=0L;
  long corruptSize=0L;
  long excessiveReplicas=0L;
  long missingReplicas=0L;
  long decommissionedReplicas=0L;
  long decommissioningReplicas=0L;
  long enteringMaintenanceReplicas=0L;
  long inMaintenanceReplicas=0L;
  long numUnderMinReplicatedBlocks=0L;
  long numOverReplicatedBlocks=0L;
  long numUnderReplicatedBlocks=0L;
  long numMisReplicatedBlocks=0L;
  long numMinReplicatedBlocks=0L;
  long totalBlocks=0L;
  long numExpectedReplicas=0L;
  long totalOpenFilesBlocks=0L;
  long totalFiles=0L;
  long totalOpenFiles=0L;
  long totalSize=0L;
  long totalOpenFilesSize=0L;
  long totalReplicas=0L;
  /** 
 * DFS is considered healthy if there are no missing blocks.
 */
  boolean isHealthy(){
    return ((missingIds.size() == 0) && (corruptBlocks == 0));
  }
  /** 
 * Add a missing block name, plus its size. 
 */
  void addMissing(  String id,  long size){
    missingIds.add(id);
    missingSize+=size;
  }
  /** 
 * Add a corrupt block. 
 */
  void addCorrupt(  long size){
    corruptBlocks++;
    corruptSize+=size;
  }
  /** 
 * Return the actual replication factor. 
 */
  float getReplicationFactor(){
    if (totalBlocks == 0)     return 0.0f;
    return (float)(totalReplicas) / (float)totalBlocks;
  }
}
