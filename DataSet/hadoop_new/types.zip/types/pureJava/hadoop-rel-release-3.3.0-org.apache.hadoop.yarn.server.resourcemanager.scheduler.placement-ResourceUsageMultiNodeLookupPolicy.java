/** 
 * <p> This class has the following functionality: <p> ResourceUsageMultiNodeLookupPolicy holds sorted nodes list based on the resource usage of nodes at given time. </p>
 */
public class ResourceUsageMultiNodeLookupPolicy<N extends SchedulerNode> implements MultiNodeLookupPolicy<N> {
  protected Map<String,Set<N>> nodesPerPartition=new ConcurrentHashMap<>();
  protected Comparator<N> comparator;
  public ResourceUsageMultiNodeLookupPolicy(){
    this.comparator=new Comparator<N>(){
      @Override public int compare(      N o1,      N o2){
        int allocatedDiff=o1.getAllocatedResource().compareTo(o2.getAllocatedResource());
        if (allocatedDiff == 0) {
          return o1.getNodeID().compareTo(o2.getNodeID());
        }
        return allocatedDiff;
      }
    }
;
  }
  @Override public Iterator<N> getPreferredNodeIterator(  Collection<N> nodes,  String partition){
    return getNodesPerPartition(partition).iterator();
  }
  @Override public void addAndRefreshNodesSet(  Collection<N> nodes,  String partition){
    Set<N> nodeList=new ConcurrentSkipListSet<N>(comparator);
    nodeList.addAll(nodes);
    nodesPerPartition.put(partition,Collections.unmodifiableSet(nodeList));
  }
  @Override public Set<N> getNodesPerPartition(  String partition){
    return nodesPerPartition.getOrDefault(partition,Collections.emptySet());
  }
}
