@Private @Unstable public class CheckForDecommissioningNodesResponsePBImpl extends CheckForDecommissioningNodesResponse {
  CheckForDecommissioningNodesResponseProto proto=CheckForDecommissioningNodesResponseProto.getDefaultInstance();
  CheckForDecommissioningNodesResponseProto.Builder builder=null;
  boolean viaProto=false;
  private Set<NodeId> decommissioningNodes;
  public CheckForDecommissioningNodesResponsePBImpl(){
    builder=CheckForDecommissioningNodesResponseProto.newBuilder();
  }
  public CheckForDecommissioningNodesResponsePBImpl(  CheckForDecommissioningNodesResponseProto proto){
    this.proto=proto;
    viaProto=true;
  }
  public CheckForDecommissioningNodesResponseProto getProto(){
    mergeLocalToProto();
    proto=viaProto ? proto : builder.build();
    viaProto=true;
    return proto;
  }
  private void mergeLocalToProto(){
    if (viaProto)     maybeInitBuilder();
    mergeLocalToBuilder();
    proto=builder.build();
    viaProto=true;
  }
  private void maybeInitBuilder(){
    if (viaProto || builder == null) {
      builder=CheckForDecommissioningNodesResponseProto.newBuilder(proto);
    }
    viaProto=false;
  }
  private void mergeLocalToBuilder(){
    if (this.decommissioningNodes != null) {
      addDecommissioningNodesToProto();
    }
  }
  private void addDecommissioningNodesToProto(){
    maybeInitBuilder();
    builder.clearDecommissioningNodes();
    if (this.decommissioningNodes == null)     return;
    Set<NodeIdProto> nodeIdProtos=new HashSet<NodeIdProto>();
    for (    NodeId nodeId : decommissioningNodes) {
      nodeIdProtos.add(convertToProtoFormat(nodeId));
    }
    builder.addAllDecommissioningNodes(nodeIdProtos);
  }
  private NodeIdProto convertToProtoFormat(  NodeId nodeId){
    return ((NodeIdPBImpl)nodeId).getProto();
  }
  @Override public void setDecommissioningNodes(  Set<NodeId> decommissioningNodes){
    maybeInitBuilder();
    if (decommissioningNodes == null)     builder.clearDecommissioningNodes();
    this.decommissioningNodes=decommissioningNodes;
  }
  @Override public Set<NodeId> getDecommissioningNodes(){
    initNodesDecommissioning();
    return this.decommissioningNodes;
  }
  private void initNodesDecommissioning(){
    if (this.decommissioningNodes != null) {
      return;
    }
    CheckForDecommissioningNodesResponseProtoOrBuilder p=viaProto ? proto : builder;
    List<NodeIdProto> nodeIds=p.getDecommissioningNodesList();
    this.decommissioningNodes=new HashSet<NodeId>();
    for (    NodeIdProto nodeIdProto : nodeIds) {
      this.decommissioningNodes.add(convertFromProtoFormat(nodeIdProto));
    }
  }
  private NodeId convertFromProtoFormat(  NodeIdProto nodeIdProto){
    return new NodeIdPBImpl(nodeIdProto);
  }
  @Override public int hashCode(){
    return getProto().hashCode();
  }
  @Override public boolean equals(  Object other){
    if (other == null)     return false;
    if (other.getClass().isAssignableFrom(this.getClass())) {
      return this.getProto().equals(this.getClass().cast(other).getProto());
    }
    return false;
  }
  @Override public String toString(){
    return TextFormat.shortDebugString(getProto());
  }
}
