@Public @Stable public static class ResourceRequestComparator implements java.util.Comparator<ResourceRequest>, Serializable {
  private static final long serialVersionUID=1L;
  @Override public int compare(  ResourceRequest r1,  ResourceRequest r2){
    int ret=r1.getPriority().compareTo(r2.getPriority());
    if (ret == 0) {
      String h1=r1.getResourceName();
      String h2=r2.getResourceName();
      ret=h1.compareTo(h2);
    }
    if (ret == 0) {
      ret=r1.getCapability().compareTo(r2.getCapability());
    }
    return ret;
  }
}
