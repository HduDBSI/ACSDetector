public class NavBlock extends HtmlBlock {
  @Override public void render(  Block html){
    boolean addErrorsAndWarningsLink=false;
    Log log=LogFactory.getLog(NavBlock.class);
    if (log instanceof Log4JLogger) {
      Log4jWarningErrorMetricsAppender appender=Log4jWarningErrorMetricsAppender.findAppender();
      if (appender != null) {
        addErrorsAndWarningsLink=true;
      }
    }
    UL<DIV<Hamlet>> mainList=html.div("#nav").h3("Cluster").ul().li().a(url("cluster"),"About")._().li().a(url("nodes"),"Nodes")._().li().a(url("nodelabels"),"Node Labels")._();
    UL<LI<UL<DIV<Hamlet>>>> subAppsList=mainList.li().a(url("apps"),"Applications").ul();
    subAppsList.li()._();
    for (    YarnApplicationState state : YarnApplicationState.values()) {
      subAppsList.li().a(url("apps",state.toString()),state.toString())._();
    }
    subAppsList._()._();
    UL<DIV<Hamlet>> tools=mainList.li().a(url("scheduler"),"Scheduler")._()._().h3("Tools").ul();
    tools.li().a("/conf","Configuration")._().li().a("/logs","Local logs")._().li().a("/stacks","Server stacks")._().li().a("/jmx?qry=Hadoop:*","Server metrics")._();
    if (addErrorsAndWarningsLink) {
      tools.li().a(url("errors-and-warnings"),"Errors/Warnings")._();
    }
    tools._()._();
  }
}
