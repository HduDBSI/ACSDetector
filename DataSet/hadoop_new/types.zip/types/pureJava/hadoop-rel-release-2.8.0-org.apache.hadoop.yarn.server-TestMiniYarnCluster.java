public class TestMiniYarnCluster {
  @Test public void testTimelineServiceStartInMiniCluster() throws Exception {
    Configuration conf=new YarnConfiguration();
    int numNodeManagers=1;
    int numLocalDirs=1;
    int numLogDirs=1;
    boolean enableAHS;
    conf.setBoolean(YarnConfiguration.TIMELINE_SERVICE_ENABLED,false);
    enableAHS=false;
    try (MiniYARNCluster cluster=new MiniYARNCluster(TestMiniYarnCluster.class.getSimpleName(),numNodeManagers,numLocalDirs,numLogDirs,numLogDirs,enableAHS)){
      cluster.init(conf);
      cluster.start();
      Assert.assertNull("Timeline Service should not have been started",cluster.getApplicationHistoryServer());
    }
     conf.setBoolean(YarnConfiguration.TIMELINE_SERVICE_ENABLED,true);
    enableAHS=false;
    try (MiniYARNCluster cluster=new MiniYARNCluster(TestMiniYarnCluster.class.getSimpleName(),numNodeManagers,numLocalDirs,numLogDirs,numLogDirs,enableAHS)){
      cluster.init(conf);
      String hostname=MiniYARNCluster.getHostname();
      Assert.assertEquals(hostname + ":0",conf.get(YarnConfiguration.TIMELINE_SERVICE_ADDRESS));
      Assert.assertEquals(hostname + ":0",conf.get(YarnConfiguration.TIMELINE_SERVICE_WEBAPP_ADDRESS));
      cluster.start();
      int wait=0;
      while (cluster.getApplicationHistoryServer() == null && wait < 20) {
        Thread.sleep(500);
        wait++;
      }
      Assert.assertNotNull("Timeline Service should have been started",cluster.getApplicationHistoryServer());
    }
     conf.setBoolean(YarnConfiguration.TIMELINE_SERVICE_ENABLED,false);
    enableAHS=true;
    try (MiniYARNCluster cluster=new MiniYARNCluster(TestMiniYarnCluster.class.getSimpleName(),numNodeManagers,numLocalDirs,numLogDirs,numLogDirs,enableAHS)){
      cluster.init(conf);
      cluster.start();
      int wait=0;
      while (cluster.getApplicationHistoryServer() == null && wait < 20) {
        Thread.sleep(500);
        wait++;
      }
      Assert.assertNotNull("Timeline Service should have been started",cluster.getApplicationHistoryServer());
    }
   }
  @Test public void testMultiRMConf() throws IOException {
    String RM1_NODE_ID="rm1", RM2_NODE_ID="rm2";
    int RM1_PORT_BASE=10000, RM2_PORT_BASE=20000;
    Configuration conf=new YarnConfiguration();
    conf.set(YarnConfiguration.RM_CLUSTER_ID,"yarn-test-cluster");
    conf.setBoolean(YarnConfiguration.RECOVERY_ENABLED,true);
    conf.setBoolean(YarnConfiguration.RM_HA_ENABLED,true);
    conf.setBoolean(YarnConfiguration.AUTO_FAILOVER_ENABLED,false);
    conf.set(YarnConfiguration.RM_HA_IDS,RM1_NODE_ID + "," + RM2_NODE_ID);
    HATestUtil.setRpcAddressForRM(RM1_NODE_ID,RM1_PORT_BASE,conf);
    HATestUtil.setRpcAddressForRM(RM2_NODE_ID,RM2_PORT_BASE,conf);
    conf.setBoolean(YarnConfiguration.YARN_MINICLUSTER_FIXED_PORTS,true);
    conf.setBoolean(YarnConfiguration.YARN_MINICLUSTER_USE_RPC,true);
    try (MiniYARNCluster cluster=new MiniYARNCluster(TestMiniYarnCluster.class.getName(),2,0,1,1)){
      cluster.init(conf);
      Configuration conf1=cluster.getResourceManager(0).getConfig(), conf2=cluster.getResourceManager(1).getConfig();
      Assert.assertFalse(conf1 == conf2);
      Assert.assertEquals("0.0.0.0:18032",conf1.get(HAUtil.addSuffix(YarnConfiguration.RM_ADDRESS,RM1_NODE_ID)));
      Assert.assertEquals("0.0.0.0:28032",conf1.get(HAUtil.addSuffix(YarnConfiguration.RM_ADDRESS,RM2_NODE_ID)));
      Assert.assertEquals("rm1",conf1.get(YarnConfiguration.RM_HA_ID));
      Assert.assertEquals("0.0.0.0:18032",conf2.get(HAUtil.addSuffix(YarnConfiguration.RM_ADDRESS,RM1_NODE_ID)));
      Assert.assertEquals("0.0.0.0:28032",conf2.get(HAUtil.addSuffix(YarnConfiguration.RM_ADDRESS,RM2_NODE_ID)));
      Assert.assertEquals("rm2",conf2.get(YarnConfiguration.RM_HA_ID));
    }
   }
}
