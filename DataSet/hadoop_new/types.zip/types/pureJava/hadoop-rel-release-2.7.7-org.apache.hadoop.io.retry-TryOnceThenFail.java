static class TryOnceThenFail implements RetryPolicy {
  @Override public RetryAction shouldRetry(  Exception e,  int retries,  int failovers,  boolean isIdempotentOrAtMostOnce) throws Exception {
    return RetryAction.FAIL;
  }
}
