private class Emptier implements Runnable {
  private Configuration conf;
  private long emptierInterval;
  Emptier(  Configuration conf,  long emptierInterval) throws IOException {
    this.conf=conf;
    this.emptierInterval=emptierInterval;
    if (emptierInterval > deletionInterval || emptierInterval == 0) {
      LOG.info("The configured checkpoint interval is " + (emptierInterval / MSECS_PER_MINUTE) + " minutes."+ " Using an interval of "+ (deletionInterval / MSECS_PER_MINUTE)+ " minutes that is used for deletion instead");
      this.emptierInterval=deletionInterval;
    }
  }
  @Override public void run(){
    if (emptierInterval == 0)     return;
    long now=Time.now();
    long end;
    while (true) {
      end=ceiling(now,emptierInterval);
      try {
        Thread.sleep(end - now);
      }
 catch (      InterruptedException e) {
        break;
      }
      try {
        now=Time.now();
        if (now >= end) {
          FileStatus[] homes=null;
          try {
            homes=fs.listStatus(homesParent);
          }
 catch (          IOException e) {
            LOG.warn("Trash can't list homes: " + e + " Sleeping.");
            continue;
          }
          for (          FileStatus home : homes) {
            if (!home.isDirectory())             continue;
            try {
              TrashPolicyDefault trash=new TrashPolicyDefault(fs,home.getPath(),conf);
              trash.deleteCheckpoint();
              trash.createCheckpoint();
            }
 catch (            IOException e) {
              LOG.warn("Trash caught: " + e + ". Skipping "+ home.getPath()+ ".");
            }
          }
        }
      }
 catch (      Exception e) {
        LOG.warn("RuntimeException during Trash.Emptier.run(): ",e);
      }
    }
    try {
      fs.close();
    }
 catch (    IOException e) {
      LOG.warn("Trash cannot close FileSystem: ",e);
    }
  }
  private long ceiling(  long time,  long interval){
    return floor(time,interval) + interval;
  }
  private long floor(  long time,  long interval){
    return (time / interval) * interval;
  }
}
