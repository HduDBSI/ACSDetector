/** 
 * Map object to serial number. <p>It allows to get the serial number of an object, if the object doesn't exist in the map, a new serial number increased by 1 is generated to map to the object. The mapped object can also be got through the serial number. <p>The map is thread-safe.
 */
@InterfaceAudience.Private public class SerialNumberMap<T> {
  private final AtomicInteger max=new AtomicInteger(1);
  private final ConcurrentMap<T,Integer> t2i=new ConcurrentHashMap<T,Integer>();
  private final ConcurrentMap<Integer,T> i2t=new ConcurrentHashMap<Integer,T>();
  public int get(  T t){
    if (t == null) {
      return 0;
    }
    Integer sn=t2i.get(t);
    if (sn == null) {
      sn=max.getAndIncrement();
      if (sn < 0) {
        throw new IllegalStateException("Too many elements!");
      }
      Integer old=t2i.putIfAbsent(t,sn);
      if (old != null) {
        return old;
      }
      i2t.put(sn,t);
    }
    return sn;
  }
  public T get(  int i){
    if (i == 0) {
      return null;
    }
    T t=i2t.get(i);
    if (t == null) {
      throw new IllegalStateException("!i2t.containsKey(" + i + "), this="+ this);
    }
    return t;
  }
  @Override public String toString(){
    return "max=" + max + ",\n  t2i="+ t2i+ ",\n  i2t="+ i2t;
  }
}
