/** 
 * Thrown if there is a problem communicating with Azure Storage service.
 */
@InterfaceAudience.Public @InterfaceStability.Evolving public class AzureException extends IOException {
  private static final long serialVersionUID=1L;
  public AzureException(  String message){
    super(message);
  }
  public AzureException(  String message,  Throwable cause){
    super(message,cause);
  }
  public AzureException(  Throwable t){
    super(t);
  }
}
