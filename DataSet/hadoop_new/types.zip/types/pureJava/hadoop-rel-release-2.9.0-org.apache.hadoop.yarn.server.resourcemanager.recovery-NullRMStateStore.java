@Unstable public class NullRMStateStore extends RMStateStore {
  @Override protected void initInternal(  Configuration conf) throws Exception {
  }
  @Override protected void startInternal() throws Exception {
  }
  @Override protected void closeInternal() throws Exception {
  }
  @Override public synchronized long getAndIncrementEpoch() throws Exception {
    return 0L;
  }
  @Override public RMState loadState() throws Exception {
    throw new UnsupportedOperationException("Cannot load state from null store");
  }
  @Override protected void storeApplicationStateInternal(  ApplicationId appId,  ApplicationStateData appStateData) throws Exception {
  }
  @Override protected void storeApplicationAttemptStateInternal(  ApplicationAttemptId attemptId,  ApplicationAttemptStateData attemptStateData) throws Exception {
  }
  @Override protected void removeApplicationStateInternal(  ApplicationStateData appState) throws Exception {
  }
  @Override public void storeRMDelegationTokenState(  RMDelegationTokenIdentifier rmDTIdentifier,  Long renewDate) throws Exception {
  }
  @Override public void removeRMDelegationTokenState(  RMDelegationTokenIdentifier rmDTIdentifier) throws Exception {
  }
  @Override protected void updateRMDelegationTokenState(  RMDelegationTokenIdentifier rmDTIdentifier,  Long renewDate) throws Exception {
  }
  @Override public void storeRMDTMasterKeyState(  DelegationKey delegationKey) throws Exception {
  }
  @Override protected void storeReservationState(  ReservationAllocationStateProto reservationAllocation,  String planName,  String reservationIdName) throws Exception {
  }
  @Override protected void removeReservationState(  String planName,  String reservationIdName) throws Exception {
  }
  @Override public void removeRMDTMasterKeyState(  DelegationKey delegationKey) throws Exception {
  }
  @Override protected void updateApplicationStateInternal(  ApplicationId appId,  ApplicationStateData appStateData) throws Exception {
  }
  @Override protected void updateApplicationAttemptStateInternal(  ApplicationAttemptId attemptId,  ApplicationAttemptStateData attemptStateData) throws Exception {
  }
  @Override public synchronized void removeApplicationAttemptInternal(  ApplicationAttemptId attemptId) throws Exception {
  }
  @Override public void checkVersion() throws Exception {
  }
  @Override protected Version loadVersion() throws Exception {
    return null;
  }
  @Override protected void storeVersion() throws Exception {
  }
  @Override protected Version getCurrentVersion(){
    return null;
  }
  @Override public void storeOrUpdateAMRMTokenSecretManagerState(  AMRMTokenSecretManagerState state,  boolean isUpdate){
  }
  @Override public void deleteStore() throws Exception {
  }
  @Override public void removeApplication(  ApplicationId removeAppId) throws Exception {
  }
}
