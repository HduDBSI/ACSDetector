public static class Perms extends CreateOpts {
  private final FsPermission permissions;
  protected Perms(  FsPermission perm){
    if (perm == null) {
      throw new IllegalArgumentException("Permissions must not be null");
    }
    permissions=perm;
  }
  public FsPermission getValue(){
    return permissions;
  }
}
