/** 
 * An exception class for authorization-related issues. This class <em>does not</em> provide the stack trace for security purposes.
 */
@InterfaceAudience.LimitedPrivate({"HDFS","MapReduce","YARN"}) @InterfaceStability.Evolving public class AuthorizationException extends AccessControlException {
  private static final long serialVersionUID=1L;
  public AuthorizationException(){
    super();
  }
  public AuthorizationException(  String message){
    super(message);
  }
  /** 
 * Constructs a new exception with the specified cause and a detail message of <tt>(cause==null ? null : cause.toString())</tt> (which typically contains the class and detail message of <tt>cause</tt>).
 * @param cause the cause (which is saved for later retrieval by the{@link #getCause()} method).  (A <tt>null</tt> value ispermitted, and indicates that the cause is nonexistent or unknown.)
 */
  public AuthorizationException(  Throwable cause){
    super(cause);
  }
  private static StackTraceElement[] stackTrace=new StackTraceElement[0];
  @Override public StackTraceElement[] getStackTrace(){
    return stackTrace;
  }
  @Override public void printStackTrace(){
  }
  @Override public void printStackTrace(  PrintStream s){
  }
  @Override public void printStackTrace(  PrintWriter s){
  }
}
