/** 
 * This class is a utility to create a wrapper script that is platform appropriate.
 */
protected abstract class LocalWrapperScriptBuilder {
  private final Path wrapperScriptPath;
  /** 
 * Return the path for the wrapper script.
 * @return the path for the wrapper script
 */
  public Path getWrapperScriptPath(){
    return wrapperScriptPath;
  }
  /** 
 * Write out the wrapper script for the container launch script. This method will create the script at the configured wrapper script path.
 * @param launchDst the script to launch
 * @param pidFile the file that will hold the PID
 * @throws IOException if the wrapper script cannot be created
 * @see #getWrapperScriptPath
 */
  public void writeLocalWrapperScript(  Path launchDst,  Path pidFile) throws IOException {
    DataOutputStream out=null;
    PrintStream pout=null;
    try {
      out=lfs.create(wrapperScriptPath,EnumSet.of(CREATE,OVERWRITE));
      pout=new PrintStream(out,false,"UTF-8");
      writeLocalWrapperScript(launchDst,pidFile,pout);
    }
  finally {
      IOUtils.cleanupWithLogger(LOG,pout,out);
    }
  }
  /** 
 * Write out the wrapper script for the container launch script.
 * @param launchDst the script to launch
 * @param pidFile the file that will hold the PID
 * @param pout the stream to use to write out the wrapper script
 */
  protected abstract void writeLocalWrapperScript(  Path launchDst,  Path pidFile,  PrintStream pout);
  /** 
 * Create an instance for the given container working directory.
 * @param containerWorkDir the working directory for the container
 */
  protected LocalWrapperScriptBuilder(  Path containerWorkDir){
    this.wrapperScriptPath=new Path(containerWorkDir,Shell.appendScriptExtension("default_container_executor"));
  }
}
