/** 
 * Invokes an operation on an MBean.
 * @param onameStr The name of the MBean.
 * @param operation The name of the operation to invoke.
 * @param parameters An array of Strings containing the parameters to theoperation. They will be converted to the appropriate types to call the requested operation.
 * @return The value returned by the requested operation.
 */
private Object invokeOperationInternal(String onameStr,String operation,String[] parameters) throws OperationsException, MBeanException, ReflectionException {
  ObjectName oname=new ObjectName(onameStr);
  MBeanOperationInfo methodInfo=registry.getMethodInfo(oname,operation);
  MBeanParameterInfo[] signature=methodInfo.getSignature();
  String[] signatureTypes=new String[signature.length];
  Object[] values=new Object[signature.length];
  for (int i=0; i < signature.length; i++) {
    MBeanParameterInfo pi=signature[i];
    signatureTypes[i]=pi.getType();
    values[i]=registry.convertValue(pi.getType(),parameters[i]);
  }
  return mBeanServer.invoke(oname,operation,values,signatureTypes);
}
