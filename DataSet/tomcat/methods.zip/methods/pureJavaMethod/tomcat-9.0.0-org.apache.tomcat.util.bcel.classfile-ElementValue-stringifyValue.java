public abstract String stringifyValue();
