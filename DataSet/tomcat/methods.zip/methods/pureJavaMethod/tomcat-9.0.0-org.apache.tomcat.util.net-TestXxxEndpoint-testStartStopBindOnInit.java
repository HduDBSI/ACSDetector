@Test public void testStartStopBindOnInit() throws Exception {
  Tomcat tomcat=getTomcatInstance();
  File appDir=new File(getBuildDirectory(),"webapps/examples");
  tomcat.addWebapp(null,"/examples",appDir.getAbsolutePath());
  tomcat.start();
  int port=getPort();
  tomcat.getConnector().stop();
  Exception e=null;
  ServerSocket s=null;
  long pool=0;
  long nativeSocket=0;
  boolean isApr=tomcat.getConnector().getProtocolHandlerClassName().contains("Apr");
  try {
    if (isApr) {
      pool=createAprPool();
      assertTrue(pool != 0);
      nativeSocket=createAprSocket(port,pool);
      assertTrue(nativeSocket != 0);
    }
 else {
      s=new ServerSocket(port,100,InetAddress.getByName("localhost"));
    }
  }
 catch (  Exception e1) {
    e=e1;
  }
 finally {
    try {
      if (isApr) {
        destroyAprSocket(nativeSocket,pool);
      }
 else       if (s != null) {
        s.close();
      }
    }
 catch (    Exception e2) {
    }
  }
  if (e != null) {
    log.info("Exception was",e);
  }
  assertNotNull(e);
  tomcat.getConnector().start();
}
