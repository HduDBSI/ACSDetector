/** 
 * Gets the minimum amount of time an object may sit idle in the pool before it is eligible for eviction by the idle object evictor (if any - see  {@link #setTimeBetweenEvictionRunsMillis(long)}), with the extra condition that at least  {@code minIdle} objectinstances remain in the pool. This setting is overridden by {@link #getMinEvictableIdleTimeMillis} (that is, if{@link #getMinEvictableIdleTimeMillis} is positive, then{@link #getSoftMinEvictableIdleTimeMillis} is ignored).
 * @return minimum amount of time an object may sit idle in the pool beforeit is eligible for eviction if minIdle instances are available
 * @see #setSoftMinEvictableIdleTimeMillis
 * @deprecated Use {@link #getSoftMinEvictableIdleTime()}.
 */
@Deprecated public final long getSoftMinEvictableIdleTimeMillis(){
  return softMinEvictableIdleDuration.toMillis();
}
