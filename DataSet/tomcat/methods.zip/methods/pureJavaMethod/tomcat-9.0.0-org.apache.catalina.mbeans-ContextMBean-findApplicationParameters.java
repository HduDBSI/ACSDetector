/** 
 * Return the set of application parameters for this application.
 * @return a string array with a representation of each parameter
 * @throws MBeanException propagated from the managed resource access
 */
public String[] findApplicationParameters() throws MBeanException {
  Context context=doGetManagedResource();
  ApplicationParameter[] params=context.findApplicationParameters();
  String[] stringParams=new String[params.length];
  for (int counter=0; counter < params.length; counter++) {
    stringParams[counter]=params[counter].toString();
  }
  return stringParams;
}
