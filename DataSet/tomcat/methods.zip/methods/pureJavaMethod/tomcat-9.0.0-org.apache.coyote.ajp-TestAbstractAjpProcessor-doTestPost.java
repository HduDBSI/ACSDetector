public void doTestPost(boolean multipleCL,int expectedStatus,String expectedMessage) throws Exception {
  getTomcatInstanceTestWebapp(false,true);
  SimpleAjpClient ajpClient=new SimpleAjpClient();
  ajpClient.setPort(getPort());
  ajpClient.connect();
  validateCpong(ajpClient.cping());
  ajpClient.setUri("/test/echo-params.jsp");
  ajpClient.setMethod("POST");
  TesterAjpMessage forwardMessage=ajpClient.createForwardMessage();
  forwardMessage.addHeader(0xA008,"9");
  if (multipleCL) {
    forwardMessage.addHeader(0xA008,"99");
  }
  forwardMessage.addHeader(0xA007,"application/x-www-form-urlencoded");
  forwardMessage.end();
  TesterAjpMessage bodyMessage=ajpClient.createBodyMessage("test=data".getBytes());
  TesterAjpMessage responseHeaders=ajpClient.sendMessage(forwardMessage,bodyMessage);
  validateResponseHeaders(responseHeaders,expectedStatus,expectedMessage);
  if (expectedStatus == HttpServletResponse.SC_OK) {
    TesterAjpMessage responseBody=ajpClient.readMessage();
    validateResponseBody(responseBody,"test - data");
    validateResponseEnd(ajpClient.readMessage(),true);
    validateCpong(ajpClient.cping());
  }
 else {
    validateResponseEnd(ajpClient.readMessage(),false);
  }
  ajpClient.disconnect();
}
