private boolean checkReset() throws IOException, Http2Exception {
  while (true) {
    if (output.getTrace().startsWith("3-RST-[3]\n")) {
      return true;
    }
 else     if (output.getTrace().startsWith("3-RST-[")) {
      output.clearTrace();
      parser.readFrame(true);
    }
 else {
      return false;
    }
  }
}
