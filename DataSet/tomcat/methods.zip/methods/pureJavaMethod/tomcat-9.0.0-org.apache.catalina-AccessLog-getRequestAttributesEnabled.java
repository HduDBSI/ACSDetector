/** 
 * @see #setRequestAttributesEnabled(boolean)
 * @return <code>true</code> if the attributes will be logged, otherwise<code>false</code>
 */
public boolean getRequestAttributesEnabled();
