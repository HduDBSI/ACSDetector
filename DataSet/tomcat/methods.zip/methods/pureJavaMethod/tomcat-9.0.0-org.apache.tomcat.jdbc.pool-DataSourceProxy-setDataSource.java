/** 
 * {@inheritDoc}
 */
@Override public void setDataSource(Object ds){
  getPoolProperties().setDataSource(ds);
}
