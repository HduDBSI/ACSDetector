@Test public void testKeyPass() throws Exception {
  TesterSupport.configureClientSsl();
  Tomcat tomcat=getTomcatInstance();
  File appDir=new File(getBuildDirectory(),"webapps/examples");
  org.apache.catalina.Context ctxt=tomcat.addWebapp(null,"/examples",appDir.getAbsolutePath());
  ctxt.addApplicationListener(WsContextListener.class.getName());
  TesterSupport.initSsl(tomcat,TesterSupport.LOCALHOST_KEYPASS_JKS,TesterSupport.JKS_PASS,TesterSupport.JKS_KEY_PASS);
  tomcat.start();
  ByteChunk res=getUrl("https://localhost:" + getPort() + "/examples/servlets/servlet/HelloWorldExample");
  assertTrue(res.toString().indexOf("<a href=\"../helloworld.html\">") > 0);
  assertTrue("Checking no client issuer has been requested",TesterSupport.getLastClientAuthRequestedIssuerCount() == 0);
}
