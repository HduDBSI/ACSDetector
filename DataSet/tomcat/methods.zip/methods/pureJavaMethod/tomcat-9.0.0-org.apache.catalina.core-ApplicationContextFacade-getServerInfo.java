@Override public String getServerInfo(){
  if (SecurityUtil.isPackageProtectionEnabled()) {
    return (String)doPrivileged("getServerInfo",null);
  }
 else {
    return context.getServerInfo();
  }
}
