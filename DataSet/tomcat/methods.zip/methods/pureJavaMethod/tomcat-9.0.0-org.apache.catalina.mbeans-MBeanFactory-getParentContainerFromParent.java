/** 
 * Get Parent Container to add its child component from parent's ObjectName
 */
private Container getParentContainerFromParent(ObjectName pname) throws Exception {
  String type=pname.getKeyProperty("type");
  String j2eeType=pname.getKeyProperty("j2eeType");
  Service service=getService(pname);
  StandardEngine engine=(StandardEngine)service.getContainer();
  if ((j2eeType != null) && (j2eeType.equals("WebModule"))) {
    String name=pname.getKeyProperty("name");
    name=name.substring(2);
    int i=name.indexOf('/');
    String hostName=name.substring(0,i);
    String path=name.substring(i);
    Container host=engine.findChild(hostName);
    String pathStr=getPathStr(path);
    Container context=host.findChild(pathStr);
    return context;
  }
 else   if (type != null) {
    if (type.equals("Engine")) {
      return engine;
    }
 else     if (type.equals("Host")) {
      String hostName=pname.getKeyProperty("host");
      Container host=engine.findChild(hostName);
      return host;
    }
  }
  return null;
}
