@Override public void messageReceived(ChannelMessage msg){
  boolean process=true;
  if (okToProcess(msg.getOptions())) {
    process=((msg.getMessage().getLength() != TCP_PING_DATA.length) || (!Arrays.equals(TCP_PING_DATA,msg.getMessage().getBytes())));
  }
  if (process)   super.messageReceived(msg);
 else   if (log.isDebugEnabled())   log.debug("Received a TCP ping packet:" + msg);
}
