@Override public void visit(Node.CustomTag n) throws JasperException {
  if (!n.implementsSimpleTag()) {
    String name=createTagHandlerPoolName(n.getPrefix(),n.getLocalName(),n.getAttributes(),n.getNamedAttributeNodes(),n.hasEmptyBody());
    n.setTagHandlerPoolName(name);
    if (!names.contains(name)) {
      names.add(name);
    }
  }
  visitBody(n);
}
