private int extractUriElement(String body,int startIx,String elementName){
  String detector=ELEMENT_HEAD + elementName + " ";
  int iStart=body.indexOf(detector,startIx);
  if (iStart > -1) {
    int iEnd=body.indexOf(ELEMENT_TAIL,iStart);
    if (iEnd < 0) {
      throw new IllegalArgumentException("Response body check failure.\n" + "element [" + detector + "] is not terminated with ["+ ELEMENT_TAIL+ "]\nActual: ["+ body+ "]");
    }
    String element=body.substring(iStart,iEnd);
    bodyUriElements.add(element);
    iStart+=element.length();
  }
  return iStart;
}
