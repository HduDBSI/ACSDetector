@Override public List<String> decode(String str) throws DecodeException {
  List<String> lst=new ArrayList<>(1);
  str=str.substring(1,str.length() - 1);
  String[] strings=str.split(",");
  for (  String t : strings) {
    lst.add(t);
  }
  return lst;
}
