/** 
 * Executes the compilation.
 */
@Override public void execute(){
  if (log.isDebugEnabled()) {
    log.debug("execute() starting for " + pages.size() + " pages.");
  }
  try {
    if (uriRoot == null) {
      if (pages.size() == 0) {
        throw new JasperException(Localizer.getMessage("jsp.error.jspc.missingTarget"));
      }
      String firstJsp=pages.get(0);
      File firstJspF=new File(firstJsp);
      if (!firstJspF.exists()) {
        throw new JasperException(Localizer.getMessage("jspc.error.fileDoesNotExist",firstJsp));
      }
      locateUriRoot(firstJspF);
    }
    if (uriRoot == null) {
      throw new JasperException(Localizer.getMessage("jsp.error.jspc.no_uriroot"));
    }
    File uriRootF=new File(uriRoot);
    if (!uriRootF.isDirectory()) {
      throw new JasperException(Localizer.getMessage("jsp.error.jspc.uriroot_not_dir"));
    }
    if (loader == null) {
      loader=initClassLoader();
    }
    if (context == null) {
      initServletContext(loader);
    }
    if (pages.size() == 0) {
      scanFiles(uriRootF);
    }
    initWebXml();
    int errorCount=0;
    long start=System.currentTimeMillis();
    for (    String nextjsp : pages) {
      File fjsp=new File(nextjsp);
      if (!fjsp.isAbsolute()) {
        fjsp=new File(uriRootF,nextjsp);
      }
      if (!fjsp.exists()) {
        if (log.isWarnEnabled()) {
          log.warn(Localizer.getMessage("jspc.error.fileDoesNotExist",fjsp.toString()));
        }
        continue;
      }
      String s=fjsp.getAbsolutePath();
      if (s.startsWith(uriRoot)) {
        nextjsp=s.substring(uriRoot.length());
      }
      if (nextjsp.startsWith("." + File.separatorChar)) {
        nextjsp=nextjsp.substring(2);
      }
      try {
        processFile(nextjsp);
      }
 catch (      JasperException e) {
        if (failFast) {
          throw e;
        }
        errorCount++;
        log.error(nextjsp + ":" + e.getMessage());
      }
    }
    long time=System.currentTimeMillis() - start;
    String msg=Localizer.getMessage("jspc.compilation.result",Integer.toString(errorCount),Long.toString(time));
    if (failOnError && errorCount > 0) {
      System.out.println("Error Count: " + errorCount);
      throw new BuildException(msg);
    }
 else {
      log.info(msg);
    }
    completeWebXml();
    if (addWebXmlMappings) {
      mergeIntoWebXml();
    }
  }
 catch (  IOException ioe) {
    throw new BuildException(ioe);
  }
catch (  JasperException je) {
    if (failOnError) {
      throw new BuildException(je);
    }
  }
 finally {
    if (loader != null) {
      LogFactory.release(loader);
    }
  }
}
