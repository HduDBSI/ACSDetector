@Override protected Struct initialValue(){
  return new Struct();
}
