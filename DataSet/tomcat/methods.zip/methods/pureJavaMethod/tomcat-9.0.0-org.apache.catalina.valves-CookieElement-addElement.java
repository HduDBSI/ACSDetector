@Override public void addElement(CharArrayWriter buf,Date date,Request request,Response response,long time){
  Cookie[] c=request.getCookies();
  for (int i=0; c != null && i < c.length; i++) {
    if (name.equals(c[i].getName())) {
      buf.append(wrap(c[i].getValue()));
    }
  }
}
