/** 
 * Provides a mechanism for sub-classes to update the component state. Calling this method will automatically fire any associated {@link Lifecycle} event. It will also check that any attempted statetransition is valid for a sub-class.
 * @param state The new state for this component
 * @param data  The data to pass to the associated {@link Lifecycle} event
 * @throws LifecycleException when attempting to set an invalid state
 */
protected synchronized void setState(LifecycleState state,Object data) throws LifecycleException {
  setStateInternal(state,data,true);
}
