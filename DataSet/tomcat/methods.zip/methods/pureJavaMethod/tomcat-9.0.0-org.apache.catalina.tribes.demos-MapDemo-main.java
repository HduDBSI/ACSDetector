@SuppressWarnings("unused") public static void main(String[] args) throws Exception {
  long start=System.currentTimeMillis();
  ManagedChannel channel=(ManagedChannel)ChannelCreator.createChannel(args);
  String mapName="MapDemo";
  if (args.length > 0 && (!args[args.length - 1].startsWith("-"))) {
    mapName=args[args.length - 1];
  }
  channel.start(Channel.DEFAULT);
  Runtime.getRuntime().addShutdownHook(new Shutdown(channel));
  new MapDemo(channel,mapName);
  System.out.println("System test complete, time to start=" + (System.currentTimeMillis() - start) + " ms. Sleeping to let threads finish.");
  Thread.sleep(60 * 1000 * 60);
}
