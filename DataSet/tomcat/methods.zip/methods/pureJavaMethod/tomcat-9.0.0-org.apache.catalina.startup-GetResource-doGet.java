@Override public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException {
  URL url=req.getServletContext().getResource("/WEB-INF/web.xml");
  res.getWriter().write("The URL obtained for /WEB-INF/web.xml was ");
  if (url == null) {
    res.getWriter().write("null");
  }
 else {
    res.getWriter().write(url.toString() + "\n");
    res.getWriter().write("The first 20 characters of that resource are:\n");
    URLConnection conn=url.openConnection();
    char cbuf[]=new char[20];
    int read=0;
    try (InputStream is=conn.getInputStream();Reader reader=new InputStreamReader(is)){
      while (read < 20) {
        int len=reader.read(cbuf,read,cbuf.length - read);
        res.getWriter().write(cbuf,read,len);
        read=read + len;
      }
    }
   }
}
