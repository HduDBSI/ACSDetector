/** 
 * Only takes the user name into account.
 */
@Override public int hashCode(){
  return Objects.hash(name);
}
