@Override public <T extends EventListener>T createListener(Class<T> c) throws ServletException {
  try {
    @SuppressWarnings("unchecked") T listener=(T)context.getInstanceManager().newInstance(c);
    if (listener instanceof ServletContextListener || listener instanceof ServletContextAttributeListener || listener instanceof ServletRequestListener|| listener instanceof ServletRequestAttributeListener|| listener instanceof HttpSessionListener|| listener instanceof HttpSessionIdListener|| listener instanceof HttpSessionAttributeListener) {
      return listener;
    }
    throw new IllegalArgumentException(sm.getString("applicationContext.addListener.iae.wrongType",listener.getClass().getName()));
  }
 catch (  InvocationTargetException e) {
    ExceptionUtils.handleThrowable(e.getCause());
    throw new ServletException(e);
  }
catch (  IllegalAccessException|NamingException|InstantiationException|NoSuchMethodException e) {
    throw new ServletException(e);
  }
}
