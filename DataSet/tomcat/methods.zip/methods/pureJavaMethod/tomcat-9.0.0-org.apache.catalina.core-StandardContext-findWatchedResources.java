/** 
 * @return the set of watched resources for this Context. If none aredefined, a zero length array will be returned.
 */
@Override public String[] findWatchedResources(){
synchronized (watchedResourcesLock) {
    return watchedResources;
  }
}
