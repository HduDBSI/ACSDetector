/** 
 * Bind current thread, both for CL purposes and for JNDI ENC support during : startup, shutdown and reloading of the context.
 * @return the previous context class loader
 */
protected ClassLoader bindThread(){
  ClassLoader oldContextClassLoader=bind(false,null);
  if (isUseNaming()) {
    try {
      ContextBindings.bindThread(this,getNamingToken());
    }
 catch (    NamingException e) {
    }
  }
  return oldContextClassLoader;
}
