public void setCommitted(boolean v){
  if (v && !this.commited) {
    this.commitTime=System.currentTimeMillis();
  }
  this.commited=v;
}
