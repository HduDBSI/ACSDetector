/** 
 * Register all cross context sessions inside endAccess. Use a list with contains check, that the Portlet API can include a lot of fragments from same or different applications with session changes.
 * @param session cross context session
 */
public void registerReplicationSession(DeltaSession session){
  List<DeltaSession> sessions=crossContextSessions.get();
  if (sessions != null) {
    if (!sessions.contains(session)) {
      if (log.isDebugEnabled()) {
        log.debug(sm.getString("ReplicationValve.crossContext.registerSession",session.getIdInternal(),session.getManager().getContext().getName()));
      }
      sessions.add(session);
    }
  }
}
