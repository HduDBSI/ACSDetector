@Test public void test304WithBody() throws Exception {
  Tomcat tomcat=getTomcatInstance();
  Context ctx=tomcat.addContext("",null);
  Tomcat.addServlet(ctx,"bug55453",new Tester304WithBodyServlet());
  ctx.addServletMappingDecoded("/","bug55453");
  tomcat.start();
  SimpleAjpClient ajpClient=new SimpleAjpClient();
  ajpClient.setPort(getPort());
  ajpClient.connect();
  validateCpong(ajpClient.cping());
  TesterAjpMessage forwardMessage=ajpClient.createForwardMessage();
  forwardMessage.end();
  TesterAjpMessage responseHeaders=ajpClient.sendMessage(forwardMessage,null);
  validateResponseHeaders(responseHeaders,304,"304");
  validateResponseEnd(ajpClient.readMessage(),true);
  validateCpong(ajpClient.cping());
  ajpClient.disconnect();
}
