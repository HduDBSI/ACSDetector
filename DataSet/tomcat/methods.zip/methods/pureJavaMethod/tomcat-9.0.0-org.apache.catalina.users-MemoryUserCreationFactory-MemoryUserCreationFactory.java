public MemoryUserCreationFactory(MemoryUserDatabase database){
  this.database=database;
}
