/** 
 * Returns the preflight response cache time in seconds.
 * @return Time to cache in seconds.
 */
public long getPreflightMaxAge(){
  return preflightMaxAge;
}
