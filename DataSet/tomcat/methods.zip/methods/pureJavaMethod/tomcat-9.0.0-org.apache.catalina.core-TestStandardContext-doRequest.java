private Exception doRequest(String uri,boolean allowCasualMultipart,boolean makeMultipartRequest){
  try {
    init();
    context.setAllowCasualMultipartParsing(allowCasualMultipart);
    connect();
    String[] request;
    if (makeMultipartRequest) {
      String boundary="--simpleboundary";
      String content="--" + boundary + CRLF+ "Content-Disposition: form-data; name=\"name\""+ CRLF+ CRLF+ "value"+ CRLF+ "--"+ boundary+ "--"+ CRLF;
      content=new String(content.getBytes("UTF-8"),"ASCII");
      request=new String[]{"POST http://localhost:" + getPort() + uri+ " HTTP/1.1"+ CRLF+ "Host: localhost:"+ getPort()+ CRLF+ "Connection: close"+ CRLF+ "Content-Type: multipart/form-data; boundary="+ boundary+ CRLF+ "Content-Length: "+ content.length()+ CRLF+ CRLF+ content+ CRLF};
    }
 else {
      request=new String[]{"GET http://localhost:" + getPort() + uri+ " HTTP/1.1"+ CRLF+ "Host: localhost:"+ getPort()+ CRLF+ "Connection: close"+ CRLF+ CRLF};
    }
    setRequest(request);
    processRequest();
    disconnect();
  }
 catch (  Exception e) {
    return e;
  }
  return null;
}
