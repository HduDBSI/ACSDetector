SDEInstaller(File inClassFile,byte[] sdeAttr) throws IOException {
  if (!inClassFile.exists()) {
    throw new FileNotFoundException("no such file: " + inClassFile);
  }
  this.sdeAttr=sdeAttr;
  orig=readWhole(inClassFile);
  gen=new byte[orig.length + sdeAttr.length + 100];
}
