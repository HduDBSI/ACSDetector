/** 
 * Obtain and return the value of a specific attribute of this MBean.
 * @param name Name of the requested attribute
 * @exception AttributeNotFoundException if this attribute is notsupported by this MBean
 * @exception MBeanException if the initializer of an objectthrows an exception
 * @exception ReflectionException if a Java reflection exceptionoccurs when invoking the getter
 */
@Override public Object getAttribute(String name) throws AttributeNotFoundException, MBeanException, ReflectionException {
  if (name == null) {
    throw new RuntimeOperationsException(new IllegalArgumentException("Attribute name is null"),"Attribute name is null");
  }
  if ((resource instanceof DynamicMBean) && !(resource instanceof BaseModelMBean)) {
    return ((DynamicMBean)resource).getAttribute(name);
  }
  Method m=managedBean.getGetter(name,this,resource);
  Object result=null;
  try {
    Class<?> declaring=m.getDeclaringClass();
    if (declaring.isAssignableFrom(this.getClass())) {
      result=m.invoke(this,NO_ARGS_PARAM);
    }
 else {
      result=m.invoke(resource,NO_ARGS_PARAM);
    }
  }
 catch (  InvocationTargetException e) {
    Throwable t=e.getTargetException();
    if (t == null) {
      t=e;
    }
    if (t instanceof RuntimeException) {
      throw new RuntimeOperationsException((RuntimeException)t,"Exception invoking method " + name);
    }
 else     if (t instanceof Error) {
      throw new RuntimeErrorException((Error)t,"Error invoking method " + name);
    }
 else {
      throw new MBeanException(e,"Exception invoking method " + name);
    }
  }
catch (  Exception e) {
    throw new MBeanException(e,"Exception invoking method " + name);
  }
  return result;
}
