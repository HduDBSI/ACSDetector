/** 
 * End the access.
 */
@Override public void endAccess(){
  isNew=false;
  if (LAST_ACCESS_AT_START) {
    this.lastAccessedTime=this.thisAccessedTime;
    this.thisAccessedTime=System.currentTimeMillis();
  }
 else {
    this.thisAccessedTime=System.currentTimeMillis();
    this.lastAccessedTime=this.thisAccessedTime;
  }
  if (ACTIVITY_CHECK) {
    accessCount.decrementAndGet();
  }
}
