@Override protected void doGet(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
  TestAsyncContextImpl.track("DispatchingServletGet-");
  resp.flushBuffer();
  final boolean first=TrackingServlet.first;
  TrackingServlet.first=false;
  final AsyncContext ctxt=req.startAsync();
  TrackingListener listener=new TrackingListener(false,true,null);
  ctxt.addListener(listener);
  ctxt.setTimeout(3000);
  Runnable run=new Runnable(){
    @Override public void run(){
      if (first) {
        ctxt.dispatch("/stage1");
      }
 else {
        ctxt.dispatch("/stage2");
      }
    }
  }
;
  if ("y".equals(req.getParameter("useThread"))) {
    new Thread(run).start();
  }
 else {
    run.run();
  }
}
