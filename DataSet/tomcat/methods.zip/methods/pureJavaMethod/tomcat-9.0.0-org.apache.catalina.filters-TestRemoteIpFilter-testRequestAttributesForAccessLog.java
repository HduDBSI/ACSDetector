@Test public void testRequestAttributesForAccessLog() throws Exception {
  FilterDef filterDef=new FilterDef();
  filterDef.addInitParameter("protocolHeader","x-forwarded-proto");
  filterDef.addInitParameter("remoteIpHeader","x-my-forwarded-for");
  filterDef.addInitParameter("httpServerPort","8080");
  MockHttpServletRequest request=new MockHttpServletRequest();
  request.setRemoteAddr("192.168.0.10");
  request.setHeader("x-my-forwarded-for","140.211.11.130");
  request.setHeader("x-forwarded-proto","http");
  HttpServletRequest actualRequest=testRemoteIpFilter(filterDef,request).getRequest();
  Assert.assertEquals("org.apache.catalina.AccessLog.ServerPort",Integer.valueOf(8080),actualRequest.getAttribute(AccessLog.SERVER_PORT_ATTRIBUTE));
  Assert.assertEquals("org.apache.catalina.AccessLog.RemoteAddr","140.211.11.130",actualRequest.getAttribute(AccessLog.REMOTE_ADDR_ATTRIBUTE));
  Assert.assertEquals("org.apache.catalina.AccessLog.RemoteHost","140.211.11.130",actualRequest.getAttribute(AccessLog.REMOTE_HOST_ATTRIBUTE));
}
