@Override public synchronized void sendMessage(Member[] destination,ChannelMessage msg) throws ChannelException {
  long start=System.currentTimeMillis();
  this.setUdpBased((msg.getOptions() & Channel.SEND_OPTIONS_UDP) == Channel.SEND_OPTIONS_UDP);
  byte[] data=XByteBuffer.createDataPackage((ChannelData)msg);
  NioSender[] senders=setupForSend(destination);
  connect(senders);
  setData(senders,data);
  int remaining=senders.length;
  ChannelException cx=null;
  try {
    long delta=System.currentTimeMillis() - start;
    boolean waitForAck=(Channel.SEND_OPTIONS_USE_ACK & msg.getOptions()) == Channel.SEND_OPTIONS_USE_ACK;
    while ((remaining > 0) && (delta < getTimeout())) {
      try {
        remaining-=doLoop(selectTimeout,getMaxRetryAttempts(),waitForAck,msg);
      }
 catch (      Exception x) {
        if (log.isTraceEnabled())         log.trace("Error sending message",x);
        int faulty=(cx == null) ? 0 : cx.getFaultyMembers().length;
        if (cx == null) {
          if (x instanceof ChannelException)           cx=(ChannelException)x;
 else           cx=new ChannelException(sm.getString("parallelNioSender.send.failed"),x);
        }
 else {
          if (x instanceof ChannelException) {
            cx.addFaultyMember(((ChannelException)x).getFaultyMembers());
          }
        }
        if (faulty < cx.getFaultyMembers().length) {
          remaining-=(cx.getFaultyMembers().length - faulty);
        }
      }
      if (cx != null && cx.getFaultyMembers().length == remaining)       throw cx;
      delta=System.currentTimeMillis() - start;
    }
    if (remaining > 0) {
      ChannelException cxtimeout=new ChannelException(sm.getString("parallelNioSender.operation.timedout",Long.toString(getTimeout())));
      if (cx == null) {
        cx=new ChannelException(sm.getString("parallelNioSender.operation.timedout",Long.toString(getTimeout())));
      }
      for (int i=0; i < senders.length; i++) {
        if (!senders[i].isComplete()) {
          cx.addFaultyMember(senders[i].getDestination(),cxtimeout);
        }
      }
      throw cx;
    }
 else     if (cx != null) {
      throw cx;
    }
  }
 catch (  Exception x) {
    try {
      this.disconnect();
    }
 catch (    Exception e) {
    }
    if (x instanceof ChannelException)     throw (ChannelException)x;
 else     throw new ChannelException(x);
  }
}
