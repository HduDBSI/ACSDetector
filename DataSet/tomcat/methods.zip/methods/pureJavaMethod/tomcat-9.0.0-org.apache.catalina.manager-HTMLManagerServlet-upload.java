protected String upload(HttpServletRequest request,StringManager smClient){
  String message="";
  try {
    while (true) {
      Part warPart=request.getPart("deployWar");
      if (warPart == null) {
        message=smClient.getString("htmlManagerServlet.deployUploadNoFile");
        break;
      }
      String filename=warPart.getSubmittedFileName();
      if (!filename.toLowerCase(Locale.ENGLISH).endsWith(".war")) {
        message=smClient.getString("htmlManagerServlet.deployUploadNotWar",filename);
        break;
      }
      if (filename.lastIndexOf('\\') >= 0) {
        filename=filename.substring(filename.lastIndexOf('\\') + 1);
      }
      if (filename.lastIndexOf('/') >= 0) {
        filename=filename.substring(filename.lastIndexOf('/') + 1);
      }
      File file=new File(host.getAppBaseFile(),filename);
      if (file.exists()) {
        message=smClient.getString("htmlManagerServlet.deployUploadWarExists",filename);
        break;
      }
      ContextName cn=new ContextName(filename,true);
      String name=cn.getName();
      if ((host.findChild(name) != null) && !isDeployed(name)) {
        message=smClient.getString("htmlManagerServlet.deployUploadInServerXml",filename);
        break;
      }
      if (isServiced(name)) {
        message=smClient.getString("managerServlet.inService",name);
      }
 else {
        addServiced(name);
        try {
          warPart.write(file.getAbsolutePath());
          check(name);
        }
  finally {
          removeServiced(name);
        }
      }
      break;
    }
  }
 catch (  Exception e) {
    message=smClient.getString("htmlManagerServlet.deployUploadFail",e.getMessage());
    log(message,e);
  }
  return message;
}
