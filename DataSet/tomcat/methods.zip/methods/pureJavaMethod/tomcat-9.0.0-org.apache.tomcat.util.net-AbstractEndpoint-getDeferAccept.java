protected abstract boolean getDeferAccept();
