private void generateCustomStart(Node.CustomTag n,TagHandlerInfo handlerInfo,String tagHandlerVar,String tagEvalVar,String tagPushBodyCountVar) throws JasperException {
  Class<?> tagHandlerClass=handlerInfo.getTagHandlerClass();
  out.printin("//  ");
  out.println(n.getQName());
  n.setBeginJavaLine(out.getJavaLine());
  declareScriptingVars(n,VariableInfo.AT_BEGIN);
  saveScriptingVars(n,VariableInfo.AT_BEGIN);
  String tagHandlerClassName=tagHandlerClass.getCanonicalName();
  if (isPoolingEnabled && !(n.implementsJspIdConsumer())) {
    out.printin(tagHandlerClassName);
    out.print(" ");
    out.print(tagHandlerVar);
    out.print(" = ");
    out.print("(");
    out.print(tagHandlerClassName);
    out.print(") ");
    out.print(n.getTagHandlerPoolName());
    out.print(".get(");
    out.print(tagHandlerClassName);
    out.println(".class);");
    out.printin("boolean ");
    out.print(tagHandlerVar);
    out.println("_reused = false;");
  }
 else {
    writeNewInstance(tagHandlerVar,tagHandlerClassName);
  }
  out.printil("try {");
  out.pushIndent();
  generateSetters(n,tagHandlerVar,handlerInfo,false);
  if (n.implementsTryCatchFinally()) {
    out.printin("int[] ");
    out.print(tagPushBodyCountVar);
    out.println(" = new int[] { 0 };");
    out.printil("try {");
    out.pushIndent();
  }
  out.printin("int ");
  out.print(tagEvalVar);
  out.print(" = ");
  out.print(tagHandlerVar);
  out.println(".doStartTag();");
  if (!n.implementsBodyTag()) {
    syncScriptingVars(n,VariableInfo.AT_BEGIN);
  }
  if (!n.hasEmptyBody()) {
    out.printin("if (");
    out.print(tagEvalVar);
    out.println(" != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {");
    out.pushIndent();
    declareScriptingVars(n,VariableInfo.NESTED);
    saveScriptingVars(n,VariableInfo.NESTED);
    if (n.implementsBodyTag()) {
      out.printin("if (");
      out.print(tagEvalVar);
      out.println(" != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {");
      out.pushIndent();
      if (n.implementsTryCatchFinally()) {
        out.printin(tagPushBodyCountVar);
        out.println("[0]++;");
      }
 else       if (pushBodyCountVar != null) {
        out.printin(pushBodyCountVar);
        out.println("[0]++;");
      }
      out.printin("out = org.apache.jasper.runtime.JspRuntimeLibrary.startBufferedBody(");
      out.print("_jspx_page_context, ");
      out.print(tagHandlerVar);
      out.println(");");
      out.popIndent();
      out.printil("}");
      syncScriptingVars(n,VariableInfo.AT_BEGIN);
      syncScriptingVars(n,VariableInfo.NESTED);
    }
 else {
      syncScriptingVars(n,VariableInfo.NESTED);
    }
    if (n.implementsIterationTag()) {
      out.printil("do {");
      out.pushIndent();
    }
  }
  n.setEndJavaLine(out.getJavaLine());
}
