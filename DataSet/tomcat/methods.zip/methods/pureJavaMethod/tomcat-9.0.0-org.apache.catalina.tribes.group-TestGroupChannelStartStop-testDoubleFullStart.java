@Test public void testDoubleFullStart() throws Exception {
  int count=0;
  try {
    channel.start(Channel.DEFAULT);
    count++;
  }
 catch (  Exception x) {
    x.printStackTrace();
  }
  try {
    channel.start(Channel.DEFAULT);
    count++;
  }
 catch (  Exception x) {
    x.printStackTrace();
  }
  assertEquals(count,2);
  channel.stop(Channel.DEFAULT);
}
