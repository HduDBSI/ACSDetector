@Override public int hashCode(){
  return (member != null) ? member.hashCode() : 0;
}
