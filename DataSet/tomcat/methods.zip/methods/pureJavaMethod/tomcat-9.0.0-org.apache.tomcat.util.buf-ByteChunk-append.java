/** 
 * Add data to the buffer.
 * @param from the ByteBuffer with the data
 * @throws IOException Writing overflow data to the output channel failed
 */
public void append(ByteBuffer from) throws IOException {
  int len=from.remaining();
  makeSpace(len);
  if (limit < 0) {
    from.get(buff,end,len);
    end+=len;
    return;
  }
  if (len == limit && end == start && out != null) {
    out.realWriteBytes(from);
    from.position(from.limit());
    return;
  }
  if (len <= limit - end) {
    from.get(buff,end,len);
    end+=len;
    return;
  }
  int avail=limit - end;
  from.get(buff,end,avail);
  end+=avail;
  flushBuffer();
  int fromLimit=from.limit();
  int remain=len - avail;
  avail=limit - end;
  while (remain >= avail) {
    from.limit(from.position() + avail);
    out.realWriteBytes(from);
    from.position(from.limit());
    remain=remain - avail;
  }
  from.limit(fromLimit);
  from.get(buff,end,remain);
  end+=remain;
}
