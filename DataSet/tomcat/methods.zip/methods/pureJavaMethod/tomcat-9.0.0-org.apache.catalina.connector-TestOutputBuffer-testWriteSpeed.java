@Test public void testWriteSpeed() throws Exception {
  Tomcat tomcat=getTomcatInstance();
  Context root=tomcat.addContext("",TEMP_DIR);
  for (int i=1; i <= WritingServlet.EXPECTED_CONTENT_LENGTH; i*=10) {
    WritingServlet servlet=new WritingServlet(i);
    Tomcat.addServlet(root,"servlet" + i,servlet);
    root.addServletMappingDecoded("/servlet" + i,"servlet" + i);
  }
  tomcat.start();
  ByteChunk bc=new ByteChunk();
  for (int i=1; i <= WritingServlet.EXPECTED_CONTENT_LENGTH; i*=10) {
    int rc=getUrl("http://localhost:" + getPort() + "/servlet"+ i,bc,null,null);
    assertEquals(HttpServletResponse.SC_OK,rc);
    assertEquals(WritingServlet.EXPECTED_CONTENT_LENGTH,bc.getLength());
    bc.recycle();
    rc=getUrl("http://localhost:" + getPort() + "/servlet"+ i+ "?useBuffer=y",bc,null,null);
    assertEquals(HttpServletResponse.SC_OK,rc);
    assertEquals(WritingServlet.EXPECTED_CONTENT_LENGTH,bc.getLength());
    bc.recycle();
  }
}
