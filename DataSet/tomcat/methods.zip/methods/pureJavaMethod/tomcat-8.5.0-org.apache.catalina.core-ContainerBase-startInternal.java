/** 
 * Start this component and implement the requirements of  {@link org.apache.catalina.util.LifecycleBase#startInternal()}.
 * @exception LifecycleException if this component detects a fatal errorthat prevents this component from being used
 */
@Override protected synchronized void startInternal() throws LifecycleException {
  logger=null;
  getLogger();
  Cluster cluster=getClusterInternal();
  if (cluster instanceof Lifecycle) {
    ((Lifecycle)cluster).start();
  }
  Realm realm=getRealmInternal();
  if (realm instanceof Lifecycle) {
    ((Lifecycle)realm).start();
  }
  Container children[]=findChildren();
  List<Future<Void>> results=new ArrayList<>();
  for (int i=0; i < children.length; i++) {
    results.add(startStopExecutor.submit(new StartChild(children[i])));
  }
  boolean fail=false;
  for (  Future<Void> result : results) {
    try {
      result.get();
    }
 catch (    Exception e) {
      log.error(sm.getString("containerBase.threadedStartFailed"),e);
      fail=true;
    }
  }
  if (fail) {
    throw new LifecycleException(sm.getString("containerBase.threadedStartFailed"));
  }
  if (pipeline instanceof Lifecycle)   ((Lifecycle)pipeline).start();
  setState(LifecycleState.STARTING);
  threadStart();
}
