/** 
 * @return the value of the deploy on startup flag.  If <code>true</code>, it indicatesthat this host's child webapps should be discovered and automatically deployed at startup time.
 */
@Override public boolean getDeployOnStartup(){
  return this.deployOnStartup;
}
