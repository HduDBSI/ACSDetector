/** 
 * Get the Coyote request.
 * @return the Coyote request object
 */
public org.apache.coyote.Request getCoyoteRequest(){
  return this.coyoteRequest;
}
