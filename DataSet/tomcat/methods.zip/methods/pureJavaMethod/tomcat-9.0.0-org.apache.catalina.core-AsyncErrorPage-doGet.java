@Override protected void doGet(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
  TestAsyncContextImpl.track("AsyncErrorPageGet-");
  final AsyncContext ctxt=req.getAsyncContext();
switch (mode) {
case COMPLETE:
    TestAsyncContextImpl.track("Complete-");
  ctxt.complete();
break;
case DISPATCH:
TestAsyncContextImpl.track("Dispatch-");
ctxt.dispatch("/error/nonasync");
break;
case NO_COMPLETE:
TestAsyncContextImpl.track("NoOp-");
break;
default :
break;
}
}
