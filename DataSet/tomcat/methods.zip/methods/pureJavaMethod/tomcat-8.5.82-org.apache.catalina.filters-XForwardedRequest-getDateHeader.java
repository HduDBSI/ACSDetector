@Override public long getDateHeader(String name){
  String value=getHeader(name);
  if (value == null) {
    return -1;
  }
  long date=FastHttpDateFormat.parseDate(value);
  if (date == -1) {
    throw new IllegalArgumentException(value);
  }
  return date;
}
