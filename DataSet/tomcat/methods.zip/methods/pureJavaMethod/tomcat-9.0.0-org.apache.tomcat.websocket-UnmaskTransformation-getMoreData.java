@Override public TransformationResult getMoreData(byte opCode,boolean fin,int rsv,ByteBuffer dest){
  while (payloadWritten < payloadLength && inputBuffer.remaining() > 0 && dest.hasRemaining()) {
    byte b=(byte)((inputBuffer.get() ^ mask[maskIndex]) & 0xFF);
    maskIndex++;
    if (maskIndex == 4) {
      maskIndex=0;
    }
    payloadWritten++;
    dest.put(b);
  }
  if (payloadWritten == payloadLength) {
    return TransformationResult.END_OF_FRAME;
  }
 else   if (inputBuffer.remaining() == 0) {
    return TransformationResult.UNDERFLOW;
  }
 else {
    return TransformationResult.OVERFLOW;
  }
}
