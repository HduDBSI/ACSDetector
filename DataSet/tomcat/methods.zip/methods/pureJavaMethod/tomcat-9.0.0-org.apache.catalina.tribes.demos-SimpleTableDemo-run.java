@Override public void run(){
  for (int i=0; i < 5; i++) {
    String key=random(5,0,0,true,true,null);
    map.put(key,new StringBuilder(key));
    dataModel.fireTableDataChanged();
    table.paint(table.getGraphics());
    try {
      Thread.sleep(500);
    }
 catch (    InterruptedException x) {
      Thread.interrupted();
    }
  }
}
