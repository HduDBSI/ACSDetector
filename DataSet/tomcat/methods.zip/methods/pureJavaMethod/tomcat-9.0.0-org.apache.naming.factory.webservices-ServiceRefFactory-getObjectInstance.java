/** 
 * Create a new serviceref instance.
 * @param obj The reference object describing the webservice
 */
@Override public Object getObjectInstance(Object obj,Name name,Context nameCtx,Hashtable<?,?> environment) throws Exception {
  if (obj instanceof ServiceRef) {
    Reference ref=(Reference)obj;
    ClassLoader tcl=Thread.currentThread().getContextClassLoader();
    if (tcl == null)     tcl=this.getClass().getClassLoader();
    ServiceFactory factory=ServiceFactory.newInstance();
    javax.xml.rpc.Service service=null;
    RefAddr tmp=ref.get(ServiceRef.SERVICE_INTERFACE);
    String serviceInterface=null;
    if (tmp != null)     serviceInterface=(String)tmp.getContent();
    tmp=ref.get(ServiceRef.WSDL);
    String wsdlRefAddr=null;
    if (tmp != null)     wsdlRefAddr=(String)tmp.getContent();
    Hashtable<String,QName> portComponentRef=new Hashtable<>();
    QName serviceQname=null;
    tmp=ref.get(ServiceRef.SERVICE_LOCAL_PART);
    if (tmp != null) {
      String serviceLocalPart=(String)tmp.getContent();
      tmp=ref.get(ServiceRef.SERVICE_NAMESPACE);
      if (tmp == null) {
        serviceQname=new QName(serviceLocalPart);
      }
 else {
        String serviceNamespace=(String)tmp.getContent();
        serviceQname=new QName(serviceNamespace,serviceLocalPart);
      }
    }
    Class<?> serviceInterfaceClass=null;
    if (serviceInterface == null) {
      if (serviceQname == null) {
        throw new NamingException("Could not create service-ref instance");
      }
      try {
        if (wsdlRefAddr == null) {
          service=factory.createService(serviceQname);
        }
 else {
          service=factory.createService(new URL(wsdlRefAddr),serviceQname);
        }
      }
 catch (      Exception e) {
        NamingException ex=new NamingException("Could not create service");
        ex.initCause(e);
        throw ex;
      }
    }
 else {
      try {
        serviceInterfaceClass=tcl.loadClass(serviceInterface);
      }
 catch (      ClassNotFoundException e) {
        NamingException ex=new NamingException("Could not load service Interface");
        ex.initCause(e);
        throw ex;
      }
      if (serviceInterfaceClass == null) {
        throw new NamingException("Could not load service Interface");
      }
      try {
        if (wsdlRefAddr == null) {
          if (!Service.class.isAssignableFrom(serviceInterfaceClass)) {
            throw new NamingException("service Interface should extend javax.xml.rpc.Service");
          }
          service=factory.loadService(serviceInterfaceClass);
        }
 else {
          service=factory.loadService(new URL(wsdlRefAddr),serviceInterfaceClass,new Properties());
        }
      }
 catch (      Exception e) {
        NamingException ex=new NamingException("Could not create service");
        ex.initCause(e);
        throw ex;
      }
    }
    if (service == null) {
      throw new NamingException("Cannot create service object");
    }
    serviceQname=service.getServiceName();
    serviceInterfaceClass=service.getClass();
    if (wsdlRefAddr != null) {
      try {
        WSDLFactory wsdlfactory=WSDLFactory.newInstance();
        WSDLReader reader=wsdlfactory.newWSDLReader();
        reader.setFeature("javax.wsdl.importDocuments",true);
        Definition def=reader.readWSDL((new URL(wsdlRefAddr)).toExternalForm());
        javax.wsdl.Service wsdlservice=def.getService(serviceQname);
        @SuppressWarnings("unchecked") Map<String,?> ports=wsdlservice.getPorts();
        Method m=serviceInterfaceClass.getMethod("setEndpointAddress",new Class[]{java.lang.String.class,java.lang.String.class});
        for (        String portName : ports.keySet()) {
          Port port=wsdlservice.getPort(portName);
          String endpoint=getSOAPLocation(port);
          m.invoke(service,new Object[]{port.getName(),endpoint});
          portComponentRef.put(endpoint,new QName(port.getName()));
        }
      }
 catch (      Exception e) {
        if (e instanceof InvocationTargetException) {
          Throwable cause=e.getCause();
          if (cause instanceof ThreadDeath) {
            throw (ThreadDeath)cause;
          }
          if (cause instanceof VirtualMachineError) {
            throw (VirtualMachineError)cause;
          }
        }
        NamingException ex=new NamingException("Error while reading Wsdl File");
        ex.initCause(e);
        throw ex;
      }
    }
    ServiceProxy proxy=new ServiceProxy(service);
    for (int i=0; i < ref.size(); i++)     if (ServiceRef.SERVICEENDPOINTINTERFACE.equals(ref.get(i).getType())) {
      String serviceendpoint="";
      String portlink="";
      serviceendpoint=(String)ref.get(i).getContent();
      if (ServiceRef.PORTCOMPONENTLINK.equals(ref.get(i + 1).getType())) {
        i++;
        portlink=(String)ref.get(i).getContent();
      }
      portComponentRef.put(serviceendpoint,new QName(portlink));
    }
    proxy.setPortComponentRef(portComponentRef);
    Class<?>[] serviceInterfaces=serviceInterfaceClass.getInterfaces();
    Class<?>[] interfaces=Arrays.copyOf(serviceInterfaces,serviceInterfaces.length + 1);
    interfaces[interfaces.length - 1]=javax.xml.rpc.Service.class;
    Object proxyInstance=null;
    try {
      proxyInstance=Proxy.newProxyInstance(tcl,interfaces,proxy);
    }
 catch (    IllegalArgumentException e) {
      proxyInstance=Proxy.newProxyInstance(tcl,serviceInterfaces,proxy);
    }
    if (((ServiceRef)ref).getHandlersSize() > 0) {
      HandlerRegistry handlerRegistry=service.getHandlerRegistry();
      List<String> soaproles=new ArrayList<>();
      while (((ServiceRef)ref).getHandlersSize() > 0) {
        HandlerRef handlerRef=((ServiceRef)ref).getHandler();
        HandlerInfo handlerInfo=new HandlerInfo();
        tmp=handlerRef.get(HandlerRef.HANDLER_CLASS);
        if ((tmp == null) || (tmp.getContent() == null))         break;
        Class<?> handlerClass=null;
        try {
          handlerClass=tcl.loadClass((String)tmp.getContent());
        }
 catch (        ClassNotFoundException e) {
          break;
        }
        List<QName> headers=new ArrayList<>();
        Hashtable<String,String> config=new Hashtable<>();
        List<String> portNames=new ArrayList<>();
        for (int i=0; i < handlerRef.size(); i++)         if (HandlerRef.HANDLER_LOCALPART.equals(handlerRef.get(i).getType())) {
          String localpart="";
          String namespace="";
          localpart=(String)handlerRef.get(i).getContent();
          if (HandlerRef.HANDLER_NAMESPACE.equals(handlerRef.get(i + 1).getType())) {
            i++;
            namespace=(String)handlerRef.get(i).getContent();
          }
          QName header=new QName(namespace,localpart);
          headers.add(header);
        }
 else         if (HandlerRef.HANDLER_PARAMNAME.equals(handlerRef.get(i).getType())) {
          String paramName="";
          String paramValue="";
          paramName=(String)handlerRef.get(i).getContent();
          if (HandlerRef.HANDLER_PARAMVALUE.equals(handlerRef.get(i + 1).getType())) {
            i++;
            paramValue=(String)handlerRef.get(i).getContent();
          }
          config.put(paramName,paramValue);
        }
 else         if (HandlerRef.HANDLER_SOAPROLE.equals(handlerRef.get(i).getType())) {
          String soaprole="";
          soaprole=(String)handlerRef.get(i).getContent();
          soaproles.add(soaprole);
        }
 else         if (HandlerRef.HANDLER_PORTNAME.equals(handlerRef.get(i).getType())) {
          String portName="";
          portName=(String)handlerRef.get(i).getContent();
          portNames.add(portName);
        }
        handlerInfo.setHandlerClass(handlerClass);
        handlerInfo.setHeaders(headers.toArray(new QName[headers.size()]));
        handlerInfo.setHandlerConfig(config);
        if (!portNames.isEmpty()) {
          for (          String portName : portNames) {
            initHandlerChain(new QName(portName),handlerRegistry,handlerInfo,soaproles);
          }
        }
 else {
          Enumeration<QName> e=portComponentRef.elements();
          while (e.hasMoreElements())           initHandlerChain(e.nextElement(),handlerRegistry,handlerInfo,soaproles);
        }
      }
    }
    return proxyInstance;
  }
  return null;
}
