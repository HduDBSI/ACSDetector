@Override public boolean equals(Object o){
  if (o == this)   return true;
  if (o instanceof InterceptorProperty) {
    InterceptorProperty other=(InterceptorProperty)o;
    return other.name.equals(this.name);
  }
  return false;
}
