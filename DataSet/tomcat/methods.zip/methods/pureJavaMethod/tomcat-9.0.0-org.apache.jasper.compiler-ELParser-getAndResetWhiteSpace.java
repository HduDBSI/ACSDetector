private String getAndResetWhiteSpace(){
  String result=whiteSpace;
  whiteSpace="";
  return result;
}
