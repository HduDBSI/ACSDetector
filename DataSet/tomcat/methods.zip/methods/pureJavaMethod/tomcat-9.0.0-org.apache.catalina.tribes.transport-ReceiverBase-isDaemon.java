public boolean isDaemon(){
  return daemon;
}
