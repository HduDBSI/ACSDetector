/** 
 * {@inheritDoc}
 */
@Override public Validator getValidator(){
  return getPoolProperties().getValidator();
}
