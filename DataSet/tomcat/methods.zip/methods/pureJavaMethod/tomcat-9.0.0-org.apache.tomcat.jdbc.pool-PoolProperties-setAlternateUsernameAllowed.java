/** 
 * {@inheritDoc}
 */
@Override public void setAlternateUsernameAllowed(boolean alternateUsernameAllowed){
  this.alternateUsernameAllowed=alternateUsernameAllowed;
}
