@Override public void recycle(){
  if (buffered != null) {
    if (buffered.capacity() > 65536) {
      buffered=null;
    }
 else {
      buffered.position(0).limit(0);
    }
  }
  hasRead=false;
  buffer=null;
}
