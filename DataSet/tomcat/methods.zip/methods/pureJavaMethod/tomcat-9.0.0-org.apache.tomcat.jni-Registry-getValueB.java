/** 
 * Get the Registry value for REG_BINARY
 * @param key The Registry key descriptor to use.
 * @param name The name of the value to query
 * @return Registry key value
 * @throws Error An error occurred
 */
public static native byte[] getValueB(long key,String name) throws Error ;
