@Override public String toString(){
  return "ExpiresConfiguration[startingPoint=" + startingPoint + ", duration="+ durations+ "]";
}
