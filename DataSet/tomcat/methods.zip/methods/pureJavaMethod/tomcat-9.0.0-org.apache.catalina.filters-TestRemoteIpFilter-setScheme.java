public void setScheme(String scheme){
  getCoyoteRequest().scheme().setString(scheme);
}
