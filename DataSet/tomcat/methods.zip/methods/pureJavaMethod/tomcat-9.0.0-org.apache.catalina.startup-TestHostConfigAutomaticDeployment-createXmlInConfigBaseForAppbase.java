private File createXmlInConfigBaseForAppbase() throws IOException {
  File xml=getXmlInConfigBaseForAppbase();
  File parent=xml.getParentFile();
  if (!parent.isDirectory()) {
    Assert.assertTrue(parent.mkdirs());
  }
  Files.copy(XML_SOURCE.toPath(),xml.toPath());
  xml.setLastModified(System.currentTimeMillis() - 2 * HostConfig.FILE_MODIFICATION_RESOLUTION_MS);
  return xml;
}
