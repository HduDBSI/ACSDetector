public static String toString(Object[] data,int offset,int length){
  StringBuilder buf=new StringBuilder("{");
  if (data != null && length > 0) {
    buf.append(data[offset++]);
    for (int i=offset; i < length; i++) {
      buf.append(", ").append(data[i]);
    }
  }
  buf.append("}");
  return buf.toString();
}
