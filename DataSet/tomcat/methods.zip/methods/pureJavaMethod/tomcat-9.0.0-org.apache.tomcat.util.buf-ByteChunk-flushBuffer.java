/** 
 * Send the buffer to the sink. Called by append() when the limit is reached. You can also call it explicitly to force the data to be written.
 * @throws IOException Writing overflow data to the output channel failed
 */
public void flushBuffer() throws IOException {
  if (out == null) {
    throw new IOException("Buffer overflow, no sink " + limit + " "+ buff.length);
  }
  out.realWriteBytes(buff,start,end - start);
  end=start;
}
