@Override public void onClose(Session session,CloseReason closeReason){
  Room room=getRoom(false);
  if (room != null) {
    room.invokeAndWait(new Runnable(){
      @Override public void run(){
        try {
          if (player != null) {
            player.removeFromRoom();
            player=null;
          }
        }
 catch (        RuntimeException ex) {
          log.error("Unexpected exception: " + ex.toString(),ex);
        }
      }
    }
);
  }
}
