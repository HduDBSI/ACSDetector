/** 
 * Simple test program
 * @param args Command-line arguments
 * @throws Exception If an error occurs
 */
public static void main(String args[]) throws Exception {
  McastService service=new McastService();
  java.util.Properties p=new java.util.Properties();
  p.setProperty("mcastPort","5555");
  p.setProperty("mcastAddress","224.10.10.10");
  p.setProperty("mcastClusterDomain","catalina");
  p.setProperty("bindAddress","localhost");
  p.setProperty("memberDropTime","3000");
  p.setProperty("mcastFrequency","500");
  p.setProperty("tcpListenPort","4000");
  p.setProperty("tcpListenHost","127.0.0.1");
  p.setProperty("tcpSecurePort","4100");
  p.setProperty("udpListenPort","4200");
  service.setProperties(p);
  service.start();
  Thread.sleep(60 * 1000 * 60);
}
