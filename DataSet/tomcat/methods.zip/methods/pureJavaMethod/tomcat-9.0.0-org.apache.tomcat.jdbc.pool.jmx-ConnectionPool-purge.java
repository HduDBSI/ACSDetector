/** 
 * {@inheritDoc}
 */
@Override public void purge(){
  pool.purge();
}
