public void writeToGZip(byte b[],int off,int len) throws IOException {
  if (debug > 1) {
    System.out.println("writeToGZip, len = " + len);
  }
  if (debug > 2) {
    System.out.print("writeToGZip(");
    System.out.write(b,off,len);
    System.out.println(")");
  }
  if (gzipstream == null) {
    if (debug > 1) {
      System.out.println("new GZIPOutputStream");
    }
    boolean alreadyCompressed=false;
    String contentEncoding=response.getHeader("Content-Encoding");
    if (contentEncoding != null) {
      if (contentEncoding.contains("gzip")) {
        alreadyCompressed=true;
        if (debug > 0) {
          System.out.println("content is already compressed");
        }
      }
 else {
        if (debug > 0) {
          System.out.println("content is not compressed yet");
        }
      }
    }
    boolean compressibleMimeType=false;
    if (compressionMimeTypes != null) {
      if (startsWithStringArray(compressionMimeTypes,response.getContentType())) {
        compressibleMimeType=true;
        if (debug > 0) {
          System.out.println("mime type " + response.getContentType() + " is compressible");
        }
      }
 else {
        if (debug > 0) {
          System.out.println("mime type " + response.getContentType() + " is not compressible");
        }
      }
    }
    if (response.isCommitted()) {
      if (debug > 1)       System.out.print("Response already committed. Using original output stream");
      gzipstream=output;
    }
 else     if (alreadyCompressed) {
      if (debug > 1)       System.out.print("Response already compressed. Using original output stream");
      gzipstream=output;
    }
 else     if (!compressibleMimeType) {
      if (debug > 1)       System.out.print("Response mime type is not compressible. Using original output stream");
      gzipstream=output;
    }
 else {
      response.addHeader("Content-Encoding","gzip");
      response.setContentLength(-1);
      response.setBufferSize(compressionBuffer);
      gzipstream=new GZIPOutputStream(output);
    }
  }
  gzipstream.write(b,off,len);
}
