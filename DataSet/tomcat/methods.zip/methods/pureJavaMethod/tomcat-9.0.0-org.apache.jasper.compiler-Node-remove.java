/** 
 * Removes the given node from the list.
 * @param n The node to be removed
 */
public void remove(Node n){
  list.remove(n);
}
