@Test public void testConstructorFive() throws Exception {
  doTestConstructor(5);
}
