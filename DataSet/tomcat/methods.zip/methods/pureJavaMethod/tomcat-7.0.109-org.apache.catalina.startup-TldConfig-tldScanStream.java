private XmlErrorHandler tldScanStream(InputStream resourceStream) throws IOException {
  InputSource source=new InputSource(resourceStream);
  XmlErrorHandler result=new XmlErrorHandler();
synchronized (tldDigester) {
    try {
      tldDigester.setErrorHandler(result);
      tldDigester.push(this);
      tldDigester.parse(source);
    }
 catch (    SAXException s) {
      throw new IOException(s);
    }
 finally {
      tldDigester.reset();
    }
    return result;
  }
}
