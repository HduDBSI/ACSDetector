/** 
 * @return Access flags of the object aka. "modifiers".
 */
public final int getAccessFlags(){
  return access_flags;
}
