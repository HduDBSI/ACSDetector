public String printDate(){
  getDateLocal();
  Struct struct=structLocal.get();
  if (struct.currentDateString == null) {
    StringBuilder current=new StringBuilder(32);
    current.append('[');
    current.append(struct.dayFormatter.format(struct.currentDate));
    current.append('/');
    current.append(lookup(struct.monthFormatter.format(struct.currentDate)));
    current.append('/');
    current.append(struct.yearFormatter.format(struct.currentDate));
    current.append(':');
    current.append(struct.timeFormatter.format(struct.currentDate));
    current.append(']');
    struct.currentDateString=current.toString();
  }
  return struct.currentDateString;
}
