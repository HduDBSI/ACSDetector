@Override protected void doGet(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
  if (DispatcherType.ASYNC == req.getDispatcherType()) {
    if (ENCODED_URI.equals(req.getRequestURI())) {
      resp.getWriter().print("OK");
    }
 else {
      resp.getWriter().print("FAIL");
    }
  }
 else {
    AsyncContext ac=req.startAsync();
    ac.dispatch();
  }
}
