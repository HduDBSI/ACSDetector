private String resolveFileName(String inFileName){
  String fileName=inFileName.replace('\\','/');
  boolean isAbsolute=fileName.startsWith("/");
  fileName=isAbsolute ? fileName : baseDirStack.peek() + fileName;
  String baseDir=fileName.substring(0,fileName.lastIndexOf('/') + 1);
  baseDirStack.push(baseDir);
  return fileName;
}
