/** 
 * If enabled, requests for a directory will be redirected (adding a trailing slash) by the Mapper. This is more efficient but has the side effect of confirming that the directory is valid.
 * @param mapperDirectoryRedirectEnabled Should the redirects be enabled?
 */
public void setMapperDirectoryRedirectEnabled(boolean mapperDirectoryRedirectEnabled);
