public boolean useTagPlugin(){
  return useTagPlugin;
}
