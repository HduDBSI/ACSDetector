/** 
 * Start the host with the specified name.
 * @param writer Writer to render to
 * @param name Host name
 * @param smClient StringManager for the client's locale
 */
protected void start(PrintWriter writer,String name,StringManager smClient){
  if (debug >= 1) {
    log(sm.getString("hostManagerServlet.start",name));
  }
  if ((name == null) || name.length() == 0) {
    writer.println(smClient.getString("hostManagerServlet.invalidHostName",name));
    return;
  }
  Container host=engine.findChild(name);
  if (host == null) {
    writer.println(smClient.getString("hostManagerServlet.noHost",name));
    return;
  }
  if (host == installedHost) {
    writer.println(smClient.getString("hostManagerServlet.cannotStartOwnHost",name));
    return;
  }
  if (host.getState().isAvailable()) {
    writer.println(smClient.getString("hostManagerServlet.alreadyStarted",name));
    return;
  }
  try {
    host.start();
    writer.println(smClient.getString("hostManagerServlet.started",name));
  }
 catch (  Exception e) {
    getServletContext().log(sm.getString("hostManagerServlet.startFailed",name),e);
    writer.println(smClient.getString("hostManagerServlet.startFailed",name));
    writer.println(smClient.getString("hostManagerServlet.exception",e.toString()));
  }
}
