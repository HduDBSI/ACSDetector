private static BitSet initialSafeChars(){
  BitSet initialSafeChars=new BitSet(128);
  int i;
  for (i='a'; i <= 'z'; i++) {
    initialSafeChars.set(i);
  }
  for (i='A'; i <= 'Z'; i++) {
    initialSafeChars.set(i);
  }
  for (i='0'; i <= '9'; i++) {
    initialSafeChars.set(i);
  }
  initialSafeChars.set('$');
  initialSafeChars.set('-');
  initialSafeChars.set('_');
  initialSafeChars.set('.');
  initialSafeChars.set('!');
  initialSafeChars.set('*');
  initialSafeChars.set('\'');
  initialSafeChars.set('(');
  initialSafeChars.set(')');
  initialSafeChars.set(',');
  return initialSafeChars;
}
