/** 
 * Prepare for the beginning of active use of the public methods of this component and implement the requirements of {@link org.apache.catalina.util.LifecycleBase#startInternal()}.
 * @exception LifecycleException if this component detects a fatal errorthat prevents this component from being used
 */
@Override protected void startInternal() throws LifecycleException {
  String pathName=getPathname();
  try (InputStream is=ConfigFileLoader.getInputStream(pathName)){
    if (log.isDebugEnabled()) {
      log.debug(sm.getString("memoryRealm.loadPath",pathName));
    }
    Digester digester=getDigester();
    try {
synchronized (digester) {
        digester.push(this);
        digester.parse(is);
      }
    }
 catch (    Exception e) {
      throw new LifecycleException(sm.getString("memoryRealm.readXml"),e);
    }
 finally {
      digester.reset();
    }
  }
 catch (  IOException ioe) {
    throw new LifecycleException(sm.getString("memoryRealm.loadExist",pathName),ioe);
  }
  super.startInternal();
}
