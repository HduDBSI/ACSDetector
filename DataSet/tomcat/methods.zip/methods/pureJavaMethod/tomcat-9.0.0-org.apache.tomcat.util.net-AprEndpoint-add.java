/** 
 * Add the sendfile data to the sendfile poller. Note that in most cases, the initial non blocking calls to sendfile will return right away, and will be handled asynchronously inside the kernel. As a result, the poller will never be used.
 * @param data containing the reference to the data which should be snet
 * @return true if all the data has been sent right away, and falseotherwise
 */
public SendfileState add(SendfileData data){
  try {
    data.fdpool=Socket.pool(data.socket);
    data.fd=File.open(data.fileName,File.APR_FOPEN_READ | File.APR_FOPEN_SENDFILE_ENABLED | File.APR_FOPEN_BINARY,0,data.fdpool);
    Socket.timeoutSet(data.socket,0);
    while (sendfileRunning) {
      long nw=Socket.sendfilen(data.socket,data.fd,data.pos,data.length,0);
      if (nw < 0) {
        if (!(-nw == Status.EAGAIN)) {
          Pool.destroy(data.fdpool);
          data.socket=0;
          return SendfileState.ERROR;
        }
 else {
          break;
        }
      }
 else {
        data.pos+=nw;
        data.length-=nw;
        if (data.length == 0) {
          Pool.destroy(data.fdpool);
          Socket.timeoutSet(data.socket,getConnectionTimeout() * 1000);
          return SendfileState.DONE;
        }
      }
    }
  }
 catch (  Exception e) {
    log.warn(sm.getString("endpoint.sendfile.error"),e);
    return SendfileState.ERROR;
  }
synchronized (this) {
    addS.add(data);
    this.notify();
  }
  return SendfileState.PENDING;
}
