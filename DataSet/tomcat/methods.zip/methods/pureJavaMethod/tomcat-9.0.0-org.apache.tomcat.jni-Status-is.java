private static native boolean is(int err,int idx);
