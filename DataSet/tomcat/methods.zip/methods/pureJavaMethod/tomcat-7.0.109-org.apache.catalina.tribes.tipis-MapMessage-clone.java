/** 
 * shallow clone
 * @return Object
 */
@Override public MapMessage clone(){
  try {
    return (MapMessage)super.clone();
  }
 catch (  CloneNotSupportedException e) {
    throw new AssertionError();
  }
}
