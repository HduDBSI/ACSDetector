@Test public void testBug56032() throws Exception {
  Tomcat tomcat=getTomcatInstance();
  Context ctx=tomcat.addContext("",null);
  ctx.addApplicationListener(TesterFirehoseServer.Config.class.getName());
  Tomcat.addServlet(ctx,"default",new DefaultServlet());
  ctx.addServletMappingDecoded("/","default");
  TesterSupport.initSsl(tomcat);
  tomcat.start();
  WebSocketContainer wsContainer=ContainerProvider.getWebSocketContainer();
  ClientEndpointConfig clientEndpointConfig=ClientEndpointConfig.Builder.create().build();
  clientEndpointConfig.getUserProperties().put(Constants.SSL_TRUSTSTORE_PROPERTY,TesterSupport.CA_JKS);
  Session wsSession=wsContainer.connectToServer(TesterProgrammaticEndpoint.class,clientEndpointConfig,new URI("wss://localhost:" + getPort() + TesterFirehoseServer.Config.PATH));
  MessageHandler handler=new SleepingText(5000);
  wsSession.addMessageHandler(handler);
  wsSession.getBasicRemote().sendText("Hello");
  int count=0;
  int limit=TesterFirehoseServer.WAIT_TIME_MILLIS / 100;
  System.out.println("Waiting for server to report an error");
  while (TesterFirehoseServer.Endpoint.getErrorCount() == 0 && count < limit) {
    Thread.sleep(100);
    count++;
  }
  if (TesterFirehoseServer.Endpoint.getErrorCount() == 0) {
    Assert.fail("No error reported by Endpoint when timeout was expected");
  }
  System.out.println("Waiting for connection to be closed");
  count=0;
  limit=(TesterFirehoseServer.SEND_TIME_OUT_MILLIS * 2) / 100;
  while (TesterFirehoseServer.Endpoint.getOpenConnectionCount() != 0 && count < limit) {
    Thread.sleep(100);
    count++;
  }
  int openConnectionCount=TesterFirehoseServer.Endpoint.getOpenConnectionCount();
  if (openConnectionCount != 0) {
    Assert.fail("There are [" + openConnectionCount + "] connections still open");
  }
  wsSession.close();
}
