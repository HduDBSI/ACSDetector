private void doTestClientCertGet(boolean preemptive) throws Exception {
  Assume.assumeTrue("SSL renegotiation has to be supported for this test",TesterSupport.isRenegotiationSupported(getTomcatInstance()));
  if (preemptive) {
    Tomcat tomcat=getTomcatInstance();
    Context c=(Context)tomcat.getHost().findChildren()[0];
    c.setPreemptiveAuthentication(true);
  }
  getTomcatInstance().start();
  ByteChunk res=getUrl("https://localhost:" + getPort() + "/unprotected");
  if (log.isDebugEnabled()) {
    int count=TesterSupport.getLastClientAuthRequestedIssuerCount();
    log.debug("Last client KeyManager usage: " + TesterSupport.getLastClientAuthKeyManagerUsage() + ", "+ count+ " requested Issuers, first one: "+ (count > 0 ? TesterSupport.getLastClientAuthRequestedIssuer(0).getName() : "NONE"));
    log.debug("Expected requested Issuer: " + TesterSupport.getClientAuthExpectedIssuer());
  }
  assertTrue("Checking requested client issuer against " + TesterSupport.getClientAuthExpectedIssuer(),TesterSupport.checkLastClientAuthRequestedIssuers());
  if (preemptive) {
    assertEquals("OK-" + TesterSupport.ROLE,res.toString());
  }
 else {
    assertEquals("OK",res.toString());
  }
  res=getUrl("https://localhost:" + getPort() + "/protected");
  if (log.isDebugEnabled()) {
    int count=TesterSupport.getLastClientAuthRequestedIssuerCount();
    log.debug("Last client KeyManager usage: " + TesterSupport.getLastClientAuthKeyManagerUsage() + ", "+ count+ " requested Issuers, first one: "+ (count > 0 ? TesterSupport.getLastClientAuthRequestedIssuer(0).getName() : "NONE"));
    log.debug("Expected requested Issuer: " + TesterSupport.getClientAuthExpectedIssuer());
  }
  assertTrue("Checking requested client issuer against " + TesterSupport.getClientAuthExpectedIssuer(),TesterSupport.checkLastClientAuthRequestedIssuers());
  assertEquals("OK-" + TesterSupport.ROLE,res.toString());
}
