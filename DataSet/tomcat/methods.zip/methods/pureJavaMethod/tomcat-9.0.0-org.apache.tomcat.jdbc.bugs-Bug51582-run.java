@Override public void run(){
  try {
    if (i == 0) {
      Thread.sleep(1000);
      s.cancel();
    }
 else     if (i == 1) {
      long start=System.currentTimeMillis();
      System.out.println("[" + getName() + "] Calling SP SLEEP");
      s.execute();
      System.out.println("[" + getName() + "] Executed SP SLEEP ["+ (System.currentTimeMillis() - start)+ "]");
    }
 else {
      Thread.sleep(1000);
      connection.close();
    }
  }
 catch (  InterruptedException e) {
  }
catch (  SQLException e) {
    e.printStackTrace();
  }
}
