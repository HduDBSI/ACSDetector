@Override public boolean asyncDispatch(org.apache.coyote.Request req,org.apache.coyote.Response res,SocketEvent status) throws Exception {
  Request request=(Request)req.getNote(ADAPTER_NOTES);
  Response response=(Response)res.getNote(ADAPTER_NOTES);
  if (request == null) {
    throw new IllegalStateException("Dispatch may only happen on an existing request.");
  }
  boolean success=true;
  AsyncContextImpl asyncConImpl=request.getAsyncContextInternal();
  req.getRequestProcessor().setWorkerThreadName(THREAD_NAME.get());
  try {
    if (!request.isAsync()) {
      response.setSuspended(false);
    }
    if (status == SocketEvent.TIMEOUT) {
      if (!asyncConImpl.timeout()) {
        asyncConImpl.setErrorState(null,false);
      }
    }
 else     if (status == SocketEvent.ERROR) {
      success=false;
      Throwable t=(Throwable)req.getAttribute(RequestDispatcher.ERROR_EXCEPTION);
      req.getAttributes().remove(RequestDispatcher.ERROR_EXCEPTION);
      ClassLoader oldCL=null;
      try {
        oldCL=request.getContext().bind(false,null);
        if (req.getReadListener() != null) {
          req.getReadListener().onError(t);
        }
        if (res.getWriteListener() != null) {
          res.getWriteListener().onError(t);
        }
      }
  finally {
        request.getContext().unbind(false,oldCL);
      }
      if (t != null) {
        asyncConImpl.setErrorState(t,true);
      }
    }
    if (!request.isAsyncDispatching() && request.isAsync()) {
      WriteListener writeListener=res.getWriteListener();
      ReadListener readListener=req.getReadListener();
      if (writeListener != null && status == SocketEvent.OPEN_WRITE) {
        ClassLoader oldCL=null;
        try {
          oldCL=request.getContext().bind(false,null);
          res.onWritePossible();
          if (request.isFinished() && req.sendAllDataReadEvent() && readListener != null) {
            readListener.onAllDataRead();
          }
        }
 catch (        Throwable t) {
          ExceptionUtils.handleThrowable(t);
          writeListener.onError(t);
          success=false;
        }
 finally {
          request.getContext().unbind(false,oldCL);
        }
      }
 else       if (readListener != null && status == SocketEvent.OPEN_READ) {
        ClassLoader oldCL=null;
        try {
          oldCL=request.getContext().bind(false,null);
          if (!request.isFinished()) {
            readListener.onDataAvailable();
          }
          if (request.isFinished() && req.sendAllDataReadEvent()) {
            readListener.onAllDataRead();
          }
        }
 catch (        Throwable t) {
          ExceptionUtils.handleThrowable(t);
          readListener.onError(t);
          success=false;
        }
 finally {
          request.getContext().unbind(false,oldCL);
        }
      }
    }
    if (!request.isAsyncDispatching() && request.isAsync() && response.isErrorReportRequired()) {
      connector.getService().getContainer().getPipeline().getFirst().invoke(request,response);
    }
    if (request.isAsyncDispatching()) {
      connector.getService().getContainer().getPipeline().getFirst().invoke(request,response);
      Throwable t=(Throwable)request.getAttribute(RequestDispatcher.ERROR_EXCEPTION);
      if (t != null) {
        asyncConImpl.setErrorState(t,true);
      }
    }
    if (!request.isAsync()) {
      request.finishRequest();
      response.finishResponse();
    }
    AtomicBoolean error=new AtomicBoolean(false);
    res.action(ActionCode.IS_ERROR,error);
    if (error.get()) {
      if (request.isAsyncCompleting()) {
        res.action(ActionCode.ASYNC_POST_PROCESS,null);
      }
      success=false;
    }
  }
 catch (  IOException e) {
    success=false;
  }
catch (  Throwable t) {
    ExceptionUtils.handleThrowable(t);
    success=false;
    log.error(sm.getString("coyoteAdapter.asyncDispatch"),t);
  }
 finally {
    if (!success) {
      res.setStatus(500);
    }
    if (!success || !request.isAsync()) {
      long time=0;
      if (req.getStartTime() != -1) {
        time=System.currentTimeMillis() - req.getStartTime();
      }
      Context context=request.getContext();
      if (context != null) {
        context.logAccess(request,response,time,false);
      }
 else {
        log(req,res,time);
      }
    }
    req.getRequestProcessor().setWorkerThreadName(null);
    if (!success || !request.isAsync()) {
      request.recycle();
      response.recycle();
    }
  }
  return success;
}
