/** 
 * Find an entry given its name in a sorted array of map elements. This will return the index for the closest inferior or equal item in the given array.
 * @param name The name to find
 * @param array The array in which to look
 * @param len The effective length of the array
 * @return the position of the best match
 */
protected static final int findClosest(CharChunk name,CharEntry[] array,int len){
  int a=0;
  int b=len - 1;
  if (b == -1) {
    return -1;
  }
  if (compare(name,array[0].name) < 0) {
    return -1;
  }
  if (b == 0) {
    return 0;
  }
  int i=0;
  while (true) {
    i=(b + a) >>> 1;
    int result=compare(name,array[i].name);
    if (result == 1) {
      a=i;
    }
 else     if (result == 0) {
      return i;
    }
 else {
      b=i;
    }
    if ((b - a) == 1) {
      int result2=compare(name,array[b].name);
      if (result2 < 0) {
        return a;
      }
 else {
        return b;
      }
    }
  }
}
