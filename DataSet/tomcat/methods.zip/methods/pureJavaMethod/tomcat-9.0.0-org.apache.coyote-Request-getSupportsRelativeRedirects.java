public boolean getSupportsRelativeRedirects(){
  if (protocol().equals("") || protocol().equals("HTTP/1.0")) {
    return false;
  }
  return true;
}
