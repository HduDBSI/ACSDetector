/** 
 * @return an array containing the session identifiers of all Sessionscurrently saved in this Store.  If there are no such Sessions, a zero-length array is returned.
 * @exception IOException if an input/output error occurred
 */
public String[] keys() throws IOException ;
