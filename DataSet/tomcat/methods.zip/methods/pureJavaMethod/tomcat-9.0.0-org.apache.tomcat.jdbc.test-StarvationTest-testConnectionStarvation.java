@Test public void testConnectionStarvation() throws Exception {
  config();
  Connection con1=datasource.getConnection();
  Connection con2=null;
  try {
    con2=datasource.getConnection();
    try {
      con2.setCatalog("mysql");
    }
 catch (    SQLException x) {
      Assert.assertFalse("2nd Connection is not valid:" + x.getMessage(),true);
    }
    Assert.assertTrue("Connection 1 should be closed.",con1.isClosed());
  }
 catch (  Exception x) {
    Assert.assertFalse("Connection got starved:" + x.getMessage(),true);
  }
 finally {
    if (con2 != null)     con2.close();
  }
}
