/** 
 * Reload the web application at the specified context path.
 * @param writer Writer to render to
 * @param cn Name of the application to be restarted
 */
protected void reload(PrintWriter writer,ContextName cn,StringManager smClient){
  if (debug >= 1)   log("restart: Reloading web application '" + cn + "'");
  if (!validateContextName(cn,writer,smClient)) {
    return;
  }
  try {
    Context context=(Context)host.findChild(cn.getName());
    if (context == null) {
      writer.println(smClient.getString("managerServlet.noContext",RequestUtil.filter(cn.getDisplayName())));
      return;
    }
    if (context.getName().equals(this.context.getName())) {
      writer.println(smClient.getString("managerServlet.noSelf"));
      return;
    }
    context.reload();
    writer.println(smClient.getString("managerServlet.reloaded",cn.getDisplayName()));
  }
 catch (  Throwable t) {
    ExceptionUtils.handleThrowable(t);
    log("ManagerServlet.reload[" + cn.getDisplayName() + "]",t);
    writer.println(smClient.getString("managerServlet.exception",t.toString()));
  }
}
