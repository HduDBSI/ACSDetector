protected String getReport(){
  String report=reportBuf.toString();
  reportBuf.setLength(0);
  return report;
}
