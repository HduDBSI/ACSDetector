/** 
 * Deploy exploded webapps.
 * @param appBase The base path for applications
 * @param files The exploded webapps that should be deployed
 */
protected void deployDirectories(File appBase,String[] files){
  if (files == null)   return;
  ExecutorService es=host.getStartStopExecutor();
  List<Future<?>> results=new ArrayList<>();
  for (int i=0; i < files.length; i++) {
    if (files[i].equalsIgnoreCase("META-INF"))     continue;
    if (files[i].equalsIgnoreCase("WEB-INF"))     continue;
    File dir=new File(appBase,files[i]);
    if (dir.isDirectory()) {
      ContextName cn=new ContextName(files[i],false);
      if (isServiced(cn.getName()) || deploymentExists(cn.getName()))       continue;
      results.add(es.submit(new DeployDirectory(this,cn,dir)));
    }
  }
  for (  Future<?> result : results) {
    try {
      result.get();
    }
 catch (    Exception e) {
      log.error(sm.getString("hostConfig.deployDir.threaded.error"),e);
    }
  }
}
