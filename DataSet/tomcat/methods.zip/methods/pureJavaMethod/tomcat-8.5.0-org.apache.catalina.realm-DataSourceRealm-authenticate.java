/** 
 * Return the Principal associated with the specified username and credentials, if there is one; otherwise return <code>null</code>.
 * @param dbConnection The database connection to be used
 * @param username Username of the Principal to look up
 * @param credentials Password or other credentials to use inauthenticating this username
 * @return the associated principal, or <code>null</code> if there is none.
 */
protected Principal authenticate(Connection dbConnection,String username,String credentials){
  String dbCredentials=getPassword(dbConnection,username);
  if (credentials == null || dbCredentials == null) {
    if (containerLog.isTraceEnabled())     containerLog.trace(sm.getString("dataSourceRealm.authenticateFailure",username));
    return null;
  }
  boolean validated=getCredentialHandler().matches(credentials,dbCredentials);
  if (validated) {
    if (containerLog.isTraceEnabled())     containerLog.trace(sm.getString("dataSourceRealm.authenticateSuccess",username));
  }
 else {
    if (containerLog.isTraceEnabled())     containerLog.trace(sm.getString("dataSourceRealm.authenticateFailure",username));
    return (null);
  }
  ArrayList<String> list=getRoles(dbConnection,username);
  return new GenericPrincipal(username,credentials,list);
}
