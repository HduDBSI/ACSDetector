protected String getProtocol(){
  String protocol=System.getProperty("tomcat.test.protocol");
  if (protocol == null) {
    protocol=Http11NioProtocol.class.getName();
  }
  return protocol;
}
