final public void Equality() throws ParseException {
  Compare();
  label_9:   while (true) {
switch ((jj_ntk == -1) ? jj_ntk() : jj_ntk) {
case EQ0:
case EQ1:
case NE0:
case NE1:
      ;
    break;
default :
  jj_la1[14]=jj_gen;
break label_9;
}
switch ((jj_ntk == -1) ? jj_ntk() : jj_ntk) {
case EQ0:
case EQ1:
switch ((jj_ntk == -1) ? jj_ntk() : jj_ntk) {
case EQ0:
jj_consume_token(EQ0);
break;
case EQ1:
jj_consume_token(EQ1);
break;
default :
jj_la1[15]=jj_gen;
jj_consume_token(-1);
throw new ParseException();
}
AstEqual jjtn001=new AstEqual(JJTEQUAL);
boolean jjtc001=true;
jjtree.openNodeScope(jjtn001);
try {
Compare();
}
 catch (Throwable jjte001) {
if (jjtc001) {
jjtree.clearNodeScope(jjtn001);
jjtc001=false;
}
 else {
jjtree.popNode();
}
if (jjte001 instanceof RuntimeException) {
{
if (true) throw (RuntimeException)jjte001;
}
}
if (jjte001 instanceof ParseException) {
{
if (true) throw (ParseException)jjte001;
}
}
{
if (true) throw (Error)jjte001;
}
}
 finally {
if (jjtc001) {
jjtree.closeNodeScope(jjtn001,2);
}
}
break;
case NE0:
case NE1:
switch ((jj_ntk == -1) ? jj_ntk() : jj_ntk) {
case NE0:
jj_consume_token(NE0);
break;
case NE1:
jj_consume_token(NE1);
break;
default :
jj_la1[16]=jj_gen;
jj_consume_token(-1);
throw new ParseException();
}
AstNotEqual jjtn002=new AstNotEqual(JJTNOTEQUAL);
boolean jjtc002=true;
jjtree.openNodeScope(jjtn002);
try {
Compare();
}
 catch (Throwable jjte002) {
if (jjtc002) {
jjtree.clearNodeScope(jjtn002);
jjtc002=false;
}
 else {
jjtree.popNode();
}
if (jjte002 instanceof RuntimeException) {
{
if (true) throw (RuntimeException)jjte002;
}
}
if (jjte002 instanceof ParseException) {
{
if (true) throw (ParseException)jjte002;
}
}
{
if (true) throw (Error)jjte002;
}
}
 finally {
if (jjtc002) {
jjtree.closeNodeScope(jjtn002,2);
}
}
break;
default :
jj_la1[17]=jj_gen;
jj_consume_token(-1);
throw new ParseException();
}
}
}
