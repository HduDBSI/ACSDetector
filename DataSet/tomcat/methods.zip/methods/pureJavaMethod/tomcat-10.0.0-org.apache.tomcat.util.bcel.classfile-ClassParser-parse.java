/** 
 * Parses the given Java class file and return an object that represents the contained data, i.e., constants, methods, fields and commands. A <em>ClassFormatException</em> is raised, if the file is not a valid .class file. (This does not include verification of the byte code as it is performed by the java interpreter).
 * @return Class object representing the parsed class file
 * @throws IOException If an I/O occurs reading the byte code
 * @throws ClassFormatException If the byte code is invalid
 */
public JavaClass parse() throws IOException, ClassFormatException {
  readID();
  readVersion();
  readConstantPool();
  readClassInfo();
  readInterfaces();
  readFields();
  readMethods();
  readAttributes();
  return new JavaClass(class_name,superclassName,accessFlags,constantPool,interfaceNames,runtimeVisibleAnnotations);
}
