private static void doTestBug53867(){
  int count=100000;
  for (int j=0; j < bug53867TestData.length; j++) {
    Assert.assertEquals(doTestBug53867OldVersion(bug53867TestData[j]),Validator.xmlEscape(bug53867TestData[j]));
  }
  for (int i=0; i < 100; i++) {
    for (int j=0; j < bug53867TestData.length; j++) {
      doTestBug53867OldVersion(bug53867TestData[j]);
    }
  }
  for (int i=0; i < 100; i++) {
    for (int j=0; j < bug53867TestData.length; j++) {
      Validator.xmlEscape(bug53867TestData[j]);
    }
  }
  long start=System.currentTimeMillis();
  for (int i=0; i < count; i++) {
    for (int j=0; j < bug53867TestData.length; j++) {
      doTestBug53867OldVersion(bug53867TestData[j]);
    }
  }
  System.out.println("Old escape:" + (System.currentTimeMillis() - start));
  start=System.currentTimeMillis();
  for (int i=0; i < count; i++) {
    for (int j=0; j < bug53867TestData.length; j++) {
      Validator.xmlEscape(bug53867TestData[j]);
    }
  }
  System.out.println("New escape:" + (System.currentTimeMillis() - start));
}
