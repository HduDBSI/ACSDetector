/** 
 * Stop the endpoint. This will cause all processing threads to stop.
 */
@Override public void stopInternal(){
  if (!paused) {
    pause();
  }
  if (running) {
    running=false;
    for (int i=0; pollers != null && i < pollers.length; i++) {
      if (pollers[i] == null)       continue;
      pollers[i].destroy();
      pollers[i]=null;
    }
    try {
      if (!getStopLatch().await(selectorTimeout + 100,TimeUnit.MILLISECONDS)) {
        log.warn(sm.getString("endpoint.nio.stopLatchAwaitFail"));
      }
    }
 catch (    InterruptedException e) {
      log.warn(sm.getString("endpoint.nio.stopLatchAwaitInterrupted"),e);
    }
    shutdownExecutor();
    eventCache.clear();
    nioChannels.clear();
    processorCache.clear();
  }
}
