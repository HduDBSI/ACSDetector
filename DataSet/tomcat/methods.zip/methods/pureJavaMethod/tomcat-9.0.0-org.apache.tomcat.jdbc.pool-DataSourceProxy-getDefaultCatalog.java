/** 
 * {@inheritDoc}
 */
@Override public String getDefaultCatalog(){
  return getPoolProperties().getDefaultCatalog();
}
