private static void validateEncoders(Class<? extends Encoder>[] encoders) throws DeploymentException {
  for (  Class<? extends Encoder> encoder : encoders) {
    @SuppressWarnings("unused") Encoder instance;
    try {
      encoder.newInstance();
    }
 catch (    InstantiationException|IllegalAccessException e) {
      throw new DeploymentException(sm.getString("serverContainer.encoderFail",encoder.getName()),e);
    }
  }
}
