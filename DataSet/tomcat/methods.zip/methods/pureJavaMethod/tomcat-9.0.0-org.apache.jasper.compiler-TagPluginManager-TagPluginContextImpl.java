TagPluginContextImpl(Node.CustomTag n,PageInfo pageInfo){
  this.node=n;
  this.pageInfo=pageInfo;
  curNodes=new Node.Nodes();
  n.setAtETag(curNodes);
  curNodes=new Node.Nodes();
  n.setAtSTag(curNodes);
  n.setUseTagPlugin(true);
  pluginAttributes=new HashMap<>();
}
