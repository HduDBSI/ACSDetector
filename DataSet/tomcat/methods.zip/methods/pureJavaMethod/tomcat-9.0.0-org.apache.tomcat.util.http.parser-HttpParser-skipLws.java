static int skipLws(Reader input,boolean withReset) throws IOException {
  if (withReset) {
    input.mark(1);
  }
  int c=input.read();
  while (c == 32 || c == 9 || c == 10 || c == 13) {
    if (withReset) {
      input.mark(1);
    }
    c=input.read();
  }
  if (withReset) {
    input.reset();
  }
  return c;
}
