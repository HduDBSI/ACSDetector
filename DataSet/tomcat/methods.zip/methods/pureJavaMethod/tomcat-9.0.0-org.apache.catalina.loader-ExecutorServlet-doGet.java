@Override protected void doGet(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
  resp.getWriter().println("The current thread served " + this + " servlet");
  tpe=new ThreadPoolExecutor(tpSize,tpSize,50000L,TimeUnit.MILLISECONDS,new LinkedBlockingQueue<Runnable>());
  Task[] tasks=new Task[nTasks];
  for (int i=0; i < nTasks; i++) {
    tasks[i]=new Task("Task " + i);
    tpe.execute(tasks[i]);
  }
  resp.getWriter().println("Started " + nTasks + " never ending tasks using the ThreadPoolExecutor");
  resp.getWriter().flush();
}
