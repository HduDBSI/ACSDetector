@Override public PooledObject<PoolableConnection> makeObject() throws Exception {
  Connection conn=connectionFactory.createConnection();
  if (conn == null) {
    throw new IllegalStateException("Connection factory returned null from createConnection");
  }
  try {
    initializeConnection(conn);
  }
 catch (  final SQLException sqle) {
    Utils.closeQuietly((AutoCloseable)conn);
    throw sqle;
  }
  final long connIndex=connectionIndex.getAndIncrement();
  if (poolStatements) {
    conn=new PoolingConnection(conn);
    final GenericKeyedObjectPoolConfig<DelegatingPreparedStatement> config=new GenericKeyedObjectPoolConfig<>();
    config.setMaxTotalPerKey(-1);
    config.setBlockWhenExhausted(false);
    config.setMaxWait(Duration.ZERO);
    config.setMaxIdlePerKey(1);
    config.setMaxTotal(maxOpenPreparedStatements);
    if (dataSourceJmxObjectName != null) {
      final StringBuilder base=new StringBuilder(dataSourceJmxObjectName.toString());
      base.append(Constants.JMX_CONNECTION_BASE_EXT);
      base.append(connIndex);
      config.setJmxNameBase(base.toString());
      config.setJmxNamePrefix(Constants.JMX_STATEMENT_POOL_PREFIX);
    }
 else {
      config.setJmxEnabled(false);
    }
    final PoolingConnection poolingConn=(PoolingConnection)conn;
    final KeyedObjectPool<PStmtKey,DelegatingPreparedStatement> stmtPool=new GenericKeyedObjectPool<>(poolingConn,config);
    poolingConn.setStatementPool(stmtPool);
    poolingConn.setClearStatementPoolOnReturn(clearStatementPoolOnReturn);
    poolingConn.setCacheState(cacheState);
  }
  final ObjectName connJmxName;
  if (dataSourceJmxObjectName == null) {
    connJmxName=null;
  }
 else {
    connJmxName=new ObjectName(dataSourceJmxObjectName.toString() + Constants.JMX_CONNECTION_BASE_EXT + connIndex);
  }
  final PoolableConnection pc=new PoolableConnection(conn,pool,connJmxName,disconnectionSqlCodes,fastFailValidation);
  pc.setCacheState(cacheState);
  return new DefaultPooledObject<>(pc);
}
