/** 
 * Set the default context override flag for this web application.
 * @param override The new override flag
 */
@Override public void setOverride(boolean override){
  boolean oldOverride=this.override;
  this.override=override;
  support.firePropertyChange("override",oldOverride,this.override);
}
