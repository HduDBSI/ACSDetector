public String getDay(){
  int x=getDayOfWeek();
  String[] days=new String[]{"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
  if (x > 7)   return "Unknown to Man";
  return days[x - 1];
}
