/** 
 * Returns, whether the object is already closed.
 * @return True, if the object is closed, otherwise false.
 * @throws IOException An I/O error occurred.
 */
boolean isClosed() throws IOException ;
