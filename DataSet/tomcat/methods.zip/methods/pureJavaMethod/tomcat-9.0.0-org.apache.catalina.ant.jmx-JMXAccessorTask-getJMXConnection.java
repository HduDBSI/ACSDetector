/** 
 * get JMXConnection
 * @throws MalformedURLException Invalid URL specified
 * @throws IOException Other connection error
 * @return the JMX connection
 */
protected MBeanServerConnection getJMXConnection() throws MalformedURLException, IOException {
  MBeanServerConnection jmxServerConnection=null;
  if (isUseRef()) {
    Object pref=null;
    if (getProject() != null) {
      pref=getProject().getReference(getRef());
      if (pref != null) {
        try {
          jmxServerConnection=(MBeanServerConnection)pref;
        }
 catch (        ClassCastException cce) {
          getProject().log("Wrong object reference " + getRef() + " - "+ pref.getClass());
          return null;
        }
      }
    }
    if (jmxServerConnection == null) {
      jmxServerConnection=accessJMXConnection(getProject(),getUrl(),getHost(),getPort(),getUsername(),getPassword(),getRef());
    }
  }
 else {
    jmxServerConnection=accessJMXConnection(getProject(),getUrl(),getHost(),getPort(),getUsername(),getPassword(),null);
  }
  return jmxServerConnection;
}
