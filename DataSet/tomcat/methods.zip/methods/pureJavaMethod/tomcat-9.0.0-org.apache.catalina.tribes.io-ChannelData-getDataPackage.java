public byte[] getDataPackage(byte[] data,int offset){
  byte[] addr=address.getData(false);
  XByteBuffer.toBytes(options,data,offset);
  offset+=4;
  XByteBuffer.toBytes(timestamp,data,offset);
  offset+=8;
  XByteBuffer.toBytes(uniqueId.length,data,offset);
  offset+=4;
  System.arraycopy(uniqueId,0,data,offset,uniqueId.length);
  offset+=uniqueId.length;
  XByteBuffer.toBytes(addr.length,data,offset);
  offset+=4;
  System.arraycopy(addr,0,data,offset,addr.length);
  offset+=addr.length;
  XByteBuffer.toBytes(message.getLength(),data,offset);
  offset+=4;
  System.arraycopy(message.getBytesDirect(),0,data,offset,message.getLength());
  offset+=message.getLength();
  return data;
}
