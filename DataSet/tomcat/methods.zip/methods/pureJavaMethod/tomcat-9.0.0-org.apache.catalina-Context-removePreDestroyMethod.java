/** 
 * Removes the pre destroy method definition for the given class, if it exists; otherwise, no action is taken.
 * @param clazz Fully qualified class name
 */
public void removePreDestroyMethod(String clazz);
