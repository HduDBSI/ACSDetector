/** 
 * Return the servlet output stream associated with this Response.
 * @exception IllegalStateException if <code>getWriter</code> hasalready been called for this response
 * @exception IOException if an input/output error occurs
 */
@Override public ServletOutputStream getOutputStream() throws IOException {
  if (writer != null)   throw new IllegalStateException("getWriter() has already been called for this response");
  if (stream == null)   stream=createOutputStream();
  if (debug > 1) {
    System.out.println("stream is set to " + stream + " in getOutputStream");
  }
  return stream;
}
