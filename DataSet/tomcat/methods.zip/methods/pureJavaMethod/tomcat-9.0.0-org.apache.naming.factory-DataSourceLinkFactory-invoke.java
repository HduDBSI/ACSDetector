@Override public Object invoke(Object proxy,Method method,Object[] args) throws Throwable {
  if ("getConnection".equals(method.getName()) && (args == null || args.length == 0)) {
    args=new String[]{username,password};
    method=getConnection;
  }
 else   if ("unwrap".equals(method.getName())) {
    return unwrap((Class<?>)args[0]);
  }
  try {
    return method.invoke(ds,args);
  }
 catch (  Throwable t) {
    if (t instanceof InvocationTargetException && t.getCause() != null) {
      throw t.getCause();
    }
 else {
      throw t;
    }
  }
}
