/** 
 * Get the readme file as a string.
 * @param directory The directory to search
 * @param encoding The readme encoding
 * @return the readme for the specified directory
 */
protected String getReadme(WebResource directory,String encoding){
  if (readmeFile != null) {
    WebResource resource=resources.getResource(directory.getWebappPath() + readmeFile);
    if (resource.isFile()) {
      StringWriter buffer=new StringWriter();
      InputStreamReader reader=null;
      try (InputStream is=resource.getInputStream()){
        if (encoding != null) {
          reader=new InputStreamReader(is,encoding);
        }
 else {
          reader=new InputStreamReader(is);
        }
        copyRange(reader,new PrintWriter(buffer));
      }
 catch (      IOException e) {
        log("Failure to close reader",e);
      }
 finally {
        if (reader != null) {
          try {
            reader.close();
          }
 catch (          IOException e) {
          }
        }
      }
      return buffer.toString();
    }
 else {
      if (debug > 10)       log("readme '" + readmeFile + "' not found");
      return null;
    }
  }
  return null;
}
