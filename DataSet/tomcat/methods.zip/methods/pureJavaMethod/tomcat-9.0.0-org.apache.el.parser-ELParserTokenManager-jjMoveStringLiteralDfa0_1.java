private int jjMoveStringLiteralDfa0_1(){
switch (curChar) {
case 33:
    jjmatchedKind=37;
  return jjMoveStringLiteralDfa1_1(0x800000000L);
case 37:
return jjStopAtPos(0,51);
case 38:
return jjMoveStringLiteralDfa1_1(0x8000000000L);
case 40:
return jjStopAtPos(0,18);
case 41:
return jjStopAtPos(0,19);
case 42:
return jjStopAtPos(0,45);
case 43:
jjmatchedKind=46;
return jjMoveStringLiteralDfa1_1(0x20000000000000L);
case 44:
return jjStopAtPos(0,24);
case 45:
jjmatchedKind=47;
return jjMoveStringLiteralDfa1_1(0x80000000000000L);
case 46:
return jjStartNfaWithStates_1(0,17,1);
case 47:
return jjStopAtPos(0,49);
case 58:
return jjStopAtPos(0,22);
case 59:
return jjStopAtPos(0,23);
case 60:
jjmatchedKind=27;
return jjMoveStringLiteralDfa1_1(0x80000000L);
case 61:
jjmatchedKind=54;
return jjMoveStringLiteralDfa1_1(0x200000000L);
case 62:
jjmatchedKind=25;
return jjMoveStringLiteralDfa1_1(0x20000000L);
case 63:
return jjStopAtPos(0,48);
case 91:
return jjStopAtPos(0,20);
case 93:
return jjStopAtPos(0,21);
case 97:
return jjMoveStringLiteralDfa1_1(0x10000000000L);
case 100:
return jjMoveStringLiteralDfa1_1(0x4000000000000L);
case 101:
return jjMoveStringLiteralDfa1_1(0x80400000000L);
case 102:
return jjMoveStringLiteralDfa1_1(0x8000L);
case 103:
return jjMoveStringLiteralDfa1_1(0x44000000L);
case 105:
return jjMoveStringLiteralDfa1_1(0x100000000000L);
case 108:
return jjMoveStringLiteralDfa1_1(0x110000000L);
case 109:
return jjMoveStringLiteralDfa1_1(0x10000000000000L);
case 110:
return jjMoveStringLiteralDfa1_1(0x5000010000L);
case 111:
return jjMoveStringLiteralDfa1_1(0x40000000000L);
case 116:
return jjMoveStringLiteralDfa1_1(0x4000L);
case 123:
return jjStopAtPos(0,8);
case 124:
return jjMoveStringLiteralDfa1_1(0x20000000000L);
case 125:
return jjStopAtPos(0,9);
default :
return jjMoveNfa_1(0,0);
}
}
