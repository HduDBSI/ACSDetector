/** 
 * Process given socket. Called in non-comet mode, typically keep alive or upgraded protocol.
 */
public boolean processSocket(long socket,SocketStatus status){
  try {
    Executor executor=getExecutor();
    if (executor == null) {
      log.warn(sm.getString("endpoint.warn.noExector",Long.valueOf(socket),null));
    }
 else {
      SocketWrapper<Long> wrapper=connections.get(Long.valueOf(socket));
      if (wrapper != null) {
        executor.execute(new SocketProcessor(wrapper,status));
      }
    }
  }
 catch (  RejectedExecutionException x) {
    log.warn("Socket processing request was rejected for:" + socket,x);
    return false;
  }
catch (  Throwable t) {
    ExceptionUtils.handleThrowable(t);
    log.error(sm.getString("endpoint.process.fail"),t);
    return false;
  }
  return true;
}
