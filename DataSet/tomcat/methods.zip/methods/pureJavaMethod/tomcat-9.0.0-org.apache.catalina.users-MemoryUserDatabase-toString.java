/** 
 * Return a String representation of this UserDatabase.
 */
@Override public String toString(){
  StringBuilder sb=new StringBuilder("MemoryUserDatabase[id=");
  sb.append(this.id);
  sb.append(",pathname=");
  sb.append(pathname);
  sb.append(",groupCount=");
  sb.append(this.groups.size());
  sb.append(",roleCount=");
  sb.append(this.roles.size());
  sb.append(",userCount=");
  sb.append(this.users.size());
  sb.append("]");
  return sb.toString();
}
