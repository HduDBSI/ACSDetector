/** 
 * @return the compiler target VM, e.g. 1.8.
 */
public String getCompilerTargetVM();
