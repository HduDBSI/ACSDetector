/** 
 * Specify the node identifier associated with this node which will be included in the generated session ID.
 * @param jvmRoute  The node identifier
 */
public void setJvmRoute(String jvmRoute);
