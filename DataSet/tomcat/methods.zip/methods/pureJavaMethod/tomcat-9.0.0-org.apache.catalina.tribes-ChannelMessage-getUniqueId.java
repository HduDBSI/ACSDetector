/** 
 * Each message must have a globally unique Id. interceptors heavily depend on this id for message processing
 * @return byte
 */
public byte[] getUniqueId();
