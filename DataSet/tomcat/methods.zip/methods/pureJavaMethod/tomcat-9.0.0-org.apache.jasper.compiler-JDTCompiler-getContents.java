@Override public char[] getContents(){
  char[] result=null;
  try (FileInputStream is=new FileInputStream(sourceFile);InputStreamReader isr=new InputStreamReader(is,ctxt.getOptions().getJavaEncoding());Reader reader=new BufferedReader(isr)){
    char[] chars=new char[8192];
    StringBuilder buf=new StringBuilder();
    int count;
    while ((count=reader.read(chars,0,chars.length)) > 0) {
      buf.append(chars,0,count);
    }
    result=new char[buf.length()];
    buf.getChars(0,result.length,result,0);
  }
 catch (  IOException e) {
    log.error("Compilation error",e);
  }
  return result;
}
