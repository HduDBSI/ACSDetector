public void setWar(String war){
  this.war=war;
}
