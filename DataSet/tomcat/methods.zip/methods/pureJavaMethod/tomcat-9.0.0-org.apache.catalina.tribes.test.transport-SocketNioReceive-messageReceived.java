@Override public void messageReceived(ChannelMessage msg){
  if (first) {
    first=false;
    start=System.currentTimeMillis();
  }
  mb+=((double)len) / 1024 / 1024;
synchronized (this) {
    count++;
  }
  if (((count) % 10000) == 0) {
    long time=System.currentTimeMillis();
    seconds=((double)(time - start)) / 1000;
    System.out.println("Throughput " + df.format(mb / seconds) + " MB/seconds, messages "+ count+ ", total "+ mb+ " MB.");
  }
}
