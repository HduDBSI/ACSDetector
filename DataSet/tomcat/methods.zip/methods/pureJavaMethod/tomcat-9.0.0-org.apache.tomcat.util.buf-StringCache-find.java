/** 
 * Find an entry given its name in the cache and return the associated String.
 * @param name The name to find
 * @return the corresponding value
 */
protected static final String find(CharChunk name){
  int pos=findClosest(name,ccCache,ccCache.length);
  if ((pos < 0) || (compare(name,ccCache[pos].name) != 0)) {
    return null;
  }
 else {
    return ccCache[pos].value;
  }
}
