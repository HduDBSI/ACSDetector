@Test public void testHIGH() throws Exception {
  testSpecification("HIGH");
}
