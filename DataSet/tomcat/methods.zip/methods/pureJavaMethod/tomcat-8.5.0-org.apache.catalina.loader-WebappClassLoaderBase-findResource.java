/** 
 * Find the specified resource in our local repository, and return a <code>URL</code> referring to it, or <code>null</code> if this resource cannot be found.
 * @param name Name of the resource to be found
 */
@Override public URL findResource(final String name){
  if (log.isDebugEnabled())   log.debug("    findResource(" + name + ")");
  checkStateForResourceLoading(name);
  URL url=null;
  String path=nameToPath(name);
  WebResource resource=resources.getClassLoaderResource(path);
  if (resource.exists()) {
    url=resource.getURL();
    trackLastModified(path,resource);
  }
  if ((url == null) && hasExternalRepositories) {
    url=super.findResource(name);
  }
  if (log.isDebugEnabled()) {
    if (url != null)     log.debug("    --> Returning '" + url.toString() + "'");
 else     log.debug("    --> Resource not found, returning null");
  }
  return url;
}
