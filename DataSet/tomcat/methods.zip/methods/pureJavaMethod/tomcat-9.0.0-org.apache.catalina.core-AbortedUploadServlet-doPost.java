@Override protected void doPost(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
  PrintWriter out=resp.getWriter();
  resp.setContentType("text/plain");
  resp.setCharacterEncoding("UTF-8");
  StringBuilder sb=new StringBuilder();
  try {
    Collection<Part> c=req.getParts();
    if (c == null) {
      log.debug("Count: -1");
      sb.append("Count: -1\n");
    }
 else {
      log.debug("Count: " + c.size());
      sb.append("Count: " + c.size() + "\n");
      for (      Part p : c) {
        log.debug("Name: " + p.getName() + ", Size: "+ p.getSize());
        sb.append("Name: " + p.getName() + ", Size: "+ p.getSize()+ "\n");
      }
    }
  }
 catch (  IllegalStateException ex) {
    log.debug("IllegalStateException during getParts()");
    sb.append("IllegalStateException during getParts()\n");
    resp.setStatus(500);
  }
catch (  Throwable ex) {
    log.error("Exception during getParts()",ex);
    sb.append(ex);
    resp.setStatus(500);
  }
  out.print(sb.toString());
  resp.flushBuffer();
}
