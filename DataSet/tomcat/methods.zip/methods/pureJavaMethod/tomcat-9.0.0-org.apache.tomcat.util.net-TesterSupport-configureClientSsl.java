protected static void configureClientSsl(){
  try {
    SSLContext sc=SSLContext.getInstance("TLS");
    sc.init(TesterSupport.getUser1KeyManagers(),TesterSupport.getTrustManagers(),null);
    javax.net.ssl.HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
  }
 catch (  Exception e) {
    e.printStackTrace();
  }
}
