@Override public Object invoke(Object proxy,Method method,Object[] args) throws Throwable {
  String name=method.getName();
  boolean read=false;
  int index=-1;
  for (int i=0; (!read) && i < readState.length; i++) {
    read=compare(name,readState[i]);
    if (read)     index=i;
  }
  boolean write=false;
  for (int i=0; (!write) && (!read) && i < writeState.length; i++) {
    write=compare(name,writeState[i]);
    if (write)     index=i;
  }
  Object result=null;
  if (read) {
switch (index) {
case 0:
{
        result=autoCommit;
        break;
      }
case 1:
{
      result=transactionIsolation;
      break;
    }
case 2:
{
    result=readOnly;
    break;
  }
case 3:
{
  result=catalog;
  break;
}
default :
}
if (result != null) return result;
}
result=super.invoke(proxy,method,args);
if (read || write) {
switch (index) {
case 0:
{
autoCommit=(Boolean)(read ? result : args[0]);
break;
}
case 1:
{
transactionIsolation=(Integer)(read ? result : args[0]);
break;
}
case 2:
{
readOnly=(Boolean)(read ? result : args[0]);
break;
}
case 3:
{
catalog=(String)(read ? result : args[0]);
break;
}
}
}
return result;
}
