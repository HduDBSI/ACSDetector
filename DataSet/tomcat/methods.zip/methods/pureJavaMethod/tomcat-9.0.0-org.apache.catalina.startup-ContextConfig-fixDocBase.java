/** 
 * Adjust docBase.
 * @throws IOException cannot access the context base path
 */
protected void fixDocBase() throws IOException {
  Host host=(Host)context.getParent();
  File appBase=host.getAppBaseFile();
  String docBase=context.getDocBase();
  if (docBase == null) {
    String path=context.getPath();
    if (path == null) {
      return;
    }
    ContextName cn=new ContextName(path,context.getWebappVersion());
    docBase=cn.getBaseName();
  }
  File file=new File(docBase);
  if (!file.isAbsolute()) {
    docBase=(new File(appBase,docBase)).getPath();
  }
 else {
    docBase=file.getCanonicalPath();
  }
  file=new File(docBase);
  String origDocBase=docBase;
  ContextName cn=new ContextName(context.getPath(),context.getWebappVersion());
  String pathName=cn.getBaseName();
  boolean unpackWARs=true;
  if (host instanceof StandardHost) {
    unpackWARs=((StandardHost)host).isUnpackWARs();
    if (unpackWARs && context instanceof StandardContext) {
      unpackWARs=((StandardContext)context).getUnpackWAR();
    }
  }
  boolean docBaseInAppBase=docBase.startsWith(appBase.getPath() + File.separatorChar);
  if (docBase.toLowerCase(Locale.ENGLISH).endsWith(".war") && !file.isDirectory()) {
    URL war=UriUtil.buildJarUrl(new File(docBase));
    if (unpackWARs) {
      docBase=ExpandWar.expand(host,war,pathName);
      file=new File(docBase);
      docBase=file.getCanonicalPath();
      if (context instanceof StandardContext) {
        ((StandardContext)context).setOriginalDocBase(origDocBase);
      }
    }
 else {
      ExpandWar.validate(host,war,pathName);
    }
  }
 else {
    File docDir=new File(docBase);
    File warFile=new File(docBase + ".war");
    URL war=null;
    if (warFile.exists() && docBaseInAppBase) {
      war=UriUtil.buildJarUrl(warFile);
    }
    if (docDir.exists()) {
      if (war != null && unpackWARs) {
        ExpandWar.expand(host,war,pathName);
      }
    }
 else {
      if (war != null) {
        if (unpackWARs) {
          docBase=ExpandWar.expand(host,war,pathName);
          file=new File(docBase);
          docBase=file.getCanonicalPath();
        }
 else {
          docBase=warFile.getCanonicalPath();
          ExpandWar.validate(host,war,pathName);
        }
      }
      if (context instanceof StandardContext) {
        ((StandardContext)context).setOriginalDocBase(origDocBase);
      }
    }
  }
  docBaseInAppBase=docBase.startsWith(appBase.getPath() + File.separatorChar);
  if (docBaseInAppBase) {
    docBase=docBase.substring(appBase.getPath().length());
    docBase=docBase.replace(File.separatorChar,'/');
    if (docBase.startsWith("/")) {
      docBase=docBase.substring(1);
    }
  }
 else {
    docBase=docBase.replace(File.separatorChar,'/');
  }
  context.setDocBase(docBase);
}
