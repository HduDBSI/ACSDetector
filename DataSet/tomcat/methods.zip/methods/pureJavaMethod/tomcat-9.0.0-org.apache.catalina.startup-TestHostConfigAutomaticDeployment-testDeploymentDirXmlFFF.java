@Test public void testDeploymentDirXmlFFF() throws Exception {
  createDirInAppbase(true);
  doTestDeployment(false,false,false,LifecycleState.FAILED,null,false,false,true);
}
