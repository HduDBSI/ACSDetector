public Member getPrimary(){
  return primary;
}
