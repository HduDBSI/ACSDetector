/** 
 * Constructor with generated Token Manager. 
 */
public ELParser(ELParserTokenManager tm){
  token_source=tm;
  token=new Token();
  jj_ntk=-1;
  jj_gen=0;
  for (int i=0; i < 52; i++)   jj_la1[i]=-1;
  for (int i=0; i < jj_2_rtns.length; i++)   jj_2_rtns[i]=new JJCalls();
}
