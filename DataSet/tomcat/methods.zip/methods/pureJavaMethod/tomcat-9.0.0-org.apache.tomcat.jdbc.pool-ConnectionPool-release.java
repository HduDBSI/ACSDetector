/** 
 * thread safe way to release a connection
 * @param con PooledConnection
 */
protected void release(PooledConnection con){
  if (con == null)   return;
  try {
    con.lock();
    if (con.release()) {
      size.addAndGet(-1);
      con.setHandler(null);
    }
    releasedCount.incrementAndGet();
  }
  finally {
    con.unlock();
  }
  if (waitcount.get() > 0) {
    idle.offer(create(true));
  }
}
