@Test public void testLong(){
  testIsSame(Long.valueOf(0x0102030405060708L));
}
