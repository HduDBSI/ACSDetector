@Override public boolean accept(Serializable s,Member m){
  return (s instanceof Data);
}
