public MapMessage(byte[] mapId,int msgtype,boolean diff,Serializable key,Serializable value,byte[] diffvalue,Member primary,Member[] nodes){
  this.mapId=mapId;
  this.msgtype=msgtype;
  this.diff=diff;
  this.key=key;
  this.value=value;
  this.diffvalue=diffvalue;
  this.nodes=nodes;
  this.primary=primary;
  setValue(value);
  setKey(key);
}
