@Test public void testAdditionXmlAddDir() throws Exception {
  doTestAddition(true,false,false,false,false,DIR,true,false,true,XML_COOKIE_NAME,NONE);
}
