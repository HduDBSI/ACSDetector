/** 
 * @return the MIME type to which the specified extension is mapped,if any; otherwise return <code>null</code>.
 * @param extension Extension to map to a MIME type
 */
@Override public String findMimeMapping(String extension){
  return mimeMappings.get(extension.toLowerCase(Locale.ENGLISH));
}
