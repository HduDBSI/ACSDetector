/** 
 * Load the class with the specified name, searching using the following algorithm until it finds and returns the class.  If the class cannot be found, returns <code>ClassNotFoundException</code>. <ul> <li>Call <code>findLoadedClass(String)</code> to check if the class has already been loaded.  If it has, the same <code>Class</code> object is returned.</li> <li>If the <code>delegate</code> property is set to <code>true</code>, call the <code>loadClass()</code> method of the parent class loader, if any.</li> <li>Call <code>findClass()</code> to find this class in our locally defined repositories.</li> <li>Call the <code>loadClass()</code> method of our parent class loader, if any.</li> </ul> If the class was found using the above steps, and the <code>resolve</code> flag is <code>true</code>, this method will then call <code>resolveClass(Class)</code> on the resulting Class object.
 * @param name Name of the class to be loaded
 * @param resolve If <code>true</code> then resolve the class
 * @exception ClassNotFoundException if the class was not found
 */
@Override public synchronized Class<?> loadClass(final String name,boolean resolve) throws ClassNotFoundException {
  Class<?> clazz=null;
  clazz=findLoadedClass(name);
  if (clazz != null) {
    if (resolve)     resolveClass(clazz);
    return clazz;
  }
  if (securityManager != null) {
    int dot=name.lastIndexOf('.');
    if (dot >= 0) {
      try {
        if (!"org.apache.jasper.runtime".equalsIgnoreCase(name.substring(0,dot))) {
          securityManager.checkPackageAccess(name.substring(0,dot));
        }
      }
 catch (      SecurityException se) {
        String error="Security Violation, attempt to use " + "Restricted Class: " + name;
        se.printStackTrace();
        throw new ClassNotFoundException(error);
      }
    }
  }
  if (!name.startsWith(Constants.JSP_PACKAGE_NAME + '.')) {
    clazz=getParent().loadClass(name);
    if (resolve)     resolveClass(clazz);
    return clazz;
  }
  return findClass(name);
}
