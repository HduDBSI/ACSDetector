/** 
 * Updates each ThreadPoolExecutor with the current time, which is the time when a context is being stopped.
 * @param context the context being stopped, used to discover all the Connectors of its parent Service.
 */
private void stopIdleThreads(Context context){
  if (serverStopping)   return;
  if (!(context instanceof StandardContext) || !((StandardContext)context).getRenewThreadsWhenStoppingContext()) {
    log.debug("Not renewing threads when the context is stopping. " + "It is not configured to do it.");
    return;
  }
  Engine engine=(Engine)context.getParent().getParent();
  Service service=engine.getService();
  Connector[] connectors=service.findConnectors();
  if (connectors != null) {
    for (    Connector connector : connectors) {
      ProtocolHandler handler=connector.getProtocolHandler();
      Executor executor=null;
      if (handler != null) {
        executor=handler.getExecutor();
      }
      if (executor instanceof ThreadPoolExecutor) {
        ThreadPoolExecutor threadPoolExecutor=(ThreadPoolExecutor)executor;
        threadPoolExecutor.contextStopping();
      }
 else       if (executor instanceof StandardThreadExecutor) {
        StandardThreadExecutor stdThreadExecutor=(StandardThreadExecutor)executor;
        stdThreadExecutor.contextStopping();
      }
    }
  }
}
