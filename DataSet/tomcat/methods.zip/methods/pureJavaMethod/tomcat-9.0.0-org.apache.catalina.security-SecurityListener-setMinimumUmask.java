/** 
 * Set the minimum umask that must be configured before Tomcat will start.
 * @param umask The 4-digit umask as returned by the OS command <i>umask</i>
 */
public void setMinimumUmask(String umask){
  if (umask == null || umask.length() == 0) {
    minimumUmask=Integer.valueOf(0);
  }
 else {
    minimumUmask=Integer.valueOf(umask,8);
  }
}
