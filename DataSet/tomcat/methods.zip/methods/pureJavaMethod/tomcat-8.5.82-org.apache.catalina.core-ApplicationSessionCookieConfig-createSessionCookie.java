/** 
 * Creates a new session cookie for the given session ID
 * @param context     The Context for the web application
 * @param sessionId   The ID of the session for which the cookie will becreated
 * @param secure      Should session cookie be configured as secure
 * @return the cookie for the session
 */
public static Cookie createSessionCookie(Context context,String sessionId,boolean secure){
  SessionCookieConfig scc=context.getServletContext().getSessionCookieConfig();
  Cookie cookie=new Cookie(SessionConfig.getSessionCookieName(context),sessionId);
  cookie.setMaxAge(scc.getMaxAge());
  cookie.setComment(scc.getComment());
  if (context.getSessionCookieDomain() == null) {
    if (scc.getDomain() != null) {
      cookie.setDomain(scc.getDomain());
    }
  }
 else {
    cookie.setDomain(context.getSessionCookieDomain());
  }
  if (scc.isSecure() || secure) {
    cookie.setSecure(true);
  }
  if (scc.isHttpOnly() || context.getUseHttpOnly()) {
    cookie.setHttpOnly(true);
  }
  cookie.setPath(SessionConfig.getSessionCookiePath(context));
  return cookie;
}
