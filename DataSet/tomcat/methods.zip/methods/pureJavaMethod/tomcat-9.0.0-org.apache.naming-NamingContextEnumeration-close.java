/** 
 * Closes this enumeration.
 */
@Override public void close() throws NamingException {
}
