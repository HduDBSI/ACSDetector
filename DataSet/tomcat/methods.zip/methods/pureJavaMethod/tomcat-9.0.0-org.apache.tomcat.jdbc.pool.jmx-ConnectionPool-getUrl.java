@Override public String getUrl(){
  return getPoolProperties().getUrl();
}
