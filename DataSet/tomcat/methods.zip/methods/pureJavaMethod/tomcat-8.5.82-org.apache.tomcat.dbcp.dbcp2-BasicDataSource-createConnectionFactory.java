/** 
 * Creates a JDBC connection factory for this data source. The JDBC driver is loaded using the following algorithm: <ol> <li>If a Driver instance has been specified via  {@link #setDriver(Driver)} use it</li><li>If no Driver instance was specified and  {@link #driverClassName} is specified that class is loaded using the{@link ClassLoader} of this class or, if {@link #driverClassLoader} is set, {@link #driverClassName} is loadedwith the specified  {@link ClassLoader}.</li> <li>If  {@link #driverClassName} is specified and the previous attempt fails, the class is loaded using thecontext class loader of the current thread.</li> <li>If a driver still isn't loaded one is loaded via the  {@link DriverManager} using the specified {@link #url}. </ol> <p> This method exists so subclasses can replace the implementation class. </p>
 * @return A new connection factory.
 * @throws SQLException If the connection factory cannot be created
 */
protected ConnectionFactory createConnectionFactory() throws SQLException {
  return ConnectionFactoryFactory.createConnectionFactory(this,DriverFactory.createDriver(this));
}
