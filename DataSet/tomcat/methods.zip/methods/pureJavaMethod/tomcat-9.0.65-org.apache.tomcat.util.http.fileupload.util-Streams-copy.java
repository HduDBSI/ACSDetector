/** 
 * Copies the contents of the given  {@link InputStream}to the given  {@link OutputStream}.
 * @param inputStream The input stream, which is being read.It is guaranteed, that  {@link InputStream#close()} is calledon the stream.
 * @param outputStream The output stream, to which data shouldbe written. May be null, in which case the input streams contents are simply discarded.
 * @param closeOutputStream True guarantees, that {@link OutputStream#close()}is called on the stream. False indicates, that only {@link OutputStream#flush()} should be called finally.
 * @param buffer Temporary buffer, which is to be used forcopying data.
 * @return Number of bytes, which have been copied.
 * @throws IOException An I/O error occurred.
 */
public static long copy(final InputStream inputStream,final OutputStream outputStream,final boolean closeOutputStream,final byte[] buffer) throws IOException {
  try (OutputStream out=outputStream;InputStream in=inputStream){
    long total=0;
    for (; ; ) {
      final int res=in.read(buffer);
      if (res == -1) {
        break;
      }
      if (res > 0) {
        total+=res;
        if (out != null) {
          out.write(buffer,0,res);
        }
      }
    }
    if (out != null) {
      if (closeOutputStream) {
        out.close();
      }
 else {
        out.flush();
      }
    }
    in.close();
    return total;
  }
 }
