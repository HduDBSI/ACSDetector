@Override public boolean matches(Object obj0,Object obj1){
  return (obj0 instanceof Double || obj1 instanceof Double || obj0 instanceof Float|| obj1 instanceof Float|| (obj0 instanceof String && ELSupport.isStringFloat((String)obj0))|| (obj1 instanceof String && ELSupport.isStringFloat((String)obj1)));
}
