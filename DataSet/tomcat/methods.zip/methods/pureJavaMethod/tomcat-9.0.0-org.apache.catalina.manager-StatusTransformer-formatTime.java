/** 
 * Display the given time in ms, either as ms or s.
 * @param obj The object to format
 * @param seconds true to display seconds, false for milliseconds
 * @return formatted time
 */
public static String formatTime(Object obj,boolean seconds){
  long time=-1L;
  if (obj instanceof Long) {
    time=((Long)obj).longValue();
  }
 else   if (obj instanceof Integer) {
    time=((Integer)obj).intValue();
  }
  if (seconds) {
    return ((((float)time) / 1000) + " s");
  }
 else {
    return (time + " ms");
  }
}
