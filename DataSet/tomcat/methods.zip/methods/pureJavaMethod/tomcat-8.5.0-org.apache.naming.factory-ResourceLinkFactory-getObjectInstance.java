/** 
 * Create a new DataSource instance.
 * @param obj The reference object describing the DataSource
 */
@Override public Object getObjectInstance(Object obj,Name name,Context nameCtx,Hashtable<?,?> environment) throws NamingException {
  if (!(obj instanceof ResourceLinkRef))   return null;
  Reference ref=(Reference)obj;
  String globalName=null;
  RefAddr refAddr=ref.get(ResourceLinkRef.GLOBALNAME);
  if (refAddr != null) {
    globalName=refAddr.getContent().toString();
    Object result=null;
    result=globalContext.lookup(globalName);
    return result;
  }
  return (null);
}
