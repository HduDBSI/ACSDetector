protected void printThreadResults(TestThread[] threads,String name,int active,int expected){
  long minfetch=Long.MAX_VALUE, maxfetch=Long.MIN_VALUE, totalfetch=0;
  long maxwait=0, minwait=Long.MAX_VALUE, totalwait=0;
  for (int i=0; i < threads.length; i++) {
    TestThread t=threads[i];
    totalfetch+=t.nroffetch;
    totalwait+=t.totalwait;
    maxwait=Math.max(maxwait,t.maxwait);
    minwait=Math.min(minwait,t.minwait);
    minfetch=Math.min(minfetch,t.nroffetch);
    maxfetch=Math.max(maxfetch,t.nroffetch);
    if (ConnectCountTest.this.printthread)     System.out.println(t.getName() + " : Nr-of-fetch:" + t.nroffetch+ " Max fetch Time:"+ t.maxwait / 1000000f + "ms. :Max close time:" + t.cmax / 1000000f + "ms.");
  }
  System.out.println("[" + name + "] Max fetch:"+ (maxfetch)+ " Min fetch:"+ (minfetch)+ " Average fetch:"+ (((float)totalfetch)) / (float)threads.length);
  System.out.println("[" + name + "] Max wait:"+ maxwait / 1000000f + "ms. Min wait:" + minwait / 1000000f + "ms. Average wait:" + (((((float)totalwait)) / (float)totalfetch) / 1000000f) + " ms.");
  System.out.println("[" + name + "] Max active:"+ active+ " Expected Active:"+ expected);
}
