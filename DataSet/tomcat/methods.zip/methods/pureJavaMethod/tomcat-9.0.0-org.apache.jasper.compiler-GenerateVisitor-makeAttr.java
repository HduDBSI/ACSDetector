/** 
 * @return a string for the form 'attr = "value"'
 */
private String makeAttr(String attr,String value){
  if (value == null)   return "";
  return " " + attr + "=\""+ value+ '\"';
}
