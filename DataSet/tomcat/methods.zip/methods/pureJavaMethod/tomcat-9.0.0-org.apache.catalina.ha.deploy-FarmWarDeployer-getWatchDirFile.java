public File getWatchDirFile(){
  if (watchDirFile != null)   return watchDirFile;
  File dir=getAbsolutePath(getWatchDir());
  this.watchDirFile=dir;
  return dir;
}
