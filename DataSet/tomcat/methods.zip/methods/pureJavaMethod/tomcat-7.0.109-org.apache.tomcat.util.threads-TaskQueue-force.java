public boolean force(Runnable o,long timeout,TimeUnit unit) throws InterruptedException {
  if (parent == null || parent.isShutdown())   throw new RejectedExecutionException(sm.getString("taskQueue.notRunning"));
  return super.offer(o,timeout,unit);
}
