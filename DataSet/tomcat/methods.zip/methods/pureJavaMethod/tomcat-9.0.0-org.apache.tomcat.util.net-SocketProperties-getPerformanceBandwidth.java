public int getPerformanceBandwidth(){
  return performanceBandwidth.intValue();
}
