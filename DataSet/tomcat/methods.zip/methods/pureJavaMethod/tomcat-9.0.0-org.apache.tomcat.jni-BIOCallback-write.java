/** 
 * Write data
 * @param buf containing the bytes to write.
 * @return Number of characters written.
 */
public int write(byte[] buf);
