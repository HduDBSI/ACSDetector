/** 
 * @return response status code that is used to reject denied request.
 */
public int getDenyStatus(){
  return denyStatus;
}
