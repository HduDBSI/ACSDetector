@Override public void memberDisappeared(Member member){
  if (members.contains(member)) {
    members.remove(member);
    try {
      System.out.println(name + ":member disappeared[" + new String(member.getPayload(),"ASCII")+ "; Thread:"+ Thread.currentThread().getName()+ "]");
    }
 catch (    Exception x) {
      System.out.println(name + ":member disappeared[unknown]");
    }
  }
}
