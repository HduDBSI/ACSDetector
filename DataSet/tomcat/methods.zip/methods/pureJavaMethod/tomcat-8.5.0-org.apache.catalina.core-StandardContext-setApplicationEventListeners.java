/** 
 * {@inheritDoc}Note that this implementation is not thread safe. If two threads call this method concurrently, the result may be either set of listeners or a the union of both.
 */
@Override public void setApplicationEventListeners(Object listeners[]){
  applicationEventListenersList.clear();
  if (listeners != null && listeners.length > 0) {
    applicationEventListenersList.addAll(Arrays.asList(listeners));
  }
}
