private boolean hasJspRoot(JspReader reader){
  Mark start=null;
  while ((start=reader.skipUntil("<")) != null) {
    int c=reader.nextChar();
    if (c != '!' && c != '?')     break;
  }
  if (start == null) {
    return false;
  }
  Mark stop=reader.skipUntil(":root");
  if (stop == null) {
    return false;
  }
  String prefix=reader.getText(start,stop).substring(1);
  start=stop;
  stop=reader.skipUntil(">");
  if (stop == null) {
    return false;
  }
  String root=reader.getText(start,stop);
  String xmlnsDecl="xmlns:" + prefix;
  int index=root.indexOf(xmlnsDecl);
  if (index == -1) {
    return false;
  }
  index+=xmlnsDecl.length();
  while (index < root.length() && Character.isWhitespace(root.charAt(index))) {
    index++;
  }
  if (index < root.length() && root.charAt(index) == '=') {
    index++;
    while (index < root.length() && Character.isWhitespace(root.charAt(index))) {
      index++;
    }
    if (index < root.length() && (root.charAt(index) == '"' || root.charAt(index) == '\'')) {
      index++;
      if (root.regionMatches(index,JSP_URI,0,JSP_URI.length())) {
        return true;
      }
    }
  }
  return false;
}
