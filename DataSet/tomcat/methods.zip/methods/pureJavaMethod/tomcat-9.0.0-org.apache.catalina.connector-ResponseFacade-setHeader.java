@Override public void setHeader(String name,String value){
  if (isCommitted()) {
    return;
  }
  response.setHeader(name,value);
}
