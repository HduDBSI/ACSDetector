private void register(Request request,HttpServletResponse response,Principal principal,String authType,String username,String password,boolean alwaysUseSession,boolean cache){
  if (log.isDebugEnabled()) {
    String name=(principal == null) ? "none" : principal.getName();
    log.debug("Authenticated '" + name + "' with type '"+ authType+ "'");
  }
  request.setAuthType(authType);
  request.setUserPrincipal(principal);
  Session session=request.getSessionInternal(false);
  if (session != null) {
    if (changeSessionIdOnAuthentication && principal != null) {
      String oldId=null;
      if (log.isDebugEnabled()) {
        oldId=session.getId();
      }
      Manager manager=request.getContext().getManager();
      manager.changeSessionId(session);
      request.changeSessionId(session.getId());
      if (log.isDebugEnabled()) {
        log.debug(sm.getString("authenticator.changeSessionId",oldId,session.getId()));
      }
    }
  }
 else   if (alwaysUseSession) {
    session=request.getSessionInternal(true);
  }
  if (cache) {
    if (session != null) {
      session.setAuthType(authType);
      session.setPrincipal(principal);
      if (username != null) {
        session.setNote(Constants.SESS_USERNAME_NOTE,username);
      }
 else {
        session.removeNote(Constants.SESS_USERNAME_NOTE);
      }
      if (password != null) {
        session.setNote(Constants.SESS_PASSWORD_NOTE,password);
      }
 else {
        session.removeNote(Constants.SESS_PASSWORD_NOTE);
      }
    }
  }
  if (sso == null) {
    return;
  }
  String ssoId=(String)request.getNote(Constants.REQ_SSOID_NOTE);
  if (ssoId == null) {
    ssoId=sessionIdGenerator.generateSessionId();
    Cookie cookie=new Cookie(Constants.SINGLE_SIGN_ON_COOKIE,ssoId);
    cookie.setMaxAge(-1);
    cookie.setPath("/");
    cookie.setSecure(request.isSecure());
    String ssoDomain=sso.getCookieDomain();
    if (ssoDomain != null) {
      cookie.setDomain(ssoDomain);
    }
    if (request.getServletContext().getSessionCookieConfig().isHttpOnly() || request.getContext().getUseHttpOnly()) {
      cookie.setHttpOnly(true);
    }
    response.addCookie(cookie);
    sso.register(ssoId,principal,authType,username,password);
    request.setNote(Constants.REQ_SSOID_NOTE,ssoId);
  }
 else {
    if (principal == null) {
      sso.deregister(ssoId);
      request.removeNote(Constants.REQ_SSOID_NOTE);
      return;
    }
 else {
      sso.update(ssoId,principal,authType,username,password);
    }
  }
  if (session == null) {
    session=request.getSessionInternal(true);
  }
  sso.associate(ssoId,session);
}
