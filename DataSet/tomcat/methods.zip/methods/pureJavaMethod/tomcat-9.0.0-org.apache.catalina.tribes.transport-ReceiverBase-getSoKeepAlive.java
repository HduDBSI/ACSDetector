public boolean getSoKeepAlive(){
  return soKeepAlive;
}
