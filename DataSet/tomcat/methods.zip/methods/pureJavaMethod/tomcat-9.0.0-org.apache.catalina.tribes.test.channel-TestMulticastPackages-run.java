@Override public void run(){
  try {
    long start=System.currentTimeMillis();
    for (int i=0; i < msgCount; i++) {
      int cnt=counter.getAndAdd(1);
      channel1.send(new Member[]{channel2.getLocalMember(false)},Data.createRandomData(1024,cnt),Channel.SEND_OPTIONS_MULTICAST | Channel.SEND_OPTIONS_ASYNCHRONOUS);
    }
    System.out.println("Thread[" + this.getName() + "] sent "+ msgCount+ " messages in "+ (System.currentTimeMillis() - start)+ " ms.");
  }
 catch (  Exception x) {
    x.printStackTrace();
  }
}
