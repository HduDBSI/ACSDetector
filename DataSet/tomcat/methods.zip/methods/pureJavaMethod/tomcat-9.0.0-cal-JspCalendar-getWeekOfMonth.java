public int getWeekOfMonth(){
  return calendar.get(Calendar.WEEK_OF_MONTH);
}
