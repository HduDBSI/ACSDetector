public boolean isStripRealmForGss(){
  return stripRealmForGss;
}
