@Test public void testThreadLocalLeak2() throws Exception {
  Tomcat tomcat=getTomcatInstance();
  tomcat.getServer().addLifecycleListener(new JreMemoryLeakPreventionListener());
  Context ctx=tomcat.addContext("",null);
  Tomcat.addServlet(ctx,"leakServlet2","org.apache.tomcat.unittest.TesterLeakingServlet2");
  ctx.addServletMapping("/leak2","leakServlet2");
  tomcat.start();
  Executor executor=tomcat.getConnector().getProtocolHandler().getExecutor();
  ((ThreadPoolExecutor)executor).setThreadRenewalDelay(-1);
  LogValidationFilter f=new LogValidationFilter("The web application [ROOT] created a ThreadLocal with key of");
  LogManager.getLogManager().getLogger("org.apache.catalina.loader.WebappClassLoaderBase").setFilter(f);
  loadClass("TesterCounter",(WebappClassLoader)ctx.getLoader().getClassLoader());
  loadClass("TesterThreadScopedHolder",(WebappClassLoader)ctx.getLoader().getClassLoader());
  loadClass("TesterLeakingServlet2",(WebappClassLoader)ctx.getLoader().getClassLoader());
  int rc=getUrl("http://localhost:" + getPort() + "/leak2",new ByteChunk(),null);
  Assert.assertEquals(HttpServletResponse.SC_OK,rc);
  ctx.stop();
  tomcat.getHost().removeChild(ctx);
  ctx=null;
  String[] leaks=((StandardHost)tomcat.getHost()).findReloadedContextMemoryLeaks();
  Assert.assertNotNull(leaks);
  Assert.assertTrue(leaks.length > 0);
  Assert.assertEquals(1,f.getMessageCount());
}
