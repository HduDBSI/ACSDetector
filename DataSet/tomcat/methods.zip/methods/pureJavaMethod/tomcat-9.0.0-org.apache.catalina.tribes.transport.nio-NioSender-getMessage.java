public byte[] getMessage(){
  return current;
}
