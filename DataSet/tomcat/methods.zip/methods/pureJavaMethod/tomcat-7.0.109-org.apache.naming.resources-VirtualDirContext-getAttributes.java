@Override public Attributes getAttributes(String name) throws NamingException {
  NamingException initialException;
  try {
    Attributes attributes=super.getAttributes(name);
    return attributes;
  }
 catch (  NamingException exc) {
    initialException=exc;
  }
  if (mappedResourcePaths != null) {
    for (    Map.Entry<String,List<String>> mapping : mappedResourcePaths.entrySet()) {
      String path=mapping.getKey();
      List<String> dirList=mapping.getValue();
      String resourcesDir=dirList.get(0);
      if (name.equals(path)) {
        File f=new File(resourcesDir);
        f=validate(f,name,true,resourcesDir);
        if (f != null) {
          return new FileResourceAttributes(f);
        }
      }
      path+="/";
      if (name.startsWith(path)) {
        String res=name.substring(path.length());
        File f=new File(resourcesDir,res);
        f=validate(f,res,true,resourcesDir);
        if (f != null) {
          return new FileResourceAttributes(f);
        }
      }
    }
  }
  throw initialException;
}
