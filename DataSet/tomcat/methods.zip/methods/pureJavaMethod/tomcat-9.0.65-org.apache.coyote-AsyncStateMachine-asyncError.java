synchronized boolean asyncError(){
  clearNonBlockingListeners();
  if (state == AsyncState.STARTING) {
    updateState(AsyncState.MUST_ERROR);
  }
 else   if (state == AsyncState.DISPATCHED) {
    asyncCtxt.incrementInProgressAsyncCount();
    updateState(AsyncState.ERROR);
  }
 else {
    updateState(AsyncState.ERROR);
  }
  Request request=processor.getRequest();
  return request == null || !request.isRequestThread();
}
