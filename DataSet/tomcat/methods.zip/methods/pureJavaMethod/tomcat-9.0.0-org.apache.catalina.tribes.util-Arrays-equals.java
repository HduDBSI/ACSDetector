public static boolean equals(Object[] o1,Object[] o2){
  boolean result=o1.length == o2.length;
  if (result)   for (int i=0; i < o1.length && result; i++)   result=o1[i].equals(o2[i]);
  return result;
}
