public boolean setErrorReported(){
  return getCoyoteResponse().setErrorReported();
}
