@Test public void testPreparedStatementCache2() throws Exception {
  init();
  config(false,false,100);
  Connection con=datasource.getConnection();
  PreparedStatement ps1=con.prepareStatement("select 1");
  PreparedStatement ps2=con.prepareStatement("select 1");
  Assert.assertEquals(0,interceptor.getCacheSize().get());
  ps1.close();
  Assert.assertTrue(ps1.isClosed());
  Assert.assertEquals(0,interceptor.getCacheSize().get());
  PreparedStatement ps3=con.prepareStatement("select 1");
  Assert.assertEquals(0,interceptor.getCacheSize().get());
  ps2.close();
  Assert.assertTrue(ps2.isClosed());
  ps3.close();
  Assert.assertTrue(ps3.isClosed());
  Assert.assertEquals(0,interceptor.getCacheSize().get());
}
