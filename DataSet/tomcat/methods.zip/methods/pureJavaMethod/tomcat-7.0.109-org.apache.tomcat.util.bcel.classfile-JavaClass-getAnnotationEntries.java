/** 
 * Return annotations entries from "RuntimeVisibleAnnotations" attribute on the class, if there is any.
 * @return An array of entries or {@code null}
 */
public AnnotationEntry[] getAnnotationEntries(){
  if (runtimeVisibleAnnotations != null) {
    return runtimeVisibleAnnotations.getAnnotationEntries();
  }
  return null;
}
