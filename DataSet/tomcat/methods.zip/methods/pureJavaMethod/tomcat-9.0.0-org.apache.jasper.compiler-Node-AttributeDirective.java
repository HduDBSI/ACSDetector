public AttributeDirective(String qName,Attributes attrs,Attributes nonTaglibXmlnsAttrs,Attributes taglibAttrs,Mark start,Node parent){
  super(qName,ATTRIBUTE_DIRECTIVE_ACTION,attrs,nonTaglibXmlnsAttrs,taglibAttrs,start,parent);
}
