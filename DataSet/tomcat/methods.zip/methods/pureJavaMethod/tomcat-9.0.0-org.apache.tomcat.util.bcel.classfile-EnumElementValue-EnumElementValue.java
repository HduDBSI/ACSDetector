EnumElementValue(final int type,final int valueIdx,final ConstantPool cpool){
  super(type,cpool);
  if (type != ENUM_CONSTANT)   throw new RuntimeException("Only element values of type enum can be built with this ctor - type specified: " + type);
  this.valueIdx=valueIdx;
}
