@Override public void lifecycleEvent(LifecycleEvent event){
  if (Lifecycle.BEFORE_INIT_EVENT.equals(event.getType())) {
    ClassLoader loader=Thread.currentThread().getContextClassLoader();
    try {
      Thread.currentThread().setContextClassLoader(ClassLoader.getSystemClassLoader());
      if (driverManagerProtection) {
        DriverManager.getDrivers();
      }
      if (awtThreadProtection && !JreCompat.isJre9Available()) {
        java.awt.Toolkit.getDefaultToolkit();
      }
      if (gcDaemonProtection && !JreCompat.isJre9Available()) {
        try {
          Class<?> clazz=Class.forName("sun.misc.GC");
          Method method=clazz.getDeclaredMethod("requestLatency",new Class[]{long.class});
          method.invoke(null,Long.valueOf(Long.MAX_VALUE - 1));
        }
 catch (        ClassNotFoundException e) {
          if (JreVendor.IS_ORACLE_JVM) {
            log.error(sm.getString("jreLeakListener.gcDaemonFail"),e);
          }
 else {
            log.debug(sm.getString("jreLeakListener.gcDaemonFail"),e);
          }
        }
catch (        SecurityException|NoSuchMethodException|IllegalArgumentException|IllegalAccessException e) {
          log.error(sm.getString("jreLeakListener.gcDaemonFail"),e);
        }
catch (        InvocationTargetException e) {
          ExceptionUtils.handleThrowable(e.getCause());
          log.error(sm.getString("jreLeakListener.gcDaemonFail"),e);
        }
      }
      if (tokenPollerProtection && !JreCompat.isJre9Available()) {
        java.security.Security.getProviders();
      }
      if (urlCacheProtection) {
        try {
          JreCompat.getInstance().disableCachingForJarUrlConnections();
        }
 catch (        IOException e) {
          log.error(sm.getString("jreLeakListener.jarUrlConnCacheFail"),e);
        }
      }
      if (xmlParsingProtection && !JreCompat.isJre9Available()) {
        DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance();
        try {
          DocumentBuilder documentBuilder=factory.newDocumentBuilder();
          Document document=documentBuilder.newDocument();
          document.createElement("dummy");
          DOMImplementationLS implementation=(DOMImplementationLS)document.getImplementation();
          implementation.createLSSerializer().writeToString(document);
          document.normalize();
        }
 catch (        ParserConfigurationException e) {
          log.error(sm.getString("jreLeakListener.xmlParseFail"),e);
        }
      }
      if (ldapPoolProtection && !JreCompat.isJre9Available()) {
        try {
          Class.forName("com.sun.jndi.ldap.LdapPoolManager");
        }
 catch (        ClassNotFoundException e) {
          if (JreVendor.IS_ORACLE_JVM) {
            log.error(sm.getString("jreLeakListener.ldapPoolManagerFail"),e);
          }
 else {
            log.debug(sm.getString("jreLeakListener.ldapPoolManagerFail"),e);
          }
        }
      }
      if (forkJoinCommonPoolProtection) {
        if (System.getProperty(FORK_JOIN_POOL_THREAD_FACTORY_PROPERTY) == null) {
          System.setProperty(FORK_JOIN_POOL_THREAD_FACTORY_PROPERTY,SafeForkJoinWorkerThreadFactory.class.getName());
        }
      }
      if (classesToInitialize != null) {
        StringTokenizer strTok=new StringTokenizer(classesToInitialize,", \r\n\t");
        while (strTok.hasMoreTokens()) {
          String classNameToLoad=strTok.nextToken();
          try {
            Class.forName(classNameToLoad);
          }
 catch (          ClassNotFoundException e) {
            log.error(sm.getString("jreLeakListener.classToInitializeFail",classNameToLoad),e);
          }
        }
      }
    }
  finally {
      Thread.currentThread().setContextClassLoader(loader);
    }
  }
}
