@Override public void reset(ConnectionPool parent,PooledConnection con){
  super.reset(parent,con);
  if (parent != null) {
    poolName=parent.getName();
    pool=parent;
    registerJmx();
  }
}
