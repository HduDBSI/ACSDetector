public boolean isCompleted(){
  return completed;
}
