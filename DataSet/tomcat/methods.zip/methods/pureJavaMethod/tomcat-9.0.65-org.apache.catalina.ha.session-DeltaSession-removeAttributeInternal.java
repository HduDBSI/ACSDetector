protected void removeAttributeInternal(String name,boolean notify,boolean addDeltaRequest){
  lockInternal();
  try {
    Object value=attributes.get(name);
    if (value == null) {
      return;
    }
    super.removeAttributeInternal(name,notify);
    if (addDeltaRequest && !exclude(name,null)) {
      deltaRequest.removeAttribute(name);
    }
  }
  finally {
    unlockInternal();
  }
}
