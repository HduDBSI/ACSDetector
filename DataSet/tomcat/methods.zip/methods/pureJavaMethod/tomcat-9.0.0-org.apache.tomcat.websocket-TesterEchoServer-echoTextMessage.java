@OnMessage public void echoTextMessage(Session session,String msg){
  try {
    session.getBasicRemote().sendText(msg);
  }
 catch (  IOException e) {
    try {
      session.close();
    }
 catch (    IOException e1) {
    }
  }
}
