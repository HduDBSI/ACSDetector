public ExpiresConfiguration(StartingPoint startingPoint,List<Duration> durations){
  super();
  this.startingPoint=startingPoint;
  this.durations=durations;
}
