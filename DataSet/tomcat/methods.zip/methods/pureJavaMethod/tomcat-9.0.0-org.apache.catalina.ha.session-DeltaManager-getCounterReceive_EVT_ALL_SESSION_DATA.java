/** 
 * @return Returns the counterReceive_EVT_ALL_SESSION_DATA.
 */
public long getCounterReceive_EVT_ALL_SESSION_DATA(){
  return counterReceive_EVT_ALL_SESSION_DATA;
}
