@Test public void testPoolThreads20Connections10FairAsync() throws Exception {
  System.out.println("[testPoolThreads20Connections10FairAsync] Starting fairness - Tomcat JDBC - Fair - Async");
  this.datasource.getPoolProperties().setMaxActive(10);
  this.datasource.getPoolProperties().setFairQueue(true);
  this.threadcount=20;
  this.transferProperties();
  this.datasource.getConnection().close();
  latch=new CountDownLatch(threadcount);
  long start=System.currentTimeMillis();
  TestThread[] threads=new TestThread[threadcount];
  for (int i=0; i < threadcount; i++) {
    threads[i]=new TestThread();
    threads[i].setName("tomcat-pool-" + i);
    threads[i].async=true;
    threads[i].d=this.datasource;
  }
  for (int i=0; i < threadcount; i++) {
    threads[i].start();
  }
  if (!latch.await(complete + 1000,TimeUnit.MILLISECONDS)) {
    System.out.println("Latch timed out.");
  }
  this.run=false;
  long delta=System.currentTimeMillis() - start;
  printThreadResults(threads,"testPoolThreads20Connections10FairAsync",this.datasource.getSize(),10);
  System.out.println("Test completed in: " + delta + "ms.");
}
