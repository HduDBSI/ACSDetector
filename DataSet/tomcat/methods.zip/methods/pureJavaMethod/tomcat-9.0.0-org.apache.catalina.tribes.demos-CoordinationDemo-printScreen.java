public synchronized void printScreen(){
  clearScreen();
  System.out.println(" ###." + getHeader());
  for (int i=0; i < status.length; i++) {
    System.out.print(leftfill(String.valueOf(i + 1) + ".",5," "));
    if (status[i] != null)     System.out.print(status[i].getStatusLine());
  }
  System.out.println("\n\n");
  System.out.println("Overall status:" + statusLine);
  printMenuOptions();
}
