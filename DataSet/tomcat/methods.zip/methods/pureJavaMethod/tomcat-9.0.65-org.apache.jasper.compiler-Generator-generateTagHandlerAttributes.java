/** 
 * Generates declarations for tag handler attributes, and defines the getter and setter methods for each.
 */
private void generateTagHandlerAttributes(TagInfo tagInfo){
  if (tagInfo.hasDynamicAttributes()) {
    out.printil("private java.util.HashMap _jspx_dynamic_attrs = new java.util.HashMap();");
  }
  TagAttributeInfo[] attrInfos=tagInfo.getAttributes();
  for (  TagAttributeInfo info : attrInfos) {
    out.printin("private ");
    if (info.isFragment()) {
      out.print("javax.servlet.jsp.tagext.JspFragment ");
    }
 else {
      out.print(JspUtil.toJavaSourceType(info.getTypeName()));
      out.print(" ");
    }
    out.print(JspUtil.makeJavaIdentifierForAttribute(info.getName()));
    out.println(";");
  }
  out.println();
  for (  TagAttributeInfo attrInfo : attrInfos) {
    String javaName=JspUtil.makeJavaIdentifierForAttribute(attrInfo.getName());
    out.printin("public ");
    if (attrInfo.isFragment()) {
      out.print("javax.servlet.jsp.tagext.JspFragment ");
    }
 else {
      out.print(JspUtil.toJavaSourceType(attrInfo.getTypeName()));
      out.print(" ");
    }
    out.print(toGetterMethod(attrInfo.getName()));
    out.println(" {");
    out.pushIndent();
    out.printin("return this.");
    out.print(javaName);
    out.println(";");
    out.popIndent();
    out.printil("}");
    out.println();
    out.printin("public void ");
    out.print(toSetterMethodName(attrInfo.getName()));
    if (attrInfo.isFragment()) {
      out.print("(javax.servlet.jsp.tagext.JspFragment ");
    }
 else {
      out.print("(");
      out.print(JspUtil.toJavaSourceType(attrInfo.getTypeName()));
      out.print(" ");
    }
    out.print(javaName);
    out.println(") {");
    out.pushIndent();
    out.printin("this.");
    out.print(javaName);
    out.print(" = ");
    out.print(javaName);
    out.println(";");
    out.printin("jspContext.setAttribute(\"");
    out.print(attrInfo.getName());
    out.print("\", ");
    out.print(javaName);
    out.println(");");
    out.popIndent();
    out.printil("}");
    out.println();
  }
}
