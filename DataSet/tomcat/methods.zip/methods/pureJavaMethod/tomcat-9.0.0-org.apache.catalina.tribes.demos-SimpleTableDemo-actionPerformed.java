@Override public void actionPerformed(ActionEvent e){
  System.out.println(e.getActionCommand());
  if ("add".equals(e.getActionCommand())) {
    System.out.println("Add key:" + txtAddKey.getText() + " value:"+ txtAddValue.getText());
    map.put(txtAddKey.getText(),new StringBuilder(txtAddValue.getText()));
  }
  if ("change".equals(e.getActionCommand())) {
    System.out.println("Change key:" + txtChangeKey.getText() + " value:"+ txtChangeValue.getText());
    StringBuilder buf=map.get(txtChangeKey.getText());
    if (buf != null) {
      buf.delete(0,buf.length());
      buf.append(txtChangeValue.getText());
      map.replicate(txtChangeKey.getText(),true);
    }
 else {
      buf=new StringBuilder();
      buf.append(txtChangeValue.getText());
      map.put(txtChangeKey.getText(),buf);
    }
  }
  if ("remove".equals(e.getActionCommand())) {
    System.out.println("Remove key:" + txtRemoveKey.getText());
    map.remove(txtRemoveKey.getText());
  }
  if ("sync".equals(e.getActionCommand())) {
    System.out.println("Syncing from another node.");
    map.transferState();
  }
  if ("random".equals(e.getActionCommand())) {
    Thread t=new Thread(){
      @Override public void run(){
        for (int i=0; i < 5; i++) {
          String key=random(5,0,0,true,true,null);
          map.put(key,new StringBuilder(key));
          dataModel.fireTableDataChanged();
          table.paint(table.getGraphics());
          try {
            Thread.sleep(500);
          }
 catch (          InterruptedException x) {
            Thread.interrupted();
          }
        }
      }
    }
;
    t.start();
  }
  if ("replicate".equals(e.getActionCommand())) {
    System.out.println("Replicating out to the other nodes.");
    map.replicate(true);
  }
  dataModel.getValueAt(-1,-1);
}
