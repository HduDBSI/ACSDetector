/** 
 * Unlock after serialization
 */
public void unlock();
