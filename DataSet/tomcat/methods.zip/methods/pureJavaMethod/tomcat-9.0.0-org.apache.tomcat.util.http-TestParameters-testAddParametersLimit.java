@Test public void testAddParametersLimit(){
  Parameters p=new Parameters();
  p.setLimit(2);
  Enumeration<String> names=p.getParameterNames();
  assertFalse(names.hasMoreElements());
  String[] values=p.getParameterValues("foo1");
  assertNull(values);
  p.addParameter("foo1","value1");
  names=p.getParameterNames();
  assertTrue(names.hasMoreElements());
  assertEquals("foo1",names.nextElement());
  assertFalse(names.hasMoreElements());
  values=p.getParameterValues("foo1");
  assertEquals(1,values.length);
  assertEquals("value1",values[0]);
  p.addParameter("foo2","value2");
  names=p.getParameterNames();
  assertTrue(names.hasMoreElements());
  assertEquals("foo1",names.nextElement());
  assertEquals("foo2",names.nextElement());
  assertFalse(names.hasMoreElements());
  values=p.getParameterValues("foo1");
  assertEquals(1,values.length);
  assertEquals("value1",values[0]);
  values=p.getParameterValues("foo2");
  assertEquals(1,values.length);
  assertEquals("value2",values[0]);
  IllegalStateException e=null;
  try {
    p.addParameter("foo3","value3");
  }
 catch (  IllegalStateException ise) {
    e=ise;
  }
  assertNotNull(e);
  names=p.getParameterNames();
  assertTrue(names.hasMoreElements());
  assertEquals("foo1",names.nextElement());
  assertEquals("foo2",names.nextElement());
  assertFalse(names.hasMoreElements());
  values=p.getParameterValues("foo1");
  assertEquals(1,values.length);
  assertEquals("value1",values[0]);
  values=p.getParameterValues("foo2");
  assertEquals(1,values.length);
  assertEquals("value2",values[0]);
}
