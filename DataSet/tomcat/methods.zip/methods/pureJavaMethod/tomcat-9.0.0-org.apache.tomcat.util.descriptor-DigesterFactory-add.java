private static void add(Map<String,String> ids,String id,String location){
  if (location != null) {
    ids.put(id,location);
  }
}
