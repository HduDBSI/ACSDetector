@Override protected void doWrite(SendHandler handler,long blockingWriteTimeoutExpiry,ByteBuffer... buffers){
  if (blockingWriteTimeoutExpiry == -1) {
    this.handler=handler;
    this.buffers=buffers;
    onWritePossible(true);
  }
 else {
    try {
      for (      ByteBuffer buffer : buffers) {
        long timeout=blockingWriteTimeoutExpiry - System.currentTimeMillis();
        if (timeout <= 0) {
          SendResult sr=new SendResult(new SocketTimeoutException());
          handler.onResult(sr);
          return;
        }
        socketWrapper.setWriteTimeout(timeout);
        socketWrapper.write(true,buffer);
      }
      long timeout=blockingWriteTimeoutExpiry - System.currentTimeMillis();
      if (timeout <= 0) {
        SendResult sr=new SendResult(new SocketTimeoutException());
        handler.onResult(sr);
        return;
      }
      socketWrapper.setWriteTimeout(timeout);
      socketWrapper.flush(true);
      handler.onResult(SENDRESULT_OK);
    }
 catch (    IOException e) {
      SendResult sr=new SendResult(e);
      handler.onResult(sr);
    }
  }
}
