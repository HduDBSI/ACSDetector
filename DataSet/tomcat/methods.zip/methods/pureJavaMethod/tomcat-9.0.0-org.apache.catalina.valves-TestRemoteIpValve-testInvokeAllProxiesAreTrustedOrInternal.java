@Test public void testInvokeAllProxiesAreTrustedOrInternal() throws Exception {
  RemoteIpValve remoteIpValve=new RemoteIpValve();
  remoteIpValve.setInternalProxies("192\\.168\\.0\\.10|192\\.168\\.0\\.11");
  remoteIpValve.setTrustedProxies("proxy1|proxy2|proxy3");
  remoteIpValve.setRemoteIpHeader("x-forwarded-for");
  remoteIpValve.setProxiesHeader("x-forwarded-by");
  RemoteAddrAndHostTrackerValve remoteAddrAndHostTrackerValve=new RemoteAddrAndHostTrackerValve();
  remoteIpValve.setNext(remoteAddrAndHostTrackerValve);
  Request request=new MockRequest();
  request.setCoyoteRequest(new org.apache.coyote.Request());
  request.setRemoteAddr("192.168.0.10");
  request.setRemoteHost("remote-host-original-value");
  request.getCoyoteRequest().getMimeHeaders().addValue("x-forwarded-for").setString("140.211.11.130, proxy1, proxy2, 192.168.0.10, 192.168.0.11");
  remoteIpValve.invoke(request,null);
  String actualXForwardedFor=remoteAddrAndHostTrackerValve.getForwardedFor();
  assertNull("all proxies are trusted, x-forwarded-for must be null",actualXForwardedFor);
  String actualXForwardedBy=remoteAddrAndHostTrackerValve.getForwardedBy();
  assertEquals("all proxies are trusted, they must appear in x-forwarded-by","proxy1, proxy2",actualXForwardedBy);
  String actualRemoteAddr=remoteAddrAndHostTrackerValve.getRemoteAddr();
  assertEquals("remoteAddr","140.211.11.130",actualRemoteAddr);
  String actualRemoteHost=remoteAddrAndHostTrackerValve.getRemoteHost();
  assertEquals("remoteHost","140.211.11.130",actualRemoteHost);
  String actualPostInvokeRemoteAddr=request.getRemoteAddr();
  assertEquals("postInvoke remoteAddr","192.168.0.10",actualPostInvokeRemoteAddr);
  String actualPostInvokeRemoteHost=request.getRemoteHost();
  assertEquals("postInvoke remoteAddr","remote-host-original-value",actualPostInvokeRemoteHost);
}
