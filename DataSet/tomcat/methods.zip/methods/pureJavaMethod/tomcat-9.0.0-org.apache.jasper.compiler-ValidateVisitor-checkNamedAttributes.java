private void checkNamedAttributes(Node.CustomTag n,Node.JspAttribute[] jspAttrs,int start,Hashtable<String,Object> tagDataAttrs) throws JasperException {
  TagInfo tagInfo=n.getTagInfo();
  TagAttributeInfo[] tldAttrs=tagInfo.getAttributes();
  Node.Nodes naNodes=n.getNamedAttributeNodes();
  for (int i=0; i < naNodes.size(); i++) {
    Node.NamedAttribute na=(Node.NamedAttribute)naNodes.getNode(i);
    boolean found=false;
    for (int j=0; j < tldAttrs.length; j++) {
      String attrPrefix=na.getPrefix();
      if (na.getLocalName().equals(tldAttrs[j].getName()) && (attrPrefix == null || attrPrefix.length() == 0 || attrPrefix.equals(n.getPrefix()))) {
        jspAttrs[start + i]=new Node.JspAttribute(na,tldAttrs[j],false);
        NamedAttributeVisitor nav=null;
        if (na.getBody() != null) {
          nav=new NamedAttributeVisitor();
          na.getBody().visit(nav);
        }
        if (nav != null && nav.hasDynamicContent()) {
          tagDataAttrs.put(na.getName(),TagData.REQUEST_TIME_VALUE);
        }
 else {
          tagDataAttrs.put(na.getName(),na.getText());
        }
        found=true;
        break;
      }
    }
    if (!found) {
      if (tagInfo.hasDynamicAttributes()) {
        jspAttrs[start + i]=new Node.JspAttribute(na,null,true);
      }
 else {
        err.jspError(n,"jsp.error.bad_attribute",na.getName(),n.getLocalName());
      }
    }
  }
}
