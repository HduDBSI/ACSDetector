@Override public InputSource getExternalSubset(String name,String baseURI) throws SAXException, IOException {
  return entityResolver.getExternalSubset(name,baseURI);
}
