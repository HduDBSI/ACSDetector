public Bug58624SendMessage(Session session){
  this.session=session;
}
