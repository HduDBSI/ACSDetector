@Test public void testOverrideWithSCIDefaultMapping() throws Exception {
  doTestOverrideDefaultServletWithSCI("anything");
}
