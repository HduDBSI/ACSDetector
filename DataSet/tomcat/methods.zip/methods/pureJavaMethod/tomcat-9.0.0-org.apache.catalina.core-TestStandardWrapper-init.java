@Override public void init(ServletConfig config) throws ServletException {
  super.init(config);
  data=10;
}
