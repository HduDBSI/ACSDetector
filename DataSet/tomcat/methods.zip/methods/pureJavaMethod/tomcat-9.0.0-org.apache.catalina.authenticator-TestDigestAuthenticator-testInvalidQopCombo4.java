@Test public void testInvalidQopCombo4() throws Exception {
  doTest(USER,PWD,CONTEXT_PATH + URI,false,true,REALM,true,true,null,null,CNONCE,QOP,false,false);
}
