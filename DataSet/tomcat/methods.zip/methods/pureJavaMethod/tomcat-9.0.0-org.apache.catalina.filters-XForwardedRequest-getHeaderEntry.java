protected Map.Entry<String,List<String>> getHeaderEntry(String name){
  for (  Map.Entry<String,List<String>> entry : headers.entrySet()) {
    if (entry.getKey().equalsIgnoreCase(name)) {
      return entry;
    }
  }
  return null;
}
