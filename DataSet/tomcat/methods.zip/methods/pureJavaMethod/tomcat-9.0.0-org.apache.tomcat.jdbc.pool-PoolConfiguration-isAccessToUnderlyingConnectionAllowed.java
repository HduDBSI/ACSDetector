/** 
 * Property not used. Access is always allowed. Access can be achieved by calling unwrap on the pooled connection. see  {@link javax.sql.DataSource} interfaceor call getConnection through reflection or cast the object as  {@link javax.sql.PooledConnection}
 * @return <code>true</code>
 */
public boolean isAccessToUnderlyingConnectionAllowed();
