/** 
 * Read constants from given input stream.
 * @param input Input stream
 * @throws IOException
 * @throws ClassFormatException
 */
ConstantPool(final DataInput input) throws IOException, ClassFormatException {
  final int constant_pool_count=input.readUnsignedShort();
  constant_pool=new Constant[constant_pool_count];
  for (int i=1; i < constant_pool_count; i++) {
    constant_pool[i]=Constant.readConstant(input);
    if (constant_pool[i] != null) {
      byte tag=constant_pool[i].getTag();
      if ((tag == Const.CONSTANT_Double) || (tag == Const.CONSTANT_Long)) {
        i++;
      }
    }
  }
}
