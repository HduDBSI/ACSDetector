public TagLibraryInfoImpl(JspCompilationContext ctxt,ParserController pc,PageInfo pi,String prefix,String uriIn,TldResourcePath tldResourcePath,ErrorDispatcher err) throws JasperException {
  super(prefix,uriIn);
  this.ctxt=ctxt;
  this.parserController=pc;
  this.pi=pi;
  this.err=err;
  if (tldResourcePath == null) {
    tldResourcePath=generateTldResourcePath(uri,ctxt);
  }
  try (Jar jar=tldResourcePath.openJar()){
    PageInfo pageInfo=ctxt.createCompiler().getPageInfo();
    if (pageInfo != null) {
      String path=tldResourcePath.getWebappPath();
      if (path != null) {
        pageInfo.addDependant(path,ctxt.getLastModified(path,null));
      }
      if (jar != null) {
        if (path == null) {
          URL jarUrl=jar.getJarFileURL();
          long lastMod=-1;
          URLConnection urlConn=null;
          try {
            urlConn=jarUrl.openConnection();
            lastMod=urlConn.getLastModified();
          }
 catch (          IOException ioe) {
            throw new JasperException(ioe);
          }
 finally {
            if (urlConn != null) {
              try {
                urlConn.getInputStream().close();
              }
 catch (              IOException e) {
              }
            }
          }
          pageInfo.addDependant(jarUrl.toExternalForm(),Long.valueOf(lastMod));
        }
        String entryName=tldResourcePath.getEntryName();
        try {
          pageInfo.addDependant(jar.getURL(entryName),Long.valueOf(jar.getLastModified(entryName)));
        }
 catch (        IOException ioe) {
          throw new JasperException(ioe);
        }
      }
    }
    if (tldResourcePath.getUrl() == null) {
      err.jspError("jsp.error.tld.missing",prefix,uri);
    }
    TaglibXml taglibXml=ctxt.getOptions().getTldCache().getTaglibXml(tldResourcePath);
    if (taglibXml == null) {
      err.jspError("jsp.error.tld.missing",prefix,uri);
    }
    @SuppressWarnings("null") String v=taglibXml.getJspVersion();
    this.jspversion=v;
    this.tlibversion=taglibXml.getTlibVersion();
    this.shortname=taglibXml.getShortName();
    this.urn=taglibXml.getUri();
    this.info=taglibXml.getInfo();
    this.tagLibraryValidator=createValidator(taglibXml.getValidator());
    List<TagInfo> tagInfos=new ArrayList<>();
    for (    TagXml tagXml : taglibXml.getTags()) {
      tagInfos.add(createTagInfo(tagXml));
    }
    List<TagFileInfo> tagFileInfos=new ArrayList<>();
    for (    TagFileXml tagFileXml : taglibXml.getTagFiles()) {
      tagFileInfos.add(createTagFileInfo(tagFileXml,jar));
    }
    Set<String> names=new HashSet<>();
    List<FunctionInfo> functionInfos=taglibXml.getFunctions();
    for (    FunctionInfo functionInfo : functionInfos) {
      String name=functionInfo.getName();
      if (!names.add(name)) {
        err.jspError("jsp.error.tld.fn.duplicate.name",name,uri);
      }
    }
    if (tlibversion == null) {
      err.jspError("jsp.error.tld.mandatory.element.missing","tlib-version",uri);
    }
    if (jspversion == null) {
      err.jspError("jsp.error.tld.mandatory.element.missing","jsp-version",uri);
    }
    this.tags=tagInfos.toArray(new TagInfo[tagInfos.size()]);
    this.tagFiles=tagFileInfos.toArray(new TagFileInfo[tagFileInfos.size()]);
    this.functions=functionInfos.toArray(new FunctionInfo[functionInfos.size()]);
  }
 catch (  IOException ioe) {
    throw new JasperException(ioe);
  }
}
