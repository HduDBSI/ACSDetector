@Test public void testPostWithContinueNoServerCookies() throws Exception {
  doTest("POST","GET",USE_100_CONTINUE,CLIENT_USE_COOKIES,SERVER_NO_COOKIES,SERVER_CHANGE_SESSID);
}
