@Test public void testSkipBecauseCacheControlMaxAgeIsDefined() throws Exception {
  HttpServlet servlet=new HttpServlet(){
    private static final long serialVersionUID=1L;
    @Override protected void service(    HttpServletRequest request,    HttpServletResponse response) throws ServletException, IOException {
      response.setContentType("text/xml; charset=utf-8");
      response.addHeader("Cache-Control","private, max-age=232");
      response.getWriter().print("Hello world");
    }
  }
;
  validate(servlet,Integer.valueOf(232));
}
