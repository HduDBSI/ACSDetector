public void reset(){
  counter.set(0);
}
