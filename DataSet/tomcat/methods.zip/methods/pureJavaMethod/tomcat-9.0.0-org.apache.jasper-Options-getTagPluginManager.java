/** 
 * @return a Tag Plugin Manager
 */
public TagPluginManager getTagPluginManager();
