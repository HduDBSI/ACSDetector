protected Session getSessionForNameAndId(ContextName cn,String id,StringManager smClient){
  List<Session> sessions=getSessionsForName(cn,smClient);
  if (sessions.isEmpty())   return null;
  for (  Session session : sessions) {
    if (session.getId().equals(id)) {
      return session;
    }
  }
  return null;
}
