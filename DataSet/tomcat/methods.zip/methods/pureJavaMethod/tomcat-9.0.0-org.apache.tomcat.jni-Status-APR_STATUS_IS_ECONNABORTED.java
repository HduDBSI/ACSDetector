public static final boolean APR_STATUS_IS_ECONNABORTED(int s){
  return is(s,92);
}
