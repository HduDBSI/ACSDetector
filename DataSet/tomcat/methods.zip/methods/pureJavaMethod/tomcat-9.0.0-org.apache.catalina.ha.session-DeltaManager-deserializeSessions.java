/** 
 * Load sessions from other cluster node. FIXME replace currently sessions with same id without notification. FIXME SSO handling is not really correct with the session replacement!
 * @param data Serialized data
 * @exception ClassNotFoundException if a serialized class cannot be found during the reload
 * @exception IOException if an input/output error occurs
 */
protected void deserializeSessions(byte[] data) throws ClassNotFoundException, IOException {
  try (ObjectInputStream ois=getReplicationStream(data)){
    Integer count=(Integer)ois.readObject();
    int n=count.intValue();
    for (int i=0; i < n; i++) {
      DeltaSession session=(DeltaSession)createEmptySession();
      session.readObjectData(ois);
      session.setManager(this);
      session.setValid(true);
      session.setPrimarySession(false);
      session.access();
      session.setAccessCount(0);
      session.resetDeltaRequest();
      if (findSession(session.getIdInternal()) == null) {
        sessionCounter++;
      }
 else {
        sessionReplaceCounter++;
        if (log.isWarnEnabled()) {
          log.warn(sm.getString("deltaManager.loading.existing.session",session.getIdInternal()));
        }
      }
      add(session);
      if (notifySessionListenersOnReplication) {
        session.tellNew();
      }
    }
  }
 catch (  ClassNotFoundException e) {
    log.error(sm.getString("deltaManager.loading.cnfe",e),e);
    throw e;
  }
catch (  IOException e) {
    log.error(sm.getString("deltaManager.loading.ioe",e),e);
    throw e;
  }
}
