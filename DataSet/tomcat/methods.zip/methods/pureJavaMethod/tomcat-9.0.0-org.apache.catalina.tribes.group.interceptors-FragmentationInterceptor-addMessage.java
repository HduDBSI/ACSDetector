public void addMessage(ChannelMessage msg){
  msg.getMessage().trim(4);
  int nr=XByteBuffer.toInt(msg.getMessage().getBytesDirect(),msg.getMessage().getLength() - 4);
  msg.getMessage().trim(4);
  frags[nr]=msg.getMessage();
}
