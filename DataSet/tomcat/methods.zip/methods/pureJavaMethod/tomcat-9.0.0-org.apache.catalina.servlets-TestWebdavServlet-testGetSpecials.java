@Test public void testGetSpecials() throws Exception {
  Tomcat tomcat=getTomcatInstance();
  String contextPath="/examples";
  File appDir=new File(getBuildDirectory(),"webapps" + contextPath);
  org.apache.catalina.Context ctx=tomcat.addWebapp(null,"/examples",appDir.getAbsolutePath());
  Tomcat.addServlet(ctx,"webdav",new WebdavServlet());
  ctx.addServletMappingDecoded("/*","webdav");
  tomcat.start();
  final ByteChunk res=new ByteChunk();
  int rc=getUrl("http://localhost:" + getPort() + contextPath+ "/WEB-INF/web.xml",res,null);
  assertEquals(HttpServletResponse.SC_NOT_FOUND,rc);
  rc=getUrl("http://localhost:" + getPort() + contextPath+ "/WEB-INF/doesntexistanywhere",res,null);
  assertEquals(HttpServletResponse.SC_NOT_FOUND,rc);
  rc=getUrl("http://localhost:" + getPort() + contextPath+ "/WEB-INF/",res,null);
  assertEquals(HttpServletResponse.SC_NOT_FOUND,rc);
  rc=getUrl("http://localhost:" + getPort() + contextPath+ "/META-INF/MANIFEST.MF",res,null);
  assertEquals(HttpServletResponse.SC_NOT_FOUND,rc);
  rc=getUrl("http://localhost:" + getPort() + contextPath+ "/META-INF/doesntexistanywhere",res,null);
  assertEquals(HttpServletResponse.SC_NOT_FOUND,rc);
}
