public CachedStatement isCached(Method method,Object[] args){
  ConcurrentHashMap<CacheKey,CachedStatement> cache=getCache();
  if (cache == null) {
    return null;
  }
  return cache.get(createCacheKey(method,args));
}
