/** 
 * Close the specified database connection.
 * @param dbConnection The connection to be closed
 */
protected void close(Connection dbConnection){
  if (dbConnection == null)   return;
  try {
    if (!dbConnection.getAutoCommit()) {
      dbConnection.commit();
    }
  }
 catch (  SQLException e) {
    containerLog.error("Exception committing connection before closing:",e);
  }
  try {
    dbConnection.close();
  }
 catch (  SQLException e) {
    containerLog.error(sm.getString("dataSourceRealm.close"),e);
  }
}
