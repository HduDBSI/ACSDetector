public CoordinationMessage(Member leader,Member source,Member[] view,UniqueId id,byte[] type){
  this.buf=new XByteBuffer(4096,false);
  this.leader=leader;
  this.source=source;
  this.view=view;
  this.id=id;
  this.type=type;
  this.write();
}
