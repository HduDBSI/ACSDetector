@Override public boolean isRemoveAbandoned(){
  return getPoolProperties().isRemoveAbandoned();
}
