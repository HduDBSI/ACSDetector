@Override public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
  reply=true;
  int length=in.readInt();
  uuid=new byte[length];
  in.readFully(uuid);
  length=in.readInt();
  rpcId=new byte[length];
  in.readFully(rpcId);
}
