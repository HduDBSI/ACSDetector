/** 
 * Read an AJP message.
 * @param message   The message to populate
 * @param block If there is no data available to read when this method iscalled, should this call block until data becomes available?
 * @return true if the message has been read, false if no data was read
 * @throws IOException any other failure, including incomplete reads
 */
private boolean readMessage(AjpMessage message,boolean block) throws IOException {
  byte[] buf=message.getBuffer();
  if (!read(buf,0,Constants.H_SIZE,block)) {
    return false;
  }
  int messageLength=message.processHeader(true);
  if (messageLength < 0) {
    throw new IOException(sm.getString("ajpmessage.invalidLength",Integer.valueOf(messageLength)));
  }
 else   if (messageLength == 0) {
    return true;
  }
 else {
    if (messageLength > message.getBuffer().length) {
      String msg=sm.getString("ajpprocessor.header.tooLong",Integer.valueOf(messageLength),Integer.valueOf(buf.length));
      log.error(msg);
      throw new IllegalArgumentException(msg);
    }
    read(buf,Constants.H_SIZE,messageLength,true);
    return true;
  }
}
