/** 
 * Sets the validation query timeout, the amount of time, in seconds, that connection validation will wait for a response from the database when executing a validation query. Use a value less than or equal to 0 for no timeout.
 * @param validationQueryTimeoutSeconds new validation query timeout value in seconds
 */
public void setValidationQueryTimeout(final int validationQueryTimeoutSeconds){
  this.validationQueryTimeoutSeconds=validationQueryTimeoutSeconds;
}
