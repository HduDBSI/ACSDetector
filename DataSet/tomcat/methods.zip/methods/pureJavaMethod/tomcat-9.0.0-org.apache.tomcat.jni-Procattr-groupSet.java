/** 
 * Set the group used for running process
 * @param attr The procattr we care about.
 * @param groupname The group name  used
 * @return the operation status
 */
public static native int groupSet(long attr,String groupname);
