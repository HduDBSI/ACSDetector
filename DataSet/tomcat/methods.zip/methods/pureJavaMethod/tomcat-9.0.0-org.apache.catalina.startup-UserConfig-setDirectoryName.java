/** 
 * Set the directory name for user web applications.
 * @param directoryName The new directory name
 */
public void setDirectoryName(String directoryName){
  this.directoryName=directoryName;
}
