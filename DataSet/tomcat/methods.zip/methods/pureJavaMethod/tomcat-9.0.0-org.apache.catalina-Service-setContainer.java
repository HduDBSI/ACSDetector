/** 
 * Set the <code>Engine</code> that handles requests for all <code>Connectors</code> associated with this Service.
 * @param engine The new Engine
 */
public void setContainer(Engine engine);
