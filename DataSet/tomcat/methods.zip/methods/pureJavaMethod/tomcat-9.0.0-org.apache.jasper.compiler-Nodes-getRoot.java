public Node.Root getRoot(){
  return root;
}
