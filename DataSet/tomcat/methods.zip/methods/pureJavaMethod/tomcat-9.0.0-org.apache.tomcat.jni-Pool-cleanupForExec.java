/** 
 * Run all of the child_cleanups, so that any unnecessary files are closed because we are about to exec a new program
 */
public static native void cleanupForExec();
