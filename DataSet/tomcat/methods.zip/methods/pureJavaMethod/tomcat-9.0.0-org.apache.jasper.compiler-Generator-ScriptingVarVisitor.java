ScriptingVarVisitor(){
  vars=new Vector<>();
}
