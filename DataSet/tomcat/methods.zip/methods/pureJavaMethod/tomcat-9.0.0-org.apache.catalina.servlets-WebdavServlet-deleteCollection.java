/** 
 * Deletes a collection.
 * @param req The Servlet request
 * @param path Path to the collection to be deleted
 * @param errorList Contains the list of the errors which occurred
 */
private void deleteCollection(HttpServletRequest req,String path,Hashtable<String,Integer> errorList){
  if (debug > 1)   log("Delete:" + path);
  if (isSpecialPath(path)) {
    errorList.put(path,Integer.valueOf(WebdavStatus.SC_FORBIDDEN));
    return;
  }
  String ifHeader=req.getHeader("If");
  if (ifHeader == null)   ifHeader="";
  String lockTokenHeader=req.getHeader("Lock-Token");
  if (lockTokenHeader == null)   lockTokenHeader="";
  String[] entries=resources.list(path);
  for (  String entry : entries) {
    String childName=path;
    if (!childName.equals("/"))     childName+="/";
    childName+=entry;
    if (isLocked(childName,ifHeader + lockTokenHeader)) {
      errorList.put(childName,Integer.valueOf(WebdavStatus.SC_LOCKED));
    }
 else {
      WebResource childResource=resources.getResource(childName);
      if (childResource.isDirectory()) {
        deleteCollection(req,childName,errorList);
      }
      if (!childResource.delete()) {
        if (!childResource.isDirectory()) {
          errorList.put(childName,Integer.valueOf(WebdavStatus.SC_INTERNAL_SERVER_ERROR));
        }
      }
    }
  }
}
