public CharSequence echo1(CharSequence cs){
  return "A1" + cs;
}
