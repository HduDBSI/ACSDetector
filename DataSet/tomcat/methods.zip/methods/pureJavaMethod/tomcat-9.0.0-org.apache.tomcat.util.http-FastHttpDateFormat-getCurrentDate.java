/** 
 * Get the current date in HTTP format.
 * @return the HTTP date
 */
public static final String getCurrentDate(){
  long now=System.currentTimeMillis();
  if ((now - currentDateGenerated) > 1000) {
synchronized (format) {
      if ((now - currentDateGenerated) > 1000) {
        currentDate=format.format(new Date(now));
        currentDateGenerated=now;
      }
    }
  }
  return currentDate;
}
