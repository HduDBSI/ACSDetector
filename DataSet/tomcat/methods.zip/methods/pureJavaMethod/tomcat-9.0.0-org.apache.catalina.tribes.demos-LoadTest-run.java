@Override public void run(){
  try {
    Thread.sleep(delay);
  }
 catch (  Exception x) {
    x.printStackTrace();
  }
  System.exit(0);
}
