@Test public void testBug53337() throws Exception {
  Tomcat tomcat=getTomcatInstance();
  Context ctx=tomcat.addContext("",null);
  Wrapper a=Tomcat.addServlet(ctx,"ServletA",new Bug53337ServletA());
  a.setAsyncSupported(true);
  Wrapper b=Tomcat.addServlet(ctx,"ServletB",new Bug53337ServletB());
  b.setAsyncSupported(true);
  Tomcat.addServlet(ctx,"ServletC",new Bug53337ServletC());
  ctx.addServletMappingDecoded("/ServletA","ServletA");
  ctx.addServletMappingDecoded("/ServletB","ServletB");
  ctx.addServletMappingDecoded("/ServletC","ServletC");
  tomcat.start();
  StringBuilder url=new StringBuilder(48);
  url.append("http://localhost:");
  url.append(getPort());
  url.append("/ServletA");
  ByteChunk body=new ByteChunk();
  int rc=getUrl(url.toString(),body,null);
  assertEquals(HttpServletResponse.SC_OK,rc);
  assertEquals("OK",body.toString());
}
