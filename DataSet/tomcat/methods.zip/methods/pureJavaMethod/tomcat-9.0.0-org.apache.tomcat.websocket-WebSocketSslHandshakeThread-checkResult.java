private void checkResult(SSLEngineResult result,boolean wrap) throws SSLException {
  handshakeStatus=result.getHandshakeStatus();
  resultStatus=result.getStatus();
  if (resultStatus != Status.OK && (wrap || resultStatus != Status.BUFFER_UNDERFLOW)) {
    throw new SSLException(sm.getString("asyncChannelWrapperSecure.check.notOk",resultStatus));
  }
  if (wrap && result.bytesConsumed() != 0) {
    throw new SSLException(sm.getString("asyncChannelWrapperSecure.check.wrap"));
  }
  if (!wrap && result.bytesProduced() != 0) {
    throw new SSLException(sm.getString("asyncChannelWrapperSecure.check.unwrap"));
  }
}
