/** 
 * Gets the value of the use HttpOnly cookies for session cookies flag.
 * @return <code>true</code> if the HttpOnly flag should be set on sessioncookies
 */
@Override public boolean getUseHttpOnly(){
  return useHttpOnly;
}
