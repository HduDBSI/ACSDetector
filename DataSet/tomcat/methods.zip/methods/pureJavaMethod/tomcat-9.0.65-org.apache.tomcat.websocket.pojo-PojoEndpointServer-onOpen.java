@Override public void onOpen(Session session,EndpointConfig endpointConfig){
  ServerEndpointConfig sec=(ServerEndpointConfig)endpointConfig;
  PojoMethodMapping methodMapping=(PojoMethodMapping)sec.getUserProperties().get(Constants.POJO_METHOD_MAPPING_KEY);
  setMethodMapping(methodMapping);
  doOnOpen(session,endpointConfig);
}
