/** 
 * @return the class name of the Coyote protocol handler in use.
 */
public String getProtocolHandlerClassName(){
  return this.protocolHandlerClassName;
}
