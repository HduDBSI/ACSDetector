public void setDescription(String descr){
  description=descr;
}
