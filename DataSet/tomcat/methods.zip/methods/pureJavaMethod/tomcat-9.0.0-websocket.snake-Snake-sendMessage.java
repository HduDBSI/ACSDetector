protected void sendMessage(String msg){
  try {
    session.getBasicRemote().sendText(msg);
  }
 catch (  IOException ioe) {
    CloseReason cr=new CloseReason(CloseCodes.CLOSED_ABNORMALLY,ioe.getMessage());
    try {
      session.close(cr);
    }
 catch (    IOException ioe2) {
    }
  }
}
