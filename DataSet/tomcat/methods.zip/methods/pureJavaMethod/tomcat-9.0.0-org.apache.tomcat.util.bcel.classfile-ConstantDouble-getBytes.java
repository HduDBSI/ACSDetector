/** 
 * @return data, i.e., 8 bytes.
 */
public final double getBytes(){
  return bytes;
}
