/** 
 * @param host The host in which the context will be deployed
 * @param contextPath The context mapping to use, "" for root context.
 * @param docBase Base directory for the context, for static files.Must exist, relative to the server home
 * @param config Custom context configurator helper
 * @return the deployed context
 * @see #addWebapp(String,String)
 */
public Context addWebapp(Host host,String contextPath,String docBase,LifecycleListener config){
  silence(host,contextPath);
  Context ctx=createContext(host,contextPath);
  ctx.setPath(contextPath);
  ctx.setDocBase(docBase);
  ctx.addLifecycleListener(getDefaultWebXmlListener());
  ctx.setConfigFile(getWebappConfigFile(docBase,contextPath));
  ctx.addLifecycleListener(config);
  if (config instanceof ContextConfig) {
    ((ContextConfig)config).setDefaultWebXml(noDefaultWebXmlPath());
  }
  if (host == null) {
    getHost().addChild(ctx);
  }
 else {
    host.addChild(ctx);
  }
  return ctx;
}
