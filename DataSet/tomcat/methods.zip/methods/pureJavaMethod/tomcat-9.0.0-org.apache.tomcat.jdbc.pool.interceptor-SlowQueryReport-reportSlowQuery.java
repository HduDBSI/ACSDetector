@Override protected String reportSlowQuery(String query,Object[] args,String name,long start,long delta){
  String sql=super.reportSlowQuery(query,args,name,start,delta);
  if (this.maxQueries > 0) {
    QueryStats qs=this.getQueryStats(sql);
    if (qs != null) {
      qs.add(delta,start);
      if (isLogSlow() && log.isWarnEnabled()) {
        log.warn("Slow Query Report SQL=" + sql + "; time="+ delta+ " ms;");
      }
    }
  }
  return sql;
}
