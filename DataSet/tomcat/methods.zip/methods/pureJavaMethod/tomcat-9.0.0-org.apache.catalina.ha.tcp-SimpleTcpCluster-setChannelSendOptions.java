public void setChannelSendOptions(String channelSendOptions){
  int value=Channel.parseSendOptions(channelSendOptions);
  if (value > 0) {
    this.setChannelSendOptions(value);
  }
}
