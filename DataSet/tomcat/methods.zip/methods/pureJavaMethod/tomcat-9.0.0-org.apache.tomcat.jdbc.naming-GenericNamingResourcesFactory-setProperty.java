@SuppressWarnings("null") private static boolean setProperty(Object o,String name,String value){
  if (log.isDebugEnabled())   log.debug("IntrospectionUtils: setProperty(" + o.getClass() + " "+ name+ "="+ value+ ")");
  String setter="set" + capitalize(name);
  try {
    Method methods[]=o.getClass().getMethods();
    Method setPropertyMethodVoid=null;
    Method setPropertyMethodBool=null;
    for (int i=0; i < methods.length; i++) {
      Class<?> paramT[]=methods[i].getParameterTypes();
      if (setter.equals(methods[i].getName()) && paramT.length == 1 && "java.lang.String".equals(paramT[0].getName())) {
        methods[i].invoke(o,new Object[]{value});
        return true;
      }
    }
    for (int i=0; i < methods.length; i++) {
      boolean ok=true;
      if (setter.equals(methods[i].getName()) && methods[i].getParameterTypes().length == 1) {
        Class<?> paramType=methods[i].getParameterTypes()[0];
        Object params[]=new Object[1];
        if ("java.lang.Integer".equals(paramType.getName()) || "int".equals(paramType.getName())) {
          try {
            params[0]=Integer.valueOf(value);
          }
 catch (          NumberFormatException ex) {
            ok=false;
          }
        }
 else         if ("java.lang.Long".equals(paramType.getName()) || "long".equals(paramType.getName())) {
          try {
            params[0]=Long.valueOf(value);
          }
 catch (          NumberFormatException ex) {
            ok=false;
          }
        }
 else         if ("java.lang.Boolean".equals(paramType.getName()) || "boolean".equals(paramType.getName())) {
          params[0]=Boolean.valueOf(value);
        }
 else         if ("java.net.InetAddress".equals(paramType.getName())) {
          try {
            params[0]=InetAddress.getByName(value);
          }
 catch (          UnknownHostException exc) {
            if (log.isDebugEnabled())             log.debug("IntrospectionUtils: Unable to resolve host name:" + value);
            ok=false;
          }
        }
 else {
          if (log.isDebugEnabled())           log.debug("IntrospectionUtils: Unknown type " + paramType.getName());
        }
        if (ok) {
          methods[i].invoke(o,params);
          return true;
        }
      }
      if ("setProperty".equals(methods[i].getName())) {
        if (methods[i].getReturnType() == Boolean.TYPE) {
          setPropertyMethodBool=methods[i];
        }
 else {
          setPropertyMethodVoid=methods[i];
        }
      }
    }
    if (setPropertyMethodBool != null || setPropertyMethodVoid != null) {
      Object params[]=new Object[2];
      params[0]=name;
      params[1]=value;
      if (setPropertyMethodBool != null) {
        try {
          return ((Boolean)setPropertyMethodBool.invoke(o,params)).booleanValue();
        }
 catch (        IllegalArgumentException biae) {
          if (setPropertyMethodVoid != null) {
            setPropertyMethodVoid.invoke(o,params);
            return true;
          }
 else {
            throw biae;
          }
        }
      }
 else {
        setPropertyMethodVoid.invoke(o,params);
        return true;
      }
    }
  }
 catch (  IllegalArgumentException ex2) {
    log.warn("IAE " + o + " "+ name+ " "+ value,ex2);
  }
catch (  SecurityException ex1) {
    if (log.isDebugEnabled())     log.debug("IntrospectionUtils: SecurityException for " + o.getClass() + " "+ name+ "="+ value+ ")",ex1);
  }
catch (  IllegalAccessException iae) {
    if (log.isDebugEnabled())     log.debug("IntrospectionUtils: IllegalAccessException for " + o.getClass() + " "+ name+ "="+ value+ ")",iae);
  }
catch (  InvocationTargetException ie) {
    Throwable cause=ie.getCause();
    if (cause instanceof ThreadDeath) {
      throw (ThreadDeath)cause;
    }
    if (cause instanceof VirtualMachineError) {
      throw (VirtualMachineError)cause;
    }
    if (log.isDebugEnabled())     log.debug("IntrospectionUtils: InvocationTargetException for " + o.getClass() + " "+ name+ "="+ value+ ")",ie);
  }
  return false;
}
