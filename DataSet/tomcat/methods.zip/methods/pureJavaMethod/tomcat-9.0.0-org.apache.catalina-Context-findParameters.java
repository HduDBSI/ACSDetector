/** 
 * @return the names of all defined context initialization parametersfor this Context.  If no parameters are defined, a zero-length array is returned.
 */
public String[] findParameters();
