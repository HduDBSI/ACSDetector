/** 
 * Close a socket.
 * @param thesocket The socket to close
 * @return the operation status
 */
public static native int close(long thesocket);
