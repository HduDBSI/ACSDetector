public String getQuery(){
  return query;
}
