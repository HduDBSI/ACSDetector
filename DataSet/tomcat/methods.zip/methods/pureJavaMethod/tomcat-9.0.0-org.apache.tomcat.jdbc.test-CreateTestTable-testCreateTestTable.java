@Test public void testCreateTestTable() throws Exception {
  Connection con=datasource.getConnection();
  Statement st=con.createStatement();
  try {
    st.execute("create table test(id int not null, val1 varchar(255), val2 varchar(255), val3 varchar(255), val4 varchar(255))");
  }
 catch (  Exception ignore) {
  }
  st.close();
  con.close();
}
