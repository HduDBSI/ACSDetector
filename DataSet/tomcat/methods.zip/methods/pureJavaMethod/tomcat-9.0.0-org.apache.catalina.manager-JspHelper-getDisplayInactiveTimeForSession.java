public static String getDisplayInactiveTimeForSession(Session in_session){
  try {
    if (in_session.getCreationTime() == 0) {
      return "";
    }
  }
 catch (  IllegalStateException ise) {
    return "";
  }
  return secondsToTimeString(SessionUtils.getInactiveTimeForSession(in_session) / 1000);
}
