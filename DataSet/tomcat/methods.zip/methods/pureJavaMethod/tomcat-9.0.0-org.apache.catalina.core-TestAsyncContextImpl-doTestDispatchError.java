private void doTestDispatchError(int iter,boolean useThread,boolean completeOnError) throws Exception {
  resetTracker();
  Tomcat tomcat=getTomcatInstance();
  Context ctx=tomcat.addContext("",null);
  DispatchingServlet dispatch=new DispatchingServlet(true,completeOnError);
  Wrapper wrapper=Tomcat.addServlet(ctx,"dispatch",dispatch);
  wrapper.setAsyncSupported(true);
  ctx.addServletMappingDecoded("/stage1","dispatch");
  ErrorServlet error=new ErrorServlet();
  Tomcat.addServlet(ctx,"error",error);
  ctx.addServletMappingDecoded("/stage2","error");
  ctx.addApplicationListener(TrackingRequestListener.class.getName());
  TesterAccessLogValve alv=new TesterAccessLogValve();
  ctx.getPipeline().addValve(alv);
  tomcat.start();
  StringBuilder url=new StringBuilder(48);
  url.append("http://localhost:");
  url.append(getPort());
  url.append("/stage1?iter=");
  url.append(iter);
  if (useThread) {
    url.append("&useThread=y");
  }
  getUrl(url.toString());
  StringBuilder expected=new StringBuilder("requestInitialized-");
  int loop=iter;
  while (loop > 0) {
    expected.append("DispatchingServletGet-");
    if (loop != iter) {
      expected.append("onStartAsync-");
    }
    loop--;
  }
  expected.append("ErrorServletGet-onError-onComplete-requestDestroyed");
  String expectedTrack=expected.toString();
  int count=0;
  while (!expectedTrack.equals(getTrack()) && count < 100) {
    Thread.sleep(50);
    count++;
  }
  assertEquals(expectedTrack,getTrack());
  alv.validateAccessLog(1,500,0,REQUEST_TIME);
}
