@OnMessage public void echoBinaryMessage(Session session,ByteBuffer bb,boolean last){
  try {
    if (session.isOpen()) {
      session.getBasicRemote().sendBinary(bb,last);
    }
  }
 catch (  IOException e) {
    try {
      session.close();
    }
 catch (    IOException e1) {
    }
  }
}
