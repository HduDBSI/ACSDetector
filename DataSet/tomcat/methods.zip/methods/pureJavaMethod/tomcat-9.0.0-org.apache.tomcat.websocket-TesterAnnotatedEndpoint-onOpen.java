@OnOpen public void onOpen(Session session){
  session.getUserProperties().put("endpoint",this);
}
