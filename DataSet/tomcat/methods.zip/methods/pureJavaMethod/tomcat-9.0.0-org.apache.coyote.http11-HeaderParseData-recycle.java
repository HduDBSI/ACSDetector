public void recycle(){
  start=0;
  realPos=0;
  lastSignificantChar=0;
  headerValue=null;
}
