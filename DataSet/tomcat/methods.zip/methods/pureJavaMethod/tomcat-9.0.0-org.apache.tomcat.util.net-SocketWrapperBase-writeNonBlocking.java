/** 
 * Writes the data to the socket (writing that data to the socket using a non-blocking write) until either all the data has been transferred and space remains in the socket write buffer or a non-blocking write leaves data in the socket write buffer. If it is possible use the provided buffer directly and do not transfer to the socket write buffer.
 * @param from The ByteBuffer containing the data to be written
 * @throws IOException If an IO error occurs during the write
 */
protected void writeNonBlocking(ByteBuffer from) throws IOException {
  if (bufferedWrites.size() == 0 && socketBufferHandler.isWriteBufferWritable()) {
    writeNonBlockingInternal(from);
  }
  if (from.remaining() > 0) {
    addToBuffers(from);
  }
}
