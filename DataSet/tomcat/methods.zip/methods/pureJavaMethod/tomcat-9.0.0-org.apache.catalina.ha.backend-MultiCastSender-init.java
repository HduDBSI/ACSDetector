@Override public void init(HeartbeatListener config) throws Exception {
  this.config=config;
}
