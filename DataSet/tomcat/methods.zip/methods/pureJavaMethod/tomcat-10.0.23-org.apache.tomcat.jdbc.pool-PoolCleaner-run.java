@Override public void run(){
  ConnectionPool pool=this.pool.get();
  if (pool == null) {
    stopRunning();
  }
 else   if (!pool.isClosed()) {
    try {
      if (pool.getPoolProperties().isRemoveAbandoned() || pool.getPoolProperties().getSuspectTimeout() > 0) {
        pool.checkAbandoned();
      }
      if (pool.getPoolProperties().getMinIdle() < pool.idle.size()) {
        pool.checkIdle();
      }
      if (pool.getPoolProperties().isTestWhileIdle()) {
        pool.testAllIdle(false);
      }
 else       if (pool.getPoolProperties().getMaxAge() > 0) {
        pool.testAllIdle(true);
      }
    }
 catch (    Exception x) {
      log.error("",x);
    }
  }
}
