/** 
 * Create a new process and execute a new program within that process. This function returns without waiting for the new process to terminate; use apr_proc_wait for that.
 * @param proc The process handle
 * @param progname The program to run
 * @param args The arguments to pass to the new program.  The firstone should be the program name.
 * @param env The new environment table for the new process.  Thisshould be a list of NULL-terminated strings. This argument is ignored for APR_PROGRAM_ENV, APR_PROGRAM_PATH, and APR_SHELLCMD_ENV types of commands.
 * @param attr The procattr we should use to determine how to create the newprocess
 * @param pool The pool to use.
 * @return The resulting process handle.
 */
public static native int create(long proc,String progname,String[] args,String[] env,long attr,long pool);
