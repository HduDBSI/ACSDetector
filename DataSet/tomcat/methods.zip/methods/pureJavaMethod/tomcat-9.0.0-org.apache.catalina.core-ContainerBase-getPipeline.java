/** 
 * Return the Pipeline object that manages the Valves associated with this Container.
 */
@Override public Pipeline getPipeline(){
  return this.pipeline;
}
