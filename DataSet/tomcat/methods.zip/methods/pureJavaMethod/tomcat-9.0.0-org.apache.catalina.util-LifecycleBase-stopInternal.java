/** 
 * Sub-classes must ensure that the state is changed to {@link LifecycleState#STOPPING} during the execution of this method.Changing state will trigger the  {@link Lifecycle#STOP_EVENT} event.
 * @throws LifecycleException Stop error occurred
 */
protected abstract void stopInternal() throws LifecycleException ;
