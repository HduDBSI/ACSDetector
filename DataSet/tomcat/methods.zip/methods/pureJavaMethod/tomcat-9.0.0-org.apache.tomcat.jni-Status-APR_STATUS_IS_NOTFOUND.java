public static final boolean APR_STATUS_IS_NOTFOUND(int s){
  return is(s,65);
}
