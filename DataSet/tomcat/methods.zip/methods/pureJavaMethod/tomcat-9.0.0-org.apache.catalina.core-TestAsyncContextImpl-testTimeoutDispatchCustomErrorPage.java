@Test public void testTimeoutDispatchCustomErrorPage() throws Exception {
  Tomcat tomcat=getTomcatInstance();
  Context context=tomcat.addContext("",null);
  tomcat.addServlet("","timeout",Bug58751AsyncServlet.class.getName()).setAsyncSupported(true);
  CustomErrorServlet customErrorServlet=new CustomErrorServlet();
  Tomcat.addServlet(context,"customErrorServlet",customErrorServlet);
  context.addServletMappingDecoded("/timeout","timeout");
  context.addServletMappingDecoded("/error","customErrorServlet");
  ErrorPage errorPage=new ErrorPage();
  errorPage.setLocation("/error");
  context.addErrorPage(errorPage);
  tomcat.start();
  ByteChunk responseBody=new ByteChunk();
  int rc=getUrl("http://localhost:" + getPort() + "/timeout",responseBody,null);
  Assert.assertEquals(503,rc);
  Assert.assertEquals(CustomErrorServlet.ERROR_MESSAGE,responseBody.toString());
}
