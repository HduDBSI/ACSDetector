public static void main(String[] args) throws Exception {
  long pause=3000;
  int count=1000000;
  int stats=10000;
  String name="EchoRpcId";
  int options=RpcChannel.ALL_REPLY;
  long timeout=15000;
  String message="EchoRpcMessage";
  if (args.length == 0) {
    usage();
    System.exit(1);
  }
  for (int i=0; i < args.length; i++) {
    if ("-threads".equals(args[i])) {
    }
 else     if ("-count".equals(args[i])) {
      count=Integer.parseInt(args[++i]);
      System.out.println("Sending " + count + " messages.");
    }
 else     if ("-pause".equals(args[i])) {
      pause=Long.parseLong(args[++i]) * 1000;
    }
 else     if ("-break".equals(args[i])) {
    }
 else     if ("-stats".equals(args[i])) {
      stats=Integer.parseInt(args[++i]);
      System.out.println("Stats every " + stats + " message");
    }
 else     if ("-timeout".equals(args[i])) {
      timeout=Long.parseLong(args[++i]);
    }
 else     if ("-message".equals(args[i])) {
      message=args[++i];
    }
 else     if ("-name".equals(args[i])) {
      name=args[++i];
    }
 else     if ("-mode".equals(args[i])) {
      if ("all".equals(args[++i]))       options=RpcChannel.ALL_REPLY;
 else       if ("first".equals(args[i]))       options=RpcChannel.FIRST_REPLY;
 else       if ("majority".equals(args[i]))       options=RpcChannel.MAJORITY_REPLY;
    }
 else     if ("-debug".equals(args[i])) {
    }
 else     if ("-help".equals(args[i])) {
      usage();
      System.exit(1);
    }
  }
  ManagedChannel channel=(ManagedChannel)ChannelCreator.createChannel(args);
  EchoRpcTest test=new EchoRpcTest(channel,name,count,message,pause,options,timeout);
  channel.start(Channel.DEFAULT);
  Runtime.getRuntime().addShutdownHook(new Shutdown(channel));
  test.run();
  System.out.println("System test complete, sleeping to let threads finish.");
  Thread.sleep(60 * 1000 * 60);
}
