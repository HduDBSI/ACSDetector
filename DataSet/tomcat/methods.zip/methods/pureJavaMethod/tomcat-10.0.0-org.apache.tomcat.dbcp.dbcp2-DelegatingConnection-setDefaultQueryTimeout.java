/** 
 * Sets the default query timeout that will be used for  {@link Statement}s created from this connection. <code>null</code> means that the driver default will be used.
 * @param defaultQueryTimeoutSeconds the new query timeout limit in seconds; zero means there is no limit
 */
public void setDefaultQueryTimeout(final Integer defaultQueryTimeoutSeconds){
  this.defaultQueryTimeoutSeconds=defaultQueryTimeoutSeconds;
}
