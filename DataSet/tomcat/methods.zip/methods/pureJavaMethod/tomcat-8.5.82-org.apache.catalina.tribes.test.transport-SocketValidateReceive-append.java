public int append(byte[] b,int off,int len) throws Exception {
  int packages=0;
  for (int i=off; i < len; i++) {
    if (cur == length) {
      cur=0;
      seq++;
      packages++;
    }
    if (b[i] != seq) {
      throw new Exception("mismatch on seq:" + seq + " and byte nr:"+ cur+ " count:"+ count+ " packages:"+ packages);
    }
    cur++;
  }
  return packages;
}
