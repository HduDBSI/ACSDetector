public long getRequestBytesReceived(){
  return req.getBytesRead();
}
