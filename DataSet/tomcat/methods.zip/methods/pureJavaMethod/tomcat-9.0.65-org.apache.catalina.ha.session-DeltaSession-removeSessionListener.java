public void removeSessionListener(SessionListener listener,boolean addDeltaRequest){
  lockInternal();
  try {
    super.removeSessionListener(listener);
    if (addDeltaRequest && listener instanceof ReplicatedSessionListener) {
      deltaRequest.removeSessionListener(listener);
    }
  }
  finally {
    unlockInternal();
  }
}
