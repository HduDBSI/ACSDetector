@Override public boolean isConstantAttribute(String attribute){
  Node.JspAttribute attr=getNodeAttribute(attribute);
  if (attr == null)   return false;
  return attr.isLiteral();
}
