@Override public ByteBuffer getApplicationData(){
  return applicationData;
}
