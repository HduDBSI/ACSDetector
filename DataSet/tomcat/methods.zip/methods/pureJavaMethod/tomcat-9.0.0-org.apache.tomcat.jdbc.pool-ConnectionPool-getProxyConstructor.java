/** 
 * Creates and caches a  {@link java.lang.reflect.Constructor} used to instantiate the proxy object.We cache this, since the creation of a constructor is fairly slow.
 * @param xa Use a XA connection
 * @return constructor used to instantiate the wrapper object
 * @throws NoSuchMethodException Failed to get a constructor
 */
public Constructor<?> getProxyConstructor(boolean xa) throws NoSuchMethodException {
  if (proxyClassConstructor == null) {
    Class<?> proxyClass=xa ? Proxy.getProxyClass(ConnectionPool.class.getClassLoader(),new Class[]{java.sql.Connection.class,javax.sql.PooledConnection.class,javax.sql.XAConnection.class}) : Proxy.getProxyClass(ConnectionPool.class.getClassLoader(),new Class[]{java.sql.Connection.class,javax.sql.PooledConnection.class});
    proxyClassConstructor=proxyClass.getConstructor(new Class[]{InvocationHandler.class});
  }
  return proxyClassConstructor;
}
