@Test public void testWsCloseThenTcpResetWhenOnMessageSends() throws Exception {
  events.onMessageSends=true;
  startServer(TestEndpointConfig.class);
  TesterWsCloseClient client=new TesterWsCloseClient("localhost",getPort());
  client.httpUpgrade(BaseEndpointConfig.PATH);
  client.sendMessage("Test");
  awaitLatch(events.onMessageCalled,"onMessage not called");
  client.sendCloseFrame(CloseCodes.NORMAL_CLOSURE);
  client.forceCloseSocket();
  events.onMessageWait.countDown();
  awaitOnClose(CloseCodes.CLOSED_ABNORMALLY);
}
