/** 
 * Return the MBean Names of the set of defined environment entries for this web application
 * @return an array of object names as strings
 */
public String[] getEnvironments(){
  ContextEnvironment[] envs=((NamingResourcesImpl)this.resource).findEnvironments();
  List<String> results=new ArrayList<>();
  for (  ContextEnvironment env : envs) {
    try {
      ObjectName oname=MBeanUtils.createObjectName(managed.getDomain(),env);
      results.add(oname.toString());
    }
 catch (    MalformedObjectNameException e) {
      throw new IllegalArgumentException(sm.getString("namingResourcesMBean.createObjectNameError.environment",env),e);
    }
  }
  return results.toArray(new String[0]);
}
