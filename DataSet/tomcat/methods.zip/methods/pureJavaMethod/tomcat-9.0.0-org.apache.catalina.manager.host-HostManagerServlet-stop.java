/** 
 * Stop the host with the specified name.
 * @param writer Writer to render to
 * @param name Host name
 * @param smClient StringManager for the client's locale
 */
protected void stop(PrintWriter writer,String name,StringManager smClient){
  if (debug >= 1) {
    log(sm.getString("hostManagerServlet.stop",name));
  }
  if ((name == null) || name.length() == 0) {
    writer.println(smClient.getString("hostManagerServlet.invalidHostName",name));
    return;
  }
  Container host=engine.findChild(name);
  if (host == null) {
    writer.println(smClient.getString("hostManagerServlet.noHost",name));
    return;
  }
  if (host == installedHost) {
    writer.println(smClient.getString("hostManagerServlet.cannotStopOwnHost",name));
    return;
  }
  if (!host.getState().isAvailable()) {
    writer.println(smClient.getString("hostManagerServlet.alreadyStopped",name));
    return;
  }
  try {
    host.stop();
    writer.println(smClient.getString("hostManagerServlet.stopped",name));
  }
 catch (  Exception e) {
    getServletContext().log(sm.getString("hostManagerServlet.stopFailed",name),e);
    writer.println(smClient.getString("hostManagerServlet.stopFailed",name));
    writer.println(smClient.getString("hostManagerServlet.exception",e.toString()));
  }
}
