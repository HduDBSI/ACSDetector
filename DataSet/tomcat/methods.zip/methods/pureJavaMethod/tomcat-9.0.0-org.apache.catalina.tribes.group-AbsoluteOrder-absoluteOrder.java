public static void absoluteOrder(List<Member> members){
  if (members == null || members.size() <= 1)   return;
  java.util.Collections.sort(members,comp);
}
