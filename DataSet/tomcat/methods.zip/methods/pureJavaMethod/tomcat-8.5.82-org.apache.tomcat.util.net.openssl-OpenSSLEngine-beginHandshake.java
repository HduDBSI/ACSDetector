@Override public synchronized void beginHandshake() throws SSLException {
  if (engineClosed || destroyed) {
    throw new SSLException(sm.getString("engine.engineClosed"));
  }
switch (accepted) {
case NOT:
    handshake();
  accepted=Accepted.EXPLICIT;
break;
case IMPLICIT:
accepted=Accepted.EXPLICIT;
break;
case EXPLICIT:
renegotiate();
break;
}
}
