void writeU4(int val){
  writeU2(val >> 16);
  writeU2(val & 0xFFFF);
}
