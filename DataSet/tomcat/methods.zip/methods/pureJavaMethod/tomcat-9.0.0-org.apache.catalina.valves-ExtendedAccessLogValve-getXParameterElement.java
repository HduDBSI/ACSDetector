protected AccessLogElement getXParameterElement(PatternTokenizer tokenizer) throws IOException {
  if (!tokenizer.hasSubToken()) {
    log.error("x param in wrong format. Needs to be 'x-#(...)' read the docs!");
    return null;
  }
  String token=tokenizer.getToken();
  if ("threadname".equals(token)) {
    return new ThreadNameElement();
  }
  if (!tokenizer.hasParameter()) {
    log.error("x param in wrong format. Needs to be 'x-#(...)' read the docs!");
    return null;
  }
  String parameter=tokenizer.getParameter();
  if (parameter == null) {
    log.error("No closing ) found for in decode");
    return null;
  }
  if ("A".equals(token)) {
    return new ServletContextElement(parameter);
  }
 else   if ("C".equals(token)) {
    return new CookieElement(parameter);
  }
 else   if ("R".equals(token)) {
    return new RequestAttributeElement(parameter);
  }
 else   if ("S".equals(token)) {
    return new SessionAttributeElement(parameter);
  }
 else   if ("H".equals(token)) {
    return getServletRequestElement(parameter);
  }
 else   if ("P".equals(token)) {
    return new RequestParameterElement(parameter);
  }
 else   if ("O".equals(token)) {
    return new ResponseAllHeaderElement(parameter);
  }
  log.error("x param for servlet request, couldn't decode value: " + token);
  return null;
}
