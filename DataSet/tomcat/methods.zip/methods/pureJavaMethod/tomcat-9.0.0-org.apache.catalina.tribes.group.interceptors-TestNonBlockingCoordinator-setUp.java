@Before public void setUp() throws Exception {
  System.out.println("Setup");
  channels=new GroupChannel[CHANNEL_COUNT];
  coordinators=new NonBlockingCoordinator[CHANNEL_COUNT];
  Thread[] threads=new Thread[CHANNEL_COUNT];
  for (int i=0; i < CHANNEL_COUNT; i++) {
    channels[i]=new GroupChannel();
    coordinators[i]=new NonBlockingCoordinator();
    channels[i].addInterceptor(coordinators[i]);
    channels[i].addInterceptor(new TcpFailureDetector());
    final int j=i;
    threads[i]=new Thread(){
      @Override public void run(){
        try {
          channels[j].start(Channel.DEFAULT);
          Thread.sleep(50);
        }
 catch (        Exception x) {
          x.printStackTrace();
        }
      }
    }
;
  }
  TesterUtil.addRandomDomain(channels);
  for (int i=0; i < CHANNEL_COUNT; i++) {
    threads[i].start();
  }
  for (int i=0; i < CHANNEL_COUNT; i++) {
    threads[i].join();
  }
  Thread.sleep(1000);
}
