public Sendfile getSendfile(){
  return sendfile;
}
