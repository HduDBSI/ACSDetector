@Test public void testText() throws JasperException {
  doTestParser("foo","foo");
}
