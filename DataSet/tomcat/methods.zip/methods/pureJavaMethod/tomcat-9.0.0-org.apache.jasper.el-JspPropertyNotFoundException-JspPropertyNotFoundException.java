public JspPropertyNotFoundException(String mark,PropertyNotFoundException e){
  super(mark + " " + e.getMessage(),e.getCause());
}
