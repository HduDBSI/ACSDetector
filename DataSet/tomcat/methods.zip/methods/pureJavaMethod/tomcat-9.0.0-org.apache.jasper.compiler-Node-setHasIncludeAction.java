public void setHasIncludeAction(boolean i){
  hasIncludeAction=i;
}
