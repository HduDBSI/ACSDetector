@Override public int getTimeBetweenEvictionRunsMillis(){
  return getPoolProperties().getTimeBetweenEvictionRunsMillis();
}
