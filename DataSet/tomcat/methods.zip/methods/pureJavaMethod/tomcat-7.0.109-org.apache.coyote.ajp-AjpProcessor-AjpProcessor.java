public AjpProcessor(int packetSize,JIoEndpoint endpoint){
  super(packetSize,endpoint);
  response.setOutputBuffer(new SocketOutputBuffer());
}
