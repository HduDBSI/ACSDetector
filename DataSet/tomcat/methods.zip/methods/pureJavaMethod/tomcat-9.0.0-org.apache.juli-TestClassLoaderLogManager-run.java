@Override public void run(){
  while (running) {
    try {
      Collections.list(logManager.getLoggerNames());
    }
 catch (    Exception e) {
      e.printStackTrace();
      running=false;
    }
  }
}
