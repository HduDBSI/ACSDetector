@Test public void testBug52830() throws Exception {
  Tomcat tomcat=getTomcatInstance();
  tomcat.enableNaming();
  org.apache.catalina.Context ctx=tomcat.addContext("",null);
  ContextEnvironment env=new ContextEnvironment();
  env.setName("boolean");
  env.setType(Boolean.class.getName());
  env.setValue("true");
  ctx.getNamingResources().addEnvironment(env);
  Bug52830Servlet bug52830Servlet=new Bug52830Servlet();
  Tomcat.addServlet(ctx,"bug52830Servlet",bug52830Servlet);
  ctx.addServletMappingDecoded("/","bug52830Servlet");
  tomcat.start();
  ByteChunk bc=new ByteChunk();
  int rc=getUrl("http://localhost:" + getPort() + "/",bc,null);
  assertEquals(200,rc);
  assertTrue(bc.toString().contains("truetrue"));
}
