@Override public void backgroundProcess(){
  super.backgroundProcess();
  long thresholdInMillis=threshold * 1000L;
  for (  MonitoredThread monitoredThread : activeThreads.values()) {
    long activeTime=monitoredThread.getActiveTimeInMillis();
    if (activeTime >= thresholdInMillis && monitoredThread.markAsStuckIfStillRunning()) {
      int numStuckThreads=stuckCount.incrementAndGet();
      notifyStuckThreadDetected(monitoredThread,activeTime,numStuckThreads);
    }
    if (interruptThreadThreshold > 0 && activeTime >= interruptThreadThreshold * 1000L) {
      monitoredThread.interruptIfStuck(interruptThreadThreshold);
    }
  }
  for (CompletedStuckThread completedStuckThread=completedStuckThreadsQueue.poll(); completedStuckThread != null; completedStuckThread=completedStuckThreadsQueue.poll()) {
    int numStuckThreads=stuckCount.decrementAndGet();
    notifyStuckThreadCompleted(completedStuckThread,numStuckThreads);
  }
}
