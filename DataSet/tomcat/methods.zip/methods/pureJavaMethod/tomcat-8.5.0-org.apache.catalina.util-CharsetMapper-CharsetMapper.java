/** 
 * Construct a new CharsetMapper using the specified properties resource.
 * @param name Name of a properties resource to be loaded
 * @exception IllegalArgumentException if the specified propertiesresource could not be loaded for any reason.
 */
public CharsetMapper(String name){
  try (InputStream stream=this.getClass().getResourceAsStream(name)){
    map.load(stream);
  }
 catch (  Throwable t) {
    ExceptionUtils.handleThrowable(t);
    throw new IllegalArgumentException(t.toString());
  }
}
