public void setBeanName(String beanName){
  this.beanName=beanName;
}
