public void setWriteResponseBodyStarted(boolean writeResponseBodyStarted){
  this.writeResponseBodyStarted=writeResponseBodyStarted;
}
