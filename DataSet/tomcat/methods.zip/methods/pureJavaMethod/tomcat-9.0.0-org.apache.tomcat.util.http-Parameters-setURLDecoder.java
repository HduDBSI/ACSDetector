public void setURLDecoder(UDecoder u){
  urlDec=u;
}
