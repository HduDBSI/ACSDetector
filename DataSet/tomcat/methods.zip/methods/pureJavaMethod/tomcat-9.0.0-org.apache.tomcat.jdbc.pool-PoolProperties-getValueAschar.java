public char getValueAschar(char def){
  if (value == null)   return def;
  try {
    return value.charAt(0);
  }
 catch (  StringIndexOutOfBoundsException nfe) {
    return def;
  }
}
