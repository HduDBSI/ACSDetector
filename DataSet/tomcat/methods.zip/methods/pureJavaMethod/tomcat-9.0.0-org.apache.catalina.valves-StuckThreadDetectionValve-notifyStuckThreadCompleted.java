private void notifyStuckThreadCompleted(CompletedStuckThread thread,int numStuckThreads){
  if (log.isWarnEnabled()) {
    String msg=sm.getString("stuckThreadDetectionValve.notifyStuckThreadCompleted",thread.getName(),Long.valueOf(thread.getTotalActiveTime()),Integer.valueOf(numStuckThreads),String.valueOf(thread.getId()));
    log.warn(msg);
  }
}
