public boolean isScriptingInvalid(){
  return scriptingInvalid;
}
