/** 
 * {@inheritDoc}
 */
@Override public String getValidatorClassName(){
  return getPoolProperties().getValidatorClassName();
}
