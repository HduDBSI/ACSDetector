@Override public void flush() throws IOException {
  fireOnBeforeWriteResponseBodyEvent();
  servletOutputStream.flush();
}
