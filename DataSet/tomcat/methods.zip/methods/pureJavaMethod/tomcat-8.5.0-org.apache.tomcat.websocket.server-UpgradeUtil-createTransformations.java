private static List<Transformation> createTransformations(List<Extension> negotiatedExtensions){
  TransformationFactory factory=TransformationFactory.getInstance();
  LinkedHashMap<String,List<List<Extension.Parameter>>> extensionPreferences=new LinkedHashMap<>();
  List<Transformation> result=new ArrayList<>(negotiatedExtensions.size());
  for (  Extension extension : negotiatedExtensions) {
    List<List<Extension.Parameter>> preferences=extensionPreferences.get(extension.getName());
    if (preferences == null) {
      preferences=new ArrayList<>();
      extensionPreferences.put(extension.getName(),preferences);
    }
    preferences.add(extension.getParameters());
  }
  for (  Map.Entry<String,List<List<Extension.Parameter>>> entry : extensionPreferences.entrySet()) {
    Transformation transformation=factory.create(entry.getKey(),entry.getValue(),true);
    if (transformation != null) {
      result.add(transformation);
    }
  }
  return result;
}
