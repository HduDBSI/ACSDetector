/** 
 * @return The request associated with this processor.
 */
Request getRequest();
