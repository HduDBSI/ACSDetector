public void update(){
  fireTableDataChanged();
}
