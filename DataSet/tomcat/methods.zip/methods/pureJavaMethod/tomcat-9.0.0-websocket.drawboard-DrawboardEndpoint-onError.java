@Override public void onError(Session session,Throwable t){
  int count=0;
  Throwable root=t;
  while (root.getCause() != null && count < 20) {
    root=root.getCause();
    count++;
  }
  if (root instanceof EOFException) {
  }
 else   if (!session.isOpen() && root instanceof IOException) {
  }
 else {
    log.error("onError: " + t.toString(),t);
  }
}
