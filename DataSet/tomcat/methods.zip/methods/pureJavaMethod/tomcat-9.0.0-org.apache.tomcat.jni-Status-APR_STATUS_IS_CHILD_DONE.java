public static final boolean APR_STATUS_IS_CHILD_DONE(int s){
  return is(s,55);
}
