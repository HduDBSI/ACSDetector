/** 
 * Remove any resource reference with the specified name.
 * @param resourceName Name of the resource reference to remove
 */
public void removeResource(String resourceName){
  resourceName=ObjectName.unquote(resourceName);
  NamingResourcesImpl nresources=(NamingResourcesImpl)this.resource;
  if (nresources == null) {
    return;
  }
  ContextResource resource=nresources.findResource(resourceName);
  if (resource == null) {
    throw new IllegalArgumentException("Invalid resource name '" + resourceName + "'");
  }
  nresources.removeResource(resourceName);
}
