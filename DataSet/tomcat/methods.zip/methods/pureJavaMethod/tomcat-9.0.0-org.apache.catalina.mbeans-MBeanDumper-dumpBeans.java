/** 
 * The following code to dump MBeans has been copied from JMXProxyServlet.
 * @param mbeanServer the MBean server
 * @param names a set of object names for which to dump the info
 * @return a string representation of the MBeans
 */
public static String dumpBeans(MBeanServer mbeanServer,Set<ObjectName> names){
  StringBuilder buf=new StringBuilder();
  for (  ObjectName oname : names) {
    buf.append("Name: ");
    buf.append(oname.toString());
    buf.append(CRLF);
    try {
      MBeanInfo minfo=mbeanServer.getMBeanInfo(oname);
      String code=minfo.getClassName();
      if ("org.apache.commons.modeler.BaseModelMBean".equals(code)) {
        code=(String)mbeanServer.getAttribute(oname,"modelerType");
      }
      buf.append("modelerType: ");
      buf.append(code);
      buf.append(CRLF);
      MBeanAttributeInfo attrs[]=minfo.getAttributes();
      Object value=null;
      for (      MBeanAttributeInfo attr : attrs) {
        if (!attr.isReadable())         continue;
        String attName=attr.getName();
        if ("modelerType".equals(attName))         continue;
        if (attName.indexOf('=') >= 0 || attName.indexOf(':') >= 0 || attName.indexOf(' ') >= 0) {
          continue;
        }
        try {
          value=mbeanServer.getAttribute(oname,attName);
        }
 catch (        JMRuntimeException rme) {
          Throwable cause=rme.getCause();
          if (cause instanceof UnsupportedOperationException) {
            if (log.isDebugEnabled()) {
              log.debug("Error getting attribute " + oname + " "+ attName,rme);
            }
          }
 else           if (cause instanceof NullPointerException) {
            if (log.isDebugEnabled()) {
              log.debug("Error getting attribute " + oname + " "+ attName,rme);
            }
          }
 else {
            log.error("Error getting attribute " + oname + " "+ attName,rme);
          }
          continue;
        }
catch (        Throwable t) {
          ExceptionUtils.handleThrowable(t);
          log.error("Error getting attribute " + oname + " "+ attName,t);
          continue;
        }
        if (value == null) {
          continue;
        }
        String valueString;
        try {
          Class<?> c=value.getClass();
          if (c.isArray()) {
            int len=Array.getLength(value);
            StringBuilder sb=new StringBuilder("Array[" + c.getComponentType().getName() + "] of length "+ len);
            if (len > 0) {
              sb.append(CRLF);
            }
            for (int j=0; j < len; j++) {
              Object item=Array.get(value,j);
              sb.append(tableItemToString(item));
              if (j < len - 1) {
                sb.append(CRLF);
              }
            }
            valueString=sb.toString();
          }
 else           if (TabularData.class.isInstance(value)) {
            TabularData tab=TabularData.class.cast(value);
            StringJoiner joiner=new StringJoiner(CRLF);
            joiner.add("TabularData[" + tab.getTabularType().getRowType().getTypeName() + "] of length "+ tab.size());
            for (            Object item : tab.values()) {
              joiner.add(tableItemToString(item));
            }
            valueString=joiner.toString();
          }
 else {
            valueString=valueToString(value);
          }
          buf.append(attName);
          buf.append(": ");
          buf.append(valueString);
          buf.append(CRLF);
        }
 catch (        Throwable t) {
          ExceptionUtils.handleThrowable(t);
        }
      }
    }
 catch (    Throwable t) {
      ExceptionUtils.handleThrowable(t);
    }
    buf.append(CRLF);
  }
  return buf.toString();
}
