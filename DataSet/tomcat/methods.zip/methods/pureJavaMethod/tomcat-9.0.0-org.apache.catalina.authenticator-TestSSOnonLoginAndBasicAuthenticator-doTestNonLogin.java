public void doTestNonLogin(String uri,boolean useCookie,int expectedRC) throws Exception {
  Map<String,List<String>> reqHeaders=new HashMap<>();
  Map<String,List<String>> respHeaders=new HashMap<>();
  if (useCookie && (cookies != null)) {
    addCookies(reqHeaders);
  }
  ByteChunk bc=new ByteChunk();
  int rc=getUrl(HTTP_PREFIX + getPort() + uri,bc,reqHeaders,respHeaders);
  if (expectedRC != HttpServletResponse.SC_OK) {
    assertEquals(expectedRC,rc);
    assertTrue(bc.getLength() > 0);
  }
 else {
    assertEquals("OK",bc.toString());
  }
}
