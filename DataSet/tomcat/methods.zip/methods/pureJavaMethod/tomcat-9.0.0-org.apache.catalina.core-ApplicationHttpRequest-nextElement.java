@Override public String nextElement(){
  if (pos != last) {
    for (int i=pos + 1; i <= last; i++) {
      if (getAttribute(specials[i]) != null) {
        pos=i;
        return specials[i];
      }
    }
  }
  String result=next;
  if (next != null) {
    next=findNext();
  }
 else {
    throw new NoSuchElementException();
  }
  return result;
}
