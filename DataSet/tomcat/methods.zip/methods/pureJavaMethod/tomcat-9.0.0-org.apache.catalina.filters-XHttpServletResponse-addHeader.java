@Override public void addHeader(String name,String value){
  super.addHeader(name,value);
  if (HEADER_CACHE_CONTROL.equalsIgnoreCase(name) && cacheControlHeader == null) {
    cacheControlHeader=value;
  }
}
