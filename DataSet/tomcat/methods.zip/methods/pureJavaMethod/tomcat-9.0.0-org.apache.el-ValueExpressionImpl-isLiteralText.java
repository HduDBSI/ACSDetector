@Override public boolean isLiteralText(){
  try {
    return this.getNode() instanceof AstLiteralExpression;
  }
 catch (  ELException ele) {
    return false;
  }
}
