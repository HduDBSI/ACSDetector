@Override protected void startInternal() throws LifecycleException {
  while (sessionCreationTiming.size() < TIMING_STATS_CACHE_SIZE) {
    sessionCreationTiming.add(null);
  }
  while (sessionExpirationTiming.size() < TIMING_STATS_CACHE_SIZE) {
    sessionExpirationTiming.add(null);
  }
  SessionIdGenerator sessionIdGenerator=getSessionIdGenerator();
  if (sessionIdGenerator == null) {
    sessionIdGenerator=new StandardSessionIdGenerator();
    setSessionIdGenerator(sessionIdGenerator);
  }
  sessionIdGenerator.setJvmRoute(getJvmRoute());
  if (sessionIdGenerator instanceof SessionIdGeneratorBase) {
    SessionIdGeneratorBase sig=(SessionIdGeneratorBase)sessionIdGenerator;
    sig.setSecureRandomAlgorithm(getSecureRandomAlgorithm());
    sig.setSecureRandomClass(getSecureRandomClass());
    sig.setSecureRandomProvider(getSecureRandomProvider());
  }
  if (sessionIdGenerator instanceof Lifecycle) {
    ((Lifecycle)sessionIdGenerator).start();
  }
 else {
    if (log.isDebugEnabled())     log.debug("Force random number initialization starting");
    sessionIdGenerator.generateSessionId();
    if (log.isDebugEnabled())     log.debug("Force random number initialization completed");
  }
}
