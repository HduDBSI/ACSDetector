/** 
 * Send all changed cross context sessions to backups
 * @param containerCluster
 */
protected void sendCrossContextSession(CatalinaCluster containerCluster){
  List<DeltaSession> sessions=crossContextSessions.get();
  if (sessions != null && sessions.size() > 0) {
    for (    DeltaSession session : sessions) {
      if (log.isDebugEnabled()) {
        log.debug(sm.getString("ReplicationValve.crossContext.sendDelta",session.getManager().getContainer().getName()));
      }
      sendMessage(session,(ClusterManager)session.getManager(),containerCluster);
      if (doStatistics()) {
        nrOfCrossContextSendRequests++;
      }
    }
  }
}
