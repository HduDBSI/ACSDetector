public static final boolean APR_STATUS_IS_FILEBASED(int s){
  return is(s,70);
}
