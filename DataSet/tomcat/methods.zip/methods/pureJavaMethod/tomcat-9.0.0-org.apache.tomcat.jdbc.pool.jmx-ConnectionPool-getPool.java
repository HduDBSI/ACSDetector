public org.apache.tomcat.jdbc.pool.ConnectionPool getPool(){
  return pool;
}
