public void setErrorCount(int errorCount){
  this.errorCount=errorCount;
}
