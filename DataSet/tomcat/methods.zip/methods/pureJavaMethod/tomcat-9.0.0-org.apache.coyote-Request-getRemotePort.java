public int getRemotePort(){
  return remotePort;
}
