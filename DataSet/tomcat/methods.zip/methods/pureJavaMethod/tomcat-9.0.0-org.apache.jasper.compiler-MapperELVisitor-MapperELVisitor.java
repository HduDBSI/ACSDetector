MapperELVisitor(ValidateFunctionMapper fmapper){
  this.fmapper=fmapper;
}
