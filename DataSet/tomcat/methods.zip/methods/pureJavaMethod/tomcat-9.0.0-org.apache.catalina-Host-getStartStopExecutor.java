/** 
 * @return the executor that is used for starting and stopping contexts. Thisis primarily for use by components deploying contexts that want to do this in a multi-threaded manner.
 */
public ExecutorService getStartStopExecutor();
