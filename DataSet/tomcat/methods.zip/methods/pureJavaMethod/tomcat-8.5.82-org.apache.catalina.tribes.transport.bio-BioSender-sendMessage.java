/** 
 * Send message.
 * @param data The data to send
 * @param waitForAck Wait for an ack
 * @throws IOException An IO error occurred sending the message
 */
public void sendMessage(byte[] data,boolean waitForAck) throws IOException {
  IOException exception=null;
  setAttempt(0);
  try {
    pushMessage(data,false,waitForAck);
  }
 catch (  IOException x) {
    SenderState.getSenderState(getDestination()).setSuspect();
    exception=x;
    if (log.isTraceEnabled()) {
      log.trace(sm.getString("bioSender.send.again",getAddress().getHostAddress(),Integer.valueOf(getPort())),x);
    }
    while (getAttempt() < getMaxRetryAttempts()) {
      try {
        setAttempt(getAttempt() + 1);
        pushMessage(data,true,waitForAck);
        exception=null;
      }
 catch (      IOException xx) {
        exception=xx;
        closeSocket();
      }
    }
  }
 finally {
    setRequestCount(getRequestCount() + 1);
    keepalive();
    if (exception != null) {
      throw exception;
    }
  }
}
