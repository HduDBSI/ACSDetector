/** 
 * @return the member that represents this node.
 */
public Member getLocalMember();
