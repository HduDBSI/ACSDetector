/** 
 * @param sendAllSessionsSize The sendAllSessionsSize to set.
 */
public void setSendAllSessionsSize(int sendAllSessionsSize){
  this.sendAllSessionsSize=sendAllSessionsSize;
}
