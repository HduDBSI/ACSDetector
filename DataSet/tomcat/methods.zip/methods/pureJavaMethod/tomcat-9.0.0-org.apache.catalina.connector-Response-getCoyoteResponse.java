/** 
 * @return the Coyote response.
 */
public org.apache.coyote.Response getCoyoteResponse(){
  return this.coyoteResponse;
}
