@Test public void testSendRedirect03() throws Exception {
  doTestSendRedirect("../foo%20bar","../foo%20bar");
}
