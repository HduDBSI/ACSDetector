public char getType(){
  return type;
}
