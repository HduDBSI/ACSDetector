static Method findMethod(Class<?> clazz,String methodName,Class<?>[] paramTypes,Object[] paramValues){
  if (clazz == null || methodName == null) {
    throw new MethodNotFoundException(message(null,"util.method.notfound",clazz,methodName,paramString(paramTypes)));
  }
  if (paramTypes == null) {
    paramTypes=getTypesFromValues(paramValues);
  }
  Method[] methods=clazz.getMethods();
  List<Wrapper> wrappers=Wrapper.wrap(methods,methodName);
  Wrapper result=findWrapper(clazz,wrappers,methodName,paramTypes,paramValues);
  if (result == null) {
    return null;
  }
  return getMethod(clazz,(Method)result.unWrap());
}
