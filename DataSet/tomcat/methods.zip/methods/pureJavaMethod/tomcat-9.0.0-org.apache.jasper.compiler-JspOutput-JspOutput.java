public JspOutput(String qName,Attributes attrs,Attributes nonTaglibXmlnsAttrs,Attributes taglibAttrs,Mark start,Node parent){
  super(qName,OUTPUT_ACTION,attrs,nonTaglibXmlnsAttrs,taglibAttrs,start,parent);
}
