@Override public void addElement(CharArrayWriter buf,Date date,Request request,Response response,long time){
  buf.append(LOCAL_ADDR_VALUE);
}
