public DOMWriter(Writer writer,boolean canonical){
  out=new PrintWriter(writer);
  this.canonical=canonical;
}
