@Override public void messageReceived(ChannelMessage msg){
  if (msg.getMessage().getLength() == MEMBER_START.length && Arrays.equals(MEMBER_START,msg.getMessage().getBytes())) {
    Member member=getMember(msg.getAddress());
    if (member != null) {
      super.memberAdded(member);
    }
  }
 else   if (msg.getMessage().getLength() == MEMBER_STOP.length && Arrays.equals(MEMBER_STOP,msg.getMessage().getBytes())) {
    Member member=getMember(msg.getAddress());
    if (member != null) {
      try {
        member.setCommand(Member.SHUTDOWN_PAYLOAD);
        super.memberDisappeared(member);
      }
  finally {
        member.setCommand(new byte[0]);
      }
    }
  }
 else {
    super.messageReceived(msg);
  }
}
