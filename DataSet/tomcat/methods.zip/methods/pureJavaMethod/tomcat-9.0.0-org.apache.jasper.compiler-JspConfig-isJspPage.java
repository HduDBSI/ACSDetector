/** 
 * To find out if an uri matches an url pattern in jsp config.  If so, then the uri is a JSP page.  This is used primarily for jspc.
 * @param uri The path to check
 * @return <code>true</code> if the path denotes a JSP page
 */
public boolean isJspPage(String uri){
  init();
  if (jspProperties == null) {
    return false;
  }
  String uriPath=null;
  int index=uri.lastIndexOf('/');
  if (index >= 0) {
    uriPath=uri.substring(0,index + 1);
  }
  String uriExtension=null;
  index=uri.lastIndexOf('.');
  if (index >= 0) {
    uriExtension=uri.substring(index + 1);
  }
  for (  JspPropertyGroup jpg : jspProperties) {
    String extension=jpg.getExtension();
    String path=jpg.getPath();
    if (extension == null) {
      if (uri.equals(path)) {
        return true;
      }
    }
 else {
      if ((path == null || path.equals(uriPath)) && (extension.equals("*") || extension.equals(uriExtension))) {
        return true;
      }
    }
  }
  return false;
}
