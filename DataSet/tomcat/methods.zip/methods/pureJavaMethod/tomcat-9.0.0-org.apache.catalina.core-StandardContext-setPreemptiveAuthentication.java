@Override public void setPreemptiveAuthentication(boolean preemptiveAuthentication){
  this.preemptiveAuthentication=preemptiveAuthentication;
}
