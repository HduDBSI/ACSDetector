public String getAttrValue(){
  return attrValue;
}
