/** 
 * Sets the use HttpOnly cookies for session cookies flag.
 * @param useHttpOnly   Set to <code>true</code> to use HttpOnly cookiesfor session cookies
 */
public void setUseHttpOnly(boolean useHttpOnly);
