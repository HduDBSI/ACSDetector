public boolean isDeferredSyntaxAllowedAsLiteral(){
  return deferredSyntaxAllowedAsLiteral;
}
