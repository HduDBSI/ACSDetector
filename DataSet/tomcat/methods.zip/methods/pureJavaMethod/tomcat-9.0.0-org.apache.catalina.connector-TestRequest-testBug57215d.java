@Test public void testBug57215d() throws Exception {
  doBug56501("/path","/%2Fpath%2F","/%2Fpath");
}
