/** 
 * Set the Wrapper with which we are associated.
 * @param wrapper The new wrapper
 */
@Override public void setWrapper(Wrapper wrapper){
  this.wrapper=wrapper;
  if (wrapper == null) {
    context=null;
    host=null;
    oname=null;
  }
 else {
    context=(Context)wrapper.getParent();
    host=(Host)context.getParent();
    Engine engine=(Engine)host.getParent();
    String name=engine.getName() + ":type=Deployer,host=" + host.getName();
    try {
      oname=new ObjectName(name);
    }
 catch (    Exception e) {
      log(sm.getString("managerServlet.objectNameFail",name),e);
    }
  }
  mBeanServer=Registry.getRegistry(null,null).getMBeanServer();
}
