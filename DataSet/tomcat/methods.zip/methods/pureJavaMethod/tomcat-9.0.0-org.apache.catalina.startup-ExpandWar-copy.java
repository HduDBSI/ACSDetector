/** 
 * Copy the specified file or directory to the destination.
 * @param src File object representing the source
 * @param dest File object representing the destination
 * @return <code>true</code> if the copy was successful
 */
public static boolean copy(File src,File dest){
  boolean result=true;
  String files[]=null;
  if (src.isDirectory()) {
    files=src.list();
    result=dest.mkdir();
  }
 else {
    files=new String[1];
    files[0]="";
  }
  if (files == null) {
    files=new String[0];
  }
  for (int i=0; (i < files.length) && result; i++) {
    File fileSrc=new File(src,files[i]);
    File fileDest=new File(dest,files[i]);
    if (fileSrc.isDirectory()) {
      result=copy(fileSrc,fileDest);
    }
 else {
      try (FileChannel ic=(new FileInputStream(fileSrc)).getChannel();FileChannel oc=(new FileOutputStream(fileDest)).getChannel()){
        ic.transferTo(0,ic.size(),oc);
      }
 catch (      IOException e) {
        log.error(sm.getString("expandWar.copy",fileSrc,fileDest),e);
        result=false;
      }
    }
  }
  return result;
}
