/** 
 * Check if sendfile can be used.
 * @param request The Servlet request
 * @param response The Servlet response
 * @param resource The resource
 * @param length The length which will be written (will be used only ifrange is null)
 * @param range The range that will be written
 * @return <code>true</code> if sendfile should be used (writing is thendelegated to the endpoint)
 */
protected boolean checkSendfile(HttpServletRequest request,HttpServletResponse response,WebResource resource,long length,Range range){
  String canonicalPath;
  if (sendfileSize > 0 && length > sendfileSize && (Boolean.TRUE.equals(request.getAttribute(Globals.SENDFILE_SUPPORTED_ATTR))) && (request.getClass().getName().equals("org.apache.catalina.connector.RequestFacade")) && (response.getClass().getName().equals("org.apache.catalina.connector.ResponseFacade")) && resource.isFile() && ((canonicalPath=resource.getCanonicalPath()) != null)) {
    request.setAttribute(Globals.SENDFILE_FILENAME_ATTR,canonicalPath);
    if (range == null) {
      request.setAttribute(Globals.SENDFILE_FILE_START_ATTR,Long.valueOf(0L));
      request.setAttribute(Globals.SENDFILE_FILE_END_ATTR,Long.valueOf(length));
    }
 else {
      request.setAttribute(Globals.SENDFILE_FILE_START_ATTR,Long.valueOf(range.start));
      request.setAttribute(Globals.SENDFILE_FILE_END_ATTR,Long.valueOf(range.end + 1));
    }
    return true;
  }
  return false;
}
