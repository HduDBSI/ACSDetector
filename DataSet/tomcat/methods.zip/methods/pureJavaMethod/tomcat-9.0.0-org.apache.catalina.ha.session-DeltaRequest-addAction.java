protected void addAction(int type,int action,String name,Object value){
  AttributeInfo info=null;
  if (this.actionPool.size() > 0) {
    try {
      info=actionPool.removeFirst();
    }
 catch (    Exception x) {
      log.error(sm.getString("deltaRequest.removeUnable"),x);
      info=new AttributeInfo(type,action,name,value);
    }
    info.init(type,action,name,value);
  }
 else {
    info=new AttributeInfo(type,action,name,value);
  }
  if (!recordAllActions) {
    try {
      actions.remove(info);
    }
 catch (    java.util.NoSuchElementException x) {
    }
  }
  actions.addLast(info);
}
