@Override public boolean willDecode(ByteBuffer bb){
  bb.mark();
  if (bb.get() == 0x12 && bb.get() == 0x34) {
    return true;
  }
  bb.reset();
  return false;
}
