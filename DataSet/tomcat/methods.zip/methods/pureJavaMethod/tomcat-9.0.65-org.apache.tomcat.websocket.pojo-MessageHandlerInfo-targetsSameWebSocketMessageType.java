public boolean targetsSameWebSocketMessageType(MessageHandlerInfo otherHandler){
  if (otherHandler == null) {
    return false;
  }
  return isPong() && otherHandler.isPong() || isBinary() && otherHandler.isBinary() || isText() && otherHandler.isText();
}
