private Exception doRequest(int postLimit,boolean ucChunkedHead){
  Tomcat tomcat=getTomcatInstance();
  try {
    init();
    tomcat.getConnector().setMaxPostSize(postLimit);
    connect();
    String[] request=new String[2];
    if (ucChunkedHead) {
      request[0]="POST http://localhost:8080/test HTTP/1.1" + CRLF + "Host: localhost:8080"+ CRLF+ "content-type: application/x-www-form-urlencoded"+ CRLF+ "Transfer-Encoding: CHUNKED"+ CRLF+ "Connection: close"+ CRLF+ CRLF+ "3"+ CRLF+ "a=1"+ CRLF;
    }
 else {
      request[0]="POST http://localhost:8080/test HTTP/1.1" + CRLF + "Host: localhost:8080"+ CRLF+ "content-type: application/x-www-form-urlencoded"+ CRLF+ "Transfer-Encoding: chunked"+ CRLF+ "Connection: close"+ CRLF+ CRLF+ "3"+ CRLF+ "a=1"+ CRLF;
    }
    request[1]="4" + CRLF + "&b=2"+ CRLF+ "0"+ CRLF+ CRLF;
    setRequest(request);
    processRequest();
    disconnect();
  }
 catch (  Exception e) {
    return e;
  }
  return null;
}
