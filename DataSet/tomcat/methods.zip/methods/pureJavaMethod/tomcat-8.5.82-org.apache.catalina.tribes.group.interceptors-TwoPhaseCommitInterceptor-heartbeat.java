@Override public void heartbeat(){
  try {
    long now=System.currentTimeMillis();
    @SuppressWarnings("unchecked") Map.Entry<UniqueId,MapEntry>[] entries=messages.entrySet().toArray(new Map.Entry[0]);
    for (    Map.Entry<UniqueId,MapEntry> uniqueIdMapEntryEntry : entries) {
      MapEntry entry=uniqueIdMapEntryEntry.getValue();
      if (entry.expired(now,expire)) {
        if (log.isInfoEnabled()) {
          log.info("Message [" + entry.id + "] has expired. Removing.");
        }
        messages.remove(entry.id);
      }
    }
  }
 catch (  Exception x) {
    log.warn(sm.getString("twoPhaseCommitInterceptor.heartbeat.failed"),x);
  }
 finally {
    super.heartbeat();
  }
}
