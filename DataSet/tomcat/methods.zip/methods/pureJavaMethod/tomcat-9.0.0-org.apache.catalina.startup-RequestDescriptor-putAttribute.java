public void putAttribute(String name,String value){
  attributes.put(name,value);
}
