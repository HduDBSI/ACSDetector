public void setMethod(String method){
  this.method=method;
}
