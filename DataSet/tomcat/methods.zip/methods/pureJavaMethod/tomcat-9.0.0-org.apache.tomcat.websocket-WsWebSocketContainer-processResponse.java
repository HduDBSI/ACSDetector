/** 
 * Process response, blocking until HTTP response has been fully received.
 * @throws ExecutionException
 * @throws InterruptedException
 * @throws DeploymentException
 * @throws TimeoutException
 */
private HttpResponse processResponse(ByteBuffer response,AsyncChannelWrapper channel,long timeout) throws InterruptedException, ExecutionException, DeploymentException, EOFException, TimeoutException {
  Map<String,List<String>> headers=new CaseInsensitiveKeyMap<>();
  int status=0;
  boolean readStatus=false;
  boolean readHeaders=false;
  String line=null;
  while (!readHeaders) {
    response.clear();
    Future<Integer> read=channel.read(response);
    Integer bytesRead=read.get(timeout,TimeUnit.MILLISECONDS);
    if (bytesRead.intValue() == -1) {
      throw new EOFException();
    }
    response.flip();
    while (response.hasRemaining() && !readHeaders) {
      if (line == null) {
        line=readLine(response);
      }
 else {
        line+=readLine(response);
      }
      if ("\r\n".equals(line)) {
        readHeaders=true;
      }
 else       if (line.endsWith("\r\n")) {
        if (readStatus) {
          parseHeaders(line,headers);
        }
 else {
          status=parseStatus(line);
          readStatus=true;
        }
        line=null;
      }
    }
  }
  return new HttpResponse(status,new WsHandshakeResponse(headers));
}
