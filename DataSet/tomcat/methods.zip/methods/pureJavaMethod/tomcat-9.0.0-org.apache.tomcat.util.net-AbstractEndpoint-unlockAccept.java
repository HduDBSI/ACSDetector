/** 
 * Unlock the server socket acceptor threads using bogus connections.
 */
private void unlockAccept(){
  int unlocksRequired=0;
  for (  Acceptor<U> acceptor : acceptors) {
    if (acceptor.getState() == AcceptorState.RUNNING) {
      unlocksRequired++;
    }
  }
  if (unlocksRequired == 0) {
    return;
  }
  InetSocketAddress unlockAddress=null;
  InetSocketAddress localAddress=null;
  try {
    localAddress=getLocalAddress();
  }
 catch (  IOException ioe) {
    getLog().debug(sm.getString("endpoint.debug.unlock.localFail",getName()),ioe);
  }
  if (localAddress == null) {
    getLog().warn(sm.getString("endpoint.debug.unlock.localNone",getName()));
    return;
  }
  try {
    unlockAddress=getUnlockAddress(localAddress);
    for (int i=0; i < unlocksRequired; i++) {
      try (java.net.Socket s=new java.net.Socket()){
        int stmo=2 * 1000;
        int utmo=2 * 1000;
        if (getSocketProperties().getSoTimeout() > stmo)         stmo=getSocketProperties().getSoTimeout();
        if (getSocketProperties().getUnlockTimeout() > utmo)         utmo=getSocketProperties().getUnlockTimeout();
        s.setSoTimeout(stmo);
        s.setSoLinger(getSocketProperties().getSoLingerOn(),getSocketProperties().getSoLingerTime());
        if (getLog().isDebugEnabled()) {
          getLog().debug("About to unlock socket for:" + unlockAddress);
        }
        s.connect(unlockAddress,utmo);
        if (getDeferAccept()) {
          OutputStreamWriter sw;
          sw=new OutputStreamWriter(s.getOutputStream(),"ISO-8859-1");
          sw.write("OPTIONS * HTTP/1.0\r\n" + "User-Agent: Tomcat wakeup connection\r\n\r\n");
          sw.flush();
        }
        if (getLog().isDebugEnabled()) {
          getLog().debug("Socket unlock completed for:" + unlockAddress);
        }
      }
     }
    long waitLeft=1000;
    for (    Acceptor<U> acceptor : acceptors) {
      while (waitLeft > 0 && acceptor.getState() == AcceptorState.RUNNING) {
        Thread.sleep(50);
        waitLeft-=50;
      }
    }
  }
 catch (  Exception e) {
    if (getLog().isDebugEnabled()) {
      getLog().debug(sm.getString("endpoint.debug.unlock.fail","" + getPort()),e);
    }
  }
}
