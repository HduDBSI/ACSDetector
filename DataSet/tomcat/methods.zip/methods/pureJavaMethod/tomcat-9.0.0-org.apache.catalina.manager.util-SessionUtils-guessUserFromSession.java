/** 
 * Try to get user from the session, if possible.
 * @param in_session The session
 * @return the user
 */
public static Object guessUserFromSession(final Session in_session){
  if (null == in_session) {
    return null;
  }
  if (in_session.getPrincipal() != null) {
    return in_session.getPrincipal().getName();
  }
  HttpSession httpSession=in_session.getSession();
  if (httpSession == null)   return null;
  try {
    Object user=null;
    for (int i=0; i < USER_TEST_ATTRIBUTES.length; ++i) {
      Object obj=httpSession.getAttribute(USER_TEST_ATTRIBUTES[i]);
      if (null != obj) {
        user=obj;
        break;
      }
      obj=httpSession.getAttribute(USER_TEST_ATTRIBUTES[i].toLowerCase(Locale.ENGLISH));
      if (null != obj) {
        user=obj;
        break;
      }
      obj=httpSession.getAttribute(USER_TEST_ATTRIBUTES[i].toUpperCase(Locale.ENGLISH));
      if (null != obj) {
        user=obj;
        break;
      }
    }
    if (null != user) {
      return user;
    }
    final List<Object> principalArray=new ArrayList<>();
    for (Enumeration<String> enumeration=httpSession.getAttributeNames(); enumeration.hasMoreElements(); ) {
      String name=enumeration.nextElement();
      Object obj=httpSession.getAttribute(name);
      if (obj instanceof Principal || obj instanceof Subject) {
        principalArray.add(obj);
      }
    }
    if (principalArray.size() == 1) {
      user=principalArray.get(0);
    }
    if (null != user) {
      return user;
    }
    return user;
  }
 catch (  IllegalStateException ise) {
    return null;
  }
}
