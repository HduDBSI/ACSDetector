private void gotoEntry(String name) throws IOException {
  if (entry != null && name.equals(entry.getName())) {
    return;
  }
  reset();
  JarEntry jarEntry=jarInputStream.getNextJarEntry();
  while (jarEntry != null) {
    if (name.equals(jarEntry.getName())) {
      entry=jarEntry;
      break;
    }
    jarEntry=jarInputStream.getNextJarEntry();
  }
}
