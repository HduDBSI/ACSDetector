/** 
 * AttributeValueDouble ::= (QuotedChar - '"')* ('"' | <TRANSLATION_ERROR>) RTAttributeValueDouble ::= ((QuotedChar - '"')* - ((QuotedChar-'"')'%>"') ('%>"' | TRANSLATION_ERROR)
 */
private String parseAttributeValue(String qName,String watch,boolean ignoreEL) throws JasperException {
  boolean quoteAttributeEL=ctxt.getOptions().getQuoteAttributeEL();
  Mark start=reader.mark();
  Mark stop=reader.skipUntilIgnoreEsc(watch,ignoreEL || quoteAttributeEL);
  if (stop == null) {
    err.jspError(start,"jsp.error.attribute.unterminated",qName);
  }
  String ret=null;
  try {
    char quote=watch.charAt(watch.length() - 1);
    boolean isElIgnored=pageInfo.isELIgnored() || watch.length() > 1;
    ret=AttributeParser.getUnquoted(reader.getText(start,stop),quote,isElIgnored,pageInfo.isDeferredSyntaxAllowedAsLiteral(),ctxt.getOptions().getStrictQuoteEscaping(),quoteAttributeEL);
  }
 catch (  IllegalArgumentException iae) {
    err.jspError(start,iae.getMessage());
  }
  if (watch.length() == 1)   return ret;
  return "<%=" + ret + "%>";
}
