private void doTestInternal(int threadCount,int iterations,Runnable test) throws Exception {
  long start=System.currentTimeMillis();
  Thread[] threads=new Thread[threadCount];
  for (int i=0; i < threadCount; i++) {
    threads[i]=new Thread(new TestThread(iterations,test));
  }
  for (int i=0; i < threadCount; i++) {
    threads[i].start();
  }
  for (int i=0; i < threadCount; i++) {
    threads[i].join();
  }
  long end=System.currentTimeMillis();
  System.out.println(test.getClass().getSimpleName() + ": " + threadCount+ " threads and "+ iterations+ " iterations using "+ test+ " took "+ (end - start)+ "ms");
}
