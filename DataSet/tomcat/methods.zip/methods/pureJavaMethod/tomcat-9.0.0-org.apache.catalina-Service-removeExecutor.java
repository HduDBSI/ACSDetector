/** 
 * Removes an executor from the service
 * @param ex Executor
 */
public void removeExecutor(Executor ex);
