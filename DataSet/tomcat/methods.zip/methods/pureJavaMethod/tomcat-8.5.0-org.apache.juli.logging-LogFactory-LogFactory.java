/** 
 * Private constructor that is not available for public use.
 */
private LogFactory(){
  ServiceLoader<Log> logLoader=ServiceLoader.load(Log.class);
  Constructor<? extends Log> m=null;
  for (  Log log : logLoader) {
    Class<? extends Log> c=log.getClass();
    try {
      m=c.getConstructor(String.class);
      break;
    }
 catch (    NoSuchMethodException|SecurityException e) {
      throw new Error(e);
    }
  }
  discoveredLogConstructor=m;
}
