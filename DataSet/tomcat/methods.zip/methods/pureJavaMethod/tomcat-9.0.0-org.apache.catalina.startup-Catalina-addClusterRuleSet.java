/** 
 * Cluster support is optional. The JARs may have been removed.
 */
private void addClusterRuleSet(Digester digester,String prefix){
  Class<?> clazz=null;
  Constructor<?> constructor=null;
  try {
    clazz=Class.forName("org.apache.catalina.ha.ClusterRuleSet");
    constructor=clazz.getConstructor(String.class);
    RuleSet ruleSet=(RuleSet)constructor.newInstance(prefix);
    digester.addRuleSet(ruleSet);
  }
 catch (  Exception e) {
    if (log.isDebugEnabled()) {
      log.debug(sm.getString("catalina.noCluster",e.getClass().getName() + ": " + e.getMessage()),e);
    }
 else     if (log.isInfoEnabled()) {
      log.info(sm.getString("catalina.noCluster",e.getClass().getName() + ": " + e.getMessage()));
    }
  }
}
