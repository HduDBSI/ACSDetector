/** 
 * Check if the if-none-match condition is satisfied.
 * @param request   The servlet request we are processing
 * @param response  The servlet response we are creating
 * @param resource  The resource
 * @return <code>true</code> if the resource meets the specified condition,and <code>false</code> if the condition is not satisfied, in which case request processing is stopped
 * @throws IOException an IO error occurred
 */
protected boolean checkIfNoneMatch(HttpServletRequest request,HttpServletResponse response,WebResource resource) throws IOException {
  String eTag=resource.getETag();
  String headerValue=request.getHeader("If-None-Match");
  if (headerValue != null) {
    boolean conditionSatisfied=false;
    if (!headerValue.equals("*")) {
      StringTokenizer commaTokenizer=new StringTokenizer(headerValue,",");
      while (!conditionSatisfied && commaTokenizer.hasMoreTokens()) {
        String currentToken=commaTokenizer.nextToken();
        if (currentToken.trim().equals(eTag))         conditionSatisfied=true;
      }
    }
 else {
      conditionSatisfied=true;
    }
    if (conditionSatisfied) {
      if (("GET".equals(request.getMethod())) || ("HEAD".equals(request.getMethod()))) {
        response.setStatus(HttpServletResponse.SC_NOT_MODIFIED);
        response.setHeader("ETag",eTag);
        return false;
      }
      response.sendError(HttpServletResponse.SC_PRECONDITION_FAILED);
      return false;
    }
  }
  return true;
}
