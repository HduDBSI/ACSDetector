private File createDirInExternal(boolean withXml) throws IOException {
  File ext=new File(external,"external" + ".war");
  if (withXml) {
    recursiveCopy(DIR_XML_SOURCE.toPath(),ext.toPath());
  }
 else {
    recursiveCopy(DIR_SOURCE.toPath(),ext.toPath());
  }
  return ext;
}
