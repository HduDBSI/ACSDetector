/** 
 * Creates a new WebSocket session for communication between the two provided end points. The result of  {@link Thread#getContextClassLoader()}at the time this constructor is called will be used when calling {@link Endpoint#onClose(Session,CloseReason)}.
 * @param localEndpoint        The end point managed by this code
 * @param wsRemoteEndpoint     The other / remote endpoint
 * @param wsWebSocketContainer The container that created this session
 * @param requestUri           The URI used to connect to this endpoint or<code>null</code> is this is a client session
 * @param requestParameterMap  The parameters associated with the requestthat initiated this session or <code>null</code> if this is a client session
 * @param queryString          The query string associated with the requestthat initiated this session or <code>null</code> if this is a client session
 * @param userPrincipal        The principal associated with the requestthat initiated this session or <code>null</code> if this is a client session
 * @param httpSessionId        The HTTP session ID associated with therequest that initiated this session or <code>null</code> if this is a client session
 * @param negotiatedExtensions The agreed extensions to use for this session
 * @param subProtocol          The agreed subprotocol to use for thissession
 * @param pathParameters       The path parameters associated with therequest that initiated this session or <code>null</code> if this is a client session
 * @param secure               Was this session initiated over a secureconnection?
 * @param endpointConfig       The configuration information for theendpoint
 * @throws DeploymentException if an invalid encode is specified
 */
public WsSession(Endpoint localEndpoint,WsRemoteEndpointImplBase wsRemoteEndpoint,WsWebSocketContainer wsWebSocketContainer,URI requestUri,Map<String,List<String>> requestParameterMap,String queryString,Principal userPrincipal,String httpSessionId,List<Extension> negotiatedExtensions,String subProtocol,Map<String,String> pathParameters,boolean secure,EndpointConfig endpointConfig) throws DeploymentException {
  this.localEndpoint=localEndpoint;
  this.wsRemoteEndpoint=wsRemoteEndpoint;
  this.wsRemoteEndpoint.setSession(this);
  this.remoteEndpointAsync=new WsRemoteEndpointAsync(wsRemoteEndpoint);
  this.remoteEndpointBasic=new WsRemoteEndpointBasic(wsRemoteEndpoint);
  this.webSocketContainer=wsWebSocketContainer;
  applicationClassLoader=Thread.currentThread().getContextClassLoader();
  wsRemoteEndpoint.setSendTimeout(wsWebSocketContainer.getDefaultAsyncSendTimeout());
  this.maxBinaryMessageBufferSize=webSocketContainer.getDefaultMaxBinaryMessageBufferSize();
  this.maxTextMessageBufferSize=webSocketContainer.getDefaultMaxTextMessageBufferSize();
  this.maxIdleTimeout=webSocketContainer.getDefaultMaxSessionIdleTimeout();
  this.requestUri=requestUri;
  if (requestParameterMap == null) {
    this.requestParameterMap=Collections.emptyMap();
  }
 else {
    this.requestParameterMap=requestParameterMap;
  }
  this.queryString=queryString;
  this.userPrincipal=userPrincipal;
  this.httpSessionId=httpSessionId;
  this.negotiatedExtensions=negotiatedExtensions;
  if (subProtocol == null) {
    this.subProtocol="";
  }
 else {
    this.subProtocol=subProtocol;
  }
  this.pathParameters=pathParameters;
  this.secure=secure;
  this.wsRemoteEndpoint.setEncoders(endpointConfig);
  this.endpointConfig=endpointConfig;
  this.userProperties.putAll(endpointConfig.getUserProperties());
  this.id=Long.toHexString(ids.getAndIncrement());
  InstanceManager instanceManager=webSocketContainer.getInstanceManager();
  if (instanceManager == null) {
    instanceManager=InstanceManagerBindings.get(applicationClassLoader);
  }
  if (instanceManager != null) {
    try {
      instanceManager.newInstance(localEndpoint);
    }
 catch (    Exception e) {
      throw new DeploymentException(sm.getString("wsSession.instanceNew"),e);
    }
  }
  if (log.isDebugEnabled()) {
    log.debug(sm.getString("wsSession.created",id));
  }
}
