private void doTestNon2xxResponseAndExpectation(boolean useExpectation) throws Exception {
  Tomcat tomcat=getTomcatInstance();
  Context ctx=tomcat.addContext("",null);
  Tomcat.addServlet(ctx,"echo",new EchoBodyServlet());
  ctx.addServletMappingDecoded("/echo","echo");
  SecurityCollection collection=new SecurityCollection("All","");
  collection.addPatternDecoded("/*");
  SecurityConstraint constraint=new SecurityConstraint();
  constraint.addAuthRole("Any");
  constraint.addCollection(collection);
  ctx.addConstraint(constraint);
  tomcat.start();
  String request="POST /echo HTTP/1.1" + SimpleHttpClient.CRLF + "Host: localhost:"+ getPort()+ SimpleHttpClient.CRLF;
  if (useExpectation) {
    request+="Expect: 100-continue" + SimpleHttpClient.CRLF;
  }
  request+=SimpleHttpClient.CRLF + "HelloWorld";
  Client client=new Client(tomcat.getConnector().getLocalPort());
  client.setRequest(new String[]{request});
  client.setUseContentLength(true);
  client.connect();
  client.processRequest();
  Assert.assertTrue(client.isResponse403());
  String connectionHeaderValue=null;
  for (  String header : client.getResponseHeaders()) {
    if (header.startsWith("Connection:")) {
      connectionHeaderValue=header.substring(header.indexOf(':') + 1).trim();
      break;
    }
  }
  if (useExpectation) {
    List<String> connectionHeaders=new ArrayList<>();
    TokenList.parseTokenList(new StringReader(connectionHeaderValue),connectionHeaders);
    Assert.assertEquals(1,connectionHeaders.size());
    Assert.assertEquals("close",connectionHeaders.get(0));
  }
 else {
    Assert.assertNull(connectionHeaderValue);
  }
}
