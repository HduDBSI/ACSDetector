private void ReInitRounds(){
  int i;
  jjround=0x80000001;
  for (i=30; i-- > 0; )   jjrounds[i]=0x80000000;
}
