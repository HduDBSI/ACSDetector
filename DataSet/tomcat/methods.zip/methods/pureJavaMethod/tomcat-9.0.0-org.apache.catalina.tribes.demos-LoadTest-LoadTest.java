public LoadTest(ManagedChannel channel,boolean send,int msgCount,boolean debug,long pause,int stats,boolean breakOnEx){
  this.channel=channel;
  this.send=send;
  this.msgCount=msgCount;
  this.debug=debug;
  this.pause=pause;
  this.statsInterval=stats;
  this.breakonChannelException=breakOnEx;
}
