public static final boolean APR_STATUS_IS_EBADPATH(int s){
  return is(s,24);
}
