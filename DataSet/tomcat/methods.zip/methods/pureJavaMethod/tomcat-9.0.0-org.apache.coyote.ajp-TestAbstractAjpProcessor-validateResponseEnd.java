private void validateResponseEnd(TesterAjpMessage message,boolean expectedReuse){
  Assert.assertEquals((byte)'A',message.buf[0]);
  Assert.assertEquals((byte)'B',message.buf[1]);
  message.processHeader(false);
  Assert.assertEquals(0x05,message.readByte());
  Assert.assertEquals(2,message.getLen());
  boolean reuse=false;
  if (message.readByte() > 0) {
    reuse=true;
  }
  Assert.assertEquals(Boolean.valueOf(expectedReuse),Boolean.valueOf(reuse));
}
