public int getSoLingerTime(){
  return soLingerTime;
}
