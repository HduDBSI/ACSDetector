/** 
 * Load the class with the specified name, searching using the following algorithm until it finds and returns the class.  If the class cannot be found, returns <code>ClassNotFoundException</code>. <ul> <li>Call <code>findLoadedClass(String)</code> to check if the class has already been loaded.  If it has, the same <code>Class</code> object is returned.</li> <li>If the <code>delegate</code> property is set to <code>true</code>, call the <code>loadClass()</code> method of the parent class loader, if any.</li> <li>Call <code>findClass()</code> to find this class in our locally defined repositories.</li> <li>Call the <code>loadClass()</code> method of our parent class loader, if any.</li> </ul> If the class was found using the above steps, and the <code>resolve</code> flag is <code>true</code>, this method will then call <code>resolveClass(Class)</code> on the resulting Class object.
 * @param name The binary name of the class to be loaded
 * @param resolve If <code>true</code> then resolve the class
 * @exception ClassNotFoundException if the class was not found
 */
@Override public Class<?> loadClass(String name,boolean resolve) throws ClassNotFoundException {
synchronized (getClassLoadingLock(name)) {
    if (log.isDebugEnabled())     log.debug("loadClass(" + name + ", "+ resolve+ ")");
    Class<?> clazz=null;
    checkStateForClassLoading(name);
    clazz=findLoadedClass0(name);
    if (clazz != null) {
      if (log.isDebugEnabled())       log.debug("  Returning class from cache");
      if (resolve)       resolveClass(clazz);
      return clazz;
    }
    clazz=findLoadedClass(name);
    if (clazz != null) {
      if (log.isDebugEnabled())       log.debug("  Returning class from cache");
      if (resolve)       resolveClass(clazz);
      return clazz;
    }
    String resourceName=binaryNameToPath(name,false);
    ClassLoader javaseLoader=getJavaseClassLoader();
    boolean tryLoadingFromJavaseLoader;
    try {
      tryLoadingFromJavaseLoader=(javaseLoader.getResource(resourceName) != null);
    }
 catch (    Throwable t) {
      ExceptionUtils.handleThrowable(t);
      tryLoadingFromJavaseLoader=true;
    }
    if (tryLoadingFromJavaseLoader) {
      try {
        clazz=javaseLoader.loadClass(name);
        if (clazz != null) {
          if (resolve)           resolveClass(clazz);
          return clazz;
        }
      }
 catch (      ClassNotFoundException e) {
      }
    }
    if (securityManager != null) {
      int i=name.lastIndexOf('.');
      if (i >= 0) {
        try {
          securityManager.checkPackageAccess(name.substring(0,i));
        }
 catch (        SecurityException se) {
          String error="Security Violation, attempt to use " + "Restricted Class: " + name;
          log.info(error,se);
          throw new ClassNotFoundException(error,se);
        }
      }
    }
    boolean delegateLoad=delegate || filter(name,true);
    if (delegateLoad) {
      if (log.isDebugEnabled())       log.debug("  Delegating to parent classloader1 " + parent);
      try {
        clazz=Class.forName(name,false,parent);
        if (clazz != null) {
          if (log.isDebugEnabled())           log.debug("  Loading class from parent");
          if (resolve)           resolveClass(clazz);
          return clazz;
        }
      }
 catch (      ClassNotFoundException e) {
      }
    }
    if (log.isDebugEnabled())     log.debug("  Searching local repositories");
    try {
      clazz=findClass(name);
      if (clazz != null) {
        if (log.isDebugEnabled())         log.debug("  Loading class from local repository");
        if (resolve)         resolveClass(clazz);
        return clazz;
      }
    }
 catch (    ClassNotFoundException e) {
    }
    if (!delegateLoad) {
      if (log.isDebugEnabled())       log.debug("  Delegating to parent classloader at end: " + parent);
      try {
        clazz=Class.forName(name,false,parent);
        if (clazz != null) {
          if (log.isDebugEnabled())           log.debug("  Loading class from parent");
          if (resolve)           resolveClass(clazz);
          return clazz;
        }
      }
 catch (      ClassNotFoundException e) {
      }
    }
  }
  throw new ClassNotFoundException(name);
}
