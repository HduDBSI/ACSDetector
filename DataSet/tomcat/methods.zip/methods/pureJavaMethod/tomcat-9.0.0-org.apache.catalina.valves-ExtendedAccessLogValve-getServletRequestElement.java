protected AccessLogElement getServletRequestElement(String parameter){
  if ("authType".equals(parameter)) {
    return new AccessLogElement(){
      @Override public void addElement(      CharArrayWriter buf,      Date date,      Request request,      Response response,      long time){
        buf.append(wrap(request.getAuthType()));
      }
    }
;
  }
 else   if ("remoteUser".equals(parameter)) {
    return new AccessLogElement(){
      @Override public void addElement(      CharArrayWriter buf,      Date date,      Request request,      Response response,      long time){
        buf.append(wrap(request.getRemoteUser()));
      }
    }
;
  }
 else   if ("requestedSessionId".equals(parameter)) {
    return new AccessLogElement(){
      @Override public void addElement(      CharArrayWriter buf,      Date date,      Request request,      Response response,      long time){
        buf.append(wrap(request.getRequestedSessionId()));
      }
    }
;
  }
 else   if ("requestedSessionIdFromCookie".equals(parameter)) {
    return new AccessLogElement(){
      @Override public void addElement(      CharArrayWriter buf,      Date date,      Request request,      Response response,      long time){
        buf.append(wrap("" + request.isRequestedSessionIdFromCookie()));
      }
    }
;
  }
 else   if ("requestedSessionIdValid".equals(parameter)) {
    return new AccessLogElement(){
      @Override public void addElement(      CharArrayWriter buf,      Date date,      Request request,      Response response,      long time){
        buf.append(wrap("" + request.isRequestedSessionIdValid()));
      }
    }
;
  }
 else   if ("contentLength".equals(parameter)) {
    return new AccessLogElement(){
      @Override public void addElement(      CharArrayWriter buf,      Date date,      Request request,      Response response,      long time){
        buf.append(wrap("" + request.getContentLengthLong()));
      }
    }
;
  }
 else   if ("characterEncoding".equals(parameter)) {
    return new AccessLogElement(){
      @Override public void addElement(      CharArrayWriter buf,      Date date,      Request request,      Response response,      long time){
        buf.append(wrap(request.getCharacterEncoding()));
      }
    }
;
  }
 else   if ("locale".equals(parameter)) {
    return new AccessLogElement(){
      @Override public void addElement(      CharArrayWriter buf,      Date date,      Request request,      Response response,      long time){
        buf.append(wrap(request.getLocale()));
      }
    }
;
  }
 else   if ("protocol".equals(parameter)) {
    return new AccessLogElement(){
      @Override public void addElement(      CharArrayWriter buf,      Date date,      Request request,      Response response,      long time){
        buf.append(wrap(request.getProtocol()));
      }
    }
;
  }
 else   if ("scheme".equals(parameter)) {
    return new AccessLogElement(){
      @Override public void addElement(      CharArrayWriter buf,      Date date,      Request request,      Response response,      long time){
        buf.append(request.getScheme());
      }
    }
;
  }
 else   if ("secure".equals(parameter)) {
    return new AccessLogElement(){
      @Override public void addElement(      CharArrayWriter buf,      Date date,      Request request,      Response response,      long time){
        buf.append(wrap("" + request.isSecure()));
      }
    }
;
  }
  log.error("x param for servlet request, couldn't decode value: " + parameter);
  return null;
}
