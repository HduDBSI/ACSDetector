private String[] optionalMBeanNames(String host){
  if (isAccessLogEnabled()) {
    return new String[]{"Tomcat:type=Valve,host=" + host + ",name=AccessLogValve"};
  }
 else {
    return new String[]{};
  }
}
