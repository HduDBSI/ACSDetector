private static class DefaultAttributeMatcher implements AttributeMatcher {
  private final ComponentAttributeMatcher componentAttributeMatcher;
  private final AttributeSelectionSchema effectiveSchema;
  DefaultAttributeMatcher(  ComponentAttributeMatcher componentAttributeMatcher,  AttributeSelectionSchema effectiveSchema){
    this.componentAttributeMatcher=componentAttributeMatcher;
    this.effectiveSchema=effectiveSchema;
  }
  @Override public boolean isMatching(  AttributeContainer candidate,  AttributeContainer requested){
    return componentAttributeMatcher.isMatching(effectiveSchema,candidate,requested);
  }
  @Override public <T>boolean isMatching(  Attribute<T> attribute,  T candidate,  T requested){
    DefaultCompatibilityCheckResult<Object> result=new DefaultCompatibilityCheckResult<Object>(requested,candidate);
    effectiveSchema.matchValue(attribute,result);
    return result.isCompatible();
  }
  @Override public <T extends HasAttributes>List<T> matches(  Collection<? extends T> candidates,  AttributeContainerInternal requested){
    return matches(candidates,requested,null);
  }
  @Override public <T extends HasAttributes>List<T> matches(  Collection<? extends T> candidates,  AttributeContainerInternal requested,  @Nullable T fallback){
    return componentAttributeMatcher.match(effectiveSchema,candidates,requested,fallback);
  }
}
