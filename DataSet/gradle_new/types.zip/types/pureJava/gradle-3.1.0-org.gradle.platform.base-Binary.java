/** 
 * A physical binary artifact, which can run on a particular platform or runtime.
 */
@Incubating public interface Binary {
  /** 
 * Returns a human-consumable display name for this binary.
 */
  String getDisplayName();
}
