public class ResolvedLocalComponentsResultGraphVisitor implements DependencyGraphVisitor, ResolvedLocalComponentsResult {
  private final List<ResolvedProjectConfiguration> resolvedProjectConfigurations=new ArrayList<ResolvedProjectConfiguration>();
  private ComponentIdentifier rootId;
  @Override public void start(  DependencyGraphNode root){
    this.rootId=root.getOwner().getComponentId();
  }
  @Override public void visitNode(  DependencyGraphNode resolvedConfiguration){
    ComponentIdentifier componentId=resolvedConfiguration.getOwner().getComponentId();
    if (!rootId.equals(componentId) && componentId instanceof ProjectComponentIdentifier) {
      resolvedProjectConfigurations.add(new DefaultResolvedProjectConfiguration((ProjectComponentIdentifier)componentId,resolvedConfiguration.getResolvedConfigurationId().getConfiguration()));
    }
  }
  @Override public void visitEdge(  DependencyGraphNode resolvedConfiguration){
  }
  @Override public void finish(  DependencyGraphNode root){
  }
  @Override public Iterable<ResolvedProjectConfiguration> getResolvedProjectConfigurations(){
    return resolvedProjectConfigurations;
  }
  public ResolvedLocalComponentsResult complete(){
    return this;
  }
}
