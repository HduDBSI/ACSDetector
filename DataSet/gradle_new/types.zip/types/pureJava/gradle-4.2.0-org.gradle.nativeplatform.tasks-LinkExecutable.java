/** 
 * Links a binary executable from object files and libraries.
 */
@Incubating public class LinkExecutable extends AbstractLinkTask {
  @Override protected LinkerSpec createLinkerSpec(){
    return new DefaultLinkerSpec();
  }
}
