/** 
 * Deletes stale classes before invoking the actual compiler
 */
public abstract class CleaningJavaCompilerSupport<T extends JavaCompileSpec> implements org.gradle.language.base.internal.compile.Compiler<T> {
  @Override public WorkResult execute(  T spec){
    StaleClassCleaner cleaner=createCleaner(spec);
    addDirectory(cleaner,spec.getDestinationDir());
    MinimalJavaCompileOptions compileOptions=spec.getCompileOptions();
    addDirectory(cleaner,compileOptions.getAnnotationProcessorGeneratedSourcesDirectory());
    addDirectory(cleaner,compileOptions.getHeaderOutputDirectory());
    cleaner.execute();
    Compiler<? super T> compiler=getCompiler();
    return compiler.execute(spec);
  }
  private void addDirectory(  StaleClassCleaner cleaner,  File dir){
    if (dir != null) {
      cleaner.addDirToClean(dir);
    }
  }
  public abstract Compiler<T> getCompiler();
  protected abstract StaleClassCleaner createCleaner(  T spec);
}
