public static class ComponentCategoryDisambiguationRule implements AttributeDisambiguationRule<Category>, ReusableAction {
  final Category library;
  final Category platform;
  @Inject ComponentCategoryDisambiguationRule(  Category library,  Category regularPlatform){
    this.library=library;
    this.platform=regularPlatform;
  }
  @Override public void execute(  MultipleCandidatesDetails<Category> details){
    Category consumerValue=details.getConsumerValue();
    if (consumerValue == null) {
      Set<Category> candidateValues=details.getCandidateValues();
      if (candidateValues.contains(library)) {
        details.closestMatch(library);
      }
 else       if (candidateValues.contains(platform)) {
        details.closestMatch(platform);
      }
    }
  }
}
