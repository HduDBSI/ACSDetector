public class NativePlatformResolver implements PlatformResolver<NativePlatform> {
  private final NativePlatforms nativePlatforms;
  public NativePlatformResolver(  NativePlatforms nativePlatforms){
    this.nativePlatforms=nativePlatforms;
  }
  @Override public Class<NativePlatform> getType(){
    return NativePlatform.class;
  }
  @Override public NativePlatform resolve(  final PlatformRequirement platformRequirement){
    return CollectionUtils.findFirst(nativePlatforms.defaultPlatformDefinitions(),new Spec<NativePlatform>(){
      @Override public boolean isSatisfiedBy(      NativePlatform element){
        return element.getName().equals(platformRequirement.getPlatformName());
      }
    }
);
  }
}
