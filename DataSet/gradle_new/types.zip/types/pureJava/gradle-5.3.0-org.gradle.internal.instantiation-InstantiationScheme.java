/** 
 * A scheme, or strategy, for creating objects. <p>Implementations are provided by a  {@link InstantiatorFactory}.</p>
 */
public interface InstantiationScheme {
  /** 
 * Returns the set of annotations that are used by this instantiation scheme for dependency injection.
 */
  Set<Class<? extends Annotation>> getInjectionAnnotations();
  /** 
 * Creates a new  {@link InstanceFactory} for the given type, which creates instances based on the configuration of this scheme.
 */
  <T>InstanceFactory<T> forType(  Class<T> type);
  /** 
 * Creates a new  {@link Instantiator} which creates instances using the given services, based on the configuration of this scheme.
 */
  Instantiator withServices(  ServiceLookup services);
  /** 
 * Returns the instantiator which creates instances using a default set of services (usually empty), based on the configuration of this scheme.
 */
  Instantiator instantiator();
}
