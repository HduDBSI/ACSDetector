/** 
 * DO NOT CHANGE THIS INTERFACE. It is part of the cross-version protocol.
 * @since 2.5
 */
public interface InternalOperationFinishedProgressEvent extends InternalProgressEvent {
  /** 
 * Returns the result of running the build operation.
 * @return The build operation result
 */
  InternalOperationResult getResult();
}
