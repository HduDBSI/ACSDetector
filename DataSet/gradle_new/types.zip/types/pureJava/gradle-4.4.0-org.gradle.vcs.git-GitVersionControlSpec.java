/** 
 * A specification of a Git repository.
 * @since 4.4
 */
@Incubating public interface GitVersionControlSpec extends VersionControlSpec {
  /** 
 * The URL for the repository in the specification. <p><b>Note:</b> The return value is a  {@link URI} to avoid exposing thefull contract of  {@link java.net.URL} clients of this interface.Specifically,  {@link java.net.URL} extends {@link URI} to add networkoperations which are both unsuited for simple data specification and allocate additional memory.</p>
 */
  URI getUrl();
  /** 
 * Sets the URL of the repository.
 */
  void setUrl(  URI url);
  /** 
 * Sets the URL of the repository.
 */
  void setUrl(  String url);
}
