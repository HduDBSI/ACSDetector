public class TestExecutionRequestActionRunner implements BuildActionRunner {
  private final BuildOperationAncestryTracker ancestryTracker;
  private final BuildOperationListenerManager buildOperationListenerManager;
  public TestExecutionRequestActionRunner(  BuildOperationAncestryTracker ancestryTracker,  BuildOperationListenerManager buildOperationListenerManager){
    this.ancestryTracker=ancestryTracker;
    this.buildOperationListenerManager=buildOperationListenerManager;
  }
  @Override public Result run(  BuildAction action,  BuildTreeLifecycleController buildController){
    if (!(action instanceof TestExecutionRequestAction)) {
      return Result.nothing();
    }
    try {
      TestExecutionRequestAction testExecutionRequestAction=(TestExecutionRequestAction)action;
      TestExecutionResultEvaluator testExecutionResultEvaluator=new TestExecutionResultEvaluator(ancestryTracker,testExecutionRequestAction);
      buildOperationListenerManager.addListener(testExecutionResultEvaluator);
      try {
        doRun(testExecutionRequestAction,buildController);
      }
  finally {
        buildOperationListenerManager.removeListener(testExecutionResultEvaluator);
      }
      testExecutionResultEvaluator.evaluate();
    }
 catch (    RuntimeException e) {
      Throwable throwable=findRootCause(e);
      if (throwable instanceof TestExecutionException) {
        return Result.failed(e,new InternalTestExecutionException("Error while running test(s)",throwable));
      }
 else {
        return Result.failed(e);
      }
    }
    return Result.of(null);
  }
  private void doRun(  TestExecutionRequestAction action,  BuildTreeLifecycleController buildController){
    TestExecutionBuildConfigurationAction testTasksConfigurationAction=new TestExecutionBuildConfigurationAction(action,buildController.getGradle());
    buildController.getGradle().getServices().get(BuildConfigurationActionExecuter.class).setTaskSelectors(Collections.singletonList(testTasksConfigurationAction));
    buildController.scheduleAndRunTasks();
  }
  private Throwable findRootCause(  Exception tex){
    Throwable t=tex;
    while (t.getCause() != null) {
      t=t.getCause();
    }
    return t;
  }
}
