public class DefaultCppLibrary extends DefaultCppComponent implements CppLibrary, PublicationAwareComponent {
  private final ObjectFactory objectFactory;
  private final ConfigurableFileCollection publicHeaders;
  private final FileCollection publicHeadersWithConvention;
  private final LockableSetProperty<Linkage> linkage;
  private final Property<CppBinary> developmentBinary;
  private final Configuration apiElements;
  private final MainLibraryVariant mainVariant;
  private final DefaultLibraryDependencies dependencies;
  @Inject public DefaultCppLibrary(  String name,  ObjectFactory objectFactory,  FileOperations fileOperations,  ConfigurationContainer configurations){
    super(name,fileOperations,objectFactory);
    this.objectFactory=objectFactory;
    this.developmentBinary=objectFactory.property(CppBinary.class);
    publicHeaders=fileOperations.files();
    publicHeadersWithConvention=createDirView(publicHeaders,"src/" + name + "/public");
    linkage=new LockableSetProperty<Linkage>(objectFactory.setProperty(Linkage.class));
    linkage.add(Linkage.SHARED);
    dependencies=objectFactory.newInstance(DefaultLibraryDependencies.class,getNames().withSuffix("implementation"),getNames().withSuffix("api"));
    Usage apiUsage=objectFactory.named(Usage.class,Usage.C_PLUS_PLUS_API);
    apiElements=configurations.create(getNames().withSuffix("cppApiElements"));
    apiElements.extendsFrom(dependencies.getApiDependencies());
    apiElements.setCanBeResolved(false);
    apiElements.getAttributes().attribute(Usage.USAGE_ATTRIBUTE,apiUsage);
    mainVariant=new MainLibraryVariant("api",apiUsage,apiElements);
  }
  public DefaultCppSharedLibrary addSharedLibrary(  String nameSuffix,  boolean debuggable,  boolean optimized,  CppPlatform targetPlatform,  NativeToolChainInternal toolChain,  PlatformToolProvider platformToolProvider){
    DefaultCppSharedLibrary result=objectFactory.newInstance(DefaultCppSharedLibrary.class,getName() + StringUtils.capitalize(nameSuffix),getBaseName(),debuggable,optimized,getCppSource(),getAllHeaderDirs(),getImplementationDependencies(),targetPlatform,toolChain,platformToolProvider);
    getBinaries().add(result);
    return result;
  }
  public DefaultCppStaticLibrary addStaticLibrary(  String nameSuffix,  boolean debuggable,  boolean optimized,  CppPlatform targetPlatform,  NativeToolChainInternal toolChain,  PlatformToolProvider platformToolProvider){
    DefaultCppStaticLibrary result=objectFactory.newInstance(DefaultCppStaticLibrary.class,getName() + StringUtils.capitalize(nameSuffix),getBaseName(),debuggable,optimized,getCppSource(),getAllHeaderDirs(),getImplementationDependencies(),targetPlatform,toolChain,platformToolProvider);
    getBinaries().add(result);
    return result;
  }
  @Override public DisplayName getDisplayName(){
    return Describables.withTypeAndName("C++ library",getName());
  }
  @Override public Configuration getImplementationDependencies(){
    return dependencies.getImplementationDependencies();
  }
  @Override public Configuration getApiDependencies(){
    return dependencies.getApiDependencies();
  }
  @Override public LibraryDependencies getDependencies(){
    return dependencies;
  }
  public void dependencies(  Action<? super LibraryDependencies> action){
    action.execute(dependencies);
  }
  public Configuration getApiElements(){
    return apiElements;
  }
  @Override public MainLibraryVariant getMainPublication(){
    return mainVariant;
  }
  @Override public ConfigurableFileCollection getPublicHeaders(){
    return publicHeaders;
  }
  @Override public void publicHeaders(  Action<? super ConfigurableFileCollection> action){
    action.execute(publicHeaders);
  }
  @Override public FileCollection getPublicHeaderDirs(){
    return publicHeadersWithConvention;
  }
  @Override public FileTree getPublicHeaderFiles(){
    PatternSet patterns=new PatternSet();
    patterns.include("**/*.h");
    patterns.include("**/*.hpp");
    return publicHeadersWithConvention.getAsFileTree().matching(patterns);
  }
  @Override public FileCollection getAllHeaderDirs(){
    return publicHeadersWithConvention.plus(super.getAllHeaderDirs());
  }
  @Override public Property<CppBinary> getDevelopmentBinary(){
    return developmentBinary;
  }
  @Override public LockableSetProperty<Linkage> getLinkage(){
    return linkage;
  }
}
