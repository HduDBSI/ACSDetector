public class SwiftcMetadataProvider extends AbstractMetadataProvider<SwiftcMetadata> {
  private static final CompilerType SWIFTC_COMPILER_TYPE=new CompilerType(){
    @Override public String getIdentifier(){
      return "swiftc";
    }
    @Override public String getDescription(){
      return "SwiftC";
    }
  }
;
  public SwiftcMetadataProvider(  ExecActionFactory execActionFactory){
    super(execActionFactory);
  }
  @Override protected List<String> compilerArgs(){
    return ImmutableList.of("--version");
  }
  @Override protected SwiftcMetadata brokenMetadata(  String message){
    return new BrokenMetadata(message);
  }
  @Override public CompilerType getCompilerType(){
    return SWIFTC_COMPILER_TYPE;
  }
  @Override protected SwiftcMetadata parseCompilerOutput(  String stdout,  String stderr,  File swiftc){
    BufferedReader reader=new BufferedReader(new StringReader(stdout));
    try {
      String line;
      while ((line=reader.readLine()) != null) {
        if (line.contains("Swift version")) {
          String[] tokens=line.split(" ");
          int i=2;
          if ("Apple".equals(tokens[0])) {
            i++;
          }
          VersionNumber version=VersionNumber.parse(tokens[i]);
          return new DefaultSwiftcMetadata(line,version);
        }
      }
      return new BrokenMetadata(String.format("Could not determine %s metadata: %s produced unexpected output.",getCompilerType().getDescription(),swiftc.getName()));
    }
 catch (    IOException e) {
      throw new UncheckedIOException(e);
    }
  }
private class BrokenMetadata extends AbstractBrokenMetadata implements SwiftcMetadata {
    public BrokenMetadata(    String message){
      super(message);
    }
  }
private class DefaultSwiftcMetadata implements SwiftcMetadata {
    private final String versionString;
    private final VersionNumber version;
    public DefaultSwiftcMetadata(    String versionString,    VersionNumber version){
      this.versionString=versionString;
      this.version=version;
    }
    public String getVendor(){
      return versionString;
    }
    @Override public VersionNumber getVersion(){
      return version;
    }
    @Override public boolean isAvailable(){
      return true;
    }
    @Override public void explain(    TreeVisitor<? super String> visitor){
    }
  }
}
