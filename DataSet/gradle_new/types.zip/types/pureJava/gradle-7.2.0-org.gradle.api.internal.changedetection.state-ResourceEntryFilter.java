/** 
 * A resource entry filter supporting exact matches of values.
 */
public interface ResourceEntryFilter extends ConfigurableNormalizer {
  ResourceEntryFilter FILTER_NOTHING=new ResourceEntryFilter(){
    @Override public boolean shouldBeIgnored(    String entry){
      return false;
    }
    @Override public void appendConfigurationToHasher(    Hasher hasher){
      hasher.putString(getClass().getName());
    }
  }
;
  boolean shouldBeIgnored(  String entry);
}
