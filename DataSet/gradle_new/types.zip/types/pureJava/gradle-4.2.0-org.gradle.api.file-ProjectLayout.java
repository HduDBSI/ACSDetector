/** 
 * Provides access to several important locations for a project. An instance of the factory can be injected into a task or plugin by annotating a public constructor or method with  {@code javax.inject.Inject}. It is also available via  {@link org.gradle.api.Project#getLayout()}.
 * @since 4.1
 */
@Incubating public interface ProjectLayout {
  /** 
 * Returns the project directory.
 */
  Directory getProjectDirectory();
  /** 
 * Returns the build directory for the project.
 */
  DirectoryVar getBuildDirectory();
  /** 
 * Creates a new  {@link DirectoryVar} that uses the project directory to resolve paths, if required. The var has no initial value.
 */
  DirectoryVar newDirectoryVar();
  /** 
 * Creates a new  {@link RegularFileVar} that uses the project directory to resolve paths, if required. The var has no initial value.
 */
  RegularFileVar newFileVar();
  /** 
 * Creates a  {@link RegularFile} implementation whose location is calculated from the given {@link Provider}.
 */
  Provider<RegularFile> file(  Provider<File> file);
}
