public class WorkerDaemonServer implements WorkerProtocol {
  private final ServiceRegistry serviceRegistry;
  private Worker isolatedClassloaderWorker;
  @Inject public WorkerDaemonServer(  ServiceRegistry parent,  RequestArgumentSerializers argumentSerializers){
    this.serviceRegistry=createWorkerDaemonServices(parent);
    argumentSerializers.add(WorkerDaemonMessageSerializer.create());
  }
  static ServiceRegistry createWorkerDaemonServices(  ServiceRegistry parent){
    ServiceRegistry workerSharedGlobalServices=ServiceRegistryBuilder.builder().parent(parent).provider(new WorkerSharedGlobalScopeServices()).build();
    return new WorkerDaemonServices(workerSharedGlobalServices);
  }
  @Override public DefaultWorkResult execute(  ActionExecutionSpec spec){
    try {
      SerializedActionExecutionSpec classloaderActionExecutionSpec=(SerializedActionExecutionSpec)spec;
      Worker worker=getIsolatedClassloaderWorker(classloaderActionExecutionSpec.getClassLoaderStructure());
      return worker.execute(classloaderActionExecutionSpec);
    }
 catch (    Throwable t) {
      return new DefaultWorkResult(true,t);
    }
  }
  private Worker getIsolatedClassloaderWorker(  ClassLoaderStructure classLoaderStructure){
    if (isolatedClassloaderWorker == null) {
      if (classLoaderStructure instanceof FlatClassLoaderStructure) {
        isolatedClassloaderWorker=new FlatClassLoaderWorker(this.getClass().getClassLoader(),serviceRegistry);
      }
 else {
        isolatedClassloaderWorker=new IsolatedClassloaderWorker(classLoaderStructure,this.getClass().getClassLoader(),serviceRegistry,true);
      }
    }
    return isolatedClassloaderWorker;
  }
  @Override public String toString(){
    return "WorkerDaemonServer{}";
  }
private static class WorkerDaemonServices extends DefaultServiceRegistry {
    public WorkerDaemonServices(    ServiceRegistry... parents){
      super("WorkerDaemonServices",parents);
    }
    InstantiatorFactory createInstantiatorFactory(    CrossBuildInMemoryCacheFactory cacheFactory){
      return new DefaultInstantiatorFactory(cacheFactory,Collections.<InjectAnnotationHandler>emptyList());
    }
    WorkerDaemonServices createWorkerDaemonServices(){
      return this;
    }
  }
}
