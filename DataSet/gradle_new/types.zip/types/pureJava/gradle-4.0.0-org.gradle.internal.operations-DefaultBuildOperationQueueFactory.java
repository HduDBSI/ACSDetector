public class DefaultBuildOperationQueueFactory implements BuildOperationQueueFactory {
  private final WorkerLeaseService workerLeaseService;
  public DefaultBuildOperationQueueFactory(  WorkerLeaseService workerLeaseService){
    this.workerLeaseService=workerLeaseService;
  }
  @Override public <T extends BuildOperation>BuildOperationQueue<T> create(  StoppableExecutor executor,  BuildOperationQueue.QueueWorker<T> worker){
    return new DefaultBuildOperationQueue<T>(workerLeaseService,executor,worker);
  }
}
