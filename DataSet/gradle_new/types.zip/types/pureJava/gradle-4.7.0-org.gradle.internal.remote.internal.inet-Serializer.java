private static class Serializer implements org.gradle.internal.serialize.Serializer<SocketInetAddress> {
  @Override public SocketInetAddress read(  Decoder decoder) throws Exception {
    return new SocketInetAddress(readAddress(decoder),decoder.readInt());
  }
  private InetAddress readAddress(  Decoder decoder) throws IOException {
    return InetAddress.getByAddress(decoder.readBinary());
  }
  @Override public void write(  Encoder encoder,  SocketInetAddress address) throws Exception {
    writeAddress(encoder,address);
    encoder.writeInt(address.port);
  }
  private void writeAddress(  Encoder encoder,  SocketInetAddress address) throws IOException {
    encoder.writeBinary(address.address.getAddress());
  }
}
