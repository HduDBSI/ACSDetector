/** 
 * Hashes contents of resources files and  {@link ZipEntry}s) in runtime classpath entries. Currently, we take the unmodified content into account but we could be smarter at some point.
 */
public class RuntimeClasspathResourceHasher implements ResourceHasher {
  @Nullable @Override public HashCode hash(  PhysicalFileSnapshot fileSnapshot){
    return fileSnapshot.getHash();
  }
  @Override public HashCode hash(  ZipEntry zipEntry,  InputStream zipInput) throws IOException {
    HashingOutputStream hasher=new HashingOutputStream(Hashing.md5(),NullOutputStream.INSTANCE);
    ByteStreams.copy(zipInput,hasher);
    return hasher.hash();
  }
  @Override public void appendConfigurationToHasher(  BuildCacheHasher hasher){
    hasher.putString(getClass().getName());
  }
}
