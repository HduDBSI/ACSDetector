/** 
 * Configuration object for a build cache.
 * @since 3.5
 */
@Incubating public interface BuildCache {
  /** 
 * Returns whether the build cache is enabled.
 */
  boolean isEnabled();
  /** 
 * Enables or disables the build cache service.
 */
  void setEnabled(  boolean enabled);
  /** 
 * Returns whether pushing to the build cache is enabled.
 */
  boolean isPush();
  /** 
 * Sets whether pushing to the build cache is enabled.
 */
  void setPush(  boolean enabled);
}
