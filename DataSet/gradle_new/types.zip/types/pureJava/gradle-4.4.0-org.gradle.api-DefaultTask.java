/** 
 * {@code DefaultTask} is the standard {@link Task} implementation. You can extend this to implement your own task types.
 */
@NoConventionMapping public class DefaultTask extends AbstractTask {
  /** 
 * Creates a new output directory property for this task.
 * @return The property.
 * @since 4.4
 */
  @Incubating protected DirectoryProperty newOutputDirectory(){
    return getServices().get(TaskFileVarFactory.class).newOutputDirectory(this);
  }
  /** 
 * Creates a new output file property for this task.
 * @return The property.
 * @since 4.4
 */
  @Incubating protected RegularFileProperty newOutputFile(){
    return getServices().get(TaskFileVarFactory.class).newOutputFile(this);
  }
  /** 
 * Creates a new input file property for this task.
 * @return The property.
 * @since 4.4
 */
  @Incubating protected RegularFileProperty newInputFile(){
    return getServices().get(TaskFileVarFactory.class).newInputFile(this);
  }
  /** 
 * Creates a new input directory property for this task.
 * @return The property.
 * @since 4.4
 */
  @Incubating protected DirectoryProperty newInputDirectory(){
    return getServices().get(TaskFileVarFactory.class).newInputDirectory(this);
  }
}
