/** 
 * Marker interface for types that are runtime generated subclasses by  {@link ClassGenerator}
 */
public interface GeneratedSubclass {
  Class<?> publicType();
}
