/** 
 * Base test suite functionality. Makes an extension named "testing" available to the project.
 * @since 7.3
 */
@Incubating public class TestSuiteBasePlugin implements Plugin<Project> {
  @Override public void apply(  Project project){
    project.getExtensions().create(TestingExtension.class,"testing",DefaultTestingExtension.class);
  }
}
