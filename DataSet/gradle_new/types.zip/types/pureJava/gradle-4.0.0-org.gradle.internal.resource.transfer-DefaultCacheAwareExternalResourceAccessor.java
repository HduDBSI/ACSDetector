public class DefaultCacheAwareExternalResourceAccessor implements CacheAwareExternalResourceAccessor {
  private static final Logger LOGGER=LoggerFactory.getLogger(DefaultCacheAwareExternalResourceAccessor.class);
  private final ExternalResourceRepository delegate;
  private final CachedExternalResourceIndex<String> cachedExternalResourceIndex;
  private final BuildCommencedTimeProvider timeProvider;
  private final TemporaryFileProvider temporaryFileProvider;
  private final CacheLockingManager cacheLockingManager;
  private final ExternalResourceCachePolicy externalResourceCachePolicy;
  private final ProducerGuard<ExternalResourceName> producerGuard;
  private final FileResourceRepository fileResourceRepository;
  public DefaultCacheAwareExternalResourceAccessor(  ExternalResourceRepository delegate,  CachedExternalResourceIndex<String> cachedExternalResourceIndex,  BuildCommencedTimeProvider timeProvider,  TemporaryFileProvider temporaryFileProvider,  CacheLockingManager cacheLockingManager,  ExternalResourceCachePolicy externalResourceCachePolicy,  ProducerGuard<ExternalResourceName> producerGuard,  FileResourceRepository fileResourceRepository){
    this.delegate=delegate;
    this.cachedExternalResourceIndex=cachedExternalResourceIndex;
    this.timeProvider=timeProvider;
    this.temporaryFileProvider=temporaryFileProvider;
    this.cacheLockingManager=cacheLockingManager;
    this.externalResourceCachePolicy=externalResourceCachePolicy;
    this.producerGuard=producerGuard;
    this.fileResourceRepository=fileResourceRepository;
  }
  public LocallyAvailableExternalResource getResource(  final ExternalResourceName location,  final ResourceFileStore fileStore,  @Nullable final LocallyAvailableResourceCandidates additionalCandidates) throws IOException {
    return producerGuard.guardByKey(location,new Factory<LocallyAvailableExternalResource>(){
      @Override public LocallyAvailableExternalResource create(){
        LOGGER.debug("Constructing external resource: {}",location);
        CachedExternalResource cached=cachedExternalResourceIndex.lookup(location.toString());
        if (cached == null && (additionalCandidates == null || additionalCandidates.isNone())) {
          return copyToCache(location,fileStore,delegate.withProgressLogging().resource(location));
        }
        if (cached != null && !externalResourceCachePolicy.mustRefreshExternalResource(getAgeMillis(timeProvider,cached))) {
          return fileResourceRepository.resource(cached.getCachedFile(),location.getUri(),cached.getExternalResourceMetaData());
        }
        final boolean revalidate=true;
        final ExternalResourceMetaData remoteMetaData=delegate.resource(location,revalidate).getMetaData();
        if (remoteMetaData == null) {
          return null;
        }
        if (cached != null) {
          boolean isUnchanged=ExternalResourceMetaDataCompare.isDefinitelyUnchanged(cached.getExternalResourceMetaData(),new Factory<ExternalResourceMetaData>(){
            public ExternalResourceMetaData create(){
              return remoteMetaData;
            }
          }
);
          if (isUnchanged) {
            LOGGER.info("Cached resource {} is up-to-date (lastModified: {}).",location,cached.getExternalLastModified());
            return fileResourceRepository.resource(cached.getCachedFile(),location.getUri(),cached.getExternalResourceMetaData());
          }
        }
        boolean hasLocalCandidates=additionalCandidates != null && !additionalCandidates.isNone();
        if (hasLocalCandidates) {
          HashValue remoteChecksum=remoteMetaData.getSha1();
          if (remoteChecksum == null) {
            remoteChecksum=getResourceSha1(location,revalidate);
          }
          if (remoteChecksum != null) {
            LocallyAvailableResource local=additionalCandidates.findByHashValue(remoteChecksum);
            if (local != null) {
              LOGGER.info("Found locally available resource with matching checksum: [{}, {}]",location,local.getFile());
              LocallyAvailableExternalResource resource;
              try {
                resource=copyCandidateToCache(location,fileStore,remoteMetaData,remoteChecksum,local);
              }
 catch (              IOException e) {
                throw new UncheckedIOException(e);
              }
              if (resource != null) {
                return resource;
              }
            }
          }
        }
        return copyToCache(location,fileStore,delegate.withProgressLogging().resource(location,revalidate));
      }
    }
);
  }
  private HashValue getResourceSha1(  ExternalResourceName location,  boolean revalidate){
    try {
      ExternalResourceName sha1Location=location.append(".sha1");
      ExternalResource resource=delegate.resource(sha1Location,revalidate);
      ExternalResourceReadResult<HashValue> result=resource.withContentIfPresent(new Transformer<HashValue,InputStream>(){
        @Override public HashValue transform(        InputStream inputStream){
          try {
            String sha=IOUtils.toString(inputStream,"us-ascii");
            return HashValue.parse(sha);
          }
 catch (          IOException e) {
            throw new UncheckedIOException(e);
          }
        }
      }
);
      return result == null ? null : result.getResult();
    }
 catch (    Exception e) {
      throw new ResourceException(location.getUri(),String.format("Failed to download SHA1 for resource '%s'.",location),e);
    }
  }
  private LocallyAvailableExternalResource copyCandidateToCache(  ExternalResourceName source,  ResourceFileStore fileStore,  ExternalResourceMetaData remoteMetaData,  HashValue remoteChecksum,  LocallyAvailableResource local) throws IOException {
    final File destination=temporaryFileProvider.createTemporaryFile("gradle_download","bin");
    try {
      Files.copy(local.getFile(),destination);
      HashValue localChecksum=HashUtil.createHash(destination,"SHA1");
      if (!localChecksum.equals(remoteChecksum)) {
        return null;
      }
      return moveIntoCache(source,destination,fileStore,remoteMetaData);
    }
  finally {
      destination.delete();
    }
  }
  private LocallyAvailableExternalResource copyToCache(  final ExternalResourceName source,  final ResourceFileStore fileStore,  final ExternalResource resource){
    DownloadAction downloadAction=new DownloadAction(source);
    try {
      resource.withContentIfPresent(downloadAction);
    }
 catch (    Exception e) {
      throw ResourceExceptions.getFailed(source.getUri(),e);
    }
    if (downloadAction.metaData == null) {
      return null;
    }
    try {
      return moveIntoCache(source,downloadAction.destination,fileStore,downloadAction.metaData);
    }
  finally {
      downloadAction.destination.delete();
    }
  }
  private LocallyAvailableExternalResource moveIntoCache(  final ExternalResourceName source,  final File destination,  final ResourceFileStore fileStore,  final ExternalResourceMetaData metaData){
    return cacheLockingManager.useCache(new Factory<LocallyAvailableExternalResource>(){
      public LocallyAvailableExternalResource create(){
        LocallyAvailableResource cachedResource=fileStore.moveIntoCache(destination);
        File fileInFileStore=cachedResource.getFile();
        cachedExternalResourceIndex.store(source.toString(),fileInFileStore,metaData);
        return fileResourceRepository.resource(fileInFileStore,source.getUri(),metaData);
      }
    }
);
  }
  public long getAgeMillis(  BuildCommencedTimeProvider timeProvider,  CachedExternalResource cached){
    return timeProvider.getCurrentTime() - cached.getCachedAt();
  }
private class DownloadAction implements ExternalResource.ContentAction<Object> {
    private final ExternalResourceName source;
    File destination;
    ExternalResourceMetaData metaData;
    DownloadAction(    ExternalResourceName source){
      this.source=source;
    }
    @Override public Object execute(    InputStream inputStream,    ExternalResourceMetaData metaData) throws IOException {
      destination=temporaryFileProvider.createTemporaryFile("gradle_download","bin");
      this.metaData=metaData;
      LOGGER.debug("Downloading {} to {}",source,destination);
      if (destination.getParentFile() != null) {
        GFileUtils.mkdirs(destination.getParentFile());
      }
      FileOutputStream outputStream=new FileOutputStream(destination);
      try {
        IOUtils.copyLarge(inputStream,outputStream);
      }
  finally {
        outputStream.close();
      }
      return null;
    }
  }
}
