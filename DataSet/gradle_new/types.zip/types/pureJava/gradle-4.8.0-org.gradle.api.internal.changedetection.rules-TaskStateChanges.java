public interface TaskStateChanges extends Iterable<TaskStateChange> {
}
