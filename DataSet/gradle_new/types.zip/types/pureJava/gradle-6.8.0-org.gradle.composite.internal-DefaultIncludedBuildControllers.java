class DefaultIncludedBuildControllers implements Stoppable, IncludedBuildControllers {
  private final Map<BuildIdentifier,IncludedBuildController> buildControllers=new HashMap<>();
  private final ManagedExecutor executorService;
  private final ResourceLockCoordinationService coordinationService;
  private final ProjectStateRegistry projectStateRegistry;
  private final BuildStateRegistry buildRegistry;
  private BuildOperationRef rootBuildOperation;
  DefaultIncludedBuildControllers(  ExecutorFactory executorFactory,  BuildStateRegistry buildRegistry,  ResourceLockCoordinationService coordinationService,  ProjectStateRegistry projectStateRegistry){
    this.buildRegistry=buildRegistry;
    this.executorService=executorFactory.create("included builds");
    this.coordinationService=coordinationService;
    this.projectStateRegistry=projectStateRegistry;
  }
  @Override public void rootBuildOperationStarted(){
    rootBuildOperation=CurrentBuildOperationRef.instance().get();
  }
  @Override public IncludedBuildController getBuildController(  BuildIdentifier buildId){
    IncludedBuildController buildController=buildControllers.get(buildId);
    if (buildController != null) {
      return buildController;
    }
    IncludedBuildState build=buildRegistry.getIncludedBuild(buildId);
    DefaultIncludedBuildController newBuildController=new DefaultIncludedBuildController(build,coordinationService,projectStateRegistry);
    buildControllers.put(buildId,newBuildController);
    executorService.submit(new BuildOpRunnable(newBuildController,rootBuildOperation));
    return newBuildController;
  }
  @Override public void startTaskExecution(){
    for (    IncludedBuildController buildController : buildControllers.values()) {
      buildController.startTaskExecution();
    }
  }
  @Override public void populateTaskGraphs(){
    boolean tasksDiscovered=true;
    while (tasksDiscovered) {
      tasksDiscovered=false;
      for (      IncludedBuildController buildController : ImmutableList.copyOf(buildControllers.values())) {
        if (buildController.populateTaskGraph()) {
          tasksDiscovered=true;
        }
      }
    }
  }
  @Override public void awaitTaskCompletion(  Collection<? super Throwable> taskFailures){
    for (    IncludedBuildController buildController : buildControllers.values()) {
      buildController.awaitTaskCompletion(taskFailures);
    }
  }
  @Override public void finishBuild(  Collection<? super Throwable> failures){
    CompositeStoppable.stoppable(buildControllers.values()).stop();
    buildControllers.clear();
    for (    IncludedBuildState includedBuild : buildRegistry.getIncludedBuilds()) {
      try {
        includedBuild.finishBuild();
      }
 catch (      Exception e) {
        failures.add(e);
      }
    }
  }
  @Override public void stop(){
    CompositeStoppable.stoppable(buildControllers.values()).stop();
    executorService.stop();
  }
private static class BuildOpRunnable implements Runnable {
    private final DefaultIncludedBuildController newBuildController;
    private final BuildOperationRef rootBuildOperation;
    BuildOpRunnable(    DefaultIncludedBuildController newBuildController,    BuildOperationRef rootBuildOperation){
      this.newBuildController=newBuildController;
      this.rootBuildOperation=rootBuildOperation;
    }
    @Override public void run(){
      CurrentBuildOperationRef.instance().set(rootBuildOperation);
      try {
        newBuildController.run();
      }
  finally {
        CurrentBuildOperationRef.instance().set(null);
      }
    }
  }
}
