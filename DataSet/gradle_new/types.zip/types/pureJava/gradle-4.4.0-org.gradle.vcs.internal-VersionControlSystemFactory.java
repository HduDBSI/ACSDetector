public interface VersionControlSystemFactory {
  VersionControlSystem create(  VersionControlSpec spec);
}
