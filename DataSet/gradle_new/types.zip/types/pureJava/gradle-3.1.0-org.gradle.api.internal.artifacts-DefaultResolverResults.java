public class DefaultResolverResults implements ResolverResults {
  private ResolvedConfiguration resolvedConfiguration;
  private ResolutionResult resolutionResult;
  private ResolveException fatalFailure;
  private ResolvedLocalComponentsResult resolvedLocalComponentsResult;
  private TransientConfigurationResultsBuilder transientConfigurationResultsBuilder;
  private ResolvedGraphResults graphResults;
  private ResolvedArtifactsBuilder artifactResults;
  @Override public boolean hasError(){
    if (fatalFailure != null) {
      return true;
    }
    if (resolvedConfiguration != null && resolvedConfiguration.hasError()) {
      return true;
    }
    return false;
  }
  @Override public ResolvedConfiguration getResolvedConfiguration(){
    assertHasArtifacts();
    return resolvedConfiguration;
  }
  @Override public ResolutionResult getResolutionResult(){
    assertHasResult();
    if (fatalFailure != null) {
      throw fatalFailure;
    }
    return resolutionResult;
  }
  @Override public ResolvedLocalComponentsResult getResolvedLocalComponents(){
    assertHasResult();
    if (fatalFailure != null) {
      throw fatalFailure;
    }
    return resolvedLocalComponentsResult;
  }
  private void assertHasResult(){
    if (resolutionResult == null && fatalFailure == null) {
      throw new IllegalStateException("Resolution result has not been attached.");
    }
  }
  private void assertHasArtifacts(){
    if (resolvedConfiguration == null) {
      throw new IllegalStateException("Resolution artifacts have not been attached.");
    }
  }
  @Override public void resolved(  ResolutionResult resolutionResult,  ResolvedLocalComponentsResult resolvedLocalComponentsResult){
    this.resolutionResult=resolutionResult;
    this.resolvedLocalComponentsResult=resolvedLocalComponentsResult;
    this.fatalFailure=null;
  }
  @Override public void failed(  ResolveException failure){
    this.resolutionResult=null;
    this.fatalFailure=failure;
  }
  @Override public void withResolvedConfiguration(  ResolvedConfiguration resolvedConfiguration){
    this.resolvedConfiguration=resolvedConfiguration;
    this.graphResults=null;
    this.transientConfigurationResultsBuilder=null;
    this.artifactResults=null;
  }
  public void retainState(  ResolvedGraphResults graphResults,  ResolvedArtifactsBuilder artifactResults,  TransientConfigurationResultsBuilder transientConfigurationResultsBuilder){
    this.graphResults=graphResults;
    this.artifactResults=artifactResults;
    this.transientConfigurationResultsBuilder=transientConfigurationResultsBuilder;
  }
  public ResolvedGraphResults getGraphResults(){
    return graphResults;
  }
  public ResolvedArtifactResults getResolvedArtifacts(){
    return artifactResults.resolve();
  }
  public TransientConfigurationResultsBuilder getTransientConfigurationResultsBuilder(){
    return transientConfigurationResultsBuilder;
  }
}
