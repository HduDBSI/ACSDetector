/** 
 * Transformed artifact set that performs the transformation itself when visited.
 */
public abstract class AbstractTransformedArtifactSet implements ResolvedArtifactSet, FileCollectionInternal.Source {
  private final CalculatedValueContainer<ImmutableList<ResolvedArtifactSet.Artifacts>,CalculateArtifacts> result;
  public AbstractTransformedArtifactSet(  ComponentIdentifier componentIdentifier,  ResolvedArtifactSet delegate,  ImmutableAttributes targetVariantAttributes,  Transformation transformation,  ExtraExecutionGraphDependenciesResolverFactory dependenciesResolverFactory,  CalculatedValueContainerFactory calculatedValueContainerFactory){
    TransformUpstreamDependenciesResolver dependenciesResolver=dependenciesResolverFactory.create(componentIdentifier,transformation);
    ImmutableList.Builder<BoundTransformationStep> builder=ImmutableList.builder();
    transformation.visitTransformationSteps(transformationStep -> builder.add(new BoundTransformationStep(transformationStep,dependenciesResolver.dependenciesFor(transformationStep))));
    ImmutableList<BoundTransformationStep> steps=builder.build();
    this.result=calculatedValueContainerFactory.create(Describables.of(componentIdentifier),new CalculateArtifacts(componentIdentifier,delegate,targetVariantAttributes,steps));
  }
  public AbstractTransformedArtifactSet(  CalculatedValueContainer<ImmutableList<ResolvedArtifactSet.Artifacts>,CalculateArtifacts> result){
    this.result=result;
  }
  public CalculatedValueContainer<ImmutableList<Artifacts>,CalculateArtifacts> getResult(){
    return result;
  }
  @Override public void visit(  Visitor visitor){
    FileCollectionStructureVisitor.VisitType visitType=visitor.prepareForVisit(this);
    if (visitType == FileCollectionStructureVisitor.VisitType.NoContents) {
      visitor.visitArtifacts(new EndCollection(this));
      return;
    }
    result.finalizeIfNotAlready();
    for (    Artifacts artifacts : result.get()) {
      visitor.visitArtifacts(artifacts);
    }
    visitor.visitArtifacts(new EndCollection(this));
  }
  @Override public void visitDependencies(  TaskDependencyResolveContext context){
    result.visitDependencies(context);
  }
  @Override public void visitLocalArtifacts(  LocalArtifactVisitor visitor){
    throw new IllegalStateException();
  }
  @Override public void visitExternalArtifacts(  Action<ResolvableArtifact> visitor){
    throw new IllegalStateException();
  }
public static class CalculateArtifacts implements ValueCalculator<ImmutableList<Artifacts>> {
    private final ComponentIdentifier ownerId;
    private final ResolvedArtifactSet delegate;
    private final ImmutableList<BoundTransformationStep> steps;
    private final ImmutableAttributes targetVariantAttributes;
    public CalculateArtifacts(    ComponentIdentifier ownerId,    ResolvedArtifactSet delegate,    ImmutableAttributes targetVariantAttributes,    ImmutableList<BoundTransformationStep> steps){
      this.ownerId=ownerId;
      this.delegate=delegate;
      this.steps=steps;
      this.targetVariantAttributes=targetVariantAttributes;
    }
    public ComponentIdentifier getOwnerId(){
      return ownerId;
    }
    public ResolvedArtifactSet getDelegate(){
      return delegate;
    }
    public ImmutableList<BoundTransformationStep> getSteps(){
      return steps;
    }
    public ImmutableAttributes getTargetVariantAttributes(){
      return targetVariantAttributes;
    }
    @Override public boolean usesMutableProjectState(){
      return false;
    }
    @Override public ProjectInternal getOwningProject(){
      return null;
    }
    @Override public void visitDependencies(    TaskDependencyResolveContext context){
      for (      BoundTransformationStep step : steps) {
        context.add(step.getUpstreamDependencies());
      }
    }
    @Override public ImmutableList<Artifacts> calculateValue(    NodeExecutionContext context){
      for (      BoundTransformationStep step : steps) {
        step.getTransformation().isolateParametersIfNotAlready();
        step.getUpstreamDependencies().finalizeIfNotAlready();
      }
      ImmutableList.Builder<Artifacts> builder=ImmutableList.builderWithExpectedSize(1);
      delegate.visit(new TransformingAsyncArtifactListener(steps,targetVariantAttributes,builder));
      return builder.build();
    }
  }
}
