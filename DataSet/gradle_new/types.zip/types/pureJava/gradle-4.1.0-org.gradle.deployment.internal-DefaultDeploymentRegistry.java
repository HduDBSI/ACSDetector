public class DefaultDeploymentRegistry implements DeploymentRegistry {
  private static final Logger LOGGER=Logging.getLogger(DefaultDeploymentRegistry.class);
  private final Lock lock=new ReentrantLock();
  private final Map<String,DeploymentHandle> handles=Maps.newHashMap();
  private boolean stopped;
  @Override public void register(  String id,  DeploymentHandle handle){
    lock.lock();
    try {
      failIfStopped();
      if (!handles.containsKey(id)) {
        handles.put(id,handle);
      }
 else {
        throw new IllegalStateException("A deployment with id '" + id + "' is already registered.");
      }
    }
  finally {
      lock.unlock();
    }
  }
  @Override public <T extends DeploymentHandle>T get(  Class<T> handleType,  String id){
    lock.lock();
    try {
      failIfStopped();
      return Cast.cast(handleType,handles.get(id));
    }
  finally {
      lock.unlock();
    }
  }
  @Override public void onNewBuild(  Gradle gradle){
    lock.lock();
    try {
      for (      DeploymentHandle handle : handles.values()) {
        handle.onNewBuild(gradle);
      }
    }
  finally {
      lock.unlock();
    }
  }
  @Override public void stop(){
    lock.lock();
    try {
      LOGGER.debug("Stopping {} deployment handles",handles.size());
      CompositeStoppable.stoppable(handles.values()).stop();
    }
  finally {
      LOGGER.debug("Stopped deployment handles");
      stopped=true;
      handles.clear();
      lock.unlock();
    }
  }
  private void failIfStopped(){
    if (stopped) {
      throw new IllegalStateException("Cannot modify deployment handles once the registry has been stopped.");
    }
  }
}
