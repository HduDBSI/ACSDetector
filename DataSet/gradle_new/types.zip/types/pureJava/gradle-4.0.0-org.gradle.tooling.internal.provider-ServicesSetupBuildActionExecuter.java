public class ServicesSetupBuildActionExecuter implements BuildExecuter {
  private final BuildActionExecuter<BuildActionParameters> delegate;
  private final GradleUserHomeScopeServiceRegistry userHomeServiceRegistry;
  public ServicesSetupBuildActionExecuter(  BuildActionExecuter<BuildActionParameters> delegate,  GradleUserHomeScopeServiceRegistry userHomeServiceRegistry){
    this.delegate=delegate;
    this.userHomeServiceRegistry=userHomeServiceRegistry;
  }
  @Override public Object execute(  BuildAction action,  BuildRequestContext requestContext,  BuildActionParameters actionParameters,  ServiceRegistry contextServices){
    StartParameter startParameter=action.getStartParameter();
    ServiceRegistry userHomeServices=userHomeServiceRegistry.getServicesFor(startParameter.getGradleUserHomeDir());
    try {
      ServiceRegistry buildSessionScopeServices=new BuildSessionScopeServices(userHomeServices,startParameter,actionParameters.getInjectedPluginClasspath());
      try {
        SessionLifecycleListener sessionLifecycleListener=buildSessionScopeServices.get(ListenerManager.class).getBroadcaster(SessionLifecycleListener.class);
        try {
          sessionLifecycleListener.afterStart();
          return delegate.execute(action,requestContext,actionParameters,buildSessionScopeServices);
        }
  finally {
          sessionLifecycleListener.beforeComplete();
        }
      }
  finally {
        CompositeStoppable.stoppable(buildSessionScopeServices).stop();
      }
    }
  finally {
      userHomeServiceRegistry.release(userHomeServices);
    }
  }
}
