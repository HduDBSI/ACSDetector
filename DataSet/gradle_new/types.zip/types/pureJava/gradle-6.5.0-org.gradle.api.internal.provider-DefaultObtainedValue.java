private static class DefaultObtainedValue<T,P extends ValueSourceParameters> implements Listener.ObtainedValue<T,P> {
  private final Try<T> value;
  private final Class<? extends ValueSource<T,P>> valueSourceType;
  private final Class<P> parametersType;
  @Nullable private final P parameters;
  public DefaultObtainedValue(  Try<T> value,  Class<? extends ValueSource<T,P>> valueSourceType,  Class<P> parametersType,  @Nullable P parameters){
    this.value=value;
    this.valueSourceType=valueSourceType;
    this.parametersType=parametersType;
    this.parameters=parameters;
  }
  @Override public Try<T> getValue(){
    return value;
  }
  @Override public Class<? extends ValueSource<T,P>> getValueSourceType(){
    return valueSourceType;
  }
  @Override public Class<P> getValueSourceParametersType(){
    return parametersType;
  }
  @Override public P getValueSourceParameters(){
    return parameters;
  }
}
