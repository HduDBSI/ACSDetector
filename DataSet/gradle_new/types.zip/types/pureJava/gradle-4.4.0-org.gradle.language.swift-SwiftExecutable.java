/** 
 * An executable built from Swift source.
 * @since 4.2
 */
@Incubating public interface SwiftExecutable extends SwiftBinary {
  /** 
 * Returns the executable file for this binary.
 * @since 4.4
 */
  Provider<RegularFile> getExecutableFile();
  /** 
 * Returns the installation directory for this binary.
 * @since 4.4
 */
  Provider<Directory> getInstallDirectory();
  /** 
 * Returns the script for running this binary.
 * @since 4.4
 */
  Provider<RegularFile> getRunScriptFile();
}
