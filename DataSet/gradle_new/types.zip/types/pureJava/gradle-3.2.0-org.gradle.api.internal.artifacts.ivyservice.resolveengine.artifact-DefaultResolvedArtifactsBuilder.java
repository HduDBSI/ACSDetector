/** 
 * Collects all artifacts.
 */
public class DefaultResolvedArtifactsBuilder implements ResolvedArtifactsBuilder {
  private final DefaultResolvedArtifactResults artifactResults=new DefaultResolvedArtifactResults();
  @Override public void visitArtifacts(  DependencyGraphNode parent,  DependencyGraphNode child,  ArtifactSet artifacts){
    artifactResults.addArtifactSet(artifacts);
  }
  @Override public void finishArtifacts(){
  }
  @Override public ResolvedArtifactResults resolve(){
    artifactResults.resolveNow();
    return artifactResults;
  }
}
