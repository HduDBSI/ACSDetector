public class CompositeDependencyArtifactsVisitor implements ValidatingArtifactsVisitor {
  private final List<DependencyArtifactsVisitor> visitors;
  public CompositeDependencyArtifactsVisitor(  List<DependencyArtifactsVisitor> visitors){
    this.visitors=ImmutableList.copyOf(visitors);
  }
  @Override public void startArtifacts(  RootGraphNode root){
    for (    DependencyArtifactsVisitor visitor : visitors) {
      visitor.startArtifacts(root);
    }
  }
  @Override public void visitNode(  DependencyGraphNode node){
    for (    DependencyArtifactsVisitor visitor : visitors) {
      visitor.visitNode(node);
    }
  }
  @Override public void visitArtifacts(  DependencyGraphNode from,  LocalFileDependencyMetadata fileDependency,  int artifactSetId,  ArtifactSet artifactSet){
    for (    DependencyArtifactsVisitor visitor : visitors) {
      visitor.visitArtifacts(from,fileDependency,artifactSetId,artifactSet);
    }
  }
  @Override public void visitArtifacts(  DependencyGraphNode from,  DependencyGraphNode to,  int artifactSetId,  ArtifactSet artifacts){
    for (    DependencyArtifactsVisitor visitor : visitors) {
      visitor.visitArtifacts(from,to,artifactSetId,artifacts);
    }
  }
  @Override public void finishArtifacts(){
    for (    DependencyArtifactsVisitor visitor : visitors) {
      visitor.finishArtifacts();
    }
  }
  @Override public void complete(){
    for (    DependencyArtifactsVisitor visitor : visitors) {
      if (visitor instanceof ValidatingArtifactsVisitor) {
        ((ValidatingArtifactsVisitor)visitor).complete();
      }
    }
  }
}
