@Contextual private static class WorkExecutionException extends RuntimeException {
  WorkExecutionException(  String description){
    super(toMessage(description));
  }
  WorkExecutionException(  String description,  Throwable cause){
    super(toMessage(description),cause);
  }
  private static String toMessage(  String description){
    return "A failure occurred while executing " + description;
  }
}
