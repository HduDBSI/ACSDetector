static class StreamByteBufferChunk {
  private int pointer;
  private byte[] buffer;
  private int size;
  private int used;
  public StreamByteBufferChunk(  int size){
    this.size=size;
    buffer=new byte[size];
  }
  public StreamByteBufferChunk(  byte[] buf){
    this.size=buf.length;
    this.buffer=buf;
    this.used=buf.length;
  }
  public ByteBuffer readToNioBuffer(){
    if (pointer < used) {
      ByteBuffer result;
      if (pointer > 0 || used < size) {
        result=ByteBuffer.wrap(buffer,pointer,used - pointer);
      }
 else {
        result=ByteBuffer.wrap(buffer);
      }
      pointer=used;
      return result;
    }
    return null;
  }
  public boolean write(  byte b){
    if (used < size) {
      buffer[used++]=b;
      return true;
    }
    return false;
  }
  public void write(  byte[] b,  int off,  int len){
    System.arraycopy(b,off,buffer,used,len);
    used=used + len;
  }
  public void read(  byte[] b,  int off,  int len){
    System.arraycopy(buffer,pointer,b,off,len);
    pointer=pointer + len;
  }
  public void writeTo(  OutputStream target) throws IOException {
    if (pointer < used) {
      target.write(buffer,pointer,used - pointer);
      pointer=used;
    }
  }
  public void reset(){
    pointer=0;
  }
  public int bytesUsed(){
    return used;
  }
  public int bytesUnread(){
    return used - pointer;
  }
  public int read(){
    if (pointer < used) {
      return buffer[pointer++] & 0xff;
    }
    return -1;
  }
  public int spaceLeft(){
    return size - used;
  }
  public int readFrom(  InputStream inputStream,  int len) throws IOException {
    int readBytes=inputStream.read(buffer,used,len);
    if (readBytes > 0) {
      used+=readBytes;
    }
    return readBytes;
  }
  public void clear(){
    used=pointer=0;
  }
  public byte[] readBuffer(){
    if (used == buffer.length && pointer == 0) {
      pointer=used;
      return buffer;
    }
 else     if (pointer < used) {
      byte[] buf=new byte[used - pointer];
      read(buf,0,used - pointer);
      return buf;
    }
 else {
      return new byte[0];
    }
  }
}
