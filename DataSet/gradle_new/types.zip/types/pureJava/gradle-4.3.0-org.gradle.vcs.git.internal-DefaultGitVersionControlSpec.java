public class DefaultGitVersionControlSpec implements GitVersionControlSpec {
  private URI url;
  @Override public URI getUrl(){
    return url;
  }
  @Override public void setUrl(  URI url){
    this.url=url;
  }
  @Override public void setUrl(  String url){
    try {
      setUrl(new URI(url));
    }
 catch (    URISyntaxException e) {
      throw new UncheckedException(e);
    }
  }
  @Override public String getDisplayName(){
    return "Git Repository at " + getUrl();
  }
  @Override public String getUniqueId(){
    return Hashing.md5().hashString(getDisplayName()).toString();
  }
  @Override public String getRepoName(){
    String[] pathParts=url.getPath().split("/");
    String repoPart=pathParts[pathParts.length - 1];
    if (repoPart.endsWith(".git")) {
      repoPart=repoPart.substring(0,repoPart.indexOf(".git"));
    }
    return repoPart;
  }
}
