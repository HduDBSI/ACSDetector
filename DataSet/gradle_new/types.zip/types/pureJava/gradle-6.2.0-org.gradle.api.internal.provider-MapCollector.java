/** 
 * A supplier of zero or more mappings from value of type  {@link K} to value of type {@link V}.
 */
public interface MapCollector<K,V> extends ValueSupplier {
  Value<Void> collectEntries(  MapEntryCollector<K,V> collector,  Map<K,V> dest);
  Value<Void> collectKeys(  ValueCollector<K> collector,  ImmutableCollection.Builder<K> dest);
  void visit(  List<ProviderInternal<? extends Map<? extends K,? extends V>>> sources);
}
