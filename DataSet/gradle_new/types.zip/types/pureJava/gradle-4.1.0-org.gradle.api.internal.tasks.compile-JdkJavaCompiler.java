public class JdkJavaCompiler implements Compiler<JavaCompileSpec>, Serializable {
  private static final Logger LOGGER=LoggerFactory.getLogger(JdkJavaCompiler.class);
  private final Factory<JavaCompiler> javaHomeBasedJavaCompilerFactory;
  public JdkJavaCompiler(  Factory<JavaCompiler> javaHomeBasedJavaCompilerFactory){
    this.javaHomeBasedJavaCompilerFactory=javaHomeBasedJavaCompilerFactory;
  }
  @Override public WorkResult execute(  JavaCompileSpec spec){
    LOGGER.info("Compiling with JDK Java compiler API.");
    JavaCompiler.CompilationTask task=createCompileTask(spec);
    boolean success=task.call();
    if (!success) {
      throw new CompilationFailedException();
    }
    return new SimpleWorkResult(true);
  }
  private JavaCompiler.CompilationTask createCompileTask(  JavaCompileSpec spec){
    List<String> options=new JavaCompilerArgumentsBuilder(spec).build();
    JavaCompiler compiler=javaHomeBasedJavaCompilerFactory.create();
    CompileOptions compileOptions=spec.getCompileOptions();
    StandardJavaFileManager standardFileManager=compiler.getStandardFileManager(null,null,compileOptions.getEncoding() != null ? Charset.forName(compileOptions.getEncoding()) : null);
    Iterable<? extends JavaFileObject> compilationUnits=standardFileManager.getJavaFileObjectsFromFiles(spec.getSource());
    StandardJavaFileManager fileManager=standardFileManager;
    if (JavaVersion.current().isJava9Compatible() && emptySourcepathIn(options)) {
      fileManager=(StandardJavaFileManager)SourcepathIgnoringProxy.proxy(standardFileManager,StandardJavaFileManager.class);
    }
    return compiler.getTask(null,fileManager,null,options,null,compilationUnits);
  }
  private static boolean emptySourcepathIn(  List<String> options){
    Iterator<String> optionsIter=options.iterator();
    while (optionsIter.hasNext()) {
      String current=optionsIter.next();
      if (current.equals("-sourcepath") || current.equals("--source-path")) {
        return optionsIter.next().isEmpty();
      }
    }
    return false;
  }
}
