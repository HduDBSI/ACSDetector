class UnsupportedSymlink implements Symlink {
  @Override public boolean isSymlinkSupported(){
    return false;
  }
  @Override public void symlink(  File link,  File target) throws IOException {
    throw new IOException("Support for the creation of symlinks is only available on this platform using Java 7 or later.");
  }
  @Override public boolean isSymlink(  File suspect){
    return false;
  }
}
