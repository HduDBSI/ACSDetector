public interface ProvidesWorkResult {
  DefaultWorkResult getWorkResult();
}
