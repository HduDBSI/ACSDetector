/** 
 * Mechanism by which the scan plugin registers for notifications. <p> One instance of this exists per build tree. Only one listener may register. Subsequent attempts yield exceptions.
 * @since 4.0
 */
@UsedByScanPlugin("obtained from the root build's root project's service registry") public interface BuildOperationNotificationListenerRegistrar {
  /** 
 * This method is inaccurately named. The term “build” here is actually what we name “build tree”. The listener expects to be automatically de-registered. The registered listener will receive notification for all build operations for the current build execution, _NOT_ including those those operations that started before the listener was registered.
 */
  void registerBuildScopeListener(  BuildOperationNotificationListener listener);
  /** 
 * The registered listener will receive notification for all build operations for the current build execution, including those those operations that started before the listener was registered.
 * @since 4.2
 */
  void registerBuildScopeListenerAndReceiveStoredOperations(  BuildOperationNotificationListener listener);
  /** 
 * The registered listener will receive notification for all build operations for the current build execution, including those those operations that started before the listener was registered.
 * @since 4.4
 */
  void register(  BuildOperationNotificationListener2 listener);
}
