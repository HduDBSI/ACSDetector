public interface TaskStateChanges {
  /** 
 * Propagate changes the visitor.
 * @return Whether the visitor still wants to obtain more changes.
 */
  boolean accept(  TaskStateChangeVisitor visitor);
}
