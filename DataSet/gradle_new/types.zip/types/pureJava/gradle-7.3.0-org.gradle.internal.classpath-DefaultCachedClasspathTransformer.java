public class DefaultCachedClasspathTransformer implements CachedClasspathTransformer, Closeable {
  private final PersistentCache cache;
  private final FileAccessTracker fileAccessTracker;
  private final ClasspathWalker classpathWalker;
  private final ClasspathBuilder classpathBuilder;
  private final FileSystemAccess fileSystemAccess;
  private final GlobalCacheLocations globalCacheLocations;
  private final FileLockManager fileLockManager;
  private final ManagedExecutor executor;
  public DefaultCachedClasspathTransformer(  GlobalScopedCache globalScopedCache,  ClasspathTransformerCacheFactory classpathTransformerCacheFactory,  FileAccessTimeJournal fileAccessTimeJournal,  ClasspathWalker classpathWalker,  ClasspathBuilder classpathBuilder,  FileSystemAccess fileSystemAccess,  ExecutorFactory executorFactory,  GlobalCacheLocations globalCacheLocations,  FileLockManager fileLockManager){
    this.classpathWalker=classpathWalker;
    this.classpathBuilder=classpathBuilder;
    this.fileSystemAccess=fileSystemAccess;
    this.globalCacheLocations=globalCacheLocations;
    this.fileLockManager=fileLockManager;
    this.cache=classpathTransformerCacheFactory.createCache(globalScopedCache,fileAccessTimeJournal);
    this.fileAccessTracker=classpathTransformerCacheFactory.createFileAccessTracker(cache,fileAccessTimeJournal);
    this.executor=executorFactory.create("jar transforms",Runtime.getRuntime().availableProcessors());
  }
  @Override public void close(){
    CompositeStoppable.stoppable(executor,cache).stop();
  }
  @Override public ClassPath transform(  ClassPath classPath,  StandardTransform transform){
    if (classPath.isEmpty()) {
      return classPath;
    }
    return transformFiles(classPath,fileTransformerFor(transform));
  }
  @Override public ClassPath transform(  ClassPath classPath,  StandardTransform transform,  Transform additional){
    if (classPath.isEmpty()) {
      return classPath;
    }
    return transformFiles(classPath,instrumentingClasspathFileTransformerFor(new CompositeTransformer(additional,transformerFor(transform))));
  }
  @Override public List<URL> transform(  Collection<URL> urls,  StandardTransform transform){
    if (urls.isEmpty()) {
      return ImmutableList.of();
    }
    ClasspathFileTransformer transformer=fileTransformerFor(transform);
    return transformAll(urls,(url,seen) -> cachedURL(url,transformer,seen));
  }
  private ClassPath transformFiles(  ClassPath classPath,  ClasspathFileTransformer transformer){
    return DefaultClassPath.of(transformAll(classPath.getAsFiles(),(file,seen) -> cachedFile(file,transformer,seen)));
  }
  private Transform transformerFor(  StandardTransform transform){
    if (transform == StandardTransform.BuildLogic) {
      return new InstrumentingTransformer();
    }
 else {
      throw new UnsupportedOperationException("Not implemented yet.");
    }
  }
  private ClasspathFileTransformer fileTransformerFor(  StandardTransform transform){
switch (transform) {
case BuildLogic:
      return instrumentingClasspathFileTransformerFor(new InstrumentingTransformer());
case None:
    return new CopyingClasspathFileTransformer(globalCacheLocations);
default :
  throw new IllegalArgumentException();
}
}
private InstrumentingClasspathFileTransformer instrumentingClasspathFileTransformerFor(CachedClasspathTransformer.Transform transform){
return new InstrumentingClasspathFileTransformer(fileLockManager,classpathWalker,classpathBuilder,transform);
}
private Optional<Either<URL,Callable<URL>>> cachedURL(URL original,ClasspathFileTransformer transformer,Set<HashCode> seen){
if (original.getProtocol().equals("file")) {
return cachedFile(Convert.urlToFile(original),transformer,seen).map(result -> result.fold(file -> left(Convert.fileToURL(file)),transform -> right(() -> Convert.fileToURL(transform.call()))));
}
return Optional.of(left(original));
}
private Optional<Either<File,Callable<File>>> cachedFile(File original,ClasspathFileTransformer transformer,Set<HashCode> seen){
FileSystemLocationSnapshot snapshot=snapshotOf(original);
if (snapshot.getType() == FileType.Missing) {
return empty();
}
if (shouldUseFromCache(original)) {
final HashCode contentHash=snapshot.getHash();
if (!seen.add(contentHash)) {
  return empty();
}
return Optional.of(right(() -> transformFile(original,snapshot,transformer)));
}
return Optional.of(left(original));
}
private File transformFile(File original,FileSystemLocationSnapshot snapshot,ClasspathFileTransformer transformer){
final File result=transformer.transform(original,snapshot,cache.getBaseDir());
markAccessed(result,original);
return result;
}
private FileSystemLocationSnapshot snapshotOf(File file){
return fileSystemAccess.read(file.getAbsolutePath(),s -> s);
}
private boolean shouldUseFromCache(File original){
return !original.toPath().startsWith(cache.getBaseDir().toPath());
}
private void markAccessed(File result,File original){
if (!result.equals(original)) {
fileAccessTracker.markAccessed(result);
}
}
@FunctionalInterface private interface ValueOrTransformProvider<T,U> {
Optional<Either<U,Callable<U>>> apply(T input,Set<HashCode> seen);
}
private <T,U>List<U> transformAll(Collection<T> inputs,ValueOrTransformProvider<T,U> valueOrTransformProvider){
assert !inputs.isEmpty();
return cache.useCache(() -> {
final List<U> results=new ArrayList<>(inputs.size());
final List<Callable<Void>> transforms=new ArrayList<>(inputs.size());
final Set<HashCode> seen=new HashSet<>();
for (T input : inputs) {
  valueOrTransformProvider.apply(input,seen).ifPresent(valueOrTransform -> valueOrTransform.apply(value -> results.add(value),transform -> {
    final int index=results.size();
    results.add(null);
    transforms.add(() -> {
      results.set(index,unchecked(transform));
      return null;
    }
);
  }
));
}
for (Future<Void> result : unchecked(() -> executor.invokeAll(transforms))) {
  unchecked(result::get);
}
return results;
}
);
}
private static class Convert {
public static File urlToFile(URL original){
return new File(unchecked(original::toURI));
}
public static URL fileToURL(File file){
return unchecked(file.toURI()::toURL);
}
}
}
