/** 
 * <p>A  {@code TaskExecutionException} is thrown when a task fails to execute successfully.</p>
 */
@Contextual public class TaskExecutionException extends DefaultMultiCauseException {
  private final Task task;
  public TaskExecutionException(  Task task,  Throwable cause){
    super(String.format("Execution failed for %s.",task),cause);
    this.task=task;
  }
  public Task getTask(){
    return task;
  }
}
