public class DefaultBinaryTasksCollection extends DefaultDomainObjectSet<Task> implements BinaryTasksCollection {
  private final BinarySpecInternal binary;
  private final ITaskFactory taskFactory;
  public DefaultBinaryTasksCollection(  BinarySpecInternal binarySpecInternal,  ITaskFactory taskFactory){
    super(Task.class);
    this.binary=binarySpecInternal;
    this.taskFactory=taskFactory;
  }
  @Override public String taskName(  String verb){
    return verb + StringUtils.capitalize(binary.getProjectScopedName());
  }
  @Override public String taskName(  String verb,  String object){
    return verb + StringUtils.capitalize(binary.getProjectScopedName()) + StringUtils.capitalize(object);
  }
  @Override public Task getBuild(){
    return binary.getBuildTask();
  }
  @Override public Task getCheck(){
    return binary.getCheckTask();
  }
  public <T extends Task>T findSingleTaskWithType(  Class<T> type){
    DomainObjectSet<T> tasks=withType(type);
    if (tasks.size() == 0) {
      return null;
    }
    if (tasks.size() > 1) {
      throw new UnknownDomainObjectException(String.format("Multiple tasks with type '%s' found.",type.getSimpleName()));
    }
    return tasks.iterator().next();
  }
  @Override public <T extends Task>void create(  String name,  Class<T> type,  Action<? super T> config){
    @SuppressWarnings("unchecked") T task=(T)taskFactory.create(name,(Class<TaskInternal>)type);
    add(task);
    config.execute(task);
  }
}
