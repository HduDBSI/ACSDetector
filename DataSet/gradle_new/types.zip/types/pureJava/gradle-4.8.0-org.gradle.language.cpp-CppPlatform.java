/** 
 * A target platform for building C++ binaries.
 * @since 4.5
 */
@Incubating public interface CppPlatform extends NativePlatform {
  /** 
 * The operating system family being targeted.
 * @since 4.8
 */
  @Nested OperatingSystemFamily getOperatingSystemFamily();
}
