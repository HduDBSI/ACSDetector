/** 
 * Allows the test to synchronise with and unblock a single request.
 */
public interface BlockingRequest extends ExpectedRequest {
  /** 
 * Waits for the request to be received and blocked.
 */
  void waitUntilBlocked();
  /** 
 * Unblock the request.
 */
  void release();
}
