class DefaultNestedBuild extends AbstractBuildState implements StandAloneNestedBuild, Stoppable {
  private final Path identityPath;
  private final BuildState owner;
  private final ProjectStateRegistry projectStateRegistry;
  private final BuildIdentifier buildIdentifier;
  private final BuildDefinition buildDefinition;
  private final BuildLifecycleController buildLifecycleController;
  private final BuildTreeLifecycleController buildTreeLifecycleController;
  DefaultNestedBuild(  BuildIdentifier buildIdentifier,  Path identityPath,  BuildDefinition buildDefinition,  BuildState owner,  BuildTreeState buildTree,  BuildLifecycleControllerFactory buildLifecycleControllerFactory,  ProjectStateRegistry projectStateRegistry){
    this.buildIdentifier=buildIdentifier;
    this.identityPath=identityPath;
    this.buildDefinition=buildDefinition;
    this.owner=owner;
    this.projectStateRegistry=projectStateRegistry;
    BuildScopeServices buildScopeServices=new BuildScopeServices(buildTree.getServices());
    this.buildLifecycleController=buildLifecycleControllerFactory.newInstance(buildDefinition,this,owner,buildScopeServices);
    IncludedBuildTaskGraph taskGraph=buildScopeServices.get(IncludedBuildTaskGraph.class);
    ExceptionAnalyser exceptionAnalyser=buildScopeServices.get(ExceptionAnalyser.class);
    BuildModelParameters modelParameters=buildScopeServices.get(BuildModelParameters.class);
    BuildTreeWorkExecutor workExecutor=new DefaultBuildTreeWorkExecutor(taskGraph,buildLifecycleController);
    BuildTreeLifecycleControllerFactory buildTreeLifecycleControllerFactory=buildScopeServices.get(BuildTreeLifecycleControllerFactory.class);
    BuildTreeFinishExecutor finishExecutor;
    if (modelParameters.isRequiresBuildModel()) {
      finishExecutor=new DoNothingBuildFinishExecutor(exceptionAnalyser);
    }
 else {
      finishExecutor=new FinishThisBuildOnlyFinishExecutor(exceptionAnalyser);
    }
    buildTreeLifecycleController=buildTreeLifecycleControllerFactory.createController(buildLifecycleController,workExecutor,finishExecutor);
  }
  @Override protected BuildLifecycleController getBuildController(){
    return buildLifecycleController;
  }
  @Override protected ProjectStateRegistry getProjectStateRegistry(){
    return projectStateRegistry;
  }
  @Override public BuildIdentifier getBuildIdentifier(){
    return buildIdentifier;
  }
  @Override public Path getIdentityPath(){
    return identityPath;
  }
  @Override public boolean isImplicitBuild(){
    return true;
  }
  @Override public void stop(){
    buildLifecycleController.stop();
  }
  @Override public ExecutionResult<Void> finishBuild(){
    return buildLifecycleController.finishBuild(null);
  }
  @Override public <T>T run(  Function<? super BuildTreeLifecycleController,T> buildAction){
    return buildAction.apply(buildTreeLifecycleController);
  }
  @Override public Path getCurrentPrefixForProjectsInChildBuilds(){
    return owner.getCurrentPrefixForProjectsInChildBuilds().child(buildDefinition.getName());
  }
  @Override public Path calculateIdentityPathForProject(  Path projectPath){
    return buildLifecycleController.getGradle().getIdentityPath().append(projectPath);
  }
  @Override public File getBuildRootDir(){
    return buildDefinition.getBuildRootDir();
  }
  @Override public GradleInternal getBuild(){
    return buildLifecycleController.getGradle();
  }
  @Override public GradleInternal getMutableModel(){
    return buildLifecycleController.getGradle();
  }
private static class DoNothingBuildFinishExecutor implements BuildTreeFinishExecutor {
    private final ExceptionAnalyser exceptionAnalyser;
    public DoNothingBuildFinishExecutor(    ExceptionAnalyser exceptionAnalyser){
      this.exceptionAnalyser=exceptionAnalyser;
    }
    @Override @Nullable public RuntimeException finishBuildTree(    List<Throwable> failures){
      return exceptionAnalyser.transform(failures);
    }
  }
private class FinishThisBuildOnlyFinishExecutor implements BuildTreeFinishExecutor {
    private final ExceptionAnalyser exceptionAnalyser;
    public FinishThisBuildOnlyFinishExecutor(    ExceptionAnalyser exceptionAnalyser){
      this.exceptionAnalyser=exceptionAnalyser;
    }
    @Override @Nullable public RuntimeException finishBuildTree(    List<Throwable> failures){
      RuntimeException reportable=exceptionAnalyser.transform(failures);
      ExecutionResult<Void> finishResult=buildLifecycleController.finishBuild(reportable);
      return exceptionAnalyser.transform(ExecutionResult.maybeFailed(reportable).withFailures(finishResult).getFailures());
    }
  }
}
