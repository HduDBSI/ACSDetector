private static class LocalLibraryDependencyResolverFactory implements ResolverProviderFactory {
  private final ProjectModelResolver projectModelResolver;
  private final ModelSchemaStore schemaStore;
  private final CalculatedValueContainerFactory calculatedValueContainerFactory;
  private final List<VariantAxisCompatibilityFactory> factories;
  LocalLibraryDependencyResolverFactory(  ProjectModelResolver projectModelResolver,  ModelSchemaStore schemaStore,  CalculatedValueContainerFactory calculatedValueContainerFactory,  List<VariantAxisCompatibilityFactory> factories){
    this.projectModelResolver=projectModelResolver;
    this.schemaStore=schemaStore;
    this.calculatedValueContainerFactory=calculatedValueContainerFactory;
    this.factories=factories;
  }
  @Override public void create(  ResolveContext context,  Collection<ComponentResolvers> resolvers){
    if (context instanceof JvmLibraryResolveContext) {
      VariantsMetaData variants=((JvmLibraryResolveContext)context).getVariants();
      VariantBinarySelector variantSelector=new JvmVariantSelector(factories,JvmBinarySpec.class,schemaStore,variants);
      JvmLocalLibraryMetaDataAdapter libraryMetaDataAdapter=new JvmLocalLibraryMetaDataAdapter();
      resolvers.add(new LocalLibraryDependencyResolver(JvmBinarySpec.class,projectModelResolver,new DefaultLocalLibraryResolver(),variantSelector,libraryMetaDataAdapter,new DefaultLibraryResolutionErrorMessageBuilder(variants,schemaStore),calculatedValueContainerFactory));
    }
  }
}
