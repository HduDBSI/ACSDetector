public abstract class DefaultSwiftComponent extends DefaultNativeComponent implements SwiftComponent, ComponentWithNames {
  private final DefaultBinaryCollection<SwiftBinary> binaries;
  private final FileCollection swiftSource;
  private final Property<String> module;
  private final String name;
  private final Names names;
  private final LockableProperty<SwiftVersion> sourceCompatibility;
  public DefaultSwiftComponent(  String name,  FileOperations fileOperations,  ObjectFactory objectFactory){
    super(fileOperations);
    this.name=name;
    swiftSource=createSourceView("src/" + name + "/swift",Collections.singletonList("swift"));
    module=objectFactory.property(String.class);
    sourceCompatibility=new LockableProperty<SwiftVersion>(objectFactory.property(SwiftVersion.class));
    names=Names.of(name);
    binaries=Cast.uncheckedCast(objectFactory.newInstance(DefaultBinaryCollection.class,SwiftBinary.class));
  }
  @Override public String getName(){
    return name;
  }
  @Override public Names getNames(){
    return names;
  }
  @Override public Property<String> getModule(){
    return module;
  }
  @Override public FileCollection getSwiftSource(){
    return swiftSource;
  }
  @Override public DefaultBinaryCollection<SwiftBinary> getBinaries(){
    return binaries;
  }
  @Override public LockableProperty<SwiftVersion> getSourceCompatibility(){
    return sourceCompatibility;
  }
}
