/** 
 * A HTML Report whose generation can be customized with a XSLT stylesheet.
 */
public interface CustomizableHtmlReport extends SingleFileReport {
  /** 
 * The stylesheet to use to generate the HTML report.
 * @return the stylesheet to use to generate the HTML report
 */
  @Nullable @Optional @Nested TextResource getStylesheet();
  /** 
 * The stylesheet to use to generate the report.
 * @param stylesheet the stylesheet to use to generate the HTML report
 */
  void setStylesheet(  @Nullable TextResource stylesheet);
}
