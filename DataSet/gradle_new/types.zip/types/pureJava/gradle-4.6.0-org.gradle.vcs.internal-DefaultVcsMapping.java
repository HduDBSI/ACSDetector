public class DefaultVcsMapping implements VcsMappingInternal {
  private final ComponentSelector requested;
  private final VersionControlSpecFactory specFactory;
  private ClassLoaderScope classLoaderScope;
  private VersionControlSpec versionControlSpec;
  public DefaultVcsMapping(  ComponentSelector requested,  VersionControlSpecFactory specFactory){
    this.requested=requested;
    this.specFactory=specFactory;
  }
  @Override public ComponentSelector getRequested(){
    return requested;
  }
  @Override public void from(  VersionControlSpec versionControlSpec){
    Preconditions.checkNotNull(versionControlSpec,"VCS repository cannot be null");
    this.versionControlSpec=versionControlSpec;
  }
  @Override public <T extends VersionControlSpec>void from(  Class<T> type,  Action<? super T> configureAction){
    T spec=specFactory.create(type,classLoaderScope);
    configureAction.execute(spec);
    this.versionControlSpec=spec;
  }
  @Override public VersionControlSpec getRepository(){
    return versionControlSpec;
  }
  @Override public boolean hasRepository(){
    return versionControlSpec != null;
  }
  public void setClassLoaderScope(  ClassLoaderScope classLoaderScope){
    this.classLoaderScope=classLoaderScope;
  }
}
