/** 
 * Represents a task which is executable by Gradle.
 * @since 1.0-milestone-5
 */
public interface GradleTask extends Task {
  /** 
 * Returns the Gradle project this task is defined in.
 * @return The element.
 * @since 1.0-milestone-5
 */
  GradleProject getProject();
}
