/** 
 * Contains zero or more variants of a particular component.
 */
public abstract class DefaultArtifactSet implements ArtifactSet, ResolvedVariantSet {
  private final ComponentIdentifier componentIdentifier;
  private final AttributesSchemaInternal schema;
  private DefaultArtifactSet(  ComponentIdentifier componentIdentifier,  AttributesSchemaInternal schema){
    this.componentIdentifier=componentIdentifier;
    this.schema=schema;
  }
  public static ArtifactSet multipleVariants(  ComponentIdentifier componentIdentifier,  ModuleVersionIdentifier ownerId,  ModuleSource moduleSource,  ModuleExclusion exclusions,  Set<? extends VariantMetadata> variants,  AttributesSchemaInternal schema,  ArtifactResolver artifactResolver,  Map<ComponentArtifactIdentifier,ResolvableArtifact> allResolvedArtifacts,  ArtifactTypeRegistry artifactTypeRegistry){
    if (variants.size() == 1) {
      VariantMetadata variantMetadata=variants.iterator().next();
      ResolvedVariant resolvedVariant=toResolvedVariant(variantMetadata,ownerId,moduleSource,exclusions,artifactResolver,allResolvedArtifacts,artifactTypeRegistry);
      return new SingleVariantAttributeSet(componentIdentifier,schema,resolvedVariant);
    }
    ImmutableSet.Builder<ResolvedVariant> result=ImmutableSet.builder();
    for (    VariantMetadata variant : variants) {
      ResolvedVariant resolvedVariant=toResolvedVariant(variant,ownerId,moduleSource,exclusions,artifactResolver,allResolvedArtifacts,artifactTypeRegistry);
      result.add(resolvedVariant);
    }
    return new MultipleVariantAttributeSet(componentIdentifier,schema,result.build());
  }
  public static ArtifactSet singleVariant(  ComponentIdentifier componentIdentifier,  ModuleVersionIdentifier ownerId,  DisplayName displayName,  Set<? extends ComponentArtifactMetadata> artifacts,  ModuleSource moduleSource,  ModuleExclusion exclusions,  AttributesSchemaInternal schema,  ArtifactResolver artifactResolver,  Map<ComponentArtifactIdentifier,ResolvableArtifact> allResolvedArtifacts,  ArtifactTypeRegistry artifactTypeRegistry){
    VariantMetadata variantMetadata=new DefaultVariantMetadata(displayName,ImmutableAttributes.EMPTY,artifacts);
    ResolvedVariant resolvedVariant=toResolvedVariant(variantMetadata,ownerId,moduleSource,exclusions,artifactResolver,allResolvedArtifacts,artifactTypeRegistry);
    return new SingleVariantAttributeSet(componentIdentifier,schema,resolvedVariant);
  }
  private static ResolvedVariant toResolvedVariant(  VariantMetadata variant,  ModuleVersionIdentifier ownerId,  ModuleSource moduleSource,  ModuleExclusion exclusions,  ArtifactResolver artifactResolver,  Map<ComponentArtifactIdentifier,ResolvableArtifact> allResolvedArtifacts,  ArtifactTypeRegistry artifactTypeRegistry){
    Set<? extends ComponentArtifactMetadata> artifacts=variant.getArtifacts();
    Set<ResolvableArtifact> resolvedArtifacts=new LinkedHashSet<ResolvableArtifact>(artifacts.size());
    ImmutableAttributes attributes=artifactTypeRegistry.mapAttributesFor(variant);
    for (    ComponentArtifactMetadata artifact : artifacts) {
      IvyArtifactName artifactName=artifact.getName();
      if (exclusions.excludeArtifact(ownerId.getModule(),artifactName)) {
        continue;
      }
      ResolvableArtifact resolvedArtifact=allResolvedArtifacts.get(artifact.getId());
      if (resolvedArtifact == null) {
        Factory<File> artifactSource=new LazyArtifactSource(artifact,moduleSource,artifactResolver);
        resolvedArtifact=new DefaultResolvedArtifact(ownerId,artifactName,artifact.getId(),artifact.getBuildDependencies(),artifactSource);
        allResolvedArtifacts.put(artifact.getId(),resolvedArtifact);
      }
      resolvedArtifacts.add(resolvedArtifact);
    }
    return ArtifactBackedResolvedVariant.create(variant.asDescribable(),attributes,resolvedArtifacts);
  }
  @Override public String toString(){
    return asDescribable().getDisplayName();
  }
  @Override public Describable asDescribable(){
    return Describables.of(componentIdentifier);
  }
  @Override public AttributesSchemaInternal getSchema(){
    return schema;
  }
  @Override public ResolvedArtifactSet select(  Spec<? super ComponentIdentifier> componentFilter,  VariantSelector selector){
    if (!componentFilter.isSatisfiedBy(componentIdentifier)) {
      return ResolvedArtifactSet.EMPTY;
    }
 else {
      return selector.select(this);
    }
  }
private static class SingleVariantAttributeSet extends DefaultArtifactSet {
    private final ResolvedVariant variant;
    public SingleVariantAttributeSet(    ComponentIdentifier componentIdentifier,    AttributesSchemaInternal schema,    ResolvedVariant variant){
      super(componentIdentifier,schema);
      this.variant=variant;
    }
    @Override public Set<ResolvedVariant> getVariants(){
      return ImmutableSet.of(variant);
    }
  }
private static class MultipleVariantAttributeSet extends DefaultArtifactSet {
    private final Set<ResolvedVariant> variants;
    public MultipleVariantAttributeSet(    ComponentIdentifier componentIdentifier,    AttributesSchemaInternal schema,    Set<ResolvedVariant> variants){
      super(componentIdentifier,schema);
      this.variants=variants;
    }
    @Override public Set<ResolvedVariant> getVariants(){
      return variants;
    }
  }
private static class LazyArtifactSource implements Factory<File> {
    private final ArtifactResolver artifactResolver;
    private final ModuleSource moduleSource;
    private final ComponentArtifactMetadata artifact;
    private LazyArtifactSource(    ComponentArtifactMetadata artifact,    ModuleSource moduleSource,    ArtifactResolver artifactResolver){
      this.artifact=artifact;
      this.artifactResolver=artifactResolver;
      this.moduleSource=moduleSource;
    }
    public File create(){
      DefaultBuildableArtifactResolveResult result=new DefaultBuildableArtifactResolveResult();
      artifactResolver.resolveArtifact(artifact,moduleSource,result);
      return result.getResult();
    }
  }
}
