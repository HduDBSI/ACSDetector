@NonNullApi public class DefaultTaskExecutionModeResolver implements TaskExecutionModeResolver {
  private final StartParameter startParameter;
  public DefaultTaskExecutionModeResolver(  StartParameter startParameter){
    this.startParameter=startParameter;
  }
  @Override public TaskExecutionMode getExecutionMode(  TaskInternal task,  TaskProperties properties){
    AndSpec<? super TaskInternal> upToDateSpec=task.getOutputs().getUpToDateSpec();
    if (!properties.hasDeclaredOutputs() && upToDateSpec.isEmpty()) {
      if (task.hasTaskActions()) {
        if (requiresInputChanges(task)) {
          DeprecationLogger.nagUserOfDeprecated("Using the incremental task API without declaring any outputs","Please declare output files for your task or use `TaskOutputs.upToDateWhen()`.");
        }
 else {
          return TaskExecutionMode.NO_OUTPUTS_WITH_ACTIONS;
        }
      }
 else {
        return TaskExecutionMode.NO_OUTPUTS_WITHOUT_ACTIONS;
      }
    }
    if (startParameter.isRerunTasks()) {
      return TaskExecutionMode.RERUN_TASKS_ENABLED;
    }
    if (!upToDateSpec.isSatisfiedBy(task)) {
      return TaskExecutionMode.UP_TO_DATE_WHEN_FALSE;
    }
    return TaskExecutionMode.INCREMENTAL;
  }
  private static boolean requiresInputChanges(  TaskInternal task){
    for (    InputChangesAwareTaskAction taskAction : task.getTaskActions()) {
      if (taskAction instanceof AbstractIncrementalTaskAction) {
        return true;
      }
    }
    return false;
  }
}
