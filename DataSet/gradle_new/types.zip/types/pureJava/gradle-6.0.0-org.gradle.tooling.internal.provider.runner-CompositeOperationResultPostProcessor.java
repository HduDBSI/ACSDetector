class CompositeOperationResultPostProcessor implements OperationResultPostProcessor {
  private final List<OperationResultPostProcessor> processors;
  CompositeOperationResultPostProcessor(  List<OperationResultPostProcessor> processors){
    this.processors=processors;
  }
  @Override public AbstractTaskResult process(  AbstractTaskResult taskResult,  Object taskBuildOperationId){
    for (    OperationResultPostProcessor factory : processors) {
      taskResult=factory.process(taskResult,taskBuildOperationId);
    }
    return taskResult;
  }
}
