public abstract class NativeLanguageTransform<U extends LanguageSourceSet> implements LanguageTransform<U,ObjectFile> {
  @Override public boolean applyToBinary(  BinarySpec binary){
    return binary instanceof NativeBinarySpec;
  }
  public abstract ToolType getToolType();
  @Override public Class<ObjectFile> getOutputType(){
    return ObjectFile.class;
  }
}
