/** 
 * Implementation of the  {@code TaskFinishEvent} interface.
 */
public final class DefaultTaskFinishEvent extends DefaultFinishEvent implements TaskFinishEvent {
  public DefaultTaskFinishEvent(  long eventTime,  String displayName,  TaskOperationDescriptor descriptor,  TaskOperationResult result){
    super(eventTime,displayName,descriptor,result);
  }
  @Override public TaskOperationDescriptor getDescriptor(){
    return (TaskOperationDescriptor)super.getDescriptor();
  }
  @Override public TaskOperationResult getResult(){
    return (TaskOperationResult)super.getResult();
  }
}
