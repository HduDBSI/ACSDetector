private static class IncludeSerializer extends AbstractSerializer<Include> {
  private final Serializer<String> stringSerializer=SERIALIZER_FACTORY.getSerializerFor(String.class);
  private final Serializer<Boolean> booleanSerializer=SERIALIZER_FACTORY.getSerializerFor(Boolean.class);
  private final Serializer<IncludeType> enumSerializer=SERIALIZER_FACTORY.getSerializerFor(IncludeType.class);
  @Override public Include read(  Decoder decoder) throws Exception {
    String value=stringSerializer.read(decoder);
    boolean isImport=booleanSerializer.read(decoder);
    IncludeType type=enumSerializer.read(decoder);
    return new DefaultInclude(value,isImport,type);
  }
  @Override public void write(  Encoder encoder,  Include value) throws Exception {
    stringSerializer.write(encoder,value.getValue());
    booleanSerializer.write(encoder,value.isImport());
    enumSerializer.write(encoder,value.getType());
  }
  @Override public boolean equals(  Object obj){
    if (!super.equals(obj)) {
      return false;
    }
    IncludeSerializer rhs=(IncludeSerializer)obj;
    return Objects.equal(stringSerializer,rhs.stringSerializer) && Objects.equal(booleanSerializer,rhs.booleanSerializer) && Objects.equal(enumSerializer,rhs.enumSerializer);
  }
  @Override public int hashCode(){
    return Objects.hashCode(super.hashCode(),stringSerializer,booleanSerializer,enumSerializer);
  }
}
