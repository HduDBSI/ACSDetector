public interface CompatibilityRule<T> extends Action<CompatibilityCheckResult<T>> {
}
