public class FilterChainTest {
  private final FilterChain filterChain=new FilterChain();
  private final Reader originalReader=new StringReader("string");
  @Test public void usesOriginalReaderByDefault(){
    assertThat(filterChain.transform(originalReader),sameInstance(originalReader));
  }
  @Test public void canAddFilterReaderToEndOfChain(){
    filterChain.add(TestFilterReader.class);
    Reader transformedReader=filterChain.transform(originalReader);
    assertThat(transformedReader,instanceOf(TestFilterReader.class));
    TestFilterReader reader=(TestFilterReader)transformedReader;
    assertThat(reader.getIn(),sameInstance(originalReader));
  }
  @Test public void canAddFilterReaderWithParametersToEndOfChain(){
    filterChain.add(TestFilterReader.class,toMap("property","value"));
    Reader transformedReader=filterChain.transform(originalReader);
    assertThat(transformedReader,instanceOf(TestFilterReader.class));
    TestFilterReader reader=(TestFilterReader)transformedReader;
    assertThat(reader.getIn(),sameInstance(originalReader));
    assertThat(reader.property,equalTo("value"));
  }
  @Test public void canAddLineFilterReaderToEndOfChain(){
    filterChain.add(TestUtil.TEST_CLOSURE);
    Reader transformedReader=filterChain.transform(originalReader);
    assertThat(transformedReader,instanceOf(LineFilter.class));
  }
  @Test public void canAddExpandFilterToEndOfChain() throws IOException {
    filterChain.expand(WrapUtil.toMap("prop",1),escapeBackslashProperty());
    Reader transformedReader=filterChain.transform(new StringReader("[$prop][${prop+1}][<%= prop+2 %>]"));
    assertThat(IOUtils.toString(transformedReader),equalTo("[1][2][3]"));
  }
  @Test public void canFilterUsingISO88591() throws IOException {
    canFilterUsingCharset("ISO_8859_1");
  }
  @Test public void canFilterUsingUTF8() throws IOException {
    canFilterUsingCharset("UTF8");
  }
  private void canFilterUsingCharset(  String charset) throws IOException {
    FilterChain filterChainWithCharset=new FilterChain(charset);
    filterChainWithCharset.expand(WrapUtil.toMap("prop",1),escapeBackslashProperty());
    byte[] source="éàüî $prop".getBytes(charset);
    InputStream transformedInputStream=filterChainWithCharset.transform(new ByteArrayInputStream(source));
    String actualResult=new String(ByteStreams.toByteArray(transformedInputStream),charset);
    String expectedResult="éàüî 1";
    assertThat(actualResult,equalTo(expectedResult));
  }
  @Test public void canFilterSurrogatePairs() throws IOException {
    Charset charset=StandardCharsets.UTF_8;
    FilterChain filterChain=new FilterChain(charset.name());
    filterChain.add(s -> s);
    StringBuilder sb=new StringBuilder();
    for (int i=0; i < 10000; i++) {
      sb.append("丈, 😃, and नि");
    }
    String input=sb.toString();
    ByteArrayOutputStream baos=new ByteArrayOutputStream();
    InputStream transformed=filterChain.transform(new ByteArrayInputStream(input.getBytes(charset.name())));
    int read;
    while ((read=transformed.read()) != -1) {
      baos.write(read);
    }
    assertThat(baos.toString(charset.name()),equalTo(input));
  }
  @Test public void convertsBackslashesIfNotEscaped() throws IOException {
    filterChain.expand(Collections.emptyMap(),escapeBackslashProperty());
    Reader transformedReader=filterChain.transform(new StringReader("\\n\\t\\\\"));
    assertThat(IOUtils.toString(transformedReader),equalTo("\n\t\\"));
  }
  @Test public void doNotConvertsBackslashesIfEscaped() throws IOException {
    filterChain.expand(Collections.emptyMap(),escapeBackslashProperty().value(true));
    Reader transformedReader=filterChain.transform(new StringReader("\\n\\t\\\\"));
    assertThat(IOUtils.toString(transformedReader),equalTo("\\n\\t\\\\"));
  }
public static class TestFilterReader extends FilterReader {
    String property;
    public TestFilterReader(    Reader reader){
      super(reader);
    }
    public Reader getIn(){
      return in;
    }
    public void setProperty(    String property){
      this.property=property;
    }
  }
  private static Property<Boolean> escapeBackslashProperty(){
    return TestUtil.objectFactory().property(Boolean.class).value(false);
  }
}
