public interface DisambiguationRule<T> extends Action<MultipleCandidatesResult<T>> {
  boolean doesSomething();
}
