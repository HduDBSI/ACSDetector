class LeafOutgoingVariant implements OutgoingVariant {
  private final AttributeContainerInternal attributes;
  private final Set<? extends PublishArtifact> artifacts;
  private final DisplayName displayName;
  public LeafOutgoingVariant(  DisplayName displayName,  AttributeContainerInternal attributes,  Set<? extends PublishArtifact> artifacts){
    this.displayName=displayName;
    this.attributes=attributes;
    this.artifacts=artifacts;
  }
  @Override public DisplayName asDescribable(){
    return displayName;
  }
  @Override public AttributeContainerInternal getAttributes(){
    return attributes;
  }
  @Override public Set<? extends PublishArtifact> getArtifacts(){
    return artifacts;
  }
  @Override public Set<? extends OutgoingVariant> getChildren(){
    return ImmutableSet.of();
  }
}
