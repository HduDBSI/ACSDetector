public class DefaultLocalComponentMetadataBuilder implements LocalComponentMetadataBuilder {
  private final LocalConfigurationMetadataBuilder configurationMetadataBuilder;
  public DefaultLocalComponentMetadataBuilder(  LocalConfigurationMetadataBuilder configurationMetadataBuilder){
    this.configurationMetadataBuilder=configurationMetadataBuilder;
  }
  public void addConfigurations(  BuildableLocalComponentMetadata metaData,  Collection<? extends ConfigurationInternal> configurations){
    for (    ConfigurationInternal configuration : configurations) {
      addConfiguration(metaData,configuration);
      metaData.addDependenciesAndExcludesForConfiguration(configuration,configurationMetadataBuilder);
      OutgoingVariant outgoingVariant=configuration.convertToOutgoingVariant();
      metaData.addArtifacts(configuration.getName(),outgoingVariant.getArtifacts());
      for (      OutgoingVariant variant : outgoingVariant.getChildren()) {
        metaData.addVariant(configuration.getName(),variant);
      }
    }
  }
  private BuildableLocalConfigurationMetadata addConfiguration(  BuildableLocalComponentMetadata metaData,  ConfigurationInternal configuration){
    configuration.preventFromFurtherMutation();
    Set<String> hierarchy=Configurations.getNames(configuration.getHierarchy());
    Set<String> extendsFrom=Configurations.getNames(configuration.getExtendsFrom());
    ImmutableCapabilities capabilities=asImmutable(Configurations.collectCapabilities(configuration,Sets.<Capability>newHashSet(),Sets.<Configuration>newHashSet()));
    return metaData.addConfiguration(configuration.getName(),configuration.getDescription(),extendsFrom,hierarchy,configuration.isVisible(),configuration.isTransitive(),configuration.getAttributes().asImmutable(),configuration.isCanBeConsumed(),configuration.isCanBeResolved(),capabilities);
  }
  private static ImmutableCapabilities asImmutable(  Collection<? extends Capability> descriptors){
    if (descriptors.isEmpty()) {
      return ImmutableCapabilities.EMPTY;
    }
    ImmutableList.Builder<ImmutableCapability> builder=new ImmutableList.Builder<ImmutableCapability>();
    for (    Capability descriptor : descriptors) {
      builder.add(new ImmutableCapability(descriptor.getGroup(),descriptor.getName(),descriptor.getVersion()));
    }
    return new ImmutableCapabilities(builder.build());
  }
}
