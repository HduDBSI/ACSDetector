public class ApiGroovyCompiler implements org.gradle.language.base.internal.compile.Compiler<GroovyJavaJointCompileSpec>, Serializable {
  private final Compiler<JavaCompileSpec> javaCompiler;
  public ApiGroovyCompiler(  Compiler<JavaCompileSpec> javaCompiler){
    this.javaCompiler=javaCompiler;
  }
private static abstract class IncrementalCompilationCustomizer extends CompilationCustomizer {
    static IncrementalCompilationCustomizer fromSpec(    GroovyJavaJointCompileSpec spec){
      if (spec.incrementalCompilationEnabled()) {
        return new TrackingClassGenerationCompilationCustomizer(new CompilationSourceDirs(spec.getSourceRoots()),spec.getCompilationMappingFile());
      }
 else {
        return new NoOpCompilationCustomizer();
      }
    }
    public IncrementalCompilationCustomizer(){
      super(CompilePhase.CLASS_GENERATION);
    }
    abstract void writeToMappingFile();
    abstract void addToConfiguration(    CompilerConfiguration configuration);
  }
private static class NoOpCompilationCustomizer extends IncrementalCompilationCustomizer {
    @Override public void writeToMappingFile(){
    }
    @Override public void addToConfiguration(    CompilerConfiguration configuration){
    }
    @Override public void call(    SourceUnit source,    GeneratorContext context,    ClassNode classNode) throws org.codehaus.groovy.control.CompilationFailedException {
      throw new UnsupportedOperationException();
    }
  }
private static class TrackingClassGenerationCompilationCustomizer extends IncrementalCompilationCustomizer {
    private final Multimap<String,String> sourceClassesMapping=MultimapBuilder.SetMultimapBuilder.hashKeys().hashSetValues().build();
    private final CompilationSourceDirs compilationSourceDirs;
    private final File sourceClassesMappingFile;
    private TrackingClassGenerationCompilationCustomizer(    CompilationSourceDirs compilationSourceDirs,    File mappingFile){
      this.compilationSourceDirs=compilationSourceDirs;
      this.sourceClassesMappingFile=mappingFile;
    }
    @Override public void call(    SourceUnit source,    GeneratorContext context,    ClassNode classNode){
      inspectClassNode(source,classNode);
    }
    private void inspectClassNode(    SourceUnit sourceUnit,    ClassNode classNode){
      String relativePath=compilationSourceDirs.relativize(new File(sourceUnit.getSource().getURI().getPath())).orElseThrow(IllegalStateException::new);
      sourceClassesMapping.put(relativePath,classNode.getName());
      Iterator<InnerClassNode> iterator=classNode.getInnerClasses();
      while (iterator.hasNext()) {
        inspectClassNode(sourceUnit,iterator.next());
      }
    }
    @Override public void writeToMappingFile(){
      writeSourceClassesMappingFile(sourceClassesMappingFile,sourceClassesMapping);
    }
    @Override public void addToConfiguration(    CompilerConfiguration configuration){
      configuration.addCompilationCustomizers(this);
    }
  }
  private File[] getSortedSourceFiles(  GroovyJavaJointCompileSpec spec){
    File[] sortedSourceFiles=Iterables.toArray(spec.getSourceFiles(),File.class);
    Arrays.sort(sortedSourceFiles);
    return sortedSourceFiles;
  }
  @Override public WorkResult execute(  final GroovyJavaJointCompileSpec spec){
    GroovySystemLoaderFactory groovySystemLoaderFactory=new GroovySystemLoaderFactory();
    ClassLoader compilerClassLoader=this.getClass().getClassLoader();
    GroovySystemLoader compilerGroovyLoader=groovySystemLoaderFactory.forClassLoader(compilerClassLoader);
    CompilerConfiguration configuration=new CompilerConfiguration();
    configuration.setVerbose(spec.getGroovyCompileOptions().isVerbose());
    configuration.setSourceEncoding(spec.getGroovyCompileOptions().getEncoding());
    configuration.setTargetBytecode(spec.getTargetCompatibility());
    configuration.setTargetDirectory(spec.getDestinationDir());
    canonicalizeValues(spec.getGroovyCompileOptions().getOptimizationOptions());
    IncrementalCompilationCustomizer customizer=IncrementalCompilationCustomizer.fromSpec(spec);
    customizer.addToConfiguration(configuration);
    if (spec.getGroovyCompileOptions().getConfigurationScript() != null) {
      applyConfigurationScript(spec.getGroovyCompileOptions().getConfigurationScript(),configuration);
    }
    try {
      configuration.setOptimizationOptions(spec.getGroovyCompileOptions().getOptimizationOptions());
    }
 catch (    NoSuchMethodError ignored) {
    }
    Map<String,Object> jointCompilationOptions=new HashMap<String,Object>();
    final File stubDir=spec.getGroovyCompileOptions().getStubDir();
    stubDir.mkdirs();
    jointCompilationOptions.put("stubDir",stubDir);
    jointCompilationOptions.put("keepStubs",spec.getGroovyCompileOptions().isKeepStubs());
    configuration.setJointCompilationOptions(jointCompilationOptions);
    ClassLoader classPathLoader;
    VersionNumber version=parseGroovyVersion();
    if (version.compareTo(VersionNumber.parse("2.0")) < 0) {
      classPathLoader=new GroovyCompileTransformingClassLoader(getExtClassLoader(),DefaultClassPath.of(spec.getCompileClasspath()));
    }
 else {
      classPathLoader=new DefaultClassLoaderFactory().createIsolatedClassLoader("api-groovy-compile-loader",DefaultClassPath.of(spec.getCompileClasspath()));
    }
    GroovyClassLoader compileClasspathClassLoader=new GroovyClassLoader(classPathLoader,null);
    GroovySystemLoader compileClasspathLoader=groovySystemLoaderFactory.forClassLoader(classPathLoader);
    FilteringClassLoader.Spec groovyCompilerClassLoaderSpec=new FilteringClassLoader.Spec();
    groovyCompilerClassLoaderSpec.allowPackage("org.codehaus.groovy");
    groovyCompilerClassLoaderSpec.allowPackage("groovy");
    groovyCompilerClassLoaderSpec.disallowClass("groovy.util.GroovyTestCase");
    groovyCompilerClassLoaderSpec.disallowPackage("groovy.servlet");
    FilteringClassLoader groovyCompilerClassLoader=new FilteringClassLoader(GroovyClassLoader.class.getClassLoader(),groovyCompilerClassLoaderSpec);
    final GroovyClassLoader astTransformClassLoader=new GroovyClassLoader(groovyCompilerClassLoader,null);
    for (    File file : spec.getCompileClasspath()) {
      astTransformClassLoader.addClasspath(file.getPath());
    }
    JavaAwareCompilationUnit unit=new JavaAwareCompilationUnit(configuration,compileClasspathClassLoader){
      @Override public GroovyClassLoader getTransformLoader(){
        return astTransformClassLoader;
      }
    }
;
    final boolean shouldProcessAnnotations=shouldProcessAnnotations(spec);
    if (shouldProcessAnnotations) {
      unit.addSources(new File[]{new File("ForceStubGeneration.java")});
    }
    unit.addSources(getSortedSourceFiles(spec));
    unit.setCompilerFactory(new JavaCompilerFactory(){
      @Override public JavaCompiler createCompiler(      final CompilerConfiguration config){
        return new JavaCompiler(){
          @Override public void compile(          List<String> files,          CompilationUnit cu){
            if (shouldProcessAnnotations) {
              spec.setSourceFiles(Iterables.concat(spec.getSourceFiles(),ImmutableFileCollection.of(stubDir).getAsFileTree()));
            }
 else {
              ImmutableList.Builder<File> sourcepathBuilder=ImmutableList.builder();
              sourcepathBuilder.add(stubDir);
              if (spec.getCompileOptions().getSourcepath() != null) {
                sourcepathBuilder.addAll(spec.getCompileOptions().getSourcepath());
              }
              spec.getCompileOptions().setSourcepath(sourcepathBuilder.build());
            }
            spec.setSourceFiles(Iterables.filter(spec.getSourceFiles(),new Predicate<File>(){
              @Override public boolean apply(              File file){
                return hasExtension(file,".java");
              }
            }
));
            try {
              javaCompiler.execute(spec);
            }
 catch (            CompilationFailedException e) {
              cu.getErrorCollector().addFatalError(new SimpleMessage(e.getMessage(),cu));
            }
          }
        }
;
      }
    }
);
    try {
      unit.compile();
      customizer.writeToMappingFile();
    }
 catch (    org.codehaus.groovy.control.CompilationFailedException e) {
      System.err.println(e.getMessage());
      System.err.flush();
      throw new CompilationFailedException();
    }
 finally {
      compilerGroovyLoader.discardTypesFrom(classPathLoader);
      compilerGroovyLoader.discardTypesFrom(astTransformClassLoader);
      compileClasspathLoader.shutdown();
      CompositeStoppable.stoppable(classPathLoader,astTransformClassLoader).stop();
    }
    return WorkResults.didWork(true);
  }
  private static boolean shouldProcessAnnotations(  GroovyJavaJointCompileSpec spec){
    return spec.getGroovyCompileOptions().isJavaAnnotationProcessing() && spec.annotationProcessingConfigured();
  }
  private void applyConfigurationScript(  File configScript,  CompilerConfiguration configuration){
    VersionNumber version=parseGroovyVersion();
    if (version.compareTo(VersionNumber.parse("2.1")) < 0) {
      throw new GradleException("Using a Groovy compiler configuration script requires Groovy 2.1+ but found Groovy " + version + "");
    }
    Binding binding=new Binding();
    binding.setVariable("configuration",configuration);
    CompilerConfiguration configuratorConfig=new CompilerConfiguration();
    ImportCustomizer customizer=new ImportCustomizer();
    customizer.addStaticStars("org.codehaus.groovy.control.customizers.builder.CompilerCustomizationBuilder");
    configuratorConfig.addCompilationCustomizers(customizer);
    GroovyShell shell=new GroovyShell(binding,configuratorConfig);
    try {
      shell.evaluate(configScript);
    }
 catch (    Exception e) {
      throw new GradleException("Could not execute Groovy compiler configuration script: " + configScript.getAbsolutePath(),e);
    }
  }
  private VersionNumber parseGroovyVersion(){
    String version;
    try {
      version=GroovySystem.getVersion();
    }
 catch (    NoSuchMethodError e) {
      try {
        Class<?> ih=Class.forName("org.codehaus.groovy.runtime.InvokerHelper");
        Method getVersion=ih.getDeclaredMethod("getVersion");
        version=(String)getVersion.invoke(ih);
      }
 catch (      Exception e1) {
        throw new GradleException("Unable to determine Groovy version.",e1);
      }
    }
    return VersionNumber.parse(version);
  }
  private void canonicalizeValues(  Map<String,Boolean> options){
    for (    String key : options.keySet()) {
      boolean value=options.get(key);
      options.put(key,value);
    }
  }
  private ClassLoader getExtClassLoader(){
    return ClassLoaderUtils.getPlatformClassLoader();
  }
}
