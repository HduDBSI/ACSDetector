/** 
 * Resolves dependencies to  {@link TransformationNode} objects.
 */
@ServiceScope(Scopes.Build.class) public class TransformationNodeDependencyResolver implements DependencyResolver {
  @Override public boolean resolve(  Task task,  Object node,  Action<? super Node> resolveAction){
    if (node instanceof DefaultTransformationDependency) {
      DefaultTransformationDependency transformation=(DefaultTransformationDependency)node;
      for (      TransformationNode transformationNode : transformation.getNodes()) {
        resolveAction.execute(transformationNode);
      }
      return true;
    }
    return false;
  }
  @Override public boolean attachActionTo(  Node value,  Action<? super Task> action){
    return false;
  }
}
