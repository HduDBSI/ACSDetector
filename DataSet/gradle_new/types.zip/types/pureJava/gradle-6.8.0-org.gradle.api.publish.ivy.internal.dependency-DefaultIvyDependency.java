public class DefaultIvyDependency implements IvyDependencyInternal {
  private final String organisation;
  private final String module;
  private final String revision;
  private final String confMapping;
  private final boolean transitive;
  private final List<DependencyArtifact> artifacts=new ArrayList<DependencyArtifact>();
  private final List<ExcludeRule> excludeRules=new ArrayList<ExcludeRule>();
  private final ImmutableAttributes attributes;
  public DefaultIvyDependency(  String organisation,  String module,  String revision,  String confMapping,  boolean transitive){
    this.organisation=organisation;
    this.module=module;
    this.revision=Strings.nullToEmpty(revision);
    this.confMapping=confMapping;
    this.transitive=transitive;
    this.attributes=ImmutableAttributes.EMPTY;
  }
  public DefaultIvyDependency(  String organisation,  String module,  String revision,  String confMapping,  boolean transitive,  Collection<DependencyArtifact> artifacts){
    this(organisation,module,revision,confMapping,transitive);
    this.artifacts.addAll(artifacts);
  }
  public DefaultIvyDependency(  String organisation,  String module,  String revision,  String confMapping,  boolean transitive,  Collection<DependencyArtifact> artifacts,  Collection<ExcludeRule> excludeRules){
    this(organisation,module,revision,confMapping,transitive,artifacts);
    this.excludeRules.addAll(excludeRules);
  }
  public DefaultIvyDependency(  ExternalDependency dependency,  String confMapping,  ImmutableAttributes attributes){
    this.organisation=dependency.getGroup();
    this.module=dependency.getName();
    this.revision=Strings.nullToEmpty(dependency.getVersion());
    this.confMapping=confMapping;
    this.transitive=dependency.isTransitive();
    this.artifacts.addAll(dependency.getArtifacts());
    this.excludeRules.addAll(dependency.getExcludeRules());
    this.attributes=attributes;
  }
  @Override public String getOrganisation(){
    return organisation;
  }
  @Override public String getModule(){
    return module;
  }
  @Override public String getRevision(){
    return revision;
  }
  @Override public String getConfMapping(){
    return confMapping;
  }
  @Override public boolean isTransitive(){
    return transitive;
  }
  @Override public Iterable<DependencyArtifact> getArtifacts(){
    return artifacts;
  }
  @Override public Iterable<ExcludeRule> getExcludeRules(){
    return excludeRules;
  }
  @Override public ImmutableAttributes getAttributes(){
    return attributes;
  }
  @Override public String getProjectPath(){
    return null;
  }
}
