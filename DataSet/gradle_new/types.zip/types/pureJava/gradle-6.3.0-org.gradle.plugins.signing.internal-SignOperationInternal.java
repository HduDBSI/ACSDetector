public class SignOperationInternal extends SignOperation {
  private final ProjectLayout projectLayout;
  @Inject public SignOperationInternal(  ProjectLayout projectLayout){
    this.projectLayout=projectLayout;
  }
  @Override protected FileCollection toFileCollection(  List<File> files){
    return projectLayout.files(files);
  }
}
