public class WebApplication implements SoftwareComponentInternal {
  private final UsageContext webArchiveUsage=new WebArchiveUsageContext();
  private final PublishArtifact warArtifact;
  private final Usage masterUsage;
  @Inject public WebApplication(  PublishArtifact warArtifact,  Usage masterUsage){
    this.warArtifact=warArtifact;
    this.masterUsage=masterUsage;
  }
  @Override public String getName(){
    return "web";
  }
  @Override public Set<UsageContext> getUsages(){
    return Collections.singleton(webArchiveUsage);
  }
private class WebArchiveUsageContext implements UsageContext {
    @Override public Usage getUsage(){
      return masterUsage;
    }
    @Override public String getName(){
      return masterUsage.getName();
    }
    @Override public AttributeContainer getAttributes(){
      return ImmutableAttributes.EMPTY;
    }
    @Override public Set<PublishArtifact> getArtifacts(){
      return Collections.singleton(warArtifact);
    }
    @Override public Set<ModuleDependency> getDependencies(){
      return Collections.emptySet();
    }
  }
}
