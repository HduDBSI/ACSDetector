/** 
 * A publication is a description of a consumable representation of one or more artifacts, and possibly associated metadata.
 * @since 1.3
 */
public interface Publication extends Named {
  /** 
 * Disables publication of a unique build identifier in Gradle Module Metadata. <p> The build identifier is published by default.
 * @since 6.6
 */
  @Incubating void withoutBuildIdentifier();
  /** 
 * Enables publication of a unique build identifier in Gradle Module Metadata. <p> The build identifier is published by default.
 * @since 6.6
 */
  @Incubating void withBuildIdentifier();
}
