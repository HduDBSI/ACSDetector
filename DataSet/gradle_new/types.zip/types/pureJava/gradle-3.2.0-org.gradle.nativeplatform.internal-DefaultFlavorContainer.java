public class DefaultFlavorContainer extends AbstractNamedDomainObjectContainer<Flavor> implements FlavorContainer {
  public DefaultFlavorContainer(  Instantiator instantiator){
    super(Flavor.class,instantiator);
  }
  @Override protected Flavor doCreate(  String name){
    return getInstantiator().newInstance(DefaultFlavor.class,name);
  }
}
