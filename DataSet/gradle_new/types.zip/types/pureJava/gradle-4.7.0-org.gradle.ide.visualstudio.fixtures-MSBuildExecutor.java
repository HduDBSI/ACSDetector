public class MSBuildExecutor {
  public enum MSBuildAction {  BUILD,   CLEAN;   @Override public String toString(){
    return this.name().toLowerCase();
  }
}
  private final List<String> args=new ArrayList<String>();
  private final AvailableToolChains.InstalledToolChain toolChain;
  private TestFile workingDir;
  private String projectName;
  public MSBuildExecutor(  TestFile workingDir,  AvailableToolChains.InstalledToolChain toolChain){
    this.workingDir=workingDir;
    this.toolChain=toolChain;
  }
  public MSBuildExecutor withWorkingDir(  TestFile workingDir){
    this.workingDir=workingDir;
    return this;
  }
  public MSBuildExecutor withSolution(  SolutionFile visualStudioSolution){
    TestFile solutionFile=new TestFile(visualStudioSolution.getFile());
    solutionFile.assertIsFile();
    return addArguments(solutionFile.getAbsolutePath());
  }
  public MSBuildExecutor withConfiguration(  String configurationName){
    return addArguments("/p:Configuration=" + configurationName);
  }
  public MSBuildExecutor withProject(  String projectName){
    this.projectName=projectName;
    return this;
  }
  public MSBuildExecutor withArgument(  String arg){
    this.args.add(arg);
    return this;
  }
  private MSBuildExecutor addArguments(  String... args){
    this.args.addAll(Arrays.asList(args));
    return this;
  }
  private File getOutputsDir(){
    return workingDir.file("output");
  }
  private void cleanupOutputDir(){
    try {
      FileUtils.deleteDirectory(getOutputsDir());
      getOutputsDir().mkdir();
    }
 catch (    IOException e) {
      throw UncheckedException.throwAsUncheckedException(e);
    }
  }
  private List<ExecutionOutput> getOutputFiles(){
    List<ExecutionOutput> outputFiles=Lists.newArrayList();
    for (    File executionDir : getOutputsDir().listFiles()) {
      if (executionDir.isDirectory()) {
        outputFiles.add(new ExecutionOutput(new File(executionDir,"output.txt"),new File(executionDir,"error.txt")));
      }
    }
    return outputFiles;
  }
  public List<ExecutionResult> succeeds(){
    return succeeds(MSBuildAction.BUILD);
  }
  public List<ExecutionResult> succeeds(  MSBuildAction action){
    cleanupOutputDir();
    List<ExecutionResult> results=Lists.newArrayList();
    withArgument(toTargetArgument(action));
    ExecOutput result=findMSBuild().execute(args,buildEnvironment(workingDir));
    System.out.println(result.getOut());
    for (    ExecutionOutput output : getOutputFiles()) {
      String gradleStdout=fileContents(output.stdout);
      String gradleStderr=fileContents(output.stderr);
      System.out.println(gradleStdout);
      System.out.println(gradleStderr);
      results.add(OutputScrapingExecutionResult.from(trimLines(gradleStdout),trimLines(gradleStderr)));
    }
    System.out.println(result.getError());
    return results;
  }
  public ExecutionFailure fails(){
    return fails(MSBuildAction.BUILD);
  }
  public ExecutionFailure fails(  MSBuildAction action){
    cleanupOutputDir();
    withArgument(toTargetArgument(action));
    ExecOutput result=findMSBuild().execWithFailure(args,buildEnvironment(workingDir));
    List<ExecutionOutput> outputs=getOutputFiles();
    assert outputs.size() == 1;
    String gradleStdout=fileContents(outputs.get(0).stdout);
    String gradleStderr=fileContents(outputs.get(0).stderr);
    System.out.println(result.getOut());
    System.out.println(gradleStdout);
    System.out.println(gradleStderr);
    System.out.println(result.getError());
    return OutputScrapingExecutionFailure.from(trimLines(gradleStdout),trimLines(gradleStderr));
  }
  private static String fileContents(  File file){
    try {
      return FileUtils.readFileToString(file);
    }
 catch (    IOException e) {
      throw UncheckedException.throwAsUncheckedException(e);
    }
  }
  private String trimLines(  String s){
    return s.replaceAll("\r?\n\\s+","\n");
  }
  private String toTargetArgument(  MSBuildAction action){
    String result="";
    if (projectName != null) {
      result=projectName;
    }
    if (!(projectName != null && action == MSBuildAction.BUILD)) {
      if (projectName != null) {
        result+=":";
      }
      result+=action.toString();
    }
    return "/t:" + result;
  }
  private TestFile findMSBuild(){
    return new TestFile(new MSBuildVersionLocator(VisualStudioLocatorTestFixture.getVswhereLocator()).getMSBuildInstall(toolChain));
  }
private static class ExecutionOutput {
    private final File stdout;
    private final File stderr;
    public ExecutionOutput(    File stdout,    File stderr){
      this.stdout=stdout;
      this.stderr=stderr;
    }
  }
}
