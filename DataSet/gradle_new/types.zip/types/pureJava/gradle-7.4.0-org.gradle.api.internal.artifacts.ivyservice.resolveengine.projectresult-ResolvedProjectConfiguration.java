public interface ResolvedProjectConfiguration {
  ProjectComponentIdentifier getId();
  String getTargetConfiguration();
}
