private static class ModuleArtifactsKeySerializer extends AbstractSerializer<ModuleArtifactsKey> {
  private final ComponentIdentifierSerializer identifierSerializer=new ComponentIdentifierSerializer();
  public void write(  Encoder encoder,  ModuleArtifactsKey value) throws Exception {
    encoder.writeString(value.repositoryId);
    identifierSerializer.write(encoder,value.componentId);
    encoder.writeString(value.context);
  }
  public ModuleArtifactsKey read(  Decoder decoder) throws Exception {
    String resolverId=decoder.readString();
    ComponentIdentifier componentId=identifierSerializer.read(decoder);
    String context=decoder.readString();
    return new ModuleArtifactsKey(resolverId,componentId,context);
  }
  @Override public boolean equals(  Object obj){
    if (!super.equals(obj)) {
      return false;
    }
    ModuleArtifactsKeySerializer rhs=(ModuleArtifactsKeySerializer)obj;
    return Objects.equal(identifierSerializer,rhs.identifierSerializer);
  }
  @Override public int hashCode(){
    return Objects.hashCode(super.hashCode(),identifierSerializer);
  }
}
