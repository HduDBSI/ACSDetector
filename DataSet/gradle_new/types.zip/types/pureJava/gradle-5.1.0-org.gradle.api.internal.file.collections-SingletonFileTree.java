/** 
 * A file tree with a single file entry.
 */
public interface SingletonFileTree extends MinimalFileTree {
  File getFile();
  PatternSet getPatterns();
}
