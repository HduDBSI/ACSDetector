public class DefaultPublishingExtension implements PublishingExtension {
  private final RepositoryHandler repositories;
  private final PublicationContainer publications;
  public DefaultPublishingExtension(  RepositoryHandler repositories,  PublicationContainer publications){
    this.repositories=repositories;
    this.publications=publications;
  }
  public RepositoryHandler getRepositories(){
    return repositories;
  }
  public void repositories(  Action<? super RepositoryHandler> configure){
    configure.execute(repositories);
  }
  public PublicationContainer getPublications(){
    return publications;
  }
  public void publications(  Action<? super PublicationContainer> configure){
    configure.execute(publications);
  }
}
