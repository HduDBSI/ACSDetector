public interface JavaToolChainInternal extends JavaToolChain, ToolChainInternal<JavaPlatform> {
}
