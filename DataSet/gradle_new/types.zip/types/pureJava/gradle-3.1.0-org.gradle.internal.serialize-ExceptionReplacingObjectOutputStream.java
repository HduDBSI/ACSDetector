private static class ExceptionReplacingObjectOutputStream extends ObjectOutputStream {
  public ExceptionReplacingObjectOutputStream(  OutputStream outputSteam) throws IOException {
    super(outputSteam);
    enableReplaceObject(true);
  }
  @Override protected Object replaceObject(  Object obj) throws IOException {
    if (obj instanceof Throwable) {
      return new TopLevelExceptionPlaceholder((Throwable)obj);
    }
    return obj;
  }
}
