/** 
 * An event consumer that asynchronously dispatches events to the client.
 */
class DaemonConnectionBackedEventConsumer implements BuildEventConsumer {
  private final DaemonCommandExecution execution;
  private final BlockingQueue<Object> queue=new LinkedBlockingQueue<Object>();
  private final ForwardEvents forwarder=new ForwardEvents();
  public DaemonConnectionBackedEventConsumer(  DaemonCommandExecution execution){
    this.execution=execution;
    forwarder.start();
  }
  @Override public void dispatch(  Object event){
    queue.offer(event);
  }
  public void waitForFinish(){
    forwarder.waitForFinish();
  }
private class ForwardEvents extends Thread {
    private volatile boolean stopped;
    private boolean ableToSend=true;
    @Override public void run(){
      while (moreMessagesToSend()) {
        Object event=getNextEvent();
        if (event != null) {
          dispatchEvent(event);
        }
      }
    }
    private boolean moreMessagesToSend(){
      return ableToSend && !(stopped && queue.isEmpty());
    }
    private Object getNextEvent(){
      try {
        return queue.poll(10,TimeUnit.MILLISECONDS);
      }
 catch (      InterruptedException e) {
        stopped=true;
        return null;
      }
    }
    private void dispatchEvent(    Object event){
      try {
        execution.getConnection().event(event);
      }
 catch (      RuntimeException e) {
        ableToSend=false;
      }
    }
    public void waitForFinish(){
      stopped=true;
      try {
        join();
      }
 catch (      InterruptedException e) {
        Thread.currentThread().interrupt();
      }
    }
  }
}
