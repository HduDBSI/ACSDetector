/** 
 * The result of successfully resolving an artifact.
 * @since 2.0
 */
@Incubating public interface ResolvedArtifactResult extends ArtifactResult {
  /** 
 * The file for the artifact.
 */
  File getFile();
  /** 
 * The variant that included this artifact.
 */
  ResolvedVariantResult getVariant();
}
