public interface WritableArtifactCacheLockingParameters {
  FileAccessTimeJournal getFileAccessTimeJournal();
  UsedGradleVersions getUsedGradleVersions();
}
