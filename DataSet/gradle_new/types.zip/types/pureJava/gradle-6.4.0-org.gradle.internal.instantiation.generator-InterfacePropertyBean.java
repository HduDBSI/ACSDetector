public interface InterfacePropertyBean {
  Property<String> getProp();
}
