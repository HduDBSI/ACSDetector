private static class ResponseSerializer<T> extends AbstractSerializer<Response<T>> {
  private final Serializer<T> payloadSerializer;
  private static <T>ResponseSerializer<T> of(  Serializer<T> payloadSerializer){
    return new ResponseSerializer<T>(payloadSerializer);
  }
  private ResponseSerializer(  Serializer<T> payloadSerializer){
    this.payloadSerializer=payloadSerializer;
  }
  public Response<T> read(  Decoder decoder) throws Exception {
    return new SuccessResponse<T>(payloadSerializer.read(decoder),decoder.readSmallInt(),decoder.readString(),decoder.readNullableString());
  }
  public void write(  Encoder encoder,  Response<T> value) throws Exception {
    T response=value.getResponse();
    payloadSerializer.write(encoder,response);
    encoder.writeSmallInt(value.getStatusCode());
    encoder.writeString(value.getUrl());
    encoder.writeNullableString(value.getClientStatusChecksum());
  }
  @Override public boolean equals(  Object obj){
    if (!super.equals(obj)) {
      return false;
    }
    ResponseSerializer rhs=(ResponseSerializer)obj;
    return Objects.equal(payloadSerializer,rhs.payloadSerializer);
  }
  @Override public int hashCode(){
    return Objects.hashCode(super.hashCode(),payloadSerializer);
  }
}
