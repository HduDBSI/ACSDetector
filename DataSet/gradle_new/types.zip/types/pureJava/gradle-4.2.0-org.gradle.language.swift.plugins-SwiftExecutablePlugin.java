/** 
 * <p>A plugin that produces an executable from Swift source.</p> <p>Adds compile, link and install tasks to build the executable. Defaults to looking for source files in `src/main/swift`.</p> <p>Adds a  {@link SwiftComponent} extension to the project to allow configuration of the executable.</p>
 * @since 4.1
 */
@Incubating public class SwiftExecutablePlugin implements Plugin<ProjectInternal> {
  private final FileOperations fileOperations;
  /** 
 * Injects a  {@link FileOperations} instance.
 * @since 4.2
 */
  @Inject public SwiftExecutablePlugin(  FileOperations fileOperations){
    this.fileOperations=fileOperations;
  }
  @Override public void apply(  final ProjectInternal project){
    project.getPluginManager().apply(SwiftBasePlugin.class);
    final DirectoryVar buildDirectory=project.getLayout().getBuildDirectory();
    ProviderFactory providers=project.getProviders();
    ConfigurationContainer configurations=project.getConfigurations();
    TaskContainer tasks=project.getTasks();
    SwiftApplication application=project.getExtensions().create(SwiftApplication.class,"executable",DefaultSwiftApplication.class,"main",project.getObjects(),fileOperations,providers,configurations);
    project.getComponents().add(application);
    project.getComponents().add(application.getDebugExecutable());
    project.getComponents().add(application.getReleaseExecutable());
    final PropertyState<String> module=application.getModule();
    module.set(GUtil.toCamelCase(project.getName()));
    SwiftCompile compile=(SwiftCompile)tasks.getByName("compileDebugSwift");
    compile.setCompilerArgs(Lists.newArrayList("-g","-enable-testing"));
    LinkExecutable link=(LinkExecutable)tasks.getByName("linkDebug");
    final InstallExecutable install=tasks.create("installMain",InstallExecutable.class);
    install.setPlatform(link.getTargetPlatform());
    install.setToolChain(link.getToolChain());
    install.setDestinationDir(buildDirectory.dir(providers.provider(new Callable<CharSequence>(){
      @Override public String call(){
        return "install/" + module.get();
      }
    }
)));
    install.setExecutable(link.getBinaryFile());
    install.onlyIf(new Spec<Task>(){
      @Override public boolean isSatisfiedBy(      Task element){
        return install.getExecutable().exists();
      }
    }
);
    install.lib(application.getDebugExecutable().getRuntimeLibraries());
    tasks.getByName(LifecycleBasePlugin.ASSEMBLE_TASK_NAME).dependsOn(install);
  }
}
