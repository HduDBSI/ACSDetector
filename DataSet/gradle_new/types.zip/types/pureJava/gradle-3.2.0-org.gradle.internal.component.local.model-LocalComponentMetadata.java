public interface LocalComponentMetadata extends ComponentResolveMetadata {
}
