/** 
 * A  {@link ResolvedGraphComponent} that is used during the resolution of the dependency graph.Additional fields in this interface are not required to reconstitute the serialized graph.
 */
public interface DependencyGraphComponent extends ResolvedGraphComponent {
  /** 
 * Returns the meta-data for the component. Resolves if not already resolved.
 * @return null if the meta-data is not available due to some failure.
 */
  @Nullable ComponentResolveMetadata getMetadata();
  Collection<? extends DependencyGraphComponent> getDependents();
  /** 
 * Returns all versions that were seen for this component during resolution.
 */
  Collection<? extends ModuleVersionIdentifier> getAllVersions();
}
