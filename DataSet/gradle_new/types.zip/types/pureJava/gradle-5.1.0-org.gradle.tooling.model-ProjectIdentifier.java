/** 
 * Identifies a Gradle project. <p> A Gradle Project is a project in a multi-project Gradle build or a single "standalone" project. </p>
 * @since 2.13
 */
public interface ProjectIdentifier extends Model {
  /** 
 * The path of the project, relative to its build.
 * @return the path, never null
 * @since 3.3
 */
  String getProjectPath();
  /** 
 * Identifier of the build this project is a member of.
 * @return build identifier, never null.
 */
  BuildIdentifier getBuildIdentifier();
}
