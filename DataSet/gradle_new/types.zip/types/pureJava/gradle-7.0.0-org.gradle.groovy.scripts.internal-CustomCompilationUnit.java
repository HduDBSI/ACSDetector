@SuppressWarnings("deprecation") class CustomCompilationUnit extends CompilationUnit {
  public CustomCompilationUnit(  CompilerConfiguration compilerConfiguration,  CodeSource codeSource,  final Action<? super ClassNode> customVerifier,  GroovyClassLoader groovyClassLoader,  Map<String,List<String>> simpleNameToFQN){
    super(compilerConfiguration,codeSource,groovyClassLoader);
    this.resolveVisitor=new GradleResolveVisitor(this,simpleNameToFQN);
    installCustomCodegen(customVerifier);
  }
  private void installCustomCodegen(  Action<? super ClassNode> customVerifier){
    final IPrimaryClassNodeOperation nodeOperation=prepareCustomCodegen(customVerifier);
    addFirstPhaseOperation(nodeOperation,Phases.CLASS_GENERATION);
  }
  @Override public void addPhaseOperation(  IPrimaryClassNodeOperation op,  int phase){
    if (phase != Phases.CLASS_GENERATION) {
      super.addPhaseOperation(op,phase);
    }
  }
  private IPrimaryClassNodeOperation prepareCustomCodegen(  Action<? super ClassNode> customVerifier){
    try {
      final Field classgen=getClassgenField();
      IPrimaryClassNodeOperation realClassgen=(IPrimaryClassNodeOperation)classgen.get(this);
      final IPrimaryClassNodeOperation decoratedClassgen=decoratedNodeOperation(customVerifier,realClassgen);
      classgen.set(this,decoratedClassgen);
      return decoratedClassgen;
    }
 catch (    ReflectiveOperationException e) {
      throw new GradleException("Unable to install custom rules code generation",e);
    }
  }
  private Field getClassgenField(){
    try {
      final Field classgen=CompilationUnit.class.getDeclaredField("classgen");
      classgen.setAccessible(true);
      return classgen;
    }
 catch (    NoSuchFieldException e) {
      throw new GradleException("Unable to detect class generation in Groovy CompilationUnit",e);
    }
  }
  private static IPrimaryClassNodeOperation decoratedNodeOperation(  Action<? super ClassNode> customVerifier,  IPrimaryClassNodeOperation realClassgen){
    return new IPrimaryClassNodeOperation(){
      @Override public boolean needSortedInput(){
        return realClassgen.needSortedInput();
      }
      @Override public void call(      SourceUnit source,      GeneratorContext context,      ClassNode classNode) throws CompilationFailedException {
        customVerifier.execute(classNode);
        realClassgen.call(source,context,classNode);
      }
    }
;
  }
}
