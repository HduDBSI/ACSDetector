private static class SourceIncludesSerializer extends AbstractSerializer<IncludeDirectives> {
  private final Serializer<Include> includeSerializer=new IncludeSerializer();
  private final ListSerializer<Include> includeListSerializer=new ListSerializer<Include>(includeSerializer);
  @Override public IncludeDirectives read(  Decoder decoder) throws Exception {
    return new DefaultIncludeDirectives(includeListSerializer.read(decoder));
  }
  @Override public void write(  Encoder encoder,  IncludeDirectives value) throws Exception {
    includeListSerializer.write(encoder,value.getIncludesAndImports());
  }
  @Override public boolean equals(  Object obj){
    if (!super.equals(obj)) {
      return false;
    }
    SourceIncludesSerializer rhs=(SourceIncludesSerializer)obj;
    return Objects.equal(includeSerializer,rhs.includeSerializer) && Objects.equal(includeListSerializer,rhs.includeListSerializer);
  }
  @Override public int hashCode(){
    return Objects.hashCode(super.hashCode(),includeSerializer,includeListSerializer);
  }
}
