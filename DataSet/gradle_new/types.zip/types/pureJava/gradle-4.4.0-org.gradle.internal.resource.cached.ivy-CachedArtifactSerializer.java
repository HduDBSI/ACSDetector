private static class CachedArtifactSerializer implements Serializer<CachedArtifact> {
  public void write(  Encoder encoder,  CachedArtifact value) throws Exception {
    encoder.writeBoolean(value.isMissing());
    encoder.writeLong(value.getCachedAt());
    byte[] hash=value.getDescriptorHash().toByteArray();
    encoder.writeBinary(hash);
    if (!value.isMissing()) {
      encoder.writeString(value.getCachedFile().getPath());
    }
 else {
      encoder.writeSmallInt(value.attemptedLocations().size());
      for (      String location : value.attemptedLocations()) {
        encoder.writeString(location);
      }
    }
  }
  public CachedArtifact read(  Decoder decoder) throws Exception {
    boolean isMissing=decoder.readBoolean();
    long createTimestamp=decoder.readLong();
    byte[] encodedHash=decoder.readBinary();
    BigInteger hash=new BigInteger(encodedHash);
    if (!isMissing) {
      File file=new File(decoder.readString());
      return new DefaultCachedArtifact(file,createTimestamp,hash);
    }
 else {
      int size=decoder.readSmallInt();
      List<String> attempted=new ArrayList<String>(size);
      for (int i=0; i < size; i++) {
        attempted.add(decoder.readString());
      }
      return new DefaultCachedArtifact(attempted,createTimestamp,hash);
    }
  }
}
