public class DefaultBuildableComponentResolveResult extends DefaultResourceAwareResolveResult implements BuildableComponentResolveResult {
  private ComponentResolveMetadata metaData;
  private ModuleVersionResolveException failure;
  public DefaultBuildableComponentResolveResult failed(  ModuleVersionResolveException failure){
    metaData=null;
    this.failure=failure;
    return this;
  }
  @Override public void notFound(  ModuleComponentIdentifier versionIdentifier){
    failed(new ModuleVersionNotFoundException(DefaultModuleVersionIdentifier.newId(versionIdentifier),getAttempted()));
  }
  public void resolved(  ComponentResolveMetadata metaData){
    this.metaData=metaData;
  }
  public void setMetaData(  ComponentResolveMetadata metaData){
    assertResolved();
    this.metaData=metaData;
  }
  public ModuleVersionIdentifier getId() throws ModuleVersionResolveException {
    assertResolved();
    return metaData.getId();
  }
  public ComponentResolveMetadata getMetaData() throws ModuleVersionResolveException {
    assertResolved();
    return metaData;
  }
  public ModuleVersionResolveException getFailure(){
    assertHasResult();
    return failure;
  }
  private void assertResolved(){
    assertHasResult();
    if (failure != null) {
      throw failure;
    }
  }
  private void assertHasResult(){
    if (!hasResult()) {
      throw new IllegalStateException("No result has been specified.");
    }
  }
  public boolean hasResult(){
    return failure != null || metaData != null;
  }
  public void applyTo(  BuildableComponentIdResolveResult idResolve){
    super.applyTo(idResolve);
    if (failure != null) {
      idResolve.failed(failure);
    }
    if (metaData != null) {
      idResolve.resolved(metaData);
    }
  }
}
