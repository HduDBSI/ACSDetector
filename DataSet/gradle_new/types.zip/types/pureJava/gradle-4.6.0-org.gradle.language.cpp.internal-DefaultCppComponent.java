public abstract class DefaultCppComponent extends DefaultNativeComponent implements CppComponent, ComponentWithNames {
  private final FileCollection cppSource;
  private final String name;
  private final FileOperations fileOperations;
  private final ConfigurableFileCollection privateHeaders;
  private final FileCollection privateHeadersWithConvention;
  private final Property<String> baseName;
  private final Names names;
  private final DefaultBinaryCollection<CppBinary> binaries;
  @Inject public DefaultCppComponent(  String name,  FileOperations fileOperations,  ObjectFactory objectFactory){
    super(fileOperations);
    this.name=name;
    this.fileOperations=fileOperations;
    cppSource=createSourceView("src/" + name + "/cpp",Arrays.asList("cpp","c++","cc"));
    privateHeaders=fileOperations.files();
    privateHeadersWithConvention=createDirView(privateHeaders,"src/" + name + "/headers");
    baseName=objectFactory.property(String.class);
    names=Names.of(name);
    binaries=Cast.uncheckedCast(objectFactory.newInstance(DefaultBinaryCollection.class,CppBinary.class));
  }
  @Override public Names getNames(){
    return names;
  }
  @Override public String getName(){
    return name;
  }
  protected FileCollection createDirView(  final ConfigurableFileCollection dirs,  final String conventionLocation){
    return fileOperations.files(new Callable<Object>(){
      @Override public Object call() throws Exception {
        if (dirs.getFrom().isEmpty()) {
          return fileOperations.files(conventionLocation);
        }
        return dirs;
      }
    }
);
  }
  @Override public Property<String> getBaseName(){
    return baseName;
  }
  @Override public FileCollection getCppSource(){
    return cppSource;
  }
  @Override public ConfigurableFileCollection getPrivateHeaders(){
    return privateHeaders;
  }
  @Override public void privateHeaders(  Action<? super ConfigurableFileCollection> action){
    action.execute(privateHeaders);
  }
  @Override public FileCollection getPrivateHeaderDirs(){
    return privateHeadersWithConvention;
  }
  @Override public FileTree getHeaderFiles(){
    return getAllHeaderDirs().getAsFileTree().matching(new PatternSet().include("**/*.h"));
  }
  public FileCollection getAllHeaderDirs(){
    return privateHeadersWithConvention;
  }
  @Override public DefaultBinaryCollection<CppBinary> getBinaries(){
    return binaries;
  }
}
