/** 
 * Collects all artifacts and their build dependencies.
 */
public class DefaultResolvedArtifactsBuilder implements DependencyArtifactsVisitor {
  private final boolean buildProjectDependencies;
  private final Map<Long,ArtifactSet> artifactSets=newLinkedHashMap();
  private final Set<Long> buildableArtifactSets=new HashSet<Long>();
  public DefaultResolvedArtifactsBuilder(  boolean buildProjectDependencies){
    this.buildProjectDependencies=buildProjectDependencies;
  }
  @Override public void visitArtifacts(  DependencyGraphNode from,  DependencyGraphNode to,  ArtifactSet artifacts){
    artifactSets.put(artifacts.getId(),artifacts);
    if (!buildProjectDependencies) {
      return;
    }
    if (buildableArtifactSets.contains(artifacts.getId())) {
      return;
    }
    ConfigurationMetadata configurationMetadata=to.getMetadata();
    if (!(configurationMetadata instanceof LocalConfigurationMetadata)) {
      return;
    }
    if (from.getOwner().getComponentId() instanceof ProjectComponentIdentifier) {
      ProjectComponentIdentifier incomingId=(ProjectComponentIdentifier)from.getOwner().getComponentId();
      if (!incomingId.getBuild().isCurrentBuild()) {
        return;
      }
    }
    buildableArtifactSets.add(artifacts.getId());
  }
  @Override public void finishArtifacts(){
  }
  public VisitedArtifactsResults complete(){
    Map<Long,ArtifactSet> artifactsById=newLinkedHashMap();
    for (    Map.Entry<Long,ArtifactSet> entry : artifactSets.entrySet()) {
      ArtifactSet resolvedArtifacts=entry.getValue().snapshot();
      artifactsById.put(entry.getKey(),resolvedArtifacts);
    }
    return new DefaultResolvedArtifactResults(artifactsById,buildableArtifactSets);
  }
}
