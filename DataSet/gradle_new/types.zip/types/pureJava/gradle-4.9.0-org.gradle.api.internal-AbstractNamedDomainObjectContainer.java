public abstract class AbstractNamedDomainObjectContainer<T> extends DefaultNamedDomainObjectSet<T> implements NamedDomainObjectContainer<T>, HasPublicType {
  protected AbstractNamedDomainObjectContainer(  Class<T> type,  Instantiator instantiator,  Namer<? super T> namer){
    super(type,instantiator,namer);
  }
  protected AbstractNamedDomainObjectContainer(  Class<T> type,  Instantiator instantiator){
    super(type,instantiator,Named.Namer.forType(type));
  }
  /** 
 * Subclasses need only implement this method as the creation strategy.
 */
  protected abstract T doCreate(  String name);
  public T create(  String name){
    return create(name,Actions.doNothing());
  }
  public T maybeCreate(  String name){
    T item=findByName(name);
    if (item != null) {
      return item;
    }
    return create(name);
  }
  public T create(  String name,  Closure configureClosure){
    return create(name,ConfigureUtil.configureUsing(configureClosure));
  }
  public T create(  String name,  Action<? super T> configureAction) throws InvalidUserDataException {
    assertCanAdd(name);
    T object=doCreate(name);
    add(object);
    configureAction.execute(object);
    return object;
  }
  protected ConfigureDelegate createConfigureDelegate(  Closure configureClosure){
    return new NamedDomainObjectContainerConfigureDelegate(configureClosure,this);
  }
  public AbstractNamedDomainObjectContainer<T> configure(  Closure configureClosure){
    ConfigureDelegate delegate=createConfigureDelegate(configureClosure);
    ConfigureUtil.configureSelf(configureClosure,this,delegate);
    return this;
  }
  public String getDisplayName(){
    return getTypeDisplayName() + " container";
  }
  @Override public TypeOf<?> getPublicType(){
    return parameterizedTypeOf(new TypeOf<NamedDomainObjectContainer<?>>(){
    }
,typeOf(getType()));
  }
}
