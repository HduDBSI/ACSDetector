/** 
 * A dependency declared as part of an  {@link MavenPublication}.
 */
@Incubating @HasInternalProtocol public interface MavenDependency {
  /** 
 * The groupId value for this dependency.
 */
  String getGroupId();
  /** 
 * The artifactId value for this dependency.
 */
  String getArtifactId();
  /** 
 * The version value for this dependency.
 */
  String getVersion();
}
