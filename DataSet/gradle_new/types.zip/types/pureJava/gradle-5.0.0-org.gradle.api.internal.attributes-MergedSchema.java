private class MergedSchema implements AttributeSelectionSchema {
  private final AttributesSchemaInternal producerSchema;
  MergedSchema(  AttributesSchemaInternal producerSchema){
    this.producerSchema=producerSchema;
  }
  @Override public boolean hasAttribute(  Attribute<?> attribute){
    return DefaultAttributesSchema.this.getAttributes().contains(attribute) || producerSchema.getAttributes().contains(attribute);
  }
  @Override public Set<Object> disambiguate(  Attribute<?> attribute,  Object requested,  Set<Object> candidates){
    DefaultMultipleCandidateResult<Object> result=null;
    DisambiguationRule<Object> rules=disambiguationRules(attribute);
    if (rules.doesSomething()) {
      result=new DefaultMultipleCandidateResult<Object>(requested,candidates);
      rules.execute(result);
      if (result.hasResult()) {
        return result.getMatches();
      }
    }
    rules=producerSchema.disambiguationRules(attribute);
    if (rules.doesSomething()) {
      if (result == null) {
        result=new DefaultMultipleCandidateResult<Object>(requested,candidates);
      }
      rules.execute(result);
      if (result.hasResult()) {
        return result.getMatches();
      }
    }
    if (requested != null && candidates.contains(requested)) {
      return Collections.singleton(requested);
    }
    return candidates;
  }
  @Override public boolean matchValue(  Attribute<?> attribute,  Object requested,  Object candidate){
    if (requested.equals(candidate)) {
      return true;
    }
    CompatibilityCheckResult<Object> result=null;
    CompatibilityRule<Object> rules=compatibilityRules(attribute);
    if (rules.doesSomething()) {
      result=new DefaultCompatibilityCheckResult<Object>(requested,candidate);
      rules.execute(result);
      if (result.hasResult()) {
        return result.isCompatible();
      }
    }
    rules=producerSchema.compatibilityRules(attribute);
    if (rules.doesSomething()) {
      if (result == null) {
        result=new DefaultCompatibilityCheckResult<Object>(requested,candidate);
      }
      rules.execute(result);
      if (result.hasResult()) {
        return result.isCompatible();
      }
    }
    return false;
  }
  @Override public Attribute<?> getAttribute(  String name){
    Attribute<?> attribute=attributesByName.get(name);
    if (attribute != null) {
      return attribute;
    }
    if (producerSchema instanceof DefaultAttributesSchema) {
      return ((DefaultAttributesSchema)producerSchema).attributesByName.get(name);
    }
    for (    Attribute<?> producerAttribute : producerSchema.getAttributes()) {
      if (producerAttribute.getName().equals(name)) {
        return producerAttribute;
      }
    }
    return null;
  }
  @Override public Attribute<?>[] collectExtraAttributes(  ImmutableAttributes[] candidateAttributeSets,  ImmutableAttributes requested){
    ExtraAttributesEntry entry=new ExtraAttributesEntry(candidateAttributeSets,requested);
    Attribute<?>[] attributes=extraAttributesCache.get(entry);
    if (attributes == null) {
      attributes=AttributeSelectionUtils.collectExtraAttributes(this,candidateAttributeSets,requested);
      extraAttributesCache.put(entry,attributes);
    }
    return attributes;
  }
  @Override public boolean equals(  Object o){
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    MergedSchema that=(MergedSchema)o;
    return producerSchema.equals(that.producerSchema);
  }
  @Override public int hashCode(){
    return Objects.hashCode(producerSchema);
  }
}
