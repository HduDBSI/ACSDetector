public class DefaultBuildableComponentSelectionResult implements BuildableComponentSelectionResult {
  private State state=State.Unknown;
  private ModuleComponentIdentifier moduleComponentIdentifier;
  private ModuleVersionResolveException failure;
  private final Set<String> unmatchedVersions=new LinkedHashSet<String>();
  private final Set<String> rejectedVersions=new LinkedHashSet<String>();
  public void matches(  ModuleComponentIdentifier moduleComponentIdentifier){
    setChosenComponentWithReason(State.Match,moduleComponentIdentifier);
  }
  public void noMatchFound(){
    setChosenComponentWithReason(State.NoMatch,null);
  }
  private void setChosenComponentWithReason(  State state,  ModuleComponentIdentifier moduleComponentIdentifier){
    this.state=state;
    this.moduleComponentIdentifier=moduleComponentIdentifier;
    this.failure=null;
  }
  public State getState(){
    return state;
  }
  public ModuleComponentIdentifier getMatch(){
    if (state != State.Match) {
      throw new IllegalStateException("This result has not been resolved.");
    }
    return moduleComponentIdentifier;
  }
  @Override public boolean hasResult(){
    return state != State.Unknown;
  }
  @Nullable @Override public ModuleVersionResolveException getFailure(){
    if (state == State.Unknown) {
      throw new IllegalStateException("This result has not been resolved.");
    }
    return failure;
  }
  @Override public void failed(  ModuleVersionResolveException failure){
    this.moduleComponentIdentifier=null;
    this.failure=failure;
    this.state=State.Failed;
  }
  public Set<String> getUnmatchedVersions(){
    return unmatchedVersions;
  }
  @Override public void notMatched(  String candidateVersion){
    unmatchedVersions.add(candidateVersion);
  }
  public Set<String> getRejectedVersions(){
    return rejectedVersions;
  }
  @Override public void rejected(  String version){
    rejectedVersions.add(version);
  }
}
