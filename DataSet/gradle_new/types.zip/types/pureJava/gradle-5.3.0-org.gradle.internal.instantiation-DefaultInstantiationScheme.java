class DefaultInstantiationScheme implements InstantiationScheme {
  private final DependencyInjectingInstantiator instantiator;
  private final ConstructorSelector constructorSelector;
  private final Set<Class<? extends Annotation>> injectionAnnotations;
  public DefaultInstantiationScheme(  ConstructorSelector constructorSelector,  ServiceRegistry defaultServices,  Set<Class<? extends Annotation>> injectionAnnotations){
    this.constructorSelector=constructorSelector;
    this.injectionAnnotations=injectionAnnotations;
    this.instantiator=new DependencyInjectingInstantiator(constructorSelector,defaultServices);
  }
  @Override public Set<Class<? extends Annotation>> getInjectionAnnotations(){
    return injectionAnnotations;
  }
  @Override public <T>InstanceFactory<T> forType(  Class<T> type){
    return instantiator.factoryFor(type);
  }
  @Override public Instantiator withServices(  ServiceLookup services){
    return new DependencyInjectingInstantiator(constructorSelector,services);
  }
  @Override public Instantiator instantiator(){
    return instantiator;
  }
}
