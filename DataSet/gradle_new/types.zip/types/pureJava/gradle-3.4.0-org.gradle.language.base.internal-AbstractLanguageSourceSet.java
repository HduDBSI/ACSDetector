public abstract class AbstractLanguageSourceSet extends AbstractBuildableComponentSpec implements LanguageSourceSetInternal {
  private final static Map<String,String> LANGUAGES=Maps.newHashMap();
  private final SourceDirectorySet source;
  private boolean generated;
  private Task generatorTask;
  public AbstractLanguageSourceSet(  ComponentSpecIdentifier identifier,  Class<? extends BuildableComponentSpec> publicType,  SourceDirectorySet source){
    super(identifier,publicType);
    this.source=source;
    super.builtBy(source.getBuildDependencies());
  }
  protected String getLanguageName(){
    return guessLanguageName(getTypeName());
  }
  private static synchronized String guessLanguageName(  String typeName){
    String language=LANGUAGES.get(typeName);
    if (language != null) {
      return language;
    }
    language=typeName.replaceAll("LanguageSourceSet$","").replaceAll("SourceSet$","").replaceAll("Source$","").replaceAll("Set$","");
    LANGUAGES.put(typeName,language);
    return language;
  }
  @Override public String getProjectScopedName(){
    return getIdentifier().getProjectScopedName();
  }
  @Override public void builtBy(  Object... tasks){
    generated=true;
    super.builtBy(tasks);
  }
  @Override public void generatedBy(  Task generatorTask){
    this.generatorTask=generatorTask;
  }
  @Override public Task getGeneratorTask(){
    return generatorTask;
  }
  @Override public boolean getMayHaveSources(){
    return generated || !source.isEmpty();
  }
  @Override public String getDisplayName(){
    String languageName=getLanguageName();
    if (languageName.toLowerCase().endsWith("resources")) {
      return languageName + " '" + getIdentifier().getPath()+ "'";
    }
    return languageName + " source '" + getIdentifier().getPath()+ "'";
  }
  @Override public SourceDirectorySet getSource(){
    return source;
  }
  @Override public String getParentName(){
    return getIdentifier().getParent() == null ? null : getIdentifier().getParent().getName();
  }
}
