private static class CachingProvider implements Provider {
  private static final Object ABSENT=new Object();
  private final ConcurrentMap<Object,Object> seen=new ConcurrentHashMap<Object,Object>();
  private final ConcurrentMap<Class<?>,List<ServiceProvider>> allServicesCache=new ConcurrentHashMap<Class<?>,List<ServiceProvider>>();
  private final Map<Class<?>,Boolean> serviceTypes=new ConcurrentHashMap<Class<?>,Boolean>();
  private final Provider delegate;
  private CachingProvider(  Provider delegate){
    this.delegate=delegate;
  }
  private static Provider of(  Provider delegate){
    if (delegate instanceof CachingProvider) {
      return delegate;
    }
    return new CachingProvider(delegate);
  }
  @Override public ServiceProvider getService(  LookupContext context,  TypeSpec serviceType){
    Object cached=seen.get(serviceType);
    if (cached != null) {
      return cached == ABSENT ? null : (ServiceProvider)cached;
    }
    ServiceProvider service=delegate.getService(context,serviceType);
    return cacheServiceProvider(serviceType,service);
  }
  private ServiceProvider cacheServiceProvider(  Object key,  ServiceProvider service){
    seen.putIfAbsent(key,service == null ? ABSENT : service);
    return service;
  }
  @Override public ServiceProvider getFactory(  LookupContext context,  Class<?> type){
    Object cached=seen.get(type);
    if (cached != null) {
      return cached == ABSENT ? null : (ServiceProvider)cached;
    }
    ServiceProvider service=delegate.getFactory(context,type);
    return cacheServiceProvider(type,service);
  }
  @Override public void getAll(  LookupContext context,  Class<?> serviceType,  List<ServiceProvider> result){
    List<ServiceProvider> services=allServicesCache.get(serviceType);
    if (services != null) {
      result.addAll(services);
      return;
    }
    ArrayList<ServiceProvider> tmp=new ArrayList<ServiceProvider>();
    delegate.getAll(context,serviceType,tmp);
    allServicesCache.putIfAbsent(serviceType,tmp);
    if (!tmp.isEmpty()) {
      result.addAll(tmp);
    }
  }
  @Override public boolean hasService(  Class<?> type){
    Boolean val=serviceTypes.get(type);
    if (val != null) {
      return val;
    }
    val=delegate.hasService(type);
    serviceTypes.put(type,val);
    return val;
  }
  @Override public void stop(){
    delegate.stop();
    seen.clear();
    allServicesCache.clear();
  }
}
