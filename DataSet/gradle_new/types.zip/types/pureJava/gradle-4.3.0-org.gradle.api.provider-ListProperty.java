/** 
 * Represents a property whose type is a  {@link List} of elements of type {@link T}. <p><b>Note:</b> This interface is not intended for implementation by build script or plugin authors. An instance of this class can be created through the factory method  {@link org.gradle.api.model.ObjectFactory#listProperty(Class)}.
 * @param < T > the type of elements.
 * @since 4.3
 */
@Incubating public interface ListProperty<T> extends Property<List<T>> {
}
