public class FileChange implements TaskStateChange, InputFileDetails {
  private final String path;
  private final ChangeType change;
  private final String fileType;
  public FileChange(  String path,  ChangeType change,  String fileType){
    this.path=path;
    this.change=change;
    this.fileType=fileType;
  }
  public String getMessage(){
    return fileType + " file " + path+ " "+ change.describe()+ ".";
  }
  @Override public String toString(){
    return getMessage();
  }
  public String getPath(){
    return path;
  }
  public File getFile(){
    return new File(path);
  }
  public ChangeType getType(){
    return change;
  }
  public boolean isAdded(){
    return change == ChangeType.ADDED;
  }
  public boolean isModified(){
    return change == ChangeType.MODIFIED;
  }
  public boolean isRemoved(){
    return change == ChangeType.REMOVED;
  }
  @Override public boolean equals(  Object o){
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    FileChange that=(FileChange)o;
    return Objects.equal(path,that.path) && change == that.change && Objects.equal(fileType,that.fileType);
  }
  @Override public int hashCode(){
    return Objects.hashCode(path,change,fileType);
  }
}
