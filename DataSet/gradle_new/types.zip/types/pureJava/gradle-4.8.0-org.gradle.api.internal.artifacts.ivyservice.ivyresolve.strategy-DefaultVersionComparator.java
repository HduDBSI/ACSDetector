/** 
 * This comparator considers `1.1.1 == 1-1-1`.
 * @see StaticVersionComparator
 */
public class DefaultVersionComparator implements VersionComparator {
  private final Comparator<Version> baseComparator=new StaticVersionComparator();
  public int compare(  Versioned element1,  Versioned element2){
    Version version1=element1.getVersion();
    Version version2=element2.getVersion();
    return baseComparator.compare(version1,version2);
  }
  @Override public Comparator<Version> asVersionComparator(){
    return baseComparator;
  }
}
