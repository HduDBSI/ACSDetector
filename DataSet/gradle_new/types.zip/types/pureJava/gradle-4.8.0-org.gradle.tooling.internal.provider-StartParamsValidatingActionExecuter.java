/** 
 * Validates certain aspects of the start parameters, prior to starting a session using the parameters.
 */
public class StartParamsValidatingActionExecuter implements BuildExecuter {
  private final BuildExecuter delegate;
  public StartParamsValidatingActionExecuter(  BuildExecuter delegate){
    this.delegate=delegate;
  }
  @Override public Object execute(  BuildAction action,  BuildRequestContext requestContext,  BuildActionParameters actionParameters,  ServiceRegistry contextServices){
    StartParameter startParameter=action.getStartParameter();
    if (startParameter.getBuildFile() != null) {
      validateIsFileAndExists(startParameter.getBuildFile(),"build file");
    }
    if (startParameter.getProjectDir() != null) {
      if (!startParameter.getProjectDir().isDirectory()) {
        if (!startParameter.getProjectDir().exists()) {
          throw new IllegalArgumentException(String.format("The specified project directory '%s' does not exist.",startParameter.getProjectDir()));
        }
        throw new IllegalArgumentException(String.format("The specified project directory '%s' is not a directory.",startParameter.getProjectDir()));
      }
    }
    if (startParameter.getSettingsFile() != null) {
      validateIsFileAndExists(startParameter.getSettingsFile(),"settings file");
    }
    for (    File initScript : startParameter.getInitScripts()) {
      validateIsFileAndExists(initScript,"initialization script");
    }
    return delegate.execute(action,requestContext,actionParameters,contextServices);
  }
  private static void validateIsFileAndExists(  File file,  String fileType){
    if (!file.isFile()) {
      if (!file.exists()) {
        throw new IllegalArgumentException(String.format("The specified %s '%s' does not exist.",fileType,file));
      }
      throw new IllegalArgumentException(String.format("The specified %s '%s' is not a file.",fileType,file));
    }
  }
}
