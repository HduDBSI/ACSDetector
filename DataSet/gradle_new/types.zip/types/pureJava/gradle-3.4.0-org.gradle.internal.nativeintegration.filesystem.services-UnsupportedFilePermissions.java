public class UnsupportedFilePermissions implements FileModeAccessor, FileModeMutator {
  private static final Logger LOGGER=LoggerFactory.getLogger(UnsupportedFilePermissions.class);
  private final AtomicBoolean warned=new AtomicBoolean();
  private final FallbackStat stat=new FallbackStat();
  private final EmptyChmod chmod=new EmptyChmod();
  @Override public int getUnixMode(  File f) throws IOException {
    maybeWarn();
    return stat.getUnixMode(f);
  }
  @Override public void chmod(  File file,  int mode) throws Exception {
    maybeWarn();
    chmod.chmod(file,mode);
  }
  private void maybeWarn(){
    if (warned.compareAndSet(false,true)) {
      LOGGER.warn("Support for reading or changing file permissions is only available on this platform using Java 7 or later.");
    }
  }
}
