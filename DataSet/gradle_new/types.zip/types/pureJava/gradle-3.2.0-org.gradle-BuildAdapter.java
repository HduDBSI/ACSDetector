/** 
 * A  {@link BuildListener} adapter class for receiving build events. The methods in this class are empty. This classexists as convenience for creating listener objects.
 */
public class BuildAdapter implements BuildListener {
  public void buildStarted(  Gradle gradle){
  }
  public void settingsEvaluated(  Settings settings){
  }
  public void projectsLoaded(  Gradle gradle){
  }
  public void projectsEvaluated(  Gradle gradle){
  }
  public void buildFinished(  BuildResult result){
  }
}
