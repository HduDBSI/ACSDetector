private static class DefaultComponentSelectionReason implements ComponentSelectionReason {
  private final boolean forced;
  private final boolean conflictResolution;
  private final boolean selectedByRule;
  private final boolean expected;
  private final String description;
  private DefaultComponentSelectionReason(  boolean forced,  boolean conflictResolution,  boolean selectedByRule,  boolean expected,  String description){
    this.forced=forced;
    this.conflictResolution=conflictResolution;
    this.selectedByRule=selectedByRule;
    this.expected=expected;
    assert description != null;
    this.description=description;
  }
  public boolean isForced(){
    return forced;
  }
  public boolean isConflictResolution(){
    return conflictResolution;
  }
  public boolean isSelectedByRule(){
    return selectedByRule;
  }
  public boolean isExpected(){
    return expected;
  }
  public String getDescription(){
    return description;
  }
  public String toString(){
    return description;
  }
}
