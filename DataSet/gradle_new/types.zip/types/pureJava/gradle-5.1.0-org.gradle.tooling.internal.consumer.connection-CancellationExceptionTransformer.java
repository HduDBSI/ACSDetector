class CancellationExceptionTransformer implements Transformer<RuntimeException,RuntimeException> {
  private CancellationExceptionTransformer(){
  }
  static Transformer<RuntimeException,RuntimeException> transformerFor(  VersionDetails versionDetails){
    if (versionDetails.honorsContractOnCancel()) {
      return Transformers.noOpTransformer();
    }
    return new CancellationExceptionTransformer();
  }
  public RuntimeException transform(  RuntimeException e){
    for (Throwable t=e; t != null; t=t.getCause()) {
      if ("org.gradle.api.BuildCancelledException".equals(t.getClass().getName()) || "org.gradle.tooling.BuildCancelledException".equals(t.getClass().getName())) {
        return new InternalBuildCancelledException(e.getCause());
      }
    }
    return e;
  }
}
