public class ClassAnalysisSerializer extends AbstractSerializer<ClassAnalysis> {
  private SetSerializer<String> stringSetSerializer=new SetSerializer<String>(STRING_SERIALIZER,false);
  private SetSerializer<Integer> integerSetSerializer=new SetSerializer<Integer>(INTEGER_SERIALIZER,false);
  @Override public ClassAnalysis read(  Decoder decoder) throws Exception {
    String className=decoder.readString();
    boolean relatedToAll=decoder.readBoolean();
    Set<String> classes=stringSetSerializer.read(decoder);
    Set<Integer> constants=integerSetSerializer.read(decoder);
    Set<Integer> literals=integerSetSerializer.read(decoder);
    Set<String> superTypes=stringSetSerializer.read(decoder);
    return new ClassAnalysis(className,classes,relatedToAll,constants,literals,superTypes);
  }
  @Override public void write(  Encoder encoder,  ClassAnalysis value) throws Exception {
    encoder.writeString(value.getClassName());
    encoder.writeBoolean(value.isDependencyToAll());
    stringSetSerializer.write(encoder,value.getClassDependencies());
    integerSetSerializer.write(encoder,value.getConstants());
    integerSetSerializer.write(encoder,value.getLiterals());
    stringSetSerializer.write(encoder,value.getSuperTypes());
  }
  @Override public boolean equals(  Object obj){
    if (!super.equals(obj)) {
      return false;
    }
    ClassAnalysisSerializer rhs=(ClassAnalysisSerializer)obj;
    return Objects.equal(stringSetSerializer,rhs.stringSetSerializer) && Objects.equal(integerSetSerializer,rhs.integerSetSerializer);
  }
  @Override public int hashCode(){
    return Objects.hashCode(super.hashCode(),stringSetSerializer,integerSetSerializer);
  }
}
