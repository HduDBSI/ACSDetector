class DefaultVersionedComponentChooser implements VersionedComponentChooser {
  private final ComponentSelectionRulesProcessor rulesProcessor=new ComponentSelectionRulesProcessor();
  private final VersionSelectorScheme versionSelectorScheme;
  private final VersionComparator versionComparator;
  private final ComponentSelectionRulesInternal componentSelectionRules;
  DefaultVersionedComponentChooser(  VersionComparator versionComparator,  VersionSelectorScheme versionSelectorScheme,  ComponentSelectionRulesInternal componentSelectionRules){
    this.versionComparator=versionComparator;
    this.versionSelectorScheme=versionSelectorScheme;
    this.componentSelectionRules=componentSelectionRules;
  }
  public ComponentResolveMetadata selectNewestComponent(  ComponentResolveMetadata one,  ComponentResolveMetadata two){
    if (one == null || two == null) {
      return two == null ? one : two;
    }
    int comparison=versionComparator.compare(new VersionInfo(one.getId().getVersion()),new VersionInfo(two.getId().getVersion()));
    if (comparison == 0) {
      if (isGeneratedModuleDescriptor(one) && !isGeneratedModuleDescriptor(two)) {
        return two;
      }
      return one;
    }
    return comparison < 0 ? two : one;
  }
  private boolean isGeneratedModuleDescriptor(  ComponentResolveMetadata componentResolveMetadata){
    return componentResolveMetadata.isGenerated();
  }
  public void selectNewestMatchingComponent(  Collection<? extends ModuleComponentResolveState> versions,  BuildableComponentSelectionResult result,  ModuleVersionSelector requested){
    VersionSelector requestedVersion=versionSelectorScheme.parseSelector(requested.getVersion());
    Collection<SpecRuleAction<? super ComponentSelection>> rules=componentSelectionRules.getRules();
    for (    ModuleComponentResolveState candidate : sortLatestFirst(versions)) {
      MetadataProvider metadataProvider=createMetadataProvider(candidate);
      boolean versionMatches=versionMatches(requestedVersion,candidate,metadataProvider);
      if (!metadataProvider.isUsable()) {
        applyTo(metadataProvider,result);
        return;
      }
      String version=candidate.getVersion().getSource();
      if (!versionMatches) {
        result.notMatched(version);
        continue;
      }
      ModuleComponentIdentifier candidateIdentifier=candidate.getId();
      boolean accepted=!isRejectedByRules(candidateIdentifier,rules,metadataProvider);
      if (!metadataProvider.isUsable()) {
        applyTo(metadataProvider,result);
        return;
      }
      if (accepted) {
        result.matches(candidateIdentifier);
        return;
      }
      result.rejected(version);
      if (requestedVersion.matchesUniqueVersion()) {
        break;
      }
    }
    result.noMatchFound();
  }
  protected MetadataProvider createMetadataProvider(  ModuleComponentResolveState candidate){
    return new MetadataProvider(candidate);
  }
  private void applyTo(  MetadataProvider provider,  BuildableComponentSelectionResult result){
    BuildableModuleComponentMetaDataResolveResult metaDataResult=provider.getResult();
switch (metaDataResult.getState()) {
case Unknown:
      result.noMatchFound();
    break;
case Missing:
  result.noMatchFound();
break;
case Failed:
result.failed(metaDataResult.getFailure());
break;
default :
throw new IllegalStateException("Unexpected meta-data resolution result.");
}
}
private boolean versionMatches(VersionSelector selector,ModuleComponentResolveState component,MetadataProvider metadataProvider){
if (selector.requiresMetadata()) {
ComponentMetadata componentMetadata=metadataProvider.getComponentMetadata();
return componentMetadata != null && selector.accept(componentMetadata);
}
 else {
return selector.accept(component.getVersion());
}
}
public boolean isRejectedComponent(ModuleComponentIdentifier candidateIdentifier,MetadataProvider metadataProvider){
return isRejectedByRules(candidateIdentifier,componentSelectionRules.getRules(),metadataProvider);
}
private boolean isRejectedByRules(ModuleComponentIdentifier candidateIdentifier,Collection<SpecRuleAction<? super ComponentSelection>> rules,MetadataProvider metadataProvider){
ComponentSelectionInternal selection=new DefaultComponentSelection(candidateIdentifier);
rulesProcessor.apply(selection,rules,metadataProvider);
return selection.isRejected();
}
private List<ModuleComponentResolveState> sortLatestFirst(Collection<? extends ModuleComponentResolveState> listing){
return CollectionUtils.sort(listing,Collections.reverseOrder(versionComparator));
}
}
