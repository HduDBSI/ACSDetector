public interface ResourceFilter extends ConfigurableNormalizer {
  ResourceFilter FILTER_NOTHING=new ResourceFilter(){
    @Override public boolean shouldBeIgnored(    Supplier<String[]> relativePathFactory){
      return false;
    }
    @Override public void appendConfigurationToHasher(    Hasher hasher){
      hasher.putString(getClass().getName());
    }
  }
;
  boolean shouldBeIgnored(  Supplier<String[]> relativePathFactory);
}
