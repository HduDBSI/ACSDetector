protected abstract class AbstractNamedDomainObjectProvider<I extends T> extends AbstractReadOnlyProvider<I> implements Named, NamedDomainObjectProvider<I> {
  private final String name;
  private final Class<I> type;
  protected AbstractNamedDomainObjectProvider(  String name,  Class<I> type){
    this.name=name;
    this.type=type;
  }
  @Nullable @Override public Class<I> getType(){
    return type;
  }
  @Override public String getName(){
    return name;
  }
  @Override public boolean isPresent(){
    return findDomainObject(getName()) != null;
  }
  @Override public String toString(){
    return String.format("provider(%s %s, %s)",getTypeDisplayName(),getName(),getType());
  }
}
