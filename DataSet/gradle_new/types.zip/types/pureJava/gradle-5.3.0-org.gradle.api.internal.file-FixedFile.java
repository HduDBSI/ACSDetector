static class FixedFile implements RegularFile, Managed {
  private final File file;
  FixedFile(  File file){
    this.file=file;
  }
  @Override public boolean immutable(){
    return true;
  }
  @Override public Class<?> publicType(){
    return RegularFile.class;
  }
  @Override public Factory managedFactory(){
    return new Factory(){
      @Override public <T>T fromState(      Class<T> type,      Object state){
        if (!type.isAssignableFrom(RegularFile.class)) {
          return null;
        }
        return type.cast(new FixedFile((File)state));
      }
    }
;
  }
  @Override public Object unpackState(){
    return file;
  }
  @Override public String toString(){
    return file.toString();
  }
  @Override public boolean equals(  Object obj){
    if (obj == this) {
      return true;
    }
    if (obj == null || obj.getClass() != getClass()) {
      return false;
    }
    FixedFile other=(FixedFile)obj;
    return other.file.equals(file);
  }
  @Override public int hashCode(){
    return file.hashCode();
  }
  @Override public File getAsFile(){
    return file;
  }
}
