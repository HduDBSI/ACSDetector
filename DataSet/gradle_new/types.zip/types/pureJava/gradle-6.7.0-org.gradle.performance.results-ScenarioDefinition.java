public interface ScenarioDefinition {
  /** 
 * A human consumable display name for this definition.
 */
  String getDisplayName();
  /** 
 * The test project name.
 */
  String getTestProject();
  /** 
 * The tasks executed.
 */
  List<String> getTasks();
  /** 
 * The clean tasks executed.
 */
  List<String> getCleanTasks();
  /** 
 * The Gradle arguments.
 */
  List<String> getArgs();
  /** 
 * The Gradle JVM args. Null if not known
 */
  @Nullable List<String> getGradleOpts();
  /** 
 * Was the daemon used. Null if not known
 */
  @Nullable Boolean getDaemon();
}
