/** 
 * Demarcates objects that expose a convention. Convention objects aren't going to be around forever, so this is a temporary interface.
 */
public interface HasConvention {
  Convention getConvention();
}
