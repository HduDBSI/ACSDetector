public class DefaultUsageContext implements UsageContext, Named {
  private final String name;
  private final Usage usage;
  private final AttributeContainer attributes;
  private final Set<? extends PublishArtifact> artifacts;
  private final Set<? extends ModuleDependency> dependencies;
  private final Set<? extends DependencyConstraint> dependencyConstraints;
  private final Set<ExcludeRule> globalExcludes;
  DefaultUsageContext(  String name,  Usage usage,  Set<? extends PublishArtifact> artifacts,  Configuration configuration){
    this(name,usage,configuration.getAttributes(),artifacts,configuration);
  }
  public DefaultUsageContext(  UsageContext usageContext,  Set<? extends PublishArtifact> artifacts,  Configuration configuration){
    this(usageContext.getName(),usageContext.getUsage(),usageContext.getAttributes(),artifacts,configuration);
  }
  public DefaultUsageContext(  String name,  Usage usage,  AttributeContainer attributes){
    this(name,usage,attributes,null,null);
  }
  private DefaultUsageContext(  String name,  Usage usage,  AttributeContainer attributes,  Set<? extends PublishArtifact> artifacts,  Configuration configuration){
    this.name=name;
    this.usage=usage;
    this.attributes=attributes;
    this.artifacts=artifacts;
    if (configuration != null) {
      this.dependencies=configuration.getAllDependencies().withType(ModuleDependency.class);
      this.dependencyConstraints=configuration.getAllDependencyConstraints();
      this.globalExcludes=((ConfigurationInternal)configuration).getAllExcludeRules();
    }
 else {
      this.dependencies=null;
      this.dependencyConstraints=null;
      this.globalExcludes=Collections.emptySet();
    }
  }
  @Override public String getName(){
    return name;
  }
  @Override public Usage getUsage(){
    return usage;
  }
  @Override public AttributeContainer getAttributes(){
    return attributes;
  }
  @Override public Set<? extends PublishArtifact> getArtifacts(){
    assert artifacts != null;
    return artifacts;
  }
  @Override public Set<? extends ModuleDependency> getDependencies(){
    assert dependencies != null;
    return dependencies;
  }
  @Override public Set<? extends DependencyConstraint> getDependencyConstraints(){
    assert dependencyConstraints != null;
    return dependencyConstraints;
  }
  @Override public Set<? extends Capability> getCapabilities(){
    return Collections.emptySet();
  }
  @Override public Set<ExcludeRule> getGlobalExcludes(){
    return globalExcludes;
  }
}
