/** 
 * A  {@link TaskExecuter} which performs validation before executing the task.
 */
public class ValidatingTaskExecuter implements TaskExecuter {
  private final TaskExecuter executer;
  public ValidatingTaskExecuter(  TaskExecuter executer){
    this.executer=executer;
  }
  public void execute(  TaskInternal task,  TaskStateInternal state,  TaskExecutionContext context){
    List<String> messages=Lists.newArrayList();
    FileResolver resolver=((ProjectInternal)task.getProject()).getFileResolver();
    final TaskValidationContext validationContext=new DefaultTaskValidationContext(resolver,messages);
    try {
      context.getTaskProperties().validate(validationContext);
    }
 catch (    Exception ex) {
      throw new TaskExecutionException(task,ex);
    }
    if (!messages.isEmpty()) {
      List<String> firstMessages=messages.subList(0,Math.min(5,messages.size()));
      report(task,firstMessages,state);
      return;
    }
    executer.execute(task,state,context);
  }
  private static void report(  Task task,  List<String> messages,  TaskStateInternal state){
    List<InvalidUserDataException> causes=Lists.newArrayListWithCapacity(messages.size());
    for (    String message : messages) {
      causes.add(new InvalidUserDataException(message));
    }
    String errorMessage=getMainMessage(task,messages);
    state.setOutcome(new TaskValidationException(errorMessage,causes));
  }
  private static String getMainMessage(  Task task,  List<String> messages){
    if (messages.size() == 1) {
      return String.format("A problem was found with the configuration of %s.",task);
    }
 else {
      return String.format("Some problems were found with the configuration of %s.",task);
    }
  }
}
