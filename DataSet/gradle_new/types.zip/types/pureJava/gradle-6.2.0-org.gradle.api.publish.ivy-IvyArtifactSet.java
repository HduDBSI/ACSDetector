/** 
 * A Collection of  {@link IvyArtifact}s to be included in an  {@link IvyPublication}. Being a  {@link DomainObjectSet}, a  {@code IvyArtifactSet} provides convenient methods for querying, filtering, and applying actions to the set of {@link IvyArtifact}s. <pre class='autoTested'> apply plugin: 'ivy-publish' def publication = publishing.publications.create("my-pub", IvyPublication) def artifacts = publication.artifacts artifacts.matching({ it.type == "source" }).all({ it.extension = "src.jar" }) </pre>
 * @see DomainObjectSet
 */
public interface IvyArtifactSet extends DomainObjectSet<IvyArtifact> {
  /** 
 * Creates and adds a  {@link IvyArtifact} to the set.The semantics of this method are the same as  {@link IvyPublication#artifact(Object)}.
 * @param source The source of the artifact content.
 */
  IvyArtifact artifact(  Object source);
  /** 
 * Creates and adds a  {@link IvyArtifact} to the set, which is configured by the associated action.The semantics of this method are the same as  {@link IvyPublication#artifact(Object,Action)}.
 * @param source The source of the artifact.
 * @param config An action to configure the values of the constructed {@link IvyArtifact}.
 */
  IvyArtifact artifact(  Object source,  Action<? super IvyArtifact> config);
}
