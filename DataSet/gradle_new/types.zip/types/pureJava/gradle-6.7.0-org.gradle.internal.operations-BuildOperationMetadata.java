public interface BuildOperationMetadata {
  BuildOperationMetadata NONE=new BuildOperationMetadata(){
  }
;
}
