/** 
 * An event that informs about an operation having finished its execution.
 * @since 2.4
 */
public interface FinishEvent extends ProgressEvent {
  /** 
 * Returns the result of the finished operation.
 * @return the result of the finished operation
 */
  OperationResult getResult();
}
