public interface TaskInputFilePropertySpec extends TaskFilePropertySpec, LifecycleAwareTaskProperty {
  boolean isSkipWhenEmpty();
}
