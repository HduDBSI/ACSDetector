public class DefaultFileContentCacheFactory implements FileContentCacheFactory, Closeable {
  private final ListenerManager listenerManager;
  private final FileSystemSnapshotter fileSystemSnapshotter;
  private final InMemoryCacheDecoratorFactory inMemoryCacheDecoratorFactory;
  private final PersistentCache cache;
  private final HashCodeSerializer hashCodeSerializer=new HashCodeSerializer();
  private final ConcurrentMap<String,DefaultFileContentCache<?>> caches=new ConcurrentHashMap<String,DefaultFileContentCache<?>>();
  public DefaultFileContentCacheFactory(  ListenerManager listenerManager,  FileSystemSnapshotter fileSystemSnapshotter,  CacheRepository cacheRepository,  InMemoryCacheDecoratorFactory inMemoryCacheDecoratorFactory,  Object scope){
    this.listenerManager=listenerManager;
    this.fileSystemSnapshotter=fileSystemSnapshotter;
    this.inMemoryCacheDecoratorFactory=inMemoryCacheDecoratorFactory;
    cache=cacheRepository.cache(scope,"fileContent").withDisplayName("file content cache").withLockOptions(mode(FileLockManager.LockMode.None)).open();
  }
  @Override public void close() throws IOException {
    cache.close();
  }
  @Override public <V>FileContentCache<V> newCache(  String name,  int normalizedCacheSize,  final Calculator<? extends V> calculator,  Serializer<V> serializer){
    PersistentIndexedCacheParameters<HashCode,V> parameters=new PersistentIndexedCacheParameters<HashCode,V>(name,hashCodeSerializer,serializer).cacheDecorator(inMemoryCacheDecoratorFactory.decorator(normalizedCacheSize,true));
    PersistentIndexedCache<HashCode,V> store=cache.createCache(parameters);
    DefaultFileContentCache<V> cache=(DefaultFileContentCache<V>)caches.get(name);
    if (cache == null) {
      cache=new DefaultFileContentCache<V>(name,fileSystemSnapshotter,store,calculator);
      DefaultFileContentCache<V> existing=(DefaultFileContentCache<V>)caches.putIfAbsent(name,cache);
      if (existing == null) {
        listenerManager.addListener(cache);
      }
 else {
        cache=existing;
      }
    }
    cache.assertStoredIn(store);
    return cache;
  }
  /** 
 * Maintains 2 levels of in-memory caching. The first, fast, level indexes on file path and contains the value that is very likely to reflect the current contents of the file. This first cache is invalidated whenever any task actions are run. The second level indexes on the hash of file content and contains the value that was calculated from a file with the given hash.
 */
private static class DefaultFileContentCache<V> implements FileContentCache<V>, TaskOutputChangesListener {
    private final Map<File,V> cache=new ConcurrentHashMap<File,V>();
    private final String name;
    private final FileSystemSnapshotter fileSystemSnapshotter;
    private final PersistentIndexedCache<HashCode,V> contentCache;
    private final Calculator<? extends V> calculator;
    DefaultFileContentCache(    String name,    FileSystemSnapshotter fileSystemSnapshotter,    PersistentIndexedCache<HashCode,V> contentCache,    Calculator<? extends V> calculator){
      this.name=name;
      this.fileSystemSnapshotter=fileSystemSnapshotter;
      this.contentCache=contentCache;
      this.calculator=calculator;
    }
    @Override public void beforeTaskOutputChanged(){
      cache.clear();
    }
    @Override public V get(    File file){
      V value=cache.get(file);
      if (value == null) {
        FileSnapshot fileSnapshot=fileSystemSnapshotter.snapshotSelf(file);
        FileType fileType=fileSnapshot.getType();
        if (fileType == FileType.RegularFile) {
          HashCode hashCode=fileSnapshot.getContent().getContentMd5();
          value=contentCache.get(hashCode);
          if (value == null) {
            value=calculator.calculate(file,fileType);
            contentCache.put(hashCode,value);
          }
        }
 else {
          value=calculator.calculate(file,fileType);
        }
        cache.put(file,value);
      }
      return value;
    }
    private void assertStoredIn(    PersistentIndexedCache<HashCode,V> store){
      if (this.contentCache != store) {
        throw new IllegalStateException("Cache " + name + " cannot be recreated with different parameters");
      }
    }
  }
}
