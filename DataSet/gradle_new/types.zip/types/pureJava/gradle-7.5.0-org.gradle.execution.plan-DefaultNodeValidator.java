public class DefaultNodeValidator implements NodeValidator {
  @Override public boolean hasValidationProblems(  LocalTaskNode node){
    WorkValidationContext validationContext=node.getValidationContext();
    Class<?> taskType=GeneratedSubclasses.unpackType(node.getTask());
    TypeValidationContext taskValidationContext=validationContext.forType(taskType,false);
    node.getTaskProperties().validateType(taskValidationContext);
    List<TypeValidationProblem> problems=validationContext.getProblems();
    problems.stream().filter(problem -> problem.getSeverity().isWarning()).forEach(problem -> {
      Optional<UserManualReference> userManualReference=problem.getUserManualReference();
      String docId="more_about_tasks";
      String section="sec:up_to_date_checks";
      if (userManualReference.isPresent()) {
        UserManualReference docref=userManualReference.get();
        docId=docref.getId();
        section=docref.getSection();
      }
      String warning=convertToSingleLine(renderMinimalInformationAbout(problem,false,false));
      DeprecationLogger.deprecateBehaviour(warning).withContext("Execution optimizations are disabled to ensure correctness.").willBeRemovedInGradle8().withUserManual(docId,section).nagUser();
    }
);
    return !problems.isEmpty();
  }
}
