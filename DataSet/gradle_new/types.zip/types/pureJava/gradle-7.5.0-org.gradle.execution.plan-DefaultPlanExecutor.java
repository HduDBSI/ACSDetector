@NonNullApi public class DefaultPlanExecutor implements PlanExecutor, Stoppable {
  private static final Logger LOGGER=LoggerFactory.getLogger(DefaultPlanExecutor.class);
  private final int executorCount;
  private final WorkerLeaseService workerLeaseService;
  private final BuildCancellationToken cancellationToken;
  private final ResourceLockCoordinationService coordinationService;
  private final ManagedExecutor executor;
  private final MergedQueues queue;
  private final AtomicBoolean workersStarted=new AtomicBoolean();
  public DefaultPlanExecutor(  ParallelismConfiguration parallelismConfiguration,  ExecutorFactory executorFactory,  WorkerLeaseService workerLeaseService,  BuildCancellationToken cancellationToken,  ResourceLockCoordinationService coordinationService){
    this.cancellationToken=cancellationToken;
    this.coordinationService=coordinationService;
    int numberOfParallelExecutors=parallelismConfiguration.getMaxWorkerCount();
    if (numberOfParallelExecutors < 1) {
      throw new IllegalArgumentException("Not a valid number of parallel executors: " + numberOfParallelExecutors);
    }
    this.executorCount=numberOfParallelExecutors;
    this.workerLeaseService=workerLeaseService;
    this.queue=new MergedQueues(coordinationService,false);
    this.executor=executorFactory.create("Execution worker");
  }
  @Override public void stop(){
    CompositeStoppable.stoppable(queue,executor).stop();
  }
  @Override public <T>ExecutionResult<Void> process(  WorkSource<T> workSource,  Action<T> worker){
    PlanDetails planDetails=new PlanDetails(Cast.uncheckedCast(workSource),Cast.uncheckedCast(worker));
    queue.add(planDetails);
    maybeStartWorkers(queue,executor);
    WorkerLease currentWorkerLease=workerLeaseService.getCurrentWorkerLease();
    MergedQueues thisPlanOnly=new MergedQueues(coordinationService,true);
    thisPlanOnly.add(planDetails);
    new ExecutorWorker(thisPlanOnly,currentWorkerLease,cancellationToken,coordinationService,workerLeaseService).run();
    List<Throwable> failures=new ArrayList<>();
    awaitCompletion(workSource,currentWorkerLease,failures);
    return ExecutionResult.maybeFailed(failures);
  }
  @Override public void assertHealthy(){
    coordinationService.withStateLock(queue::assertHealthy);
  }
  /** 
 * Blocks until all items in the queue have been processed. This method will only return when every item in the queue has either completed, failed or been skipped.
 */
  private void awaitCompletion(  WorkSource<?> workSource,  WorkerLease workerLease,  Collection<? super Throwable> failures){
    coordinationService.withStateLock(resourceLockState -> {
      if (workSource.allExecutionComplete()) {
        if (!workerLease.isLockedByCurrentThread()) {
          if (!workerLease.tryLock()) {
            return RETRY;
          }
        }
        workSource.collectFailures(failures);
        queue.removeFinishedPlans();
        return FINISHED;
      }
 else {
        workerLease.unlock();
        return RETRY;
      }
    }
);
  }
  private void maybeStartWorkers(  MergedQueues queue,  Executor executor){
    if (workersStarted.compareAndSet(false,true)) {
      LOGGER.debug("Using {} parallel executor threads",executorCount);
      for (int i=1; i < executorCount; i++) {
        executor.execute(new ExecutorWorker(queue,null,cancellationToken,coordinationService,workerLeaseService));
      }
    }
  }
private static class PlanDetails {
    final WorkSource<Object> source;
    final Action<Object> worker;
    public PlanDetails(    WorkSource<Object> source,    Action<Object> worker){
      this.source=source;
      this.worker=worker;
    }
  }
private static class WorkItem {
    final WorkSource.Selection<Object> selection;
    final WorkSource<Object> plan;
    final Action<Object> executor;
    public WorkItem(    WorkSource.Selection<Object> selection,    WorkSource<Object> plan,    Action<Object> executor){
      this.selection=selection;
      this.plan=plan;
      this.executor=executor;
    }
  }
private static class MergedQueues implements Closeable {
    private final ResourceLockCoordinationService coordinationService;
    private final boolean autoFinish;
    private boolean finished;
    private final LinkedList<PlanDetails> queues=new LinkedList<>();
    public MergedQueues(    ResourceLockCoordinationService coordinationService,    boolean autoFinish){
      this.coordinationService=coordinationService;
      this.autoFinish=autoFinish;
    }
    public WorkSource.State executionState(){
      coordinationService.assertHasStateLock();
      Iterator<PlanDetails> iterator=queues.iterator();
      while (iterator.hasNext()) {
        PlanDetails details=iterator.next();
        WorkSource.State state=details.source.executionState();
        if (state == WorkSource.State.NoMoreWorkToStart) {
          if (details.source.allExecutionComplete()) {
            iterator.remove();
          }
        }
 else         if (state == WorkSource.State.MaybeWorkReadyToStart) {
          return WorkSource.State.MaybeWorkReadyToStart;
        }
      }
      if (nothingMoreToStart()) {
        return WorkSource.State.NoMoreWorkToStart;
      }
 else {
        return WorkSource.State.NoWorkReadyToStart;
      }
    }
    public WorkSource.Selection<WorkItem> selectNext(){
      coordinationService.assertHasStateLock();
      Iterator<PlanDetails> iterator=queues.iterator();
      while (iterator.hasNext()) {
        PlanDetails details=iterator.next();
        WorkSource.Selection<Object> selection=details.source.selectNext();
        if (selection.isNoMoreWorkToStart()) {
          if (details.source.allExecutionComplete()) {
            iterator.remove();
          }
        }
 else         if (!selection.isNoWorkReadyToStart()) {
          return WorkSource.Selection.of(new WorkItem(selection,details.source,details.worker));
        }
      }
      if (nothingMoreToStart()) {
        return WorkSource.Selection.noMoreWorkToStart();
      }
 else {
        return WorkSource.Selection.noWorkReadyToStart();
      }
    }
    private boolean nothingMoreToStart(){
      return finished || (autoFinish && queues.isEmpty());
    }
    public void add(    PlanDetails planDetails){
      coordinationService.withStateLock(() -> {
        if (finished) {
          throw new IllegalStateException("This queue has been closed.");
        }
        queues.addFirst(planDetails);
        coordinationService.notifyStateChange();
      }
);
    }
    public void removeFinishedPlans(){
      coordinationService.assertHasStateLock();
      queues.removeIf(details -> details.source.allExecutionComplete());
    }
    @Override public void close() throws IOException {
      coordinationService.withStateLock(() -> {
        finished=true;
        if (!queues.isEmpty()) {
          throw new IllegalStateException("Not all work has completed.");
        }
        coordinationService.notifyStateChange();
      }
);
    }
    public void cancelExecution(){
      coordinationService.assertHasStateLock();
      for (      PlanDetails details : queues) {
        details.source.cancelExecution();
      }
    }
    public void abortAllAndFail(    Throwable t){
      coordinationService.assertHasStateLock();
      for (      PlanDetails details : queues) {
        details.source.abortAllAndFail(t);
      }
    }
    public void assertHealthy(){
      coordinationService.assertHasStateLock();
      if (queues.isEmpty()) {
        return;
      }
      List<WorkSource.Diagnostics> allDiagnostics=new ArrayList<>(queues.size());
      for (      PlanDetails details : queues) {
        WorkSource.Diagnostics diagnostics=details.source.healthDiagnostics();
        if (diagnostics.canMakeProgress()) {
          return;
        }
        allDiagnostics.add(diagnostics);
      }
      TreeFormatter formatter=new TreeFormatter();
      formatter.node("Unable to make progress running work. The following items are queued for execution but none of them can be started:");
      formatter.startChildren();
      for (      WorkSource.Diagnostics diagnostics : allDiagnostics) {
        diagnostics.describeTo(formatter);
      }
      formatter.endChildren();
      System.out.println(formatter);
      IllegalStateException failure=new IllegalStateException("Unable to make progress running work. There are items queued for execution but none of them can be started");
      abortAllAndFail(failure);
      coordinationService.notifyStateChange();
    }
  }
private static class ExecutorWorker implements Runnable {
    private final MergedQueues queue;
    private WorkerLease workerLease;
    private final BuildCancellationToken cancellationToken;
    private final ResourceLockCoordinationService coordinationService;
    private final WorkerLeaseService workerLeaseService;
    private ExecutorWorker(    MergedQueues queue,    @Nullable WorkerLease workerLease,    BuildCancellationToken cancellationToken,    ResourceLockCoordinationService coordinationService,    WorkerLeaseService workerLeaseService){
      this.queue=queue;
      this.workerLease=workerLease;
      this.cancellationToken=cancellationToken;
      this.coordinationService=coordinationService;
      this.workerLeaseService=workerLeaseService;
    }
    @Override public void run(){
      final AtomicLong busy=new AtomicLong(0);
      Timer totalTimer=Time.startTimer();
      final Timer executionTimer=Time.startTimer();
      boolean releaseLeaseOnCompletion;
      if (workerLease == null) {
        workerLease=workerLeaseService.newWorkerLease();
        releaseLeaseOnCompletion=true;
      }
 else {
        releaseLeaseOnCompletion=false;
      }
      while (true) {
        WorkItem workItem=getNextItem(workerLease);
        if (workItem == null) {
          break;
        }
        Object selected=workItem.selection.getItem();
        LOGGER.info("{} ({}) started.",selected,Thread.currentThread());
        executionTimer.reset();
        execute(selected,workItem.plan,workItem.executor);
        long duration=executionTimer.getElapsedMillis();
        busy.addAndGet(duration);
        if (LOGGER.isInfoEnabled()) {
          LOGGER.info("{} ({}) completed. Took {}.",selected,Thread.currentThread(),TimeFormatting.formatDurationVerbose(duration));
        }
      }
      if (releaseLeaseOnCompletion) {
        coordinationService.withStateLock(() -> workerLease.unlock());
      }
      long total=totalTimer.getElapsedMillis();
      if (LOGGER.isDebugEnabled()) {
        LOGGER.debug("Execution worker [{}] finished, busy: {}, idle: {}",Thread.currentThread(),TimeFormatting.formatDurationVerbose(busy.get()),TimeFormatting.formatDurationVerbose(total - busy.get()));
      }
    }
    /** 
 * Selects an item that's ready to execute and executes the provided action against it. If no item is ready, blocks until some can be executed.
 * @return The next item to execute or {@code null} when there are no items remaining
 */
    @Nullable private WorkItem getNextItem(    final WorkerLease workerLease){
      final MutableReference<WorkItem> selected=MutableReference.empty();
      coordinationService.withStateLock(resourceLockState -> {
        if (cancellationToken.isCancellationRequested()) {
          queue.cancelExecution();
        }
        WorkSource.State state=queue.executionState();
        if (state == WorkSource.State.NoMoreWorkToStart) {
          return FINISHED;
        }
 else         if (state == WorkSource.State.NoWorkReadyToStart) {
          if (workerLease.isLockedByCurrentThread()) {
            workerLease.unlock();
          }
          return RETRY;
        }
        boolean hasWorkerLease=workerLease.isLockedByCurrentThread();
        if (!hasWorkerLease && !workerLease.tryLock()) {
          return RETRY;
        }
        WorkSource.Selection<WorkItem> workItem;
        try {
          workItem=queue.selectNext();
        }
 catch (        Throwable t) {
          resourceLockState.releaseLocks();
          queue.abortAllAndFail(t);
          return FINISHED;
        }
        if (workItem.isNoMoreWorkToStart()) {
          return FINISHED;
        }
 else         if (workItem.isNoWorkReadyToStart()) {
          workerLease.unlock();
          return RETRY;
        }
        selected.set(workItem.getItem());
        return FINISHED;
      }
);
      return selected.get();
    }
    private void execute(    Object selected,    WorkSource<Object> executionPlan,    Action<Object> worker){
      Throwable failure=null;
      try {
        try {
          worker.execute(selected);
        }
 catch (        Throwable t) {
          failure=t;
        }
      }
  finally {
        markFinished(selected,executionPlan,failure);
      }
    }
    private void markFinished(    Object selected,    WorkSource<Object> executionPlan,    @Nullable Throwable failure){
      coordinationService.withStateLock(() -> {
        try {
          executionPlan.finishedExecuting(selected,failure);
        }
 catch (        Throwable t) {
          queue.abortAllAndFail(t);
        }
        coordinationService.notifyStateChange();
      }
);
    }
  }
}
