@NonNullApi public class DefaultPropertyWalker implements PropertyWalker {
  private final RuntimeBeanNodeFactory nodeFactory;
  public DefaultPropertyWalker(  TypeMetadataStore typeMetadataStore){
    this.nodeFactory=new RuntimeBeanNodeFactory(typeMetadataStore);
  }
  @Override public void visitProperties(  PropertySpecFactory specFactory,  PropertyVisitor visitor,  Object bean){
    Queue<RuntimeBeanNode<?>> queue=new ArrayDeque<RuntimeBeanNode<?>>();
    queue.add(nodeFactory.createRoot(bean));
    while (!queue.isEmpty()) {
      RuntimeBeanNode<?> node=queue.remove();
      node.visitNode(visitor,specFactory,queue,nodeFactory);
    }
  }
}
