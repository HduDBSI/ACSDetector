public abstract class AbstractVersionControlSpec implements VersionControlSpec {
  private String rootDir="";
  private final DefaultInjectedPluginDependencies pluginDependencies=new DefaultInjectedPluginDependencies();
  @Override public String getRootDir(){
    return rootDir;
  }
  @Override public void setRootDir(  String rootDir){
    Preconditions.checkNotNull(rootDir,"rootDir should be non-null for '%s'.",getDisplayName());
    this.rootDir=rootDir;
  }
  @Override public void plugins(  Action<? super InjectedPluginDependencies> configuration){
    configuration.execute(pluginDependencies);
  }
  public List<DefaultInjectedPluginDependency> getInjectedPlugins(){
    return pluginDependencies.getDependencies();
  }
}
