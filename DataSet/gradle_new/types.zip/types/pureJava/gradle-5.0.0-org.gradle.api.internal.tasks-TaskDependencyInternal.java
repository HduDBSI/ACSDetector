public interface TaskDependencyInternal extends TaskDependency, TaskDependencyContainer {
  TaskDependencyInternal EMPTY=new TaskDependencyInternal(){
    @Override public Set<? extends Task> getDependencies(    @Nullable Task task){
      return Collections.emptySet();
    }
    @Override public void visitDependencies(    TaskDependencyResolveContext context){
    }
  }
;
}
