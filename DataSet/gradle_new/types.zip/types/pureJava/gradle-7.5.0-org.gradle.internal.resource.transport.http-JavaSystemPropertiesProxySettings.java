public abstract class JavaSystemPropertiesProxySettings implements HttpProxySettings {
  private static final Logger LOGGER=LoggerFactory.getLogger(JavaSystemPropertiesProxySettings.class);
  private final HttpProxy proxy;
  private final String propertyPrefix;
  private final int defaultPort;
  public JavaSystemPropertiesProxySettings(  String propertyPrefix,  int defaultPort){
    this(propertyPrefix,defaultPort,System.getProperty(propertyPrefix + ".proxyHost"),System.getProperty(propertyPrefix + ".proxyPort"),System.getProperty(propertyPrefix + ".proxyUser"),System.getProperty(propertyPrefix + ".proxyPassword"));
  }
  JavaSystemPropertiesProxySettings(  String propertyPrefix,  int defaultPort,  String proxyHost,  String proxyPortString,  String proxyUser,  String proxyPassword){
    this.propertyPrefix=propertyPrefix;
    this.defaultPort=defaultPort;
    if (StringUtils.isBlank(proxyHost)) {
      this.proxy=null;
    }
 else {
      this.proxy=new HttpProxy(proxyHost,initProxyPort(proxyPortString),proxyUser,proxyPassword);
    }
  }
  private int initProxyPort(  String proxyPortString){
    if (StringUtils.isBlank(proxyPortString)) {
      return defaultPort;
    }
    try {
      return Integer.parseInt(proxyPortString);
    }
 catch (    NumberFormatException e) {
      String key=propertyPrefix + ".proxyPort";
      LOGGER.warn("Invalid value for java system property '{}': '{}'. Value is not a valid number. Default port '{}' will be used.",key,proxyPortString,defaultPort);
      return defaultPort;
    }
  }
  @Override public HttpProxySettings.HttpProxy getProxy(){
    return proxy;
  }
  public String getPropertyPrefix(){
    return propertyPrefix;
  }
  public int getDefaultPort(){
    return defaultPort;
  }
  private static String getAndTrimSystemProperty(  String key){
    String value=System.getProperty(key);
    return value != null ? value.trim() : null;
  }
}
