public interface PublicationArtifactInternal extends PublicationArtifact {
  boolean shouldBePublished();
}
