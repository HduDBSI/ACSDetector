private static class HashBackedSnapshot implements Snapshot {
  private final HashCode hashCode;
  HashBackedSnapshot(  HashCode hashCode){
    this.hashCode=hashCode;
  }
  @Override public void appendToHasher(  BuildCacheHasher hasher){
    hasher.putHash(hashCode);
  }
  @Override public boolean equals(  Object o){
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    HashBackedSnapshot that=(HashBackedSnapshot)o;
    return hashCode.equals(that.hashCode);
  }
  @Override public int hashCode(){
    return hashCode.hashCode();
  }
}
