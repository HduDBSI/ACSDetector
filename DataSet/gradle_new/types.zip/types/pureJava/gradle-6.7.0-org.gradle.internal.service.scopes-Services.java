private static class Services {
  private final ServiceRegistry registry;
  private int count;
  public Services(  ServiceRegistry registry){
    this.registry=registry;
  }
}
