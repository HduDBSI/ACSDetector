public class LocalClassSetAnalysisStore implements Loader<ClassSetAnalysisData>, Stash<ClassSetAnalysisData> {
  private final String taskPath;
  private final PersistentIndexedCache<String,ClassSetAnalysisData> cache;
  public LocalClassSetAnalysisStore(  String taskPath,  PersistentIndexedCache<String,ClassSetAnalysisData> cache){
    this.taskPath=taskPath;
    this.cache=cache;
  }
  @Override public void put(  ClassSetAnalysisData analysis){
    cache.put(taskPath,analysis);
  }
  @Override public ClassSetAnalysisData get(){
    return cache.get(taskPath);
  }
}
