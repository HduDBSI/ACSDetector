public class DefaultProviderFactory implements ProviderFactory {
  public <T>Provider<T> provider(  final Callable<T> value){
    if (value == null) {
      throw new InvalidUserDataException("Value cannot be null");
    }
    return new DefaultProvider<T>(value);
  }
  @Override public <T>PropertyState<T> property(  Class<T> type){
    if (type == null) {
      throw new InvalidUserDataException("Class cannot be null");
    }
    PropertyState<T> propertyState=new DefaultPropertyState<T>(type);
    if (type == Boolean.class) {
      ((PropertyState<Boolean>)propertyState).set(Providers.FALSE);
    }
 else     if (type == Byte.class) {
      ((PropertyState<Byte>)propertyState).set(Providers.BYTE_ZERO);
    }
 else     if (type == Short.class) {
      ((PropertyState<Short>)propertyState).set(Providers.SHORT_ZERO);
    }
 else     if (type == Integer.class) {
      ((PropertyState<Integer>)propertyState).set(Providers.INTEGER_ZERO);
    }
 else     if (type == Long.class) {
      ((PropertyState<Long>)propertyState).set(Providers.LONG_ZERO);
    }
 else     if (type == Float.class) {
      ((PropertyState<Float>)propertyState).set(Providers.FLOAT_ZERO);
    }
 else     if (type == Double.class) {
      ((PropertyState<Double>)propertyState).set(Providers.DOUBLE_ZERO);
    }
 else     if (type == Character.class) {
      ((PropertyState<Character>)propertyState).set(Providers.CHAR_ZERO);
    }
    return propertyState;
  }
}
