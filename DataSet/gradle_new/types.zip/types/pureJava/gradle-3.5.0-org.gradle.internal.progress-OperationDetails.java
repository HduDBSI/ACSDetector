private static class OperationDetails implements Operation {
  final AtomicBoolean running=new AtomicBoolean();
  final OperationDetails parent;
  final OperationIdentifier id;
  final BuildOperationDetails operationDetails;
  OperationDetails(  OperationDetails parent,  OperationIdentifier id,  BuildOperationDetails operationDetails){
    this.parent=parent;
    this.id=id;
    this.operationDetails=operationDetails;
  }
  @Override public Object getId(){
    return id;
  }
  @Override public Object getParentId(){
    return parent.id;
  }
}
