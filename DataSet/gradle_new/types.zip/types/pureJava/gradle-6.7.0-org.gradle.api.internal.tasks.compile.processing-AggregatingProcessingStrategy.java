/** 
 * The strategy used for aggregating annotation processors.
 * @see AggregatingProcessor
 */
class AggregatingProcessingStrategy extends IncrementalProcessingStrategy {
  private static final Map<Class<?>,Optional<Field>> FIELD_CACHE=new HashMap<>(5);
  private static Boolean canAccessJDKTypes;
  AggregatingProcessingStrategy(  AnnotationProcessorResult result){
    super(result);
    result.setType(AGGREGATING);
  }
  @Override public void recordProcessingInputs(  Set<String> supportedAnnotationTypes,  Set<? extends TypeElement> annotations,  RoundEnvironment roundEnv){
    validateAnnotations(annotations);
    recordAggregatedTypes(supportedAnnotationTypes,annotations,roundEnv);
  }
  private void validateAnnotations(  Set<? extends TypeElement> annotations){
    for (    TypeElement annotation : annotations) {
      Retention retention=annotation.getAnnotation(Retention.class);
      if (retention != null && retention.value() == RetentionPolicy.SOURCE) {
        result.setFullRebuildCause("'@" + annotation.getSimpleName() + "' has source retention. Aggregating annotation processors require class or runtime retention");
      }
    }
  }
  private void recordAggregatedTypes(  Set<String> supportedAnnotationTypes,  Set<? extends TypeElement> annotations,  RoundEnvironment roundEnv){
    if (supportedAnnotationTypes.contains("*")) {
      result.getAggregatedTypes().addAll(namesOfElementsWithSource(roundEnv.getRootElements()));
    }
 else {
      for (      TypeElement annotation : annotations) {
        result.getAggregatedTypes().addAll(namesOfElementsWithSource(roundEnv.getElementsAnnotatedWith(annotation)));
      }
    }
  }
  private static Set<String> namesOfElementsWithSource(  Set<? extends Element> orig){
    if (orig == null || orig.isEmpty()) {
      return Collections.emptySet();
    }
    return orig.stream().map(ElementUtils::getTopLevelType).filter(AggregatingProcessingStrategy::filterElements).map(ElementUtils::getElementName).collect(Collectors.toSet());
  }
  private static boolean filterElements(  Element element){
    if (canAccessJDKTypes()) {
      return filterElementsDirect(element);
    }
 else {
      return filterElementsReflection(element);
    }
  }
  private static boolean filterElementsReflection(  Element element){
    try {
      Optional<Field> field=FIELD_CACHE.computeIfAbsent(element.getClass(),AggregatingProcessingStrategy::getField);
      if (field.isPresent()) {
        return field.get().get(element) != null;
      }
 else {
        return false;
      }
    }
 catch (    IllegalAccessException e) {
      FIELD_CACHE.put(element.getClass(),Optional.empty());
    }
    return false;
  }
  private static Optional<Field> getField(  Class<?> clazz){
    try {
      Field sourceFile=clazz.getField("sourceFile");
      return Optional.of(sourceFile);
    }
 catch (    NoSuchFieldException e) {
      return Optional.empty();
    }
  }
  private static boolean filterElementsDirect(  Element element){
    if (element instanceof Symbol.ClassSymbol) {
      return ((Symbol.ClassSymbol)element).sourcefile != null;
    }
    return false;
  }
  private static boolean canAccessJDKTypes(){
    if (canAccessJDKTypes == null) {
      try {
        AggregatingProcessingStrategy.class.getClassLoader().loadClass("com.sun.tools.javac.code.Symbol");
        canAccessJDKTypes=Boolean.TRUE;
      }
 catch (      Throwable t) {
        canAccessJDKTypes=Boolean.FALSE;
      }
    }
    return canAccessJDKTypes;
  }
  @Override public void recordGeneratedType(  CharSequence name,  Element[] originatingElements){
    result.getGeneratedAggregatingTypes().add(name.toString());
  }
  @Override public void recordGeneratedResource(  JavaFileManager.Location location,  CharSequence pkg,  CharSequence relativeName,  Element[] originatingElements){
    GeneratedResource.Location resourceLocation=GeneratedResource.Location.from(location);
    if (resourceLocation == null) {
      result.setFullRebuildCause(location + " is not supported for incremental annotation processing");
    }
 else {
      result.getGeneratedAggregatingResources().add(new GeneratedResource(resourceLocation,pkg,relativeName));
    }
  }
}
