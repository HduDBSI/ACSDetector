/** 
 * A supplier of zero or more mappings from value of type  {@link K} to value of type {@link V}.
 */
public interface MapCollector<K,V> extends ValueSupplier {
  boolean present();
  void collectInto(  DisplayName owner,  MapEntryCollector<K,V> collector,  Map<K,V> dest);
  boolean maybeCollectInto(  MapEntryCollector<K,V> collector,  Map<K,V> dest);
  void collectKeysInto(  ValueCollector<K> collector,  Collection<K> dest);
  boolean maybeCollectKeysInto(  ValueCollector<K> collector,  Collection<K> dest);
  void visit(  List<ProviderInternal<? extends Map<? extends K,? extends V>>> sources);
}
