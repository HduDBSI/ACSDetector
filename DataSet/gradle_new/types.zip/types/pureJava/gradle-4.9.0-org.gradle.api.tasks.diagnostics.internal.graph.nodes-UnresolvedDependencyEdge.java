public class UnresolvedDependencyEdge implements DependencyEdge {
  private final UnresolvedDependencyResult dependency;
  private final ModuleComponentIdentifier actual;
  public UnresolvedDependencyEdge(  UnresolvedDependencyResult dependency){
    this.dependency=dependency;
    ModuleComponentSelector attempted=(ModuleComponentSelector)dependency.getAttempted();
    actual=DefaultModuleComponentIdentifier.newId(attempted.getModuleIdentifier(),attempted.getVersionConstraint().getPreferredVersion());
  }
  public Throwable getFailure(){
    return dependency.getFailure();
  }
  @Override public boolean isResolvable(){
    return false;
  }
  @Override public ComponentSelector getRequested(){
    return dependency.getRequested();
  }
  @Override public ModuleComponentIdentifier getActual(){
    return actual;
  }
  @Override public ComponentSelectionReason getReason(){
    return dependency.getAttemptedReason();
  }
  @Override public ResolvedVariantResult getSelectedVariant(){
    return null;
  }
  @Override public ComponentIdentifier getFrom(){
    return dependency.getFrom().getId();
  }
  @Override public Set<? extends RenderableDependency> getChildren(){
    return Collections.singleton(new InvertedRenderableModuleResult(dependency.getFrom()));
  }
}
