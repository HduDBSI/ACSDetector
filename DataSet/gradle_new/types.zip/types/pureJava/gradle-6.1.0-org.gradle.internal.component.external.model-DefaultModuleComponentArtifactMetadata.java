public class DefaultModuleComponentArtifactMetadata implements ModuleComponentArtifactMetadata {
  private final DefaultModuleComponentArtifactIdentifier id;
  public DefaultModuleComponentArtifactMetadata(  ModuleComponentIdentifier componentIdentifier,  IvyArtifactName artifact){
    this(new DefaultModuleComponentArtifactIdentifier(componentIdentifier,artifact));
  }
  public DefaultModuleComponentArtifactMetadata(  ModuleComponentArtifactIdentifier moduleComponentArtifactIdentifier){
    this.id=(DefaultModuleComponentArtifactIdentifier)moduleComponentArtifactIdentifier;
  }
  @Override public String toString(){
    return id.toString();
  }
  @Override public ModuleComponentArtifactIdentifier getId(){
    return id;
  }
  @Override public ComponentIdentifier getComponentId(){
    return id.getComponentIdentifier();
  }
  @Override public ArtifactIdentifier toArtifactIdentifier(){
    return new DefaultArtifactIdentifier(id);
  }
  @Override public IvyArtifactName getName(){
    return id.getName();
  }
  @Override public TaskDependency getBuildDependencies(){
    return TaskDependencyInternal.EMPTY;
  }
}
