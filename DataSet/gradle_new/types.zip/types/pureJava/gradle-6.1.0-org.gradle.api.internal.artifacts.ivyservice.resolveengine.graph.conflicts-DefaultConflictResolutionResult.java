class DefaultConflictResolutionResult implements ConflictResolutionResult {
  private static ComponentState findComponent(  Object selected){
    if (selected instanceof ComponentState) {
      return (ComponentState)selected;
    }
    if (selected instanceof NodeState) {
      return ((NodeState)selected).getComponent();
    }
    throw new IllegalArgumentException("Cannot extract a ComponentState from " + selected.getClass());
  }
  private final Collection<? extends ModuleIdentifier> participatingModules;
  private final ComponentState selected;
  public DefaultConflictResolutionResult(  Collection<? extends ModuleIdentifier> participatingModules,  Object selected){
    this.selected=findComponent(selected);
    this.participatingModules=participatingModules.stream().sorted((first,second) -> {
      if (this.selected.getId().getModule().equals(first)) {
        return -1;
      }
 else       if (this.selected.getId().getModule().equals(second)) {
        return 1;
      }
      return 0;
    }
).collect(Collectors.toList());
  }
  @Override public void withParticipatingModules(  Action<? super ModuleIdentifier> action){
    for (    ModuleIdentifier module : participatingModules) {
      action.execute(module);
    }
  }
  @Override public ComponentState getSelected(){
    return selected;
  }
}
