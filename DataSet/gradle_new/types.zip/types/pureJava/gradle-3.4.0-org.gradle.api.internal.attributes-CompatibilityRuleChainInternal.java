public interface CompatibilityRuleChainInternal<T> extends CompatibilityRuleChain<T>, Action<CompatibilityCheckDetails<T>> {
  boolean isCompatibleWhenMissing();
}
