/** 
 * {@code DefaultTask} is the standard {@link Task} implementation. You can extend this to implement your own task types.
 */
@NoConventionMapping public class DefaultTask extends AbstractTask {
}
