public interface FileTreeInternal extends FileTree, FileCollectionInternal {
}
