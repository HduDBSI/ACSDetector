/** 
 * A target platform for building C++ binaries.
 * @since 4.5
 */
@Incubating public interface CppPlatform extends NativePlatform {
}
