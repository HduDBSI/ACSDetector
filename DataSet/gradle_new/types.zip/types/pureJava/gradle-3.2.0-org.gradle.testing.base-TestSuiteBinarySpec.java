/** 
 * A binary which runs a suite of tests.
 */
@Incubating public interface TestSuiteBinarySpec extends BinarySpec {
  /** 
 * Returns the test suite that this binary belongs to.
 */
  TestSuiteSpec getTestSuite();
  /** 
 * Returns the binary tested by this test suite.
 */
  BinarySpec getTestedBinary();
}
