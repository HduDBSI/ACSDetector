class SwiftLinker extends AbstractCompiler<LinkerSpec> {
  SwiftLinker(  BuildOperationExecutor buildOperationExecutor,  CommandLineToolInvocationWorker commandLineToolInvocationWorker,  CommandLineToolContext invocationContext,  WorkerLeaseService workerLeaseService){
    super(buildOperationExecutor,commandLineToolInvocationWorker,invocationContext,new SwiftCompileArgsTransformer(),false,workerLeaseService);
  }
  @Override protected void addOptionsFileArgs(  List<String> args,  File tempDir){
  }
  @Override protected Action<BuildOperationQueue<CommandLineToolInvocation>> newInvocationAction(  final LinkerSpec spec,  List<String> args){
    final CommandLineToolInvocation invocation=newInvocation("linking " + spec.getOutputFile().getName(),spec.getOutputFile().getParentFile(),args,spec.getOperationLogger());
    return new Action<BuildOperationQueue<CommandLineToolInvocation>>(){
      @Override public void execute(      BuildOperationQueue<CommandLineToolInvocation> buildQueue){
        buildQueue.setLogLocation(spec.getOperationLogger().getLogLocation());
        buildQueue.add(invocation);
      }
    }
;
  }
private static class SwiftCompileArgsTransformer implements ArgsTransformer<LinkerSpec> {
    @Override public List<String> transform(    LinkerSpec spec){
      List<String> args=new ArrayList<String>();
      args.addAll(spec.getSystemArgs());
      if (spec instanceof SharedLibraryLinkerSpec) {
        args.add("-emit-library");
      }
 else       if (spec instanceof BundleLinkerSpec) {
        args.add("-Xlinker");
        args.add("-bundle");
      }
 else {
        args.add("-emit-executable");
      }
      args.add("-o");
      args.add(spec.getOutputFile().getAbsolutePath());
      for (      File file : spec.getObjectFiles()) {
        args.add(file.getAbsolutePath());
      }
      for (      File file : spec.getLibraries()) {
        args.add(file.getAbsolutePath());
      }
      if (!spec.getLibraryPath().isEmpty()) {
        throw new UnsupportedOperationException("Library Path not yet supported on Swiftc");
      }
      for (      String userArg : spec.getArgs()) {
        args.add(userArg);
      }
      return args;
    }
  }
}
