public interface InterfaceFileCollectionBean {
  ConfigurableFileCollection getProp();
}
