public class DefaultImportsReader implements ImportsReader {
  private static final String RESOURCE="/default-imports.txt";
  private static final String MAPPING_RESOURCE="/api-mapping.txt";
  private final String[] importPackages;
  private final Map<String,List<String>> simpleNameToFQCN;
  public DefaultImportsReader(){
    try {
      URL url=getClass().getResource(RESOURCE);
      if (url == null) {
        throw new IllegalStateException("Could not load default imports resource: " + RESOURCE);
      }
      this.importPackages=Resources.asCharSource(url,Charsets.UTF_8).readLines(new LineProcessor<String[]>(){
        private final List<String> packages=Lists.newLinkedList();
        @Override public boolean processLine(        @SuppressWarnings("NullableProblems") String line) throws IOException {
          packages.add(line.substring(7,line.length() - 2));
          return true;
        }
        @Override public String[] getResult(){
          return packages.toArray(new String[0]);
        }
      }
);
      url=getClass().getResource(MAPPING_RESOURCE);
      if (url == null) {
        throw new IllegalStateException("Could not load default imports resource: " + MAPPING_RESOURCE);
      }
      this.simpleNameToFQCN=Resources.asCharSource(url,Charsets.UTF_8).readLines(new LineProcessor<Map<String,List<String>>>(){
        private final ImmutableMap.Builder<String,List<String>> builder=ImmutableMap.builder();
        @Override public boolean processLine(        String line) throws IOException {
          boolean process=!StringUtils.isEmpty(line);
          if (process) {
            String[] split=line.split(":");
            if (split.length == 2) {
              String simpleName=split[0];
              List<String> fqcns=Splitter.on(';').omitEmptyStrings().splitToList(split[1]);
              builder.put(simpleName,fqcns);
            }
 else {
              process=false;
            }
          }
          return process;
        }
        @Override public Map<String,List<String>> getResult(){
          return builder.build();
        }
      }
);
    }
 catch (    IOException e) {
      throw new UncheckedIOException(e);
    }
  }
  @Override public String[] getImportPackages(){
    return importPackages;
  }
  @Override public Map<String,List<String>> getSimpleNameToFullClassNamesMapping(){
    return simpleNameToFQCN;
  }
}
