public class DefaultBuildTypeContainer extends AbstractNamedDomainObjectContainer<BuildType> implements BuildTypeContainer {
  public DefaultBuildTypeContainer(  Instantiator instantiator){
    super(BuildType.class,instantiator);
  }
  @Override protected BuildType doCreate(  String name){
    return getInstantiator().newInstance(DefaultBuildType.class,name);
  }
}
