public class GradleProfilerReporter implements DataReporter<PerformanceTestResult> {
  private static final String DEBUG_ARTIFACTS_DIRECTORY_PROPERTY_NAME="org.gradle.performance.debugArtifactsDirectory";
  private BenchmarkResultCollector resultCollector;
  private final File debugArtifactsDirectory;
  public GradleProfilerReporter(  File fallbackDirectory){
    String debugArtifactsDirectoryPath=System.getProperty(DEBUG_ARTIFACTS_DIRECTORY_PROPERTY_NAME);
    this.debugArtifactsDirectory=Strings.isNullOrEmpty(debugArtifactsDirectoryPath) ? fallbackDirectory : new File(debugArtifactsDirectoryPath);
  }
  @Override public void report(  PerformanceTestResult results){
    resultCollector.summarizeResults(line -> System.out.println("  " + line));
    try {
      resultCollector.write();
    }
 catch (    IOException e) {
      throw new UncheckedIOException(e);
    }
  }
  public BenchmarkResultCollector getResultCollector(  String displayName){
    if (resultCollector == null) {
      File baseDir=new File(debugArtifactsDirectory,displayName.replaceAll("[^a-zA-Z0-9]","_"));
      baseDir.mkdirs();
      this.resultCollector=new BenchmarkResultCollector(new CsvGenerator(new File(baseDir,"benchmark.csv"),CsvGenerator.Format.LONG),new HtmlGenerator(new File(baseDir,"benchmark.html")));
    }
    return resultCollector;
  }
  @Override public void close(){
  }
}
