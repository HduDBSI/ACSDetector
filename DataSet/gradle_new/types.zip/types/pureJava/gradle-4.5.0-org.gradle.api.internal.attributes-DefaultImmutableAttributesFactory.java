public class DefaultImmutableAttributesFactory implements ImmutableAttributesFactory {
  private final ImmutableAttributes root;
  private final Map<ImmutableAttributes,List<DefaultImmutableAttributes>> children;
  private final IsolatableFactory isolatableFactory;
  public DefaultImmutableAttributesFactory(  IsolatableFactory isolatableFactory){
    this.isolatableFactory=isolatableFactory;
    this.root=ImmutableAttributes.EMPTY;
    this.children=Maps.newHashMap();
    children.put(root,new ArrayList<DefaultImmutableAttributes>());
  }
  public int size(){
    return children.size();
  }
  @Override public AttributeContainerInternal mutable(){
    return new DefaultMutableAttributeContainer(this);
  }
  @Override public AttributeContainerInternal mutable(  AttributeContainerInternal parent){
    return new DefaultMutableAttributeContainer(this,parent);
  }
  @Override public <T>ImmutableAttributes of(  Attribute<T> key,  T value){
    return concat(root,key,value);
  }
  @Override public <T>ImmutableAttributes concat(  ImmutableAttributes node,  Attribute<T> key,  T value){
    return concat(node,key,isolatableFactory.isolate(value));
  }
  @Override public <T>ImmutableAttributes concat(  ImmutableAttributes node,  Attribute<T> key,  Isolatable<T> value){
synchronized (this) {
      List<DefaultImmutableAttributes> nodeChildren=children.get(node);
      if (nodeChildren == null) {
        nodeChildren=Lists.newArrayList();
        children.put(node,nodeChildren);
      }
      for (      DefaultImmutableAttributes child : nodeChildren) {
        if (child.attribute.equals(key) && child.value.equals(value)) {
          return child;
        }
      }
      DefaultImmutableAttributes child=new DefaultImmutableAttributes((DefaultImmutableAttributes)node,key,value);
      nodeChildren.add(child);
      return child;
    }
  }
  public ImmutableAttributes getRoot(){
    return root;
  }
  @Override public ImmutableAttributes concat(  ImmutableAttributes attributes1,  ImmutableAttributes attributes2){
    ImmutableAttributes current=attributes2;
    for (    Attribute attribute : attributes1.keySet()) {
      if (!current.contains(attribute)) {
        current=concat(current,attribute,attributes1.getAttribute(attribute));
      }
    }
    return current;
  }
}
