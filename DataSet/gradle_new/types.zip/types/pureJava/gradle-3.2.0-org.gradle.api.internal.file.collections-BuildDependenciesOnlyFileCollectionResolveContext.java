/** 
 * <p>A  {@link FileCollectionResolveContext} which is used to determine the builder dependencies of a file collection hierarchy.
 */
public class BuildDependenciesOnlyFileCollectionResolveContext implements FileCollectionResolveContext {
  private final TaskDependencyResolveContext taskContext;
  public BuildDependenciesOnlyFileCollectionResolveContext(  TaskDependencyResolveContext taskContext){
    this.taskContext=taskContext;
  }
  @Override public FileCollectionResolveContext push(  PathToFileResolver fileResolver){
    return this;
  }
  @Override public ResolvableFileCollectionResolveContext newContext(){
    throw new UnsupportedOperationException();
  }
  @Override public FileCollectionResolveContext add(  Object element){
    if (element instanceof FileCollection) {
      taskContext.add(element);
    }
 else     if (element instanceof MinimalFileCollection && element instanceof Buildable) {
      taskContext.add(element);
    }
 else     if (element instanceof Task) {
      Task task=(Task)element;
      taskContext.add(task);
    }
 else     if (element instanceof TaskOutputs) {
      TaskOutputs outputs=(TaskOutputs)element;
      taskContext.add(outputs.getFiles());
    }
 else     if (element instanceof Closure) {
      Closure closure=(Closure)element;
      Object closureResult=closure.call();
      if (closureResult != null) {
        add(closureResult);
      }
    }
 else     if (element instanceof Callable) {
      Callable callable=(Callable)element;
      Object callableResult=uncheckedCall(callable);
      if (callableResult != null) {
        add(callableResult);
      }
    }
 else     if (element instanceof Iterable) {
      Iterable<?> iterable=(Iterable)element;
      for (      Object value : iterable) {
        add(value);
      }
    }
 else     if (element instanceof Object[]) {
      Object[] array=(Object[])element;
      for (      Object value : array) {
        add(value);
      }
    }
    return this;
  }
}
