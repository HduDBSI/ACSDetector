public class IncrementalCompilerFactory {
  private final FileOperations fileOperations;
  private final StreamHasher streamHasher;
  private final GeneralCompileCaches generalCompileCaches;
  private final BuildOperationExecutor buildOperationExecutor;
  private final StringInterner interner;
  private final FileSystemSnapshotter fileSystemSnapshotter;
  private final FileHasher fileHasher;
  public IncrementalCompilerFactory(  FileOperations fileOperations,  StreamHasher streamHasher,  GeneralCompileCaches generalCompileCaches,  BuildOperationExecutor buildOperationExecutor,  StringInterner interner,  FileSystemSnapshotter fileSystemSnapshotter,  FileHasher fileHasher){
    this.fileOperations=fileOperations;
    this.streamHasher=streamHasher;
    this.generalCompileCaches=generalCompileCaches;
    this.buildOperationExecutor=buildOperationExecutor;
    this.interner=interner;
    this.fileSystemSnapshotter=fileSystemSnapshotter;
    this.fileHasher=fileHasher;
  }
  public <T extends JavaCompileSpec>Compiler<T> makeIncremental(  CleaningJavaCompilerSupport<T> cleaningJavaCompiler,  String taskPath,  FileTree sources,  RecompilationSpecProvider recompilationSpecProvider){
    TaskScopedCompileCaches compileCaches=createCompileCaches(taskPath);
    Compiler<T> rebuildAllCompiler=createRebuildAllCompiler(cleaningJavaCompiler,sources);
    ClassDependenciesAnalyzer analyzer=new CachingClassDependenciesAnalyzer(new DefaultClassDependenciesAnalyzer(interner),compileCaches.getClassAnalysisCache());
    ClasspathEntrySnapshotter classpathEntrySnapshotter=new CachingClasspathEntrySnapshotter(fileHasher,streamHasher,fileSystemSnapshotter,analyzer,compileCaches.getClasspathEntrySnapshotCache(),fileOperations);
    ClasspathSnapshotMaker classpathSnapshotMaker=new ClasspathSnapshotMaker(new ClasspathSnapshotFactory(classpathEntrySnapshotter,buildOperationExecutor));
    PreviousCompilationOutputAnalyzer previousCompilationOutputAnalyzer=new PreviousCompilationOutputAnalyzer(fileHasher,streamHasher,analyzer,fileOperations);
    IncrementalCompilerDecorator<T> incrementalSupport=new IncrementalCompilerDecorator<T>(classpathSnapshotMaker,compileCaches,cleaningJavaCompiler,rebuildAllCompiler,previousCompilationOutputAnalyzer,interner);
    return incrementalSupport.prepareCompiler(recompilationSpecProvider);
  }
  private TaskScopedCompileCaches createCompileCaches(  String path){
    final PreviousCompilationStore previousCompilationStore=generalCompileCaches.createPreviousCompilationStore(path);
    return new TaskScopedCompileCaches(){
      @Override public ClassAnalysisCache getClassAnalysisCache(){
        return generalCompileCaches.getClassAnalysisCache();
      }
      @Override public ClasspathEntrySnapshotCache getClasspathEntrySnapshotCache(){
        return generalCompileCaches.getClasspathEntrySnapshotCache();
      }
      @Override public PreviousCompilationStore getPreviousCompilationStore(){
        return previousCompilationStore;
      }
    }
;
  }
  private <T extends JavaCompileSpec>Compiler<T> createRebuildAllCompiler(  final CleaningJavaCompilerSupport<T> cleaningJavaCompiler,  final FileTree sourceFiles){
    return new Compiler<T>(){
      @Override public WorkResult execute(      T spec){
        spec.setSourceFiles(sourceFiles);
        return cleaningJavaCompiler.execute(spec);
      }
    }
;
  }
}
