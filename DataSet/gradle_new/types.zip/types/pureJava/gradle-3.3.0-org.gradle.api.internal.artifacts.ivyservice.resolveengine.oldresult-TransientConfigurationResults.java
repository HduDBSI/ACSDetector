public interface TransientConfigurationResults {
  Map<ModuleDependency,DependencyGraphNodeResult> getFirstLevelDependencies();
  DependencyGraphNodeResult getRootNode();
}
