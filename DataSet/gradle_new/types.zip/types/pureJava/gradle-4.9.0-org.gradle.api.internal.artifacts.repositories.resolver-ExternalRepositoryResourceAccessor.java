public class ExternalRepositoryResourceAccessor implements RepositoryResourceAccessor, ImplicitInputsProvidingService<String,Long,RepositoryResourceAccessor> {
  private static final String SERVICE_TYPE=RepositoryResourceAccessor.class.getName();
  private final URI rootUri;
  private final String rootUriAsString;
  private final ExternalResourceAccessor resourceResolver;
  public ExternalRepositoryResourceAccessor(  URI rootUri,  CacheAwareExternalResourceAccessor cacheAwareExternalResourceAccessor,  FileStore<String> fileStore){
    this.rootUri=rootUri;
    this.rootUriAsString=rootUri.toString();
    this.resourceResolver=new DefaultExternalResourceAccessor(fileStore,cacheAwareExternalResourceAccessor);
  }
  @Override public void withResource(  String relativePath,  Action<? super InputStream> action){
    ExternalResourceName location=new ExternalResourceName(rootUri,relativePath);
    LocallyAvailableExternalResource resource=resourceResolver.resolveResource(location);
    if (resource != null) {
      resource.withContent(action);
    }
  }
  @Override public RepositoryResourceAccessor withImplicitInputRecorder(  final ImplicitInputRecorder registrar){
    return new RepositoryResourceAccessor(){
      @Override public void withResource(      String relativePath,      Action<? super InputStream> action){
        ExternalResourceName location=new ExternalResourceName(rootUri,relativePath);
        LocallyAvailableExternalResource resource=resourceResolver.resolveResource(location);
        registrar.register(SERVICE_TYPE,new ServiceCall(rootUriAsString + ";" + relativePath,hashFor(resource)));
        if (resource != null) {
          resource.withContent(action);
        }
      }
    }
;
  }
  @Nullable private static Long hashFor(  @Nullable LocallyAvailableExternalResource resource){
    return resource == null ? null : resource.getMetaData().getLastModified().getTime();
  }
  @Override public boolean isUpToDate(  String resource,  @Nullable Long oldValue){
    String[] parts=resource.split(";");
    if (!rootUriAsString.equals(parts[0])) {
      return false;
    }
    ExternalResourceName externalResourceName=new ExternalResourceName(rootUri,parts[1]);
    LocallyAvailableExternalResource locallyAvailableExternalResource=resourceResolver.resolveResource(externalResourceName);
    return Objects.equal(oldValue,hashFor(locallyAvailableExternalResource));
  }
private static class ServiceCall implements ImplicitInputRecord<String,Long> {
    private final String resource;
    private final Long hash;
    private ServiceCall(    String resource,    @Nullable Long resourceHash){
      this.resource=resource;
      this.hash=resourceHash;
    }
    @Override public String getInput(){
      return resource;
    }
    @Override public Long getOutput(){
      return hash;
    }
  }
}
