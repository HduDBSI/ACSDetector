public class SourceFile {
  private final String path;
  private final String name;
  private final String content;
  public SourceFile(  String path,  String name,  String content){
    this.content=content;
    this.path=path;
    this.name=name;
  }
  public String getPath(){
    return path;
  }
  public String getName(){
    return name;
  }
  public String getContent(){
    return content;
  }
  public TestFile writeToDir(  TestFile base){
    TestFile file=base.file(path,name);
    writeToFile(file);
    return file;
  }
  public void writeToFile(  TestFile file){
    if (file.exists()) {
      file.write("");
    }
    file.write(content);
  }
  public String withPath(  String basePath){
    return Joiner.on('/').join(basePath,path,name);
  }
}
