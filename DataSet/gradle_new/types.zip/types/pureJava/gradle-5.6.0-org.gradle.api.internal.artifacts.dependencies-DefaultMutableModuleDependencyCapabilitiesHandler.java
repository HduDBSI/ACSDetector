public class DefaultMutableModuleDependencyCapabilitiesHandler implements ModuleDependencyCapabilitiesInternal {
  private final NotationParser<Object,Capability> notationParser;
  private final Set<Capability> requestedCapabilities=Sets.newLinkedHashSet();
  public DefaultMutableModuleDependencyCapabilitiesHandler(  NotationParser<Object,Capability> notationParser){
    this.notationParser=notationParser;
  }
  @Override public void requireCapability(  Object capabilityNotation){
    requestedCapabilities.add(notationParser.parseNotation(capabilityNotation));
  }
  @Override public void requireCapabilities(  Object... capabilityNotations){
    for (    Object notation : capabilityNotations) {
      requireCapability(notation);
    }
  }
  @Override public List<Capability> getRequestedCapabilities(){
    return ImmutableList.copyOf(requestedCapabilities);
  }
  @Override public ModuleDependencyCapabilitiesInternal copy(){
    DefaultMutableModuleDependencyCapabilitiesHandler out=new DefaultMutableModuleDependencyCapabilitiesHandler(notationParser);
    out.requestedCapabilities.addAll(requestedCapabilities);
    return out;
  }
}
