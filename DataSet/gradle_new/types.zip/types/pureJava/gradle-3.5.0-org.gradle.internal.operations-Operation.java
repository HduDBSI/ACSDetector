interface Operation {
  /** 
 * Starts a child operation of the current worker. Marks the start of the build operation, reserving a lease. Blocks until a lease is available. Allows one child operation to proceed without a lease, so that the child effectively borrows the parent's lease, on the assumption that the parent is not doing any real work while children are running. <p>Note that the caller must call  {@link Completion#operationFinish()} to mark the completion of the operation and to release the lease for other threads to use.
 */
  Completion operationStart();
}
