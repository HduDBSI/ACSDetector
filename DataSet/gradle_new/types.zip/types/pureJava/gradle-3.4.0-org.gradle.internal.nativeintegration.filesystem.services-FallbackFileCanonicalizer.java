class FallbackFileCanonicalizer implements FileCanonicalizer {
  @Override public File canonicalize(  File file) throws FileException {
    try {
      return file.getCanonicalFile();
    }
 catch (    IOException e) {
      throw new FileException(String.format("Could not canonicalize file %s.",file),e);
    }
  }
}
