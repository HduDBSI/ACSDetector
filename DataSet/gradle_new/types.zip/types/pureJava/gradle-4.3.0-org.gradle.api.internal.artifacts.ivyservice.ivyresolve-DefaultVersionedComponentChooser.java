class DefaultVersionedComponentChooser implements VersionedComponentChooser {
  private final ComponentSelectionRulesProcessor rulesProcessor=new ComponentSelectionRulesProcessor();
  private final VersionComparator versionComparator;
  private final ComponentSelectionRulesInternal componentSelectionRules;
  DefaultVersionedComponentChooser(  VersionComparator versionComparator,  ComponentSelectionRulesInternal componentSelectionRules){
    this.versionComparator=versionComparator;
    this.componentSelectionRules=componentSelectionRules;
  }
  public ComponentResolveMetadata selectNewestComponent(  ComponentResolveMetadata one,  ComponentResolveMetadata two){
    if (one == null || two == null) {
      return two == null ? one : two;
    }
    int comparison=versionComparator.compare(new VersionInfo(one.getId().getVersion()),new VersionInfo(two.getId().getVersion()));
    if (comparison == 0) {
      if (isMissingModuleDescriptor(one) && !isMissingModuleDescriptor(two)) {
        return two;
      }
      return one;
    }
    return comparison < 0 ? two : one;
  }
  private boolean isMissingModuleDescriptor(  ComponentResolveMetadata componentResolveMetadata){
    return componentResolveMetadata.isMissing();
  }
  public void selectNewestMatchingComponent(  Collection<? extends ModuleComponentResolveState> versions,  ComponentSelectionContext result,  VersionSelector requestedVersionMatcher){
    Collection<SpecRuleAction<? super ComponentSelection>> rules=componentSelectionRules.getRules();
    for (    ModuleComponentResolveState candidate : sortLatestFirst(versions)) {
      MetadataProvider metadataProvider=createMetadataProvider(candidate);
      boolean versionMatches=versionMatches(requestedVersionMatcher,candidate,metadataProvider);
      if (metadataIsNotUsable(result,metadataProvider)) {
        return;
      }
      String version=candidate.getVersion().getSource();
      if (!versionMatches) {
        result.notMatched(version);
        continue;
      }
      ModuleComponentIdentifier candidateIdentifier=candidate.getId();
      if (!isRejectedByRules(candidateIdentifier,rules,metadataProvider)) {
        result.matches(candidateIdentifier);
        return;
      }
      result.rejected(version);
      if (requestedVersionMatcher.matchesUniqueVersion()) {
        break;
      }
    }
    result.noMatchFound();
  }
  /** 
 * This method checks if the metadata provider already knows that metadata for this version is not usable. If that's the case it means it's not necessary to perform more checks for this version, because we already know it's broken in some way.
 * @param result where to notify that metadata is broken, if broken
 * @param metadataProvider the metadata provider
 * @return true if metadata is not usable
 */
  private boolean metadataIsNotUsable(  ComponentSelectionContext result,  MetadataProvider metadataProvider){
    if (!metadataProvider.isUsable()) {
      applyTo(metadataProvider,result);
      return true;
    }
    return false;
  }
  private static MetadataProvider createMetadataProvider(  ModuleComponentResolveState candidate){
    return new MetadataProvider(candidate);
  }
  private static void applyTo(  MetadataProvider provider,  ComponentSelectionContext result){
    BuildableModuleComponentMetaDataResolveResult metaDataResult=provider.getResult();
switch (metaDataResult.getState()) {
case Unknown:
      result.noMatchFound();
    break;
case Missing:
  result.noMatchFound();
break;
case Failed:
result.failed(metaDataResult.getFailure());
break;
default :
throw new IllegalStateException("Unexpected meta-data resolution result.");
}
}
private static boolean versionMatches(VersionSelector selector,ModuleComponentResolveState component,MetadataProvider metadataProvider){
if (selector.requiresMetadata()) {
ComponentMetadata componentMetadata=metadataProvider.getComponentMetadata();
return componentMetadata != null && selector.accept(componentMetadata);
}
 else {
return selector.accept(component.getVersion());
}
}
public boolean isRejectedComponent(ModuleComponentIdentifier candidateIdentifier,MetadataProvider metadataProvider){
return isRejectedByRules(candidateIdentifier,componentSelectionRules.getRules(),metadataProvider);
}
private boolean isRejectedByRules(ModuleComponentIdentifier candidateIdentifier,Collection<SpecRuleAction<? super ComponentSelection>> rules,MetadataProvider metadataProvider){
ComponentSelectionInternal selection=new DefaultComponentSelection(candidateIdentifier);
rulesProcessor.apply(selection,rules,metadataProvider);
return selection.isRejected();
}
private List<ModuleComponentResolveState> sortLatestFirst(Collection<? extends ModuleComponentResolveState> listing){
return CollectionUtils.sort(listing,Collections.reverseOrder(versionComparator));
}
}
