public class ExistingTaskProvider<I extends T> extends DefaultTaskProvider<I> {
  private final I task;
  public ExistingTaskProvider(  I task,  TaskIdentity<I> identity){
    super(identity);
    this.task=task;
  }
  @Override public void configure(  Action<? super I> action){
    action.execute(task);
  }
  @Override public boolean isPresent(){
    return true;
  }
  public I getOrNull(){
    return task;
  }
}
