/** 
 * A shared library built from Swift source.
 * @since 4.2
 */
@Incubating public interface SwiftSharedLibrary extends SwiftBinary {
  /** 
 * Returns the run-time file for this binary.
 * @since 4.4
 */
  Provider<RegularFile> getRuntimeFile();
}
