public class MaybeCompressedFileResource implements ReadableResourceInternal {
  private final ReadableResourceInternal resource;
  public MaybeCompressedFileResource(  ReadableResourceInternal resource){
    if (resource instanceof CompressedReadableResource) {
      this.resource=resource;
    }
 else {
      String ext=FilenameUtils.getExtension(resource.getURI().toString());
      if (Compression.BZIP2.getSupportedExtensions().contains(ext)) {
        this.resource=new Bzip2Archiver(resource);
      }
 else       if (Compression.GZIP.getSupportedExtensions().contains(ext)) {
        this.resource=new GzipArchiver(resource);
      }
 else {
        this.resource=resource;
      }
    }
  }
  public InputStream read() throws MissingResourceException {
    return resource.read();
  }
  public ReadableResource getResource(){
    return resource;
  }
  public String getDisplayName(){
    return resource.getDisplayName();
  }
  public URI getURI(){
    return resource.getURI();
  }
  public String getBaseName(){
    return resource.getBaseName();
  }
  public File getBackingFile(){
    return resource.getBackingFile();
  }
}
