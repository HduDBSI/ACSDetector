public class ComponentArtifactMetadataSerializer extends AbstractSerializer<ComponentArtifactMetadata> {
  private final ComponentIdentifierSerializer componentIdentifierSerializer=new ComponentIdentifierSerializer();
  public void write(  Encoder encoder,  ComponentArtifactMetadata value) throws Exception {
    if (value instanceof ModuleComponentArtifactMetadata) {
      ModuleComponentArtifactMetadata moduleComponentArtifactMetadata=(ModuleComponentArtifactMetadata)value;
      componentIdentifierSerializer.write(encoder,moduleComponentArtifactMetadata.getComponentId());
      IvyArtifactName ivyArtifactName=moduleComponentArtifactMetadata.getName();
      encoder.writeString(ivyArtifactName.getName());
      encoder.writeString(ivyArtifactName.getType());
      encoder.writeNullableString(ivyArtifactName.getExtension());
      encoder.writeNullableString(ivyArtifactName.getClassifier());
    }
 else {
      throw new IllegalArgumentException("Unknown artifact metadata type.");
    }
  }
  public ComponentArtifactMetadata read(  Decoder decoder) throws Exception {
    ModuleComponentIdentifier componentIdentifier=(ModuleComponentIdentifier)componentIdentifierSerializer.read(decoder);
    String artifactName=decoder.readString();
    String type=decoder.readString();
    String extension=decoder.readNullableString();
    String classifier=decoder.readNullableString();
    return new DefaultModuleComponentArtifactMetadata(componentIdentifier,new DefaultIvyArtifactName(artifactName,type,extension,classifier));
  }
  @Override public boolean equals(  Object obj){
    if (!super.equals(obj)) {
      return false;
    }
    ComponentArtifactMetadataSerializer rhs=(ComponentArtifactMetadataSerializer)obj;
    return Objects.equal(componentIdentifierSerializer,rhs.componentIdentifierSerializer);
  }
  @Override public int hashCode(){
    return Objects.hashCode(super.hashCode(),componentIdentifierSerializer);
  }
}
