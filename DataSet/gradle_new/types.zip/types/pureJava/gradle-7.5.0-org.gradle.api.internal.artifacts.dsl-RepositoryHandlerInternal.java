public interface RepositoryHandlerInternal extends RepositoryHandler {
  boolean isExclusiveContentInUse();
}
