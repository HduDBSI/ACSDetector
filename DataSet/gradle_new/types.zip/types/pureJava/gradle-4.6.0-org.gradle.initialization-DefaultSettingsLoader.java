/** 
 * Handles locating and processing setting.gradle files.  Also deals with the buildSrc module, since that modules is found after settings is located, but needs to be built before settings is processed.
 */
public class DefaultSettingsLoader implements SettingsLoader {
  private ISettingsFinder settingsFinder;
  private SettingsProcessor settingsProcessor;
  private BuildSourceBuilder buildSourceBuilder;
  public DefaultSettingsLoader(  ISettingsFinder settingsFinder,  SettingsProcessor settingsProcessor,  BuildSourceBuilder buildSourceBuilder){
    this.settingsFinder=settingsFinder;
    this.settingsProcessor=settingsProcessor;
    this.buildSourceBuilder=buildSourceBuilder;
  }
  @Override public SettingsInternal findAndLoadSettings(  GradleInternal gradle){
    StartParameter startParameter=gradle.getStartParameter();
    SettingsInternal settings=findSettingsAndLoadIfAppropriate(gradle,startParameter);
    ProjectSpec spec=ProjectSpecs.forStartParameter(startParameter,settings);
    if (spec.containsProject(settings.getProjectRegistry())) {
      setDefaultProject(spec,settings);
      return settings;
    }
    deprecateWarningIfNecessary(startParameter,settings);
    StartParameter noSearchParameter=startParameter.newInstance();
    noSearchParameter.useEmptySettings();
    settings=findSettingsAndLoadIfAppropriate(gradle,noSearchParameter);
    if (noSearchParameter.getBuildFile() != null) {
      ProjectDescriptor rootProject=settings.getRootProject();
      rootProject.setBuildFileName(noSearchParameter.getBuildFile().getName());
    }
    setDefaultProject(spec,settings);
    return settings;
  }
  private void deprecateWarningIfNecessary(  StartParameter startParameter,  SettingsInternal settings){
    if (startParameter.getSettingsFile() != null) {
      return;
    }
    File projectDir=startParameter.getProjectDir() == null ? startParameter.getCurrentDir() : startParameter.getProjectDir();
    if (settings.getSettingsDir().equals(projectDir)) {
      return;
    }
    for (    ProjectDescriptor project : settings.getProjectRegistry().getAllProjects()) {
      if (project.getProjectDir().equals(projectDir)) {
        return;
      }
    }
    DeprecationLogger.nagUserWith("Support for nested build without a settings file was deprecated and will be removed in Gradle 5.0. You should create a empty settings file in " + projectDir.getAbsolutePath());
  }
  private void setDefaultProject(  ProjectSpec spec,  SettingsInternal settings){
    settings.setDefaultProject(spec.selectProject(settings.getProjectRegistry()));
  }
  /** 
 * Finds the settings.gradle for the given startParameter, and loads it if contains the project selected by the startParameter, or if the startParameter explicitly specifies a settings script.  If the settings file is not loaded (executed), then a null is returned.
 */
  private SettingsInternal findSettingsAndLoadIfAppropriate(  GradleInternal gradle,  StartParameter startParameter){
    SettingsLocation settingsLocation=findSettings(startParameter);
    StartParameter buildSrcStartParameter=startParameter.newBuild();
    buildSrcStartParameter.setCurrentDir(new File(settingsLocation.getSettingsDir(),DefaultSettings.DEFAULT_BUILD_SRC_DIR));
    ClassLoaderScope buildSourceClassLoaderScope=buildSourceBuilder.buildAndCreateClassLoader(gradle,buildSrcStartParameter);
    return settingsProcessor.process(gradle,settingsLocation,buildSourceClassLoaderScope,startParameter);
  }
  private SettingsLocation findSettings(  StartParameter startParameter){
    return settingsFinder.find(startParameter);
  }
}
