public class WorkerDaemonServer implements WorkerProtocol<ActionExecutionSpec> {
  private final InstantiatorFactory instantiatorFactory=new DefaultInstantiatorFactory(new AsmBackedClassGenerator());
  @Override public DefaultWorkResult execute(  ActionExecutionSpec spec){
    try {
      Class<? extends Runnable> implementationClass=spec.getImplementationClass();
      Runnable runnable=instantiatorFactory.inject().newInstance(implementationClass,spec.getParams(implementationClass.getClassLoader()));
      runnable.run();
      return new DefaultWorkResult(true,null);
    }
 catch (    Throwable t) {
      return new DefaultWorkResult(true,t);
    }
  }
  @Override public String toString(){
    return "WorkerDaemonServer{}";
  }
}
