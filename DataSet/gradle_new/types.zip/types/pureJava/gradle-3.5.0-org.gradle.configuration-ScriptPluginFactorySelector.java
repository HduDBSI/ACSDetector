/** 
 * Selects a  {@link ScriptPluginFactory} suitable for handling a given build script basedon its file name. Build script file names ending in ".gradle" are supported by the {@link DefaultScriptPluginFactory}. Other files are delegated to the first available implementation of the  {@link ScriptPluginFactoryProvider} SPI to return non-null from{@link ScriptPluginFactoryProvider#getFor(String)}. If all provider implementations return null for a given file name, handling falls back to the {@link DefaultScriptPluginFactory}. This approach allows users to name build scripts with a suffix of choice, e.g. "build.groovy" or "my.build" instead of the typical "build.gradle" while preserving default behaviour.
 * @see ScriptPluginFactoryProvider
 * @since 2.14
 */
@Incubating public class ScriptPluginFactorySelector implements ScriptPluginFactory {
  private final ScriptPluginFactory defaultScriptPluginFactory;
  private final ServiceRegistry serviceRegistry;
  public ScriptPluginFactorySelector(  ScriptPluginFactory defaultScriptPluginFactory,  ServiceRegistry serviceRegistry){
    this.defaultScriptPluginFactory=defaultScriptPluginFactory;
    this.serviceRegistry=serviceRegistry;
  }
  @Override public ScriptPlugin create(  ScriptSource scriptSource,  ScriptHandler scriptHandler,  ClassLoaderScope targetScope,  ClassLoaderScope baseScope,  boolean topLevelScript){
    return scriptPluginFactoryFor(scriptSource.getFileName()).create(scriptSource,scriptHandler,targetScope,baseScope,topLevelScript);
  }
  private ScriptPluginFactory scriptPluginFactoryFor(  String fileName){
    return fileName.endsWith(".gradle") ? defaultScriptPluginFactory : findScriptPluginFactoryFor(fileName);
  }
  private ScriptPluginFactory findScriptPluginFactoryFor(  String fileName){
    for (    ScriptPluginFactoryProvider scriptPluginFactoryProvider : scriptPluginFactoryProviders()) {
      ScriptPluginFactory scriptPluginFactory=scriptPluginFactoryProvider.getFor(fileName);
      if (scriptPluginFactory != null) {
        return scriptPluginFactory;
      }
    }
    return defaultScriptPluginFactory;
  }
  private Iterable<ScriptPluginFactoryProvider> scriptPluginFactoryProviders(){
    return serviceLoader().load(ScriptPluginFactoryProvider.class,getClass().getClassLoader());
  }
  private DependencyInjectingServiceLoader serviceLoader(){
    return new DependencyInjectingServiceLoader(serviceRegistry);
  }
}
