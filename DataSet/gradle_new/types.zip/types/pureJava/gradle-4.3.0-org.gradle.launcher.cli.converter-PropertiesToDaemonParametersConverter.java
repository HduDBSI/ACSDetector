public class PropertiesToDaemonParametersConverter {
  private List<BuildOption<DaemonParameters>> buildOptions=DaemonBuildOptions.get();
  public void convert(  Map<String,String> properties,  DaemonParameters target){
    for (    BuildOption<DaemonParameters> option : buildOptions) {
      option.applyFromProperty(properties,target);
    }
  }
}
