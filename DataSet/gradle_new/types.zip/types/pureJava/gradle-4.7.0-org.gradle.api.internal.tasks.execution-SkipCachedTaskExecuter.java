public class SkipCachedTaskExecuter implements TaskExecuter {
  private static final Logger LOGGER=LoggerFactory.getLogger(SkipCachedTaskExecuter.class);
  private final BuildCacheController buildCache;
  private final TaskExecuter delegate;
  private final TaskOutputChangesListener taskOutputChangesListener;
  private final TaskOutputCacheCommandFactory buildCacheCommandFactory;
  public SkipCachedTaskExecuter(  BuildCacheController buildCache,  TaskOutputChangesListener taskOutputChangesListener,  TaskOutputCacheCommandFactory buildCacheCommandFactory,  TaskExecuter delegate){
    this.taskOutputChangesListener=taskOutputChangesListener;
    this.buildCacheCommandFactory=buildCacheCommandFactory;
    this.buildCache=buildCache;
    this.delegate=delegate;
  }
  @Override public void execute(  final TaskInternal task,  TaskStateInternal state,  TaskExecutionContext context){
    LOGGER.debug("Determining if {} is cached already",task);
    TaskProperties taskProperties=context.getTaskProperties();
    TaskOutputCachingBuildCacheKey cacheKey=context.getBuildCacheKey();
    boolean taskOutputCachingEnabled=state.getTaskOutputCaching().isEnabled();
    SortedSet<ResolvedTaskOutputFilePropertySpec> outputProperties=null;
    if (taskOutputCachingEnabled) {
      if (task.isHasCustomActions()) {
        LOGGER.info("Custom actions are attached to {}.",task);
      }
      if (cacheKey.isValid()) {
        TaskArtifactState taskState=context.getTaskArtifactState();
        outputProperties=resolveProperties(taskProperties.getOutputFileProperties());
        if (taskState.isAllowedToUseCachedResults()) {
          try {
            OriginTaskExecutionMetadata originMetadata=buildCache.load(buildCacheCommandFactory.createLoad(cacheKey,outputProperties,task,taskProperties,taskOutputChangesListener,taskState));
            if (originMetadata != null) {
              state.setOutcome(TaskExecutionOutcome.FROM_CACHE);
              context.setOriginExecutionMetadata(originMetadata);
              return;
            }
          }
 catch (          UnrecoverableTaskOutputUnpackingException e) {
            throw e;
          }
catch (          Exception e) {
            LOGGER.warn("Failed to load cache entry for {}, falling back to executing task",task,e);
          }
        }
 else {
          LOGGER.info("Not loading {} from cache because pulling from cache is disabled for this task",task);
        }
      }
 else {
        LOGGER.info("Not caching {} because no valid cache key was generated",task);
      }
    }
    delegate.execute(task,state,context);
    if (taskOutputCachingEnabled) {
      if (cacheKey.isValid()) {
        if (state.getFailure() == null) {
          try {
            TaskArtifactState taskState=context.getTaskArtifactState();
            Map<String,Map<String,FileContentSnapshot>> outputSnapshots=taskState.getOutputContentSnapshots();
            buildCache.store(buildCacheCommandFactory.createStore(cacheKey,outputProperties,outputSnapshots,task,context.getExecutionTime()));
          }
 catch (          Exception e) {
            LOGGER.warn("Failed to store cache entry {}",cacheKey.getDisplayName(),task,e);
          }
        }
 else {
          LOGGER.debug("Not pushing result from {} to cache because the task failed",task);
        }
      }
 else {
        LOGGER.info("Not pushing results from {} to cache because no valid cache key was generated",task);
      }
    }
  }
  private static SortedSet<ResolvedTaskOutputFilePropertySpec> resolveProperties(  ImmutableSortedSet<? extends TaskOutputFilePropertySpec> properties){
    ImmutableSortedSet.Builder<ResolvedTaskOutputFilePropertySpec> builder=ImmutableSortedSet.naturalOrder();
    for (    TaskOutputFilePropertySpec property : properties) {
      CacheableTaskOutputFilePropertySpec cacheableProperty=(CacheableTaskOutputFilePropertySpec)property;
      builder.add(new ResolvedTaskOutputFilePropertySpec(cacheableProperty.getPropertyName(),cacheableProperty.getOutputType(),cacheableProperty.getOutputFile()));
    }
    return builder.build();
  }
}
