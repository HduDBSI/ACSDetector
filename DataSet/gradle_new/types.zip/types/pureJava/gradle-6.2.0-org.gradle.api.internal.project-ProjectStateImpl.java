private class ProjectStateImpl implements ProjectState {
  private final Path projectPath;
  private final String projectName;
  private final ProjectComponentIdentifier identifier;
  private final BuildState owner;
  private final Path identityPath;
  private final ResourceLock projectLock;
  private ProjectInternal project;
  ProjectStateImpl(  BuildState owner,  Path identityPath,  Path projectPath,  String projectName,  ProjectComponentIdentifier identifier){
    this.owner=owner;
    this.identityPath=identityPath;
    this.projectPath=projectPath;
    this.projectName=projectName;
    this.identifier=identifier;
    this.projectLock=workerLeaseService.getProjectLock(owner.getIdentityPath(),identityPath);
  }
  @Override public String toString(){
    return identifier.getDisplayName();
  }
  @Override public BuildState getOwner(){
    return owner;
  }
  @Nullable @Override public ProjectState getParent(){
    return identityPath.getParent() == null ? null : projectsByPath.get(identityPath.getParent());
  }
  @Override public String getName(){
    return projectName;
  }
  @Override public Path getIdentityPath(){
    return identityPath;
  }
  @Override public Path getProjectPath(){
    return projectPath;
  }
  @Override public void attachMutableModel(  ProjectInternal project){
synchronized (this) {
      if (this.project != null) {
        throw new IllegalStateException(String.format("The project object for project %s has already been attached.",getIdentityPath()));
      }
      this.project=project;
    }
  }
  @Override public ProjectInternal getMutableModel(){
synchronized (this) {
      if (project == null) {
        throw new IllegalStateException(String.format("The project object for project %s has not been attached yet.",getIdentityPath()));
      }
      return project;
    }
  }
  @Override public ProjectComponentIdentifier getComponentIdentifier(){
    return identifier;
  }
  @Override public ResourceLock getAccessLock(){
    return projectLock;
  }
  @Override public void withMutableState(  Runnable action){
    withMutableState(Factories.toFactory(action));
  }
  @Override public void withLenientState(  Runnable runnable){
    DefaultProjectStateRegistry.this.withLenientState(runnable);
  }
  @Override public <T>T withMutableState(  final Factory<? extends T> factory){
    if (LENIENT_MUTATION_STATE.get()) {
      return factory.create();
    }
    Collection<? extends ResourceLock> currentLocks=workerLeaseService.getCurrentProjectLocks();
    if (currentLocks.contains(projectLock)) {
      if (currentLocks.size() == 1) {
        return factory.create();
      }
 else {
        currentLocks=Lists.newArrayList(currentLocks);
        currentLocks.remove(projectLock);
        return workerLeaseService.withoutLocks(currentLocks,factory);
      }
    }
 else {
      if (!currentLocks.isEmpty()) {
        return workerLeaseService.withoutLocks(currentLocks,new Factory<T>(){
          @Nullable @Override public T create(){
            return withProjectLock(projectLock,factory);
          }
        }
);
      }
 else {
        return withProjectLock(projectLock,factory);
      }
    }
  }
  private <T>T withProjectLock(  ResourceLock projectLock,  final Factory<? extends T> factory){
    return workerLeaseService.withLocks(Collections.singleton(projectLock),factory);
  }
  @Override public boolean hasMutableState(){
    return LENIENT_MUTATION_STATE.get() || workerLeaseService.getCurrentProjectLocks().contains(projectLock);
  }
}
