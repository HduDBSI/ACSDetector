public class DefaultResolvedConfigurationBuilder implements ResolvedConfigurationBuilder {
  private final Set<UnresolvedDependency> unresolvedDependencies=new LinkedHashSet<UnresolvedDependency>();
  private final Map<Long,ModuleDependency> modulesMap=new HashMap<Long,ModuleDependency>();
  private final TransientConfigurationResultsBuilder builder;
  public DefaultResolvedConfigurationBuilder(  TransientConfigurationResultsBuilder builder){
    this.builder=builder;
  }
  public void addUnresolvedDependency(  UnresolvedDependency unresolvedDependency){
    unresolvedDependencies.add(unresolvedDependency);
  }
  @Override public void addFirstLevelDependency(  ModuleDependency moduleDependency,  DependencyGraphNode dependency){
    builder.firstLevelDependency(dependency.getResultId());
    modulesMap.put(dependency.getResultId(),moduleDependency);
  }
  @Override public void done(  DependencyGraphNode root){
    builder.done(root.getResultId());
  }
  @Override public void addChild(  DependencyGraphNode parent,  DependencyGraphNode child,  long artifactsId){
    builder.parentChildMapping(parent.getResultId(),child.getResultId(),artifactsId);
  }
  @Override public void newResolvedDependency(  DependencyGraphNode node){
    builder.resolvedDependency(node.getResultId(),node.getNodeId());
  }
  @Override public ResolvedGraphResults complete(){
    return new DefaultResolvedGraphResults(unresolvedDependencies,modulesMap);
  }
}
