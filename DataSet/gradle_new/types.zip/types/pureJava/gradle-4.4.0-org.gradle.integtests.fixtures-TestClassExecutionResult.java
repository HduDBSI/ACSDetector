public interface TestClassExecutionResult {
  /** 
 * Asserts that the given tests (and only the given tests) were executed for the given test class.
 */
  TestClassExecutionResult assertTestsExecuted(  String... testNames);
  TestClassExecutionResult assertTestCount(  int tests,  int failures,  int errors);
  /** 
 * Asserts that the given tests (and only the given tests) were skipped for the given test class.
 */
  TestClassExecutionResult assertTestsSkipped(  String... testNames);
  /** 
 * Asserts that the given test passed.
 */
  TestClassExecutionResult assertTestPassed(  String name);
  /** 
 * Asserts that the given test failed.
 */
  TestClassExecutionResult assertTestFailed(  String name,  Matcher<? super String>... messageMatchers);
  /** 
 * Asserts that the given test was skipped.
 */
  TestClassExecutionResult assertTestSkipped(  String name);
  /** 
 * Asserts that the given config method passed.
 */
  TestClassExecutionResult assertConfigMethodPassed(  String name);
  /** 
 * Asserts that the given config method failed.
 */
  TestClassExecutionResult assertConfigMethodFailed(  String name);
  TestClassExecutionResult assertStdout(  Matcher<? super String> matcher);
  TestClassExecutionResult assertTestCaseStdout(  String testCaseName,  Matcher<? super String> matcher);
  TestClassExecutionResult assertStderr(  Matcher<? super String> matcher);
  TestClassExecutionResult assertTestCaseStderr(  String testCaseName,  Matcher<? super String> matcher);
  TestClassExecutionResult assertExecutionFailedWithCause(  Matcher<? super String> causeMatcher);
}
