class MutableClassDetails implements ClassDetails {
  private final Class<?> type;
  private final MethodSet instanceMethods=new MethodSet();
  private final Map<String,MutablePropertyDetails> properties=new TreeMap<String,MutablePropertyDetails>();
  private final List<Method> methods=new ArrayList<Method>();
  private final Set<Class<?>> superTypes=new LinkedHashSet<Class<?>>();
  MutableClassDetails(  Class<?> type){
    this.type=type;
  }
  @Override public List<Method> getAllMethods(){
    return methods;
  }
  @Override public List<Method> getInstanceMethods(){
    return instanceMethods.getValues();
  }
  @Override public Set<Class<?>> getSuperTypes(){
    return superTypes;
  }
  @Override public Set<String> getPropertyNames(){
    return properties.keySet();
  }
  @Override public Collection<? extends PropertyDetails> getProperties(){
    return properties.values();
  }
  @Override public PropertyDetails getProperty(  String name) throws NoSuchPropertyException {
    MutablePropertyDetails property=properties.get(name);
    if (property == null) {
      throw new NoSuchPropertyException(String.format("No property '%s' found on %s.",name,type));
    }
    return property;
  }
  void superType(  Class<?> type){
    superTypes.add(type);
  }
  void method(  Method method){
    methods.add(method);
  }
  void instanceMethod(  Method method){
    instanceMethods.add(method);
  }
  MutablePropertyDetails property(  String propertyName){
    MutablePropertyDetails property=properties.get(propertyName);
    if (property == null) {
      property=new MutablePropertyDetails(propertyName);
      properties.put(propertyName,property);
    }
    return property;
  }
}
