/** 
 * A factory for a worker process which loads the application classes using the JVM's system ClassLoader. <p>Class loader hierarchy:</p> <pre> jvm bootstrap | | jvm system (GradleWorkerMain, application classes) | | filter (shared packages) | | implementation (SystemApplicationClassLoaderWorker, logging) (ActionExecutionWorker + worker action implementation) </pre>
 */
public class ApplicationClassesInSystemClassLoaderWorkerImplementationFactory {
  private final ClassPathRegistry classPathRegistry;
  private final TemporaryFileProvider temporaryFileProvider;
  private final File gradleUserHomeDir;
  public ApplicationClassesInSystemClassLoaderWorkerImplementationFactory(  ClassPathRegistry classPathRegistry,  TemporaryFileProvider temporaryFileProvider,  File gradleUserHomeDir){
    this.classPathRegistry=classPathRegistry;
    this.temporaryFileProvider=temporaryFileProvider;
    this.gradleUserHomeDir=gradleUserHomeDir;
  }
  /** 
 * Configures the Java command that will be used to launch the child process.
 */
  public void prepareJavaCommand(  long workerId,  String displayName,  WorkerProcessBuilder processBuilder,  List<URL> implementationClassPath,  List<URL> implementationModulePath,  Address serverAddress,  JavaExecHandleBuilder execSpec,  boolean publishProcessInfo,  boolean useOptionsFile){
    Collection<File> applicationClasspath=processBuilder.getApplicationClasspath();
    Set<File> applicationModulePath=processBuilder.getApplicationModulePath();
    LogLevel logLevel=processBuilder.getLogLevel();
    Set<String> sharedPackages=processBuilder.getSharedPackages();
    Object requestedSecurityManager=execSpec.getSystemProperties().get("java.security.manager");
    List<File> workerMainClassPath=classPathRegistry.getClassPath("WORKER_MAIN").getAsFiles();
    boolean runAsModule=!applicationModulePath.isEmpty() && execSpec.getModularity().getInferModulePath().get();
    if (runAsModule) {
      execSpec.getMainModule().set("gradle.worker");
    }
    execSpec.getMainClass().set("worker." + GradleWorkerMain.class.getName());
    if (useOptionsFile) {
      File optionsFile=temporaryFileProvider.createTemporaryFile("gradle-worker-classpath","txt");
      List<String> jvmArgs=writeOptionsFile(runAsModule,workerMainClassPath,implementationModulePath,applicationClasspath,applicationModulePath,optionsFile);
      execSpec.jvmArgs(jvmArgs);
    }
 else {
      execSpec.classpath(workerMainClassPath);
      execSpec.systemProperty("java.security.manager","worker." + BootstrapSecurityManager.class.getName());
    }
    StreamByteBuffer buffer=new StreamByteBuffer();
    try {
      DataOutputStream outstr=new DataOutputStream(new EncodedStream.EncodedOutput(buffer.getOutputStream()));
      if (!useOptionsFile) {
        outstr.writeInt(applicationClasspath.size());
        for (        File file : applicationClasspath) {
          outstr.writeUTF(file.getAbsolutePath());
        }
        outstr.writeUTF(requestedSecurityManager == null ? "" : requestedSecurityManager.toString());
      }
      outstr.writeInt(sharedPackages.size());
      for (      String str : sharedPackages) {
        outstr.writeUTF(str);
      }
      if (runAsModule || implementationModulePath == null) {
        outstr.writeInt(implementationClassPath.size());
        for (        URL entry : implementationClassPath) {
          outstr.writeUTF(entry.toString());
        }
      }
 else {
        outstr.writeInt(implementationClassPath.size() + implementationModulePath.size());
        for (        URL entry : implementationClassPath) {
          outstr.writeUTF(entry.toString());
        }
        for (        URL entry : implementationModulePath) {
          outstr.writeUTF(entry.toString());
        }
      }
      OutputStreamBackedEncoder encoder=new OutputStreamBackedEncoder(outstr);
      encoder.writeSmallInt(logLevel.ordinal());
      encoder.writeBoolean(publishProcessInfo);
      encoder.writeString(gradleUserHomeDir.getAbsolutePath());
      new MultiChoiceAddressSerializer().write(encoder,(MultiChoiceAddress)serverAddress);
      encoder.writeSmallLong(workerId);
      encoder.writeString(displayName);
      byte[] serializedWorker=GUtil.serialize(processBuilder.getWorker());
      encoder.writeBinary(serializedWorker);
      encoder.flush();
    }
 catch (    IOException e) {
      throw new UncheckedIOException(e);
    }
    execSpec.setStandardInput(buffer.getInputStream());
  }
  private List<String> writeOptionsFile(  boolean runAsModule,  Collection<File> workerMainClassPath,  Collection<URL> implementationModulePath,  Collection<File> applicationClasspath,  Set<File> applicationModulePath,  File optionsFile){
    List<File> classpath=new ArrayList<>();
    List<File> modulePath=new ArrayList<>();
    if (runAsModule) {
      modulePath.addAll(workerMainClassPath);
    }
 else {
      classpath.addAll(workerMainClassPath);
    }
    modulePath.addAll(applicationModulePath);
    classpath.addAll(applicationClasspath);
    if (!modulePath.isEmpty() && implementationModulePath != null && !implementationModulePath.isEmpty()) {
      modulePath.addAll(implementationModulePath.stream().map(url -> {
        try {
          return new File(url.toURI());
        }
 catch (        URISyntaxException e) {
          throw new RuntimeException(e);
        }
      }
).collect(Collectors.toList()));
    }
    List<String> argumentList=new ArrayList<>();
    if (!modulePath.isEmpty()) {
      argumentList.addAll(Arrays.asList("--module-path",Joiner.on(File.pathSeparator).join(modulePath),"--add-modules","ALL-MODULE-PATH"));
    }
    if (!classpath.isEmpty()) {
      argumentList.addAll(Arrays.asList("-cp",Joiner.on(File.pathSeparator).join(classpath)));
    }
    return ArgWriter.argsFileGenerator(optionsFile,ArgWriter.javaStyleFactory()).transform(argumentList);
  }
}
