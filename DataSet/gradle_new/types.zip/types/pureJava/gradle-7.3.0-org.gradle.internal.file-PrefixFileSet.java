private static class PrefixFileSet extends FileHierarchySet {
  private final Node rootNode;
  PrefixFileSet(  File rootDir){
    this(toAbsolutePath(rootDir));
  }
  PrefixFileSet(  String rootPath){
    String path=removeTrailingSeparator(rootPath);
    this.rootNode=new Node(path);
  }
  PrefixFileSet(  Node rootNode){
    this.rootNode=rootNode;
  }
  @VisibleForTesting List<String> flatten(){
    final List<String> prefixes=new ArrayList<String>();
    rootNode.visitHierarchy(0,new NodeVisitor(){
      @Override public void visitNode(      int depth,      Node node){
        if (depth == 0) {
          prefixes.add(node.prefix);
        }
 else {
          prefixes.add(depth + ":" + node.prefix.replace(File.separatorChar,'/'));
        }
      }
    }
);
    return prefixes;
  }
  @Override public boolean contains(  String path){
    return rootNode.contains(path,0);
  }
  @Override public boolean contains(  File file){
    return rootNode.contains(file.getPath(),0);
  }
  @Override public FileHierarchySet plus(  File rootDir){
    return plus(toAbsolutePath(rootDir));
  }
  @Override public FileHierarchySet plus(  String absolutePath){
    return new PrefixFileSet(rootNode.plus(removeTrailingSeparator(absolutePath)));
  }
  private static String toAbsolutePath(  File rootDir){
    assert rootDir.isAbsolute();
    return rootDir.getAbsolutePath();
  }
  private static String removeTrailingSeparator(  String absolutePath){
    if (absolutePath.equals("/")) {
      absolutePath="";
    }
 else     if (absolutePath.endsWith(File.separator)) {
      absolutePath=absolutePath.substring(0,absolutePath.length() - 1);
    }
    return absolutePath;
  }
  @Override public void visitRoots(  final RootVisitor visitor){
    final Deque<String> prefixStack=new ArrayDeque<String>();
    rootNode.visitHierarchy(0,new NodeVisitor(){
      @Override public void visitNode(      int depth,      Node node){
        while (prefixStack.size() > depth) {
          prefixStack.removeLast();
        }
        if (node.children.isEmpty()) {
          String root;
          if (prefixStack.isEmpty()) {
            root=node.prefix;
          }
 else {
            StringBuilder builder=new StringBuilder();
            for (            String prefix : prefixStack) {
              builder.append(prefix);
              builder.append(File.separatorChar);
            }
            builder.append(node.prefix);
            root=builder.toString();
          }
          visitor.visitRoot(root);
        }
 else {
          prefixStack.add(node.prefix);
        }
      }
    }
);
  }
  @Override public String toString(){
    final StringBuilder builder=new StringBuilder();
    rootNode.visitHierarchy(0,new NodeVisitor(){
      private boolean first=true;
      @Override public void visitNode(      int depth,      Node node){
        if (first) {
          first=false;
        }
 else {
          builder.append("\n");
        }
        builder.append(Strings.repeat(" ",depth * 2));
        builder.append(node.prefix);
      }
    }
);
    return builder.toString();
  }
}
