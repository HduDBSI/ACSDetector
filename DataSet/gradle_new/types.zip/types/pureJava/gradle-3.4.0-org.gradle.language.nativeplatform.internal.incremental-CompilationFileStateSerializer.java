private static class CompilationFileStateSerializer extends AbstractSerializer<CompilationFileState> {
  private final Serializer<HashCode> hashSerializer=new HashCodeSerializer();
  private final Serializer<Set<ResolvedInclude>> resolveIncludesSerializer;
  private final Serializer<IncludeDirectives> sourceIncludesSerializer=new SourceIncludesSerializer();
  private CompilationFileStateSerializer(  Serializer<File> fileSerializer){
    this.resolveIncludesSerializer=new SetSerializer<ResolvedInclude>(new ResolvedIncludeSerializer(fileSerializer));
  }
  @Override public CompilationFileState read(  Decoder decoder) throws Exception {
    HashCode hash=hashSerializer.read(decoder);
    ImmutableSet<ResolvedInclude> resolvedIncludes=ImmutableSet.copyOf(resolveIncludesSerializer.read(decoder));
    IncludeDirectives includeDirectives=sourceIncludesSerializer.read(decoder);
    return new CompilationFileState(hash,includeDirectives,resolvedIncludes);
  }
  @Override public void write(  Encoder encoder,  CompilationFileState value) throws Exception {
    hashSerializer.write(encoder,value.getHash());
    resolveIncludesSerializer.write(encoder,value.getResolvedIncludes());
    sourceIncludesSerializer.write(encoder,value.getIncludeDirectives());
  }
  @Override public boolean equals(  Object obj){
    if (!super.equals(obj)) {
      return false;
    }
    CompilationFileStateSerializer rhs=(CompilationFileStateSerializer)obj;
    return Objects.equal(hashSerializer,rhs.hashSerializer) && Objects.equal(resolveIncludesSerializer,rhs.resolveIncludesSerializer) && Objects.equal(sourceIncludesSerializer,rhs.sourceIncludesSerializer);
  }
  @Override public int hashCode(){
    return Objects.hashCode(super.hashCode(),hashSerializer,resolveIncludesSerializer,sourceIncludesSerializer);
  }
}
