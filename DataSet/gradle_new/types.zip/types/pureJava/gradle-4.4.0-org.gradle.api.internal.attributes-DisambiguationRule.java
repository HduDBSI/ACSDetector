public interface DisambiguationRule<T> extends Action<MultipleCandidatesResult<T>> {
}
