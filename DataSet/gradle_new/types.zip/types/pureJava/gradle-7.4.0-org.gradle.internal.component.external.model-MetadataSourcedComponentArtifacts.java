/** 
 * Uses the artifacts attached to each configuration.
 */
public class MetadataSourcedComponentArtifacts implements ComponentArtifacts {
  @Override public ArtifactSet getArtifactsFor(  ComponentResolveMetadata component,  ConfigurationMetadata configuration,  ArtifactResolver artifactResolver,  Map<ComponentArtifactIdentifier,ResolvableArtifact> allResolvedArtifacts,  ArtifactTypeRegistry artifactTypeRegistry,  ExcludeSpec exclusions,  ImmutableAttributes overriddenAttributes,  CalculatedValueContainerFactory calculatedValueContainerFactory){
    return DefaultArtifactSet.createFromVariantMetadata(component.getId(),component.getModuleVersionId(),component.getSources(),exclusions,configuration.getVariants(),component.getAttributesSchema(),artifactResolver,allResolvedArtifacts,artifactTypeRegistry,overriddenAttributes,calculatedValueContainerFactory);
  }
}
