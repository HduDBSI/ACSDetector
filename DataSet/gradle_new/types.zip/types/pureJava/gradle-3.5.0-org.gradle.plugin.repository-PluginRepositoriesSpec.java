/** 
 * Used to declare  {@link org.gradle.plugin.repository.PluginRepository} instances.<p> Plugin repositories added via this interface will used to resolve plugins specified in the <code>plugins {}</code> block.
 */
@Incubating public interface PluginRepositoriesSpec {
  /** 
 * Adds and configures a  {@link MavenPluginRepository}.
 * @param action The action to use to configure the repository.
 * @return The added repository.
 */
  MavenPluginRepository maven(  Action<? super MavenPluginRepository> action);
  /** 
 * Adds and configures an  {@link IvyPluginRepository}.
 * @param action The action to use to configure the repository.
 * @return the added repository.
 */
  IvyPluginRepository ivy(  Action<? super IvyPluginRepository> action);
  /** 
 * Adds the Gradle Plugin Portal (plugins.gradle.org) as a plugin repository.
 * @return The added repository.
 * @throws IllegalArgumentException if called more than once.
 */
  GradlePluginPortal gradlePluginPortal();
}
