public class DefaultMavenDependency implements MavenDependencyInternal {
  private final String groupId;
  private final String artifactId;
  private final String version;
  private final String type;
  private final List<DependencyArtifact> artifacts=new ArrayList<DependencyArtifact>();
  private final List<ExcludeRule> excludeRules=new ArrayList<ExcludeRule>();
  public DefaultMavenDependency(  String groupId,  String artifactId,  String version){
    this(groupId,artifactId,version,(String)null);
  }
  public DefaultMavenDependency(  String groupId,  String artifactId,  String version,  Collection<DependencyArtifact> artifacts){
    this(groupId,artifactId,version);
    this.artifacts.addAll(artifacts);
  }
  public DefaultMavenDependency(  String groupId,  String artifactId,  String version,  Collection<DependencyArtifact> artifacts,  Collection<ExcludeRule> excludeRules){
    this(groupId,artifactId,version,artifacts);
    this.excludeRules.addAll(excludeRules);
  }
  public DefaultMavenDependency(  String groupId,  String artifactId,  String version,  String type){
    this.groupId=groupId;
    this.artifactId=artifactId;
    this.version=version;
    this.type=type;
  }
  @Override public String getGroupId(){
    return groupId;
  }
  @Override public String getArtifactId(){
    return artifactId;
  }
  @Override public String getVersion(){
    return version;
  }
  @Nullable @Override public String getType(){
    return type;
  }
  @Override public Collection<DependencyArtifact> getArtifacts(){
    return artifacts;
  }
  @Override public Collection<ExcludeRule> getExcludeRules(){
    return excludeRules;
  }
  @Override public String getProjectPath(){
    return null;
  }
}
