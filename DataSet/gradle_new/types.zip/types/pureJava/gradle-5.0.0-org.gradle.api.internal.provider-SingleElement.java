public static class SingleElement<T> implements Collector<T> {
  private final T element;
  public SingleElement(  T element){
    this.element=element;
  }
  @Override public boolean present(){
    return true;
  }
  @Override public void collectInto(  ValueCollector<T> collector,  Collection<T> collection){
    collector.add(element,collection);
  }
  @Override public boolean maybeCollectInto(  ValueCollector<T> collector,  Collection<T> collection){
    collector.add(element,collection);
    return true;
  }
  @Override public boolean maybeVisitBuildDependencies(  TaskDependencyResolveContext context){
    return false;
  }
  @Override public boolean equals(  Object o){
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SingleElement<?> that=(SingleElement<?>)o;
    return Objects.equal(element,that.element);
  }
  @Override public int hashCode(){
    return Objects.hashCode(element);
  }
  @Override public int size(){
    return 1;
  }
}
