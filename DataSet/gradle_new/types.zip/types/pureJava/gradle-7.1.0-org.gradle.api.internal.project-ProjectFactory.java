public class ProjectFactory implements IProjectFactory {
  private final Instantiator instantiator;
  private final TextFileResourceLoader textFileResourceLoader;
  public ProjectFactory(  Instantiator instantiator,  TextFileResourceLoader textFileResourceLoader){
    this.instantiator=instantiator;
    this.textFileResourceLoader=textFileResourceLoader;
  }
  @Override public ProjectInternal createProject(  GradleInternal gradle,  ProjectDescriptor projectDescriptor,  ProjectState owner,  @Nullable ProjectInternal parent,  ClassLoaderScope selfClassLoaderScope,  ClassLoaderScope baseClassLoaderScope){
    File buildFile=projectDescriptor.getBuildFile();
    TextResource resource=textFileResourceLoader.loadFile("build file",buildFile);
    ScriptSource source=new TextResourceScriptSource(resource);
    DefaultProject project=instantiator.newInstance(DefaultProject.class,projectDescriptor.getName(),parent,projectDescriptor.getProjectDir(),buildFile,source,gradle,owner,gradle.getServiceRegistryFactory(),selfClassLoaderScope,baseClassLoaderScope);
    project.beforeEvaluate(p -> {
      nagUserAboutDeprecatedFlatProjectLayout(project);
      NameValidator.validate(project.getName(),"project name",DefaultProjectDescriptor.INVALID_NAME_IN_INCLUDE_HINT);
      gradle.getServices().get(DependenciesAccessors.class).createExtensions(project);
      gradle.getServices().get(DependencyResolutionManagementInternal.class).configureProject(project);
    }
);
    if (parent != null) {
      parent.addChildProject(project);
    }
    gradle.getProjectRegistry().addProject(project);
    return project;
  }
  private void nagUserAboutDeprecatedFlatProjectLayout(  DefaultProject project){
    File rootDir=FileUtils.canonicalize(project.getRootProject().getProjectDir());
    File projectDir=FileUtils.canonicalize(project.getProjectDir());
    if (!isParentDir(rootDir,projectDir)) {
      DeprecationLogger.deprecateBehaviour(String.format("Subproject '%s' has location '%s' which is outside of the project root.",project.getPath(),project.getProjectDir().getAbsolutePath())).willBeRemovedInGradle8().withUpgradeGuideSection(7,"deprecated_flat_project_structure").nagUser();
    }
  }
  private static boolean isParentDir(  File parent,  @Nullable File f){
    if (f == null) {
      return false;
    }
 else     if (f.equals(parent)) {
      return true;
    }
 else {
      return isParentDir(parent,f.getParentFile());
    }
  }
}
