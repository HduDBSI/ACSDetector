public class StaticValue implements ValidatingValue {
  private final Object value;
  public StaticValue(  Object value){
    this.value=value;
  }
  @Override public Object call(){
    return value;
  }
  @Override public void validate(  String propertyName,  boolean optional,  ValidationAction valueValidator,  TaskValidationContext context){
    Object unpacked=DeferredUtil.unpack(value);
    if (unpacked == null) {
      if (!optional) {
        context.recordValidationMessage(WARNING,String.format("No value has been specified for property '%s'.",propertyName));
      }
    }
 else {
      valueValidator.validate(propertyName,unpacked,context,WARNING);
    }
  }
}
