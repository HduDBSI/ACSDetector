/** 
 * Thrown when a component model is declared in an invalid way.
 */
@Incubating public class InvalidModelException extends GradleException {
  public InvalidModelException(  String message){
    super(message);
  }
  public InvalidModelException(  String message,  Exception cause){
    super(message,cause);
  }
}
