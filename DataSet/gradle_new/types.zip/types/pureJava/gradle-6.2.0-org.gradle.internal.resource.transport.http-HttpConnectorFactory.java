public class HttpConnectorFactory implements ResourceConnectorFactory {
  private final static Set<String> SUPPORTED_PROTOCOLS=ImmutableSet.of("http","https");
  private final static Set<Class<? extends Authentication>> SUPPORTED_AUTHENTICATION=ImmutableSet.of(BasicAuthentication.class,DigestAuthentication.class,HttpHeaderAuthentication.class,AllSchemesAuthentication.class);
  private SslContextFactory sslContextFactory;
  public HttpConnectorFactory(  SslContextFactory sslContextFactory){
    this.sslContextFactory=sslContextFactory;
  }
  @Override public Set<String> getSupportedProtocols(){
    return SUPPORTED_PROTOCOLS;
  }
  @Override public Set<Class<? extends Authentication>> getSupportedAuthentication(){
    return SUPPORTED_AUTHENTICATION;
  }
  @Override public ExternalResourceConnector createResourceConnector(  ResourceConnectorSpecification connectionDetails){
    HttpClientHelper http=new HttpClientHelper(DefaultHttpSettings.builder().withAuthenticationSettings(connectionDetails.getAuthentications()).withSslContextFactory(sslContextFactory).withRedirectVerifier(connectionDetails.getRedirectVerifier()).build());
    HttpResourceAccessor accessor=new HttpResourceAccessor(http);
    HttpResourceLister lister=new HttpResourceLister(accessor);
    HttpResourceUploader uploader=new HttpResourceUploader(http);
    return new DefaultExternalResourceConnector(accessor,lister,uploader);
  }
}
