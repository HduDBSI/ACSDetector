public class TestBuildScopeServices extends BuildScopeServices {
  private final File homeDir;
  public TestBuildScopeServices(  ServiceRegistry parent,  File homeDir){
    super(parent);
    this.homeDir=homeDir;
  }
  protected BuildDefinition createBuildDefinition(  StartParameter startParameter){
    return BuildDefinition.fromStartParameter(startParameter);
  }
  protected BuildCancellationToken createBuildCancellationToken(){
    return new DefaultBuildCancellationToken();
  }
  protected BuildClientMetaData createClientMetaData(){
    return new GradleLauncherMetaData();
  }
  protected CurrentGradleInstallation createCurrentGradleInstallation(){
    return new CurrentGradleInstallation(new GradleInstallation(homeDir));
  }
  protected NestedBuildFactory createNestedBuildFactory(){
    return new NestedBuildFactory(){
      @Override public GradleLauncher nestedInstance(      BuildDefinition buildDefinition,      NestedBuildState build){
        throw new UnsupportedOperationException();
      }
      @Override public GradleLauncher nestedBuildTree(      BuildDefinition buildDefinition,      NestedBuildState build){
        throw new UnsupportedOperationException();
      }
    }
;
  }
}
