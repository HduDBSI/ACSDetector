/** 
 * DO NOT CHANGE THIS INTERFACE. It is part of the cross-version protocol.
 * @since 2.5
 */
public interface InternalOperationResult extends InternalProtocolInterface {
  /** 
 * Returns the time the build execution started.
 * @return The start time of the build
 */
  long getStartTime();
  /** 
 * Returns the time the result was produced.
 * @return The time the result was produced.
 */
  long getEndTime();
  /** 
 * Returns the failures that occurred while running the build, if any.
 * @return The failures that occurred
 */
  List<? extends InternalFailure> getFailures();
}
