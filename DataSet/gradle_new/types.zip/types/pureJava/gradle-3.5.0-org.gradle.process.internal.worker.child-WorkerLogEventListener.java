public class WorkerLogEventListener implements OutputEventListener {
  private WorkerLoggingProtocol workerLoggingProtocol;
  public WorkerLogEventListener(  WorkerLoggingProtocol workerLoggingProtocol){
    this.workerLoggingProtocol=workerLoggingProtocol;
  }
  @Override public void onOutput(  OutputEvent event){
    if (event instanceof LogEvent) {
      workerLoggingProtocol.sendOutputEvent((LogEvent)event);
    }
 else     if (event instanceof StyledTextOutputEvent) {
      workerLoggingProtocol.sendOutputEvent((StyledTextOutputEvent)event);
    }
  }
}
