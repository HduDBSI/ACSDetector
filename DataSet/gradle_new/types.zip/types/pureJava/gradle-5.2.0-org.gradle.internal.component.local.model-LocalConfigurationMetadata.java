public interface LocalConfigurationMetadata extends ConfigurationMetadata {
  String getDescription();
  Set<String> getExtendsFrom();
  @Override List<? extends LocalOriginDependencyMetadata> getDependencies();
  @Override List<? extends LocalComponentArtifactMetadata> getArtifacts();
  /** 
 * Returns the files attached to this configuration, if any. These should be represented as dependencies, but are currently represented as files as a migration step.
 */
  Set<LocalFileDependencyMetadata> getFiles();
}
