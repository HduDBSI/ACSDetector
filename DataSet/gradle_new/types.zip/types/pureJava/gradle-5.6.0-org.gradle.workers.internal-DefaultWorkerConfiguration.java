public class DefaultWorkerConfiguration extends DefaultActionConfiguration implements WorkerConfiguration {
  private final ActionConfiguration actionConfiguration=new DefaultActionConfiguration();
  private final JavaForkOptions forkOptions;
  private IsolationMode isolationMode=IsolationMode.AUTO;
  private String displayName;
  private List<File> classpath=Lists.newArrayList();
  public DefaultWorkerConfiguration(  JavaForkOptionsFactory forkOptionsFactory){
    this.forkOptions=forkOptionsFactory.newJavaForkOptions();
  }
  @Override public IsolationMode getIsolationMode(){
    return isolationMode;
  }
  @Override public void setIsolationMode(  IsolationMode isolationMode){
    this.isolationMode=isolationMode == null ? IsolationMode.AUTO : isolationMode;
  }
  @Override public void forkOptions(  Action<? super JavaForkOptions> forkOptionsAction){
    forkOptionsAction.execute(forkOptions);
  }
  @Override public JavaForkOptions getForkOptions(){
    return forkOptions;
  }
  @Override public void setDisplayName(  String displayName){
    this.displayName=displayName;
  }
  @Override public String getDisplayName(){
    return displayName;
  }
  @Override public Iterable<File> getClasspath(){
    return classpath;
  }
  @Override public void setClasspath(  Iterable<File> classpath){
    this.classpath=Lists.newArrayList(classpath);
  }
  @Override public void classpath(  Iterable<File> files){
    GUtil.addToCollection(classpath,files);
  }
  @Override public void params(  Object... params){
    actionConfiguration.params(params);
  }
  @Override public void setParams(  Object... params){
    actionConfiguration.setParams(params);
  }
  @Override public Object[] getParams(){
    return actionConfiguration.getParams();
  }
  @Override public ForkMode getForkMode(){
switch (getIsolationMode()) {
case AUTO:
      return ForkMode.AUTO;
case NONE:
case CLASSLOADER:
    return ForkMode.NEVER;
case PROCESS:
  return ForkMode.ALWAYS;
default :
throw new IllegalStateException();
}
}
@Override public void setForkMode(ForkMode forkMode){
switch (forkMode) {
case AUTO:
setIsolationMode(IsolationMode.AUTO);
break;
case NEVER:
setIsolationMode(IsolationMode.CLASSLOADER);
break;
case ALWAYS:
setIsolationMode(IsolationMode.PROCESS);
break;
}
}
void adaptTo(WorkerSpec workerSpec){
if (workerSpec instanceof ClassLoaderWorkerSpec) {
ClassLoaderWorkerSpec classLoaderWorkerSpec=(ClassLoaderWorkerSpec)workerSpec;
classLoaderWorkerSpec.getClasspath().from(getClasspath());
}
if (workerSpec instanceof ProcessWorkerSpec) {
ProcessWorkerSpec processWorkerSpec=(ProcessWorkerSpec)workerSpec;
processWorkerSpec.getClasspath().from(getClasspath());
getForkOptions().copyTo(processWorkerSpec.getForkOptions());
}
}
}
