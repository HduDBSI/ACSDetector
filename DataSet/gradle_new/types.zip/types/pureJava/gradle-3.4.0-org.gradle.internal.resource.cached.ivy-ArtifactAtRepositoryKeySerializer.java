private static class ArtifactAtRepositoryKeySerializer extends AbstractSerializer<ArtifactAtRepositoryKey> {
  private final Serializer<ComponentArtifactIdentifier> artifactIdSerializer=new ComponentArtifactIdentifierSerializer();
  public void write(  Encoder encoder,  ArtifactAtRepositoryKey value) throws Exception {
    encoder.writeString(value.getRepositoryId());
    artifactIdSerializer.write(encoder,value.getArtifactId());
  }
  public ArtifactAtRepositoryKey read(  Decoder decoder) throws Exception {
    String repositoryId=decoder.readString();
    ComponentArtifactIdentifier artifactIdentifier=artifactIdSerializer.read(decoder);
    return new ArtifactAtRepositoryKey(repositoryId,artifactIdentifier);
  }
  @Override public boolean equals(  Object obj){
    if (!super.equals(obj)) {
      return false;
    }
    ArtifactAtRepositoryKeySerializer rhs=(ArtifactAtRepositoryKeySerializer)obj;
    return Objects.equal(artifactIdSerializer,rhs.artifactIdSerializer);
  }
  @Override public int hashCode(){
    return Objects.hashCode(super.hashCode(),artifactIdSerializer);
  }
}
