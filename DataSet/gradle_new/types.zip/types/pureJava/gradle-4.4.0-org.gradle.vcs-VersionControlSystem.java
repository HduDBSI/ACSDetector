/** 
 * Allows the user to perform generic version control operations in ways specified by the underlying implementations.
 * @since 4.4
 */
@Incubating public interface VersionControlSystem {
  /** 
 * Returns a  {@link Set} of {@link VersionRef}s representing versions of a software package as they are known to the version control system.
 */
  Set<VersionRef> getAvailableVersions(  VersionControlSpec spec);
  /** 
 * Populates a working directory under  {@code versionDir} with the lateststate of the version control repository from the  {@code spec} andreturns the working directory.
 */
  File populate(  File versionDir,  VersionRef ref,  VersionControlSpec spec);
}
