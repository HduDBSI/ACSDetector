class Property {
  private final String hash;
  private final String normalization;
  private final List<Entry> roots=new ArrayList<Entry>();
  public Property(  String hash,  String normalization){
    this.hash=hash;
    this.normalization=normalization;
  }
  public String getHash(){
    return hash;
  }
  public String getNormalization(){
    return normalization;
  }
  public Collection<Entry> getRoots(){
    return roots;
  }
}
