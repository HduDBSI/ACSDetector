public class NativeVariant implements SoftwareComponentInternal, ComponentWithVariants {
  private final String name;
  private final Usage linkUsage;
  private final Configuration linkElements;
  private final Usage runtimeUsage;
  private final Set<? extends PublishArtifact> runtimeArtifacts;
  private final Configuration runtimeElementsConfiguration;
  public NativeVariant(  String name,  Usage usage,  Set<? extends PublishArtifact> artifacts,  Configuration dependencies){
    this.name=name;
    this.linkUsage=null;
    this.linkElements=null;
    this.runtimeUsage=usage;
    this.runtimeArtifacts=artifacts;
    this.runtimeElementsConfiguration=dependencies;
  }
  public NativeVariant(  String name,  Usage linkUsage,  Configuration linkElements,  Usage runtimeUsage,  Configuration runtimeElements){
    this.name=name;
    this.linkUsage=linkUsage;
    this.linkElements=linkElements;
    this.runtimeUsage=runtimeUsage;
    this.runtimeArtifacts=runtimeElements.getAllArtifacts();
    this.runtimeElementsConfiguration=runtimeElements;
  }
  @Override public String getName(){
    return name;
  }
  @Override public Set<SoftwareComponent> getVariants(){
    return ImmutableSet.of();
  }
  @Override public Set<? extends UsageContext> getUsages(){
    if (linkElements == null) {
      return ImmutableSet.of(new DefaultUsageContext(name + "-runtime",runtimeUsage,runtimeArtifacts,runtimeElementsConfiguration));
    }
 else {
      return ImmutableSet.of(new DefaultUsageContext(name + "-link",linkUsage,linkElements.getAllArtifacts(),linkElements),new DefaultUsageContext(name + "-runtime",runtimeUsage,runtimeArtifacts,runtimeElementsConfiguration));
    }
  }
}
