public class DeprecationLogger extends SingleMessageLogger {
}
