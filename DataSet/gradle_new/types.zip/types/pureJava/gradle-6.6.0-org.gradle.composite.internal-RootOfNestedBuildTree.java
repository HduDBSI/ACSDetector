public class RootOfNestedBuildTree extends AbstractBuildState implements NestedRootBuild {
  private final BuildIdentifier buildIdentifier;
  private final Path identityPath;
  private final BuildState owner;
  private final GradleLauncher gradleLauncher;
  private String buildName;
  public RootOfNestedBuildTree(  BuildDefinition buildDefinition,  BuildIdentifier buildIdentifier,  Path identityPath,  BuildState owner){
    this.buildIdentifier=buildIdentifier;
    this.identityPath=identityPath;
    this.owner=owner;
    this.buildName=buildDefinition.getName() == null ? buildIdentifier.getName() : buildDefinition.getName();
    this.gradleLauncher=owner.getNestedBuildFactory().nestedBuildTree(buildDefinition,this);
  }
  public void attach(){
    gradleLauncher.getGradle().getServices().get(BuildStateRegistry.class).attachRootBuild(this);
  }
  @Override public StartParameter getStartParameter(){
    return gradleLauncher.getGradle().getStartParameter();
  }
  @Override public BuildIdentifier getBuildIdentifier(){
    return buildIdentifier;
  }
  @Override public Path getIdentityPath(){
    return identityPath;
  }
  @Override public boolean isImplicitBuild(){
    return false;
  }
  @Override public SettingsInternal getLoadedSettings(){
    return gradleLauncher.getGradle().getSettings();
  }
  @Override public NestedBuildFactory getNestedBuildFactory(){
    return gradleLauncher.getGradle().getServices().get(NestedBuildFactory.class);
  }
  @Override public Path getCurrentPrefixForProjectsInChildBuilds(){
    return owner.getCurrentPrefixForProjectsInChildBuilds().child(buildName);
  }
  @Override public Path getIdentityPathForProject(  Path projectPath){
    return gradleLauncher.getGradle().getIdentityPath().append(projectPath);
  }
  @Override public File getBuildRootDir(){
    return gradleLauncher.getBuildRootDir();
  }
  @Override public <T>T run(  final Transformer<T,? super BuildController> buildAction){
    final BuildController buildController=new GradleBuildController(gradleLauncher);
    try {
      final GradleInternal gradle=gradleLauncher.getGradle();
      BuildOperationExecutor executor=gradle.getServices().get(BuildOperationExecutor.class);
      return executor.call(new CallableBuildOperation<T>(){
        @Override public T call(        BuildOperationContext context){
          gradle.addBuildListener(new InternalBuildAdapter(){
            @Override public void settingsEvaluated(            Settings settings){
              buildName=settings.getRootProject().getName();
            }
          }
);
          T result=buildAction.transform(buildController);
          context.setResult(new RunNestedBuildBuildOperationType.Result(){
          }
);
          return result;
        }
        @Override public BuildOperationDescriptor.Builder description(){
          return BuildOperationDescriptor.displayName("Run nested build").details(new RunNestedBuildBuildOperationType.Details(){
            @Override public String getBuildPath(){
              return gradle.getIdentityPath().getPath();
            }
          }
);
        }
      }
);
    }
  finally {
      buildController.stop();
    }
  }
}
