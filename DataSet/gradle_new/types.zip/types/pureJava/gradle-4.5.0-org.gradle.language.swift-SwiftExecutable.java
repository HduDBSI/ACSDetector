/** 
 * An executable built from Swift source.
 * @since 4.2
 */
@Incubating public interface SwiftExecutable extends SwiftBinary, ComponentWithExecutable, ComponentWithInstallation, ComponentWithOutputs {
  /** 
 * Returns the executable file to use with a debugger for this binary.
 * @since 4.5
 */
  Provider<RegularFile> getDebuggerExecutableFile();
}
