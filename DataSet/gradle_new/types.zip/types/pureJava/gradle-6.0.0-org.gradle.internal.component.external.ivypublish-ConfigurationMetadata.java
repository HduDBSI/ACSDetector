private class ConfigurationMetadata implements BuildableLocalConfigurationMetadata {
  private final String configurationName;
  private ConfigurationMetadata(  String configurationName){
    this.configurationName=configurationName;
  }
  @Override public ComponentIdentifier getComponentId(){
    return id;
  }
  @Override public void addDependency(  LocalOriginDependencyMetadata dependency){
    assert dependency.getModuleConfiguration().equals(configurationName);
    dependencies.add(normalizeVersionForIvy(dependency));
  }
  @Override public void addExclude(  ExcludeMetadata exclude){
    excludes.add(Pair.of(exclude,configurationName));
  }
  @Override public void addFiles(  LocalFileDependencyMetadata files){
  }
  @Override public void enableLocking(){
  }
}
