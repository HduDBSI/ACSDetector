public interface TaskInputPropertySpec extends TaskPropertySpec {
  @Nullable Object getValue();
}
