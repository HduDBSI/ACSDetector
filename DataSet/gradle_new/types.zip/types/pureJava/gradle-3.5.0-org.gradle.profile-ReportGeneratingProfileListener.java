public class ReportGeneratingProfileListener extends BuildAdapter implements ProfileListener {
  private static final SimpleDateFormat FILE_DATE_FORMAT=new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
  private final StyledTextOutputFactory textOutputFactory;
  private File buildDir;
  public ReportGeneratingProfileListener(  StyledTextOutputFactory textOutputFactory){
    this.textOutputFactory=textOutputFactory;
  }
  @Override public void projectsEvaluated(  Gradle gradle){
    buildDir=gradle.getRootProject().getBuildDir();
  }
  public void buildFinished(  BuildProfile buildProfile){
    ProfileReportRenderer renderer=new ProfileReportRenderer();
    File file=new File(buildDir,"reports/profile/profile-" + FILE_DATE_FORMAT.format(new Date(buildProfile.getBuildStarted())) + ".html");
    renderer.writeTo(buildProfile,file);
    renderReportUrl(file);
  }
  private void renderReportUrl(  File reportFile){
    StyledTextOutput textOutput=textOutputFactory.create(ReportGeneratingProfileListener.class,LogLevel.LIFECYCLE);
    textOutput.println();
    String reportUrl=new ConsoleRenderer().asClickableFileUrl(reportFile);
    textOutput.formatln("See the profiling report at: %s",reportUrl);
  }
}
