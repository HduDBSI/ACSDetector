public class RootBuildCacheControllerSettingsProcessor implements SettingsProcessor {
  public static void process(  GradleInternal gradle){
    if (gradle.isRootBuild()) {
      BuildCacheController rootController=gradle.getServices().get(BuildCacheController.class);
      RootBuildCacheControllerRef rootControllerRef=gradle.getServices().get(RootBuildCacheControllerRef.class);
      rootControllerRef.set(rootController);
    }
  }
  private final SettingsProcessor delegate;
  public RootBuildCacheControllerSettingsProcessor(  SettingsProcessor delegate){
    this.delegate=delegate;
  }
  @Override public SettingsInternal process(  GradleInternal gradle,  SettingsLocation settingsLocation,  ClassLoaderScope buildRootClassLoaderScope,  StartParameter startParameter){
    SettingsInternal settings=delegate.process(gradle,settingsLocation,buildRootClassLoaderScope,startParameter);
    process(gradle);
    return settings;
  }
}
