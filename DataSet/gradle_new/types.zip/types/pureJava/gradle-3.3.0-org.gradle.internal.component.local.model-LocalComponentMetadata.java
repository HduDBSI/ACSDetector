public interface LocalComponentMetadata extends ComponentResolveMetadata {
  AttributesSchema getAttributesSchema();
  @Nullable @Override LocalConfigurationMetadata getConfiguration(  String name);
}
