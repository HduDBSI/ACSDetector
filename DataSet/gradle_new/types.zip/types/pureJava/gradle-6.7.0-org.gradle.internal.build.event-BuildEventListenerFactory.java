@ServiceScope(Scope.Global.class) public interface BuildEventListenerFactory {
  Iterable<Object> createListeners(  BuildEventSubscriptions subscriptions,  BuildEventConsumer consumer);
}
