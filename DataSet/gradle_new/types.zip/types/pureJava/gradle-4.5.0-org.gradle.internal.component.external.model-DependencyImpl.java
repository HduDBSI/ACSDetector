protected static class DependencyImpl implements ComponentVariant.Dependency {
  private final String group;
  private final String module;
  private final VersionConstraint versionConstraint;
  private final ImmutableList<ExcludeMetadata> excludes;
  DependencyImpl(  String group,  String module,  VersionConstraint versionConstraint,  List<ExcludeMetadata> excludes){
    this.group=group;
    this.module=module;
    this.versionConstraint=versionConstraint;
    this.excludes=ImmutableList.copyOf(excludes);
  }
  @Override public String getGroup(){
    return group;
  }
  @Override public String getModule(){
    return module;
  }
  @Override public VersionConstraint getVersionConstraint(){
    return versionConstraint;
  }
  @Override public ImmutableList<ExcludeMetadata> getExcludes(){
    return excludes;
  }
  @Override public boolean equals(  Object o){
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    DependencyImpl that=(DependencyImpl)o;
    return Objects.equal(group,that.group) && Objects.equal(module,that.module) && Objects.equal(versionConstraint,that.versionConstraint)&& Objects.equal(excludes,that.excludes);
  }
  @Override public int hashCode(){
    return Objects.hashCode(group,module,versionConstraint,excludes);
  }
}
