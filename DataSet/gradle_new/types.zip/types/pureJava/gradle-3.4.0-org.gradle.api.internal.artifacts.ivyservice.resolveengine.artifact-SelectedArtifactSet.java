/** 
 * A container of artifacts that match some criteria. Not every query method is available, depending on which details are available.
 */
public interface SelectedArtifactSet {
  /** 
 * Collects the build dependencies required to build the artifacts in this result.
 */
  <T extends Collection<Object>>T collectBuildDependencies(  T dest);
  /** 
 * Collects files into the given collection. Fails when any file cannot be resolved.
 * @return the collection
 * @throws ResolveException On any failure.
 */
  <T extends Collection<? super File>>T collectFiles(  T dest) throws ResolveException ;
  /** 
 * Collects all artifacts into the given collection. Fails when any artifact cannot be resolved.
 * @return the collection
 * @throws ResolveException On any failure.
 */
  <T extends Collection<? super ResolvedArtifactResult>>T collectArtifacts(  T dest) throws ResolveException ;
  /** 
 * Visits the files and artifacts of this set.
 */
  void visitArtifacts(  ArtifactVisitor visitor);
}
