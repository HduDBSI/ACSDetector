public class DefaultCompatibilityCheckResult<T> implements CompatibilityCheckResult<T> {
  private final T consumerValue;
  private final T producerValue;
  private boolean compatible;
  private boolean done;
  public DefaultCompatibilityCheckResult(  T consumerValue,  T producerValue){
    assert producerValue != null : "Internal contract of the current implementation, can be changed with a motivation";
    assert !Objects.equals(consumerValue,producerValue);
    this.consumerValue=consumerValue;
    this.producerValue=producerValue;
  }
  public boolean isCompatible(){
    assert done;
    return compatible;
  }
  @Override public boolean hasResult(){
    return done;
  }
  @Override public T getConsumerValue(){
    return consumerValue;
  }
  @Override public T getProducerValue(){
    return producerValue;
  }
  @Override public void compatible(){
    done=true;
    compatible=true;
  }
  @Override public void incompatible(){
    done=true;
    compatible=false;
  }
}
