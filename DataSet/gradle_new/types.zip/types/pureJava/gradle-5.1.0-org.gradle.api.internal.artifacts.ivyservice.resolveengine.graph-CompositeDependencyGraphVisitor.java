public class CompositeDependencyGraphVisitor implements DependencyGraphVisitor {
  private final List<DependencyGraphVisitor> visitors;
  public CompositeDependencyGraphVisitor(  DependencyGraphVisitor... visitors){
    this.visitors=Arrays.asList(visitors);
  }
  @Override public void start(  RootGraphNode root){
    for (    DependencyGraphVisitor visitor : visitors) {
      visitor.start(root);
    }
  }
  @Override public void visitNode(  DependencyGraphNode node){
    for (    DependencyGraphVisitor visitor : visitors) {
      visitor.visitNode(node);
    }
  }
  @Override public void visitSelector(  DependencyGraphSelector selector){
    for (    DependencyGraphVisitor visitor : visitors) {
      visitor.visitSelector(selector);
    }
  }
  @Override public void visitEdges(  DependencyGraphNode node){
    for (    DependencyGraphVisitor visitor : visitors) {
      visitor.visitEdges(node);
    }
  }
  @Override public void finish(  DependencyGraphNode root){
    for (    DependencyGraphVisitor visitor : visitors) {
      visitor.finish(root);
    }
  }
}
