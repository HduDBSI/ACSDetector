public interface VcsMappingInternal extends VcsMapping {
  VersionControlSpec getRepository();
  boolean hasRepository();
}
