private class ConfigurationFileCollection extends AbstractFileCollection {
  private final Spec<? super Dependency> dependencySpec;
  private final AttributeContainerInternal viewAttributes;
  private final Spec<? super ComponentIdentifier> componentSpec;
  private SelectedArtifactSet selectedArtifacts;
  private ConfigurationFileCollection(  Spec<? super Dependency> dependencySpec){
    assertResolvingAllowed();
    this.dependencySpec=dependencySpec;
    this.viewAttributes=ImmutableAttributes.EMPTY;
    this.componentSpec=Specs.satisfyAll();
  }
  private ConfigurationFileCollection(  Spec<? super Dependency> dependencySpec,  AttributeContainerInternal viewAttributes,  Spec<? super ComponentIdentifier> componentSpec){
    this.dependencySpec=dependencySpec;
    this.viewAttributes=viewAttributes.asImmutable();
    this.componentSpec=componentSpec;
  }
  private ConfigurationFileCollection(  Closure dependencySpecClosure){
    this(Specs.convertClosureToSpec(dependencySpecClosure));
  }
  private ConfigurationFileCollection(  final Set<Dependency> dependencies){
    this(new Spec<Dependency>(){
      public boolean isSatisfiedBy(      Dependency element){
        return dependencies.contains(element);
      }
    }
);
  }
  @Override public TaskDependency getBuildDependencies(){
    assertResolvingAllowed();
    return new ConfigurationTaskDependency(dependencySpec,viewAttributes,componentSpec);
  }
  public Spec<? super Dependency> getDependencySpec(){
    return dependencySpec;
  }
  public String getDisplayName(){
    return DefaultConfiguration.this.getDisplayName();
  }
  public Set<File> getFiles(){
    return getSelectedArtifacts().collectFiles(new LinkedHashSet<File>());
  }
  private SelectedArtifactSet getSelectedArtifacts(){
    assertResolvingAllowed();
    if (selectedArtifacts == null) {
      resolveToStateOrLater(ARTIFACTS_RESOLVED);
      selectedArtifacts=cachedResolverResults.getVisitedArtifacts().select(dependencySpec,viewAttributes,componentSpec);
    }
    return selectedArtifacts;
  }
}
