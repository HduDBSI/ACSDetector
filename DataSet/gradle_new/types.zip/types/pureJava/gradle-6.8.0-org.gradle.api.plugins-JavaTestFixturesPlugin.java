/** 
 * Adds support for producing test fixtures. This plugin will automatically create a `testFixtures` source set, and wires the tests to use those test fixtures automatically. Other projects may consume the test fixtures of the current project by declaring a dependency using the  {@link DependencyHandler#testFixtures(Object)}method.
 * @since 5.6
 */
@Incubating public class JavaTestFixturesPlugin implements Plugin<Project> {
  private final JvmModelingServices jvmEcosystemUtilities;
  @Inject public JavaTestFixturesPlugin(  JvmModelingServices jvmModelingServices){
    this.jvmEcosystemUtilities=jvmModelingServices;
  }
  @Override public void apply(  Project project){
    project.getPluginManager().withPlugin("java",plugin -> {
      jvmEcosystemUtilities.createJvmVariant(TEST_FIXTURES_FEATURE_NAME,builder -> builder.exposesApi().published());
      createImplicitTestFixturesDependencies(project,findJavaConvention(project));
    }
);
  }
  private void createImplicitTestFixturesDependencies(  Project project,  JavaPluginConvention convention){
    DependencyHandler dependencies=project.getDependencies();
    dependencies.add(TEST_FIXTURES_API,dependencies.create(project));
    SourceSet testSourceSet=findTestSourceSet(convention);
    ProjectDependency testDependency=(ProjectDependency)dependencies.add(testSourceSet.getImplementationConfigurationName(),dependencies.create(project));
    testDependency.capabilities(new ProjectTestFixtures(project));
    ConfigurationContainer configurations=project.getConfigurations();
    testSourceSet.setCompileClasspath(project.getObjects().fileCollection().from(configurations.getByName(TEST_COMPILE_CLASSPATH_CONFIGURATION_NAME)));
    testSourceSet.setRuntimeClasspath(project.getObjects().fileCollection().from(testSourceSet.getOutput(),configurations.getByName(TEST_RUNTIME_CLASSPATH_CONFIGURATION_NAME)));
  }
  private SourceSet findTestSourceSet(  JavaPluginConvention convention){
    return convention.getSourceSets().getByName("test");
  }
  private JavaPluginConvention findJavaConvention(  Project project){
    return (JavaPluginConvention)project.getConvention().getPlugins().get("java");
  }
}
