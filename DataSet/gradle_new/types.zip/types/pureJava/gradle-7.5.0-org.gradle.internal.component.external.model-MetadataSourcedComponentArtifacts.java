/** 
 * Uses the artifacts attached to each configuration.
 */
public class MetadataSourcedComponentArtifacts implements ComponentArtifacts {
  @Override public ArtifactSet getArtifactsFor(  ComponentResolveMetadata component,  ConfigurationMetadata configuration,  ArtifactResolver artifactResolver,  Map<ComponentArtifactIdentifier,ResolvableArtifact> allResolvedArtifacts,  ArtifactTypeRegistry artifactTypeRegistry,  ExcludeSpec exclusions,  ImmutableAttributes overriddenAttributes,  CalculatedValueContainerFactory calculatedValueContainerFactory){
    Set<? extends VariantResolveMetadata> variants=getVariantResolveMetadata(component,configuration);
    return DefaultArtifactSet.createFromVariantMetadata(component.getId(),component.getModuleVersionId(),component.getSources(),exclusions,variants,component.getAttributesSchema(),artifactResolver,allResolvedArtifacts,artifactTypeRegistry,overriddenAttributes,calculatedValueContainerFactory);
  }
  public static Set<? extends VariantResolveMetadata> getVariantResolveMetadata(  ComponentResolveMetadata component,  ConfigurationMetadata configuration){
    return configuration.getVariants();
  }
}
