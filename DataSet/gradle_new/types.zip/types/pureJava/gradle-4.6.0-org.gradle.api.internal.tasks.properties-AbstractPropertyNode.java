abstract class AbstractPropertyNode<SELF extends AbstractPropertyNode<SELF>> implements PropertyNode<SELF> {
  private final String propertyName;
  private final Class<?> beanClass;
  public AbstractPropertyNode(  @Nullable String propertyName,  Class<?> beanClass){
    this.propertyName=propertyName;
    this.beanClass=beanClass;
  }
  @Override public String getQualifiedPropertyName(  String childPropertyName){
    return propertyName == null ? childPropertyName : propertyName + "." + childPropertyName;
  }
  @Override public boolean isRoot(){
    return propertyName == null;
  }
  @Nullable @Override public String getPropertyName(){
    return propertyName;
  }
  @Override public Class<?> getBeanClass(){
    return beanClass;
  }
  @Override public String toString(){
    return isRoot() ? "<root>" : getPropertyName();
  }
}
