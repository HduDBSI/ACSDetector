public interface UpToDateResult extends AfterExecutionResult {
  /** 
 * A list of messages describing the first few reasons encountered that caused the work to be executed. An empty list means the work was up-to-date and hasn't been executed.
 */
  ImmutableList<String> getExecutionReasons();
  /** 
 * If a previously produced output was reused in some way, the reused output's origin metadata is returned.
 */
  Optional<OriginMetadata> getReusedOutputOriginMetadata();
}
