/** 
 * Adapts a  {@link ResolvedConfigurationBuilder}, which is responsible for assembling the resolved configuration result, to a  {@link DependencyGraphVisitor} and{@link DependencyArtifactsVisitor}.
 */
public class ResolvedConfigurationDependencyGraphVisitor implements DependencyGraphVisitor, DependencyArtifactsVisitor {
  private final ResolvedConfigurationBuilder builder;
  private final Map<ModuleVersionSelector,BrokenDependency> failuresByRevisionId=new LinkedHashMap<ModuleVersionSelector,BrokenDependency>();
  private DependencyGraphNode root;
  public ResolvedConfigurationDependencyGraphVisitor(  ResolvedConfigurationBuilder builder){
    this.builder=builder;
  }
  public void start(  DependencyGraphNode root){
    this.root=root;
  }
  public void visitNode(  DependencyGraphNode resolvedConfiguration){
    builder.newResolvedDependency(resolvedConfiguration);
    for (    DependencyGraphEdge dependency : resolvedConfiguration.getOutgoingEdges()) {
      ModuleVersionResolveException failure=dependency.getFailure();
      if (failure != null) {
        addUnresolvedDependency(dependency,dependency.getRequestedModuleVersion(),failure);
      }
    }
  }
  public void visitEdge(  DependencyGraphNode resolvedConfiguration){
    for (    DependencyGraphEdge dependency : resolvedConfiguration.getIncomingEdges()) {
      if (dependency.getFrom() == root) {
        ModuleDependency moduleDependency=dependency.getModuleDependency();
        builder.addFirstLevelDependency(moduleDependency,resolvedConfiguration);
      }
    }
  }
  @Override public void visitArtifacts(  DependencyGraphNode parent,  DependencyGraphNode child,  ArtifactSet artifacts){
    builder.addChild(parent,child,artifacts.getId());
  }
  public void finish(  DependencyGraphNode root){
    attachFailures(builder);
    builder.done(root);
  }
  public void finishArtifacts(){
  }
  private void attachFailures(  ResolvedConfigurationBuilder result){
    for (    Map.Entry<ModuleVersionSelector,BrokenDependency> entry : failuresByRevisionId.entrySet()) {
      Collection<List<ComponentIdentifier>> paths=DependencyGraphPathResolver.calculatePaths(entry.getValue().requiredBy,root);
      result.addUnresolvedDependency(new DefaultUnresolvedDependency(entry.getKey(),entry.getValue().failure.withIncomingPaths(paths)));
    }
  }
  private void addUnresolvedDependency(  DependencyGraphEdge dependency,  ModuleVersionSelector requested,  ModuleVersionResolveException failure){
    BrokenDependency breakage=failuresByRevisionId.get(requested);
    if (breakage == null) {
      breakage=new BrokenDependency(failure);
      failuresByRevisionId.put(requested,breakage);
    }
    breakage.requiredBy.add(dependency.getFrom());
  }
private static class BrokenDependency {
    final ModuleVersionResolveException failure;
    final List<DependencyGraphNode> requiredBy=new ArrayList<DependencyGraphNode>();
    private BrokenDependency(    ModuleVersionResolveException failure){
      this.failure=failure;
    }
  }
}
