public class DefaultAdhocSoftwareComponent implements AdhocComponentWithVariants, SoftwareComponentInternal {
  private final String componentName;
  private final Map<Configuration,ConfigurationVariantMapping> variants=Maps.newLinkedHashMapWithExpectedSize(4);
  private final Instantiator instantiator;
  public DefaultAdhocSoftwareComponent(  String componentName,  Instantiator instantiator){
    this.componentName=componentName;
    this.instantiator=instantiator;
  }
  @Override public String getName(){
    return componentName;
  }
  @Override public void addVariantsFromConfiguration(  Configuration outgoingConfiguration,  Action<? super ConfigurationVariantDetails> spec){
    variants.put(outgoingConfiguration,new ConfigurationVariantMapping((ConfigurationInternal)outgoingConfiguration,spec,instantiator));
  }
  @Override public void withVariantsFromConfiguration(  Configuration outgoingConfiguration,  Action<? super ConfigurationVariantDetails> action){
    if (!variants.containsKey(outgoingConfiguration)) {
      throw new InvalidUserDataException("Variant for configuration " + outgoingConfiguration.getName() + " does not exist in component "+ componentName);
    }
    variants.get(outgoingConfiguration).addAction(action);
  }
  @Override public Set<? extends UsageContext> getUsages(){
    ImmutableSet.Builder<UsageContext> builder=new ImmutableSet.Builder<>();
    for (    ConfigurationVariantMapping variant : variants.values()) {
      variant.collectUsageContexts(builder);
    }
    return builder.build();
  }
}
