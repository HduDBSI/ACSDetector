public class ComponentResolversChain {
  private final DependencyToComponentIdResolverChain dependencyToComponentIdResolver;
  private final ComponentMetaDataResolverChain componentMetaDataResolver;
  private final ArtifactResolver artifactResolverChain;
  private final DefaultArtifactSelector artifactSelector;
  public ComponentResolversChain(  List<ComponentResolvers> providers,  ArtifactTypeRegistry artifactTypeRegistry){
    List<DependencyToComponentIdResolver> depToComponentIdResolvers=new ArrayList<DependencyToComponentIdResolver>(providers.size());
    List<ComponentMetaDataResolver> componentMetaDataResolvers=new ArrayList<ComponentMetaDataResolver>(providers.size());
    List<ArtifactResolver> artifactResolvers=new ArrayList<ArtifactResolver>(providers.size());
    List<OriginArtifactSelector> artifactSelectors=new ArrayList<OriginArtifactSelector>(providers.size());
    for (    ComponentResolvers provider : providers) {
      depToComponentIdResolvers.add(provider.getComponentIdResolver());
      componentMetaDataResolvers.add(provider.getComponentResolver());
      artifactSelectors.add(provider.getArtifactSelector());
      artifactResolvers.add(provider.getArtifactResolver());
    }
    dependencyToComponentIdResolver=new DependencyToComponentIdResolverChain(depToComponentIdResolvers);
    componentMetaDataResolver=new ComponentMetaDataResolverChain(componentMetaDataResolvers);
    artifactResolverChain=new ErrorHandlingArtifactResolver(new ArtifactResolverChain(artifactResolvers));
    artifactSelector=new DefaultArtifactSelector(artifactSelectors,artifactResolverChain,artifactTypeRegistry);
  }
  public DefaultArtifactSelector getArtifactSelector(){
    return artifactSelector;
  }
  public DependencyToComponentIdResolver getComponentIdResolver(){
    return dependencyToComponentIdResolver;
  }
  public ComponentMetaDataResolver getComponentResolver(){
    return componentMetaDataResolver;
  }
  public ArtifactResolver getArtifactResolver(){
    return artifactResolverChain;
  }
private static class ComponentMetaDataResolverChain implements ComponentMetaDataResolver {
    private final List<ComponentMetaDataResolver> resolvers;
    public ComponentMetaDataResolverChain(    List<ComponentMetaDataResolver> resolvers){
      this.resolvers=resolvers;
    }
    @Override public void resolve(    ComponentIdentifier identifier,    ComponentOverrideMetadata componentOverrideMetadata,    BuildableComponentResolveResult result){
      for (      ComponentMetaDataResolver resolver : resolvers) {
        if (result.hasResult()) {
          return;
        }
        resolver.resolve(identifier,componentOverrideMetadata,result);
      }
    }
    @Override public boolean isFetchingMetadataCheap(    ComponentIdentifier identifier){
      for (      ComponentMetaDataResolver resolver : resolvers) {
        if (!resolver.isFetchingMetadataCheap(identifier)) {
          return false;
        }
      }
      return true;
    }
  }
private static class ArtifactResolverChain implements ArtifactResolver {
    private final List<ArtifactResolver> resolvers;
    private ArtifactResolverChain(    List<ArtifactResolver> resolvers){
      this.resolvers=resolvers;
    }
    @Override public void resolveArtifact(    ComponentArtifactMetadata artifact,    ModuleSource moduleSource,    BuildableArtifactResolveResult result){
      for (      ArtifactResolver resolver : resolvers) {
        if (result.hasResult()) {
          return;
        }
        resolver.resolveArtifact(artifact,moduleSource,result);
      }
    }
    @Override public void resolveArtifactsWithType(    ComponentResolveMetadata component,    ArtifactType artifactType,    BuildableArtifactSetResolveResult result){
      for (      ArtifactResolver resolver : resolvers) {
        if (result.hasResult()) {
          return;
        }
        resolver.resolveArtifactsWithType(component,artifactType,result);
      }
    }
  }
private static class DependencyToComponentIdResolverChain implements DependencyToComponentIdResolver {
    private final List<DependencyToComponentIdResolver> resolvers;
    public DependencyToComponentIdResolverChain(    List<DependencyToComponentIdResolver> resolvers){
      this.resolvers=resolvers;
    }
    @Override public void resolve(    DependencyMetadata dependency,    BuildableComponentIdResolveResult result){
      for (      DependencyToComponentIdResolver resolver : resolvers) {
        if (result.hasResult()) {
          return;
        }
        resolver.resolve(dependency,result);
      }
    }
  }
}
