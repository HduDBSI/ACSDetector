private static class ImmutableVariantImpl implements ComponentVariant, VariantMetadata {
  private final ModuleComponentIdentifier componentId;
  private final String name;
  private final ImmutableAttributes attributes;
  private final ImmutableList<DependencyImpl> dependencies;
  private final ImmutableList<FileImpl> files;
  ImmutableVariantImpl(  ModuleComponentIdentifier componentId,  String name,  ImmutableAttributes attributes,  ImmutableList<DependencyImpl> dependencies,  ImmutableList<FileImpl> files){
    this.componentId=componentId;
    this.name=name;
    this.attributes=attributes;
    this.dependencies=dependencies;
    this.files=files;
  }
  @Override public String getName(){
    return name;
  }
  @Override public DisplayName asDescribable(){
    return Describables.of(componentId,"variant",name);
  }
  @Override public ImmutableAttributes getAttributes(){
    return attributes;
  }
  @Override public ImmutableList<? extends Dependency> getDependencies(){
    return dependencies;
  }
  @Override public ImmutableList<? extends File> getFiles(){
    return files;
  }
  @Override public List<? extends ComponentArtifactMetadata> getArtifacts(){
    List<ComponentArtifactMetadata> artifacts=new ArrayList<ComponentArtifactMetadata>(files.size());
    for (    ComponentVariant.File file : files) {
      artifacts.add(new UrlBackedArtifactMetadata(componentId,file.getName(),file.getUri()));
    }
    return artifacts;
  }
}
