public class FileBasedMavenArtifact extends AbstractMavenArtifact {
  private final File file;
  private final String extension;
  public FileBasedMavenArtifact(  File file){
    this.file=file;
    extension=Files.getFileExtension(file.getName());
  }
  @Override public File getFile(){
    return file;
  }
  @Override protected String getDefaultExtension(){
    return extension;
  }
  @Override protected String getDefaultClassifier(){
    return null;
  }
  @Override protected TaskDependencyInternal getDefaultBuildDependencies(){
    return TaskDependencyInternal.EMPTY;
  }
  @Override public boolean shouldBePublished(){
    return true;
  }
}
