public class ProgressLoggingExternalResourceAccessor extends AbstractProgressLoggingHandler implements ExternalResourceAccessor {
  private final ExternalResourceAccessor delegate;
  public ProgressLoggingExternalResourceAccessor(  ExternalResourceAccessor delegate,  ProgressLoggerFactory progressLoggerFactory){
    super(progressLoggerFactory);
    this.delegate=delegate;
  }
  public ExternalResourceReadResponse openResource(  URI location,  boolean revalidate){
    ExternalResourceReadResponse resource=delegate.openResource(location,revalidate);
    if (resource != null) {
      return new ProgressLoggingExternalResource(location,resource);
    }
 else {
      return null;
    }
  }
  @Nullable public ExternalResourceMetaData getMetaData(  URI location,  boolean revalidate){
    return delegate.getMetaData(location,revalidate);
  }
private class ProgressLoggingExternalResource implements ExternalResourceReadResponse {
    private final ExternalResourceReadResponse resource;
    private final ResourceOperation downloadOperation;
    private ProgressLoggingExternalResource(    URI location,    ExternalResourceReadResponse resource){
      this.resource=resource;
      downloadOperation=createResourceOperation(location,ResourceOperation.Type.download,getClass(),resource.getMetaData().getContentLength());
    }
    @Override public InputStream openStream() throws IOException {
      return new ProgressLoggingInputStream(resource.openStream(),downloadOperation);
    }
    @Override public void close() throws IOException {
      try {
        resource.close();
      }
  finally {
        downloadOperation.completed();
      }
    }
    @Override public ExternalResourceMetaData getMetaData(){
      return resource.getMetaData();
    }
    public String toString(){
      return resource.toString();
    }
  }
}
