/** 
 * Determines whether a specific scenario within a performance test should run and whether it should run locally or be added to the list of scenarios to run in distributed mode.
 */
public class TestScenarioSelector {
  public static boolean shouldRun(  String fullClassName,  String testId,  Set<String> templates,  ResultsStore resultsStore){
    if (testId.contains(";")) {
      throw new IllegalArgumentException("Test ID cannot contain ';', but was '" + testId + "'");
    }
    String scenarioProperty=System.getProperty("org.gradle.performance.scenarios","");
    List<String> scenarios=Splitter.on(";").omitEmptyStrings().trimResults().splitToList(scenarioProperty);
    boolean shouldRun=scenarios.isEmpty() || scenarios.contains(testId);
    String scenarioList=System.getProperty("org.gradle.performance.scenario.list");
    if (shouldRun && scenarioList != null) {
      addToScenarioList(fullClassName,testId,templates,new File(scenarioList),resultsStore);
      return false;
    }
 else {
      return shouldRun;
    }
  }
  private static void addToScenarioList(  String fullClassName,  String testId,  Set<String> templates,  File scenarioList,  ResultsStore resultsStore){
    try {
      long estimatedRuntime=getEstimatedRuntime(testId,resultsStore);
      List<String> args=Lists.newArrayList();
      args.add(fullClassName);
      args.add(testId);
      args.add(String.valueOf(estimatedRuntime));
      args.addAll(templates);
      Files.touch(scenarioList);
      Files.append(Joiner.on(';').join(args) + '\n',scenarioList,Charsets.UTF_8);
    }
 catch (    IOException e) {
      throw new RuntimeException("Could not write to scenario list at " + scenarioList,e);
    }
  }
  private static long getEstimatedRuntime(  String testId,  ResultsStore resultsStore){
    String channel=ResultsStoreHelper.determineChannel();
    PerformanceTestHistory history=resultsStore.getTestResults(testId,1,365,channel);
    PerformanceTestExecution lastRun=Iterables.getFirst(history.getExecutions(),null);
    if (lastRun == null) {
      return 0;
    }
 else {
      return lastRun.getEndTime() - lastRun.getStartTime();
    }
  }
}
