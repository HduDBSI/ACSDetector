public class ExecuteStep<C extends InputChangesContext> implements Step<C,Result> {
  private final BuildOperationExecutor buildOperationExecutor;
  public ExecuteStep(  BuildOperationExecutor buildOperationExecutor){
    this.buildOperationExecutor=buildOperationExecutor;
  }
  @Override public Result execute(  UnitOfWork work,  C context){
    return buildOperationExecutor.call(new CallableBuildOperation<Result>(){
      @Override public Result call(      BuildOperationContext operationContext){
        Result result=executeInternal(work,context);
        operationContext.setResult(Operation.Result.INSTANCE);
        return result;
      }
      @Override public BuildOperationDescriptor.Builder description(){
        return BuildOperationDescriptor.displayName("Executing " + work.getDisplayName()).details(Operation.Details.INSTANCE);
      }
    }
);
  }
  private static Result executeInternal(  UnitOfWork work,  InputChangesContext context){
    try {
      UnitOfWork.ExecutionRequest executionRequest=new UnitOfWork.ExecutionRequest(){
        @Override public File getWorkspace(){
          return context.getWorkspace();
        }
        @Override public Optional<InputChangesInternal> getInputChanges(){
          return context.getInputChanges();
        }
        @Override public Optional<ImmutableSortedMap<String,FileSystemSnapshot>> getPreviouslyProducedOutputs(){
          return context.getAfterPreviousExecutionState().map(AfterPreviousExecutionState::getOutputFilesProducedByWork);
        }
      }
;
      UnitOfWork.WorkOutput workOutput=work.execute(executionRequest);
      ExecutionOutcome outcome=determineOutcome(context,workOutput);
      ExecutionResult executionResult=new ExecutionResult(){
        @Override public ExecutionOutcome getOutcome(){
          return outcome;
        }
        @Override public Object getOutput(){
          return workOutput.getOutput();
        }
      }
;
      return () -> Try.successful(executionResult);
    }
 catch (    Throwable t) {
      return () -> Try.failure(t);
    }
  }
  private static ExecutionOutcome determineOutcome(  InputChangesContext context,  UnitOfWork.WorkOutput workOutput){
    ExecutionOutcome outcome;
switch (workOutput.getDidWork()) {
case DID_NO_WORK:
      outcome=ExecutionOutcome.UP_TO_DATE;
    break;
case DID_WORK:
  boolean incremental=context.getInputChanges().map(InputChanges::isIncremental).orElse(false);
outcome=incremental ? ExecutionOutcome.EXECUTED_INCREMENTALLY : ExecutionOutcome.EXECUTED_NON_INCREMENTALLY;
break;
default :
throw new AssertionError();
}
return outcome;
}
public interface Operation extends BuildOperationType<Operation.Details,Operation.Result> {
interface Details {
Operation.Details INSTANCE=new Operation.Details(){
}
;
}
interface Result {
Operation.Result INSTANCE=new Operation.Result(){
}
;
}
}
}
