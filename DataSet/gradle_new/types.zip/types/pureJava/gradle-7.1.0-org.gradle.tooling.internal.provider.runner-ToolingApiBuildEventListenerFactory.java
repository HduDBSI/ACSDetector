public class ToolingApiBuildEventListenerFactory implements BuildEventListenerFactory {
  private final BuildOperationAncestryTracker ancestryTracker;
  private final BuildOperationIdFactory idFactory;
  private final List<OperationResultPostProcessorFactory> postProcessorFactories;
  ToolingApiBuildEventListenerFactory(  BuildOperationAncestryTracker ancestryTracker,  BuildOperationIdFactory idFactory,  List<OperationResultPostProcessorFactory> postProcessorFactories){
    this.ancestryTracker=ancestryTracker;
    this.idFactory=idFactory;
    this.postProcessorFactories=postProcessorFactories;
  }
  @Override public Iterable<Object> createListeners(  BuildEventSubscriptions subscriptions,  BuildEventConsumer consumer){
    if (!subscriptions.isAnyOperationTypeRequested()) {
      return emptyList();
    }
    ProgressEventConsumer progressEventConsumer=new ProgressEventConsumer(consumer,ancestryTracker);
    List<Object> listeners=new ArrayList<>();
    listeners.add(ancestryTracker);
    if (subscriptions.isRequested(OperationType.TEST)) {
      BuildOperationListener buildListener=new ClientForwardingTestOperationListener(progressEventConsumer,ancestryTracker,subscriptions);
      if (subscriptions.isRequested(OperationType.TEST_OUTPUT)) {
        buildListener=new ClientForwardingTestOutputOperationListener(buildListener,progressEventConsumer,idFactory);
      }
      listeners.add(buildListener);
    }
    if (subscriptions.isAnyRequested(OperationType.GENERIC,OperationType.WORK_ITEM,OperationType.TASK,OperationType.PROJECT_CONFIGURATION,OperationType.TRANSFORM)) {
      BuildOperationListener buildListener=NO_OP;
      if (subscriptions.isRequested(OperationType.GENERIC)) {
        buildListener=new TestIgnoringBuildOperationListener(new ClientForwardingBuildOperationListener(progressEventConsumer));
      }
      if (subscriptions.isAnyRequested(OperationType.GENERIC,OperationType.WORK_ITEM)) {
        buildListener=new ClientForwardingWorkItemOperationListener(progressEventConsumer,subscriptions,buildListener);
      }
      OperationDependenciesResolver operationDependenciesResolver=new OperationDependenciesResolver();
      if (subscriptions.isAnyRequested(OperationType.GENERIC,OperationType.WORK_ITEM,OperationType.TRANSFORM)) {
        ClientForwardingTransformOperationListener transformOperationListener=new ClientForwardingTransformOperationListener(progressEventConsumer,subscriptions,buildListener,operationDependenciesResolver);
        operationDependenciesResolver.addLookup(transformOperationListener);
        buildListener=transformOperationListener;
      }
      PluginApplicationTracker pluginApplicationTracker=new PluginApplicationTracker(ancestryTracker);
      if (subscriptions.isAnyRequested(OperationType.PROJECT_CONFIGURATION,OperationType.TASK)) {
        listeners.add(pluginApplicationTracker);
      }
      if (subscriptions.isAnyRequested(OperationType.GENERIC,OperationType.WORK_ITEM,OperationType.TRANSFORM,OperationType.TASK)) {
        TaskOriginTracker taskOriginTracker=new TaskOriginTracker(pluginApplicationTracker);
        if (subscriptions.isAnyRequested(OperationType.TASK)) {
          listeners.add(taskOriginTracker);
        }
        List<OperationResultPostProcessor> postProcessors=new ArrayList<>(postProcessorFactories.size());
        for (        OperationResultPostProcessorFactory postProcessorFactory : postProcessorFactories) {
          postProcessors.addAll(postProcessorFactory.createProcessors(subscriptions,consumer));
        }
        listeners.addAll(postProcessors);
        OperationResultPostProcessor postProcessor=new CompositeOperationResultPostProcessor(postProcessors);
        ClientForwardingTaskOperationListener taskOperationListener=new ClientForwardingTaskOperationListener(progressEventConsumer,subscriptions,buildListener,postProcessor,taskOriginTracker,operationDependenciesResolver);
        operationDependenciesResolver.addLookup(taskOperationListener);
        buildListener=taskOperationListener;
      }
      listeners.add(new ClientForwardingProjectConfigurationOperationListener(progressEventConsumer,subscriptions,buildListener,ancestryTracker,pluginApplicationTracker));
    }
    return listeners;
  }
  private static final BuildOperationListener NO_OP=new BuildOperationListener(){
    @Override public void started(    BuildOperationDescriptor buildOperation,    OperationStartEvent startEvent){
    }
    @Override public void progress(    OperationIdentifier buildOperationId,    OperationProgressEvent progressEvent){
    }
    @Override public void finished(    BuildOperationDescriptor buildOperation,    OperationFinishEvent finishEvent){
    }
  }
;
}
