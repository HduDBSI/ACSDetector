/** 
 * A C++ source file and corresponding header file.
 */
public abstract class CppSourceFileElement extends CppLibraryElement {
  public abstract SourceFileElement getHeader();
  public abstract SourceFileElement getSource();
  @Override public SourceElement getPublicHeaders(){
    return getHeader();
  }
  @Override public SourceElement getSources(){
    return getSource();
  }
}
