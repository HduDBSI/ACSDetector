private static class ElementsFromCollection<T> implements Collector<T> {
  private final Iterable<? extends T> value;
  ElementsFromCollection(  Iterable<? extends T> value){
    this.value=value;
  }
  @Override public boolean present(){
    return true;
  }
  @Override public void collectInto(  ValueCollector<T> collector,  Collection<T> dest){
    collector.addAll(value,dest);
  }
  @Override public boolean maybeCollectInto(  ValueCollector<T> collector,  Collection<T> dest){
    collectInto(collector,dest);
    return true;
  }
}
