abstract class AbstractVersionSelector implements VersionSelector {
  private final String selector;
  protected AbstractVersionSelector(  String selector){
    this.selector=selector;
  }
  public String getSelector(){
    return selector;
  }
  public boolean accept(  ComponentMetadata candidate){
    return accept(candidate.getId().getVersion());
  }
  @Override public boolean canShortCircuitWhenVersionAlreadyPreselected(){
    return true;
  }
  @Override public boolean equals(  Object o){
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AbstractVersionSelector that=(AbstractVersionSelector)o;
    return selector.equals(that.selector);
  }
  @Override public int hashCode(){
    return selector.hashCode();
  }
}
