interface Completion {
  /** 
 * Marks the completion of a build operation, releasing the lease.
 */
  void operationFinish();
}
