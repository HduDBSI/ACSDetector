/** 
 * An immutable snapshot of the type and content of a file. Should implement  {@link #equals(Object)} and {@link #hashCode()} to compare these.
 */
public interface IncrementalFileSnapshot {
  HashCode getHash();
  boolean isContentUpToDate(  IncrementalFileSnapshot snapshot);
  boolean isContentAndMetadataUpToDate(  IncrementalFileSnapshot snapshot);
}
