public interface FileTreeInternal extends FileTree, FileCollectionInternal {
  String getDisplayName();
  void visitContentsAsFileTrees(  Consumer<FileTreeInternal> visitor);
  @Override FileTreeInternal matching(  PatternFilterable patterns);
}
