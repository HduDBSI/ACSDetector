/** 
 * A handle to an operation. Can be used to reference an operation from several threads to run nested operations.
 */
interface Operation {
  Object getId();
  @Nullable Object getParentId();
}
