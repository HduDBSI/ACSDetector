/** 
 * Information about a project in the eclipse workspace.
 * @since 5.5
 */
@Incubating public interface EclipseWorkspaceProject {
  /** 
 * The name of the eclipse project
 * @return the name of the project, never null
 */
  @Incubating String getName();
  /** 
 * The filesystem location of the eclipse project
 * @return the location of the eclipse project, may be null in case of remote projects
 */
  @Incubating File getLocation();
  /** 
 * The status of the eclipse project.
 * @since 5.6
 */
  @Incubating boolean isOpen();
}
