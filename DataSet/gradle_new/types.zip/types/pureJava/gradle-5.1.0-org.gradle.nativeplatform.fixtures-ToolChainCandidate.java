public static abstract class ToolChainCandidate implements AbstractContextualMultiVersionSpecRunner.VersionedTool {
  @Override public String toString(){
    return getDisplayName();
  }
  public abstract String getDisplayName();
  public abstract ToolFamily getFamily();
  public abstract VersionNumber getVersion();
  public abstract boolean isAvailable();
  public abstract boolean meets(  ToolChainRequirement requirement);
  public abstract void initialiseEnvironment();
  public abstract void resetEnvironment();
}
