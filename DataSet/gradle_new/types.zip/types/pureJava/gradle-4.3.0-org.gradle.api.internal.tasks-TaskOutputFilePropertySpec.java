public interface TaskOutputFilePropertySpec extends TaskFilePropertySpec {
  OutputType getOutputType();
}
