class ConsumerVariant {
  final AttributeContainerInternal attributes;
  final Transformation transformation;
  final int depth;
  public ConsumerVariant(  AttributeContainerInternal attributes,  Transformation transformation,  int depth){
    this.attributes=attributes;
    this.transformation=transformation;
    this.depth=depth;
  }
}
