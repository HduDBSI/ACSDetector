public interface IncrementalCompilerBuilder {
  IncrementalCompiler newCompiler(  TaskInternal task,  FileCollection sourceFiles,  FileCollection includeDirs);
interface IncrementalCompiler {
    <T extends NativeCompileSpec>Compiler<T> createCompiler(    Compiler<T> compiler);
    void setToolChain(    NativeToolChainInternal toolChain);
    /** 
 * Returns a file collection that contains the header files required by the source files.
 */
    FileCollection getHeaderFiles();
  }
}
