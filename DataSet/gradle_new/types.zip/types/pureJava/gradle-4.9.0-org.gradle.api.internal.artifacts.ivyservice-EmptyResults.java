private static class EmptyResults implements VisitedArtifactSet, SelectedArtifactSet {
  private static final EmptyResults INSTANCE=new EmptyResults();
  @Override public SelectedArtifactSet select(  Spec<? super Dependency> dependencySpec,  AttributeContainerInternal requestedAttributes,  Spec<? super ComponentIdentifier> componentSpec,  boolean allowNoMatchingVariant){
    return this;
  }
  @Override public void collectBuildDependencies(  BuildDependenciesVisitor visitor){
  }
  @Override public void visitArtifacts(  ArtifactVisitor visitor,  boolean continueOnSelectionFailure){
  }
}
