/** 
 * Manages the listeners and state for a given listener type
 */
private class EventBroadcast<T> implements Dispatch<MethodInvocation> {
  private final Class<T> type;
  private final ListenerDispatch dispatch;
  private final ListenerDispatch dispatchNoLogger;
  private volatile ProxyDispatchAdapter<T> source;
  private final Set<ListenerDetails> listeners=new LinkedHashSet<ListenerDetails>();
  private final List<Runnable> queuedOperations=new LinkedList<Runnable>();
  private final ReentrantLock broadcasterLock=new ReentrantLock();
  private ListenerDetails logger;
  private Dispatch<MethodInvocation> parentDispatch;
  private List<Dispatch<MethodInvocation>> allWithLogger=Collections.emptyList();
  private List<Dispatch<MethodInvocation>> allWithNoLogger=Collections.emptyList();
  EventBroadcast(  Class<T> type){
    this.type=type;
    dispatch=new ListenerDispatch(type,true);
    dispatchNoLogger=new ListenerDispatch(type,false);
    if (parent != null) {
      parentDispatch=parent.getBroadcasterInternal(type).getDispatch(true);
      invalidateDispatchCache();
    }
  }
  @Override public void dispatch(  MethodInvocation message){
    dispatch.dispatch(message);
  }
  Dispatch<MethodInvocation> getDispatch(  boolean includeLogger){
    return includeLogger ? dispatch : dispatchNoLogger;
  }
  T getBroadcaster(){
    if (source == null) {
synchronized (this) {
        if (source == null) {
          source=new ProxyDispatchAdapter<T>(this,type);
        }
      }
    }
    return source.getSource();
  }
  private void invalidateDispatchCache(){
    ensureAllWithLoggerInitialized();
    ensureAllWithoutLoggerInitialized();
  }
  void maybeAdd(  final ListenerDetails listener){
    if (type.isInstance(listener.listener)) {
      if (broadcasterLock.tryLock()) {
        try {
          listeners.add(listener);
          invalidateDispatchCache();
        }
  finally {
          broadcasterLock.unlock();
        }
      }
 else {
synchronized (queuedOperations) {
          queuedOperations.add(new Runnable(){
            @Override public void run(){
              listeners.add(listener);
            }
          }
);
        }
      }
    }
  }
  void maybeRemove(  final ListenerDetails listener){
    if (broadcasterLock.tryLock()) {
      try {
        if (listeners.remove(listener)) {
          invalidateDispatchCache();
        }
      }
  finally {
        broadcasterLock.unlock();
      }
    }
 else {
synchronized (queuedOperations) {
        queuedOperations.add(new Runnable(){
          @Override public void run(){
            listeners.remove(listener);
          }
        }
);
      }
    }
  }
  void maybeSetLogger(  final ListenerDetails candidate){
    if (type.isInstance(candidate.listener)) {
      if (broadcasterLock.tryLock()) {
        try {
          doSetLogger(candidate);
          invalidateDispatchCache();
        }
  finally {
          broadcasterLock.unlock();
        }
      }
 else {
synchronized (queuedOperations) {
          queuedOperations.add(new Runnable(){
            @Override public void run(){
              doSetLogger(candidate);
            }
          }
);
        }
      }
    }
  }
  private void doSetLogger(  ListenerDetails candidate){
    if (logger == null && parent != null) {
      parentDispatch=parent.getBroadcasterInternal(type).getDispatch(false);
    }
    logger=candidate;
  }
  private List<Dispatch<MethodInvocation>> startNotification(  boolean includeLogger){
    takeOwnership();
    List<Dispatch<MethodInvocation>> result=includeLogger ? allWithLogger : allWithNoLogger;
    doStartNotification(result);
    return result;
  }
  private void doStartNotification(  List<Dispatch<MethodInvocation>> result){
    for (    Dispatch<MethodInvocation> dispatch : result) {
      if (dispatch instanceof ListenerDetails) {
        ListenerDetails listenerDetails=(ListenerDetails)dispatch;
        listenerDetails.startNotification();
      }
    }
  }
  private void ensureAllWithoutLoggerInitialized(){
    if (parentDispatch == null && listeners.isEmpty()) {
      allWithNoLogger=Collections.emptyList();
    }
 else {
      List<Dispatch<MethodInvocation>> dispatchers=new ArrayList<Dispatch<MethodInvocation>>();
      if (parentDispatch != null) {
        dispatchers.add(parentDispatch);
      }
      dispatchers.addAll(listeners);
      allWithNoLogger=dispatchers;
    }
  }
  private void ensureAllWithLoggerInitialized(){
    if (logger == null && parentDispatch == null && listeners.isEmpty()) {
      allWithLogger=Collections.emptyList();
    }
 else {
      allWithLogger=buildAllWithLogger();
    }
  }
  private void takeOwnership(){
    if (broadcasterLock.isHeldByCurrentThread()) {
      throw new IllegalStateException(String.format("Cannot notify listeners of type %s as these listeners are already being notified.",type.getSimpleName()));
    }
    broadcasterLock.lock();
  }
  private List<Dispatch<MethodInvocation>> buildAllWithLogger(){
    List<Dispatch<MethodInvocation>> result=new ArrayList<Dispatch<MethodInvocation>>();
    if (logger != null) {
      result.add(logger);
    }
    if (parentDispatch != null) {
      result.add(parentDispatch);
    }
    result.addAll(listeners);
    return result;
  }
  private void endNotification(  List<Dispatch<MethodInvocation>> dispatchers){
    for (    Dispatch<MethodInvocation> dispatcher : dispatchers) {
      if (dispatcher instanceof ListenerDetails) {
        ListenerDetails listener=(ListenerDetails)dispatcher;
        listener.endNotification();
      }
    }
    try {
synchronized (queuedOperations) {
        if (!queuedOperations.isEmpty()) {
          for (          Runnable queuedOperation : queuedOperations) {
            queuedOperation.run();
          }
          invalidateDispatchCache();
        }
      }
    }
  finally {
      broadcasterLock.unlock();
    }
  }
private class ListenerDispatch extends AbstractBroadcastDispatch<T> {
    private final boolean includeLogger;
    ListenerDispatch(    Class<T> type,    boolean includeLogger){
      super(type);
      this.includeLogger=includeLogger;
    }
    @Override public void dispatch(    MethodInvocation invocation){
      List<Dispatch<MethodInvocation>> dispatchers=startNotification(includeLogger);
      try {
        if (!dispatchers.isEmpty()) {
          dispatch(invocation,dispatchers.iterator());
        }
      }
  finally {
        endNotification(dispatchers);
      }
    }
  }
}
