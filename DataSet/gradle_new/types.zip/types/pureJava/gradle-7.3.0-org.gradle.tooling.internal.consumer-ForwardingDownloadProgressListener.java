private class ForwardingDownloadProgressListener implements DownloadProgressListener {
  private final OperationDescriptor descriptor;
  private long downloaded=0;
  ForwardingDownloadProgressListener(  OperationDescriptor descriptor){
    this.descriptor=descriptor;
  }
  @Override public void downloadStatusChanged(  URI address,  long contentLength,  long downloaded){
    this.downloaded=downloaded;
    StatusEvent statusEvent=new DefaultStatusEvent(clock.getCurrentTime(),descriptor,contentLength,downloaded,"bytes");
    currentListener.get().onEvent(statusEvent);
  }
}
