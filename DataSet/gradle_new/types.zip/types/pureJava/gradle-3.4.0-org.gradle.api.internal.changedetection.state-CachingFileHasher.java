public class CachingFileHasher implements FileHasher {
  private final PersistentIndexedCache<String,FileInfo> cache;
  private final FileHasher delegate;
  private final StringInterner stringInterner;
  private final FileTimeStampInspector timestampInspector;
  public CachingFileHasher(  FileHasher delegate,  TaskHistoryStore store,  StringInterner stringInterner,  FileTimeStampInspector timestampInspector,  String cacheName){
    this.delegate=delegate;
    this.cache=store.createCache(cacheName,String.class,new FileInfoSerializer(),400000,true);
    this.stringInterner=stringInterner;
    this.timestampInspector=timestampInspector;
  }
  public static boolean isLog(){
    return System.getProperty("org.gradle.internal.changes.log","false").equalsIgnoreCase("true");
  }
  @Override public HashCode hash(  TextResource resource){
    File file=resource.getFile();
    if (file != null) {
      return hash(file);
    }
    return delegate.hash(resource);
  }
  @Override public HashCode hash(  InputStream inputStream){
    return delegate.hash(inputStream);
  }
  @Override public HashCode hash(  File file){
    return snapshot(file).getHash();
  }
  @Override public HashCode hash(  FileTreeElement fileDetails){
    return snapshot(fileDetails).getHash();
  }
  @Override public HashCode hash(  File file,  FileMetadataSnapshot fileDetails){
    return snapshot(file,fileDetails.getLength(),fileDetails.getLastModified()).getHash();
  }
  private FileInfo snapshot(  File file){
    return snapshot(file,file.length(),file.lastModified());
  }
  private FileInfo snapshot(  FileTreeElement file){
    return snapshot(file.getFile(),file.getSize(),file.getLastModified());
  }
  private FileInfo snapshot(  File file,  long length,  long timestamp){
    String absolutePath=file.getAbsolutePath();
    if (timestampInspector.timestampCanBeUsedToDetectFileChange(absolutePath,timestamp)) {
      FileInfo info=cache.get(absolutePath);
      if (info != null && length == info.length && timestamp == info.timestamp) {
        return info;
      }
    }
    HashCode hash=delegate.hash(file);
    FileInfo info=new FileInfo(hash,length,timestamp);
    cache.put(stringInterner.intern(absolutePath),info);
    return info;
  }
  public void discard(  String path){
    cache.remove(path);
  }
@VisibleForTesting static class FileInfo {
    private final HashCode hash;
    private final long timestamp;
    private final long length;
    public FileInfo(    HashCode hash,    long length,    long timestamp){
      this.hash=hash;
      this.length=length;
      this.timestamp=timestamp;
    }
    public HashCode getHash(){
      return hash;
    }
  }
private static class FileInfoSerializer extends AbstractSerializer<FileInfo> {
    private final HashCodeSerializer hashCodeSerializer=new HashCodeSerializer();
    public FileInfo read(    Decoder decoder) throws Exception {
      HashCode hash=hashCodeSerializer.read(decoder);
      long timestamp=decoder.readLong();
      long length=decoder.readLong();
      return new FileInfo(hash,length,timestamp);
    }
    public void write(    Encoder encoder,    FileInfo value) throws Exception {
      hashCodeSerializer.write(encoder,value.hash);
      encoder.writeLong(value.timestamp);
      encoder.writeLong(value.length);
    }
    @Override public boolean equals(    Object obj){
      if (!super.equals(obj)) {
        return false;
      }
      FileInfoSerializer rhs=(FileInfoSerializer)obj;
      return Objects.equal(hashCodeSerializer,rhs.hashCodeSerializer);
    }
    @Override public int hashCode(){
      return Objects.hashCode(super.hashCode(),hashCodeSerializer);
    }
  }
}
