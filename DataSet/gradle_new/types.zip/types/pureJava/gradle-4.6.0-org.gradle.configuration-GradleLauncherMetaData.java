public class GradleLauncherMetaData implements Serializable, BuildClientMetaData {
  private final String appName=System.getProperty("org.gradle.appname","gradle");
  public void describeCommand(  Appendable output,  String... args){
    try {
      output.append(appName);
      for (      String arg : args) {
        output.append(' ');
        output.append(arg);
      }
    }
 catch (    IOException e) {
      throw UncheckedException.throwAsUncheckedException(e);
    }
  }
}
