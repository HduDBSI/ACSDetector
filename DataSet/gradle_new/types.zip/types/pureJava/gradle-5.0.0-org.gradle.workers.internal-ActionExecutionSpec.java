public interface ActionExecutionSpec extends Serializable, Describable {
  Class<?> getImplementationClass();
  @Override String getDisplayName();
  Object[] getParams(  ClassLoader classLoader);
}
