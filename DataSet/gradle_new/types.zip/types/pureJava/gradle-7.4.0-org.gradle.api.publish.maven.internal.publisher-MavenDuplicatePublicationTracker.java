@ServiceScope(Scopes.Project.class) public class MavenDuplicatePublicationTracker {
  private final Project project;
  private final DuplicatePublicationTracker duplicatePublicationTracker;
  private final LocalMavenRepositoryLocator mavenRepositoryLocator;
  public MavenDuplicatePublicationTracker(  Project project,  DuplicatePublicationTracker duplicatePublicationTracker,  LocalMavenRepositoryLocator mavenRepositoryLocator){
    this.project=project;
    this.duplicatePublicationTracker=duplicatePublicationTracker;
    this.mavenRepositoryLocator=mavenRepositoryLocator;
  }
  public void checkCanPublish(  PublicationInternal publication,  @Nullable URI repositoryLocation,  String repositoryName){
    duplicatePublicationTracker.checkCanPublish(project,publication,repositoryLocation,repositoryName);
  }
  public void checkCanPublishToMavenLocal(  PublicationInternal publication){
    checkCanPublish(publication,mavenRepositoryLocator.getLocalMavenRepository().toURI(),"mavenLocal");
  }
}
