public interface VcsMappingFactory {
  VcsMappingInternal create(  ComponentSelector selector);
}
