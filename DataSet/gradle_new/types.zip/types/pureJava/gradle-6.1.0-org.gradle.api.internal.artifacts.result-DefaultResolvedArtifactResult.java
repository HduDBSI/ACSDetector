public class DefaultResolvedArtifactResult implements ResolvedArtifactResult {
  private final ComponentArtifactIdentifier identifier;
  private final ResolvedVariantResult variant;
  private final Class<? extends Artifact> type;
  private final File file;
  public DefaultResolvedArtifactResult(  ComponentArtifactIdentifier identifier,  AttributeContainer variantAttributes,  DisplayName variantDisplayName,  Class<? extends Artifact> type,  File file){
    this(identifier,variantDisplayName,variantAttributes,type,file);
  }
  public DefaultResolvedArtifactResult(  ComponentArtifactIdentifier identifier,  DisplayName variantDisplayName,  AttributeContainer variantAttributes,  Class<? extends Artifact> type,  File file){
    this.identifier=identifier;
    this.variant=new DefaultResolvedVariantResult(variantDisplayName,variantAttributes,Collections.emptyList());
    this.type=type;
    this.file=file;
  }
  @Override public String toString(){
    return identifier.getDisplayName();
  }
  @Override public ComponentArtifactIdentifier getId(){
    return identifier;
  }
  @Override public Class<? extends Artifact> getType(){
    return type;
  }
  @Override public File getFile(){
    return file;
  }
  @Override public ResolvedVariantResult getVariant(){
    return variant;
  }
}
