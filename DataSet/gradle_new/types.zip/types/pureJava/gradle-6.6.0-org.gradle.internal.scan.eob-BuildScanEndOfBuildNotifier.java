/** 
 * Used by the scan plugin to register a listener to be notified about the build finishing.
 */
@UsedByScanPlugin public interface BuildScanEndOfBuildNotifier {
interface BuildResult {
    @Nullable Throwable getFailure();
  }
interface BuildScanResult {
  }
interface Listener {
    /** 
 * Called after all user build logic has completed and the build outcome reported to the logging system. Also called prior to shutting down the build(-tree) scope services
 */
    BuildScanResult execute(    BuildResult buildResult);
  }
  void notify(  Listener listener);
}
