/** 
 * Provides access to the persistent task history store.
 */
public interface TaskHistoryStore extends PersistentStore {
}
