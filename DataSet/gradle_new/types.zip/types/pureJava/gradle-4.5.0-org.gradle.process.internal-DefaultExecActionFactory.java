public class DefaultExecActionFactory implements ExecFactory, Stoppable {
  private final FileResolver fileResolver;
  private final DefaultExecutorFactory executorFactory=new DefaultExecutorFactory();
  private final Executor executor;
  public DefaultExecActionFactory(  FileResolver fileResolver){
    this.fileResolver=fileResolver;
    executor=executorFactory.create("Exec process");
  }
  @Override public void stop(){
    executorFactory.stop();
  }
  @Override public ExecFactory forContext(  FileResolver fileResolver,  Instantiator instantiator){
    return new DecoratingExecActionFactory(fileResolver,instantiator,executor);
  }
  @Override public ExecAction newDecoratedExecAction(){
    throw new UnsupportedOperationException();
  }
  @Override public ExecAction newExecAction(){
    return new DefaultExecAction(fileResolver,executor);
  }
  @Override public JavaExecAction newDecoratedJavaExecAction(){
    throw new UnsupportedOperationException();
  }
  @Override public JavaExecAction newJavaExecAction(){
    return new DefaultJavaExecAction(fileResolver,executor);
  }
  @Override public ExecHandleBuilder newExec(){
    return new DefaultExecHandleBuilder(fileResolver,executor);
  }
  @Override public JavaExecHandleBuilder newJavaExec(){
    return new JavaExecHandleBuilder(fileResolver,executor);
  }
private static class DecoratingExecActionFactory implements ExecFactory {
    private final FileResolver fileResolver;
    private final Instantiator instantiator;
    private final Executor executor;
    DecoratingExecActionFactory(    FileResolver fileResolver,    Instantiator instantiator,    Executor executor){
      this.fileResolver=fileResolver;
      this.instantiator=instantiator;
      this.executor=executor;
    }
    @Override public ExecFactory forContext(    FileResolver fileResolver,    Instantiator instantiator){
      return new DecoratingExecActionFactory(fileResolver,instantiator,executor);
    }
    @Override public ExecAction newExecAction(){
      return new DefaultExecAction(fileResolver,executor);
    }
    @Override public JavaExecAction newJavaExecAction(){
      return new DefaultJavaExecAction(fileResolver,executor);
    }
    @Override public ExecHandleBuilder newExec(){
      return new DefaultExecHandleBuilder(fileResolver,executor);
    }
    @Override public JavaExecHandleBuilder newJavaExec(){
      return new JavaExecHandleBuilder(fileResolver,executor);
    }
    @Override public ExecAction newDecoratedExecAction(){
      return instantiator.newInstance(DefaultExecAction.class,fileResolver,executor);
    }
    @Override public JavaExecAction newDecoratedJavaExecAction(){
      return instantiator.newInstance(DefaultJavaExecAction.class,fileResolver,executor);
    }
  }
}
