public class AllResultsStore implements ResultsStore, Closeable {
  private final CrossVersionResultsStore crossVersion=new CrossVersionResultsStore();
  private final CrossBuildResultsStore crossBuild=new CrossBuildResultsStore();
  private final GradleVsMavenBuildResultsStore gradleVsMaven=new GradleVsMavenBuildResultsStore();
  private final CompositeResultsStore store=new CompositeResultsStore(crossVersion,crossBuild,gradleVsMaven);
  @Override public List<PerformanceExperiment> getPerformanceExperiments(){
    return store.getPerformanceExperiments();
  }
  @Override public PerformanceTestHistory getTestResults(  PerformanceExperiment experiment,  String channel){
    return store.getTestResults(experiment,channel);
  }
  @Override public PerformanceTestHistory getTestResults(  PerformanceExperiment experiment,  int mostRecentN,  int maxDaysOld,  String channel){
    return store.getTestResults(experiment,mostRecentN,maxDaysOld,channel);
  }
  @Override public Map<PerformanceExperimentOnOs,Long> getEstimatedExperimentDurationsInMillis(){
    return store.getEstimatedExperimentDurationsInMillis();
  }
  @Override public void close(){
    CompositeStoppable.stoppable(crossVersion,crossBuild,gradleVsMaven).stop();
  }
}
