@UsedByScanPlugin public static class Span implements StyledTextBuildOperationProgressDetails.Span, Serializable {
  private final String text;
  private final StyledTextOutput.Style style;
  public Span(  StyledTextOutput.Style style,  String text){
    this.style=style;
    this.text=text;
  }
  public Span(  String text){
    this.style=StyledTextOutput.Style.Normal;
    this.text=text;
  }
  public StyledTextOutput.Style getStyle(){
    return style;
  }
  @Override public String getStyleName(){
    return getStyle().name();
  }
  public String getText(){
    return text;
  }
}
