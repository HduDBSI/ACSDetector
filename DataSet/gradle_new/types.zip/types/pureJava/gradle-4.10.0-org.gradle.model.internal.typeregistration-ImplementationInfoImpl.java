private static class ImplementationInfoImpl<PUBLIC> implements ImplementationInfo {
  private final ModelType<PUBLIC> publicType;
  private final ImplementationRegistration<? super PUBLIC> implementationRegistration;
  private final Set<ModelType<?>> internalViews;
  public ImplementationInfoImpl(  ModelType<PUBLIC> publicType,  ImplementationRegistration<?> implementationRegistration,  Set<ModelType<?>> internalViews){
    this.publicType=publicType;
    this.internalViews=internalViews;
    this.implementationRegistration=Cast.uncheckedCast(implementationRegistration);
  }
  @Override public Object create(  MutableModelNode modelNode){
    ImplementationFactory<PUBLIC,Object> implementationFactory=Cast.uncheckedCast(implementationRegistration.factory);
    return implementationFactory.create(publicType,implementationRegistration.implementationType,modelNode.getPath().getName(),modelNode);
  }
  @Override public ModelType<?> getDelegateType(){
    return implementationRegistration.implementationType;
  }
  @Override public Set<ModelType<?>> getInternalViews(){
    return internalViews;
  }
  @Override public String toString(){
    return String.valueOf(publicType);
  }
}
