public abstract class ConventionTask extends DefaultTask implements IConventionAware {
  private ConventionMapping conventionMapping;
  public Task conventionMapping(  String property,  Callable<?> mapping){
    getConventionMapping().map(property,mapping);
    return this;
  }
  public Task conventionMapping(  String property,  Closure mapping){
    getConventionMapping().map(property,mapping);
    return this;
  }
  @Override @Internal public ConventionMapping getConventionMapping(){
    if (conventionMapping == null) {
      conventionMapping=new ConventionAwareHelper(this,getConvention());
    }
    return conventionMapping;
  }
}
