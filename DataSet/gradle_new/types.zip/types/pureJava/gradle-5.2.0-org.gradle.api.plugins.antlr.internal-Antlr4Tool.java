static class Antlr4Tool extends AntlrTool {
  @Override int invoke(  List<String> arguments,  File inputDirectory) throws ClassNotFoundException {
    final Object backedObject=loadTool("org.antlr.v4.Tool",toArray(arguments));
    if (inputDirectory != null) {
      setField(backedObject,"inputDirectory",inputDirectory);
    }
    JavaMethod.of(backedObject,Void.class,"processGrammarsOnCommandLine").invoke(backedObject);
    return JavaMethod.of(backedObject,Integer.class,"getNumErrors").invoke(backedObject);
  }
  private static void setField(  Object object,  String fieldName,  File value){
    try {
      Field field=object.getClass().getField(fieldName);
      field.set(object,value);
    }
 catch (    NoSuchFieldException|IllegalAccessException e) {
      throw UncheckedException.throwAsUncheckedException(e);
    }
  }
  @Override public boolean available(){
    try {
      loadTool("org.antlr.v4.Tool",null);
    }
 catch (    ClassNotFoundException cnf) {
      return false;
    }
    return true;
  }
}
