public interface InputChangesContext extends BeforeExecutionContext {
  Optional<InputChangesInternal> getInputChanges();
  boolean isIncrementalExecution();
}
