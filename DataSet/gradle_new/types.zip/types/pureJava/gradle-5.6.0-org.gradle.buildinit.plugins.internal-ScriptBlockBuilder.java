public interface ScriptBlockBuilder {
  /** 
 * Adds a property assignment statement to this block
 */
  void propertyAssignment(  @Nullable String comment,  String propertyName,  Object propertyValue);
  /** 
 * Adds a method invocation statement to this block
 */
  void methodInvocation(  @Nullable String comment,  String methodName,  Object... methodArgs);
  /** 
 * Adds a method invocation statement to this block
 */
  void methodInvocation(  @Nullable String comment,  BuildScriptBuilder.Expression target,  String methodName,  Object... methodArgs);
  /** 
 * Adds a block statement to this block.
 * @return The body of the block, to which further statements can be added.
 */
  ScriptBlockBuilder block(  @Nullable String comment,  String methodName);
  /** 
 * Adds a block statement to this block.
 */
  void block(  @Nullable String comment,  String methodName,  Action<? super ScriptBlockBuilder> blockContentsBuilder);
  /** 
 * Adds an element to the given container.
 * @return an expression that can be used to refer to the element. Note: currently this expression can only be used within this current block.
 */
  BuildScriptBuilder.Expression containerElement(  @Nullable String comment,  String container,  String elementName,  Action<? super ScriptBlockBuilder> blockContentsBuilder);
  /** 
 * Returns a property expression that can be used as a method argument or property assignment value
 */
  BuildScriptBuilder.Expression propertyExpression(  String value);
}
