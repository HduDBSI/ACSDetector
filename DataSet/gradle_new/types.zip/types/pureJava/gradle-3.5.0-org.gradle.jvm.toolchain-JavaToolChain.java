/** 
 * A set of tools for building from Java source. <p>A  {@code JavaToolChain} is able to:<ul> <li>Compile Java source to bytecode.</li> <li>Generate Javadoc from Java source.</li> </ul>
 */
@Incubating @HasInternalProtocol public interface JavaToolChain extends ToolChain {
  /** 
 * The version of the toolchain.
 * @since 3.5
 */
  @Input String getVersion();
  /** 
 * {@inheritDoc}
 */
  @Override @Internal String getDisplayName();
  /** 
 * {@inheritDoc}
 */
  @Override @Internal String getName();
}
