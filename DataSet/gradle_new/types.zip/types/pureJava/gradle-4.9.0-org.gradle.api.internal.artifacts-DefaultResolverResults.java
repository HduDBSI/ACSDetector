public class DefaultResolverResults implements ResolverResults {
  private ResolvedConfiguration resolvedConfiguration;
  private ResolutionResult resolutionResult;
  private ResolveException fatalFailure;
  private ResolveException nonFatalFailure;
  private ResolvedLocalComponentsResult resolvedLocalComponentsResult;
  private Object artifactResolveState;
  private VisitedArtifactSet visitedArtifacts;
  @Override public boolean hasError(){
    if (fatalFailure != null || nonFatalFailure != null) {
      return true;
    }
    if (resolvedConfiguration != null && resolvedConfiguration.hasError()) {
      return true;
    }
    return false;
  }
  @Override public ResolvedConfiguration getResolvedConfiguration(){
    assertHasArtifactResult();
    return resolvedConfiguration;
  }
  @Override public ResolutionResult getResolutionResult(){
    assertHasGraphResult();
    return resolutionResult;
  }
  @Override public ResolvedLocalComponentsResult getResolvedLocalComponents(){
    assertHasGraphResult();
    return resolvedLocalComponentsResult;
  }
  @Override public VisitedArtifactSet getVisitedArtifacts(){
    assertHasVisitResult();
    return visitedArtifacts;
  }
  private void assertHasVisitResult(){
    maybeRethrowFatalError();
    if (visitedArtifacts == null) {
      throw new IllegalStateException("Resolution result has not been attached.");
    }
  }
  private void assertHasGraphResult(){
    maybeRethrowFatalError();
    if (resolvedLocalComponentsResult == null) {
      throw new IllegalStateException("Resolution result has not been attached.");
    }
  }
  private void maybeRethrowFatalError(){
    if (fatalFailure != null) {
      throw fatalFailure;
    }
  }
  private void maybeRethrowAnyError(){
    maybeRethrowFatalError();
    if (nonFatalFailure != null) {
      throw nonFatalFailure;
    }
  }
  private void assertHasArtifactResult(){
    if (resolvedConfiguration == null) {
      throw new IllegalStateException("Resolution artifacts have not been attached.");
    }
  }
  @Override public void graphResolved(  VisitedArtifactSet visitedArtifacts){
    this.visitedArtifacts=visitedArtifacts;
    this.resolvedLocalComponentsResult=null;
    this.resolutionResult=null;
    this.fatalFailure=null;
  }
  @Override public void graphResolved(  ResolutionResult resolutionResult,  ResolvedLocalComponentsResult resolvedLocalComponentsResult,  VisitedArtifactSet visitedArtifacts){
    this.resolutionResult=resolutionResult;
    this.resolvedLocalComponentsResult=resolvedLocalComponentsResult;
    this.visitedArtifacts=visitedArtifacts;
    this.fatalFailure=null;
  }
  @Override public void failed(  ResolveException failure){
    if (isNonFatalError(failure)) {
      nonFatalFailure=failure;
    }
 else {
      this.resolutionResult=null;
      this.resolvedLocalComponentsResult=null;
      this.fatalFailure=failure;
    }
  }
  private static boolean isNonFatalError(  ResolveException failure){
    return failure.getCause() instanceof GraphValidationException;
  }
  @Override public void artifactsResolved(  ResolvedConfiguration resolvedConfiguration,  VisitedArtifactSet visitedArtifacts){
    this.resolvedConfiguration=resolvedConfiguration;
    this.visitedArtifacts=visitedArtifacts;
    this.artifactResolveState=null;
  }
  @Override public ResolveException consumeNonFatalFailure(){
    try {
      return nonFatalFailure;
    }
  finally {
      nonFatalFailure=null;
    }
  }
  @Override public Throwable getFailure(){
    if (fatalFailure != null) {
      return fatalFailure;
    }
    if (nonFatalFailure != null) {
      return nonFatalFailure;
    }
    return null;
  }
  @Override public boolean hasResolutionResult(){
    return resolutionResult != null;
  }
  @Override public void retainState(  Object artifactResolveState){
    this.artifactResolveState=artifactResolveState;
  }
  @Override public Object getArtifactResolveState(){
    maybeRethrowAnyError();
    return artifactResolveState;
  }
}
