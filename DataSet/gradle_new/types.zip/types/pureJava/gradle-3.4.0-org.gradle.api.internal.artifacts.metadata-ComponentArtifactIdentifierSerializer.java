public class ComponentArtifactIdentifierSerializer extends AbstractSerializer<ComponentArtifactIdentifier> {
  private final ComponentIdentifierSerializer componentIdentifierSerializer=new ComponentIdentifierSerializer();
  public void write(  Encoder encoder,  ComponentArtifactIdentifier value) throws Exception {
    if (value instanceof DefaultModuleComponentArtifactIdentifier) {
      DefaultModuleComponentArtifactIdentifier moduleComponentArtifactIdentifier=(DefaultModuleComponentArtifactIdentifier)value;
      componentIdentifierSerializer.write(encoder,moduleComponentArtifactIdentifier.getComponentIdentifier());
      IvyArtifactName ivyArtifactName=moduleComponentArtifactIdentifier.getName();
      encoder.writeString(ivyArtifactName.getName());
      encoder.writeString(ivyArtifactName.getType());
      encoder.writeNullableString(ivyArtifactName.getExtension());
      encoder.writeNullableString(ivyArtifactName.getClassifier());
    }
 else {
      throw new IllegalArgumentException("Unknown identifier type.");
    }
  }
  public ComponentArtifactIdentifier read(  Decoder decoder) throws Exception {
    ModuleComponentIdentifier componentIdentifier=(ModuleComponentIdentifier)componentIdentifierSerializer.read(decoder);
    String artifactName=decoder.readString();
    String type=decoder.readString();
    String extension=decoder.readNullableString();
    String classifier=decoder.readNullableString();
    return new DefaultModuleComponentArtifactIdentifier(componentIdentifier,artifactName,type,extension,classifier);
  }
  @Override public boolean equals(  Object obj){
    if (!super.equals(obj)) {
      return false;
    }
    ComponentArtifactIdentifierSerializer rhs=(ComponentArtifactIdentifierSerializer)obj;
    return Objects.equal(componentIdentifierSerializer,rhs.componentIdentifierSerializer);
  }
  @Override public int hashCode(){
    return Objects.hashCode(super.hashCode(),componentIdentifierSerializer);
  }
}
