/** 
 * The result of resolving a component.
 * @since 2.0
 */
@Incubating public interface ComponentResult {
  /** 
 * Returns the ID of the requested component.
 */
  ComponentIdentifier getId();
}
