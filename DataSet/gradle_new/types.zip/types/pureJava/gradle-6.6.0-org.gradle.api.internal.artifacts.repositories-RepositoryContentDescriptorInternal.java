public interface RepositoryContentDescriptorInternal extends RepositoryContentDescriptor {
  Action<? super ArtifactResolutionDetails> toContentFilter();
}
