/** 
 * A Junit rule which copies a sample into the test directory before the test executes. Looks for a {@link org.gradle.integtests.fixtures.UsesSample} annotation on the test method to determine which sample thetest requires. If not found, uses the default sample provided in the constructor.
 */
public class Sample implements TestRule {
  private final Logger logger=LoggerFactory.getLogger(Sample.class);
  private final String defaultSampleName;
  private final String testSampleDirName;
  private String sampleName;
  private TestFile sampleDir;
  private TestDirectoryProvider testDirectoryProvider;
  public Sample(  TestDirectoryProvider testDirectoryProvider){
    this(testDirectoryProvider,null);
  }
  public Sample(  TestDirectoryProvider testDirectoryProvider,  String defaultSampleName){
    this(testDirectoryProvider,defaultSampleName,null);
  }
  public Sample(  TestDirectoryProvider testDirectoryProvider,  String defaultSampleName,  String testSampleDirName){
    this.testDirectoryProvider=testDirectoryProvider;
    this.defaultSampleName=defaultSampleName;
    this.testSampleDirName=testSampleDirName;
  }
  @Override public Statement apply(  final Statement base,  Description description){
    sampleName=getSampleName(description);
    return new Statement(){
      @Override public void evaluate() throws Throwable {
        if (sampleName != null) {
          String hintForMissingSample=String.format("If '%s' is a new sample, try running 'gradle intTestImage'.",sampleName);
          TestFile srcDir=new IntegrationTestBuildContext().getSamplesDir().file(sampleName).assertIsDir(hintForMissingSample);
          logger.debug("Copying sample '{}' to test directory.",sampleName);
          srcDir.copyTo(getDir());
        }
 else {
          logger.debug("No sample specified for this test, skipping.");
        }
        base.evaluate();
      }
    }
;
  }
  private String getSampleName(  Description description){
    UsesSample annotation=description.getAnnotation(UsesSample.class);
    return annotation != null ? annotation.value() : defaultSampleName;
  }
  public TestFile getDir(){
    if (sampleDir == null) {
      sampleDir=computeSampleDir();
    }
    return sampleDir;
  }
  @Nullable private TestFile computeSampleDir(){
    if (testSampleDirName != null) {
      return testFile(testSampleDirName);
    }
    if (sampleName != null) {
      return testFile(dirNameFor(sampleName));
    }
    return null;
  }
  /** 
 * Shortens path as much as possible to prevent long path issues on Windows by keeping the last segment only, ignoring /groovy or /kotlin suffix.
 */
  @VisibleForTesting static String dirNameFor(  String sampleName){
    String dirName=sampleName.endsWith("/") ? sampleName.substring(0,sampleName.length() - 1) : sampleName;
    for (    String dslLanguageCodeName : GradleDsl.languageCodeNames()) {
      String dslPathFragment='/' + dslLanguageCodeName;
      if (dirName.endsWith(dslPathFragment)) {
        dirName=dirName.substring(0,dirName.lastIndexOf(dslPathFragment));
      }
    }
    return dirName.substring(dirName.lastIndexOf('/') + 1);
  }
  private TestFile testFile(  String testSampleDirName){
    return testDirectoryProvider.getTestDirectory().file(testSampleDirName);
  }
}
