static class Antlr4Tool extends AntlrTool {
  @Override int invoke(  List<String> arguments,  File inputDirectory) throws ClassNotFoundException {
    final Object backedObject=loadTool("org.antlr.v4.Tool",toArray(arguments));
    if (inputDirectory != null) {
      JavaReflectionUtil.writeableField(backedObject.getClass(),"inputDirectory").setValue(backedObject,inputDirectory);
    }
    JavaReflectionUtil.method(backedObject,Void.class,"processGrammarsOnCommandLine").invoke(backedObject);
    return JavaReflectionUtil.method(backedObject,Integer.class,"getNumErrors").invoke(backedObject);
  }
  @Override public boolean available(){
    try {
      loadTool("org.antlr.v4.Tool",null);
    }
 catch (    ClassNotFoundException cnf) {
      return false;
    }
    return true;
  }
}
