public class ClasspathPropertyAnnotationHandler implements OverridingPropertyAnnotationHandler, FileSnapshottingPropertyAnnotationHandler {
  @Override public Class<? extends Annotation> getAnnotationType(){
    return Classpath.class;
  }
  @Override public Class<? extends Annotation> getOverriddenAnnotationType(){
    return InputFiles.class;
  }
  public Class<? extends FileCollectionSnapshotter> getSnapshotterType(){
    return ClasspathSnapshotter.class;
  }
  @Override public void attachActions(  final TaskPropertyActionContext context){
    context.setConfigureAction(new UpdateAction(){
      public void update(      TaskInternal task,      Callable<Object> futureValue){
        final TaskInputFilePropertyBuilder propertyBuilder=((TaskInputFilePropertyBuilderInternal)task.getInputs().files(futureValue)).withPropertyName(context.getName()).withSnapshotNormalizationStrategy(ClasspathSnapshotNormalizationStrategy.INSTANCE).withSnapshotter(getSnapshotterType()).optional(context.isOptional());
        DeprecationLogger.whileDisabled(new Runnable(){
          @Override @SuppressWarnings("deprecation") public void run(){
            propertyBuilder.orderSensitive();
          }
        }
);
      }
    }
);
  }
}
