/** 
 * Adapter to create  {@link org.gradle.tooling.internal.protocol.InternalBuildAction}from an instance of  {@link org.gradle.tooling.BuildAction}. Used by consumer connections 1.8+.
 */
public class InternalBuildActionAdapter<T> implements InternalBuildAction<T>, InternalBuildActionVersion2<T> {
  private final BuildAction<T> action;
  private final File rootDir;
  private final VersionDetails versionDetails;
  public InternalBuildActionAdapter(  BuildAction<T> action,  File rootDir,  VersionDetails versionDetails){
    this.action=action;
    this.rootDir=rootDir;
    this.versionDetails=versionDetails;
  }
  /** 
 * This is used by providers 1.8-rc-1 to 4.3
 */
  public T execute(  final InternalBuildController buildController){
    ProtocolToModelAdapter protocolToModelAdapter=new ProtocolToModelAdapter(new ConsumerTargetTypeProvider());
    BuildController buildControllerAdapter=new BuildControllerAdapter(protocolToModelAdapter,new InternalBuildControllerAdapter(){
      @Override public BuildResult<?> getModel(      Object target,      ModelIdentifier modelIdentifier,      Object parameter){
        return buildController.getModel(target,modelIdentifier);
      }
    }
,new ModelMapping(),rootDir);
    buildControllerAdapter=new BuildControllerWithoutParameterSupport(versionDetails,buildControllerAdapter);
    if (!versionDetails.maySupportModel(BuildInvocations.class)) {
      buildControllerAdapter=new BuildInvocationsAdapterController(protocolToModelAdapter,buildControllerAdapter);
    }
    return action.execute(buildControllerAdapter);
  }
  /** 
 * This is used by providers 4.4 and later
 */
  public T execute(  final InternalBuildControllerVersion2 buildController){
    ProtocolToModelAdapter protocolToModelAdapter=new ProtocolToModelAdapter(new ConsumerTargetTypeProvider());
    BuildController buildControllerAdapter=new BuildControllerAdapter(protocolToModelAdapter,new InternalBuildControllerAdapter(){
      @Override public BuildResult<?> getModel(      Object target,      ModelIdentifier modelIdentifier,      Object parameter){
        return buildController.getModel(target,modelIdentifier,parameter);
      }
    }
,new ModelMapping(),rootDir);
    return action.execute(buildControllerAdapter);
  }
}
