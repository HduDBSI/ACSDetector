interface TrackingHttpHandler {
  /** 
 * Selects a response producer to handle the given request. This method is called under the state lock. The handler is _not_ called under the state lock. That is, the lock is held only while selecting how to handle the request. This method may block until the request is ready to be handled, but must do so using a condition created from the state lock.
 * @return null when this handler is not expecting any further requests.
 */
  @Nullable ResponseProducer selectResponseProducer(  int id,  HttpExchange exchange);
  boolean expecting(  HttpExchange exchange);
  /** 
 * Returns a precondition that asserts that this handler is not expecting any further requests to be released by the test in order to complete.
 */
  WaitPrecondition getWaitPrecondition();
  /** 
 * Releases any blocked requests, in preparation for shutdown.
 */
  void cancelBlockedRequests();
  /** 
 * Asserts that this handler has been completed successfully.
 */
  void assertComplete(  Collection<Throwable> failures);
}
