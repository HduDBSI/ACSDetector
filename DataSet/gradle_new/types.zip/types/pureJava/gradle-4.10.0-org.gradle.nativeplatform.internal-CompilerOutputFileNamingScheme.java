public class CompilerOutputFileNamingScheme {
  private String objectFileNameSuffix;
  private File outputBaseFolder;
  private final RelativeFilePathResolver fileResolver;
  public CompilerOutputFileNamingScheme(  RelativeFilePathResolver fileResolver){
    this.fileResolver=fileResolver;
  }
  public CompilerOutputFileNamingScheme withOutputBaseFolder(  File outputBaseFolder){
    this.outputBaseFolder=outputBaseFolder;
    return this;
  }
  public CompilerOutputFileNamingScheme withObjectFileNameSuffix(  String suffix){
    this.objectFileNameSuffix=suffix;
    return this;
  }
  public File map(  File sourceFile){
    final String baseName=FilenameUtils.removeExtension(sourceFile.getName());
    final String uniqueName=generateUniqueNameFor(sourceFile);
    File hashDirectory=new File(outputBaseFolder,uniqueName);
    return new File(hashDirectory,baseName + objectFileNameSuffix);
  }
  protected String generateUniqueNameFor(  File sourceFile){
    return HashUtil.createCompactMD5(fileResolver.resolveAsRelativePath(sourceFile));
  }
}
