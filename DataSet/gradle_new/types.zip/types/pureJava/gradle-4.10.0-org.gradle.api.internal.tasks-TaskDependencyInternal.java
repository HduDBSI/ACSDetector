public interface TaskDependencyInternal extends TaskDependency, TaskDependencyContainer {
}
