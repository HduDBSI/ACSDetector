private static class DefaultComponentSelectionReason implements ComponentSelectionReasonInternal {
  private final boolean forced;
  private final boolean conflictResolution;
  private final boolean selectedByRule;
  private final boolean expected;
  private final boolean compositeParticipant;
  private final String description;
  private DefaultComponentSelectionReason(  boolean forced,  boolean conflictResolution,  boolean selectedByRule,  boolean expected,  boolean compositeBuild,  String description){
    this.forced=forced;
    this.conflictResolution=conflictResolution;
    this.selectedByRule=selectedByRule;
    this.expected=expected;
    this.compositeParticipant=compositeBuild;
    assert description != null;
    this.description=description;
  }
  public boolean isForced(){
    return forced;
  }
  public boolean isConflictResolution(){
    return conflictResolution;
  }
  public boolean isSelectedByRule(){
    return selectedByRule;
  }
  public boolean isExpected(){
    return expected;
  }
  public boolean isCompositeSubstitution(){
    return compositeParticipant;
  }
  public String getDescription(){
    return description;
  }
  public String toString(){
    return description;
  }
  @Override public ComponentSelectionReasonInternal withReason(  String description){
    return new DefaultComponentSelectionReason(forced,conflictResolution,selectedByRule,expected,compositeParticipant,description);
  }
  @Override public boolean equals(  Object o){
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    DefaultComponentSelectionReason that=(DefaultComponentSelectionReason)o;
    return forced == that.forced && conflictResolution == that.conflictResolution && selectedByRule == that.selectedByRule && expected == that.expected && compositeParticipant == that.compositeParticipant && Objects.equal(description,that.description);
  }
  @Override public int hashCode(){
    return Objects.hashCode(forced,conflictResolution,selectedByRule,expected,compositeParticipant,description);
  }
}
