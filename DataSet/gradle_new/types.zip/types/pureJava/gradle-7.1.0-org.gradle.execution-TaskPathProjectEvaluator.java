public class TaskPathProjectEvaluator implements ProjectConfigurer {
  private final BuildCancellationToken cancellationToken;
  public TaskPathProjectEvaluator(  BuildCancellationToken cancellationToken){
    this.cancellationToken=cancellationToken;
  }
  @Override public void configure(  ProjectInternal project){
    if (cancellationToken.isCancellationRequested()) {
      throw new BuildCancelledException();
    }
    ProjectInternal parentProject=project.getParent();
    if (parentProject != null) {
      configure(parentProject);
    }
    project.getOwner().ensureConfigured();
  }
  @Override public void configureFully(  ProjectInternal project){
    configure(project);
    if (cancellationToken.isCancellationRequested()) {
      throw new BuildCancelledException();
    }
    project.getOwner().ensureTasksDiscovered();
  }
  @Override public void configureHierarchy(  ProjectInternal project){
    configure(project);
    for (    Project sub : project.getSubprojects()) {
      configure((ProjectInternal)sub);
    }
  }
  @Override public void configureHierarchyFully(  ProjectInternal project){
    configureFully(project);
    for (    Project sub : project.getSubprojects()) {
      configureFully((ProjectInternal)sub);
    }
  }
}
