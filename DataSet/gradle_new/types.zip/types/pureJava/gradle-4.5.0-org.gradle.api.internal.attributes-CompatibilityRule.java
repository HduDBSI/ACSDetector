public interface CompatibilityRule<T> extends Action<CompatibilityCheckResult<T>> {
  boolean doesSomething();
}
