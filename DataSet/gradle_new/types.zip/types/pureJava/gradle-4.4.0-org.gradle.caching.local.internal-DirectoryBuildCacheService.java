public class DirectoryBuildCacheService implements LocalBuildCacheService, BuildCacheService {
  private final PathKeyFileStore fileStore;
  private final PersistentCache persistentCache;
  private final BuildCacheTempFileStore tempFileStore;
  private final String failedFileSuffix;
  private final ReadWriteLock lock=new ReentrantReadWriteLock();
  public DirectoryBuildCacheService(  PathKeyFileStore fileStore,  PersistentCache persistentCache,  BuildCacheTempFileStore tempFileStore,  String failedFileSuffix){
    this.fileStore=fileStore;
    this.persistentCache=persistentCache;
    this.tempFileStore=tempFileStore;
    this.failedFileSuffix=failedFileSuffix;
  }
private static class LoadAction implements Action<File> {
    private final BuildCacheEntryReader reader;
    boolean loaded;
    private LoadAction(    BuildCacheEntryReader reader){
      this.reader=reader;
    }
    @Override public void execute(    @Nonnull File file){
      try {
        GFileUtils.touch(file);
        Closer closer=Closer.create();
        FileInputStream stream=closer.register(new FileInputStream(file));
        try {
          reader.readFrom(stream);
          loaded=true;
        }
  finally {
          closer.close();
        }
      }
 catch (      IOException ex) {
        throw new UncheckedIOException(ex);
      }
    }
  }
  @Override public boolean load(  final BuildCacheKey key,  final BuildCacheEntryReader reader) throws BuildCacheException {
    LoadAction loadAction=new LoadAction(reader);
    load(key,loadAction);
    return loadAction.loaded;
  }
  @Override public void load(  final BuildCacheKey key,  final Action<? super File> reader){
    persistentCache.withFileLock(new Runnable(){
      @Override public void run(){
        lock.readLock().lock();
        try {
          loadInsideLock(key,reader);
        }
  finally {
          lock.readLock().unlock();
        }
      }
    }
);
  }
  private void loadInsideLock(  BuildCacheKey key,  Action<? super File> reader){
    LocallyAvailableResource resource=fileStore.get(key.getHashCode());
    if (resource == null) {
      return;
    }
    File file=resource.getFile();
    touch(file);
    try {
      reader.execute(file);
    }
 catch (    Exception e) {
      File failedFile=new File(file.getAbsolutePath() + failedFileSuffix);
      GFileUtils.deleteQuietly(failedFile);
      file.renameTo(failedFile);
      throw UncheckedException.throwAsUncheckedException(e);
    }
  }
  @Override public void store(  final BuildCacheKey key,  final BuildCacheEntryWriter result) throws BuildCacheException {
    tempFileStore.allocateTempFile(key,new Action<File>(){
      @Override public void execute(      @Nonnull File file){
        try {
          Closer closer=Closer.create();
          try {
            result.writeTo(closer.register(new FileOutputStream(file)));
          }
 catch (          Exception e) {
            throw closer.rethrow(e);
          }
 finally {
            closer.close();
          }
        }
 catch (        IOException ex) {
          throw UncheckedException.throwAsUncheckedException(ex);
        }
        store(key,file);
      }
    }
);
  }
  @Override public void store(  final BuildCacheKey key,  final File file){
    persistentCache.withFileLock(new Runnable(){
      @Override public void run(){
        lock.writeLock().lock();
        try {
          storeInsideLock(key,file);
        }
  finally {
          lock.writeLock().unlock();
        }
      }
    }
);
  }
  private void storeInsideLock(  BuildCacheKey key,  File file){
    fileStore.move(key.getHashCode(),file);
  }
  @Override public void allocateTempFile(  final BuildCacheKey key,  final Action<? super File> action){
    persistentCache.withFileLock(new Runnable(){
      @Override public void run(){
        tempFileStore.allocateTempFile(key,action);
      }
    }
);
  }
  @Override public void close(){
    persistentCache.close();
  }
  @SuppressWarnings("Since15") private static void touch(  File file){
    try {
      Files.setLastModifiedTime(file.toPath(),FileTime.fromMillis(System.currentTimeMillis()));
    }
 catch (    IOException e) {
      throw new UncheckedIOException(e);
    }
  }
}
