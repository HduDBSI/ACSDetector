public class JavaHomeBasedJavaCompilerFactory implements Factory<JavaCompiler>, Serializable {
  private final List<File> compilerPluginsClasspath;
  private final static transient Map<List<File>,JdkTools> JDK_TOOLS=new ConcurrentHashMap<>();
  public JavaHomeBasedJavaCompilerFactory(  List<File> compilerPluginsClasspath){
    this.compilerPluginsClasspath=compilerPluginsClasspath;
  }
  @Override public JavaCompiler create(){
    JdkTools jdkTools=JavaHomeBasedJavaCompilerFactory.JDK_TOOLS.computeIfAbsent(compilerPluginsClasspath,JavaHomeBasedJavaCompilerFactory::createJdkTools);
    return jdkTools.getSystemJavaCompiler();
  }
  private static JdkTools createJdkTools(  List<File> compilerPluginsClasspath){
    return new JdkTools(Jvm.current(),compilerPluginsClasspath);
  }
}
