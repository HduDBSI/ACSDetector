public class LocalClassSetAnalysisStore implements Loader<ClassSetAnalysisData>, Stash<ClassSetAnalysisData> {
  private SingleOperationPersistentStore<ClassSetAnalysisData> store;
  public LocalClassSetAnalysisStore(  CacheRepository cacheRepository,  Object scope){
    this.store=new SingleOperationPersistentStore<ClassSetAnalysisData>(cacheRepository,scope,"local class set analysis",new ClassSetAnalysisData.Serializer());
  }
  @Override public void put(  ClassSetAnalysisData analysis){
    store.putAndClose(analysis);
  }
  @Override public ClassSetAnalysisData get(){
    return store.getAndClose();
  }
}
