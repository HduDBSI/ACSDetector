public interface CacheableTaskOutputFilePropertySpec extends TaskOutputFilePropertySpec {
  @Nullable File getOutputFile();
}
