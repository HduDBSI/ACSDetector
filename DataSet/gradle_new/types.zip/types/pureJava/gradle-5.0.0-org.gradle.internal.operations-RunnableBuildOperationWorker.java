private static class RunnableBuildOperationWorker implements BuildOperationWorker<RunnableBuildOperation> {
  @Override public String getDisplayName(){
    return "runnable build operation";
  }
  @Override public void execute(  RunnableBuildOperation buildOperation,  BuildOperationContext context){
    buildOperation.run(context);
  }
}
