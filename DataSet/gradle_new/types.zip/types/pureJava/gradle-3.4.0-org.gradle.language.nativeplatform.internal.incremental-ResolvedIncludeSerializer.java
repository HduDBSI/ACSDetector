private static class ResolvedIncludeSerializer extends AbstractSerializer<ResolvedInclude> {
  private final Serializer<File> fileSerializer;
  private ResolvedIncludeSerializer(  Serializer<File> fileSerializer){
    this.fileSerializer=fileSerializer;
  }
  @Override public ResolvedInclude read(  Decoder decoder) throws Exception {
    String include=decoder.readString();
    File included=null;
    if (decoder.readBoolean()) {
      included=fileSerializer.read(decoder);
    }
    return new ResolvedInclude(include,included);
  }
  @Override public void write(  Encoder encoder,  ResolvedInclude value) throws Exception {
    encoder.writeString(value.getInclude());
    if (value.getFile() == null) {
      encoder.writeBoolean(false);
    }
 else {
      encoder.writeBoolean(true);
      fileSerializer.write(encoder,value.getFile());
    }
  }
  @Override public boolean equals(  Object obj){
    if (!super.equals(obj)) {
      return false;
    }
    ResolvedIncludeSerializer rhs=(ResolvedIncludeSerializer)obj;
    return Objects.equal(fileSerializer,rhs.fileSerializer);
  }
  @Override public int hashCode(){
    return Objects.hashCode(super.hashCode(),fileSerializer);
  }
}
