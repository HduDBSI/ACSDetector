abstract class AbstractOptionElement implements OptionElement {
  private final String optionName;
  private final String description;
  private final Class<?> optionType;
  private final NotationParser<CharSequence,?> notationParser;
  public AbstractOptionElement(  String optionName,  org.gradle.api.internal.tasks.options.Option option,  Class<?> optionType,  Class<?> declaringClass,  NotationParser<CharSequence,?> notationParser){
    this(readDescription(option,optionName,declaringClass),optionName,optionType,notationParser);
  }
  public AbstractOptionElement(  String optionName,  Option option,  Class<?> optionType,  Class<?> declaringClass,  NotationParser<CharSequence,?> notationParser){
    this(readDescription(option,optionName,declaringClass),optionName,optionType,notationParser);
  }
  private AbstractOptionElement(  String description,  String optionName,  Class<?> optionType,  NotationParser<CharSequence,?> notationParser){
    this.description=description;
    this.optionName=optionName;
    this.optionType=optionType;
    this.notationParser=notationParser;
  }
  public Set<String> getAvailableValues(){
    ValueCollectingDiagnosticsVisitor visitor=new ValueCollectingDiagnosticsVisitor();
    notationParser.describe(visitor);
    return visitor.getValues();
  }
  public Class<?> getOptionType(){
    return optionType;
  }
  private static String readDescription(  Option option,  String optionName,  Class<?> declaringClass){
    try {
      return option.description();
    }
 catch (    IncompleteAnnotationException ex) {
      throw new OptionValidationException(String.format("No description set on option '%s' at for class '%s'.",optionName,declaringClass.getName()));
    }
  }
  private static String readDescription(  org.gradle.api.internal.tasks.options.Option option,  String optionName,  Class<?> declaringClass){
    try {
      return option.description();
    }
 catch (    IncompleteAnnotationException ex) {
      throw new OptionValidationException(String.format("No description set on option '%s' at for class '%s'.",optionName,declaringClass.getName()));
    }
  }
  protected Object invokeMethod(  Object object,  Method method,  Object... parameterValues){
    final JavaMethod<Object,Object> javaMethod=JavaReflectionUtil.method(Object.class,method);
    return javaMethod.invoke(object,parameterValues);
  }
  public String getOptionName(){
    return optionName;
  }
  public String getDescription(){
    return description;
  }
  protected NotationParser<CharSequence,?> getNotationParser(){
    return notationParser;
  }
  protected static <T>NotationParser<CharSequence,T> createNotationParserOrFail(  OptionValueNotationParserFactory optionValueNotationParserFactory,  String optionName,  Class<T> optionType,  Class<?> declaringClass){
    try {
      return optionValueNotationParserFactory.toComposite(optionType);
    }
 catch (    OptionValidationException ex) {
      throw new OptionValidationException(String.format("Option '%s' cannot be casted to type '%s' in class '%s'.",optionName,optionType.getName(),declaringClass.getName()));
    }
  }
  protected static Class<?> calculateOptionType(  Class<?> type){
    if (type == Boolean.class || type == Boolean.TYPE) {
      return Void.TYPE;
    }
 else {
      return type;
    }
  }
}
