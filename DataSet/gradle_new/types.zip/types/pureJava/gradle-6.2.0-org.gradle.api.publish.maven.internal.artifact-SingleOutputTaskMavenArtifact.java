public class SingleOutputTaskMavenArtifact extends AbstractMavenArtifact {
  private final TaskProvider<? extends Task> generator;
  private final String extension;
  private final String classifier;
  private final TaskDependencyInternal buildDependencies;
  public SingleOutputTaskMavenArtifact(  TaskProvider<? extends Task> generator,  String extension,  String classifier){
    this.generator=generator;
    this.extension=extension;
    this.classifier=classifier;
    this.buildDependencies=new GeneratorTaskDependency();
  }
  @Override public File getFile(){
    return generator.get().getOutputs().getFiles().getSingleFile();
  }
  @Override protected String getDefaultExtension(){
    return extension;
  }
  @Override protected String getDefaultClassifier(){
    return classifier;
  }
  @Override protected TaskDependencyInternal getDefaultBuildDependencies(){
    return buildDependencies;
  }
  public boolean isEnabled(){
    return generator.get().getEnabled();
  }
private class GeneratorTaskDependency extends AbstractTaskDependency {
    @Override public void visitDependencies(    TaskDependencyResolveContext context){
      context.add(generator.get());
    }
  }
  @Override public boolean shouldBePublished(){
    return isEnabled();
  }
}
