private static class CompositeProjectPathConverter implements NotationConverter<String,ProjectComponentSelector> {
  private final IncludedBuildState build;
  private CompositeProjectPathConverter(  IncludedBuildState build){
    this.build=build;
  }
  @Override public void describe(  DiagnosticsVisitor visitor){
    visitor.example("Project paths, e.g. ':api'.");
  }
  @Override public void convert(  String notation,  NotationConvertResult<? super ProjectComponentSelector> result) throws TypeConversionException {
    result.converted(DefaultProjectComponentSelector.newSelector(identifierForProject(build,notation)));
  }
  static ProjectComponentIdentifier identifierForProject(  IncludedBuildState build,  String notation){
    return build.getIdentifierForProject(Path.path(notation));
  }
}
