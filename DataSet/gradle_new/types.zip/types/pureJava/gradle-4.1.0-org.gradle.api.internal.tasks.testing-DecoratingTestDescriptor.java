public class DecoratingTestDescriptor implements TestDescriptorInternal {
  private final TestDescriptorInternal descriptor;
  private final TestDescriptorInternal parent;
  public DecoratingTestDescriptor(  TestDescriptorInternal descriptor,  TestDescriptorInternal parent){
    this.descriptor=descriptor;
    this.parent=parent;
  }
  @Override public String toString(){
    return descriptor.toString();
  }
  public TestDescriptorInternal getDescriptor(){
    return descriptor;
  }
  @Override public TestDescriptorInternal getParent(){
    return parent;
  }
  @Override public Object getId(){
    return descriptor.getId();
  }
  @Nullable @Override public Object getOwnerBuildOperationId(){
    return descriptor.getOwnerBuildOperationId();
  }
  @Override public String getClassName(){
    return descriptor.getClassName();
  }
  @Override public String getName(){
    return descriptor.getName();
  }
  @Override public boolean isComposite(){
    return descriptor.isComposite();
  }
}
