class WindowsSymlink implements Symlink {
  @Override public boolean isSymlinkSupported(){
    return false;
  }
  @Override public void symlink(  File link,  File target) throws IOException {
    throw new IOException("Creation of symlinks is not supported on this platform.");
  }
  @Override public boolean isSymlink(  File suspect){
    return false;
  }
}
