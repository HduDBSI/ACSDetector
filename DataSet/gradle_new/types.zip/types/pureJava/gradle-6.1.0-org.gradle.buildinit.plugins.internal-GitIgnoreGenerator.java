public class GitIgnoreGenerator implements BuildContentGenerator {
  private final FileResolver fileResolver;
  public GitIgnoreGenerator(  FileResolver fileResolver){
    this.fileResolver=fileResolver;
  }
  @Override public void generate(  InitSettings settings){
    File file=fileResolver.resolve(".gitignore");
    Set<String> gitignoresToAppend=getGitignoresToAppend(file);
    if (!gitignoresToAppend.isEmpty()) {
      boolean shouldAppendNewLine=file.exists();
      try (PrintWriter writer=new PrintWriter(new FileWriter(file,true))){
        if (shouldAppendNewLine) {
          writer.println();
        }
        Spliterator<String> it=gitignoresToAppend.spliterator();
        if (it.tryAdvance(e -> withComment(e).forEach(writer::println))) {
          StreamSupport.stream(it,false).forEach(e -> withSeparator(withComment(e)).forEach(writer::println));
        }
      }
 catch (      IOException e) {
        throw new UncheckedIOException(e);
      }
    }
  }
  private static Set<String> getGitignoresToAppend(  File gitignoreFile){
    Set<String> result=Sets.newLinkedHashSet(Arrays.asList(".gradle","build"));
    if (gitignoreFile.exists()) {
      try (BufferedReader reader=new BufferedReader(new FileReader(gitignoreFile))){
        result.removeAll(reader.lines().filter(it -> result.contains(it)).collect(Collectors.toSet()));
      }
 catch (      IOException e) {
        throw new UncheckedIOException(e);
      }
    }
    return result;
  }
  private static List<String> withComment(  String entry){
    List<String> result=Lists.newArrayList();
    if (entry.startsWith(".gradle")) {
      result.add("# Ignore Gradle project-specific cache directory");
    }
 else     if (entry.startsWith("build")) {
      result.add("# Ignore Gradle build output directory");
    }
    result.add(entry);
    return result;
  }
  private static List<String> withSeparator(  List<String> entry){
    List<String> result=Lists.newArrayList("");
    result.addAll(entry);
    return result;
  }
}
