/** 
 * A configuration to be applied to a Gradle model object.
 */
private static class ConfigSpec {
  /** 
 * Selects the model object to be configured.
 */
  final ConfigSelector selector;
  /** 
 * The configuration expression to be applied to the selected model object.
 */
  final ConfigExpression expression;
  ConfigSpec(  ConfigSelector selector,  ConfigExpression expression){
    this.selector=selector;
    this.expression=expression;
  }
}
