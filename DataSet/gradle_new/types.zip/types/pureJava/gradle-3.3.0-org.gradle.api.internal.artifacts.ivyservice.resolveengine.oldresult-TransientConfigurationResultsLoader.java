public class TransientConfigurationResultsLoader {
  private final TransientConfigurationResultsBuilder transientConfigurationResultsBuilder;
  private final ResolvedGraphResults graphResults;
  public TransientConfigurationResultsLoader(  TransientConfigurationResultsBuilder transientConfigurationResultsBuilder,  ResolvedGraphResults graphResults){
    this.transientConfigurationResultsBuilder=transientConfigurationResultsBuilder;
    this.graphResults=graphResults;
  }
  /** 
 * Creates the result given the selected artifacts.
 */
  public TransientConfigurationResults create(  SelectedArtifactResults artifactResults){
    return transientConfigurationResultsBuilder.load(graphResults,artifactResults);
  }
}
