public class DefaultWorkerExecutor implements WorkerExecutor {
  private final ListeningExecutorService executor;
  private final WorkerFactory daemonWorkerFactory;
  private final WorkerFactory isolatedClassloaderWorkerFactory;
  private final WorkerFactory noIsolationWorkerFactory;
  private final FileResolver fileResolver;
  private final WorkerLeaseRegistry workerLeaseRegistry;
  private final BuildOperationExecutor buildOperationExecutor;
  private final AsyncWorkTracker asyncWorkTracker;
  public DefaultWorkerExecutor(  WorkerFactory daemonWorkerFactory,  WorkerFactory isolatedClassloaderWorkerFactory,  WorkerFactory noIsolationWorkerFactory,  FileResolver fileResolver,  ExecutorFactory executorFactory,  WorkerLeaseRegistry workerLeaseRegistry,  BuildOperationExecutor buildOperationExecutor,  AsyncWorkTracker asyncWorkTracker){
    this.daemonWorkerFactory=daemonWorkerFactory;
    this.isolatedClassloaderWorkerFactory=isolatedClassloaderWorkerFactory;
    this.noIsolationWorkerFactory=noIsolationWorkerFactory;
    this.fileResolver=fileResolver;
    this.executor=MoreExecutors.listeningDecorator(executorFactory.create("Worker Daemon Execution"));
    this.workerLeaseRegistry=workerLeaseRegistry;
    this.buildOperationExecutor=buildOperationExecutor;
    this.asyncWorkTracker=asyncWorkTracker;
  }
  @Override public void submit(  Class<? extends Runnable> actionClass,  Action<? super WorkerConfiguration> configAction){
    WorkerConfiguration configuration=new DefaultWorkerConfiguration(fileResolver);
    configAction.execute(configuration);
    String description=configuration.getDisplayName() != null ? configuration.getDisplayName() : actionClass.getName();
    ActionExecutionSpec spec;
    try {
      spec=new ActionExecutionSpec(actionClass,description,configuration.getParams());
    }
 catch (    Throwable t) {
      throw new WorkExecutionException(description,t);
    }
    submit(spec,configuration.getForkOptions().getWorkingDir(),configuration.getIsolationMode(),getDaemonForkOptions(actionClass,configuration));
  }
  private void submit(  final ActionExecutionSpec spec,  final File workingDir,  final IsolationMode isolationMode,  final DaemonForkOptions daemonForkOptions){
    final WorkerLease currentWorkerWorkerLease=workerLeaseRegistry.getCurrentWorkerLease();
    final BuildOperationState currentBuildOperation=buildOperationExecutor.getCurrentOperation();
    ListenableFuture<DefaultWorkResult> workerDaemonResult=executor.submit(new Callable<DefaultWorkResult>(){
      @Override public DefaultWorkResult call() throws Exception {
        try {
          WorkerFactory workerFactory=getWorkerFactory(isolationMode);
          Worker<ActionExecutionSpec> worker=workerFactory.getWorker(WorkerDaemonServer.class,workingDir,daemonForkOptions);
          return worker.execute(spec,currentWorkerWorkerLease,currentBuildOperation);
        }
 catch (        Throwable t) {
          throw new WorkExecutionException(spec.getDisplayName(),t);
        }
      }
    }
);
    registerAsyncWork(spec.getDisplayName(),workerDaemonResult);
  }
  private WorkerFactory getWorkerFactory(  IsolationMode isolationMode){
switch (isolationMode) {
case AUTO:
case CLASSLOADER:
      return isolatedClassloaderWorkerFactory;
case NONE:
    return noIsolationWorkerFactory;
case PROCESS:
  return daemonWorkerFactory;
default :
throw new IllegalArgumentException("Unknown isolation mode: " + isolationMode);
}
}
void registerAsyncWork(final String description,final Future<DefaultWorkResult> workItem){
asyncWorkTracker.registerWork(buildOperationExecutor.getCurrentOperation(),new AsyncWorkCompletion(){
@Override public void waitForCompletion(){
try {
  DefaultWorkResult result=workItem.get();
  if (!result.isSuccess()) {
    throw new WorkExecutionException(description,result.getException());
  }
}
 catch (InterruptedException e) {
  throw UncheckedException.throwAsUncheckedException(e);
}
catch (ExecutionException e) {
  throw UncheckedException.throwAsUncheckedException(e);
}
}
@Override public boolean isComplete(){
return workItem.isDone();
}
}
);
}
@Override public void await() throws WorkerExecutionException {
BuildOperationState currentOperation=buildOperationExecutor.getCurrentOperation();
try {
asyncWorkTracker.waitForCompletion(currentOperation);
}
 catch (DefaultMultiCauseException e) {
throw workerExecutionException(e.getCauses());
}
}
private WorkerExecutionException workerExecutionException(List<? extends Throwable> failures){
if (failures.size() == 1) {
throw new WorkerExecutionException("There was a failure while executing work items",failures);
}
 else {
throw new WorkerExecutionException("There were multiple failures while executing work items",failures);
}
}
DaemonForkOptions getDaemonForkOptions(Class<?> actionClass,WorkerConfiguration configuration){
validateWorkerConfiguration(configuration);
Iterable<Class<?>> paramTypes=CollectionUtils.collect(configuration.getParams(),new Transformer<Class<?>,Object>(){
@Override public Class<?> transform(Object o){
return o.getClass();
}
}
);
return toDaemonOptions(actionClass,paramTypes,configuration.getForkOptions(),configuration.getClasspath());
}
private void validateWorkerConfiguration(WorkerConfiguration configuration){
if (configuration.getIsolationMode() == IsolationMode.NONE) {
if (configuration.getClasspath().iterator().hasNext()) {
throw unsupportedWorkerConfigurationException("classpath",configuration.getIsolationMode());
}
}
if (configuration.getIsolationMode() == IsolationMode.NONE || configuration.getIsolationMode() == IsolationMode.CLASSLOADER) {
if (!configuration.getForkOptions().getBootstrapClasspath().isEmpty()) {
throw unsupportedWorkerConfigurationException("bootstrap classpath",configuration.getIsolationMode());
}
if (!configuration.getForkOptions().getJvmArgs().isEmpty()) {
throw unsupportedWorkerConfigurationException("jvm arguments",configuration.getIsolationMode());
}
if (configuration.getForkOptions().getMaxHeapSize() != null) {
throw unsupportedWorkerConfigurationException("maximum heap size",configuration.getIsolationMode());
}
if (configuration.getForkOptions().getMinHeapSize() != null) {
throw unsupportedWorkerConfigurationException("minimum heap size",configuration.getIsolationMode());
}
if (!configuration.getForkOptions().getSystemProperties().isEmpty()) {
throw unsupportedWorkerConfigurationException("system properties",configuration.getIsolationMode());
}
}
}
private RuntimeException unsupportedWorkerConfigurationException(String propertyDescription,IsolationMode isolationMode){
return new UnsupportedOperationException("The worker " + propertyDescription + " cannot be set when using isolation mode "+ isolationMode.name());
}
private DaemonForkOptions toDaemonOptions(Class<?> actionClass,Iterable<Class<?>> paramClasses,JavaForkOptions forkOptions,Iterable<File> classpath){
ImmutableSet.Builder<File> classpathBuilder=ImmutableSet.builder();
ImmutableSet.Builder<String> sharedPackagesBuilder=ImmutableSet.builder();
sharedPackagesBuilder.add("javax.inject");
if (classpath != null) {
classpathBuilder.addAll(classpath);
}
addVisibilityFor(actionClass,classpathBuilder,sharedPackagesBuilder,true);
for (Class<?> paramClass : paramClasses) {
addVisibilityFor(paramClass,classpathBuilder,sharedPackagesBuilder,false);
}
Iterable<File> daemonClasspath=classpathBuilder.build();
Iterable<String> daemonSharedPackages=sharedPackagesBuilder.build();
return new DaemonForkOptions(forkOptions.getMinHeapSize(),forkOptions.getMaxHeapSize(),forkOptions.getAllJvmArgs(),daemonClasspath,daemonSharedPackages);
}
private static void addVisibilityFor(Class<?> visibleClass,ImmutableSet.Builder<File> classpathBuilder,ImmutableSet.Builder<String> sharedPackagesBuilder,boolean addToSharedPackages){
if (visibleClass.getClassLoader() != null) {
classpathBuilder.addAll(ClasspathUtil.getClasspath(visibleClass.getClassLoader()).getAsFiles());
}
if (addToSharedPackages) {
addVisiblePackage(visibleClass,sharedPackagesBuilder);
}
}
private static void addVisiblePackage(Class<?> visibleClass,ImmutableSet.Builder<String> sharedPackagesBuilder){
if (visibleClass.getPackage() == null || "".equals(visibleClass.getPackage().getName())) {
sharedPackagesBuilder.add(FilteringClassLoader.DEFAULT_PACKAGE);
}
 else {
sharedPackagesBuilder.add(visibleClass.getPackage().getName());
}
}
@Contextual private static class WorkExecutionException extends RuntimeException {
WorkExecutionException(String description,Throwable cause){
super("A failure occurred while executing " + description,cause);
}
}
}
