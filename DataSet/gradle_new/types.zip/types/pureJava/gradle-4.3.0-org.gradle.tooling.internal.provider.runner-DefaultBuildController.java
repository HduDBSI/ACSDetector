class DefaultBuildController implements InternalBuildController {
  private final GradleInternal gradle;
  public DefaultBuildController(  GradleInternal gradle){
    this.gradle=gradle;
  }
  public BuildResult<?> getBuildModel() throws BuildExceptionVersion1 {
    return new ProviderBuildResult<Object>(gradle);
  }
  public BuildResult<?> getModel(  Object target,  ModelIdentifier modelIdentifier) throws BuildExceptionVersion1, InternalUnsupportedModelException {
    BuildCancellationToken cancellationToken=gradle.getServices().get(BuildCancellationToken.class);
    if (cancellationToken.isCancellationRequested()) {
      throw new BuildCancelledException(String.format("Could not build '%s' model. Build cancelled.",modelIdentifier.getName()));
    }
    ProjectInternal project=getTargetProject(target);
    ToolingModelBuilder builder=getToolingModelBuilder(project,modelIdentifier);
    Object model=builder.buildAll(modelIdentifier.getName(),project);
    return new ProviderBuildResult<Object>(model);
  }
  private ProjectInternal getTargetProject(  Object target){
    ProjectInternal project;
    if (target == null) {
      project=gradle.getDefaultProject();
    }
 else     if (target instanceof GradleProjectIdentity) {
      GradleProjectIdentity projectIdentity=(GradleProjectIdentity)target;
      GradleInternal build=findBuild(projectIdentity);
      project=findProject(build,projectIdentity);
    }
 else     if (target instanceof GradleBuildIdentity) {
      GradleBuildIdentity buildIdentity=(GradleBuildIdentity)target;
      project=findBuild(buildIdentity).getDefaultProject();
    }
 else {
      throw new IllegalArgumentException("Don't know how to build models for " + target);
    }
    return project;
  }
  private GradleInternal findBuild(  GradleBuildIdentity buildIdentity){
    GradleInternal build=findBuild(gradle,buildIdentity);
    if (build != null) {
      return build;
    }
 else {
      throw new IllegalArgumentException(buildIdentity.getRootDir() + " is not included in this build");
    }
  }
  private GradleInternal findBuild(  GradleInternal rootBuild,  GradleBuildIdentity buildIdentity){
    if (rootBuild.getRootProject().getProjectDir().equals(buildIdentity.getRootDir())) {
      return rootBuild;
    }
    for (    IncludedBuild includedBuild : rootBuild.getIncludedBuilds()) {
      GradleInternal matchingBuild=findBuild(((IncludedBuildInternal)includedBuild).getConfiguredBuild(),buildIdentity);
      if (matchingBuild != null) {
        return matchingBuild;
      }
    }
    return null;
  }
  private ProjectInternal findProject(  GradleInternal build,  GradleProjectIdentity projectIdentity){
    return build.getRootProject().project(projectIdentity.getProjectPath());
  }
  private ToolingModelBuilder getToolingModelBuilder(  ProjectInternal project,  ModelIdentifier modelIdentifier){
    ToolingModelBuilderRegistry modelBuilderRegistry=project.getServices().get(ToolingModelBuilderRegistry.class);
    ToolingModelBuilder builder;
    try {
      builder=modelBuilderRegistry.getBuilder(modelIdentifier.getName());
    }
 catch (    UnknownModelException e) {
      throw (InternalUnsupportedModelException)(new InternalUnsupportedModelException()).initCause(e);
    }
    return builder;
  }
}
