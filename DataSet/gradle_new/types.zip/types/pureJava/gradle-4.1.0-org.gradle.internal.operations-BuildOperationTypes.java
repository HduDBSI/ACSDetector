public final class BuildOperationTypes {
  private BuildOperationTypes(){
  }
  public static <D,R,T extends BuildOperationType<D,R>>Class<D> detailsType(  Class<T> type){
    return uncheckedCast(extract(type,0));
  }
  public static <D,R,T extends BuildOperationType<D,R>>Class<R> resultType(  Class<T> type){
    return uncheckedCast(extract(type,1));
  }
  private static <T extends BuildOperationType<?,?>>Class<?> extract(  Class<T> type,  int index){
    assert BuildOperationType.class.isAssignableFrom(type) : type.getName() + " is not a " + BuildOperationType.class.getName();
    for (    Type superType : type.getGenericInterfaces()) {
      if (superType instanceof ParameterizedType && ((ParameterizedType)superType).getRawType().equals(BuildOperationType.class)) {
        ParameterizedType parameterizedSuperType=(ParameterizedType)superType;
        Type typeParameter=parameterizedSuperType.getActualTypeArguments()[index];
        assert typeParameter instanceof Class;
        return (Class<?>)typeParameter;
      }
    }
    throw new IllegalStateException("Failed to extract type from " + type);
  }
}
