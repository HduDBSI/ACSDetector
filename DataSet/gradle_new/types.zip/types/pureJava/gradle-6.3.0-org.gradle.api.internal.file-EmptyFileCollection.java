private static final class EmptyFileCollection extends AbstractFileCollection {
  private final String displayName;
  public EmptyFileCollection(  String displayName){
    this.displayName=displayName;
  }
  @Override public String getDisplayName(){
    return displayName;
  }
  @Override public Set<File> getFiles(){
    return ImmutableSet.of();
  }
  @Override public void visitStructure(  FileCollectionStructureVisitor visitor){
  }
  @Override public FileTree getAsFileTree(){
    return new EmptyFileTree();
  }
}
