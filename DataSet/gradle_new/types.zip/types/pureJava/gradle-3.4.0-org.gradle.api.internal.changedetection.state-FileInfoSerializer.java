private static class FileInfoSerializer extends AbstractSerializer<FileInfo> {
  private final HashCodeSerializer hashCodeSerializer=new HashCodeSerializer();
  public FileInfo read(  Decoder decoder) throws Exception {
    HashCode hash=hashCodeSerializer.read(decoder);
    long timestamp=decoder.readLong();
    long length=decoder.readLong();
    return new FileInfo(hash,length,timestamp);
  }
  public void write(  Encoder encoder,  FileInfo value) throws Exception {
    hashCodeSerializer.write(encoder,value.hash);
    encoder.writeLong(value.timestamp);
    encoder.writeLong(value.length);
  }
  @Override public boolean equals(  Object obj){
    if (!super.equals(obj)) {
      return false;
    }
    FileInfoSerializer rhs=(FileInfoSerializer)obj;
    return Objects.equal(hashCodeSerializer,rhs.hashCodeSerializer);
  }
  @Override public int hashCode(){
    return Objects.hashCode(super.hashCode(),hashCodeSerializer);
  }
}
