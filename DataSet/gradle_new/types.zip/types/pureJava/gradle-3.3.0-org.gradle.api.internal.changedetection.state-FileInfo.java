@VisibleForTesting static class FileInfo {
  private final HashCode hash;
  private final long timestamp;
  private final long length;
  public FileInfo(  HashCode hash,  long length,  long timestamp){
    this.hash=hash;
    this.length=length;
    this.timestamp=timestamp;
  }
  public HashCode getHash(){
    return hash;
  }
}
