public class DefaultBuildOperationLoggerFactory implements BuildOperationLoggerFactory {
  private static final int MAX_FAILURES=10;
  private final Logger logger;
  DefaultBuildOperationLoggerFactory(  Logger logger){
    this.logger=logger;
  }
  public DefaultBuildOperationLoggerFactory(){
    this(Logging.getLogger(DefaultBuildOperationLoggerFactory.class));
  }
  @Override public BuildOperationLogger newOperationLogger(  String taskName,  File outputDir){
    final File outputFile=createOutputFile(outputDir);
    final BuildOperationLogInfo configuration=createLogInfo(taskName,outputFile,MAX_FAILURES);
    return new DefaultBuildOperationLogger(configuration,logger,outputFile);
  }
  protected File createOutputFile(  File outputDir){
    GFileUtils.mkdirs(outputDir);
    return new File(outputDir,"output.txt");
  }
  protected BuildOperationLogInfo createLogInfo(  String taskName,  File outputFile,  int maximumFailures){
    final BuildOperationLogInfo configuration;
    if (logger.isDebugEnabled()) {
      configuration=new BuildOperationLogInfo(taskName,outputFile,Integer.MAX_VALUE);
    }
 else {
      configuration=new BuildOperationLogInfo(taskName,outputFile,maximumFailures);
    }
    return configuration;
  }
}
