public class S3ResourceConnector implements ExternalResourceConnector {
  private static final Logger LOGGER=LoggerFactory.getLogger(S3ResourceConnector.class);
  private final S3Client s3Client;
  public S3ResourceConnector(  S3Client s3Client){
    this.s3Client=s3Client;
  }
  @Override public List<String> list(  URI parent){
    LOGGER.debug("Listing parent resources: {}",parent);
    return s3Client.listDirectChildren(parent);
  }
  @Override public ExternalResourceReadResponse openResource(  URI location,  boolean revalidate){
    LOGGER.debug("Attempting to get resource: {}",location);
    S3Object s3Object=s3Client.getResource(location);
    if (s3Object == null) {
      return null;
    }
    return new S3Resource(s3Object,location);
  }
  @Override public ExternalResourceMetaData getMetaData(  URI location,  boolean revalidate){
    LOGGER.debug("Attempting to get resource metadata: {}",location);
    S3Object s3Object=s3Client.getMetaData(location);
    if (s3Object == null) {
      return null;
    }
    try {
      ObjectMetadata objectMetadata=s3Object.getObjectMetadata();
      return new DefaultExternalResourceMetaData(location,objectMetadata.getLastModified().getTime(),objectMetadata.getContentLength(),objectMetadata.getContentType(),objectMetadata.getETag(),null);
    }
  finally {
      discardEmptyContentAndClose(s3Object);
    }
  }
  private static void discardEmptyContentAndClose(  S3Object s3Object){
    try {
      S3ObjectInputStream objectContent=s3Object.getObjectContent();
      if (objectContent == null) {
        return;
      }
      long downloadedContentLength=ByteStreams.exhaust(objectContent);
      if (downloadedContentLength > 1L) {
        LOGGER.debug("Downloaded {} bytes of the object content for metadata request which is too much.",downloadedContentLength);
      }
    }
 catch (    IOException e) {
      LOGGER.debug("Exception while consuming empty object content from metadata request",e);
    }
 finally {
      IoActions.closeQuietly(s3Object);
    }
  }
  @Override public void upload(  ReadableContent resource,  URI destination) throws IOException {
    LOGGER.debug("Attempting to upload stream to : {}",destination);
    InputStream inputStream=resource.open();
    try {
      s3Client.put(inputStream,resource.getContentLength(),destination);
    }
  finally {
      inputStream.close();
    }
  }
}
