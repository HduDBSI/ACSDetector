@Deprecated public class DefaultGroovySourceSet implements GroovySourceSet, HasPublicType {
  private final GroovySourceDirectorySet groovy;
  private final SourceDirectorySet allGroovy;
  public DefaultGroovySourceSet(  String name,  String displayName,  ObjectFactory objectFactory){
    this.groovy=createGroovySourceDirectorySet(name,displayName,objectFactory);
    allGroovy=objectFactory.sourceDirectorySet("all" + name,displayName + " Groovy source");
    allGroovy.source(groovy);
    allGroovy.getFilter().include("**/*.groovy");
  }
  private static GroovySourceDirectorySet createGroovySourceDirectorySet(  String name,  String displayName,  ObjectFactory objectFactory){
    GroovySourceDirectorySet groovySourceDirectorySet=new DefaultGroovySourceDirectorySet(objectFactory.sourceDirectorySet(name,displayName + " Groovy source"));
    groovySourceDirectorySet.getFilter().include("**/*.java","**/*.groovy");
    return groovySourceDirectorySet;
  }
  @Override public GroovySourceDirectorySet getGroovy(){
    return groovy;
  }
  @Override public GroovySourceSet groovy(  @Nullable Closure configureClosure){
    configure(configureClosure,getGroovy());
    return this;
  }
  @Override public GroovySourceSet groovy(  Action<? super SourceDirectorySet> configureAction){
    configureAction.execute(getGroovy());
    return this;
  }
  @Override public SourceDirectorySet getAllGroovy(){
    return allGroovy;
  }
  @Override public TypeOf<?> getPublicType(){
    return typeOf(GroovySourceSet.class);
  }
}
