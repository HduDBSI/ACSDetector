private class SourceIncludesSerializer implements Serializer<IncludeDirectives> {
  private final Serializer<Include> includeSerializer=new IncludeSerializer();
  private final ListSerializer<Include> includeListSerializer=new ListSerializer<Include>(includeSerializer);
  @Override public IncludeDirectives read(  Decoder decoder) throws Exception {
    return new DefaultIncludeDirectives(includeListSerializer.read(decoder));
  }
  @Override public void write(  Encoder encoder,  IncludeDirectives value) throws Exception {
    includeListSerializer.write(encoder,value.getIncludesAndImports());
  }
}
