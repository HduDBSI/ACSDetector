@NonNullApi public class DefaultTaskExecutionModeResolver implements TaskExecutionModeResolver {
  private final StartParameter startParameter;
  public DefaultTaskExecutionModeResolver(  StartParameter startParameter){
    this.startParameter=startParameter;
  }
  public TaskExecutionMode getExecutionMode(  TaskInternal task,  TaskProperties properties){
    AndSpec<? super TaskInternal> upToDateSpec=task.getOutputs().getUpToDateSpec();
    if (!properties.hasDeclaredOutputs() && upToDateSpec.isEmpty()) {
      if (task.hasTaskActions()) {
        return TaskExecutionMode.NO_OUTPUTS_WITH_ACTIONS;
      }
 else {
        return TaskExecutionMode.NO_OUTPUTS_WITHOUT_ACTIONS;
      }
    }
    if (startParameter.isRerunTasks()) {
      return TaskExecutionMode.RERUN_TASKS_ENABLED;
    }
    if (!upToDateSpec.isSatisfiedBy(task)) {
      return TaskExecutionMode.UP_TO_DATE_WHEN_FALSE;
    }
    return TaskExecutionMode.INCREMENTAL;
  }
}
