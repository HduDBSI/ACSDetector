public class DefaultVersionSelectorScheme implements VersionSelectorScheme {
  private final VersionComparator versionComparator;
  private final VersionParser versionParser;
  /** 
 * This constructor is here to maintain backwards compatibility with the nebula plugins and should be removed as soon as possible. See https://github.com/nebula-plugins/nebula-gradle-interop/issues/5
 */
  @Deprecated public DefaultVersionSelectorScheme(  VersionComparator versionComparator){
    this(versionComparator,new VersionParser());
  }
  public DefaultVersionSelectorScheme(  VersionComparator versionComparator,  VersionParser versionParser){
    this.versionComparator=versionComparator;
    this.versionParser=versionParser;
  }
  @Override public VersionSelector parseSelector(  String selectorString){
    if (VersionRangeSelector.ALL_RANGE.matcher(selectorString).matches()) {
      return maybeCreateRangeSelector(selectorString);
    }
    if (selectorString.endsWith("+")) {
      return new SubVersionSelector(selectorString);
    }
    if (selectorString.startsWith("latest.")) {
      return new LatestVersionSelector(selectorString);
    }
    return new ExactVersionSelector(selectorString);
  }
  private VersionSelector maybeCreateRangeSelector(  String selectorString){
    VersionRangeSelector rangeSelector=new VersionRangeSelector(selectorString,versionComparator.asVersionComparator(),versionParser);
    if (isSingleVersionRange(rangeSelector)) {
      return new ExactVersionSelector(rangeSelector.getUpperBound());
    }
    return rangeSelector;
  }
  private static boolean isSingleVersionRange(  VersionRangeSelector rangeSelector){
    String lowerBound=rangeSelector.getLowerBound();
    return lowerBound != null && lowerBound.equals(rangeSelector.getUpperBound()) && rangeSelector.isLowerInclusive() && rangeSelector.isUpperInclusive();
  }
  @Override public String renderSelector(  VersionSelector selector){
    return selector.getSelector();
  }
  @Override public VersionSelector complementForRejection(  VersionSelector selector){
    return new InverseVersionSelector(selector);
  }
}
