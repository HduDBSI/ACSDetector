public class PublishArtifactNotationParserFactory implements Factory<NotationParser<Object,ConfigurablePublishArtifact>> {
  private final Instantiator instantiator;
  private final DependencyMetaDataProvider metaDataProvider;
  private final TaskResolver taskResolver;
  private final FileResolver fileResolver;
  public PublishArtifactNotationParserFactory(  Instantiator instantiator,  DependencyMetaDataProvider metaDataProvider,  TaskResolver taskResolver,  FileResolver fileResolver){
    this.instantiator=instantiator;
    this.metaDataProvider=metaDataProvider;
    this.taskResolver=taskResolver;
    this.fileResolver=fileResolver;
  }
  @Override public NotationParser<Object,ConfigurablePublishArtifact> create(){
    FileNotationConverter fileConverter=new FileNotationConverter();
    return NotationParserBuilder.toType(ConfigurablePublishArtifact.class).converter(new DecoratingConverter()).converter(new ArchiveTaskNotationConverter()).converter(new FileProviderNotationConverter()).converter(new FileSystemLocationNotationConverter()).converter(fileConverter).converter(new FileMapNotationConverter(fileConverter)).toComposite();
  }
private class DecoratingConverter extends TypedNotationConverter<PublishArtifact,ConfigurablePublishArtifact> {
    private DecoratingConverter(){
      super(PublishArtifact.class);
    }
    @Override protected ConfigurablePublishArtifact parseType(    PublishArtifact notation){
      return instantiator.newInstance(DecoratingPublishArtifact.class,notation);
    }
  }
private class ArchiveTaskNotationConverter extends TypedNotationConverter<AbstractArchiveTask,ConfigurablePublishArtifact> {
    private ArchiveTaskNotationConverter(){
      super(AbstractArchiveTask.class);
    }
    @Override public void describe(    DiagnosticsVisitor visitor){
      visitor.candidate("Instances of AbstractArchiveTask").example("jar");
    }
    @Override protected ConfigurablePublishArtifact parseType(    AbstractArchiveTask notation){
      return instantiator.newInstance(ArchivePublishArtifact.class,notation);
    }
  }
private static class FileMapNotationConverter extends MapNotationConverter<ConfigurablePublishArtifact> {
    private final FileNotationConverter fileConverter;
    private FileMapNotationConverter(    FileNotationConverter fileConverter){
      this.fileConverter=fileConverter;
    }
    @Override public void describe(    DiagnosticsVisitor visitor){
      visitor.candidate("Maps with 'file' key");
    }
    protected PublishArtifact parseMap(    @MapKey("file") File file){
      return fileConverter.parseType(file);
    }
  }
private class FileProviderNotationConverter extends TypedNotationConverter<Provider<?>,ConfigurablePublishArtifact> {
    @SuppressWarnings("unchecked") FileProviderNotationConverter(){
      super((Class<Provider<?>>)(Class<?>)Provider.class);
    }
    @Override public void describe(    DiagnosticsVisitor visitor){
      visitor.candidate("Instances of Provider<RegularFile>.");
      visitor.candidate("Instances of Provider<Directory>.");
      visitor.candidate("Instances of Provider<File>.");
    }
    @Override protected ConfigurablePublishArtifact parseType(    Provider<?> notation){
      Module module=metaDataProvider.getModule();
      return instantiator.newInstance(DecoratingPublishArtifact.class,new LazyPublishArtifact(notation,module.getVersion(),fileResolver));
    }
  }
private class FileSystemLocationNotationConverter extends TypedNotationConverter<FileSystemLocation,ConfigurablePublishArtifact> {
    FileSystemLocationNotationConverter(){
      super(FileSystemLocation.class);
    }
    @Override public void describe(    DiagnosticsVisitor visitor){
      visitor.candidate("Instances of RegularFile.");
      visitor.candidate("Instances of Directory.");
    }
    @Override protected ConfigurablePublishArtifact parseType(    FileSystemLocation notation){
      Module module=metaDataProvider.getModule();
      return instantiator.newInstance(DecoratingPublishArtifact.class,new FileSystemPublishArtifact(notation,module.getVersion()));
    }
  }
private class FileNotationConverter extends TypedNotationConverter<File,ConfigurablePublishArtifact> {
    private FileNotationConverter(){
      super(File.class);
    }
    @Override protected ConfigurablePublishArtifact parseType(    File file){
      Module module=metaDataProvider.getModule();
      ArtifactFile artifactFile=new ArtifactFile(file,module.getVersion());
      return instantiator.newInstance(DefaultPublishArtifact.class,taskResolver,artifactFile.getName(),artifactFile.getExtension(),artifactFile.getExtension(),artifactFile.getClassifier(),null,file,new Task[0]);
    }
  }
}
