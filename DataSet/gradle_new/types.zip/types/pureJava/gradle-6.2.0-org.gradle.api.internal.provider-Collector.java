/** 
 * A supplier of zero or more values of type  {@link T}.
 */
public interface Collector<T> extends ValueSupplier {
  Value<Void> collectEntries(  ValueCollector<T> collector,  ImmutableCollection.Builder<T> dest);
  int size();
  void visit(  List<ProviderInternal<? extends Iterable<? extends T>>> sources);
}
