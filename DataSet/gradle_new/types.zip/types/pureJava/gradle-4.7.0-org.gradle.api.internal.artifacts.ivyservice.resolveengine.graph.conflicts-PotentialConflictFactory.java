class PotentialConflictFactory {
  private static final PotentialConflict NO_CONFLICT=new NoConflict();
  static PotentialConflict potentialConflict(  final ConflictContainer<ModuleIdentifier,? extends ComponentResolutionState>.Conflict conflict){
    if (conflict == null) {
      return NO_CONFLICT;
    }
    return new HasConflict(conflict.participants);
  }
  static PotentialConflict noConflict(){
    return NO_CONFLICT;
  }
private static class HasConflict implements PotentialConflict {
    private final Set<ModuleIdentifier> participants;
    private HasConflict(    Set<ModuleIdentifier> participants){
      this.participants=participants;
    }
    @Override public void withParticipatingModules(    Action<ModuleIdentifier> action){
      for (      ModuleIdentifier participant : participants) {
        action.execute(participant);
      }
    }
    @Override public boolean conflictExists(){
      return true;
    }
  }
private static class NoConflict implements PotentialConflict {
    @Override public void withParticipatingModules(    Action<ModuleIdentifier> action){
    }
    @Override public boolean conflictExists(){
      return false;
    }
  }
}
