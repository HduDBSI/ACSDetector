public class PreResolvedResolvableArtifact implements ResolvableArtifact, ResolvedArtifact {
  private final ModuleVersionIdentifier owner;
  private final IvyArtifactName artifact;
  private final ComponentArtifactIdentifier artifactId;
  private final CalculatedValue<File> fileSource;
  private final TaskDependencyContainer builtBy;
  private final CalculatedValueContainerFactory calculatedValueContainerFactory;
  public PreResolvedResolvableArtifact(  @Nullable ModuleVersionIdentifier owner,  IvyArtifactName artifact,  ComponentArtifactIdentifier artifactId,  CalculatedValue<File> fileSource,  TaskDependencyContainer builtBy,  CalculatedValueContainerFactory calculatedValueContainerFactory){
    this.owner=owner;
    this.artifact=artifact;
    this.artifactId=artifactId;
    this.fileSource=fileSource;
    this.builtBy=builtBy;
    this.calculatedValueContainerFactory=calculatedValueContainerFactory;
  }
  @Override public String toString(){
    return artifactId.getDisplayName();
  }
  @Override public int hashCode(){
    return artifactId.hashCode();
  }
  @Override public boolean equals(  Object obj){
    if (obj == this) {
      return true;
    }
    if (obj == null || obj.getClass() != getClass()) {
      return false;
    }
    PreResolvedResolvableArtifact other=(PreResolvedResolvableArtifact)obj;
    return other.artifactId.equals(artifactId);
  }
  @Override public ComponentArtifactIdentifier getId(){
    return artifactId;
  }
  @Override public CalculatedValue<File> getFileSource(){
    return fileSource;
  }
  @Override public File getFile(){
    fileSource.finalizeIfNotAlready();
    return fileSource.get();
  }
  @Override public ResolvedArtifact toPublicView(){
    return this;
  }
  @Override public void visitDependencies(  TaskDependencyResolveContext context){
    builtBy.visitDependencies(context);
  }
  @Override public boolean isResolveSynchronously(){
    return true;
  }
  @Override public ResolvedModuleVersion getModuleVersion(){
    if (owner == null) {
      throw new UnsupportedOperationException();
    }
    return new DefaultResolvedModuleVersion(owner);
  }
  @Override public ResolvableArtifact transformedTo(  File file){
    IvyArtifactName artifactName=DefaultIvyArtifactName.forFile(file,getClassifier());
    ComponentArtifactIdentifier newId=new ComponentFileArtifactIdentifier(artifactId.getComponentIdentifier(),artifactName);
    return new PreResolvedResolvableArtifact(owner,artifactName,newId,calculatedValueContainerFactory.create(Describables.of(newId),file),builtBy,calculatedValueContainerFactory);
  }
  @Override public String getName(){
    return artifact.getName();
  }
  @Override public String getType(){
    return artifact.getType();
  }
  @Override public String getExtension(){
    return artifact.getExtension();
  }
  @Nullable @Override public String getClassifier(){
    return artifact.getClassifier();
  }
}
