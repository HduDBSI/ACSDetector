static abstract class AbstractFileVar<T extends FileSystemLocation> extends DefaultProperty<T> implements FileSystemLocationProperty<T> {
  public AbstractFileVar(  Class<T> type){
    super(type);
  }
  @Override public void setFromAnyValue(  Object object){
    if (object instanceof File) {
      set((File)object);
    }
 else {
      super.setFromAnyValue(object);
    }
  }
  @Override public Provider<T> getLocationOnly(){
    return new AbstractReadOnlyProvider<T>(){
      @Nullable @Override public Class<T> getType(){
        return AbstractFileVar.this.getType();
      }
      @Nullable @Override public T getOrNull(){
        return AbstractFileVar.this.getOrNull();
      }
    }
;
  }
}
