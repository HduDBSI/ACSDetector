protected static class FileImpl implements ComponentVariant.File {
  private final String name;
  private final String uri;
  FileImpl(  String name,  String uri){
    this.name=name;
    this.uri=uri;
  }
  @Override public String getName(){
    return name;
  }
  @Override public String getUri(){
    return uri;
  }
  @Override public boolean equals(  Object o){
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    FileImpl file=(FileImpl)o;
    return Objects.equal(name,file.name) && Objects.equal(uri,file.uri);
  }
  @Override public int hashCode(){
    return Objects.hashCode(name,uri);
  }
}
