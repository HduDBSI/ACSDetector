/** 
 * Build listener that forwards all receiving events to the client via the provided  {@code ProgressEventConsumer} instance.
 * @since 2.5
 */
class ClientForwardingBuildOperationListener implements BuildOperationListener {
  private final ProgressEventConsumer eventConsumer;
  ClientForwardingBuildOperationListener(  ProgressEventConsumer eventConsumer){
    this.eventConsumer=eventConsumer;
  }
  @Override public void started(  BuildOperationDescriptor buildOperation,  OperationStartEvent startEvent){
    eventConsumer.started(new DefaultOperationStartedProgressEvent(startEvent.getStartTime(),toBuildOperationDescriptor(buildOperation)));
  }
  @Override public void progress(  OperationIdentifier buildOperationId,  OperationProgressEvent progressEvent){
  }
  @Override public void finished(  BuildOperationDescriptor buildOperation,  OperationFinishEvent result){
    eventConsumer.finished(new DefaultOperationFinishedProgressEvent(result.getEndTime(),toBuildOperationDescriptor(buildOperation),toOperationResult(result)));
  }
  private DefaultOperationDescriptor toBuildOperationDescriptor(  BuildOperationDescriptor buildOperation){
    Object id=buildOperation.getId();
    String name=buildOperation.getName();
    String displayName=buildOperation.getDisplayName();
    Object parentId=buildOperation.getParentId();
    return new DefaultOperationDescriptor(id,name,displayName,parentId);
  }
  static AbstractOperationResult toOperationResult(  OperationFinishEvent result){
    Throwable failure=result.getFailure();
    long startTime=result.getStartTime();
    long endTime=result.getEndTime();
    if (failure != null) {
      return new DefaultFailureResult(startTime,endTime,Collections.singletonList(DefaultFailure.fromThrowable(failure)));
    }
    return new DefaultSuccessResult(startTime,endTime);
  }
}
