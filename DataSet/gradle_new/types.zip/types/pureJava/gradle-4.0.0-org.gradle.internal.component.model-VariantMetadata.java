/** 
 * Metadata for a basic variant of a component, that defines only artifacts and no dependencies.
 */
public interface VariantMetadata {
  DisplayName asDescribable();
  AttributeContainerInternal getAttributes();
  Set<? extends ComponentArtifactMetadata> getArtifacts();
}
