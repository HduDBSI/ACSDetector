private static class MavenFieldValidator extends PublicationFieldValidator<MavenFieldValidator> {
  private MavenFieldValidator(  String publicationName,  String name,  String value){
    super(MavenFieldValidator.class,publicationName,name,value);
  }
  public MavenFieldValidator validMavenIdentifier(){
    notEmpty();
    if (!value.matches(ID_REGEX)) {
      throw failure(String.format("%s (%s) is not a valid Maven identifier (%s).",name,value,ID_REGEX));
    }
    return this;
  }
  public MavenFieldValidator matches(  String expectedValue){
    if (!value.equals(expectedValue)) {
      throw failure(String.format("supplied %s does not match POM file (cannot edit %1$s directly in the POM file).",name));
    }
    return this;
  }
  @Override protected InvalidMavenPublicationException failure(  String message){
    return new InvalidMavenPublicationException(publicationName,message);
  }
}
