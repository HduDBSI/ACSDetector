/** 
 * Compiles C++ source files into object files.
 */
@Incubating public class CppCompile extends AbstractNativeSourceCompileTask {
  @Override protected NativeCompileSpec createCompileSpec(){
    return new DefaultCppCompileSpec();
  }
}
