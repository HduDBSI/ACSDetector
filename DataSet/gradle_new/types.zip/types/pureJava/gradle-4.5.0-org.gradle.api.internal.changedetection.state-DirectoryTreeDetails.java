/** 
 * Represents the state of a directory tree.
 */
public class DirectoryTreeDetails implements FileTreeSnapshot {
  private final String path;
  private final Collection<FileSnapshot> descendants;
  public DirectoryTreeDetails(  String path,  Collection<FileSnapshot> descendants){
    this.path=path;
    this.descendants=descendants;
  }
  @Override public String getPath(){
    return path;
  }
  @Override public Collection<FileSnapshot> getDescendants(){
    return descendants;
  }
  @Override public String toString(){
    return path + " (" + descendants.size()+ " descendants)";
  }
}
