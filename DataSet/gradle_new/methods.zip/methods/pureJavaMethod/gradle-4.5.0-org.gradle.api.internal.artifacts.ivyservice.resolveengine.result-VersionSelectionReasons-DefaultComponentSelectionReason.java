private DefaultComponentSelectionReason(boolean forced,boolean conflictResolution,boolean selectedByRule,boolean expected,boolean compositeBuild,String description){
  this.forced=forced;
  this.conflictResolution=conflictResolution;
  this.selectedByRule=selectedByRule;
  this.expected=expected;
  this.compositeParticipant=compositeBuild;
  assert description != null;
  this.description=description;
}
