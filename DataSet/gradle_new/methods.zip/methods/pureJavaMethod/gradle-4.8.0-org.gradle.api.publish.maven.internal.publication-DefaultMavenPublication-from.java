public void from(SoftwareComponent component){
  if (this.component != null) {
    throw new InvalidUserDataException(String.format("Maven publication '%s' cannot include multiple components",name));
  }
  this.component=(SoftwareComponentInternal)component;
  artifactsOverridden=false;
  updateModuleDescriptorArtifact();
}
