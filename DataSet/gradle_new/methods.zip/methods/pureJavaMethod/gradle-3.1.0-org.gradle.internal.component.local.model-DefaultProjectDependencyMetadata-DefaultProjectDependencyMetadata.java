public DefaultProjectDependencyMetadata(ProjectComponentSelector selector,DependencyMetadata delegate){
  this.selector=selector;
  this.delegate=delegate;
}
