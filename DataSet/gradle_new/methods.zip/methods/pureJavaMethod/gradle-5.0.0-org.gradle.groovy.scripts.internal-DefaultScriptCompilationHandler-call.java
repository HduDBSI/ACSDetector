@Override public void call(SourceUnit source){
  if (!source.getAST().getMethods().isEmpty()) {
    hasMethods=true;
  }
  emptyScript=isEmpty(source);
}
