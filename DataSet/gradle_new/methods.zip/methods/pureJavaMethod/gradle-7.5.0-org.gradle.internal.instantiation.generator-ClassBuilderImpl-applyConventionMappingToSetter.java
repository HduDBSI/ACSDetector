@Override public void applyConventionMappingToSetter(PropertyMetadata property,Method setter){
  if (!conventionAware) {
    return;
  }
  addConventionSetter(setter,property);
}
