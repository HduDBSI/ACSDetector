@Override protected Value<? extends T> calculateOwnValue(ValueConsumer consumer){
  return Value.of(getInstance());
}
