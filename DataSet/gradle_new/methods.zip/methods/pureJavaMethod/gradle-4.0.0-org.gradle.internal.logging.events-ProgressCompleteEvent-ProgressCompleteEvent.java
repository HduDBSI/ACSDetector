public ProgressCompleteEvent(OperationIdentifier progressOperationId,long timestamp,String status){
  this.progressOperationId=progressOperationId;
  this.timestamp=timestamp;
  this.status=status;
}
