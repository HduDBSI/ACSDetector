private void generateGeneratedSubtypeMethods(){
  MethodVisitor methodVisitor=visitor.visitMethod(ACC_PUBLIC,"publicType",RETURN_CLASS,null,EMPTY_STRINGS);
  methodVisitor.visitLdcInsn(superclassType);
  methodVisitor.visitInsn(ARETURN);
  methodVisitor.visitMaxs(0,0);
  methodVisitor.visitEnd();
  methodVisitor=visitor.visitMethod(ACC_PUBLIC | ACC_STATIC,"generatedFrom",RETURN_CLASS,null,EMPTY_STRINGS);
  methodVisitor.visitLdcInsn(superclassType);
  methodVisitor.visitInsn(ARETURN);
  methodVisitor.visitMaxs(0,0);
  methodVisitor.visitEnd();
}
