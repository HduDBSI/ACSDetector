@VisibleForTesting public DirectoryFileTree(File dir,PatternSet patternSet,FileSystem fileSystem,boolean postfix){
  this.patternSet=patternSet;
  this.dir=dir;
  this.fileSystem=fileSystem;
  this.postfix=postfix;
}
