public void apply(final Project project){
  project.getPluginManager().apply(BasePlugin.class);
  EarPluginConvention earPluginConvention=objectFactory.newInstance(DefaultEarPluginConvention.class);
  project.getConvention().getPlugins().put("ear",earPluginConvention);
  earPluginConvention.setLibDirName(DEFAULT_LIB_DIR_NAME);
  earPluginConvention.setAppDirName("src/main/application");
  wireEarTaskConventions(project,earPluginConvention);
  configureConfigurations(project);
  PluginContainer plugins=project.getPlugins();
  setupEarTask(project,earPluginConvention);
  configureWithJavaPluginApplied(project,earPluginConvention,plugins);
  configureWithNoJavaPluginApplied(project,earPluginConvention);
}
