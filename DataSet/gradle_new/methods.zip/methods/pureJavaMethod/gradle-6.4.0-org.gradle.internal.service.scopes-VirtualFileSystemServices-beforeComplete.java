@Override public void beforeComplete(GradleInternal gradle){
  buildSessionsScopedVirtualFileSystem.invalidateAll();
}
