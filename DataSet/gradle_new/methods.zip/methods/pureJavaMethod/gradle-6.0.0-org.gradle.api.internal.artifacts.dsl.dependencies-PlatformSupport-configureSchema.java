public void configureSchema(AttributesSchema attributesSchema){
  configureCategoryDisambiguationRule(attributesSchema);
}
