public void attachActions(final TaskPropertyActionContext context){
  context.setValidationAction(new ValidationAction(){
    @Override public void validate(    String propertyName,    Object value,    Collection<String> messages){
      AbstractOutputPropertyAnnotationHandler.this.validate(propertyName,value,messages);
    }
  }
);
  context.setConfigureAction(new UpdateAction(){
    @Override public void update(    TaskInternal task,    final Callable<Object> futureValue){
      createPropertyBuilder(context,task,futureValue).withPropertyName(context.getName()).optional(context.isOptional());
      task.prependParallelSafeAction(new CreateOutputDirectoryTaskAction(context.getName(),futureValue));
    }
  }
);
}
