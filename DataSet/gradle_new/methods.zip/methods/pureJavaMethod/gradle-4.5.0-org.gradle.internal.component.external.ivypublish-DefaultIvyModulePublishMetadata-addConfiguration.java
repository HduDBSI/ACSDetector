@Override public void addConfiguration(String name,String description,Set<String> extendsFrom,Set<String> hierarchy,boolean visible,boolean transitive,ImmutableAttributes attributes,boolean canBeConsumed,boolean canBeResolved){
  List<String> sortedExtends=Lists.newArrayList(extendsFrom);
  Collections.sort(sortedExtends);
  Configuration configuration=new Configuration(name,transitive,visible,sortedExtends);
  configurations.put(name,configuration);
}
