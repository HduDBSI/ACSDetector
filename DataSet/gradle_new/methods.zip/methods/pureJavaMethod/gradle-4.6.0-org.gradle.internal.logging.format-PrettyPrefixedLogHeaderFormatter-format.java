@Override public List<StyledTextOutputEvent.Span> format(@Nullable String header,String description,@Nullable String shortDescription,@Nullable String status,boolean failed){
  final String message=header != null ? header : description;
  if (message != null) {
    final List<StyledTextOutputEvent.Span> result=Lists.newArrayList(header(message,failed),status(status,failed),eol());
    if (spaceBefore) {
      result.add(0,eol());
    }
    return result;
  }
 else {
    return Collections.emptyList();
  }
}
