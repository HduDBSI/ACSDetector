@Override public GradleLauncher newInstance(BuildDefinition buildDefinition,RootBuildState build,BuildTreeScopeServices parentRegistry){
  if (rootBuild != null) {
    throw new IllegalStateException("Cannot have a current root build");
  }
  DefaultGradleLauncher launcher=doNewInstance(buildDefinition,build,null,parentRegistry,ImmutableList.of(new Stoppable(){
    @Override public void stop(){
      rootBuild=null;
    }
  }
));
  rootBuild=launcher;
  final DefaultDeploymentRegistry deploymentRegistry=parentRegistry.get(DefaultDeploymentRegistry.class);
  launcher.getGradle().addBuildListener(new InternalBuildAdapter(){
    @Override public void buildFinished(    BuildResult result){
      deploymentRegistry.buildFinished(result);
    }
  }
);
  return launcher;
}
