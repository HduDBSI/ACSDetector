@Deprecated @Override public boolean addAll(Collection<? extends Task> c){
  DeprecationLogger.nagUserOfDiscontinuedMethodInvocation("TaskContainer.addAll()");
  return addAllInternal(c);
}
