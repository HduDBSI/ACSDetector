@TaskAction void buildReport(){
  List<Configuration> configurations=filterConfigurations();
  StyledTextOutput output=getTextOutputFactory().create(getClass());
  if (configurations.isEmpty()) {
    reportNoMatchingVariant(configurations,output);
  }
 else {
    Legend legend=new Legend();
    ProjectModuleFactory factory=getProjectModuleFactory();
    Module projectBackedModule=factory.getModule(getProject());
    configurations.forEach(cnf -> {
      reportVariant((ConfigurationInternal)cnf,projectBackedModule,output,legend);
    }
);
    legend.print(output);
  }
}
