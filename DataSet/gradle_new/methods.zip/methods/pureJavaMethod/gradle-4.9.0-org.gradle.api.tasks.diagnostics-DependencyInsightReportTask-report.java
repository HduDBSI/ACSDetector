@TaskAction public void report(){
  final Configuration configuration=getConfiguration();
  assertValidTaskConfiguration(configuration);
  StyledTextOutput output=getTextOutputFactory().create(getClass());
  ResolutionErrorRenderer errorHandler=new ResolutionErrorRenderer(dependencySpec);
  Set<DependencyResult> selectedDependencies=selectDependencies(configuration,errorHandler);
  if (selectedDependencies.isEmpty()) {
    output.println("No dependencies matching given input were found in " + String.valueOf(configuration));
    return;
  }
  errorHandler.renderErrors(output);
  renderSelectedDependencies(configuration,output,selectedDependencies);
  renderBuildScanHint(output);
}
