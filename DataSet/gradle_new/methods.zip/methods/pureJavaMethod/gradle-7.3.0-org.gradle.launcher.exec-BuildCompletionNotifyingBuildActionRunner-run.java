@Override public Result run(final BuildAction action,BuildTreeLifecycleController buildController){
  Result result;
  try {
    result=delegate.run(action,buildController);
  }
 catch (  Throwable t) {
    notifyEnterprisePluginManager(Result.failed(t));
    throw UncheckedException.throwAsUncheckedException(t);
  }
  notifyEnterprisePluginManager(result);
  return result;
}
