private static ImmutableSortedSet<String> getOutputPropertyNamesForCacheKey(TaskInternal task){
  ImmutableSortedSet<TaskOutputFilePropertySpec> fileProperties=task.getOutputs().getFileProperties();
  List<String> outputPropertyNames=Lists.newArrayListWithCapacity(fileProperties.size());
  for (  TaskOutputFilePropertySpec propertySpec : fileProperties) {
    if (propertySpec instanceof CacheableTaskOutputFilePropertySpec) {
      CacheableTaskOutputFilePropertySpec cacheablePropertySpec=(CacheableTaskOutputFilePropertySpec)propertySpec;
      if (cacheablePropertySpec.getOutputFile() != null) {
        outputPropertyNames.add(propertySpec.getPropertyName());
      }
    }
  }
  return ImmutableSortedSet.copyOf(outputPropertyNames);
}
