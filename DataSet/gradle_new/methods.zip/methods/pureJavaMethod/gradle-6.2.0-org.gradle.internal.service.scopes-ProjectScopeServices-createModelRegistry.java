protected ModelRegistry createModelRegistry(ModelRuleExtractor ruleExtractor){
  return new DefaultModelRegistry(ruleExtractor,project.getPath(),run -> {
    project.getMutationState().withMutableState(run);
  }
);
}
