private void transformDependencies(BuildableModuleComponentMetaDataResolveResult result){
  ModuleComponentResolveMetadata metadata=result.getMetaData();
  if (metadata instanceof IvyModuleResolveMetadata) {
    IvyModuleResolveMetadata transformedMetadata=((IvyModuleResolveMetadata)metadata).withDynamicConstraintVersions();
    result.setMetadata(transformedMetadata);
  }
}
