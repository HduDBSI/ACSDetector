private BasicGradleProject convert(Project project,Map<Project,BasicGradleProject> convertedProjects){
  DefaultProjectIdentifier id=new DefaultProjectIdentifier(project.getRootDir(),project.getPath());
  BasicGradleProject converted=new BasicGradleProject().setName(project.getName()).setProjectIdentifier(id);
  converted.setProjectDirectory(project.getProjectDir());
  if (project.getParent() != null) {
    converted.setParent(convertedProjects.get(project.getParent()));
  }
  convertedProjects.put(project,converted);
  for (  Project child : project.getChildProjects().values()) {
    converted.addChild(convert(child,convertedProjects));
  }
  return converted;
}
