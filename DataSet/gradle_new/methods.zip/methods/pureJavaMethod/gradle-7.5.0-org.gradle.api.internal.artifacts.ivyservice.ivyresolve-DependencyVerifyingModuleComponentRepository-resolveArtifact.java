@Override public void resolveArtifact(ComponentArtifactMetadata artifact,ModuleSources moduleSources,BuildableArtifactResolveResult result){
  delegate.resolveArtifact(artifact,moduleSources,result);
  if (result.hasResult() && result.isSuccessful()) {
    ComponentArtifactIdentifier id=artifact.getId();
    if (isExternalArtifactId(id) && isNotChanging(moduleSources)) {
      ModuleComponentArtifactIdentifier mcai=(ModuleComponentArtifactIdentifier)id;
      ArtifactVerificationOperation.ArtifactKind artifactKind=determineArtifactKind(artifact);
      if (!(result instanceof SignatureFileDefaultBuildableArtifactResolveResult)) {
        Factory<File> signatureFileFactory=() -> maybeFetchArtifactSignatureFile(moduleSources,mcai,artifact.getName());
        operation.onArtifact(artifactKind,mcai,result.getResult(),signatureFileFactory,getName(),getId());
      }
    }
  }
}
