@Override public void accept(ExecutingBuildOperation operation){
  operation.setResult(new SnapshotTaskInputsBuildOperationResult(cachingState));
}
