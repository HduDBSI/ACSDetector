private Set<File> gradleTestKitFileCollection(Collection<File> testKitClasspath){
  List<File> gradleApi=getClassPath(GRADLE_API);
  testKitClasspath.removeAll(gradleApi);
  ImmutableSet.Builder<File> builder=ImmutableSet.builder();
  builder.add(relocatedDepsJar(testKitClasspath,RuntimeShadedJarType.TEST_KIT));
  builder.addAll(gradleApiFileCollection(gradleApi));
  return builder.build();
}
