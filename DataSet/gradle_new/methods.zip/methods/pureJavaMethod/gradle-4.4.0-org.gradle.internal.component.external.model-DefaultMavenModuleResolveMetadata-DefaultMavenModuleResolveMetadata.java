private DefaultMavenModuleResolveMetadata(DefaultMavenModuleResolveMetadata metadata,ModuleSource source){
  super(metadata,source);
  packaging=metadata.packaging;
  relocated=metadata.relocated;
  snapshotTimestamp=metadata.snapshotTimestamp;
  variants=metadata.variants;
  graphVariants=metadata.graphVariants;
}
