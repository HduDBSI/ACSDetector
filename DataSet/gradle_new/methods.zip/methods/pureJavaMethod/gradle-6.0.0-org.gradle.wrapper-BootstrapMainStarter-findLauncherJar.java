static File findLauncherJar(File gradleHome){
  File libDirectory=new File(gradleHome,"lib");
  if (libDirectory.exists() && libDirectory.isDirectory()) {
    File[] launcherJars=libDirectory.listFiles(new FilenameFilter(){
      @Override public boolean accept(      File dir,      String name){
        return name.matches("gradle-launcher-.*\\.jar");
      }
    }
);
    if (launcherJars != null && launcherJars.length == 1) {
      return launcherJars[0];
    }
  }
  return null;
}
