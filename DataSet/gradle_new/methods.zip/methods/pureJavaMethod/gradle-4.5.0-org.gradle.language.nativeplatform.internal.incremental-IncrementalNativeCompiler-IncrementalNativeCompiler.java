public IncrementalNativeCompiler(TaskOutputsInternal outputs,Compiler<T> delegateCompiler,PersistentStateCache<CompilationState> compileStateCache,IncrementalCompilation incrementalCompilation){
  this.outputs=outputs;
  this.delegateCompiler=delegateCompiler;
  this.compileStateCache=compileStateCache;
  this.incrementalCompilation=incrementalCompilation;
}
