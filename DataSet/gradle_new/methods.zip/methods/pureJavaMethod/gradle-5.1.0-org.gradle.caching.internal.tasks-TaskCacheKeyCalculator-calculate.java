public TaskOutputCachingBuildCacheKey calculate(TaskInternal task,BeforeExecutionState execution,TaskProperties taskProperties){
  TaskOutputCachingBuildCacheKeyBuilder builder=new DefaultTaskOutputCachingBuildCacheKeyBuilder(task.getIdentityPath());
  if (buildCacheDebugLogging) {
    builder=new DebuggingTaskOutputCachingBuildCacheKeyBuilder(builder);
  }
  builder.appendTaskImplementation(execution.getImplementation());
  builder.appendTaskActionImplementations(execution.getAdditionalImplementations());
  SortedMap<String,ValueSnapshot> inputProperties=execution.getInputProperties();
  for (  Map.Entry<String,ValueSnapshot> entry : inputProperties.entrySet()) {
    Hasher newHasher=Hashing.newHasher();
    entry.getValue().appendToHasher(newHasher);
    if (newHasher.isValid()) {
      HashCode hash=newHasher.hash();
      builder.appendInputValuePropertyHash(entry.getKey(),hash);
    }
 else {
      builder.inputPropertyNotCacheable(entry.getKey(),newHasher.getInvalidReason());
    }
  }
  SortedMap<String,CurrentFileCollectionFingerprint> inputFingerprints=execution.getInputFileProperties();
  for (  Map.Entry<String,CurrentFileCollectionFingerprint> entry : inputFingerprints.entrySet()) {
    builder.appendInputFilesProperty(entry.getKey(),entry.getValue());
  }
  for (  TaskOutputFilePropertySpec propertySpec : taskProperties.getOutputFileProperties()) {
    if (!(propertySpec instanceof CacheableTaskOutputFilePropertySpec)) {
      continue;
    }
    if (((CacheableTaskOutputFilePropertySpec)propertySpec).getOutputFile() != null) {
      builder.appendOutputPropertyName(propertySpec.getPropertyName());
    }
  }
  return builder.build();
}
