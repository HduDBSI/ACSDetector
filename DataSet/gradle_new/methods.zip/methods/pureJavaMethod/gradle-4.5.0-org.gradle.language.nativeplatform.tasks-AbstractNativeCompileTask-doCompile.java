private <T extends NativeCompileSpec>WorkResult doCompile(T spec,PlatformToolProvider platformToolProvider){
  Class<T> specType=Cast.uncheckedCast(spec.getClass());
  Compiler<T> baseCompiler=platformToolProvider.newCompiler(specType);
  Compiler<T> incrementalCompiler=this.incrementalCompiler.createCompiler(baseCompiler);
  Compiler<T> loggingCompiler=BuildOperationLoggingCompilerDecorator.wrap(incrementalCompiler);
  return loggingCompiler.execute(spec);
}
