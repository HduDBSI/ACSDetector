@Override public Try<TransformationSubject> transform(TransformationSubject subjectToTransform,ExecutionGraphDependenciesResolver dependenciesResolver){
  if (LOGGER.isInfoEnabled()) {
    LOGGER.info("Transforming {} with {}",subjectToTransform.getDisplayName(),transformer.getDisplayName());
  }
  ImmutableList<File> primaryInputs=subjectToTransform.getFiles();
  return dependenciesResolver.forTransformer(transformer).flatMap(dependencies -> {
    ImmutableList.Builder<File> builder=ImmutableList.builder();
    for (    File primaryInput : primaryInputs) {
      Try<ImmutableList<File>> result=transformerInvoker.invoke(transformer,primaryInput,dependencies,subjectToTransform);
      if (result.getFailure().isPresent()) {
        return Try.failure(result.getFailure().get());
      }
      builder.addAll(result.get());
    }
    return Try.successful(subjectToTransform.createSubjectFromResult(builder.build()));
  }
);
}
