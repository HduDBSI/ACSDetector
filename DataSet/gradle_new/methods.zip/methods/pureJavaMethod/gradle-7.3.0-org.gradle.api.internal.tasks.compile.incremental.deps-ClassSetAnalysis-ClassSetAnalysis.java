public ClassSetAnalysis(ClassSetAnalysisData classAnalysis,AnnotationProcessingData annotationProcessingData,CompilerApiData compilerApiData){
  this.classAnalysis=classAnalysis;
  this.annotationProcessingData=annotationProcessingData;
  this.compilerApiData=compilerApiData;
}
