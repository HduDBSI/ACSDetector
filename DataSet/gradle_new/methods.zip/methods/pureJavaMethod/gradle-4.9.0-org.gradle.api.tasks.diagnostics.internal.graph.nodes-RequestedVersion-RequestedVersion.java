public RequestedVersion(ComponentSelector requested,ComponentIdentifier actual,boolean resolvable){
  this.requested=requested;
  this.actual=actual;
  this.resolvable=resolvable;
}
