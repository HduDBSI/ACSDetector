private void findImplementationClasspath(String name,Collection<File> implementationClasspath){
  Matcher matcher=Pattern.compile("gradle-(.+)").matcher(name);
  matcher.matches();
  String projectDirName=matcher.group(1);
  String projectName=toCamelCase(projectDirName);
  List<String> suffixesForProjectDir=getClasspathSuffixesForProjectDir(projectDirName);
  List<String> suffixesForProjectName=getClasspathSuffixesForProjectName(projectName);
  for (  File file : classpath) {
    if (file.isDirectory()) {
      String path=file.getAbsolutePath();
      if (path.endsWith(projectName) && !isLocatedInSubproject(file)) {
        for (        String suffix : suffixesForProjectName) {
          if (path.endsWith(suffix)) {
            implementationClasspath.add(file);
          }
        }
      }
 else {
        for (        String suffix : suffixesForProjectDir) {
          if (path.endsWith(suffix)) {
            implementationClasspath.add(file);
          }
        }
      }
    }
  }
}
