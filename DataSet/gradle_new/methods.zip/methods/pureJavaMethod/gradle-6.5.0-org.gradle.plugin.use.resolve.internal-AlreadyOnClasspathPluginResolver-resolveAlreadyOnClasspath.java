private void resolveAlreadyOnClasspath(PluginId pluginId,PluginResolutionResult result){
  PluginResolution pluginResolution=new ClassPathPluginResolution(pluginId,parentLoaderScope,pluginInspector);
  result.found("Already on classpath",pluginResolution);
}
