@Override public LocallyAvailableExternalResource create(){
  LocallyAvailableResource cachedResource=fileStore.moveIntoCache(destination);
  File fileInFileStore=cachedResource.getFile();
  cachedExternalResourceIndex.store(source.toString(),fileInFileStore,metaData);
  return fileResourceRepository.resource(fileInFileStore,source.getUri(),metaData);
}
