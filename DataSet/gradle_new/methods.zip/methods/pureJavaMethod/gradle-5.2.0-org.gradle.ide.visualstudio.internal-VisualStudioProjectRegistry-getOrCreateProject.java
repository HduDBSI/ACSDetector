private DefaultVisualStudioProject getOrCreateProject(String vsProjectName,String componentName){
  DefaultVisualStudioProject vsProject=findByName(vsProjectName);
  if (vsProject == null) {
    vsProject=createProject(vsProjectName,componentName);
  }
  return vsProject;
}
