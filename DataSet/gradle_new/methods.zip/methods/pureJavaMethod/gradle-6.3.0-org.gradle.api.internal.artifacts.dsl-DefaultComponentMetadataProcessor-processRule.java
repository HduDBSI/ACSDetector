private void processRule(SpecRuleAction<? super ComponentMetadataDetails> specRuleAction,ModuleComponentResolveMetadata metadata,final ComponentMetadataDetails details){
  if (!specRuleAction.getSpec().isSatisfiedBy(details)) {
    return;
  }
  final RuleAction<? super ComponentMetadataDetails> action=specRuleAction.getAction();
  if (!shouldExecute(action,metadata)) {
    return;
  }
  List<?> inputs=gatherAdditionalInputs(action,metadata);
  executeAction(action,inputs,details);
}
