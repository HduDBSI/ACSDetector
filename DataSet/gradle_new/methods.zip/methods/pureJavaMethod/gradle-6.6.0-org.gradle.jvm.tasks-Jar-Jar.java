public Jar(){
  getArchiveExtension().set(DEFAULT_EXTENSION);
  setMetadataCharset("UTF-8");
  manifest=new DefaultManifest(getFileResolver());
  metaInf=(CopySpecInternal)getRootSpec().addFirst().into("META-INF");
  metaInf.addChild().from(manifestFileTree());
  getMainSpec().appendCachingSafeCopyAction(new ExcludeManifestAction());
}
