public JUnitPlatformSpec(JUnitPlatformOptions options,Set<String> includedTests,Set<String> excludedTests,Set<String> includedTestsCommandLine){
  super(includedTests,excludedTests,includedTestsCommandLine);
  this.includeEngines=options.getIncludeEngines();
  this.excludeEngines=options.getExcludeEngines();
  this.includeTags=options.getIncludeTags();
  this.excludeTags=options.getExcludeTags();
}
