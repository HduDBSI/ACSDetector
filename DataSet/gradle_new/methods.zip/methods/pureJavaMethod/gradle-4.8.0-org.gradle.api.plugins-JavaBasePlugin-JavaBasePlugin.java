@Inject public JavaBasePlugin(Instantiator instantiator,ObjectFactory objectFactory){
  this.instantiator=instantiator;
  this.objectFactory=objectFactory;
}
