ModuleMetadataCacheEntry(byte type,boolean isChanging,long createTimestamp,BigInteger moduleDescriptorHash,ModuleSource moduleSource){
  this.type=type;
  this.isChanging=isChanging;
  this.createTimestamp=createTimestamp;
  this.moduleSource=moduleSource;
  this.moduleDescriptorHash=moduleDescriptorHash;
}
