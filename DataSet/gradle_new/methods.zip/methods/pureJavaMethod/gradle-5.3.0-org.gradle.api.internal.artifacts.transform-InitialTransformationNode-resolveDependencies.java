@Override public void resolveDependencies(TaskDependencyResolver dependencyResolver,Action<Node> processHardSuccessor){
  super.resolveDependencies(dependencyResolver,processHardSuccessor);
  processDependencies(processHardSuccessor,dependencyResolver.resolveDependenciesFor(null,artifact));
}
