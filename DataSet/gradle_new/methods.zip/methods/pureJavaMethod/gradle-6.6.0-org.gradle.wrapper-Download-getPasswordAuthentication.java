@Override protected PasswordAuthentication getPasswordAuthentication(){
  if (getRequestorType() == RequestorType.PROXY) {
    String protocol=getRequestingURL().getProtocol();
    String proxyUser=System.getProperty(protocol + ".proxyUser");
    if (proxyUser != null) {
      String proxyPassword=System.getProperty(protocol + ".proxyPassword","");
      return new PasswordAuthentication(proxyUser,proxyPassword.toCharArray());
    }
  }
  return super.getPasswordAuthentication();
}
