private ImmutableAttributes appendAttributes(ImmutableAttributes dependencyAttributes,SelectorState selectorState){
  try {
    ComponentSelector selector=selectorState.getDependencyMetadata().getSelector();
    ImmutableAttributes attributes=((AttributeContainerInternal)selector.getAttributes()).asImmutable();
    dependencyAttributes=attributesFactory.safeConcat(attributes,dependencyAttributes);
  }
 catch (  AttributeMergingException e) {
    attributeMergingError=e;
  }
  return dependencyAttributes;
}
