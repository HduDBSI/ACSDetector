public ProgressOperation start(String status,String category,OperationIdentifier operationId,@Nullable OperationIdentifier parentOperationId){
  ProgressOperation parent=null;
  if (parentOperationId != null) {
    parent=operationsById.get(parentOperationId);
  }
  ProgressOperation operation=new ProgressOperation(status,category,operationId,parent);
  if (parent != null) {
    parent.addChild(operation);
  }
  operationsById.put(operationId,operation);
  return operation;
}
