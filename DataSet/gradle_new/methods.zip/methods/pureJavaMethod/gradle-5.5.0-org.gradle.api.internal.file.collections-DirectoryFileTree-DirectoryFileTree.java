DirectoryFileTree(File dir,PatternSet patternSet,Factory<DirectoryWalker> directoryWalkerFactory,FileSystem fileSystem,boolean postfix){
  this.patternSet=patternSet;
  this.dir=dir;
  this.directoryWalkerFactory=directoryWalkerFactory;
  this.fileSystem=fileSystem;
  this.postfix=postfix;
}
