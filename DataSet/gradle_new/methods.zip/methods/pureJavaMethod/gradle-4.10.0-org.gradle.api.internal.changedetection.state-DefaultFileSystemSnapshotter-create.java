@Override public FileSystemSnapshot create(){
  PhysicalSnapshot snapshot=fileSystemMirror.getSnapshot(path);
  if (snapshot == null) {
    snapshot=snapshotAndCache(dirTree.getDir(),patterns);
    return snapshot.getType() == FileType.Missing ? FileSystemSnapshot.EMPTY : snapshot;
  }
 else {
    return filterSnapshot(snapshot,patterns);
  }
}
