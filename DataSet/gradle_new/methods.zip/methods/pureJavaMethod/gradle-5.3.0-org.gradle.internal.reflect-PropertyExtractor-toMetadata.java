PropertyMetadata toMetadata(){
  return new DefaultPropertyMetadata(fieldName,method,propertyType,ImmutableMap.copyOf(annotations));
}
