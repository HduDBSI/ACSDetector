@Override protected final void doAppend(String text){
  StateContext context=new StateContext(text);
  while (context.hasChar()) {
    currentState.execute(context);
  }
  seenCharsFromEol=context.seenCharsFromEol;
  context.flushLineText();
}
