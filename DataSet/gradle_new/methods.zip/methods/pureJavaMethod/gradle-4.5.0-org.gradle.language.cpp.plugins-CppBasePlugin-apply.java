@Override public void apply(final ProjectInternal project){
  project.getPluginManager().apply(NativeBasePlugin.class);
  project.getPluginManager().apply(StandardToolChainsPlugin.class);
  final TaskContainerInternal tasks=project.getTasks();
  final DirectoryProperty buildDirectory=project.getLayout().getBuildDirectory();
  project.getGradle().getExperimentalFeatures().enable();
  project.getComponents().withType(DefaultCppBinary.class,new Action<DefaultCppBinary>(){
    @Override public void execute(    final DefaultCppBinary binary){
      final Names names=binary.getNames();
      String language="cpp";
      final NativePlatform currentPlatform=binary.getTargetPlatform();
      final NativeToolChainInternal toolChain=binary.getToolChain();
      Callable<List<File>> systemIncludes=new Callable<List<File>>(){
        @Override public List<File> call(){
          PlatformToolProvider platformToolProvider=binary.getPlatformToolProvider();
          if (platformToolProvider instanceof SystemIncludesAwarePlatformToolProvider) {
            return ((SystemIncludesAwarePlatformToolProvider)platformToolProvider).getSystemIncludes(ToolType.CPP_COMPILER);
          }
          return ImmutableList.of();
        }
      }
;
      CppCompile compile=tasks.create(names.getCompileTaskName(language),CppCompile.class);
      compile.includes(binary.getCompileIncludePath());
      compile.includes(systemIncludes);
      compile.source(binary.getCppSource());
      if (binary.isDebuggable()) {
        compile.setDebuggable(true);
      }
      if (binary.isOptimized()) {
        compile.setOptimized(true);
      }
      compile.setTargetPlatform(currentPlatform);
      compile.setToolChain(toolChain);
      compile.getObjectFileDir().set(buildDirectory.dir("obj/" + names.getDirName()));
      binary.getObjectsDir().set(compile.getObjectFileDir());
      binary.getCompileTask().set(compile);
    }
  }
);
  project.getComponents().withType(CppSharedLibrary.class,new Action<CppSharedLibrary>(){
    @Override public void execute(    CppSharedLibrary library){
      library.getCompileTask().get().setPositionIndependentCode(true);
    }
  }
);
}
