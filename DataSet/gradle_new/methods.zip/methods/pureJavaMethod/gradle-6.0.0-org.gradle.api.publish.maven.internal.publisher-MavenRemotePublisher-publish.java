@Override public void publish(MavenNormalizedPublication publication,MavenArtifactRepository artifactRepository){
  LOGGER.info("Publishing to repository '{}' ({})",artifactRepository.getName(),artifactRepository.getUrl());
  String protocol=artifactRepository.getUrl().getScheme().toLowerCase();
  DefaultMavenArtifactRepository realRepository=(DefaultMavenArtifactRepository)artifactRepository;
  RepositoryTransport transport=realRepository.getTransport(protocol);
  ExternalResourceRepository repository=transport.getRepository();
  URI rootUri=artifactRepository.getUrl();
  publish(publication,repository,rootUri,false);
}
