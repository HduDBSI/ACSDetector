private void storeDirectoryEntry(String path,int mode,TarArchiveOutputStream tarOutput) throws IOException {
  createTarEntry(path + "/",0,UnixStat.DIR_FLAG | mode,tarOutput);
  tarOutput.closeArchiveEntry();
}
