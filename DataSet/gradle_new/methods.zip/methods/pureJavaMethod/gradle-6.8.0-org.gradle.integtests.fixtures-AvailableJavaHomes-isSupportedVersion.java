private static boolean isSupportedVersion(JvmInstallationMetadata jvmInstallation){
  return DISTRIBUTION.worksWith(jvmFromMetadata(jvmInstallation));
}
