public ImmutableList<TaskExecutionSnapshot> read(Decoder decoder) throws Exception {
  byte count=decoder.readByte();
  List<TaskExecutionSnapshot> executions=new ArrayList<TaskExecutionSnapshot>(count);
  for (int i=0; i < count; i++) {
    TaskExecutionSnapshot exec=executionSerializer.read(decoder);
    executions.add(exec);
  }
  return ImmutableList.copyOf(executions);
}
