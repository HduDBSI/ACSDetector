private List<Test> configureBuildForTestDescriptors(TestExecutionRequestAction testExecutionRequest){
  Map<String,List<InternalJvmTestRequest>> taskAndTests=testExecutionRequest.getTaskAndTests();
  List<Test> testTasksToRun=new ArrayList<Test>();
  for (  final Map.Entry<String,List<InternalJvmTestRequest>> entry : taskAndTests.entrySet()) {
    String testTaskPath=entry.getKey();
    for (    Test testTask : queryTestTasks(testTaskPath)) {
      for (      InternalJvmTestRequest jvmTestRequest : entry.getValue()) {
        final TestFilter filter=testTask.getFilter();
        filter.includeTest(jvmTestRequest.getClassName(),jvmTestRequest.getMethodName());
      }
      testTasksToRun.add(testTask);
    }
  }
  return testTasksToRun;
}
