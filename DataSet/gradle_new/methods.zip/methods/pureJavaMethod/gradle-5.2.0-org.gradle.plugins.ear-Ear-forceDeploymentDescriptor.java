private DeploymentDescriptor forceDeploymentDescriptor(){
  if (deploymentDescriptor == null) {
    deploymentDescriptor=getObjectFactory().newInstance(DefaultDeploymentDescriptor.class);
  }
  return deploymentDescriptor;
}
