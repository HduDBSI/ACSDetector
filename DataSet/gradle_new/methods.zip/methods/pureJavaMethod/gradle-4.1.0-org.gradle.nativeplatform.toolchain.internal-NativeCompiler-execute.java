@Override public void execute(BuildOperationQueue<CommandLineToolInvocation> buildQueue){
  buildQueue.setLogLocation(spec.getOperationLogger().getLogLocation());
  for (  File sourceFile : spec.getSourceFiles()) {
    CommandLineToolInvocation perFileInvocation=createPerFileInvocation(genericArgs,sourceFile,objectDir,spec);
    buildQueue.add(perFileInvocation);
  }
}
