private VirtualComponentIdentifier readModuleIdentifier(Decoder decoder) throws IOException {
  String group=decoder.readString();
  String module=decoder.readString();
  String version=decoder.readString();
  ModuleIdentifier moduleIdentifier=DefaultModuleIdentifier.newId(group,module);
  return new DefaultVirtualModuleComponentIdentifier(moduleIdentifier,version);
}
