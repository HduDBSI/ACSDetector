private ArtifactsForNode getArtifacts(DependencyGraphEdge dependency,DependencyGraphNode toConfiguration){
  ConfigurationMetadata configuration=toConfiguration.getMetadata();
  ComponentResolveMetadata component=toConfiguration.getOwner().getMetadata();
  Set<? extends ComponentArtifactMetadata> artifacts=dependency.getArtifacts(configuration);
  if (!artifacts.isEmpty()) {
    int id=nextId++;
    ArtifactSet artifactSet=artifactSelector.resolveArtifacts(component,artifacts);
    return new ArtifactsForNode(id,artifactSet);
  }
  ArtifactsForNode configurationArtifactSet=artifactsByNodeId.get(toConfiguration.getNodeId());
  if (configurationArtifactSet == null) {
    ModuleExclusion exclusions=dependency.getExclusions(moduleExclusions);
    ArtifactSet nodeArtifacts=artifactSelector.resolveArtifacts(component,configuration,exclusions);
    int id=nextId++;
    configurationArtifactSet=new ArtifactsForNode(id,nodeArtifacts);
    if (!exclusions.mayExcludeArtifacts()) {
      artifactsByNodeId.put(toConfiguration.getNodeId(),configurationArtifactSet);
    }
  }
  return configurationArtifactSet;
}
