protected void assertDependencyDescriptorHasCommonFixtureValues(DslOriginDependencyMetadata dependencyMetadata){
  assertEquals(TEST_IVY_EXCLUDE_RULE,dependencyMetadata.getExcludes().get(0));
  assertThat(dependencyMetadata.getModuleConfiguration(),equalTo(TEST_CONF));
  assertThat(dependencyMetadata.getDependencyConfiguration(),equalTo(TEST_DEP_CONF));
  assertThat(dependencyMetadata.isTransitive(),equalTo(true));
  assertDependencyDescriptorHasArtifacts(dependencyMetadata);
}
