/** 
 * The desired type of build to create, defaults to 'pom' if 'pom.xml' is found in project root if no pom.xml is found, it defaults to 'basic'. This property can be set via command-line option '--type'.
 */
@Input public String getType(){
  return isNullOrEmpty(type) ? detectType() : type;
}
