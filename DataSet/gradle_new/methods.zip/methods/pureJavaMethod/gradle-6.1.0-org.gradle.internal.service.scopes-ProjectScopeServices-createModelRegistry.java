protected ModelRegistry createModelRegistry(ModelRuleExtractor ruleExtractor){
  return new DefaultModelRegistry(ruleExtractor,project.getPath(),run -> {
    ProjectState projectState=null;
    try {
      projectState=project.getMutationState();
    }
 catch (    IllegalArgumentException e) {
    }
    if (projectState != null) {
      projectState.withMutableState(run);
    }
 else {
      run.run();
    }
  }
);
}
