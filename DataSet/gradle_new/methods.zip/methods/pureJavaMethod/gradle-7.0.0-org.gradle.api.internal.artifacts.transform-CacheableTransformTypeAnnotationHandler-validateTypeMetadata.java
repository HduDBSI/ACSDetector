@Override public void validateTypeMetadata(Class<?> classWithAnnotationAttached,TypeValidationContext visitor){
  if (!TransformAction.class.isAssignableFrom(classWithAnnotationAttached)) {
    reportInvalidUseOfCacheableAnnotation(classWithAnnotationAttached,visitor,getAnnotationType(),TransformAction.class);
  }
}
