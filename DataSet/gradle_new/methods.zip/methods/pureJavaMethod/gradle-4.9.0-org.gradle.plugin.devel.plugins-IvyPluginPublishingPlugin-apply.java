@Override public void apply(Project project){
  if (featurePreviews.isFeatureEnabled(FeaturePreviews.Feature.STABLE_PUBLISHING)) {
    project.afterEvaluate(new Action<Project>(){
      @Override public void execute(      final Project project){
        configurePublishing(project);
      }
    }
);
  }
 else {
    configurePublishing(project);
  }
}
