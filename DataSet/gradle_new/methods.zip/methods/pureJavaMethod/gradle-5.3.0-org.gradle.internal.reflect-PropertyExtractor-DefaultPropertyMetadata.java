DefaultPropertyMetadata(String fieldName,Method method,Class<? extends Annotation> propertyType,ImmutableMap<Class<? extends Annotation>,Annotation> annotations){
  this.fieldName=fieldName;
  this.method=method;
  this.propertyType=propertyType;
  this.annotations=annotations;
}
