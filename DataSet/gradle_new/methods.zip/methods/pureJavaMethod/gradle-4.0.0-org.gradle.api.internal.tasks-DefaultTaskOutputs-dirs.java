@Override public TaskOutputFilePropertyBuilder dirs(final Object... paths){
  return taskMutator.mutate("TaskOutputs.dirs(Object...)",new Callable<TaskOutputFilePropertyBuilder>(){
    @Override public TaskOutputFilePropertyBuilder call() throws Exception {
      return addSpec(new CompositeTaskOutputPropertySpec(task.getName(),resolver,OutputType.DIRECTORY,paths));
    }
  }
);
}
