@TaskAction void generate(){
  reportGenerator().generateReport(model.get().projects,projectModel -> projectModel.get().project,projectModel -> {
    render(projectModel.get());
    logClickableOutputFileUrl();
  }
);
}
