public static void tryClose(@Nullable ClassLoader classLoader){
  CompositeStoppable.stoppable(classLoader).stop();
}
