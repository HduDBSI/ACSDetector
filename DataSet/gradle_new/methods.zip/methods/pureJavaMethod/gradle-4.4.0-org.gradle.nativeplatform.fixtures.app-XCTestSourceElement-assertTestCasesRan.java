public void assertTestCasesRan(TestExecutionResult testExecutionResult){
  assertTestCasesRanInSuite(testExecutionResult,getTestSuites());
}
