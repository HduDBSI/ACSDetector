private void processEntry(ZipOutputStream outputStream,InputStream inputStream,ZipEntry zipEntry,byte[] buffer,final Set<String> seenPaths,Map<String,List<String>> services) throws IOException {
  String name=zipEntry.getName();
  if (zipEntry.isDirectory() || name.equals("META-INF/MANIFEST.MF")) {
    return;
  }
  if (name.startsWith("LICENSE") || name.startsWith("license")) {
    return;
  }
  if (!name.startsWith(SERVICES_DIR_PREFIX) && !seenPaths.add(name)) {
    return;
  }
  if (name.endsWith(".class")) {
    processClassFile(outputStream,inputStream,zipEntry,buffer);
  }
 else   if (name.startsWith(SERVICES_DIR_PREFIX)) {
    processServiceDescriptor(inputStream,zipEntry,buffer,services);
  }
 else {
    copyEntry(outputStream,inputStream,zipEntry,buffer);
  }
}
