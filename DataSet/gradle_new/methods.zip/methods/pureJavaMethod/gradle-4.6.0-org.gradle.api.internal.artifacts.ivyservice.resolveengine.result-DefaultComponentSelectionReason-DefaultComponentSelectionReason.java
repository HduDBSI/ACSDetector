public DefaultComponentSelectionReason(List<? extends ComponentSelectionDescriptor> descriptions){
  this.descriptions=new ArrayDeque<ComponentSelectionDescriptorInternal>(1);
  for (  ComponentSelectionDescriptor description : descriptions) {
    addCause(description);
  }
}
