@Override public void execute(CompatibilityCheckResult<T> result){
  for (  Action<? super CompatibilityCheckDetails<T>> rule : rules) {
    rule.execute(result);
    if (result.hasResult()) {
      return;
    }
  }
}
