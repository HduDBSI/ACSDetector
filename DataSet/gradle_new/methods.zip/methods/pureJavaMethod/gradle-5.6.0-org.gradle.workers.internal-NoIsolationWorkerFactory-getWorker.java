@Override public BuildOperationAwareWorker getWorker(final DaemonForkOptions forkOptions){
  final WorkerExecutor workerExecutor=this.workerExecutor;
  final ClassLoader contextClassLoader=Thread.currentThread().getContextClassLoader();
  return new AbstractWorker(buildOperationExecutor){
    @Override public DefaultWorkResult execute(    ActionExecutionSpec spec,    BuildOperationRef parentBuildOperation){
      return executeWrappedInBuildOperation(spec,parentBuildOperation,new Work(){
        @Override public DefaultWorkResult execute(        ActionExecutionSpec spec){
          DefaultWorkResult result;
          try {
            result=ClassLoaderUtils.executeInClassloader(contextClassLoader,new Factory<DefaultWorkResult>(){
              @Nullable @Override public DefaultWorkResult create(){
                return workerServer.execute(spec);
              }
            }
);
          }
  finally {
            workerExecutor.await();
          }
          return result;
        }
      }
);
    }
  }
;
}
