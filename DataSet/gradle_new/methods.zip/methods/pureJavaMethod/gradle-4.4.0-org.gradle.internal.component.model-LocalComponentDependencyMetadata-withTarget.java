@Override public LocalOriginDependencyMetadata withTarget(ComponentSelector target){
  if (selector.equals(target)) {
    return this;
  }
  return copyWithTarget(target);
}
