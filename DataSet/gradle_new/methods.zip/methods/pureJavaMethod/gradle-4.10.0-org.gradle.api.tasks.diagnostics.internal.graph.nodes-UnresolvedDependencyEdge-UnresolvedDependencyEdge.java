public UnresolvedDependencyEdge(UnresolvedDependencyResult dependency){
  this.dependency=dependency;
  ModuleComponentSelector attempted=(ModuleComponentSelector)dependency.getAttempted();
  actual=DefaultModuleComponentIdentifier.newId(attempted.getModuleIdentifier(),attempted.getVersion());
}
