@Internal @Override public org.gradle.api.logging.LoggingManager getLogging(){
  return loggingManager();
}
