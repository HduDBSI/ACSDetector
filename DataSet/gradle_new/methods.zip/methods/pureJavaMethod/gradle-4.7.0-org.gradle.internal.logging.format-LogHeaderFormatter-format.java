/** 
 * Given a message, return possibly-styled output for displaying message meant to categorize other messages "below" it, if any.
 */
List<StyledTextOutputEvent.Span> format(@Nullable String logHeader,String description,String status,boolean failed);
