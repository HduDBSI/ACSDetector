private static void configureUsageMetadata(UsageKind usage,Object buildDependency,Iterable<DependencySpec> dependencies,EnumMap<UsageKind,Iterable<DependencySpec>> dependenciesPerUsage,EnumMap<UsageKind,TaskDependency> buildDependenciesPerUsage){
  Iterable<DependencySpec> dependencySpecs=dependenciesPerUsage.get(usage);
  dependenciesPerUsage.put(usage,Iterables.concat(dependencies,dependencySpecs));
  if (buildDependency != null) {
    DefaultTaskDependency buildDependencies=(DefaultTaskDependency)buildDependenciesPerUsage.get(usage);
    buildDependencies.add(buildDependency);
  }
}
