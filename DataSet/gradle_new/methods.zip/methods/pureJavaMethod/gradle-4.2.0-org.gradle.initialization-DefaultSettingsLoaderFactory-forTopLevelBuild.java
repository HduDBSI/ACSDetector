@Override public SettingsLoader forTopLevelBuild(){
  return notifyingSettingsLoader(compositeBuildSettingsLoader());
}
