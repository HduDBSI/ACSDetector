private void applyPlugin(PluginRequestInternal request,PluginId id,Runnable applicator){
  try {
    try {
      applicator.run();
    }
 catch (    UnknownPluginException e) {
      throw couldNotApply(request,id,e);
    }
catch (    Exception e) {
      throw exceptionOccurred(request,e);
    }
  }
 catch (  Exception e) {
    throw new LocationAwareException(e,request.getScriptDisplayName(),request.getLineNumber());
  }
}
