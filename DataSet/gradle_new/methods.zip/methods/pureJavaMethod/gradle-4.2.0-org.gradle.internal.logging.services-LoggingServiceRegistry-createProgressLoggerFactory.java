protected ProgressLoggerFactory createProgressLoggerFactory(){
  return new DefaultProgressLoggerFactory(new ProgressLoggingBridge(get(OutputEventListener.class)),get(Clock.class));
}
