public DefaultJavaPluginConvention(ProjectInternal project,ObjectFactory objectFactory){
  this.project=project;
  sourceSets=objectFactory.newInstance(DefaultSourceSetContainer.class);
  docsDirName="docs";
  testResultsDirName=TestingBasePlugin.TEST_RESULTS_DIR_NAME;
  testReportDirName=TestingBasePlugin.TESTS_DIR_NAME;
}
