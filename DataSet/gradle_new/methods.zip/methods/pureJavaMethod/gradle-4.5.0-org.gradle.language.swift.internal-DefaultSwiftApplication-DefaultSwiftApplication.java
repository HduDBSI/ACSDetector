@Inject public DefaultSwiftApplication(String name,ObjectFactory objectFactory,FileOperations fileOperations,ConfigurationContainer configurations){
  super(name,fileOperations,objectFactory,configurations);
  this.objectFactory=objectFactory;
  this.developmentBinary=objectFactory.property(SwiftExecutable.class);
}
