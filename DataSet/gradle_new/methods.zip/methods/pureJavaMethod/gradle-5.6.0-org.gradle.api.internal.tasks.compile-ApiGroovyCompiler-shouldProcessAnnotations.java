private static boolean shouldProcessAnnotations(GroovyJavaJointCompileSpec spec){
  return spec.getGroovyCompileOptions().isJavaAnnotationProcessing() && spec.annotationProcessingConfigured();
}
