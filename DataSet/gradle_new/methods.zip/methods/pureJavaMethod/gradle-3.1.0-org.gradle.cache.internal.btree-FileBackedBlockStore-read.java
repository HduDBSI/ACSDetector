public void read() throws Exception {
  long pos=getPos().getPos();
  assert pos >= 0;
  if (pos + HEADER_SIZE >= currentFileSize) {
    throw blockCorruptedException();
  }
  DataInputStream inputStream=input.start(pos);
  BlockPayload payload=getPayload();
  byte type=inputStream.readByte();
  if (type != payload.getType()) {
    throw blockCorruptedException();
  }
  payloadSize=inputStream.readInt();
  if (pos + HEADER_SIZE + TAIL_SIZE+ payloadSize > currentFileSize) {
    throw blockCorruptedException();
  }
  payload.read(inputStream);
  long actualCount=input.getBytesRead();
  long count=inputStream.readInt();
  if (actualCount != count) {
    throw blockCorruptedException();
  }
  input.done();
}
