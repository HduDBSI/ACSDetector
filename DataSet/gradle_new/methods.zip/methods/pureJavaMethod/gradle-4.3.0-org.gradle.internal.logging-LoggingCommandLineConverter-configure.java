public void configure(CommandLineParser parser){
  for (  BuildOption<LoggingConfiguration> option : buildOptions) {
    option.configure(parser);
  }
}
