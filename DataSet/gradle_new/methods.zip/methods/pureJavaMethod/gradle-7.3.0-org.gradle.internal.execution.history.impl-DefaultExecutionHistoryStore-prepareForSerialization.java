private static ImmutableSortedMap<String,FileCollectionFingerprint> prepareForSerialization(ImmutableSortedMap<String,CurrentFileCollectionFingerprint> fingerprints){
  return copyOfSorted(transformValues(fingerprints,value -> value.archive(SerializableFileCollectionFingerprint::new)));
}
