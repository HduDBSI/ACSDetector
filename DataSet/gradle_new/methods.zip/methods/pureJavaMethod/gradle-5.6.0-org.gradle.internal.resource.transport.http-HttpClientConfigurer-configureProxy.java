private void configureProxy(HttpClientBuilder builder,CredentialsProvider credentialsProvider,HttpSettings httpSettings){
  HttpProxySettings.HttpProxy httpProxy=httpSettings.getProxySettings().getProxy();
  HttpProxySettings.HttpProxy httpsProxy=httpSettings.getSecureProxySettings().getProxy();
  for (  HttpProxySettings.HttpProxy proxy : Lists.newArrayList(httpProxy,httpsProxy)) {
    if (proxy != null) {
      if (proxy.credentials != null) {
        AllSchemesAuthentication authentication=new AllSchemesAuthentication(proxy.credentials);
        authentication.addHost(proxy.host,proxy.port);
        useCredentials(credentialsProvider,Collections.singleton(authentication));
      }
    }
  }
  builder.setRoutePlanner(new SystemDefaultRoutePlanner(ProxySelector.getDefault()));
}
