@Override public StandAloneNestedBuild addNestedBuild(BuildDefinition buildDefinition,BuildState owner){
  if (buildDefinition.getName() == null) {
    throw new UnsupportedOperationException("Not yet implemented.");
  }
  BuildIdentifier buildIdentifier=idFor(buildDefinition.getName());
  Path identityPath=pathFor(owner,buildIdentifier.getName());
  DefaultNestedBuild build=new DefaultNestedBuild(buildIdentifier,identityPath,buildDefinition,owner);
  addBuild(build);
  return build;
}
