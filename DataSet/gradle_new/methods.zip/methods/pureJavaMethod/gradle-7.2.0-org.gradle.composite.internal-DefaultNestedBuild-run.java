@Override public <T>T run(Function<? super BuildTreeLifecycleController,T> buildAction){
  return buildAction.apply(buildTreeLifecycleController);
}
