public DefaultProjectDescriptor createProjectDescriptor(DefaultProjectDescriptor parent,String name,File dir){
  return new DefaultProjectDescriptor(parent,name,dir,getProjectDescriptorRegistry(),getFileResolver());
}
