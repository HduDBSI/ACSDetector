protected AbstractNamedFileSnapshotTaskStateChanges(String taskName,TaskExecution previous,TaskExecution current,FileCollectionSnapshotterRegistry snapshotterRegistry,String title,ImmutableSortedSet<? extends TaskFilePropertySpec> fileProperties,InputNormalizationStrategy normalizationStrategy){
  this.taskName=taskName;
  this.previous=previous;
  this.current=current;
  this.snapshotterRegistry=snapshotterRegistry;
  this.title=title;
  this.fileProperties=fileProperties;
  this.normalizationStrategy=normalizationStrategy;
  this.currentSnapshots=buildSnapshots(taskName,snapshotterRegistry,title,fileProperties);
}
