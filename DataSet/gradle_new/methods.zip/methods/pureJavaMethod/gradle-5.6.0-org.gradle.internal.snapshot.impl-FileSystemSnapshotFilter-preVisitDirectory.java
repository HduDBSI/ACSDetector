@Override public boolean preVisitDirectory(DirectorySnapshot directorySnapshot){
  boolean root=relativePathTracker.isRoot();
  relativePathTracker.enter(directorySnapshot);
  if (root || predicate.test(directorySnapshot,relativePathTracker.getRelativePath())) {
    builder.preVisitDirectory(directorySnapshot);
    return true;
  }
 else {
    hasBeenFiltered.set(true);
  }
  relativePathTracker.leave();
  return false;
}
