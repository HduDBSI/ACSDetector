@Override public Optional<ExecutionOutcome> skipIfInputsEmpty(ImmutableSortedMap<String,FileSystemSnapshot> previousOutputFiles){
  TaskProperties properties=context.getTaskProperties();
  FileCollection inputFiles=properties.getInputFiles();
  FileCollection sourceFiles=properties.getSourceFiles();
  boolean hasSourceFiles=properties.hasSourceFiles();
  return emptySourceTaskSkipper.skipIfEmptySources(task,hasSourceFiles,inputFiles,sourceFiles,previousOutputFiles);
}
