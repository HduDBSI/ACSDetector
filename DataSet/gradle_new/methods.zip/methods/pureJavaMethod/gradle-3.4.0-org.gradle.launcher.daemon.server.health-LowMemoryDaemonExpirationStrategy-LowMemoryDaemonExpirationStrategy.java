public LowMemoryDaemonExpirationStrategy(double minFreeMemoryPercentage){
  Preconditions.checkArgument(minFreeMemoryPercentage >= 0,"Free memory percentage must be >= 0");
  Preconditions.checkArgument(minFreeMemoryPercentage <= 1,"Free memory percentage must be <= 1");
  this.minFreeMemoryPercentage=minFreeMemoryPercentage;
}
