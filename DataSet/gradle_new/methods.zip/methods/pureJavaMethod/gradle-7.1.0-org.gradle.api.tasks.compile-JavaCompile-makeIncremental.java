private Compiler<JavaCompileSpec> makeIncremental(InputChanges inputs,CleaningJavaCompiler<JavaCompileSpec> compiler,FileCollection stableSources){
  FileTree sources=stableSources.getAsFileTree();
  return getIncrementalCompilerFactory().makeIncremental(compiler,sources,createRecompilationSpec(inputs,sources));
}
