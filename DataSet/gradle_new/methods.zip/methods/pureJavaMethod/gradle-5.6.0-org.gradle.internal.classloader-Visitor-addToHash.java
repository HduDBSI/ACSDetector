private boolean addToHash(ClassLoader cl){
  byte[] knownId=knownClassLoaders.get(cl);
  if (knownId != null) {
    hasher.putBytes(knownId);
    return false;
  }
  if (cl instanceof CachingClassLoader || cl instanceof MultiParentClassLoader || cl instanceof DeprecatedClassloader) {
    return true;
  }
  HashCode hash=classLoaderFactory.getClassLoaderClasspathHash(cl);
  if (hash != null) {
    hasher.putHash(hash);
    return true;
  }
  foundUnknown=true;
  return false;
}
