private ModuleMetadataCacheEntry createEntry(ModuleComponentResolveMetadata metaData,HashValue moduleDescriptorHash){
  return ModuleMetadataCacheEntry.forMetaData(metaData,timeProvider.getCurrentTime(),moduleDescriptorHash.asBigInteger());
}
