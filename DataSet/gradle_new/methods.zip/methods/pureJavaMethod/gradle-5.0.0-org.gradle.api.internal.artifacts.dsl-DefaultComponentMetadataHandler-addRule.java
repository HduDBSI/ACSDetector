private ComponentMetadataHandler addRule(SpecRuleAction<? super ComponentMetadataDetails> ruleAction){
  metadataRuleContainer.addRule(ruleAction);
  return this;
}
