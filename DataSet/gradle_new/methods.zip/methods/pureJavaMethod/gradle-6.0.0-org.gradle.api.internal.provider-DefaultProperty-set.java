@Override public void set(Provider<? extends T> provider){
  if (!beforeMutate()) {
    return;
  }
  if (provider == null) {
    throw new IllegalArgumentException("Cannot set the value of a property using a null provider.");
  }
  ProviderInternal<? extends T> p=Providers.internal(provider);
  this.value=p.asSupplier(getValidationDisplayName(),type,sanitizer);
}
