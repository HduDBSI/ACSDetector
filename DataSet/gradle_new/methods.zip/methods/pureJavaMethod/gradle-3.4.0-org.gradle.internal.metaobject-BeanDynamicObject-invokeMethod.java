public void invokeMethod(String name,InvokeMethodResult result,Object... arguments){
  MetaClass metaClass=getMetaClass();
  MetaMethod metaMethod=lookupMethod(metaClass,name,inferTypes(arguments));
  if (metaMethod != null) {
    result.result(metaMethod.doMethodInvoke(bean,arguments));
    return;
  }
  List<MetaMethod> metaMethods=metaClass.respondsTo(bean,name);
  for (  MetaMethod method : metaMethods) {
    if (method.getParameterTypes().length != arguments.length) {
      continue;
    }
    Object[] transformed=argsTransformer.transform(method.getParameterTypes(),arguments);
    if (transformed == arguments) {
      continue;
    }
    result.result(method.doMethodInvoke(bean,transformed));
    return;
  }
  if (bean instanceof MethodMixIn) {
    MethodMixIn methodMixIn=(MethodMixIn)bean;
    methodMixIn.getAdditionalMethods().invokeMethod(name,result,arguments);
    return;
  }
  if (!implementsMissing) {
    return;
  }
  invokeOpaqueMethod(metaClass,name,arguments,result);
}
