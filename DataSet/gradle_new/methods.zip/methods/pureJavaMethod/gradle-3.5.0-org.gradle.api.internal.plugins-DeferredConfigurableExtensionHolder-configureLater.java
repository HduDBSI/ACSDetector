private void configureLater(Action<? super T> action){
  if (configured) {
    throw new InvalidUserDataException(format("Cannot configure the '%s' extension after it has been accessed.",name));
  }
  actions.add(action);
}
