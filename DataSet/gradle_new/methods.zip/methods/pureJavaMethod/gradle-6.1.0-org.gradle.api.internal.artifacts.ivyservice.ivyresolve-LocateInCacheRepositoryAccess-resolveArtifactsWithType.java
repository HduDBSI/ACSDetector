@Override public void resolveArtifactsWithType(ComponentResolveMetadata component,ArtifactType artifactType,BuildableArtifactSetResolveResult result){
  delegate.getLocalAccess().resolveArtifactsWithType(component,artifactType,result);
  if (result.hasResult()) {
    return;
  }
  resolveModuleArtifactsFromCache(cacheKey(artifactType),component,result);
}
