boolean test(Path path,String name,boolean isDirectory,Iterable<String> relativePath);
