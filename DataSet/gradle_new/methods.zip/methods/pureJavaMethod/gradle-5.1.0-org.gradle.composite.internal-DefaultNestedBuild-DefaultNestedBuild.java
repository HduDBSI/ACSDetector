DefaultNestedBuild(BuildIdentifier buildIdentifier,Path identityPath,BuildDefinition buildDefinition,BuildState owner){
  this.buildIdentifier=buildIdentifier;
  this.identityPath=identityPath;
  this.buildDefinition=buildDefinition;
  this.owner=owner;
  gradleLauncher=owner.getNestedBuildFactory().nestedInstance(buildDefinition,this);
}
