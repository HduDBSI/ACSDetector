protected List<? extends FileCollectionInternal> getSourceCollections(){
  DefaultFileCollectionResolveContext context=new DefaultFileCollectionResolveContext(patternSetFactory);
  visitContents(context);
  return context.resolveAsFileCollections();
}
