private List<Dispatch<MethodInvocation>> startNotification(boolean includeLogger){
  takeOwnership();
  List<Dispatch<MethodInvocation>> result=includeLogger ? allWithLogger : allWithNoLogger;
  doStartNotification(result);
  return result;
}
