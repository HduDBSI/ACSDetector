@Override public ComponentSelectionReasonInternal addCause(ComponentSelectionDescriptor description){
  ComponentSelectionDescriptorInternal descriptor=(ComponentSelectionDescriptorInternal)description;
  if (!descriptions.contains(descriptor)) {
    descriptions.add(descriptor);
  }
  return this;
}
