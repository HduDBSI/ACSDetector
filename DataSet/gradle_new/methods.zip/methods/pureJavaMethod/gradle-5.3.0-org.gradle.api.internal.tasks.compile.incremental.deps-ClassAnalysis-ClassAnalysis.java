public ClassAnalysis(String className,Set<String> classDependencies,boolean dependencyToAll,IntSet constants,Set<String> superTypes){
  this.className=className;
  this.classDependencies=ImmutableSet.copyOf(classDependencies);
  this.dependencyToAll=dependencyToAll;
  this.constants=constants.isEmpty() ? IntSets.EMPTY_SET : constants;
  this.superTypes=ImmutableSet.copyOf(superTypes);
}
