@Override public DefaultWorkResult execute(IsolatedParametersActionExecutionSpec<?> spec,BuildOperationRef parentBuildOperation){
  return executeWrappedInBuildOperation(spec,parentBuildOperation,workSpec -> {
    DefaultWorkResult result;
    try {
      result=ClassLoaderUtils.executeInClassloader(contextClassLoader,new Factory<DefaultWorkResult>(){
        @Nullable @Override public DefaultWorkResult create(){
          return workerServer.execute(specFactory.newSimpleSpec(workSpec));
        }
      }
);
    }
  finally {
      workerExecutor.await();
    }
    return result;
  }
);
}
