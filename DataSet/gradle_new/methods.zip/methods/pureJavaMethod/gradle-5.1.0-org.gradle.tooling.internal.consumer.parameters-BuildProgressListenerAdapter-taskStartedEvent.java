private TaskStartEvent taskStartedEvent(InternalOperationStartedProgressEvent event,InternalTaskDescriptor descriptor){
  TaskOperationDescriptor taskDescriptor=addDescriptor(event.getDescriptor(),toTaskDescriptor(descriptor));
  return new DefaultTaskStartEvent(event.getEventTime(),event.getDisplayName(),taskDescriptor);
}
