public DefaultFileSystemSnapshotter(FileHasher hasher,StringInterner stringInterner,FileSystem fileSystem,DirectoryFileTreeFactory directoryFileTreeFactory,FileSystemMirror fileSystemMirror){
  this.hasher=hasher;
  this.stringInterner=stringInterner;
  this.fileSystem=fileSystem;
  this.directoryFileTreeFactory=directoryFileTreeFactory;
  this.fileSystemMirror=fileSystemMirror;
  snapshotter=new DefaultGenericFileCollectionSnapshotter(stringInterner,directoryFileTreeFactory,this);
}
