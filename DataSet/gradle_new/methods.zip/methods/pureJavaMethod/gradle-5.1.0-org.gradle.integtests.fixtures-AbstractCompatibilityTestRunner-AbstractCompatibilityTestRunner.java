protected AbstractCompatibilityTestRunner(Class<?> target){
  super(target);
  validateTestName(target);
  NativeServicesTestFixture.initialize();
}
