@SuppressWarnings("OptionalUsedAsFieldOrParameterType") private static boolean didChangeOutput(Optional<AfterPreviousExecutionState> afterPreviousExecutionState,ImmutableSortedMap<String,FileSystemSnapshot> current){
  if (!afterPreviousExecutionState.isPresent()) {
    return true;
  }
  ImmutableSortedMap<String,FileSystemSnapshot> previous=afterPreviousExecutionState.get().getOutputFilesProducedByWork();
  if (!previous.keySet().equals(current.keySet())) {
    return true;
  }
  ChangeDetectorVisitor visitor=new ChangeDetectorVisitor();
  OutputFileChanges changes=new OutputFileChanges(previous,current);
  changes.accept(visitor);
  return visitor.hasAnyChanges();
}
