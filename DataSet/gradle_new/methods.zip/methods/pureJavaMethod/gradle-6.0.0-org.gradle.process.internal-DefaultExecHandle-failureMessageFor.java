private String failureMessageFor(Throwable failureCause,ExecHandleState currentState){
  if (currentState == ExecHandleState.STARTING) {
    if (hasCommandLineExceedMaxLength(command,arguments) && hasCommandLineExceedMaxLengthException(failureCause)) {
      return format("Process '%s' could not be started because the command line exceed operating system limits.",displayName);
    }
    return format("A problem occurred starting process '%s'",displayName);
  }
  return format("A problem occurred waiting for process '%s' to complete.",displayName);
}
