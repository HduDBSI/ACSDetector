private void failOnMissingOutput(String message,String type,String expected,String actual){
  failureOnUnexpectedOutput(String.format("%s%nExpected: %s%n%n%s:%n=======%n%s",message,expected,type,actual));
}
