CachedClasspathTransformer createCachedClasspathTransformer(CacheRepository cacheRepository,FileHasher fileHasher,List<CachedJarFileStore> fileStores){
  return new DefaultCachedClasspathTransformer(cacheRepository,new JarCache(fileHasher),fileStores);
}
