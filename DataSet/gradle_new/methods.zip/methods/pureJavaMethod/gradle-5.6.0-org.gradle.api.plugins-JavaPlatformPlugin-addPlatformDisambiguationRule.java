private void addPlatformDisambiguationRule(Project project){
  platformSupport.addDisambiguationRule(project.getDependencies().getAttributesSchema());
}
