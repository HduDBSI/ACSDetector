public BaseCrossBuildResultsStore(String resultType){
  this.db=new PerformanceDatabase("cross_build_results");
  this.resultType=resultType;
}
