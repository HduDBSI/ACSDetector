public DefaultProjectDependencyMetadata(String projectPath,ModuleVersionSelector requested,Map<String,List<String>> confs,Map<IvyArtifactName,Set<String>> dependencyArtifacts,Map<Exclude,Set<String>> excludeRules,String dynamicConstraintVersion,boolean changing,boolean transitive){
  super(requested,confs,dependencyArtifacts,excludeRules,dynamicConstraintVersion,changing,transitive);
  this.projectPath=projectPath;
}
