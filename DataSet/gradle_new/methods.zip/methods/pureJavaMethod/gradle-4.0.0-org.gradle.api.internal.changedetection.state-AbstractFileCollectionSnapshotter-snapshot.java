public FileCollectionSnapshot snapshot(FileCollection input,FileCollectionSnapshotBuilder fileCollectionSnapshotBuilder){
  FileCollectionInternal fileCollection=(FileCollectionInternal)input;
  FileCollectionVisitorImpl visitor=new FileCollectionVisitorImpl(fileCollectionSnapshotBuilder);
  fileCollection.visitRootElements(visitor);
  return fileCollectionSnapshotBuilder.build();
}
