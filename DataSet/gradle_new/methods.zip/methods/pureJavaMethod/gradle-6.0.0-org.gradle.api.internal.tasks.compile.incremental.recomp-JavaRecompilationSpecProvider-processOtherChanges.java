private void processOtherChanges(CurrentCompilation current,PreviousCompilation previous,RecompilationSpec spec){
  if (spec.isFullRebuildNeeded()) {
    return;
  }
  boolean emptyAnnotationProcessorPath=current.getAnnotationProcessorPath().isEmpty();
  SourceFileChangeProcessor javaChangeProcessor=new SourceFileChangeProcessor(previous);
  for (  FileChange fileChange : sourceFileChanges) {
    if (spec.isFullRebuildNeeded()) {
      return;
    }
    if (fileChange.getFileType() != FileType.FILE) {
      continue;
    }
    File file=fileChange.getFile();
    if (hasExtension(file,".java")) {
      String className=getClassNameForRelativePath(fileChange.getNormalizedPath());
      javaChangeProcessor.processChange(file,Collections.singletonList(className),spec);
    }
 else {
      if (emptyAnnotationProcessorPath) {
        continue;
      }
      spec.setFullRebuildCause(rebuildClauseForChangedNonSourceFile("resource",fileChange),null);
      return;
    }
  }
}
