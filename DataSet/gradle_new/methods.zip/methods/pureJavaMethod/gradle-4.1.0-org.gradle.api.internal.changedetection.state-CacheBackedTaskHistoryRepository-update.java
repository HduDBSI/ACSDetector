public void update(){
  storeSnapshots(currentExecution);
  if (previousExecution != null) {
    removeUnnecessarySnapshots(previousExecution);
  }
  taskHistoryCache.put(task.getPath(),currentExecution.snapshot());
}
