public NoProjectDependenciesRebuildOption(){
  super(null,CommandLineOptionConfiguration.create(LONG_OPTION,SHORT_OPTION,"Do not rebuild project dependencies."));
}
