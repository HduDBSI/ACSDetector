private TypeMetaData extractTypeName(Type type){
  TypeMetaData typeMetaData=new TypeMetaData();
  type.ifArrayType(arrayType -> typeMetaData.setArrayDimensions(arrayType.getArrayLevel()));
  extractElementTypeName(type.getElementType(),typeMetaData);
  return typeMetaData;
}
