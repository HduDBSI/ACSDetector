/** 
 * Create relationships between the ordinal nodes such that destroyer ordinals cannot complete until all preceding producer ordinals have completed (and vice versa).  This ensures that an ordinal does not complete early simply because the nodes in the ordinal group it represents have no explicit dependencies.
 */
void createInterNodeRelationships(){
  destroyerLocationNodes.forEach((ordinal,destroyer) -> {
    for (int i=0; i < ordinal.getOrdinal(); i++) {
      Node precedingNode=destroyerLocationNodes.get(group(i));
      if (precedingNode != null) {
        destroyer.addDependencySuccessor(precedingNode);
      }
    }
  }
);
  producerLocationNodes.forEach((ordinal,producer) -> {
    for (int i=0; i < ordinal.getOrdinal(); i++) {
      Node precedingNode=producerLocationNodes.get(group(i));
      if (precedingNode != null) {
        producer.addDependencySuccessor(precedingNode);
      }
    }
  }
);
}
