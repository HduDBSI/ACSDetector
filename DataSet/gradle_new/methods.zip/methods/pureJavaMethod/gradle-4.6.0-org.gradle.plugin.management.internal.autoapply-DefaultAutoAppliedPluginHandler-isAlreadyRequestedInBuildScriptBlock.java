private static boolean isAlreadyRequestedInBuildScriptBlock(PluginRequestInternal autoAppliedPlugin,ScriptHandler scriptHandler){
  ModuleVersionSelector module=autoAppliedPlugin.getModule();
  if (module == null) {
    return false;
  }
  Configuration classpathConfiguration=scriptHandler.getConfigurations().getByName(ScriptHandler.CLASSPATH_CONFIGURATION);
  for (  Dependency dependency : classpathConfiguration.getDependencies()) {
    if (module.getGroup().equals(dependency.getGroup()) && module.getName().equals(dependency.getName())) {
      return true;
    }
  }
  return false;
}
