public void visitOutgoingDependencies(Collection<EdgeState> target){
  if (!component.isSelected()) {
    LOGGER.debug("version for {} is not selected. ignoring.",this);
    return;
  }
  boolean hasIncomingEdges=!incomingEdges.isEmpty();
  List<EdgeState> transitiveIncoming=findTransitiveIncomingEdges(hasIncomingEdges);
  if (transitiveIncoming.isEmpty() && !isRoot()) {
    if (previousTraversalExclusions != null) {
      removeOutgoingEdges();
    }
    if (hasIncomingEdges) {
      LOGGER.debug("{} has no transitive incoming edges. ignoring outgoing edges.",this);
    }
 else {
      LOGGER.debug("{} has no incoming edges. ignoring.",this);
    }
    return;
  }
  ModuleExclusion resolutionFilter=getModuleResolutionFilter(transitiveIncoming);
  if (previousTraversalExclusions != null) {
    if (previousTraversalExclusions.excludesSameModulesAs(resolutionFilter)) {
      LOGGER.debug("Changed edges for {} selects same versions as previous traversal. ignoring",this);
      previousTraversalExclusions=resolutionFilter;
      return;
    }
    removeOutgoingEdges();
  }
  for (  DependencyMetadata dependency : metaData.getDependencies()) {
    if (isExcluded(resolutionFilter,dependency)) {
      continue;
    }
    EdgeState dependencyEdge=new EdgeState(this,dependency,resolutionFilter,resolveState);
    outgoingEdges.add(dependencyEdge);
    target.add(dependencyEdge);
  }
  previousTraversalExclusions=resolutionFilter;
}
