/** 
 * Injects the interfaces into an arbitrary classloader via {@link ClassLoader#defineClass(String,byte[],int,int)}.
 */
@Override public void injectEmptyInterfacesIntoClassLoader(ClassLoader classLoader){
  try {
    for (    String name : syntheticClasses) {
      byte[] bytes=generateSyntheticClass(name);
      ClassLoaderUtils.define(classLoader,name,bytes);
    }
  }
 catch (  Exception e) {
    throw new GradleException("Could not inject synthetic classes.",e);
  }
}
