@Override public List<File> transform(File input){
  try {
    File absoluteFile=input.getAbsoluteFile();
    return transformedFileCache.getResult(absoluteFile,inputsHash,transformer);
  }
 catch (  Throwable t) {
    throw new ArtifactTransformException(input,to,implementation,t);
  }
}
