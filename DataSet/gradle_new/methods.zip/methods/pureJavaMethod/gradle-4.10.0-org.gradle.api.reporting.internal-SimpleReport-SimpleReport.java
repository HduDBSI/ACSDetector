public SimpleReport(String name,Factory<String> displayName,OutputType outputType,PathToFileResolver fileResolver,Project project){
  this.name=name;
  this.displayName=displayName;
  this.fileResolver=fileResolver;
  this.outputType=outputType;
  destination=project.getObjects().property(File.class);
  enabled=project.getObjects().property(Boolean.class);
  this.project=project;
}
