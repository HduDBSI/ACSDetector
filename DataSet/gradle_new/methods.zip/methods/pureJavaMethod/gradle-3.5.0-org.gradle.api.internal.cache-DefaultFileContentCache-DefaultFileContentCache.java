DefaultFileContentCache(String name,FileHasher fileHasher,FileSystem fileSystem,FileSystemMirror fileSystemMirror,PersistentIndexedCache<HashCode,V> contentCache,Calculator<? extends V> calculator){
  this.name=name;
  this.fileHasher=fileHasher;
  this.fileSystem=fileSystem;
  this.fileSystemMirror=fileSystemMirror;
  this.contentCache=contentCache;
  this.calculator=calculator;
}
