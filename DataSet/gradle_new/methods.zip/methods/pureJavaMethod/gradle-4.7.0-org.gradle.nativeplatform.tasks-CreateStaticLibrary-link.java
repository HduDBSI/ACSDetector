@TaskAction public void link(){
  StaticLibraryArchiverSpec spec=new DefaultStaticLibraryArchiverSpec();
  spec.setTempDir(getTemporaryDir());
  spec.setOutputFile(getOutputFile().get().getAsFile());
  spec.objectFiles(getSource());
  spec.args(getStaticLibArgs().get());
  BuildOperationLogger operationLogger=getOperationLoggerFactory().newOperationLogger(getName(),getTemporaryDir());
  spec.setOperationLogger(operationLogger);
  Compiler<StaticLibraryArchiverSpec> compiler=createCompiler();
  WorkResult result=BuildOperationLoggingCompilerDecorator.wrap(compiler).execute(spec);
  setDidWork(result.getDidWork());
}
