@Override public void write(IvyModulePublishMetadata module,File output){
  try {
    output.getParentFile().mkdirs();
    OutputStream outputStream=new FileOutputStream(output);
    try {
      SimpleXmlWriter xmlWriter=new SimpleXmlWriter(outputStream,"  ");
      writeTo(module,xmlWriter);
      xmlWriter.flush();
    }
  finally {
      outputStream.close();
    }
  }
 catch (  IOException e) {
    throw new UncheckedIOException(e);
  }
}
