@TaskAction void build(){
  BuildDefinition buildDefinition=BuildDefinition.fromStartParameter(getStartParameter());
  StandAloneNestedBuild nestedBuild=buildStateRegistry.addNestedBuildTree(buildDefinition,nestedBuildFactory);
  nestedBuild.run(new Transformer<Void,BuildController>(){
    @Override public Void transform(    BuildController buildController){
      buildController.run();
      return null;
    }
  }
);
}
