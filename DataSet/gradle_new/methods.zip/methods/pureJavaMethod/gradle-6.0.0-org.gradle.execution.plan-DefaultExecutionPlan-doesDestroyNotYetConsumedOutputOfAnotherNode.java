private boolean doesDestroyNotYetConsumedOutputOfAnotherNode(Node destroyer,Set<String> destroyablePaths){
  if (!destroyablePaths.isEmpty()) {
    for (    Node producingNode : producedButNotYetConsumed) {
      MutationInfo producingNodeMutations=producingNode.getMutationInfo();
      assert !producingNodeMutations.consumingNodes.isEmpty();
      if (!hasOverlap(destroyablePaths,producingNodeMutations.outputPaths)) {
        continue;
      }
      for (      Node consumer : producingNodeMutations.consumingNodes) {
        if (doesConsumerDependOnDestroyer(consumer,destroyer)) {
          continue;
        }
        LOGGER.debug("Node {} destroys output of consumer {}",destroyer,consumer);
        return true;
      }
    }
  }
  return false;
}
