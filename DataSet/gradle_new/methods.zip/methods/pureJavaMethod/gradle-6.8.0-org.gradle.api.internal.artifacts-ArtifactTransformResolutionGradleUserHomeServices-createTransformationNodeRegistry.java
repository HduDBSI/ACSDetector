TransformationNodeRegistry createTransformationNodeRegistry(){
  return TransformationNodeRegistry.EMPTY;
}
