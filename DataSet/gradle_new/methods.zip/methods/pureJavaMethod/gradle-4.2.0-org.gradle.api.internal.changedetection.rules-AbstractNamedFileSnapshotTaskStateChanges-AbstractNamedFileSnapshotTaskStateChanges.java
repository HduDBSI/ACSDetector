protected AbstractNamedFileSnapshotTaskStateChanges(TaskExecution previous,TaskExecution current,TaskInternal task,String title){
  this.previous=previous;
  this.current=current;
  this.task=task;
  this.title=title;
}
