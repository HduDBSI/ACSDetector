private void configureReportsConventionMapping(Pmd task,final String baseName){
  ProjectLayout layout=project.getLayout();
  ProviderFactory providers=project.getProviders();
  Provider<RegularFile> reportsDir=layout.file(providers.provider(() -> extension.getReportsDir()));
  task.getReports().all(action(report -> {
    report.getRequired().convention(true);
    report.getOutputLocation().convention(layout.getProjectDirectory().file(providers.provider(() -> {
      String reportFileName=baseName + "." + report.getName();
      return new File(reportsDir.get().getAsFile(),reportFileName).getAbsolutePath();
    }
)));
  }
));
}
