/** 
 * Finds the settings.gradle for the given startParameter, and loads it if contains the project selected by the startParameter, or if the startParameter explicitly specifies a settings script.  If the settings file is not loaded (executed), then a null is returned.
 */
private SettingsInternal findSettingsAndLoadIfAppropriate(GradleInternal gradle,StartParameter startParameter,ClassLoaderScope classLoaderScope){
  SettingsLocation settingsLocation=findSettings(startParameter);
  SettingsInternal settings=settingsProcessor.process(gradle,settingsLocation,classLoaderScope,startParameter);
  validate(settings);
  return settings;
}
