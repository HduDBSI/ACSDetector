@Inject public XcodeTarget(String name,String id,FileOperations fileOperations){
  this.name=name;
  this.id=id;
  this.sources=fileOperations.files();
  this.headerSearchPaths=fileOperations.files();
  this.compileModules=fileOperations.files();
}
