public RequestedVersion(ComponentSelector requested,ComponentIdentifier actual,boolean resolvable,String description,ResolvedVariantResult resolvedVariant){
  this.requested=requested;
  this.actual=actual;
  this.resolvable=resolvable;
  this.description=description;
  this.variantResult=resolvedVariant;
}
