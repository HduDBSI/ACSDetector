public DaemonServices(DaemonServerConfiguration configuration,ServiceRegistry loggingServices,LoggingManagerInternal loggingManager,ClassPath additionalModuleClassPath){
  super(NativeServices.getInstance(),loggingServices);
  this.configuration=configuration;
  this.loggingManager=loggingManager;
  this.runningClock=new Clock();
  addProvider(new DaemonRegistryServices(configuration.getBaseDir()));
  addProvider(new GlobalScopeServices(true,additionalModuleClassPath));
}
