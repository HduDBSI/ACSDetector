@Override public SettingsInternal findAndLoadSettings(GradleInternal gradle){
  SettingsInternal settings=delegate.findAndLoadSettings(gradle);
  List<IncludedBuildSpec> includedBuilds=settings.getIncludedBuilds();
  if (!includedBuilds.isEmpty()) {
    Set<IncludedBuild> children=new LinkedHashSet<>(includedBuilds.size());
    for (    IncludedBuildSpec includedBuildSpec : includedBuilds) {
      if (!includedBuildSpec.rootDir.equals(buildRegistry.getRootBuild().getBuildRootDir())) {
        IncludedBuildState includedBuild=addIncludedBuild(includedBuildSpec,gradle);
        children.add(includedBuild.getModel());
      }
 else {
        children.add(new IncludedRootBuild((CompositeBuildParticipantBuildState)buildRegistry.getRootBuild()));
      }
    }
    gradle.setIncludedBuilds(children);
  }
 else {
    gradle.setIncludedBuilds(Collections.emptyList());
  }
  return settings;
}
