@Inject public IvyPublishPlugin(Instantiator instantiator,ObjectFactory objectFactory,DependencyMetaDataProvider dependencyMetaDataProvider,FileResolver fileResolver){
  this.instantiator=instantiator;
  this.objectFactory=objectFactory;
  this.dependencyMetaDataProvider=dependencyMetaDataProvider;
  this.fileResolver=fileResolver;
}
