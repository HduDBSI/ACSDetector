private void configureComponent(Project project,PublishArtifact warArtifact){
  project.getComponents().add(objectFactory.newInstance(WebApplication.class,warArtifact,"master"));
}
