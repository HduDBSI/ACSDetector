public DefaultNamedDomainObjectList(Class<T> type,Instantiator instantiator,Namer<? super T> namer,CollectionCallbackActionDecorator decorator){
  super(type,new ListElementSource<T>(),instantiator,namer,decorator);
}
