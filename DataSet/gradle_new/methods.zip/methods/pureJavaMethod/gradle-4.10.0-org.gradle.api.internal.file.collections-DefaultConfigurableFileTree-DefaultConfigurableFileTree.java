public DefaultConfigurableFileTree(Map<String,?> args,FileResolver resolver,@Nullable TaskResolver taskResolver,FileCopier fileCopier,DirectoryFileTreeFactory directoryFileTreeFactory){
  this.resolver=resolver;
  this.fileCopier=fileCopier;
  this.directoryFileTreeFactory=directoryFileTreeFactory;
  patternSet=resolver.getPatternSetFactory().create();
  buildDependency=new DefaultTaskDependency(taskResolver);
  ConfigureUtil.configureByMap(args,this);
}
