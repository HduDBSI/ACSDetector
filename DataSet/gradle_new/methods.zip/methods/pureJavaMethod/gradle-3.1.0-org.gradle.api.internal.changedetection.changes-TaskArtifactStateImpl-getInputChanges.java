public IncrementalTaskInputs getInputChanges(){
  assert !upToDate : "Should not be here if the task is up-to-date";
  if (canPerformIncrementalBuild()) {
    taskInputs=instantiator.newInstance(ChangesOnlyIncrementalTaskInputs.class,getStates().getInputFilesChanges());
  }
 else {
    taskInputs=instantiator.newInstance(RebuildIncrementalTaskInputs.class,task);
  }
  return taskInputs;
}
