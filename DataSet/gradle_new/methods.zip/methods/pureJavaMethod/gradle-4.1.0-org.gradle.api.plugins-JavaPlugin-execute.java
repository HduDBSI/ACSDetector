public void execute(final Test test){
  test.getConventionMapping().map("testClassesDirs",new Callable<Object>(){
    public Object call() throws Exception {
      return pluginConvention.getSourceSets().getByName(SourceSet.TEST_SOURCE_SET_NAME).getOutput().getClassesDirs();
    }
  }
);
  test.getConventionMapping().map("classpath",new Callable<Object>(){
    public Object call() throws Exception {
      return pluginConvention.getSourceSets().getByName(SourceSet.TEST_SOURCE_SET_NAME).getRuntimeClasspath();
    }
  }
);
}
