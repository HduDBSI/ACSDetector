private NoHistoryTaskUpToDateState(){
  noHistoryTaskStateChanges=ImmutableList.<TaskStateChange>of(noHistoryChange);
}
