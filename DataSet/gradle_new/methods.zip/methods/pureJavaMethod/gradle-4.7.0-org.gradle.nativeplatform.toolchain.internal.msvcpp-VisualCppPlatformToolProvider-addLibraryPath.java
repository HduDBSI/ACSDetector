private Transformer<LinkerSpec,LinkerSpec> addLibraryPath(){
  return new Transformer<LinkerSpec,LinkerSpec>(){
    public LinkerSpec transform(    LinkerSpec original){
      original.libraryPath(libraries.getLibDirs());
      return original;
    }
  }
;
}
