private boolean isExcluded(ModuleExclusion selector,DependencyState dependencyState){
  DependencyMetadata dependency=dependencyState.getDependencyMetadata();
  if (!resolveState.getEdgeFilter().isSatisfiedBy(dependency)) {
    LOGGER.debug("{} is filtered.",dependency);
    return true;
  }
  if (selector == ModuleExclusions.excludeNone()) {
    return false;
  }
  ModuleIdentifier targetModuleId=dependencyState.getModuleIdentifier();
  if (selector.excludeModule(targetModuleId)) {
    LOGGER.debug("{} is excluded from {}.",targetModuleId,this);
    return true;
  }
  return false;
}
