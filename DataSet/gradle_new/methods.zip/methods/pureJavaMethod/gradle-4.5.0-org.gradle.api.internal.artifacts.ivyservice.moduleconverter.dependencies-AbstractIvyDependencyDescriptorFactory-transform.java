@Override public ExcludeMetadata transform(ExcludeRule excludeRule){
  return excludeRuleConverter.convertExcludeRule(excludeRule);
}
