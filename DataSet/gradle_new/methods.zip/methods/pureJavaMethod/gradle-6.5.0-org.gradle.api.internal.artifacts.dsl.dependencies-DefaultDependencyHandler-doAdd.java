@SuppressWarnings("rawtypes") private Dependency doAdd(Configuration configuration,Object dependencyNotation,@Nullable Closure configureClosure){
  if (dependencyNotation instanceof Configuration) {
    return doAddConfiguration(configuration,(Configuration)dependencyNotation);
  }
  if (dependencyNotation instanceof Provider<?>) {
    return doAddProvider(configuration,(Provider<?>)dependencyNotation,configureClosure);
  }
 else {
    return doAddRegularDependency(configuration,dependencyNotation,configureClosure);
  }
}
