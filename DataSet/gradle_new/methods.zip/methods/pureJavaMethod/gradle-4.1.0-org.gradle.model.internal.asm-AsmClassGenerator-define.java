public <T>Class<T> define(ClassLoader targetClassLoader){
  return ClassLoaderUtils.define(targetClassLoader,generatedTypeName,visitor.toByteArray());
}
