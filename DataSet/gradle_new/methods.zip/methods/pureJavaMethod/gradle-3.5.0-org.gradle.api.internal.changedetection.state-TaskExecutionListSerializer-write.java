public void write(Encoder encoder,ImmutableList<TaskExecutionSnapshot> value) throws Exception {
  int size=value.size();
  encoder.writeByte((byte)size);
  for (  TaskExecutionSnapshot execution : value) {
    executionSerializer.write(encoder,execution);
  }
}
