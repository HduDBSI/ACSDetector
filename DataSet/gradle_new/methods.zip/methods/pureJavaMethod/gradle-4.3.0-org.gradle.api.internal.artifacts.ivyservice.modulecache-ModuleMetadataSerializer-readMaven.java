private MutableModuleComponentResolveMetadata readMaven() throws IOException {
  readInfoSection();
  List<DependencyMetadata> dependencies=readDependencies();
  DefaultMutableMavenModuleResolveMetadata metadata=new DefaultMutableMavenModuleResolveMetadata(mvi,id,dependencies);
  readSharedInfo(metadata);
  metadata.setSnapshotTimestamp(readNullableString());
  metadata.setPackaging(readNullableString());
  metadata.setRelocated(readBoolean());
  readVariants(metadata);
  return metadata;
}
