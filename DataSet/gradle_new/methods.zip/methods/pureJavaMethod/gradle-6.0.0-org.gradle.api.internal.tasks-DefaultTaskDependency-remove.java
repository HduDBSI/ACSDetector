@Override public boolean remove(Object o){
  throw new UnsupportedOperationException(REMOVE_ERROR);
}
