public WtpComponentFactory(Project project,IdeArtifactRegistry artifactRegistry,ProjectStateRegistry projectRegistry){
  projectDependencyBuilder=new ProjectDependencyBuilder(artifactRegistry);
  currentProjectId=projectRegistry.stateFor(project).getComponentIdentifier();
}
