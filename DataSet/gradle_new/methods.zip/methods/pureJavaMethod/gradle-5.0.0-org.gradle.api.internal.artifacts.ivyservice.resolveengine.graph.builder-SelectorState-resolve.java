private ComponentIdResolveResult resolve(VersionSelector selector,VersionSelector rejector,ComponentIdResolveResult previousResult){
  try {
    if (!requiresResolve(previousResult,rejector)) {
      return previousResult;
    }
    BuildableComponentIdResolveResult idResolveResult=new DefaultBuildableComponentIdResolveResult();
    if (dependencyState.failure != null) {
      idResolveResult.failed(dependencyState.failure);
    }
 else {
      resolver.resolve(firstSeenDependency,selector,rejector,idResolveResult);
    }
    if (idResolveResult.getFailure() != null) {
      failure=idResolveResult.getFailure();
    }
    return idResolveResult;
  }
  finally {
    this.resolved=true;
  }
}
