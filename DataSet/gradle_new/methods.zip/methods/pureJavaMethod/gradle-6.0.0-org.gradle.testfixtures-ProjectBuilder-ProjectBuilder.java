/** 
 * An instance should only be created via the  {@link #builder()}.
 */
private ProjectBuilder(){
}
