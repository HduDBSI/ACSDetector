@Override public Iterable<String> getChangingOutputs(){
  return ImmutableList.of(workspace.getOutputDirectory().getAbsolutePath(),workspace.getResultsFile().getAbsolutePath());
}
