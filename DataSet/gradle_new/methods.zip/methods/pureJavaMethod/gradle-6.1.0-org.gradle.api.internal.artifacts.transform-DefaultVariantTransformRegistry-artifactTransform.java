@Override public void artifactTransform(Class<? extends ArtifactTransform> type,@Nullable Action<? super ActionConfiguration> config){
  if (this.actionType != null) {
    throw new IllegalStateException("Only one ArtifactTransform may be provided for registration.");
  }
  this.actionType=type;
  this.configAction=config;
}
