public IncrementalCompilerFactory(BuildOperationExecutor buildOperationExecutor,StringInterner interner,ClassSetAnalyzer classSetAnalyzer){
  this.buildOperationExecutor=buildOperationExecutor;
  this.interner=interner;
  this.classSetAnalyzer=classSetAnalyzer;
}
