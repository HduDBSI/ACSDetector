private Set<ResolvedArtifact> sort(ResolvedArtifactSet artifacts){
  ArtifactCollectingVisitor visitor=new ArtifactCollectingVisitor(new TreeSet<>(new ResolvedArtifactComparator()));
  ParallelResolveArtifactSet.wrap(artifacts,buildOperationProcessor).visit(visitor);
  return visitor.getArtifacts();
}
