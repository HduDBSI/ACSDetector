@Override public ExecutionResult assertTasksNotSkipped(Object... taskPaths){
  Set<String> expectedTasks=new TreeSet<String>(flattenTaskPaths(taskPaths));
  Set<String> tasks=new TreeSet<String>(getNotSkippedTasks());
  if (!expectedTasks.equals(tasks)) {
    failOnDifferentSets("Build output does not contain the expected non skipped tasks.",expectedTasks,tasks);
  }
  return this;
}
