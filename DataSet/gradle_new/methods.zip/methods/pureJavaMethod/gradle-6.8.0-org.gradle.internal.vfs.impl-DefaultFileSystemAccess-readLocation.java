private FileSystemLocationSnapshot readLocation(String location){
  return readSnapshotFromLocation(location,() -> snapshot(location,SnapshottingFilter.EMPTY));
}
