public static TaskInAnotherBuild of(Path taskIdentityPath,String taskPath,BuildIdentifier targetBuild,BuildIdentifier thisBuild,IncludedBuildTaskGraph taskGraph){
  return new Deferred(taskIdentityPath,taskPath,targetBuild,thisBuild,taskGraph);
}
