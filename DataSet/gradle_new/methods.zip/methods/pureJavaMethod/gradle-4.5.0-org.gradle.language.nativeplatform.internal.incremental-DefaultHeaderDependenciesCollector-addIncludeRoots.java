private void addIncludeRoots(String taskPath,List<File> includeRoots,final Set<File> headerDependencies){
  for (  final File includeRoot : includeRoots) {
    logger.info("adding files in {} to header dependencies for {}",includeRoot,taskPath);
    directoryFileTreeFactory.create(includeRoot).visit(new EmptyFileVisitor(){
      @Override public void visitFile(      FileVisitDetails fileDetails){
        headerDependencies.add(fileDetails.getFile());
      }
    }
);
  }
}
