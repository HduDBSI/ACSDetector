private AbstractModuleExclusion maybeMergeIntoUnion(IntersectionExclusion one,IntersectionExclusion other){
  if (one.canMerge() && other.canMerge()) {
    AbstractModuleExclusion[] oneFilters=one.getFilters().elements;
    AbstractModuleExclusion[] otherFilters=other.getFilters().elements;
    if (Arrays.equals(oneFilters,otherFilters)) {
      return one;
    }
    MergeOperation merge=mergeOperation(oneFilters,otherFilters);
    AbstractModuleExclusion exclusion=mergeCache.get(merge);
    if (exclusion != null) {
      return exclusion;
    }
    return mergeAndCacheResult(merge,oneFilters,otherFilters);
  }
  return null;
}
