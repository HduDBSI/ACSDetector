public LinkerSpec transform(LinkerSpec original){
  original.libraryPath(libraries.getLibDirs());
  return original;
}
