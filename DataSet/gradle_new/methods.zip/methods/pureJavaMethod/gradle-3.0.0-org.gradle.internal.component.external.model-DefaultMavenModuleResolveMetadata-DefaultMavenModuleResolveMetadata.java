private DefaultMavenModuleResolveMetadata(ModuleComponentIdentifier componentId,ModuleVersionIdentifier id,ModuleDescriptorState moduleDescriptor,String packaging,boolean relocated){
  super(componentId,id,moduleDescriptor);
  this.packaging=packaging;
  this.relocated=relocated;
}
