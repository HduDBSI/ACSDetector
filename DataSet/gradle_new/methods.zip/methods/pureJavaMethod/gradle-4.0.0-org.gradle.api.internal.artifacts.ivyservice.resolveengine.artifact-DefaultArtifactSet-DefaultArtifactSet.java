private DefaultArtifactSet(ComponentIdentifier componentIdentifier,AttributesSchemaInternal schema){
  this.componentIdentifier=componentIdentifier;
  this.schema=schema;
}
