private <T>List<T> doResolve(Converter<? extends T> converter){
  List<T> result=new ArrayList<T>();
  for (  Object element : queue) {
    converter.convertInto(element,result);
  }
  return result;
}
