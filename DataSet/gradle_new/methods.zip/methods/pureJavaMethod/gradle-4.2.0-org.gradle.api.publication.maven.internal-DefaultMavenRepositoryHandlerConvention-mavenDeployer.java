public GroovyMavenDeployer mavenDeployer(Map<String,?> args,Action<? super GroovyMavenDeployer> configureAction){
  return mavenDeployer(composite(configureByMapActionFor(args),configureAction));
}
