@Override public void evaluate() throws Throwable {
  if (sampleName != null) {
    IntegrationTestBuildContext context=IntegrationTestBuildContext.INSTANCE;
    TestFile srcDir=context.getSamplesDir().file(sampleName);
    logger.debug("Copying sample '{}' to test directory.",sampleName);
    srcDir.copyTo(getDir());
  }
 else {
    logger.debug("No sample specified for this test, skipping.");
  }
  base.evaluate();
}
