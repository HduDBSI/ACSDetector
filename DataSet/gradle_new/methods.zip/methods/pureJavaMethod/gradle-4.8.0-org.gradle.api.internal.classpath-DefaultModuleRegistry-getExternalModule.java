public Module getExternalModule(String name){
  Module module=externalModules.get(name);
  if (module == null) {
    module=loadExternalModule(name);
    externalModules.put(name,module);
  }
  return module;
}
