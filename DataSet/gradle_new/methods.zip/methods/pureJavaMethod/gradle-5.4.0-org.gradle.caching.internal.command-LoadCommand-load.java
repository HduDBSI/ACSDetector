@Override public BuildCacheLoadCommand.Result<LoadMetadata> load(InputStream input) throws IOException {
  BuildCacheEntryPacker.UnpackResult unpackResult=packer.unpack(entity,input,originMetadataFactory.createReader(entity));
  ImmutableSortedMap<String,CurrentFileCollectionFingerprint> snapshots=snapshotUnpackedData(unpackResult.getSnapshots());
  LOGGER.info("Unpacked trees for {} from cache.",entity.getDisplayName());
  return new Result<LoadMetadata>(){
    @Override public long getArtifactEntryCount(){
      return unpackResult.getEntries();
    }
    @Override public LoadMetadata getMetadata(){
      return new LoadMetadata(){
        @Override public OriginMetadata getOriginMetadata(){
          return unpackResult.getOriginMetadata();
        }
        @Override public ImmutableSortedMap<String,CurrentFileCollectionFingerprint> getResultingSnapshots(){
          return snapshots;
        }
      }
;
    }
  }
;
}
