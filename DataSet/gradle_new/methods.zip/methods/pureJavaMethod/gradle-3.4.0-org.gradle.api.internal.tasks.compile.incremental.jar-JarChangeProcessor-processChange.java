public void processChange(InputFileDetails input,RecompilationSpec spec){
  JarArchive jarArchive=new JarArchive(input.getFile(),fileOperations.zipTree(input.getFile()));
  JarChangeDependentsFinder dependentsFinder=new JarChangeDependentsFinder(jarClasspathSnapshot,previousCompilation);
  DependentsSet actualDependents=dependentsFinder.getActualDependents(input,jarArchive);
  if (actualDependents.isDependencyToAll()) {
    spec.setFullRebuildCause(actualDependents.getDescription(),input.getFile());
    return;
  }
  spec.getClassNames().addAll(actualDependents.getDependentClasses());
}
