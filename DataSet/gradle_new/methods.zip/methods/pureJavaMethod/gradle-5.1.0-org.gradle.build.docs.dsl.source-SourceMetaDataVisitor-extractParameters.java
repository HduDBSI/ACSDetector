private void extractParameters(MethodDeclaration n,MethodMetaData method){
  for (  Parameter parameter : n.getParameters()) {
    TypeMetaData typeMetaData=extractTypeName(parameter.getType());
    if (parameter.isVarArgs()) {
      typeMetaData.setVarargs();
    }
    method.addParameter(parameter.getNameAsString(),typeMetaData);
  }
}
