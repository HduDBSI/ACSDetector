CachedIncludeFile get(String includePath){
  CachedIncludeFile includeFile=contents.get(includePath);
  if (includeFile != null) {
    return includeFile;
  }
  File candidate=new File(searchDir,includePath);
  HashCode contentHash=fileSystemSnapshotter.getRegularFileContentHash(candidate);
  includeFile=contentHash != null ? new SystemIncludeFile(candidate,includePath,contentHash) : MISSING_INCLUDE_FILE;
  contents.put(includePath,includeFile);
  return includeFile;
}
