@ComponentBinaries public void createCUnitTestBinaries(ModelMap<CUnitTestSuiteBinarySpec> binaries,CUnitTestSuiteSpec testSuite,@Path("buildDir") final File buildDir,final ServiceRegistry serviceRegistry,final ITaskFactory taskFactory){
  createNativeTestSuiteBinaries(binaries,testSuite,CUnitTestSuiteBinarySpec.class,"CUnitExe",buildDir,serviceRegistry);
}
