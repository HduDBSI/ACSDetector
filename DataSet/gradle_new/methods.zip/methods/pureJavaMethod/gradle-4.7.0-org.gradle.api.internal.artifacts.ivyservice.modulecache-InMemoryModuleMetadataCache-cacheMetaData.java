public CachedMetadata cacheMetaData(ModuleComponentRepository repository,final ModuleComponentIdentifier id,final ModuleComponentResolveMetadata metadata){
  LOGGER.debug("Recording module descriptor in cache: {} [changing = {}]",metadata.getId(),metadata.isChanging());
  final ModuleComponentAtRepositoryKey key=createKey(repository,id);
  ModuleMetadataCacheEntry entry=createEntry(metadata);
  DefaultCachedMetadata cachedMetaData=new DefaultCachedMetadata(entry,metadata,timeProvider);
  store(key,entry,cachedMetaData);
  return cachedMetaData;
}
