private void writeDependencyAccessor(String alias,String coordinates,@Nullable String context,boolean asProvider) throws IOException {
  String name=leafNodeForAlias(alias);
  writeLn("    /**");
  writeLn("     * Creates a dependency provider for " + name + " ("+ coordinates+ ")");
  if (context != null) {
    writeLn("     * This dependency was declared in " + context);
  }
  writeLn("     */");
  String methodName=asProvider ? "asProvider" : "get" + toJavaName(name);
  writeLn("    public Provider<MinimalExternalModuleDependency> " + methodName + "() { return create(\""+ alias+ "\"); }");
  writeLn();
}
