@Override public TaskOutputFilePropertyBuilder file(final Object path){
  return taskMutator.mutate("TaskOutputs.file(Object)",new Callable<TaskOutputFilePropertyBuilder>(){
    @Override public TaskOutputFilePropertyBuilder call(){
      StaticValue value=new StaticValue(path);
      DeclaredTaskOutputFileProperty outputFileSpec=specFactory.createOutputFileSpec(value);
      registeredFileProperties.add(outputFileSpec);
      return outputFileSpec;
    }
  }
);
}
