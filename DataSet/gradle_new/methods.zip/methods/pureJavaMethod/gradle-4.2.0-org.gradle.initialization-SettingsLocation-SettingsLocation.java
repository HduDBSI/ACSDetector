public SettingsLocation(File settingsDir,File settingsFile){
  this.settingsDir=settingsDir;
  TextResource settingsResource=new BasicTextResourceLoader().loadFile("settings file",settingsFile);
  this.settingsScriptSource=new TextResourceScriptSource(settingsResource);
}
