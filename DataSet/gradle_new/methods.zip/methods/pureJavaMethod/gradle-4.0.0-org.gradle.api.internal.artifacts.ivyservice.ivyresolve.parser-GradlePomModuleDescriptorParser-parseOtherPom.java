private PomReader parseOtherPom(DescriptorParseContext parseContext,ModuleComponentIdentifier parentId) throws IOException, SAXException {
  return parsePom(parseContext,parentId,Maps.<String,String>newHashMap());
}
