public MavenDependencyKey(String groupId,String artifactId,String type,String classifier){
  this.groupId=groupId;
  this.artifactId=artifactId;
  this.type=type;
  this.classifier=classifier;
}
