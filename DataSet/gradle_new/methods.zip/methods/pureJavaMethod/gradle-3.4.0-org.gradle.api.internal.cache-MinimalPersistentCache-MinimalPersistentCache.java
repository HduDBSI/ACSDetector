public MinimalPersistentCache(PersistentIndexedCache<K,V> cache){
  this.cache=cache;
}
