protected AbstractMutableModuleComponentResolveMetadata(ModuleComponentResolveMetadata metadata){
  this.componentId=metadata.getId();
  this.moduleVersionId=metadata.getModuleVersionId();
  this.changing=metadata.isChanging();
  this.missing=metadata.isMissing();
  this.statusScheme=metadata.getStatusScheme();
  this.moduleSources=MutableModuleSources.of(metadata.getSources());
  this.variants=metadata.getVariants();
  this.attributesFactory=metadata.getAttributesFactory();
  this.schema=metadata.getAttributesSchema();
  this.componentLevelAttributes=attributesFactory.mutable(metadata.getAttributes());
  this.variantDerivationStrategy=metadata.getVariantDerivationStrategy();
  this.variantMetadataRules=new VariantMetadataRules(attributesFactory,moduleVersionId);
}
