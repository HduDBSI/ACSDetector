@Override public StandardOutputCapture start(){
  super.start();
  if (!reset) {
    LogManager.getLogManager().reset();
    if (shouldReadLoggingConfigFile()) {
      try {
        LogManager.getLogManager().readConfiguration();
      }
 catch (      IOException error) {
        Logger.getLogger("").addHandler(new ConsoleHandler());
      }
    }
 else {
      Logger.getLogger("").addHandler(new ConsoleHandler());
    }
    reset=true;
  }
  return this;
}
