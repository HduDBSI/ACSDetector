private void validateIdentity(MavenNormalizedPublication publication){
  Model model=parsePomFileIntoMavenModel(publication);
  field(publication,"artifactId",publication.getArtifactId()).validMavenIdentifier().matches(model.getArtifactId());
  boolean hasParentPom=model.getParent() != null;
  MavenFieldValidator groupIdValidator=field(publication,"groupId",publication.getGroupId()).validMavenIdentifier();
  MavenFieldValidator versionValidator=field(publication,"version",publication.getVersion()).notEmpty().validInFileName();
  if (!hasParentPom) {
    groupIdValidator.matches(model.getGroupId());
    versionValidator.matches(model.getVersion());
  }
}
