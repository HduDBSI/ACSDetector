@Override public Action<DependencySubstitution> getRuleAction(){
  return Actions.composite(CollectionUtils.collect(ruleProviders,DependencySubstitutionRules::getRuleAction));
}
