public CustomCompilationUnit(CompilerConfiguration compilerConfiguration,CodeSource codeSource,final Action<? super ClassNode> customVerifier,GroovyClassLoader groovyClassLoader){
  super(compilerConfiguration,codeSource,groovyClassLoader);
  this.verifier=new Verifier(){
    public void visitClass(    ClassNode node){
      customVerifier.execute(node);
      super.visitClass(node);
    }
  }
;
  this.resolveVisitor=new GradleResolveVisitor(this,simpleNameToFQN);
}
