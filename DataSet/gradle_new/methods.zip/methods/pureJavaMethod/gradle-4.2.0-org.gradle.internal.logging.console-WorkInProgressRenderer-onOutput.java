@Override public void onOutput(OutputEvent event){
  queue.add(event);
  if (event instanceof UpdateNowEvent) {
    renderNow();
  }
 else   if (event instanceof EndOutputEvent) {
    progressArea.setVisible(false);
  }
  listener.onOutput(event);
}
