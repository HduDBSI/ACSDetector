DefaultPropertyMetadata(String fieldName,Method method,Class<? extends Annotation> propertyType,ImmutableMap<Class<? extends Annotation>,Annotation> annotations,ImmutableList<String> validationMessages){
  this.fieldName=fieldName;
  this.method=method;
  this.propertyType=propertyType;
  this.annotations=annotations;
  this.validationMessages=validationMessages;
}
