public DefaultVisualStudioSolution(ComponentSpecIdentifier componentIdentifier,DefaultVisualStudioProject rootProject,PathToFileResolver fileResolver,VisualStudioProjectResolver vsProjectResolver,Instantiator instantiator){
  super(componentIdentifier,VisualStudioSolution.class);
  this.rootProject=rootProject;
  this.vsProjectResolver=vsProjectResolver;
  this.solutionFile=instantiator.newInstance(SolutionFile.class,fileResolver,getName() + ".sln");
}
