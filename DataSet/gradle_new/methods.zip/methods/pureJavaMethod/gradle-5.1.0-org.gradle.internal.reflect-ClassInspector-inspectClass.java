private static void inspectClass(Class<?> type,MutableClassDetails classDetails){
  for (  Method method : type.getDeclaredMethods()) {
    classDetails.method(method);
    if (Modifier.isPrivate(method.getModifiers()) || Modifier.isStatic(method.getModifiers()) || method.isBridge()) {
      continue;
    }
    PropertyAccessorType accessorType=PropertyAccessorType.of(method);
    if (accessorType == PropertyAccessorType.GET_GETTER || accessorType == PropertyAccessorType.IS_GETTER) {
      String propertyName=accessorType.propertyNameFor(method);
      classDetails.property(propertyName).addGetter(method);
    }
 else     if (accessorType == PropertyAccessorType.SETTER) {
      String propertyName=accessorType.propertyNameFor(method);
      classDetails.property(propertyName).addSetter(method);
    }
 else {
      classDetails.instanceMethod(method);
    }
  }
}
