private void processAllTestClasses(){
  Launcher launcher=LauncherFactory.create();
  launcher.registerTestExecutionListeners(new JUnitPlatformTestExecutionListener(resultProcessor,clock,idGenerator));
  launcher.execute(createLauncherDiscoveryRequest(testClasses));
}
