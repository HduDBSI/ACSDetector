protected AbstractMutableModuleComponentResolveMetadata(ModuleComponentResolveMetadata metadata){
  this.descriptor=metadata.getDescriptor();
  this.componentId=metadata.getComponentId();
  this.id=metadata.getId();
  this.changing=metadata.isChanging();
  this.status=metadata.getStatus();
  this.statusScheme=metadata.getStatusScheme();
  this.moduleSource=metadata.getSource();
  this.configurationDefinitions=metadata.getConfigurationDefinitions();
  this.artifacts=metadata.getArtifacts();
  this.dependencies=metadata.getDependencies();
}
