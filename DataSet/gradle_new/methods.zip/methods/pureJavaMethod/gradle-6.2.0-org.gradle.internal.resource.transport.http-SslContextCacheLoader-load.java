@Override public SSLContext load(Map<String,String> props){
  try {
    TrustManagerFactory tmFactory=initTrustManagerFactory(props);
    KeyManagerFactory kmFactory=initKeyManagerFactory(props);
    SSLContext sslcontext=SSLContext.getInstance("TLS");
    sslcontext.init(kmFactory.getKeyManagers(),tmFactory.getTrustManagers(),null);
    return sslcontext;
  }
 catch (  GeneralSecurityException|IOException e) {
    throw new SSLInitializationException(e.getMessage(),e);
  }
}
