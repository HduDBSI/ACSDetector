@Inject public JavaBasePlugin(Instantiator instantiator,JavaToolChain javaToolChain,ITaskFactory taskFactory,ModelRegistry modelRegistry,ObjectFactory objectFactory){
  this.instantiator=instantiator;
  this.javaToolChain=javaToolChain;
  this.taskFactory=taskFactory;
  this.modelRegistry=modelRegistry;
  this.objectFactory=objectFactory;
}
