public CompositeTaskOutputPropertySpec(TaskOutputs taskOutputs,String taskName,FileResolver resolver,CacheableTaskOutputFilePropertySpec.OutputType outputType,Object[] paths){
  super(taskOutputs);
  this.taskName=taskName;
  this.resolver=resolver;
  this.outputType=outputType;
  this.paths=(paths != null && paths.length == 1) ? paths[0] : paths;
}
