@Override public void validateTypeMetadata(Class<?> classWithAnnotationAttached,TypeValidationContext visitor){
  if (!Task.class.isAssignableFrom(classWithAnnotationAttached)) {
    reportInvalidUseOfCacheableAnnotation(classWithAnnotationAttached,visitor,getAnnotationType(),Task.class);
  }
}
