public DefaultWorkerLease(String displayName,ResourceLockCoordinationService coordinationService,ResourceLockContainer owner,LeaseHolder parent,Thread ownerThread){
  super(displayName,coordinationService,owner);
  this.parent=parent;
  this.ownerThread=ownerThread;
}
