private boolean doesConsumerDependOnDestroyer(WorkInfo consumer,WorkInfo destroyer){
  if (consumer == destroyer) {
    return true;
  }
  Pair<WorkInfo,WorkInfo> workPair=Pair.of(consumer,destroyer);
  if (reachableCache.get(workPair) != null) {
    return reachableCache.get(workPair);
  }
  boolean reachable=false;
  for (  WorkInfo dependency : consumer.getAllSuccessors()) {
    if (!dependency.isComplete()) {
      if (doesConsumerDependOnDestroyer(dependency,destroyer)) {
        reachable=true;
      }
    }
  }
  reachableCache.put(workPair,reachable);
  return reachable;
}
