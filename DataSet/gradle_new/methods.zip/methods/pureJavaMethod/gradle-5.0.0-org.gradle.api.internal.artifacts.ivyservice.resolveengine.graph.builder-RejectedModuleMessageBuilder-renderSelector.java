static void renderSelector(StringBuilder sb,SelectorState selectorState){
  ResolvedVersionConstraint constraint=selectorState.getVersionConstraint();
  ModuleIdentifier moduleId=selectorState.getTargetModule().getId();
  sb.append('\'').append(moduleId.getGroup()).append(':').append(moduleId.getName());
  if (constraint.isRejectAll()) {
    sb.append("' rejects all versions");
    return;
  }
  VersionSelector requiredSelector=constraint.getRequiredSelector();
  VersionSelector rejectedSelector=constraint.getRejectedSelector();
  if (rejectedSelector instanceof InverseVersionSelector) {
    sb.append("' strictly '").append(requiredSelector.getSelector()).append("'");
    return;
  }
  if (requiredSelector != null) {
    sb.append(':').append(requiredSelector.getSelector());
  }
  sb.append("'");
  if (constraint.getPreferredSelector() != null) {
    sb.append(" prefers '").append(constraint.getPreferredSelector().getSelector()).append("'");
  }
  if (rejectedSelector == null) {
    return;
  }
  sb.append(" rejects ");
  if (rejectedSelector instanceof CompositeVersionSelector) {
    sb.append("any of \"");
    int i=0;
    for (    VersionSelector selector : ((CompositeVersionSelector)rejectedSelector).getSelectors()) {
      if (i++ > 0) {
        sb.append(", ");
      }
      sb.append('\'');
      sb.append(selector.getSelector());
      sb.append('\'');
    }
    sb.append("\"");
  }
 else {
    sb.append('\'');
    sb.append(rejectedSelector.getSelector());
    sb.append('\'');
  }
}
