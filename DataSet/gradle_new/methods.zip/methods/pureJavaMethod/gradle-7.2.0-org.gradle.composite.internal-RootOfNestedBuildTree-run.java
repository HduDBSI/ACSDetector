@Override public <T>T run(Function<? super BuildTreeLifecycleController,T> action){
  try {
    final GradleInternal gradle=buildLifecycleController.getGradle();
    ServiceRegistry services=gradle.getServices();
    BuildOperationExecutor executor=services.get(BuildOperationExecutor.class);
    return executor.call(new CallableBuildOperation<T>(){
      @Override public T call(      BuildOperationContext context){
        gradle.addBuildListener(new InternalBuildAdapter(){
          @Override public void settingsEvaluated(          Settings settings){
            buildName=settings.getRootProject().getName();
          }
        }
);
        T result=action.apply(buildTreeLifecycleController);
        context.setResult(new RunNestedBuildBuildOperationType.Result(){
        }
);
        return result;
      }
      @Override public BuildOperationDescriptor.Builder description(){
        return BuildOperationDescriptor.displayName("Run nested build").details(new RunNestedBuildBuildOperationType.Details(){
          @Override public String getBuildPath(){
            return gradle.getIdentityPath().getPath();
          }
        }
);
      }
    }
);
  }
  finally {
    CompositeStoppable.stoppable(buildLifecycleController,buildTree,session).stop();
  }
}
