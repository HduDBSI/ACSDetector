@Inject UsageDisambiguationRules(Usage javaApi,Usage javaApiJars,Usage javaApiClasses,Usage javaRuntime,Usage javaRuntimeJars,Usage javaRuntimeClasses,Usage javaRuntimeResources){
  this.javaApi=javaApi;
  this.javaApiJars=javaApiJars;
  this.javaApiClasses=javaApiClasses;
  this.apiVariants=ImmutableSet.of(javaApi,javaApiJars,javaApiClasses);
  this.javaRuntime=javaRuntime;
  this.javaRuntimeJars=javaRuntimeJars;
  this.javaRuntimeClasses=javaRuntimeClasses;
  this.javaRuntimeResources=javaRuntimeResources;
  this.runtimeVariants=ImmutableSet.of(javaRuntime,javaRuntimeJars,javaRuntimeClasses,javaRuntimeResources);
}
