public BuildStatusRenderer(OutputEventListener listener,StyledLabel buildStatusLabel,Console console,ConsoleMetaData consoleMetaData,Clock clock){
  this.listener=listener;
  this.buildStatusLabel=buildStatusLabel;
  this.console=console;
  this.consoleMetaData=consoleMetaData;
  this.clock=clock;
}
