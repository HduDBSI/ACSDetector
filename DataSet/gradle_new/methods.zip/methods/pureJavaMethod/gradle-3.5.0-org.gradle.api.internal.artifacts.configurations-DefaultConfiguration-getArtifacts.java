@Override public Set<ResolvedArtifactResult> getArtifacts(){
  return fileCollection.getSelectedArtifacts().collectArtifacts(new LinkedHashSet<ResolvedArtifactResult>());
}
