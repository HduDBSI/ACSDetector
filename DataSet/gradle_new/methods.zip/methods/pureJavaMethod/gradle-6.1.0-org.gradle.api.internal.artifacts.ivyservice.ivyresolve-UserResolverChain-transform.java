@Override public ModuleComponentResolveMetadata transform(RepositoryChainModuleResolution original){
  RepositoryChainModuleSource moduleSource=new RepositoryChainModuleSource(original.repository);
  ModuleSources originSources=original.module.getSources();
  ImmutableModuleSources mutated=ImmutableModuleSources.of(originSources,moduleSource);
  return original.module.withSources(mutated);
}
