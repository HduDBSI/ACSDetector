@Override protected <T>T newInstance(Constructor<T> constructor,ServiceLookup services,InstanceGenerator nested,@Nullable Describable displayName,Object[] params) throws InvocationTargetException, IllegalAccessException, InstantiationException {
  ObjectCreationDetails previous=SERVICES_FOR_NEXT_OBJECT.get();
  SERVICES_FOR_NEXT_OBJECT.set(new ObjectCreationDetails(nested,services,displayName));
  try {
    constructor.setAccessible(true);
    return constructor.newInstance(params);
  }
  finally {
    SERVICES_FOR_NEXT_OBJECT.set(previous);
  }
}
