@Override protected final void doAppend(String text){
  int max=text.length();
  int pos=0;
  int start=0;
  while (pos < max) {
    if (seenCharsFromEol == eolChars.length) {
      doStartLine();
      seenCharsFromEol=0;
    }
    if (seenCharsFromEol < eolChars.length && text.charAt(pos) == eolChars[seenCharsFromEol]) {
      seenCharsFromEol++;
      pos++;
      if (seenCharsFromEol == eolChars.length) {
        if (start < pos - seenCharsFromEol) {
          doLineText(text.substring(start,pos - seenCharsFromEol));
        }
        doEndLine(eol);
        start=pos;
      }
    }
 else {
      if (seenCharsFromEol > 0 && start == 0) {
        doLineText(eol.substring(0,seenCharsFromEol));
        start=pos;
      }
      seenCharsFromEol=0;
      pos++;
    }
  }
  if (start < pos - seenCharsFromEol) {
    doLineText(text.substring(start,pos - seenCharsFromEol));
  }
}
