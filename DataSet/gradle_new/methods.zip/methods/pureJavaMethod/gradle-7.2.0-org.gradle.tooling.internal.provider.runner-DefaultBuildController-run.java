@Override public void run(BuildOperationContext context){
  try {
    T value=action.get();
    result=Try.successful(value);
  }
 catch (  Throwable t) {
    result=Try.failure(t);
  }
}
