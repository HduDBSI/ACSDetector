@Override public void applyConventionMappingToSetMethod(PropertyMetadata property,Method setter){
  if (!mixInDsl || !conventionAware) {
    return;
  }
  addConventionSetter(setter,property);
}
