@Override public void configureTask(Task task,BinarySpec binary,LanguageSourceSet sourceSet,ServiceRegistry serviceRegistry){
  final PlatformJavaCompile compile=(PlatformJavaCompile)task;
  JavaSourceSet javaSourceSet=(JavaSourceSet)sourceSet;
  JvmAssembly assembly=((WithJvmAssembly)binary).getAssembly();
  assembly.builtBy(compile);
  compile.setDescription("Compiles " + javaSourceSet + ".");
  compile.getDestinationDirectory().set(conventionalCompilationOutputDirFor(assembly));
  compile.dependsOn(javaSourceSet);
  compile.setSource(javaSourceSet.getSource());
  JavaPlatform targetPlatform=assembly.getTargetPlatform();
  String targetCompatibility=targetPlatform.getTargetCompatibility().toString();
  compile.setPlatform(targetPlatform);
  compile.setToolChain(assembly.getToolChain());
  compile.setTargetCompatibility(targetCompatibility);
  compile.setSourceCompatibility(targetCompatibility);
  SourceSetDependencyResolvingClasspath classpath=classpathFor(binary,javaSourceSet,serviceRegistry,schemaStore);
  compile.setClasspath(classpath);
}
