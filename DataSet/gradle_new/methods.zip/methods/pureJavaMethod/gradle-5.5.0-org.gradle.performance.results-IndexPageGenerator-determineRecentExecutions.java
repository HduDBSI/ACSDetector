private List<ExecutionData> determineRecentExecutions(List<ExecutionData> executions){
  List<ExecutionData> executionsOfSameCommit=executions.stream().filter(this::sameCommit).collect(toList());
  if (executionsOfSameCommit.isEmpty()) {
    return executions;
  }
 else {
    return executionsOfSameCommit;
  }
}
