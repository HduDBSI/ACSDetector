@Override public List<ResolvedVariantResult> getResolvedVariants(){
  List<ResolvedVariantResult> result=null;
  ResolvedVariantResult cur=null;
  for (  NodeState node : nodes) {
    if (node.isSelected()) {
      ResolvedVariantResult details=node.getResolvedVariant();
      if (result != null) {
        result.add(details);
      }
 else       if (cur != null) {
        result=Lists.newArrayList();
        result.add(cur);
        result.add(details);
      }
 else {
        cur=details;
      }
    }
  }
  if (result != null) {
    return result;
  }
  if (cur != null) {
    return Collections.singletonList(cur);
  }
  return Collections.emptyList();
}
