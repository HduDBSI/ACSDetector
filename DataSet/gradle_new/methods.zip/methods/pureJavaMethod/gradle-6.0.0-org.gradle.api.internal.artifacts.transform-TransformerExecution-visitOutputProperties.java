@Override public void visitOutputProperties(OutputPropertyVisitor visitor){
  visitor.visitOutputProperty(OUTPUT_DIRECTORY_PROPERTY_NAME,TreeType.DIRECTORY,workspace.getOutputDirectory());
  visitor.visitOutputProperty(RESULTS_FILE_PROPERTY_NAME,TreeType.FILE,workspace.getResultsFile());
}
