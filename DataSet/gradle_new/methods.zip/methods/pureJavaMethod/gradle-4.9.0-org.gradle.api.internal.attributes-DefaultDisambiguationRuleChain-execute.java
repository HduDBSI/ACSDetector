@Override public void execute(MultipleCandidatesResult<T> details){
  for (  Action<? super MultipleCandidatesDetails<T>> rule : rules) {
    rule.execute(details);
    if (details.hasResult()) {
      return;
    }
  }
}
