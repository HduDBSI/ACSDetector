ClassPath createBuildSourceClasspath(final StartParameter startParameter){
  assert startParameter.getCurrentDir() != null && startParameter.getBuildFile() == null;
  LOGGER.debug("Starting to build the build sources.");
  if (!startParameter.getCurrentDir().isDirectory()) {
    LOGGER.debug("Gradle source dir does not exist. We leave.");
    return new DefaultClassPath();
  }
  return buildOperationExecutor.call(new CallableBuildOperation<ClassPath>(){
    @Override public ClassPath call(    BuildOperationContext context){
      return buildBuildSrc(startParameter);
    }
    @Override public BuildOperationDescriptor.Builder description(){
      return BuildOperationDescriptor.displayName("Build buildSrc").progressDisplayName("buildSrc");
    }
  }
);
}
