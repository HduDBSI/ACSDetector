private DefaultMavenModuleResolveMetadata(DefaultMavenModuleResolveMetadata metadata,ModuleSource source){
  super(metadata,source);
  packaging=metadata.getPackaging();
  relocated=metadata.isRelocated();
  snapshotTimestamp=metadata.getSnapshotTimestamp();
}
