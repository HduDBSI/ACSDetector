/** 
 * Initializes the native services to use the given user home directory to store native libs and other resources. Does nothing if already initialized.
 * @param requestedFeatures Whether to initialize additional native libraries like jansi and file-events.
 */
private void initialize(File userHomeDir,EnumSet<NativeFeatures> requestedFeatures){
  if (!initialized) {
    try {
      initializeNativeIntegrations(userHomeDir);
      initialized=true;
      initializeFeatures(requestedFeatures);
    }
 catch (    RuntimeException e) {
      throw new ServiceCreationException("Could not initialize native services.",e);
    }
  }
}
