@Override public void run(BuildAction action,final BuildController buildController){
  if (!(action instanceof ClientProvidedBuildAction)) {
    return;
  }
  final GradleInternal gradle=buildController.getGradle();
  gradle.getStartParameter().setConfigureOnDemand(false);
  ClientProvidedBuildAction clientProvidedBuildAction=(ClientProvidedBuildAction)action;
  PayloadSerializer payloadSerializer=getPayloadSerializer(gradle);
  final Object clientAction=payloadSerializer.deserialize(clientProvidedBuildAction.getAction());
  gradle.addBuildListener(new BuildAdapter(){
    @Override public void buildFinished(    BuildResult result){
      if (result.getFailure() == null) {
        buildController.setResult(buildResult(clientAction,gradle));
      }
    }
  }
);
  if (clientProvidedBuildAction.isRunTasks()) {
    buildController.run();
  }
 else {
    buildController.configure();
  }
}
