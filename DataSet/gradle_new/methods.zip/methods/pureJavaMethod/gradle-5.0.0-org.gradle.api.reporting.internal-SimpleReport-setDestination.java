@Override public void setDestination(Provider<File> provider){
  this.destination.set(provider);
}
