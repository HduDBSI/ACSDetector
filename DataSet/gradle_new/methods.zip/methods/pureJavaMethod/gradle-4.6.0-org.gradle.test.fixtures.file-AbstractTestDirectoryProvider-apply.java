public Statement apply(final Statement base,Description description){
  init(description.getMethodName(),description.getTestClass().getSimpleName());
  return new TestDirectoryCleaningStatement(base,description);
}
