public void apply(ProjectInternal project){
  project.getPluginManager().apply(BasePlugin.class);
  project.getPluginManager().apply(ReportingBasePlugin.class);
  JavaPluginConvention javaConvention=new JavaPluginConvention(project,instantiator);
  project.getConvention().getPlugins().put("java",javaConvention);
  configureSourceSetDefaults(javaConvention);
  configureCompileDefaults(project,javaConvention);
  configureJavaDoc(project,javaConvention);
  configureTest(project,javaConvention);
  configureBuildNeeded(project);
  configureBuildDependents(project);
  configureSchema(project);
  bridgeToSoftwareModelIfNecessary(project);
}
