public DefaultJavaFeatureSpec(String name,Capability defaultCapability,JavaPluginConvention javaPluginConvention,JavaPluginExtension javaPluginExtension,ConfigurationContainer configurationContainer,ObjectFactory objectFactory,SoftwareComponentContainer components,TaskContainer tasks){
  this.name=name;
  this.javaPluginConvention=javaPluginConvention;
  this.javaPluginExtension=javaPluginExtension;
  this.configurationContainer=configurationContainer;
  this.objectFactory=objectFactory;
  this.components=components;
  this.tasks=tasks;
  this.capabilities.add(defaultCapability);
}
