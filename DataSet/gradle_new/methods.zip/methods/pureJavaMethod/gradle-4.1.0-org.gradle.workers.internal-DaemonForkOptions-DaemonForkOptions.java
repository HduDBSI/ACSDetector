DaemonForkOptions(JavaForkOptionsInternal forkOptions,Iterable<File> classpath,Iterable<String> sharedPackages,KeepAliveMode keepAliveMode){
  this.forkOptions=forkOptions;
  this.classpath=classpath;
  this.sharedPackages=sharedPackages;
  this.keepAliveMode=keepAliveMode;
}
