private ImmutableList<? extends ModuleComponentArtifactMetadata> getArtifactsForConfiguration(){
  return RealisedMavenModuleResolveMetadata.getArtifactsForConfiguration(this);
}
