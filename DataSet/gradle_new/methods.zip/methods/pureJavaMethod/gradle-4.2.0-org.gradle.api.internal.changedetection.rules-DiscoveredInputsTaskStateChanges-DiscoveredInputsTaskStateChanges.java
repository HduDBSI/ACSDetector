public DiscoveredInputsTaskStateChanges(@Nullable TaskExecution previous,TaskExecution current){
  this.previous=previous;
  this.current=current;
}
