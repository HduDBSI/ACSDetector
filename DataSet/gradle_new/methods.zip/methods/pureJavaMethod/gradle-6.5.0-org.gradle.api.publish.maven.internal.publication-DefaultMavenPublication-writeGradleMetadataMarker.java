@Override public boolean writeGradleMetadataMarker(){
  return canPublishModuleMetadata() && moduleMetadataArtifact != null && moduleMetadataArtifact.isEnabled();
}
