/** 
 * Returns Java statements to get the given resource.
 */
public String callFromBuild(String resource){
  return callFromBuildUsingExpression("\"" + resource + "\"");
}
