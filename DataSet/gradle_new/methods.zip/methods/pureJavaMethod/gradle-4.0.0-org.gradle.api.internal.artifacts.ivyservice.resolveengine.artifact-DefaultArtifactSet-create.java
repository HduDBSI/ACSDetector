public File create(){
  DefaultBuildableArtifactResolveResult result=new DefaultBuildableArtifactResolveResult();
  artifactResolver.resolveArtifact(artifact,moduleSource,result);
  return result.getResult();
}
