void flushLineText(){
  if (start < pos) {
    String data="";
    if (start < 0 && pos >= 0) {
      data=eol.substring(0,Math.abs(start)) + text.substring(0,pos);
    }
 else     if (start >= 0) {
      data=text.substring(start,pos);
    }
    if (data.length() > 0) {
      doLineText(data);
    }
  }
}
