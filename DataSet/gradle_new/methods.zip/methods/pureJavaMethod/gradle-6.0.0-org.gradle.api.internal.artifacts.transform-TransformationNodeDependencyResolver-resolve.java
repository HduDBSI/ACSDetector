@Override public boolean resolve(Task task,Object node,Action<? super Node> resolveAction){
  if (node instanceof DefaultTransformationDependency) {
    DefaultTransformationDependency transformation=(DefaultTransformationDependency)node;
    for (    TransformationNode transformationNode : transformation.getNodes()) {
      resolveAction.execute(transformationNode);
    }
    return true;
  }
  return false;
}
