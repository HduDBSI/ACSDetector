@ComponentBinaries public void createCUnitTestBinaries(ModelMap<CUnitTestSuiteBinarySpec> binaries,CUnitTestSuiteSpec testSuite,@Path("buildDir") final File buildDir,final ServiceRegistry serviceRegistry){
  createNativeTestSuiteBinaries(binaries,testSuite,CUnitTestSuiteBinarySpec.class,"CUnitExe",buildDir,serviceRegistry);
}
