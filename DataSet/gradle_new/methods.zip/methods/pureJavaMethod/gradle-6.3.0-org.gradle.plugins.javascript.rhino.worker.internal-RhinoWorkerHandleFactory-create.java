<T>T create(Iterable<File> rhinoClasspath,Class<T> protocolType,Class<? extends T> workerImplementationType,LogLevel logLevel,File workingDir);
