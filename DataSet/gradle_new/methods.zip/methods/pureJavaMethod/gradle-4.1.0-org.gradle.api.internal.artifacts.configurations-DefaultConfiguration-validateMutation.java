public void validateMutation(MutationType type){
  preventIllegalMutation(type);
  markAsModifiedAndNotifyChildren(type);
}
