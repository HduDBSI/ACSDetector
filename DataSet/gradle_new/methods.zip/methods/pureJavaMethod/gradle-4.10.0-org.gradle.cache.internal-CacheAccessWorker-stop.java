public synchronized void stop(){
  if (!closed && !workerCompleted) {
    closed=true;
    try {
      workQueue.put(new ShutdownOperationsCommand());
    }
 catch (    InterruptedException e) {
    }
    try {
      doneSignal.await();
    }
 catch (    InterruptedException e) {
    }
  }
  rethrowFailure();
}
