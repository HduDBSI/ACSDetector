private void performIncrementalCompilation(InputChanges inputs,DefaultJavaCompileSpec spec){
  boolean isUsingCliCompiler=isUsingCliCompiler(spec);
  spec.getCompileOptions().setSupportsCompilerApi(!isUsingCliCompiler);
  spec.getCompileOptions().setSupportsConstantAnalysis(!isUsingCliCompiler);
  spec.getCompileOptions().setPreviousCompilationDataFile(getPreviousCompilationData());
  Compiler<JavaCompileSpec> compiler=createCompiler();
  compiler=makeIncremental(inputs,(CleaningJavaCompiler<JavaCompileSpec>)compiler,getStableSources());
  performCompilation(spec,compiler);
}
