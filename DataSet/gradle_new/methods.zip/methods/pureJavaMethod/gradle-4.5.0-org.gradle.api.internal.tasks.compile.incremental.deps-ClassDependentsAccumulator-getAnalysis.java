public ClassSetAnalysisData getAnalysis(){
  return new ClassSetAnalysisData(filePathToClassName,getDependentsMap(),getClassesToConstants(),parentToChildren);
}
