private void configureBuildDependents(Project project){
  project.getTasks().register(BUILD_DEPENDENTS_TASK_NAME,new Action<Task>(){
    @Override public void execute(    Task buildTask){
      buildTask.setDescription("Assembles and tests this project and all projects that depend on it.");
      buildTask.setGroup(BasePlugin.BUILD_GROUP);
      buildTask.dependsOn(BUILD_TASK_NAME);
      boolean hasIncludedBuilds=!buildTask.getProject().getGradle().getIncludedBuilds().isEmpty();
      buildTask.doFirst(new Action<Task>(){
        @Override public void execute(        Task task){
          if (hasIncludedBuilds) {
            task.getLogger().warn("[composite-build] Warning: `" + task.getPath() + "` task does not build included builds.");
          }
        }
      }
);
    }
  }
);
}
