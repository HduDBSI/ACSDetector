public RecompileScriptsOption(){
  super(null,CommandLineOptionConfiguration.create(LONG_OPTION,"Force build script recompiling.").deprecated());
}
