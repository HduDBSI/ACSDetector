private boolean resolveFromDefaultImports(ClassNode type,boolean testDefaultImports){
  testDefaultImports&=!type.hasPackageName();
  testDefaultImports&=!(type instanceof LowerCaseClass);
  if (testDefaultImports) {
    String name=type.getName();
    List<String> fqn=simpleNameToFQN.get(type.getName());
    if (fqn != null) {
      if (resolveFromResolver(type,fqn.get(0))) {
        return true;
      }
    }
    for (    String packagePrefix : DEFAULT_IMPORTS) {
      ConstructedClassWithPackage tmp=new ConstructedClassWithPackage(packagePrefix,name);
      if (resolve(tmp,false,false,false)) {
        type.setRedirect(tmp.redirect());
        return true;
      }
    }
    if (TYPE_REDIRECT_MAPPING.containsKey(name)) {
      type.setRedirect(TYPE_REDIRECT_MAPPING.get(name));
      return true;
    }
  }
  return false;
}
