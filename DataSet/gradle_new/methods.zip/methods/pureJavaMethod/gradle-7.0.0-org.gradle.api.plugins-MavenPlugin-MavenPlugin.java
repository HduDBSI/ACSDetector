@Inject public MavenPlugin(DocumentationRegistry documentationRegistry){
  this.documentationRegistry=documentationRegistry;
}
