public LocalClassSetAnalysisStore(String taskPath,PersistentIndexedCache<String,ClassSetAnalysisData> cache){
  this.taskPath=taskPath;
  this.cache=cache;
}
