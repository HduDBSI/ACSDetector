public DefaultArtifactSet(ComponentIdentifier componentIdentifier,ModuleVersionIdentifier ownerId,ModuleSource moduleSource,ModuleExclusion exclusions,Set<? extends VariantMetadata> variants,ArtifactResolver artifactResolver,Map<ComponentArtifactIdentifier,ResolvedArtifact> allResolvedArtifacts,long id,ImmutableAttributesFactory attributesFactory,BuildOperationExecutor buildOperationExecutor){
  this.componentIdentifier=componentIdentifier;
  this.moduleVersionIdentifier=ownerId;
  this.moduleSource=moduleSource;
  this.exclusions=exclusions;
  this.variants=variants;
  this.artifactResolver=artifactResolver;
  this.allResolvedArtifacts=allResolvedArtifacts;
  this.id=id;
  this.attributesFactory=attributesFactory;
  this.buildOperationExecutor=buildOperationExecutor;
}
