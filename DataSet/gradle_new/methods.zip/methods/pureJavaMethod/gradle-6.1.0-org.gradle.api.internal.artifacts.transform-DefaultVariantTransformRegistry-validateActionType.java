private static <T>void validateActionType(@Nullable Class<T> actionType){
  if (actionType == null) {
    throw new IllegalArgumentException("An artifact transform action type must be provided.");
  }
}
