public void publish(List<ModuleVersionPublisher> publishResolvers,IvyModulePublishMetadata publishMetaData){
  DefaultIvyModulePublishMetadata publication=new DefaultIvyModulePublishMetadata(publishMetaData);
  for (  IvyModuleArtifactPublishMetadata artifact : publishMetaData.getArtifacts()) {
    addPublishedArtifact(artifact,publication);
  }
  for (  ModuleVersionPublisher publisher : publishResolvers) {
    LOGGER.info("Publishing to {}",publisher);
    publisher.publish(publication);
  }
}
