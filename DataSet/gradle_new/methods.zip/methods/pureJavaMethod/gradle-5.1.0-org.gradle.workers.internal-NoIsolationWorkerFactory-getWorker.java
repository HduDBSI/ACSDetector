@Override public Worker getWorker(final DaemonForkOptions forkOptions){
  final WorkerExecutor workerExecutor=this.workerExecutor;
  return new AbstractWorker(buildOperationExecutor){
    @Override public DefaultWorkResult execute(    ActionExecutionSpec spec,    BuildOperationRef parentBuildOperation){
      return executeWrappedInBuildOperation(spec,parentBuildOperation,new Work(){
        @Override public DefaultWorkResult execute(        ActionExecutionSpec spec){
          DefaultWorkResult result;
          try {
            WorkerProtocol workerServer=new DefaultWorkerServer(actionInstantiator);
            result=workerServer.execute(spec);
          }
  finally {
            workerExecutor.await();
          }
          return result;
        }
      }
);
    }
  }
;
}
