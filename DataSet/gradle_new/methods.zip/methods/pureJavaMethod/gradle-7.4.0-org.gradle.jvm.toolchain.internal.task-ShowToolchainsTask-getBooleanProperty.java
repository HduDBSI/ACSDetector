private Boolean getBooleanProperty(String propertyKey){
  return getProviderFactory().gradleProperty(propertyKey).map(Boolean::parseBoolean).getOrElse(true);
}
