public ClassLoaderStructure getWorkerProcessClassLoaderStructure(final Iterable<File> additionalClasspath,Class<?>... classes){
  MixInLegacyTypesClassLoader.Spec workerExtensionSpec=classLoaderRegistry.getGradleWorkerExtensionSpec();
  FilteringClassLoader.Spec gradleApiFilter=classLoaderRegistry.getGradleApiFilterSpec();
  VisitableURLClassLoader.Spec userSpec=getUserSpec("worker-loader",additionalClasspath,classes);
  return new HierarchicalClassLoaderStructure(workerExtensionSpec).withChild(gradleApiFilter).withChild(userSpec);
}
