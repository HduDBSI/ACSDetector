protected abstract void generate(InitSettings settings,BuildScriptBuilder buildScriptBuilder);
