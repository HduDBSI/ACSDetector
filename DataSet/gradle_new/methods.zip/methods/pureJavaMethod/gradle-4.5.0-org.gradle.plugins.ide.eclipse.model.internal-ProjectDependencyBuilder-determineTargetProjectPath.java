private String determineTargetProjectPath(ProjectComponentIdentifier id){
  return "/" + determineTargetProjectName(id);
}
