@Override public void visitDependencies(TaskDependencyResolveContext context){
  context.add(new FinalizeAction(){
    @Override public TaskDependencyContainer getDependencies(){
      return buildDependencies;
    }
    @Override public void execute(    Task task){
      if (isResolveSynchronously()) {
        try {
          getFile();
        }
 catch (        Exception e) {
        }
      }
    }
  }
);
}
