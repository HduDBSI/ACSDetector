protected Result runClientAction(ClientAction action,BuildTreeLifecycleController buildController){
  GradleInternal gradle=buildController.getGradle();
  ActionRunningListener listener=new ActionRunningListener(action,payloadSerializer);
  try {
    gradle.addBuildListener(listener);
    ActionResults actionResults=buildController.fromBuildModel(action.isRunTasks(),listener);
    listener.maybeApplyResult(actionResults);
    return Result.of(action.getResult());
  }
 catch (  RuntimeException e) {
    RuntimeException clientFailure=e;
    if (listener.actionFailure != null) {
      clientFailure=new InternalBuildActionFailureException(listener.actionFailure);
    }
    return Result.failed(e,clientFailure);
  }
}
