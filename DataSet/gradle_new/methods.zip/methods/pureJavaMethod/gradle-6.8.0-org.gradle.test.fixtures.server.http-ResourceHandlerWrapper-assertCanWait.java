@Override public void assertCanWait() throws IllegalStateException {
  lock.lock();
  try {
    owner.assertCanWait();
    if (!autoRelease && !started) {
      throw new IllegalStateException(String.format("Cannot wait as request %s has not been released yet.",getDisplayName()));
    }
  }
  finally {
    lock.unlock();
  }
}
