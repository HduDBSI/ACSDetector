@Override public void run(NodeExecutionContext context){
  FileCollectionFingerprinterRegistry fingerprinterRegistry=context.getService(FileCollectionFingerprinterRegistry.class);
  isolateTransformerParameters(fingerprinterRegistry);
}
