@Override public boolean equals(Object o){
  if (this == o) {
    return true;
  }
  if (!(o instanceof DefaultArtifactIdentifier)) {
    return false;
  }
  DefaultArtifactIdentifier that=(DefaultArtifactIdentifier)o;
  if (!Objects.equals(classifier,that.classifier)) {
    return false;
  }
  if (!Objects.equals(extension,that.extension)) {
    return false;
  }
  if (!Objects.equals(moduleVersionIdentifier,that.moduleVersionIdentifier)) {
    return false;
  }
  if (!Objects.equals(name,that.name)) {
    return false;
  }
  return Objects.equals(type,that.type);
}
