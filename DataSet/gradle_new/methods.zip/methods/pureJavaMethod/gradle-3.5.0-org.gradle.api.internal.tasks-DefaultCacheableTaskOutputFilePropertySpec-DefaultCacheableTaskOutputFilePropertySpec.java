public DefaultCacheableTaskOutputFilePropertySpec(TaskOutputs taskOutputs,String taskName,FileResolver resolver,OutputType outputType,Object path){
  super(taskOutputs);
  this.resolver=resolver;
  this.outputType=outputType;
  this.path=path;
  this.files=new TaskPropertyFileCollection(taskName,"output",this,resolver,path);
}
