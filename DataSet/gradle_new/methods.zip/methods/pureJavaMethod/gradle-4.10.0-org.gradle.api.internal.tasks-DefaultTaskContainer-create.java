public <T extends Task>T create(String name,Class<T> type,Action<? super T> configuration) throws InvalidUserDataException {
  T task=create(name,type);
  configuration.execute(task);
  return task;
}
