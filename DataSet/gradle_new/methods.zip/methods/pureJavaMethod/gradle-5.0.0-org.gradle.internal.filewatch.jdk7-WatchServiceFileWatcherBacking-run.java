@Override public void run(){
  if (!stopped.get()) {
    pollerThreadReference.set(new SoftReference<Thread>(Thread.currentThread()));
    running.set(true);
    try {
      try {
        pumpEvents();
      }
 catch (      InterruptedException e) {
        Thread.currentThread().interrupt();
      }
catch (      Throwable t) {
        if (!(Throwables.getRootCause(t) instanceof InterruptedException)) {
          stop();
          onError.execute(t);
        }
      }
    }
  finally {
      stop();
    }
  }
}
