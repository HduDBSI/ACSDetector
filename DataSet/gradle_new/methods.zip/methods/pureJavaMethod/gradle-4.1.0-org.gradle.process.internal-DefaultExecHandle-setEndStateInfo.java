private void setEndStateInfo(ExecHandleState newState,int exitValue,Throwable failureCause){
  ShutdownHookActionRegister.removeAction(shutdownHookAction);
  ExecHandleState currentState;
  ExecResultImpl result;
  lock.lock();
  try {
    currentState=this.state;
    setState(newState);
    execResult=new ExecResultImpl(exitValue,execExceptionFor(failureCause,currentState),displayName);
    result=execResult;
  }
  finally {
    lock.unlock();
  }
  LOGGER.debug("Process '{}' finished with exit value {} (state: {})",displayName,exitValue,newState);
  if (currentState != ExecHandleState.DETACHED && newState != ExecHandleState.DETACHED) {
    broadcast.getSource().executionFinished(this,result);
  }
  executor.requestStop();
}
