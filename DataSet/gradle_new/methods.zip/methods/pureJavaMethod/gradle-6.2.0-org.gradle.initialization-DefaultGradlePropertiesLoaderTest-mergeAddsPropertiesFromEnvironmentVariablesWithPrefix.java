@Test public void mergeAddsPropertiesFromEnvironmentVariablesWithPrefix(){
  envProperties=GUtil.map(ENV_PROJECT_PROPERTIES_PREFIX + "envProp","env value","ignoreMe","ignored");
  Map<String,String> properties=loadAndMergePropertiesWith(emptyMap());
  assertEquals("env value",properties.get("envProp"));
}
