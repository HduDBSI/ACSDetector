@Override public void resolveComponentMetaData(final ModuleComponentIdentifier moduleComponentIdentifier,final ComponentOverrideMetadata requestMetaData,final BuildableModuleComponentMetaDataResolveResult result){
  cacheLockingManager.longRunningOperation(new Runnable(){
    public void run(){
      delegate.resolveComponentMetaData(moduleComponentIdentifier,requestMetaData,result);
    }
  }
);
}
