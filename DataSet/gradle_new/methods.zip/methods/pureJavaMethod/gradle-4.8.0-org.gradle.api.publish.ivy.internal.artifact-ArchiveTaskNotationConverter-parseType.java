@Override protected IvyArtifact parseType(AbstractArchiveTask archiveTask){
  return instantiator.newInstance(ArchiveTaskBasedIvyArtifact.class,archiveTask,publicationIdentity);
}
