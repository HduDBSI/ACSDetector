@Nullable @Override IncludeFile searchForDependency(String includePath,boolean quotedPath){
  CachedIncludeFile includeFile=cachedLookups.get(includePath);
  if (includeFile == null) {
    for (    DirectoryContents dir : directories) {
      includeFile=dir.get(includePath);
      if (includeFile.getType() == FileType.RegularFile) {
        break;
      }
    }
    if (includeFile == null) {
      includeFile=MISSING_INCLUDE_FILE;
    }
    cachedLookups.put(includePath,includeFile);
  }
  if (includeFile.getType() == FileType.RegularFile) {
    return includeFile.toIncludeFile(quotedPath);
  }
  return null;
}
