@Override protected GradleHandle createGradleHandle(){
  configureConsoleCommandLineArgs();
  return super.createGradleHandle();
}
