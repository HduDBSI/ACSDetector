@Override public TaskOutputFilePropertyBuilder file(final Object path){
  return taskMutator.mutate("TaskOutputs.file(Object)",new Callable<TaskOutputFilePropertyBuilder>(){
    @Override public TaskOutputFilePropertyBuilder call() throws Exception {
      return addSpec(new DefaultCacheableTaskOutputFilePropertySpec(task.getName(),resolver,OutputType.FILE,path));
    }
  }
);
}
