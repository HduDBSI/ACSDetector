public DefaultProjectsPreparer(ProjectConfigurer projectConfigurer,BuildStateRegistry buildRegistry,BuildLoader buildLoader,ModelConfigurationListener modelConfigurationListener,BuildOperationExecutor buildOperationExecutor){
  this.projectConfigurer=projectConfigurer;
  this.buildRegistry=buildRegistry;
  this.buildLoader=buildLoader;
  this.modelConfigurationListener=modelConfigurationListener;
  this.buildOperationExecutor=buildOperationExecutor;
}
