private void handleFailedDelete(File file){
  if (isRunGcOnFailedDelete()) {
    System.gc();
  }
  try {
    Thread.sleep(DELETE_RETRY_SLEEP_MILLIS);
  }
 catch (  InterruptedException ex) {
  }
  if (!file.delete() && file.exists()) {
    throw new UnableToDeleteFileException(file);
  }
}
