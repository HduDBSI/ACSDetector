@Override public void getAll(Class<?> serviceType,List<Service> result){
  if (parent instanceof DefaultServiceRegistry) {
    ((DefaultServiceRegistry)parent).collectServices(serviceType,result);
    return;
  }
  List<?> services=parent.getAll(serviceType);
  for (  Object service : services) {
    result.add(instanceToService(service));
  }
}
