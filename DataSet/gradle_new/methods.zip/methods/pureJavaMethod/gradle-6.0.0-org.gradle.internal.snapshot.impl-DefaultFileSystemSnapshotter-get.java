@Nullable @Override public HashCode get(){
  InternableString internableAbsolutePath=new InternableString(absolutePath);
  FileMetadataSnapshot metadata=statAndCache(internableAbsolutePath,file);
  if (metadata.getType() != FileType.RegularFile) {
    return null;
  }
  FileSystemLocationSnapshot snapshot=snapshotAndCache(internableAbsolutePath,file,metadata,null);
  return snapshot.getHash();
}
