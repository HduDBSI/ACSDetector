@Override public BuildActionParameters read(Decoder decoder) throws Exception {
  File currentDir=FILE_SERIALIZER.read(decoder);
  Map<String,String> sysProperties=NO_NULL_STRING_MAP_SERIALIZER.read(decoder);
  Map<String,String> envVariables=NO_NULL_STRING_MAP_SERIALIZER.read(decoder);
  LogLevel logLevel=logLevelSerializer.read(decoder);
  boolean useDaemon=decoder.readBoolean();
  boolean continuous=decoder.readBoolean();
  ClassPath classPath=DefaultClassPath.of(classPathSerializer.read(decoder));
  return new DefaultBuildActionParameters(sysProperties,envVariables,currentDir,logLevel,useDaemon,continuous,classPath);
}
