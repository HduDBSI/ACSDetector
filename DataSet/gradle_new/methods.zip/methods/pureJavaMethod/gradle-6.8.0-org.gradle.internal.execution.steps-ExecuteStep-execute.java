@Override public Result execute(UnitOfWork work,C context){
  return buildOperationExecutor.call(new CallableBuildOperation<Result>(){
    @Override public Result call(    BuildOperationContext operationContext){
      Result result=executeOperation(work,context);
      operationContext.setResult(Operation.Result.INSTANCE);
      return result;
    }
    @Override public BuildOperationDescriptor.Builder description(){
      return BuildOperationDescriptor.displayName("Executing " + work.getDisplayName()).details(Operation.Details.INSTANCE);
    }
  }
);
}
