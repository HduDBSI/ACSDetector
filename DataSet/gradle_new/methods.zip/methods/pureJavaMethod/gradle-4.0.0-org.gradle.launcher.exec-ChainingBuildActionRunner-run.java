@Override public void run(BuildAction action,BuildController buildController){
  for (  BuildActionRunner runner : runners) {
    runner.run(action,buildController);
    if (buildController.hasResult()) {
      return;
    }
  }
}
