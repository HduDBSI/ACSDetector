@Override public void withResource(String relativePath,Action<? super InputStream> action){
  ExternalResourceName location=new ExternalResourceName(rootUri,relativePath);
  LocallyAvailableExternalResource resource=resourceResolver.resolveResource(location);
  if (resource != null) {
    resource.withContent(action);
  }
}
