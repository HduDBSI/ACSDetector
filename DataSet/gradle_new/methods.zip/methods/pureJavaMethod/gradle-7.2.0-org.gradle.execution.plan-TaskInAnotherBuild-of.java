public static TaskInAnotherBuild of(String taskPath,BuildIdentifier targetBuild,IncludedBuildTaskGraph taskGraph){
  IncludedBuildTaskResource taskResource=taskGraph.locateTask(targetBuild,taskPath);
  Path taskIdentityPath=Path.path(targetBuild.getName()).append(Path.path(taskPath));
  return new TaskInAnotherBuild(taskIdentityPath,taskPath,targetBuild,taskResource);
}
