private void detectOverlappingOutputs(){
  for (  Map.Entry<String,FileCollectionSnapshot> entry : getCurrent().entrySet()) {
    String propertyName=entry.getKey();
    FileCollectionSnapshot beforeExecution=entry.getValue();
    FileCollectionSnapshot afterPreviousExecution=getSnapshotAfterPreviousExecution(propertyName);
    OverlappingOutputs overlappingOutputs=OverlappingOutputs.detect(propertyName,afterPreviousExecution,beforeExecution);
    if (overlappingOutputs != null) {
      current.setDetectedOverlappingOutputs(overlappingOutputs);
      return;
    }
  }
}
