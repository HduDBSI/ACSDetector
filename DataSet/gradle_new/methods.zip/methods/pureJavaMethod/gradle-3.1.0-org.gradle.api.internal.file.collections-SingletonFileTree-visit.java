public void visit(FileVisitor visitor){
  visitor.visitFile(new SingletonFileVisitDetails(file,fileSystem));
}
