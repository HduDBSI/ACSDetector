@Override public PluginRequests mergeWithAutoAppliedPlugins(PluginRequests initialRequests,Object pluginTarget){
  if (pluginTarget instanceof Project) {
    Project project=(Project)pluginTarget;
    PluginRequests autoAppliedPlugins=registry.getAutoAppliedPlugins(project);
    if (autoAppliedPlugins.isEmpty()) {
      return initialRequests;
    }
    return mergePluginRequests(autoAppliedPlugins,initialRequests,project.getPlugins(),project.getBuildscript());
  }
 else   if (pluginTarget instanceof Settings) {
    Settings settings=(Settings)pluginTarget;
    PluginRequests autoAppliedPlugins=registry.getAutoAppliedPlugins(settings);
    if (autoAppliedPlugins.isEmpty()) {
      return initialRequests;
    }
    return mergePluginRequests(autoAppliedPlugins,initialRequests,settings.getPlugins(),settings.getBuildscript());
  }
 else {
    return initialRequests;
  }
}
