public SelectorState getSelector(DependencyState dependencyState){
  SelectorState selectorState=selectors.computeIfAbsent(dependencyState.getRequested(),req -> {
    ModuleIdentifier moduleIdentifier=dependencyState.getModuleIdentifier();
    return new SelectorState(idGenerator.generateId(),dependencyState,idResolver,this,moduleIdentifier);
  }
);
  selectorState.update(dependencyState);
  return selectorState;
}
