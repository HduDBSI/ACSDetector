@TaskAction public void create() throws IOException {
  Properties prop=new Properties();
  OutputStream output=null;
  try {
    output=new FileOutputStream(outputFile);
    prop.setProperty("version",version);
    prop.store(output,null);
  }
  finally {
    if (output != null) {
      try {
        output.close();
      }
 catch (      IOException e) {
      }
    }
  }
}
