@Override public TaskOutputFilePropertyBuilder dir(final Object path){
  return taskMutator.mutate("TaskOutputs.dir(Object)",new Callable<TaskOutputFilePropertyBuilder>(){
    @Override public TaskOutputFilePropertyBuilder call() throws Exception {
      return addSpec(new DefaultCacheableTaskOutputFilePropertySpec(task.getName(),resolver,OutputType.DIRECTORY,path));
    }
  }
);
}
