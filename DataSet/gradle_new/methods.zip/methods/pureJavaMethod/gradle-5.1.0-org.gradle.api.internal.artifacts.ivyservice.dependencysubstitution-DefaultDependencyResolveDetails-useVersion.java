@Override public void useVersion(String version){
  if (version == null) {
    throw new IllegalArgumentException("Configuring the dependency resolve details with 'null' version is not allowed.");
  }
  useSelector=null;
  useVersion=new DefaultMutableVersionConstraint(version);
  dirty=true;
}
