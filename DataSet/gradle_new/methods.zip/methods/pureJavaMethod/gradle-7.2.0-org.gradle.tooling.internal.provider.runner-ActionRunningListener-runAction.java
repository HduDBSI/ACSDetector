@SuppressWarnings("deprecation") private SerializedPayload runAction(GradleInternal gradle,@Nullable Object action,PhasedActionResult.Phase phase){
  if (action == null || actionFailure != null) {
    return null;
  }
  DefaultBuildController internalBuildController=buildControllerFactory.controllerFor(gradle);
  try {
    Object result;
    if (action instanceof InternalBuildActionVersion2<?>) {
      result=((InternalBuildActionVersion2)action).execute(internalBuildController);
    }
 else {
      result=((org.gradle.tooling.internal.protocol.InternalBuildAction)action).execute(internalBuildController);
    }
    SerializedPayload serializedResult=payloadSerializer.serialize(result);
    clientAction.collectActionResult(serializedResult,phase);
    return serializedResult;
  }
 catch (  RuntimeException e) {
    actionFailure=e;
    throw e;
  }
}
