@Override public void visitInputFileProperty(String propertyName,UnitOfWork.InputPropertyType type,UnitOfWork.IdentityKind identity,@Nullable Object value,Supplier<CurrentFileCollectionFingerprint> fingerprinter){
  if (type.isIncremental()) {
    if (value == null) {
      throw new InvalidUserDataException("Must specify a value for incremental input property '" + propertyName + "'.");
    }
    builder.put(propertyName,value);
  }
}
