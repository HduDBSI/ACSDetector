@Override public SharedResource forService(Provider<? extends BuildService<?>> service){
  if (!(service instanceof BuildServiceProvider)) {
    throw new IllegalArgumentException("The given provider is not a build service provider.");
  }
  BuildServiceProvider<?,?> provider=(BuildServiceProvider<?,?>)service;
  DefaultServiceRegistration<?,?> registration=getByName(provider.getName());
  return registration.asSharedResource(() -> {
    registration.getMaxParallelUsages().finalizeValue();
    int maxUsages=registration.getMaxParallelUsages().getOrElse(-1);
    if (maxUsages > 0) {
      leaseRegistry.registerSharedResource(provider.getName(),maxUsages);
    }
    return new ServiceBackedSharedResource(provider.getName(),maxUsages,leaseRegistry);
  }
);
}
