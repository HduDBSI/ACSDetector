@Override public void execute(BuildOperationQueue<CommandLineToolInvocation> buildQueue){
  buildQueue.setLogLocation(spec.getOperationLogger().getLogLocation());
  buildQueue.add(invocation);
}
