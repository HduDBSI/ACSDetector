public void waitForCompletion(){
  loggingOutput.removeOutputEventListener(listener);
  shouldStop=true;
  try {
    completionLock.await();
  }
 catch (  InterruptedException e) {
  }
}
