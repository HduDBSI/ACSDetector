/** 
 * Calculates, resolves and returns dependency entries of this classpath.
 */
public List<ClasspathEntry> resolveDependencies(){
  ProjectInternal projectInternal=(ProjectInternal)this.project;
  IdeArtifactRegistry ideArtifactRegistry=projectInternal.getServices().get(IdeArtifactRegistry.class);
  ProjectStateRegistry projectRegistry=projectInternal.getServices().get(ProjectStateRegistry.class);
  ClasspathFactory classpathFactory=new ClasspathFactory(this,ideArtifactRegistry,projectRegistry);
  return classpathFactory.createEntries();
}
