public void write(Encoder encoder,ImmutableMap<String,ValueSnapshot> properties) throws Exception {
  encoder.writeSmallInt(properties.size());
  for (  Map.Entry<String,ValueSnapshot> entry : properties.entrySet()) {
    encoder.writeString(entry.getKey());
    writeEntry(encoder,entry.getValue());
  }
}
