/** 
 * unlistable directories (and maybe some locked files) will stop here 
 */
@Override public FileVisitResult visitFileFailed(Path file,IOException exc){
  if (isNotFileSystemLoopException(exc)) {
    String internedName=intern(file.getFileName().toString());
    boolean isDirectory=Files.isDirectory(file);
    if (shouldVisit(file,internedName,isDirectory,null,builder.getRelativePath())) {
      LOGGER.info("Could not read file path '{}'.",file);
      String internedAbsolutePath=intern(file.toString());
      builder.visitFile(new MissingFileSnapshot(internedAbsolutePath,internedName));
    }
  }
  return FileVisitResult.CONTINUE;
}
