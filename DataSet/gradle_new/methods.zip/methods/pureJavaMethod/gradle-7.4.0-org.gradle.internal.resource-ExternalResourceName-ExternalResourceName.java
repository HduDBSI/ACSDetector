private ExternalResourceName(@Nullable String encodedRoot,String path,String encodedQuery){
  this.encodedRoot=encodedRoot;
  this.path=path;
  this.encodedQuery=encodedQuery;
}
