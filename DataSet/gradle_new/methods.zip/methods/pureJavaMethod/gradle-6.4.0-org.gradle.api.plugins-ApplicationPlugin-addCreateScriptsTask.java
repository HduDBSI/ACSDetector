private void addCreateScriptsTask(Project project,JavaApplication pluginExtension,ApplicationPluginConvention pluginConvention){
  project.getTasks().register(TASK_START_SCRIPTS_NAME,CreateStartScripts.class,startScripts -> {
    startScripts.setDescription("Creates OS specific scripts to run the project as a JVM application.");
    startScripts.setClasspath(jarsOnlyRuntimeClasspath(project));
    startScripts.getMainModule().set(pluginExtension.getMainModule());
    startScripts.getMainClass().set(pluginExtension.getMainClass());
    startScripts.getConventionMapping().map("applicationName",pluginConvention::getApplicationName);
    startScripts.getConventionMapping().map("outputDir",() -> new File(project.getBuildDir(),"scripts"));
    startScripts.getConventionMapping().map("executableDir",pluginConvention::getExecutableDir);
    startScripts.getConventionMapping().map("defaultJvmOpts",pluginConvention::getApplicationDefaultJvmArgs);
    JavaPluginExtension javaPluginExtension=project.getExtensions().getByType(JavaPluginExtension.class);
    startScripts.getModularity().getInferModulePath().convention(javaPluginExtension.getModularity().getInferModulePath());
  }
);
}
