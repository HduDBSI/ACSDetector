protected AbstractMutableModuleComponentResolveMetadata(ModuleComponentResolveMetadata metadata){
  this.componentId=metadata.getComponentId();
  this.id=metadata.getId();
  this.changing=metadata.isChanging();
  this.missing=metadata.isMissing();
  this.status=metadata.getStatus();
  this.statusScheme=metadata.getStatusScheme();
  this.moduleSource=metadata.getSource();
  this.artifacts=metadata.getArtifactOverrides();
  this.dependencies=metadata.getDependencies();
  this.contentHash=metadata.getContentHash();
}
