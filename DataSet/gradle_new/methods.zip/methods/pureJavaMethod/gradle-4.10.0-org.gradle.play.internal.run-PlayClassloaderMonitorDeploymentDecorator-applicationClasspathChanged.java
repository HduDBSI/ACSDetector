private boolean applicationClasspathChanged(){
  HashCode oldClasspathHash=classpathHash;
  classpathHash=fingerprinter.fingerprint(applicationClasspath,InputNormalizationStrategy.NO_NORMALIZATION).getHash();
  return !classpathHash.equals(oldClasspathHash);
}
