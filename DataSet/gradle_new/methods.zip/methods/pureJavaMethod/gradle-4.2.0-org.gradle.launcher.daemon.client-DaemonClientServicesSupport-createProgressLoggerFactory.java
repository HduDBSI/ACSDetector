ProgressLoggerFactory createProgressLoggerFactory(Clock clock){
  return new DefaultProgressLoggerFactory(new ProgressLoggingBridge(get(OutputEventListener.class)),clock);
}
