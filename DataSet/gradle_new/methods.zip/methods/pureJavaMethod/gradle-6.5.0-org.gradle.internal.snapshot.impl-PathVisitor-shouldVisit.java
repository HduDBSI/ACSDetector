/** 
 * Returns whether we want to visit the given path during our walk, or ignore it completely, based on the directory/file excludes or the provided filtering predicate. Excludes won't mark this walk as `filtered`, only if the `predicate` rejects any entry.
 */
private boolean shouldVisit(Path path,String internedName,boolean isDirectory,Iterable<String> relativePath){
  if (isDirectory) {
    if (defaultExcludes.excludeDir(internedName)) {
      return false;
    }
  }
 else   if (defaultExcludes.excludeFile(internedName)) {
    return false;
  }
  if (predicate == null) {
    return true;
  }
  boolean allowed=predicate.test(path,internedName,isDirectory,relativePath);
  if (!allowed) {
    hasBeenFiltered.set(true);
  }
  return allowed;
}
