public DefaultSettingsLoaderFactory(ISettingsFinder settingsFinder,SettingsProcessor settingsProcessor,BuildSourceBuilder buildSourceBuilder,NestedBuildFactory nestedBuildFactory,BuildStateRegistry buildRegistry){
  this.settingsFinder=settingsFinder;
  this.settingsProcessor=settingsProcessor;
  this.buildSourceBuilder=buildSourceBuilder;
  this.nestedBuildFactory=nestedBuildFactory;
  this.buildRegistry=buildRegistry;
}
