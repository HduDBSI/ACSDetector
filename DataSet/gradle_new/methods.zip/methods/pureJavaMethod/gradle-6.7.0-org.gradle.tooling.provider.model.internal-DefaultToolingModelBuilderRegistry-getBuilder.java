@Override public ToolingModelBuilder getBuilder(String modelName) throws UnsupportedOperationException {
  ToolingModelBuilder builder=get(modelName);
  return new LenientToolingModelBuilder(builder);
}
