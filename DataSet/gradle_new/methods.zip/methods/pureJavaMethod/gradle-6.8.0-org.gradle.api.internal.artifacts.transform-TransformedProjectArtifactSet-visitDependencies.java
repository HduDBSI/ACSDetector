@Override public void visitDependencies(TaskDependencyResolveContext context){
  if (!transformedArtifacts.isEmpty()) {
    context.add(new DefaultTransformationDependency(transformedArtifacts));
  }
}
