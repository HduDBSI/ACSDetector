@Override public RootComponentMetadataBuilder withConfigurationsProvider(ConfigurationsProvider alternateProvider){
  return factory.create(alternateProvider);
}
