private PluginRepositoriesSpec getPluginRepositorySpec(){
  return ((SettingsInternal)getScriptTarget()).getPluginManagement().getRepositories();
}
