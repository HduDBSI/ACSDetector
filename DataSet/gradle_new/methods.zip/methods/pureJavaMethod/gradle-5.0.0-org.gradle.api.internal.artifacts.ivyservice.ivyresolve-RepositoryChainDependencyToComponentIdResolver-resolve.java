@Override public void resolve(DependencyMetadata dependency,VersionSelector acceptor,VersionSelector rejector,BuildableComponentIdResolveResult result){
  ComponentSelector componentSelector=dependency.getSelector();
  if (componentSelector instanceof ModuleComponentSelector) {
    ModuleComponentSelector module=(ModuleComponentSelector)componentSelector;
    if (acceptor.isDynamic()) {
      dynamicRevisionResolver.resolve(toModuleDependencyMetadata(dependency),acceptor,rejector,consumerAttributes,result);
    }
 else {
      String version=acceptor.getSelector();
      ModuleIdentifier moduleId=module.getModuleIdentifier();
      ModuleComponentIdentifier id=DefaultModuleComponentIdentifier.newId(moduleId,version);
      ModuleVersionIdentifier mvId=DefaultModuleVersionIdentifier.newId(moduleId,version);
      if (rejector != null && rejector.accept(version)) {
        result.rejected(id,mvId);
      }
 else {
        result.resolved(id,mvId);
      }
    }
  }
}
