@Override public Task leftShift(final Closure action){
  DeprecationLogger.nagUserOfDiscontinuedMethod("Task.leftShift(Closure)","Please use Task.doLast(Action) instead.");
  hasCustomActions=true;
  if (action == null) {
    throw new InvalidUserDataException("Action must not be null!");
  }
  taskMutator.mutate("Task.leftShift(Closure)",new Runnable(){
    public void run(){
      getTaskActions().add(taskMutator.leftShift(convertClosureToAction(action,"doLast {} action")));
    }
  }
);
  return this;
}
