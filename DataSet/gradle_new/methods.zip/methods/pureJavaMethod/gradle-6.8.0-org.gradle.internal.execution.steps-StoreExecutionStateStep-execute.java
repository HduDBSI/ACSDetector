@Override public CurrentSnapshotResult execute(UnitOfWork work,C context){
  CurrentSnapshotResult result=delegate.execute(work,context);
  UnitOfWork.Identity identity=context.getIdentity();
  context.getHistory().ifPresent(history -> storeState(context,history,identity.getUniqueId(),result));
  return result;
}
