public XCTestSourceFileElement withTestableImport(String importName){
  testableImports.add(importName);
  return this;
}
