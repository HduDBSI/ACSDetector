@Override public DefaultWorkResult execute(ActionExecutionSpec spec){
  DefaultWorkResult result;
  try {
    result=ClassLoaderUtils.executeInClassloader(contextClassLoader,new Factory<DefaultWorkResult>(){
      @Nullable @Override public DefaultWorkResult create(){
        return workerServer.execute(spec);
      }
    }
);
  }
  finally {
    workerExecutor.await();
  }
  return result;
}
