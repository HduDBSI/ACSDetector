@Override public List<StyledTextOutputEvent.Span> format(@Nullable String header,String description,String status,boolean failed){
  final String message=header != null ? header : description;
  if (status.isEmpty()) {
    return Lists.newArrayList(header(message,failed),EOL);
  }
 else {
    return Lists.newArrayList(header(message,failed),status(status,failed),EOL);
  }
}
