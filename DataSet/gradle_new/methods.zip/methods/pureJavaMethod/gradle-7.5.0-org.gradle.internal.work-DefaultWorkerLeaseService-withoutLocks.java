@Override public <T>T withoutLocks(Collection<? extends ResourceLock> locks,Factory<T> factory){
  if (locks.isEmpty()) {
    return factory.create();
  }
  assertAllLocked(locks);
  releaseLocks(locks);
  try {
    return factory.create();
  }
  finally {
    acquireLocksWithoutWorkerLeaseWhileBlocked(locks);
  }
}
