private void configureReportsConventionMapping(CodeNarc task,final String baseName){
  ProjectLayout layout=project.getLayout();
  ProviderFactory providers=project.getProviders();
  Provider<String> reportFormat=providers.provider(() -> extension.getReportFormat());
  Provider<RegularFile> reportsDir=layout.file(providers.provider(() -> extension.getReportsDir()));
  task.getReports().all(action(report -> {
    report.getRequired().convention(providers.provider(() -> report.getName().equals(reportFormat.get())));
    report.getOutputLocation().convention(layout.getProjectDirectory().file(providers.provider(() -> {
      String fileSuffix=report.getName().equals("text") ? "txt" : report.getName();
      return new File(reportsDir.get().getAsFile(),baseName + "." + fileSuffix).getAbsolutePath();
    }
)));
  }
));
}
