@Override public TaskDependency getBuildDependencies(){
  assertResolvingAllowed();
  return new ConfigurationTaskDependency(dependencySpec,viewAttributes,componentSpec);
}
