/** 
 * Selects the artifacts of this set that meet the given criteria. Implementation should be eager where possible, so that selection happens immediately, but may be lazy.
 */
ResolvedArtifactSet select(Spec<? super ComponentIdentifier> componentFilter,VariantSelector selector);
