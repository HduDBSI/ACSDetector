public static boolean isDropVfs(StartParameter startParameter){
  String dropVfs=getSystemProperty(VFS_DROP_PROPERTY,startParameter.getSystemPropertiesArgs());
  return dropVfs != null && !"false".equalsIgnoreCase(dropVfs);
}
