public ProgressOperation(String shortDescription,String status,String category,OperationIdentifier operationId,ProgressOperation parent){
  this.shortDescription=shortDescription;
  this.status=status;
  this.category=category;
  this.operationId=operationId;
  this.parent=parent;
}
