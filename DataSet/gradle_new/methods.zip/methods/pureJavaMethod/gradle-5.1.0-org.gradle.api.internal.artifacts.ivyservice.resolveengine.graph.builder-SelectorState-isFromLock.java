@Override public boolean isFromLock(){
  return fromLock;
}
