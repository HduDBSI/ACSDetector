private void visitImplementation(PropertyVisitor visitor){
  visitor.visitInputProperty(getPropertyName(),new ImplementationPropertyValue(getImplementationClass(getBean())),false);
}
