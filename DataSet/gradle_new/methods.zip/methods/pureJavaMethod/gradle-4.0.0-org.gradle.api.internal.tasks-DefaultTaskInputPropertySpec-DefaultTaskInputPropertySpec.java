public DefaultTaskInputPropertySpec(String taskName,FileResolver resolver,Object paths){
  this.files=new TaskPropertyFileCollection(taskName,"input",this,resolver,paths);
}
