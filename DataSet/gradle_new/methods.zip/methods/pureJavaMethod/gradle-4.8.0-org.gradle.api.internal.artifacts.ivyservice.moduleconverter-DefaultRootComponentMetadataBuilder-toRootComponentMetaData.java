@Override public ComponentResolveMetadata toRootComponentMetaData(){
  Module module=metadataProvider.getModule();
  ComponentIdentifier componentIdentifier=componentIdentifierFactory.createComponentIdentifier(module);
  DefaultLocalComponentMetadata metadata=holder.tryCached(componentIdentifier);
  if (metadata == null) {
    metadata=buildRootComponentMetadata(module,componentIdentifier);
    holder.cachedValue=metadata;
  }
  return metadata;
}
