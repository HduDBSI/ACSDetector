public abstract TaskSelection getSelection(@Nullable String projectPath,@Nullable File root,String path);
