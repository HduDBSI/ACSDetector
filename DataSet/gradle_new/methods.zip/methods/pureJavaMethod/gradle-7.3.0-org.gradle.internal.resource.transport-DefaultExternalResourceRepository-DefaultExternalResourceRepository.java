public DefaultExternalResourceRepository(String name,ExternalResourceAccessor accessor,ExternalResourceUploader uploader,ExternalResourceLister lister){
  this.name=name;
  this.accessor=accessor;
  this.uploader=uploader;
  this.lister=lister;
}
