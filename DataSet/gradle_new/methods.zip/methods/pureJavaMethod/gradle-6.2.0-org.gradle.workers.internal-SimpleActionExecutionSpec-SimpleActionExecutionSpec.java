public SimpleActionExecutionSpec(Class<? extends WorkAction<T>> implementationClass,T params,boolean usesInternalServices){
  this.implementationClass=implementationClass;
  this.params=params;
  this.usesInternalServices=usesInternalServices;
}
