void attachConsole(OutputStream outputStream,OutputStream errorStream,ConsoleOutput consoleOutput,ConsoleMetaData consoleMetadata){
  addConsoleAttachement(new ConsoleAttachment(loggingRouter,outputStream,errorStream,consoleOutput,consoleMetadata));
}
