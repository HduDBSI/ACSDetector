public ComponentResolveMetadata toRootComponentMetaData(){
  return rootComponentMetadataBuilder.toRootComponentMetaData();
}
