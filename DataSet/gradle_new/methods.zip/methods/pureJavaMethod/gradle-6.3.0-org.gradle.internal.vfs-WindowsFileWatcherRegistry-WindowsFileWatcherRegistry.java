public WindowsFileWatcherRegistry(Set<Path> watchRoots,ChangeHandler handler){
  super(watchRoots,callback -> Native.get(WindowsFileEventFunctions.class).startWatcher(callback),handler);
}
