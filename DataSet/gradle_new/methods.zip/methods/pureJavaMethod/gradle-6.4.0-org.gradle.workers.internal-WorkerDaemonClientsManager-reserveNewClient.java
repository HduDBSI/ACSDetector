public WorkerDaemonClient reserveNewClient(DaemonForkOptions forkOptions){
  WorkerDaemonClient client=workerDaemonStarter.startDaemon(forkOptions,workerProcessCleanupAction);
synchronized (lock) {
    allClients.add(client);
  }
  return client;
}
