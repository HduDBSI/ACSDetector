@Override public Set<ModuleDependency> getDependencies(){
  return runtimeDependencies.withType(ModuleDependency.class);
}
