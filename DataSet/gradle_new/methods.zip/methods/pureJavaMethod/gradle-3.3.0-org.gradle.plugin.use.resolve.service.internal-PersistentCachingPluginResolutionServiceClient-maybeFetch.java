private <K,V extends Response<?>>V maybeFetch(String operationName,final PersistentIndexedCache<K,V> cache,final K key,Factory<V> factory,Spec<? super V> shouldFetch){
  V cachedValue=cacheAccess.useCache(operationName + " - read",new Factory<V>(){
    public V create(){
      return cache.get(key);
    }
  }
);
  boolean fetch=cachedValue == null || shouldFetch.isSatisfiedBy(cachedValue);
  if (fetch) {
    return fetch(operationName,cache,key,factory);
  }
 else {
    return cachedValue;
  }
}
