private void reset(){
  failure=null;
  metadata=null;
  id=null;
  moduleVersionId=null;
}
