@Nullable @Override public String getOriginBuildInvocationId(){
  UniqueId originBuildInvocationId=originMetadata == null ? null : originMetadata.getBuildInvocationId();
  return originBuildInvocationId == null ? null : originBuildInvocationId.asString();
}
