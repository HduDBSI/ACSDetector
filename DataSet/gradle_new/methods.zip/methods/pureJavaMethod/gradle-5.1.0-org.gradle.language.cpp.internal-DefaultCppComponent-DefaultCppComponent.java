@Inject public DefaultCppComponent(String name,FileOperations fileOperations,ObjectFactory objectFactory){
  super(fileOperations);
  this.name=name;
  this.fileOperations=fileOperations;
  cppSource=createSourceView("src/" + name + "/cpp",Arrays.asList("cpp","c++","cc"));
  privateHeaders=fileOperations.configurableFiles();
  privateHeadersWithConvention=createDirView(privateHeaders,"src/" + name + "/headers");
  baseName=objectFactory.property(String.class);
  names=Names.of(name);
  binaries=Cast.uncheckedCast(objectFactory.newInstance(DefaultBinaryCollection.class,CppBinary.class));
  targetMachines=objectFactory.setProperty(TargetMachine.class);
}
