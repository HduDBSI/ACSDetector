@Override public SearchResult<GccMetadata> getCompilerMetaData(List<File> searchPath,Action<? super CompilerExecSpec> configureAction){
  return delegate.getCompilerMetaData(searchPath,execSpec -> {
    execSpec.args(compilerProbeArgs);
    configureAction.execute(execSpec);
  }
);
}
