@TaskAction public void create() throws IOException {
  Properties prop=new Properties();
  prop.setProperty("version",getVersion().get());
  try (OutputStream output=new FileOutputStream(getOutputFile().getAsFile().get())){
    prop.store(output,null);
  }
 }
