@Override public Compiler<JavaCompileSpec> create(Class<? extends CompileSpec> type){
  Compiler<JavaCompileSpec> result=createTargetCompiler(type);
  return new AnnotationProcessorDiscoveringCompiler<>(new NormalizingJavaCompiler(result),processorDetector);
}
