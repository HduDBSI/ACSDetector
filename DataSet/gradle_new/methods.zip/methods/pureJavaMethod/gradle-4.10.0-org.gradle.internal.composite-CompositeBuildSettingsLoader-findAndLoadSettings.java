@Override public SettingsInternal findAndLoadSettings(GradleInternal gradle){
  SettingsInternal settings=delegate.findAndLoadSettings(gradle);
  buildRegistry.registerRootBuild(settings);
  return settings;
}
