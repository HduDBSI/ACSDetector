@Override public TaskExecuterResult execute(TaskInternal task,TaskStateInternal state,TaskExecutionContext context){
  if (!task.getReasonNotToTrackState().isPresent()) {
    cleanupStaleOutputs(context);
  }
  return executer.execute(task,state,context);
}
