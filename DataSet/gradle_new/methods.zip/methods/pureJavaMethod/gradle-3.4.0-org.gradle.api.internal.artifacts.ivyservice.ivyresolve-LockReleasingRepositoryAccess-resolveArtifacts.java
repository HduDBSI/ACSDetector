@Override public void resolveArtifacts(final ComponentResolveMetadata component,final BuildableComponentArtifactsResolveResult result){
  cacheLockingManager.longRunningOperation(new Runnable(){
    public void run(){
      delegate.resolveArtifacts(component,result);
    }
  }
);
}
