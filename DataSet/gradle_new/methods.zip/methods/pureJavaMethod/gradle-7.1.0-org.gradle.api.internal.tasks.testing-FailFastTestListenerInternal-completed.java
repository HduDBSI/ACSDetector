@Override public void completed(TestDescriptorInternal testDescriptor,TestResult testResult,TestCompleteEvent completeEvent){
  delegate.completed(testDescriptor,testResult,completeEvent);
  if (!failed && testResult.getResultType() == TestResult.ResultType.FAILURE) {
    failed=true;
    testExecuter.stopNow();
  }
}
