@Override public int compareTo(Stage other){
  if (stage > other.stage) {
    return 1;
  }
  if (stage < other.stage) {
    return -1;
  }
  if (number > other.number) {
    return 1;
  }
  if (number < other.number) {
    return -1;
  }
  if (patchNo > other.patchNo) {
    return 1;
  }
  if (patchNo < other.patchNo) {
    return -1;
  }
  return 0;
}
