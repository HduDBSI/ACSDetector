public DefaultSettingsLoaderFactory(ISettingsFinder settingsFinder,SettingsProcessor settingsProcessor,BuildSourceBuilder buildSourceBuilder,BuildStateRegistry buildRegistry){
  this.settingsFinder=settingsFinder;
  this.settingsProcessor=settingsProcessor;
  this.buildSourceBuilder=buildSourceBuilder;
  this.buildRegistry=buildRegistry;
}
