@Override public boolean writeGradleMetadataMarker(){
  if (canPublishModuleMetadata() && moduleMetadataArtifact != null && moduleMetadataArtifact.isEnabled()) {
    return true;
  }
  return false;
}
