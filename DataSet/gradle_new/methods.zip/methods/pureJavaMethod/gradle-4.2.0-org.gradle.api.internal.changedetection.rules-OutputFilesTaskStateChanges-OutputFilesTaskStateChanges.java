public OutputFilesTaskStateChanges(@Nullable TaskExecution previous,TaskExecution current,TaskInternal task){
  super(previous,current,task,"Output");
}
