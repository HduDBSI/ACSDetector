public void addArtifact(IvyArtifactName newArtifact,Set<String> configurations){
  if (configurations.isEmpty()) {
    throw new IllegalArgumentException("Artifact should be attached to at least one configuration.");
  }
  Artifact artifact=findOrCreate(newArtifact);
  artifact.getConfigurations().addAll(configurations);
}
