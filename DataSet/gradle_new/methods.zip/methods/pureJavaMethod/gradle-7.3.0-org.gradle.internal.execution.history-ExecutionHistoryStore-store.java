void store(String key,OriginMetadata originMetadata,boolean successful,AfterExecutionState executionState);
