@Nullable @Override public LocalComponentMetadata getComponent(ProjectState projectState){
  projectState.ensureConfigured();
  return projectState.fromMutableState(p -> getLocalComponentMetadata(projectState,p));
}
