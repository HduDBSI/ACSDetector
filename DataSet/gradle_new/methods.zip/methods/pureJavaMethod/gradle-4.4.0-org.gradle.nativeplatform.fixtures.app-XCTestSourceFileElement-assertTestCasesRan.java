@SuppressWarnings("unchecked") public void assertTestCasesRan(TestClassExecutionResult testExecutionResult){
  testExecutionResult.assertTestCount(getTestCount(),getFailureCount(),0);
  for (  XCTestCaseElement testCase : getTestCases()) {
    if (testCase.isExpectFailure()) {
      testExecutionResult.assertTestFailed(testCase.getName(),Matchers.anything());
    }
 else {
      testExecutionResult.assertTestPassed(testCase.getName());
    }
  }
}
