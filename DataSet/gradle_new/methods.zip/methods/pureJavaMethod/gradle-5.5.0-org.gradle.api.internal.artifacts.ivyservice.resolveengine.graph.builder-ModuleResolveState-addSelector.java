void addSelector(SelectorState selector,boolean deferSelection){
  selectors.add(selector,deferSelection);
  mergedConstraintAttributes=appendAttributes(mergedConstraintAttributes,selector);
  if (overriddenSelection) {
    assert selected != null : "An overridden module cannot have selected == null";
    selector.overrideSelection(selected);
  }
}
