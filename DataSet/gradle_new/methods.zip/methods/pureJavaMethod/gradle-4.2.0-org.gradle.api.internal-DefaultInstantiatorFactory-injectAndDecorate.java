@Override public Instantiator injectAndDecorate(ServiceRegistry registry){
  return new DependencyInjectingInstantiator(classGenerator,registry,decoratedConstructorCache);
}
