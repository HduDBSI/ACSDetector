private LockableSftpClient acquireClient(SftpHost sftpHost){
  return idleClients.containsKey(sftpHost) ? reuseExistingOrCreateNewClient(sftpHost) : createNewClient(sftpHost);
}
