@Override @Nullable public ConfigurationMetadata getConfiguration(String name){
  return new ClientModuleConfigurationMetadata(delegate.getId(),name,clientModuleArtifact,clientModuleDependencies);
}
