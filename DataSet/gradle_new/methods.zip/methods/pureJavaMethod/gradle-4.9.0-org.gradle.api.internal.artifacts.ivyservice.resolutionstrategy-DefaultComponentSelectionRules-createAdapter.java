private static RuleActionAdapter createAdapter(){
  RuleActionValidator ruleActionValidator=new DefaultRuleActionValidator(VALID_INPUT_TYPES);
  return new DefaultRuleActionAdapter(ruleActionValidator,"ComponentSelectionRules");
}
