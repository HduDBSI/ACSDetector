private static TaskExecuter createSkipCachedExecuterIfNecessary(StartParameter startParameter,TaskArtifactStateRepository repository,TaskOutputCache cache,TaskOutputPacker packer,TaskExecuter delegate){
  if ("true".equals(startParameter.getSystemPropertiesArgs().get("org.gradle.cache.tasks"))) {
    return new SkipCachedTaskExecuter(repository,cache,packer,delegate);
  }
 else {
    return delegate;
  }
}
