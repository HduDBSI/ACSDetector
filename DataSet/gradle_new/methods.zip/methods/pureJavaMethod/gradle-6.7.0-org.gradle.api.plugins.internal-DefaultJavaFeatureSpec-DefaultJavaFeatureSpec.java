public DefaultJavaFeatureSpec(String name,Capability defaultCapability,JvmModelingServices jvmModelingServices){
  this.name=name;
  this.jvmEcosystemUtilities=jvmModelingServices;
  this.capabilities.add(defaultCapability);
}
