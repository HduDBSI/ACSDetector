private String invalidParameterMessage(Class<?> inputType){
  if (validInputType == null) {
    return String.format(VALID_NO_TYPES,inputType.getName());
  }
 else {
    return String.format(VALID_SINGLE_TYPES,inputType.getName(),className(validInputType));
  }
}
