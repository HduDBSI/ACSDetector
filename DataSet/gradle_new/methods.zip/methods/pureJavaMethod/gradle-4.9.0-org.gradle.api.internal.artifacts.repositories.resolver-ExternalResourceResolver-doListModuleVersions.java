private void doListModuleVersions(ModuleDependencyMetadata dependency,BuildableModuleVersionListingResolveResult result){
  ModuleIdentifier module=dependency.getSelector().getModuleIdentifier();
  tryListingViaRule(module,result);
  if (result.hasResult() && result.isAuthoritative()) {
    return;
  }
  ResourceVersionLister versionLister=new ResourceVersionLister(repository);
  List<ResourcePattern> completeIvyPatterns=filterComplete(this.ivyPatterns,module);
  List<ResourcePattern> completeArtifactPatterns=filterComplete(this.artifactPatterns,module);
  for (  MetadataSource<?> metadataSource : metadataSources.sources()) {
    metadataSource.listModuleVersions(dependency,module,completeIvyPatterns,completeArtifactPatterns,versionLister,result);
    if (result.hasResult() && result.isAuthoritative()) {
      return;
    }
  }
  result.listed(ImmutableSet.<String>of());
}
