private int compareModuleComponentSelectors(DependencyEdge left,DependencyEdge right){
  ModuleComponentSelector leftRequested=(ModuleComponentSelector)left.getRequested();
  ModuleComponentSelector rightRequested=(ModuleComponentSelector)right.getRequested();
  int byGroup=leftRequested.getGroup().compareTo(rightRequested.getGroup());
  if (byGroup != 0) {
    return byGroup;
  }
  int byModule=leftRequested.getModule().compareTo(rightRequested.getModule());
  if (byModule != 0) {
    return byModule;
  }
  boolean leftMatches=leftRequested.matchesStrictly(left.getActual());
  boolean rightMatches=rightRequested.matchesStrictly(right.getActual());
  if (leftMatches && !rightMatches) {
    return -1;
  }
 else   if (!leftMatches && rightMatches) {
    return 1;
  }
  int byVersion=compareVersions(leftRequested.getVersionConstraint(),rightRequested.getVersionConstraint());
  if (byVersion != 0) {
    return byVersion;
  }
  return compareFromComponentIdentifiers(left.getFrom(),right.getFrom());
}
