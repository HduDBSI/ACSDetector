@Override public Worker getWorker(final DaemonForkOptions forkOptions){
  return new AbstractWorker(buildOperationExecutor){
    @Override public DefaultWorkResult execute(    ActionExecutionSpec spec,    BuildOperationRef parentBuildOperation){
      return executeWrappedInBuildOperation(spec,parentBuildOperation,new Work(){
        @Override public DefaultWorkResult execute(        ActionExecutionSpec spec){
          return executeInWorkerClassLoader(spec,forkOptions);
        }
      }
);
    }
  }
;
}
