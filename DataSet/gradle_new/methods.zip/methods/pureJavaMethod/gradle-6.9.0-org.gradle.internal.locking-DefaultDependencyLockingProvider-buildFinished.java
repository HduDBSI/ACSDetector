@Override public void buildFinished(){
  if (uniqueLockStateEnabled && uniqueLockStateLoaded && lockFileReaderWriter.canWrite()) {
    lockFileReaderWriter.writeUniqueLockfile(allLockState);
    if (context.isScript()) {
      LOGGER.lifecycle("Persisted dependency lock state for buildscript of project '{}'",context.getProjectPath());
    }
 else {
      LOGGER.lifecycle("Persisted dependency lock state for project '{}'",context.getProjectPath());
    }
  }
}
