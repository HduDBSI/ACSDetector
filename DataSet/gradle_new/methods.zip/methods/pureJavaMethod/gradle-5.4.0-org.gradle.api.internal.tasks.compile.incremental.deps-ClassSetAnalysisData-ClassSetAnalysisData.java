public ClassSetAnalysisData(Set<String> classes,Map<String,DependentsSet> dependents,Map<String,IntSet> classesToConstants,String fullRebuildCause){
  this.classes=classes;
  this.dependents=dependents;
  this.classesToConstants=classesToConstants;
  this.fullRebuildCause=fullRebuildCause;
}
