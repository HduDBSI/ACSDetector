@Override public void finishArtifacts(){
  artifactsResults=artifactsBuilder.complete().select(Specs.<ComponentIdentifier>satisfyAll(),new VariantSelector(){
    @Override public ResolvedArtifactSet select(    ResolvedVariantSet variants){
      return variants.getVariants().iterator().next().getArtifacts();
    }
  }
);
}
