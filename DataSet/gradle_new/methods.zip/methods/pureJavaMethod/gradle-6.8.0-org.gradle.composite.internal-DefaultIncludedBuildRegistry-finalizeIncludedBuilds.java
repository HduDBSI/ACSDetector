@Override public void finalizeIncludedBuilds(){
  while (!pendingIncludedBuilds.isEmpty()) {
    IncludedBuildState build=pendingIncludedBuilds.removeFirst();
    build.loadSettings();
  }
}
