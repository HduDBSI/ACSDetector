@Override public BuildServiceProvider<?,?> register(String name,Class<? extends BuildService> implementationType,BuildServiceParameters parameters,int maxUsages){
  if (registrations.findByName(name) != null) {
    throw new IllegalArgumentException(String.format("Service '%s' has already been registered.",name));
  }
  return doRegister(name,Cast.uncheckedNonnullCast(implementationType),parameters,maxUsages <= 0 ? null : maxUsages);
}
