public static ModuleComponentIdentifier newId(ModuleVersionIdentifier moduleVersionIdentifier){
  return new DefaultModuleComponentIdentifier(moduleVersionIdentifier.getModule(),moduleVersionIdentifier.getVersion());
}
