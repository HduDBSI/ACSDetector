@Override public void execute(MultipleCandidatesDetails<T> details){
  Collection<AttributeValue<T>> values=details.getCandidateValues();
  T min=null;
  T max=null;
  for (  AttributeValue<T> value : values) {
    if (value.isPresent()) {
      T v=value.get();
      if (min == null || comparator.compare(v,min) < 0) {
        min=v;
      }
      if (max == null || comparator.compare(v,max) > 0) {
        max=v;
      }
    }
  }
  T cmp=pickFirst ? min : max;
  if (cmp != null) {
    for (    AttributeValue<T> value : details.getCandidateValues()) {
      if (value.isPresent() && value.get().equals(cmp)) {
        details.closestMatch(value);
      }
    }
  }
}
