@Override public CurrentFileCollectionFingerprint fingerprint(FileCollection files){
  return super.fingerprint(files,fingerprintingStrategy);
}
