@Override public ProjectComponentIdentifier createProjectComponentIdentifier(ProjectComponentSelector selector){
  return ((DefaultProjectComponentSelector)selector).toIdentifier();
}
