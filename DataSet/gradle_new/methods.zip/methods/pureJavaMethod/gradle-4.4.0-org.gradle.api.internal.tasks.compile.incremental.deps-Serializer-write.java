@Override public void write(Encoder encoder,ClassSetAnalysisData value) throws Exception {
  Map<String,Integer> classNameMap=new HashMap<String,Integer>();
  encoder.writeSmallInt(value.filePathToClassName.size());
  for (  Map.Entry<String,String> entry : value.filePathToClassName.entrySet()) {
    encoder.writeString(entry.getKey());
    writeClassName(entry.getValue(),classNameMap,encoder);
  }
  encoder.writeSmallInt(value.dependents.size());
  for (  Map.Entry<String,DependentsSet> entry : value.dependents.entrySet()) {
    writeClassName(entry.getKey(),classNameMap,encoder);
    writeDependentSet(entry.getValue(),classNameMap,encoder);
  }
  encoder.writeSmallInt(value.classesToConstants.size());
  for (  Map.Entry<String,Set<Integer>> entry : value.classesToConstants.entrySet()) {
    writeClassName(entry.getKey(),classNameMap,encoder);
    INTEGER_SET_SERIALIZER.write(encoder,entry.getValue());
  }
  encoder.writeSmallInt(value.literalsToClasses.size());
  for (  Map.Entry<Integer,Set<String>> entry : value.literalsToClasses.entrySet()) {
    encoder.writeInt(entry.getKey());
    encoder.writeSmallInt(entry.getValue().size());
    for (    String className : entry.getValue()) {
      writeClassName(className,classNameMap,encoder);
    }
  }
  encoder.writeSmallInt(value.classesToChildren.size());
  for (  Map.Entry<String,Set<String>> entry : value.classesToChildren.entrySet()) {
    writeClassName(entry.getKey(),classNameMap,encoder);
    encoder.writeSmallInt(entry.getValue().size());
    for (    String className : entry.getValue()) {
      writeClassName(className,classNameMap,encoder);
    }
  }
}
