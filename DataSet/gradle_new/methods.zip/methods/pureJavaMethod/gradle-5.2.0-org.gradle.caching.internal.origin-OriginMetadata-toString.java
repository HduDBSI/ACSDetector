@Override public String toString(){
  return "OriginMetadata{" + "buildInvocationId=" + buildInvocationId + ", executionTime="+ executionTime+ '}';
}
