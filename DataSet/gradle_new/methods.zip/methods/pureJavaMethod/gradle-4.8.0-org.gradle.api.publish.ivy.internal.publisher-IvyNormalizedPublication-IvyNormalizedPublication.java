public IvyNormalizedPublication(String name,IvyPublicationIdentity projectIdentity,File ivyDescriptorFile,Set<IvyArtifact> allArtifacts){
  this.name=name;
  this.projectIdentity=projectIdentity;
  this.ivyDescriptorFile=ivyDescriptorFile;
  this.allArtifacts=allArtifacts;
}
