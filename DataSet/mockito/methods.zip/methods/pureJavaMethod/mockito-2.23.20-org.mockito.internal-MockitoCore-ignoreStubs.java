public Object[] ignoreStubs(Object... mocks){
  for (  Object m : mocks) {
    InvocationContainerImpl container=getInvocationContainer(m);
    List<Invocation> ins=container.getInvocations();
    for (    Invocation in : ins) {
      if (in.stubInfo() != null) {
        in.ignoreForVerification();
      }
    }
  }
  return mocks;
}
