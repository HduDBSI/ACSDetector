Boolean booleanObjectReturningMethod();
