/** 
 * @param logger target for the stubbing warnings
 * @param strictness how strict mocking / stubbing is concerned
 */
public JUnitRule(MockitoLogger logger,Strictness strictness){
  this.logger=logger;
  this.listener=new UniversalTestListener(strictness,logger);
}
