@Test public void should_capture_arguments_when_args_count_does_NOT_match() throws Exception {
  mock.varargs();
  Invocation invocation=getLastInvocation();
  InvocationMatcher invocationMatcher=new InvocationMatcher(invocation,(List)asList(ANY));
  invocationMatcher.captureArgumentsFrom(invocation);
}
