public boolean matches(Invocation actual){
  return invocation.getMock().equals(actual.getMock()) && hasSameMethod(actual) && argumentsMatch(this,actual);
}
