@Test public void shouldMatchTypes() throws Exception {
  ContainsExtraTypeInfo equals=new Equals(10);
  assertTrue(equals.typeMatches(10));
  assertFalse(equals.typeMatches(10L));
}
