@Test public void testMultiByteArray(){
  byte[][] array1=new byte[2][2];
  byte[][] array2=new byte[2][2];
  for (byte i=0; i < array1.length; ++i) {
    for (byte j=0; j < array1[0].length; j++) {
      array1[i][j]=i;
      array2[i][j]=i;
    }
  }
  assertTrue(new EqualsBuilder().append(array1,array1).isEquals());
  assertTrue(new EqualsBuilder().append(array1,array2).isEquals());
  array1[1][1]=0;
  assertTrue(!new EqualsBuilder().append(array1,array2).isEquals());
}
