@Test public void shouldPointStackTraceToPreviousInvocation(){
  inOrder.verify(mock,times(2)).simpleMethod(anyInt());
  inOrder.verify(mockTwo,times(2)).simpleMethod(anyInt());
  try {
    inOrder.verify(mock).simpleMethod(999);
    fail();
  }
 catch (  VerificationInOrderFailure e) {
    assertThat(e).hasMessageContaining("secondChunk(");
  }
}
