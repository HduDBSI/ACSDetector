@Test public void shouldNotAffectMockName(){
  IMethods mock=mock(IMethods.class,"mockie");
  IMethods mockTwo=mock(IMethods.class);
  reset(mock);
  assertThat(mockTwo.toString()).contains("Mock for IMethods");
  assertEquals("mockie","" + mock);
}
