@Test public void shouldVerifyInOrderMockTwoAndThree(){
  inOrder.verify(mockTwo,times(2)).simpleMethod(2);
  inOrder.verify(mockThree).simpleMethod(3);
  inOrder.verify(mockTwo).simpleMethod(2);
  verifyNoMoreInteractions(mockTwo,mockThree);
}
