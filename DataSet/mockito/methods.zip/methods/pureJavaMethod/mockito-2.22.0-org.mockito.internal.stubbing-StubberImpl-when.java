@Override public <T>T when(T mock){
  if (mock == null) {
    throw nullPassedToWhenMethod();
  }
  if (!isMock(mock)) {
    throw notAMockPassedToWhenMethod();
  }
  MockUtil.getInvocationContainer(mock).setAnswersForStubbing(answers,strictness);
  return mock;
}
