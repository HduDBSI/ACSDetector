@Override public void tooLittleActualInvocations(Discrepancy discrepancy,PrintableInvocation wanted,Location lastActualLocation){
  this.wantedCount=discrepancy.getWantedCount();
  this.actualCount=discrepancy.getActualCount();
  this.wanted=wanted;
  this.location=lastActualLocation;
}
