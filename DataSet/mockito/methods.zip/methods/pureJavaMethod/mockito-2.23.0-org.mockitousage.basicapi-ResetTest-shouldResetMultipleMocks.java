@Test public void shouldResetMultipleMocks(){
  mock.simpleMethod();
  mockTwo.simpleMethod();
  reset(mock,mockTwo);
  verifyNoMoreInteractions(mock,mockTwo);
}
