@Test public void shouldFailOnLastAndFirstInWrongOrder(){
  inOrder.verify(mockOne).simpleMethod(4);
  try {
    inOrder.verify(mockOne).simpleMethod(1);
    fail();
  }
 catch (  VerificationInOrderFailure e) {
  }
}
