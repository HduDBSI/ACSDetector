@Test(expected=ArgumentsAreDifferent.class) public void shouldNotMatchAgain() throws Exception {
  Child wanted=new Child(1,"foo",999,"bar");
  verify(mock).run(refEq(wanted));
}
