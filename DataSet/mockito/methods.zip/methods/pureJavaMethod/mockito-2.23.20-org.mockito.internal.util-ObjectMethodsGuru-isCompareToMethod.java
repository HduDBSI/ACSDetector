public static boolean isCompareToMethod(Method method){
  return Comparable.class.isAssignableFrom(method.getDeclaringClass()) && "compareTo".equals(method.getName()) && method.getParameterTypes().length == 1 && method.getParameterTypes()[0] == method.getDeclaringClass();
}
