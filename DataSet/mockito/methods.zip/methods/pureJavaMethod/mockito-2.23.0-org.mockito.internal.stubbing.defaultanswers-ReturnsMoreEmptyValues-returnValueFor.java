Object returnValueFor(Class<?> type){
  if (type == String.class) {
    return "";
  }
 else   if (type.isArray()) {
    Class<?> componentType=type.getComponentType();
    return Array.newInstance(componentType,0);
  }
  return null;
}
