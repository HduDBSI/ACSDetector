int foo(Object... objects);
