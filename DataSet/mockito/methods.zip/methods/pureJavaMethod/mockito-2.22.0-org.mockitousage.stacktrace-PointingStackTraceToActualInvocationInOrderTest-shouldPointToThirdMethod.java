@Test public void shouldPointToThirdMethod(){
  inOrder.verify(mock,atLeastOnce()).simpleMethod(anyInt());
  try {
    inOrder.verify(mockTwo).simpleMethod(999);
    fail();
  }
 catch (  VerificationInOrderFailure e) {
    assertThat(e).hasMessageContaining("third(");
  }
}
