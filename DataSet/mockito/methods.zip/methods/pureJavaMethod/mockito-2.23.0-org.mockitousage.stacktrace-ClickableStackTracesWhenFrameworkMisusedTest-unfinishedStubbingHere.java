@SuppressWarnings({"MockitoUsage","CheckReturnValue"}) private void unfinishedStubbingHere(){
  when(mock.simpleMethod());
}
