private void processIndependentAnnotations(final Class<?> clazz,final Object testInstance){
  Class<?> classContext=clazz;
  while (classContext != Object.class) {
    delegate.process(classContext,testInstance);
    spyAnnotationEngine.process(classContext,testInstance);
    classContext=classContext.getSuperclass();
  }
}
