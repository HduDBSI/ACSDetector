@Test public void shouldPrintVerificationInOrderErrorAndShowWantedAndActual(){
  try {
    inOrder.verify(one).simpleMethod(999);
    fail();
  }
 catch (  org.mockito.exceptions.verification.junit.ArgumentsAreDifferent e) {
    assertThat(e).hasMessageContaining("has different arguments");
  }
}
