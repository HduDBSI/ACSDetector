@Test public void shouldFailOnSecondMethodBecauseFourInvocationsWanted(){
  inOrder.verify(mockOne,times(1)).simpleMethod(1);
  try {
    inOrder.verify(mockTwo,times(4)).simpleMethod(2);
    fail();
  }
 catch (  VerificationInOrderFailure e) {
  }
}
