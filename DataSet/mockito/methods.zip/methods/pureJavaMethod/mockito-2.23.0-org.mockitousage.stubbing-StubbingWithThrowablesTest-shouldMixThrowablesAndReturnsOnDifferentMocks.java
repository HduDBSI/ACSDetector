@Test public void shouldMixThrowablesAndReturnsOnDifferentMocks() throws Exception {
  when(mock.add("ExceptionOne")).thenThrow(new ExceptionOne());
  when(mock.getLast()).thenReturn("last");
  doThrow(new ExceptionTwo()).when(mock).clear();
  doThrow(new ExceptionThree()).when(mockTwo).clear();
  when(mockTwo.containsValue("ExceptionFour")).thenThrow(new ExceptionFour());
  when(mockTwo.get("Are you there?")).thenReturn("Yes!");
  assertNull(mockTwo.get("foo"));
  assertTrue(mockTwo.keySet().isEmpty());
  assertEquals("Yes!",mockTwo.get("Are you there?"));
  try {
    mockTwo.clear();
    fail();
  }
 catch (  ExceptionThree e) {
  }
  try {
    mockTwo.containsValue("ExceptionFour");
    fail();
  }
 catch (  ExceptionFour e) {
  }
  assertNull(mock.getFirst());
  assertEquals("last",mock.getLast());
  try {
    mock.add("ExceptionOne");
    fail();
  }
 catch (  ExceptionOne e) {
  }
  try {
    mock.clear();
    fail();
  }
 catch (  ExceptionTwo e) {
  }
}
