@Test public void shouldVerifyNoMoreInteractionsAndFail(){
  spy.add("one");
  spy.add("two");
  verify(spy).add("one");
  try {
    verifyNoMoreInteractions(spy);
    fail();
  }
 catch (  NoInteractionsWanted e) {
  }
}
