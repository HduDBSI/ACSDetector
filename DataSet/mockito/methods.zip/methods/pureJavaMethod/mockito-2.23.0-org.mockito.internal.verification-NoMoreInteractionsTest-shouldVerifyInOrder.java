@Test public void shouldVerifyInOrder(){
  NoMoreInteractions n=new NoMoreInteractions();
  Invocation i=new InvocationBuilder().toInvocation();
  assertFalse(context.isVerified(i));
  try {
    n.verifyInOrder(new VerificationDataInOrderImpl(context,asList(i),null));
    fail();
  }
 catch (  VerificationInOrderFailure e) {
  }
}
