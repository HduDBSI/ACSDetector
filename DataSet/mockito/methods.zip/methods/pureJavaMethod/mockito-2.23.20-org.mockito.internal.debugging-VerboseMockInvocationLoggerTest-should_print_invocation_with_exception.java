@Test public void should_print_invocation_with_exception(){
  listener.reportInvocation(new NotifiedMethodInvocationReport(invocation,new ThirdPartyException()));
  assertThat(printed()).contains(invocation.toString()).contains(invocation.getLocation().toString()).contains(ThirdPartyException.class.getName());
}
