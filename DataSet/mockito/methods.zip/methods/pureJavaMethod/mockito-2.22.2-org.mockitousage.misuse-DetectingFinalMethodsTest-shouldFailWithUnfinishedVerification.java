@Test public void shouldFailWithUnfinishedVerification(){
  assumeTrue("Does not apply for inline mocks",withFinal.getClass() != WithFinal.class);
  verify(withFinal).foo();
  try {
    verify(withFinal).foo();
    fail();
  }
 catch (  UnfinishedVerificationException e) {
  }
}
