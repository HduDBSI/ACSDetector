@Test public void shouldScreamWhenNullPassed() throws Exception {
  try {
    AdditionalAnswers.returnsElementsOf(null);
    fail();
  }
 catch (  MockitoException e) {
  }
}
