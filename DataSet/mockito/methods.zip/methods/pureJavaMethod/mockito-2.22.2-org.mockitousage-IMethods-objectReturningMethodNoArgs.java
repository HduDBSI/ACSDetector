Object objectReturningMethodNoArgs();
