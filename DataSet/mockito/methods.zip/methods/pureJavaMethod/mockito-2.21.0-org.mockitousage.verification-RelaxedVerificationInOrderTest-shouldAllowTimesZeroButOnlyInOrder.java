@Test public void shouldAllowTimesZeroButOnlyInOrder(){
  inOrder.verify(mockTwo,atLeastOnce()).simpleMethod(2);
  inOrder.verify(mockOne,times(0)).simpleMethod(1);
  try {
    verify(mockOne,times(0)).simpleMethod(1);
    fail();
  }
 catch (  NeverWantedButInvoked e) {
  }
}
