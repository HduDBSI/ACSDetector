public int len(String text){
  return text.length();
}
