public static MockitoException cannotMockClass(Class<?> clazz,String reason){
  return new MockitoException(join("Cannot mock/spy " + clazz,"Mockito cannot mock/spy because :"," - " + reason));
}
