@Test(expected=IllegalArgumentException.class) public void should_not_allow_null_on_fields(){
  MockInjection.onFields((Set<Field>)null,this);
}
