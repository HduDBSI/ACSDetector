@Test public void shouldThrowSmartNPEWhenMethodReturnsClass() throws Exception {
  Foo mock=mock(Foo.class,RETURNS_SMART_NULLS);
  Foo foo=mock.getSomeClass();
  try {
    foo.boo();
    fail();
  }
 catch (  SmartNullPointerException e) {
  }
}
