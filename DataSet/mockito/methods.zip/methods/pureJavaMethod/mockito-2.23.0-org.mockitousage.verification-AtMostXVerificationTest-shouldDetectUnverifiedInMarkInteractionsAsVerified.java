@Test public void shouldDetectUnverifiedInMarkInteractionsAsVerified() throws Exception {
  mock.clear();
  mock.clear();
  undesiredInteraction();
  verify(mock,atMost(3)).clear();
  try {
    verifyNoMoreInteractions(mock);
    fail();
  }
 catch (  NoInteractionsWanted e) {
    assertThat(e).hasMessageContaining("undesiredInteraction(");
  }
}
