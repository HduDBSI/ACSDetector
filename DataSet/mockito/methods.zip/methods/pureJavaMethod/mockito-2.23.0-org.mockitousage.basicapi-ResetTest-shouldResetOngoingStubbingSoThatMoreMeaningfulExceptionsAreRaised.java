@Test public void shouldResetOngoingStubbingSoThatMoreMeaningfulExceptionsAreRaised(){
  mock.booleanReturningMethod();
  reset(mock);
  try {
    when(null).thenReturn("anything");
    fail();
  }
 catch (  MissingMethodInvocationException e) {
  }
}
