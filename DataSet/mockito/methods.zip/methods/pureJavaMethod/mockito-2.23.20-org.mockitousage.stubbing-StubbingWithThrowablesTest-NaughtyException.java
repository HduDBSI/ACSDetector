public NaughtyException(){
  throw new RuntimeException("boo!");
}
