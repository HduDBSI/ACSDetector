/** 
 * Create this verification mode, to be used to verify invocation ongoing data later.
 * @param pollingPeriodMillis The frequency to poll delegate.verify(), to check whether the delegate has been satisfied
 * @param delegate The verification mode to delegate overall success or failure to
 * @param returnOnSuccess Whether to immediately return successfully once the delegate is satisfied (as in{@link org.mockito.verification.VerificationWithTimeout}, or to only return once the delegate is satisfied and the full duration has passed (as in {@link org.mockito.verification.VerificationAfterDelay}).
 * @param timer Checker of whether the duration of the verification is still acceptable
 */
public VerificationOverTimeImpl(long pollingPeriodMillis,VerificationMode delegate,boolean returnOnSuccess,Timer timer){
  this.pollingPeriodMillis=pollingPeriodMillis;
  this.delegate=delegate;
  this.returnOnSuccess=returnOnSuccess;
  this.timer=timer;
}
