/** 
 * Test that stubbing of two mocks stubs don't interfere
 */
@Test public void interactions() throws Exception {
  OutputStream out1=new ByteArrayOutputStream();
  OutputStream out2=new ByteArrayOutputStream();
  SocketFactory sf1=mock(SocketFactory.class,RETURNS_DEEP_STUBS);
  when(sf1.createSocket().getOutputStream()).thenReturn(out1);
  SocketFactory sf2=mock(SocketFactory.class,RETURNS_DEEP_STUBS);
  when(sf2.createSocket().getOutputStream()).thenReturn(out2);
  assertSame(out1,sf1.createSocket().getOutputStream());
  assertSame(out2,sf2.createSocket().getOutputStream());
}
