void reportOngoingStubbing(OngoingStubbing<?> ongoingStubbing);
