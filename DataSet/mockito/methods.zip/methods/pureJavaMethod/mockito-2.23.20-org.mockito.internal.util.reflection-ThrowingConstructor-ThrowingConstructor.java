public ThrowingConstructor(Observer observer) throws IOException {
  throw new IOException();
}
