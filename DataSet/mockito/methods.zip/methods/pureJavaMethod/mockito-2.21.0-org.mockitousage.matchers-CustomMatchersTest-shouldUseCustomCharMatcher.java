@Test public void shouldUseCustomCharMatcher(){
  when(mock.oneArg(charThat(new IsSorZ()))).thenReturn("foo");
  assertEquals("foo",mock.oneArg('s'));
  assertEquals("foo",mock.oneArg('z'));
  assertEquals(null,mock.oneArg('x'));
}
