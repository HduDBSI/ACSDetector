/** 
 * similar means the same method name, same mock, unverified and: if arguments are the same cannot be overloaded
 */
@Override public boolean hasSimilarMethod(Invocation candidate){
  String wantedMethodName=getMethod().getName();
  String candidateMethodName=candidate.getMethod().getName();
  if (!wantedMethodName.equals(candidateMethodName)) {
    return false;
  }
  if (candidate.isVerified()) {
    return false;
  }
  if (getInvocation().getMock() != candidate.getMock()) {
    return false;
  }
  if (hasSameMethod(candidate)) {
    return true;
  }
  return !argumentsMatch(candidate);
}
