@Test public void can_remove_a_collection() throws Exception {
  HashCodeAndEqualsSafeSet mocks=HashCodeAndEqualsSafeSet.of(mock1,mock(Observer.class));
  HashCodeAndEqualsSafeSet workingSet=new HashCodeAndEqualsSafeSet();
  workingSet.addAll(mocks);
  workingSet.add(mock(List.class));
  assertThat(workingSet.removeAll(mocks)).isTrue();
  assertThat(workingSet.containsAll(mocks)).isFalse();
}
