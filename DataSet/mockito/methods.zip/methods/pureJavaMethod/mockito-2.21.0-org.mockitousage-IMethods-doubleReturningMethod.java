double doubleReturningMethod();
