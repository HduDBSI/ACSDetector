@Override public void validateFor(InvocationOnMock invocation){
  int argumentPosition=inferWantedArgumentPosition(invocation);
  validateIndexWithinInvocationRange(invocation,argumentPosition);
  validateArgumentTypeCompatibility(invocation,argumentPosition);
}
