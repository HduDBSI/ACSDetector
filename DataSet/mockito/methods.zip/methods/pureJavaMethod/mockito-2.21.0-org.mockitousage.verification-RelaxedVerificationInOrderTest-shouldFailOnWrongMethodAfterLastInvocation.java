@Test public void shouldFailOnWrongMethodAfterLastInvocation(){
  inOrder.verify(mockOne).simpleMethod(4);
  try {
    inOrder.verify(mockOne).simpleMethod(999);
    fail();
  }
 catch (  VerificationInOrderFailure e) {
  }
}
