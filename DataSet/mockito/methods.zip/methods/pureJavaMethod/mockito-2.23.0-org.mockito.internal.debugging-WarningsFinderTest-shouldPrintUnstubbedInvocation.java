@Test public void shouldPrintUnstubbedInvocation(){
  InvocationMatcher unstubbedInvocation=new InvocationBuilder().differentMethod().toInvocationMatcher();
  WarningsFinder finder=new WarningsFinder(Arrays.<Invocation>asList(),Arrays.<InvocationMatcher>asList(unstubbedInvocation));
  finder.find(listener);
  verify(listener,only()).foundUnstubbed(unstubbedInvocation);
}
