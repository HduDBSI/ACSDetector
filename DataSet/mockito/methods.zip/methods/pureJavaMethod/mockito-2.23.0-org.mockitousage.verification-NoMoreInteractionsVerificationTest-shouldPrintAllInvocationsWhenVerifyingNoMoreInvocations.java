@Test public void shouldPrintAllInvocationsWhenVerifyingNoMoreInvocations() throws Exception {
  mock.add(1);
  mock.add(2);
  mock.clear();
  verify(mock).add(2);
  try {
    verifyNoMoreInteractions(mock);
    fail();
  }
 catch (  NoInteractionsWanted e) {
    assertThat(e).hasMessageContaining("list of all invocations");
  }
}
