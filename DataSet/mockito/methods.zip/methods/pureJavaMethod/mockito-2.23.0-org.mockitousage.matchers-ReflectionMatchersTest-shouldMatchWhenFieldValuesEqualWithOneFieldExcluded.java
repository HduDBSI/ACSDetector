@Test public void shouldMatchWhenFieldValuesEqualWithOneFieldExcluded() throws Exception {
  Child wanted=new Child(1,"foo",2,"excluded");
  verify(mock).run(refEq(wanted,"childFieldTwo"));
}
