@Test public void shouldBeAbleToRetrieveMethodName() throws Exception {
  assertEquals(toStringMethod.getName(),method.getName());
}
