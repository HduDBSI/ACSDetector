@Test public void shouldNotCallRealMethodWhenStubbedLater(){
  TestedObject mock=mock(TestedObject.class);
  when(mock.getValue()).thenCallRealMethod();
  when(mock.getValue()).thenReturn("FAKE_VALUE");
  assertEquals("FAKE_VALUE",mock.getValue());
}
