@Test public void shouldThrowSmartNPEWhenMethodReturnsInterface() throws Exception {
  Foo mock=mock(Foo.class,RETURNS_SMART_NULLS);
  Bar bar=mock.getSomeInterface();
  try {
    bar.boo();
    fail();
  }
 catch (  SmartNullPointerException e) {
  }
}
