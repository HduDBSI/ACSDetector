@Test public void should_be_created_with_an_argument_resolver() throws Exception {
  new ParameterizedConstructorInstantiator(this,field("whateverForNow"),resolver);
}
