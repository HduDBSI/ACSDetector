@After public void cleanUpConfigInAnyCase(){
  ConfigurationAccess.getConfig().overrideCleansStackTrace(false);
  ConfigurationAccess.getConfig().overrideDefaultAnswer(null);
  StateMaster state=new StateMaster();
  state.validate();
  state.reset();
}
