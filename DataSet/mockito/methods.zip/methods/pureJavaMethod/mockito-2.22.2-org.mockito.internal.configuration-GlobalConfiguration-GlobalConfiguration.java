public GlobalConfiguration(){
  if (GLOBAL_CONFIGURATION.get() == null) {
    GLOBAL_CONFIGURATION.set(createConfig());
  }
}
