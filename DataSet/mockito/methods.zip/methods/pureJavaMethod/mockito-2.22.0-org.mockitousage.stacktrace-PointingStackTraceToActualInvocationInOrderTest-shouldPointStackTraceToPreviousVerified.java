@Test public void shouldPointStackTraceToPreviousVerified(){
  inOrder.verify(mock,atLeastOnce()).simpleMethod(anyInt());
  inOrder.verify(mockTwo).simpleMethod(anyInt());
  try {
    inOrder.verify(mock).simpleMethod(999);
    fail();
  }
 catch (  VerificationInOrderFailure e) {
    assertThat(e).hasMessageContaining("fourth(");
  }
}
