@Test public void shouldUseCustomObjectMatcher(){
  when(mock.oneArg(argThat(new ContainsFoo()))).thenReturn("foo");
  assertEquals("foo",mock.oneArg("foo"));
  assertEquals(null,mock.oneArg("bar"));
}
