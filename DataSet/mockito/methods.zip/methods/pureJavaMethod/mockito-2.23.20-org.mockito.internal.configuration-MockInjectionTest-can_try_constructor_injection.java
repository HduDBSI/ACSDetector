@Test public void can_try_constructor_injection() throws Exception {
  MockInjection.onField(field("withConstructor"),this).withMocks(oneSetMock()).tryConstructorInjection().apply();
  assertThat(withConstructor.initializedWithConstructor).isEqualTo(true);
}
