@Test public void shouldVerifyAtLeastXTimes() throws Exception {
  mock.clear();
  mock.clear();
  mock.clear();
  verify(mock,atLeast(2)).clear();
}
