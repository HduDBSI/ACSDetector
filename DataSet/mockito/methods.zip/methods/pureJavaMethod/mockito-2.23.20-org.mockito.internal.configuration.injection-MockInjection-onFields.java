/** 
 * Create a new configuration setup for fields
 * @param fields Fields needing mock injection
 * @param ofInstance Instance owning the <code>field</code>
 * @return New configuration builder
 */
public static OngoingMockInjection onFields(Set<Field> fields,Object ofInstance){
  return new OngoingMockInjection(fields,ofInstance);
}
