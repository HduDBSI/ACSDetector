public Object answer(InvocationOnMock invocation) throws Throwable {
  Object[] arguments=invocation.getArguments();
  for (int i=0; i < arguments.length; i++) {
    Object from=arguments[i];
    Instantiator instantiator=Plugins.getInstantiatorProvider().getInstantiator(null);
    Object newInstance=instantiator.newInstance(from.getClass());
    new LenientCopyTool().copyToRealObject(from,newInstance);
    arguments[i]=newInstance;
  }
  return new ReturnsEmptyValues().answer(invocation);
}
