@SuppressWarnings({"CheckReturnValue","MockitoUsage"}) public void detect(IMethods mock){
  verifyNoMoreInteractions(mock);
}
