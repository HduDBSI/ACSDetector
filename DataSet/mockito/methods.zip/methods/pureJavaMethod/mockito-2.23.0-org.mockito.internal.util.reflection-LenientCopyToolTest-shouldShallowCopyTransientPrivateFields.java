@Test public void shouldShallowCopyTransientPrivateFields() throws Exception {
  from.privateTransientField=1000;
  assertThat(to.privateTransientField).isNotEqualTo(1000);
  tool.copyToMock(from,to);
  assertEquals(1000,to.privateTransientField);
}
