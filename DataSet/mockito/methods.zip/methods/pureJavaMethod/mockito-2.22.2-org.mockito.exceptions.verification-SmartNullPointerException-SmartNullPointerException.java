public SmartNullPointerException(String message){
  super(message);
}
