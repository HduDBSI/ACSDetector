@Test public void shouldPassOnCombinationOfTimesAndAtLeastOnce(){
  mockTwo.simpleMethod(2);
  inOrder.verify(mockTwo,times(2)).simpleMethod(2);
  inOrder.verify(mockTwo,atLeastOnce()).simpleMethod(2);
  verifyNoMoreInteractions(mockTwo);
}
