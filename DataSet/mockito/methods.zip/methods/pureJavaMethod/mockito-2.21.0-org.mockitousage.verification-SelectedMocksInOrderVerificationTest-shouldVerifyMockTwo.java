@Test public void shouldVerifyMockTwo(){
  InOrder inOrder=inOrder(mockTwo);
  inOrder.verify(mockTwo,atLeastOnce()).simpleMethod(2);
  verifyNoMoreInteractions(mockTwo);
}
