public Not(ArgumentMatcher<?> matcher){
  this.matcher=matcher;
}
