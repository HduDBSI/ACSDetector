@Test public void shouldShallowCopyBasicFinalField() throws Exception {
  assertEquals(100,from.finalField);
  assertThat(to.finalField).isNotEqualTo(100);
  tool.copyToMock(from,to);
  assertEquals(100,to.finalField);
}
