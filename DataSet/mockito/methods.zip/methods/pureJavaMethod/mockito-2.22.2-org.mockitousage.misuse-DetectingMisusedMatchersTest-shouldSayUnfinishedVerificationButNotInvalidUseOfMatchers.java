@SuppressWarnings({"MockitoUsage","CheckReturnValue"}) @Test public void shouldSayUnfinishedVerificationButNotInvalidUseOfMatchers(){
  assumeTrue("Does not apply for inline mocks",withFinal.getClass() != WithFinal.class);
  verify(withFinal).finalMethod(anyObject());
  try {
    verify(withFinal);
    fail();
  }
 catch (  UnfinishedVerificationException e) {
  }
}
