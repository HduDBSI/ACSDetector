@Test public void shouldPrintThrowingInvocationOnMockToStdOut(){
  Foo foo=mock(Foo.class,withSettings().verboseLogging());
  doThrow(new ThirdPartyException()).when(foo).doSomething("Klipsch");
  try {
    foo.doSomething("Klipsch");
    fail("Exception excepted.");
  }
 catch (  ThirdPartyException e) {
    Assertions.assertThat(printed()).contains(getClass().getName()).contains(mockName(foo)).contains("doSomething").contains("Klipsch").contains(ThirdPartyException.class.getName());
  }
}
