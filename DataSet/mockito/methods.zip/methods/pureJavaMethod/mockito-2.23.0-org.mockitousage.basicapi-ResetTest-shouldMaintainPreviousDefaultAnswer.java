@Test public void shouldMaintainPreviousDefaultAnswer(){
  mock=mock(IMethods.class,RETURNS_MOCKS);
  reset(mock);
  assertNotNull(mock.iMethodsReturningMethod());
}
