private static URL[] getPossibleClassPathsUrls(){
  return new URL[]{obtainClassPath(),obtainClassPath("org.mockito.Mockito"),obtainClassPath("net.bytebuddy.ByteBuddy")};
}
