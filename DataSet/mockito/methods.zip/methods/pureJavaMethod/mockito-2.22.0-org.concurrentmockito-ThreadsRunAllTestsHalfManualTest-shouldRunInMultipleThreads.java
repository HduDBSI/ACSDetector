@Test public void shouldRunInMultipleThreads() throws Exception {
  assertEquals("Run in multiple thread failed for tests",Collections.emptySet(),runInMultipleThreads(3));
}
