@Test public void shouldAllowZeroInvocations() throws Exception {
  VerificationModeFactory.atLeast(0);
}
