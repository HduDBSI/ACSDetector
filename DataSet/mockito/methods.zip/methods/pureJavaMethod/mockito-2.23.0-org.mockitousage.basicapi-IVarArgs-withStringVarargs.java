void withStringVarargs(int value,String... s);
