public StackTraceElement[] toStackTrace(){
  StackTraceElement[] trace=new StackTraceElement[methods.length];
  for (int i=0; i < methods.length; i++) {
    trace[i]=new StackTraceElement("DummyClass",methods[i],"DummyClass.java",100);
  }
  return trace;
}
