public void updateNumberOfEnglishArticles(String newspaper,int i){
}
