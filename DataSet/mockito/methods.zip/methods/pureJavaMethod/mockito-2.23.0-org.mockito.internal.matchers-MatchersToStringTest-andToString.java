@Test public void andToString(){
  ArgumentMatcher<?> m1=new Equals(1);
  ArgumentMatcher<?> m2=new Equals(2);
  assertEquals("and(1, 2)",new And(m1,m2).toString());
}
