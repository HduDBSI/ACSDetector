@Test public void should_return_null_when_types_are_primitives() throws Exception {
  ConstructorInjection.SimpleArgumentResolver resolver=new ConstructorInjection.SimpleArgumentResolver(newSetOf(new HashMap<Integer,String>(),new TreeSet<Integer>()));
  Object[] resolvedInstance=resolver.resolveTypeInstances(Set.class,Map.class,Boolean.class);
  assertEquals(3,resolvedInstance.length);
  assertTrue(resolvedInstance[0] instanceof Set);
  assertTrue(resolvedInstance[1] instanceof Map);
  assertNull(resolvedInstance[2]);
}
