@Test public void shouldStartVerificationAndPullVerificationMode() throws Exception {
  assertNull(mockingProgress.pullVerificationMode());
  VerificationMode mode=VerificationModeFactory.times(19);
  mockingProgress.verificationStarted(mode);
  assertSame(mode,mockingProgress.pullVerificationMode());
  assertNull(mockingProgress.pullVerificationMode());
}
