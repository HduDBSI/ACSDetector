private void checkNotInner(Field field){
  Class<?> type=field.getType();
  if (type.isMemberClass() && !isStatic(type.getModifiers())) {
    throw new MockitoException("the type '" + type.getSimpleName() + "' is an inner non static class.");
  }
}
