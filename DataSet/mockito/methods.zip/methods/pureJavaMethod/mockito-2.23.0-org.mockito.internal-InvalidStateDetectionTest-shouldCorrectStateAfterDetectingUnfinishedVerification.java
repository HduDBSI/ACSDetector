@SuppressWarnings({"CheckReturnValue","MockitoUsage"}) @Test public void shouldCorrectStateAfterDetectingUnfinishedVerification(){
  mock.simpleMethod();
  verify(mock);
  try {
    verify(mock).simpleMethod();
    fail();
  }
 catch (  UnfinishedVerificationException e) {
  }
  verify(mock).simpleMethod();
}
