public void run(){
  try {
    starter.await();
  }
 catch (  InterruptedException e) {
    throw new RuntimeException(e);
  }
  c.setInvocationForPotentialStubbing(new InvocationMatcher(invocation));
  c.addAnswer(new Returns("foo"));
  c.findAnswerFor(invocation);
}
