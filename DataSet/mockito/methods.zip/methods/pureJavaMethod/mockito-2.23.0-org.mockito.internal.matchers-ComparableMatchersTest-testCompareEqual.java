@Test public void testCompareEqual(){
  test(new CompareEqual<String>("b"),false,false,true,"cmpEq");
  CompareEqual<BigDecimal> cmpEq=new CompareEqual<BigDecimal>(new BigDecimal("5.00"));
  assertTrue(cmpEq.matches(new BigDecimal("5")));
}
