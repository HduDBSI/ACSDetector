@Test public void shouldFindSuspiciousMatchers(){
  Equals matcherInt20=new Equals(20);
  Long longPretendingAnInt=20L;
  List<ArgumentMatcher> matchers=(List)Arrays.asList(new Equals(10),matcherInt20);
  Integer[] suspicious=ArgumentMatchingTool.getSuspiciouslyNotMatchingArgsIndexes(matchers,new Object[]{10,longPretendingAnInt});
  assertEquals(1,suspicious.length);
  assertEquals(new Integer(1),suspicious[0]);
}
