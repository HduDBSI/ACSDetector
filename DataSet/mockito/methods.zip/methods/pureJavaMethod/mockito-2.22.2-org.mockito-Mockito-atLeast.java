/** 
 * Allows at-least-x verification. E.g: <pre class="code"><code class="java"> verify(mock, atLeast(3)).someMethod("some arg"); </code></pre> See examples in javadoc for  {@link Mockito} class
 * @param minNumberOfInvocations minimum number of invocations
 * @return verification mode
 */
@CheckReturnValue public static VerificationMode atLeast(int minNumberOfInvocations){
  return VerificationModeFactory.atLeast(minNumberOfInvocations);
}
