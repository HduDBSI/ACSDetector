@Test public void shouldVerifyWhenWantedNumberOfInvocationsUsed() throws Exception {
  mock.add("one");
  mock.add("one");
  mock.add("one");
  verify(mock,times(3)).add("one");
  verifyNoMoreInteractions(mock);
}
