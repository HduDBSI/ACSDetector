@Test(expected=ArgumentsAreDifferent.class) public void shouldNotMatch() throws Exception {
  Child wanted=new Child(234234,"foo",2,"bar");
  verify(mock).run(refEq(wanted));
}
