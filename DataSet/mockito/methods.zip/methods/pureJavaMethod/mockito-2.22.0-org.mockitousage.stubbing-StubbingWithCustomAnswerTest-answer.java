public Object answer(InvocationOnMock invocation) throws Throwable {
  called=true;
  return null;
}
