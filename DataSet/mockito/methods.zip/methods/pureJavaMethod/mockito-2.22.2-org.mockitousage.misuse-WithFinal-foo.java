final int foo(){
  return 0;
}
