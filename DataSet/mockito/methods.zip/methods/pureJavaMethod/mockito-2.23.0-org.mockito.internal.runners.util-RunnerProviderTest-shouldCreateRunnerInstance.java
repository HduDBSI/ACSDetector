@Test public void shouldCreateRunnerInstance() throws Throwable {
  RunnerProvider provider=new RunnerProvider();
  InternalRunner runner=provider.newInstance(DefaultInternalRunner.class.getName(),this.getClass(),null);
  assertNotNull(runner);
}
