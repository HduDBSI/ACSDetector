@Test public void shouldVerifyExactNumberOfInvocationsUsingMatcher(){
  mock.simpleMethod(1);
  mock.simpleMethod(2);
  mock.simpleMethod(3);
  verify(mock,times(3)).simpleMethod(anyInt());
}
