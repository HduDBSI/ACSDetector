@SuppressWarnings("unchecked") private Collection<Object> instanceMocksOf(Object instance){
  return Fields.allDeclaredFieldsOf(instance).filter(annotatedBy(Mock.class,Spy.class)).notNull().assignedValues();
}
