boolean anyImportRunningOrRunnedToday(int importType,Date currentDate);
