void validateState();
