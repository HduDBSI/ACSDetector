public SomeObject(int finalField){
  this.finalField=finalField;
}
