Object returnValueFor(Class<?> type){
  if (Primitives.isPrimitiveOrWrapper(type)) {
    return Primitives.defaultValue(type);
  }
 else   if (type == Iterable.class) {
    return new ArrayList<Object>(0);
  }
 else   if (type == Collection.class) {
    return new LinkedList<Object>();
  }
 else   if (type == Set.class) {
    return new HashSet<Object>();
  }
 else   if (type == HashSet.class) {
    return new HashSet<Object>();
  }
 else   if (type == SortedSet.class) {
    return new TreeSet<Object>();
  }
 else   if (type == TreeSet.class) {
    return new TreeSet<Object>();
  }
 else   if (type == LinkedHashSet.class) {
    return new LinkedHashSet<Object>();
  }
 else   if (type == List.class) {
    return new LinkedList<Object>();
  }
 else   if (type == LinkedList.class) {
    return new LinkedList<Object>();
  }
 else   if (type == ArrayList.class) {
    return new ArrayList<Object>();
  }
 else   if (type == Map.class) {
    return new HashMap<Object,Object>();
  }
 else   if (type == HashMap.class) {
    return new HashMap<Object,Object>();
  }
 else   if (type == SortedMap.class) {
    return new TreeMap<Object,Object>();
  }
 else   if (type == TreeMap.class) {
    return new TreeMap<Object,Object>();
  }
 else   if (type == LinkedHashMap.class) {
    return new LinkedHashMap<Object,Object>();
  }
 else   if ("java.util.Optional".equals(type.getName())) {
    return JavaEightUtil.emptyOptional();
  }
 else   if ("java.util.OptionalDouble".equals(type.getName())) {
    return JavaEightUtil.emptyOptionalDouble();
  }
 else   if ("java.util.OptionalInt".equals(type.getName())) {
    return JavaEightUtil.emptyOptionalInt();
  }
 else   if ("java.util.OptionalLong".equals(type.getName())) {
    return JavaEightUtil.emptyOptionalLong();
  }
 else   if ("java.util.stream.Stream".equals(type.getName())) {
    return JavaEightUtil.emptyStream();
  }
 else   if ("java.util.stream.DoubleStream".equals(type.getName())) {
    return JavaEightUtil.emptyDoubleStream();
  }
 else   if ("java.util.stream.IntStream".equals(type.getName())) {
    return JavaEightUtil.emptyIntStream();
  }
 else   if ("java.util.stream.LongStream".equals(type.getName())) {
    return JavaEightUtil.emptyLongStream();
  }
  return null;
}
