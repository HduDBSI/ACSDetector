@SuppressWarnings({"MockitoUsage","CheckReturnValue"}) @Test public void shouldPointOutUnfinishedStubbing(){
  when(mock.simpleMethod());
  verify(mock).simpleMethod();
}
