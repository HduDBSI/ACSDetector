public boolean equals(){
  return false;
}
