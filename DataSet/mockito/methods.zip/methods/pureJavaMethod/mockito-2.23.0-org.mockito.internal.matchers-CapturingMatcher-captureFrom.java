public void captureFrom(Object argument){
  writeLock.lock();
  try {
    this.arguments.add(argument);
  }
  finally {
    writeLock.unlock();
  }
}
