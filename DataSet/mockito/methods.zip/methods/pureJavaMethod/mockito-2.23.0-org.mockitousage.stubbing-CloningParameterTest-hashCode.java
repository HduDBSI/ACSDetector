@Override public int hashCode(){
  final int prime=31;
  int result=1;
  result=prime * result + getOuterType().hashCode();
  result=prime * result + (emailSent ? 1231 : 1237);
  result=prime * result + ((name == null) ? 0 : name.hashCode());
  return result;
}
