@Test public void shouldVerifyActualNumberOfInvocationsSmallerThanWanted() throws Exception {
  mock.clear();
  mock.clear();
  mock.clear();
  Mockito.verify(mock,times(3)).clear();
  try {
    Mockito.verify(mock,times(100)).clear();
    fail();
  }
 catch (  TooLittleActualInvocations e) {
    assertThat(e).hasMessageContaining("mock.clear();").hasMessageContaining("Wanted 100 times").hasMessageContaining("was 3");
  }
}
