@Test public void shouldNotMarkAsVerifiedWhenAssertionFailed(){
  Invocation invocation=new InvocationBuilder().toInvocation();
  assertFalse(invocation.isVerified());
  try {
    only.verify(new VerificationDataStub(new InvocationBuilder().toInvocationMatcher(),invocation));
    fail();
  }
 catch (  MockitoAssertionError e) {
  }
  assertFalse(invocation.isVerified());
}
