@Override public Object getSpiedInstance(){
  return spiedInstance;
}
