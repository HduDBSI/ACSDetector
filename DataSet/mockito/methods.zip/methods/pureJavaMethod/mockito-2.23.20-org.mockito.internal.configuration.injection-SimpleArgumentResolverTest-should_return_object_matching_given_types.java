@Test public void should_return_object_matching_given_types() throws Exception {
  ConstructorInjection.SimpleArgumentResolver resolver=new ConstructorInjection.SimpleArgumentResolver(newSetOf(new HashSet<Long>(),new ByteArrayOutputStream(),new HashMap<String,String>()));
  Object[] resolvedInstance=resolver.resolveTypeInstances(Set.class,Map.class,OutputStream.class);
  assertEquals(3,resolvedInstance.length);
  assertTrue(resolvedInstance[0] instanceof Set);
  assertTrue(resolvedInstance[1] instanceof Map);
  assertTrue(resolvedInstance[2] instanceof OutputStream);
}
