/** 
 * Use it to capture the argument. This method <b>must be used inside of verification</b>. <p> Internally, this method registers a special implementation of an  {@link ArgumentMatcher}. This argument matcher stores the argument value so that you can use it later to perform assertions. <p> See examples in javadoc for  {@link ArgumentCaptor} class.
 * @return null or default values
 */
public T capture(){
  Mockito.argThat(capturingMatcher);
  return defaultValue(clazz);
}
