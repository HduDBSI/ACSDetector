StaticClassThrowingExceptionDefaultConstructor() throws Exception {
  throw new NullPointerException("business logic failed");
}
