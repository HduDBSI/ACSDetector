public <T>T createMock(MockCreationSettings<T> settings){
  MockHandler mockHandler=new MockHandlerFactory().create(settings);
  T mock=mockMaker.createMock(settings,mockHandler);
  Object spiedInstance=settings.getSpiedInstance();
  if (spiedInstance != null) {
    new LenientCopyTool().copyToMock(spiedInstance,mock);
  }
  return mock;
}
