@Test public void shouldAlterFinalLog(){
  int importType=0;
  Date currentDate=new GregorianCalendar(2009,10,12).getTime();
  ImportLogBean finalLog=new ImportLogBean(currentDate,importType);
  finalLog.setStatus(9);
  given(importLogDao.anyImportRunningOrRunnedToday(importType,currentDate)).willReturn(false);
  willAnswer(byCheckingLogEquals(finalLog)).given(importLogDao).alter(any(ImportLogBean.class));
  importManager.startImportProcess(importType,currentDate);
  verify(importLogDao).alter(any(ImportLogBean.class));
}
