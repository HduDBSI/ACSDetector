@Test public void shouldAllowToExcludeStubsForVerification() throws Exception {
  when(mock.simpleMethod()).thenReturn("foo");
  String stubbed=mock.simpleMethod();
  mock.objectArgMethod(stubbed);
  verify(mock).objectArgMethod("foo");
  try {
    verifyNoMoreInteractions(mock);
    fail();
  }
 catch (  NoInteractionsWanted e) {
  }
  ignoreStubs(mock);
  verifyNoMoreInteractions(mock);
}
