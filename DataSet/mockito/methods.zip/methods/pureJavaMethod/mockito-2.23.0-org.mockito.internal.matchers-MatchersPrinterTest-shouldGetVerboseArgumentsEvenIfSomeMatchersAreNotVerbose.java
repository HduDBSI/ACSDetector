@Test public void shouldGetVerboseArgumentsEvenIfSomeMatchersAreNotVerbose(){
  String line=printer.getArgumentsLine((List)Arrays.asList(new Equals(1L),NotNull.NOT_NULL),PrintSettings.verboseMatchers(0));
  assertEquals("((Long) 1L, notNull());",line);
}
