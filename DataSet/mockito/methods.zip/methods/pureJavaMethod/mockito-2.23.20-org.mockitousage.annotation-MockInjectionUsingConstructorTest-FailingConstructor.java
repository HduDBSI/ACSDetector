FailingConstructor(Set<?> set){
  throw new IllegalStateException("always fail");
}
