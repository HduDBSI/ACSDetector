private void thirdChunk(){
  mock.simpleMethod(3);
  mock.simpleMethod(3);
}
