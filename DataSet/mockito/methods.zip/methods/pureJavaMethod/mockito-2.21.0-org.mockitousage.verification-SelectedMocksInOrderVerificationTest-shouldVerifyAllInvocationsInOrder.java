@Test public void shouldVerifyAllInvocationsInOrder(){
  InOrder inOrder=inOrder(mockOne,mockTwo,mockThree);
  inOrder.verify(mockOne).simpleMethod(1);
  inOrder.verify(mockTwo,times(2)).simpleMethod(2);
  inOrder.verify(mockThree).simpleMethod(3);
  inOrder.verify(mockTwo).simpleMethod(2);
  inOrder.verify(mockOne).simpleMethod(4);
  verifyNoMoreInteractions(mockOne,mockTwo,mockThree);
}
