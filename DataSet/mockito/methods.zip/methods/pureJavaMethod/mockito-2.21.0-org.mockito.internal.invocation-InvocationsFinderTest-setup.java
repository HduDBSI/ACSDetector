@Before public void setup() throws Exception {
  simpleMethodInvocation=new InvocationBuilder().mock(mock).simpleMethod().seq(1).toInvocation();
  simpleMethodInvocationTwo=new InvocationBuilder().mock(mock).simpleMethod().seq(2).toInvocation();
  differentMethodInvocation=new InvocationBuilder().mock(mock).differentMethod().seq(3).toInvocation();
  invocations.addAll(Arrays.asList(simpleMethodInvocation,simpleMethodInvocationTwo,differentMethodInvocation));
}
