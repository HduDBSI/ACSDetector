@Test public void shouldAllowAllChunksBeforeLastInvocation(){
  inOrder.verify(mockTwo,times(3)).simpleMethod(2);
  inOrder.verify(mockOne).simpleMethod(4);
  verifyNoMoreInteractions(mockTwo);
}
