private void printlnIndented(String message){
  printStream.println("   " + message);
}
