public NotAMockException(String message){
  super(message);
}
