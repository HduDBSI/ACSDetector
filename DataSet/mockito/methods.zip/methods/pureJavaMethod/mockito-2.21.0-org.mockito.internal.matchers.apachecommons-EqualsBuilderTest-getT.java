public int getT(){
  return t;
}
