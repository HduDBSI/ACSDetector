private Field field(String fieldName) throws NoSuchFieldException {
  return this.getClass().getDeclaredField(fieldName);
}
