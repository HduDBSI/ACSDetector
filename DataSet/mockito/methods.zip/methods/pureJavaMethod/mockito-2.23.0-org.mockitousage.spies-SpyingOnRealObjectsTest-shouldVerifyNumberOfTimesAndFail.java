@Test public void shouldVerifyNumberOfTimesAndFail(){
  spy.add("one");
  spy.add("one");
  try {
    verify(spy,times(3)).add("one");
    fail();
  }
 catch (  TooLittleActualInvocations e) {
  }
}
