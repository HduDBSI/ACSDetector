String verySlowMethod();
