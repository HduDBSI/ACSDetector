@Test public void shouldVerifyInOrderUsingMatcher(){
  mockOne.simpleMethod(1);
  mockOne.simpleMethod(2);
  mockTwo.differentMethod();
  mockOne.simpleMethod(3);
  mockOne.simpleMethod(4);
  verify(mockOne,times(4)).simpleMethod(anyInt());
  inOrder.verify(mockOne,times(2)).simpleMethod(anyInt());
  inOrder.verify(mockTwo).differentMethod();
  inOrder.verify(mockOne,times(2)).simpleMethod(anyInt());
  try {
    inOrder.verify(mockOne,times(3)).simpleMethod(anyInt());
    fail();
  }
 catch (  VerificationInOrderFailure e) {
  }
}
