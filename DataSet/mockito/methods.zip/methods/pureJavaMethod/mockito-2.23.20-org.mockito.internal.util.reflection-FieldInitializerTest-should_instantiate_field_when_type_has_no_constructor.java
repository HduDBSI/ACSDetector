@Test public void should_instantiate_field_when_type_has_no_constructor() throws Exception {
  FieldInitializer fieldInitializer=new FieldInitializer(this,field("noConstructor"));
  FieldInitializationReport report=fieldInitializer.initialize();
  assertNotNull(report.fieldInstance());
  assertTrue(report.fieldWasInitialized());
  assertFalse(report.fieldWasInitializedUsingContructorArgs());
}
