@Test public void shouldAllowVerifyingInThreads() throws Exception {
  for (int i=0; i < 50; i++) {
    performTest();
  }
}
