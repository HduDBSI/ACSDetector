/** 
 * Sets a generic Answer for the method. E.g: <pre class="code"><code class="java"> when(mock.someMethod(10)).thenAnswer(new Answer&lt;Integer&gt;() { public Integer answer(InvocationOnMock invocation) throws Throwable { return (Integer) invocation.getArguments()[0]; } } </code></pre>
 * @param answer the custom answer to execute.
 * @return object that allows stubbing consecutive calls
 */
OngoingStubbing<T> thenAnswer(Answer<?> answer);
