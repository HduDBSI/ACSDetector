public Invocation findSimilarInvocation(List<Invocation> invocations,InvocationMatcher wanted,VerificationModeImpl mode){
  for (  Invocation invocation : invocations) {
    if (wanted.isSimilarTo(invocation)) {
      return invocation;
    }
  }
  return null;
}
