public boolean matches(Number actual){
  if (wanted == null ^ actual == null) {
    return false;
  }
  if (wanted == actual) {
    return true;
  }
  return wanted.doubleValue() - delta.doubleValue() <= actual.doubleValue() && actual.doubleValue() <= wanted.doubleValue() + delta.doubleValue();
}
