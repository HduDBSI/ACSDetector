@Test public void shouldDescribeUsingToString(){
  String descStr=new Equals(100).toString();
  assertEquals("100",descStr);
}
