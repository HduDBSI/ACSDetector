protected abstract boolean matchResult(int result);
