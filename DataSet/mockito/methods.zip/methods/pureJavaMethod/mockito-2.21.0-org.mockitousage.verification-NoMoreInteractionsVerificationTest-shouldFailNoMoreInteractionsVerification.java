@Test public void shouldFailNoMoreInteractionsVerification() throws Exception {
  mock.clear();
  try {
    verifyNoMoreInteractions(mock);
    fail();
  }
 catch (  NoInteractionsWanted e) {
  }
}
