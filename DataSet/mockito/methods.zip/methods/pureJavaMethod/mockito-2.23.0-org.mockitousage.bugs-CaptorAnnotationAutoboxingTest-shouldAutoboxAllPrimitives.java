@Test public void shouldAutoboxAllPrimitives(){
  verify(fun,never()).moreFun(intCaptor.capture());
}
