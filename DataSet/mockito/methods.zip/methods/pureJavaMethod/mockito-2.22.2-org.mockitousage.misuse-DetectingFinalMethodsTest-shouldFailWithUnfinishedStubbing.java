@Test public void shouldFailWithUnfinishedStubbing(){
  assumeTrue("Does not apply for inline mocks",withFinal.getClass() != WithFinal.class);
  withFinal=mock(WithFinal.class);
  try {
    when(withFinal.foo()).thenReturn(null);
    fail();
  }
 catch (  MissingMethodInvocationException e) {
  }
}
