@Test(expected=VerificationInOrderFailure.class) public void shouldFailWhenMockTwoWantedZeroTimes(){
  inOrder.verify(mockTwo,times(0)).simpleMethod(2);
}
