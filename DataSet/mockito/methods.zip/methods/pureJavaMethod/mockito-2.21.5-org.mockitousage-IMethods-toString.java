String toString(String foo);
