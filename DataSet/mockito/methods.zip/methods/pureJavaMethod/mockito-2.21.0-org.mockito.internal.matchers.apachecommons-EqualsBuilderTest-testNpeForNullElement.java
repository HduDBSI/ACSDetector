/** 
 * Test from http://issues.apache.org/bugzilla/show_bug.cgi?id=33067
 */
@Test public void testNpeForNullElement(){
  Object[] x1=new Object[]{new Integer(1),null,new Integer(3)};
  Object[] x2=new Object[]{new Integer(1),new Integer(2),new Integer(3)};
  new EqualsBuilder().append(x1,x2);
}
