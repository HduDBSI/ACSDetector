@Test public void shouldNotThrowNPEWhenIntegerPassedToEq(){
  mock.intArgumentMethod(100);
  verify(mock).intArgumentMethod(eq(new Integer(100)));
}
