@Test public void shouldNotThrowNPEWhenIntegerPassed(){
  mock.intArgumentMethod(100);
  verify(mock).intArgumentMethod(isA(Integer.class));
}
