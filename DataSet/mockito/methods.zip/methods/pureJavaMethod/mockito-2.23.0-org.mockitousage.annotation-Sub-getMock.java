public IMethods getMock(){
  return mock;
}
