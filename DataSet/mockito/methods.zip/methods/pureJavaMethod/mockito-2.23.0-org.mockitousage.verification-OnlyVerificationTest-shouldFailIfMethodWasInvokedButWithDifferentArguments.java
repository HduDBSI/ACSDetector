@Test public void shouldFailIfMethodWasInvokedButWithDifferentArguments(){
  mock.get(0);
  mock.get(2);
  try {
    verify(mock,only()).get(999);
    fail();
  }
 catch (  WantedButNotInvoked e) {
  }
}
