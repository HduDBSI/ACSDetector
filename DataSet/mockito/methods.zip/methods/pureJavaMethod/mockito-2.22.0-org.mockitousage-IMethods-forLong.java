String forLong(Long value);
