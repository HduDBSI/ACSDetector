@Test public void should_pass_proper_checked_exception() throws Throwable {
  new ThrowsException(new CharacterCodingException()).validateFor(createMethodInvocation());
}
