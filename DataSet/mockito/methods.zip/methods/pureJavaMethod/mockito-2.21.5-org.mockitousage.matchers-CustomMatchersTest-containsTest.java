private String containsTest(){
  return argThat(new StringThatContainsXxx());
}
