@Test public void shouldPointOutInteractionsOnMockWhenOrdinaryVerificationFails(){
  mock.otherMethod();
  mock.booleanObjectReturningMethod();
  verify(mock).simpleMethod();
}
