@Test public void shouldAllowTwoTimesOnMockTwo(){
  InOrder inOrder=inOrder(mockTwo,mockThree);
  inOrder.verify(mockTwo,times(2)).simpleMethod(2);
  try {
    verifyNoMoreInteractions(mockTwo);
    fail();
  }
 catch (  NoInteractionsWanted e) {
  }
}
