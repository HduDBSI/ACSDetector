public void run(){
  Result result=JUnitCore.runClasses(EqualsTest.class,ListUtilTest.class,MockingProgressImplTest.class,TimesTest.class,MockHandlerImplTest.class,AllInvocationsFinderTest.class,ReturnsEmptyValuesTest.class,NumberOfInvocationsCheckerTest.class,DefaultRegisteredInvocationsTest.class,MissingInvocationCheckerTest.class,NumberOfInvocationsInOrderCheckerTest.class,MissingInvocationInOrderCheckerTest.class,TypeCachingMockBytecodeGeneratorTest.class,InvocationMatcherTest.class,InvocationsFinderTest.class,MockitoTest.class,MockUtilTest.class,ReporterTest.class,MockitoAssertionErrorTest.class,MockitoExceptionTest.class,StackTraceFilteringTest.class,BridgeMethodPuzzleTest.class,OverloadingPuzzleTest.class,InvalidUsageTest.class,UsingVarargsTest.class,CustomMatchersTest.class,ComparableMatchersTest.class,InvalidUseOfMatchersTest.class,MatchersTest.class,MatchersToStringTest.class,VerificationAndStubbingUsingMatchersTest.class,BasicStubbingTest.class,ReturningDefaultValuesTest.class,StubbingWithThrowablesTest.class,AtMostXVerificationTest.class,BasicVerificationTest.class,ExactNumberOfTimesVerificationTest.class,VerificationInOrderTest.class,NoMoreInteractionsVerificationTest.class,SelectedMocksInOrderVerificationTest.class,VerificationOnMultipleMocksUsingMatchersTest.class,VerificationUsingMatchersTest.class,RelaxedVerificationInOrderTest.class,DescriptiveMessagesWhenVerificationFailsTest.class,DescriptiveMessagesWhenTimesXVerificationFailsTest.class,BasicVerificationInOrderTest.class,VerificationInOrderMixedWithOrdiraryVerificationTest.class,DescriptiveMessagesOnVerificationInOrderErrorsTest.class,InvalidStateDetectionTest.class,ReplacingObjectMethodsTest.class,ClickableStackTracesTest.class,ExampleTest.class,PointingStackTraceToActualInvocationTest.class,VerificationInOrderFromMultipleThreadsTest.class,ResetTest.class,ReturnsGenericDeepStubsTest.class);
  if (!result.wasSuccessful()) {
    System.err.println("Thread[" + Thread.currentThread().getId() + "]: error!");
    List<Failure> failures=result.getFailures();
    System.err.println(failures.size());
    for (    Failure failure : failures) {
      System.err.println(failure.getTrace());
      failed.add(failure.getDescription().getTestClass());
    }
  }
}
