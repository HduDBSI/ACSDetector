private void finalizeResume(ImportLogBean importLogBean){
  importLogDao.alter(importLogBean);
}
