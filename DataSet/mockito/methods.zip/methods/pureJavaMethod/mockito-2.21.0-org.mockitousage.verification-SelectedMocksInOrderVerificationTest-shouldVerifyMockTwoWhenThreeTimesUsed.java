@Test public void shouldVerifyMockTwoWhenThreeTimesUsed(){
  InOrder inOrder=inOrder(mockTwo);
  inOrder.verify(mockTwo,times(3)).simpleMethod(2);
  verifyNoMoreInteractions(mockTwo);
}
