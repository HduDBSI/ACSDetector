public int intReturningMethod(){
  return 0;
}
