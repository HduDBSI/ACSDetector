public TestEmptySubObject(int a){
  super(a);
}
