/** 
 * Decrement counter and wait until counter has value 0
 */
public String answer(InvocationOnMock invocation) throws Throwable {
  counter.decrementAndGet();
  while (counter.get() != 0) {
    Thread.sleep(10);
  }
  return null;
}
