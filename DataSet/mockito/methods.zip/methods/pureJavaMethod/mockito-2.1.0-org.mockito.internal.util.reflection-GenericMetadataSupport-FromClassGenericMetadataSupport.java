public FromClassGenericMetadataSupport(Class<?> clazz){
  this.clazz=clazz;
  registerTypeParametersOn(clazz.getTypeParameters());
  registerAllTypeVariables(clazz);
}
