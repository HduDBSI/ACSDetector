public static boolean isToString(InvocationOnMock invocation){
  return new ObjectMethodsGuru().isToString(invocation.getMethod());
}
