@Test public void shouldNotThrowNPEWhenIntPassed(){
  mock.intArgumentMethod(100);
  verify(mock).intArgumentMethod(isA(Integer.class));
}
