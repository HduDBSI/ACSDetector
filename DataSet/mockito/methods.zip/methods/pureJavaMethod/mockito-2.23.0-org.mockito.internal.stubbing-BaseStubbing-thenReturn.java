@Override public OngoingStubbing<T> thenReturn(T value,T... values){
  OngoingStubbing<T> stubbing=thenReturn(value);
  if (values == null) {
    return stubbing.thenReturn(null);
  }
  for (  T v : values) {
    stubbing=stubbing.thenReturn(v);
  }
  return stubbing;
}
