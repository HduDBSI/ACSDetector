@Test public void shouldDetectRedundantInvocation() throws Exception {
  mock.clear();
  mock.add("foo");
  mock.add("bar");
  verify(mock).clear();
  verify(mock).add("foo");
  try {
    verifyNoMoreInteractions(mock);
    fail();
  }
 catch (  NoInteractionsWanted e) {
  }
}
