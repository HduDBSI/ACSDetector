@Test public void shouldFailWhenMiddleMethodVerifiedFirst(){
  inOrder.verify(mockTwo,times(2)).simpleMethod(2);
  try {
    inOrder.verify(mockOne).simpleMethod(1);
    fail();
  }
 catch (  VerificationInOrderFailure e) {
  }
}
