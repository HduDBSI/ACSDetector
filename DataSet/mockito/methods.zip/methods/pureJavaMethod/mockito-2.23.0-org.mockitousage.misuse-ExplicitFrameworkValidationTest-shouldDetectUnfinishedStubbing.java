@SuppressWarnings({"MockitoUsage","CheckReturnValue"}) @Test public void shouldDetectUnfinishedStubbing(){
  when(mock.simpleMethod());
  try {
    Mockito.validateMockitoUsage();
    fail();
  }
 catch (  UnfinishedStubbingException e) {
  }
}
