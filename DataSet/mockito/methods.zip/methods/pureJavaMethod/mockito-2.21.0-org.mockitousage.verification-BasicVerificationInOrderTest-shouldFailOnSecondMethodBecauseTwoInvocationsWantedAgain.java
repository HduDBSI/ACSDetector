@Test public void shouldFailOnSecondMethodBecauseTwoInvocationsWantedAgain(){
  inOrder.verify(mockOne,times(1)).simpleMethod(1);
  try {
    inOrder.verify(mockTwo,times(0)).simpleMethod(2);
    fail();
  }
 catch (  VerificationInOrderFailure e) {
  }
}
