public static NoMoreInteractions noMoreInteractions(){
  return new NoMoreInteractions();
}
