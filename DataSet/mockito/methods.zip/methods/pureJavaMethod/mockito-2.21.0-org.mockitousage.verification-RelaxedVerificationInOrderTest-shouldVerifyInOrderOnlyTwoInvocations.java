@Test public void shouldVerifyInOrderOnlyTwoInvocations(){
  inOrder.verify(mockTwo,times(2)).simpleMethod(2);
  inOrder.verify(mockOne).simpleMethod(4);
}
