private static List<Invocation> removeVerifiedInOrder(List<Invocation> invocations,InOrderContext orderingContext){
  List<Invocation> unverified=new LinkedList<Invocation>();
  for (  Invocation i : invocations) {
    if (orderingContext.isVerified(i)) {
      unverified.clear();
    }
 else {
      unverified.add(i);
    }
  }
  return unverified;
}
