@Test @Ignore public void test(){
  IMethods mock=mock(IMethods.class);
  mock.simpleMethod(1);
  mock.otherMethod();
  verify(mock).simpleMethod(1);
  throw new RuntimeException("boo");
}
