@Test public void testLongArray(){
  long[] obj1=new long[2];
  obj1[0]=5L;
  obj1[1]=6L;
  long[] obj2=new long[2];
  obj2[0]=5L;
  obj2[1]=6L;
  assertTrue(new EqualsBuilder().append(obj1,obj1).isEquals());
  assertTrue(new EqualsBuilder().append(obj1,obj2).isEquals());
  obj1[1]=7;
  assertTrue(!new EqualsBuilder().append(obj1,obj2).isEquals());
  obj2=null;
  assertTrue(!new EqualsBuilder().append(obj1,obj2).isEquals());
  obj1=null;
  assertTrue(new EqualsBuilder().append(obj1,obj2).isEquals());
}
