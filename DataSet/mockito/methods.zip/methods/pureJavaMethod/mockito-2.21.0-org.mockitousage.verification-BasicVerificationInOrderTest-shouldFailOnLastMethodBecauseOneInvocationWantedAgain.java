@Test public void shouldFailOnLastMethodBecauseOneInvocationWantedAgain(){
  inOrder.verify(mockOne,atLeastOnce()).simpleMethod(1);
  inOrder.verify(mockTwo,times(2)).simpleMethod(2);
  inOrder.verify(mockThree,atLeastOnce()).simpleMethod(3);
  inOrder.verify(mockTwo,atLeastOnce()).simpleMethod(2);
  try {
    inOrder.verify(mockOne,times(2)).simpleMethod(4);
    fail();
  }
 catch (  VerificationInOrderFailure e) {
  }
}
