@Test public void shouldMarkAsVerifiedInOrder() throws Exception {
  Invocation invocation=buildSimpleMethod().toInvocation();
  invocations=asList(invocation);
  wanted=buildSimpleMethod().toInvocationMatcher();
  assertThat(context.isVerified(invocation)).isFalse();
  NumberOfInvocationsChecker.checkNumberOfInvocations(invocations,wanted,1,context);
  assertThat(context.isVerified(invocation)).isTrue();
}
