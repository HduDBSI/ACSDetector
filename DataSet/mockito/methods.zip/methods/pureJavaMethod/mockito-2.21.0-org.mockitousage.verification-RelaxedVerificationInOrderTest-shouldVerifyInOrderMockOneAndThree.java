@Test public void shouldVerifyInOrderMockOneAndThree(){
  inOrder.verify(mockOne).simpleMethod(1);
  inOrder.verify(mockThree).simpleMethod(3);
  inOrder.verify(mockOne).simpleMethod(4);
  verifyNoMoreInteractions(mockOne,mockThree);
}
