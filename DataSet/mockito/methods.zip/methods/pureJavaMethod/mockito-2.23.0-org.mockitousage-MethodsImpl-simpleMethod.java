public String simpleMethod(String one,String[] two){
  return null;
}
