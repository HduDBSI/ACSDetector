public String oneArg(String value){
  return null;
}
