@Override public OngoingStubbing<T> thenThrow(Class<? extends Throwable> toBeThrown,Class<? extends Throwable>... nextToBeThrown){
  if (nextToBeThrown == null) {
    return thenThrow((Class<Throwable>)null);
  }
  OngoingStubbing<T> stubbing=thenThrow(toBeThrown);
  for (  Class<? extends Throwable> t : nextToBeThrown) {
    stubbing=stubbing.thenThrow(t);
  }
  return stubbing;
}
