public void assertValue(String value){
  assertTrue("This substring: \n" + substring + "\nshould be at the end of:\n"+ value,value.endsWith(substring));
}
