@Test public void shouldToStringBeNotVerifiable() throws Exception {
  InvocationMatcher toString=new InvocationBuilder().method("toString").toInvocationMatcher();
  try {
    new VerificationDataImpl(null,toString);
    fail();
  }
 catch (  MockitoException e) {
  }
}
