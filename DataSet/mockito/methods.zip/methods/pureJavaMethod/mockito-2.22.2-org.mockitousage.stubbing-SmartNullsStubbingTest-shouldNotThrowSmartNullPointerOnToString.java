@Test public void shouldNotThrowSmartNullPointerOnToString(){
  Object smartNull=mock.objectReturningMethod();
  try {
    verify(mock).simpleMethod(smartNull);
    fail();
  }
 catch (  WantedButNotInvoked e) {
  }
}
