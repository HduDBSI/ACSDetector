@Test public void shouldInstantiateExceptionClassOnInteraction(){
  when(mock.add(null)).thenThrow(NaughtyException.class);
  exception.expect(NaughtyException.class);
  mock.add(null);
}
