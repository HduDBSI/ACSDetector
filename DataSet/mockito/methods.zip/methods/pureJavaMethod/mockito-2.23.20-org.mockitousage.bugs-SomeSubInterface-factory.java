ExtendedFactory factory();
