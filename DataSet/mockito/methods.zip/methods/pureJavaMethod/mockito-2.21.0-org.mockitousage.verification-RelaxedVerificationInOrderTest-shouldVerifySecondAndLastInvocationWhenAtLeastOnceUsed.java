@Test public void shouldVerifySecondAndLastInvocationWhenAtLeastOnceUsed(){
  inOrder.verify(mockTwo,atLeastOnce()).simpleMethod(2);
  inOrder.verify(mockOne).simpleMethod(4);
}
