@Override public MockSettings defaultAnswer(Answer defaultAnswer){
  this.defaultAnswer=defaultAnswer;
  if (defaultAnswer == null) {
    throw defaultAnswerDoesNotAcceptNullParameter();
  }
  return this;
}
