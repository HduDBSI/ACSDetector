@SuppressWarnings("all") @Test public void tryDescriptiveMessagesOnMisuse(){
  Foo foo=mock(Foo.class);
}
