String forList(List<String> list);
