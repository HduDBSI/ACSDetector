@Before public void setup(){
  mockOne=mock(IMethods.class);
  mockTwo=mock(IMethods.class);
}
