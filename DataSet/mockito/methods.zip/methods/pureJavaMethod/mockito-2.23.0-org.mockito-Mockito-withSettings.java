/** 
 * Allows mock creation with additional mock settings. <p> Don't use it too often. Consider writing simple tests that use simple mocks. Repeat after me: simple tests push simple, KISSy, readable & maintainable code. If you cannot write a test in a simple way - refactor the code under test. <p> Examples of mock settings: <pre class="code"><code class="java"> //Creates mock with different default answer & name Foo mock = mock(Foo.class, withSettings() .defaultAnswer(RETURNS_SMART_NULLS) .name("cool mockie")); //Creates mock with different default answer, descriptive name and extra interfaces Foo mock = mock(Foo.class, withSettings() .defaultAnswer(RETURNS_SMART_NULLS) .name("cool mockie") .extraInterfaces(Bar.class)); </code></pre> {@link MockSettings} has been introduced for two reasons.Firstly, to make it easy to add another mock settings when the demand comes. Secondly, to enable combining different mock settings without introducing zillions of overloaded mock() methods. <p> See javadoc for  {@link MockSettings} to learn about possible mock settings.<p>
 * @return mock settings instance with defaults.
 */
@CheckReturnValue public static MockSettings withSettings(){
  return new MockSettingsImpl().defaultAnswer(RETURNS_DEFAULTS);
}
