@Test public void shouldNotThrowCCE(){
  mock.simpleMethod(new Object());
  try {
    verify(mock).simpleMethod(argThat(isStringWithTextFoo()));
    fail();
  }
 catch (  ArgumentsAreDifferent e) {
  }
}
