@Test public void shouldAnswerVoidMethodConsecutively() throws Exception {
  RecordCall call1=new RecordCall();
  RecordCall call2=new RecordCall();
  doAnswer(call1).doThrow(new UnsupportedOperationException()).doAnswer(call2).when(mock).voidMethod();
  mock.voidMethod();
  assertTrue(call1.isCalled());
  assertFalse(call2.isCalled());
  try {
    mock.voidMethod();
    fail();
  }
 catch (  UnsupportedOperationException e) {
  }
  mock.voidMethod();
  assertTrue(call2.isCalled());
}
