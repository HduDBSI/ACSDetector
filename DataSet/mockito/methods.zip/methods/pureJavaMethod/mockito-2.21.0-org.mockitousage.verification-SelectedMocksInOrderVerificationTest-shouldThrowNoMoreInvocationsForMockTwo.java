@Test public void shouldThrowNoMoreInvocationsForMockTwo(){
  InOrder inOrder=inOrder(mockTwo);
  try {
    inOrder.verify(mockTwo,times(2)).simpleMethod(2);
    fail();
  }
 catch (  VerificationInOrderFailure e) {
  }
}
