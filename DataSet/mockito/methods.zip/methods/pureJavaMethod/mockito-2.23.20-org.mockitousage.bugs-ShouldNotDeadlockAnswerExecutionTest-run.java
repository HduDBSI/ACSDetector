public void run(){
  service.verySlowMethod();
}
