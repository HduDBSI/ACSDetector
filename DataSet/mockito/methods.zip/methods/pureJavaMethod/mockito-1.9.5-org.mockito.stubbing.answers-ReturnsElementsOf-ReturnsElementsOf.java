@Deprecated public ReturnsElementsOf(Collection<?> elements){
  super(elements);
}
