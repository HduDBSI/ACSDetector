@Test public void shouldVerifyUsingSameMatcher(){
  Object one=new String("1243");
  Object two=new String("1243");
  Object three=new String("1243");
  assertNotSame(one,two);
  assertEquals(one,two);
  assertEquals(two,three);
  mock.oneArg(one);
  mock.oneArg(two);
  verify(mock).oneArg(same(one));
  verify(mock,times(2)).oneArg(two);
  try {
    verify(mock).oneArg(same(three));
    fail();
  }
 catch (  WantedButNotInvoked e) {
  }
}
