@Test public void shouldBeEqualForTwoInstances() throws Exception {
  assertTrue(new SerializableMethod(toStringMethod).equals(method));
}
