@Test public void shouldFilterStacktraceWhenInOrderThrowsMockitoException(){
  try {
    inOrder();
    fail();
  }
 catch (  MockitoException expected) {
    Assertions.assertThat(expected).has(firstMethodInStackTrace("shouldFilterStacktraceWhenInOrderThrowsMockitoException"));
  }
}
