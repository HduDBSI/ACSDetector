/** 
 * Scans the classpath for given pluginType. If not found, default class is used.
 */
@SuppressWarnings("unchecked") <T>T loadPlugin(final Class<T> pluginType){
  try {
    T plugin=loadImpl(pluginType);
    if (plugin != null) {
      return plugin;
    }
    return plugins.getDefaultPlugin(pluginType);
  }
 catch (  final Throwable t) {
    return (T)Proxy.newProxyInstance(pluginType.getClassLoader(),new Class<?>[]{pluginType},new InvocationHandler(){
      @Override public Object invoke(      Object proxy,      Method method,      Object[] args) throws Throwable {
        throw new IllegalStateException("Could not initialize plugin: " + pluginType,t);
      }
    }
);
  }
}
