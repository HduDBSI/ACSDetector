Foo(){
  bar=new Bar();
  bar.foo=this;
}
