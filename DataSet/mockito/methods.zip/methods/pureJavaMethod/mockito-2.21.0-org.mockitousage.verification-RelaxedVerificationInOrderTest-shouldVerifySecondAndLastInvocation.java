@Test public void shouldVerifySecondAndLastInvocation(){
  inOrder.verify(mockTwo,atLeastOnce()).simpleMethod(2);
  inOrder.verify(mockOne).simpleMethod(4);
}
