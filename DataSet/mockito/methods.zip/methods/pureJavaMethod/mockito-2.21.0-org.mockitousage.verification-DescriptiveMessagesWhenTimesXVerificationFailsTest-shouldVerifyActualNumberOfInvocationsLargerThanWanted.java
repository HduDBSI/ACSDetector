@Test public void shouldVerifyActualNumberOfInvocationsLargerThanWanted() throws Exception {
  mock.clear();
  mock.clear();
  mock.clear();
  mock.clear();
  Mockito.verify(mock,times(4)).clear();
  try {
    Mockito.verify(mock,times(1)).clear();
    fail();
  }
 catch (  TooManyActualInvocations e) {
    assertThat(e).hasMessageContaining("mock.clear();").hasMessageContaining("Wanted 1 time").hasMessageContaining("was 4");
  }
}
