@Test public void shouldStubbingWithThrowableBeVerifiable(){
  when(mock.size()).thenThrow(new RuntimeException());
  doThrow(new RuntimeException()).when(mock).clone();
  try {
    mock.size();
    fail();
  }
 catch (  RuntimeException e) {
  }
  try {
    mock.clone();
    fail();
  }
 catch (  RuntimeException e) {
  }
  verify(mock).size();
  verify(mock).clone();
  verifyNoMoreInteractions(mock);
}
