@Test public void shouldDetectWhenOverloadedMethodCalled() throws Exception {
  IMethods mockThree=mock(IMethods.class);
  mockThree.varargs((Object[])new Object[]{});
  try {
    verify(mockThree).varargs((String[])new String[]{});
    fail();
  }
 catch (  WantedButNotInvoked e) {
  }
}
