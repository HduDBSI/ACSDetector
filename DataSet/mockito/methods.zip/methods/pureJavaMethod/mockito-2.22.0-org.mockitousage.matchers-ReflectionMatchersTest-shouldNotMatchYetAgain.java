@Test(expected=ArgumentsAreDifferent.class) public void shouldNotMatchYetAgain() throws Exception {
  Child wanted=new Child(1,"XXXXX",2,"bar");
  verify(mock).run(refEq(wanted));
}
