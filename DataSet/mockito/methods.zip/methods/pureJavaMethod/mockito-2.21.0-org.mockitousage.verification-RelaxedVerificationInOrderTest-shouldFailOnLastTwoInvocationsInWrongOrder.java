@Test public void shouldFailOnLastTwoInvocationsInWrongOrder(){
  inOrder.verify(mockOne).simpleMethod(4);
  try {
    inOrder.verify(mockTwo,atLeastOnce()).simpleMethod(2);
    fail();
  }
 catch (  VerificationInOrderFailure e) {
  }
}
