@Test public void shouldNotAllowNegativeNumberOfMinimumInvocations() throws Exception {
  try {
    VerificationModeFactory.atLeast(-50);
    fail();
  }
 catch (  MockitoException e) {
    assertEquals("Negative value is not allowed here",e.getMessage());
  }
}
