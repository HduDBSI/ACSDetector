public HandyReturnValues reportOr(){
  assertStateFor("Or(?)",TWO_SUB_MATCHERS);
  Or or=new Or(popLastArgumentMatchers(TWO_SUB_MATCHERS));
  matcherStack.push(new LocalizedMatcher(or));
  return new HandyReturnValues();
}
