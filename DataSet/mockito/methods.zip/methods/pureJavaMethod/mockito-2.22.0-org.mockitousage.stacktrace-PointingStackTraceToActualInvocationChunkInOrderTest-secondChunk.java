private void secondChunk(){
  mockTwo.simpleMethod(2);
  mockTwo.simpleMethod(2);
}
