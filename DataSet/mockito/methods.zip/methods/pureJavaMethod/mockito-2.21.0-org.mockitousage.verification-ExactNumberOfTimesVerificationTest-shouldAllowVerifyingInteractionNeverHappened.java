@Test public void shouldAllowVerifyingInteractionNeverHappened() throws Exception {
  mock.add("one");
  verify(mock,never()).add("two");
  verify(mock,never()).clear();
  try {
    verify(mock,never()).add("one");
    fail();
  }
 catch (  NeverWantedButInvoked e) {
  }
}
