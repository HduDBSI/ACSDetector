/** 
 * Allows verifying exact number of invocations. E.g: <pre class="code"><code class="java"> verify(mock, times(2)).someMethod("some arg"); </code></pre> See examples in javadoc for  {@link Mockito} class
 * @param wantedNumberOfInvocations wanted number of invocations
 * @return verification mode
 */
@CheckReturnValue public static VerificationMode times(int wantedNumberOfInvocations){
  return VerificationModeFactory.times(wantedNumberOfInvocations);
}
