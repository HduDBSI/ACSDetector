@Test public void shouldBeEqual(){
  assertEquals(new Equals(null),new Equals(null));
  assertEquals(new Equals(new Integer(2)),new Equals(new Integer(2)));
  assertFalse(new Equals(null).equals(null));
  assertFalse(new Equals(null).equals("Test"));
  assertEquals(1,new Equals(null).hashCode());
}
