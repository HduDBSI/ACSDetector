int countArticles(String newspaper);
