private static boolean safelyMatches(ArgumentMatcher m,Object arg){
  try {
    return m.matches(arg);
  }
 catch (  Throwable t) {
    return false;
  }
}
