public void tooLittleActualInvocations(Discrepancy discrepancy,PrintableInvocation wanted,Location lastActualLocation){
  String message=createTooLittleInvocationsMessage(discrepancy,wanted,lastActualLocation);
  throw new TooLittleActualInvocations(message);
}
