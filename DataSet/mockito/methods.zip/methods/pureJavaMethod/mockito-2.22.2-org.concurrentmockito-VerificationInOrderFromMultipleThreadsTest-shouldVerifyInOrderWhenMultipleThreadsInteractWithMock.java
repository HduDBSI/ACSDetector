@Test public void shouldVerifyInOrderWhenMultipleThreadsInteractWithMock() throws Exception {
  final Foo testInf=mock(Foo.class);
  Thread threadOne=new Thread(new Runnable(){
    public void run(){
      testInf.methodOne();
    }
  }
);
  threadOne.start();
  threadOne.join();
  Thread threadTwo=new Thread(new Runnable(){
    public void run(){
      testInf.methodTwo();
    }
  }
);
  threadTwo.start();
  threadTwo.join();
  InOrder inOrder=inOrder(testInf);
  inOrder.verify(testInf).methodOne();
  inOrder.verify(testInf).methodTwo();
}
