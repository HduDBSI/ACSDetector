@Test public void shouldFailOnWrongMethod() throws Exception {
  mock.clear();
  mock.clear();
  mockTwo.add("add");
  verify(mock,atLeastOnce()).clear();
  verify(mockTwo,atLeastOnce()).add("add");
  try {
    verify(mockTwo,atLeastOnce()).add("foo");
    fail();
  }
 catch (  WantedButNotInvoked e) {
  }
}
