@Test public void should_discard_generics_metadata_when_serialized_then_disabling_deep_stubs_with_generics() throws Exception {
  ListContainer deep_stubbed=mock(ListContainer.class,withSettings().defaultAnswer(RETURNS_DEEP_STUBS).serializable());
  when(deep_stubbed.iterator().hasNext()).thenReturn(true);
  ListContainer deserialized_deep_stub=serializeAndBack(deep_stubbed);
  assertThat(deserialized_deep_stub.iterator().next()).isNull();
}
