@Test public void shouldFailInRuntimeWhenCallingRealMethodOnInterface() throws Exception {
  List<Object> list=mock(List.class);
  when(list.get(0)).thenAnswer(new Answer<Object>(){
    public Object answer(    InvocationOnMock invocation) throws Throwable {
      return invocation.callRealMethod();
    }
  }
);
  try {
    list.get(0);
    fail();
  }
 catch (  MockitoException e) {
  }
}
