public boolean matches(String actual){
  return actual != null && Pattern.compile(regex).matcher(actual).find();
}
