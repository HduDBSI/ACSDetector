public Person(String name){
  this.name=name;
}
