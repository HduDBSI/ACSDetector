@Test public void shouldDetectWhenInvokedMoreThanOnce() throws Exception {
  mock.add("foo");
  mock.clear();
  mock.clear();
  verify(mock).add("foo");
  try {
    verify(mock).clear();
    fail();
  }
 catch (  TooManyActualInvocations e) {
  }
}
