public void foundStubCalledWithDifferentArgs(Invocation unused,InvocationMatcher unstubbed){
  String index=Integer.toString(indexOfNextPair(argMismatchStubs.size()));
  String padding=index.replaceAll("\\d"," ");
  argMismatchStubs.add(index + ". Stubbed " + unused.getLocation());
  argMismatchStubs.add(padding + "  Invoked " + unstubbed.getInvocation().getLocation());
}
