@Test(expected=NotAMockException.class) public void shouldScreamWhenWholeMethodPassedToVerify(){
  verify(mock.booleanReturningMethod());
}
