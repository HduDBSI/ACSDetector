@Before public void createMethodToTestWith() throws SecurityException, NoSuchMethodException {
  args=new Class<?>[0];
  toStringMethod=this.getClass().getMethod("toString",args);
  method=new SerializableMethod(toStringMethod);
}
