@Test public void mockJustWorks(){
  articleManager.updateArticleCounters("new");
}
