/** 
 * Alias to <code>times(0)</code>, see  {@link Mockito#times(int)}<p> Verifies that interaction did not happen. E.g: <pre class="code"><code class="java"> verify(mock, never()).someMethod(); </code></pre> <p> If you want to verify there were NO interactions with the mock check out  {@link Mockito#verifyZeroInteractions(Object)}or  {@link Mockito#verifyNoMoreInteractions(Object)}<p> See examples in javadoc for  {@link Mockito} class
 * @return verification mode
 */
@CheckReturnValue public static VerificationMode never(){
  return times(0);
}
