@Test public void shouldAddVerboseLoggingListenerOnlyOnce(){
  assertFalse(mockSettingsImpl.hasInvocationListeners());
  mockSettingsImpl.verboseLogging().verboseLogging();
  Assertions.assertThat(mockSettingsImpl.getInvocationListeners()).hasSize(1);
}
