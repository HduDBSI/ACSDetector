String withStringVarargsReturningString(int value,String... s);
