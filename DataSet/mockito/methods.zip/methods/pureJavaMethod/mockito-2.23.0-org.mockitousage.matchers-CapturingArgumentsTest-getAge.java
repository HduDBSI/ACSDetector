public int getAge(){
  return age;
}
