HashSet<?> hashSet(){
  return null;
}
