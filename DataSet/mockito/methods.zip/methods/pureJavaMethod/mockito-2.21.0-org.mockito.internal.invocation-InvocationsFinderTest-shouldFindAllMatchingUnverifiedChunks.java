@Test public void shouldFindAllMatchingUnverifiedChunks() throws Exception {
  List<Invocation> allMatching=InvocationsFinder.findAllMatchingUnverifiedChunks(invocations,new InvocationMatcher(simpleMethodInvocation),context);
  Assertions.assertThat(allMatching).containsSequence(simpleMethodInvocation,simpleMethodInvocationTwo);
  context.markVerified(simpleMethodInvocation);
  allMatching=InvocationsFinder.findAllMatchingUnverifiedChunks(invocations,new InvocationMatcher(simpleMethodInvocation),context);
  Assertions.assertThat(allMatching).containsSequence(simpleMethodInvocationTwo);
  context.markVerified(simpleMethodInvocationTwo);
  allMatching=InvocationsFinder.findAllMatchingUnverifiedChunks(invocations,new InvocationMatcher(simpleMethodInvocation),context);
  assertTrue(allMatching.isEmpty());
}
