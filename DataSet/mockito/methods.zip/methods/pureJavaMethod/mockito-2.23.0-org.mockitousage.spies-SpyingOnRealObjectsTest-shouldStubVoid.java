@Test public void shouldStubVoid(){
  doNothing().doThrow(new RuntimeException()).when(spy).clear();
  spy.add("one");
  spy.clear();
  try {
    spy.clear();
    fail();
  }
 catch (  RuntimeException e) {
  }
  assertEquals(1,spy.size());
}
