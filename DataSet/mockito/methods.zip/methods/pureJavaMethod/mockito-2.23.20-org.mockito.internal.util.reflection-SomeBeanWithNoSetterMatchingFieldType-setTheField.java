public void setTheField(final FileOutputStream somethingElse){
  theFieldSetterWasUsed=true;
}
