@Test public void shouldPointOutUnfinishedStubbing(){
  unfinishedStubbingHere();
  try {
    verify(mock).simpleMethod();
    fail();
  }
 catch (  UnfinishedStubbingException e) {
    assertThat(e).hasMessageContaining("-> at ").hasMessageContaining("unfinishedStubbingHere(");
  }
}
