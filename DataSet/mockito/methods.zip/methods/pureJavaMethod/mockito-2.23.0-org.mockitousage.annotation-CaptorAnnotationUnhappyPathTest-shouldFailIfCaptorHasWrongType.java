@Test public void shouldFailIfCaptorHasWrongType() throws Exception {
  try {
    MockitoAnnotations.initMocks(this);
    fail();
  }
 catch (  MockitoException e) {
    assertThat(e).hasMessageContaining("notACaptorField").hasMessageContaining("wrong type");
  }
}
