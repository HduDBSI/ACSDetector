private void detectsAndCleansUp(DetectsInvalidState detector,Class<?> expected){
  try {
    detector.detect(mock);
    fail("Should throw an exception");
  }
 catch (  Exception e) {
    assertEquals(expected,e.getClass());
  }
  new StateMaster().validate();
}
