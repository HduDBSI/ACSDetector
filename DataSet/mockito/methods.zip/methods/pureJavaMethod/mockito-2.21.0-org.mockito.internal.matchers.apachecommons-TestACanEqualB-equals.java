public boolean equals(Object o){
  if (o == this) {
    return true;
  }
  if (o instanceof TestACanEqualB) {
    return this.a == ((TestACanEqualB)o).getA();
  }
  if (o instanceof TestBCanEqualA) {
    return this.a == ((TestBCanEqualA)o).getB();
  }
  return false;
}
