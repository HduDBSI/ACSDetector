@Test public void detects_invalid_mockito_usage_on_success() throws Throwable {
  rule.expectFailure(UnfinishedStubbingException.class);
  when(mock.simpleMethod());
}
