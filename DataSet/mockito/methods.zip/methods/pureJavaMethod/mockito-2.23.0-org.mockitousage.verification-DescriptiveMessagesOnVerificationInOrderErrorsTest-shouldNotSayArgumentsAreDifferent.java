@Test public void shouldNotSayArgumentsAreDifferent(){
  inOrder.verify(three).simpleMethod(3);
  try {
    inOrder.verify(one).simpleMethod(999);
    fail();
  }
 catch (  VerificationInOrderFailure e) {
    assertThat(e).hasMessageContaining("Wanted but not invoked");
  }
}
