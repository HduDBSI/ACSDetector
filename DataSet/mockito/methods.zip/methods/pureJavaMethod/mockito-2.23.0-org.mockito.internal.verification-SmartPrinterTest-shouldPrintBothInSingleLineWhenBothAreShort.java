@Test public void shouldPrintBothInSingleLineWhenBothAreShort(){
  SmartPrinter printer=new SmartPrinter(shortie,shortie.getInvocation());
  assertThat(printer.getWanted()).doesNotContain("\n");
  assertThat(printer.getActual()).doesNotContain("\n");
}
