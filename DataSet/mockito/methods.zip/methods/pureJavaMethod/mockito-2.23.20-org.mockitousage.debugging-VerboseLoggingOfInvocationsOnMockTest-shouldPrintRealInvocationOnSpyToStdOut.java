@Test public void shouldPrintRealInvocationOnSpyToStdOut(){
  FooImpl fooSpy=mock(FooImpl.class,withSettings().spiedInstance(new FooImpl()).verboseLogging());
  doCallRealMethod().when(fooSpy).doSomething("Klipsch");
  fooSpy.doSomething("Klipsch");
  Assertions.assertThat(printed()).contains(getClass().getName()).contains(mockName(fooSpy)).contains("doSomething").contains("Klipsch");
}
