@Test public void startsWithToString(){
  assertEquals("startsWith(\"AB\")",new StartsWith("AB").toString());
}
