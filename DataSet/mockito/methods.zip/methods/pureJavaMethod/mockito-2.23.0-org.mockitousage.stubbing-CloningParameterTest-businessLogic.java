private void businessLogic(EmailSender emailSender){
  Person person=new Person("Wes");
  emailSender.sendEmail(1,person);
  person.emailSent();
}
