@Test public void shouldVerifyDetectFirstChunkOfInvocationThatExistInManyChunks(){
  inOrder.verify(mockTwo,times(2)).simpleMethod(2);
  inOrder.verify(mockThree).simpleMethod(3);
  try {
    verifyNoMoreInteractions(mockTwo);
    fail();
  }
 catch (  NoInteractionsWanted e) {
  }
}
