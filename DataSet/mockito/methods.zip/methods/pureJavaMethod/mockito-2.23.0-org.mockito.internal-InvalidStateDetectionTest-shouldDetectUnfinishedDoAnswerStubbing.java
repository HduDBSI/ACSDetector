@SuppressWarnings({"CheckReturnValue","MockitoUsage"}) @Test public void shouldDetectUnfinishedDoAnswerStubbing(){
  doAnswer(null);
  detectsAndCleansUp(new OnMethodCallOnMock(),UnfinishedStubbingException.class);
  doAnswer(null);
  detectsAndCleansUp(new OnStub(),UnfinishedStubbingException.class);
  doAnswer(null);
  detectsAndCleansUp(new OnVerify(),UnfinishedStubbingException.class);
  doAnswer(null);
  detectsAndCleansUp(new OnVerifyInOrder(),UnfinishedStubbingException.class);
  doAnswer(null);
  detectsAndCleansUp(new OnVerifyZeroInteractions(),UnfinishedStubbingException.class);
  doAnswer(null);
  detectsAndCleansUp(new OnVerifyNoMoreInteractions(),UnfinishedStubbingException.class);
  doAnswer(null);
  detectsAndCleansUp(new OnDoAnswer(),UnfinishedStubbingException.class);
}
