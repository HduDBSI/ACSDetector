@Test public void shouldPrintStubbedInvocationOnMockToStdOut(){
  Foo foo=mock(Foo.class,withSettings().verboseLogging());
  given(foo.giveMeSomeString("Klipsch")).willReturn("earbuds");
  foo.giveMeSomeString("Klipsch");
  Assertions.assertThat(printed()).contains(getClass().getName()).contains(mockName(foo)).contains("giveMeSomeString").contains("Klipsch").contains("earbuds");
}
