@Test public void shouldKnowCompareToMethod() throws Exception {
  assertFalse(ObjectMethodsGuru.isCompareToMethod(Date.class.getMethod("toString")));
  assertFalse(ObjectMethodsGuru.isCompareToMethod(HasCompare.class.getMethod("foo",HasCompare.class)));
  assertFalse(ObjectMethodsGuru.isCompareToMethod(HasCompare.class.getMethod("compareTo",HasCompare.class,String.class)));
  assertFalse(ObjectMethodsGuru.isCompareToMethod(HasCompare.class.getMethod("compareTo",String.class)));
  assertFalse(ObjectMethodsGuru.isCompareToMethod(HasCompareToButDoesNotImplementComparable.class.getDeclaredMethod("compareTo",HasCompareToButDoesNotImplementComparable.class)));
  assertTrue(ObjectMethodsGuru.isCompareToMethod(HasCompare.class.getMethod("compareTo",HasCompare.class)));
}
