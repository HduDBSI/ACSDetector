/** 
 * Test that deep stubbing work with argument patterns
 */
@Test public void withAnyPatternArguments() throws Exception {
  OutputStream out=new ByteArrayOutputStream();
  SocketFactory sf=mock(SocketFactory.class,RETURNS_DEEP_STUBS);
  when(sf.createSocket(anyString(),anyInt()).getOutputStream()).thenReturn(out);
  assertSame(out,sf.createSocket("google.com",80).getOutputStream());
  assertSame(out,sf.createSocket("stackoverflow.com",8080).getOutputStream());
}
