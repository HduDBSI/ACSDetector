boolean equals(Object o);
