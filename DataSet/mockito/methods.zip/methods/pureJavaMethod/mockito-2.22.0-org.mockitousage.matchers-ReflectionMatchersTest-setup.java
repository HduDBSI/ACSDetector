@Before public void setup(){
  mock=mock(MockMe.class);
  Child actual=new Child(1,"foo",2,"bar");
  mock.run(actual);
}
