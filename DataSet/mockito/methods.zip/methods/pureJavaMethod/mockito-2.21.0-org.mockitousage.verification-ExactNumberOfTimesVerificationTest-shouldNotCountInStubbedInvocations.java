@Test public void shouldNotCountInStubbedInvocations() throws Exception {
  when(mock.add("test")).thenReturn(false);
  when(mock.add("test")).thenReturn(true);
  mock.add("test");
  mock.add("test");
  verify(mock,times(2)).add("test");
}
