public void verifyTheStackTrace(){
  spy.getNameButDelegateToMethodThatThrows();
}
