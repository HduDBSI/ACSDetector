/** 
 * Suspiciously not matching arguments are those that don't match, the toString() representation is the same but types are different.
 */
public static Integer[] getSuspiciouslyNotMatchingArgsIndexes(List<ArgumentMatcher> matchers,Object[] arguments){
  if (matchers.size() != arguments.length) {
    return new Integer[0];
  }
  List<Integer> suspicious=new LinkedList<Integer>();
  int i=0;
  for (  ArgumentMatcher m : matchers) {
    if (m instanceof ContainsExtraTypeInfo && !safelyMatches(m,arguments[i]) && toStringEquals(m,arguments[i])&& !((ContainsExtraTypeInfo)m).typeMatches(arguments[i])) {
      suspicious.add(i);
    }
    i++;
  }
  return suspicious.toArray(new Integer[0]);
}
