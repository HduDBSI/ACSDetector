@SuppressWarnings({"MockitoUsage","CheckReturnValue"}) @Test public void shouldValidateState() throws Exception {
  InOrder inOrder=inOrder(mock);
  verify(mock);
  try {
    inOrder.verifyNoMoreInteractions();
    fail();
  }
 catch (  UnfinishedVerificationException e) {
  }
}
