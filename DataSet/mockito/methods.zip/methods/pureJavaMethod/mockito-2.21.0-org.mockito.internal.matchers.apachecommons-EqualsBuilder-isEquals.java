/** 
 * <p>Returns <code>true</code> if the fields that have been checked are all equal.</p>
 * @return boolean
 */
public boolean isEquals(){
  return this.isEquals;
}
