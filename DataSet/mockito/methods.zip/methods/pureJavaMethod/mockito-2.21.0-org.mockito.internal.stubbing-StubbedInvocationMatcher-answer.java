public Object answer(InvocationOnMock invocation) throws Throwable {
  Answer a;
synchronized (answers) {
    a=answers.size() == 1 ? answers.peek() : answers.poll();
  }
  return a.answer(invocation);
}
