char charMethod();
