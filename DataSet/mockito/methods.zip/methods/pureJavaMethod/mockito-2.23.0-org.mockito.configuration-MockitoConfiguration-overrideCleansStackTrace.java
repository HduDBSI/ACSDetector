public void overrideCleansStackTrace(boolean cleansStackTrace){
  this.cleansStackTrace=cleansStackTrace;
}
