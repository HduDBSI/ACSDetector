@Test public void shouldVerifyStringVarargs(){
  mock.withStringVarargs(1);
  mock.withStringVarargs(2,"1","2","3");
  mock.withStringVarargs(3,"1","2","3","4");
  verify(mock).withStringVarargs(1);
  verify(mock).withStringVarargs(2,"1","2","3");
  try {
    verify(mock).withStringVarargs(2,"1","2","79","4");
    fail();
  }
 catch (  ArgumentsAreDifferent e) {
  }
}
