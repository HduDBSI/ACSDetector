@Test public void shouldPassBecauseActualInvocationFound(){
  wanted=buildSimpleMethod().toInvocationMatcher();
  invocations=asList(buildSimpleMethod().toInvocation());
  MissingInvocationChecker.checkMissingInvocation(invocations,wanted);
}
