public ArrayEquals(Object wanted){
  super(wanted);
}
