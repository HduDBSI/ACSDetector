/** 
 * The returned runnable simply calls ToMock.getValues(int).
 * @param toMock The mocked object
 * @return The runnable.
 */
private Runnable getConflictingRunnable(final ToMock toMock){
  return new Runnable(){
    public void run(){
      while (true) {
        try {
          Thread.sleep((long)(Math.random() * 10));
        }
 catch (        InterruptedException e) {
        }
        if (!toMock.getValues(0).isEmpty()) {
          fail("Shouldn't happen, were just making sure it wasn't optimized away...");
        }
      }
    }
  }
;
}
