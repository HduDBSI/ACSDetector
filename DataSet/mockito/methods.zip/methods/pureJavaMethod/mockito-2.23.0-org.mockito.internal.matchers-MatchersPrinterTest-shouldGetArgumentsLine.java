@Test public void shouldGetArgumentsLine(){
  String line=printer.getArgumentsLine((List)Arrays.asList(new Equals(1),new Equals(2)),new PrintSettings());
  assertEquals("(1, 2);",line);
}
