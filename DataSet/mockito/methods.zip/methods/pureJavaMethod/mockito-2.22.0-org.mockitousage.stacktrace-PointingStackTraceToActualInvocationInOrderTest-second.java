private void second(){
  mockTwo.simpleMethod(2);
}
