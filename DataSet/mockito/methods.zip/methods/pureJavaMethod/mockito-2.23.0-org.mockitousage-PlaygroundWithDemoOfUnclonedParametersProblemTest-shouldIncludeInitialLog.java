@Test public void shouldIncludeInitialLog(){
  int importType=0;
  Date currentDate=new GregorianCalendar(2009,10,12).getTime();
  ImportLogBean initialLog=new ImportLogBean(currentDate,importType);
  initialLog.setStatus(1);
  given(importLogDao.anyImportRunningOrRunnedToday(importType,currentDate)).willReturn(false);
  willAnswer(byCheckingLogEquals(initialLog)).given(importLogDao).include(any(ImportLogBean.class));
  importManager.startImportProcess(importType,currentDate);
  verify(importLogDao).include(any(ImportLogBean.class));
}
