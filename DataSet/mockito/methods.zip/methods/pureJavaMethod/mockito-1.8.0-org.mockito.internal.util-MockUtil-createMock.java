public <T>T createMock(Class<T> classToMock,MockingProgress progress,MockSettingsImpl settings){
  creationValidator.validateType(classToMock);
  creationValidator.validateExtraInterfaces(classToMock,settings.getExtraInterfaces());
  MockName mockName=new MockName(settings.getMockName(),classToMock);
  MockHandler<T> mockHandler=new MockHandler<T>(mockName,progress,new MatchersBinder(),settings);
  MethodInterceptorFilter filter=new MethodInterceptorFilter(classToMock,mockHandler);
  Class<?>[] interfaces=settings.getExtraInterfaces();
  Class<?>[] ancillaryTypes=interfaces == null ? new Class<?>[0] : interfaces;
  Object spiedInstance=settings.getSpiedInstance();
  T mock=ClassImposterizer.INSTANCE.imposterise(filter,classToMock,ancillaryTypes);
  if (spiedInstance != null) {
    new LenientCopyTool().copyToMock(spiedInstance,mock);
  }
  return mock;
}
