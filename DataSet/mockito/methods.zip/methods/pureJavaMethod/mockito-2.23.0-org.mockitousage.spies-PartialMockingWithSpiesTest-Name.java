public Name(String name){
  this.name=name;
}
