@Test public void testChar(){
  char o1=1;
  char o2=2;
  assertTrue(new EqualsBuilder().append(o1,o1).isEquals());
  assertTrue(!new EqualsBuilder().append(o1,o2).isEquals());
}
