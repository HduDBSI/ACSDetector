@SuppressWarnings({"CheckReturnValue","MockitoUsage"}) @Test(expected=NotAMockException.class) public void shouldValidateMockWhenVerifyingWithExpectedNumberOfInvocations(){
  Mockito.verify("notMock",times(19));
}
