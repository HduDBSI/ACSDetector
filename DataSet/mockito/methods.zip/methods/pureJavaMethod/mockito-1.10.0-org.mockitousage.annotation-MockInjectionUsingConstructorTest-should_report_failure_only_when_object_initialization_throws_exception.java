@Test public void should_report_failure_only_when_object_initialization_throws_exception() throws Exception {
  try {
    MockitoAnnotations.initMocks(new ATest());
    fail();
  }
 catch (  MockitoException e) {
    assertThat(e.getMessage()).contains("failingConstructor").contains("constructor").contains("threw an exception");
    assertThat(e.getCause()).isInstanceOf(IllegalStateException.class);
  }
}
