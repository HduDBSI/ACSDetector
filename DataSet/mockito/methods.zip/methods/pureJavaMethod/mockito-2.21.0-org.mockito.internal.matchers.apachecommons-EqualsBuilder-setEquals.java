/** 
 * Sets the <code>isEquals</code> value.
 * @param isEquals The value to set.
 * @since 2.1
 */
protected void setEquals(boolean isEquals){
  this.isEquals=isEquals;
}
