private void fourth(){
  mockTwo.simpleMethod(4);
}
