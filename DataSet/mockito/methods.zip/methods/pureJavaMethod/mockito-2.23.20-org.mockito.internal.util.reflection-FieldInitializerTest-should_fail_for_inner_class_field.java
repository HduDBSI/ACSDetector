@Test(expected=MockitoException.class) public void should_fail_for_inner_class_field() throws Exception {
  new FieldInitializer(this,field("innerClassType"));
}
