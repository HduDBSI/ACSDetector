public LessThan(T value){
  super(value);
}
