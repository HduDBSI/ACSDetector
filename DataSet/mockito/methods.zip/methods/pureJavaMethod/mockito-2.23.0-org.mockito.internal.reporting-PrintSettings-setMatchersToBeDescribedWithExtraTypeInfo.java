public void setMatchersToBeDescribedWithExtraTypeInfo(Integer[] indexesOfMatchers){
  this.withTypeInfo=Arrays.asList(indexesOfMatchers);
}
