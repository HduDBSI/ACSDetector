public MockHandler(MockHandlerInterface<T> oldMockHandler){
  this(oldMockHandler.getMockSettings());
}
