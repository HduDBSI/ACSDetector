public String differentMethod(String argument){
  return null;
}
