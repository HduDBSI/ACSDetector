private void printInvocation(DescribedInvocation invocation){
  printStream.println(invocation.toString());
  printlnIndented("invoked: " + invocation.getLocation().toString());
}
