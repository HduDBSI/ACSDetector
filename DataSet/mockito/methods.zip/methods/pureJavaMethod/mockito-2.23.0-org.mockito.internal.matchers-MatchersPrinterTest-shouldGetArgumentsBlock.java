@Test public void shouldGetArgumentsBlock(){
  String line=printer.getArgumentsBlock((List)Arrays.asList(new Equals(1),new Equals(2)),new PrintSettings());
  assertEquals("(\n    1,\n    2\n);",line);
}
