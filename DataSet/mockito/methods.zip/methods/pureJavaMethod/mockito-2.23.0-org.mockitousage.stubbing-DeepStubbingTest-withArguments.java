/** 
 * Test that stubbing of methods of different arguments don't interfere
 */
@Test public void withArguments() throws Exception {
  OutputStream out1=new ByteArrayOutputStream();
  OutputStream out2=new ByteArrayOutputStream();
  OutputStream out3=new ByteArrayOutputStream();
  SocketFactory sf=mock(SocketFactory.class,RETURNS_DEEP_STUBS);
  when(sf.createSocket().getOutputStream()).thenReturn(out1);
  when(sf.createSocket("google.com",80).getOutputStream()).thenReturn(out2);
  when(sf.createSocket("stackoverflow.com",80).getOutputStream()).thenReturn(out3);
  assertSame(out1,sf.createSocket().getOutputStream());
  assertSame(out2,sf.createSocket("google.com",80).getOutputStream());
  assertSame(out3,sf.createSocket("stackoverflow.com",80).getOutputStream());
}
