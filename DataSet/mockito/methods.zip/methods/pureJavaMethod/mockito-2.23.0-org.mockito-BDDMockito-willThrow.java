/** 
 * see original  {@link Mockito#doThrow(Class)}
 * @since 1.9.0
 */
public static BDDStubber willThrow(Class<? extends Throwable> toBeThrown,Class<? extends Throwable>... throwableTypes){
  return new BDDStubberImpl(Mockito.doThrow(toBeThrown,throwableTypes));
}
