int foo(HasCompare other);
