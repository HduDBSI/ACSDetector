boolean withBooleanVarargs(int value,boolean... b);
