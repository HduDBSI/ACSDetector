private boolean isAnnotatedByMockOrSpy(Field field){
  return field.isAnnotationPresent(Spy.class) || field.isAnnotationPresent(Mock.class);
}
