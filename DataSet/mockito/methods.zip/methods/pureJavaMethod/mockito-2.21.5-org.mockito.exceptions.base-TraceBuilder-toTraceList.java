private List<StackTraceElement> toTraceList(){
  assert methods.length == 0 || classes.length == 0;
  List<StackTraceElement> trace=new LinkedList<StackTraceElement>();
  for (  String method : methods) {
    trace.add(new StackTraceElement("SomeClass",method,"SomeClass.java",50));
  }
  for (  String clazz : classes) {
    trace.add(new StackTraceElement(clazz,"someMethod",clazz + ".java",50));
  }
  Collections.reverse(trace);
  return trace;
}
