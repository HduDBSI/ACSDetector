public void updateNumberOfArticles(String newspaper,int articles){
}
