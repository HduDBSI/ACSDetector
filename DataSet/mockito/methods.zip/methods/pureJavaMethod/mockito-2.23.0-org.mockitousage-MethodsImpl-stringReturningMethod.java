public String stringReturningMethod(){
  return null;
}
