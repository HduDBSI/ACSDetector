@Test public void shouldCorrectStateAfterDetectingUnfinishedStubbing(){
  doThrow(new RuntimeException()).when(mock);
  try {
    doThrow(new RuntimeException()).when(mock).oneArg(true);
    fail();
  }
 catch (  UnfinishedStubbingException e) {
  }
  doThrow(new RuntimeException()).when(mock).oneArg(true);
  try {
    mock.oneArg(true);
    fail();
  }
 catch (  RuntimeException e) {
  }
}
