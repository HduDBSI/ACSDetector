public static MockName getMockName(Object mock){
  return getMockHandler(mock).getMockSettings().getMockName();
}
