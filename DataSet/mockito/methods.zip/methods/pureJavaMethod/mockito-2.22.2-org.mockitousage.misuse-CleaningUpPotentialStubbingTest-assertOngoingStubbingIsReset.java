private void assertOngoingStubbingIsReset(){
  try {
    when(null).thenReturn("anything");
    fail();
  }
 catch (  MissingMethodInvocationException e) {
  }
}
