@Override public boolean hasSameMethod(Invocation candidate){
  Method m1=invocation.getMethod();
  Method m2=candidate.getMethod();
  if (m1.getName() != null && m1.getName().equals(m2.getName())) {
    Class<?>[] params1=m1.getParameterTypes();
    Class<?>[] params2=m2.getParameterTypes();
    return Arrays.equals(params1,params2);
  }
  return false;
}
