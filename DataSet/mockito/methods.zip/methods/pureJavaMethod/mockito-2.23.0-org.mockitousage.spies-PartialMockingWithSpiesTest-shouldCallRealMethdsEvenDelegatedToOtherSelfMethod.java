@Test public void shouldCallRealMethdsEvenDelegatedToOtherSelfMethod(){
  String name=spy.getName();
  assertEquals("Default name",name);
}
