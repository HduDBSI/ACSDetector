@Test public void shouldReturnRealValue(){
  when(mock.getValue()).thenCallRealMethod();
  assertEquals("HARD_CODED_RETURN_VALUE",mock.getValue());
}
