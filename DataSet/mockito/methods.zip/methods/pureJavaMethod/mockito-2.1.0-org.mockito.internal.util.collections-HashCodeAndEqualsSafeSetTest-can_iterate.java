@Test public void can_iterate() throws Exception {
  HashCodeAndEqualsSafeSet mocks=HashCodeAndEqualsSafeSet.of(mock1,mock(Observer.class));
  LinkedList<Object> accumulator=new LinkedList<Object>();
  for (  Object mock : mocks) {
    accumulator.add(mock);
  }
  assertThat(accumulator).isNotEmpty();
}
