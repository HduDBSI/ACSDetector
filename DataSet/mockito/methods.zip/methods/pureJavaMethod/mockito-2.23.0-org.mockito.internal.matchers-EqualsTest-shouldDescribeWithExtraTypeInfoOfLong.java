@Test public void shouldDescribeWithExtraTypeInfoOfLong() throws Exception {
  String descStr=new Equals(100L).toStringWithType();
  assertEquals("(Long) 100L",descStr);
}
