public ArgumentCaptor<IMethods> getSuperBaseCaptor(){
  return mock;
}
