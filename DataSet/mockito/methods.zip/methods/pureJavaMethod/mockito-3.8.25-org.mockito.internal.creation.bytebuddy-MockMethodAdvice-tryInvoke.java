private static Object tryInvoke(Method origin,Object instance,Object[] arguments) throws Throwable {
  MemberAccessor accessor=Plugins.getMemberAccessor();
  try {
    return accessor.invoke(origin,instance,arguments);
  }
 catch (  InvocationTargetException exception) {
    Throwable cause=exception.getCause();
    StackTraceElement[] tmpStack=new Throwable().getStackTrace();
    int skip=tmpStack.length;
    if (instance != null) {
      skip=0;
      String causingClassName=instance.getClass().getName();
      StackTraceElement stackFrame;
      do {
        stackFrame=tmpStack[skip++];
      }
 while (stackFrame.getClassName().startsWith(causingClassName));
    }
    new ConditionalStackTraceFilter().filter(hideRecursiveCall(cause,skip,origin.getDeclaringClass()));
    throw cause;
  }
}
