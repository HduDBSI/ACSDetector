@Test public void shouldVerifyInOrderOnlyMockTwo(){
  inOrder.verify(mockTwo,times(2)).simpleMethod(2);
  inOrder.verify(mockTwo).simpleMethod(2);
  verifyNoMoreInteractions(mockTwo);
}
