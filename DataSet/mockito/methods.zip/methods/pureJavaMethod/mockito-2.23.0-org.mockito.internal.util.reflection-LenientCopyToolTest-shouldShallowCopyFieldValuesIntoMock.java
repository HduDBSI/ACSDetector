@Test public void shouldShallowCopyFieldValuesIntoMock() throws Exception {
  from.defaultField="foo";
  from.instancePublicField=new SomeOtherObject();
  from.privateField=1;
  from.privateTransientField=2;
  from.protectedField=3;
  assertThat(to.defaultField).isNotEqualTo(from.defaultField);
  assertThat(to.instancePublicField).isNotEqualTo(from.instancePublicField);
  assertThat(to.privateField).isNotEqualTo(from.privateField);
  assertThat(to.privateTransientField).isNotEqualTo(from.privateTransientField);
  assertThat(to.protectedField).isNotEqualTo(from.protectedField);
  tool.copyToMock(from,to);
  assertEquals(from.defaultField,to.defaultField);
  assertEquals(from.instancePublicField,to.instancePublicField);
  assertEquals(from.privateField,to.privateField);
  assertEquals(from.privateTransientField,to.privateTransientField);
  assertEquals(from.protectedField,to.protectedField);
}
