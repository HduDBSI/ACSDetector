@Test public void shouldFailOnSecondMethodBecauseDifferentMethodWanted(){
  inOrder.verify(mockOne,times(1)).simpleMethod(1);
  try {
    inOrder.verify(mockTwo,times(2)).oneArg(true);
    fail();
  }
 catch (  VerificationInOrderFailure e) {
  }
}
