public Set<?> getHistogram1(){
  return histogram1;
}
