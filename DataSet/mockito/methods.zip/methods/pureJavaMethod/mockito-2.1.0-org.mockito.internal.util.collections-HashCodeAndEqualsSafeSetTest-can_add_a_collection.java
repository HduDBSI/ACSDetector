@Test public void can_add_a_collection() throws Exception {
  HashCodeAndEqualsSafeSet mocks=HashCodeAndEqualsSafeSet.of(mock1,mock(Observer.class));
  HashCodeAndEqualsSafeSet workingSet=new HashCodeAndEqualsSafeSet();
  workingSet.addAll(mocks);
  assertThat(workingSet.containsAll(mocks)).isTrue();
}
