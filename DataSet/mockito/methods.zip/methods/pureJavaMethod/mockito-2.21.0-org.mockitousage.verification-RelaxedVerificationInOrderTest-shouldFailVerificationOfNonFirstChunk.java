@Test(expected=VerificationInOrderFailure.class) public void shouldFailVerificationOfNonFirstChunk(){
  inOrder.verify(mockTwo,times(1)).simpleMethod(2);
}
