public InvocationBuilder args(Object... args){
  this.args=args;
  return this;
}
