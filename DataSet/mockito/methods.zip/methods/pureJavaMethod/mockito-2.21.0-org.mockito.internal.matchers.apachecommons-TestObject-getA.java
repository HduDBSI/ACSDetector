public int getA(){
  return a;
}
