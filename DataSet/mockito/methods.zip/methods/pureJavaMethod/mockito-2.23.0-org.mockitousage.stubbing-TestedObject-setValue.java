void setValue(String value){
  this.value=value;
}
