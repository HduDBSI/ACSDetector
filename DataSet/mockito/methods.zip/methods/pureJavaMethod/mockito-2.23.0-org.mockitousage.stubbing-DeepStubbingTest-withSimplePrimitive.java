/** 
 * Test that deep stubbing work with primitive expected values
 */
@Test public void withSimplePrimitive() throws Exception {
  int a=32;
  SocketFactory sf=mock(SocketFactory.class,RETURNS_DEEP_STUBS);
  when(sf.createSocket().getPort()).thenReturn(a);
  assertEquals(a,sf.createSocket().getPort());
}
