Float floatObjectReturningMethod();
