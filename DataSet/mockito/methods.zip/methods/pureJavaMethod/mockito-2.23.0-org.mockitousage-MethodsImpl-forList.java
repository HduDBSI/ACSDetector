public String forList(List<String> list){
  return null;
}
