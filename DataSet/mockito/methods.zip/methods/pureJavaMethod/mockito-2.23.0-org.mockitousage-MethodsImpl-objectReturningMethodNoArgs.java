public Object objectReturningMethodNoArgs(){
  return null;
}
