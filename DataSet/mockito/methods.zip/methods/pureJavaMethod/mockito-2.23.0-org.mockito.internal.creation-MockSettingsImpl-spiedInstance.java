@Override public MockSettings spiedInstance(Object spiedInstance){
  this.spiedInstance=spiedInstance;
  return this;
}
