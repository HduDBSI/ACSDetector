@Test public void shouldVerifyInOrderWhenExpectingSomeInvocationsToBeCalledZeroTimes(){
  inOrder.verify(mockOne,times(0)).oneArg(false);
  inOrder.verify(mockOne).simpleMethod(1);
  inOrder.verify(mockTwo,times(2)).simpleMethod(2);
  inOrder.verify(mockTwo,times(0)).simpleMethod(22);
  inOrder.verify(mockThree).simpleMethod(3);
  inOrder.verify(mockTwo).simpleMethod(2);
  inOrder.verify(mockOne).simpleMethod(4);
  inOrder.verify(mockThree,times(0)).oneArg(false);
  verifyNoMoreInteractions(mockOne,mockTwo,mockThree);
}
