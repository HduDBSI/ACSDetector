@Test public void shouldMatchTypesSafelyWhenActualIsNull() throws Exception {
  ContainsExtraTypeInfo equals=new Equals(null);
  assertFalse(equals.typeMatches(10));
}
