private void test(CompareTo<String> compareTo,boolean lower,boolean higher,boolean equals,String name){
  assertEquals(lower,compareTo.matches("a"));
  assertEquals(equals,compareTo.matches("b"));
  assertEquals(higher,compareTo.matches("c"));
  assertEquals(name + "(b)",compareTo.toString());
}
