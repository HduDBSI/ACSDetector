@Test public void shouldFailIfMethodWasNotInvoked(){
  mock.clear();
  try {
    verify(mock,only()).get(0);
    fail();
  }
 catch (  WantedButNotInvoked e) {
  }
}
