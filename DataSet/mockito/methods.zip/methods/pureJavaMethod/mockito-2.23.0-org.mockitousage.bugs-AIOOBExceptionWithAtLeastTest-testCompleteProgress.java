@Test public void testCompleteProgress() throws Exception {
  IProgressMonitor progressMonitor=mock(IProgressMonitor.class);
  progressMonitor.beginTask("foo",12);
  progressMonitor.worked(10);
  progressMonitor.done();
  verify(progressMonitor).beginTask(anyString(),anyInt());
  verify(progressMonitor,atLeastOnce()).worked(anyInt());
}
