/** 
 * Allows configuring the default answers of unstubbed invocations <p> See javadoc for  {@link IMockitoConfiguration}
 */
Answer<Object> getDefaultAnswer();
