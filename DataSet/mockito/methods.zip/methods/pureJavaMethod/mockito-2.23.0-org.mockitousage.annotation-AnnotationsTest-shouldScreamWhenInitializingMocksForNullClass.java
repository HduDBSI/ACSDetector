@Test public void shouldScreamWhenInitializingMocksForNullClass() throws Exception {
  try {
    MockitoAnnotations.initMocks(null);
    fail();
  }
 catch (  MockitoException e) {
    assertEquals("testClass cannot be null. For info how to use @Mock annotations see examples in javadoc for MockitoAnnotations class",e.getMessage());
  }
}
