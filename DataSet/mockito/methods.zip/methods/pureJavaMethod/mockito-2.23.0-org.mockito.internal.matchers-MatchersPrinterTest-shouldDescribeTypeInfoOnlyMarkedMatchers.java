@Test public void shouldDescribeTypeInfoOnlyMarkedMatchers(){
  String line=printer.getArgumentsLine((List)Arrays.asList(new Equals(1L),new Equals(2)),PrintSettings.verboseMatchers(1));
  assertEquals("(1L, (Integer) 2);",line);
}
