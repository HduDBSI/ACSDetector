@Test public void shouldMatchWhenFieldValuesEqual() throws Exception {
  Child wanted=new Child(1,"foo",2,"bar");
  verify(mock).run(refEq(wanted));
}
