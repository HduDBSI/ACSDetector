private IMockitoConfiguration createConfig(){
  IMockitoConfiguration defaultConfiguration=new DefaultMockitoConfiguration();
  IMockitoConfiguration config=new ClassPathLoader().loadConfiguration();
  if (config != null) {
    return config;
  }
 else {
    return defaultConfiguration;
  }
}
