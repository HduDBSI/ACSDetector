@Test public void should_raise_wanted_throwable() throws Throwable {
  try {
    new ThrowsException(new IllegalStateException("my dear throwable")).answer(createMethodInvocation());
    Assertions.fail("should have raised wanted exception");
  }
 catch (  Throwable throwable) {
    assertThat(throwable).isInstanceOf(IllegalStateException.class).hasMessage("my dear throwable");
  }
}
