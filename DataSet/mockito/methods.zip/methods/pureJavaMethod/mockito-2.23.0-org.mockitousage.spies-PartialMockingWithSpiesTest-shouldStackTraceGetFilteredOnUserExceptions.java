@Test public void shouldStackTraceGetFilteredOnUserExceptions(){
  try {
    spy.getNameButDelegateToMethodThatThrows();
    fail();
  }
 catch (  Throwable t) {
    Assertions.assertThat(t).has(methodsInStackTrace("throwSomeException","getNameButDelegateToMethodThatThrows","shouldStackTraceGetFilteredOnUserExceptions"));
  }
}
