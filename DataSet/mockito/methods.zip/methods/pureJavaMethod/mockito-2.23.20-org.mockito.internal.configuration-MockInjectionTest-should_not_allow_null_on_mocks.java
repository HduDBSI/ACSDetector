@Test(expected=IllegalArgumentException.class) public void should_not_allow_null_on_mocks() throws Exception {
  MockInjection.onField(field("withConstructor"),this).withMocks(null);
}
