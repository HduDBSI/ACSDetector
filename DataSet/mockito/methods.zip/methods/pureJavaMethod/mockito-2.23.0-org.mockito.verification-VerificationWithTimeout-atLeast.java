/** 
 * Allows at-least-x verification within given timeout. E.g: <pre class="code"><code class="java"> verify(mock, timeout(100).atLeast(3)).someMethod("some arg"); </code></pre> See examples in javadoc for  {@link Mockito} class
 * @param minNumberOfInvocations minimum number of invocations
 * @return verification mode
 */
VerificationMode atLeast(int minNumberOfInvocations);
