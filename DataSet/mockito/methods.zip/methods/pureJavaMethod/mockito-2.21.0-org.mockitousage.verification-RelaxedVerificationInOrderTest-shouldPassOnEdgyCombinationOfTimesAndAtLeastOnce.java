@Test public void shouldPassOnEdgyCombinationOfTimesAndAtLeastOnce(){
  mockTwo.simpleMethod(2);
  mockThree.simpleMethod(3);
  inOrder.verify(mockThree).simpleMethod(3);
  inOrder.verify(mockTwo,atLeastOnce()).simpleMethod(2);
  inOrder.verify(mockThree).simpleMethod(3);
  verifyNoMoreInteractions(mockThree);
}
