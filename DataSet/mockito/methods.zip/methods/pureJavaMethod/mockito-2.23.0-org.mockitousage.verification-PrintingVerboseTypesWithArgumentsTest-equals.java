public boolean equals(Object obj){
  return x == ((Foo)obj).x;
}
