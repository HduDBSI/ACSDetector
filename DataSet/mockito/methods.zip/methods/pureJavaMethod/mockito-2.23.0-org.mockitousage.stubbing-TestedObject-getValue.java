String getValue(){
  return "HARD_CODED_RETURN_VALUE";
}
