public OneConstructor(Observer observer){
}
