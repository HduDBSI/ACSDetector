@Test public void shouldNotFindSuspiciousMatchersWhenTypesAreTheSame(){
  Equals matcherWithBadDescription=new Equals(20){
    public String toString(){
      return "10";
    }
  }
;
  Integer argument=10;
  Integer[] suspicious=ArgumentMatchingTool.getSuspiciouslyNotMatchingArgsIndexes((List)Arrays.asList(matcherWithBadDescription),new Object[]{argument});
  assertEquals(0,suspicious.length);
}
