@Test public void shouldPrintUnstubbedInvocationOnMockToStdOut(){
  Foo foo=mock(Foo.class,withSettings().verboseLogging());
  foo.doSomething("Klipsch");
  Assertions.assertThat(printed()).contains(getClass().getName()).contains(mockName(foo)).contains("doSomething").contains("Klipsch");
}
