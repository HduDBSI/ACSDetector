@Test public void shouldReturnAllChunksWhenModeIsAtLeastOnce() throws Exception {
  Invocation simpleMethodInvocationThree=new InvocationBuilder().mock(mock).toInvocation();
  invocations.add(simpleMethodInvocationThree);
  List<Invocation> chunk=finder.findMatchingChunk(invocations,new InvocationMatcher(simpleMethodInvocation),1);
  assertThat(chunk,hasExactlyInOrder(simpleMethodInvocation,simpleMethodInvocationTwo,simpleMethodInvocationThree));
}
