@Test public void shouldFailStubbingThrowableOnTheSameInvocationDueToAcceptableLimitation() throws Exception {
  when(mock.size()).thenThrow(new ExceptionOne());
  exception.expect(ExceptionOne.class);
  when(mock.size()).thenThrow(new ExceptionTwo());
}
