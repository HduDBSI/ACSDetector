@Test public void mocking_inner_classes_with_wrong_outer_instance(){
  try {
    mock(InnerClass.class,withSettings().useConstructor().outerInstance("foo").defaultAnswer(CALLS_REAL_METHODS));
    fail();
  }
 catch (  MockitoException e) {
    assertThat(e).hasMessage("Unable to create mock instance of type 'InnerClass'");
    assertThat(e.getCause()).hasMessageContaining("Unable to find a matching 1-arg constructor for the outer instance.");
  }
}
