@Override public AnnotationEngine getAnnotationEngine(){
  if (this.overriddenEngine != null) {
    return this.overriddenEngine;
  }
  return new CustomizedAnnotationForSmartMockTest.CustomInjectingAnnotationEngine();
}
