/** 
 * NOP Strategy that will always try the next strategy.
 */
public static MockInjectionStrategy nop(){
  return new MockInjectionStrategy(){
    protected boolean processInjection(    Field field,    Object fieldOwner,    Set<Object> mockCandidates){
      return false;
    }
  }
;
}
