public int hashCode(){
  throw new RuntimeException("Should not be called. MethodInterceptorFilter provides implementation");
}
