private void third(){
  mock.simpleMethod(3);
}
