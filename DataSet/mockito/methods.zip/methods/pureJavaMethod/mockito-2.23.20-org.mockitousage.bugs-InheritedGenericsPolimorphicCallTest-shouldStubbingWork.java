@Test public void shouldStubbingWork(){
  Mockito.when(iterable.iterator()).thenReturn(myIterator);
  assertNotNull(((Iterable<String>)iterable).iterator());
  assertNotNull(iterable.iterator());
}
