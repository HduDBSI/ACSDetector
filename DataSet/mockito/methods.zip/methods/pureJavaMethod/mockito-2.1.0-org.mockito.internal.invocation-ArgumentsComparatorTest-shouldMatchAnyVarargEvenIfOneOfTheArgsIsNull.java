@Test public void shouldMatchAnyVarargEvenIfOneOfTheArgsIsNull(){
  mock.mixedVarargs(null,null,"2");
  Invocation invocation=getLastInvocation();
  InvocationMatcher invocationMatcher=new InvocationMatcher(invocation,(List)asList(new Equals(null),ANY));
  boolean match=argumentsMatch(invocationMatcher,invocation);
  assertTrue(match);
}
