/** 
 * Specifies extra interfaces the mock should implement. Might be useful for legacy code or some corner cases. <p> This mysterious feature should be used very occasionally. The object under test should know exactly its collaborators & dependencies. If you happen to use it often than please make sure you are really producing simple, clean & readable code. <p> Examples: <pre class="code"><code class="java"> Foo foo = mock(Foo.class, withSettings().extraInterfaces(Bar.class, Baz.class)); //now, the mock implements extra interfaces, so following casting is possible: Bar bar = (Bar) foo; Baz baz = (Baz) foo; </code></pre>
 * @param interfaces extra interfaces the should implement.
 * @return settings instance so that you can fluently specify other settings
 */
MockSettings extraInterfaces(Class<?>... interfaces);
