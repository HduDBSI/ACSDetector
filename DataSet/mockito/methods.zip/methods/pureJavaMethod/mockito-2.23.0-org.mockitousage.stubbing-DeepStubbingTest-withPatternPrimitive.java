/** 
 * Test that deep stubbing work with primitive expected values with pattern method arguments
 */
@Test public void withPatternPrimitive() throws Exception {
  int a=12, b=23, c=34;
  SocketFactory sf=mock(SocketFactory.class,RETURNS_DEEP_STUBS);
  when(sf.createSocket(eq("stackoverflow.com"),eq(80)).getPort()).thenReturn(a);
  when(sf.createSocket(eq("google.com"),anyInt()).getPort()).thenReturn(b);
  when(sf.createSocket(eq("stackoverflow.com"),eq(8080)).getPort()).thenReturn(c);
  assertEquals(b,sf.createSocket("google.com",80).getPort());
  assertEquals(c,sf.createSocket("stackoverflow.com",8080).getPort());
  assertEquals(a,sf.createSocket("stackoverflow.com",80).getPort());
}
