String throwsNothing(boolean value);
