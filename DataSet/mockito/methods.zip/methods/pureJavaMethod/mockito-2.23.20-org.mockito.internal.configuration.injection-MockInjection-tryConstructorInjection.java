public OngoingMockInjection tryConstructorInjection(){
  injectionStrategies.thenTry(new ConstructorInjection());
  return this;
}
