@Test public void should_print_invocation_with_return_value(){
  listener.reportInvocation(new NotifiedMethodInvocationReport(invocation,"return value"));
  assertThat(printed()).contains(invocation.toString()).contains(invocation.getLocation().toString()).contains("return value");
}
