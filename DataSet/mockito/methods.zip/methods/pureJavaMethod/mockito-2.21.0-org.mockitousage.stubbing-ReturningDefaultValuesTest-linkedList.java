LinkedList<?> linkedList(){
  return null;
}
