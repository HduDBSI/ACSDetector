@Test public void shouldNotThrowNPE() throws Exception {
  Foo foo=new Foo();
  Foo spy=spy(foo);
  spy.len(anyString());
  spy.size(anyMap());
  spy.size(anyList());
  spy.size(anyCollection());
  spy.size(anySet());
}
