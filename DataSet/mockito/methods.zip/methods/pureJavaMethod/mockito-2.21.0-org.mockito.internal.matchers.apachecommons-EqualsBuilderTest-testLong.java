@Test public void testLong(){
  long o1=1L;
  long o2=2L;
  assertTrue(new EqualsBuilder().append(o1,o1).isEquals());
  assertTrue(!new EqualsBuilder().append(o1,o2).isEquals());
}
