public <T>void copyToMock(T from,T mock){
  copy(from,mock,from.getClass(),mock.getClass().getSuperclass());
}
