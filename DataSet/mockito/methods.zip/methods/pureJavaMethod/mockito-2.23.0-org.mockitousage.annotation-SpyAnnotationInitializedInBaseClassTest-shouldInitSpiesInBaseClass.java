@Test public void shouldInitSpiesInBaseClass() throws Exception {
  SubClass subClass=new SubClass();
  MockitoAnnotations.initMocks(subClass);
  assertTrue(MockUtil.isMock(subClass.list));
}
