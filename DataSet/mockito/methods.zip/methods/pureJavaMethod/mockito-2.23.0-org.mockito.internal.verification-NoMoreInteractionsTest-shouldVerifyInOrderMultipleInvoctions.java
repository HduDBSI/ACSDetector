@Test public void shouldVerifyInOrderMultipleInvoctions(){
  NoMoreInteractions n=new NoMoreInteractions();
  Invocation i=new InvocationBuilder().seq(1).toInvocation();
  Invocation i2=new InvocationBuilder().seq(2).toInvocation();
  context.markVerified(i2);
  n.verifyInOrder(new VerificationDataInOrderImpl(context,asList(i,i2),null));
}
