String forByte(Byte value);
