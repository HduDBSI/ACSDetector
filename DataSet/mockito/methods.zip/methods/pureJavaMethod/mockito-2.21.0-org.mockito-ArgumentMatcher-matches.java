/** 
 * Informs if this matcher accepts the given argument. <p> The method should <b>never</b> assert if the argument doesn't match. It should only return false. <p> See the example in the top level javadoc for  {@link ArgumentMatcher}
 * @param argument the argument
 * @return true if this matcher accepts the given argument.
 */
boolean matches(T argument);
