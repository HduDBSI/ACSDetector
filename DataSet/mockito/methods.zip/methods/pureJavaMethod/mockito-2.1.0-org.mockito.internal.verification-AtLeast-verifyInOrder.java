@Override public void verifyInOrder(VerificationDataInOrder data){
  if (wantedCount == 1) {
    checkMissingInvocation(data.getAllInvocations(),data.getWanted(),data.getOrderingContext());
  }
  checkAtLeastNumberOfInvocations(data.getAllInvocations(),data.getWanted(),wantedCount,data.getOrderingContext());
}
