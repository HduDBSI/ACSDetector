private Field field(String fieldName) throws NoSuchFieldException {
  Field field=this.getClass().getDeclaredField(fieldName);
  field.setAccessible(true);
  return field;
}
