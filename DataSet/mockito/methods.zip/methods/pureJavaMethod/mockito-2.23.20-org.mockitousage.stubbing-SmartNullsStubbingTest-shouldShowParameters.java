@Test public void shouldShowParameters(){
  Foo foo=mock(Foo.class,RETURNS_SMART_NULLS);
  Bar smartNull=foo.getBarWithParams(10,"yes sir");
  try {
    smartNull.boo();
    fail();
  }
 catch (  Exception e) {
    assertThat(e).hasMessageContaining("yes sir");
  }
}
