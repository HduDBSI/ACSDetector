String giveMeSomeString(String param);
