@Test public void shouldWorkWithArgumentMatchers() throws Exception {
  mock.add("one");
  verify(mock,atMost(5)).add(anyString());
  try {
    verify(mock,atMost(0)).add(anyString());
    fail();
  }
 catch (  MoreThanAllowedActualInvocations e) {
  }
}
