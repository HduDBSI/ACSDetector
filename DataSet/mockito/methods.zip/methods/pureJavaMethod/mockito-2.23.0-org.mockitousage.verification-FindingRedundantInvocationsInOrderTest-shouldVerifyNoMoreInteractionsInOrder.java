@Test public void shouldVerifyNoMoreInteractionsInOrder() throws Exception {
  mock.simpleMethod();
  mock.simpleMethod(10);
  mock.otherMethod();
  InOrder inOrder=inOrder(mock);
  inOrder.verify(mock).simpleMethod(10);
  inOrder.verify(mock).otherMethod();
  inOrder.verifyNoMoreInteractions();
}
