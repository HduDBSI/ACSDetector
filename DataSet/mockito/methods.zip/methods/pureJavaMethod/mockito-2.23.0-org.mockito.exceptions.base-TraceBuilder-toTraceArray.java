public StackTraceElement[] toTraceArray(){
  return toTraceList().toArray(new StackTraceElement[0]);
}
