static final class FinalClass {
}
