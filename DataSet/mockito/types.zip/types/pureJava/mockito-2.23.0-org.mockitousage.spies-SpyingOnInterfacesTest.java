@SuppressWarnings({"unchecked"}) public class SpyingOnInterfacesTest extends TestBase {
  @Test public void shouldFailFastWhenCallingRealMethodOnInterface() throws Exception {
    List<?> list=mock(List.class);
    try {
      when(list.get(0)).thenCallRealMethod();
      fail();
    }
 catch (    MockitoException e) {
    }
  }
  @Test public void shouldFailInRuntimeWhenCallingRealMethodOnInterface() throws Exception {
    List<Object> list=mock(List.class);
    when(list.get(0)).thenAnswer(new Answer<Object>(){
      public Object answer(      InvocationOnMock invocation) throws Throwable {
        return invocation.callRealMethod();
      }
    }
);
    try {
      list.get(0);
      fail();
    }
 catch (    MockitoException e) {
    }
  }
  @Test public void shouldAllowDelegatingToDefaultMethod() throws Exception {
    assumeTrue("Test can only be executed on Java 8 capable VMs",ClassFileVersion.ofThisVm().isAtLeast(ClassFileVersion.JAVA_V8));
    Class<?> type=new ByteBuddy().makeInterface().defineMethod("foo",String.class,Visibility.PUBLIC).intercept(FixedValue.value("bar")).make().load(getClass().getClassLoader(),ClassLoadingStrategy.Default.WRAPPER).getLoaded();
    Object object=mock(type);
    when(type.getMethod("foo").invoke(object)).thenCallRealMethod();
    Assertions.assertThat(type.getMethod("foo").invoke(object)).isEqualTo((Object)"bar");
    type.getMethod("foo").invoke(verify(object));
  }
  @Test public void shouldAllowSpyingOnDefaultMethod() throws Exception {
    assumeTrue("Test can only be executed on Java 8 capable VMs",ClassFileVersion.ofThisVm().isAtLeast(ClassFileVersion.JAVA_V8));
    Class<?> iFace=new ByteBuddy().makeInterface().defineMethod("foo",String.class,Visibility.PUBLIC).intercept(FixedValue.value("bar")).make().load(getClass().getClassLoader(),ClassLoadingStrategy.Default.WRAPPER).getLoaded();
    Class<?> impl=new ByteBuddy().subclass(iFace).make().load(iFace.getClassLoader(),ClassLoadingStrategy.Default.WRAPPER).getLoaded();
    Object object=spy(impl.newInstance());
    Assertions.assertThat(impl.getMethod("foo").invoke(object)).isEqualTo((Object)"bar");
    impl.getMethod("foo").invoke(verify(object));
  }
}
