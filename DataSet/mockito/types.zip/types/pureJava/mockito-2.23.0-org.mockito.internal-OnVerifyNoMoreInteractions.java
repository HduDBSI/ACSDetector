private static class OnVerifyNoMoreInteractions implements DetectsInvalidState {
  @SuppressWarnings({"CheckReturnValue","MockitoUsage"}) public void detect(  IMethods mock){
    verifyNoMoreInteractions(mock);
  }
}
