public class MockUtilTest extends TestBase {
  @SuppressWarnings("unchecked") @Test public void shouldGetHandler(){
    List mock=Mockito.mock(List.class);
    assertNotNull(MockUtil.getMockHandler(mock));
  }
  @Test public void shouldScreamWhenEnhancedButNotAMockPassed(){
    Object o=Enhancer.create(ArrayList.class,NoOp.INSTANCE);
    try {
      MockUtil.getMockHandler(o);
      fail();
    }
 catch (    NotAMockException e) {
    }
  }
  @Test(expected=NotAMockException.class) public void shouldScreamWhenNotAMockPassed(){
    MockUtil.getMockHandler("");
  }
  @Test(expected=MockitoException.class) public void shouldScreamWhenNullPassed(){
    MockUtil.getMockHandler(null);
  }
  @Test public void shouldValidateMock(){
    assertFalse(MockUtil.isMock("i mock a mock"));
    assertTrue(MockUtil.isMock(Mockito.mock(List.class)));
  }
}
