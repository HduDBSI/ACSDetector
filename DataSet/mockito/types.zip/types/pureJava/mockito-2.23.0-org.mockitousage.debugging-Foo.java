interface Foo {
  String giveMeSomeString(  String param);
  void doSomething(  String param);
}
