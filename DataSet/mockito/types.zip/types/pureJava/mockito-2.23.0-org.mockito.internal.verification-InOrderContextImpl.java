public class InOrderContextImpl implements InOrderContext {
  final IdentitySet verified=new IdentitySet();
  public boolean isVerified(  Invocation invocation){
    return verified.contains(invocation);
  }
  public void markVerified(  Invocation i){
    verified.add(i);
  }
}
