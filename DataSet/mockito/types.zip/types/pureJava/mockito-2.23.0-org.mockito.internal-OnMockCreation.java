private static class OnMockCreation implements DetectsInvalidState {
  @SuppressWarnings({"CheckReturnValue","MockitoUsage"}) public void detect(  IMethods mock){
    mock(IMethods.class);
  }
}
