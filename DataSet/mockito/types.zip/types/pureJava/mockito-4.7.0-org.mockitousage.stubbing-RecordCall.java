private static class RecordCall implements Answer<Object> {
  private boolean called=false;
  public boolean isCalled(){
    return called;
  }
  public Object answer(  InvocationOnMock invocation) throws Throwable {
    called=true;
    return null;
  }
}
