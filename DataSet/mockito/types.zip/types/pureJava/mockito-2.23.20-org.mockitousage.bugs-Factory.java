public interface Factory {
}
