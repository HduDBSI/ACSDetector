interface HasCompare extends Comparable {
  public int foo(  HasCompare other);
  public int compareTo(  HasCompare other,  String redHerring);
  public int compareTo(  String redHerring);
  public int compareTo(  HasCompare redHerring);
}
