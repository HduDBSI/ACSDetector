interface ObjectLikeInterface {
  boolean equals(  Object o);
  String toString();
  int hashCode();
}
