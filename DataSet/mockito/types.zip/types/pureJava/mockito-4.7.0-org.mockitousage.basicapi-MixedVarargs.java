interface MixedVarargs {
  String doSomething(  String one,  String... varargs);
  String doSomething(  String one,  String two,  String... varargs);
}
