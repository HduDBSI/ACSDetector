public class MatchersMixedWithRawArgumentsTest extends TestBase {
  @Mock private IMethods mock;
  @Ignore("prototyping new feature that allows to avoid eq() matchers when raw args passed") @Test public void shouldAllowMixingRawArgumentsWithMatchers(){
    mock.varargs("1","2","3");
    verify(mock).varargs("1",anyString(),"3");
    verify(mock).varargs(anyBoolean(),false);
  }
}
