static class Street {
  String name;
  public String getName(){
    return name;
  }
  public String getLongName(){
    return name;
  }
}
