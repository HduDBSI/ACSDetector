public interface TableBuilder {
  void newRow(  String trAttributes,  String... cells);
}
