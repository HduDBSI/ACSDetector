/** 
 * Tests the verbose logging of invocation on mock methods. BEWARE: These tests rely on mocking the standard output. While in a single-threaded environment the Before/After-contract ensures, that the original output stream is restored, there is no guarantee for this in the parallel setting. Maybe, the test class should be @Ignore'd by default ...
 */
@RunWith(MockitoJUnitRunner.class) public class VerboseLoggingOfInvocationsOnMockTest {
  private ByteArrayOutputStream output;
  private PrintStream original;
  @Mock UnrelatedClass unrelatedMock;
  @Before public void setUp(){
    original=System.out;
    output=new ByteArrayOutputStream();
    System.setOut(new PrintStream(output));
  }
  @After public void tearDown(){
    System.setOut(original);
  }
  @Test public void shouldNotPrintInvocationOnMockWithoutSetting(){
    Foo foo=mock(Foo.class,withSettings().verboseLogging());
    foo.giveMeSomeString("Klipsch");
    unrelatedMock.unrelatedMethod("Apple");
    Assertions.assertThat(printed()).doesNotContain(mockName(unrelatedMock)).doesNotContain("unrelatedMethod").doesNotContain("Apple");
  }
  @Test public void shouldPrintUnstubbedInvocationOnMockToStdOut(){
    Foo foo=mock(Foo.class,withSettings().verboseLogging());
    foo.doSomething("Klipsch");
    Assertions.assertThat(printed()).contains(getClass().getName()).contains(mockName(foo)).contains("doSomething").contains("Klipsch");
  }
  @Test public void shouldPrintStubbedInvocationOnMockToStdOut(){
    Foo foo=mock(Foo.class,withSettings().verboseLogging());
    given(foo.giveMeSomeString("Klipsch")).willReturn("earbuds");
    foo.giveMeSomeString("Klipsch");
    Assertions.assertThat(printed()).contains(getClass().getName()).contains(mockName(foo)).contains("giveMeSomeString").contains("Klipsch").contains("earbuds");
  }
  @Test public void shouldPrintThrowingInvocationOnMockToStdOut(){
    Foo foo=mock(Foo.class,withSettings().verboseLogging());
    doThrow(new ThirdPartyException()).when(foo).doSomething("Klipsch");
    try {
      foo.doSomething("Klipsch");
      fail("Exception excepted.");
    }
 catch (    ThirdPartyException e) {
      Assertions.assertThat(printed()).contains(getClass().getName()).contains(mockName(foo)).contains("doSomething").contains("Klipsch").contains(ThirdPartyException.class.getName());
    }
  }
  @Test public void shouldPrintRealInvocationOnSpyToStdOut(){
    FooImpl fooSpy=mock(FooImpl.class,withSettings().spiedInstance(new FooImpl()).verboseLogging());
    doCallRealMethod().when(fooSpy).doSomething("Klipsch");
    fooSpy.doSomething("Klipsch");
    Assertions.assertThat(printed()).contains(getClass().getName()).contains(mockName(fooSpy)).contains("doSomething").contains("Klipsch");
  }
  @Test public void usage(){
    Foo foo=mock(Foo.class,withSettings().verboseLogging());
    given(foo.giveMeSomeString("Apple")).willReturn("earbuds");
    foo.giveMeSomeString("Shure");
    foo.giveMeSomeString("Apple");
    foo.doSomething("Klipsch");
  }
  private String printed(){
    return output.toString();
  }
  private String mockName(  Object mock){
    return MockUtil.getMockName(mock).toString();
  }
private static class UnrelatedClass {
    void unrelatedMethod(    String anotherStringValue){
    }
  }
  /** 
 * An exception that isn't defined by Mockito or the JDK and therefore does not appear in the logging result by chance alone.
 */
static class ThirdPartyException extends RuntimeException {
    private static final long serialVersionUID=2160445705646210847L;
  }
static class FooImpl implements Foo {
    public String giveMeSomeString(    String param){
      return null;
    }
    public void doSomething(    String param){
    }
  }
}
