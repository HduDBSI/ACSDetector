public class MockingMultipleInterfacesTest {
class Foo {
  }
interface IFoo {
  }
interface IBar {
  }
  @Test public void should_allow_multiple_interfaces(){
    Foo mock=mock(Foo.class,withSettings().extraInterfaces(IFoo.class,IBar.class));
    assertThat(mock).isInstanceOf(IFoo.class);
    assertThat(mock).isInstanceOf(IBar.class);
  }
  @Test public void should_scream_when_null_passed_instead_of_an_interface(){
    try {
      mock(Foo.class,withSettings().extraInterfaces(IFoo.class,null));
      fail();
    }
 catch (    MockitoException e) {
      assertThat(e.getMessage()).contains("extraInterfaces() does not accept null parameters");
    }
  }
  @Test public void should_scream_when_no_args_passed(){
    try {
      mock(Foo.class,withSettings().extraInterfaces());
      fail();
    }
 catch (    MockitoException e) {
      assertThat(e.getMessage()).contains("extraInterfaces() requires at least one interface");
    }
  }
  @Test public void should_scream_when_null_passed_instead_of_an_array(){
    try {
      mock(Foo.class,withSettings().extraInterfaces((Class[])null));
      fail();
    }
 catch (    MockitoException e) {
      assertThat(e.getMessage()).contains("extraInterfaces() requires at least one interface");
    }
  }
  @Test public void should_scream_when_non_interface_passed(){
    try {
      mock(Foo.class,withSettings().extraInterfaces(Foo.class));
      fail();
    }
 catch (    MockitoException e) {
      assertThat(e.getMessage()).contains("Foo which is not an interface");
    }
  }
  @Test public void should_scream_when_the_same_interfaces_passed(){
    try {
      mock(IMethods.class,withSettings().extraInterfaces(IMethods.class));
      fail();
    }
 catch (    MockitoException e) {
      assertThat(e.getMessage()).contains("You mocked following type: IMethods");
    }
  }
  @Test public void should_mock_class_with_interfaces_of_different_class_loader_AND_different_classpaths() throws ClassNotFoundException {
    Class<?> interface1=inMemoryClassLoader().withClassDefinition("test.Interface1",makeMarkerInterface("test.Interface1")).build().loadClass("test.Interface1");
    Class<?> interface2=inMemoryClassLoader().withClassDefinition("test.Interface2",makeMarkerInterface("test.Interface2")).build().loadClass("test.Interface2");
    Object mocked=mock(interface1,withSettings().extraInterfaces(interface2));
    assertThat(interface2.isInstance(mocked)).describedAs("mock should be assignable from interface2 type").isTrue();
  }
}
