static class ThrowingConstructor {
  ThrowingConstructor(){
    throw new RuntimeException("boo!");
  }
}
