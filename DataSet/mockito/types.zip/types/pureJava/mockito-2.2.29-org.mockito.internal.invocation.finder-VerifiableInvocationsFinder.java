/** 
 * Author: Szczepan Faber, created at: 4/3/11
 */
public class VerifiableInvocationsFinder {
  private VerifiableInvocationsFinder(){
  }
  public static List<Invocation> find(  List<?> mocks){
    List<Invocation> invocations=AllInvocationsFinder.find(mocks);
    return ListUtil.filter(invocations,new RemoveIgnoredForVerification());
  }
private static class RemoveIgnoredForVerification implements Filter<Invocation> {
    public boolean isOut(    Invocation invocation){
      return invocation.isIgnoredForVerification();
    }
  }
}
