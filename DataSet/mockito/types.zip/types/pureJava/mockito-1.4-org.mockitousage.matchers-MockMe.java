interface MockMe {
  void run(  Child child);
}
