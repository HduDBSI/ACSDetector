public class MockitoPluginsTest extends TestBase {
  private final MockitoPlugins plugins=Mockito.framework().getPlugins();
  @Test public void provides_built_in_plugins(){
    assertNotNull(plugins.getInlineMockMaker());
    assertNotNull(plugins.getDefaultPlugin(MockMaker.class));
    assertNotNull(plugins.getDefaultPlugin(StackTraceCleanerProvider.class));
    assertNotNull(plugins.getDefaultPlugin(PluginSwitch.class));
    assertNotNull(plugins.getDefaultPlugin(InstantiatorProvider.class));
    assertNotNull(plugins.getDefaultPlugin(InstantiatorProvider2.class));
    assertNotNull(plugins.getDefaultPlugin(AnnotationEngine.class));
  }
  @SuppressWarnings("deprecation") @Test public void instantiator_provider_backwards_compatibility(){
    InstantiatorProvider provider=plugins.getDefaultPlugin(InstantiatorProvider.class);
    Instantiator instantiator=provider.getInstantiator(withSettings().build(MockitoPluginsTest.class));
    assertNotNull(instantiator.newInstance(MockitoPluginsTest.class));
  }
}
