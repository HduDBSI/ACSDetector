private class ExceptionFour extends RuntimeException {
}
