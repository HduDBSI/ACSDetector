interface IBar {
}
