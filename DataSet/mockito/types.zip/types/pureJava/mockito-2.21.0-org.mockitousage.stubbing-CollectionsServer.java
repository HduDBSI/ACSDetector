private class CollectionsServer {
  List<?> list(){
    return null;
  }
  LinkedList<?> linkedList(){
    return null;
  }
  Map<?,?> map(){
    return null;
  }
  HashSet<?> hashSet(){
    return null;
  }
}
