public static class SomeMethods {
  public void allowedMethod(){
  }
  public void disallowedMethod(){
  }
}
