public class ThreadsRunAllTestsHalfManualTest extends TestBase {
private static class AllTestsRunner extends Thread {
    private Set<Class<?>> failed=new HashSet<Class<?>>();
    public void run(){
      Result result=JUnitCore.runClasses(EqualsTest.class,MockingProgressImplTest.class,TimesTest.class,MockHandlerImplTest.class,AllInvocationsFinderTest.class,ReturnsEmptyValuesTest.class,NumberOfInvocationsCheckerTest.class,DefaultRegisteredInvocationsTest.class,MissingInvocationCheckerTest.class,NumberOfInvocationsInOrderCheckerTest.class,MissingInvocationInOrderCheckerTest.class,TypeCachingMockBytecodeGeneratorTest.class,InvocationMatcherTest.class,InvocationsFinderTest.class,MockitoTest.class,MockUtilTest.class,ReporterTest.class,MockitoAssertionErrorTest.class,MockitoExceptionTest.class,StackTraceFilteringTest.class,BridgeMethodPuzzleTest.class,OverloadingPuzzleTest.class,InvalidUsageTest.class,UsingVarargsTest.class,CustomMatchersTest.class,ComparableMatchersTest.class,InvalidUseOfMatchersTest.class,MatchersTest.class,MatchersToStringTest.class,VerificationAndStubbingUsingMatchersTest.class,BasicStubbingTest.class,ReturningDefaultValuesTest.class,StubbingWithThrowablesTest.class,AtMostXVerificationTest.class,BasicVerificationTest.class,ExactNumberOfTimesVerificationTest.class,VerificationInOrderTest.class,NoMoreInteractionsVerificationTest.class,SelectedMocksInOrderVerificationTest.class,VerificationOnMultipleMocksUsingMatchersTest.class,VerificationUsingMatchersTest.class,RelaxedVerificationInOrderTest.class,DescriptiveMessagesWhenVerificationFailsTest.class,DescriptiveMessagesWhenTimesXVerificationFailsTest.class,BasicVerificationInOrderTest.class,VerificationInOrderMixedWithOrdinaryVerificationTest.class,DescriptiveMessagesOnVerificationInOrderErrorsTest.class,InvalidStateDetectionTest.class,ReplacingObjectMethodsTest.class,ClickableStackTracesTest.class,ExampleTest.class,PointingStackTraceToActualInvocationTest.class,VerificationInOrderFromMultipleThreadsTest.class,ResetTest.class,ReturnsGenericDeepStubsTest.class);
      if (!result.wasSuccessful()) {
        System.err.println("Thread[" + Thread.currentThread().getId() + "]: error!");
        List<Failure> failures=result.getFailures();
        System.err.println(failures.size());
        for (        Failure failure : failures) {
          System.err.println(failure.getTrace());
          failed.add(failure.getDescription().getTestClass());
        }
      }
    }
    public Set<Class<?>> getFailed(){
      return failed;
    }
  }
  @Test public void shouldRunInMultipleThreads() throws Exception {
    assertEquals("Run in multiple thread failed for tests",Collections.emptySet(),runInMultipleThreads(3));
  }
  public static Set<Class<?>> runInMultipleThreads(  int numberOfThreads) throws Exception {
    List<AllTestsRunner> threads=new LinkedList<AllTestsRunner>();
    for (int i=1; i <= numberOfThreads; i++) {
      threads.add(new AllTestsRunner());
    }
    for (    Thread t : threads) {
      t.start();
    }
    Set<Class<?>> failed=new HashSet<Class<?>>();
    for (    AllTestsRunner t : threads) {
      t.join();
      failed.addAll(t.getFailed());
    }
    return failed;
  }
  public static void main(  String[] args) throws Exception {
    int numberOfThreads=20;
    long before=System.currentTimeMillis();
    Set<Class<?>> failed=runInMultipleThreads(numberOfThreads);
    long after=System.currentTimeMillis();
    long executionTime=(after - before) / 1000;
    System.out.println("Finished tests in " + numberOfThreads + " threads in "+ executionTime+ " seconds. ("+ failed.size()+ " tests failed)");
  }
}
