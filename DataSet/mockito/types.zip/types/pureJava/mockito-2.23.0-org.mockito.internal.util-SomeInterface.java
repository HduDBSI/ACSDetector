interface SomeInterface {
}
