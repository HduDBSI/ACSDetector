public interface FindingsListener {
  void foundStubCalledWithDifferentArgs(  Invocation unused,  InvocationMatcher unstubbed);
  void foundUnusedStub(  Invocation unused);
  void foundUnstubbed(  InvocationMatcher unstubbed);
}
