@SuppressWarnings("unused") public class FieldReaderTest extends TestBase {
class Foo {
    private final String isNull=null;
    private final String notNull="";
  }
  @Test public void shouldKnowWhenNull() throws Exception {
    FieldReader reader=new FieldReader(new Foo(),Foo.class.getDeclaredField("isNull"));
    assertTrue(reader.isNull());
  }
  @Test public void shouldKnowWhenNotNull() throws Exception {
    FieldReader reader=new FieldReader(new Foo(),Foo.class.getDeclaredField("notNull"));
    assertFalse(reader.isNull());
  }
}
