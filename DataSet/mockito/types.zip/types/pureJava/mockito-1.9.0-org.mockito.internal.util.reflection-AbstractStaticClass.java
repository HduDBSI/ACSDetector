static abstract class AbstractStaticClass {
  public AbstractStaticClass(){
  }
}
