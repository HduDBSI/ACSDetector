@SuppressWarnings("unchecked") public class Or extends ArgumentMatcher {
  private final List<Matcher> matchers;
  public Or(  List<Matcher> matchers){
    this.matchers=matchers;
  }
  public boolean matches(  Object actual){
    for (    Matcher matcher : matchers) {
      if (matcher.matches(actual)) {
        return true;
      }
    }
    return false;
  }
  public void describeTo(  Description description){
    description.appendText("or(");
    for (Iterator<Matcher> it=matchers.iterator(); it.hasNext(); ) {
      it.next().describeTo(description);
      if (it.hasNext()) {
        description.appendText(", ");
      }
    }
    description.appendText(")");
  }
}
