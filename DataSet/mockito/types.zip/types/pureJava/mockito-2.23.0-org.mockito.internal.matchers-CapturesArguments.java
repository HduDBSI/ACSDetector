public interface CapturesArguments {
  void captureFrom(  Object argument);
}
