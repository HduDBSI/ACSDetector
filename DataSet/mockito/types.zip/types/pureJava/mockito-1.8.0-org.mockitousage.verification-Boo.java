class Boo {
  public void withLong(  long x){
  }
  public void withLongAndInt(  long x,  int y){
  }
}
