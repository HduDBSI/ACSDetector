static class Street {
  String name;
  public String getName(){
    return name;
  }
}
