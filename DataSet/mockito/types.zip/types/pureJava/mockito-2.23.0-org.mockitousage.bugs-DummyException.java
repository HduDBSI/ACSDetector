class DummyException extends RuntimeException {
  private static final long serialVersionUID=1L;
}
