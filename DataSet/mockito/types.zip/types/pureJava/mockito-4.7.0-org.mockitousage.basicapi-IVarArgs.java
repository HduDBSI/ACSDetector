private interface IVarArgs {
  void withStringVarargs(  int value,  String... s);
  String withStringVarargsReturningString(  int value,  String... s);
  void withObjectVarargs(  int value,  Object... o);
  boolean withBooleanVarargs(  int value,  boolean... b);
  int foo(  Object... objects);
}
