public class TestMethodsFinderTest extends TestBase {
public static class HasTests {
    @Test public void someTest(){
    }
  }
static class DoesNotHaveTests {
    public void someTest(){
    }
  }
  @Test public void shouldKnowWhenClassHasTests(){
    assertTrue(TestMethodsFinder.hasTestMethods(HasTests.class));
    assertFalse(TestMethodsFinder.hasTestMethods(DoesNotHaveTests.class));
  }
}
