static class Foo {
}
