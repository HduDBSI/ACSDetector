static class ConcreteStaticClass extends AbstractStaticClass implements Interface {
}
