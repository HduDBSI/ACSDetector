static class TestSubObject extends TestObject {
  private int b;
  public TestSubObject(){
    super(0);
  }
  public TestSubObject(  int a,  int b){
    super(a);
    this.b=b;
  }
  public boolean equals(  Object o){
    if (o == null) {
      return false;
    }
    if (o == this) {
      return true;
    }
    if (o.getClass() != getClass()) {
      return false;
    }
    TestSubObject rhs=(TestSubObject)o;
    return super.equals(o) && (b == rhs.b);
  }
  public int hashCode(){
    return 1;
  }
  public void setB(  int b){
    this.b=b;
  }
  public int getB(){
    return b;
  }
}
