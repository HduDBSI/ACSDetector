static class Foo {
  int doSomeThing(){
    return 0;
  }
  protected String getStuff(){
    return "foo";
  }
}
