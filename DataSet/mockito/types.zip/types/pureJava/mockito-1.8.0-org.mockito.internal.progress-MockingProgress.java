public interface MockingProgress {
  void reportOngoingStubbing(  IOngoingStubbing iOngoingStubbing);
  IOngoingStubbing pullOngoingStubbing();
  void verificationStarted(  VerificationMode verificationMode);
  VerificationMode pullVerificationMode();
  void stubbingStarted();
  void stubbingCompleted(  Invocation invocation);
  void validateState();
  void reset();
  /** 
 * Removes ongoing stubbing so that in case the framework is misused state validation errors are more accurate
 */
  void resetOngoingStubbing();
  ArgumentMatcherStorage getArgumentMatcherStorage();
  DebuggingInfo getDebuggingInfo();
}
