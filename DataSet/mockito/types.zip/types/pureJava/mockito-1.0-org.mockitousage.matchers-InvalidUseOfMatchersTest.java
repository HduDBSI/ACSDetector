@SuppressWarnings("unchecked") public class InvalidUseOfMatchersTest extends TestBase {
  private IMethods mock;
  @Before public void setUp(){
    StateResetter.reset();
    mock=Mockito.mock(IMethods.class);
  }
  @After public void resetState(){
    StateResetter.reset();
  }
  @Test public void shouldDetectWrongNumberOfMatchersWhenStubbing(){
    Mockito.stub(mock.threeArgumentMethod(1,"2","3")).toReturn(null);
    try {
      Mockito.stub(mock.threeArgumentMethod(1,eq("2"),"3")).toReturn(null);
      fail();
    }
 catch (    InvalidUseOfMatchersException e) {
    }
  }
  @Test public void shouldDetectStupidUseOfMatchersWhenVerifying(){
    mock.oneArg(true);
    eq("that's the stupid way");
    eq("of using matchers");
    try {
      Mockito.verify(mock).oneArg(true);
      fail();
    }
 catch (    InvalidUseOfMatchersException e) {
    }
  }
  @Test public void shouldScreamWhenMatchersAreInvalid(){
    mock.simpleMethod(AdditionalMatchers.not(eq("asd")));
    try {
      mock.simpleMethod(AdditionalMatchers.not("jkl"));
      fail();
    }
 catch (    InvalidUseOfMatchersException e) {
      assertThat(e,messageContains("No matchers found for Not(?)."));
    }
    try {
      mock.simpleMethod(AdditionalMatchers.or(eq("jkl"),"asd"));
      fail();
    }
 catch (    InvalidUseOfMatchersException e) {
      assertThat(e,messageContains("2 matchers expected, 1 recorded."));
    }
    try {
      mock.threeArgumentMethod(1,"asd",eq("asd"));
      fail();
    }
 catch (    InvalidUseOfMatchersException e) {
      assertThat(e,messageContains("3 matchers expected, 1 recorded."));
    }
  }
}
