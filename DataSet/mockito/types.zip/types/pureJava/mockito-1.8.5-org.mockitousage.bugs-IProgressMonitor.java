interface IProgressMonitor {
  void beginTask(  String s,  int i);
  void worked(  int i);
  void done();
}
