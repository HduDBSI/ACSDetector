private static class ThirdPartyException extends Exception {
  private static final long serialVersionUID=3022739107688491354L;
}
