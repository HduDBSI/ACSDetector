public class SimpleMockitoLoggerTest extends TestBase {
  @Test public void shouldLog() throws Exception {
    SimpleMockitoLogger logger=new SimpleMockitoLogger();
    logger.log("foo");
    assertEquals("foo",logger.getLoggedInfo());
  }
}
