public static class SomeOtherObject {
}
