private class ExceptionOne extends RuntimeException {
}
