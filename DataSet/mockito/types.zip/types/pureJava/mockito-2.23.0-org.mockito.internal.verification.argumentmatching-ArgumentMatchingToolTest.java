@SuppressWarnings({"unchecked","serial"}) public class ArgumentMatchingToolTest extends TestBase {
  @Test public void shouldNotFindAnySuspiciousMatchersWhenNumberOfArgumentsDoesntMatch(){
    List<ArgumentMatcher> matchers=(List)Arrays.asList(new Equals(1));
    Integer[] suspicious=ArgumentMatchingTool.getSuspiciouslyNotMatchingArgsIndexes(matchers,new Object[]{10,20});
    assertEquals(0,suspicious.length);
  }
  @Test public void shouldNotFindAnySuspiciousMatchersWhenArgumentsMatch(){
    List<ArgumentMatcher> matchers=(List)Arrays.asList(new Equals(10),new Equals(20));
    Integer[] suspicious=ArgumentMatchingTool.getSuspiciouslyNotMatchingArgsIndexes(matchers,new Object[]{10,20});
    assertEquals(0,suspicious.length);
  }
  @Test public void shouldFindSuspiciousMatchers(){
    Equals matcherInt20=new Equals(20);
    Long longPretendingAnInt=20L;
    List<ArgumentMatcher> matchers=(List)Arrays.asList(new Equals(10),matcherInt20);
    Integer[] suspicious=ArgumentMatchingTool.getSuspiciouslyNotMatchingArgsIndexes(matchers,new Object[]{10,longPretendingAnInt});
    assertEquals(1,suspicious.length);
    assertEquals(new Integer(1),suspicious[0]);
  }
  @Test public void shouldNotFindSuspiciousMatchersWhenTypesAreTheSame(){
    Equals matcherWithBadDescription=new Equals(20){
      public String toString(){
        return "10";
      }
    }
;
    Integer argument=10;
    Integer[] suspicious=ArgumentMatchingTool.getSuspiciouslyNotMatchingArgsIndexes((List)Arrays.asList(matcherWithBadDescription),new Object[]{argument});
    assertEquals(0,suspicious.length);
  }
  @Test public void shouldWorkFineWhenGivenArgIsNull(){
    Integer[] suspicious=ArgumentMatchingTool.getSuspiciouslyNotMatchingArgsIndexes((List)Arrays.asList(new Equals(20)),new Object[]{null});
    assertEquals(0,suspicious.length);
  }
  @Test @SuppressWarnings("rawtypes") public void shouldUseMatchersSafely(){
class StringMatcher implements ArgumentMatcher<String>, ContainsExtraTypeInfo {
      @Override public boolean matches(      String item){
        return true;
      }
      @Override public String toStringWithType(){
        return "";
      }
      @Override public boolean typeMatches(      Object target){
        return true;
      }
    }
    List<ArgumentMatcher> matchers=(List)singletonList(new StringMatcher());
    Integer[] suspicious=ArgumentMatchingTool.getSuspiciouslyNotMatchingArgsIndexes(matchers,new Object[]{10});
    assertEquals(0,suspicious.length);
  }
}
