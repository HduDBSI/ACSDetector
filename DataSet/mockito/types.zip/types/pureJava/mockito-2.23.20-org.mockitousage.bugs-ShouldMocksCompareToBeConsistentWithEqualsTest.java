public class ShouldMocksCompareToBeConsistentWithEqualsTest extends TestBase {
  @Test public void should_compare_to_be_consistent_with_equals(){
    Date today=mock(Date.class);
    Date tomorrow=mock(Date.class);
    Set<Date> set=new TreeSet<Date>();
    set.add(today);
    set.add(tomorrow);
    assertEquals(2,set.size());
  }
  @Test public void should_compare_to_be_consistent_with_equals_when_comparing_the_same_reference(){
    Date today=mock(Date.class);
    Set<Date> set=new TreeSet<Date>();
    set.add(today);
    set.add(today);
    assertEquals(1,set.size());
  }
  @Test public void should_allow_stubbing_and_verifying_compare_to(){
    Date mock=mock(Date.class);
    when(mock.compareTo(any(Date.class))).thenReturn(10);
    mock.compareTo(new Date());
    assertEquals(10,mock.compareTo(new Date()));
    verify(mock,atLeastOnce()).compareTo(any(Date.class));
  }
  @Test public void should_reset_not_remove_default_stubbing(){
    Date mock=mock(Date.class);
    reset(mock);
    assertEquals(1,mock.compareTo(new Date()));
  }
}
