static class Address {
  Street street;
  public Street getStreet(){
    return street;
  }
}
