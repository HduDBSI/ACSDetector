public class InvocationMarkerTest extends TestBase {
  @Test public void shouldMarkInvocationAsVerified(){
    Invocation i=new InvocationBuilder().toInvocation();
    InvocationMatcher im=new InvocationBuilder().toInvocationMatcher();
    assertFalse(i.isVerified());
    InvocationMarker.markVerified(Arrays.asList(i),im);
    assertTrue(i.isVerified());
  }
  @Test public void shouldCaptureArguments(){
    Invocation i=new InvocationBuilder().toInvocation();
    final AtomicReference<Invocation> box=new AtomicReference<Invocation>();
    MatchableInvocation c=new InvocationMatcher(i){
      public void captureArgumentsFrom(      Invocation i){
        box.set(i);
      }
    }
;
    InvocationMarker.markVerified(Arrays.asList(i),c);
    assertEquals(i,box.get());
  }
  @Test public void shouldMarkInvocationsAsVerifiedInOrder(){
    InOrderContextImpl context=new InOrderContextImpl();
    Invocation i=new InvocationBuilder().toInvocation();
    InvocationMatcher im=new InvocationBuilder().toInvocationMatcher();
    assertFalse(context.isVerified(i));
    assertFalse(i.isVerified());
    InvocationMarker.markVerifiedInOrder(Arrays.asList(i),im,context);
    assertTrue(context.isVerified(i));
    assertTrue(i.isVerified());
  }
}
