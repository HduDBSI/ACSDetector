@SuppressWarnings("unchecked") public class PartialMockingWithSpiesTest extends TestBase {
  @Before public void pleaseMakeStackTracesClean(){
    makeStackTracesClean();
  }
class InheritMe {
    private String inherited="100$";
    protected String getInherited(){
      return inherited;
    }
  }
class Person extends InheritMe {
    private final Name defaultName=new Name("Default name");
    public String getName(){
      return guessName().name;
    }
    Name guessName(){
      return defaultName;
    }
    public String howMuchDidYouInherit(){
      return getInherited();
    }
    public String getNameButDelegateToMethodThatThrows(){
      throwSomeException();
      return guessName().name;
    }
    private void throwSomeException(){
      throw new RuntimeException("boo");
    }
  }
class Name {
    private final String name;
    public Name(    String name){
      this.name=name;
    }
  }
  Person spy=spy(new Person());
  @Test public void shouldCallRealMethdsEvenDelegatedToOtherSelfMethod(){
    String name=spy.getName();
    assertEquals("Default name",name);
  }
  @Test public void shouldAllowStubbingOfMethodsThatDelegateToOtherMethods(){
    when(spy.getName()).thenReturn("foo");
    assertEquals("foo",spy.getName());
  }
  @Test public void shouldAllowStubbingWithThrowablesMethodsThatDelegateToOtherMethods(){
    doThrow(new RuntimeException("appetite for destruction")).when(spy).getNameButDelegateToMethodThatThrows();
    try {
      spy.getNameButDelegateToMethodThatThrows();
      fail();
    }
 catch (    Exception e) {
      assertEquals("appetite for destruction",e.getMessage());
    }
  }
  @Test public void shouldStackTraceGetFilteredOnUserExceptions(){
    try {
      spy.getNameButDelegateToMethodThatThrows();
      fail();
    }
 catch (    Throwable t) {
      Assertions.assertThat(t).has(methodsInStackTrace("throwSomeException","getNameButDelegateToMethodThatThrows","shouldStackTraceGetFilteredOnUserExceptions"));
    }
  }
  public void verifyTheStackTrace(){
    spy.getNameButDelegateToMethodThatThrows();
  }
  @Test public void shouldVerify(){
    spy.getName();
    verify(spy).guessName();
  }
  @Test public void shouldStub(){
    when(spy.guessName()).thenReturn(new Name("John"));
    String name=spy.getName();
    assertEquals("John",name);
  }
  @Test public void shouldDealWithPrivateFieldsOfSubclasses(){
    assertEquals("100$",spy.howMuchDidYouInherit());
  }
}
