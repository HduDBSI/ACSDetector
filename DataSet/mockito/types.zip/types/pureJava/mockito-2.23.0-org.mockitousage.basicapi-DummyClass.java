private class DummyClass {
}
