private final class IsSorZ implements ArgumentMatcher<Character> {
  public boolean matches(  Character character){
    return character.equals('s') || character.equals('z');
  }
}
