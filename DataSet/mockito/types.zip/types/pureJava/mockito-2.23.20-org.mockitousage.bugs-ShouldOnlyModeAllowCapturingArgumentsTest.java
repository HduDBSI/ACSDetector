public class ShouldOnlyModeAllowCapturingArgumentsTest extends TestBase {
  @Mock IMethods mock;
  @Test public void shouldAllowCapturingArguments(){
    mock.simpleMethod("o");
    ArgumentCaptor<String> arg=ArgumentCaptor.forClass(String.class);
    verify(mock,only()).simpleMethod(arg.capture());
    assertEquals("o",arg.getValue());
  }
}
