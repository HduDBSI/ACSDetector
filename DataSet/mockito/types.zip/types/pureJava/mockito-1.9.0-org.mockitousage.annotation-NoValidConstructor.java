static class NoValidConstructor {
  NoValidConstructor(  String f){
  }
}
