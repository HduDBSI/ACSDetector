public class AtMost implements VerificationMode {
  private final int maxNumberOfInvocations;
  public AtMost(  int maxNumberOfInvocations){
    if (maxNumberOfInvocations < 0) {
      throw new MockitoException("Negative value is not allowed here");
    }
    this.maxNumberOfInvocations=maxNumberOfInvocations;
  }
  public void verify(  VerificationData data){
    List<Invocation> invocations=data.getAllInvocations();
    MatchableInvocation wanted=data.getTarget();
    List<Invocation> found=findInvocations(invocations,wanted);
    int foundSize=found.size();
    if (foundSize > maxNumberOfInvocations) {
      throw wantedAtMostX(maxNumberOfInvocations,foundSize);
    }
    removeAlreadyVerified(found);
    markVerified(found,wanted);
  }
  @Override public VerificationMode description(  String description){
    return VerificationModeFactory.description(this,description);
  }
  private void removeAlreadyVerified(  List<Invocation> invocations){
    for (Iterator<Invocation> iterator=invocations.iterator(); iterator.hasNext(); ) {
      Invocation i=iterator.next();
      if (i.isVerified()) {
        iterator.remove();
      }
    }
  }
}
