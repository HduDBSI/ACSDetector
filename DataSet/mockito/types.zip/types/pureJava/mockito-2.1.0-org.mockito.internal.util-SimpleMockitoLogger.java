public class SimpleMockitoLogger implements MockitoLogger {
  private final StringBuilder loggedInfo=new StringBuilder();
  public void log(  Object what){
    loggedInfo.append(what);
  }
  public String getLoggedInfo(){
    return loggedInfo.toString();
  }
  public boolean isEmpty(){
    return loggedInfo.length() == 0;
  }
}
