static class DoesNotHaveTests {
  public void someTest(){
  }
}
