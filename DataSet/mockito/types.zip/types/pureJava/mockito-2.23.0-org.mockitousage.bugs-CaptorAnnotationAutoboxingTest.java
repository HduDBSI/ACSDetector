public class CaptorAnnotationAutoboxingTest extends TestBase {
interface Fun {
    void doFun(    double prmitive);
    void moreFun(    int howMuch);
  }
  @Mock Fun fun;
  @Captor ArgumentCaptor<Double> captor;
  @Test public void shouldAutoboxSafely(){
    fun.doFun(1.0);
    verify(fun).doFun(captor.capture());
    assertEquals(Double.valueOf(1.0),captor.getValue());
  }
  @Captor ArgumentCaptor<Integer> intCaptor;
  @Test public void shouldAutoboxAllPrimitives(){
    verify(fun,never()).moreFun(intCaptor.capture());
  }
}
