public class BasicVerificationTest extends TestBase {
  @Mock private List<String> mock;
  @Mock private List<String> mockTwo;
  @Test public void shouldVerify(){
    mock.clear();
    verify(mock).clear();
    mock.add("test");
    verify(mock).add("test");
    verifyNoMoreInteractions(mock);
  }
  @Test public void shouldFailVerification(){
    assertThatThrownBy(() -> {
      verify(mock).clear();
    }
).isInstanceOf(WantedButNotInvoked.class).hasMessageContainingAll("Wanted but not invoked:","mock.clear();","-> at ","Actually, there were zero interactions with this mock.");
  }
  @Test public void shouldFailVerificationOnMethodArgument(){
    mock.clear();
    mock.add("foo");
    verify(mock).clear();
    assertThatThrownBy(() -> {
      verify(mock).add("bar");
    }
).isInstanceOf(ArgumentsAreDifferent.class);
  }
  @Test public void shouldFailOnWrongMethod(){
    mock.clear();
    mock.clear();
    mockTwo.add("add");
    verify(mock,atLeastOnce()).clear();
    verify(mockTwo,atLeastOnce()).add("add");
    try {
      verify(mockTwo,atLeastOnce()).add("foo");
      fail();
    }
 catch (    WantedButNotInvoked e) {
    }
  }
  @Test public void shouldDetectRedundantInvocation(){
    mock.clear();
    mock.add("foo");
    mock.add("bar");
    verify(mock).clear();
    verify(mock).add("foo");
    try {
      verifyNoMoreInteractions(mock);
      fail();
    }
 catch (    NoInteractionsWanted e) {
    }
  }
  @Test public void shouldDetectWhenInvokedMoreThanOnce(){
    mock.add("foo");
    mock.clear();
    mock.clear();
    verify(mock).add("foo");
    try {
      verify(mock).clear();
      fail();
    }
 catch (    TooManyActualInvocations e) {
    }
  }
  @Test public void shouldVerifyStubbedMethods(){
    when(mock.add("test")).thenReturn(Boolean.FALSE);
    mock.add("test");
    verify(mock).add("test");
  }
  @Test public void shouldDetectWhenOverloadedMethodCalled(){
    IMethods mockThree=mock(IMethods.class);
    mockThree.varargs((Object[])new Object[]{});
    try {
      verify(mockThree).varargs((String[])new String[]{});
      fail();
    }
 catch (    WantedButNotInvoked e) {
    }
  }
}
