private interface DetectsInvalidState {
  void detect(  IMethods mock);
}
