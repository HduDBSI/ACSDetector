public class TypeBasedCandidateFilter implements MockCandidateFilter {
  private final MockCandidateFilter next;
  public TypeBasedCandidateFilter(  MockCandidateFilter next){
    this.next=next;
  }
  public OngoingInjector filterCandidate(  final Collection<Object> mocks,  final Field candidateFieldToBeInjected,  final List<Field> allRemainingCandidateFields,  final Object injectee){
    List<Object> mockTypeMatches=new ArrayList<Object>();
    for (    Object mock : mocks) {
      if (candidateFieldToBeInjected.getType().isAssignableFrom(mock.getClass())) {
        mockTypeMatches.add(mock);
      }
    }
    return next.filterCandidate(mockTypeMatches,candidateFieldToBeInjected,allRemainingCandidateFields,injectee);
  }
}
