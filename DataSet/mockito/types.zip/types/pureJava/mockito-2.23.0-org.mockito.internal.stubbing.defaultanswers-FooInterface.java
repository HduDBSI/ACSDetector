interface FooInterface {
}
