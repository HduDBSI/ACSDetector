class WithFinal {
  final int foo(){
    return 0;
  }
}
