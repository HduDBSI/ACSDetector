public interface Foo {
  void methodOne();
  void methodTwo();
}
