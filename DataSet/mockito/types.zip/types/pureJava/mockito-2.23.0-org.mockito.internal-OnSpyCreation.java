private static class OnSpyCreation implements DetectsInvalidState {
  @SuppressWarnings({"CheckReturnValue","MockitoUsage"}) public void detect(  IMethods mock){
    spy(new Object());
  }
}
