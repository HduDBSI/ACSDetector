static class FooImpl implements Foo {
  public String giveMeSomeString(  String param){
    return null;
  }
  public void doSomething(  String param){
  }
}
