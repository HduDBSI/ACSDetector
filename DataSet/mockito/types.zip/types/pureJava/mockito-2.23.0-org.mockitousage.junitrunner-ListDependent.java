class ListDependent {
  private List<?> list;
  public List<?> getList(){
    return list;
  }
}
