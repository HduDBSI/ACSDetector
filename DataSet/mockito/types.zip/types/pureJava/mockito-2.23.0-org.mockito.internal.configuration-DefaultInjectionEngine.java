/** 
 * Inject mock/spies dependencies for fields annotated with &#064;InjectMocks <p/> See  {@link org.mockito.MockitoAnnotations}
 */
public class DefaultInjectionEngine {
  public void injectMocksOnFields(  Set<Field> needingInjection,  Set<Object> mocks,  Object testClassInstance){
    MockInjection.onFields(needingInjection,testClassInstance).withMocks(mocks).tryConstructorInjection().tryPropertyOrFieldInjection().handleSpyAnnotation().apply();
  }
}
