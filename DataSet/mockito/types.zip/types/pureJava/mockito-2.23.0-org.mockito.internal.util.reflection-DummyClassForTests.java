public class DummyClassForTests extends DummyParentClassForTests {
}
