private interface ConstructorInstantiator {
  FieldInitializationReport instantiate();
}
