@SuppressWarnings("unchecked") public interface ArgumentMatcherStorage {
  void reportMatcher(  ArgumentMatcher<?> matcher);
  List<LocalizedMatcher> pullLocalizedMatchers();
  void reportAnd();
  void reportNot();
  void reportOr();
  void validateState();
  void reset();
}
