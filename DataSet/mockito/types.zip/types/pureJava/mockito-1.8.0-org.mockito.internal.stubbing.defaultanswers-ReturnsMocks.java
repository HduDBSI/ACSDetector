public class ReturnsMocks implements Answer<Object> {
  private MockitoCore mockitoCore=new MockitoCore();
  private Answer<Object> delegate=new ReturnsMoreEmptyValues();
  public Object answer(  InvocationOnMock invocation) throws Throwable {
    Object ret=delegate.answer(invocation);
    if (ret != null) {
      return ret;
    }
    return returnValueFor(invocation.getMethod().getReturnType());
  }
  @SuppressWarnings("unchecked") Object returnValueFor(  Class<?> clazz){
    if (!ClassImposterizer.INSTANCE.canImposterise(clazz)) {
      return null;
    }
    return mockitoCore.mock((Class)clazz,new MockSettingsImpl().defaultAnswer(this));
  }
}
