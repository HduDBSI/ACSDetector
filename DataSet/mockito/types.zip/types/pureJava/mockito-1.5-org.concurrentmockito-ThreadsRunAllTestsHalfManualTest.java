public class ThreadsRunAllTestsHalfManualTest extends TestBase {
private static class AllTestsRunner extends Thread {
    private boolean failed;
    public void run(){
      Result result=JUnitCore.runClasses(ConfiguringDefaultReturnValuesUsingBaseClassTest.class,ConfiguringDefaultReturnValuesUsingRunnerTest.class,ConfiguringSelectedMocksToReturnFakesTest.class,EqualsTest.class,ListUtilTest.class,MockingProgressImplTest.class,VerificationModeImplTest.class,MockHandlerTest.class,AllInvocationsFinderTest.class,DefaultReturnValuesTest.class,NumberOfInvocationsVerifierTest.class,VerifyingRecorderTest.class,MissingInvocationVerifierTest.class,NoMoreInvocationsVerifierTest.class,NumberOfInvocationsInOrderVerifierTest.class,MissingInvocationInOrderVerifierTest.class,MockFactoryTest.class,CglibTest.class,InvocationMatcherTest.class,InvocationsFinderTest.class,InvocationTest.class,MockitoTest.class,MockUtilTest.class,ReporterTest.class,MockitoAssertionErrorTest.class,StackTraceRemoverTest.class,MockitoExceptionTest.class,StackTraceFilteringTest.class,BridgeMethodPuzzleTest.class,OverloadingPuzzleTest.class,InvalidUsageTest.class,UsingVarargsTest.class,CustomMatchersTest.class,ComparableMatchersTest.class,InvalidUseOfMatchersTest.class,MatchersTest.class,MatchersToStringTest.class,VerificationAndStubbingUsingMatchersTest.class,BasicStubbingTest.class,ReturningDefaultValuesTest.class,StubbingWithThrowablesTest.class,AtLeastOnceVerificationTest.class,BasicVerificationTest.class,ExactNumberOfTimesVerificationTest.class,VerificationInOrderTest.class,NoMoreInteractionsVerificationTest.class,SelectedMocksInOrderVerificationTest.class,VerificationOnMultipleMocksUsingMatchersTest.class,VerificationUsingMatchersTest.class,RelaxedVerificationInOrderTest.class,DescriptiveMessagesWhenVerificationFailsTest.class,DescriptiveMessagesWhenTimesXVerificationFailsTest.class,BasicVerificationInOrderTest.class,VerificationInOrderMixedWithOrdiraryVerificationTest.class,DescriptiveMessagesOnVerificationInOrderErrorsTest.class,InvalidStateDetectionTest.class,ReplacingObjectMethodsTest.class,StackTrackeChangingTest.class,ExampleTest.class,PointingStackTraceToActualInvocationTest.class,PointingStackTraceToActualInvocationChunkTest.class);
      if (!result.wasSuccessful()) {
        System.err.println("Thread[" + Thread.currentThread().getId() + "]: error!");
        List<Failure> failures=result.getFailures();
        System.err.println(failures.size());
        for (        Failure failure : failures) {
          System.err.println(failure.getTrace());
          failed=true;
        }
      }
    }
    public boolean isFailed(){
      return failed;
    }
  }
  @Test public void shouldRunInMultipleThreads() throws Exception {
    assertFalse("Run in multiple thread failed",runInMultipleThreads(4));
  }
  public static boolean runInMultipleThreads(  int numberOfThreads) throws Exception {
    List<AllTestsRunner> threads=new LinkedList<AllTestsRunner>();
    for (int i=1; i <= numberOfThreads; i++) {
      threads.add(new AllTestsRunner());
    }
    for (    Thread t : threads) {
      t.start();
    }
    boolean failed=false;
    for (    AllTestsRunner t : threads) {
      t.join();
      failed=failed ? true : t.isFailed();
    }
    return failed;
  }
  public static void main(  String[] args) throws Exception {
    int numberOfThreads=20;
    long before=System.currentTimeMillis();
    runInMultipleThreads(numberOfThreads);
    long after=System.currentTimeMillis();
    long executionTime=(after - before) / 1000;
    System.out.println("Finished tests in " + numberOfThreads + " threads in "+ executionTime+ " seconds.");
  }
}
