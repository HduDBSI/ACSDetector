static class StaticClassWithoutDefaultConstructor {
  private StaticClassWithoutDefaultConstructor(  String param){
  }
}
