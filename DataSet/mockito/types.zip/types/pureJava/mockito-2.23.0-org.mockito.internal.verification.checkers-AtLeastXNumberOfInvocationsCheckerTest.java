public class AtLeastXNumberOfInvocationsCheckerTest {
  @Rule public ExpectedException exception=ExpectedException.none();
  @Test public void shouldMarkActualInvocationsAsVerifiedInOrder(){
    InOrderContext context=new InOrderContextImpl();
    Invocation invocation=new InvocationBuilder().simpleMethod().toInvocation();
    Invocation invocationTwo=new InvocationBuilder().differentMethod().toInvocation();
    checkAtLeastNumberOfInvocations(asList(invocation,invocationTwo),new InvocationMatcher(invocation),1,context);
    assertThat(invocation.isVerified()).isTrue();
  }
  @Test public void shouldReportTooLittleInvocationsInOrder(){
    InOrderContext context=new InOrderContextImpl();
    Invocation invocation=new InvocationBuilder().simpleMethod().toInvocation();
    Invocation invocationTwo=new InvocationBuilder().differentMethod().toInvocation();
    exception.expect(VerificationInOrderFailure.class);
    exception.expectMessage("iMethods.simpleMethod()");
    exception.expectMessage("Wanted *at least* 2 times");
    exception.expectMessage("But was 1 time");
    checkAtLeastNumberOfInvocations(asList(invocation,invocationTwo),new InvocationMatcher(invocation),2,context);
  }
  @Test public void shouldMarkActualInvocationsAsVerified(){
    Invocation invocation=new InvocationBuilder().simpleMethod().toInvocation();
    Invocation invocationTwo=new InvocationBuilder().differentMethod().toInvocation();
    checkAtLeastNumberOfInvocations(asList(invocation,invocationTwo),new InvocationMatcher(invocation),1);
    assertThat(invocation.isVerified()).isTrue();
  }
  @Test public void shouldReportTooLittleInvocations(){
    Invocation invocation=new InvocationBuilder().simpleMethod().toInvocation();
    Invocation invocationTwo=new InvocationBuilder().differentMethod().toInvocation();
    exception.expect(TooLittleActualInvocations.class);
    exception.expectMessage("iMethods.simpleMethod()");
    exception.expectMessage("Wanted *at least* 2 times");
    exception.expectMessage("But was 1 time");
    checkAtLeastNumberOfInvocations(asList(invocation,invocationTwo),new InvocationMatcher(invocation),2);
  }
}
