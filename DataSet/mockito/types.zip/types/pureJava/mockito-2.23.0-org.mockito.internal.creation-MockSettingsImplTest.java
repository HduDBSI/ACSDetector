public class MockSettingsImplTest extends TestBase {
  private MockSettingsImpl<?> mockSettingsImpl=new MockSettingsImpl<Object>();
  @Mock private InvocationListener invocationListener;
  @Test(expected=MockitoException.class) @SuppressWarnings("unchecked") public void shouldNotAllowSettingNullInterface(){
    mockSettingsImpl.extraInterfaces(List.class,null);
  }
  @Test(expected=MockitoException.class) @SuppressWarnings("unchecked") public void shouldNotAllowNonInterfaces(){
    mockSettingsImpl.extraInterfaces(List.class,LinkedList.class);
  }
  @Test(expected=MockitoException.class) @SuppressWarnings("unchecked") public void shouldNotAllowUsingTheSameInterfaceAsExtra(){
    mockSettingsImpl.extraInterfaces(List.class,LinkedList.class);
  }
  @Test(expected=MockitoException.class) @SuppressWarnings("unchecked") public void shouldNotAllowEmptyExtraInterfaces(){
    mockSettingsImpl.extraInterfaces();
  }
  @Test(expected=MockitoException.class) @SuppressWarnings("unchecked") public void shouldNotAllowNullArrayOfExtraInterfaces(){
    mockSettingsImpl.extraInterfaces((Class<?>[])null);
  }
  @Test @SuppressWarnings("unchecked") public void shouldAllowMultipleInterfaces(){
    mockSettingsImpl.extraInterfaces(List.class,Set.class);
    assertEquals(2,mockSettingsImpl.getExtraInterfaces().size());
    assertTrue(mockSettingsImpl.getExtraInterfaces().contains(List.class));
    assertTrue(mockSettingsImpl.getExtraInterfaces().contains(Set.class));
  }
  @Test public void shouldSetMockToBeSerializable() throws Exception {
    mockSettingsImpl.serializable();
    assertTrue(mockSettingsImpl.isSerializable());
  }
  @Test public void shouldKnowIfIsSerializable() throws Exception {
    assertFalse(mockSettingsImpl.isSerializable());
    mockSettingsImpl.serializable();
    assertTrue(mockSettingsImpl.isSerializable());
  }
  @Test public void shouldAddVerboseLoggingListener(){
    assertFalse(mockSettingsImpl.hasInvocationListeners());
    mockSettingsImpl.verboseLogging();
    assertThat(mockSettingsImpl.getInvocationListeners()).extracting("class").contains(VerboseMockInvocationLogger.class);
  }
  @Test public void shouldAddVerboseLoggingListenerOnlyOnce(){
    assertFalse(mockSettingsImpl.hasInvocationListeners());
    mockSettingsImpl.verboseLogging().verboseLogging();
    Assertions.assertThat(mockSettingsImpl.getInvocationListeners()).hasSize(1);
  }
  @SuppressWarnings("unchecked") @Test(expected=MockitoException.class) public void shouldNotAllowNullListener(){
    mockSettingsImpl.invocationListeners((InvocationListener[])null);
  }
  @Test @SuppressWarnings("unchecked") public void shouldAddInvocationListener(){
    assertFalse(mockSettingsImpl.hasInvocationListeners());
    mockSettingsImpl.invocationListeners(invocationListener);
    Assertions.assertThat(mockSettingsImpl.getInvocationListeners()).contains(invocationListener);
  }
  @Test @SuppressWarnings("unchecked") public void canAddDuplicateInvocationListeners_ItsNotOurBusinessThere(){
    assertFalse(mockSettingsImpl.hasInvocationListeners());
    mockSettingsImpl.invocationListeners(invocationListener,invocationListener).invocationListeners(invocationListener);
    Assertions.assertThat(mockSettingsImpl.getInvocationListeners()).containsSequence(invocationListener,invocationListener,invocationListener);
  }
  @Test public void shouldReportErrorWhenAddingNoInvocationListeners() throws Exception {
    try {
      mockSettingsImpl.invocationListeners();
      fail();
    }
 catch (    Exception e) {
      Assertions.assertThat(e.getMessage()).contains("at least one listener");
    }
  }
  @Test public void shouldReportErrorWhenAddingANullInvocationListener() throws Exception {
    try {
      mockSettingsImpl.invocationListeners(invocationListener,null);
      fail();
    }
 catch (    Exception e) {
      Assertions.assertThat(e.getMessage()).contains("does not accept null");
    }
  }
}
