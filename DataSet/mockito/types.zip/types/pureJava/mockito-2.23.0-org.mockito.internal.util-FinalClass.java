final class FinalClass {
}
