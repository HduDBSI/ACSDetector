public class CustomMatcherDoesYieldCCETest extends TestBase {
  @Mock private IMethods mock;
  @Test public void shouldNotThrowCCE(){
    mock.simpleMethod(new Object());
    try {
      verify(mock).simpleMethod(argThat(isStringWithTextFoo()));
      fail();
    }
 catch (    ArgumentsAreDifferent e) {
    }
  }
  private ArgumentMatcher<String> isStringWithTextFoo(){
    return new ArgumentMatcher<String>(){
      public boolean matches(      String argument){
        String str=(String)argument;
        return str.equals("foo");
      }
    }
;
  }
}
