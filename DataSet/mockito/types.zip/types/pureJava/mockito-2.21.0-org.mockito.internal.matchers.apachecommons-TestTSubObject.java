@SuppressWarnings("unused") static class TestTSubObject extends TestObject {
  private transient int t;
  public TestTSubObject(  int a,  int t){
    super(a);
    this.t=t;
  }
}
