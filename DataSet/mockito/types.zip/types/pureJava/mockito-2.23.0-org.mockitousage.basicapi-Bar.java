class Bar implements Serializable {
  Foo foo;
  public Foo doSomething(){
    return foo;
  }
}
