public class MockitoConfiguration extends DefaultMockitoConfiguration implements IMockitoConfiguration {
  private Answer<Object> overriddenDefaultAnswer=null;
  private boolean cleansStackTrace;
  private AnnotationEngine overriddenEngine;
  private boolean enableClassCache=true;
  public void overrideDefaultAnswer(  Answer<Object> defaultAnswer){
    this.overriddenDefaultAnswer=defaultAnswer;
  }
  public void overrideCleansStackTrace(  boolean cleansStackTrace){
    this.cleansStackTrace=cleansStackTrace;
  }
  public void overrideAnnotationEngine(  AnnotationEngine engine){
    this.overriddenEngine=engine;
  }
  public void overrideEnableClassCache(  boolean enableClassCache){
    this.enableClassCache=enableClassCache;
  }
  @Override public Answer<Object> getDefaultAnswer(){
    if (overriddenDefaultAnswer == null) {
      return super.getDefaultAnswer();
    }
 else {
      return overriddenDefaultAnswer;
    }
  }
  @Override public AnnotationEngine getAnnotationEngine(){
    if (this.overriddenEngine != null) {
      return this.overriddenEngine;
    }
    return new CustomizedAnnotationForSmartMockTest.CustomInjectingAnnotationEngine();
  }
  @Override public boolean cleansStackTrace(){
    return cleansStackTrace;
  }
  @Override public boolean enableClassCache(){
    return enableClassCache;
  }
}
