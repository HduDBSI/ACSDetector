private static class CallingSuperMethodClass extends SampleClass {
  @Override public String foo(){
    return super.foo();
  }
}
