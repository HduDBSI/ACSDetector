class Parent {
  private int parentField;
  protected String protectedParentField;
  public Parent(  int parentField,  String protectedParentField){
    this.parentField=parentField;
    this.protectedParentField=protectedParentField;
  }
}
