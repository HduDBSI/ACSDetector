private static class BDDStubberImpl implements BDDStubber {
  private final Stubber mockitoStubber;
  public BDDStubberImpl(  Stubber mockitoStubber){
    this.mockitoStubber=mockitoStubber;
  }
  public <T>T given(  T mock){
    return mockitoStubber.when(mock);
  }
  public BDDStubber willAnswer(  Answer<?> answer){
    return new BDDStubberImpl(mockitoStubber.doAnswer(answer));
  }
  public BDDStubber will(  Answer<?> answer){
    return new BDDStubberImpl(mockitoStubber.doAnswer(answer));
  }
  /** 
 * @deprecated please use {@link #willDoNothing()} instead
 */
  @Deprecated public BDDStubber willNothing(){
    return willDoNothing();
  }
  public BDDStubber willDoNothing(){
    return new BDDStubberImpl(mockitoStubber.doNothing());
  }
  public BDDStubber willReturn(  Object toBeReturned){
    return new BDDStubberImpl(mockitoStubber.doReturn(toBeReturned));
  }
  public BDDStubber willReturn(  Object toBeReturned,  Object... nextToBeReturned){
    return new BDDStubberImpl(mockitoStubber.doReturn(toBeReturned).doReturn(nextToBeReturned));
  }
  public BDDStubber willThrow(  Throwable... toBeThrown){
    return new BDDStubberImpl(mockitoStubber.doThrow(toBeThrown));
  }
  public BDDStubber willThrow(  Class<? extends Throwable> toBeThrown){
    return new BDDStubberImpl(mockitoStubber.doThrow(toBeThrown));
  }
  public BDDStubber willThrow(  Class<? extends Throwable> toBeThrown,  Class<? extends Throwable>... nextToBeThrown){
    return new BDDStubberImpl(mockitoStubber.doThrow(toBeThrown,nextToBeThrown));
  }
  public BDDStubber willCallRealMethod(){
    return new BDDStubberImpl(mockitoStubber.doCallRealMethod());
  }
}
