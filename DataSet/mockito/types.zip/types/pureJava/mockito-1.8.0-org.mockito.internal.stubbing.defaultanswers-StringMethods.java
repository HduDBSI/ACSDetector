interface StringMethods {
  String stringMethod();
  String[] stringArrayMethod();
}
