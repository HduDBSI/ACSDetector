public class ThrowsException implements Answer<Object>, ValidableAnswer, Serializable {
  private static final long serialVersionUID=1128820328555183980L;
  private final Throwable throwable;
  private final ConditionalStackTraceFilter filter=new ConditionalStackTraceFilter();
  public ThrowsException(  Throwable throwable){
    this.throwable=throwable;
  }
  public Object answer(  InvocationOnMock invocation) throws Throwable {
    if (MockUtil.isMock(throwable)) {
      throw throwable;
    }
    Throwable t=throwable.fillInStackTrace();
    filter.filter(t);
    throw t;
  }
  @Override public void validateFor(  InvocationOnMock invocation){
    if (throwable == null) {
      throw cannotStubWithNullThrowable();
    }
    if (throwable instanceof RuntimeException || throwable instanceof Error) {
      return;
    }
    if (!new InvocationInfo(invocation).isValidException(throwable)) {
      throw checkedExceptionInvalid(throwable);
    }
  }
}
