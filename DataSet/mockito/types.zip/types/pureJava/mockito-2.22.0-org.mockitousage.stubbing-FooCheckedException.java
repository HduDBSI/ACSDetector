class FooCheckedException extends Exception {
}
