protected interface MyIterable<T> extends Iterable<T> {
  MyIterator<T> iterator();
}
