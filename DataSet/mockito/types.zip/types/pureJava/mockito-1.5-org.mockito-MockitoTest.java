@SuppressWarnings("unchecked") public class MockitoTest extends TestBase {
  @Test public void shouldRemoveStubbableFromProgressAfterStubbing(){
    List mock=Mockito.mock(List.class);
    Mockito.stub(mock.add("test")).toReturn(true);
    assertNull(Mockito.MOCKING_PROGRESS.pullOngoingStubbing());
  }
  @Test(expected=NotAMockException.class) public void shouldValidateMockWhenVerifying(){
    Mockito.verify("notMock");
  }
  @Test(expected=NotAMockException.class) public void shouldValidateMockWhenVerifyingWithExpectedNumberOfInvocations(){
    Mockito.verify("notMock",times(19));
  }
  @Test(expected=NotAMockException.class) public void shouldValidateMockWhenVerifyingNoMoreInteractions(){
    Mockito.verifyNoMoreInteractions("notMock");
  }
  @Test(expected=NotAMockException.class) public void shouldValidateMockWhenVerifyingZeroInteractions(){
    Mockito.verifyZeroInteractions("notMock");
  }
  @SuppressWarnings("deprecation") @Test(expected=NotAMockException.class) public void shouldValidateMockWhenStubbingVoid(){
    Mockito.stubVoid("notMock");
  }
  @Test(expected=NotAMockException.class) public void shouldValidateMockWhenCreatingInOrderObject(){
    Mockito.inOrder("notMock");
  }
}
