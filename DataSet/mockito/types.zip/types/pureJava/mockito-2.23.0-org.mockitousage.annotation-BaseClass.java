class BaseClass {
  @Spy List list=new LinkedList();
}
