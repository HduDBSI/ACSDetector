private static class VarargConstructor {
  VarargConstructor(  String whatever,  Observer... observers){
  }
}
