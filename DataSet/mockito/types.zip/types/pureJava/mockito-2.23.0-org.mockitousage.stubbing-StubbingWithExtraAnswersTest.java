public class StubbingWithExtraAnswersTest extends TestBase {
  @Mock private IMethods mock;
  @Test public void shouldWorkAsStandardMockito() throws Exception {
    List<Integer> list=asList(1,2,3);
    when(mock.objectReturningMethodNoArgs()).thenAnswer(AdditionalAnswers.returnsElementsOf(list));
    assertEquals(1,mock.objectReturningMethodNoArgs());
    assertEquals(2,mock.objectReturningMethodNoArgs());
    assertEquals(3,mock.objectReturningMethodNoArgs());
    assertEquals(3,mock.objectReturningMethodNoArgs());
    assertEquals(3,mock.objectReturningMethodNoArgs());
  }
  @Test public void shouldReturnNullIfNecessary() throws Exception {
    List<Integer> list=asList(1,null);
    when(mock.objectReturningMethodNoArgs()).thenAnswer(AdditionalAnswers.returnsElementsOf(list));
    assertEquals(1,mock.objectReturningMethodNoArgs());
    assertEquals(null,mock.objectReturningMethodNoArgs());
    assertEquals(null,mock.objectReturningMethodNoArgs());
  }
  @Test public void shouldScreamWhenNullPassed() throws Exception {
    try {
      AdditionalAnswers.returnsElementsOf(null);
      fail();
    }
 catch (    MockitoException e) {
    }
  }
}
