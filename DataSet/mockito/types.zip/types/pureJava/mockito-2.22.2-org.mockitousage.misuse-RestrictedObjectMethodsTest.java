public class RestrictedObjectMethodsTest extends TestBase {
  @Mock List<?> mock;
  @After public void after(){
    this.resetState();
  }
  @Test public void shouldScreamWhenVerifyToString(){
    try {
      verify(mock).toString();
      fail();
    }
 catch (    MockitoException e) {
      assertThat(e).hasMessageContaining("cannot verify");
    }
  }
  @Test public void shouldBeSilentWhenVerifyHashCode(){
    verify(mock).hashCode();
  }
  @Test public void shouldBeSilentWhenVerifyEquals(){
    verify(mock).equals(null);
  }
  @Test public void shouldBeSilentWhenVerifyEqualsInOrder(){
    InOrder inOrder=inOrder(mock);
    inOrder.verify(mock).equals(null);
  }
}
