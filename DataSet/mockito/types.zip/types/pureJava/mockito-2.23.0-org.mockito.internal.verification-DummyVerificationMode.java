public class DummyVerificationMode implements VerificationMode {
  public void verify(  VerificationData data){
  }
  public VerificationMode description(  String description){
    return new DummyVerificationMode();
  }
}
