public class RegisteredInvocations {
  private final List<Invocation> invocations=Collections.synchronizedList(new LinkedList<Invocation>());
  public void add(  Invocation invocation){
    invocations.add(invocation);
  }
  public void removeLast(){
    invocations.remove(invocations.size() - 1);
  }
  public List<Invocation> getAll(){
    return ListUtil.filter(new LinkedList<Invocation>(invocations),new RemoveToString());
  }
private static class RemoveToString implements Filter<Invocation> {
    public boolean isOut(    Invocation invocation){
      return Invocation.isToString(invocation);
    }
  }
}
