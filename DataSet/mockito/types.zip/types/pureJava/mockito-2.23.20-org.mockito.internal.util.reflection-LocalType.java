class LocalType {
}
