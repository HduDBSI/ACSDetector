public class NoMoreInteractionsTest extends TestBase {
  InOrderContextImpl context=new InOrderContextImpl();
  @Test public void shouldVerifyInOrder(){
    NoMoreInteractions n=new NoMoreInteractions();
    Invocation i=new InvocationBuilder().toInvocation();
    assertFalse(context.isVerified(i));
    try {
      n.verifyInOrder(new VerificationDataInOrderImpl(context,asList(i),null));
      fail();
    }
 catch (    VerificationInOrderFailure e) {
    }
  }
  @Test public void shouldVerifyInOrderAndPass(){
    NoMoreInteractions n=new NoMoreInteractions();
    Invocation i=new InvocationBuilder().toInvocation();
    context.markVerified(i);
    assertTrue(context.isVerified(i));
    n.verifyInOrder(new VerificationDataInOrderImpl(context,asList(i),null));
  }
  @Test public void shouldVerifyInOrderMultipleInvoctions(){
    NoMoreInteractions n=new NoMoreInteractions();
    Invocation i=new InvocationBuilder().seq(1).toInvocation();
    Invocation i2=new InvocationBuilder().seq(2).toInvocation();
    context.markVerified(i2);
    n.verifyInOrder(new VerificationDataInOrderImpl(context,asList(i,i2),null));
  }
  @Test public void shouldVerifyInOrderMultipleInvoctionsAndThrow(){
    NoMoreInteractions n=new NoMoreInteractions();
    Invocation i=new InvocationBuilder().seq(1).toInvocation();
    Invocation i2=new InvocationBuilder().seq(2).toInvocation();
    try {
      n.verifyInOrder(new VerificationDataInOrderImpl(context,asList(i,i2),null));
      fail();
    }
 catch (    VerificationInOrderFailure e) {
    }
  }
  @Test public void noMoreInteractionsExceptionMessageShouldDescribeMock(){
    NoMoreInteractions n=new NoMoreInteractions();
    IMethods mock=mock(IMethods.class,"a mock");
    InvocationMatcher i=new InvocationBuilder().mock(mock).toInvocationMatcher();
    InvocationContainerImpl invocations=new InvocationContainerImpl(new MockSettingsImpl());
    invocations.setInvocationForPotentialStubbing(i);
    try {
      n.verify(new VerificationDataImpl(invocations,null));
      fail();
    }
 catch (    NoInteractionsWanted e) {
      Assertions.assertThat(e.toString()).contains(mock.toString());
    }
  }
  @Test public void noMoreInteractionsInOrderExceptionMessageShouldDescribeMock(){
    NoMoreInteractions n=new NoMoreInteractions();
    IMethods mock=mock(IMethods.class,"a mock");
    Invocation i=new InvocationBuilder().mock(mock).toInvocation();
    try {
      n.verifyInOrder(new VerificationDataInOrderImpl(context,asList(i),null));
      fail();
    }
 catch (    VerificationInOrderFailure e) {
      Assertions.assertThat(e.toString()).contains(mock.toString());
    }
  }
}
