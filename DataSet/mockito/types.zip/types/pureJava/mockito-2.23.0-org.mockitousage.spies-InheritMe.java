class InheritMe {
  private String inherited="100$";
  protected String getInherited(){
    return inherited;
  }
}
