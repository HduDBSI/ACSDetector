static class StaticClassThrowingExceptionDefaultConstructor {
  StaticClassThrowingExceptionDefaultConstructor(){
    throw new NullPointerException("business logic failed");
  }
}
