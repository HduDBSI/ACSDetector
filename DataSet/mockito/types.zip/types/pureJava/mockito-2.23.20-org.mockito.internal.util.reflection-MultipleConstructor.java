private static class MultipleConstructor extends OneConstructor {
  Observer observer;
  Map map;
  public MultipleConstructor(  Observer observer){
    this(observer,null);
  }
  public MultipleConstructor(  Observer observer,  Map map){
    super(observer);
    this.observer=observer;
    this.map=map;
  }
}
