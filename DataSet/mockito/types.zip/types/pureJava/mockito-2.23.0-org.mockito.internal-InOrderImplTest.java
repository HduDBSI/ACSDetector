@SuppressWarnings("unchecked") public class InOrderImplTest extends TestBase {
  @Mock IMethods mock;
  @Test public void shouldMarkVerifiedInOrder() throws Exception {
    InOrderImpl impl=new InOrderImpl(singletonList(mock));
    Invocation i=new InvocationBuilder().toInvocation();
    assertFalse(impl.isVerified(i));
    impl.markVerified(i);
    assertTrue(impl.isVerified(i));
  }
}
