@Ignore("don't run this code in the test runner") private static class ATest {
  @Mock Set<?> set;
  @InjectMocks FailingConstructor failingConstructor;
}
