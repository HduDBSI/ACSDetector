static class TestedObject {
  String value;
  void setValue(  String value){
    this.value=value;
  }
  String getValue(){
    return "HARD_CODED_RETURN_VALUE";
  }
  String callInternalMethod(){
    return getValue();
  }
}
