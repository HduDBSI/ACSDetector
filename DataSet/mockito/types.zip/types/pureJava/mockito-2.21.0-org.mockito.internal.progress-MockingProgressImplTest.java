public class MockingProgressImplTest extends TestBase {
  private MockingProgress mockingProgress;
  @Before public void setup(){
    mockingProgress=new MockingProgressImpl();
  }
  @Test public void shouldStartVerificationAndPullVerificationMode() throws Exception {
    assertNull(mockingProgress.pullVerificationMode());
    VerificationMode mode=VerificationModeFactory.times(19);
    mockingProgress.verificationStarted(mode);
    assertSame(mode,mockingProgress.pullVerificationMode());
    assertNull(mockingProgress.pullVerificationMode());
  }
  @Test public void shouldCheckIfVerificationWasFinished() throws Exception {
    mockingProgress.verificationStarted(VerificationModeFactory.atLeastOnce());
    try {
      mockingProgress.verificationStarted(VerificationModeFactory.atLeastOnce());
      fail();
    }
 catch (    MockitoException e) {
    }
  }
  @Test public void shouldNotifyListenerSafely() throws Exception {
    mockingProgress.addListener(null);
    mockingProgress.mockingStarted(null,null);
  }
}
