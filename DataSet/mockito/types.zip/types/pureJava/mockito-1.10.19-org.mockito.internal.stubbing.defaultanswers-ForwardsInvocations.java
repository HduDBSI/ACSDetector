/** 
 * Internal answer to forward invocations on a real instance.
 * @since 1.9.5
 */
public class ForwardsInvocations implements Answer<Object>, Serializable {
  private static final long serialVersionUID=-8343690268123254910L;
  private Object delegatedObject=null;
  public ForwardsInvocations(  Object delegatedObject){
    this.delegatedObject=delegatedObject;
  }
  public Object answer(  InvocationOnMock invocation) throws Throwable {
    Method mockMethod=invocation.getMethod();
    Object result=null;
    try {
      Method delegateMethod=getDelegateMethod(mockMethod);
      if (!compatibleReturnTypes(mockMethod.getReturnType(),delegateMethod.getReturnType())) {
        new Reporter().delegatedMethodHasWrongReturnType(mockMethod,delegateMethod,invocation.getMock(),delegatedObject);
      }
      result=delegateMethod.invoke(delegatedObject,invocation.getArguments());
    }
 catch (    NoSuchMethodException e) {
      new Reporter().delegatedMethodDoesNotExistOnDelegate(mockMethod,invocation.getMock(),delegatedObject);
    }
catch (    InvocationTargetException e) {
      throw e.getCause();
    }
    return result;
  }
  private Method getDelegateMethod(  Method mockMethod) throws NoSuchMethodException {
    if (mockMethod.getDeclaringClass().isAssignableFrom(delegatedObject.getClass())) {
      return mockMethod;
    }
 else {
      return delegatedObject.getClass().getMethod(mockMethod.getName(),mockMethod.getParameterTypes());
    }
  }
  private static boolean compatibleReturnTypes(  Class<?> superType,  Class<?> subType){
    return superType.equals(subType) || superType.isAssignableFrom(subType);
  }
}
