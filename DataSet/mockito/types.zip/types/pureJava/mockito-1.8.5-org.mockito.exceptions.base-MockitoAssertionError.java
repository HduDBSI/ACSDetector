public class MockitoAssertionError extends AssertionError {
  private static final long serialVersionUID=1L;
  private StackTraceElement[] unfilteredStackTrace;
  public MockitoAssertionError(  String message){
    super(message);
    unfilteredStackTrace=getStackTrace();
    ConditionalStackTraceFilter filter=new ConditionalStackTraceFilter();
    filter.filter(this);
  }
  public StackTraceElement[] getUnfilteredStackTrace(){
    return unfilteredStackTrace;
  }
}
