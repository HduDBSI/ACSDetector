public interface VerificationDataInOrder {
  List<Invocation> getAllInvocations();
  InvocationMatcher getWanted();
  InOrderContext getOrderingContext();
}
