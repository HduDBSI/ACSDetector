public class ConfigurationAccess {
  public static MockitoConfiguration getConfig(){
    return (MockitoConfiguration)new GlobalConfiguration().getIt();
  }
}
