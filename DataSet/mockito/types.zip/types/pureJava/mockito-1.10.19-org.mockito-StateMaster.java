public class StateMaster {
  private final ThreadSafeMockingProgress mockingProgress=new ThreadSafeMockingProgress();
  public void reset(){
    mockingProgress.reset();
    mockingProgress.resetOngoingStubbing();
  }
  public void validate(){
    mockingProgress.validateState();
  }
}
