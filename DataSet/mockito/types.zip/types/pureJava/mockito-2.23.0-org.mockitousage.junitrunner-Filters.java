public class Filters {
  public static Filter methodNameContains(  final String substring){
    return new Filter(){
      @Override public boolean shouldRun(      Description description){
        return description.getDisplayName().contains(substring);
      }
      @Override public String describe(){
        return null;
      }
    }
;
  }
}
