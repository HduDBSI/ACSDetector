public class OnlyTest {
  Only only=new Only();
public class VerificationDataStub implements VerificationData {
    private final Invocation invocation;
    private final InvocationMatcher wanted;
    public VerificationDataStub(    InvocationMatcher wanted,    Invocation invocation){
      this.invocation=invocation;
      this.wanted=wanted;
    }
    public List<Invocation> getAllInvocations(){
      return Arrays.asList(invocation);
    }
    @Override public MatchableInvocation getTarget(){
      return wanted;
    }
    public InvocationMatcher getWanted(){
      return wanted;
    }
  }
  @Test public void shouldMarkAsVerified(){
    Invocation invocation=new InvocationBuilder().toInvocation();
    assertFalse(invocation.isVerified());
    only.verify(new VerificationDataStub(new InvocationMatcher(invocation),invocation));
    assertTrue(invocation.isVerified());
  }
  @Test public void shouldNotMarkAsVerifiedWhenAssertionFailed(){
    Invocation invocation=new InvocationBuilder().toInvocation();
    assertFalse(invocation.isVerified());
    try {
      only.verify(new VerificationDataStub(new InvocationBuilder().toInvocationMatcher(),invocation));
      fail();
    }
 catch (    MockitoAssertionError e) {
    }
    assertFalse(invocation.isVerified());
  }
}
