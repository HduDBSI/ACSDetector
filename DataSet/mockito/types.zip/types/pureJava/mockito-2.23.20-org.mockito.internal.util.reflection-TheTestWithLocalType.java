class TheTestWithLocalType {
  @InjectMocks LocalType field=new LocalType();
}
