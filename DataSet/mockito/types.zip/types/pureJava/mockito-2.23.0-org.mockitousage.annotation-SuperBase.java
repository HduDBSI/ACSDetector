class SuperBase {
  @Captor private ArgumentCaptor<IMethods> mock;
  public ArgumentCaptor<IMethods> getSuperBaseCaptor(){
    return mock;
  }
}
