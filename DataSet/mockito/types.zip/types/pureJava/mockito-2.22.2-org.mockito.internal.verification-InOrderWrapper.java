public class InOrderWrapper implements VerificationMode {
  private final VerificationInOrderMode mode;
  private final InOrderImpl inOrder;
  public InOrderWrapper(  VerificationInOrderMode mode,  InOrderImpl inOrder){
    this.mode=mode;
    this.inOrder=inOrder;
  }
  public void verify(  VerificationData data){
    List<Invocation> invocations=VerifiableInvocationsFinder.find(inOrder.getMocksToBeVerifiedInOrder());
    VerificationDataInOrderImpl dataInOrder=new VerificationDataInOrderImpl(inOrder,invocations,data.getTarget());
    mode.verifyInOrder(dataInOrder);
  }
  @Override public VerificationMode description(  String description){
    return VerificationModeFactory.description(this,description);
  }
}
