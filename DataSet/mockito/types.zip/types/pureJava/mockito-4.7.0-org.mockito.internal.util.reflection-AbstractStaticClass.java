abstract static class AbstractStaticClass {
  public AbstractStaticClass(){
  }
}
