interface Foo {
  void bar(  long id);
}
