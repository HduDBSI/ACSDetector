@SuppressWarnings("unchecked") public class SpyAnnotationInitializedInBaseClassTest extends TestBase {
class BaseClass {
    @Spy List list=new LinkedList();
  }
class SubClass extends BaseClass {
  }
  @Test public void shouldInitSpiesInBaseClass() throws Exception {
    SubClass subClass=new SubClass();
    MockitoAnnotations.initMocks(subClass);
    assertTrue(MockUtil.isMock(subClass.list));
  }
  @Before @Override public void init(){
  }
  @Before public void before(){
    MockitoAnnotations.initMocks(this);
  }
  @Spy List spyInBaseclass=new LinkedList();
public static class SubTest extends SpyAnnotationInitializedInBaseClassTest {
    @Spy List spyInSubclass=new LinkedList();
    @Test public void shouldInitSpiesInHierarchy() throws Exception {
      assertTrue(isMock(spyInSubclass));
      assertTrue(isMock(spyInBaseclass));
    }
  }
}
