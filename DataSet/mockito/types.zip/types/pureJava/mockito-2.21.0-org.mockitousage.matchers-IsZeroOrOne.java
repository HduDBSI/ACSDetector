private final class IsZeroOrOne<T extends Number> implements ArgumentMatcher<T> {
  public boolean matches(  T number){
    return number.intValue() == 0 || number.intValue() == 1;
  }
}
