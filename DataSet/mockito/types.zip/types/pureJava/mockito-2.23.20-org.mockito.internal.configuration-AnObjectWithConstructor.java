public static class AnObjectWithConstructor {
  public boolean initializedWithConstructor=false;
  public AnObjectWithConstructor(  Set<String> strings){
    initializedWithConstructor=true;
  }
}
