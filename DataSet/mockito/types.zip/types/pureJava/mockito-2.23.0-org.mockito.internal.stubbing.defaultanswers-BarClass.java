class BarClass {
}
