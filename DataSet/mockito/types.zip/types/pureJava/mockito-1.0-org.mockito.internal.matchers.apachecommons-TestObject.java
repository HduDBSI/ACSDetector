static class TestObject {
  private int a;
  public TestObject(){
  }
  public TestObject(  int a){
    this.a=a;
  }
  public boolean equals(  Object o){
    if (o == null) {
      return false;
    }
    if (o == this) {
      return true;
    }
    if (o.getClass() != getClass()) {
      return false;
    }
    TestObject rhs=(TestObject)o;
    return (a == rhs.a);
  }
  public int hashCode(){
    return super.hashCode();
  }
  public void setA(  int a){
    this.a=a;
  }
  public int getA(){
    return a;
  }
}
