static class BaseUnderTesting extends SuperUnderTesting {
  private Map<?,?> aMap;
  public Map<?,?> getAMap(){
    return aMap;
  }
}
