@SuppressWarnings("serial") class MyException extends RuntimeException {
}
