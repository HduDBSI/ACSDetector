private static class OnVerifyInOrder implements DetectsInvalidState {
  @SuppressWarnings({"CheckReturnValue","MockitoUsage"}) public void detect(  IMethods mock){
    inOrder(mock).verify(mock);
  }
}
