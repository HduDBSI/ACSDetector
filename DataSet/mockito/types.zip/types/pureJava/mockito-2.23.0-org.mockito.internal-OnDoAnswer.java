private static class OnDoAnswer implements DetectsInvalidState {
  @SuppressWarnings({"CheckReturnValue","MockitoUsage"}) public void detect(  IMethods mock){
    doAnswer(null);
  }
}
