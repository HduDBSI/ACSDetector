private static class OnVerify implements DetectsInvalidState {
  @SuppressWarnings({"CheckReturnValue","MockitoUsage"}) public void detect(  IMethods mock){
    verify(mock);
  }
}
