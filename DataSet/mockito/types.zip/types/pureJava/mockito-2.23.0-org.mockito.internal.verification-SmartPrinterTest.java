public class SmartPrinterTest extends TestBase {
  private InvocationMatcher multi;
  private InvocationMatcher shortie;
  @Mock private IMethods mock;
  @Before public void setup() throws Exception {
    mock.varargs("first very long argument","second very long argument","another very long argument");
    multi=new InvocationMatcher(getLastInvocation());
    mock.varargs("short arg");
    shortie=new InvocationMatcher(getLastInvocation());
  }
  @Test public void shouldPrintBothInMultilinesWhenFirstIsMulti(){
    SmartPrinter printer=new SmartPrinter(multi,shortie.getInvocation());
    assertThat(printer.getWanted()).contains("\n");
    assertThat(printer.getActual()).contains("\n");
  }
  @Test public void shouldPrintBothInMultilinesWhenSecondIsMulti(){
    SmartPrinter printer=new SmartPrinter(shortie,multi.getInvocation());
    assertThat(printer.getWanted()).contains("\n");
    assertThat(printer.getActual()).contains("\n");
  }
  @Test public void shouldPrintBothInMultilinesWhenBothAreMulti(){
    SmartPrinter printer=new SmartPrinter(multi,multi.getInvocation());
    assertThat(printer.getWanted()).contains("\n");
    assertThat(printer.getActual()).contains("\n");
  }
  @Test public void shouldPrintBothInSingleLineWhenBothAreShort(){
    SmartPrinter printer=new SmartPrinter(shortie,shortie.getInvocation());
    assertThat(printer.getWanted()).doesNotContain("\n");
    assertThat(printer.getActual()).doesNotContain("\n");
  }
}
