public class WantedButNotInvoked extends MockitoAssertionError {
  private static final long serialVersionUID=1L;
  public WantedButNotInvoked(  String message){
    super(message);
  }
  @Override public String toString(){
    return new RemoveFirstLine().of(super.toString());
  }
}
