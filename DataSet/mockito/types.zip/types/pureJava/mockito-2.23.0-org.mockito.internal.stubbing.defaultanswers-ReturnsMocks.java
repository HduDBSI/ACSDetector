public class ReturnsMocks implements Answer<Object>, Serializable {
  private static final long serialVersionUID=-6755257986994634579L;
  private final MockitoCore mockitoCore=new MockitoCore();
  private final Answer<Object> delegate=new ReturnsMoreEmptyValues();
  public Object answer(  InvocationOnMock invocation) throws Throwable {
    Object ret=delegate.answer(invocation);
    if (ret != null) {
      return ret;
    }
    return returnValueFor(invocation.getMethod().getReturnType());
  }
  Object returnValueFor(  Class<?> clazz){
    if (!mockitoCore.isTypeMockable(clazz)) {
      return null;
    }
    return mockitoCore.mock(clazz,new MockSettingsImpl().defaultAnswer(this));
  }
}
