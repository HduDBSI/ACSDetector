/** 
 * Ongoing configuration of the mock injector.
 */
public static class OngoingMockInjection {
  private final Set<Field> fields=new HashSet<Field>();
  private final Set<Object> mocks=newMockSafeHashSet();
  private final Object fieldOwner;
  private final MockInjectionStrategy injectionStrategies=MockInjectionStrategy.nop();
  private final MockInjectionStrategy postInjectionStrategies=MockInjectionStrategy.nop();
  private OngoingMockInjection(  Field field,  Object fieldOwner){
    this(Collections.singleton(field),fieldOwner);
  }
  private OngoingMockInjection(  Set<Field> fields,  Object fieldOwner){
    this.fieldOwner=checkNotNull(fieldOwner,"fieldOwner");
    this.fields.addAll(checkItemsNotNull(fields,"fields"));
  }
  public OngoingMockInjection withMocks(  Set<Object> mocks){
    this.mocks.addAll(checkNotNull(mocks,"mocks"));
    return this;
  }
  public OngoingMockInjection tryConstructorInjection(){
    injectionStrategies.thenTry(new ConstructorInjection());
    return this;
  }
  public OngoingMockInjection tryPropertyOrFieldInjection(){
    injectionStrategies.thenTry(new PropertyAndSetterInjection());
    return this;
  }
  public OngoingMockInjection handleSpyAnnotation(){
    postInjectionStrategies.thenTry(new SpyOnInjectedFieldsHandler());
    return this;
  }
  public void apply(){
    for (    Field field : fields) {
      injectionStrategies.process(field,fieldOwner,mocks);
      postInjectionStrategies.process(field,fieldOwner,mocks);
    }
  }
}
