@SuppressWarnings("unchecked") public class ScenarioPrinterTest extends TestBase {
  ScenarioPrinter sp=new ScenarioPrinter();
  @Test public void shouldPrintInvocations(){
    Invocation verified=new InvocationBuilder().simpleMethod().verified().toInvocation();
    Invocation unverified=new InvocationBuilder().differentMethod().toInvocation();
    String out=sp.print((List)asList(verified,unverified));
    assertThat(out).contains("1. -> at").contains("2. [?]-> at");
  }
  @Test public void shouldNotPrintInvocationsWhenSingleUnwanted(){
    Invocation unverified=new InvocationBuilder().differentMethod().toInvocation();
    String out=sp.print((List)asList(unverified));
    assertThat(out).contains("Actually, above is the only interaction with this mock.");
  }
}
