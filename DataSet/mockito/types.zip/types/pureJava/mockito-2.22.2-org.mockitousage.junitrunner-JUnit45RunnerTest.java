@RunWith(MockitoJUnitRunner.class) public class JUnit45RunnerTest {
  @InjectMocks private ListDependent listDependent=new ListDependent();
  @Mock private List<String> list;
  @Test public void shouldInitMocksUsingRunner(){
    list.add("test");
    verify(list).add("test");
  }
  @Test public void shouldInjectMocksUsingRunner(){
    assertNotNull(list);
    assertSame(list,listDependent.getList());
  }
  @Test public void shouldFilterTestMethodsCorrectly() throws Exception {
    MockitoJUnitRunner runner=new MockitoJUnitRunner(this.getClass());
    runner.filter(methodNameContains("shouldInitMocksUsingRunner"));
    assertEquals(1,runner.testCount());
  }
class ListDependent {
    private List<?> list;
    public List<?> getList(){
      return list;
    }
  }
}
