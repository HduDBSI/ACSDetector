protected interface MyIterable<T> extends Iterable<T> {
  public MyIterator<T> iterator();
}
