public class ReturnsMocks implements Answer<Object>, Serializable {
  private static final long serialVersionUID=-6755257986994634579L;
  private final Answer<Object> delegate=new ReturnsMoreEmptyValues();
  @Override public Object answer(  final InvocationOnMock invocation) throws Throwable {
    Object defaultReturnValue=delegate.answer(invocation);
    if (defaultReturnValue != null) {
      return defaultReturnValue;
    }
    return RetrieveGenericsForDefaultAnswers.returnTypeForMockWithCorrectGenerics(invocation,new RetrieveGenericsForDefaultAnswers.AnswerCallback(){
      @Override public Object apply(      Class<?> type){
        if (type == null) {
          return null;
        }
        return Mockito.mock(type,new MockSettingsImpl<Object>().defaultAnswer(ReturnsMocks.this));
      }
    }
);
  }
}
