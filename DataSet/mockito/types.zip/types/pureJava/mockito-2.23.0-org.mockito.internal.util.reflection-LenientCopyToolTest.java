@SuppressWarnings("unchecked") public class LenientCopyToolTest extends TestBase {
  private LenientCopyTool tool=new LenientCopyTool();
static class InheritMe {
    protected String protectedInherited="protected";
    private String privateInherited="private";
  }
public static class SomeObject extends InheritMe {
    @SuppressWarnings("unused") private static int staticField=-100;
    private int privateField=-100;
    private transient int privateTransientField=-100;
    String defaultField="-100";
    protected Object protectedField=new Object();
    public SomeOtherObject instancePublicField=new SomeOtherObject();
    final int finalField;
    public SomeObject(    int finalField){
      this.finalField=finalField;
    }
  }
public static class SomeOtherObject {
  }
  private SomeObject from=new SomeObject(100);
  private SomeObject to=mock(SomeObject.class);
  @Test public void shouldShallowCopyBasicFinalField() throws Exception {
    assertEquals(100,from.finalField);
    assertThat(to.finalField).isNotEqualTo(100);
    tool.copyToMock(from,to);
    assertEquals(100,to.finalField);
  }
  @Test public void shouldShallowCopyTransientPrivateFields() throws Exception {
    from.privateTransientField=1000;
    assertThat(to.privateTransientField).isNotEqualTo(1000);
    tool.copyToMock(from,to);
    assertEquals(1000,to.privateTransientField);
  }
  @Test public void shouldShallowCopyLinkedListIntoMock() throws Exception {
    LinkedList fromList=new LinkedList();
    LinkedList toList=mock(LinkedList.class);
    tool.copyToMock(fromList,toList);
  }
  @Test public void shouldShallowCopyFieldValuesIntoMock() throws Exception {
    from.defaultField="foo";
    from.instancePublicField=new SomeOtherObject();
    from.privateField=1;
    from.privateTransientField=2;
    from.protectedField=3;
    assertThat(to.defaultField).isNotEqualTo(from.defaultField);
    assertThat(to.instancePublicField).isNotEqualTo(from.instancePublicField);
    assertThat(to.privateField).isNotEqualTo(from.privateField);
    assertThat(to.privateTransientField).isNotEqualTo(from.privateTransientField);
    assertThat(to.protectedField).isNotEqualTo(from.protectedField);
    tool.copyToMock(from,to);
    assertEquals(from.defaultField,to.defaultField);
    assertEquals(from.instancePublicField,to.instancePublicField);
    assertEquals(from.privateField,to.privateField);
    assertEquals(from.privateTransientField,to.privateTransientField);
    assertEquals(from.protectedField,to.protectedField);
  }
  @Test public void shouldCopyValuesOfInheritedFields() throws Exception {
    ((InheritMe)from).privateInherited="foo";
    ((InheritMe)from).protectedInherited="bar";
    assertThat(((InheritMe)to).privateInherited).isNotEqualTo(((InheritMe)from).privateInherited);
    tool.copyToMock(from,to);
    assertEquals(((InheritMe)from).privateInherited,((InheritMe)to).privateInherited);
  }
  @Test public void shouldEnableAndThenDisableAccessibility() throws Exception {
    Field privateField=SomeObject.class.getDeclaredField("privateField");
    assertFalse(privateField.isAccessible());
    tool.copyToMock(from,to);
    privateField=SomeObject.class.getDeclaredField("privateField");
    assertFalse(privateField.isAccessible());
  }
  @Test public void shouldContinueEvenIfThereAreProblemsCopyingSingleFieldValue() throws Exception {
    tool.fieldCopier=mock(FieldCopier.class);
    doNothing().doThrow(new IllegalAccessException()).doNothing().when(tool.fieldCopier).copyValue(anyObject(),anyObject(),any(Field.class));
    tool.copyToMock(from,to);
    verify(tool.fieldCopier,atLeast(3)).copyValue(any(),any(),any(Field.class));
  }
  @Test public void shouldBeAbleToCopyFromRealObjectToRealObject() throws Exception {
    from.defaultField="defaultField";
    from.instancePublicField=new SomeOtherObject();
    from.privateField=1;
    from.privateTransientField=2;
    from.protectedField="protectedField";
    from.protectedInherited="protectedInherited";
    to=new SomeObject(0);
    tool.copyToRealObject(from,to);
    assertEquals(from.defaultField,to.defaultField);
    assertEquals(from.instancePublicField,to.instancePublicField);
    assertEquals(from.privateField,to.privateField);
    assertEquals(from.privateTransientField,to.privateTransientField);
    assertEquals(from.protectedField,to.protectedField);
    assertEquals(from.protectedInherited,to.protectedInherited);
  }
}
