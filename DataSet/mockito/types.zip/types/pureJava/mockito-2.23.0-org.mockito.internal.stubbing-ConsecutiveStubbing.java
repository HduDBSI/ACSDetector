public class ConsecutiveStubbing<T> extends BaseStubbing<T> {
  private final InvocationContainerImpl invocationContainerImpl;
  public ConsecutiveStubbing(  InvocationContainerImpl invocationContainerImpl){
    this.invocationContainerImpl=invocationContainerImpl;
  }
  public OngoingStubbing<T> thenAnswer(  Answer<?> answer){
    invocationContainerImpl.addConsecutiveAnswer(answer);
    return this;
  }
  public OngoingStubbing<T> then(  Answer<?> answer){
    return thenAnswer(answer);
  }
  @SuppressWarnings("unchecked") public <M>M getMock(){
    return (M)invocationContainerImpl.invokedMock();
  }
}
