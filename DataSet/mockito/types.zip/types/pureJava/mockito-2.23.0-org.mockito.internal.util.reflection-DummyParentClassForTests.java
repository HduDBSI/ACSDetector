public class DummyParentClassForTests {
  @SuppressWarnings("unused") private String somePrivateField;
}
