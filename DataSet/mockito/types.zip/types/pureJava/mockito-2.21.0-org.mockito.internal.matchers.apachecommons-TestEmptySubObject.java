static class TestEmptySubObject extends TestObject {
  public TestEmptySubObject(  int a){
    super(a);
  }
}
