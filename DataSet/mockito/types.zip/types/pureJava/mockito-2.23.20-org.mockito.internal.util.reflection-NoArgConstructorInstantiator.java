/** 
 * Constructor instantiating strategy for no-arg constructor. <p> If a no-arg constructor can be found then the instance is created using this constructor. Otherwise a technical MockitoException is thrown. </p>
 */
static class NoArgConstructorInstantiator implements ConstructorInstantiator {
  private final Object testClass;
  private final Field field;
  /** 
 * Internal, checks are done by FieldInitializer. Fields are assumed to be accessible.
 */
  NoArgConstructorInstantiator(  Object testClass,  Field field){
    this.testClass=testClass;
    this.field=field;
  }
  public FieldInitializationReport instantiate(){
    final AccessibilityChanger changer=new AccessibilityChanger();
    Constructor<?> constructor=null;
    try {
      constructor=field.getType().getDeclaredConstructor();
      changer.enableAccess(constructor);
      final Object[] noArg=new Object[0];
      Object newFieldInstance=constructor.newInstance(noArg);
      setField(testClass,field,newFieldInstance);
      return new FieldInitializationReport(field.get(testClass),true,false);
    }
 catch (    NoSuchMethodException e) {
      throw new MockitoException("the type '" + field.getType().getSimpleName() + "' has no default constructor",e);
    }
catch (    InvocationTargetException e) {
      throw new MockitoException("the default constructor of type '" + field.getType().getSimpleName() + "' has raised an exception (see the stack trace for cause): "+ e.getTargetException().toString(),e);
    }
catch (    InstantiationException e) {
      throw new MockitoException("InstantiationException (see the stack trace for cause): " + e.toString(),e);
    }
catch (    IllegalAccessException e) {
      throw new MockitoException("IllegalAccessException (see the stack trace for cause): " + e.toString(),e);
    }
 finally {
      if (constructor != null) {
        changer.safelyDisableAccess(constructor);
      }
    }
  }
}
