public static class TestACanEqualB {
  private int a;
  public TestACanEqualB(  int a){
    this.a=a;
  }
  public boolean equals(  Object o){
    if (o == this) {
      return true;
    }
    if (o instanceof TestACanEqualB) {
      return this.a == ((TestACanEqualB)o).getA();
    }
    if (o instanceof TestBCanEqualA) {
      return this.a == ((TestBCanEqualA)o).getB();
    }
    return false;
  }
  public int hashCode(){
    return 1;
  }
  public int getA(){
    return this.a;
  }
}
