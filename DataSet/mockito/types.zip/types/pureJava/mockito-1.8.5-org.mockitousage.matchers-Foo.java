private interface Foo {
  List<String> sort(  List<String> otherList);
  String convertDate(  Date date);
}
