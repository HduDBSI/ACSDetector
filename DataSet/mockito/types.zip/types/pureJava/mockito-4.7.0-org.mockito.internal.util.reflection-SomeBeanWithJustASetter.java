static class SomeBeanWithJustASetter {
  private File theField;
  boolean theFieldSetterWasUsed;
  public void setTheField(  final File theField){
    theFieldSetterWasUsed=true;
    this.theField=theField;
  }
}
