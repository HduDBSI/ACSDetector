class FailingSpy {
  @Spy ThrowingConstructor throwingConstructor;
}
