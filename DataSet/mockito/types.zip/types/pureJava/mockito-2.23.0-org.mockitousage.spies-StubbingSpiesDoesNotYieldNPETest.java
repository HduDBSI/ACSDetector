public class StubbingSpiesDoesNotYieldNPETest extends TestBase {
class Foo {
    public int len(    String text){
      return text.length();
    }
    public int size(    Map<?,?> map){
      return map.size();
    }
    public int size(    Collection<?> collection){
      return collection.size();
    }
  }
  @Test public void shouldNotThrowNPE() throws Exception {
    Foo foo=new Foo();
    Foo spy=spy(foo);
    spy.len(anyString());
    spy.size(anyMap());
    spy.size(anyList());
    spy.size(anyCollection());
    spy.size(anySet());
  }
}
