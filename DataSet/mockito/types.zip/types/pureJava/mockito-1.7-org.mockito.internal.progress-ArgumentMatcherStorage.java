@SuppressWarnings("unchecked") public interface ArgumentMatcherStorage {
  HandyReturnValues reportMatcher(  Matcher matcher);
  List<Matcher> pullMatchers();
  HandyReturnValues reportAnd();
  HandyReturnValues reportNot();
  HandyReturnValues reportOr();
  void validateState();
  void reset();
}
