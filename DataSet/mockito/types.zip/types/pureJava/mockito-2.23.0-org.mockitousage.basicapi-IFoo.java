interface IFoo {
}
