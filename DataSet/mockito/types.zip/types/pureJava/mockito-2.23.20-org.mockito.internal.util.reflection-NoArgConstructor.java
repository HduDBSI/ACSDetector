private static class NoArgConstructor {
  NoArgConstructor(){
  }
}
