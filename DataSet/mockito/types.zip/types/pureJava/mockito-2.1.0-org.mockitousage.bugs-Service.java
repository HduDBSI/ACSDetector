interface Service {
  String verySlowMethod();
}
