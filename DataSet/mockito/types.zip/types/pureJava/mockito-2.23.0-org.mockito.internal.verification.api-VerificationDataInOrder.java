public interface VerificationDataInOrder {
  List<Invocation> getAllInvocations();
  MatchableInvocation getWanted();
  InOrderContext getOrderingContext();
}
