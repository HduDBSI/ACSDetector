public static class AnObjectWithoutConstructor {
  private Set<?> theSet;
}
