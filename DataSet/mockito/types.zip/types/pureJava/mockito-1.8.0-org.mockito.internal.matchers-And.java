@SuppressWarnings("unchecked") public class And extends ArgumentMatcher {
  private final List<Matcher> matchers;
  public And(  List<Matcher> matchers){
    this.matchers=matchers;
  }
  public boolean matches(  Object actual){
    for (    Matcher matcher : matchers) {
      if (!matcher.matches(actual)) {
        return false;
      }
    }
    return true;
  }
  public void describeTo(  Description description){
    description.appendText("and(");
    for (Iterator<Matcher> it=matchers.iterator(); it.hasNext(); ) {
      it.next().describeTo(description);
      if (it.hasNext()) {
        description.appendText(", ");
      }
    }
    description.appendText(")");
  }
}
