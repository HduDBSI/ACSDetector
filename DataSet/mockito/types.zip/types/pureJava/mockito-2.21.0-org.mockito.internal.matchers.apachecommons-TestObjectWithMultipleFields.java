@SuppressWarnings("unused") static class TestObjectWithMultipleFields {
  private TestObject one;
  private TestObject two;
  private TestObject three;
  public TestObjectWithMultipleFields(  int one,  int two,  int three){
    this.one=new TestObject(one);
    this.two=new TestObject(two);
    this.three=new TestObject(three);
  }
}
