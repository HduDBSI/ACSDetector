public class ShouldNotDeadlockAnswerExecutionTest {
  @Test public void failIfMockIsSharedBetweenThreads() throws Exception {
    Service service=Mockito.mock(Service.class);
    ExecutorService threads=Executors.newCachedThreadPool();
    AtomicInteger counter=new AtomicInteger(2);
    Mockito.when(service.verySlowMethod()).thenAnswer(new LockingAnswer(counter));
    threads.execute(new ServiceRunner(service));
    threads.execute(new ServiceRunner(service));
    threads.shutdown();
    if (!threads.awaitTermination(1000,TimeUnit.MILLISECONDS)) {
      fail();
    }
  }
  @Test public void successIfEveryThreadHasItsOwnMock() throws Exception {
    Service service1=Mockito.mock(Service.class);
    Service service2=Mockito.mock(Service.class);
    ExecutorService threads=Executors.newCachedThreadPool();
    AtomicInteger counter=new AtomicInteger(2);
    Mockito.when(service1.verySlowMethod()).thenAnswer(new LockingAnswer(counter));
    Mockito.when(service2.verySlowMethod()).thenAnswer(new LockingAnswer(counter));
    threads.execute(new ServiceRunner(service1));
    threads.execute(new ServiceRunner(service2));
    threads.shutdown();
    if (!threads.awaitTermination(500,TimeUnit.MILLISECONDS)) {
      fail();
    }
  }
static class LockingAnswer implements Answer<String> {
    private AtomicInteger counter;
    public LockingAnswer(    AtomicInteger counter){
      this.counter=counter;
    }
    /** 
 * Decrement counter and wait until counter has value 0
 */
    public String answer(    InvocationOnMock invocation) throws Throwable {
      counter.decrementAndGet();
      while (counter.get() != 0) {
        Thread.sleep(10);
      }
      return null;
    }
  }
static class ServiceRunner implements Runnable {
    private Service service;
    public ServiceRunner(    Service service){
      this.service=service;
    }
    public void run(){
      service.verySlowMethod();
    }
  }
interface Service {
    String verySlowMethod();
  }
}
