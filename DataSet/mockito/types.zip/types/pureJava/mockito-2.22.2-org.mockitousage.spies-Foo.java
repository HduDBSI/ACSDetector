interface Foo {
  String print();
}
