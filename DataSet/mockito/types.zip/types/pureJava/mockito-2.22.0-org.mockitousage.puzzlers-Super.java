private class Super<T> {
  public String say(  T t){
    return "Super says: " + t;
  }
}
