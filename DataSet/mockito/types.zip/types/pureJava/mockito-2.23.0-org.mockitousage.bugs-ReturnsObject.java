public interface ReturnsObject {
  Object callMe();
}
