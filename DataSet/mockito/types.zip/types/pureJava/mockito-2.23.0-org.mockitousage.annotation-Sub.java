class Sub extends Base {
  @Captor private ArgumentCaptor<IMethods> mock;
  public ArgumentCaptor<IMethods> getCaptor(){
    return mock;
  }
}
