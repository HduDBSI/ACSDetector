private static class RecordCall implements Answer {
  private boolean called=false;
  public boolean isCalled(){
    return called;
  }
  public Object answer(  InvocationOnMock invocation) throws Throwable {
    called=true;
    return null;
  }
}
