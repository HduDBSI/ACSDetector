public static class SubTest extends SpyAnnotationInitializedInBaseClassTest {
  @Spy List spyInSubclass=new LinkedList();
  @Test public void shouldInitSpiesInHierarchy() throws Exception {
    assertTrue(isMock(spyInSubclass));
    assertTrue(isMock(spyInBaseclass));
  }
}
