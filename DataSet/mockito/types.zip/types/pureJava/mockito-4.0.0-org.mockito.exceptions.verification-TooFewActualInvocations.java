/** 
 * @since 2.27.5
 */
public class TooFewActualInvocations extends MockitoAssertionError {
  private static final long serialVersionUID=1L;
  public TooFewActualInvocations(  String message){
    super(message);
  }
}
