static class Person {
  Address address;
  public Address getAddress(){
    return address;
  }
  public Address getAddress(  String addressName){
    return address;
  }
  public FinalClass getFinalClass(){
    return null;
  }
}
