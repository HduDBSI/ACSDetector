@SuppressWarnings("unused") static class TestTTSubObject extends TestTSubObject {
  private transient int tt;
  public TestTTSubObject(  int a,  int t,  int tt){
    super(a,t);
    this.tt=tt;
  }
}
