private final class IsAnyBoolean implements ArgumentMatcher<Boolean> {
  public boolean matches(  Boolean arg){
    return true;
  }
}
