static class InheritMe {
  protected String protectedInherited="protected";
  private String privateInherited="private";
}
