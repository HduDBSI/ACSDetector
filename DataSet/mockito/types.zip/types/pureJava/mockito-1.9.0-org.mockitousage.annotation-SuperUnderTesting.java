static class SuperUnderTesting {
  private List aList;
  public List getAList(){
    return aList;
  }
}
