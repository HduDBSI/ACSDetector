public interface InOrderContext {
  boolean isVerified(  Invocation invocation);
  void markVerified(  Invocation i);
}
