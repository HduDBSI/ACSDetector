public class PlaygroundTest extends TestBase {
static class Foo {
    int doSomeThing(){
      return 0;
    }
    protected String getStuff(){
      return "foo";
    }
  }
class Boo {
    final public Object withLong(    long y){
      return "";
    }
    public Object foo(){
      return "";
    }
  }
  Foo mock;
  @Mock IMethods mockTwo;
  @Test public void spyInAction(){
  }
  @Test public void partialMockInAction(){
  }
}
