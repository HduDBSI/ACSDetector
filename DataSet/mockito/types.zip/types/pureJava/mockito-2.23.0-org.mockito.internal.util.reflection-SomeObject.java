public static class SomeObject extends InheritMe {
  @SuppressWarnings("unused") private static int staticField=-100;
  private int privateField=-100;
  private transient int privateTransientField=-100;
  String defaultField="-100";
  protected Object protectedField=new Object();
  public SomeOtherObject instancePublicField=new SomeOtherObject();
  final int finalField;
  public SomeObject(  int finalField){
    this.finalField=finalField;
  }
}
