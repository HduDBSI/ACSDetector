public abstract class BaseStubbing<T> implements OngoingStubbing<T> {
  @Override public OngoingStubbing<T> thenReturn(  T value){
    return thenAnswer(new Returns(value));
  }
  @Override public OngoingStubbing<T> thenReturn(  T value,  T... values){
    OngoingStubbing<T> stubbing=thenReturn(value);
    if (values == null) {
      return stubbing.thenReturn(null);
    }
    for (    T v : values) {
      stubbing=stubbing.thenReturn(v);
    }
    return stubbing;
  }
  private OngoingStubbing<T> thenThrow(  Throwable throwable){
    return thenAnswer(new ThrowsException(throwable));
  }
  @Override public OngoingStubbing<T> thenThrow(  Throwable... throwables){
    if (throwables == null) {
      return thenThrow((Throwable)null);
    }
    OngoingStubbing<T> stubbing=null;
    for (    Throwable t : throwables) {
      if (stubbing == null) {
        stubbing=thenThrow(t);
      }
 else {
        stubbing=stubbing.thenThrow(t);
      }
    }
    return stubbing;
  }
  @Override public OngoingStubbing<T> thenThrow(  Class<? extends Throwable> throwableType){
    if (throwableType == null) {
      mockingProgress().reset();
      throw notAnException();
    }
    return thenThrow(newInstance(throwableType));
  }
  @Override public OngoingStubbing<T> thenThrow(  Class<? extends Throwable> toBeThrown,  Class<? extends Throwable>... nextToBeThrown){
    if (nextToBeThrown == null) {
      return thenThrow((Class<Throwable>)null);
    }
    OngoingStubbing<T> stubbing=thenThrow(toBeThrown);
    for (    Class<? extends Throwable> t : nextToBeThrown) {
      stubbing=stubbing.thenThrow(t);
    }
    return stubbing;
  }
  @Override public OngoingStubbing<T> thenCallRealMethod(){
    return thenAnswer(new CallsRealMethods());
  }
}
