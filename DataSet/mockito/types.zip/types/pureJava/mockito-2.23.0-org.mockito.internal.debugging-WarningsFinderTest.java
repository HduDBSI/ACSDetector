public class WarningsFinderTest extends TestBase {
  @Mock private IMethods mock;
  @Mock private FindingsListener listener;
  @Test public void shouldPrintUnusedStub(){
    Invocation unusedStub=new InvocationBuilder().simpleMethod().toInvocation();
    WarningsFinder finder=new WarningsFinder(asList(unusedStub),Arrays.<InvocationMatcher>asList());
    finder.find(listener);
    verify(listener,only()).foundUnusedStub(unusedStub);
  }
  @Test public void shouldPrintUnstubbedInvocation(){
    InvocationMatcher unstubbedInvocation=new InvocationBuilder().differentMethod().toInvocationMatcher();
    WarningsFinder finder=new WarningsFinder(Arrays.<Invocation>asList(),Arrays.<InvocationMatcher>asList(unstubbedInvocation));
    finder.find(listener);
    verify(listener,only()).foundUnstubbed(unstubbedInvocation);
  }
  @Test public void shouldPrintStubWasUsedWithDifferentArgs(){
    Invocation stub=new InvocationBuilder().arg("foo").mock(mock).toInvocation();
    InvocationMatcher wrongArg=new InvocationBuilder().arg("bar").mock(mock).toInvocationMatcher();
    WarningsFinder finder=new WarningsFinder(Arrays.<Invocation>asList(stub),Arrays.<InvocationMatcher>asList(wrongArg));
    finder.find(listener);
    verify(listener,only()).foundStubCalledWithDifferentArgs(stub,wrongArg);
  }
}
