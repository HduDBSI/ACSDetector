@RunWith(MockitoJUnitRunner.Silent.class) public class InvalidUseOfMatchersTest {
  private IMethods mock=Mockito.mock(IMethods.class);
  @Test public void should_detect_wrong_number_of_matchers_when_stubbing(){
    when(mock.threeArgumentMethod(1,"2","3")).thenReturn(null);
    try {
      when(mock.threeArgumentMethod(1,eq("2"),"3")).thenReturn(null);
      fail();
    }
 catch (    InvalidUseOfMatchersException e) {
      assertThat(e.getMessage()).contains("3 matchers expected").contains("1 recorded");
    }
  }
  @Test public void should_detect_stupid_use_of_matchers_when_verifying(){
    mock.oneArg(true);
    eq("that's the stupid way");
    eq("of using matchers");
    try {
      Mockito.verify(mock).oneArg(true);
      fail();
    }
 catch (    InvalidUseOfMatchersException e) {
      assertThat(e.getMessage()).contains("Misplaced or misused argument matcher detected here");
      e.printStackTrace();
    }
  }
  @Test public void should_not_scream_on_correct_usage() throws Exception {
    mock.simpleMethod(AdditionalMatchers.not(eq("asd")));
    mock.simpleMethod(AdditionalMatchers.or(eq("jkl"),eq("asd")));
  }
  @Test public void should_scream_when_no_matchers_inside_not(){
    try {
      mock.simpleMethod(AdditionalMatchers.not("jkl"));
      fail();
    }
 catch (    InvalidUseOfMatchersException e) {
      assertThat(e.getMessage()).contains("No matchers found for").containsIgnoringCase("Not(?)");
    }
  }
  @Test public void should_scream_when_not_enough_matchers_inside_or_AddtionalMatcher(){
    try {
      mock.simpleMethod(AdditionalMatchers.or(eq("jkl"),"asd"));
      fail();
    }
 catch (    InvalidUseOfMatchersException e) {
      assertThat(e.getMessage()).containsIgnoringCase("inside additional matcher Or(?)").contains("2 sub matchers expected").contains("1 recorded");
    }
  }
  @Test public void should_scream_when_Matchers_count_dont_match_parameter_count(){
    try {
      mock.threeArgumentMethod(1,"asd",eq("asd"));
      fail();
    }
 catch (    InvalidUseOfMatchersException e) {
      assertThat(e.getMessage()).contains("3 matchers expected").contains("1 recorded");
    }
  }
  @Test public void should_mention_matcher_when_misuse_detected(){
    Result run=new JUnitCore().run(ObjectMatcherMisuseOnPrimitiveSite.class);
    assertThat(run.getFailures()).hasSize(2);
    assertThat(run.getFailures().get(0).getException()).isInstanceOf(NullPointerException.class).hasMessage(null);
    assertThat(run.getFailures().get(1).getException()).isInstanceOf(InvalidUseOfMatchersException.class).hasMessageContaining("primitive alternatives");
    new StateMaster().reset();
  }
@RunWith(MockitoJUnitRunner.class) public static class ObjectMatcherMisuseOnPrimitiveSite {
    @Test public void fails_with_NPE(){
      IMethods mock=Mockito.mock(IMethods.class);
      doNothing().when(mock).twoArgumentMethod(eq(73),(Integer)any());
    }
  }
}
