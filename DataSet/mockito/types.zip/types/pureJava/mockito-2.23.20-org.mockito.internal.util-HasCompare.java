private interface HasCompare extends Comparable<HasCompare> {
  int foo(  HasCompare other);
  int compareTo(  HasCompare other,  String redHerring);
  int compareTo(  String redHerring);
  int compareTo(  HasCompare redHerring);
}
