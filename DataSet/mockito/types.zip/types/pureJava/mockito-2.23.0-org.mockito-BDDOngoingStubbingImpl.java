private static class BDDOngoingStubbingImpl<T> implements BDDMyOngoingStubbing<T> {
  private final OngoingStubbing<T> mockitoOngoingStubbing;
  public BDDOngoingStubbingImpl(  OngoingStubbing<T> ongoingStubbing){
    this.mockitoOngoingStubbing=ongoingStubbing;
  }
  public BDDMyOngoingStubbing<T> willAnswer(  Answer<?> answer){
    return new BDDOngoingStubbingImpl<T>(mockitoOngoingStubbing.thenAnswer(answer));
  }
  public BDDMyOngoingStubbing<T> will(  Answer<?> answer){
    return new BDDOngoingStubbingImpl<T>(mockitoOngoingStubbing.then(answer));
  }
  public BDDMyOngoingStubbing<T> willReturn(  T value){
    return new BDDOngoingStubbingImpl<T>(mockitoOngoingStubbing.thenReturn(value));
  }
  public BDDMyOngoingStubbing<T> willReturn(  T value,  T... values){
    return new BDDOngoingStubbingImpl<T>(mockitoOngoingStubbing.thenReturn(value,values));
  }
  public BDDMyOngoingStubbing<T> willThrow(  Throwable... throwables){
    return new BDDOngoingStubbingImpl<T>(mockitoOngoingStubbing.thenThrow(throwables));
  }
  public BDDMyOngoingStubbing<T> willThrow(  Class<? extends Throwable> throwableType){
    return new BDDOngoingStubbingImpl<T>(mockitoOngoingStubbing.thenThrow(throwableType));
  }
  public BDDMyOngoingStubbing<T> willThrow(  Class<? extends Throwable> throwableType,  Class<? extends Throwable>... throwableTypes){
    return new BDDOngoingStubbingImpl<T>(mockitoOngoingStubbing.thenThrow(throwableType,throwableTypes));
  }
  public BDDMyOngoingStubbing<T> willCallRealMethod(){
    return new BDDOngoingStubbingImpl<T>(mockitoOngoingStubbing.thenCallRealMethod());
  }
  public <M>M getMock(){
    return (M)mockitoOngoingStubbing.getMock();
  }
}
