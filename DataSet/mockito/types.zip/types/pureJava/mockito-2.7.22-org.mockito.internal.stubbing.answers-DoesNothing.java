public class DoesNothing implements Answer<Object>, ValidableAnswer, Serializable {
  private static final long serialVersionUID=4840880517740698416L;
  private static final DoesNothing SINGLETON=new DoesNothing();
  private DoesNothing(){
  }
  public static DoesNothing doesNothing(){
    return SINGLETON;
  }
  @Override public Object answer(  InvocationOnMock invocation){
    return null;
  }
  @Override public void validateFor(  InvocationOnMock invocation){
    if (!new InvocationInfo(invocation).isVoid()) {
      throw onlyVoidMethodsCanBeSetToDoNothing();
    }
  }
}
