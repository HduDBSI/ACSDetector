/** 
 * Notified when mock object is created. For more information on listeners see  {@link org.mockito.MockitoFramework#addListener(MockitoListener)}.
 */
public interface MockCreationListener extends MockitoListener {
  /** 
 * Mock object was just created.
 * @param mock created mock object
 * @param settings the settings used for creation
 */
  void onMockCreated(  Object mock,  MockCreationSettings settings);
}
