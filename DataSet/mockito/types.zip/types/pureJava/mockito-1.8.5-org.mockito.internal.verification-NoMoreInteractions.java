public class NoMoreInteractions implements VerificationMode, VerificationInOrderMode {
  @SuppressWarnings("unchecked") public void verify(  VerificationData data){
    Invocation unverified=new InvocationsFinder().findFirstUnverified(data.getAllInvocations());
    if (unverified != null) {
      new Reporter().noMoreInteractionsWanted(unverified,(List)data.getAllInvocations());
    }
  }
  public void verifyInOrder(  VerificationDataInOrder data){
    List<Invocation> invocations=data.getAllInvocations();
    Invocation unverified=new InvocationsFinder().findFirstUnverifiedInOrder(data.getOrderingContext(),invocations);
    if (unverified != null) {
      new Reporter().noMoreInteractionsWantedInOrder(unverified);
    }
  }
}
