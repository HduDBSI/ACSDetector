@RunWith(MockitoJUnitRunner.class) @Ignore public class ModellingVerboseMockitoTest extends TestBase {
  @Mock private IMethods mock;
  @Before public void cleanStackTraces(){
    super.makeStackTracesClean();
  }
  @Test public void shouldLogUnusedStubbingWarningWhenTestFails() throws Exception {
    when(mock.simpleMethod(1)).thenReturn("foo");
    when(mock.otherMethod()).thenReturn("foo");
    when(mock.booleanObjectReturningMethod()).thenReturn(false);
    String ret=mock.simpleMethod(2);
    assertEquals("foo",ret);
  }
  @Test public void shouldNotLogAnythingWhenNoWarnings() throws Exception {
    when(mock.simpleMethod()).thenReturn("foo");
    mock.simpleMethod();
    verify(mock).simpleMethod();
    fail();
  }
}
