static class ServiceRunner implements Runnable {
  private Service service;
  public ServiceRunner(  Service service){
    this.service=service;
  }
  public void run(){
    service.verySlowMethod();
  }
}
