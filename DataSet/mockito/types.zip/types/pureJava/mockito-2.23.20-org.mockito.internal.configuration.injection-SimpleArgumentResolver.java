/** 
 * Returns mocks that match the argument type, if not possible assigns null.
 */
static class SimpleArgumentResolver implements ConstructorArgumentResolver {
  final Set<Object> objects;
  public SimpleArgumentResolver(  Set<Object> objects){
    this.objects=objects;
  }
  public Object[] resolveTypeInstances(  Class<?>... argTypes){
    List<Object> argumentInstances=new ArrayList<Object>(argTypes.length);
    for (    Class<?> argType : argTypes) {
      argumentInstances.add(objectThatIsAssignableFrom(argType));
    }
    return argumentInstances.toArray();
  }
  private Object objectThatIsAssignableFrom(  Class<?> argType){
    for (    Object object : objects) {
      if (argType.isAssignableFrom(object.getClass()))       return object;
    }
    return null;
  }
}
