/** 
 * An exception that isn't defined by Mockito or the JDK and therefore does not appear in the logging result by chance alone.
 */
static class ThirdPartyException extends RuntimeException {
  private static final long serialVersionUID=2160445705646210847L;
}
