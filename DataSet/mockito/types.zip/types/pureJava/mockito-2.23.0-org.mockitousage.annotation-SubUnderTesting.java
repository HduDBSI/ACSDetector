static class SubUnderTesting extends BaseUnderTesting {
  private Set<?> histogram1;
  private Set<?> histogram2;
  public Set<?> getHistogram1(){
    return histogram1;
  }
  public Set<?> getHistogram2(){
    return histogram2;
  }
}
