private interface ConstructorInstantiator {
  Object instantiate();
}
