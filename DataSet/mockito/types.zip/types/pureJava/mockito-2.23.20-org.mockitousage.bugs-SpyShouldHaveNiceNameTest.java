public class SpyShouldHaveNiceNameTest extends TestBase {
  @Spy List<Integer> veryCoolSpy=new LinkedList<Integer>();
  @Test public void shouldPrintNiceName(){
    veryCoolSpy.add(1);
    try {
      verify(veryCoolSpy).add(2);
      fail();
    }
 catch (    AssertionError e) {
      Assertions.assertThat(e.getMessage()).contains("veryCoolSpy");
    }
  }
}
