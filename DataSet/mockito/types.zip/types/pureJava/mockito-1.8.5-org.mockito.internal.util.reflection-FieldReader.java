public class FieldReader {
  final Object target;
  final Field field;
  final AccessibilityChanger changer=new AccessibilityChanger();
  public FieldReader(  Object target,  Field field){
    this.target=target;
    this.field=field;
    changer.enableAccess(field);
  }
  public boolean isNull(){
    try {
      return field.get(target) == null;
    }
 catch (    Exception e) {
      throw new MockitoException("Cannot read state from field: " + field + ", on instance: "+ target);
    }
  }
}
