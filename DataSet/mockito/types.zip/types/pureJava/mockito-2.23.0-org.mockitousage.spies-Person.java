class Person extends InheritMe {
  private final Name defaultName=new Name("Default name");
  public String getName(){
    return guessName().name;
  }
  Name guessName(){
    return defaultName;
  }
  public String howMuchDidYouInherit(){
    return getInherited();
  }
  public String getNameButDelegateToMethodThatThrows(){
    throwSomeException();
    return guessName().name;
  }
  private void throwSomeException(){
    throw new RuntimeException("boo");
  }
}
