public class CleaningUpPotentialStubbingTest extends TestBase {
  @Mock private IMethods mock;
  @Test public void shouldResetOngoingStubbingOnVerify(){
    mock.booleanReturningMethod();
    verify(mock).booleanReturningMethod();
    assertOngoingStubbingIsReset();
  }
  @Test public void shouldResetOngoingStubbingOnInOrder(){
    mock.booleanReturningMethod();
    InOrder inOrder=inOrder(mock);
    inOrder.verify(mock).booleanReturningMethod();
    assertOngoingStubbingIsReset();
  }
  @Test public void shouldResetOngoingStubbingOnDoReturn(){
    mock.booleanReturningMethod();
    doReturn(false).when(mock).booleanReturningMethod();
    assertOngoingStubbingIsReset();
  }
  private void assertOngoingStubbingIsReset(){
    try {
      when(null).thenReturn("anything");
      fail();
    }
 catch (    MissingMethodInvocationException e) {
    }
  }
}
