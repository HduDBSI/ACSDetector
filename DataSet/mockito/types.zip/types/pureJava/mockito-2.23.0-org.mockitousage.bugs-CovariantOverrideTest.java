public class CovariantOverrideTest extends TestBase {
public interface ReturnsObject {
    Object callMe();
  }
public interface ReturnsString extends ReturnsObject {
    String callMe();
  }
  @Test public void returnFoo1(){
    ReturnsObject mock=mock(ReturnsObject.class);
    when(mock.callMe()).thenReturn("foo");
    assertEquals("foo",mock.callMe());
  }
  @Test public void returnFoo2(){
    ReturnsString mock=mock(ReturnsString.class);
    when(mock.callMe()).thenReturn("foo");
    assertEquals("foo",mock.callMe());
  }
  @Test public void returnFoo3(){
    ReturnsObject mock=mock(ReturnsString.class);
    when(mock.callMe()).thenReturn("foo");
    assertEquals("foo",mock.callMe());
  }
  @Test public void returnFoo4(){
    ReturnsString mock=mock(ReturnsString.class);
    mock.callMe();
    ReturnsObject mock2=mock;
    verify(mock2).callMe();
  }
}
