public class CaptorAnnotationUnhappyPathTest extends TestBase {
  @Captor List<?> notACaptorField;
  @Before @Override public void init(){
  }
  @Test public void shouldFailIfCaptorHasWrongType() throws Exception {
    try {
      MockitoAnnotations.initMocks(this);
      fail();
    }
 catch (    MockitoException e) {
      assertThat(e).hasMessageContaining("notACaptorField").hasMessageContaining("wrong type");
    }
  }
}
