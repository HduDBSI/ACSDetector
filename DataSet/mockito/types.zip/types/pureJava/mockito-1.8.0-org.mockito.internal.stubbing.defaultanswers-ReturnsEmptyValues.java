/** 
 * Default answer of every Mockito mock. <ul> <li> Returns appropriate primitive for primitive-returning methods </li> <li> Returns consistent values for primitive wrapper classes (e.g. int-returning method retuns 0 <b>and</b> Integer-returning method returns 0, too) </li> <li> Returns empty collection for collection-returning methods (works for most commonly used collection types) </li> <li> Returns description of mock for toString() method </li> <li> Returns null for everything else </li> </ul>
 */
public class ReturnsEmptyValues implements Answer<Object> {
  public Object answer(  InvocationOnMock invocation){
    if (Invocation.isToString(invocation)) {
      Object mock=invocation.getMock();
      MockName name=new MockUtil().getMockName(mock);
      if (name.isSurrogate()) {
        return "Mock for " + ClassNameFinder.classNameForMock(mock) + ", hashCode: "+ mock.hashCode();
      }
 else {
        return name.toString();
      }
    }
    Class<?> returnType=invocation.getMethod().getReturnType();
    return returnValueFor(returnType);
  }
  Object returnValueFor(  Class<?> type){
    if (type.isPrimitive()) {
      return primitiveOf(type);
    }
 else     if (Primitives.isPrimitiveWrapper(type)) {
      return Primitives.primitiveWrapperOf(type);
    }
 else     if (type == Collection.class) {
      return new LinkedList<Object>();
    }
 else     if (type == Set.class) {
      return new HashSet<Object>();
    }
 else     if (type == HashSet.class) {
      return new HashSet<Object>();
    }
 else     if (type == SortedSet.class) {
      return new TreeSet<Object>();
    }
 else     if (type == TreeSet.class) {
      return new TreeSet<Object>();
    }
 else     if (type == LinkedHashSet.class) {
      return new LinkedHashSet<Object>();
    }
 else     if (type == List.class) {
      return new LinkedList<Object>();
    }
 else     if (type == LinkedList.class) {
      return new LinkedList<Object>();
    }
 else     if (type == ArrayList.class) {
      return new ArrayList<Object>();
    }
 else     if (type == Map.class) {
      return new HashMap<Object,Object>();
    }
 else     if (type == HashMap.class) {
      return new HashMap<Object,Object>();
    }
 else     if (type == SortedMap.class) {
      return new TreeMap<Object,Object>();
    }
 else     if (type == TreeMap.class) {
      return new TreeMap<Object,Object>();
    }
 else     if (type == LinkedHashMap.class) {
      return new LinkedHashMap<Object,Object>();
    }
    return null;
  }
  private Object primitiveOf(  Class<?> type){
    if (type == Boolean.TYPE) {
      return false;
    }
 else     if (type == Character.TYPE) {
      return (char)0;
    }
 else {
      return 0;
    }
  }
}
