public interface VerificationAwareInvocation extends DescribedInvocation {
  boolean isVerified();
}
