public interface SomeSubInterface extends SomeInterface {
  ExtendedFactory factory();
}
