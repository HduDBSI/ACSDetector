static class TestTSubObject2 extends TestObject {
  private transient int t;
  public TestTSubObject2(  int a,  int t){
    super(a);
  }
  public int getT(){
    return t;
  }
  public void setT(  int t){
    this.t=t;
  }
}
