/** 
 * Class with two methods, one of them is repeatedly mocked while another is repeatedly called.
 */
public interface ToMock {
  Integer getValue(  Integer param);
  List<Integer> getValues(  Integer param);
}
