private final class ContainsFoo implements ArgumentMatcher<String> {
  public boolean matches(  String arg){
    return arg.contains("foo");
  }
}
