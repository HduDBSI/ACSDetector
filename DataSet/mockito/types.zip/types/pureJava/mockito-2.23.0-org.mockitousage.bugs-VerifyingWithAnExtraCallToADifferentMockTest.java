public class VerifyingWithAnExtraCallToADifferentMockTest extends TestBase {
  @Mock IMethods mock;
  @Mock IMethods mockTwo;
  @Test public void shouldAllowVerifyingWhenOtherMockCallIsInTheSameLine(){
    when(mock.otherMethod()).thenReturn("foo");
    mockTwo.simpleMethod("foo");
    verify(mockTwo).simpleMethod(mock.otherMethod());
    try {
      verify(mockTwo,never()).simpleMethod(mock.otherMethod());
      fail();
    }
 catch (    NeverWantedButInvoked e) {
    }
  }
}
