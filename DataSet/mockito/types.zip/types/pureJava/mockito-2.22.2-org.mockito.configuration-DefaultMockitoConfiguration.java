/** 
 * DefaultConfiguration of Mockito framework <p> Currently it doesn't have many configuration options but it will probably change if future. <p> See javadocs for  {@link IMockitoConfiguration} on info how to configure Mockito
 */
public class DefaultMockitoConfiguration implements IMockitoConfiguration {
  public Answer<Object> getDefaultAnswer(){
    return new ReturnsEmptyValues();
  }
  public AnnotationEngine getAnnotationEngine(){
    return new InjectingAnnotationEngine();
  }
  public boolean cleansStackTrace(){
    return true;
  }
  public boolean enableClassCache(){
    return true;
  }
}
