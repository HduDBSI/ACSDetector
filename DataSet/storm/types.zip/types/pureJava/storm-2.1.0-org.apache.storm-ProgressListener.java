/** 
 * Interface use to track progress of file upload.
 */
public interface ProgressListener {
  /** 
 * called before file is uploaded.
 * @param srcFile    - jar file to be uploaded
 * @param targetFile - destination file
 * @param totalBytes - total number of bytes of the file
 */
  public void onStart(  String srcFile,  String targetFile,  long totalBytes);
  /** 
 * called whenever a chunk of bytes is uploaded.
 * @param srcFile       - jar file to be uploaded
 * @param targetFile    - destination file
 * @param bytesUploaded - number of bytes transferred so far
 * @param totalBytes    - total number of bytes of the file
 */
  public void onProgress(  String srcFile,  String targetFile,  long bytesUploaded,  long totalBytes);
  /** 
 * called when the file is uploaded.
 * @param srcFile    - jar file to be uploaded
 * @param targetFile - destination file
 * @param totalBytes - total number of bytes of the file
 */
  public void onCompleted(  String srcFile,  String targetFile,  long totalBytes);
}
