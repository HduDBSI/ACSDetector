private static class TopologySummaryStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public TopologySummaryStandardScheme getScheme(){
    return new TopologySummaryStandardScheme();
  }
}
