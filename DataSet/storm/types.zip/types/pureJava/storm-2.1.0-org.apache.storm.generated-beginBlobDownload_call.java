public static class beginBlobDownload_call extends org.apache.storm.thrift.async.TAsyncMethodCall<BeginDownloadResult> {
  private java.lang.String key;
  public beginBlobDownload_call(  java.lang.String key,  org.apache.storm.thrift.async.AsyncMethodCallback<BeginDownloadResult> resultHandler,  org.apache.storm.thrift.async.TAsyncClient client,  org.apache.storm.thrift.protocol.TProtocolFactory protocolFactory,  org.apache.storm.thrift.transport.TNonblockingTransport transport) throws org.apache.storm.thrift.TException {
    super(client,protocolFactory,transport,resultHandler,false);
    this.key=key;
  }
  public void write_args(  org.apache.storm.thrift.protocol.TProtocol prot) throws org.apache.storm.thrift.TException {
    prot.writeMessageBegin(new org.apache.storm.thrift.protocol.TMessage("beginBlobDownload",org.apache.storm.thrift.protocol.TMessageType.CALL,0));
    beginBlobDownload_args args=new beginBlobDownload_args();
    args.set_key(key);
    args.write(prot);
    prot.writeMessageEnd();
  }
  public BeginDownloadResult getResult() throws AuthorizationException, KeyNotFoundException, org.apache.storm.thrift.TException {
    if (getState() != org.apache.storm.thrift.async.TAsyncMethodCall.State.RESPONSE_READ) {
      throw new java.lang.IllegalStateException("Method call not finished!");
    }
    org.apache.storm.thrift.transport.TMemoryInputTransport memoryTransport=new org.apache.storm.thrift.transport.TMemoryInputTransport(getFrameBuffer().array());
    org.apache.storm.thrift.protocol.TProtocol prot=client.getProtocolFactory().getProtocol(memoryTransport);
    return (new Client(prot)).recv_beginBlobDownload();
  }
}
