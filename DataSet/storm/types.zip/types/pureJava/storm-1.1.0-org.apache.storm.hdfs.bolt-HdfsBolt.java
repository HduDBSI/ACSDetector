public class HdfsBolt extends AbstractHdfsBolt {
  private static final Logger LOG=LoggerFactory.getLogger(HdfsBolt.class);
  private transient FSDataOutputStream out;
  private RecordFormat format;
  public HdfsBolt withFsUrl(  String fsUrl){
    this.fsUrl=fsUrl;
    return this;
  }
  public HdfsBolt withConfigKey(  String configKey){
    this.configKey=configKey;
    return this;
  }
  public HdfsBolt withFileNameFormat(  FileNameFormat fileNameFormat){
    this.fileNameFormat=fileNameFormat;
    return this;
  }
  public HdfsBolt withRecordFormat(  RecordFormat format){
    this.format=format;
    return this;
  }
  public HdfsBolt withSyncPolicy(  SyncPolicy syncPolicy){
    this.syncPolicy=syncPolicy;
    return this;
  }
  public HdfsBolt withRotationPolicy(  FileRotationPolicy rotationPolicy){
    this.rotationPolicy=rotationPolicy;
    return this;
  }
  public HdfsBolt addRotationAction(  RotationAction action){
    this.rotationActions.add(action);
    return this;
  }
  public HdfsBolt withTickTupleIntervalSeconds(  int interval){
    this.tickTupleInterval=interval;
    return this;
  }
  public HdfsBolt withRetryCount(  int fileRetryCount){
    this.fileRetryCount=fileRetryCount;
    return this;
  }
  public HdfsBolt withPartitioner(  Partitioner partitioner){
    this.partitioner=partitioner;
    return this;
  }
  public HdfsBolt withMaxOpenFiles(  int maxOpenFiles){
    this.maxOpenFiles=maxOpenFiles;
    return this;
  }
  @Override public void doPrepare(  Map conf,  TopologyContext topologyContext,  OutputCollector collector) throws IOException {
    LOG.info("Preparing HDFS Bolt...");
    this.fs=FileSystem.get(URI.create(this.fsUrl),hdfsConfig);
  }
  @Override protected String getWriterKey(  Tuple tuple){
    return "CONSTANT";
  }
  @Override protected AbstractHDFSWriter makeNewWriter(  Path path,  Tuple tuple) throws IOException {
    this.out=this.fs.create(path);
    return new HDFSWriter(rotationPolicy,path,out,format);
  }
}
