private static class StateSpoutSpecTupleScheme extends org.apache.storm.thrift.scheme.TupleScheme<StateSpoutSpec> {
  @Override public void write(  org.apache.storm.thrift.protocol.TProtocol prot,  StateSpoutSpec struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
    struct.state_spout_object.write(oprot);
    struct.common.write(oprot);
  }
  @Override public void read(  org.apache.storm.thrift.protocol.TProtocol prot,  StateSpoutSpec struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
    struct.state_spout_object=new ComponentObject();
    struct.state_spout_object.read(iprot);
    struct.set_state_spout_object_isSet(true);
    struct.common=new ComponentCommon();
    struct.common.read(iprot);
    struct.set_common_isSet(true);
  }
}
