private static class getClusterInfo_argsStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public getClusterInfo_argsStandardScheme getScheme(){
    return new getClusterInfo_argsStandardScheme();
  }
}
