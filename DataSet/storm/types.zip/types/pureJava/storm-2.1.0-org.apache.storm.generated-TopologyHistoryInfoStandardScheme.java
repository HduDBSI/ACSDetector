private static class TopologyHistoryInfoStandardScheme extends org.apache.storm.thrift.scheme.StandardScheme<TopologyHistoryInfo> {
  public void read(  org.apache.storm.thrift.protocol.TProtocol iprot,  TopologyHistoryInfo struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TField schemeField;
    iprot.readStructBegin();
    while (true) {
      schemeField=iprot.readFieldBegin();
      if (schemeField.type == org.apache.storm.thrift.protocol.TType.STOP) {
        break;
      }
switch (schemeField.id) {
case 1:
        if (schemeField.type == org.apache.storm.thrift.protocol.TType.LIST) {
{
            org.apache.storm.thrift.protocol.TList _list862=iprot.readListBegin();
            struct.topo_ids=new java.util.ArrayList<java.lang.String>(_list862.size);
            @org.apache.storm.thrift.annotation.Nullable java.lang.String _elem863;
            for (int _i864=0; _i864 < _list862.size; ++_i864) {
              _elem863=iprot.readString();
              struct.topo_ids.add(_elem863);
            }
            iprot.readListEnd();
          }
          struct.set_topo_ids_isSet(true);
        }
 else {
          org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
        }
      break;
default :
    org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
iprot.readFieldEnd();
}
iprot.readStructEnd();
struct.validate();
}
public void write(org.apache.storm.thrift.protocol.TProtocol oprot,TopologyHistoryInfo struct) throws org.apache.storm.thrift.TException {
struct.validate();
oprot.writeStructBegin(STRUCT_DESC);
if (struct.topo_ids != null) {
oprot.writeFieldBegin(TOPO_IDS_FIELD_DESC);
{
  oprot.writeListBegin(new org.apache.storm.thrift.protocol.TList(org.apache.storm.thrift.protocol.TType.STRING,struct.topo_ids.size()));
  for (  java.lang.String _iter865 : struct.topo_ids) {
    oprot.writeString(_iter865);
  }
  oprot.writeListEnd();
}
oprot.writeFieldEnd();
}
oprot.writeFieldStop();
oprot.writeStructEnd();
}
}
