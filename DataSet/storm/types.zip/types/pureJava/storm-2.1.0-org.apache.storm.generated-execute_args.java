public static class execute_args implements org.apache.storm.thrift.TBase<execute_args,execute_args._Fields>, java.io.Serializable, Cloneable, Comparable<execute_args> {
  private static final org.apache.storm.thrift.protocol.TStruct STRUCT_DESC=new org.apache.storm.thrift.protocol.TStruct("execute_args");
  private static final org.apache.storm.thrift.protocol.TField FUNCTION_NAME_FIELD_DESC=new org.apache.storm.thrift.protocol.TField("functionName",org.apache.storm.thrift.protocol.TType.STRING,(short)1);
  private static final org.apache.storm.thrift.protocol.TField FUNC_ARGS_FIELD_DESC=new org.apache.storm.thrift.protocol.TField("funcArgs",org.apache.storm.thrift.protocol.TType.STRING,(short)2);
  private static final org.apache.storm.thrift.scheme.SchemeFactory STANDARD_SCHEME_FACTORY=new execute_argsStandardSchemeFactory();
  private static final org.apache.storm.thrift.scheme.SchemeFactory TUPLE_SCHEME_FACTORY=new execute_argsTupleSchemeFactory();
  private @org.apache.storm.thrift.annotation.Nullable java.lang.String functionName;
  private @org.apache.storm.thrift.annotation.Nullable java.lang.String funcArgs;
  /** 
 * The set of fields this struct contains, along with convenience methods for finding and manipulating them. 
 */
  public enum _Fields implements org.apache.storm.thrift.TFieldIdEnum {  FUNCTION_NAME((short)1,"functionName"),   FUNC_ARGS((short)2,"funcArgs");   private static final java.util.Map<java.lang.String,_Fields> byName=new java.util.HashMap<java.lang.String,_Fields>();
static {
    for (    _Fields field : java.util.EnumSet.allOf(_Fields.class)) {
      byName.put(field.getFieldName(),field);
    }
  }
  /** 
 * Find the _Fields constant that matches fieldId, or null if its not found.
 */
  @org.apache.storm.thrift.annotation.Nullable public static _Fields findByThriftId(  int fieldId){
switch (fieldId) {
case 1:
      return FUNCTION_NAME;
case 2:
    return FUNC_ARGS;
default :
  return null;
}
}
/** 
 * Find the _Fields constant that matches fieldId, throwing an exception if it is not found.
 */
public static _Fields findByThriftIdOrThrow(int fieldId){
_Fields fields=findByThriftId(fieldId);
if (fields == null) throw new java.lang.IllegalArgumentException("Field " + fieldId + " doesn't exist!");
return fields;
}
/** 
 * Find the _Fields constant that matches name, or null if its not found.
 */
@org.apache.storm.thrift.annotation.Nullable public static _Fields findByName(java.lang.String name){
return byName.get(name);
}
private final short _thriftId;
private final java.lang.String _fieldName;
_Fields(short thriftId,java.lang.String fieldName){
_thriftId=thriftId;
_fieldName=fieldName;
}
public short getThriftFieldId(){
return _thriftId;
}
public java.lang.String getFieldName(){
return _fieldName;
}
}
public static final java.util.Map<_Fields,org.apache.storm.thrift.meta_data.FieldMetaData> metaDataMap;
static {
java.util.Map<_Fields,org.apache.storm.thrift.meta_data.FieldMetaData> tmpMap=new java.util.EnumMap<_Fields,org.apache.storm.thrift.meta_data.FieldMetaData>(_Fields.class);
tmpMap.put(_Fields.FUNCTION_NAME,new org.apache.storm.thrift.meta_data.FieldMetaData("functionName",org.apache.storm.thrift.TFieldRequirementType.DEFAULT,new org.apache.storm.thrift.meta_data.FieldValueMetaData(org.apache.storm.thrift.protocol.TType.STRING)));
tmpMap.put(_Fields.FUNC_ARGS,new org.apache.storm.thrift.meta_data.FieldMetaData("funcArgs",org.apache.storm.thrift.TFieldRequirementType.DEFAULT,new org.apache.storm.thrift.meta_data.FieldValueMetaData(org.apache.storm.thrift.protocol.TType.STRING)));
metaDataMap=java.util.Collections.unmodifiableMap(tmpMap);
org.apache.storm.thrift.meta_data.FieldMetaData.addStructMetaDataMap(execute_args.class,metaDataMap);
}
public execute_args(){
}
public execute_args(java.lang.String functionName,java.lang.String funcArgs){
this();
this.functionName=functionName;
this.funcArgs=funcArgs;
}
/** 
 * Performs a deep copy on <i>other</i>.
 */
public execute_args(execute_args other){
if (other.is_set_functionName()) {
this.functionName=other.functionName;
}
if (other.is_set_funcArgs()) {
this.funcArgs=other.funcArgs;
}
}
public execute_args deepCopy(){
return new execute_args(this);
}
@Override public void clear(){
this.functionName=null;
this.funcArgs=null;
}
@org.apache.storm.thrift.annotation.Nullable public java.lang.String get_functionName(){
return this.functionName;
}
public void set_functionName(@org.apache.storm.thrift.annotation.Nullable java.lang.String functionName){
this.functionName=functionName;
}
public void unset_functionName(){
this.functionName=null;
}
/** 
 * Returns true if field functionName is set (has been assigned a value) and false otherwise 
 */
public boolean is_set_functionName(){
return this.functionName != null;
}
public void set_functionName_isSet(boolean value){
if (!value) {
this.functionName=null;
}
}
@org.apache.storm.thrift.annotation.Nullable public java.lang.String get_funcArgs(){
return this.funcArgs;
}
public void set_funcArgs(@org.apache.storm.thrift.annotation.Nullable java.lang.String funcArgs){
this.funcArgs=funcArgs;
}
public void unset_funcArgs(){
this.funcArgs=null;
}
/** 
 * Returns true if field funcArgs is set (has been assigned a value) and false otherwise 
 */
public boolean is_set_funcArgs(){
return this.funcArgs != null;
}
public void set_funcArgs_isSet(boolean value){
if (!value) {
this.funcArgs=null;
}
}
public void setFieldValue(_Fields field,@org.apache.storm.thrift.annotation.Nullable java.lang.Object value){
switch (field) {
case FUNCTION_NAME:
if (value == null) {
  unset_functionName();
}
 else {
  set_functionName((java.lang.String)value);
}
break;
case FUNC_ARGS:
if (value == null) {
unset_funcArgs();
}
 else {
set_funcArgs((java.lang.String)value);
}
break;
}
}
@org.apache.storm.thrift.annotation.Nullable public java.lang.Object getFieldValue(_Fields field){
switch (field) {
case FUNCTION_NAME:
return get_functionName();
case FUNC_ARGS:
return get_funcArgs();
}
throw new java.lang.IllegalStateException();
}
/** 
 * Returns true if field corresponding to fieldID is set (has been assigned a value) and false otherwise 
 */
public boolean isSet(_Fields field){
if (field == null) {
throw new java.lang.IllegalArgumentException();
}
switch (field) {
case FUNCTION_NAME:
return is_set_functionName();
case FUNC_ARGS:
return is_set_funcArgs();
}
throw new java.lang.IllegalStateException();
}
@Override public boolean equals(java.lang.Object that){
if (that == null) return false;
if (that instanceof execute_args) return this.equals((execute_args)that);
return false;
}
public boolean equals(execute_args that){
if (that == null) return false;
if (this == that) return true;
boolean this_present_functionName=true && this.is_set_functionName();
boolean that_present_functionName=true && that.is_set_functionName();
if (this_present_functionName || that_present_functionName) {
if (!(this_present_functionName && that_present_functionName)) return false;
if (!this.functionName.equals(that.functionName)) return false;
}
boolean this_present_funcArgs=true && this.is_set_funcArgs();
boolean that_present_funcArgs=true && that.is_set_funcArgs();
if (this_present_funcArgs || that_present_funcArgs) {
if (!(this_present_funcArgs && that_present_funcArgs)) return false;
if (!this.funcArgs.equals(that.funcArgs)) return false;
}
return true;
}
@Override public int hashCode(){
int hashCode=1;
hashCode=hashCode * 8191 + ((is_set_functionName()) ? 131071 : 524287);
if (is_set_functionName()) hashCode=hashCode * 8191 + functionName.hashCode();
hashCode=hashCode * 8191 + ((is_set_funcArgs()) ? 131071 : 524287);
if (is_set_funcArgs()) hashCode=hashCode * 8191 + funcArgs.hashCode();
return hashCode;
}
@Override public int compareTo(execute_args other){
if (!getClass().equals(other.getClass())) {
return getClass().getName().compareTo(other.getClass().getName());
}
int lastComparison=0;
lastComparison=java.lang.Boolean.valueOf(is_set_functionName()).compareTo(other.is_set_functionName());
if (lastComparison != 0) {
return lastComparison;
}
if (is_set_functionName()) {
lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.functionName,other.functionName);
if (lastComparison != 0) {
return lastComparison;
}
}
lastComparison=java.lang.Boolean.valueOf(is_set_funcArgs()).compareTo(other.is_set_funcArgs());
if (lastComparison != 0) {
return lastComparison;
}
if (is_set_funcArgs()) {
lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.funcArgs,other.funcArgs);
if (lastComparison != 0) {
return lastComparison;
}
}
return 0;
}
@org.apache.storm.thrift.annotation.Nullable public _Fields fieldForId(int fieldId){
return _Fields.findByThriftId(fieldId);
}
public void read(org.apache.storm.thrift.protocol.TProtocol iprot) throws org.apache.storm.thrift.TException {
scheme(iprot).read(iprot,this);
}
public void write(org.apache.storm.thrift.protocol.TProtocol oprot) throws org.apache.storm.thrift.TException {
scheme(oprot).write(oprot,this);
}
@Override public java.lang.String toString(){
java.lang.StringBuilder sb=new java.lang.StringBuilder("execute_args(");
boolean first=true;
sb.append("functionName:");
if (this.functionName == null) {
sb.append("null");
}
 else {
sb.append(this.functionName);
}
first=false;
if (!first) sb.append(", ");
sb.append("funcArgs:");
if (this.funcArgs == null) {
sb.append("null");
}
 else {
sb.append(this.funcArgs);
}
first=false;
sb.append(")");
return sb.toString();
}
public void validate() throws org.apache.storm.thrift.TException {
}
private void writeObject(java.io.ObjectOutputStream out) throws java.io.IOException {
try {
write(new org.apache.storm.thrift.protocol.TCompactProtocol(new org.apache.storm.thrift.transport.TIOStreamTransport(out)));
}
 catch (org.apache.storm.thrift.TException te) {
throw new java.io.IOException(te);
}
}
private void readObject(java.io.ObjectInputStream in) throws java.io.IOException, java.lang.ClassNotFoundException {
try {
read(new org.apache.storm.thrift.protocol.TCompactProtocol(new org.apache.storm.thrift.transport.TIOStreamTransport(in)));
}
 catch (org.apache.storm.thrift.TException te) {
throw new java.io.IOException(te);
}
}
private static class execute_argsStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
public execute_argsStandardScheme getScheme(){
return new execute_argsStandardScheme();
}
}
private static class execute_argsStandardScheme extends org.apache.storm.thrift.scheme.StandardScheme<execute_args> {
public void read(org.apache.storm.thrift.protocol.TProtocol iprot,execute_args struct) throws org.apache.storm.thrift.TException {
org.apache.storm.thrift.protocol.TField schemeField;
iprot.readStructBegin();
while (true) {
schemeField=iprot.readFieldBegin();
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STOP) {
break;
}
switch (schemeField.id) {
case 1:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
struct.functionName=iprot.readString();
struct.set_functionName_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 2:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
struct.funcArgs=iprot.readString();
struct.set_funcArgs_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
default :
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
iprot.readFieldEnd();
}
iprot.readStructEnd();
struct.validate();
}
public void write(org.apache.storm.thrift.protocol.TProtocol oprot,execute_args struct) throws org.apache.storm.thrift.TException {
struct.validate();
oprot.writeStructBegin(STRUCT_DESC);
if (struct.functionName != null) {
oprot.writeFieldBegin(FUNCTION_NAME_FIELD_DESC);
oprot.writeString(struct.functionName);
oprot.writeFieldEnd();
}
if (struct.funcArgs != null) {
oprot.writeFieldBegin(FUNC_ARGS_FIELD_DESC);
oprot.writeString(struct.funcArgs);
oprot.writeFieldEnd();
}
oprot.writeFieldStop();
oprot.writeStructEnd();
}
}
private static class execute_argsTupleSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
public execute_argsTupleScheme getScheme(){
return new execute_argsTupleScheme();
}
}
private static class execute_argsTupleScheme extends org.apache.storm.thrift.scheme.TupleScheme<execute_args> {
@Override public void write(org.apache.storm.thrift.protocol.TProtocol prot,execute_args struct) throws org.apache.storm.thrift.TException {
org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
java.util.BitSet optionals=new java.util.BitSet();
if (struct.is_set_functionName()) {
optionals.set(0);
}
if (struct.is_set_funcArgs()) {
optionals.set(1);
}
oprot.writeBitSet(optionals,2);
if (struct.is_set_functionName()) {
oprot.writeString(struct.functionName);
}
if (struct.is_set_funcArgs()) {
oprot.writeString(struct.funcArgs);
}
}
@Override public void read(org.apache.storm.thrift.protocol.TProtocol prot,execute_args struct) throws org.apache.storm.thrift.TException {
org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
java.util.BitSet incoming=iprot.readBitSet(2);
if (incoming.get(0)) {
struct.functionName=iprot.readString();
struct.set_functionName_isSet(true);
}
if (incoming.get(1)) {
struct.funcArgs=iprot.readString();
struct.set_funcArgs_isSet(true);
}
}
}
private static <S extends org.apache.storm.thrift.scheme.IScheme>S scheme(org.apache.storm.thrift.protocol.TProtocol proto){
return (org.apache.storm.thrift.scheme.StandardScheme.class.equals(proto.getScheme()) ? STANDARD_SCHEME_FACTORY : TUPLE_SCHEME_FACTORY).getScheme();
}
}
