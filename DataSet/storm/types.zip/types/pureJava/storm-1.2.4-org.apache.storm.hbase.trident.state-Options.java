public static class Options implements Serializable {
  private TridentHBaseMapper mapper;
  private Durability durability=Durability.SKIP_WAL;
  private HBaseProjectionCriteria projectionCriteria;
  private HBaseValueMapper rowToStormValueMapper;
  private String configKey;
  private String tableName;
  public Options withDurability(  Durability durability){
    this.durability=durability;
    return this;
  }
  public Options withProjectionCriteria(  HBaseProjectionCriteria projectionCriteria){
    this.projectionCriteria=projectionCriteria;
    return this;
  }
  public Options withConfigKey(  String configKey){
    this.configKey=configKey;
    return this;
  }
  public Options withTableName(  String tableName){
    this.tableName=tableName;
    return this;
  }
  public Options withRowToStormValueMapper(  HBaseValueMapper rowToStormValueMapper){
    this.rowToStormValueMapper=rowToStormValueMapper;
    return this;
  }
  public Options withMapper(  TridentHBaseMapper mapper){
    this.mapper=mapper;
    return this;
  }
}
