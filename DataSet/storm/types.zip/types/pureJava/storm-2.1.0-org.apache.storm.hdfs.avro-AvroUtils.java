public class AvroUtils {
  /** 
 * A helper method to extract avro serialization configurations from the topology configuration and register specific kryo serializers as necessary.  A default serializer will be provided if none is specified in the configuration.  "avro.serializer" should specify the complete class name of the serializer, e.g. "org.apache.stgorm.hdfs.avro.GenericAvroSerializer"
 * @param conf The topology configuration
 * @throws ClassNotFoundException If the specified serializer cannot be located.
 */
  public static void addAvroKryoSerializations(  Config conf) throws ClassNotFoundException {
    final Class serializerClass;
    if (conf.containsKey("avro.serializer")) {
      serializerClass=Class.forName((String)conf.get("avro.serializer"));
    }
 else {
      serializerClass=GenericAvroSerializer.class;
    }
    conf.registerSerialization(GenericData.Record.class,serializerClass);
    conf.setSkipMissingKryoRegistrations(false);
  }
}
