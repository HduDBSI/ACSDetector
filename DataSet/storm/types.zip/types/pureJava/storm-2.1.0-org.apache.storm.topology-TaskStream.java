static class TaskStream {
  private int sourceTask;
  private GlobalStreamId streamId;
  TaskStream(){
  }
  TaskStream(  int sourceTask,  GlobalStreamId streamId){
    this.sourceTask=sourceTask;
    this.streamId=streamId;
  }
  static TaskStream fromTuple(  Tuple input){
    return new TaskStream(input.getSourceTask(),input.getSourceGlobalStreamId());
  }
  @Override public boolean equals(  Object o){
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TaskStream that=(TaskStream)o;
    if (sourceTask != that.sourceTask) {
      return false;
    }
    return streamId != null ? streamId.equals(that.streamId) : that.streamId == null;
  }
  @Override public int hashCode(){
    int result=streamId != null ? streamId.hashCode() : 0;
    result=31 * result + sourceTask;
    return result;
  }
  @Override public String toString(){
    return "TaskStream{" + "sourceTask=" + sourceTask + ", streamId="+ streamId+ '}';
  }
}
