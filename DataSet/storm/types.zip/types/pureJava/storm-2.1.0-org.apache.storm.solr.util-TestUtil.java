public class TestUtil {
  public static String getDate(){
    DateFormat df=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
    return df.format(new Date());
  }
}
