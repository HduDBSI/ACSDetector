public class WordSpout implements IRichSpout {
  boolean isDistributed;
  SpoutOutputCollector collector;
  public static final String[] words=new String[]{"apple","orange","pineapple","banana","watermelon"};
  public WordSpout(){
    this(true);
  }
  public WordSpout(  boolean isDistributed){
    this.isDistributed=isDistributed;
  }
  public boolean isDistributed(){
    return this.isDistributed;
  }
  public void open(  Map<String,Object> conf,  TopologyContext context,  SpoutOutputCollector collector){
    this.collector=collector;
  }
  public void close(){
  }
  public void nextTuple(){
    final Random rand=new Random();
    final String word=words[rand.nextInt(words.length)];
    this.collector.emit(new Values(word),UUID.randomUUID());
    Thread.yield();
  }
  public void ack(  Object msgId){
  }
  public void fail(  Object msgId){
  }
  public void declareOutputFields(  OutputFieldsDeclarer declarer){
    declarer.declare(new Fields("word"));
  }
  @Override public void activate(){
  }
  @Override public void deactivate(){
  }
  @Override public Map<String,Object> getComponentConfiguration(){
    return null;
  }
}
