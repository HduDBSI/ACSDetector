private static class LSSupervisorAssignmentsTupleSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public LSSupervisorAssignmentsTupleScheme getScheme(){
    return new LSSupervisorAssignmentsTupleScheme();
  }
}
