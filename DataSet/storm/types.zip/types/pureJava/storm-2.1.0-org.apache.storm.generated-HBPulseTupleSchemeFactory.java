private static class HBPulseTupleSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public HBPulseTupleScheme getScheme(){
    return new HBPulseTupleScheme();
  }
}
