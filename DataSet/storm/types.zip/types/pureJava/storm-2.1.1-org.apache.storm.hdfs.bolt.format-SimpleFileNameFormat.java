public class SimpleFileNameFormat implements FileNameFormat {
  private static final long serialVersionUID=1L;
  private String componentId;
  private int taskId;
  private String host;
  private String path="/storm";
  private String name="$TIME.$NUM.txt";
  private String timeFormat="yyyyMMddHHmmss";
  @Override public String getName(  long rotation,  long timeStamp){
    SimpleDateFormat dateFormat=new SimpleDateFormat(timeFormat);
    String ret=name.replace("$TIME",dateFormat.format(new Date(timeStamp))).replace("$NUM",String.valueOf(rotation)).replace("$HOST",host).replace("$COMPONENT",componentId).replace("$TASK",String.valueOf(taskId));
    return ret;
  }
  @Override public String getPath(){
    return path;
  }
  @SuppressWarnings("unchecked") @Override public void prepare(  Map<String,Object> conf,  TopologyContext topologyContext){
    this.componentId=topologyContext.getThisComponentId();
    this.taskId=topologyContext.getThisTaskId();
    try {
      this.host=Utils.localHostname();
    }
 catch (    UnknownHostException e) {
      throw new RuntimeException(e);
    }
  }
  public SimpleFileNameFormat withPath(  String path){
    this.path=path;
    return this;
  }
  /** 
 * support parameters:<br/> $TIME - current time. use <code>withTimeFormat</code> to format.<br/> $NUM - rotation number<br/> $HOST - local host name<br/> $COMPONENT - component id<br/> $TASK - task id<br/>
 * @param name file name
 */
  public SimpleFileNameFormat withName(  String name){
    this.name=name;
    return this;
  }
  public SimpleFileNameFormat withTimeFormat(  String timeFormat){
    try {
      new SimpleDateFormat(timeFormat);
    }
 catch (    Exception e) {
      throw new IllegalArgumentException("invalid timeFormat: " + e.getMessage());
    }
    this.timeFormat=timeFormat;
    return this;
  }
}
