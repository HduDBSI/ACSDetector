private static class TransactionRequest {
  private final CheckPointState.Action action;
  private final long txid;
  TransactionRequest(  CheckPointState.Action action,  long txid){
    this.action=action;
    this.txid=txid;
  }
  @Override public boolean equals(  Object o){
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TransactionRequest that=(TransactionRequest)o;
    if (txid != that.txid) {
      return false;
    }
    return !(action != null ? !action.equals(that.action) : that.action != null);
  }
  @Override public int hashCode(){
    int result=action != null ? action.hashCode() : 0;
    result=31 * result + (int)(txid ^ (txid >>> 32));
    return result;
  }
  @Override public String toString(){
    return "TransactionRequest{" + "action='" + action + '\''+ ", txid="+ txid+ '}';
  }
}
