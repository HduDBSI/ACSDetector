public interface MultiReducer<T> extends Serializable {
  void prepare(  Map<String,Object> conf,  TridentMultiReducerContext context);
  T init(  TridentCollector collector);
  void execute(  T state,  int streamIndex,  TridentTuple input,  TridentCollector collector);
  void complete(  T state,  TridentCollector collector);
  void cleanup();
}
