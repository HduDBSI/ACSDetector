public class FeederSpout extends BaseRichSpout {
  private int id;
  private Fields outFields;
  private SpoutOutputCollector collector;
  private AckFailDelegate ackFailDelegate;
  public FeederSpout(  List<String> outFields){
    this(new Fields(outFields));
  }
  public FeederSpout(  Fields outFields){
    id=InprocMessaging.acquireNewPort();
    this.outFields=outFields;
  }
  public void setAckFailDelegate(  AckFailDelegate d){
    ackFailDelegate=d;
  }
  public void feed(  List<Object> tuple){
    feed(tuple,UUID.randomUUID().toString());
  }
  public void feed(  List<Object> tuple,  Object msgId){
    InprocMessaging.sendMessage(id,new Values(tuple,msgId));
  }
  public void feedNoWait(  List<Object> tuple,  Object msgId){
    InprocMessaging.sendMessageNoWait(id,new Values(tuple,msgId));
  }
  public void waitForReader(){
    InprocMessaging.waitForReader(id);
  }
  @Override public void open(  Map<String,Object> conf,  TopologyContext context,  SpoutOutputCollector collector){
    this.collector=collector;
  }
  @Override public void close(){
  }
  @Override public void nextTuple(){
    List<Object> toEmit=(List<Object>)InprocMessaging.pollMessage(id);
    if (toEmit != null) {
      List<Object> tuple=(List<Object>)toEmit.get(0);
      Object msgId=toEmit.get(1);
      collector.emit(tuple,msgId);
    }
  }
  @Override public void ack(  Object msgId){
    if (ackFailDelegate != null) {
      ackFailDelegate.ack(msgId);
    }
  }
  @Override public void fail(  Object msgId){
    if (ackFailDelegate != null) {
      ackFailDelegate.fail(msgId);
    }
  }
  @Override public void declareOutputFields(  OutputFieldsDeclarer declarer){
    declarer.declare(outFields);
  }
  @Override public Map<String,Object> getComponentConfiguration(){
    return new HashMap<String,Object>();
  }
}
