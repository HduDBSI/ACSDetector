/** 
 * The StormSql class provides standalone, interactive interfaces to execute SQL statements over streaming data. <p>The StormSql class is stateless. The user needs to submit the data definition language (DDL) statements and the query statements in the same batch.
 */
public abstract class StormSql {
  public static StormSql construct(){
    return new StormSqlImpl();
  }
  /** 
 * Submit the SQL statements to Nimbus and run it as a topology.
 */
  public abstract void submit(  String name,  Iterable<String> statements,  Map<String,Object> topoConf,  SubmitOptions opts,  StormSubmitter.ProgressListener progressListener,  String asUser) throws Exception ;
  /** 
 * Print out query plan for each query.
 */
  public abstract void explain(  Iterable<String> statements) throws Exception ;
}
