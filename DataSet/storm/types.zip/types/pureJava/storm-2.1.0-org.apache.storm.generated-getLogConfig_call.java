public static class getLogConfig_call extends org.apache.storm.thrift.async.TAsyncMethodCall<LogConfig> {
  private java.lang.String name;
  public getLogConfig_call(  java.lang.String name,  org.apache.storm.thrift.async.AsyncMethodCallback<LogConfig> resultHandler,  org.apache.storm.thrift.async.TAsyncClient client,  org.apache.storm.thrift.protocol.TProtocolFactory protocolFactory,  org.apache.storm.thrift.transport.TNonblockingTransport transport) throws org.apache.storm.thrift.TException {
    super(client,protocolFactory,transport,resultHandler,false);
    this.name=name;
  }
  public void write_args(  org.apache.storm.thrift.protocol.TProtocol prot) throws org.apache.storm.thrift.TException {
    prot.writeMessageBegin(new org.apache.storm.thrift.protocol.TMessage("getLogConfig",org.apache.storm.thrift.protocol.TMessageType.CALL,0));
    getLogConfig_args args=new getLogConfig_args();
    args.set_name(name);
    args.write(prot);
    prot.writeMessageEnd();
  }
  public LogConfig getResult() throws org.apache.storm.thrift.TException {
    if (getState() != org.apache.storm.thrift.async.TAsyncMethodCall.State.RESPONSE_READ) {
      throw new java.lang.IllegalStateException("Method call not finished!");
    }
    org.apache.storm.thrift.transport.TMemoryInputTransport memoryTransport=new org.apache.storm.thrift.transport.TMemoryInputTransport(getFrameBuffer().array());
    org.apache.storm.thrift.protocol.TProtocol prot=client.getProtocolFactory().getProtocol(memoryTransport);
    return (new Client(prot)).recv_getLogConfig();
  }
}
