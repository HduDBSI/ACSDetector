private static class getTopologyHistory_argsStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public getTopologyHistory_argsStandardScheme getScheme(){
    return new getTopologyHistory_argsStandardScheme();
  }
}
