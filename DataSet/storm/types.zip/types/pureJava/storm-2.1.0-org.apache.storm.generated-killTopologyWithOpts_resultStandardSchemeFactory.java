private static class killTopologyWithOpts_resultStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public killTopologyWithOpts_resultStandardScheme getScheme(){
    return new killTopologyWithOpts_resultStandardScheme();
  }
}
