public class TotalWordCounter implements IBasicBolt {
  private BigInteger total=BigInteger.ZERO;
  private static final Logger LOG=LoggerFactory.getLogger(TotalWordCounter.class);
  private static final Random RANDOM=new Random();
  @SuppressWarnings("rawtypes") public void prepare(  Map stormConf,  TopologyContext context){
  }
  public void execute(  Tuple input,  BasicOutputCollector collector){
    total=total.add(new BigInteger(input.getValues().get(1).toString()));
    collector.emit(tuple(total.toString()));
    if (RANDOM.nextInt(1000) > 995) {
      LOG.info("Running total = " + total);
    }
  }
  public void cleanup(){
    LOG.info("Final total = " + total);
  }
  public void declareOutputFields(  OutputFieldsDeclarer declarer){
    declarer.declare(new Fields("total"));
  }
  @Override public Map<String,Object> getComponentConfiguration(){
    return null;
  }
}
