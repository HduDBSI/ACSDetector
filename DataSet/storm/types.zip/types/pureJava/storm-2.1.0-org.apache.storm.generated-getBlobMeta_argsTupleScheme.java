private static class getBlobMeta_argsTupleScheme extends org.apache.storm.thrift.scheme.TupleScheme<getBlobMeta_args> {
  @Override public void write(  org.apache.storm.thrift.protocol.TProtocol prot,  getBlobMeta_args struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
    java.util.BitSet optionals=new java.util.BitSet();
    if (struct.is_set_key()) {
      optionals.set(0);
    }
    oprot.writeBitSet(optionals,1);
    if (struct.is_set_key()) {
      oprot.writeString(struct.key);
    }
  }
  @Override public void read(  org.apache.storm.thrift.protocol.TProtocol prot,  getBlobMeta_args struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
    java.util.BitSet incoming=iprot.readBitSet(1);
    if (incoming.get(0)) {
      struct.key=iprot.readString();
      struct.set_key_isSet(true);
    }
  }
}
