public static class Factory implements org.apache.storm.thrift.async.TAsyncClientFactory<AsyncClient> {
  private org.apache.storm.thrift.async.TAsyncClientManager clientManager;
  private org.apache.storm.thrift.protocol.TProtocolFactory protocolFactory;
  public Factory(  org.apache.storm.thrift.async.TAsyncClientManager clientManager,  org.apache.storm.thrift.protocol.TProtocolFactory protocolFactory){
    this.clientManager=clientManager;
    this.protocolFactory=protocolFactory;
  }
  public AsyncClient getAsyncClient(  org.apache.storm.thrift.transport.TNonblockingTransport transport){
    return new AsyncClient(protocolFactory,clientManager,transport);
  }
}
