public class StormParser {
  public static final int DEFAULT_IDENTIFIER_MAX_LENGTH=128;
  private final StormParserImpl impl;
  /** 
 * Constructor.
 */
  public StormParser(  String s){
    this.impl=new StormParserImpl(new StringReader(s));
    this.impl.setTabSize(1);
    this.impl.setQuotedCasing(Lex.ORACLE.quotedCasing);
    this.impl.setUnquotedCasing(Lex.ORACLE.unquotedCasing);
    this.impl.setIdentifierMaxLength(DEFAULT_IDENTIFIER_MAX_LENGTH);
    this.impl.switchTo("DQID");
  }
  @VisibleForTesting public StormParserImpl impl(){
    return impl;
  }
}
