/** 
 * Factory to create instances of  {@code WindowsStore}.
 */
public interface WindowsStoreFactory extends Serializable {
  /** 
 * Creates a window store.
 * @param topoConf storm topology configuration passed in {@link org.apache.storm.trident.planner.TridentProcessor#prepare(Map,TopologyContext,TridentContext)}
 */
  public WindowsStore create(  Map<String,Object> topoConf);
}
