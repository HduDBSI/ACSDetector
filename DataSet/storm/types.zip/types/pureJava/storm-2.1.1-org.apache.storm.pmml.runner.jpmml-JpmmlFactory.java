public class JpmmlFactory {
  /** 
 * Creates a new  {@link PMML} object representing the PMML model defined in the XML {@link File} specified as argument.
 */
  public static PMML newPmml(  File file) throws JAXBException, SAXException, IOException {
    Objects.requireNonNull(file);
    return IOUtil.unmarshal(file);
  }
  /** 
 * Creates a new  {@link PMML} object representing the PMML model defined in the {@link InputStream} specified as argument.
 */
  public static PMML newPmml(  InputStream stream) throws JAXBException, SAXException, IOException {
    Objects.requireNonNull(stream);
    return IOUtil.unmarshal(stream);
  }
  /** 
 * Creates a new  {@link PMML} object representing the PMML model uploaded to the Blobstore with key specified asargument. Uses Storm config as returned by  {@code Utils.readStormConfig()} to get the Blobstore client.
 */
  public static PMML newPmml(  String blobKey) throws JAXBException, SAXException, IOException {
    return newPmml(blobKey,Utils.readStormConfig());
  }
  /** 
 * Creates a new  {@link PMML} object representing the PMML model uploaded to the Blobstore with key specified asargument. Uses the specified configuration to get the Blobstore client.
 */
  public static PMML newPmml(  String blobKey,  Map<String,Object> config) throws JAXBException, SAXException, IOException {
    Objects.requireNonNull(blobKey);
    Objects.requireNonNull(config);
    return newPmml(getPmmlModelBlob(blobKey,config));
  }
  /** 
 * Returns PMML model from Blobstore. Uses Storm config as returned by  {@code Utils.readStormConfig()}.
 * @param blobKey key of PMML model in Blobstore
 */
  public static InputStream getPmmlModelBlob(  String blobKey){
    return getPmmlModelBlob(blobKey,Utils.readStormConfig());
  }
  /** 
 * Returns PMML model from Blobstore.
 * @param blobKey key of PMML model in Blobstore
 * @param config Configuration to use to get Blobstore client
 */
  public static InputStream getPmmlModelBlob(  String blobKey,  Map<String,Object> config){
    Objects.requireNonNull(blobKey);
    Objects.requireNonNull(config);
    try {
      return Utils.getClientBlobStore(config).getBlob(blobKey);
    }
 catch (    Exception e) {
      throw new RuntimeException("Failed to download PMML Model from Blobstore using blob key [" + blobKey + "]",e);
    }
  }
  /** 
 * Creates a new  {@link Evaluator} object representing the PMML model defined in the {@link PMML} argument.
 */
  public static Evaluator newEvaluator(  PMML pmml){
    Objects.requireNonNull(pmml);
    final PMMLManager pmmlManager=new PMMLManager(pmml);
    return (ModelEvaluator<?>)pmmlManager.getModelManager(null,ModelEvaluatorFactory.getInstance());
  }
  /** 
 * Creates a new  {@link Evaluator} object representing the PMML model defined in the XML {@link File} specified asargument.
 */
  public static Evaluator newEvaluator(  File file) throws IOException, JAXBException, SAXException {
    Objects.requireNonNull(file);
    return newEvaluator(newPmml(file));
  }
  /** 
 * Creates a new  {@link Evaluator} object representing the PMML model defined in the XML {@link File} specified asargument.
 */
  public static Evaluator newEvaluator(  InputStream stream) throws IOException, JAXBException, SAXException {
    Objects.requireNonNull(stream);
    return newEvaluator(newPmml(stream));
  }
  /** 
 * Creates a new  {@link Evaluator} object representing the PMML model uploaded to the Blobstore using the blob keyspecified as argument. Uses Storm config as returned by  {@code Utils.readStormConfig()} to get the Blobstoreclient.
 */
  public static Evaluator newEvaluator(  String blobKey) throws IOException, JAXBException, SAXException {
    Objects.requireNonNull(blobKey);
    return newEvaluator(blobKey,Utils.readStormConfig());
  }
  /** 
 * Creates a new  {@link Evaluator} object representing the PMML model uploaded to the Blobstore using the blob keyspecified as argument. Uses the specified configuration to get the Blobstore client.
 */
  public static Evaluator newEvaluator(  String blobKey,  Map<String,Object> config) throws IOException, JAXBException, SAXException {
    Objects.requireNonNull(blobKey);
    Objects.requireNonNull(config);
    return newEvaluator(newPmml(blobKey,config));
  }
public static class ModelRunnerFromFile implements ModelRunnerFactory {
    private final File model;
    private final ModelOutputs outFields;
    public ModelRunnerFromFile(    File model,    ModelOutputs modelOutputs){
      Objects.requireNonNull(model);
      Objects.requireNonNull(modelOutputs);
      this.model=model;
      this.outFields=modelOutputs;
    }
    /** 
 * Creates a  {@link JPmmlModelRunner} writing to the default stream.
 */
    @Override public ModelRunner newModelRunner(){
      try {
        return new JPmmlModelRunner(JpmmlFactory.newEvaluator(model),outFields);
      }
 catch (      Exception e) {
        throw new RuntimeException("Failed to create ModelRunner from model " + model,e);
      }
    }
  }
  /** 
 * Creates a  {@link JPmmlModelRunner} writing to the default stream. PMML Model is downloaded from Blobstore.
 */
public static class ModelRunnerFromBlobStore implements ModelRunnerFactory {
    private final String blobKey;
    private final ModelOutputs modelOutputs;
    private final Map<String,Object> config;
    /** 
 * Uses Storm config as returned by  {@code Utils.readStormConfig()}.
 * @param blobKey key of PMML model in Blobstore
 */
    public ModelRunnerFromBlobStore(    String blobKey,    ModelOutputs modelOutputs){
      this(blobKey,modelOutputs,Utils.readStormConfig());
    }
    /** 
 * Create a new  {@code ModelRunnerFromBlobStore}.
 * @param blobKey key of PMML model in Blobstore
 * @param config Configuration to use to get Blobstore client
 */
    public ModelRunnerFromBlobStore(    String blobKey,    ModelOutputs modelOutputs,    Map<String,Object> config){
      Objects.requireNonNull(blobKey);
      Objects.requireNonNull(modelOutputs);
      Objects.requireNonNull(config);
      this.blobKey=blobKey;
      this.modelOutputs=modelOutputs;
      this.config=config;
    }
    @Override public ModelRunner newModelRunner(){
      try {
        return new JPmmlModelRunner(JpmmlFactory.newEvaluator(blobKey,config),modelOutputs);
      }
 catch (      Exception e) {
        throw new RuntimeException(String.format("Failed to create ModelRunner from model in Blobstore " + "using blob key [%s] and config [%s]",blobKey,config),e);
      }
    }
  }
}
