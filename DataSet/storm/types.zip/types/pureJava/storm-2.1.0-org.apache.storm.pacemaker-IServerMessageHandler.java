public interface IServerMessageHandler {
  HBMessage handleMessage(  HBMessage m,  boolean authenticated);
}
