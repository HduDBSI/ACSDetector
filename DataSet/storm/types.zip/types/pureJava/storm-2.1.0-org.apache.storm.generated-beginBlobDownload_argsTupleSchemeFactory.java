private static class beginBlobDownload_argsTupleSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public beginBlobDownload_argsTupleScheme getScheme(){
    return new beginBlobDownload_argsTupleScheme();
  }
}
