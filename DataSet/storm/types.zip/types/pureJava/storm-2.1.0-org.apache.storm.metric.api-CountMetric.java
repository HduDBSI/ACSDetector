public class CountMetric implements IMetric {
  long value=0;
  public CountMetric(){
  }
  public void incr(){
    value++;
  }
  public void incrBy(  long incrementBy){
    value+=incrementBy;
  }
  @Override public Object getValueAndReset(){
    long ret=value;
    value=0;
    return ret;
  }
}
