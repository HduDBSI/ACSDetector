public interface IGroupMappingServiceProvider {
  /** 
 * Invoked once immediately after construction.
 * @param topoConf Storm configuration
 */
  void prepare(  Map<String,Object> topoConf);
  /** 
 * Get all various group memberships of a given user. Returns EMPTY list in case of non-existing user.
 * @param user User's name
 * @return group memberships of user
 */
  public Set<String> getGroups(  String user) throws IOException ;
}
