public interface EventManager extends AutoCloseable {
  void add(  Runnable eventFn);
  boolean waiting();
}
