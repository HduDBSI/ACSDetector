/** 
 * The interface of State Encoder.
 */
public interface StateEncoder<K,V,KENCODEDT,VENCODEDT> {
  /** 
 * Encode key.
 * @param key the value of key (K type)
 * @return the encoded value of key (KENCODEDT type)
 */
  KENCODEDT encodeKey(  K key);
  /** 
 * Encode value.
 * @param value the value of value (V type)
 * @return the encoded value of value (VENCODEDT type)
 */
  VENCODEDT encodeValue(  V value);
  /** 
 * Decode key.
 * @param encodedKey the value of key (KRAW type)
 * @return the decoded value of key (K type)
 */
  K decodeKey(  KENCODEDT encodedKey);
  /** 
 * Decode value.
 * @param encodedValue the value of key (VENCODEDT type)
 * @return the decoded value of key (V type)
 */
  V decodeValue(  VENCODEDT encodedValue);
  /** 
 * Get the tombstone value (deletion mark).
 * @return the tomestone value (VENCODEDT type)
 */
  VENCODEDT getTombstoneValue();
}
