private class RetrySchedule {
  private final KafkaSpoutMessageId msgId;
  private long nextRetryTimeNanos;
  public RetrySchedule(  KafkaSpoutMessageId msgId,  long nextRetryTimeNanos){
    this.msgId=msgId;
    this.nextRetryTimeNanos=nextRetryTimeNanos;
    LOG.debug("Created {}",this);
  }
  public void setNextRetryTimeNanos(){
    nextRetryTimeNanos=nextTime(msgId);
    LOG.debug("Updated {}",this);
  }
  public boolean retry(  long currentTimeNanos){
    return nextRetryTimeNanos <= currentTimeNanos;
  }
  @Override public String toString(){
    return "RetrySchedule{" + "msgId=" + msgId + ", nextRetryTimeNanos="+ nextRetryTimeNanos+ '}';
  }
  public KafkaSpoutMessageId msgId(){
    return msgId;
  }
  public long nextRetryTimeNanos(){
    return nextRetryTimeNanos;
  }
}
