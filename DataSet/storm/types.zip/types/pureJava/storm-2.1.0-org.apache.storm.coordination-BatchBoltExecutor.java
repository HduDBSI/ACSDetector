public class BatchBoltExecutor implements IRichBolt, FinishedCallback, TimeoutCallback {
  public static final Logger LOG=LoggerFactory.getLogger(BatchBoltExecutor.class);
  private byte[] boltSer;
  private Map<Object,IBatchBolt> openTransactions;
  private Map conf;
  private TopologyContext context;
  private BatchOutputCollectorImpl collector;
  public BatchBoltExecutor(  IBatchBolt bolt){
    boltSer=Utils.javaSerialize(bolt);
  }
  @Override public void prepare(  Map<String,Object> conf,  TopologyContext context,  OutputCollector collector){
    this.conf=conf;
    this.context=context;
    this.collector=new BatchOutputCollectorImpl(collector);
    openTransactions=new HashMap<>();
  }
  @Override public void execute(  Tuple input){
    Object id=input.getValue(0);
    IBatchBolt bolt=getBatchBolt(id);
    try {
      bolt.execute(input);
      collector.ack(input);
    }
 catch (    FailedException e) {
      LOG.error("Failed to process tuple in batch",e);
      collector.fail(input);
    }
  }
  @Override public void cleanup(){
  }
  @Override public void finishedId(  Object id){
    IBatchBolt bolt=getBatchBolt(id);
    openTransactions.remove(id);
    bolt.finishBatch();
  }
  @Override public void timeoutId(  Object attempt){
    openTransactions.remove(attempt);
  }
  @Override public void declareOutputFields(  OutputFieldsDeclarer declarer){
    newTransactionalBolt().declareOutputFields(declarer);
  }
  @Override public Map<String,Object> getComponentConfiguration(){
    return newTransactionalBolt().getComponentConfiguration();
  }
  private IBatchBolt getBatchBolt(  Object id){
    IBatchBolt bolt=openTransactions.get(id);
    if (bolt == null) {
      bolt=newTransactionalBolt();
      bolt.prepare(conf,context,collector,id);
      openTransactions.put(id,bolt);
    }
    return bolt;
  }
  private IBatchBolt newTransactionalBolt(){
    return Utils.javaDeserialize(boltSer,IBatchBolt.class);
  }
}
