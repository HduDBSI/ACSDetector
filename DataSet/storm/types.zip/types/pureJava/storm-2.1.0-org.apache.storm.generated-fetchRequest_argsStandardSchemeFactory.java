private static class fetchRequest_argsStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public fetchRequest_argsStandardScheme getScheme(){
    return new fetchRequest_argsStandardScheme();
  }
}
