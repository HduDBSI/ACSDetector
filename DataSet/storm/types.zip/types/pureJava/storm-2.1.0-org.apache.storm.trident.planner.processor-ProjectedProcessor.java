public class ProjectedProcessor implements TridentProcessor {
  Fields projectFields;
  ProjectionFactory factory;
  TridentContext context;
  public ProjectedProcessor(  Fields projectFields){
    this.projectFields=projectFields;
  }
  @Override public void prepare(  Map<String,Object> conf,  TopologyContext context,  TridentContext tridentContext){
    if (tridentContext.getParentTupleFactories().size() != 1) {
      throw new RuntimeException("Projection processor can only have one parent");
    }
    this.context=tridentContext;
    factory=new ProjectionFactory(tridentContext.getParentTupleFactories().get(0),projectFields);
  }
  @Override public void cleanup(){
  }
  @Override public void startBatch(  ProcessorContext processorContext){
  }
  @Override public void execute(  ProcessorContext processorContext,  String streamId,  TridentTuple tuple){
    TridentTuple toEmit=factory.create(tuple);
    for (    TupleReceiver r : context.getReceivers()) {
      r.execute(processorContext,context.getOutStreamId(),toEmit);
    }
  }
  @Override public void flush(){
    for (    TupleReceiver r : context.getReceivers()) {
      r.flush();
    }
  }
  @Override public void finishBatch(  ProcessorContext processorContext){
  }
  @Override public Factory getOutputFactory(){
    return factory;
  }
}
