public static class submitTopology_args implements org.apache.storm.thrift.TBase<submitTopology_args,submitTopology_args._Fields>, java.io.Serializable, Cloneable, Comparable<submitTopology_args> {
  private static final org.apache.storm.thrift.protocol.TStruct STRUCT_DESC=new org.apache.storm.thrift.protocol.TStruct("submitTopology_args");
  private static final org.apache.storm.thrift.protocol.TField NAME_FIELD_DESC=new org.apache.storm.thrift.protocol.TField("name",org.apache.storm.thrift.protocol.TType.STRING,(short)1);
  private static final org.apache.storm.thrift.protocol.TField UPLOADED_JAR_LOCATION_FIELD_DESC=new org.apache.storm.thrift.protocol.TField("uploadedJarLocation",org.apache.storm.thrift.protocol.TType.STRING,(short)2);
  private static final org.apache.storm.thrift.protocol.TField JSON_CONF_FIELD_DESC=new org.apache.storm.thrift.protocol.TField("jsonConf",org.apache.storm.thrift.protocol.TType.STRING,(short)3);
  private static final org.apache.storm.thrift.protocol.TField TOPOLOGY_FIELD_DESC=new org.apache.storm.thrift.protocol.TField("topology",org.apache.storm.thrift.protocol.TType.STRUCT,(short)4);
  private static final org.apache.storm.thrift.scheme.SchemeFactory STANDARD_SCHEME_FACTORY=new submitTopology_argsStandardSchemeFactory();
  private static final org.apache.storm.thrift.scheme.SchemeFactory TUPLE_SCHEME_FACTORY=new submitTopology_argsTupleSchemeFactory();
  private @org.apache.storm.thrift.annotation.Nullable java.lang.String name;
  private @org.apache.storm.thrift.annotation.Nullable java.lang.String uploadedJarLocation;
  private @org.apache.storm.thrift.annotation.Nullable java.lang.String jsonConf;
  private @org.apache.storm.thrift.annotation.Nullable StormTopology topology;
  /** 
 * The set of fields this struct contains, along with convenience methods for finding and manipulating them. 
 */
  public enum _Fields implements org.apache.storm.thrift.TFieldIdEnum {  NAME((short)1,"name"),   UPLOADED_JAR_LOCATION((short)2,"uploadedJarLocation"),   JSON_CONF((short)3,"jsonConf"),   TOPOLOGY((short)4,"topology");   private static final java.util.Map<java.lang.String,_Fields> byName=new java.util.HashMap<java.lang.String,_Fields>();
static {
    for (    _Fields field : java.util.EnumSet.allOf(_Fields.class)) {
      byName.put(field.getFieldName(),field);
    }
  }
  /** 
 * Find the _Fields constant that matches fieldId, or null if its not found.
 */
  @org.apache.storm.thrift.annotation.Nullable public static _Fields findByThriftId(  int fieldId){
switch (fieldId) {
case 1:
      return NAME;
case 2:
    return UPLOADED_JAR_LOCATION;
case 3:
  return JSON_CONF;
case 4:
return TOPOLOGY;
default :
return null;
}
}
/** 
 * Find the _Fields constant that matches fieldId, throwing an exception if it is not found.
 */
public static _Fields findByThriftIdOrThrow(int fieldId){
_Fields fields=findByThriftId(fieldId);
if (fields == null) throw new java.lang.IllegalArgumentException("Field " + fieldId + " doesn't exist!");
return fields;
}
/** 
 * Find the _Fields constant that matches name, or null if its not found.
 */
@org.apache.storm.thrift.annotation.Nullable public static _Fields findByName(java.lang.String name){
return byName.get(name);
}
private final short _thriftId;
private final java.lang.String _fieldName;
_Fields(short thriftId,java.lang.String fieldName){
_thriftId=thriftId;
_fieldName=fieldName;
}
public short getThriftFieldId(){
return _thriftId;
}
public java.lang.String getFieldName(){
return _fieldName;
}
}
public static final java.util.Map<_Fields,org.apache.storm.thrift.meta_data.FieldMetaData> metaDataMap;
static {
java.util.Map<_Fields,org.apache.storm.thrift.meta_data.FieldMetaData> tmpMap=new java.util.EnumMap<_Fields,org.apache.storm.thrift.meta_data.FieldMetaData>(_Fields.class);
tmpMap.put(_Fields.NAME,new org.apache.storm.thrift.meta_data.FieldMetaData("name",org.apache.storm.thrift.TFieldRequirementType.DEFAULT,new org.apache.storm.thrift.meta_data.FieldValueMetaData(org.apache.storm.thrift.protocol.TType.STRING)));
tmpMap.put(_Fields.UPLOADED_JAR_LOCATION,new org.apache.storm.thrift.meta_data.FieldMetaData("uploadedJarLocation",org.apache.storm.thrift.TFieldRequirementType.DEFAULT,new org.apache.storm.thrift.meta_data.FieldValueMetaData(org.apache.storm.thrift.protocol.TType.STRING)));
tmpMap.put(_Fields.JSON_CONF,new org.apache.storm.thrift.meta_data.FieldMetaData("jsonConf",org.apache.storm.thrift.TFieldRequirementType.DEFAULT,new org.apache.storm.thrift.meta_data.FieldValueMetaData(org.apache.storm.thrift.protocol.TType.STRING)));
tmpMap.put(_Fields.TOPOLOGY,new org.apache.storm.thrift.meta_data.FieldMetaData("topology",org.apache.storm.thrift.TFieldRequirementType.DEFAULT,new org.apache.storm.thrift.meta_data.StructMetaData(org.apache.storm.thrift.protocol.TType.STRUCT,StormTopology.class)));
metaDataMap=java.util.Collections.unmodifiableMap(tmpMap);
org.apache.storm.thrift.meta_data.FieldMetaData.addStructMetaDataMap(submitTopology_args.class,metaDataMap);
}
public submitTopology_args(){
}
public submitTopology_args(java.lang.String name,java.lang.String uploadedJarLocation,java.lang.String jsonConf,StormTopology topology){
this();
this.name=name;
this.uploadedJarLocation=uploadedJarLocation;
this.jsonConf=jsonConf;
this.topology=topology;
}
/** 
 * Performs a deep copy on <i>other</i>.
 */
public submitTopology_args(submitTopology_args other){
if (other.is_set_name()) {
this.name=other.name;
}
if (other.is_set_uploadedJarLocation()) {
this.uploadedJarLocation=other.uploadedJarLocation;
}
if (other.is_set_jsonConf()) {
this.jsonConf=other.jsonConf;
}
if (other.is_set_topology()) {
this.topology=new StormTopology(other.topology);
}
}
public submitTopology_args deepCopy(){
return new submitTopology_args(this);
}
@Override public void clear(){
this.name=null;
this.uploadedJarLocation=null;
this.jsonConf=null;
this.topology=null;
}
@org.apache.storm.thrift.annotation.Nullable public java.lang.String get_name(){
return this.name;
}
public void set_name(@org.apache.storm.thrift.annotation.Nullable java.lang.String name){
this.name=name;
}
public void unset_name(){
this.name=null;
}
/** 
 * Returns true if field name is set (has been assigned a value) and false otherwise 
 */
public boolean is_set_name(){
return this.name != null;
}
public void set_name_isSet(boolean value){
if (!value) {
this.name=null;
}
}
@org.apache.storm.thrift.annotation.Nullable public java.lang.String get_uploadedJarLocation(){
return this.uploadedJarLocation;
}
public void set_uploadedJarLocation(@org.apache.storm.thrift.annotation.Nullable java.lang.String uploadedJarLocation){
this.uploadedJarLocation=uploadedJarLocation;
}
public void unset_uploadedJarLocation(){
this.uploadedJarLocation=null;
}
/** 
 * Returns true if field uploadedJarLocation is set (has been assigned a value) and false otherwise 
 */
public boolean is_set_uploadedJarLocation(){
return this.uploadedJarLocation != null;
}
public void set_uploadedJarLocation_isSet(boolean value){
if (!value) {
this.uploadedJarLocation=null;
}
}
@org.apache.storm.thrift.annotation.Nullable public java.lang.String get_jsonConf(){
return this.jsonConf;
}
public void set_jsonConf(@org.apache.storm.thrift.annotation.Nullable java.lang.String jsonConf){
this.jsonConf=jsonConf;
}
public void unset_jsonConf(){
this.jsonConf=null;
}
/** 
 * Returns true if field jsonConf is set (has been assigned a value) and false otherwise 
 */
public boolean is_set_jsonConf(){
return this.jsonConf != null;
}
public void set_jsonConf_isSet(boolean value){
if (!value) {
this.jsonConf=null;
}
}
@org.apache.storm.thrift.annotation.Nullable public StormTopology get_topology(){
return this.topology;
}
public void set_topology(@org.apache.storm.thrift.annotation.Nullable StormTopology topology){
this.topology=topology;
}
public void unset_topology(){
this.topology=null;
}
/** 
 * Returns true if field topology is set (has been assigned a value) and false otherwise 
 */
public boolean is_set_topology(){
return this.topology != null;
}
public void set_topology_isSet(boolean value){
if (!value) {
this.topology=null;
}
}
public void setFieldValue(_Fields field,@org.apache.storm.thrift.annotation.Nullable java.lang.Object value){
switch (field) {
case NAME:
if (value == null) {
unset_name();
}
 else {
set_name((java.lang.String)value);
}
break;
case UPLOADED_JAR_LOCATION:
if (value == null) {
unset_uploadedJarLocation();
}
 else {
set_uploadedJarLocation((java.lang.String)value);
}
break;
case JSON_CONF:
if (value == null) {
unset_jsonConf();
}
 else {
set_jsonConf((java.lang.String)value);
}
break;
case TOPOLOGY:
if (value == null) {
unset_topology();
}
 else {
set_topology((StormTopology)value);
}
break;
}
}
@org.apache.storm.thrift.annotation.Nullable public java.lang.Object getFieldValue(_Fields field){
switch (field) {
case NAME:
return get_name();
case UPLOADED_JAR_LOCATION:
return get_uploadedJarLocation();
case JSON_CONF:
return get_jsonConf();
case TOPOLOGY:
return get_topology();
}
throw new java.lang.IllegalStateException();
}
/** 
 * Returns true if field corresponding to fieldID is set (has been assigned a value) and false otherwise 
 */
public boolean isSet(_Fields field){
if (field == null) {
throw new java.lang.IllegalArgumentException();
}
switch (field) {
case NAME:
return is_set_name();
case UPLOADED_JAR_LOCATION:
return is_set_uploadedJarLocation();
case JSON_CONF:
return is_set_jsonConf();
case TOPOLOGY:
return is_set_topology();
}
throw new java.lang.IllegalStateException();
}
@Override public boolean equals(java.lang.Object that){
if (that == null) return false;
if (that instanceof submitTopology_args) return this.equals((submitTopology_args)that);
return false;
}
public boolean equals(submitTopology_args that){
if (that == null) return false;
if (this == that) return true;
boolean this_present_name=true && this.is_set_name();
boolean that_present_name=true && that.is_set_name();
if (this_present_name || that_present_name) {
if (!(this_present_name && that_present_name)) return false;
if (!this.name.equals(that.name)) return false;
}
boolean this_present_uploadedJarLocation=true && this.is_set_uploadedJarLocation();
boolean that_present_uploadedJarLocation=true && that.is_set_uploadedJarLocation();
if (this_present_uploadedJarLocation || that_present_uploadedJarLocation) {
if (!(this_present_uploadedJarLocation && that_present_uploadedJarLocation)) return false;
if (!this.uploadedJarLocation.equals(that.uploadedJarLocation)) return false;
}
boolean this_present_jsonConf=true && this.is_set_jsonConf();
boolean that_present_jsonConf=true && that.is_set_jsonConf();
if (this_present_jsonConf || that_present_jsonConf) {
if (!(this_present_jsonConf && that_present_jsonConf)) return false;
if (!this.jsonConf.equals(that.jsonConf)) return false;
}
boolean this_present_topology=true && this.is_set_topology();
boolean that_present_topology=true && that.is_set_topology();
if (this_present_topology || that_present_topology) {
if (!(this_present_topology && that_present_topology)) return false;
if (!this.topology.equals(that.topology)) return false;
}
return true;
}
@Override public int hashCode(){
int hashCode=1;
hashCode=hashCode * 8191 + ((is_set_name()) ? 131071 : 524287);
if (is_set_name()) hashCode=hashCode * 8191 + name.hashCode();
hashCode=hashCode * 8191 + ((is_set_uploadedJarLocation()) ? 131071 : 524287);
if (is_set_uploadedJarLocation()) hashCode=hashCode * 8191 + uploadedJarLocation.hashCode();
hashCode=hashCode * 8191 + ((is_set_jsonConf()) ? 131071 : 524287);
if (is_set_jsonConf()) hashCode=hashCode * 8191 + jsonConf.hashCode();
hashCode=hashCode * 8191 + ((is_set_topology()) ? 131071 : 524287);
if (is_set_topology()) hashCode=hashCode * 8191 + topology.hashCode();
return hashCode;
}
@Override public int compareTo(submitTopology_args other){
if (!getClass().equals(other.getClass())) {
return getClass().getName().compareTo(other.getClass().getName());
}
int lastComparison=0;
lastComparison=java.lang.Boolean.valueOf(is_set_name()).compareTo(other.is_set_name());
if (lastComparison != 0) {
return lastComparison;
}
if (is_set_name()) {
lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.name,other.name);
if (lastComparison != 0) {
return lastComparison;
}
}
lastComparison=java.lang.Boolean.valueOf(is_set_uploadedJarLocation()).compareTo(other.is_set_uploadedJarLocation());
if (lastComparison != 0) {
return lastComparison;
}
if (is_set_uploadedJarLocation()) {
lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.uploadedJarLocation,other.uploadedJarLocation);
if (lastComparison != 0) {
return lastComparison;
}
}
lastComparison=java.lang.Boolean.valueOf(is_set_jsonConf()).compareTo(other.is_set_jsonConf());
if (lastComparison != 0) {
return lastComparison;
}
if (is_set_jsonConf()) {
lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.jsonConf,other.jsonConf);
if (lastComparison != 0) {
return lastComparison;
}
}
lastComparison=java.lang.Boolean.valueOf(is_set_topology()).compareTo(other.is_set_topology());
if (lastComparison != 0) {
return lastComparison;
}
if (is_set_topology()) {
lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.topology,other.topology);
if (lastComparison != 0) {
return lastComparison;
}
}
return 0;
}
@org.apache.storm.thrift.annotation.Nullable public _Fields fieldForId(int fieldId){
return _Fields.findByThriftId(fieldId);
}
public void read(org.apache.storm.thrift.protocol.TProtocol iprot) throws org.apache.storm.thrift.TException {
scheme(iprot).read(iprot,this);
}
public void write(org.apache.storm.thrift.protocol.TProtocol oprot) throws org.apache.storm.thrift.TException {
scheme(oprot).write(oprot,this);
}
@Override public java.lang.String toString(){
java.lang.StringBuilder sb=new java.lang.StringBuilder("submitTopology_args(");
boolean first=true;
sb.append("name:");
if (this.name == null) {
sb.append("null");
}
 else {
sb.append(this.name);
}
first=false;
if (!first) sb.append(", ");
sb.append("uploadedJarLocation:");
if (this.uploadedJarLocation == null) {
sb.append("null");
}
 else {
sb.append(this.uploadedJarLocation);
}
first=false;
if (!first) sb.append(", ");
sb.append("jsonConf:");
if (this.jsonConf == null) {
sb.append("null");
}
 else {
sb.append(this.jsonConf);
}
first=false;
if (!first) sb.append(", ");
sb.append("topology:");
if (this.topology == null) {
sb.append("null");
}
 else {
sb.append(this.topology);
}
first=false;
sb.append(")");
return sb.toString();
}
public void validate() throws org.apache.storm.thrift.TException {
if (topology != null) {
topology.validate();
}
}
private void writeObject(java.io.ObjectOutputStream out) throws java.io.IOException {
try {
write(new org.apache.storm.thrift.protocol.TCompactProtocol(new org.apache.storm.thrift.transport.TIOStreamTransport(out)));
}
 catch (org.apache.storm.thrift.TException te) {
throw new java.io.IOException(te);
}
}
private void readObject(java.io.ObjectInputStream in) throws java.io.IOException, java.lang.ClassNotFoundException {
try {
read(new org.apache.storm.thrift.protocol.TCompactProtocol(new org.apache.storm.thrift.transport.TIOStreamTransport(in)));
}
 catch (org.apache.storm.thrift.TException te) {
throw new java.io.IOException(te);
}
}
private static class submitTopology_argsStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
public submitTopology_argsStandardScheme getScheme(){
return new submitTopology_argsStandardScheme();
}
}
private static class submitTopology_argsStandardScheme extends org.apache.storm.thrift.scheme.StandardScheme<submitTopology_args> {
public void read(org.apache.storm.thrift.protocol.TProtocol iprot,submitTopology_args struct) throws org.apache.storm.thrift.TException {
org.apache.storm.thrift.protocol.TField schemeField;
iprot.readStructBegin();
while (true) {
schemeField=iprot.readFieldBegin();
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STOP) {
break;
}
switch (schemeField.id) {
case 1:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
struct.name=iprot.readString();
struct.set_name_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 2:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
struct.uploadedJarLocation=iprot.readString();
struct.set_uploadedJarLocation_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 3:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
struct.jsonConf=iprot.readString();
struct.set_jsonConf_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 4:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRUCT) {
struct.topology=new StormTopology();
struct.topology.read(iprot);
struct.set_topology_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
default :
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
iprot.readFieldEnd();
}
iprot.readStructEnd();
struct.validate();
}
public void write(org.apache.storm.thrift.protocol.TProtocol oprot,submitTopology_args struct) throws org.apache.storm.thrift.TException {
struct.validate();
oprot.writeStructBegin(STRUCT_DESC);
if (struct.name != null) {
oprot.writeFieldBegin(NAME_FIELD_DESC);
oprot.writeString(struct.name);
oprot.writeFieldEnd();
}
if (struct.uploadedJarLocation != null) {
oprot.writeFieldBegin(UPLOADED_JAR_LOCATION_FIELD_DESC);
oprot.writeString(struct.uploadedJarLocation);
oprot.writeFieldEnd();
}
if (struct.jsonConf != null) {
oprot.writeFieldBegin(JSON_CONF_FIELD_DESC);
oprot.writeString(struct.jsonConf);
oprot.writeFieldEnd();
}
if (struct.topology != null) {
oprot.writeFieldBegin(TOPOLOGY_FIELD_DESC);
struct.topology.write(oprot);
oprot.writeFieldEnd();
}
oprot.writeFieldStop();
oprot.writeStructEnd();
}
}
private static class submitTopology_argsTupleSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
public submitTopology_argsTupleScheme getScheme(){
return new submitTopology_argsTupleScheme();
}
}
private static class submitTopology_argsTupleScheme extends org.apache.storm.thrift.scheme.TupleScheme<submitTopology_args> {
@Override public void write(org.apache.storm.thrift.protocol.TProtocol prot,submitTopology_args struct) throws org.apache.storm.thrift.TException {
org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
java.util.BitSet optionals=new java.util.BitSet();
if (struct.is_set_name()) {
optionals.set(0);
}
if (struct.is_set_uploadedJarLocation()) {
optionals.set(1);
}
if (struct.is_set_jsonConf()) {
optionals.set(2);
}
if (struct.is_set_topology()) {
optionals.set(3);
}
oprot.writeBitSet(optionals,4);
if (struct.is_set_name()) {
oprot.writeString(struct.name);
}
if (struct.is_set_uploadedJarLocation()) {
oprot.writeString(struct.uploadedJarLocation);
}
if (struct.is_set_jsonConf()) {
oprot.writeString(struct.jsonConf);
}
if (struct.is_set_topology()) {
struct.topology.write(oprot);
}
}
@Override public void read(org.apache.storm.thrift.protocol.TProtocol prot,submitTopology_args struct) throws org.apache.storm.thrift.TException {
org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
java.util.BitSet incoming=iprot.readBitSet(4);
if (incoming.get(0)) {
struct.name=iprot.readString();
struct.set_name_isSet(true);
}
if (incoming.get(1)) {
struct.uploadedJarLocation=iprot.readString();
struct.set_uploadedJarLocation_isSet(true);
}
if (incoming.get(2)) {
struct.jsonConf=iprot.readString();
struct.set_jsonConf_isSet(true);
}
if (incoming.get(3)) {
struct.topology=new StormTopology();
struct.topology.read(iprot);
struct.set_topology_isSet(true);
}
}
}
private static <S extends org.apache.storm.thrift.scheme.IScheme>S scheme(org.apache.storm.thrift.protocol.TProtocol proto){
return (org.apache.storm.thrift.scheme.StandardScheme.class.equals(proto.getScheme()) ? STANDARD_SCHEME_FACTORY : TUPLE_SCHEME_FACTORY).getScheme();
}
}
