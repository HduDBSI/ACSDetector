private static class deactivate_resultTupleSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public deactivate_resultTupleScheme getScheme(){
    return new deactivate_resultTupleScheme();
  }
}
