/** 
 * Represents an EventHub partition
 */
public class Partition implements ISpoutPartition, Serializable {
  private static final long serialVersionUID=1L;
  String partitionId;
  public Partition(  EventHubSpoutConfig config,  String partitionId){
    this.partitionId=partitionId;
  }
  @Override public String getId(){
    return partitionId;
  }
}
