/** 
 * Simple interface whose <tt>call</tt> method is called by {#callWithTimeout} in a new thread inside a {@linkplain java.security.PrivilegedExceptionAction#run()} call.
 * @param < T >
 */
private interface CallRunner<T> {
  T call() throws Exception ;
}
