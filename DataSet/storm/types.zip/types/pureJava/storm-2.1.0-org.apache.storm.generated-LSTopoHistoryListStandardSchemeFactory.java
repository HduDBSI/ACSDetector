private static class LSTopoHistoryListStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public LSTopoHistoryListStandardScheme getScheme(){
    return new LSTopoHistoryListStandardScheme();
  }
}
