public interface GroupedMultiReducer<T> extends Serializable {
  void prepare(  Map<String,Object> conf,  TridentMultiReducerContext context);
  T init(  TridentCollector collector,  TridentTuple group);
  void execute(  T state,  int streamIndex,  TridentTuple group,  TridentTuple input,  TridentCollector collector);
  void complete(  T state,  TridentTuple group,  TridentCollector collector);
  void cleanup();
}
