@SuppressWarnings("checkstyle:AbbreviationAsWordInName") public interface CQLStatementBuilder<T extends CQLStatementTupleMapper> extends Serializable {
  /** 
 * Builds a new  {@link CQLStatementTupleMapper} instance.
 * @return a new CQLStatementMapper instance.
 */
  T build();
}
