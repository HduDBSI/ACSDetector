/** 
 * Default  {@link CqlMapper} to map all tuple values to column.
 */
public static final class DefaultCqlMapper implements CqlMapper {
  /** 
 * Creates a new  {@link org.apache.storm.cassandra.query.CqlMapper.DefaultCqlMapper} instance.
 */
  public DefaultCqlMapper(){
  }
  /** 
 * {@inheritDoc}
 */
  @Override public List<Column> map(  ITuple tuple){
    List<Column> columns=new ArrayList<>(tuple.size());
    for (    String name : tuple.getFields()) {
      columns.add(new Column(name,tuple.getValueByField(name)));
    }
    return columns;
  }
}
