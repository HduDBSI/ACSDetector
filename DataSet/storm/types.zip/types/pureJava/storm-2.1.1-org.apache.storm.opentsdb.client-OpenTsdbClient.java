/** 
 * Client to connect to OpenTsdb TSD for storing timeseries datapoints.
 */
public class OpenTsdbClient {
  private static final String PUT_PATH="/api/put";
  private static Logger LOG=LoggerFactory.getLogger(OpenTsdbClient.class);
  private final String urlString;
  private final boolean sync;
  private final long syncTimeout;
  private final ResponseType responseType;
  private final boolean enableChunkedEncoding;
  private WebTarget target;
  private Client client;
  public enum ResponseType {  None(""),   Summary("summary"),   Details("details");   private final String value;
  ResponseType(  String value){
    this.value=value;
  }
}
  protected OpenTsdbClient(  String urlString,  boolean sync,  long syncTimeOut,  ResponseType responseType,  boolean enableChunkedEncoding){
    this.urlString=urlString;
    this.sync=sync;
    this.syncTimeout=syncTimeOut;
    this.responseType=responseType;
    this.enableChunkedEncoding=enableChunkedEncoding;
    init();
  }
  private void init(){
    final ApacheConnectorProvider apacheConnectorProvider=new ApacheConnectorProvider();
    final ClientConfig clientConfig=new ClientConfig().connectorProvider(apacheConnectorProvider);
    clientConfig.property(ClientProperties.REQUEST_ENTITY_PROCESSING,enableChunkedEncoding ? RequestEntityProcessing.CHUNKED : RequestEntityProcessing.BUFFERED);
    client=ClientBuilder.newClient(clientConfig);
    target=client.target(urlString).path(PUT_PATH);
    if (sync) {
      target=target.queryParam("sync","").queryParam("sync_timeout",syncTimeout);
    }
    if (responseType != ResponseType.None) {
      target=target.queryParam(responseType.value,"");
    }
    LOG.info("target uri [{}]",target.getUri());
  }
  public ClientResponse.Details writeMetricPoint(  OpenTsdbMetricDatapoint metricDataPoint){
    return target.request().post(Entity.json(metricDataPoint),ClientResponse.Details.class);
  }
  public ClientResponse.Details writeMetricPoints(  Collection<OpenTsdbMetricDatapoint> metricDataPoints){
    LOG.debug("Writing metric points to OpenTSDB [{}]",metricDataPoints.size());
    return target.request().post(Entity.json(metricDataPoints),ClientResponse.Details.class);
  }
  public void cleanup(){
    client.close();
  }
  public static OpenTsdbClient.Builder newBuilder(  String url){
    return new Builder(url);
  }
public static class Builder implements Serializable {
    private final String url;
    private boolean sync;
    private long syncTimeOut;
    private boolean enableChunkedEncoding;
    private ResponseType responseType=ResponseType.None;
    public Builder(    String url){
      this.url=url;
    }
    public OpenTsdbClient.Builder sync(    long timeoutInMilliSecs){
      Preconditions.checkArgument(timeoutInMilliSecs > 0,"timeout value should be more than zero.");
      sync=true;
      syncTimeOut=timeoutInMilliSecs;
      return this;
    }
    public OpenTsdbClient.Builder returnSummary(){
      responseType=ResponseType.Summary;
      return this;
    }
    public OpenTsdbClient.Builder returnDetails(){
      responseType=ResponseType.Details;
      return this;
    }
    public Builder enableChunkedEncoding(){
      enableChunkedEncoding=true;
      return this;
    }
    public OpenTsdbClient build(){
      return new OpenTsdbClient(url,sync,syncTimeOut,responseType,enableChunkedEncoding);
    }
  }
}
