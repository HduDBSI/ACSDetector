private static class BoltDeclarerImpl extends BaseConfigurationDeclarer<BoltDeclarer> implements BoltDeclarer {
  Component component;
  public BoltDeclarerImpl(  Component component){
    this.component=component;
  }
  @Override public BoltDeclarer fieldsGrouping(  final String component,  final Fields fields){
    addDeclaration(new InputDeclaration(){
      @Override public void declare(      InputDeclarer declarer){
        declarer.fieldsGrouping(component,fields);
      }
      @Override public String getComponent(){
        return component;
      }
    }
);
    return this;
  }
  @Override public BoltDeclarer fieldsGrouping(  final String component,  final String streamId,  final Fields fields){
    addDeclaration(new InputDeclaration(){
      @Override public void declare(      InputDeclarer declarer){
        declarer.fieldsGrouping(component,streamId,fields);
      }
      @Override public String getComponent(){
        return component;
      }
    }
);
    return this;
  }
  @Override public BoltDeclarer globalGrouping(  final String component){
    addDeclaration(new InputDeclaration(){
      @Override public void declare(      InputDeclarer declarer){
        declarer.globalGrouping(component);
      }
      @Override public String getComponent(){
        return component;
      }
    }
);
    return this;
  }
  @Override public BoltDeclarer globalGrouping(  final String component,  final String streamId){
    addDeclaration(new InputDeclaration(){
      @Override public void declare(      InputDeclarer declarer){
        declarer.globalGrouping(component,streamId);
      }
      @Override public String getComponent(){
        return component;
      }
    }
);
    return this;
  }
  @Override public BoltDeclarer shuffleGrouping(  final String component){
    addDeclaration(new InputDeclaration(){
      @Override public void declare(      InputDeclarer declarer){
        declarer.shuffleGrouping(component);
      }
      @Override public String getComponent(){
        return component;
      }
    }
);
    return this;
  }
  @Override public BoltDeclarer shuffleGrouping(  final String component,  final String streamId){
    addDeclaration(new InputDeclaration(){
      @Override public void declare(      InputDeclarer declarer){
        declarer.shuffleGrouping(component,streamId);
      }
      @Override public String getComponent(){
        return component;
      }
    }
);
    return this;
  }
  @Override public BoltDeclarer localOrShuffleGrouping(  final String component){
    addDeclaration(new InputDeclaration(){
      @Override public void declare(      InputDeclarer declarer){
        declarer.localOrShuffleGrouping(component);
      }
      @Override public String getComponent(){
        return component;
      }
    }
);
    return this;
  }
  @Override public BoltDeclarer localOrShuffleGrouping(  final String component,  final String streamId){
    addDeclaration(new InputDeclaration(){
      @Override public void declare(      InputDeclarer declarer){
        declarer.localOrShuffleGrouping(component,streamId);
      }
      @Override public String getComponent(){
        return component;
      }
    }
);
    return this;
  }
  @Override public BoltDeclarer noneGrouping(  final String component){
    addDeclaration(new InputDeclaration(){
      @Override public void declare(      InputDeclarer declarer){
        declarer.noneGrouping(component);
      }
      @Override public String getComponent(){
        return component;
      }
    }
);
    return this;
  }
  @Override public BoltDeclarer noneGrouping(  final String component,  final String streamId){
    addDeclaration(new InputDeclaration(){
      @Override public void declare(      InputDeclarer declarer){
        declarer.noneGrouping(component,streamId);
      }
      @Override public String getComponent(){
        return component;
      }
    }
);
    return this;
  }
  @Override public BoltDeclarer allGrouping(  final String component){
    addDeclaration(new InputDeclaration(){
      @Override public void declare(      InputDeclarer declarer){
        declarer.allGrouping(component);
      }
      @Override public String getComponent(){
        return component;
      }
    }
);
    return this;
  }
  @Override public BoltDeclarer allGrouping(  final String component,  final String streamId){
    addDeclaration(new InputDeclaration(){
      @Override public void declare(      InputDeclarer declarer){
        declarer.allGrouping(component,streamId);
      }
      @Override public String getComponent(){
        return component;
      }
    }
);
    return this;
  }
  @Override public BoltDeclarer directGrouping(  final String component){
    addDeclaration(new InputDeclaration(){
      @Override public void declare(      InputDeclarer declarer){
        declarer.directGrouping(component);
      }
      @Override public String getComponent(){
        return component;
      }
    }
);
    return this;
  }
  @Override public BoltDeclarer directGrouping(  final String component,  final String streamId){
    addDeclaration(new InputDeclaration(){
      @Override public void declare(      InputDeclarer declarer){
        declarer.directGrouping(component,streamId);
      }
      @Override public String getComponent(){
        return component;
      }
    }
);
    return this;
  }
  @Override public BoltDeclarer partialKeyGrouping(  String componentId,  Fields fields){
    return customGrouping(componentId,new PartialKeyGrouping(fields));
  }
  @Override public BoltDeclarer partialKeyGrouping(  String componentId,  String streamId,  Fields fields){
    return customGrouping(componentId,streamId,new PartialKeyGrouping(fields));
  }
  @Override public BoltDeclarer customGrouping(  final String component,  final CustomStreamGrouping grouping){
    addDeclaration(new InputDeclaration(){
      @Override public void declare(      InputDeclarer declarer){
        declarer.customGrouping(component,grouping);
      }
      @Override public String getComponent(){
        return component;
      }
    }
);
    return this;
  }
  @Override public BoltDeclarer customGrouping(  final String component,  final String streamId,  final CustomStreamGrouping grouping){
    addDeclaration(new InputDeclaration(){
      @Override public void declare(      InputDeclarer declarer){
        declarer.customGrouping(component,streamId,grouping);
      }
      @Override public String getComponent(){
        return component;
      }
    }
);
    return this;
  }
  @Override public BoltDeclarer grouping(  final GlobalStreamId stream,  final Grouping grouping){
    addDeclaration(new InputDeclaration(){
      @Override public void declare(      InputDeclarer declarer){
        declarer.grouping(stream,grouping);
      }
      @Override public String getComponent(){
        return stream.get_componentId();
      }
    }
);
    return this;
  }
  private void addDeclaration(  InputDeclaration declaration){
    component.declarations.add(declaration);
  }
  @Override public BoltDeclarer addConfigurations(  Map<String,Object> conf){
    if (conf != null) {
      getComponentConfiguration().putAll(conf);
    }
    return this;
  }
  @Override public BoltDeclarer addSharedMemory(  SharedMemory request){
    component.sharedMemory.add(request);
    return this;
  }
  @Override public Map<String,Object> getComponentConfiguration(){
    return component.componentConf;
  }
}
