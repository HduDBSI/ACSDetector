/** 
 * Computes sliding window sum.
 */
public class TumblingWindowCorrectness implements TestableTopology {
  private static final Logger LOG=LoggerFactory.getLogger(TumblingWindowCorrectness.class);
  private static final String NUMBER_FIELD="number";
  private static final String STRING_FIELD="numAsStr";
  private final int tumbleSize;
  private final String spoutName;
  private final int spoutExecutors=1;
  private final String boltName;
  private final int boltExecutors=1;
  public TumblingWindowCorrectness(  final int tumbleSize){
    this.tumbleSize=tumbleSize;
    final String prefix=this.getClass().getSimpleName() + "-tumbleSize" + tumbleSize;
    spoutName=prefix + "IncrementingSpout";
    boltName=prefix + "VerificationBolt";
  }
  @Override public String getBoltName(){
    return boltName;
  }
  @Override public String getSpoutName(){
    return spoutName;
  }
  @Override public int getBoltExecutors(){
    return boltExecutors;
  }
  @Override public int getSpoutExecutors(){
    return spoutExecutors;
  }
  @Override public StormTopology newTopology(){
    TopologyBuilder builder=new TopologyBuilder();
    builder.setSpout(getSpoutName(),new IncrementingSpout(),spoutExecutors);
    builder.setBolt(getBoltName(),new VerificationBolt().withTumblingWindow(new BaseWindowedBolt.Count(tumbleSize)),boltExecutors).shuffleGrouping(getSpoutName());
    return builder.createTopology();
  }
}
