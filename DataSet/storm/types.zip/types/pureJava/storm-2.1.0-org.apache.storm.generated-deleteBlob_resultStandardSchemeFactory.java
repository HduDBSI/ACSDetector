private static class deleteBlob_resultStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public deleteBlob_resultStandardScheme getScheme(){
    return new deleteBlob_resultStandardScheme();
  }
}
