/** 
 * Trident  {@link StateFactory} implementation for OpenTSDB.
 */
public class OpenTsdbStateFactory implements StateFactory {
  private OpenTsdbClient.Builder builder;
  private final List<? extends ITupleOpenTsdbDatapointMapper> tridentTupleOpenTsdbDatapointMappers;
  public OpenTsdbStateFactory(  OpenTsdbClient.Builder builder,  List<? extends ITupleOpenTsdbDatapointMapper> tridentTupleOpenTsdbDatapointMappers){
    this.builder=builder;
    this.tridentTupleOpenTsdbDatapointMappers=tridentTupleOpenTsdbDatapointMappers;
  }
  @Override public State makeState(  Map<String,Object> conf,  IMetricsContext metrics,  int partitionIndex,  int numPartitions){
    final OpenTsdbState openTsdbState=new OpenTsdbState(conf,builder,tridentTupleOpenTsdbDatapointMappers);
    openTsdbState.prepare();
    return openTsdbState;
  }
}
