public static class getTopologyConf_args implements org.apache.storm.thrift.TBase<getTopologyConf_args,getTopologyConf_args._Fields>, java.io.Serializable, Cloneable, Comparable<getTopologyConf_args> {
  private static final org.apache.storm.thrift.protocol.TStruct STRUCT_DESC=new org.apache.storm.thrift.protocol.TStruct("getTopologyConf_args");
  private static final org.apache.storm.thrift.protocol.TField ID_FIELD_DESC=new org.apache.storm.thrift.protocol.TField("id",org.apache.storm.thrift.protocol.TType.STRING,(short)1);
  private static final org.apache.storm.thrift.scheme.SchemeFactory STANDARD_SCHEME_FACTORY=new getTopologyConf_argsStandardSchemeFactory();
  private static final org.apache.storm.thrift.scheme.SchemeFactory TUPLE_SCHEME_FACTORY=new getTopologyConf_argsTupleSchemeFactory();
  private @org.apache.storm.thrift.annotation.Nullable java.lang.String id;
  /** 
 * The set of fields this struct contains, along with convenience methods for finding and manipulating them. 
 */
  public enum _Fields implements org.apache.storm.thrift.TFieldIdEnum {  ID((short)1,"id");   private static final java.util.Map<java.lang.String,_Fields> byName=new java.util.HashMap<java.lang.String,_Fields>();
static {
    for (    _Fields field : java.util.EnumSet.allOf(_Fields.class)) {
      byName.put(field.getFieldName(),field);
    }
  }
  /** 
 * Find the _Fields constant that matches fieldId, or null if its not found.
 */
  @org.apache.storm.thrift.annotation.Nullable public static _Fields findByThriftId(  int fieldId){
switch (fieldId) {
case 1:
      return ID;
default :
    return null;
}
}
/** 
 * Find the _Fields constant that matches fieldId, throwing an exception if it is not found.
 */
public static _Fields findByThriftIdOrThrow(int fieldId){
_Fields fields=findByThriftId(fieldId);
if (fields == null) throw new java.lang.IllegalArgumentException("Field " + fieldId + " doesn't exist!");
return fields;
}
/** 
 * Find the _Fields constant that matches name, or null if its not found.
 */
@org.apache.storm.thrift.annotation.Nullable public static _Fields findByName(java.lang.String name){
return byName.get(name);
}
private final short _thriftId;
private final java.lang.String _fieldName;
_Fields(short thriftId,java.lang.String fieldName){
_thriftId=thriftId;
_fieldName=fieldName;
}
public short getThriftFieldId(){
return _thriftId;
}
public java.lang.String getFieldName(){
return _fieldName;
}
}
public static final java.util.Map<_Fields,org.apache.storm.thrift.meta_data.FieldMetaData> metaDataMap;
static {
java.util.Map<_Fields,org.apache.storm.thrift.meta_data.FieldMetaData> tmpMap=new java.util.EnumMap<_Fields,org.apache.storm.thrift.meta_data.FieldMetaData>(_Fields.class);
tmpMap.put(_Fields.ID,new org.apache.storm.thrift.meta_data.FieldMetaData("id",org.apache.storm.thrift.TFieldRequirementType.DEFAULT,new org.apache.storm.thrift.meta_data.FieldValueMetaData(org.apache.storm.thrift.protocol.TType.STRING)));
metaDataMap=java.util.Collections.unmodifiableMap(tmpMap);
org.apache.storm.thrift.meta_data.FieldMetaData.addStructMetaDataMap(getTopologyConf_args.class,metaDataMap);
}
public getTopologyConf_args(){
}
public getTopologyConf_args(java.lang.String id){
this();
this.id=id;
}
/** 
 * Performs a deep copy on <i>other</i>.
 */
public getTopologyConf_args(getTopologyConf_args other){
if (other.is_set_id()) {
  this.id=other.id;
}
}
public getTopologyConf_args deepCopy(){
return new getTopologyConf_args(this);
}
@Override public void clear(){
this.id=null;
}
@org.apache.storm.thrift.annotation.Nullable public java.lang.String get_id(){
return this.id;
}
public void set_id(@org.apache.storm.thrift.annotation.Nullable java.lang.String id){
this.id=id;
}
public void unset_id(){
this.id=null;
}
/** 
 * Returns true if field id is set (has been assigned a value) and false otherwise 
 */
public boolean is_set_id(){
return this.id != null;
}
public void set_id_isSet(boolean value){
if (!value) {
  this.id=null;
}
}
public void setFieldValue(_Fields field,@org.apache.storm.thrift.annotation.Nullable java.lang.Object value){
switch (field) {
case ID:
  if (value == null) {
    unset_id();
  }
 else {
    set_id((java.lang.String)value);
  }
break;
}
}
@org.apache.storm.thrift.annotation.Nullable public java.lang.Object getFieldValue(_Fields field){
switch (field) {
case ID:
return get_id();
}
throw new java.lang.IllegalStateException();
}
/** 
 * Returns true if field corresponding to fieldID is set (has been assigned a value) and false otherwise 
 */
public boolean isSet(_Fields field){
if (field == null) {
throw new java.lang.IllegalArgumentException();
}
switch (field) {
case ID:
return is_set_id();
}
throw new java.lang.IllegalStateException();
}
@Override public boolean equals(java.lang.Object that){
if (that == null) return false;
if (that instanceof getTopologyConf_args) return this.equals((getTopologyConf_args)that);
return false;
}
public boolean equals(getTopologyConf_args that){
if (that == null) return false;
if (this == that) return true;
boolean this_present_id=true && this.is_set_id();
boolean that_present_id=true && that.is_set_id();
if (this_present_id || that_present_id) {
if (!(this_present_id && that_present_id)) return false;
if (!this.id.equals(that.id)) return false;
}
return true;
}
@Override public int hashCode(){
int hashCode=1;
hashCode=hashCode * 8191 + ((is_set_id()) ? 131071 : 524287);
if (is_set_id()) hashCode=hashCode * 8191 + id.hashCode();
return hashCode;
}
@Override public int compareTo(getTopologyConf_args other){
if (!getClass().equals(other.getClass())) {
return getClass().getName().compareTo(other.getClass().getName());
}
int lastComparison=0;
lastComparison=java.lang.Boolean.valueOf(is_set_id()).compareTo(other.is_set_id());
if (lastComparison != 0) {
return lastComparison;
}
if (is_set_id()) {
lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.id,other.id);
if (lastComparison != 0) {
return lastComparison;
}
}
return 0;
}
@org.apache.storm.thrift.annotation.Nullable public _Fields fieldForId(int fieldId){
return _Fields.findByThriftId(fieldId);
}
public void read(org.apache.storm.thrift.protocol.TProtocol iprot) throws org.apache.storm.thrift.TException {
scheme(iprot).read(iprot,this);
}
public void write(org.apache.storm.thrift.protocol.TProtocol oprot) throws org.apache.storm.thrift.TException {
scheme(oprot).write(oprot,this);
}
@Override public java.lang.String toString(){
java.lang.StringBuilder sb=new java.lang.StringBuilder("getTopologyConf_args(");
boolean first=true;
sb.append("id:");
if (this.id == null) {
sb.append("null");
}
 else {
sb.append(this.id);
}
first=false;
sb.append(")");
return sb.toString();
}
public void validate() throws org.apache.storm.thrift.TException {
}
private void writeObject(java.io.ObjectOutputStream out) throws java.io.IOException {
try {
write(new org.apache.storm.thrift.protocol.TCompactProtocol(new org.apache.storm.thrift.transport.TIOStreamTransport(out)));
}
 catch (org.apache.storm.thrift.TException te) {
throw new java.io.IOException(te);
}
}
private void readObject(java.io.ObjectInputStream in) throws java.io.IOException, java.lang.ClassNotFoundException {
try {
read(new org.apache.storm.thrift.protocol.TCompactProtocol(new org.apache.storm.thrift.transport.TIOStreamTransport(in)));
}
 catch (org.apache.storm.thrift.TException te) {
throw new java.io.IOException(te);
}
}
private static class getTopologyConf_argsStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
public getTopologyConf_argsStandardScheme getScheme(){
return new getTopologyConf_argsStandardScheme();
}
}
private static class getTopologyConf_argsStandardScheme extends org.apache.storm.thrift.scheme.StandardScheme<getTopologyConf_args> {
public void read(org.apache.storm.thrift.protocol.TProtocol iprot,getTopologyConf_args struct) throws org.apache.storm.thrift.TException {
org.apache.storm.thrift.protocol.TField schemeField;
iprot.readStructBegin();
while (true) {
schemeField=iprot.readFieldBegin();
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STOP) {
break;
}
switch (schemeField.id) {
case 1:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
struct.id=iprot.readString();
struct.set_id_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
default :
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
iprot.readFieldEnd();
}
iprot.readStructEnd();
struct.validate();
}
public void write(org.apache.storm.thrift.protocol.TProtocol oprot,getTopologyConf_args struct) throws org.apache.storm.thrift.TException {
struct.validate();
oprot.writeStructBegin(STRUCT_DESC);
if (struct.id != null) {
oprot.writeFieldBegin(ID_FIELD_DESC);
oprot.writeString(struct.id);
oprot.writeFieldEnd();
}
oprot.writeFieldStop();
oprot.writeStructEnd();
}
}
private static class getTopologyConf_argsTupleSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
public getTopologyConf_argsTupleScheme getScheme(){
return new getTopologyConf_argsTupleScheme();
}
}
private static class getTopologyConf_argsTupleScheme extends org.apache.storm.thrift.scheme.TupleScheme<getTopologyConf_args> {
@Override public void write(org.apache.storm.thrift.protocol.TProtocol prot,getTopologyConf_args struct) throws org.apache.storm.thrift.TException {
org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
java.util.BitSet optionals=new java.util.BitSet();
if (struct.is_set_id()) {
optionals.set(0);
}
oprot.writeBitSet(optionals,1);
if (struct.is_set_id()) {
oprot.writeString(struct.id);
}
}
@Override public void read(org.apache.storm.thrift.protocol.TProtocol prot,getTopologyConf_args struct) throws org.apache.storm.thrift.TException {
org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
java.util.BitSet incoming=iprot.readBitSet(1);
if (incoming.get(0)) {
struct.id=iprot.readString();
struct.set_id_isSet(true);
}
}
}
private static <S extends org.apache.storm.thrift.scheme.IScheme>S scheme(org.apache.storm.thrift.protocol.TProtocol proto){
return (org.apache.storm.thrift.scheme.StandardScheme.class.equals(proto.getScheme()) ? STANDARD_SCHEME_FACTORY : TUPLE_SCHEME_FACTORY).getScheme();
}
}
