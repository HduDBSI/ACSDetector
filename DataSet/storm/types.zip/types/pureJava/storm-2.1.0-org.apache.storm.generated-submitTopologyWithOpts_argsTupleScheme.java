private static class submitTopologyWithOpts_argsTupleScheme extends org.apache.storm.thrift.scheme.TupleScheme<submitTopologyWithOpts_args> {
  @Override public void write(  org.apache.storm.thrift.protocol.TProtocol prot,  submitTopologyWithOpts_args struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
    java.util.BitSet optionals=new java.util.BitSet();
    if (struct.is_set_name()) {
      optionals.set(0);
    }
    if (struct.is_set_uploadedJarLocation()) {
      optionals.set(1);
    }
    if (struct.is_set_jsonConf()) {
      optionals.set(2);
    }
    if (struct.is_set_topology()) {
      optionals.set(3);
    }
    if (struct.is_set_options()) {
      optionals.set(4);
    }
    oprot.writeBitSet(optionals,5);
    if (struct.is_set_name()) {
      oprot.writeString(struct.name);
    }
    if (struct.is_set_uploadedJarLocation()) {
      oprot.writeString(struct.uploadedJarLocation);
    }
    if (struct.is_set_jsonConf()) {
      oprot.writeString(struct.jsonConf);
    }
    if (struct.is_set_topology()) {
      struct.topology.write(oprot);
    }
    if (struct.is_set_options()) {
      struct.options.write(oprot);
    }
  }
  @Override public void read(  org.apache.storm.thrift.protocol.TProtocol prot,  submitTopologyWithOpts_args struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
    java.util.BitSet incoming=iprot.readBitSet(5);
    if (incoming.get(0)) {
      struct.name=iprot.readString();
      struct.set_name_isSet(true);
    }
    if (incoming.get(1)) {
      struct.uploadedJarLocation=iprot.readString();
      struct.set_uploadedJarLocation_isSet(true);
    }
    if (incoming.get(2)) {
      struct.jsonConf=iprot.readString();
      struct.set_jsonConf_isSet(true);
    }
    if (incoming.get(3)) {
      struct.topology=new StormTopology();
      struct.topology.read(iprot);
      struct.set_topology_isSet(true);
    }
    if (incoming.get(4)) {
      struct.options=new SubmitOptions();
      struct.options.read(iprot);
      struct.set_options_isSet(true);
    }
  }
}
