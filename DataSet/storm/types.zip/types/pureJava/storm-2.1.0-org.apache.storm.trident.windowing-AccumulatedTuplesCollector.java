/** 
 * This  {@code TridentCollector} accumulates all the values emitted.
 */
static class AccumulatedTuplesCollector implements TridentCollector {
  final List<List<Object>> values=new ArrayList<>();
  private final BatchOutputCollector delegateCollector;
  public AccumulatedTuplesCollector(  BatchOutputCollector delegateCollector){
    this.delegateCollector=delegateCollector;
  }
  @Override public void emit(  List<Object> values){
    this.values.add(values);
  }
  @Override public void flush(){
  }
  @Override public void reportError(  Throwable t){
    delegateCollector.reportError(t);
  }
}
