private static class getBlobMeta_resultStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public getBlobMeta_resultStandardScheme getScheme(){
    return new getBlobMeta_resultStandardScheme();
  }
}
