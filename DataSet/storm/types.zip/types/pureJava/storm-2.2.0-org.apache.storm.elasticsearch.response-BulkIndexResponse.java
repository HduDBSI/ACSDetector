/** 
 * Mapped response for bulk index.
 */
public class BulkIndexResponse {
  private boolean errors;
  private long took;
  private List<IndexItemDoc> items;
  public BulkIndexResponse(){
  }
  public boolean hasErrors(){
    return errors;
  }
  public void setErrors(  boolean errors){
    this.errors=errors;
  }
  public long getTook(){
    return took;
  }
  public void setTook(  long took){
    this.took=took;
  }
  public List<IndexItemDoc> getItems(){
    return items;
  }
  public void setItems(  List<IndexItemDoc> items){
    this.items=items;
  }
  /** 
 * Retrieve first error's code from response.
 * @return error status code
 */
  public Integer getFirstError(){
    if (items == null || items.isEmpty()) {
      return null;
    }
    for (    IndexItemDoc item : items) {
      int status=item.getIndex().getStatus();
      if (400 <= status && status <= 599) {
        return status;
      }
    }
    return null;
  }
  /** 
 * Retrieve first result from response.
 * @return result text
 */
  public String getFirstResult(){
    if (items == null || items.isEmpty()) {
      return null;
    }
    return items.get(0).getIndex().getResult();
  }
}
