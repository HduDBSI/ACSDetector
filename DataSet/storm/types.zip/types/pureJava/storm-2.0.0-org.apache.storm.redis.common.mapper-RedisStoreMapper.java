/** 
 * RedisStoreMapper is for defining spec. which is used for storing value to Redis.
 */
public interface RedisStoreMapper extends TupleMapper, RedisMapper {
}
