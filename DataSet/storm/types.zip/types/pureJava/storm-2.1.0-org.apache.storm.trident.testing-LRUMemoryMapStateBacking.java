@SuppressWarnings("checkstyle:AbbreviationAsWordInName") static class LRUMemoryMapStateBacking<T> implements IBackingMap<T>, ITupleCollection {
  Map<List<Object>,T> db;
  Long currTx;
  public LRUMemoryMapStateBacking(  int cacheSize,  String id){
    if (!dbs.containsKey(id)) {
      dbs.put(id,new LRUMap<List<Object>,Object>(cacheSize));
    }
    this.db=(Map<List<Object>,T>)dbs.get(id);
  }
  public static void clearAll(){
    dbs.clear();
  }
  @Override public List<T> multiGet(  List<List<Object>> keys){
    List<T> ret=new ArrayList();
    for (    List<Object> key : keys) {
      ret.add(db.get(key));
    }
    return ret;
  }
  @Override public void multiPut(  List<List<Object>> keys,  List<T> vals){
    for (int i=0; i < keys.size(); i++) {
      List<Object> key=keys.get(i);
      T val=vals.get(i);
      db.put(key,val);
    }
  }
  @Override public Iterator<List<Object>> getTuples(){
    return new Iterator<List<Object>>(){
      private Iterator<Map.Entry<List<Object>,T>> it=db.entrySet().iterator();
      @Override public boolean hasNext(){
        return it.hasNext();
      }
      @Override public List<Object> next(){
        Map.Entry<List<Object>,T> e=it.next();
        List<Object> ret=new ArrayList<Object>();
        ret.addAll(e.getKey());
        ret.add(((OpaqueValue)e.getValue()).getCurr());
        return ret;
      }
      @Override public void remove(){
        throw new UnsupportedOperationException("Not supported yet.");
      }
    }
;
  }
}
