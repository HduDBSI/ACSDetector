/** 
 * Local Resource requested by the topology.
 */
public class LocalResource {
  private final boolean needsCallback;
  private final String blobKey;
  private final boolean uncompress;
  /** 
 * Constructor.
 * @param keyname the key of the blob to download.
 * @param uncompress should the blob be uncompressed or not.
 * @param needsCallback if the blobs changes should a callback happen so the worker is restarted.
 */
  public LocalResource(  String keyname,  boolean uncompress,  boolean needsCallback){
    blobKey=keyname;
    this.uncompress=uncompress;
    this.needsCallback=needsCallback;
  }
  public String getBlobName(){
    return blobKey;
  }
  public boolean shouldUncompress(){
    return uncompress;
  }
  public boolean needsCallback(){
    return needsCallback;
  }
  @Override public String toString(){
    return "Key: " + blobKey + " uncompress: "+ uncompress;
  }
}
