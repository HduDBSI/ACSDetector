/** 
 * Default handler for batch asynchronous execution.
 */
public interface AsyncResultSetHandler<T> extends Serializable {
  AsyncResultSetHandler NO_OP_HANDLER=new AsyncResultSetHandler(){
    @Override public void failure(    Throwable t,    Object inputs){
    }
    @Override public void success(    Object inputs,    ResultSet resultSet){
    }
  }
;
  /** 
 * This method is responsible for failing specified inputs.
 * @param t The cause the failure.
 * @param inputs The input tuple proceed.
 */
  void failure(  Throwable t,  T inputs);
  /** 
 * This method is responsible for acknowledging specified inputs.
 * @param inputs The input tuple proceed.
 */
  void success(  T inputs,  ResultSet resultSet);
}
