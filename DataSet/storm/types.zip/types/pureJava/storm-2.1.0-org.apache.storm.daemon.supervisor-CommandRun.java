public static class CommandRun {
  final List<String> cmd;
  final Map<String,String> env;
  final File pwd;
  public CommandRun(  List<String> cmd,  Map<String,String> env,  File pwd){
    this.cmd=cmd;
    this.env=env;
    this.pwd=pwd;
  }
}
