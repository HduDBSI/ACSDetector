public interface TestableTopology {
  String DUMMY_FIELD="dummy";
  int TIMEDATA_SLEEP_BETWEEN_EMITS_MS=20;
  long MAX_SPOUT_EMITS=TimeUnit.MINUTES.toMillis(5) / TIMEDATA_SLEEP_BETWEEN_EMITS_MS;
  StormTopology newTopology();
  String getBoltName();
  int getBoltExecutors();
  String getSpoutName();
  int getSpoutExecutors();
}
