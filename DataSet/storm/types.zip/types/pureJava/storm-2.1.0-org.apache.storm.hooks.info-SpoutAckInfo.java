public class SpoutAckInfo {
  public Object messageId;
  public int spoutTaskId;
  public Long completeLatencyMs;
  public SpoutAckInfo(  Object messageId,  int spoutTaskId,  Long completeLatencyMs){
    this.messageId=messageId;
    this.spoutTaskId=spoutTaskId;
    this.completeLatencyMs=completeLatencyMs;
  }
  public void applyOn(  TopologyContext topologyContext){
    for (    ITaskHook hook : topologyContext.getHooks()) {
      hook.spoutAck(this);
    }
  }
}
