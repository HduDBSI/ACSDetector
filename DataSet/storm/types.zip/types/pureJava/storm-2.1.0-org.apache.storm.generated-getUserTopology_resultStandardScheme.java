private static class getUserTopology_resultStandardScheme extends org.apache.storm.thrift.scheme.StandardScheme<getUserTopology_result> {
  public void read(  org.apache.storm.thrift.protocol.TProtocol iprot,  getUserTopology_result struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TField schemeField;
    iprot.readStructBegin();
    while (true) {
      schemeField=iprot.readFieldBegin();
      if (schemeField.type == org.apache.storm.thrift.protocol.TType.STOP) {
        break;
      }
switch (schemeField.id) {
case 0:
        if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRUCT) {
          struct.success=new StormTopology();
          struct.success.read(iprot);
          struct.set_success_isSet(true);
        }
 else {
          org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
        }
      break;
case 1:
    if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRUCT) {
      struct.e=new NotAliveException();
      struct.e.read(iprot);
      struct.set_e_isSet(true);
    }
 else {
      org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
    }
  break;
case 2:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRUCT) {
  struct.aze=new AuthorizationException();
  struct.aze.read(iprot);
  struct.set_aze_isSet(true);
}
 else {
  org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
default :
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
iprot.readFieldEnd();
}
iprot.readStructEnd();
struct.validate();
}
public void write(org.apache.storm.thrift.protocol.TProtocol oprot,getUserTopology_result struct) throws org.apache.storm.thrift.TException {
struct.validate();
oprot.writeStructBegin(STRUCT_DESC);
if (struct.success != null) {
oprot.writeFieldBegin(SUCCESS_FIELD_DESC);
struct.success.write(oprot);
oprot.writeFieldEnd();
}
if (struct.e != null) {
oprot.writeFieldBegin(E_FIELD_DESC);
struct.e.write(oprot);
oprot.writeFieldEnd();
}
if (struct.aze != null) {
oprot.writeFieldBegin(AZE_FIELD_DESC);
struct.aze.write(oprot);
oprot.writeFieldEnd();
}
oprot.writeFieldStop();
oprot.writeStructEnd();
}
}
