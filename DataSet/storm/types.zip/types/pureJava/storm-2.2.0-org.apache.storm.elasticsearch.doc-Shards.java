/** 
 * Elasticsearch document fragment containing shard success information, used in percolate and bulk index responses.
 */
public class Shards {
  private int total;
  private int successful;
  private int failed;
  private List<Object> failures;
  public int getTotal(){
    return total;
  }
  public void setTotal(  int total){
    this.total=total;
  }
  public int getSuccessful(){
    return successful;
  }
  public void setSuccessful(  int successful){
    this.successful=successful;
  }
  public int getFailed(){
    return failed;
  }
  public void setFailed(  int failed){
    this.failed=failed;
  }
  public List<Object> getFailures(){
    return failures;
  }
  public void setFailures(  List<Object> failures){
    this.failures=failures;
  }
}
