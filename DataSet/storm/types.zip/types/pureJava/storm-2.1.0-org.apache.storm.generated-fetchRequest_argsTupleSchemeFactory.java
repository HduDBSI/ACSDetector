private static class fetchRequest_argsTupleSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public fetchRequest_argsTupleScheme getScheme(){
    return new fetchRequest_argsTupleScheme();
  }
}
