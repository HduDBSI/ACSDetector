private static class AccessControlStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public AccessControlStandardScheme getScheme(){
    return new AccessControlStandardScheme();
  }
}
