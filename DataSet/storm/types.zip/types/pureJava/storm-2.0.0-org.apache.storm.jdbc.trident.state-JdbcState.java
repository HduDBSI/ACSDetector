public class JdbcState implements State {
  private static final Logger LOG=LoggerFactory.getLogger(JdbcState.class);
  private Options options;
  private JdbcClient jdbcClient;
  private Map map;
  protected JdbcState(  Map<String,Object> map,  int partitionIndex,  int numPartitions,  Options options){
    this.options=options;
    this.map=map;
  }
  protected void prepare(){
    options.connectionProvider.prepare();
    if (StringUtils.isBlank(options.insertQuery) && StringUtils.isBlank(options.tableName) && StringUtils.isBlank(options.selectQuery)) {
      throw new IllegalArgumentException("If you are trying to insert into DB you must supply either insertQuery or tableName." + "If you are attempting to user a query state you must supply a select query.");
    }
    if (options.queryTimeoutSecs == null) {
      options.queryTimeoutSecs=Integer.parseInt(map.get(Config.TOPOLOGY_MESSAGE_TIMEOUT_SECS).toString());
    }
    this.jdbcClient=new JdbcClient(options.connectionProvider,options.queryTimeoutSecs);
  }
  @Override public void beginCommit(  Long aLong){
    LOG.debug("beginCommit is noop.");
  }
  @Override public void commit(  Long aLong){
    LOG.debug("commit is noop.");
  }
  public void updateState(  List<TridentTuple> tuples,  TridentCollector collector){
    List<List<Column>> columnsLists=new ArrayList<List<Column>>();
    for (    TridentTuple tuple : tuples) {
      columnsLists.add(options.mapper.getColumns(tuple));
    }
    try {
      if (!StringUtils.isBlank(options.tableName)) {
        jdbcClient.insert(options.tableName,columnsLists);
      }
 else {
        jdbcClient.executeInsertQuery(options.insertQuery,columnsLists);
      }
    }
 catch (    Exception e) {
      LOG.warn("Batch write failed but some requests might have succeeded. Triggering replay.",e);
      throw new FailedException(e);
    }
  }
  public List<List<Values>> batchRetrieve(  List<TridentTuple> tridentTuples){
    List<List<Values>> batchRetrieveResult=Lists.newArrayList();
    try {
      for (      TridentTuple tuple : tridentTuples) {
        List<Column> columns=options.jdbcLookupMapper.getColumns(tuple);
        List<List<Column>> rows=jdbcClient.select(options.selectQuery,columns);
        for (        List<Column> row : rows) {
          List<Values> values=options.jdbcLookupMapper.toTuple(tuple,row);
          batchRetrieveResult.add(values);
        }
      }
    }
 catch (    Exception e) {
      LOG.warn("Batch get operation failed. Triggering replay.",e);
      throw new FailedException(e);
    }
    return batchRetrieveResult;
  }
public static class Options implements Serializable {
    private JdbcMapper mapper;
    private JdbcLookupMapper jdbcLookupMapper;
    private ConnectionProvider connectionProvider;
    private String tableName;
    private String insertQuery;
    private String selectQuery;
    private Integer queryTimeoutSecs;
    public Options withConnectionProvider(    ConnectionProvider connectionProvider){
      this.connectionProvider=connectionProvider;
      return this;
    }
    public Options withTableName(    String tableName){
      this.tableName=tableName;
      return this;
    }
    public Options withInsertQuery(    String insertQuery){
      this.insertQuery=insertQuery;
      return this;
    }
    public Options withMapper(    JdbcMapper mapper){
      this.mapper=mapper;
      return this;
    }
    public Options withJdbcLookupMapper(    JdbcLookupMapper jdbcLookupMapper){
      this.jdbcLookupMapper=jdbcLookupMapper;
      return this;
    }
    public Options withSelectQuery(    String selectQuery){
      this.selectQuery=selectQuery;
      return this;
    }
    public Options withQueryTimeoutSecs(    int queryTimeoutSecs){
      this.queryTimeoutSecs=queryTimeoutSecs;
      return this;
    }
  }
}
