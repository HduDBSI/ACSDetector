private static class updateBlobReplication_argsStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public updateBlobReplication_argsStandardScheme getScheme(){
    return new updateBlobReplication_argsStandardScheme();
  }
}
