/** 
 * Created by pbrahmbhatt on 10/29/15.
 */
public class JdbcLookupBoltTest {
  @Test public void testValidation(){
    ConnectionProvider provider=new HikariCPConnectionProvider(new HashMap<String,Object>());
    JdbcLookupMapper mapper=new SimpleJdbcLookupMapper(new Fields("test"),Lists.newArrayList(new Column("test",0)));
    String selectQuery="select * from dual";
    expectIllegaArgs(null,selectQuery,mapper);
    expectIllegaArgs(provider,null,mapper);
    expectIllegaArgs(provider,selectQuery,null);
  }
  private void expectIllegaArgs(  ConnectionProvider provider,  String selectQuery,  JdbcLookupMapper mapper){
    try {
      JdbcLookupBolt bolt=new JdbcLookupBolt(provider,selectQuery,mapper);
      Assert.fail("Should have thrown IllegalArgumentException.");
    }
 catch (    IllegalArgumentException ne) {
    }
  }
}
