public interface IPartitionManager {
  void open() throws Exception ;
  void close();
  EventDataWrap receive();
  void checkpoint();
  void ack(  String offset);
  void fail(  String offset);
  Map<String,Object> getMetricsData();
}
