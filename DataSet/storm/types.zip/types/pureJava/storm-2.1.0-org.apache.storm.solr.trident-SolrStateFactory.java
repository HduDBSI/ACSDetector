public class SolrStateFactory implements StateFactory {
  private final SolrConfig solrConfig;
  private final SolrMapper solrMapper;
  public SolrStateFactory(  SolrConfig solrConfig,  SolrMapper solrMapper){
    this.solrConfig=solrConfig;
    this.solrMapper=solrMapper;
  }
  @Override public State makeState(  Map<String,Object> map,  IMetricsContext metricsContext,  int partitionIndex,  int numPartitions){
    SolrState state=new SolrState(solrConfig,solrMapper);
    state.prepare();
    return state;
  }
}
