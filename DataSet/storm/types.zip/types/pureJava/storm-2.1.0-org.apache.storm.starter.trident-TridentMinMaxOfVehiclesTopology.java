/** 
 * This class demonstrates different usages of *  {@link Stream#minBy(String,Comparator)}*  {@link Stream#min(Comparator)}*  {@link Stream#maxBy(String,Comparator)}*  {@link Stream#max(Comparator)}operations on trident  {@link Stream}.
 */
public class TridentMinMaxOfVehiclesTopology {
  /** 
 * Creates a topology which demonstrates min/max operations on tuples of stream which contain vehicle and driver fields with values  {@link TridentMinMaxOfVehiclesTopology.Vehicle} and {@link TridentMinMaxOfVehiclesTopology.Driver} respectively.
 */
  public static StormTopology buildVehiclesTopology(){
    Fields driverField=new Fields(Driver.FIELD_NAME);
    Fields vehicleField=new Fields(Vehicle.FIELD_NAME);
    Fields allFields=new Fields(Vehicle.FIELD_NAME,Driver.FIELD_NAME);
    FixedBatchSpout spout=new FixedBatchSpout(allFields,10,Vehicle.generateVehicles(20));
    spout.setCycle(true);
    TridentTopology topology=new TridentTopology();
    Stream vehiclesStream=topology.newStream("spout1",spout).each(allFields,new Debug("##### vehicles"));
    Stream slowVehiclesStream=vehiclesStream.min(new SpeedComparator()).each(vehicleField,new Debug("#### slowest vehicle"));
    Stream slowDriversStream=slowVehiclesStream.project(driverField).each(driverField,new Debug("##### slowest driver"));
    vehiclesStream.max(new SpeedComparator()).each(vehicleField,new Debug("#### fastest vehicle")).project(driverField).each(driverField,new Debug("##### fastest driver"));
    vehiclesStream.minBy(Vehicle.FIELD_NAME,new EfficiencyComparator()).each(vehicleField,new Debug("#### least efficient vehicle"));
    vehiclesStream.maxBy(Vehicle.FIELD_NAME,new EfficiencyComparator()).each(vehicleField,new Debug("#### most efficient vehicle"));
    return topology.build();
  }
  public static void main(  String[] args) throws Exception {
    StormTopology topology=buildVehiclesTopology();
    Config conf=new Config();
    conf.setMaxSpoutPending(20);
    conf.setNumWorkers(3);
    StormSubmitter.submitTopologyWithProgressBar("vehicles-topology",conf,topology);
  }
static class SpeedComparator implements Comparator<TridentTuple>, Serializable {
    @Override public int compare(    TridentTuple tuple1,    TridentTuple tuple2){
      Vehicle vehicle1=(Vehicle)tuple1.getValueByField(Vehicle.FIELD_NAME);
      Vehicle vehicle2=(Vehicle)tuple2.getValueByField(Vehicle.FIELD_NAME);
      return Integer.compare(vehicle1.maxSpeed,vehicle2.maxSpeed);
    }
  }
static class EfficiencyComparator implements Comparator<Vehicle>, Serializable {
    @Override public int compare(    Vehicle vehicle1,    Vehicle vehicle2){
      return Double.compare(vehicle1.efficiency,vehicle2.efficiency);
    }
  }
static class Driver implements Serializable {
    static final String FIELD_NAME="driver";
    final String name;
    final int id;
    Driver(    String name,    int id){
      this.name=name;
      this.id=id;
    }
    @Override public String toString(){
      return "Driver{" + "name='" + name + '\''+ ", id="+ id+ '}';
    }
  }
static class Vehicle implements Serializable {
    static final String FIELD_NAME="vehicle";
    final String name;
    final int maxSpeed;
    final double efficiency;
    public Vehicle(    String name,    int maxSpeed,    double efficiency){
      this.name=name;
      this.maxSpeed=maxSpeed;
      this.efficiency=efficiency;
    }
    public static List<Object>[] generateVehicles(    int count){
      List<Object>[] vehicles=new List[count];
      for (int i=0; i < count; i++) {
        int id=i - 1;
        vehicles[i]=(new Values(new Vehicle("Vehicle-" + id,ThreadLocalRandom.current().nextInt(0,100),ThreadLocalRandom.current().nextDouble(1,5)),new Driver("Driver-" + id,id)));
      }
      return vehicles;
    }
    @Override public String toString(){
      return "Vehicle{" + "name='" + name + '\''+ ", maxSpeed="+ maxSpeed+ ", efficiency="+ efficiency+ '}';
    }
  }
}
