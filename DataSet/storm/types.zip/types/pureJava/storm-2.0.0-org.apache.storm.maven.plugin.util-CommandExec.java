public class CommandExec {
  private Mojo mojo;
  public CommandExec(  Mojo mojo){
    this.mojo=mojo;
  }
  public int run(  List<String> command,  List<String> output){
    int retCode=1;
    ProcessBuilder pb=new ProcessBuilder(command);
    try {
      Process p=pb.start();
      OutputBufferThread stdOut=new OutputBufferThread(p.getInputStream());
      OutputBufferThread stdErr=new OutputBufferThread(p.getErrorStream());
      stdOut.start();
      stdErr.start();
      retCode=p.waitFor();
      if (retCode != 0) {
        mojo.getLog().warn(command + " failed with error code " + retCode);
        for (        String s : stdErr.getOutput()) {
          mojo.getLog().debug(s);
        }
      }
      stdOut.join();
      stdErr.join();
      output.addAll(stdOut.getOutput());
    }
 catch (    Exception ex) {
      mojo.getLog().warn(command + " failed: " + ex.toString());
    }
    return retCode;
  }
private static class OutputBufferThread extends Thread {
    private List<String> output;
    private BufferedReader reader;
    public OutputBufferThread(    InputStream is){
      this.setDaemon(true);
      output=new ArrayList<String>();
      reader=new BufferedReader(new InputStreamReader(is));
    }
    @Override public void run(){
      try {
        String line=reader.readLine();
        while (line != null) {
          output.add(line);
          line=reader.readLine();
        }
      }
 catch (      IOException ex) {
        throw new RuntimeException("make failed with error code " + ex.toString());
      }
    }
    public List<String> getOutput(){
      return output;
    }
  }
}
