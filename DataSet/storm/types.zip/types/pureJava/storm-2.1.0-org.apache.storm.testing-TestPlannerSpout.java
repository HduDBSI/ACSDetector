public class TestPlannerSpout extends BaseRichSpout {
  boolean isDistributed;
  Fields outFields;
  public TestPlannerSpout(  Fields outFields,  boolean isDistributed){
    this.isDistributed=isDistributed;
    this.outFields=outFields;
  }
  public TestPlannerSpout(  boolean isDistributed){
    this(new Fields("field1","field2"),isDistributed);
  }
  public TestPlannerSpout(  Fields outFields){
    this(outFields,true);
  }
  public Fields getOutputFields(){
    return outFields;
  }
  @Override public void open(  Map<String,Object> conf,  TopologyContext context,  SpoutOutputCollector collector){
  }
  @Override public void close(){
  }
  @Override public void nextTuple(){
    Utils.sleep(100);
  }
  @Override public void ack(  Object msgId){
  }
  @Override public void fail(  Object msgId){
  }
  @Override public void declareOutputFields(  OutputFieldsDeclarer declarer){
    declarer.declare(getOutputFields());
  }
  @Override public Map<String,Object> getComponentConfiguration(){
    Map<String,Object> ret=new HashMap<String,Object>();
    if (!isDistributed) {
      ret.put(Config.TOPOLOGY_MAX_TASK_PARALLELISM,1);
    }
    return ret;
  }
}
