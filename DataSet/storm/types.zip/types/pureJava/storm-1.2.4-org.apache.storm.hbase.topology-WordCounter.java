public class WordCounter implements IBasicBolt {
  @SuppressWarnings("rawtypes") public void prepare(  Map stormConf,  TopologyContext context){
  }
  public void execute(  Tuple input,  BasicOutputCollector collector){
    collector.emit(tuple(input.getValues().get(0),1));
  }
  public void cleanup(){
  }
  public void declareOutputFields(  OutputFieldsDeclarer declarer){
    declarer.declare(new Fields("word","count"));
  }
  @Override public Map<String,Object> getComponentConfiguration(){
    return null;
  }
}
