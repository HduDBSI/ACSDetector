private static class getLogConfig_resultStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public getLogConfig_resultStandardScheme getScheme(){
    return new getLogConfig_resultStandardScheme();
  }
}
