public class GroupedStream implements IAggregatableStream, GlobalAggregationScheme<GroupedStream> {
  Fields groupFields;
  Stream stream;
  public GroupedStream(  Stream stream,  Fields groupFields){
    this.groupFields=groupFields;
    this.stream=stream;
  }
  public GroupedStream name(  String name){
    return new GroupedStream(stream.name(name),groupFields);
  }
  public ChainedAggregatorDeclarer chainedAgg(){
    return new ChainedAggregatorDeclarer(this,this);
  }
  public Stream aggregate(  Aggregator agg,  Fields functionFields){
    return aggregate(null,agg,functionFields);
  }
  public Stream aggregate(  Fields inputFields,  Aggregator agg,  Fields functionFields){
    return new ChainedAggregatorDeclarer(this,this).aggregate(inputFields,agg,functionFields).chainEnd();
  }
  public Stream aggregate(  CombinerAggregator agg,  Fields functionFields){
    return aggregate(null,agg,functionFields);
  }
  public Stream aggregate(  Fields inputFields,  CombinerAggregator agg,  Fields functionFields){
    return new ChainedAggregatorDeclarer(this,this).aggregate(inputFields,agg,functionFields).chainEnd();
  }
  public Stream aggregate(  ReducerAggregator agg,  Fields functionFields){
    return aggregate(null,agg,functionFields);
  }
  public Stream aggregate(  Fields inputFields,  ReducerAggregator agg,  Fields functionFields){
    return new ChainedAggregatorDeclarer(this,this).aggregate(inputFields,agg,functionFields).chainEnd();
  }
  public TridentState persistentAggregate(  StateFactory stateFactory,  CombinerAggregator agg,  Fields functionFields){
    return persistentAggregate(new StateSpec(stateFactory),agg,functionFields);
  }
  public TridentState persistentAggregate(  StateSpec spec,  CombinerAggregator agg,  Fields functionFields){
    return persistentAggregate(spec,null,agg,functionFields);
  }
  public TridentState persistentAggregate(  StateFactory stateFactory,  Fields inputFields,  CombinerAggregator agg,  Fields functionFields){
    return persistentAggregate(new StateSpec(stateFactory),inputFields,agg,functionFields);
  }
  public TridentState persistentAggregate(  StateSpec spec,  Fields inputFields,  CombinerAggregator agg,  Fields functionFields){
    return aggregate(inputFields,agg,functionFields).partitionPersist(spec,TridentUtils.fieldsUnion(groupFields,functionFields),new MapCombinerAggStateUpdater(agg,groupFields,functionFields),TridentUtils.fieldsConcat(groupFields,functionFields));
  }
  public TridentState persistentAggregate(  StateFactory stateFactory,  Fields inputFields,  ReducerAggregator agg,  Fields functionFields){
    return persistentAggregate(new StateSpec(stateFactory),inputFields,agg,functionFields);
  }
  public TridentState persistentAggregate(  StateSpec spec,  Fields inputFields,  ReducerAggregator agg,  Fields functionFields){
    return stream.partitionBy(groupFields).partitionPersist(spec,TridentUtils.fieldsUnion(groupFields,inputFields),new MapReducerAggStateUpdater(agg,groupFields,inputFields),TridentUtils.fieldsConcat(groupFields,functionFields));
  }
  public TridentState persistentAggregate(  StateFactory stateFactory,  ReducerAggregator agg,  Fields functionFields){
    return persistentAggregate(new StateSpec(stateFactory),agg,functionFields);
  }
  public TridentState persistentAggregate(  StateSpec spec,  ReducerAggregator agg,  Fields functionFields){
    return persistentAggregate(spec,null,agg,functionFields);
  }
  public Stream stateQuery(  TridentState state,  Fields inputFields,  QueryFunction function,  Fields functionFields){
    return stream.partitionBy(groupFields).stateQuery(state,inputFields,function,functionFields);
  }
  public Stream stateQuery(  TridentState state,  QueryFunction function,  Fields functionFields){
    return stateQuery(state,null,function,functionFields);
  }
  @Override public IAggregatableStream each(  Fields inputFields,  Function function,  Fields functionFields){
    Stream s=stream.each(inputFields,function,functionFields);
    return new GroupedStream(s,groupFields);
  }
  @Override public IAggregatableStream partitionAggregate(  Fields inputFields,  Aggregator agg,  Fields functionFields){
    Aggregator groupedAgg=new GroupedAggregator(agg,groupFields,inputFields,functionFields.size());
    Fields allInFields=TridentUtils.fieldsUnion(groupFields,inputFields);
    Fields allOutFields=TridentUtils.fieldsConcat(groupFields,functionFields);
    Stream s=stream.partitionAggregate(allInFields,groupedAgg,allOutFields);
    return new GroupedStream(s,groupFields);
  }
  @Override public IAggregatableStream aggPartition(  GroupedStream s){
    return new GroupedStream(s.stream.partitionBy(groupFields),groupFields);
  }
  @Override public Stream toStream(){
    return stream;
  }
  @Override public Fields getOutputFields(){
    return stream.getOutputFields();
  }
  public Fields getGroupFields(){
    return groupFields;
  }
  @Override public BatchToPartition singleEmitPartitioner(){
    return null;
  }
}
