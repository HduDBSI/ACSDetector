public class NettyUncaughtExceptionHandler implements Thread.UncaughtExceptionHandler {
  private static final Logger LOG=LoggerFactory.getLogger(NettyUncaughtExceptionHandler.class);
  @Override public void uncaughtException(  Thread t,  Throwable e){
    try {
      LOG.error("Uncaught exception in netty " + e.getCause());
    }
 catch (    Throwable err) {
    }
    try {
      Utils.handleUncaughtException(e);
    }
 catch (    Throwable throwable) {
      LOG.error("Exception thrown while handling uncaught exception " + throwable.getCause());
    }
    LOG.info("Received error in netty thread.. terminating server...");
    Runtime.getRuntime().exit(1);
  }
}
