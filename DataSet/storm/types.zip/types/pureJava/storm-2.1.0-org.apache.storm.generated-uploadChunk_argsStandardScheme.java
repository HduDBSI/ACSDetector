private static class uploadChunk_argsStandardScheme extends org.apache.storm.thrift.scheme.StandardScheme<uploadChunk_args> {
  public void read(  org.apache.storm.thrift.protocol.TProtocol iprot,  uploadChunk_args struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TField schemeField;
    iprot.readStructBegin();
    while (true) {
      schemeField=iprot.readFieldBegin();
      if (schemeField.type == org.apache.storm.thrift.protocol.TType.STOP) {
        break;
      }
switch (schemeField.id) {
case 1:
        if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
          struct.location=iprot.readString();
          struct.set_location_isSet(true);
        }
 else {
          org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
        }
      break;
case 2:
    if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
      struct.chunk=iprot.readBinary();
      struct.set_chunk_isSet(true);
    }
 else {
      org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
    }
  break;
default :
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
iprot.readFieldEnd();
}
iprot.readStructEnd();
struct.validate();
}
public void write(org.apache.storm.thrift.protocol.TProtocol oprot,uploadChunk_args struct) throws org.apache.storm.thrift.TException {
struct.validate();
oprot.writeStructBegin(STRUCT_DESC);
if (struct.location != null) {
oprot.writeFieldBegin(LOCATION_FIELD_DESC);
oprot.writeString(struct.location);
oprot.writeFieldEnd();
}
if (struct.chunk != null) {
oprot.writeFieldBegin(CHUNK_FIELD_DESC);
oprot.writeBinary(struct.chunk);
oprot.writeFieldEnd();
}
oprot.writeFieldStop();
oprot.writeStructEnd();
}
}
