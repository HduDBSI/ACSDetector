public static class uploadNewCredentials<I extends AsyncIface> extends org.apache.storm.thrift.AsyncProcessFunction<I,uploadNewCredentials_args,Void> {
  public uploadNewCredentials(){
    super("uploadNewCredentials");
  }
  public uploadNewCredentials_args getEmptyArgsInstance(){
    return new uploadNewCredentials_args();
  }
  public org.apache.storm.thrift.async.AsyncMethodCallback<Void> getResultHandler(  final org.apache.storm.thrift.server.AbstractNonblockingServer.AsyncFrameBuffer fb,  final int seqid){
    final org.apache.storm.thrift.AsyncProcessFunction fcall=this;
    return new org.apache.storm.thrift.async.AsyncMethodCallback<Void>(){
      public void onComplete(      Void o){
        uploadNewCredentials_result result=new uploadNewCredentials_result();
        try {
          fcall.sendResponse(fb,result,org.apache.storm.thrift.protocol.TMessageType.REPLY,seqid);
        }
 catch (        org.apache.storm.thrift.transport.TTransportException e) {
          _LOGGER.error("TTransportException writing to internal frame buffer",e);
          fb.close();
        }
catch (        java.lang.Exception e) {
          _LOGGER.error("Exception writing to internal frame buffer",e);
          onError(e);
        }
      }
      public void onError(      java.lang.Exception e){
        byte msgType=org.apache.storm.thrift.protocol.TMessageType.REPLY;
        org.apache.storm.thrift.TSerializable msg;
        uploadNewCredentials_result result=new uploadNewCredentials_result();
        if (e instanceof NotAliveException) {
          result.e=(NotAliveException)e;
          result.set_e_isSet(true);
          msg=result;
        }
 else         if (e instanceof InvalidTopologyException) {
          result.ite=(InvalidTopologyException)e;
          result.set_ite_isSet(true);
          msg=result;
        }
 else         if (e instanceof AuthorizationException) {
          result.aze=(AuthorizationException)e;
          result.set_aze_isSet(true);
          msg=result;
        }
 else         if (e instanceof org.apache.storm.thrift.transport.TTransportException) {
          _LOGGER.error("TTransportException inside handler",e);
          fb.close();
          return;
        }
 else         if (e instanceof org.apache.storm.thrift.TApplicationException) {
          _LOGGER.error("TApplicationException inside handler",e);
          msgType=org.apache.storm.thrift.protocol.TMessageType.EXCEPTION;
          msg=(org.apache.storm.thrift.TApplicationException)e;
        }
 else {
          _LOGGER.error("Exception inside handler",e);
          msgType=org.apache.storm.thrift.protocol.TMessageType.EXCEPTION;
          msg=new org.apache.storm.thrift.TApplicationException(org.apache.storm.thrift.TApplicationException.INTERNAL_ERROR,e.getMessage());
        }
        try {
          fcall.sendResponse(fb,msg,msgType,seqid);
        }
 catch (        java.lang.Exception ex) {
          _LOGGER.error("Exception writing to internal frame buffer",ex);
          fb.close();
        }
      }
    }
;
  }
  protected boolean isOneway(){
    return false;
  }
  public void start(  I iface,  uploadNewCredentials_args args,  org.apache.storm.thrift.async.AsyncMethodCallback<Void> resultHandler) throws org.apache.storm.thrift.TException {
    iface.uploadNewCredentials(args.name,args.creds,resultHandler);
  }
}
