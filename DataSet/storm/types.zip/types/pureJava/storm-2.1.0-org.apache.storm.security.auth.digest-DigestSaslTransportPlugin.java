public class DigestSaslTransportPlugin extends SaslTransportPlugin {
  public static final String DIGEST="DIGEST-MD5";
  private static final Logger LOG=LoggerFactory.getLogger(DigestSaslTransportPlugin.class);
  private WorkerTokenAuthorizer workerTokenAuthorizer;
  @Override protected TTransportFactory getServerTransportFactory(  boolean impersonationAllowed) throws IOException {
    if (workerTokenAuthorizer == null) {
      workerTokenAuthorizer=new WorkerTokenAuthorizer(conf,type);
    }
    CallbackHandler serverCallbackHandler=new SimpleSaslServerCallbackHandler(impersonationAllowed,workerTokenAuthorizer,new JassPasswordProvider(loginConf));
    TSaslServerTransport.Factory factory=new TSaslServerTransport.Factory();
    factory.addServerDefinition(DIGEST,ClientAuthUtils.SERVICE,"localhost",null,serverCallbackHandler);
    LOG.info("SASL DIGEST-MD5 transport factory will be used");
    return factory;
  }
  @Override public TTransport connect(  TTransport transport,  String serverHost,  String asUser) throws TTransportException, IOException {
    CallbackHandler clientCallbackHandler;
    WorkerToken token=WorkerTokenClientCallbackHandler.findWorkerTokenInSubject(type);
    if (token != null) {
      clientCallbackHandler=new WorkerTokenClientCallbackHandler(token);
    }
 else     if (loginConf != null) {
      AppConfigurationEntry[] configurationEntries=loginConf.getAppConfigurationEntry(ClientAuthUtils.LOGIN_CONTEXT_CLIENT);
      if (configurationEntries == null) {
        String errorMessage="Could not find a '" + ClientAuthUtils.LOGIN_CONTEXT_CLIENT + "' entry in this configuration: Client cannot start.";
        throw new IOException(errorMessage);
      }
      String username="";
      String password="";
      for (      AppConfigurationEntry entry : configurationEntries) {
        Map options=entry.getOptions();
        username=(String)options.getOrDefault("username",username);
        password=(String)options.getOrDefault("password",password);
      }
      clientCallbackHandler=new SimpleSaslClientCallbackHandler(username,password);
    }
 else {
      throw new IOException("Could not find any way to authenticate with the server.");
    }
    TSaslClientTransport wrapperTransport=new TSaslClientTransport(DIGEST,null,ClientAuthUtils.SERVICE,serverHost,null,clientCallbackHandler,transport);
    wrapperTransport.open();
    LOG.debug("SASL DIGEST-MD5 client transport has been established");
    return wrapperTransport;
  }
  @Override public boolean areWorkerTokensSupported(){
    return true;
  }
  @Override public void close(){
    workerTokenAuthorizer.close();
  }
}
