private static class LSTopoHistoryTupleScheme extends org.apache.storm.thrift.scheme.TupleScheme<LSTopoHistory> {
  @Override public void write(  org.apache.storm.thrift.protocol.TProtocol prot,  LSTopoHistory struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
    oprot.writeString(struct.topology_id);
    oprot.writeI64(struct.time_stamp);
{
      oprot.writeI32(struct.users.size());
      for (      java.lang.String _iter836 : struct.users) {
        oprot.writeString(_iter836);
      }
    }
{
      oprot.writeI32(struct.groups.size());
      for (      java.lang.String _iter837 : struct.groups) {
        oprot.writeString(_iter837);
      }
    }
  }
  @Override public void read(  org.apache.storm.thrift.protocol.TProtocol prot,  LSTopoHistory struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
    struct.topology_id=iprot.readString();
    struct.set_topology_id_isSet(true);
    struct.time_stamp=iprot.readI64();
    struct.set_time_stamp_isSet(true);
{
      org.apache.storm.thrift.protocol.TList _list838=new org.apache.storm.thrift.protocol.TList(org.apache.storm.thrift.protocol.TType.STRING,iprot.readI32());
      struct.users=new java.util.ArrayList<java.lang.String>(_list838.size);
      @org.apache.storm.thrift.annotation.Nullable java.lang.String _elem839;
      for (int _i840=0; _i840 < _list838.size; ++_i840) {
        _elem839=iprot.readString();
        struct.users.add(_elem839);
      }
    }
    struct.set_users_isSet(true);
{
      org.apache.storm.thrift.protocol.TList _list841=new org.apache.storm.thrift.protocol.TList(org.apache.storm.thrift.protocol.TType.STRING,iprot.readI32());
      struct.groups=new java.util.ArrayList<java.lang.String>(_list841.size);
      @org.apache.storm.thrift.annotation.Nullable java.lang.String _elem842;
      for (int _i843=0; _i843 < _list841.size; ++_i843) {
        _elem842=iprot.readString();
        struct.groups.add(_elem842);
      }
    }
    struct.set_groups_isSet(true);
  }
}
