/** 
 * TxnRecord [txnid, data_file_path, data_file_offset]. <p>This is written to the index file during beginCommit() and used for recovery.
 */
private static class TxnRecord {
  private long txnid;
  private String dataFilePath;
  private long offset;
  private TxnRecord(  long txnId,  String dataFilePath,  long offset){
    this.txnid=txnId;
    this.dataFilePath=dataFilePath;
    this.offset=offset;
  }
  @Override public String toString(){
    return Long.toString(txnid) + "," + dataFilePath+ ","+ Long.toString(offset);
  }
}
