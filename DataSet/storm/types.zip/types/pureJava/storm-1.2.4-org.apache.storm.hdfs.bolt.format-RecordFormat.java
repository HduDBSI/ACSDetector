/** 
 * Formats a Tuple object into a byte array that will be written to HDFS.
 */
public interface RecordFormat extends Serializable {
  byte[] format(  Tuple tuple);
}
