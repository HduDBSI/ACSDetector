private static class ProfileRequestStandardScheme extends org.apache.storm.thrift.scheme.StandardScheme<ProfileRequest> {
  public void read(  org.apache.storm.thrift.protocol.TProtocol iprot,  ProfileRequest struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TField schemeField;
    iprot.readStructBegin();
    while (true) {
      schemeField=iprot.readFieldBegin();
      if (schemeField.type == org.apache.storm.thrift.protocol.TType.STOP) {
        break;
      }
switch (schemeField.id) {
case 1:
        if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRUCT) {
          struct.nodeInfo=new NodeInfo();
          struct.nodeInfo.read(iprot);
          struct.set_nodeInfo_isSet(true);
        }
 else {
          org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
        }
      break;
case 2:
    if (schemeField.type == org.apache.storm.thrift.protocol.TType.I32) {
      struct.action=org.apache.storm.generated.ProfileAction.findByValue(iprot.readI32());
      struct.set_action_isSet(true);
    }
 else {
      org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
    }
  break;
case 3:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.I64) {
  struct.time_stamp=iprot.readI64();
  struct.set_time_stamp_isSet(true);
}
 else {
  org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
default :
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
iprot.readFieldEnd();
}
iprot.readStructEnd();
struct.validate();
}
public void write(org.apache.storm.thrift.protocol.TProtocol oprot,ProfileRequest struct) throws org.apache.storm.thrift.TException {
struct.validate();
oprot.writeStructBegin(STRUCT_DESC);
if (struct.nodeInfo != null) {
oprot.writeFieldBegin(NODE_INFO_FIELD_DESC);
struct.nodeInfo.write(oprot);
oprot.writeFieldEnd();
}
if (struct.action != null) {
oprot.writeFieldBegin(ACTION_FIELD_DESC);
oprot.writeI32(struct.action.getValue());
oprot.writeFieldEnd();
}
if (struct.is_set_time_stamp()) {
oprot.writeFieldBegin(TIME_STAMP_FIELD_DESC);
oprot.writeI64(struct.time_stamp);
oprot.writeFieldEnd();
}
oprot.writeFieldStop();
oprot.writeStructEnd();
}
}
