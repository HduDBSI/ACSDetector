static class MockContext extends GeneralTopologyContext {
  private final Fields fields;
  public MockContext(  String[] fieldNames){
    super(null,new HashMap<>(),null,null,null,null);
    this.fields=new Fields(fieldNames);
  }
  @Override public String getComponentId(  int taskId){
    return "component";
  }
  @Override public Fields getComponentOutputFields(  String componentId,  String streamId){
    return fields;
  }
}
