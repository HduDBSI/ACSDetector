public interface ITopologyValidator {
  void prepare(  Map<String,Object> StormConf);
  void validate(  String topologyName,  Map<String,Object> topologyConf,  StormTopology topology) throws InvalidTopologyException ;
}
