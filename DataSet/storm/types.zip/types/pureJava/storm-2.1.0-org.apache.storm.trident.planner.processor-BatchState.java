private static class BatchState {
  public List<TridentTuple> tuples=new ArrayList<TridentTuple>();
  public List<TridentTuple> args=new ArrayList<TridentTuple>();
}
