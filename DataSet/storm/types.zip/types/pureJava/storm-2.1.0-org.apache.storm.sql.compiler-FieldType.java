private static class FieldType {
  private final String name;
  private final RelDataType relDataType;
  private FieldType(  String name,  RelDataType relDataType){
    this.name=name;
    this.relDataType=relDataType;
  }
}
