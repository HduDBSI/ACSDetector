public interface ValueUpdater<T> {
  T update(  T stored);
}
