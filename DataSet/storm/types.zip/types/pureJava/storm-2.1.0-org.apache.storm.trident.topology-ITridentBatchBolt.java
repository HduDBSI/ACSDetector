public interface ITridentBatchBolt extends IComponent {
  void prepare(  Map<String,Object> conf,  TopologyContext context,  BatchOutputCollector collector);
  void execute(  BatchInfo batchInfo,  Tuple tuple);
  void finishBatch(  BatchInfo batchInfo);
  Object initBatchState(  String batchGroup,  Object batchId);
  void cleanup();
}
