public abstract class BaseQueryFunction<S extends State,T> extends BaseOperation implements QueryFunction<S,T> {
}
