/** 
 * This should only ever be used for testing.  It provides no security at all. DO NOT USE THIS.  The user name is the current user and the password is "password".
 */
@Deprecated public class PlainClientCallbackHandler extends SimpleSaslClientCallbackHandler {
  /** 
 * For plain, using constants for a pair of user name and password.
 */
  public PlainClientCallbackHandler(){
    super(System.getProperty("user.name"),"password");
  }
}
