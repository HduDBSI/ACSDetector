public class MutableObject {
  private Object object=null;
  public MutableObject(){
  }
  public MutableObject(  Object object){
    this.object=object;
  }
  public synchronized Object getObject(){
    return object;
  }
  public synchronized void setObject(  Object o){
    this.object=o;
  }
}
