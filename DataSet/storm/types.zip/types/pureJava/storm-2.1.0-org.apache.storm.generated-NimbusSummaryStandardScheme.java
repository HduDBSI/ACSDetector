private static class NimbusSummaryStandardScheme extends org.apache.storm.thrift.scheme.StandardScheme<NimbusSummary> {
  public void read(  org.apache.storm.thrift.protocol.TProtocol iprot,  NimbusSummary struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TField schemeField;
    iprot.readStructBegin();
    while (true) {
      schemeField=iprot.readFieldBegin();
      if (schemeField.type == org.apache.storm.thrift.protocol.TType.STOP) {
        break;
      }
switch (schemeField.id) {
case 1:
        if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
          struct.host=iprot.readString();
          struct.set_host_isSet(true);
        }
 else {
          org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
        }
      break;
case 2:
    if (schemeField.type == org.apache.storm.thrift.protocol.TType.I32) {
      struct.port=iprot.readI32();
      struct.set_port_isSet(true);
    }
 else {
      org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
    }
  break;
case 3:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.I32) {
  struct.uptime_secs=iprot.readI32();
  struct.set_uptime_secs_isSet(true);
}
 else {
  org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 4:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.BOOL) {
struct.isLeader=iprot.readBool();
struct.set_isLeader_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 5:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
struct.version=iprot.readString();
struct.set_version_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
default :
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
iprot.readFieldEnd();
}
iprot.readStructEnd();
struct.validate();
}
public void write(org.apache.storm.thrift.protocol.TProtocol oprot,NimbusSummary struct) throws org.apache.storm.thrift.TException {
struct.validate();
oprot.writeStructBegin(STRUCT_DESC);
if (struct.host != null) {
oprot.writeFieldBegin(HOST_FIELD_DESC);
oprot.writeString(struct.host);
oprot.writeFieldEnd();
}
oprot.writeFieldBegin(PORT_FIELD_DESC);
oprot.writeI32(struct.port);
oprot.writeFieldEnd();
oprot.writeFieldBegin(UPTIME_SECS_FIELD_DESC);
oprot.writeI32(struct.uptime_secs);
oprot.writeFieldEnd();
oprot.writeFieldBegin(IS_LEADER_FIELD_DESC);
oprot.writeBool(struct.isLeader);
oprot.writeFieldEnd();
if (struct.version != null) {
oprot.writeFieldBegin(VERSION_FIELD_DESC);
oprot.writeString(struct.version);
oprot.writeFieldEnd();
}
oprot.writeFieldStop();
oprot.writeStructEnd();
}
}
