private static interface InputDeclaration {
  public void declare(  String prevComponent,  InputDeclarer declarer);
}
