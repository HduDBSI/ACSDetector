/** 
 * This class gives a mapping of a  {@link ITuple} with {@link OpenTsdbMetricDatapoint}.
 */
public interface ITupleOpenTsdbDatapointMapper extends Serializable {
  /** 
 * Returns a  {@link OpenTsdbMetricDatapoint} for a given {@code tuple}.
 * @param tuple tuple instance
 */
  public OpenTsdbMetricDatapoint getMetricPoint(  ITuple tuple);
}
