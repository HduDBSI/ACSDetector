public class UniqueIdGen {
  private int streamCounter=0;
  private int stateCounter=0;
  private int windowCounter=0;
  public String getUniqueStreamId(){
    streamCounter++;
    return "s" + streamCounter;
  }
  public String getUniqueStateId(){
    stateCounter++;
    return "state" + stateCounter;
  }
  public String getUniqueWindowId(){
    return "w" + (++windowCounter);
  }
}
