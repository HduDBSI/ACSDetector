private static class StreamInfoTupleScheme extends org.apache.storm.thrift.scheme.TupleScheme<StreamInfo> {
  @Override public void write(  org.apache.storm.thrift.protocol.TProtocol prot,  StreamInfo struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
{
      oprot.writeI32(struct.output_fields.size());
      for (      java.lang.String _iter20 : struct.output_fields) {
        oprot.writeString(_iter20);
      }
    }
    oprot.writeBool(struct.direct);
  }
  @Override public void read(  org.apache.storm.thrift.protocol.TProtocol prot,  StreamInfo struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
{
      org.apache.storm.thrift.protocol.TList _list21=new org.apache.storm.thrift.protocol.TList(org.apache.storm.thrift.protocol.TType.STRING,iprot.readI32());
      struct.output_fields=new java.util.ArrayList<java.lang.String>(_list21.size);
      @org.apache.storm.thrift.annotation.Nullable java.lang.String _elem22;
      for (int _i23=0; _i23 < _list21.size; ++_i23) {
        _elem22=iprot.readString();
        struct.output_fields.add(_elem22);
      }
    }
    struct.set_output_fields_isSet(true);
    struct.direct=iprot.readBool();
    struct.set_direct_isSet(true);
  }
}
