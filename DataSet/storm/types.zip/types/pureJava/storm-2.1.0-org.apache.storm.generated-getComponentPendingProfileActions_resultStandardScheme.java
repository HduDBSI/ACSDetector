private static class getComponentPendingProfileActions_resultStandardScheme extends org.apache.storm.thrift.scheme.StandardScheme<getComponentPendingProfileActions_result> {
  public void read(  org.apache.storm.thrift.protocol.TProtocol iprot,  getComponentPendingProfileActions_result struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TField schemeField;
    iprot.readStructBegin();
    while (true) {
      schemeField=iprot.readFieldBegin();
      if (schemeField.type == org.apache.storm.thrift.protocol.TType.STOP) {
        break;
      }
switch (schemeField.id) {
case 0:
        if (schemeField.type == org.apache.storm.thrift.protocol.TType.LIST) {
{
            org.apache.storm.thrift.protocol.TList _list920=iprot.readListBegin();
            struct.success=new java.util.ArrayList<ProfileRequest>(_list920.size);
            @org.apache.storm.thrift.annotation.Nullable ProfileRequest _elem921;
            for (int _i922=0; _i922 < _list920.size; ++_i922) {
              _elem921=new ProfileRequest();
              _elem921.read(iprot);
              struct.success.add(_elem921);
            }
            iprot.readListEnd();
          }
          struct.set_success_isSet(true);
        }
 else {
          org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
        }
      break;
default :
    org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
iprot.readFieldEnd();
}
iprot.readStructEnd();
struct.validate();
}
public void write(org.apache.storm.thrift.protocol.TProtocol oprot,getComponentPendingProfileActions_result struct) throws org.apache.storm.thrift.TException {
struct.validate();
oprot.writeStructBegin(STRUCT_DESC);
if (struct.success != null) {
oprot.writeFieldBegin(SUCCESS_FIELD_DESC);
{
  oprot.writeListBegin(new org.apache.storm.thrift.protocol.TList(org.apache.storm.thrift.protocol.TType.STRUCT,struct.success.size()));
  for (  ProfileRequest _iter923 : struct.success) {
    _iter923.write(oprot);
  }
  oprot.writeListEnd();
}
oprot.writeFieldEnd();
}
oprot.writeFieldStop();
oprot.writeStructEnd();
}
}
