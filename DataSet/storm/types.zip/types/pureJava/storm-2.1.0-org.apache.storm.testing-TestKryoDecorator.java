public class TestKryoDecorator implements IKryoDecorator {
  @Override public void decorate(  Kryo k){
    k.register(TestSerObject.class);
  }
}
