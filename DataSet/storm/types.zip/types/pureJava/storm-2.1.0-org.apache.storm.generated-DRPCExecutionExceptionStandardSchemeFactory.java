private static class DRPCExecutionExceptionStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public DRPCExecutionExceptionStandardScheme getScheme(){
    return new DRPCExecutionExceptionStandardScheme();
  }
}
