public class MqttBolt extends BaseTickTupleAwareRichBolt {
  private static final Logger LOG=LoggerFactory.getLogger(MqttBolt.class);
  private MqttTupleMapper mapper;
  private transient MqttPublisher publisher;
  private boolean retain=false;
  private transient OutputCollector collector;
  private MqttOptions options;
  private KeyStoreLoader keyStoreLoader;
  private transient String topologyName;
  public MqttBolt(  MqttOptions options,  MqttTupleMapper mapper){
    this(options,mapper,null,false);
  }
  public MqttBolt(  MqttOptions options,  MqttTupleMapper mapper,  boolean retain){
    this(options,mapper,null,retain);
  }
  public MqttBolt(  MqttOptions options,  MqttTupleMapper mapper,  KeyStoreLoader keyStoreLoader){
    this(options,mapper,keyStoreLoader,false);
  }
  public MqttBolt(  MqttOptions options,  MqttTupleMapper mapper,  KeyStoreLoader keyStoreLoader,  boolean retain){
    this.options=options;
    this.mapper=mapper;
    this.retain=retain;
    this.keyStoreLoader=keyStoreLoader;
    SslUtils.checkSslConfig(this.options.getUrl(),keyStoreLoader);
  }
  @Override public void prepare(  Map<String,Object> conf,  TopologyContext context,  OutputCollector collector){
    this.collector=collector;
    this.topologyName=(String)conf.get(Config.TOPOLOGY_NAME);
    this.publisher=new MqttPublisher(this.options,this.keyStoreLoader,this.retain);
    try {
      this.publisher.connectMqtt(this.topologyName + "-" + context.getThisComponentId()+ "-"+ context.getThisTaskId());
    }
 catch (    Exception e) {
      LOG.error("Unable to connect to MQTT Broker.",e);
      throw new RuntimeException("Unable to connect to MQTT Broker.",e);
    }
  }
  @Override protected void process(  Tuple input){
    MqttMessage message=this.mapper.toMessage(input);
    try {
      this.publisher.publish(message);
      this.collector.ack(input);
    }
 catch (    Exception e) {
      LOG.warn("Error publishing MQTT message. Failing tuple.",e);
      collector.reportError(e);
      collector.fail(input);
    }
  }
  @Override public void declareOutputFields(  OutputFieldsDeclarer declarer){
  }
}
