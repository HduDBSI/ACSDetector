@SuppressWarnings("checkstyle:AbbreviationAsWordInName") public class BoundCQLStatementMapperBuilder implements CQLStatementBuilder<BoundCQLStatementTupleMapper>, Serializable {
  private final ContextQuery contextQuery;
  private CqlMapper mapper;
  private List<String> routingKeys;
  private PreparedStatementBinder binder;
  /** 
 * Creates a new  {@link BoundCQLStatementMapperBuilder} instance.
 */
  public BoundCQLStatementMapperBuilder(  String cql){
    this.contextQuery=new StaticContextQuery(cql);
  }
  /** 
 * Creates a new  {@link BoundCQLStatementMapperBuilder} instance.
 */
  public BoundCQLStatementMapperBuilder(  ContextQuery contextQuery){
    this.contextQuery=contextQuery;
  }
  /** 
 * Includes only the specified tuple fields.
 * @param fields a list of field selector.
 */
  public final BoundCQLStatementMapperBuilder bind(  final FieldSelector... fields){
    this.mapper=new CqlMapper.SelectableCqlMapper(Arrays.asList(fields));
    return this;
  }
  /** 
 * Includes only the specified tuple fields.
 * @param mapper a column mapper.
 */
  public final BoundCQLStatementMapperBuilder bind(  CqlMapper mapper){
    this.mapper=mapper;
    return this;
  }
  public final BoundCQLStatementMapperBuilder withRoutingKeys(  String... fields){
    this.routingKeys=Arrays.asList(fields);
    return this;
  }
  public final BoundCQLStatementMapperBuilder byNamedSetters(){
    this.binder=new PreparedStatementBinder.CQL3NamedSettersBinder();
    return this;
  }
  /** 
 * {@inheritDoc}
 */
  @Override public BoundCQLStatementTupleMapper build(){
    return new BoundCQLStatementTupleMapper(contextQuery,mapper,getRoutingKeyGenerator(),getStatementBinder());
  }
  private RoutingKeyGenerator getRoutingKeyGenerator(){
    return (routingKeys != null) ? new RoutingKeyGenerator(routingKeys) : null;
  }
  private PreparedStatementBinder getStatementBinder(){
    return (binder != null) ? binder : new PreparedStatementBinder.DefaultBinder();
  }
}
