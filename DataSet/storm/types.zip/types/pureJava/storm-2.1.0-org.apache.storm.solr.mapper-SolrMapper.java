public interface SolrMapper extends Serializable {
  default void configure(){
  }
  String getCollection();
  SolrRequest toSolrRequest(  ITuple tuple) throws SolrMapperException ;
  SolrRequest toSolrRequest(  List<? extends ITuple> tuples) throws SolrMapperException ;
}
