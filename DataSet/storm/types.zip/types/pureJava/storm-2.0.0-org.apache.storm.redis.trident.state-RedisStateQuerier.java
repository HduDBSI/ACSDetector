/** 
 * BaseQueryFunction implementation for single Redis environment.
 * @see AbstractRedisStateQuerier
 */
public class RedisStateQuerier extends AbstractRedisStateQuerier<RedisState> {
  /** 
 * Constructor
 * @param lookupMapper mapper for querying
 */
  public RedisStateQuerier(  RedisLookupMapper lookupMapper){
    super(lookupMapper);
  }
  /** 
 * {@inheritDoc}
 */
  @Override protected List<String> retrieveValuesFromRedis(  RedisState state,  List<String> keys){
    Jedis jedis=null;
    try {
      jedis=state.getJedis();
      List<String> redisVals;
      String[] keysForRedis=keys.toArray(new String[keys.size()]);
switch (dataType) {
case STRING:
        redisVals=jedis.mget(keysForRedis);
      break;
case HASH:
    redisVals=jedis.hmget(additionalKey,keysForRedis);
  break;
default :
throw new IllegalArgumentException("Cannot process such data type: " + dataType);
}
return redisVals;
}
  finally {
if (jedis != null) {
state.returnJedis(jedis);
}
}
}
}
