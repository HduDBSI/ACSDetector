private static class Pointer implements Serializable {
  int listIndex;
  int subIndex;
  public Pointer(  int listIndex,  int subIndex){
    this.listIndex=listIndex;
    this.subIndex=subIndex;
  }
}
