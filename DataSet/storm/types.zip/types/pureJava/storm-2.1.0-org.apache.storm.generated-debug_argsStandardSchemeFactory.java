private static class debug_argsStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public debug_argsStandardScheme getScheme(){
    return new debug_argsStandardScheme();
  }
}
