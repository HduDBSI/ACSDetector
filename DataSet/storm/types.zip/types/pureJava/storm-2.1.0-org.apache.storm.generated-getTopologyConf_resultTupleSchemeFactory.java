private static class getTopologyConf_resultTupleSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public getTopologyConf_resultTupleScheme getScheme(){
    return new getTopologyConf_resultTupleScheme();
  }
}
