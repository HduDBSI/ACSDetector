/** 
 * Processor that populate simple transport info into ReqContext, and then invoke a service handler.
 */
private class SimpleWrapProcessor implements TProcessor {
  final TProcessor wrapped;
  SimpleWrapProcessor(  TProcessor wrapped){
    this.wrapped=wrapped;
  }
  @Override public boolean process(  final TProtocol inProt,  final TProtocol outProt) throws TException {
    ReqContext reqContext=ReqContext.context();
    TTransport trans=inProt.getTransport();
    if (trans instanceof TMemoryInputTransport) {
      try {
        reqContext.setRemoteAddress(InetAddress.getLocalHost());
      }
 catch (      UnknownHostException e) {
        throw new RuntimeException(e);
      }
    }
 else     if (trans instanceof TSocket) {
      TSocket tsocket=(TSocket)trans;
      Socket socket=tsocket.getSocket();
      reqContext.setRemoteAddress(socket.getInetAddress());
    }
    Subject s=getDefaultSubject();
    if (s == null) {
      final String user=(String)topoConf.get("debug.simple.transport.user");
      if (user != null) {
        HashSet<Principal> principals=new HashSet<>();
        principals.add(new Principal(){
          @Override public String getName(){
            return user;
          }
          @Override public String toString(){
            return user;
          }
        }
);
        s=new Subject(true,principals,new HashSet<>(),new HashSet<>());
      }
    }
    reqContext.setSubject(s);
    return wrapped.process(inProt,outProt);
  }
}
