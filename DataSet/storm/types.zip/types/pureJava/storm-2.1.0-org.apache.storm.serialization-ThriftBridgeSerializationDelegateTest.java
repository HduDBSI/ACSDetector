public class ThriftBridgeSerializationDelegateTest {
  SerializationDelegate testDelegate;
  @Before public void setUp() throws Exception {
    testDelegate=new ThriftSerializationDelegate();
    testDelegate.prepare(null);
  }
  @Test public void testThriftInstance() throws Exception {
    ErrorInfo errorInfo=new ErrorInfo();
    errorInfo.set_error("error");
    errorInfo.set_error_time_secs(1);
    errorInfo.set_host("host");
    errorInfo.set_port(1);
    byte[] serialized=new ThriftSerializationDelegate().serialize(errorInfo);
    ErrorInfo errorInfo2=testDelegate.deserialize(serialized,ErrorInfo.class);
    assertEquals(errorInfo,errorInfo2);
    serialized=testDelegate.serialize(errorInfo);
    errorInfo2=new ThriftSerializationDelegate().deserialize(serialized,ErrorInfo.class);
    assertEquals(errorInfo,errorInfo2);
  }
static class TestPojo implements Serializable {
    String name;
    int age;
  }
}
