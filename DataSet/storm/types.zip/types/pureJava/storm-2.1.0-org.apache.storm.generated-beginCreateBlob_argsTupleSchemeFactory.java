private static class beginCreateBlob_argsTupleSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public beginCreateBlob_argsTupleScheme getScheme(){
    return new beginCreateBlob_argsTupleScheme();
  }
}
