protected class ResultRecord {
  ArrayList<Tuple> tupleList=new ArrayList<>();
  ArrayList<Object> outFields=null;
  public ResultRecord(  Tuple tuple,  boolean generateOutputFields){
    tupleList.add(tuple);
    if (generateOutputFields) {
      outFields=doProjection(tupleList,outputFields);
    }
  }
  public ResultRecord(  ResultRecord lhs,  Tuple rhs,  boolean generateOutputFields){
    if (lhs != null) {
      tupleList.addAll(lhs.tupleList);
    }
    if (rhs != null) {
      tupleList.add(rhs);
    }
    if (generateOutputFields) {
      outFields=doProjection(tupleList,outputFields);
    }
  }
  public ArrayList<Object> getOutputFields(){
    return outFields;
  }
  public Object getField(  FieldSelector fieldSelector){
    for (    Tuple tuple : tupleList) {
      Object result=lookupField(fieldSelector,tuple);
      if (result != null) {
        return result;
      }
    }
    return null;
  }
}
