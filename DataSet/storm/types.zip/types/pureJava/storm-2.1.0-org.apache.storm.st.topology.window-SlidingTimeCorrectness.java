/** 
 * Computes sliding window sum.
 */
public class SlidingTimeCorrectness implements TestableTopology {
  private static final Logger LOG=LoggerFactory.getLogger(SlidingTimeCorrectness.class);
  private final int windowSec;
  private final int slideSec;
  private final String spoutName;
  private final int spoutExecutors=2;
  private final String boltName;
  private final int boltExecutors=1;
  public SlidingTimeCorrectness(  int windowSec,  int slideSec){
    this.windowSec=windowSec;
    this.slideSec=slideSec;
    final String prefix=this.getClass().getSimpleName() + "-winSec" + windowSec+ "slideSec"+ slideSec;
    spoutName=prefix + "IncrementingSpout";
    boltName=prefix + "VerificationBolt";
  }
  @Override public String getBoltName(){
    return boltName;
  }
  @Override public String getSpoutName(){
    return spoutName;
  }
  @Override public int getBoltExecutors(){
    return boltExecutors;
  }
  @Override public int getSpoutExecutors(){
    return spoutExecutors;
  }
  @Override public StormTopology newTopology(){
    TopologyBuilder builder=new TopologyBuilder();
    builder.setSpout(getSpoutName(),new TimeDataIncrementingSpout(),spoutExecutors);
    builder.setBolt(getBoltName(),new TimeDataVerificationBolt().withWindow(new BaseWindowedBolt.Duration(windowSec,TimeUnit.SECONDS),new BaseWindowedBolt.Duration(slideSec,TimeUnit.SECONDS)).withTimestampField(TimeData.getTimestampFieldName()).withLag(new BaseWindowedBolt.Duration(10,TimeUnit.SECONDS)),boltExecutors).globalGrouping(getSpoutName());
    return builder.createTopology();
  }
}
