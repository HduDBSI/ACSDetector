protected class JoinAccumulator {
  ArrayList<ResultRecord> records=new ArrayList<>();
  public void insert(  ResultRecord tuple){
    records.add(tuple);
  }
  public Collection<ResultRecord> getRecords(){
    return records;
  }
}
