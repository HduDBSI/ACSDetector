/** 
 * This topology demonstrates Storm's stream groupings and multilang capabilities.
 */
public class WordCountTopologyNode {
  public static void main(  String[] args) throws Exception {
    TopologyBuilder builder=new TopologyBuilder();
    builder.setSpout("spout",new RandomSentence(),5);
    builder.setBolt("split",new SplitSentence(),8).shuffleGrouping("spout");
    builder.setBolt("count",new WordCount(),12).fieldsGrouping("split",new Fields("word"));
    Config conf=new Config();
    conf.setDebug(true);
    String topoName="word-count";
    if (args != null && args.length > 0) {
      topoName=args[0];
    }
    conf.setNumWorkers(3);
    StormSubmitter.submitTopologyWithProgressBar(topoName,conf,builder.createTopology());
  }
public static class SplitSentence extends ShellBolt implements IRichBolt {
    public SplitSentence(){
      super("node","splitsentence.js");
    }
    @Override public void declareOutputFields(    OutputFieldsDeclarer declarer){
      declarer.declare(new Fields("word"));
    }
    @Override public Map<String,Object> getComponentConfiguration(){
      return null;
    }
  }
public static class RandomSentence extends ShellSpout implements IRichSpout {
    public RandomSentence(){
      super("node","randomsentence.js");
    }
    @Override public void declareOutputFields(    OutputFieldsDeclarer declarer){
      declarer.declare(new Fields("word"));
    }
    @Override public Map<String,Object> getComponentConfiguration(){
      return null;
    }
  }
public static class WordCount extends BaseBasicBolt {
    Map<String,Integer> counts=new HashMap<String,Integer>();
    @Override public void execute(    Tuple tuple,    BasicOutputCollector collector){
      String word=tuple.getString(0);
      Integer count=counts.get(word);
      if (count == null) {
        count=0;
      }
      count++;
      counts.put(word,count);
      collector.emit(new Values(word,count));
    }
    @Override public void declareOutputFields(    OutputFieldsDeclarer declarer){
      declarer.declare(new Fields("word","count"));
    }
  }
}
