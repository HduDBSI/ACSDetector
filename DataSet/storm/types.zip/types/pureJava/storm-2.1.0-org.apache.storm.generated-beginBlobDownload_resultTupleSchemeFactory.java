private static class beginBlobDownload_resultTupleSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public beginBlobDownload_resultTupleScheme getScheme(){
    return new beginBlobDownload_resultTupleScheme();
  }
}
