private static class HBAuthorizationExceptionStandardScheme extends org.apache.storm.thrift.scheme.StandardScheme<HBAuthorizationException> {
  public void read(  org.apache.storm.thrift.protocol.TProtocol iprot,  HBAuthorizationException struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TField schemeField;
    iprot.readStructBegin();
    while (true) {
      schemeField=iprot.readFieldBegin();
      if (schemeField.type == org.apache.storm.thrift.protocol.TType.STOP) {
        break;
      }
switch (schemeField.id) {
case 1:
        if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
          struct.msg=iprot.readString();
          struct.set_msg_isSet(true);
        }
 else {
          org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
        }
      break;
default :
    org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
iprot.readFieldEnd();
}
iprot.readStructEnd();
struct.validate();
}
public void write(org.apache.storm.thrift.protocol.TProtocol oprot,HBAuthorizationException struct) throws org.apache.storm.thrift.TException {
struct.validate();
oprot.writeStructBegin(STRUCT_DESC);
if (struct.msg != null) {
oprot.writeFieldBegin(MSG_FIELD_DESC);
oprot.writeString(struct.msg);
oprot.writeFieldEnd();
}
oprot.writeFieldStop();
oprot.writeStructEnd();
}
}
