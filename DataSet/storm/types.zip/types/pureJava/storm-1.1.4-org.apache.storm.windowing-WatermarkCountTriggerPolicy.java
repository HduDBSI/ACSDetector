/** 
 * A trigger policy that tracks event counts and sets the context for eviction policy to evict based on latest watermark time.
 * @param < T > the type of event tracked by this policy.
 */
public class WatermarkCountTriggerPolicy<T> implements TriggerPolicy<T> {
  private final int count;
  private final TriggerHandler handler;
  private final EvictionPolicy<T> evictionPolicy;
  private final WindowManager<T> windowManager;
  private long lastProcessedTs=0;
  private boolean started;
  public WatermarkCountTriggerPolicy(  int count,  TriggerHandler handler,  EvictionPolicy<T> evictionPolicy,  WindowManager<T> windowManager){
    this.count=count;
    this.handler=handler;
    this.evictionPolicy=evictionPolicy;
    this.windowManager=windowManager;
    this.started=false;
  }
  @Override public void track(  Event<T> event){
    if (started && event.isWatermark()) {
      handleWaterMarkEvent(event);
    }
  }
  @Override public void reset(){
  }
  @Override public void start(){
    started=true;
  }
  @Override public void shutdown(){
  }
  /** 
 * Triggers all the pending windows up to the waterMarkEvent timestamp based on the sliding interval count.
 * @param waterMarkEvent the watermark event
 */
  private void handleWaterMarkEvent(  Event<T> waterMarkEvent){
    long watermarkTs=waterMarkEvent.getTimestamp();
    List<Long> eventTs=windowManager.getSlidingCountTimestamps(lastProcessedTs,watermarkTs,count);
    for (    long ts : eventTs) {
      evictionPolicy.setContext(new DefaultEvictionContext(ts,null,Long.valueOf(count)));
      handler.onTrigger();
      lastProcessedTs=ts;
    }
  }
  @Override public String toString(){
    return "WatermarkCountTriggerPolicy{" + "count=" + count + ", lastProcessedTs="+ lastProcessedTs+ ", started="+ started+ '}';
  }
}
