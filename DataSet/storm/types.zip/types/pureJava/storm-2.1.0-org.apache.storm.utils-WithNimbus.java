/** 
 * An interface to allow callbacks with a thrift nimbus client.
 */
public interface WithNimbus {
  /** 
 * Run what you need with the nimbus client.
 * @param client the client.
 * @throws Exception on any error.
 */
  void run(  Nimbus.Iface client) throws Exception ;
}
