/** 
 * Represents the load that a Bolt is currently under to help in deciding where to route a tuple, to help balance the load.
 */
public class Load {
  private boolean hasMetrics=false;
  private double boltLoad=0.0;
  private double connectionLoad=0.0;
  /** 
 * Create a new load.
 * @param hasMetrics     have metrics been reported yet?
 * @param boltLoad       the load as reported by the bolt 0.0 no load 1.0 fully loaded
 * @param connectionLoad the load as reported by the connection to the bolt 0.0 no load 1.0 fully loaded.
 */
  public Load(  boolean hasMetrics,  double boltLoad,  double connectionLoad){
    this.hasMetrics=hasMetrics;
    this.boltLoad=boltLoad;
    this.connectionLoad=connectionLoad;
  }
  /** 
 * Check whether has metrics.
 * @return true if metrics have been reported so far.
 */
  public boolean hasMetrics(){
    return hasMetrics;
  }
  /** 
 * Get bolt load.
 * @return the load as reported by the bolt.
 */
  public double getBoltLoad(){
    return boltLoad;
  }
  /** 
 * Get connection load.
 * @return the load as reported by the connection
 */
  public double getConnectionLoad(){
    return connectionLoad;
  }
  /** 
 * Get load.
 * @return the load that is a combination of sub loads.
 */
  public double getLoad(){
    if (!hasMetrics) {
      return 1.0;
    }
    return connectionLoad > boltLoad ? connectionLoad : boltLoad;
  }
  @Override public String toString(){
    return "[:load " + boltLoad + " "+ connectionLoad+ "]";
  }
}
