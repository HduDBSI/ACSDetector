private static class TopologyHistoryInfoStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public TopologyHistoryInfoStandardScheme getScheme(){
    return new TopologyHistoryInfoStandardScheme();
  }
}
