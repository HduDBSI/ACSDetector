/** 
 * This class represents tumbling window strategy based on the window duration from the given  {@code slidingCountWindow} configuration. Inthis strategy , window and sliding durations are equal.
 */
public final class TumblingDurationWindowStrategy<T> extends BaseWindowStrategy<T> {
  public TumblingDurationWindowStrategy(  WindowConfig tumblingDurationWindow){
    super(tumblingDurationWindow);
  }
  /** 
 * Returns a  {@code TriggerPolicy} which triggers for every given sliding duration.
 */
  @Override public TriggerPolicy<T,?> getTriggerPolicy(  TriggerHandler triggerHandler,  EvictionPolicy<T,?> evictionPolicy){
    return new TimeTriggerPolicy<>(windowConfig.getSlidingLength(),triggerHandler,evictionPolicy);
  }
  /** 
 * Returns an  {@code EvictionPolicy} instance which evicts elements after given window duration.
 */
  @Override public EvictionPolicy<T,?> getEvictionPolicy(){
    return new TimeEvictionPolicy<>(windowConfig.getWindowLength());
  }
}
