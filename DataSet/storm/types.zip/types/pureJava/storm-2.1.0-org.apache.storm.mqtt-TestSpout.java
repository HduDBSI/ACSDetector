public static class TestSpout extends MqttSpout {
  public TestSpout(  MqttMessageMapper type,  MqttOptions options){
    super(type,options);
  }
  @Override public void activate(){
    super.activate();
    LOG.info("Spout activated.");
    spoutActivated=true;
  }
}
