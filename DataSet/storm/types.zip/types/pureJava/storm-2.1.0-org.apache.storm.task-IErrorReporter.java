public interface IErrorReporter {
  void reportError(  Throwable error);
}
