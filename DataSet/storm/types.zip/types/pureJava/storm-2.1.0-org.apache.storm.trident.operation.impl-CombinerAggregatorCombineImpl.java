public class CombinerAggregatorCombineImpl implements Aggregator<Result> {
  CombinerAggregator agg;
  public CombinerAggregatorCombineImpl(  CombinerAggregator agg){
    this.agg=agg;
  }
  @Override public void prepare(  Map<String,Object> conf,  TridentOperationContext context){
  }
  @Override public Result init(  Object batchId,  TridentCollector collector){
    Result ret=new Result();
    ret.obj=agg.zero();
    return ret;
  }
  @Override public void aggregate(  Result val,  TridentTuple tuple,  TridentCollector collector){
    Object v=tuple.getValue(0);
    if (val.obj == null) {
      val.obj=v;
    }
 else {
      val.obj=agg.combine(val.obj,v);
    }
  }
  @Override public void complete(  Result val,  TridentCollector collector){
    collector.emit(new Values(val.obj));
  }
  @Override public void cleanup(){
  }
}
