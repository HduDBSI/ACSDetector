/** 
 * Default interface to map a  {@link org.apache.storm.tuple.ITuple} to a CQL {@link com.datastax.driver.core.Statement}.
 */
@SuppressWarnings("checkstyle:AbbreviationAsWordInName") public interface CQLStatementTupleMapper extends Serializable {
  /** 
 * Maps a given tuple to one or multiple CQL statements.
 * @param conf the storm configuration map.
 * @param session the cassandra session.
 * @param tuple the incoming tuple to map.
 * @return a list of {@link com.datastax.driver.core.Statement}.
 */
  List<Statement> map(  Map<String,Object> conf,  Session session,  ITuple tuple);
@SuppressWarnings("checkstyle:AbbreviationAsWordInName") public static class DynamicCQLStatementTupleMapper implements CQLStatementTupleMapper {
    private List<CQLStatementBuilder> builders;
    public DynamicCQLStatementTupleMapper(    List<CQLStatementBuilder> builders){
      this.builders=builders;
    }
    @Override public List<Statement> map(    Map<String,Object> conf,    Session session,    ITuple tuple){
      List<Statement> statements=new LinkedList<>();
      for (      CQLStatementBuilder b : builders) {
        statements.addAll(b.build().map(conf,session,tuple));
      }
      return statements;
    }
  }
}
