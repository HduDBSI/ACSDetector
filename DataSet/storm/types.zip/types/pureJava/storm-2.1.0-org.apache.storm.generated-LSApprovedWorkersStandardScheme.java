private static class LSApprovedWorkersStandardScheme extends org.apache.storm.thrift.scheme.StandardScheme<LSApprovedWorkers> {
  public void read(  org.apache.storm.thrift.protocol.TProtocol iprot,  LSApprovedWorkers struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TField schemeField;
    iprot.readStructBegin();
    while (true) {
      schemeField=iprot.readFieldBegin();
      if (schemeField.type == org.apache.storm.thrift.protocol.TType.STOP) {
        break;
      }
switch (schemeField.id) {
case 1:
        if (schemeField.type == org.apache.storm.thrift.protocol.TType.MAP) {
{
            org.apache.storm.thrift.protocol.TMap _map800=iprot.readMapBegin();
            struct.approved_workers=new java.util.HashMap<java.lang.String,java.lang.Integer>(2 * _map800.size);
            @org.apache.storm.thrift.annotation.Nullable java.lang.String _key801;
            int _val802;
            for (int _i803=0; _i803 < _map800.size; ++_i803) {
              _key801=iprot.readString();
              _val802=iprot.readI32();
              struct.approved_workers.put(_key801,_val802);
            }
            iprot.readMapEnd();
          }
          struct.set_approved_workers_isSet(true);
        }
 else {
          org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
        }
      break;
default :
    org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
iprot.readFieldEnd();
}
iprot.readStructEnd();
struct.validate();
}
public void write(org.apache.storm.thrift.protocol.TProtocol oprot,LSApprovedWorkers struct) throws org.apache.storm.thrift.TException {
struct.validate();
oprot.writeStructBegin(STRUCT_DESC);
if (struct.approved_workers != null) {
oprot.writeFieldBegin(APPROVED_WORKERS_FIELD_DESC);
{
  oprot.writeMapBegin(new org.apache.storm.thrift.protocol.TMap(org.apache.storm.thrift.protocol.TType.STRING,org.apache.storm.thrift.protocol.TType.I32,struct.approved_workers.size()));
  for (  java.util.Map.Entry<java.lang.String,java.lang.Integer> _iter804 : struct.approved_workers.entrySet()) {
    oprot.writeString(_iter804.getKey());
    oprot.writeI32(_iter804.getValue());
  }
  oprot.writeMapEnd();
}
oprot.writeFieldEnd();
}
oprot.writeFieldStop();
oprot.writeStructEnd();
}
}
