public class BatchOutputCollectorImpl extends BatchOutputCollector {
  private OutputCollector collector;
  public BatchOutputCollectorImpl(  OutputCollector collector){
    this.collector=collector;
  }
  @Override public List<Integer> emit(  String streamId,  List<Object> tuple){
    return collector.emit(streamId,tuple);
  }
  @Override public void emitDirect(  int taskId,  String streamId,  List<Object> tuple){
    collector.emitDirect(taskId,streamId,tuple);
  }
  @Override public void flush(){
    collector.flush();
  }
  @Override public void reportError(  Throwable error){
    collector.reportError(error);
  }
  public void ack(  Tuple tup){
    collector.ack(tup);
  }
  public void fail(  Tuple tup){
    collector.fail(tup);
  }
}
