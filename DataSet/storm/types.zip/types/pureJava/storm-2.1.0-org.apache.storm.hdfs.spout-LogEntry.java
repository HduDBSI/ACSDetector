public static class LogEntry {
  private static final int NUM_FIELDS=3;
  public final long eventTime;
  public final String componentId;
  public final String fileOffset;
  public LogEntry(  long eventtime,  String componentId,  String fileOffset){
    this.eventTime=eventtime;
    this.componentId=componentId;
    this.fileOffset=fileOffset;
  }
  public static LogEntry deserialize(  String line){
    String[] fields=line.split(",",NUM_FIELDS);
    return new LogEntry(Long.parseLong(fields[0]),fields[1],fields[2]);
  }
  @Override public String toString(){
    return eventTime + "," + componentId+ ","+ fileOffset;
  }
  @Override public boolean equals(  Object o){
    if (this == o) {
      return true;
    }
    if (!(o instanceof LogEntry)) {
      return false;
    }
    LogEntry logEntry=(LogEntry)o;
    if (eventTime != logEntry.eventTime) {
      return false;
    }
    if (!componentId.equals(logEntry.componentId)) {
      return false;
    }
    return fileOffset.equals(logEntry.fileOffset);
  }
  @Override public int hashCode(){
    int result=(int)(eventTime ^ (eventTime >>> 32));
    result=31 * result + componentId.hashCode();
    result=31 * result + fileOffset.hashCode();
    return result;
  }
}
