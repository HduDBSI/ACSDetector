public interface ReadOnlySnapshottable<T> extends State {
  T get();
}
