@IntegrationTest public class StormMqttIntegrationTest implements Serializable {
  private static final Logger LOG=LoggerFactory.getLogger(StormMqttIntegrationTest.class);
  private static final String TEST_TOPIC="/mqtt-topology";
  private static final String RESULT_TOPIC="/integration-result";
  private static final String RESULT_PAYLOAD="Storm MQTT Spout";
  static boolean spoutActivated=false;
  private static BrokerService broker;
  @AfterAll public static void cleanup() throws Exception {
    broker.stop();
  }
  @BeforeAll public static void start() throws Exception {
    LOG.warn("Starting broker...");
    broker=new BrokerService();
    broker.addConnector("mqtt://localhost:1883");
    broker.setDataDirectory("target");
    broker.start();
    LOG.debug("MQTT broker started");
  }
  @Test public void testMqttTopology() throws Exception {
    MQTT client=new MQTT();
    client.setTracer(new MqttLogger());
    URI uri=URI.create("tcp://localhost:1883");
    client.setHost(uri);
    client.setClientId("MQTTSubscriber");
    client.setCleanSession(false);
    BlockingConnection connection=client.blockingConnection();
    connection.connect();
    Topic[] topics={new Topic("/integration-result",QoS.AT_LEAST_ONCE)};
    byte[] qoses=connection.subscribe(topics);
    try (LocalCluster cluster=new LocalCluster();LocalTopology topo=cluster.submitTopology("test",new Config(),buildMqttTopology())){
      LOG.info("topology started");
      while (!spoutActivated) {
        Thread.sleep(500);
      }
      MqttOptions options=new MqttOptions();
      options.setCleanConnection(false);
      MqttPublisher publisher=new MqttPublisher(options,true);
      publisher.connectMqtt("MqttPublisher");
      publisher.publish(new MqttMessage(TEST_TOPIC,"test".getBytes()));
      LOG.info("published message");
      Message message=connection.receive();
      LOG.info("Message recieved on topic: {}",message.getTopic());
      LOG.info("Payload: {}",new String(message.getPayload()));
      message.ack();
      Assert.assertArrayEquals(message.getPayload(),RESULT_PAYLOAD.getBytes());
      Assert.assertEquals(message.getTopic(),RESULT_TOPIC);
    }
   }
  public StormTopology buildMqttTopology(){
    TopologyBuilder builder=new TopologyBuilder();
    MqttOptions options=new MqttOptions();
    options.setTopics(Arrays.asList(TEST_TOPIC));
    options.setCleanConnection(false);
    TestSpout spout=new TestSpout(new StringMessageMapper(),options);
    MqttBolt bolt=new MqttBolt(options,new MqttTupleMapper(){
      @Override public MqttMessage toMessage(      ITuple tuple){
        LOG.info("Received: {}",tuple);
        return new MqttMessage(RESULT_TOPIC,RESULT_PAYLOAD.getBytes());
      }
    }
);
    builder.setSpout("mqtt-spout",spout);
    builder.setBolt("mqtt-bolt",bolt).shuffleGrouping("mqtt-spout");
    return builder.createTopology();
  }
public static class TestSpout extends MqttSpout {
    public TestSpout(    MqttMessageMapper type,    MqttOptions options){
      super(type,options);
    }
    @Override public void activate(){
      super.activate();
      LOG.info("Spout activated.");
      spoutActivated=true;
    }
  }
}
