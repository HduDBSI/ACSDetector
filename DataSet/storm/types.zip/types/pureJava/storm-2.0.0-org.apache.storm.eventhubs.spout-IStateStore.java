public interface IStateStore extends Serializable {
  public void open();
  public void close();
  public void saveData(  String path,  String data);
  public String readData(  String path);
}
