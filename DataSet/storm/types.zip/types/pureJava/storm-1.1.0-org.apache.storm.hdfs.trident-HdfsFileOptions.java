public static class HdfsFileOptions extends Options {
  private transient FSDataOutputStream out;
  protected RecordFormat format;
  private long offset=0;
  private int bufferSize=131072;
  public HdfsFileOptions withFsUrl(  String fsUrl){
    this.fsUrl=fsUrl;
    return this;
  }
  public HdfsFileOptions withConfigKey(  String configKey){
    this.configKey=configKey;
    return this;
  }
  public HdfsFileOptions withFileNameFormat(  FileNameFormat fileNameFormat){
    this.fileNameFormat=fileNameFormat;
    return this;
  }
  public HdfsFileOptions withRecordFormat(  RecordFormat format){
    this.format=format;
    return this;
  }
  public HdfsFileOptions withRotationPolicy(  FileRotationPolicy rotationPolicy){
    this.rotationPolicy=rotationPolicy;
    return this;
  }
  /** 
 * <p>Set the size of the buffer used for hdfs file copy in case of recovery. The default value is 131072.</p> <p> Note: The lower limit for the parameter is 4096, below which the option is ignored. </p>
 * @param sizeInBytes the buffer size in bytes
 * @return {@link HdfsFileOptions}
 */
  public HdfsFileOptions withBufferSize(  int sizeInBytes){
    this.bufferSize=Math.max(4096,sizeInBytes);
    return this;
  }
  @Deprecated public HdfsFileOptions addRotationAction(  RotationAction action){
    this.rotationActions.add(action);
    return this;
  }
  @Override void doPrepare(  Map conf,  int partitionIndex,  int numPartitions) throws IOException {
    LOG.info("Preparing HDFS File state...");
    this.fs=FileSystem.get(URI.create(this.fsUrl),hdfsConfig);
  }
  @Override public long getCurrentOffset(){
    return offset;
  }
  @Override public void doCommit(  Long txId) throws IOException {
    if (this.rotationPolicy.mark(this.offset)) {
      rotateOutputFile();
      this.offset=0;
      this.rotationPolicy.reset();
    }
 else {
      if (this.out instanceof HdfsDataOutputStream) {
        ((HdfsDataOutputStream)this.out).hsync(EnumSet.of(HdfsDataOutputStream.SyncFlag.UPDATE_LENGTH));
      }
 else {
        this.out.hsync();
      }
    }
  }
  @Override void doRecover(  Path srcPath,  long nBytes) throws IOException {
    this.offset=0;
    FSDataInputStream is=this.fs.open(srcPath);
    copyBytes(is,out,nBytes);
    this.offset=nBytes;
  }
  private void copyBytes(  FSDataInputStream is,  FSDataOutputStream out,  long bytesToCopy) throws IOException {
    byte[] buf=new byte[bufferSize];
    int n;
    while ((n=is.read(buf)) != -1 && bytesToCopy > 0) {
      out.write(buf,0,(int)Math.min(n,bytesToCopy));
      bytesToCopy-=n;
    }
  }
  @Override void closeOutputFile() throws IOException {
    this.out.close();
  }
  @Override Path createOutputFile() throws IOException {
    Path path=new Path(this.fileNameFormat.getPath(),this.fileNameFormat.getName(this.rotation,System.currentTimeMillis()));
    this.out=this.fs.create(path);
    return path;
  }
  @Override public void execute(  List<TridentTuple> tuples) throws IOException {
    for (    TridentTuple tuple : tuples) {
      byte[] bytes=this.format.format(tuple);
      out.write(bytes);
      this.offset+=bytes.length;
    }
  }
}
