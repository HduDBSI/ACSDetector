private static class BeginDownloadResultStandardScheme extends org.apache.storm.thrift.scheme.StandardScheme<BeginDownloadResult> {
  public void read(  org.apache.storm.thrift.protocol.TProtocol iprot,  BeginDownloadResult struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TField schemeField;
    iprot.readStructBegin();
    while (true) {
      schemeField=iprot.readFieldBegin();
      if (schemeField.type == org.apache.storm.thrift.protocol.TType.STOP) {
        break;
      }
switch (schemeField.id) {
case 1:
        if (schemeField.type == org.apache.storm.thrift.protocol.TType.I64) {
          struct.version=iprot.readI64();
          struct.set_version_isSet(true);
        }
 else {
          org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
        }
      break;
case 2:
    if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
      struct.session=iprot.readString();
      struct.set_session_isSet(true);
    }
 else {
      org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
    }
  break;
case 3:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.I64) {
  struct.data_size=iprot.readI64();
  struct.set_data_size_isSet(true);
}
 else {
  org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
default :
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
iprot.readFieldEnd();
}
iprot.readStructEnd();
struct.validate();
}
public void write(org.apache.storm.thrift.protocol.TProtocol oprot,BeginDownloadResult struct) throws org.apache.storm.thrift.TException {
struct.validate();
oprot.writeStructBegin(STRUCT_DESC);
oprot.writeFieldBegin(VERSION_FIELD_DESC);
oprot.writeI64(struct.version);
oprot.writeFieldEnd();
if (struct.session != null) {
oprot.writeFieldBegin(SESSION_FIELD_DESC);
oprot.writeString(struct.session);
oprot.writeFieldEnd();
}
if (struct.is_set_data_size()) {
oprot.writeFieldBegin(DATA_SIZE_FIELD_DESC);
oprot.writeI64(struct.data_size);
oprot.writeFieldEnd();
}
oprot.writeFieldStop();
oprot.writeStructEnd();
}
}
