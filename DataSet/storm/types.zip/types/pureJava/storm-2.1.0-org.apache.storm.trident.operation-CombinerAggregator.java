public interface CombinerAggregator<T> extends Serializable {
  T init(  TridentTuple tuple);
  T combine(  T val1,  T val2);
  T zero();
}
