/** 
 * {@link ISpoutPartition} that wraps {@link TopicPartition} information.
 */
public class KafkaTridentSpoutTopicPartition implements ISpoutPartition, Serializable {
  private final TopicPartition topicPartition;
  public KafkaTridentSpoutTopicPartition(  String topic,  int partition){
    this(new TopicPartition(topic,partition));
  }
  public KafkaTridentSpoutTopicPartition(  TopicPartition topicPartition){
    this.topicPartition=topicPartition;
  }
  public TopicPartition getTopicPartition(){
    return topicPartition;
  }
  @Override public String getId(){
    return topicPartition.topic() + "@" + topicPartition.partition();
  }
  @Override public boolean equals(  Object o){
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    KafkaTridentSpoutTopicPartition that=(KafkaTridentSpoutTopicPartition)o;
    return topicPartition.equals(that.topicPartition);
  }
  @Override public int hashCode(){
    return topicPartition.hashCode();
  }
  @Override public String toString(){
    return topicPartition.toString();
  }
}
