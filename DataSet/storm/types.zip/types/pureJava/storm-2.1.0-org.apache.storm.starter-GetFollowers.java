public static class GetFollowers extends BaseBasicBolt {
  @Override public void execute(  Tuple tuple,  BasicOutputCollector collector){
    Object id=tuple.getValue(0);
    String tweeter=tuple.getString(1);
    List<String> followers=FOLLOWERS_DB.get(tweeter);
    if (followers != null) {
      for (      String follower : followers) {
        collector.emit(new Values(id,follower));
      }
    }
  }
  @Override public void declareOutputFields(  OutputFieldsDeclarer declarer){
    declarer.declare(new Fields("id","follower"));
  }
}
