/** 
 * This aggregator computes the maximum of aggregated tuples in a stream. It uses given  {@code comparator} for comparing two values in astream.
 */
public class MaxWithComparator<T> extends ComparisonAggregator<T> {
  private final Comparator<T> comparator;
  public MaxWithComparator(  Comparator<T> comparator){
    this(null,comparator);
  }
  public MaxWithComparator(  String inputFieldName,  Comparator<T> comparator){
    super(inputFieldName);
    this.comparator=comparator;
  }
  @Override protected T compare(  T value1,  T value2){
    return comparator.compare(value1,value2) > 0 ? value1 : value2;
  }
  @Override public String toString(){
    return "MaxWithComparator{" + "comparator=" + comparator + '}';
  }
}
