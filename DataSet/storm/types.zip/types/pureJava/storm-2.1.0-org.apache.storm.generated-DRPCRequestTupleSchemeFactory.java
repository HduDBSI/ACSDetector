private static class DRPCRequestTupleSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public DRPCRequestTupleScheme getScheme(){
    return new DRPCRequestTupleScheme();
  }
}
