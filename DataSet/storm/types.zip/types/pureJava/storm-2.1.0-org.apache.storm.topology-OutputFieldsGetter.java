public class OutputFieldsGetter implements OutputFieldsDeclarer {
  private Map<String,StreamInfo> fields=new HashMap<>();
  @Override public void declare(  Fields fields){
    declare(false,fields);
  }
  @Override public void declare(  boolean direct,  Fields fields){
    declareStream(Utils.DEFAULT_STREAM_ID,direct,fields);
  }
  @Override public void declareStream(  String streamId,  Fields fields){
    declareStream(streamId,false,fields);
  }
  @Override public void declareStream(  String streamId,  boolean direct,  Fields fields){
    if (null == streamId) {
      throw new IllegalArgumentException("streamId can't be null");
    }
    if (this.fields.containsKey(streamId)) {
      throw new IllegalArgumentException("Fields for " + streamId + " already set");
    }
    this.fields.put(streamId,new StreamInfo(fields.toList(),direct));
  }
  public Map<String,StreamInfo> getFieldsDeclaration(){
    return fields;
  }
}
