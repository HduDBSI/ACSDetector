public class PartitionManager extends SimplePartitionManager {
  private static final Logger logger=LoggerFactory.getLogger(PartitionManager.class);
  private final int ehReceiveTimeoutMs=5000;
  private final Map<String,EventDataWrap> pending;
  private final TreeSet<EventDataWrap> toResend;
  public PartitionManager(  EventHubSpoutConfig spoutConfig,  String partitionId,  IStateStore stateStore,  IEventHubReceiver receiver){
    super(spoutConfig,partitionId,stateStore,receiver);
    this.pending=new LinkedHashMap<String,EventDataWrap>();
    this.toResend=new TreeSet<EventDataWrap>();
  }
  @Override public EventDataWrap receive(){
    if (pending.size() >= config.getMaxPendingMsgsPerPartition()) {
      return null;
    }
    EventDataWrap eventDatawrap;
    if (toResend.isEmpty()) {
      eventDatawrap=receiver.receive();
    }
 else {
      eventDatawrap=toResend.pollFirst();
    }
    if (eventDatawrap != null) {
      lastOffset=eventDatawrap.getMessageId().getOffset();
      pending.put(lastOffset,eventDatawrap);
    }
    return eventDatawrap;
  }
  @Override public void ack(  String offset){
    pending.remove(offset);
  }
  @Override public void fail(  String offset){
    logger.warn("fail on " + offset);
    EventDataWrap eventDataWrap=pending.remove(offset);
    toResend.add(eventDataWrap);
  }
  @Override protected String getCompletedOffset(){
    String offset=null;
    if (pending.size() > 0) {
      offset=pending.keySet().iterator().next();
    }
    if (toResend.size() > 0) {
      String offset2=toResend.first().getMessageId().getOffset();
      if (offset == null || offset2.compareTo(offset) < 0) {
        offset=offset2;
      }
    }
    if (offset == null) {
      offset=lastOffset;
    }
    return offset;
  }
}
