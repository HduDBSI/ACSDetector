public interface ISaslClient {
  void channelReady(  Channel channel);
  String name();
  String secretKey();
}
