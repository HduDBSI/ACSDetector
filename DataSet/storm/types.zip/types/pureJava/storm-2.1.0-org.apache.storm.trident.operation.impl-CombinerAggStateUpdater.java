public class CombinerAggStateUpdater implements StateUpdater<Snapshottable> {
  CombinerAggregator agg;
  public CombinerAggStateUpdater(  CombinerAggregator agg){
    this.agg=agg;
  }
  @Override public void updateState(  Snapshottable state,  List<TridentTuple> tuples,  TridentCollector collector){
    if (tuples.size() != 1) {
      throw new IllegalArgumentException("Combiner state updater should receive a single tuple. Received: " + tuples.toString());
    }
    Object newVal=state.update(new CombinerValueUpdater(agg,tuples.get(0).getValue(0)));
    collector.emit(new Values(newVal));
  }
  @Override public void prepare(  Map<String,Object> conf,  TridentOperationContext context){
  }
  @Override public void cleanup(){
  }
}
