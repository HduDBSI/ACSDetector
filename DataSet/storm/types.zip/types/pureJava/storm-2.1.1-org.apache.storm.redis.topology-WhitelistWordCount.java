public class WhitelistWordCount {
  private static final String WORD_SPOUT="WORD_SPOUT";
  private static final String WHITELIST_BOLT="WHITELIST_BOLT";
  private static final String COUNT_BOLT="COUNT_BOLT";
  private static final String PRINT_BOLT="PRINT_BOLT";
  private static final String TEST_REDIS_HOST="127.0.0.1";
  private static final int TEST_REDIS_PORT=6379;
public static class PrintWordTotalCountBolt extends BaseRichBolt {
    private static final Logger LOG=LoggerFactory.getLogger(PrintWordTotalCountBolt.class);
    private static final Random RANDOM=new Random();
    private OutputCollector collector;
    @Override public void prepare(    Map<String,Object> topoConf,    TopologyContext context,    OutputCollector collector){
      this.collector=collector;
    }
    @Override public void execute(    Tuple input){
      String wordName=input.getStringByField("word");
      String countStr=input.getStringByField("count");
      if (RANDOM.nextInt(1000) > 995) {
        int count=0;
        if (countStr != null) {
          count=Integer.parseInt(countStr);
        }
        LOG.info("Count result - word : " + wordName + " / count : "+ count);
      }
      collector.ack(input);
    }
    @Override public void declareOutputFields(    OutputFieldsDeclarer declarer){
    }
  }
  public static void main(  String[] args) throws Exception {
    String host=TEST_REDIS_HOST;
    int port=TEST_REDIS_PORT;
    if (args.length >= 2) {
      host=args[0];
      port=Integer.parseInt(args[1]);
    }
    JedisPoolConfig poolConfig=new JedisPoolConfig.Builder().setHost(host).setPort(port).build();
    WordSpout spout=new WordSpout();
    RedisFilterMapper filterMapper=setupWhitelistMapper();
    RedisFilterBolt whitelistBolt=new RedisFilterBolt(poolConfig,filterMapper);
    WordCounter wordCounterBolt=new WordCounter();
    TopologyBuilder builder=new TopologyBuilder();
    builder.setSpout(WORD_SPOUT,spout,1);
    builder.setBolt(WHITELIST_BOLT,whitelistBolt,1).shuffleGrouping(WORD_SPOUT);
    builder.setBolt(COUNT_BOLT,wordCounterBolt,1).fieldsGrouping(WHITELIST_BOLT,new Fields("word"));
    PrintWordTotalCountBolt printBolt=new PrintWordTotalCountBolt();
    builder.setBolt(PRINT_BOLT,printBolt,1).shuffleGrouping(COUNT_BOLT);
    String topoName="test";
    if (args.length == 3) {
      topoName=args[2];
    }
 else     if (args.length > 3) {
      System.out.println("Usage: WhitelistWordCount <redis host> <redis port> [topology name]");
      return;
    }
    Config config=new Config();
    StormSubmitter.submitTopology(topoName,config,builder.createTopology());
  }
  private static RedisFilterMapper setupWhitelistMapper(){
    return new WhitelistWordFilterMapper();
  }
private static class WhitelistWordFilterMapper implements RedisFilterMapper {
    private RedisDataTypeDescription description;
    private final String setKey="whitelist";
    public WhitelistWordFilterMapper(){
      description=new RedisDataTypeDescription(RedisDataTypeDescription.RedisDataType.SET,setKey);
    }
    @Override public void declareOutputFields(    OutputFieldsDeclarer declarer){
      declarer.declare(new Fields("word"));
    }
    @Override public RedisDataTypeDescription getDataTypeDescription(){
      return description;
    }
    @Override public String getKeyFromTuple(    ITuple tuple){
      return tuple.getStringByField("word");
    }
    @Override public String getValueFromTuple(    ITuple tuple){
      return null;
    }
  }
}
