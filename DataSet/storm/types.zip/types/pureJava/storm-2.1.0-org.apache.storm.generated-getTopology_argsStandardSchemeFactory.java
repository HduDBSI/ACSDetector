private static class getTopology_argsStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public getTopology_argsStandardScheme getScheme(){
    return new getTopology_argsStandardScheme();
  }
}
