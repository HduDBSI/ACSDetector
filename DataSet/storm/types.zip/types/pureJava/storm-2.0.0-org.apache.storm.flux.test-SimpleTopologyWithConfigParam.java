/** 
 * Test topology source that does not implement TopologySource, but has the same `getTopology()` method.
 */
public class SimpleTopologyWithConfigParam {
  public SimpleTopologyWithConfigParam(){
  }
  public SimpleTopologyWithConfigParam(  String foo,  String bar){
  }
  public StormTopology getTopology(  Config config){
    TopologyBuilder builder=new TopologyBuilder();
    FluxShellSpout spout=new FluxShellSpout(new String[]{"node","randomsentence.js"},new String[]{"word"});
    builder.setSpout("sentence-spout",spout,1);
    builder.setBolt("log-bolt",new LogInfoBolt(),1).shuffleGrouping("sentence-spout");
    return builder.createTopology();
  }
}
