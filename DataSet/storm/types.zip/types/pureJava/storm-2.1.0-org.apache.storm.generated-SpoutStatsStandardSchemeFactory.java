private static class SpoutStatsStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public SpoutStatsStandardScheme getScheme(){
    return new SpoutStatsStandardScheme();
  }
}
