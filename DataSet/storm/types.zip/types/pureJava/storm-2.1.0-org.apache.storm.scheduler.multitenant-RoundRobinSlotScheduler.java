/** 
 * Place executors into slots in a round robin way, taking into account component spreading among different hosts.
 */
public static class RoundRobinSlotScheduler {
  private Map<String,Set<String>> _nodeToComps;
  private HashMap<String,List<ExecutorDetails>> _spreadToSchedule;
  private LinkedList<Set<ExecutorDetails>> _slots;
  private Set<ExecutorDetails> _lastSlot;
  private Cluster _cluster;
  private String _topId;
  /** 
 * Create a new scheduler for a given topology
 * @param td the topology to schedule
 * @param slotsToUse the number of slots to use for the executors left toschedule.
 * @param cluster the cluster to schedule this on.
 */
  public RoundRobinSlotScheduler(  TopologyDetails td,  int slotsToUse,  Cluster cluster){
    _topId=td.getId();
    _cluster=cluster;
    Map<ExecutorDetails,String> execToComp=td.getExecutorToComponent();
    SchedulerAssignment assignment=_cluster.getAssignmentById(_topId);
    _nodeToComps=new HashMap<>();
    if (assignment != null) {
      Map<ExecutorDetails,WorkerSlot> execToSlot=assignment.getExecutorToSlot();
      for (      Entry<ExecutorDetails,WorkerSlot> entry : execToSlot.entrySet()) {
        String nodeId=entry.getValue().getNodeId();
        Set<String> comps=_nodeToComps.get(nodeId);
        if (comps == null) {
          comps=new HashSet<>();
          _nodeToComps.put(nodeId,comps);
        }
        comps.add(execToComp.get(entry.getKey()));
      }
    }
    _spreadToSchedule=new HashMap<>();
    List<String> spreadComps=(List<String>)td.getConf().get(Config.TOPOLOGY_SPREAD_COMPONENTS);
    if (spreadComps != null) {
      for (      String comp : spreadComps) {
        _spreadToSchedule.put(comp,new ArrayList<ExecutorDetails>());
      }
    }
    _slots=new LinkedList<>();
    for (int i=0; i < slotsToUse; i++) {
      _slots.add(new HashSet<ExecutorDetails>());
    }
    int at=0;
    for (    Entry<String,List<ExecutorDetails>> entry : _cluster.getNeedsSchedulingComponentToExecutors(td).entrySet()) {
      LOG.debug("Scheduling for {}",entry.getKey());
      if (_spreadToSchedule.containsKey(entry.getKey())) {
        LOG.debug("Saving {} for spread...",entry.getKey());
        _spreadToSchedule.get(entry.getKey()).addAll(entry.getValue());
      }
 else {
        for (        ExecutorDetails ed : entry.getValue()) {
          LOG.debug("Assigning {} {} to slot {}",entry.getKey(),ed,at);
          _slots.get(at).add(ed);
          at++;
          if (at >= _slots.size()) {
            at=0;
          }
        }
      }
    }
    _lastSlot=_slots.get(_slots.size() - 1);
  }
  /** 
 * Assign a slot to the given node.
 * @param n the node to assign a slot to.
 * @return true if there are more slots to assign else false.
 */
  public boolean assignSlotTo(  Node n){
    if (_slots.isEmpty()) {
      return false;
    }
    Set<ExecutorDetails> slot=_slots.pop();
    if (slot == _lastSlot) {
      for (      Entry<String,List<ExecutorDetails>> entry : _spreadToSchedule.entrySet()) {
        if (entry.getValue().size() > 0) {
          slot.addAll(entry.getValue());
        }
      }
    }
 else {
      String nodeId=n.getId();
      Set<String> nodeComps=_nodeToComps.get(nodeId);
      if (nodeComps == null) {
        nodeComps=new HashSet<>();
        _nodeToComps.put(nodeId,nodeComps);
      }
      for (      Entry<String,List<ExecutorDetails>> entry : _spreadToSchedule.entrySet()) {
        if (entry.getValue().size() > 0) {
          String comp=entry.getKey();
          if (!nodeComps.contains(comp)) {
            nodeComps.add(comp);
            slot.add(entry.getValue().remove(0));
          }
        }
      }
    }
    n.assign(_topId,slot,_cluster);
    return !_slots.isEmpty();
  }
}
