final class SaslNettyClientState {
  public static final AttributeKey<SaslNettyClient> SASL_NETTY_CLIENT=AttributeKey.valueOf("sasl.netty.client");
}
