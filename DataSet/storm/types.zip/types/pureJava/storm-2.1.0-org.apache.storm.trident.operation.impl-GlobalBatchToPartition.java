public class GlobalBatchToPartition implements SingleEmitAggregator.BatchToPartition {
  @Override public int partitionIndex(  Object batchId,  int numPartitions){
    return 0;
  }
}
