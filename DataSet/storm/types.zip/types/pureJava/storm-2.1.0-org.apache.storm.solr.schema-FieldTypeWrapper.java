/** 
 * Class wrapping all the information for fields and types.
 */
public static class FieldTypeWrapper implements Serializable {
  Field field;
  FieldType type;
  public FieldTypeWrapper(  Field field,  FieldType type){
    this.field=field;
    this.type=type;
  }
  public Field getField(){
    return field;
  }
  public FieldType getType(){
    return type;
  }
  @Override public String toString(){
    return "FieldTypeWrapper{" + "field=" + field + ", type="+ type+ '}';
  }
}
