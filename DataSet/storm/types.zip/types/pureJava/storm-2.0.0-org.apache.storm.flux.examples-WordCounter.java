/** 
 * This bolt is used by the HBase example. It simply emits the first field found in the incoming tuple as "word", with a "count" of `1`. <p/> In this case, the downstream HBase bolt handles the counting, so a value of `1` will just increment the HBase counter by one.
 */
public class WordCounter extends BaseBasicBolt {
  private static final Logger LOG=LoggerFactory.getLogger(WordCounter.class);
  public void prepare(  Map<String,Object> topoConf,  TopologyContext context){
  }
  public void execute(  Tuple input,  BasicOutputCollector collector){
    collector.emit(tuple(input.getValues().get(0),1));
  }
  public void cleanup(){
  }
  public void declareOutputFields(  OutputFieldsDeclarer declarer){
    declarer.declare(new Fields("word","count"));
  }
  @Override public Map<String,Object> getComponentConfiguration(){
    return null;
  }
}
