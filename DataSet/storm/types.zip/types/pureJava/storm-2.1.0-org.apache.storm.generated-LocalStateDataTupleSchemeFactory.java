private static class LocalStateDataTupleSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public LocalStateDataTupleScheme getScheme(){
    return new LocalStateDataTupleScheme();
  }
}
