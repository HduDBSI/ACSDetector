private class KafkaSpoutConsumerRebalanceListener implements ConsumerRebalanceListener {
  private Collection<TopicPartition> previousAssignment=new HashSet<>();
  @Override public void onPartitionsRevoked(  Collection<TopicPartition> partitions){
    previousAssignment=partitions;
    LOG.info("Partitions revoked. [consumer-group={}, consumer={}, topic-partitions={}]",kafkaSpoutConfig.getConsumerGroupId(),consumer,partitions);
    if (isAtLeastOnceProcessing()) {
      commitOffsetsForAckedTuples();
    }
  }
  @Override public void onPartitionsAssigned(  Collection<TopicPartition> partitions){
    LOG.info("Partitions reassignment. [task-ID={}, consumer-group={}, consumer={}, topic-partitions={}]",context.getThisTaskId(),kafkaSpoutConfig.getConsumerGroupId(),consumer,partitions);
    initialize(partitions);
    tupleListener.onPartitionsReassigned(partitions);
  }
  private void initialize(  Collection<TopicPartition> partitions){
    if (isAtLeastOnceProcessing()) {
      offsetManagers.keySet().retainAll(partitions);
      retryService.retainAll(partitions);
      emitted.removeIf(msgId -> !partitions.contains(msgId.getTopicPartition()));
    }
    waitingToEmit.keySet().retainAll(partitions);
    Set<TopicPartition> newPartitions=new HashSet<>(partitions);
    newPartitions.removeAll(previousAssignment);
    for (    TopicPartition newTp : newPartitions) {
      final OffsetAndMetadata committedOffset=consumer.committed(newTp);
      final long fetchOffset=doSeek(newTp,committedOffset);
      LOG.debug("Set consumer position to [{}] for topic-partition [{}] with [{}] and committed offset [{}]",fetchOffset,newTp,firstPollOffsetStrategy,committedOffset);
      if (isAtLeastOnceProcessing() && !offsetManagers.containsKey(newTp)) {
        offsetManagers.put(newTp,new OffsetManager(newTp,fetchOffset));
      }
    }
    LOG.info("Initialization complete");
  }
  /** 
 * Sets the cursor to the location dictated by the first poll strategy and returns the fetch offset.
 */
  private long doSeek(  TopicPartition newTp,  OffsetAndMetadata committedOffset){
    LOG.trace("Seeking offset for topic-partition [{}] with [{}] and committed offset [{}]",newTp,firstPollOffsetStrategy,committedOffset);
    if (committedOffset != null) {
      if (commitMetadataManager.isOffsetCommittedByThisTopology(newTp,committedOffset,Collections.unmodifiableMap(offsetManagers))) {
        consumer.seek(newTp,committedOffset.offset());
      }
 else {
        if (firstPollOffsetStrategy.equals(EARLIEST)) {
          consumer.seekToBeginning(Collections.singleton(newTp));
        }
 else         if (firstPollOffsetStrategy.equals(LATEST)) {
          consumer.seekToEnd(Collections.singleton(newTp));
        }
 else {
          consumer.seek(newTp,committedOffset.offset());
        }
      }
    }
 else {
      if (firstPollOffsetStrategy.equals(EARLIEST) || firstPollOffsetStrategy.equals(UNCOMMITTED_EARLIEST)) {
        consumer.seekToBeginning(Collections.singleton(newTp));
      }
 else       if (firstPollOffsetStrategy.equals(LATEST) || firstPollOffsetStrategy.equals(UNCOMMITTED_LATEST)) {
        consumer.seekToEnd(Collections.singleton(newTp));
      }
    }
    return consumer.position(newTp);
  }
}
