public interface IConnection extends AutoCloseable {
  /** 
 * Send load metrics to all downstream connections.
 * @param taskToLoad a map from the task id to the load for that task.
 */
  void sendLoadMetrics(  Map<Integer,Double> taskToLoad);
  /** 
 * Sends the back pressure metrics to all downstream connections.
 */
  void sendBackPressureStatus(  BackPressureStatus bpStatus);
  /** 
 * send batch messages.
 */
  void send(  Iterator<TaskMessage> msgs);
  /** 
 * Get the current load for the given tasks.
 * @param tasks the tasks to look for.
 * @return a Load for each of the tasks it knows about.
 */
  Map<Integer,Load> getLoad(  Collection<Integer> tasks);
  /** 
 * Get the port for this connection.
 * @return The port this connection is using
 */
  int getPort();
  /** 
 * close this connection.
 */
  @Override void close();
}
