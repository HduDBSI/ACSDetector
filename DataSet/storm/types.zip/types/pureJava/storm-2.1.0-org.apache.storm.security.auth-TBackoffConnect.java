public class TBackoffConnect {
  private static final Logger LOG=LoggerFactory.getLogger(TBackoffConnect.class);
  private int completedRetries=0;
  private int retryTimes;
  private StormBoundedExponentialBackoffRetry waitGrabber;
  private boolean retryForever=false;
  public TBackoffConnect(  int retryTimes,  int retryInterval,  int retryIntervalCeiling,  boolean retryForever){
    this.retryForever=retryForever;
    this.retryTimes=retryTimes;
    waitGrabber=new StormBoundedExponentialBackoffRetry(retryInterval,retryIntervalCeiling,retryTimes);
  }
  public TBackoffConnect(  int retryTimes,  int retryInterval,  int retryIntervalCeiling){
    this(retryTimes,retryInterval,retryIntervalCeiling,false);
  }
  public TTransport doConnectWithRetry(  ITransportPlugin transportPlugin,  TTransport underlyingTransport,  String host,  String asUser) throws IOException {
    boolean connected=false;
    TTransport transportResult=null;
    while (!connected) {
      try {
        transportResult=transportPlugin.connect(underlyingTransport,host,asUser);
        connected=true;
      }
 catch (      TTransportException ex) {
        retryNext(ex);
      }
    }
    return transportResult;
  }
  private void retryNext(  TTransportException ex){
    if (!canRetry()) {
      throw new RuntimeException(ex);
    }
    try {
      long sleeptime=waitGrabber.getSleepTimeMs(completedRetries,0);
      LOG.debug("Failed to connect. Retrying... (" + Integer.toString(completedRetries) + ") in "+ Long.toString(sleeptime)+ "ms");
      Thread.sleep(sleeptime);
    }
 catch (    InterruptedException e) {
      LOG.info("Nimbus connection retry interrupted.");
    }
    completedRetries++;
  }
  private boolean canRetry(){
    return retryForever || (completedRetries < retryTimes);
  }
}
