private static class HBAuthorizationExceptionStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public HBAuthorizationExceptionStandardScheme getScheme(){
    return new HBAuthorizationExceptionStandardScheme();
  }
}
