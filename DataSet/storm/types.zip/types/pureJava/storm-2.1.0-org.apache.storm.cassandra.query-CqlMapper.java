/** 
 * Default interface to defines how a storm tuple maps to a list of columns representing a row in a database.
 */
public interface CqlMapper extends Serializable {
  /** 
 * Maps the specified input tuple to a list of CQL columns.
 * @param tuple the input tuple.
 * @return the list of
 */
  List<Column> map(  ITuple tuple);
public static final class SelectableCqlMapper implements CqlMapper {
    private final List<FieldSelector> selectors;
    /** 
 * Creates a new  {@link org.apache.storm.cassandra.query.CqlMapper.DefaultCqlMapper} instance.
 * @param selectors list of selectors used to extract column values from tuple.
 */
    public SelectableCqlMapper(    List<FieldSelector> selectors){
      this.selectors=selectors;
    }
    /** 
 * {@inheritDoc}
 */
    @Override public List<Column> map(    ITuple tuple){
      List<Column> columns=new ArrayList<>(selectors.size());
      for (      FieldSelector selector : selectors) {
        columns.add(selector.select(tuple));
      }
      return columns;
    }
  }
  /** 
 * Default  {@link CqlMapper} to map all tuple values to column.
 */
public static final class DefaultCqlMapper implements CqlMapper {
    /** 
 * Creates a new  {@link org.apache.storm.cassandra.query.CqlMapper.DefaultCqlMapper} instance.
 */
    public DefaultCqlMapper(){
    }
    /** 
 * {@inheritDoc}
 */
    @Override public List<Column> map(    ITuple tuple){
      List<Column> columns=new ArrayList<>(tuple.size());
      for (      String name : tuple.getFields()) {
        columns.add(new Column(name,tuple.getValueByField(name)));
      }
      return columns;
    }
  }
}
