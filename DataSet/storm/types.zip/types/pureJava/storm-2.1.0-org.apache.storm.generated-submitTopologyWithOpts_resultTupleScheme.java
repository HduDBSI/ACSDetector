private static class submitTopologyWithOpts_resultTupleScheme extends org.apache.storm.thrift.scheme.TupleScheme<submitTopologyWithOpts_result> {
  @Override public void write(  org.apache.storm.thrift.protocol.TProtocol prot,  submitTopologyWithOpts_result struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
    java.util.BitSet optionals=new java.util.BitSet();
    if (struct.is_set_e()) {
      optionals.set(0);
    }
    if (struct.is_set_ite()) {
      optionals.set(1);
    }
    if (struct.is_set_aze()) {
      optionals.set(2);
    }
    oprot.writeBitSet(optionals,3);
    if (struct.is_set_e()) {
      struct.e.write(oprot);
    }
    if (struct.is_set_ite()) {
      struct.ite.write(oprot);
    }
    if (struct.is_set_aze()) {
      struct.aze.write(oprot);
    }
  }
  @Override public void read(  org.apache.storm.thrift.protocol.TProtocol prot,  submitTopologyWithOpts_result struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
    java.util.BitSet incoming=iprot.readBitSet(3);
    if (incoming.get(0)) {
      struct.e=new AlreadyAliveException();
      struct.e.read(iprot);
      struct.set_e_isSet(true);
    }
    if (incoming.get(1)) {
      struct.ite=new InvalidTopologyException();
      struct.ite.read(iprot);
      struct.set_ite_isSet(true);
    }
    if (incoming.get(2)) {
      struct.aze=new AuthorizationException();
      struct.aze.read(iprot);
      struct.set_aze_isSet(true);
    }
  }
}
