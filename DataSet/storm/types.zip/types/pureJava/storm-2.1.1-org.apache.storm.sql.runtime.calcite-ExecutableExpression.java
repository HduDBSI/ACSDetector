/** 
 * Compiled executable expression.
 */
public interface ExecutableExpression extends Serializable {
  Object execute(  Context context);
  void execute(  Context context,  Object[] results);
}
