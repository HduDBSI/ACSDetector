private static class beginFileUpload_argsTupleScheme extends org.apache.storm.thrift.scheme.TupleScheme<beginFileUpload_args> {
  @Override public void write(  org.apache.storm.thrift.protocol.TProtocol prot,  beginFileUpload_args struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
  }
  @Override public void read(  org.apache.storm.thrift.protocol.TProtocol prot,  beginFileUpload_args struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
  }
}
