private static interface Run {
  public void run() throws Exception ;
}
