public interface StateUpdater<S extends State> extends Operation {
  void updateState(  S state,  List<TridentTuple> tuples,  TridentCollector collector);
}
