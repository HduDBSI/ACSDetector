/** 
 * RedisDataTypeDescription defines data type and additional key if needed for lookup / store tuples.
 */
public class RedisDataTypeDescription implements Serializable {
  private RedisDataType dataType;
  private String additionalKey;
  /** 
 * Constructor
 * @param dataType data type
 */
  public RedisDataTypeDescription(  RedisDataType dataType){
    this(dataType,null);
  }
  /** 
 * Constructor
 * @param dataType data type
 * @param additionalKey additional key for hash and sorted set
 */
  public RedisDataTypeDescription(  RedisDataType dataType,  String additionalKey){
    this.dataType=dataType;
    this.additionalKey=additionalKey;
    if (dataType == RedisDataType.HASH || dataType == RedisDataType.SORTED_SET || dataType == RedisDataType.GEO) {
      if (additionalKey == null) {
        throw new IllegalArgumentException("Hash, Sorted Set and GEO should have additional key");
      }
    }
  }
  /** 
 * Returns defined data type.
 * @return data type
 */
  public RedisDataType getDataType(){
    return dataType;
  }
  /** 
 * Returns defined additional key.
 * @return additional key
 */
  public String getAdditionalKey(){
    return additionalKey;
  }
  public enum RedisDataType {  STRING,   HASH,   LIST,   SET,   SORTED_SET,   HYPER_LOG_LOG,   GEO}
}
