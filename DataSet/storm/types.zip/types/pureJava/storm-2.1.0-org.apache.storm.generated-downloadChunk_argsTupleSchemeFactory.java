private static class downloadChunk_argsTupleSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public downloadChunk_argsTupleScheme getScheme(){
    return new downloadChunk_argsTupleScheme();
  }
}
