public class TridentBatchTuple {
  final String effectiveBatchId;
  final long timeStamp;
  final int tupleIndex;
  final TridentTuple tridentTuple;
  public TridentBatchTuple(  String effectiveBatchId,  long timeStamp,  int tupleIndex){
    this(effectiveBatchId,timeStamp,tupleIndex,null);
  }
  public TridentBatchTuple(  String effectiveBatchId,  long timeStamp,  int tupleIndex,  TridentTuple tridentTuple){
    this.effectiveBatchId=effectiveBatchId;
    this.timeStamp=timeStamp;
    this.tupleIndex=tupleIndex;
    this.tridentTuple=tridentTuple;
  }
}
