public interface AsyncIface {
  public void sendSupervisorAssignments(  SupervisorAssignments assignments,  org.apache.storm.thrift.async.AsyncMethodCallback<Void> resultHandler) throws org.apache.storm.thrift.TException ;
  public void getLocalAssignmentForStorm(  java.lang.String id,  org.apache.storm.thrift.async.AsyncMethodCallback<Assignment> resultHandler) throws org.apache.storm.thrift.TException ;
  public void sendSupervisorWorkerHeartbeat(  SupervisorWorkerHeartbeat heartbeat,  org.apache.storm.thrift.async.AsyncMethodCallback<Void> resultHandler) throws org.apache.storm.thrift.TException ;
}
