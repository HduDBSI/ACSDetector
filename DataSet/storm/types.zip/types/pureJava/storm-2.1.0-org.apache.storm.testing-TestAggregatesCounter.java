public class TestAggregatesCounter extends BaseRichBolt {
  public static Logger LOG=LoggerFactory.getLogger(TestWordCounter.class);
  Map<String,Integer> counts;
  OutputCollector collector;
  @Override public void prepare(  Map<String,Object> topoConf,  TopologyContext context,  OutputCollector collector){
    this.collector=collector;
    counts=new HashMap<String,Integer>();
  }
  @Override public void execute(  Tuple input){
    String word=(String)input.getValues().get(0);
    int count=(Integer)input.getValues().get(1);
    counts.put(word,count);
    int globalCount=0;
    for (    String w : counts.keySet()) {
      globalCount+=counts.get(w);
    }
    collector.emit(tuple(globalCount));
    collector.ack(input);
  }
  @Override public void cleanup(){
  }
  @Override public void declareOutputFields(  OutputFieldsDeclarer declarer){
    declarer.declare(new Fields("agg-global"));
  }
}
