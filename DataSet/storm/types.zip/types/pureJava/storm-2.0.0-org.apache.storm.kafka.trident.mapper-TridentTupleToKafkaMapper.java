public interface TridentTupleToKafkaMapper<K,V> extends Serializable {
  K getKeyFromTuple(  TridentTuple tuple);
  V getMessageFromTuple(  TridentTuple tuple);
}
