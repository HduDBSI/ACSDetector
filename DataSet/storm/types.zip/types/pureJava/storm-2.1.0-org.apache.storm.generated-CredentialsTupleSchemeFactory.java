private static class CredentialsTupleSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public CredentialsTupleScheme getScheme(){
    return new CredentialsTupleScheme();
  }
}
