public class TestGenericResourceAwareStrategy {
  private static final Logger LOG=LoggerFactory.getLogger(TestGenericResourceAwareStrategy.class);
  private final int currentTime=1450418597;
  private IScheduler scheduler=null;
  @After public void cleanup(){
    if (scheduler != null) {
      scheduler.cleanup();
      scheduler=null;
    }
  }
  protected Class getGenericResourceAwareStrategyClass(){
    return GenericResourceAwareStrategy.class;
  }
  private Config createGrasClusterConfig(  double compPcore,  double compOnHeap,  double compOffHeap,  Map<String,Map<String,Number>> pools,  Map<String,Double> genericResourceMap){
    Config config=TestUtilsForResourceAwareScheduler.createGrasClusterConfig(compPcore,compOnHeap,compOffHeap,pools,genericResourceMap);
    config.put(Config.TOPOLOGY_SCHEDULER_STRATEGY,getGenericResourceAwareStrategyClass().getName());
    return config;
  }
  /** 
 * test if the scheduling logic for the GenericResourceAwareStrategy is correct.
 */
  @Test public void testGenericResourceAwareStrategySharedMemory(){
    int spoutParallelism=2;
    int boltParallelism=2;
    int numBolts=3;
    double cpuPercent=10;
    double memoryOnHeap=10;
    double memoryOffHeap=10;
    double sharedOnHeap=500;
    double sharedOffHeapNode=700;
    double sharedOffHeapWorker=500;
    TopologyBuilder builder=new TopologyBuilder();
    builder.setSpout("spout",new TestSpout(),spoutParallelism).addResource("gpu.count",1.0);
    builder.setBolt("bolt-1",new TestBolt(),boltParallelism).addSharedMemory(new SharedOffHeapWithinWorker(sharedOffHeapWorker,"bolt-1 shared off heap worker")).shuffleGrouping("spout");
    builder.setBolt("bolt-2",new TestBolt(),boltParallelism).addSharedMemory(new SharedOffHeapWithinNode(sharedOffHeapNode,"bolt-2 shared node")).shuffleGrouping("bolt-1");
    builder.setBolt("bolt-3",new TestBolt(),boltParallelism).addSharedMemory(new SharedOnHeap(sharedOnHeap,"bolt-3 shared worker")).shuffleGrouping("bolt-2");
    StormTopology stormToplogy=builder.createTopology();
    INimbus iNimbus=new INimbusTest();
    Config conf=createGrasClusterConfig(cpuPercent,memoryOnHeap,memoryOffHeap,null,Collections.emptyMap());
    Map<String,Double> genericResourcesMap=new HashMap<>();
    genericResourcesMap.put("gpu.count",1.0);
    Map<String,SupervisorDetails> supMap=genSupervisors(4,4,500,2000,genericResourcesMap);
    conf.put(Config.TOPOLOGY_PRIORITY,0);
    conf.put(Config.TOPOLOGY_NAME,"testTopology");
    conf.put(Config.TOPOLOGY_WORKER_MAX_HEAP_SIZE_MB,2000);
    TopologyDetails topo=new TopologyDetails("testTopology-id",conf,stormToplogy,0,genExecsAndComps(stormToplogy),currentTime,"user");
    Topologies topologies=new Topologies(topo);
    Cluster cluster=new Cluster(iNimbus,new ResourceMetrics(new StormMetricsRegistry()),supMap,new HashMap<>(),topologies,conf);
    scheduler=new ResourceAwareScheduler();
    scheduler.prepare(conf,new StormMetricsRegistry());
    scheduler.schedule(topologies,cluster);
    for (    Entry<String,SupervisorResources> entry : cluster.getSupervisorsResourcesMap().entrySet()) {
      String supervisorId=entry.getKey();
      SupervisorResources resources=entry.getValue();
      assertTrue(supervisorId,resources.getTotalCpu() >= resources.getUsedCpu());
      assertTrue(supervisorId,resources.getTotalMem() >= resources.getUsedMem());
    }
    int totalNumberOfTasks=(spoutParallelism + (boltParallelism * numBolts));
    double totalExpectedCPU=totalNumberOfTasks * cpuPercent;
    double totalExpectedOnHeap=(totalNumberOfTasks * memoryOnHeap) + sharedOnHeap;
    double totalExpectedWorkerOffHeap=(totalNumberOfTasks * memoryOffHeap) + sharedOffHeapWorker;
    SchedulerAssignment assignment=cluster.getAssignmentById(topo.getId());
    Set<WorkerSlot> slots=assignment.getSlots();
    Map<String,Double> nodeToTotalShared=assignment.getNodeIdToTotalSharedOffHeapNodeMemory();
    LOG.info("NODE TO SHARED OFF HEAP {}",nodeToTotalShared);
    Map<WorkerSlot,WorkerResources> scheduledResources=assignment.getScheduledResources();
    assertEquals(2,slots.size());
    assertEquals(2,nodeToTotalShared.size());
    assertEquals(2,scheduledResources.size());
    double totalFoundCPU=0.0;
    double totalFoundOnHeap=0.0;
    double totalFoundWorkerOffHeap=0.0;
    for (    WorkerSlot ws : slots) {
      WorkerResources resources=scheduledResources.get(ws);
      totalFoundCPU+=resources.get_cpu();
      totalFoundOnHeap+=resources.get_mem_on_heap();
      totalFoundWorkerOffHeap+=resources.get_mem_off_heap();
    }
    assertEquals(totalExpectedCPU,totalFoundCPU,0.01);
    assertEquals(totalExpectedOnHeap,totalFoundOnHeap,0.01);
    assertEquals(totalExpectedWorkerOffHeap,totalFoundWorkerOffHeap,0.01);
    assertEquals(sharedOffHeapNode,nodeToTotalShared.values().stream().mapToDouble((d) -> d).sum(),0.01);
    assertEquals(sharedOnHeap,scheduledResources.values().stream().mapToDouble(WorkerResources::get_shared_mem_on_heap).sum(),0.01);
    assertEquals(sharedOffHeapWorker,scheduledResources.values().stream().mapToDouble(WorkerResources::get_shared_mem_off_heap).sum(),0.01);
  }
  /** 
 * Test if the scheduling logic for the GenericResourceAwareStrategy is correct without setting  {@link Config#TOPOLOGY_ACKER_EXECUTORS}. Test details refer to  {@link TestDefaultResourceAwareStrategy#testDefaultResourceAwareStrategyWithoutSettingAckerExecutors(int)}
 */
  @ParameterizedTest @ValueSource(ints={-1,0,1,2}) public void testGenericResourceAwareStrategyWithoutSettingAckerExecutors(  int numOfAckersPerWorker) throws InvalidTopologyException {
    int spoutParallelism=1;
    int boltParallelism=2;
    TopologyBuilder builder=new TopologyBuilder();
    builder.setSpout("spout",new TestSpout(),spoutParallelism);
    builder.setBolt("bolt-1",new TestBolt(),boltParallelism).shuffleGrouping("spout");
    builder.setBolt("bolt-2",new TestBolt(),boltParallelism).shuffleGrouping("bolt-1").addResource("gpu.count",1.0);
    builder.setBolt("bolt-3",new TestBolt(),boltParallelism).shuffleGrouping("bolt-2").addResource("gpu.count",2.0);
    String topoName="testTopology";
    StormTopology stormToplogy=builder.createTopology();
    INimbus iNimbus=new INimbusTest();
    Config conf=createGrasClusterConfig(50,500,0,null,Collections.emptyMap());
    Map<String,Double> genericResourcesMap=new HashMap<>();
    genericResourcesMap.put("gpu.count",2.0);
    Map<String,SupervisorDetails> supMap=genSupervisors(4,4,200,2000,genericResourcesMap);
    conf.put(Config.TOPOLOGY_PRIORITY,0);
    conf.put(Config.TOPOLOGY_NAME,topoName);
    conf.put(Config.TOPOLOGY_WORKER_MAX_HEAP_SIZE_MB,2000);
    conf.put(Config.TOPOLOGY_SUBMITTER_USER,"user");
    if (numOfAckersPerWorker == -1) {
    }
 else {
      conf.put(Config.TOPOLOGY_RAS_ACKER_EXECUTORS_PER_WORKER,numOfAckersPerWorker);
    }
    int estimatedNumWorker=ServerUtils.getEstimatedWorkerCountForRasTopo(conf,stormToplogy);
    Nimbus.setUpAckerExecutorConfigs(topoName,conf,conf,estimatedNumWorker);
    conf.put(Config.TOPOLOGY_ACKER_RESOURCES_ONHEAP_MEMORY_MB,250);
    conf.put(Config.TOPOLOGY_ACKER_CPU_PCORE_PERCENT,50);
    TopologyDetails topo=new TopologyDetails("testTopology-id",conf,stormToplogy,0,genExecsAndComps(StormCommon.systemTopology(conf,stormToplogy)),currentTime,"user");
    Topologies topologies=new Topologies(topo);
    Cluster cluster=new Cluster(iNimbus,new ResourceMetrics(new StormMetricsRegistry()),supMap,new HashMap<>(),topologies,conf);
    scheduler=new ResourceAwareScheduler();
    scheduler.prepare(conf,new StormMetricsRegistry());
    scheduler.schedule(topologies,cluster);
    HashSet<HashSet<ExecutorDetails>> expectedScheduling=new HashSet<>();
    if (numOfAckersPerWorker == -1 || numOfAckersPerWorker == 1) {
      expectedScheduling.add(new HashSet<>(Arrays.asList(new ExecutorDetails(3,3))));
      expectedScheduling.add(new HashSet<>(Arrays.asList(new ExecutorDetails(6,6),new ExecutorDetails(2,2),new ExecutorDetails(5,5),new ExecutorDetails(8,8))));
      expectedScheduling.add(new HashSet<>(Arrays.asList(new ExecutorDetails(4,4),new ExecutorDetails(1,1),new ExecutorDetails(0,0),new ExecutorDetails(7,7))));
    }
 else     if (numOfAckersPerWorker == 0) {
      expectedScheduling.add(new HashSet<>(Arrays.asList(new ExecutorDetails(3,3))));
      expectedScheduling.add(new HashSet<>(Arrays.asList(new ExecutorDetails(6,6),new ExecutorDetails(2,2),new ExecutorDetails(5,5),new ExecutorDetails(1,1))));
      expectedScheduling.add(new HashSet<>(Arrays.asList(new ExecutorDetails(0,0),new ExecutorDetails(4,4))));
    }
 else     if (numOfAckersPerWorker == 2) {
      expectedScheduling.add(new HashSet<>(Arrays.asList(new ExecutorDetails(3,3))));
      expectedScheduling.add(new HashSet<>(Arrays.asList(new ExecutorDetails(7,7),new ExecutorDetails(8,8),new ExecutorDetails(6,6),new ExecutorDetails(2,2))));
      expectedScheduling.add(new HashSet<>(Arrays.asList(new ExecutorDetails(9,9),new ExecutorDetails(10,10),new ExecutorDetails(1,1),new ExecutorDetails(4,4))));
      expectedScheduling.add(new HashSet<>(Arrays.asList(new ExecutorDetails(0,0),new ExecutorDetails(5,5))));
    }
    HashSet<HashSet<ExecutorDetails>> foundScheduling=new HashSet<>();
    SchedulerAssignment assignment=cluster.getAssignmentById("testTopology-id");
    for (    Collection<ExecutorDetails> execs : assignment.getSlotToExecutors().values()) {
      foundScheduling.add(new HashSet<>(execs));
    }
    assertEquals(expectedScheduling,foundScheduling);
  }
  /** 
 * Test if the scheduling logic for the GenericResourceAwareStrategy is correct with setting  {@link Config#TOPOLOGY_ACKER_EXECUTORS}. Test details refer to  {@link TestDefaultResourceAwareStrategy#testDefaultResourceAwareStrategyWithSettingAckerExecutors(int)}
 */
  @ParameterizedTest @ValueSource(ints={-1,0,2,200}) public void testGenericResourceAwareStrategyWithSettingAckerExecutors(  int numOfAckersPerWorker) throws InvalidTopologyException {
    int spoutParallelism=1;
    int boltParallelism=2;
    TopologyBuilder builder=new TopologyBuilder();
    builder.setSpout("spout",new TestSpout(),spoutParallelism);
    builder.setBolt("bolt-1",new TestBolt(),boltParallelism).shuffleGrouping("spout");
    builder.setBolt("bolt-2",new TestBolt(),boltParallelism).shuffleGrouping("bolt-1").addResource("gpu.count",1.0);
    builder.setBolt("bolt-3",new TestBolt(),boltParallelism).shuffleGrouping("bolt-2").addResource("gpu.count",2.0);
    String topoName="testTopology";
    StormTopology stormToplogy=builder.createTopology();
    INimbus iNimbus=new INimbusTest();
    Config conf=createGrasClusterConfig(50,500,0,null,Collections.emptyMap());
    Map<String,Double> genericResourcesMap=new HashMap<>();
    genericResourcesMap.put("gpu.count",2.0);
    Map<String,SupervisorDetails> supMap=genSupervisors(4,4,200,2000,genericResourcesMap);
    conf.put(Config.TOPOLOGY_PRIORITY,0);
    conf.put(Config.TOPOLOGY_NAME,topoName);
    conf.put(Config.TOPOLOGY_WORKER_MAX_HEAP_SIZE_MB,2000);
    conf.put(Config.TOPOLOGY_SUBMITTER_USER,"user");
    conf.put(Config.TOPOLOGY_ACKER_EXECUTORS,4);
    if (numOfAckersPerWorker == -1) {
    }
 else {
      conf.put(Config.TOPOLOGY_RAS_ACKER_EXECUTORS_PER_WORKER,numOfAckersPerWorker);
    }
    int estimatedNumWorker=ServerUtils.getEstimatedWorkerCountForRasTopo(conf,stormToplogy);
    Nimbus.setUpAckerExecutorConfigs(topoName,conf,conf,estimatedNumWorker);
    conf.put(Config.TOPOLOGY_ACKER_RESOURCES_ONHEAP_MEMORY_MB,250);
    conf.put(Config.TOPOLOGY_ACKER_CPU_PCORE_PERCENT,50);
    TopologyDetails topo=new TopologyDetails("testTopology-id",conf,stormToplogy,0,genExecsAndComps(StormCommon.systemTopology(conf,stormToplogy)),currentTime,"user");
    Topologies topologies=new Topologies(topo);
    Cluster cluster=new Cluster(iNimbus,new ResourceMetrics(new StormMetricsRegistry()),supMap,new HashMap<>(),topologies,conf);
    scheduler=new ResourceAwareScheduler();
    scheduler.prepare(conf,new StormMetricsRegistry());
    scheduler.schedule(topologies,cluster);
    HashSet<HashSet<ExecutorDetails>> expectedScheduling=new HashSet<>();
    expectedScheduling.add(new HashSet<>(Arrays.asList(new ExecutorDetails(3,3))));
    expectedScheduling.add(new HashSet<>(Arrays.asList(new ExecutorDetails(7,7),new ExecutorDetails(8,8),new ExecutorDetails(6,6),new ExecutorDetails(2,2))));
    expectedScheduling.add(new HashSet<>(Arrays.asList(new ExecutorDetails(9,9),new ExecutorDetails(10,10),new ExecutorDetails(1,1),new ExecutorDetails(4,4))));
    expectedScheduling.add(new HashSet<>(Arrays.asList(new ExecutorDetails(0,0),new ExecutorDetails(5,5))));
    HashSet<HashSet<ExecutorDetails>> foundScheduling=new HashSet<>();
    SchedulerAssignment assignment=cluster.getAssignmentById("testTopology-id");
    for (    Collection<ExecutorDetails> execs : assignment.getSlotToExecutors().values()) {
      foundScheduling.add(new HashSet<>(execs));
    }
    assertEquals(expectedScheduling,foundScheduling);
  }
  private TopologyDetails createTestStormTopology(  StormTopology stormTopology,  int priority,  String name,  Config conf){
    conf.put(Config.TOPOLOGY_PRIORITY,priority);
    conf.put(Config.TOPOLOGY_NAME,name);
    return new TopologyDetails(name,conf,stormTopology,0,genExecsAndComps(stormTopology),currentTime,"user");
  }
  @Test public void testGrasRequiringEviction(){
    int spoutParallelism=3;
    double cpuPercent=10;
    double memoryOnHeap=10;
    double memoryOffHeap=10;
    TopologyBuilder builder=new TopologyBuilder();
    builder.setSpout("spout",new TestSpout(),spoutParallelism).addResource("gpu.count",1.0);
    StormTopology stormTopologyWithGpu=builder.createTopology();
    builder=new TopologyBuilder();
    builder.setSpout("spout",new TestSpout(),spoutParallelism);
    StormTopology stormTopologyNoGpu=builder.createTopology();
    Config conf=createGrasClusterConfig(cpuPercent,memoryOnHeap,memoryOffHeap,null,Collections.emptyMap());
    conf.put(DaemonConfig.RESOURCE_AWARE_SCHEDULER_MAX_TOPOLOGY_SCHEDULING_ATTEMPTS,2);
    String gpu1="hasGpu1";
    String noGpu="hasNoGpu";
    String gpu2="hasGpu2";
    TopologyDetails topo[]={createTestStormTopology(stormTopologyWithGpu,10,gpu1,conf),createTestStormTopology(stormTopologyNoGpu,10,noGpu,conf),createTestStormTopology(stormTopologyWithGpu,9,gpu2,conf)};
    Topologies topologies=new Topologies(topo[0],topo[1]);
    Map<String,Double> genericResourcesMap=new HashMap<>();
    genericResourcesMap.put("gpu.count",1.0);
    Map<String,SupervisorDetails> supMap=genSupervisors(4,4,500,2000,genericResourcesMap);
    Cluster cluster=new Cluster(new INimbusTest(),new ResourceMetrics(new StormMetricsRegistry()),supMap,new HashMap<>(),topologies,conf);
    scheduler=new ResourceAwareScheduler();
    scheduler.prepare(conf,new StormMetricsRegistry());
    scheduler.schedule(topologies,cluster);
    assertTopologiesFullyScheduled(cluster,gpu1);
    assertTopologiesFullyScheduled(cluster,noGpu);
    topologies=new Topologies(topo[0],topo[1],topo[2]);
    cluster=new Cluster(cluster,topologies);
    scheduler.schedule(topologies,cluster);
    assertTopologiesNotScheduled(cluster,gpu1);
    assertTopologiesFullyScheduled(cluster,noGpu);
    assertTopologiesFullyScheduled(cluster,gpu2);
  }
  /** 
 * test if the scheduling logic for the GenericResourceAwareStrategy (when in favor of shuffle) is correct.
 */
  @Test public void testGenericResourceAwareStrategyInFavorOfShuffle() throws InvalidTopologyException {
    int spoutParallelism=1;
    int boltParallelism=2;
    TopologyBuilder builder=new TopologyBuilder();
    builder.setSpout("spout",new TestSpout(),spoutParallelism);
    builder.setBolt("bolt-1",new TestBolt(),boltParallelism).shuffleGrouping("spout");
    builder.setBolt("bolt-2",new TestBolt(),boltParallelism).shuffleGrouping("bolt-1").addResource("gpu.count",1.0);
    builder.setBolt("bolt-3",new TestBolt(),boltParallelism).shuffleGrouping("bolt-2").addResource("gpu.count",2.0);
    StormTopology stormToplogy=builder.createTopology();
    INimbus iNimbus=new INimbusTest();
    Config conf=createGrasClusterConfig(50,250,250,null,Collections.emptyMap());
    Map<String,Double> genericResourcesMap=new HashMap<>();
    genericResourcesMap.put("gpu.count",2.0);
    Map<String,SupervisorDetails> supMap=genSupervisors(4,4,200,2000,genericResourcesMap);
    conf.put(Config.TOPOLOGY_PRIORITY,0);
    conf.put(Config.TOPOLOGY_NAME,"testTopology");
    conf.put(Config.TOPOLOGY_WORKER_MAX_HEAP_SIZE_MB,Double.MAX_VALUE);
    conf.put(Config.TOPOLOGY_SUBMITTER_USER,"user");
    conf.put(Config.TOPOLOGY_RAS_ORDER_EXECUTORS_BY_PROXIMITY_NEEDS,true);
    TopologyDetails topo=new TopologyDetails("testTopology-id",conf,stormToplogy,0,genExecsAndComps(StormCommon.systemTopology(conf,stormToplogy)),currentTime,"user");
    Topologies topologies=new Topologies(topo);
    Cluster cluster=new Cluster(iNimbus,new ResourceMetrics(new StormMetricsRegistry()),supMap,new HashMap<>(),topologies,conf);
    ResourceAwareScheduler rs=new ResourceAwareScheduler();
    rs.prepare(conf,new StormMetricsRegistry());
    rs.schedule(topologies,cluster);
    HashSet<HashSet<ExecutorDetails>> expectedScheduling=new HashSet<>();
    expectedScheduling.add(new HashSet<>(Arrays.asList(new ExecutorDetails(0,0),new ExecutorDetails(2,2),new ExecutorDetails(6,6),new ExecutorDetails(7,7))));
    expectedScheduling.add(new HashSet<>(Arrays.asList(new ExecutorDetails(4,4),new ExecutorDetails(1,1))));
    expectedScheduling.add(new HashSet<>(Arrays.asList(new ExecutorDetails(5,5))));
    expectedScheduling.add(new HashSet<>(Arrays.asList(new ExecutorDetails(3,3))));
    HashSet<HashSet<ExecutorDetails>> foundScheduling=new HashSet<>();
    SchedulerAssignment assignment=cluster.getAssignmentById("testTopology-id");
    for (    Collection<ExecutorDetails> execs : assignment.getSlotToExecutors().values()) {
      foundScheduling.add(new HashSet<>(execs));
    }
    assertEquals(expectedScheduling,foundScheduling);
  }
  @Test public void testAntiAffinityWithMultipleTopologies(){
    INimbus iNimbus=new INimbusTest();
    Map<String,SupervisorDetails> supMap=genSupervisorsWithRacks(1,40,66,0,0,4700,226200,new HashMap<>());
    HashMap<String,Double> extraResources=new HashMap<>();
    extraResources.put("my.gpu",1.0);
    supMap.putAll(genSupervisorsWithRacks(1,40,66,1,0,4700,226200,extraResources));
    Config config=new Config();
    config.putAll(createGrasClusterConfig(88,775,25,null,null));
    scheduler=new ResourceAwareScheduler();
    scheduler.prepare(config,new StormMetricsRegistry());
    TopologyDetails tdSimple=genTopology("topology-simple",config,1,5,100,300,0,0,"user",8192);
    Topologies topologies=new Topologies(tdSimple);
    Cluster cluster=new Cluster(iNimbus,new ResourceMetrics(new StormMetricsRegistry()),supMap,new HashMap<>(),topologies,config);
    scheduler.schedule(topologies,cluster);
    TopologyBuilder builder=topologyBuilder(1,5,100,300);
    builder.setBolt("gpu-bolt",new TestBolt(),40).addResource("my.gpu",1.0).shuffleGrouping("spout-0");
    TopologyDetails tdGpu=topoToTopologyDetails("topology-gpu",config,builder.createTopology(),0,0,"user",8192);
    topologies=new Topologies(tdSimple,tdGpu);
    cluster=new Cluster(cluster,topologies);
    scheduler.schedule(topologies,cluster);
    Map<String,SchedulerAssignment> assignments=new TreeMap<>(cluster.getAssignments());
    assertEquals(2,assignments.size());
    Map<String,Map<String,AtomicLong>> topoPerRackCount=new HashMap<>();
    for (    Entry<String,SchedulerAssignment> entry : assignments.entrySet()) {
      SchedulerAssignment sa=entry.getValue();
      Map<String,AtomicLong> slotsPerRack=new TreeMap<>();
      for (      WorkerSlot slot : sa.getSlots()) {
        String nodeId=slot.getNodeId();
        String rack=supervisorIdToRackName(nodeId);
        slotsPerRack.computeIfAbsent(rack,(r) -> new AtomicLong(0)).incrementAndGet();
      }
      LOG.info("{} => {}",entry.getKey(),slotsPerRack);
      topoPerRackCount.put(entry.getKey(),slotsPerRack);
    }
    Map<String,AtomicLong> simpleCount=topoPerRackCount.get("topology-simple-0");
    assertNotNull(simpleCount);
    assertEquals(1,simpleCount.size());
    assertFalse(simpleCount.containsKey("r001"));
    assertTrue(simpleCount.containsKey("r000"));
  }
}
