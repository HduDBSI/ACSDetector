/** 
 * EventLogger interface for logging the event info to a sink like log file or db for inspecting the events via UI for debugging.
 */
public interface IEventLogger {
  void prepare(  Map<String,Object> conf,  Map<String,Object> arguments,  TopologyContext context);
  /** 
 * This method would be invoked when the  {@link EventLoggerBolt} receives a tuple from the spouts or bolts that has event loggingenabled.
 * @param e the event
 */
  void log(  EventInfo e);
  void close();
  /** 
 * A wrapper for the fields that we would log.
 */
class EventInfo {
    private long ts;
    private String component;
    private int task;
    private Object messageId;
    private List<Object> values;
    public EventInfo(    long ts,    String component,    int task,    Object messageId,    List<Object> values){
      this.ts=ts;
      this.component=component;
      this.task=task;
      this.messageId=messageId;
      this.values=values;
    }
    public long getTs(){
      return ts;
    }
    public String getComponent(){
      return component;
    }
    public int getTask(){
      return task;
    }
    public Object getMessageId(){
      return messageId;
    }
    public List<Object> getValues(){
      return values;
    }
    /** 
 * Returns a default formatted string with fields separated by ",".
 * @return a default formatted string with fields separated by ","
 */
    @Override public String toString(){
      return new Date(ts).toString() + "," + component+ ","+ String.valueOf(task)+ ","+ (messageId == null ? "" : messageId.toString())+ ","+ values.toString();
    }
  }
}
