private static class debug_argsTupleSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public debug_argsTupleScheme getScheme(){
    return new debug_argsTupleScheme();
  }
}
