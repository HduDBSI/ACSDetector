private static class setLogConfig_resultStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public setLogConfig_resultStandardScheme getScheme(){
    return new setLogConfig_resultStandardScheme();
  }
}
