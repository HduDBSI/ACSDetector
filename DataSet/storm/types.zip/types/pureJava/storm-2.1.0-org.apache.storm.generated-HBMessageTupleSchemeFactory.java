private static class HBMessageTupleSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public HBMessageTupleScheme getScheme(){
    return new HBMessageTupleScheme();
  }
}
