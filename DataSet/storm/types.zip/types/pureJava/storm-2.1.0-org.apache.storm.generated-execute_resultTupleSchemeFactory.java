private static class execute_resultTupleSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public execute_resultTupleScheme getScheme(){
    return new execute_resultTupleScheme();
  }
}
