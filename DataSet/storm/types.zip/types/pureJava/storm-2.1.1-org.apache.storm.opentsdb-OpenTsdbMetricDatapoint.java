/** 
 * This class represents a metric data point in OpenTSDB's format.
 */
public class OpenTsdbMetricDatapoint implements Serializable {
  private final String metric;
  private final Map<String,String> tags;
  private final long timestamp;
  private final Number value;
  private OpenTsdbMetricDatapoint(){
    this(null,null,0L,null);
  }
  public OpenTsdbMetricDatapoint(  String metric,  Map<String,String> tags,  long timestamp,  Number value){
    this.metric=metric;
    this.tags=Collections.unmodifiableMap(tags);
    this.timestamp=timestamp;
    this.value=value;
    if (!(value instanceof Integer || value instanceof Long || value instanceof Float)) {
      throw new RuntimeException("Received tuple contains unsupported value: " + value + " field. It must be Integer/Long/Float.");
    }
  }
  /** 
 * Retrieve the metric name of this datapoint.
 * @return metric name of this datapoint
 */
  public String getMetric(){
    return metric;
  }
  /** 
 * Retrieve the map of tag/value pairs of this metric.
 * @return Map of tag/value pairs of this metric
 */
  public Map<String,String> getTags(){
    return tags;
  }
  /** 
 * Retrieve the timestamp at which this metric occured.
 * @return timestamp either in milliseconds or seconds at which this metric occurred
 */
  public long getTimestamp(){
    return timestamp;
  }
  /** 
 * Retrieve the value of this metric datapoint.
 * @return value of this metric datapoint
 */
  public Object getValue(){
    return value;
  }
  @Override public String toString(){
    return "OpenTsdbMetricDataPoint{" + "metric='" + metric + '\''+ ", tags="+ tags+ ", timestamp="+ timestamp+ ", value="+ value+ '}';
  }
  @Override public boolean equals(  Object o){
    if (this == o) {
      return true;
    }
    if (!(o instanceof OpenTsdbMetricDatapoint)) {
      return false;
    }
    OpenTsdbMetricDatapoint that=(OpenTsdbMetricDatapoint)o;
    if (timestamp != that.timestamp) {
      return false;
    }
    if (value != that.value) {
      return false;
    }
    if (!metric.equals(that.metric)) {
      return false;
    }
    return tags.equals(that.tags);
  }
  @Override public int hashCode(){
    int result=metric.hashCode();
    result=31 * result + tags.hashCode();
    result=31 * result + (int)(timestamp ^ (timestamp >>> 32));
    result=31 * result + value.hashCode();
    return result;
  }
}
