/** 
 * Validates if a number is a power of 2.
 */
public static class PowerOf2Validator extends Validator {
  @Override public void validateField(  String name,  Object o){
    if (o == null) {
      return;
    }
    final long i;
    if (o instanceof Number && (i=((Number)o).longValue()) == ((Number)o).doubleValue()) {
      if (i > 0 && (i & (i - 1)) == 0) {
        return;
      }
    }
    throw new IllegalArgumentException("Field " + name + " must be a power of 2.");
  }
}
