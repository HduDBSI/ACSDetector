/** 
 * {@code State} implementation for windowing operation. This is mainly used to get callback of commit txId of batches in which triggers areemitted.
 */
public class WindowsState implements State {
  private static final Logger LOG=LoggerFactory.getLogger(WindowsState.class);
  private Long currentTxId;
  public WindowsState(){
  }
  @Override public void beginCommit(  Long txId){
    currentTxId=txId;
    LOG.debug(" WindowsState.beginCommit:: [{}] ",txId);
  }
  @Override public void commit(  Long txId){
    LOG.debug("WindowsState.commit :: [{}]",txId);
  }
  public Long getCurrentTxId(){
    return currentTxId;
  }
}
