public class MetricsUtils {
  private static final Logger LOG=LoggerFactory.getLogger(ClientMetricsUtils.class);
  public static List<PreparableReporter> getPreparableReporters(  Map<String,Object> topoConf){
    List<String> clazzes=(List<String>)topoConf.get(DaemonConfig.STORM_DAEMON_METRICS_REPORTER_PLUGINS);
    List<PreparableReporter> reporterList=new ArrayList<>();
    if (clazzes != null) {
      for (      String clazz : clazzes) {
        reporterList.add(getPreparableReporter(clazz));
      }
    }
    if (reporterList.isEmpty()) {
      reporterList.add(new JmxPreparableReporter());
    }
    return reporterList;
  }
  private static PreparableReporter getPreparableReporter(  String clazz){
    PreparableReporter reporter=null;
    LOG.info("Using statistics reporter plugin:" + clazz);
    if (clazz != null) {
      reporter=(PreparableReporter)ReflectionUtils.newInstance(clazz);
    }
    return reporter;
  }
  public static File getCsvLogDir(  Map<String,Object> topoConf){
    String csvMetricsLogDirectory=ObjectReader.getString(topoConf.get(DaemonConfig.STORM_DAEMON_METRICS_REPORTER_CSV_LOG_DIR),null);
    if (csvMetricsLogDirectory == null) {
      csvMetricsLogDirectory=ConfigUtils.absoluteStormLocalDir(topoConf);
      csvMetricsLogDirectory=csvMetricsLogDirectory + ConfigUtils.FILE_SEPARATOR + "csvmetrics";
    }
    File csvMetricsDir=new File(csvMetricsLogDirectory);
    validateCreateOutputDir(csvMetricsDir);
    return csvMetricsDir;
  }
  private static void validateCreateOutputDir(  File dir){
    if (!dir.exists()) {
      dir.mkdirs();
    }
    if (!dir.canWrite()) {
      throw new IllegalStateException(dir.getName() + " does not have write permissions.");
    }
    if (!dir.isDirectory()) {
      throw new IllegalStateException(dir.getName() + " is not a directory.");
    }
  }
}
