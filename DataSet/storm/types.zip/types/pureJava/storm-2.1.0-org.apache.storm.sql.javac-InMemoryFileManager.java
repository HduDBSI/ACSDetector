/** 
 * Provides an in-memory representation of JavaFileManager abstraction, so we do not need to write any files to disk. <p>When files are written to, rather than putting the bytes on disk, they are appended to buffers in byteCodeForClasses.
 * @see javax.tools.JavaFileManager
 */
private class InMemoryFileManager extends ForwardingJavaFileManager<JavaFileManager> {
  InMemoryFileManager(  JavaFileManager fileManager){
    super(fileManager);
  }
  @Override public JavaFileObject getJavaFileForOutput(  Location location,  final String className,  JavaFileObject.Kind kind,  FileObject sibling) throws IOException {
    return new SimpleJavaFileObject(EMPTY_URI,kind){
      @Override public OutputStream openOutputStream() throws IOException {
        ByteArrayOutputStream outputStream=byteCodeForClasses.get(className);
        if (outputStream != null) {
          throw new IllegalStateException("Cannot write more than once");
        }
        outputStream=new ByteArrayOutputStream(256);
        byteCodeForClasses.put(className,outputStream);
        return outputStream;
      }
    }
;
  }
}
