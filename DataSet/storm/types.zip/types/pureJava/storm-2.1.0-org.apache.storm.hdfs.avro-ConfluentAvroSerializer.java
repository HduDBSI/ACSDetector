/** 
 * This class provides a mechanism to utilize the Confluent Schema Registry (https://github.com/confluentinc/schema-registry) for Storm to (de)serialize Avro generic records across a topology.  It assumes the schema registry is up and running completely independent of Storm.
 */
public class ConfluentAvroSerializer extends AbstractAvroSerializer {
  private final String url;
  private SchemaRegistryClient theClient;
  /** 
 * A constructor for use by test cases ONLY, thus the default scope.
 * @param url The complete URL reference of a confluent schema registry, e.g. "http://HOST:PORT"
 */
  ConfluentAvroSerializer(  String url){
    this.url=url;
    this.theClient=new CachedSchemaRegistryClient(this.url,10000);
  }
  /** 
 * A constructor with a signature that Storm can locate and use with kryo registration. See Storm's SerializationFactory class for details
 * @param k Unused but needs to be present for Serialization Factory to find this constructor
 * @param topoConf The global storm configuration. Must define "avro.schemaregistry.confluent" to locate theconfluent schema registry. Should in the form of "http://HOST:PORT"
 */
  public ConfluentAvroSerializer(  Kryo k,  Map<String,Object> topoConf){
    url=(String)topoConf.get("avro.schemaregistry.confluent");
    this.theClient=new CachedSchemaRegistryClient(this.url,10000);
  }
  @Override public String getFingerprint(  Schema schema){
    final String subject=schema.getName();
    final int guid;
    try {
      guid=theClient.register(subject,schema);
    }
 catch (    IOException|RestClientException e) {
      throw new RuntimeException(e);
    }
    return Integer.toString(guid);
  }
  @Override public Schema getSchema(  String fingerPrint){
    final Schema theSchema;
    try {
      theSchema=theClient.getByID(Integer.parseInt(fingerPrint));
    }
 catch (    IOException|RestClientException e) {
      throw new RuntimeException(e);
    }
    return theSchema;
  }
}
