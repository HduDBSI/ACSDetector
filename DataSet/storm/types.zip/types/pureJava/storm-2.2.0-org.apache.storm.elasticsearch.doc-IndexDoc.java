/** 
 * Elasticsearch document fragment with a single "index" field, used in bulk requests.
 */
public class IndexDoc {
  public IndexDoc(){
  }
  public IndexDoc(  Index index){
    this.index=index;
  }
  private Index index;
  public Index getIndex(){
    return index;
  }
  public void setIndex(  Index index){
    this.index=index;
  }
}
