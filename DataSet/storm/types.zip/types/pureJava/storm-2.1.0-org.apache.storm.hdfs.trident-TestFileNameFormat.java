private static class TestFileNameFormat implements FileNameFormat {
  private String currentFileName="";
  @Override public void prepare(  Map<String,Object> conf,  int partitionIndex,  int numPartitions){
  }
  @Override public String getName(  long rotation,  long timeStamp){
    currentFileName=FILE_NAME_PREFIX + Long.toString(rotation);
    return currentFileName;
  }
  @Override public String getPath(){
    return TEST_OUT_DIR;
  }
  public String getCurrentFileName(){
    return currentFileName;
  }
}
