public static class ColumnMetaData implements Serializable {
  private byte[] columnFamily;
  private byte[] qualifier;
  public ColumnMetaData(  String columnFamily,  String qualifier){
    this.columnFamily=columnFamily.getBytes();
    this.qualifier=qualifier.getBytes();
  }
  public ColumnMetaData(  byte[] columnFamily,  byte[] qualifier){
    this.columnFamily=Arrays.copyOf(columnFamily,columnFamily.length);
    this.qualifier=Arrays.copyOf(qualifier,qualifier.length);
  }
  public byte[] getColumnFamily(){
    return columnFamily;
  }
  public byte[] getQualifier(){
    return qualifier;
  }
}
