public class MessageId {
  static final MessageId unanchoredMsgId=makeId(Collections.emptyMap());
  private Map<Long,Long> anchorsToIds;
  protected MessageId(  Map<Long,Long> anchorsToIds){
    this.anchorsToIds=anchorsToIds;
  }
  public static long generateId(  Random rand){
    return rand.nextLong();
  }
  public static MessageId makeUnanchored(){
    return unanchoredMsgId;
  }
  public static MessageId makeId(  Map<Long,Long> anchorsToIds){
    return new MessageId(anchorsToIds);
  }
  public static MessageId makeRootId(  long id,  long val){
    Map<Long,Long> anchorsToIds=new HashMap<>();
    anchorsToIds.put(id,val);
    return new MessageId(anchorsToIds);
  }
  public static MessageId deserialize(  Input in) throws IOException {
    int numAnchors=in.readInt(true);
    Map<Long,Long> anchorsToIds=new HashMap<>();
    for (int i=0; i < numAnchors; i++) {
      anchorsToIds.put(in.readLong(),in.readLong());
    }
    return new MessageId(anchorsToIds);
  }
  public Map<Long,Long> getAnchorsToIds(){
    return anchorsToIds;
  }
  public Set<Long> getAnchors(){
    return anchorsToIds.keySet();
  }
  @Override public int hashCode(){
    return anchorsToIds.hashCode();
  }
  @Override public boolean equals(  Object other){
    return other instanceof MessageId && anchorsToIds.equals(((MessageId)other).anchorsToIds);
  }
  @Override public String toString(){
    return anchorsToIds.toString();
  }
  public void serialize(  Output out) throws IOException {
    out.writeInt(anchorsToIds.size(),true);
    for (    Entry<Long,Long> anchorToId : anchorsToIds.entrySet()) {
      out.writeLong(anchorToId.getKey());
      out.writeLong(anchorToId.getValue());
    }
  }
}
