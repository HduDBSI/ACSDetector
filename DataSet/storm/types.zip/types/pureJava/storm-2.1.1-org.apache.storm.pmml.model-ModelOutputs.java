/** 
 * Represents the streams and output fields declared by the  {@link PMMLPredictorBolt}.
 */
public interface ModelOutputs extends Serializable {
  /** 
 * Stream fields.
 * @return a map with the output fields declared for each stream by the {@link PMMLPredictorBolt}
 */
  Map<String,? extends Fields> streamFields();
  /** 
 * Convenience method that returns a set with all the streams declared by the  {@link PMMLPredictorBolt}. By default this this method calls  {@link #streamFields()}{@code .keySet()}.
 * @return The set with all declared streams
 */
  default Set<String> streams(){
    return streamFields().keySet();
  }
}
