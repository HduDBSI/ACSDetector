public static class deleteBlob_call extends org.apache.storm.thrift.async.TAsyncMethodCall<Void> {
  private java.lang.String key;
  public deleteBlob_call(  java.lang.String key,  org.apache.storm.thrift.async.AsyncMethodCallback<Void> resultHandler,  org.apache.storm.thrift.async.TAsyncClient client,  org.apache.storm.thrift.protocol.TProtocolFactory protocolFactory,  org.apache.storm.thrift.transport.TNonblockingTransport transport) throws org.apache.storm.thrift.TException {
    super(client,protocolFactory,transport,resultHandler,false);
    this.key=key;
  }
  public void write_args(  org.apache.storm.thrift.protocol.TProtocol prot) throws org.apache.storm.thrift.TException {
    prot.writeMessageBegin(new org.apache.storm.thrift.protocol.TMessage("deleteBlob",org.apache.storm.thrift.protocol.TMessageType.CALL,0));
    deleteBlob_args args=new deleteBlob_args();
    args.set_key(key);
    args.write(prot);
    prot.writeMessageEnd();
  }
  public Void getResult() throws AuthorizationException, KeyNotFoundException, IllegalStateException, org.apache.storm.thrift.TException {
    if (getState() != org.apache.storm.thrift.async.TAsyncMethodCall.State.RESPONSE_READ) {
      throw new java.lang.IllegalStateException("Method call not finished!");
    }
    org.apache.storm.thrift.transport.TMemoryInputTransport memoryTransport=new org.apache.storm.thrift.transport.TMemoryInputTransport(getFrameBuffer().array());
    org.apache.storm.thrift.protocol.TProtocol prot=client.getProtocolFactory().getProtocol(memoryTransport);
    return null;
  }
}
