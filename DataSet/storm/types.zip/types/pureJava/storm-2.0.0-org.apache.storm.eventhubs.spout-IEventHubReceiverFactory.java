/** 
 * An abstract factory to generate EventHubReceiver
 */
public interface IEventHubReceiverFactory extends Serializable {
  IEventHubReceiver create(  EventHubSpoutConfig config,  String partitionId);
}
