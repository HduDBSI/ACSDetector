public static class getTopologyInfo_call extends org.apache.storm.thrift.async.TAsyncMethodCall<TopologyInfo> {
  private java.lang.String id;
  public getTopologyInfo_call(  java.lang.String id,  org.apache.storm.thrift.async.AsyncMethodCallback<TopologyInfo> resultHandler,  org.apache.storm.thrift.async.TAsyncClient client,  org.apache.storm.thrift.protocol.TProtocolFactory protocolFactory,  org.apache.storm.thrift.transport.TNonblockingTransport transport) throws org.apache.storm.thrift.TException {
    super(client,protocolFactory,transport,resultHandler,false);
    this.id=id;
  }
  public void write_args(  org.apache.storm.thrift.protocol.TProtocol prot) throws org.apache.storm.thrift.TException {
    prot.writeMessageBegin(new org.apache.storm.thrift.protocol.TMessage("getTopologyInfo",org.apache.storm.thrift.protocol.TMessageType.CALL,0));
    getTopologyInfo_args args=new getTopologyInfo_args();
    args.set_id(id);
    args.write(prot);
    prot.writeMessageEnd();
  }
  public TopologyInfo getResult() throws NotAliveException, AuthorizationException, org.apache.storm.thrift.TException {
    if (getState() != org.apache.storm.thrift.async.TAsyncMethodCall.State.RESPONSE_READ) {
      throw new java.lang.IllegalStateException("Method call not finished!");
    }
    org.apache.storm.thrift.transport.TMemoryInputTransport memoryTransport=new org.apache.storm.thrift.transport.TMemoryInputTransport(getFrameBuffer().array());
    org.apache.storm.thrift.protocol.TProtocol prot=client.getProtocolFactory().getProtocol(memoryTransport);
    return (new Client(prot)).recv_getTopologyInfo();
  }
}
