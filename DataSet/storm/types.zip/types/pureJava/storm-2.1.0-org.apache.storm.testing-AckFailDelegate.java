public interface AckFailDelegate extends Serializable {
  public void ack(  Object id);
  public void fail(  Object id);
}
