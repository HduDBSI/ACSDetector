private static class LSApprovedWorkersTupleScheme extends org.apache.storm.thrift.scheme.TupleScheme<LSApprovedWorkers> {
  @Override public void write(  org.apache.storm.thrift.protocol.TProtocol prot,  LSApprovedWorkers struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
{
      oprot.writeI32(struct.approved_workers.size());
      for (      java.util.Map.Entry<java.lang.String,java.lang.Integer> _iter805 : struct.approved_workers.entrySet()) {
        oprot.writeString(_iter805.getKey());
        oprot.writeI32(_iter805.getValue());
      }
    }
  }
  @Override public void read(  org.apache.storm.thrift.protocol.TProtocol prot,  LSApprovedWorkers struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
{
      org.apache.storm.thrift.protocol.TMap _map806=new org.apache.storm.thrift.protocol.TMap(org.apache.storm.thrift.protocol.TType.STRING,org.apache.storm.thrift.protocol.TType.I32,iprot.readI32());
      struct.approved_workers=new java.util.HashMap<java.lang.String,java.lang.Integer>(2 * _map806.size);
      @org.apache.storm.thrift.annotation.Nullable java.lang.String _key807;
      int _val808;
      for (int _i809=0; _i809 < _map806.size; ++_i809) {
        _key807=iprot.readString();
        _val808=iprot.readI32();
        struct.approved_workers.put(_key807,_val808);
      }
    }
    struct.set_approved_workers_isSet(true);
  }
}
