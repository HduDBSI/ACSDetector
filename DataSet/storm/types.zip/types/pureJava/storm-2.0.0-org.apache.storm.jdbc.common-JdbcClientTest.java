public class JdbcClientTest {
  private static final String tableName="user_details";
  @Rule public ExpectedException thrown=ExpectedException.none();
  private JdbcClient client;
  @Before public void setup(){
    Map<String,Object> map=Maps.newHashMap();
    map.put("dataSourceClassName","org.hsqldb.jdbc.JDBCDataSource");
    map.put("dataSource.url","jdbc:hsqldb:mem:test");
    map.put("dataSource.user","SA");
    map.put("dataSource.password","");
    ConnectionProvider connectionProvider=new HikariCPConnectionProvider(map);
    connectionProvider.prepare();
    int queryTimeoutSecs=60;
    this.client=new JdbcClient(connectionProvider,queryTimeoutSecs);
    client.executeSql("create table user_details (id integer, user_name varchar(100), created_timestamp TIMESTAMP)");
  }
  @Test public void testInsertAndSelect(){
    List<Column> row1=createRow(1,"bob");
    List<Column> row2=createRow(2,"alice");
    List<List<Column>> rows=Lists.newArrayList(row1,row2);
    client.insert(tableName,rows);
    List<List<Column>> selectedRows=client.select("select * from user_details where id = ?",Lists.newArrayList(new Column("id",1,Types.INTEGER)));
    List<List<Column>> expectedRows=Lists.newArrayList();
    expectedRows.add(row1);
    Assert.assertEquals(expectedRows,selectedRows);
    List<Column> row3=createRow(3,"frank");
    List<List<Column>> moreRows=new ArrayList<List<Column>>();
    moreRows.add(row3);
    client.executeInsertQuery("insert into user_details values(?,?,?)",moreRows);
    selectedRows=client.select("select * from user_details where id = ?",Lists.newArrayList(new Column("id",3,Types.INTEGER)));
    expectedRows=Lists.newArrayList();
    expectedRows.add(row3);
    Assert.assertEquals(expectedRows,selectedRows);
    selectedRows=client.select("select * from user_details order by id",Lists.<Column>newArrayList());
    rows.add(row3);
    Assert.assertEquals(rows,selectedRows);
  }
  @Test public void testInsertConnectionError(){
    ConnectionProvider connectionProvider=new ThrowingConnectionProvider(null);
    this.client=new JdbcClient(connectionProvider,60);
    List<Column> row=createRow(1,"frank");
    List<List<Column>> rows=new ArrayList<List<Column>>();
    rows.add(row);
    String query="insert into user_details values(?,?,?)";
    thrown.expect(MultipleFailureException.class);
    client.executeInsertQuery(query,rows);
  }
  private List<Column> createRow(  int id,  String name){
    return Lists.newArrayList(new Column("ID",id,Types.INTEGER),new Column("USER_NAME",name,Types.VARCHAR),new Column("CREATED_TIMESTAMP",new Timestamp(System.currentTimeMillis()),Types.TIMESTAMP));
  }
  @After public void cleanup(){
    client.executeSql("drop table " + tableName);
  }
}
