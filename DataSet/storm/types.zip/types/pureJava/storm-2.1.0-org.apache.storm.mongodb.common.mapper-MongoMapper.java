/** 
 * Given a Tuple/trident keys, converts it to an MongoDB document.
 */
public interface MongoMapper extends Serializable {
  /** 
 * Converts a Tuple to a Document.
 * @param tuple the incoming tuple
 * @return the MongoDB document
 */
  Document toDocument(  ITuple tuple);
  /** 
 * Converts a keys to a Document.
 * @param keys the trident keys
 * @return the MongoDB document
 */
  Document toDocumentByKeys(  List<Object> keys);
}
