public interface QueryFunction<S extends State,T> extends EachOperation {
  List<T> batchRetrieve(  S state,  List<TridentTuple> args);
  void execute(  TridentTuple tuple,  T result,  TridentCollector collector);
}
