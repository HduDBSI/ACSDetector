/** 
 * Manages acked and committed offsets for a TopicPartition. This class is not thread safe
 */
public class OffsetManager {
  private static final Comparator<KafkaSpoutMessageId> OFFSET_COMPARATOR=new OffsetComparator();
  private static final Logger LOG=LoggerFactory.getLogger(OffsetManager.class);
  private final TopicPartition tp;
  private final NavigableSet<Long> emittedOffsets=new TreeSet<>();
  private final NavigableSet<KafkaSpoutMessageId> ackedMsgs=new TreeSet<>(OFFSET_COMPARATOR);
  private long committedOffset;
  private boolean committed;
  private long latestEmittedOffset;
  /** 
 * Creates a new OffsetManager.
 * @param tp The TopicPartition
 * @param initialFetchOffset The initial fetch offset for the given TopicPartition
 */
  public OffsetManager(  TopicPartition tp,  long initialFetchOffset){
    this.tp=tp;
    this.committedOffset=initialFetchOffset;
    LOG.debug("Instantiated {}",this.toString());
  }
  public void addToAckMsgs(  KafkaSpoutMessageId msgId){
    ackedMsgs.add(msgId);
  }
  public void addToEmitMsgs(  long offset){
    this.emittedOffsets.add(offset);
    this.latestEmittedOffset=Math.max(latestEmittedOffset,offset);
  }
  public int getNumUncommittedOffsets(){
    return this.emittedOffsets.size();
  }
  /** 
 * Gets the offset of the nth emitted message after the committed offset.  Example: If the committed offset is 0 and offsets 1, 2, 8, 10 have been emitted, getNthUncommittedOffsetAfterCommittedOffset(3) returns 8.
 * @param index The index of the message to get the offset for
 * @return The offset
 * @throws NoSuchElementException if the index is out of range
 */
  public long getNthUncommittedOffsetAfterCommittedOffset(  int index){
    Iterator<Long> offsetIter=emittedOffsets.iterator();
    for (int i=0; i < index - 1; i++) {
      offsetIter.next();
    }
    return offsetIter.next();
  }
  /** 
 * An offset can only be committed when all emitted records with lower offset have been acked. This guarantees that all offsets smaller than the committedOffset have been delivered, or that those offsets no longer exist in Kafka.  <p/> The returned offset points to the earliest uncommitted offset, and matches the semantics of the KafkaConsumer.commitSync API.
 * @param commitMetadata Metadata information to commit to Kafka. It is constant per KafkaSpout instance per topology
 * @return the next OffsetAndMetadata to commit, or null if no offset isready to commit.
 */
  public OffsetAndMetadata findNextCommitOffset(  final String commitMetadata){
    boolean found=false;
    long currOffset;
    long nextCommitOffset=committedOffset;
    for (    KafkaSpoutMessageId currAckedMsg : ackedMsgs) {
      currOffset=currAckedMsg.offset();
      if (currOffset == nextCommitOffset) {
        found=true;
        nextCommitOffset=currOffset + 1;
      }
 else       if (currOffset > nextCommitOffset) {
        if (emittedOffsets.contains(nextCommitOffset)) {
          LOG.debug("topic-partition [{}] has non-sequential offset [{}]." + " It will be processed in a subsequent batch.",tp,currOffset);
          break;
        }
 else {
          LOG.debug("Processed non-sequential offset." + " The earliest uncommitted offset is no longer part of the topic." + " Missing offset: [{}], Processed: [{}]",nextCommitOffset,currOffset);
          final Long nextEmittedOffset=emittedOffsets.ceiling(nextCommitOffset);
          if (nextEmittedOffset != null && currOffset == nextEmittedOffset) {
            LOG.debug("Found committable offset: [{}] after missing offset: [{}], skipping to the committable offset",currOffset,nextCommitOffset);
            found=true;
            nextCommitOffset=currOffset + 1;
          }
 else {
            LOG.debug("Topic-partition [{}] has non-sequential offset [{}]." + " Next offset to commit should be [{}]",tp,currOffset,nextCommitOffset);
            break;
          }
        }
      }
 else {
        throw new IllegalStateException("The offset [" + currOffset + "] is below the current nextCommitOffset "+ "["+ nextCommitOffset+ "] for ["+ tp+ "]."+ " This should not be possible, and likely indicates a bug in the spout's acking or emit logic.");
      }
    }
    OffsetAndMetadata nextCommitOffsetAndMetadata=null;
    if (found) {
      nextCommitOffsetAndMetadata=new OffsetAndMetadata(nextCommitOffset,commitMetadata);
      LOG.debug("Topic-partition [{}] has offsets [{}-{}] ready to be committed." + " Processing will resume at offset [{}] upon spout restart",tp,committedOffset,nextCommitOffsetAndMetadata.offset() - 1,nextCommitOffsetAndMetadata.offset());
    }
 else {
      LOG.debug("Topic-partition [{}] has no offsets ready to be committed",tp);
    }
    LOG.trace("{}",this);
    return nextCommitOffsetAndMetadata;
  }
  /** 
 * Marks an offset as committed. This method has side effects - it sets the internal state in such a way that future calls to {@link #findNextCommitOffset(String)} will return offsets greater than or equal to theoffset specified, if any.
 * @param committedOffsetAndMeta The committed offset. All lower offsets are expected to have been committed.
 * @return Number of offsets committed in this commit
 */
  public long commit(  OffsetAndMetadata committedOffsetAndMeta){
    committed=true;
    final long preCommitCommittedOffset=this.committedOffset;
    long numCommittedOffsets=0;
    this.committedOffset=committedOffsetAndMeta.offset();
    for (Iterator<KafkaSpoutMessageId> iterator=ackedMsgs.iterator(); iterator.hasNext(); ) {
      if (iterator.next().offset() < committedOffsetAndMeta.offset()) {
        iterator.remove();
        numCommittedOffsets++;
      }
 else {
        break;
      }
    }
    for (Iterator<Long> iterator=emittedOffsets.iterator(); iterator.hasNext(); ) {
      if (iterator.next() < committedOffsetAndMeta.offset()) {
        iterator.remove();
      }
 else {
        break;
      }
    }
    LOG.trace("{}",this);
    LOG.debug("Committed [{}] offsets in the range [{}-{}] for topic-partition [{}]." + " Processing will resume at [{}] upon spout restart",numCommittedOffsets,preCommitCommittedOffset,this.committedOffset - 1,tp,this.committedOffset);
    return numCommittedOffsets;
  }
  /** 
 * Checks if this OffsetManager has committed to Kafka.
 * @return true if this OffsetManager has made at least one commit to Kafka, false otherwise
 */
  public boolean hasCommitted(){
    return committed;
  }
  public boolean contains(  KafkaSpoutMessageId msgId){
    return ackedMsgs.contains(msgId);
  }
  @VisibleForTesting boolean containsEmitted(  long offset){
    return emittedOffsets.contains(offset);
  }
  public long getLatestEmittedOffset(){
    return latestEmittedOffset;
  }
  public long getCommittedOffset(){
    return committedOffset;
  }
  @Override public final String toString(){
    return "OffsetManager{" + "topic-partition=" + tp + ", committedOffset="+ committedOffset+ ", emittedOffsets="+ emittedOffsets+ ", ackedMsgs="+ ackedMsgs+ ", latestEmittedOffset="+ latestEmittedOffset+ '}';
  }
private static class OffsetComparator implements Comparator<KafkaSpoutMessageId> {
    @Override public int compare(    KafkaSpoutMessageId m1,    KafkaSpoutMessageId m2){
      return m1.offset() < m2.offset() ? -1 : m1.offset() == m2.offset() ? 0 : 1;
    }
  }
}
