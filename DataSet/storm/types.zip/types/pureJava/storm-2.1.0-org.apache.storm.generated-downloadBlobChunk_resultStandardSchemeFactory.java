private static class downloadBlobChunk_resultStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public downloadBlobChunk_resultStandardScheme getScheme(){
    return new downloadBlobChunk_resultStandardScheme();
  }
}
