/** 
 * Options of State.<br/> It's a data structure (whole things are public) and you can access and modify all fields.
 * @param < T > value's type class
 */
public class Options<T> implements Serializable {
  private static final RedisDataTypeDescription DEFAULT_REDIS_DATATYPE=new RedisDataTypeDescription(RedisDataTypeDescription.RedisDataType.STRING);
  public int localCacheSize=1000;
  public String globalKey="$REDIS-MAP-STATE-GLOBAL";
  public KeyFactory keyFactory=null;
  public Serializer<T> serializer=null;
  public RedisDataTypeDescription dataTypeDescription=DEFAULT_REDIS_DATATYPE;
  public int expireIntervalSec=0;
}
