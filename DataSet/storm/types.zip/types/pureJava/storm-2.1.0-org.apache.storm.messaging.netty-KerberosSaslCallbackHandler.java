/** 
 * CallbackHandler for SASL DIGEST-MD5 mechanism.
 */
public static class KerberosSaslCallbackHandler implements CallbackHandler {
  /** 
 * Used to authenticate the clients.
 */
  private List<String> authorizedUsers;
  public KerberosSaslCallbackHandler(  List<String> authorizedUsers){
    LOG.debug("KerberosSaslCallback: Creating KerberosSaslCallback handler.");
    this.authorizedUsers=authorizedUsers;
  }
  @Override public void handle(  Callback[] callbacks) throws IOException, UnsupportedCallbackException {
    for (    Callback callback : callbacks) {
      LOG.info("Kerberos Callback Handler got callback: {}",callback.getClass());
      if (callback instanceof AuthorizeCallback) {
        AuthorizeCallback ac=(AuthorizeCallback)callback;
        if (!ac.getAuthenticationID().equals(ac.getAuthorizationID())) {
          LOG.debug("{} != {}",ac.getAuthenticationID(),ac.getAuthorizationID());
          continue;
        }
        LOG.debug("Authorized Users: {}",authorizedUsers);
        LOG.debug("Checking authorization for: {}",ac.getAuthorizationID());
        for (        String user : authorizedUsers) {
          String requester=ac.getAuthorizationID();
          KerberosPrincipal principal=new KerberosPrincipal(requester);
          requester=new KerberosPrincipalToLocal().toLocal(principal);
          if (requester.equals(user)) {
            ac.setAuthorized(true);
            break;
          }
        }
      }
    }
  }
}
