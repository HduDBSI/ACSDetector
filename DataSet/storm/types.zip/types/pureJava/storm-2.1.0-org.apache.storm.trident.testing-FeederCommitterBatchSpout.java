public class FeederCommitterBatchSpout implements ICommitterTridentSpout<Map<Integer,List<List<Object>>>>, IFeeder {
  FeederBatchSpout spout;
  public FeederCommitterBatchSpout(  List<String> fields){
    spout=new FeederBatchSpout(fields);
  }
  public void setWaitToEmit(  boolean trueIfWait){
    spout.setWaitToEmit(trueIfWait);
  }
  @Override public Emitter getEmitter(  String txStateId,  Map<String,Object> conf,  TopologyContext context){
    return new CommitterEmitter(spout.getEmitter(txStateId,conf,context));
  }
  @Override public BatchCoordinator<Map<Integer,List<List<Object>>>> getCoordinator(  String txStateId,  Map<String,Object> conf,  TopologyContext context){
    return spout.getCoordinator(txStateId,conf,context);
  }
  @Override public Fields getOutputFields(){
    return spout.getOutputFields();
  }
  @Override public Map<String,Object> getComponentConfiguration(){
    return spout.getComponentConfiguration();
  }
  @Override public void feed(  Object tuples){
    spout.feed(tuples);
  }
static class CommitterEmitter implements ICommitterTridentSpout.Emitter {
    ITridentSpout.Emitter emitter;
    public CommitterEmitter(    ITridentSpout.Emitter e){
      emitter=e;
    }
    @Override public void commit(    TransactionAttempt attempt){
    }
    @Override public void emitBatch(    TransactionAttempt tx,    Object coordinatorMeta,    TridentCollector collector){
      emitter.emitBatch(tx,coordinatorMeta,collector);
    }
    @Override public void success(    TransactionAttempt tx){
      emitter.success(tx);
    }
    @Override public void close(){
      emitter.close();
    }
  }
}
