/** 
 * Create a Socket data source based on the URI and properties. The URI has the format of socket://[host]:[port]. Both of host and port are mandatory. <p/> Note that it connects to given host and port, and receive the message if it's used for input source, and send the message if it's used for output data source.
 */
public class SocketDataSourcesProvider implements DataSourcesProvider {
  @Override public String scheme(){
    return "socket";
  }
private static class SocketStreamsDataSource implements ISqlStreamsDataSource {
    private final String host;
    private final int port;
    private final Scheme scheme;
    private final IOutputSerializer serializer;
    SocketStreamsDataSource(    String host,    int port,    Scheme scheme,    IOutputSerializer serializer){
      this.host=host;
      this.port=port;
      this.scheme=scheme;
      this.serializer=serializer;
    }
    @Override public IRichSpout getProducer(){
      return new SocketSpout(scheme,host,port);
    }
    @Override public IRichBolt getConsumer(){
      return new SocketBolt(serializer,host,port);
    }
  }
  @Override public ISqlStreamsDataSource constructStreams(  URI uri,  String inputFormatClass,  String outputFormatClass,  Properties properties,  List<FieldInfo> fields){
    String host=uri.getHost();
    int port=uri.getPort();
    if (port == -1) {
      throw new RuntimeException("Port information is not available. URI: " + uri);
    }
    List<String> fieldNames=FieldInfoUtils.getFieldNames(fields);
    Scheme scheme=SerdeUtils.getScheme(inputFormatClass,properties,fieldNames);
    IOutputSerializer serializer=SerdeUtils.getSerializer(outputFormatClass,properties,fieldNames);
    return new SocketDataSourcesProvider.SocketStreamsDataSource(host,port,scheme,serializer);
  }
}
