public static class AsyncClient extends org.apache.storm.thrift.async.TAsyncClient implements AsyncIface {
public static class Factory implements org.apache.storm.thrift.async.TAsyncClientFactory<AsyncClient> {
    private org.apache.storm.thrift.async.TAsyncClientManager clientManager;
    private org.apache.storm.thrift.protocol.TProtocolFactory protocolFactory;
    public Factory(    org.apache.storm.thrift.async.TAsyncClientManager clientManager,    org.apache.storm.thrift.protocol.TProtocolFactory protocolFactory){
      this.clientManager=clientManager;
      this.protocolFactory=protocolFactory;
    }
    public AsyncClient getAsyncClient(    org.apache.storm.thrift.transport.TNonblockingTransport transport){
      return new AsyncClient(protocolFactory,clientManager,transport);
    }
  }
  public AsyncClient(  org.apache.storm.thrift.protocol.TProtocolFactory protocolFactory,  org.apache.storm.thrift.async.TAsyncClientManager clientManager,  org.apache.storm.thrift.transport.TNonblockingTransport transport){
    super(protocolFactory,clientManager,transport);
  }
  public void sendSupervisorAssignments(  SupervisorAssignments assignments,  org.apache.storm.thrift.async.AsyncMethodCallback<Void> resultHandler) throws org.apache.storm.thrift.TException {
    checkReady();
    sendSupervisorAssignments_call method_call=new sendSupervisorAssignments_call(assignments,resultHandler,this,___protocolFactory,___transport);
    this.___currentMethod=method_call;
    ___manager.call(method_call);
  }
public static class sendSupervisorAssignments_call extends org.apache.storm.thrift.async.TAsyncMethodCall<Void> {
    private SupervisorAssignments assignments;
    public sendSupervisorAssignments_call(    SupervisorAssignments assignments,    org.apache.storm.thrift.async.AsyncMethodCallback<Void> resultHandler,    org.apache.storm.thrift.async.TAsyncClient client,    org.apache.storm.thrift.protocol.TProtocolFactory protocolFactory,    org.apache.storm.thrift.transport.TNonblockingTransport transport) throws org.apache.storm.thrift.TException {
      super(client,protocolFactory,transport,resultHandler,false);
      this.assignments=assignments;
    }
    public void write_args(    org.apache.storm.thrift.protocol.TProtocol prot) throws org.apache.storm.thrift.TException {
      prot.writeMessageBegin(new org.apache.storm.thrift.protocol.TMessage("sendSupervisorAssignments",org.apache.storm.thrift.protocol.TMessageType.CALL,0));
      sendSupervisorAssignments_args args=new sendSupervisorAssignments_args();
      args.set_assignments(assignments);
      args.write(prot);
      prot.writeMessageEnd();
    }
    public Void getResult() throws AuthorizationException, org.apache.storm.thrift.TException {
      if (getState() != org.apache.storm.thrift.async.TAsyncMethodCall.State.RESPONSE_READ) {
        throw new java.lang.IllegalStateException("Method call not finished!");
      }
      org.apache.storm.thrift.transport.TMemoryInputTransport memoryTransport=new org.apache.storm.thrift.transport.TMemoryInputTransport(getFrameBuffer().array());
      org.apache.storm.thrift.protocol.TProtocol prot=client.getProtocolFactory().getProtocol(memoryTransport);
      return null;
    }
  }
  public void getLocalAssignmentForStorm(  java.lang.String id,  org.apache.storm.thrift.async.AsyncMethodCallback<Assignment> resultHandler) throws org.apache.storm.thrift.TException {
    checkReady();
    getLocalAssignmentForStorm_call method_call=new getLocalAssignmentForStorm_call(id,resultHandler,this,___protocolFactory,___transport);
    this.___currentMethod=method_call;
    ___manager.call(method_call);
  }
public static class getLocalAssignmentForStorm_call extends org.apache.storm.thrift.async.TAsyncMethodCall<Assignment> {
    private java.lang.String id;
    public getLocalAssignmentForStorm_call(    java.lang.String id,    org.apache.storm.thrift.async.AsyncMethodCallback<Assignment> resultHandler,    org.apache.storm.thrift.async.TAsyncClient client,    org.apache.storm.thrift.protocol.TProtocolFactory protocolFactory,    org.apache.storm.thrift.transport.TNonblockingTransport transport) throws org.apache.storm.thrift.TException {
      super(client,protocolFactory,transport,resultHandler,false);
      this.id=id;
    }
    public void write_args(    org.apache.storm.thrift.protocol.TProtocol prot) throws org.apache.storm.thrift.TException {
      prot.writeMessageBegin(new org.apache.storm.thrift.protocol.TMessage("getLocalAssignmentForStorm",org.apache.storm.thrift.protocol.TMessageType.CALL,0));
      getLocalAssignmentForStorm_args args=new getLocalAssignmentForStorm_args();
      args.set_id(id);
      args.write(prot);
      prot.writeMessageEnd();
    }
    public Assignment getResult() throws NotAliveException, AuthorizationException, org.apache.storm.thrift.TException {
      if (getState() != org.apache.storm.thrift.async.TAsyncMethodCall.State.RESPONSE_READ) {
        throw new java.lang.IllegalStateException("Method call not finished!");
      }
      org.apache.storm.thrift.transport.TMemoryInputTransport memoryTransport=new org.apache.storm.thrift.transport.TMemoryInputTransport(getFrameBuffer().array());
      org.apache.storm.thrift.protocol.TProtocol prot=client.getProtocolFactory().getProtocol(memoryTransport);
      return (new Client(prot)).recv_getLocalAssignmentForStorm();
    }
  }
  public void sendSupervisorWorkerHeartbeat(  SupervisorWorkerHeartbeat heartbeat,  org.apache.storm.thrift.async.AsyncMethodCallback<Void> resultHandler) throws org.apache.storm.thrift.TException {
    checkReady();
    sendSupervisorWorkerHeartbeat_call method_call=new sendSupervisorWorkerHeartbeat_call(heartbeat,resultHandler,this,___protocolFactory,___transport);
    this.___currentMethod=method_call;
    ___manager.call(method_call);
  }
public static class sendSupervisorWorkerHeartbeat_call extends org.apache.storm.thrift.async.TAsyncMethodCall<Void> {
    private SupervisorWorkerHeartbeat heartbeat;
    public sendSupervisorWorkerHeartbeat_call(    SupervisorWorkerHeartbeat heartbeat,    org.apache.storm.thrift.async.AsyncMethodCallback<Void> resultHandler,    org.apache.storm.thrift.async.TAsyncClient client,    org.apache.storm.thrift.protocol.TProtocolFactory protocolFactory,    org.apache.storm.thrift.transport.TNonblockingTransport transport) throws org.apache.storm.thrift.TException {
      super(client,protocolFactory,transport,resultHandler,false);
      this.heartbeat=heartbeat;
    }
    public void write_args(    org.apache.storm.thrift.protocol.TProtocol prot) throws org.apache.storm.thrift.TException {
      prot.writeMessageBegin(new org.apache.storm.thrift.protocol.TMessage("sendSupervisorWorkerHeartbeat",org.apache.storm.thrift.protocol.TMessageType.CALL,0));
      sendSupervisorWorkerHeartbeat_args args=new sendSupervisorWorkerHeartbeat_args();
      args.set_heartbeat(heartbeat);
      args.write(prot);
      prot.writeMessageEnd();
    }
    public Void getResult() throws AuthorizationException, org.apache.storm.thrift.TException {
      if (getState() != org.apache.storm.thrift.async.TAsyncMethodCall.State.RESPONSE_READ) {
        throw new java.lang.IllegalStateException("Method call not finished!");
      }
      org.apache.storm.thrift.transport.TMemoryInputTransport memoryTransport=new org.apache.storm.thrift.transport.TMemoryInputTransport(getFrameBuffer().array());
      org.apache.storm.thrift.protocol.TProtocol prot=client.getProtocolFactory().getProtocol(memoryTransport);
      return null;
    }
  }
}
