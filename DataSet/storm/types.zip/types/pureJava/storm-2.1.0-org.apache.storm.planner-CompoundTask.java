public class CompoundTask {
}
