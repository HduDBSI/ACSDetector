public interface PreparedStatementBinder extends Serializable {
  public BoundStatement apply(  PreparedStatement statement,  List<Column> columns);
public static final class DefaultBinder implements PreparedStatementBinder {
    /** 
 * {@inheritDoc}
 */
    @Override public BoundStatement apply(    PreparedStatement statement,    List<Column> columns){
      Object[] values=Column.getVals(columns);
      return statement.bind(values);
    }
  }
@SuppressWarnings("checkstyle:AbbreviationAsWordInName") public static final class CQL3NamedSettersBinder implements PreparedStatementBinder {
    /** 
 * {@inheritDoc}
 */
    @Override public BoundStatement apply(    PreparedStatement statement,    List<Column> columns){
      Object[] values=Column.getVals(columns);
      BoundStatement boundStatement=statement.bind();
      for (      Column col : columns) {
        if (col.isNull()) {
          boundStatement.setToNull(col.getColumnName());
        }
 else {
          boundStatement.set(col.getColumnName(),col.getVal(),CodecRegistry.DEFAULT_INSTANCE.codecFor(col.getVal()));
        }
      }
      return statement.bind(values);
    }
  }
}
