/** 
 * The param arg for `Testing.withSimulatedTimeCluster`, `Testing.withTrackedCluster` and `Testing.withLocalCluster`
 */
public class MkClusterParam {
  /** 
 * count of supervisors for the cluster.
 */
  private Integer supervisors;
  /** 
 * count of port for each supervisor
 */
  private Integer portsPerSupervisor;
  /** 
 * cluster config
 */
  private Map<String,Object> daemonConf;
  private Boolean nimbusDaemon;
  public Integer getSupervisors(){
    return supervisors;
  }
  public void setSupervisors(  Integer supervisors){
    this.supervisors=supervisors;
  }
  public Integer getPortsPerSupervisor(){
    return portsPerSupervisor;
  }
  public void setPortsPerSupervisor(  Integer portsPerSupervisor){
    this.portsPerSupervisor=portsPerSupervisor;
  }
  public Boolean isNimbusDaemon(){
    return nimbusDaemon;
  }
  public Map<String,Object> getDaemonConf(){
    return daemonConf;
  }
  public void setDaemonConf(  Map<String,Object> daemonConf){
    this.daemonConf=daemonConf;
  }
  /** 
 * When nimbusDaemon is true, the local cluster will be started with a Nimbus Thrift server, allowing communication through for example org.apache.storm.utils.NimbusClient
 */
  public void setNimbusDaemon(  Boolean nimbusDaemon){
    this.nimbusDaemon=nimbusDaemon;
  }
}
