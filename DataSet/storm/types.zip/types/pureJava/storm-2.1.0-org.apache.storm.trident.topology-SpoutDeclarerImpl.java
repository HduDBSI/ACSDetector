private static class SpoutDeclarerImpl extends BaseConfigurationDeclarer<SpoutDeclarer> implements SpoutDeclarer {
  SpoutComponent component;
  public SpoutDeclarerImpl(  SpoutComponent component){
    this.component=component;
  }
  @Override public SpoutDeclarer addConfigurations(  Map<String,Object> conf){
    if (conf != null) {
      component.componentConf.putAll(conf);
    }
    return this;
  }
  /** 
 * return the current component configuration.
 * @return the current configuration.
 */
  @Override public Map<String,Object> getComponentConfiguration(){
    return component.componentConf;
  }
  @Override public SpoutDeclarer addSharedMemory(  SharedMemory request){
    component.sharedMemory.add(request);
    return this;
  }
}
