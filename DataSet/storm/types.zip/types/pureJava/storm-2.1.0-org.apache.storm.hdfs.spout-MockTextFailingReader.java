static class MockTextFailingReader extends TextFileReader {
  public static final String[] defaultFields={"line"};
  int readAttempts=0;
  public MockTextFailingReader(  FileSystem fs,  Path file,  Map<String,Object> conf) throws IOException {
    super(fs,file,conf);
  }
  @Override public List<Object> next() throws IOException, ParseException {
    readAttempts++;
    if (readAttempts == 3 || readAttempts == 4) {
      throw new IOException("mock test exception");
    }
 else     if (readAttempts > 5) {
      throw new ParseException("mock test exception",null);
    }
    return super.next();
  }
}
