private static class TxIdState<K,V> {
  private long txid;
  private Map<K,V> state;
  TxIdState(  long txid,  Map<K,V> state){
    this.txid=txid;
    this.state=state;
  }
  @Override public String toString(){
    return "TxIdState{" + "txid=" + txid + ", state="+ state+ '}';
  }
}
