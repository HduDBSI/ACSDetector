public interface ExpiredCallback<K,V> {
  void expire(  K key,  V val);
}
