static class MessageId implements Comparable<MessageId> {
  public long msgNumber;
  public String fullPath;
  public FileOffset offset;
  public MessageId(  long msgNumber,  Path fullPath,  FileOffset offset){
    this.msgNumber=msgNumber;
    this.fullPath=fullPath.toString();
    this.offset=offset;
  }
  @Override public String toString(){
    return "{'" + fullPath + "':"+ offset+ "}";
  }
  @Override public int compareTo(  MessageId rhs){
    if (msgNumber < rhs.msgNumber) {
      return -1;
    }
    if (msgNumber > rhs.msgNumber) {
      return 1;
    }
    return 0;
  }
}
