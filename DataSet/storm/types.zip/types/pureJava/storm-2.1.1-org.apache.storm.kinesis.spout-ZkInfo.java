public class ZkInfo implements Serializable {
  private final String zkUrl;
  private final String zkNode;
  private final Integer sessionTimeoutMs;
  private final Integer connectionTimeoutMs;
  private final Long commitIntervalMs;
  private final Integer retryAttempts;
  private final Integer retryIntervalMs;
  public ZkInfo(  String zkUrl,  String zkNode,  Integer sessionTimeoutMs,  Integer connectionTimeoutMs,  Long commitIntervalMs,  Integer retryAttempts,  Integer retryIntervalMs){
    this.zkUrl=zkUrl;
    this.zkNode=zkNode;
    this.sessionTimeoutMs=sessionTimeoutMs;
    this.connectionTimeoutMs=connectionTimeoutMs;
    this.commitIntervalMs=commitIntervalMs;
    this.retryAttempts=retryAttempts;
    this.retryIntervalMs=retryIntervalMs;
    validate();
  }
  public String getZkUrl(){
    return zkUrl;
  }
  public String getZkNode(){
    return zkNode;
  }
  public Integer getSessionTimeoutMs(){
    return sessionTimeoutMs;
  }
  public Integer getConnectionTimeoutMs(){
    return connectionTimeoutMs;
  }
  public Long getCommitIntervalMs(){
    return commitIntervalMs;
  }
  public Integer getRetryAttempts(){
    return retryAttempts;
  }
  public Integer getRetryIntervalMs(){
    return retryIntervalMs;
  }
  private void validate(){
    if (zkUrl == null || zkUrl.length() < 1) {
      throw new IllegalArgumentException("zkUrl must be specified to connect to zookeeper");
    }
    if (zkNode == null || zkNode.length() < 1) {
      throw new IllegalArgumentException("zkNode must be specified");
    }
    checkPositive(sessionTimeoutMs,"sessionTimeoutMs");
    checkPositive(connectionTimeoutMs,"connectionTimeoutMs");
    checkPositive(commitIntervalMs,"commitIntervalMs");
    checkPositive(retryAttempts,"retryAttempts");
    checkPositive(retryIntervalMs,"retryIntervalMs");
  }
  private void checkPositive(  Integer argument,  String name){
    if (argument == null && argument <= 0) {
      throw new IllegalArgumentException(name + " must be positive");
    }
  }
  private void checkPositive(  Long argument,  String name){
    if (argument == null && argument <= 0) {
      throw new IllegalArgumentException(name + " must be positive");
    }
  }
  @Override public String toString(){
    return "ZkInfo{" + "zkUrl='" + zkUrl + '\''+ ", zkNode='"+ zkNode+ '\''+ ", sessionTimeoutMs="+ sessionTimeoutMs+ ", connectionTimeoutMs="+ connectionTimeoutMs+ ", commitIntervalMs="+ commitIntervalMs+ ", retryAttempts="+ retryAttempts+ ", retryIntervalMs="+ retryIntervalMs+ '}';
  }
}
