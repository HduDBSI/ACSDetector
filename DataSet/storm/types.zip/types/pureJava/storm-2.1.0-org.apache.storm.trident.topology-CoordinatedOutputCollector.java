private static class CoordinatedOutputCollector implements IOutputCollector {
  IOutputCollector delegate;
  TrackedBatch currBatch=null;
  public CoordinatedOutputCollector(  IOutputCollector delegate){
    this.delegate=delegate;
  }
  public void setCurrBatch(  TrackedBatch batch){
    currBatch=batch;
  }
  @Override public List<Integer> emit(  String stream,  Collection<Tuple> anchors,  List<Object> tuple){
    List<Integer> tasks=delegate.emit(stream,anchors,tuple);
    updateTaskCounts(tasks);
    return tasks;
  }
  @Override public void emitDirect(  int task,  String stream,  Collection<Tuple> anchors,  List<Object> tuple){
    updateTaskCounts(Arrays.asList(task));
    delegate.emitDirect(task,stream,anchors,tuple);
  }
  @Override public void ack(  Tuple tuple){
    throw new IllegalStateException("Method should never be called");
  }
  @Override public void fail(  Tuple tuple){
    throw new IllegalStateException("Method should never be called");
  }
  @Override public void resetTimeout(  Tuple tuple){
    throw new IllegalStateException("Method should never be called");
  }
  @Override public void flush(){
    delegate.flush();
  }
  @Override public void reportError(  Throwable error){
    delegate.reportError(error);
  }
  private void updateTaskCounts(  List<Integer> tasks){
    if (currBatch != null) {
      Map<Integer,Integer> taskEmittedTuples=currBatch.taskEmittedTuples;
      for (      Integer task : tasks) {
        int newCount=Utils.get(taskEmittedTuples,task,0) + 1;
        taskEmittedTuples.put(task,newCount);
      }
    }
  }
}
