/** 
 * Note, this assumes it's deserializing a gzip byte stream, and will err if it encounters any other serialization.
 */
public class GzipThriftSerializationDelegate implements SerializationDelegate {
  @Override public void prepare(  Map<String,Object> topoConf){
  }
  @Override public byte[] serialize(  Object object){
    try {
      return Utils.gzip(new TSerializer().serialize((TBase)object));
    }
 catch (    TException e) {
      throw new RuntimeException(e);
    }
  }
  @Override public <T>T deserialize(  byte[] bytes,  Class<T> clazz){
    try {
      TBase instance=(TBase)clazz.newInstance();
      new TDeserializer().deserialize(instance,Utils.gunzip(bytes));
      return (T)instance;
    }
 catch (    Exception e) {
      throw new RuntimeException(e);
    }
  }
}
