public static class submitTopologyWithOpts_call extends org.apache.storm.thrift.async.TAsyncMethodCall<Void> {
  private java.lang.String name;
  private java.lang.String uploadedJarLocation;
  private java.lang.String jsonConf;
  private StormTopology topology;
  private SubmitOptions options;
  public submitTopologyWithOpts_call(  java.lang.String name,  java.lang.String uploadedJarLocation,  java.lang.String jsonConf,  StormTopology topology,  SubmitOptions options,  org.apache.storm.thrift.async.AsyncMethodCallback<Void> resultHandler,  org.apache.storm.thrift.async.TAsyncClient client,  org.apache.storm.thrift.protocol.TProtocolFactory protocolFactory,  org.apache.storm.thrift.transport.TNonblockingTransport transport) throws org.apache.storm.thrift.TException {
    super(client,protocolFactory,transport,resultHandler,false);
    this.name=name;
    this.uploadedJarLocation=uploadedJarLocation;
    this.jsonConf=jsonConf;
    this.topology=topology;
    this.options=options;
  }
  public void write_args(  org.apache.storm.thrift.protocol.TProtocol prot) throws org.apache.storm.thrift.TException {
    prot.writeMessageBegin(new org.apache.storm.thrift.protocol.TMessage("submitTopologyWithOpts",org.apache.storm.thrift.protocol.TMessageType.CALL,0));
    submitTopologyWithOpts_args args=new submitTopologyWithOpts_args();
    args.set_name(name);
    args.set_uploadedJarLocation(uploadedJarLocation);
    args.set_jsonConf(jsonConf);
    args.set_topology(topology);
    args.set_options(options);
    args.write(prot);
    prot.writeMessageEnd();
  }
  public Void getResult() throws AlreadyAliveException, InvalidTopologyException, AuthorizationException, org.apache.storm.thrift.TException {
    if (getState() != org.apache.storm.thrift.async.TAsyncMethodCall.State.RESPONSE_READ) {
      throw new java.lang.IllegalStateException("Method call not finished!");
    }
    org.apache.storm.thrift.transport.TMemoryInputTransport memoryTransport=new org.apache.storm.thrift.transport.TMemoryInputTransport(getFrameBuffer().array());
    org.apache.storm.thrift.protocol.TProtocol prot=client.getProtocolFactory().getProtocol(memoryTransport);
    return null;
  }
}
