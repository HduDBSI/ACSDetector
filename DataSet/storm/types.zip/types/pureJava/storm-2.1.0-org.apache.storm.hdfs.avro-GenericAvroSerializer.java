/** 
 * A default implementation of the AvroSerializer that will just pass literal schemas back and forth.  This should only be used if no other serializer will fit a use case.
 */
public class GenericAvroSerializer extends AbstractAvroSerializer {
  @Override public String getFingerprint(  Schema schema){
    return schema.toString();
  }
  @Override public Schema getSchema(  String fingerPrint){
    return new Schema.Parser().parse(fingerPrint);
  }
}
