public class SimpleMongoUpdateMapper extends SimpleMongoMapper implements MongoUpdateMapper {
  private String[] fields;
  public SimpleMongoUpdateMapper(  String... fields){
    this.fields=fields;
  }
  @Override public Document toDocument(  ITuple tuple){
    Document document=new Document();
    for (    String field : fields) {
      document.append(field,tuple.getValueByField(field));
    }
    return new Document("$set",document);
  }
  @Override public SimpleMongoUpdateMapper withFields(  String... fields){
    this.fields=fields;
    return this;
  }
}
