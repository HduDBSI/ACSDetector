private static class ReadableBlobMetaStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public ReadableBlobMetaStandardScheme getScheme(){
    return new ReadableBlobMetaStandardScheme();
  }
}
