private static class HBPulseTupleScheme extends org.apache.storm.thrift.scheme.TupleScheme<HBPulse> {
  @Override public void write(  org.apache.storm.thrift.protocol.TProtocol prot,  HBPulse struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
    oprot.writeString(struct.id);
    java.util.BitSet optionals=new java.util.BitSet();
    if (struct.is_set_details()) {
      optionals.set(0);
    }
    oprot.writeBitSet(optionals,1);
    if (struct.is_set_details()) {
      oprot.writeBinary(struct.details);
    }
  }
  @Override public void read(  org.apache.storm.thrift.protocol.TProtocol prot,  HBPulse struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
    struct.id=iprot.readString();
    struct.set_id_isSet(true);
    java.util.BitSet incoming=iprot.readBitSet(1);
    if (incoming.get(0)) {
      struct.details=iprot.readBinary();
      struct.set_details_isSet(true);
    }
  }
}
