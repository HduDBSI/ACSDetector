/** 
 * Implementation of State for single Redis environment.
 */
public class RedisState implements State {
  private JedisPool jedisPool;
  /** 
 * Constructor
 * @param jedisPool JedisPool
 */
  public RedisState(  JedisPool jedisPool){
    this.jedisPool=jedisPool;
  }
  /** 
 * {@inheritDoc}
 */
  @Override public void beginCommit(  Long aLong){
  }
  /** 
 * {@inheritDoc}
 */
  @Override public void commit(  Long aLong){
  }
  /** 
 * Borrows Jedis instance from pool. <p/> Note that you should return borrowed instance to pool when you finish using instance.
 * @return Jedis instance
 */
  public Jedis getJedis(){
    return this.jedisPool.getResource();
  }
  /** 
 * Returns Jedis instance to pool.
 * @param jedis Jedis instance to return to pool
 */
  public void returnJedis(  Jedis jedis){
    jedis.close();
  }
  /** 
 * RedisState.Factory implements StateFactory for single Redis environment.
 * @see StateFactory
 */
public static class Factory implements StateFactory {
    public static final redis.clients.jedis.JedisPoolConfig DEFAULT_POOL_CONFIG=new redis.clients.jedis.JedisPoolConfig();
    private JedisPoolConfig jedisPoolConfig;
    /** 
 * Constructor
 * @param config configuration of JedisPool
 */
    public Factory(    JedisPoolConfig config){
      this.jedisPoolConfig=config;
    }
    /** 
 * {@inheritDoc}
 */
    @Override public State makeState(    Map<String,Object> conf,    IMetricsContext metrics,    int partitionIndex,    int numPartitions){
      JedisPool jedisPool=new JedisPool(DEFAULT_POOL_CONFIG,jedisPoolConfig.getHost(),jedisPoolConfig.getPort(),jedisPoolConfig.getTimeout(),jedisPoolConfig.getPassword(),jedisPoolConfig.getDatabase());
      return new RedisState(jedisPool);
    }
  }
}
