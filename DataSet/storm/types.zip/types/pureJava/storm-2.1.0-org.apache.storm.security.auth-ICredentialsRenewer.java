/** 
 * Provides a way to renew credentials on behalf of a user.
 */
public interface ICredentialsRenewer {
  /** 
 * Called when initializing the service.
 * @param conf the storm cluster configuration.
 */
  void prepare(  Map<String,Object> conf);
  /** 
 * Renew any credentials that need to be renewed. (Update the credentials if needed)
 * @param credentials            the credentials that may have something to renew.
 * @param topologyConf           topology configuration.
 * @param topologyOwnerPrincipal the full principal name of the owner of the topology
 */
  void renew(  Map<String,String> credentials,  Map<String,Object> topologyConf,  String topologyOwnerPrincipal);
}
