private static class FileDeletionThread extends Thread {
  private final int thdNum;
  private final FileSystem fs;
  private final Path file;
  public boolean succeeded;
  public Exception exception=null;
  public FileDeletionThread(  int thdNum,  FileSystem fs,  Path file) throws IOException {
    this.thdNum=thdNum;
    this.fs=fs;
    this.file=file;
  }
  @Override public void run(){
    Thread.currentThread().setName("FileDeletionThread-" + thdNum);
    try {
      succeeded=fs.delete(file,false);
    }
 catch (    Exception e) {
      exception=e;
    }
  }
}
