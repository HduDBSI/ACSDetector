/** 
 * CsvSerializer uses the standard RFC4180 CSV Parser One of the difference from Tsv format is that fields with embedded commas will be quoted. eg: a,"b,c",d is allowed.
 * @see <a href="https://tools.ietf.org/html/rfc4180">RFC4180</a>
 */
public class CsvSerializer implements IOutputSerializer, Serializable {
  private final List<String> fields;
  public CsvSerializer(  List<String> fields){
    this.fields=fields;
  }
  @Override public ByteBuffer write(  List<Object> data,  ByteBuffer buffer){
    try {
      StringWriter writer=new StringWriter();
      CSVPrinter printer=new CSVPrinter(writer,CSVFormat.RFC4180);
      for (      Object o : data) {
        printer.print(o);
      }
      return ByteBuffer.wrap(writer.getBuffer().toString().getBytes(StandardCharsets.UTF_8));
    }
 catch (    IOException e) {
      throw new RuntimeException(e);
    }
  }
}
