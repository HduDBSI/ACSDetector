private static class getNimbusConf_resultStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public getNimbusConf_resultStandardScheme getScheme(){
    return new getNimbusConf_resultStandardScheme();
  }
}
