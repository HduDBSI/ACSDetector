public interface KeyFilter<R> {
  R filter(  String key);
}
