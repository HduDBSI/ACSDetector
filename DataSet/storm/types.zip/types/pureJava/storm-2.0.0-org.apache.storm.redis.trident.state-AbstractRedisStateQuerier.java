/** 
 * AbstractRedisStateQuerier is base class of any RedisStateQuerier, which implements BaseQueryFunction. <p/> Derived classes should provide how to retrieve values from Redis, and AbstractRedisStateQuerier takes care of rest things.
 * @param < T > type of State
 */
public abstract class AbstractRedisStateQuerier<T extends State> extends BaseQueryFunction<T,List<Values>> {
  protected final RedisDataTypeDescription.RedisDataType dataType;
  protected final String additionalKey;
  private final RedisLookupMapper lookupMapper;
  /** 
 * Constructor
 * @param lookupMapper mapper for querying
 */
  public AbstractRedisStateQuerier(  RedisLookupMapper lookupMapper){
    this.lookupMapper=lookupMapper;
    RedisDataTypeDescription dataTypeDescription=lookupMapper.getDataTypeDescription();
    this.dataType=dataTypeDescription.getDataType();
    this.additionalKey=dataTypeDescription.getAdditionalKey();
  }
  /** 
 * {@inheritDoc}
 */
  @Override public List<List<Values>> batchRetrieve(  T state,  List<TridentTuple> inputs){
    List<List<Values>> values=Lists.newArrayList();
    List<String> keys=Lists.newArrayList();
    for (    TridentTuple input : inputs) {
      keys.add(lookupMapper.getKeyFromTuple(input));
    }
    List<String> redisVals=retrieveValuesFromRedis(state,keys);
    for (int i=0; i < redisVals.size(); i++) {
      values.add(lookupMapper.toTuple(inputs.get(i),redisVals.get(i)));
    }
    return values;
  }
  /** 
 * {@inheritDoc}
 */
  @Override public void execute(  TridentTuple tuple,  List<Values> values,  TridentCollector collector){
    for (    Values value : values) {
      collector.emit(value);
    }
  }
  /** 
 * Retrieves values from Redis that each value is corresponding to each key.
 * @param state State for handling query
 * @param keys keys having state values
 * @return values which are corresponding to keys
 */
  protected abstract List<String> retrieveValuesFromRedis(  T state,  List<String> keys);
}
