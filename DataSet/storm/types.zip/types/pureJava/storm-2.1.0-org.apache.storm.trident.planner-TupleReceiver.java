public interface TupleReceiver {
  void execute(  ProcessorContext processorContext,  String streamId,  TridentTuple tuple);
  void flush();
}
