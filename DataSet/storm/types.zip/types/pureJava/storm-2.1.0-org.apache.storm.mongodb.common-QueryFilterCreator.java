/** 
 * Create a MongoDB query Filter by given Tuple/trident keys.
 */
public interface QueryFilterCreator extends Serializable {
  /** 
 * Create a query Filter by given Tuple.
 * @param tuple ITuple tuple
 * @return query Filter
 */
  Bson createFilter(  ITuple tuple);
  /** 
 * Create a query Filter by given trident keys.
 * @param keys keys
 * @return query Filter
 */
  Bson createFilterByKeys(  List<Object> keys);
}
