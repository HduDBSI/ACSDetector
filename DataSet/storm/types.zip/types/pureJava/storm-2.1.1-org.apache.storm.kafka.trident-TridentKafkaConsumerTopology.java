public class TridentKafkaConsumerTopology {
  protected static final Logger LOG=LoggerFactory.getLogger(TridentKafkaConsumerTopology.class);
  /** 
 * Creates a new topology that prints inputs to stdout.
 * @param tridentSpout The spout to use
 */
  public static StormTopology newTopology(  ITridentDataSource tridentSpout){
    final TridentTopology tridentTopology=new TridentTopology();
    final Stream spoutStream=tridentTopology.newStream("spout",tridentSpout).parallelismHint(2);
    spoutStream.each(spoutStream.getOutputFields(),new Debug(false));
    return tridentTopology.build();
  }
}
