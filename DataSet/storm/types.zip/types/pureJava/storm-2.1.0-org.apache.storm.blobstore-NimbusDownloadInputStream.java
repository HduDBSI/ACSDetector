public class NimbusDownloadInputStream extends InputStreamWithMeta {
  private BeginDownloadResult beginBlobDownload;
  private byte[] buffer=null;
  private int offset=0;
  private int end=0;
  private boolean eof=false;
  public NimbusDownloadInputStream(  BeginDownloadResult beginBlobDownload){
    this.beginBlobDownload=beginBlobDownload;
  }
  @Override public long getVersion() throws IOException {
    return beginBlobDownload.get_version();
  }
  @Override public synchronized int read() throws IOException {
    try {
      if (isEmpty()) {
        readMore();
        if (eof) {
          return -1;
        }
      }
      int length=Math.min(1,available());
      if (length == 0) {
        return -1;
      }
      int ret=buffer[offset];
      offset+=length;
      return ret;
    }
 catch (    TException exp) {
      throw new IOException(exp);
    }
  }
  @Override public synchronized int read(  byte[] b,  int off,  int len) throws IOException {
    try {
      if (isEmpty()) {
        readMore();
        if (eof) {
          return -1;
        }
      }
      int length=Math.min(len,available());
      System.arraycopy(buffer,offset,b,off,length);
      offset+=length;
      return length;
    }
 catch (    TException exp) {
      throw new IOException(exp);
    }
  }
  @Override public synchronized int read(  byte[] b) throws IOException {
    return read(b,0,b.length);
  }
  private boolean isEmpty(){
    return buffer == null || offset >= end;
  }
  private void readMore() throws TException {
    if (!eof) {
      ByteBuffer buff;
synchronized (client) {
        buff=client.getClient().downloadBlobChunk(beginBlobDownload.get_session());
      }
      buffer=buff.array();
      offset=buff.arrayOffset() + buff.position();
      int length=buff.remaining();
      end=offset + length;
      if (length == 0) {
        eof=true;
      }
    }
  }
  @Override public synchronized int available(){
    return buffer == null ? 0 : (end - offset);
  }
  @Override public long getFileLength(){
    return beginBlobDownload.get_data_size();
  }
}
