public class KinesisSpout extends BaseRichSpout {
  private final KinesisConfig kinesisConfig;
  private transient KinesisRecordsManager kinesisRecordsManager;
  private transient SpoutOutputCollector collector;
  public KinesisSpout(  KinesisConfig kinesisConfig){
    this.kinesisConfig=kinesisConfig;
  }
  @Override public void declareOutputFields(  OutputFieldsDeclarer declarer){
    declarer.declare(kinesisConfig.getRecordToTupleMapper().getOutputFields());
  }
  @Override public Map<String,Object> getComponentConfiguration(){
    return super.getComponentConfiguration();
  }
  @Override public void open(  Map<String,Object> conf,  TopologyContext context,  SpoutOutputCollector collector){
    this.collector=collector;
    kinesisRecordsManager=new KinesisRecordsManager(kinesisConfig);
    kinesisRecordsManager.initialize(context.getThisTaskIndex(),context.getComponentTasks(context.getThisComponentId()).size());
  }
  @Override public void close(){
    kinesisRecordsManager.close();
  }
  @Override public void activate(){
    kinesisRecordsManager.activate();
  }
  @Override public void deactivate(){
    kinesisRecordsManager.deactivate();
  }
  @Override public void ack(  Object msgId){
    kinesisRecordsManager.ack((KinesisMessageId)msgId);
  }
  @Override public void fail(  Object msgId){
    kinesisRecordsManager.fail((KinesisMessageId)msgId);
  }
  @Override public void nextTuple(){
    kinesisRecordsManager.next(collector);
  }
}
