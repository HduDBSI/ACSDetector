public class TestTransactionalTridentEmitter {
  private final int batchSize=32;
  private TransactionalTridentEventHubEmitter emitter;
  private Partition partition;
  private TridentCollectorMock collectorMock;
  @Before public void setUp() throws Exception {
    EventHubSpoutConfig conf=new EventHubSpoutConfig("username","password","namespace","entityname",16,"zookeeper");
    conf.setTopologyName("TestTopo");
    IEventHubReceiverFactory recvFactory=new IEventHubReceiverFactory(){
      @Override public IEventHubReceiver create(      EventHubSpoutConfig config,      String partitionId){
        return new EventHubReceiverMock(partitionId);
      }
    }
;
    partition=new Partition(conf,"0");
    emitter=new TransactionalTridentEventHubEmitter(conf,batchSize,null,recvFactory);
    collectorMock=new TridentCollectorMock();
  }
  @After public void tearDown() throws Exception {
    emitter.close();
    emitter=null;
  }
  @Test public void testEmitInSequence(){
    Map<String,Object> meta=emitter.emitPartitionBatchNew(null,collectorMock,partition,null);
    String collected=collectorMock.getBuffer();
    assertTrue(collected.startsWith("message" + 0));
    collectorMock.clear();
    emitter.emitPartitionBatchNew(null,collectorMock,partition,meta);
    collected=collectorMock.getBuffer();
    assertTrue(collected.startsWith("message" + batchSize));
  }
  @Test public void testReEmit(){
    Map<String,Object> meta=emitter.emitPartitionBatchNew(null,collectorMock,partition,null);
    collectorMock.clear();
    Map<String,Object> meta1=emitter.emitPartitionBatchNew(null,collectorMock,partition,meta);
    String collected0=collectorMock.getBuffer();
    collectorMock.clear();
    emitter.emitPartitionBatch(null,collectorMock,partition,meta1);
    String collected1=collectorMock.getBuffer();
    assertTrue(collected0.equals(collected1));
  }
}
