public class TestWordCounter extends BaseBasicBolt {
  public static Logger LOG=LoggerFactory.getLogger(TestWordCounter.class);
  Map<String,Integer> counts;
  @Override public void prepare(  Map<String,Object> topoConf,  TopologyContext context){
    counts=new HashMap<String,Integer>();
  }
  protected String getTupleValue(  Tuple t,  int idx){
    return (String)t.getValues().get(idx);
  }
  @Override public void execute(  Tuple input,  BasicOutputCollector collector){
    String word=getTupleValue(input,0);
    int count=0;
    if (counts.containsKey(word)) {
      count=counts.get(word);
    }
    count++;
    counts.put(word,count);
    collector.emit(tuple(word,count));
  }
  @Override public void cleanup(){
  }
  @Override public void declareOutputFields(  OutputFieldsDeclarer declarer){
    declarer.declare(new Fields("word","count"));
  }
}
