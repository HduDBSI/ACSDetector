private static interface InputDeclaration {
  void declare(  InputDeclarer declarer);
  String getComponent();
  String getStream();
}
