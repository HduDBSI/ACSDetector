private static class TopologyHistoryInfoTupleScheme extends org.apache.storm.thrift.scheme.TupleScheme<TopologyHistoryInfo> {
  @Override public void write(  org.apache.storm.thrift.protocol.TProtocol prot,  TopologyHistoryInfo struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
    java.util.BitSet optionals=new java.util.BitSet();
    if (struct.is_set_topo_ids()) {
      optionals.set(0);
    }
    oprot.writeBitSet(optionals,1);
    if (struct.is_set_topo_ids()) {
{
        oprot.writeI32(struct.topo_ids.size());
        for (        java.lang.String _iter866 : struct.topo_ids) {
          oprot.writeString(_iter866);
        }
      }
    }
  }
  @Override public void read(  org.apache.storm.thrift.protocol.TProtocol prot,  TopologyHistoryInfo struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
    java.util.BitSet incoming=iprot.readBitSet(1);
    if (incoming.get(0)) {
{
        org.apache.storm.thrift.protocol.TList _list867=new org.apache.storm.thrift.protocol.TList(org.apache.storm.thrift.protocol.TType.STRING,iprot.readI32());
        struct.topo_ids=new java.util.ArrayList<java.lang.String>(_list867.size);
        @org.apache.storm.thrift.annotation.Nullable java.lang.String _elem868;
        for (int _i869=0; _i869 < _list867.size; ++_i869) {
          _elem868=iprot.readString();
          struct.topo_ids.add(_elem868);
        }
      }
      struct.set_topo_ids_isSet(true);
    }
  }
}
