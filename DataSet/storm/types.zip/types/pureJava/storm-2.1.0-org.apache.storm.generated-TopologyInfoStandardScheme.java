private static class TopologyInfoStandardScheme extends org.apache.storm.thrift.scheme.StandardScheme<TopologyInfo> {
  public void read(  org.apache.storm.thrift.protocol.TProtocol iprot,  TopologyInfo struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TField schemeField;
    iprot.readStructBegin();
    while (true) {
      schemeField=iprot.readFieldBegin();
      if (schemeField.type == org.apache.storm.thrift.protocol.TType.STOP) {
        break;
      }
switch (schemeField.id) {
case 1:
        if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
          struct.id=iprot.readString();
          struct.set_id_isSet(true);
        }
 else {
          org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
        }
      break;
case 2:
    if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
      struct.name=iprot.readString();
      struct.set_name_isSet(true);
    }
 else {
      org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
    }
  break;
case 3:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.I32) {
  struct.uptime_secs=iprot.readI32();
  struct.set_uptime_secs_isSet(true);
}
 else {
  org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 4:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.LIST) {
{
org.apache.storm.thrift.protocol.TList _list360=iprot.readListBegin();
struct.executors=new java.util.ArrayList<ExecutorSummary>(_list360.size);
@org.apache.storm.thrift.annotation.Nullable ExecutorSummary _elem361;
for (int _i362=0; _i362 < _list360.size; ++_i362) {
  _elem361=new ExecutorSummary();
  _elem361.read(iprot);
  struct.executors.add(_elem361);
}
iprot.readListEnd();
}
struct.set_executors_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 5:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
struct.status=iprot.readString();
struct.set_status_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 6:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.MAP) {
{
org.apache.storm.thrift.protocol.TMap _map363=iprot.readMapBegin();
struct.errors=new java.util.HashMap<java.lang.String,java.util.List<ErrorInfo>>(2 * _map363.size);
@org.apache.storm.thrift.annotation.Nullable java.lang.String _key364;
@org.apache.storm.thrift.annotation.Nullable java.util.List<ErrorInfo> _val365;
for (int _i366=0; _i366 < _map363.size; ++_i366) {
_key364=iprot.readString();
{
org.apache.storm.thrift.protocol.TList _list367=iprot.readListBegin();
_val365=new java.util.ArrayList<ErrorInfo>(_list367.size);
@org.apache.storm.thrift.annotation.Nullable ErrorInfo _elem368;
for (int _i369=0; _i369 < _list367.size; ++_i369) {
_elem368=new ErrorInfo();
_elem368.read(iprot);
_val365.add(_elem368);
}
iprot.readListEnd();
}
struct.errors.put(_key364,_val365);
}
iprot.readMapEnd();
}
struct.set_errors_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 7:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.MAP) {
{
org.apache.storm.thrift.protocol.TMap _map370=iprot.readMapBegin();
struct.component_debug=new java.util.HashMap<java.lang.String,DebugOptions>(2 * _map370.size);
@org.apache.storm.thrift.annotation.Nullable java.lang.String _key371;
@org.apache.storm.thrift.annotation.Nullable DebugOptions _val372;
for (int _i373=0; _i373 < _map370.size; ++_i373) {
_key371=iprot.readString();
_val372=new DebugOptions();
_val372.read(iprot);
struct.component_debug.put(_key371,_val372);
}
iprot.readMapEnd();
}
struct.set_component_debug_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 8:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
struct.storm_version=iprot.readString();
struct.set_storm_version_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 513:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
struct.sched_status=iprot.readString();
struct.set_sched_status_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 514:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
struct.owner=iprot.readString();
struct.set_owner_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 515:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.I32) {
struct.replication_count=iprot.readI32();
struct.set_replication_count_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 521:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.DOUBLE) {
struct.requested_memonheap=iprot.readDouble();
struct.set_requested_memonheap_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 522:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.DOUBLE) {
struct.requested_memoffheap=iprot.readDouble();
struct.set_requested_memoffheap_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 523:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.DOUBLE) {
struct.requested_cpu=iprot.readDouble();
struct.set_requested_cpu_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 524:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.DOUBLE) {
struct.assigned_memonheap=iprot.readDouble();
struct.set_assigned_memonheap_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 525:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.DOUBLE) {
struct.assigned_memoffheap=iprot.readDouble();
struct.set_assigned_memoffheap_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 526:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.DOUBLE) {
struct.assigned_cpu=iprot.readDouble();
struct.set_assigned_cpu_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
default :
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
iprot.readFieldEnd();
}
iprot.readStructEnd();
struct.validate();
}
public void write(org.apache.storm.thrift.protocol.TProtocol oprot,TopologyInfo struct) throws org.apache.storm.thrift.TException {
struct.validate();
oprot.writeStructBegin(STRUCT_DESC);
if (struct.id != null) {
oprot.writeFieldBegin(ID_FIELD_DESC);
oprot.writeString(struct.id);
oprot.writeFieldEnd();
}
if (struct.name != null) {
oprot.writeFieldBegin(NAME_FIELD_DESC);
oprot.writeString(struct.name);
oprot.writeFieldEnd();
}
oprot.writeFieldBegin(UPTIME_SECS_FIELD_DESC);
oprot.writeI32(struct.uptime_secs);
oprot.writeFieldEnd();
if (struct.executors != null) {
oprot.writeFieldBegin(EXECUTORS_FIELD_DESC);
{
oprot.writeListBegin(new org.apache.storm.thrift.protocol.TList(org.apache.storm.thrift.protocol.TType.STRUCT,struct.executors.size()));
for (ExecutorSummary _iter374 : struct.executors) {
_iter374.write(oprot);
}
oprot.writeListEnd();
}
oprot.writeFieldEnd();
}
if (struct.status != null) {
oprot.writeFieldBegin(STATUS_FIELD_DESC);
oprot.writeString(struct.status);
oprot.writeFieldEnd();
}
if (struct.errors != null) {
oprot.writeFieldBegin(ERRORS_FIELD_DESC);
{
oprot.writeMapBegin(new org.apache.storm.thrift.protocol.TMap(org.apache.storm.thrift.protocol.TType.STRING,org.apache.storm.thrift.protocol.TType.LIST,struct.errors.size()));
for (java.util.Map.Entry<java.lang.String,java.util.List<ErrorInfo>> _iter375 : struct.errors.entrySet()) {
oprot.writeString(_iter375.getKey());
{
oprot.writeListBegin(new org.apache.storm.thrift.protocol.TList(org.apache.storm.thrift.protocol.TType.STRUCT,_iter375.getValue().size()));
for (ErrorInfo _iter376 : _iter375.getValue()) {
_iter376.write(oprot);
}
oprot.writeListEnd();
}
}
oprot.writeMapEnd();
}
oprot.writeFieldEnd();
}
if (struct.component_debug != null) {
if (struct.is_set_component_debug()) {
oprot.writeFieldBegin(COMPONENT_DEBUG_FIELD_DESC);
{
oprot.writeMapBegin(new org.apache.storm.thrift.protocol.TMap(org.apache.storm.thrift.protocol.TType.STRING,org.apache.storm.thrift.protocol.TType.STRUCT,struct.component_debug.size()));
for (java.util.Map.Entry<java.lang.String,DebugOptions> _iter377 : struct.component_debug.entrySet()) {
oprot.writeString(_iter377.getKey());
_iter377.getValue().write(oprot);
}
oprot.writeMapEnd();
}
oprot.writeFieldEnd();
}
}
if (struct.storm_version != null) {
if (struct.is_set_storm_version()) {
oprot.writeFieldBegin(STORM_VERSION_FIELD_DESC);
oprot.writeString(struct.storm_version);
oprot.writeFieldEnd();
}
}
if (struct.sched_status != null) {
if (struct.is_set_sched_status()) {
oprot.writeFieldBegin(SCHED_STATUS_FIELD_DESC);
oprot.writeString(struct.sched_status);
oprot.writeFieldEnd();
}
}
if (struct.owner != null) {
if (struct.is_set_owner()) {
oprot.writeFieldBegin(OWNER_FIELD_DESC);
oprot.writeString(struct.owner);
oprot.writeFieldEnd();
}
}
if (struct.is_set_replication_count()) {
oprot.writeFieldBegin(REPLICATION_COUNT_FIELD_DESC);
oprot.writeI32(struct.replication_count);
oprot.writeFieldEnd();
}
if (struct.is_set_requested_memonheap()) {
oprot.writeFieldBegin(REQUESTED_MEMONHEAP_FIELD_DESC);
oprot.writeDouble(struct.requested_memonheap);
oprot.writeFieldEnd();
}
if (struct.is_set_requested_memoffheap()) {
oprot.writeFieldBegin(REQUESTED_MEMOFFHEAP_FIELD_DESC);
oprot.writeDouble(struct.requested_memoffheap);
oprot.writeFieldEnd();
}
if (struct.is_set_requested_cpu()) {
oprot.writeFieldBegin(REQUESTED_CPU_FIELD_DESC);
oprot.writeDouble(struct.requested_cpu);
oprot.writeFieldEnd();
}
if (struct.is_set_assigned_memonheap()) {
oprot.writeFieldBegin(ASSIGNED_MEMONHEAP_FIELD_DESC);
oprot.writeDouble(struct.assigned_memonheap);
oprot.writeFieldEnd();
}
if (struct.is_set_assigned_memoffheap()) {
oprot.writeFieldBegin(ASSIGNED_MEMOFFHEAP_FIELD_DESC);
oprot.writeDouble(struct.assigned_memoffheap);
oprot.writeFieldEnd();
}
if (struct.is_set_assigned_cpu()) {
oprot.writeFieldBegin(ASSIGNED_CPU_FIELD_DESC);
oprot.writeDouble(struct.assigned_cpu);
oprot.writeFieldEnd();
}
oprot.writeFieldStop();
oprot.writeStructEnd();
}
}
