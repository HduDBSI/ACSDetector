/** 
 * Validates a Integer.
 */
public static class IntegerValidator extends Validator {
  @Override public void validateField(  String name,  Object o){
    validateInteger(name,o);
  }
  public void validateInteger(  String name,  Object o){
    if (o == null) {
      return;
    }
    final long i;
    if (o instanceof Number && (i=((Number)o).longValue()) == ((Number)o).doubleValue()) {
      if (i <= Integer.MAX_VALUE && i >= Integer.MIN_VALUE) {
        return;
      }
    }
    throw new IllegalArgumentException("Field " + name + " must be an Integer within type range.");
  }
}
