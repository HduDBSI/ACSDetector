private static class killTopology_argsTupleSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public killTopology_argsTupleScheme getScheme(){
    return new killTopology_argsTupleScheme();
  }
}
