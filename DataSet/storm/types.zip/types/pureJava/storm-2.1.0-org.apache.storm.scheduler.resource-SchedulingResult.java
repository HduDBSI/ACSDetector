/** 
 * This class serves as a mechanism to return results and messages from a scheduling strategy to the Resource Aware Scheduler.
 */
public class SchedulingResult {
  private static final Logger LOG=LoggerFactory.getLogger(SchedulingResult.class);
  private final SchedulingStatus status;
  private final String message;
  private final String errorMessage;
  private SchedulingResult(  SchedulingStatus status,  String message,  String errorMessage){
    this.status=status;
    this.message=message;
    this.errorMessage=errorMessage;
  }
  public static SchedulingResult failure(  SchedulingStatus status,  String errorMessage){
    return new SchedulingResult(status,null,errorMessage);
  }
  public static SchedulingResult success(){
    return SchedulingResult.success(null);
  }
  public static SchedulingResult success(  String message){
    return new SchedulingResult(SchedulingStatus.SUCCESS,message,null);
  }
  public SchedulingStatus getStatus(){
    return this.status;
  }
  public String getMessage(){
    return this.message;
  }
  public String getErrorMessage(){
    return this.errorMessage;
  }
  public boolean isSuccess(){
    return SchedulingStatus.isStatusSuccess(this.status);
  }
  public boolean isFailure(){
    return SchedulingStatus.isStatusFailure(this.status);
  }
  @Override public String toString(){
    String ret=null;
    if (isSuccess()) {
      ret="Status: " + this.getStatus() + " message: "+ this.getMessage();
    }
 else {
      ret="Status: " + this.getStatus() + " error message: "+ this.getErrorMessage();
    }
    return ret;
  }
}
