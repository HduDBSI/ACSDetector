/** 
 * StateFactory for providing EsState.
 * @since 0.11
 */
public class EsStateFactory implements StateFactory {
  private final EsConfig esConfig;
  private final EsTupleMapper tupleMapper;
  /** 
 * EsStateFactory constructor.
 * @param esConfig Elasticsearch configuration containing node addresses and cluster name {@link EsConfig}
 * @param tupleMapper Tuple to ES document mapper {@link EsTupleMapper}
 */
  public EsStateFactory(  EsConfig esConfig,  EsTupleMapper tupleMapper){
    this.esConfig=requireNonNull(esConfig);
    this.tupleMapper=requireNonNull(tupleMapper);
  }
  @Override public State makeState(  Map<String,Object> conf,  IMetricsContext metrics,  int partitionIndex,  int numPartitions){
    EsState esState=new EsState(esConfig,tupleMapper);
    esState.prepare();
    return esState;
  }
}
