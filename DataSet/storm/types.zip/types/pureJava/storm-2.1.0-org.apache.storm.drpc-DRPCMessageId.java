@SuppressWarnings("checkstyle:AbbreviationAsWordInName") private static class DRPCMessageId {
  String id;
  int index;
  public DRPCMessageId(  String id,  int index){
    this.id=id;
    this.index=index;
  }
}
