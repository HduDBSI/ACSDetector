public interface ReducerAggregator<T> extends Serializable {
  T init();
  T reduce(  T curr,  TridentTuple tuple);
}
