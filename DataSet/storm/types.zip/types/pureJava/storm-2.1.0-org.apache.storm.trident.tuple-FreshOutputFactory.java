public static class FreshOutputFactory implements Factory {
  Map<String,ValuePointer> fieldIndex;
  ValuePointer[] index;
  public FreshOutputFactory(  Fields selfFields){
    fieldIndex=new HashMap<>();
    for (int i=0; i < selfFields.size(); i++) {
      String field=selfFields.get(i);
      fieldIndex.put(field,new ValuePointer(0,i,field));
    }
    index=ValuePointer.buildIndex(selfFields,fieldIndex);
  }
  public TridentTuple create(  List<Object> selfVals){
    return new TridentTupleView(Arrays.asList(selfVals),index,fieldIndex);
  }
  @Override public Map<String,ValuePointer> getFieldIndex(){
    return fieldIndex;
  }
  @Override public int numDelegates(){
    return 1;
  }
  @Override public List<String> getOutputFields(){
    return indexToFieldsList(index);
  }
}
