/** 
 * Output stream implementation used for reading the metadata and data information.
 */
protected class BlobStoreFileOutputStream extends AtomicOutputStream {
  private BlobStoreFile part;
  private OutputStream out;
  public BlobStoreFileOutputStream(  BlobStoreFile part) throws IOException {
    this.part=part;
    this.out=part.getOutputStream();
  }
  @Override public void close() throws IOException {
    try {
      out.close();
      part.commit();
    }
 catch (    IOException|RuntimeException e) {
      cancel();
      throw e;
    }
  }
  @Override public void cancel() throws IOException {
    try {
      out.close();
    }
  finally {
      part.cancel();
    }
  }
  @Override public void write(  int b) throws IOException {
    out.write(b);
  }
  @Override public void write(  byte[] b) throws IOException {
    out.write(b);
  }
  @Override public void write(  byte[] b,  int offset,  int len) throws IOException {
    out.write(b,offset,len);
  }
}
