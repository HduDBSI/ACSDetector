private static class deactivate_resultStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public deactivate_resultStandardScheme getScheme(){
    return new deactivate_resultStandardScheme();
  }
}
