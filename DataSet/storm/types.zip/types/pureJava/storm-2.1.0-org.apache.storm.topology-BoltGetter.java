protected class BoltGetter extends ConfigGetter<BoltDeclarer> implements BoltDeclarer {
  private String boltId;
  public BoltGetter(  String boltId){
    super(boltId);
    this.boltId=boltId;
  }
  public BoltDeclarer fieldsGrouping(  String componentId,  Fields fields){
    return fieldsGrouping(componentId,Utils.DEFAULT_STREAM_ID,fields);
  }
  public BoltDeclarer fieldsGrouping(  String componentId,  String streamId,  Fields fields){
    return grouping(componentId,streamId,Grouping.fields(fields.toList()));
  }
  public BoltDeclarer globalGrouping(  String componentId){
    return globalGrouping(componentId,Utils.DEFAULT_STREAM_ID);
  }
  public BoltDeclarer globalGrouping(  String componentId,  String streamId){
    return grouping(componentId,streamId,Grouping.fields(new ArrayList<String>()));
  }
  public BoltDeclarer shuffleGrouping(  String componentId){
    return shuffleGrouping(componentId,Utils.DEFAULT_STREAM_ID);
  }
  public BoltDeclarer shuffleGrouping(  String componentId,  String streamId){
    return grouping(componentId,streamId,Grouping.shuffle(new NullStruct()));
  }
  public BoltDeclarer localOrShuffleGrouping(  String componentId){
    return localOrShuffleGrouping(componentId,Utils.DEFAULT_STREAM_ID);
  }
  public BoltDeclarer localOrShuffleGrouping(  String componentId,  String streamId){
    return grouping(componentId,streamId,Grouping.local_or_shuffle(new NullStruct()));
  }
  public BoltDeclarer noneGrouping(  String componentId){
    return noneGrouping(componentId,Utils.DEFAULT_STREAM_ID);
  }
  public BoltDeclarer noneGrouping(  String componentId,  String streamId){
    return grouping(componentId,streamId,Grouping.none(new NullStruct()));
  }
  public BoltDeclarer allGrouping(  String componentId){
    return allGrouping(componentId,Utils.DEFAULT_STREAM_ID);
  }
  public BoltDeclarer allGrouping(  String componentId,  String streamId){
    return grouping(componentId,streamId,Grouping.all(new NullStruct()));
  }
  public BoltDeclarer directGrouping(  String componentId){
    return directGrouping(componentId,Utils.DEFAULT_STREAM_ID);
  }
  public BoltDeclarer directGrouping(  String componentId,  String streamId){
    return grouping(componentId,streamId,Grouping.direct(new NullStruct()));
  }
  private BoltDeclarer grouping(  String componentId,  String streamId,  Grouping grouping){
    commons.get(boltId).put_to_inputs(new GlobalStreamId(componentId,streamId),grouping);
    return this;
  }
  @Override public BoltDeclarer grouping(  GlobalStreamId id,  Grouping grouping){
    return grouping(id.get_componentId(),id.get_streamId(),grouping);
  }
  @Override public BoltDeclarer partialKeyGrouping(  String componentId,  Fields fields){
    return customGrouping(componentId,new PartialKeyGrouping(fields));
  }
  @Override public BoltDeclarer partialKeyGrouping(  String componentId,  String streamId,  Fields fields){
    return customGrouping(componentId,streamId,new PartialKeyGrouping(fields));
  }
  @Override public BoltDeclarer customGrouping(  String componentId,  CustomStreamGrouping grouping){
    return customGrouping(componentId,Utils.DEFAULT_STREAM_ID,grouping);
  }
  @Override public BoltDeclarer customGrouping(  String componentId,  String streamId,  CustomStreamGrouping grouping){
    return grouping(componentId,streamId,Grouping.custom_serialized(Utils.javaSerialize(grouping)));
  }
}
