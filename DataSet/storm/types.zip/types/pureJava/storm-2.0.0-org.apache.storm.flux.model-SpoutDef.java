/** 
 * Bean representation of a Storm spout.
 */
public class SpoutDef extends VertexDef {
}
