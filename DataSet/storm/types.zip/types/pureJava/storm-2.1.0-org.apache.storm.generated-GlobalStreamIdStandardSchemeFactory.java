private static class GlobalStreamIdStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public GlobalStreamIdStandardScheme getScheme(){
    return new GlobalStreamIdStandardScheme();
  }
}
