private static class LSTopoHistoryStandardScheme extends org.apache.storm.thrift.scheme.StandardScheme<LSTopoHistory> {
  public void read(  org.apache.storm.thrift.protocol.TProtocol iprot,  LSTopoHistory struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TField schemeField;
    iprot.readStructBegin();
    while (true) {
      schemeField=iprot.readFieldBegin();
      if (schemeField.type == org.apache.storm.thrift.protocol.TType.STOP) {
        break;
      }
switch (schemeField.id) {
case 1:
        if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
          struct.topology_id=iprot.readString();
          struct.set_topology_id_isSet(true);
        }
 else {
          org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
        }
      break;
case 2:
    if (schemeField.type == org.apache.storm.thrift.protocol.TType.I64) {
      struct.time_stamp=iprot.readI64();
      struct.set_time_stamp_isSet(true);
    }
 else {
      org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
    }
  break;
case 3:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.LIST) {
{
    org.apache.storm.thrift.protocol.TList _list828=iprot.readListBegin();
    struct.users=new java.util.ArrayList<java.lang.String>(_list828.size);
    @org.apache.storm.thrift.annotation.Nullable java.lang.String _elem829;
    for (int _i830=0; _i830 < _list828.size; ++_i830) {
      _elem829=iprot.readString();
      struct.users.add(_elem829);
    }
    iprot.readListEnd();
  }
  struct.set_users_isSet(true);
}
 else {
  org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 4:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.LIST) {
{
org.apache.storm.thrift.protocol.TList _list831=iprot.readListBegin();
struct.groups=new java.util.ArrayList<java.lang.String>(_list831.size);
@org.apache.storm.thrift.annotation.Nullable java.lang.String _elem832;
for (int _i833=0; _i833 < _list831.size; ++_i833) {
  _elem832=iprot.readString();
  struct.groups.add(_elem832);
}
iprot.readListEnd();
}
struct.set_groups_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
default :
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
iprot.readFieldEnd();
}
iprot.readStructEnd();
struct.validate();
}
public void write(org.apache.storm.thrift.protocol.TProtocol oprot,LSTopoHistory struct) throws org.apache.storm.thrift.TException {
struct.validate();
oprot.writeStructBegin(STRUCT_DESC);
if (struct.topology_id != null) {
oprot.writeFieldBegin(TOPOLOGY_ID_FIELD_DESC);
oprot.writeString(struct.topology_id);
oprot.writeFieldEnd();
}
oprot.writeFieldBegin(TIME_STAMP_FIELD_DESC);
oprot.writeI64(struct.time_stamp);
oprot.writeFieldEnd();
if (struct.users != null) {
oprot.writeFieldBegin(USERS_FIELD_DESC);
{
oprot.writeListBegin(new org.apache.storm.thrift.protocol.TList(org.apache.storm.thrift.protocol.TType.STRING,struct.users.size()));
for (java.lang.String _iter834 : struct.users) {
oprot.writeString(_iter834);
}
oprot.writeListEnd();
}
oprot.writeFieldEnd();
}
if (struct.groups != null) {
oprot.writeFieldBegin(GROUPS_FIELD_DESC);
{
oprot.writeListBegin(new org.apache.storm.thrift.protocol.TList(org.apache.storm.thrift.protocol.TType.STRING,struct.groups.size()));
for (java.lang.String _iter835 : struct.groups) {
oprot.writeString(_iter835);
}
oprot.writeListEnd();
}
oprot.writeFieldEnd();
}
oprot.writeFieldStop();
oprot.writeStructEnd();
}
}
