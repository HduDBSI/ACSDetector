public static class TrackingInfo {
  int reportCount=0;
  int expectedTupleCount=0;
  int receivedTuples=0;
  boolean failed=false;
  Map<Integer,Integer> taskEmittedTuples=new HashMap<>();
  boolean receivedId=false;
  boolean finished=false;
  List<Tuple> ackTuples=new ArrayList<>();
  @Override public String toString(){
    return "reportCount: " + reportCount + "\n"+ "expectedTupleCount: "+ expectedTupleCount+ "\n"+ "receivedTuples: "+ receivedTuples+ "\n"+ "failed: "+ failed+ "\n"+ taskEmittedTuples.toString();
  }
}
