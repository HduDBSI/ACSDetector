public class TransactionAttempt implements IBatchID {
  Long txid;
  int attemptId;
  public TransactionAttempt(){
  }
  public TransactionAttempt(  Long txid,  int attemptId){
    this.txid=txid;
    this.attemptId=attemptId;
  }
  public Long getTransactionId(){
    return txid;
  }
  @Override public Object getId(){
    return txid;
  }
  @Override public int getAttemptId(){
    return attemptId;
  }
  @Override public int hashCode(){
    return txid.hashCode();
  }
  @Override public boolean equals(  Object o){
    if (!(o instanceof TransactionAttempt)) {
      return false;
    }
    TransactionAttempt other=(TransactionAttempt)o;
    return txid.equals(other.txid) && attemptId == other.attemptId;
  }
  @Override public String toString(){
    return "" + txid + ":"+ attemptId;
  }
}
