public class FieldSelector implements Serializable {
  protected final String field;
  private String as;
  private boolean isNow;
  /** 
 * Creates a new  {@link FieldSelector} instance.
 * @param field the name of value
 */
  public FieldSelector(  String field){
    this.field=field;
  }
  public Column select(  ITuple t){
    return new Column<>(as != null ? as : field,isNow ? UUIDs.timeBased() : getFieldValue(t));
  }
  /** 
 * Get field value.
 * @return Compute the value of this field from given {@code tuple}
 */
  protected Object getFieldValue(  ITuple tuple){
    return tuple.getValueByField(field);
  }
  /** 
 * Sets the fields as an automatically generated TimeUUID.
 * @return this
 */
  public FieldSelector now(){
    this.isNow=true;
    return this;
  }
  /** 
 * Sets an alias for this field.
 * @param as the alias name
 * @return this
 */
  public FieldSelector as(  String as){
    this.as=as;
    return this;
  }
}
