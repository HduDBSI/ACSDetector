private static class beginFileUpload_argsStandardScheme extends org.apache.storm.thrift.scheme.StandardScheme<beginFileUpload_args> {
  public void read(  org.apache.storm.thrift.protocol.TProtocol iprot,  beginFileUpload_args struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TField schemeField;
    iprot.readStructBegin();
    while (true) {
      schemeField=iprot.readFieldBegin();
      if (schemeField.type == org.apache.storm.thrift.protocol.TType.STOP) {
        break;
      }
switch (schemeField.id) {
default :
        org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
    }
    iprot.readFieldEnd();
  }
  iprot.readStructEnd();
  struct.validate();
}
public void write(org.apache.storm.thrift.protocol.TProtocol oprot,beginFileUpload_args struct) throws org.apache.storm.thrift.TException {
  struct.validate();
  oprot.writeStructBegin(STRUCT_DESC);
  oprot.writeFieldStop();
  oprot.writeStructEnd();
}
}
