private static class KeyNotFoundExceptionTupleScheme extends org.apache.storm.thrift.scheme.TupleScheme<KeyNotFoundException> {
  @Override public void write(  org.apache.storm.thrift.protocol.TProtocol prot,  KeyNotFoundException struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
    oprot.writeString(struct.msg);
  }
  @Override public void read(  org.apache.storm.thrift.protocol.TProtocol prot,  KeyNotFoundException struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
    struct.msg=iprot.readString();
    struct.set_msg_isSet(true);
  }
}
