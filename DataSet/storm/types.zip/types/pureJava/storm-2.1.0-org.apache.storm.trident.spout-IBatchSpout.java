public interface IBatchSpout extends ITridentDataSource {
  void open(  Map<String,Object> conf,  TopologyContext context);
  void emitBatch(  long batchId,  TridentCollector collector);
  void ack(  long batchId);
  void close();
  Map<String,Object> getComponentConfiguration();
  Fields getOutputFields();
}
