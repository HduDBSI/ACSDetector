/** 
 * This class wraps key and value objects which can be passed to  {@code putAll} method.
 */
public static class Entry implements Serializable {
  public final String key;
  public final Object value;
  public Entry(  String key,  Object value){
    nonNullCheckForKey(key);
    nonNullCheckForValue(value);
    this.key=key;
    this.value=value;
  }
  public static void nonNullCheckForKey(  Object key){
    Preconditions.checkArgument(key != null,"key argument can not be null");
  }
  public static void nonNullCheckForValue(  Object value){
    Preconditions.checkArgument(value != null,"value argument can not be null");
  }
}
