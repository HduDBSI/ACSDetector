public class AssignableMetric implements IMetric {
  Object value;
  public AssignableMetric(  Object value){
    this.value=value;
  }
  public void setValue(  Object value){
    this.value=value;
  }
  @Override public Object getValueAndReset(){
    return value;
  }
}
