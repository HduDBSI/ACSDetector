private static class InvalidTopologyExceptionTupleSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public InvalidTopologyExceptionTupleScheme getScheme(){
    return new InvalidTopologyExceptionTupleScheme();
  }
}
