static class Driver implements Serializable {
  static final String FIELD_NAME="driver";
  final String name;
  final int id;
  Driver(  String name,  int id){
    this.name=name;
    this.id=id;
  }
  @Override public String toString(){
    return "Driver{" + "name='" + name + '\''+ ", id="+ id+ '}';
  }
}
