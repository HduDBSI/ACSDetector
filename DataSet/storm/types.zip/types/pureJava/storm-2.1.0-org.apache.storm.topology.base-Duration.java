/** 
 * Holds a Time duration for time based windows and sliding intervals.
 */
public static class Duration implements Serializable {
  public final int value;
  public Duration(  int value,  TimeUnit timeUnit){
    if (value < 0) {
      throw new IllegalArgumentException("Duration cannot be negative");
    }
    long longVal=timeUnit.toMillis(value);
    if (longVal > (long)Integer.MAX_VALUE) {
      throw new IllegalArgumentException("Duration is too long");
    }
    this.value=(int)longVal;
  }
  /** 
 * Returns a  {@link Duration} corresponding to the the given value in milli seconds.
 * @param milliseconds the duration in milliseconds
 * @return the Duration
 */
  public static Duration of(  int milliseconds){
    return new Duration(milliseconds,TimeUnit.MILLISECONDS);
  }
  /** 
 * Returns a  {@link Duration} corresponding to the the given value in days.
 * @param days the number of days
 * @return the Duration
 */
  public static Duration days(  int days){
    return new Duration(days,TimeUnit.DAYS);
  }
  /** 
 * Returns a  {@link Duration} corresponding to the the given value in hours.
 * @param hours the number of hours
 * @return the Duration
 */
  public static Duration hours(  int hours){
    return new Duration(hours,TimeUnit.HOURS);
  }
  /** 
 * Returns a  {@link Duration} corresponding to the the given value in minutes.
 * @param minutes the number of minutes
 * @return the Duration
 */
  public static Duration minutes(  int minutes){
    return new Duration(minutes,TimeUnit.MINUTES);
  }
  /** 
 * Returns a  {@link Duration} corresponding to the the given value in seconds.
 * @param seconds the number of seconds
 * @return the Duration
 */
  public static Duration seconds(  int seconds){
    return new Duration(seconds,TimeUnit.SECONDS);
  }
  @Override public boolean equals(  Object o){
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Duration duration=(Duration)o;
    return value == duration.value;
  }
  @Override public int hashCode(){
    return value;
  }
  @Override public String toString(){
    return "Duration{" + "value=" + value + '}';
  }
}
