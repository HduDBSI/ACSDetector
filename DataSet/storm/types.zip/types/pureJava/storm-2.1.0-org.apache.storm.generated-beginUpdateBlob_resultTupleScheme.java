private static class beginUpdateBlob_resultTupleScheme extends org.apache.storm.thrift.scheme.TupleScheme<beginUpdateBlob_result> {
  @Override public void write(  org.apache.storm.thrift.protocol.TProtocol prot,  beginUpdateBlob_result struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
    java.util.BitSet optionals=new java.util.BitSet();
    if (struct.is_set_success()) {
      optionals.set(0);
    }
    if (struct.is_set_aze()) {
      optionals.set(1);
    }
    if (struct.is_set_knf()) {
      optionals.set(2);
    }
    oprot.writeBitSet(optionals,3);
    if (struct.is_set_success()) {
      oprot.writeString(struct.success);
    }
    if (struct.is_set_aze()) {
      struct.aze.write(oprot);
    }
    if (struct.is_set_knf()) {
      struct.knf.write(oprot);
    }
  }
  @Override public void read(  org.apache.storm.thrift.protocol.TProtocol prot,  beginUpdateBlob_result struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
    java.util.BitSet incoming=iprot.readBitSet(3);
    if (incoming.get(0)) {
      struct.success=iprot.readString();
      struct.set_success_isSet(true);
    }
    if (incoming.get(1)) {
      struct.aze=new AuthorizationException();
      struct.aze.read(iprot);
      struct.set_aze_isSet(true);
    }
    if (incoming.get(2)) {
      struct.knf=new KeyNotFoundException();
      struct.knf.read(iprot);
      struct.set_knf_isSet(true);
    }
  }
}
