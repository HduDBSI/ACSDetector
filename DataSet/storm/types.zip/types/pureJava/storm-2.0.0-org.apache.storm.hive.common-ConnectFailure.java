public static class ConnectFailure extends Failure {
  public ConnectFailure(  HiveEndPoint ep,  Throwable cause){
    super("Failed connecting to EndPoint " + ep,cause);
  }
}
