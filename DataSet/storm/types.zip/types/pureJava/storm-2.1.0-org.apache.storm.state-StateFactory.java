/** 
 * A factory for creating  {@link State} instances.
 */
public class StateFactory {
  private static final Logger LOG=LoggerFactory.getLogger(StateFactory.class);
  private static final String DEFAULT_PROVIDER="org.apache.storm.state.InMemoryKeyValueStateProvider";
  /** 
 * Returns a new state instance using the  {@link Config#TOPOLOGY_STATE_PROVIDER} or a {@link InMemoryKeyValueState} if no provider isconfigured.
 * @param namespace the state namespace
 * @param topoConf  the storm conf
 * @param context   the topology context
 * @return the state instance
 */
  public static State getState(  String namespace,  Map<String,Object> topoConf,  TopologyContext context){
    State state;
    try {
      String provider=null;
      if (topoConf.containsKey(Config.TOPOLOGY_STATE_PROVIDER)) {
        provider=(String)topoConf.get(Config.TOPOLOGY_STATE_PROVIDER);
      }
 else {
        provider=DEFAULT_PROVIDER;
      }
      Class<?> klazz=Class.forName(provider);
      Object object=klazz.newInstance();
      if (object instanceof StateProvider) {
        state=((StateProvider)object).newState(namespace,topoConf,context);
      }
 else {
        String msg="Invalid state provider '" + provider + "'. Should implement org.apache.storm.state.StateProvider";
        LOG.error(msg);
        throw new RuntimeException(msg);
      }
    }
 catch (    Exception ex) {
      LOG.error("Got exception while loading the state provider",ex);
      throw new RuntimeException(ex);
    }
    return state;
  }
}
