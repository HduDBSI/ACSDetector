private static class BoltStatsTupleSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public BoltStatsTupleScheme getScheme(){
    return new BoltStatsTupleScheme();
  }
}
