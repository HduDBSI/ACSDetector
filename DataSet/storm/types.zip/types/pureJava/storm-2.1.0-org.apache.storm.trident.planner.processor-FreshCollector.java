public class FreshCollector implements TridentCollector {
  FreshOutputFactory factory;
  TridentContext triContext;
  ProcessorContext context;
  public FreshCollector(  TridentContext context){
    triContext=context;
    factory=new FreshOutputFactory(context.getSelfOutputFields());
  }
  public void setContext(  ProcessorContext pc){
    this.context=pc;
  }
  @Override public void emit(  List<Object> values){
    TridentTuple toEmit=factory.create(values);
    for (    TupleReceiver r : triContext.getReceivers()) {
      r.execute(context,triContext.getOutStreamId(),toEmit);
    }
  }
  @Override public void flush(){
    for (    TupleReceiver r : triContext.getReceivers()) {
      r.flush();
    }
  }
  @Override public void reportError(  Throwable t){
    triContext.getDelegateCollector().reportError(t);
  }
  public Factory getOutputFactory(){
    return factory;
  }
}
