/** 
 * TsvScheme uses a simple delimited format implemention by splitting string, and it supports user defined delimiter.
 */
public class TsvScheme implements Scheme {
  private final List<String> fieldNames;
  private final char delimiter;
  public TsvScheme(  List<String> fieldNames,  char delimiter){
    this.fieldNames=fieldNames;
    this.delimiter=delimiter;
  }
  @Override public List<Object> deserialize(  ByteBuffer ser){
    String data=new String(Utils.toByteArray(ser),StandardCharsets.UTF_8);
    List<String> parts=org.apache.storm.sql.runtime.utils.Utils.split(data,delimiter);
    Preconditions.checkArgument(parts.size() == fieldNames.size(),"Invalid schema");
    ArrayList<Object> list=new ArrayList<>(fieldNames.size());
    list.addAll(parts);
    return list;
  }
  @Override public Fields getOutputFields(){
    return new Fields(fieldNames);
  }
}
