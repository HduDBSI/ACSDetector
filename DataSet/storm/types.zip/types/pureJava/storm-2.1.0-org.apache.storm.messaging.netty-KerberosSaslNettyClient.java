/** 
 * Implements SASL logic for storm worker client processes.
 */
public class KerberosSaslNettyClient {
  private static final Logger LOG=LoggerFactory.getLogger(KerberosSaslNettyClient.class);
  /** 
 * Used to respond to server's counterpart, SaslServer with SASL tokens represented as byte arrays.
 */
  private SaslClient saslClient;
  private Subject subject;
  private String jaasSection;
  /** 
 * Create a KerberosSaslNettyClient for authentication with servers.
 */
  public KerberosSaslNettyClient(  Map<String,Object> topoConf,  String jaasSection,  String host){
    LOG.debug("KerberosSaslNettyClient: Creating SASL {} client to authenticate to server ",SaslUtils.KERBEROS);
    LOG.info("Creating Kerberos Client.");
    Configuration loginConf;
    try {
      loginConf=ClientAuthUtils.getConfiguration(topoConf);
    }
 catch (    Throwable t) {
      LOG.error("Failed to get loginConf: ",t);
      throw t;
    }
    LOG.debug("KerberosSaslNettyClient: authmethod {}",SaslUtils.KERBEROS);
    SaslClientCallbackHandler ch=new SaslClientCallbackHandler();
    subject=null;
    try {
      LOG.debug("Setting Configuration to login_config: {}",loginConf);
      Configuration.setConfiguration(loginConf);
      LOG.debug("Trying to login.");
      Login login=new Login(jaasSection,ch);
      subject=login.getSubject();
      LOG.debug("Got Subject: {}",subject.toString());
    }
 catch (    LoginException ex) {
      LOG.error("Client failed to login in principal:" + ex,ex);
      throw new RuntimeException(ex);
    }
    if (subject.getPrivateCredentials(KerberosTicket.class).isEmpty()) {
      LOG.error("Failed to verify user principal.");
      throw new RuntimeException("Fail to verify user principal with section \"" + jaasSection + "\" in login configuration file "+ loginConf);
    }
    String serviceName=null;
    try {
      serviceName=ClientAuthUtils.get(loginConf,jaasSection,"serviceName");
    }
 catch (    IOException e) {
      LOG.error("Failed to get service name.",e);
      throw new RuntimeException(e);
    }
    try {
      Principal principal=(Principal)subject.getPrincipals().toArray()[0];
      final String fPrincipalName=principal.getName();
      final String fHost=host;
      final String fServiceName=serviceName;
      final CallbackHandler fch=ch;
      LOG.debug("Kerberos Client with principal: {}, host: {}",fPrincipalName,fHost);
      saslClient=Subject.doAs(subject,new PrivilegedExceptionAction<SaslClient>(){
        @Override public SaslClient run(){
          try {
            Map<String,String> props=new TreeMap<String,String>();
            props.put(Sasl.QOP,"auth");
            props.put(Sasl.SERVER_AUTH,"false");
            return Sasl.createSaslClient(new String[]{SaslUtils.KERBEROS},fPrincipalName,fServiceName,fHost,props,fch);
          }
 catch (          Exception e) {
            LOG.error("Subject failed to create sasl client.",e);
            return null;
          }
        }
      }
);
      LOG.info("Got Client: {}",saslClient);
    }
 catch (    PrivilegedActionException e) {
      LOG.error("KerberosSaslNettyClient: Could not create Sasl Netty Client.");
      throw new RuntimeException(e);
    }
  }
  public boolean isComplete(){
    return saslClient.isComplete();
  }
  /** 
 * Respond to server's SASL token.
 * @param saslTokenMessage contains server's SASL token
 * @return client's response SASL token
 */
  public byte[] saslResponse(  SaslMessageToken saslTokenMessage){
    try {
      final SaslMessageToken fSaslTokenMessage=saslTokenMessage;
      byte[] retval=Subject.doAs(subject,new PrivilegedExceptionAction<byte[]>(){
        @Override public byte[] run(){
          try {
            byte[] retval=saslClient.evaluateChallenge(fSaslTokenMessage.getSaslToken());
            return retval;
          }
 catch (          SaslException e) {
            LOG.error("saslResponse: Failed to respond to SASL server's token:",e);
            throw new RuntimeException(e);
          }
        }
      }
);
      return retval;
    }
 catch (    PrivilegedActionException e) {
      LOG.error("Failed to generate response for token: ",e);
      throw new RuntimeException(e);
    }
  }
  /** 
 * Implementation of javax.security.auth.callback.CallbackHandler that works with Storm topology tokens.
 */
private static class SaslClientCallbackHandler implements CallbackHandler {
    /** 
 * Implementation used to respond to SASL tokens from server.
 * @param callbacks objects that indicate what credential information the server's SaslServer requires from the client.
 */
    @Override public void handle(    Callback[] callbacks) throws UnsupportedCallbackException {
      for (      Callback callback : callbacks) {
        LOG.info("Kerberos Client Callback Handler got callback: {}",callback.getClass());
      }
    }
  }
}
