/** 
 * Simple class to pair a tuple with a statement.
 */
public class PairStatementTuple {
  private final Tuple tuple;
  private final Statement statement;
  /** 
 * Creates a new  {@link PairStatementTuple} instance.
 */
  public PairStatementTuple(  Tuple tuple,  Statement statement){
    this.tuple=tuple;
    this.statement=statement;
  }
  public Tuple getTuple(){
    return tuple;
  }
  public Statement getStatement(){
    return statement;
  }
}
