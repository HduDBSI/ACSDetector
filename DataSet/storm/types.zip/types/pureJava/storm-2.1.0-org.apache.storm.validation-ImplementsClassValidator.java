public static class ImplementsClassValidator extends Validator {
  Class<?> classImplements;
  public ImplementsClassValidator(  Map<String,Object> params){
    this.classImplements=(Class<?>)params.get(ConfigValidationAnnotations.ValidatorParams.IMPLEMENTS_CLASS);
  }
  @Override public void validateField(  String name,  Object o){
    if (o == null) {
      return;
    }
    SimpleTypeValidator.validateField(name,String.class,o);
    String className=(String)o;
    try {
      Class<?> objectClass=Class.forName(className);
      if (!this.classImplements.isAssignableFrom(objectClass)) {
        throw new IllegalArgumentException("Field " + name + " with value "+ o+ " does not implement "+ this.classImplements.getName());
      }
    }
 catch (    ClassNotFoundException e) {
      if (className.startsWith("backtype.storm")) {
        LOG.error("ClassNotFoundException: {}",className);
        LOG.warn("Replace backtype.storm with org.apache.storm and try to validate again");
        LOG.warn("We loosen some constraints here to support topologies of older version running on the current version");
        validateField(name,className.replace("backtype.storm","org.apache.storm"));
      }
 else {
        throw new RuntimeException(e);
      }
    }
  }
}
