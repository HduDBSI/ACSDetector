private static class LogLevelStandardScheme extends org.apache.storm.thrift.scheme.StandardScheme<LogLevel> {
  public void read(  org.apache.storm.thrift.protocol.TProtocol iprot,  LogLevel struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TField schemeField;
    iprot.readStructBegin();
    while (true) {
      schemeField=iprot.readFieldBegin();
      if (schemeField.type == org.apache.storm.thrift.protocol.TType.STOP) {
        break;
      }
switch (schemeField.id) {
case 1:
        if (schemeField.type == org.apache.storm.thrift.protocol.TType.I32) {
          struct.action=org.apache.storm.generated.LogLevelAction.findByValue(iprot.readI32());
          struct.set_action_isSet(true);
        }
 else {
          org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
        }
      break;
case 2:
    if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
      struct.target_log_level=iprot.readString();
      struct.set_target_log_level_isSet(true);
    }
 else {
      org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
    }
  break;
case 3:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.I32) {
  struct.reset_log_level_timeout_secs=iprot.readI32();
  struct.set_reset_log_level_timeout_secs_isSet(true);
}
 else {
  org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 4:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.I64) {
struct.reset_log_level_timeout_epoch=iprot.readI64();
struct.set_reset_log_level_timeout_epoch_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 5:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
struct.reset_log_level=iprot.readString();
struct.set_reset_log_level_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
default :
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
iprot.readFieldEnd();
}
iprot.readStructEnd();
struct.validate();
}
public void write(org.apache.storm.thrift.protocol.TProtocol oprot,LogLevel struct) throws org.apache.storm.thrift.TException {
struct.validate();
oprot.writeStructBegin(STRUCT_DESC);
if (struct.action != null) {
oprot.writeFieldBegin(ACTION_FIELD_DESC);
oprot.writeI32(struct.action.getValue());
oprot.writeFieldEnd();
}
if (struct.target_log_level != null) {
if (struct.is_set_target_log_level()) {
oprot.writeFieldBegin(TARGET_LOG_LEVEL_FIELD_DESC);
oprot.writeString(struct.target_log_level);
oprot.writeFieldEnd();
}
}
if (struct.is_set_reset_log_level_timeout_secs()) {
oprot.writeFieldBegin(RESET_LOG_LEVEL_TIMEOUT_SECS_FIELD_DESC);
oprot.writeI32(struct.reset_log_level_timeout_secs);
oprot.writeFieldEnd();
}
if (struct.is_set_reset_log_level_timeout_epoch()) {
oprot.writeFieldBegin(RESET_LOG_LEVEL_TIMEOUT_EPOCH_FIELD_DESC);
oprot.writeI64(struct.reset_log_level_timeout_epoch);
oprot.writeFieldEnd();
}
if (struct.reset_log_level != null) {
if (struct.is_set_reset_log_level()) {
oprot.writeFieldBegin(RESET_LOG_LEVEL_FIELD_DESC);
oprot.writeString(struct.reset_log_level);
oprot.writeFieldEnd();
}
}
oprot.writeFieldStop();
oprot.writeStructEnd();
}
}
