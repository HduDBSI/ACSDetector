public class CassandraStateUpdater extends BaseStateUpdater<CassandraState> {
  @Override public void updateState(  CassandraState state,  List<TridentTuple> list,  TridentCollector collector){
    state.updateState(list,collector);
  }
}
