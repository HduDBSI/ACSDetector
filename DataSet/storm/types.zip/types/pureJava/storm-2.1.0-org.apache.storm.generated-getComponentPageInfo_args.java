public static class getComponentPageInfo_args implements org.apache.storm.thrift.TBase<getComponentPageInfo_args,getComponentPageInfo_args._Fields>, java.io.Serializable, Cloneable, Comparable<getComponentPageInfo_args> {
  private static final org.apache.storm.thrift.protocol.TStruct STRUCT_DESC=new org.apache.storm.thrift.protocol.TStruct("getComponentPageInfo_args");
  private static final org.apache.storm.thrift.protocol.TField TOPOLOGY_ID_FIELD_DESC=new org.apache.storm.thrift.protocol.TField("topology_id",org.apache.storm.thrift.protocol.TType.STRING,(short)1);
  private static final org.apache.storm.thrift.protocol.TField COMPONENT_ID_FIELD_DESC=new org.apache.storm.thrift.protocol.TField("component_id",org.apache.storm.thrift.protocol.TType.STRING,(short)2);
  private static final org.apache.storm.thrift.protocol.TField WINDOW_FIELD_DESC=new org.apache.storm.thrift.protocol.TField("window",org.apache.storm.thrift.protocol.TType.STRING,(short)3);
  private static final org.apache.storm.thrift.protocol.TField IS_INCLUDE_SYS_FIELD_DESC=new org.apache.storm.thrift.protocol.TField("is_include_sys",org.apache.storm.thrift.protocol.TType.BOOL,(short)4);
  private static final org.apache.storm.thrift.scheme.SchemeFactory STANDARD_SCHEME_FACTORY=new getComponentPageInfo_argsStandardSchemeFactory();
  private static final org.apache.storm.thrift.scheme.SchemeFactory TUPLE_SCHEME_FACTORY=new getComponentPageInfo_argsTupleSchemeFactory();
  private @org.apache.storm.thrift.annotation.Nullable java.lang.String topology_id;
  private @org.apache.storm.thrift.annotation.Nullable java.lang.String component_id;
  private @org.apache.storm.thrift.annotation.Nullable java.lang.String window;
  private boolean is_include_sys;
  /** 
 * The set of fields this struct contains, along with convenience methods for finding and manipulating them. 
 */
  public enum _Fields implements org.apache.storm.thrift.TFieldIdEnum {  TOPOLOGY_ID((short)1,"topology_id"),   COMPONENT_ID((short)2,"component_id"),   WINDOW((short)3,"window"),   IS_INCLUDE_SYS((short)4,"is_include_sys");   private static final java.util.Map<java.lang.String,_Fields> byName=new java.util.HashMap<java.lang.String,_Fields>();
static {
    for (    _Fields field : java.util.EnumSet.allOf(_Fields.class)) {
      byName.put(field.getFieldName(),field);
    }
  }
  /** 
 * Find the _Fields constant that matches fieldId, or null if its not found.
 */
  @org.apache.storm.thrift.annotation.Nullable public static _Fields findByThriftId(  int fieldId){
switch (fieldId) {
case 1:
      return TOPOLOGY_ID;
case 2:
    return COMPONENT_ID;
case 3:
  return WINDOW;
case 4:
return IS_INCLUDE_SYS;
default :
return null;
}
}
/** 
 * Find the _Fields constant that matches fieldId, throwing an exception if it is not found.
 */
public static _Fields findByThriftIdOrThrow(int fieldId){
_Fields fields=findByThriftId(fieldId);
if (fields == null) throw new java.lang.IllegalArgumentException("Field " + fieldId + " doesn't exist!");
return fields;
}
/** 
 * Find the _Fields constant that matches name, or null if its not found.
 */
@org.apache.storm.thrift.annotation.Nullable public static _Fields findByName(java.lang.String name){
return byName.get(name);
}
private final short _thriftId;
private final java.lang.String _fieldName;
_Fields(short thriftId,java.lang.String fieldName){
_thriftId=thriftId;
_fieldName=fieldName;
}
public short getThriftFieldId(){
return _thriftId;
}
public java.lang.String getFieldName(){
return _fieldName;
}
}
private static final int __IS_INCLUDE_SYS_ISSET_ID=0;
private byte __isset_bitfield=0;
public static final java.util.Map<_Fields,org.apache.storm.thrift.meta_data.FieldMetaData> metaDataMap;
static {
java.util.Map<_Fields,org.apache.storm.thrift.meta_data.FieldMetaData> tmpMap=new java.util.EnumMap<_Fields,org.apache.storm.thrift.meta_data.FieldMetaData>(_Fields.class);
tmpMap.put(_Fields.TOPOLOGY_ID,new org.apache.storm.thrift.meta_data.FieldMetaData("topology_id",org.apache.storm.thrift.TFieldRequirementType.DEFAULT,new org.apache.storm.thrift.meta_data.FieldValueMetaData(org.apache.storm.thrift.protocol.TType.STRING)));
tmpMap.put(_Fields.COMPONENT_ID,new org.apache.storm.thrift.meta_data.FieldMetaData("component_id",org.apache.storm.thrift.TFieldRequirementType.DEFAULT,new org.apache.storm.thrift.meta_data.FieldValueMetaData(org.apache.storm.thrift.protocol.TType.STRING)));
tmpMap.put(_Fields.WINDOW,new org.apache.storm.thrift.meta_data.FieldMetaData("window",org.apache.storm.thrift.TFieldRequirementType.DEFAULT,new org.apache.storm.thrift.meta_data.FieldValueMetaData(org.apache.storm.thrift.protocol.TType.STRING)));
tmpMap.put(_Fields.IS_INCLUDE_SYS,new org.apache.storm.thrift.meta_data.FieldMetaData("is_include_sys",org.apache.storm.thrift.TFieldRequirementType.DEFAULT,new org.apache.storm.thrift.meta_data.FieldValueMetaData(org.apache.storm.thrift.protocol.TType.BOOL)));
metaDataMap=java.util.Collections.unmodifiableMap(tmpMap);
org.apache.storm.thrift.meta_data.FieldMetaData.addStructMetaDataMap(getComponentPageInfo_args.class,metaDataMap);
}
public getComponentPageInfo_args(){
}
public getComponentPageInfo_args(java.lang.String topology_id,java.lang.String component_id,java.lang.String window,boolean is_include_sys){
this();
this.topology_id=topology_id;
this.component_id=component_id;
this.window=window;
this.is_include_sys=is_include_sys;
set_is_include_sys_isSet(true);
}
/** 
 * Performs a deep copy on <i>other</i>.
 */
public getComponentPageInfo_args(getComponentPageInfo_args other){
__isset_bitfield=other.__isset_bitfield;
if (other.is_set_topology_id()) {
this.topology_id=other.topology_id;
}
if (other.is_set_component_id()) {
this.component_id=other.component_id;
}
if (other.is_set_window()) {
this.window=other.window;
}
this.is_include_sys=other.is_include_sys;
}
public getComponentPageInfo_args deepCopy(){
return new getComponentPageInfo_args(this);
}
@Override public void clear(){
this.topology_id=null;
this.component_id=null;
this.window=null;
set_is_include_sys_isSet(false);
this.is_include_sys=false;
}
@org.apache.storm.thrift.annotation.Nullable public java.lang.String get_topology_id(){
return this.topology_id;
}
public void set_topology_id(@org.apache.storm.thrift.annotation.Nullable java.lang.String topology_id){
this.topology_id=topology_id;
}
public void unset_topology_id(){
this.topology_id=null;
}
/** 
 * Returns true if field topology_id is set (has been assigned a value) and false otherwise 
 */
public boolean is_set_topology_id(){
return this.topology_id != null;
}
public void set_topology_id_isSet(boolean value){
if (!value) {
this.topology_id=null;
}
}
@org.apache.storm.thrift.annotation.Nullable public java.lang.String get_component_id(){
return this.component_id;
}
public void set_component_id(@org.apache.storm.thrift.annotation.Nullable java.lang.String component_id){
this.component_id=component_id;
}
public void unset_component_id(){
this.component_id=null;
}
/** 
 * Returns true if field component_id is set (has been assigned a value) and false otherwise 
 */
public boolean is_set_component_id(){
return this.component_id != null;
}
public void set_component_id_isSet(boolean value){
if (!value) {
this.component_id=null;
}
}
@org.apache.storm.thrift.annotation.Nullable public java.lang.String get_window(){
return this.window;
}
public void set_window(@org.apache.storm.thrift.annotation.Nullable java.lang.String window){
this.window=window;
}
public void unset_window(){
this.window=null;
}
/** 
 * Returns true if field window is set (has been assigned a value) and false otherwise 
 */
public boolean is_set_window(){
return this.window != null;
}
public void set_window_isSet(boolean value){
if (!value) {
this.window=null;
}
}
public boolean is_is_include_sys(){
return this.is_include_sys;
}
public void set_is_include_sys(boolean is_include_sys){
this.is_include_sys=is_include_sys;
set_is_include_sys_isSet(true);
}
public void unset_is_include_sys(){
__isset_bitfield=org.apache.storm.thrift.EncodingUtils.clearBit(__isset_bitfield,__IS_INCLUDE_SYS_ISSET_ID);
}
/** 
 * Returns true if field is_include_sys is set (has been assigned a value) and false otherwise 
 */
public boolean is_set_is_include_sys(){
return org.apache.storm.thrift.EncodingUtils.testBit(__isset_bitfield,__IS_INCLUDE_SYS_ISSET_ID);
}
public void set_is_include_sys_isSet(boolean value){
__isset_bitfield=org.apache.storm.thrift.EncodingUtils.setBit(__isset_bitfield,__IS_INCLUDE_SYS_ISSET_ID,value);
}
public void setFieldValue(_Fields field,@org.apache.storm.thrift.annotation.Nullable java.lang.Object value){
switch (field) {
case TOPOLOGY_ID:
if (value == null) {
unset_topology_id();
}
 else {
set_topology_id((java.lang.String)value);
}
break;
case COMPONENT_ID:
if (value == null) {
unset_component_id();
}
 else {
set_component_id((java.lang.String)value);
}
break;
case WINDOW:
if (value == null) {
unset_window();
}
 else {
set_window((java.lang.String)value);
}
break;
case IS_INCLUDE_SYS:
if (value == null) {
unset_is_include_sys();
}
 else {
set_is_include_sys((java.lang.Boolean)value);
}
break;
}
}
@org.apache.storm.thrift.annotation.Nullable public java.lang.Object getFieldValue(_Fields field){
switch (field) {
case TOPOLOGY_ID:
return get_topology_id();
case COMPONENT_ID:
return get_component_id();
case WINDOW:
return get_window();
case IS_INCLUDE_SYS:
return is_is_include_sys();
}
throw new java.lang.IllegalStateException();
}
/** 
 * Returns true if field corresponding to fieldID is set (has been assigned a value) and false otherwise 
 */
public boolean isSet(_Fields field){
if (field == null) {
throw new java.lang.IllegalArgumentException();
}
switch (field) {
case TOPOLOGY_ID:
return is_set_topology_id();
case COMPONENT_ID:
return is_set_component_id();
case WINDOW:
return is_set_window();
case IS_INCLUDE_SYS:
return is_set_is_include_sys();
}
throw new java.lang.IllegalStateException();
}
@Override public boolean equals(java.lang.Object that){
if (that == null) return false;
if (that instanceof getComponentPageInfo_args) return this.equals((getComponentPageInfo_args)that);
return false;
}
public boolean equals(getComponentPageInfo_args that){
if (that == null) return false;
if (this == that) return true;
boolean this_present_topology_id=true && this.is_set_topology_id();
boolean that_present_topology_id=true && that.is_set_topology_id();
if (this_present_topology_id || that_present_topology_id) {
if (!(this_present_topology_id && that_present_topology_id)) return false;
if (!this.topology_id.equals(that.topology_id)) return false;
}
boolean this_present_component_id=true && this.is_set_component_id();
boolean that_present_component_id=true && that.is_set_component_id();
if (this_present_component_id || that_present_component_id) {
if (!(this_present_component_id && that_present_component_id)) return false;
if (!this.component_id.equals(that.component_id)) return false;
}
boolean this_present_window=true && this.is_set_window();
boolean that_present_window=true && that.is_set_window();
if (this_present_window || that_present_window) {
if (!(this_present_window && that_present_window)) return false;
if (!this.window.equals(that.window)) return false;
}
boolean this_present_is_include_sys=true;
boolean that_present_is_include_sys=true;
if (this_present_is_include_sys || that_present_is_include_sys) {
if (!(this_present_is_include_sys && that_present_is_include_sys)) return false;
if (this.is_include_sys != that.is_include_sys) return false;
}
return true;
}
@Override public int hashCode(){
int hashCode=1;
hashCode=hashCode * 8191 + ((is_set_topology_id()) ? 131071 : 524287);
if (is_set_topology_id()) hashCode=hashCode * 8191 + topology_id.hashCode();
hashCode=hashCode * 8191 + ((is_set_component_id()) ? 131071 : 524287);
if (is_set_component_id()) hashCode=hashCode * 8191 + component_id.hashCode();
hashCode=hashCode * 8191 + ((is_set_window()) ? 131071 : 524287);
if (is_set_window()) hashCode=hashCode * 8191 + window.hashCode();
hashCode=hashCode * 8191 + ((is_include_sys) ? 131071 : 524287);
return hashCode;
}
@Override public int compareTo(getComponentPageInfo_args other){
if (!getClass().equals(other.getClass())) {
return getClass().getName().compareTo(other.getClass().getName());
}
int lastComparison=0;
lastComparison=java.lang.Boolean.valueOf(is_set_topology_id()).compareTo(other.is_set_topology_id());
if (lastComparison != 0) {
return lastComparison;
}
if (is_set_topology_id()) {
lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.topology_id,other.topology_id);
if (lastComparison != 0) {
return lastComparison;
}
}
lastComparison=java.lang.Boolean.valueOf(is_set_component_id()).compareTo(other.is_set_component_id());
if (lastComparison != 0) {
return lastComparison;
}
if (is_set_component_id()) {
lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.component_id,other.component_id);
if (lastComparison != 0) {
return lastComparison;
}
}
lastComparison=java.lang.Boolean.valueOf(is_set_window()).compareTo(other.is_set_window());
if (lastComparison != 0) {
return lastComparison;
}
if (is_set_window()) {
lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.window,other.window);
if (lastComparison != 0) {
return lastComparison;
}
}
lastComparison=java.lang.Boolean.valueOf(is_set_is_include_sys()).compareTo(other.is_set_is_include_sys());
if (lastComparison != 0) {
return lastComparison;
}
if (is_set_is_include_sys()) {
lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.is_include_sys,other.is_include_sys);
if (lastComparison != 0) {
return lastComparison;
}
}
return 0;
}
@org.apache.storm.thrift.annotation.Nullable public _Fields fieldForId(int fieldId){
return _Fields.findByThriftId(fieldId);
}
public void read(org.apache.storm.thrift.protocol.TProtocol iprot) throws org.apache.storm.thrift.TException {
scheme(iprot).read(iprot,this);
}
public void write(org.apache.storm.thrift.protocol.TProtocol oprot) throws org.apache.storm.thrift.TException {
scheme(oprot).write(oprot,this);
}
@Override public java.lang.String toString(){
java.lang.StringBuilder sb=new java.lang.StringBuilder("getComponentPageInfo_args(");
boolean first=true;
sb.append("topology_id:");
if (this.topology_id == null) {
sb.append("null");
}
 else {
sb.append(this.topology_id);
}
first=false;
if (!first) sb.append(", ");
sb.append("component_id:");
if (this.component_id == null) {
sb.append("null");
}
 else {
sb.append(this.component_id);
}
first=false;
if (!first) sb.append(", ");
sb.append("window:");
if (this.window == null) {
sb.append("null");
}
 else {
sb.append(this.window);
}
first=false;
if (!first) sb.append(", ");
sb.append("is_include_sys:");
sb.append(this.is_include_sys);
first=false;
sb.append(")");
return sb.toString();
}
public void validate() throws org.apache.storm.thrift.TException {
}
private void writeObject(java.io.ObjectOutputStream out) throws java.io.IOException {
try {
write(new org.apache.storm.thrift.protocol.TCompactProtocol(new org.apache.storm.thrift.transport.TIOStreamTransport(out)));
}
 catch (org.apache.storm.thrift.TException te) {
throw new java.io.IOException(te);
}
}
private void readObject(java.io.ObjectInputStream in) throws java.io.IOException, java.lang.ClassNotFoundException {
try {
__isset_bitfield=0;
read(new org.apache.storm.thrift.protocol.TCompactProtocol(new org.apache.storm.thrift.transport.TIOStreamTransport(in)));
}
 catch (org.apache.storm.thrift.TException te) {
throw new java.io.IOException(te);
}
}
private static class getComponentPageInfo_argsStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
public getComponentPageInfo_argsStandardScheme getScheme(){
return new getComponentPageInfo_argsStandardScheme();
}
}
private static class getComponentPageInfo_argsStandardScheme extends org.apache.storm.thrift.scheme.StandardScheme<getComponentPageInfo_args> {
public void read(org.apache.storm.thrift.protocol.TProtocol iprot,getComponentPageInfo_args struct) throws org.apache.storm.thrift.TException {
org.apache.storm.thrift.protocol.TField schemeField;
iprot.readStructBegin();
while (true) {
schemeField=iprot.readFieldBegin();
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STOP) {
break;
}
switch (schemeField.id) {
case 1:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
struct.topology_id=iprot.readString();
struct.set_topology_id_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 2:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
struct.component_id=iprot.readString();
struct.set_component_id_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 3:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
struct.window=iprot.readString();
struct.set_window_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 4:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.BOOL) {
struct.is_include_sys=iprot.readBool();
struct.set_is_include_sys_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
default :
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
iprot.readFieldEnd();
}
iprot.readStructEnd();
struct.validate();
}
public void write(org.apache.storm.thrift.protocol.TProtocol oprot,getComponentPageInfo_args struct) throws org.apache.storm.thrift.TException {
struct.validate();
oprot.writeStructBegin(STRUCT_DESC);
if (struct.topology_id != null) {
oprot.writeFieldBegin(TOPOLOGY_ID_FIELD_DESC);
oprot.writeString(struct.topology_id);
oprot.writeFieldEnd();
}
if (struct.component_id != null) {
oprot.writeFieldBegin(COMPONENT_ID_FIELD_DESC);
oprot.writeString(struct.component_id);
oprot.writeFieldEnd();
}
if (struct.window != null) {
oprot.writeFieldBegin(WINDOW_FIELD_DESC);
oprot.writeString(struct.window);
oprot.writeFieldEnd();
}
oprot.writeFieldBegin(IS_INCLUDE_SYS_FIELD_DESC);
oprot.writeBool(struct.is_include_sys);
oprot.writeFieldEnd();
oprot.writeFieldStop();
oprot.writeStructEnd();
}
}
private static class getComponentPageInfo_argsTupleSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
public getComponentPageInfo_argsTupleScheme getScheme(){
return new getComponentPageInfo_argsTupleScheme();
}
}
private static class getComponentPageInfo_argsTupleScheme extends org.apache.storm.thrift.scheme.TupleScheme<getComponentPageInfo_args> {
@Override public void write(org.apache.storm.thrift.protocol.TProtocol prot,getComponentPageInfo_args struct) throws org.apache.storm.thrift.TException {
org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
java.util.BitSet optionals=new java.util.BitSet();
if (struct.is_set_topology_id()) {
optionals.set(0);
}
if (struct.is_set_component_id()) {
optionals.set(1);
}
if (struct.is_set_window()) {
optionals.set(2);
}
if (struct.is_set_is_include_sys()) {
optionals.set(3);
}
oprot.writeBitSet(optionals,4);
if (struct.is_set_topology_id()) {
oprot.writeString(struct.topology_id);
}
if (struct.is_set_component_id()) {
oprot.writeString(struct.component_id);
}
if (struct.is_set_window()) {
oprot.writeString(struct.window);
}
if (struct.is_set_is_include_sys()) {
oprot.writeBool(struct.is_include_sys);
}
}
@Override public void read(org.apache.storm.thrift.protocol.TProtocol prot,getComponentPageInfo_args struct) throws org.apache.storm.thrift.TException {
org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
java.util.BitSet incoming=iprot.readBitSet(4);
if (incoming.get(0)) {
struct.topology_id=iprot.readString();
struct.set_topology_id_isSet(true);
}
if (incoming.get(1)) {
struct.component_id=iprot.readString();
struct.set_component_id_isSet(true);
}
if (incoming.get(2)) {
struct.window=iprot.readString();
struct.set_window_isSet(true);
}
if (incoming.get(3)) {
struct.is_include_sys=iprot.readBool();
struct.set_is_include_sys_isSet(true);
}
}
}
private static <S extends org.apache.storm.thrift.scheme.IScheme>S scheme(org.apache.storm.thrift.protocol.TProtocol proto){
return (org.apache.storm.thrift.scheme.StandardScheme.class.equals(proto.getScheme()) ? STANDARD_SCHEME_FACTORY : TUPLE_SCHEME_FACTORY).getScheme();
}
}
