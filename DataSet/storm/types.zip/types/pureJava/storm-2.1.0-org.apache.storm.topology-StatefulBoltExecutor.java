/** 
 * Wraps a  {@link IStatefulBolt} and manages the state of the bolt.
 */
public class StatefulBoltExecutor<T extends State> extends BaseStatefulBoltExecutor {
  private static final Logger LOG=LoggerFactory.getLogger(StatefulBoltExecutor.class);
  private final IStatefulBolt<T> bolt;
  private State state;
  private boolean boltInitialized=false;
  private List<Tuple> pendingTuples=new ArrayList<>();
  private List<Tuple> preparedTuples=new ArrayList<>();
  private AckTrackingOutputCollector collector;
  public StatefulBoltExecutor(  IStatefulBolt<T> bolt){
    this.bolt=bolt;
  }
  @Override public void prepare(  Map<String,Object> topoConf,  TopologyContext context,  OutputCollector collector){
    String namespace=context.getThisComponentId() + "-" + context.getThisTaskId();
    prepare(topoConf,context,collector,StateFactory.getState(namespace,topoConf,context));
  }
  void prepare(  Map<String,Object> topoConf,  TopologyContext context,  OutputCollector collector,  State state){
    init(context,collector);
    this.collector=new AckTrackingOutputCollector(collector);
    bolt.prepare(topoConf,context,this.collector);
    this.state=state;
  }
  @Override public void cleanup(){
    bolt.cleanup();
  }
  @Override public void declareOutputFields(  OutputFieldsDeclarer declarer){
    bolt.declareOutputFields(declarer);
    declareCheckpointStream(declarer);
  }
  @Override public Map<String,Object> getComponentConfiguration(){
    return bolt.getComponentConfiguration();
  }
  @Override protected void handleCheckpoint(  Tuple checkpointTuple,  Action action,  long txid){
    LOG.debug("handleCheckPoint with tuple {}, action {}, txid {}",checkpointTuple,action,txid);
    if (action == PREPARE) {
      if (boltInitialized) {
        bolt.prePrepare(txid);
        state.prepareCommit(txid);
        preparedTuples.addAll(collector.ackedTuples());
      }
 else {
        LOG.debug("Failing checkpointTuple, PREPARE received when bolt state is not initialized.");
        collector.fail(checkpointTuple);
        return;
      }
    }
 else     if (action == COMMIT) {
      bolt.preCommit(txid);
      state.commit(txid);
      ack(preparedTuples);
    }
 else     if (action == ROLLBACK) {
      bolt.preRollback();
      state.rollback();
      fail(preparedTuples);
      fail(collector.ackedTuples());
    }
 else     if (action == INITSTATE) {
      if (!boltInitialized) {
        bolt.initState((T)state);
        boltInitialized=true;
        LOG.debug("{} pending tuples to process",pendingTuples.size());
        for (        Tuple tuple : pendingTuples) {
          doExecute(tuple);
        }
        pendingTuples.clear();
      }
 else {
        LOG.debug("Bolt state is already initialized, ignoring tuple {}, action {}, txid {}",checkpointTuple,action,txid);
      }
    }
    collector.emit(CheckpointSpout.CHECKPOINT_STREAM_ID,checkpointTuple,new Values(txid,action));
    collector.delegate.ack(checkpointTuple);
  }
  @Override protected void handleTuple(  Tuple input){
    if (boltInitialized) {
      doExecute(input);
    }
 else {
      LOG.debug("Bolt state not initialized, adding tuple {} to pending tuples",input);
      pendingTuples.add(input);
    }
  }
  private void doExecute(  Tuple tuple){
    bolt.execute(tuple);
  }
  private void ack(  List<Tuple> tuples){
    if (!tuples.isEmpty()) {
      LOG.debug("Acking {} tuples",tuples.size());
      for (      Tuple tuple : tuples) {
        collector.delegate.ack(tuple);
      }
      tuples.clear();
    }
  }
  private void fail(  List<Tuple> tuples){
    if (!tuples.isEmpty()) {
      LOG.debug("Failing {} tuples",tuples.size());
      for (      Tuple tuple : tuples) {
        collector.fail(tuple);
      }
      tuples.clear();
    }
  }
private static class AckTrackingOutputCollector extends AnchoringOutputCollector {
    private final OutputCollector delegate;
    private final Queue<Tuple> ackedTuples;
    AckTrackingOutputCollector(    OutputCollector delegate){
      super(delegate);
      this.delegate=delegate;
      this.ackedTuples=new ConcurrentLinkedQueue<>();
    }
    List<Tuple> ackedTuples(){
      List<Tuple> result=new ArrayList<>();
      Iterator<Tuple> it=ackedTuples.iterator();
      while (it.hasNext()) {
        result.add(it.next());
        it.remove();
      }
      return result;
    }
    @Override public void ack(    Tuple input){
      ackedTuples.add(input);
    }
  }
}
