/** 
 * A fixed batch spout.
 */
public static class FixedBatchSpout implements IBatchSpout {
  private static final long serialVersionUID=1L;
  private int maxBatchSize;
  /** 
 * The passed batches.
 */
  private HashMap<Long,List<List<Object>>> batches=new HashMap<>();
  /** 
 * The output values.
 */
  private Values[] outputs={new Values("{\"user\":\"user1\"}","index1","type1",UUID.randomUUID().toString()),new Values("{\"user\":\"user2\"}","index1","type2",UUID.randomUUID().toString()),new Values("{\"user\":\"user3\"}","index2","type1",UUID.randomUUID().toString()),new Values("{\"user\":\"user4\"}","index2","type2",UUID.randomUUID().toString())};
  /** 
 * The current index.
 */
  private int index=0;
  /** 
 * A flag indicating whether cycling ought to be performed.
 */
  private boolean cycle=false;
  /** 
 * Creates a new fixed batch spout.
 * @param maxBatchSizeArg the maximum batch size to set
 */
  public FixedBatchSpout(  final int maxBatchSizeArg){
    this.maxBatchSize=maxBatchSizeArg;
  }
  /** 
 * Gets the output fields.
 * @return the output fields.
 */
  @Override public Fields getOutputFields(){
    return new Fields("source","index","type","id");
  }
  /** 
 * Opens the spout.
 * @param conf the configuration to use for opening
 * @param context the context to use for opening
 */
  @Override public void open(  final Map<String,Object> conf,  final TopologyContext context){
    index=0;
  }
  /** 
 * Emits a batch.
 * @param batchId the batch id to use
 * @param collector the collector to emit to
 */
  @Override public void emitBatch(  final long batchId,  final TridentCollector collector){
    List<List<Object>> batch=this.batches.get(batchId);
    if (batch == null) {
      batch=new ArrayList<List<Object>>();
      if (index >= outputs.length && cycle) {
        index=0;
      }
      for (int i=0; i < maxBatchSize; index++, i++) {
        if (index == outputs.length) {
          index=0;
        }
        batch.add(outputs[index]);
      }
      this.batches.put(batchId,batch);
    }
    for (    List<Object> list : batch) {
      collector.emit(list);
    }
  }
  /** 
 * Acknowledges the message with id  {@code msgId}.
 * @param batchId the message id
 */
  @Override public void ack(  final long batchId){
    this.batches.remove(batchId);
  }
  /** 
 * Closes the spout.
 */
  @Override public void close(){
  }
  /** 
 * Get the component configuration.
 * @return the component configuration
 */
  @Override public Map<String,Object> getComponentConfiguration(){
    Config conf=new Config();
    conf.setMaxTaskParallelism(1);
    return conf;
  }
}
