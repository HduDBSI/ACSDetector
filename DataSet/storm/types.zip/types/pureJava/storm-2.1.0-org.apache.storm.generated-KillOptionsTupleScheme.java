private static class KillOptionsTupleScheme extends org.apache.storm.thrift.scheme.TupleScheme<KillOptions> {
  @Override public void write(  org.apache.storm.thrift.protocol.TProtocol prot,  KillOptions struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
    java.util.BitSet optionals=new java.util.BitSet();
    if (struct.is_set_wait_secs()) {
      optionals.set(0);
    }
    oprot.writeBitSet(optionals,1);
    if (struct.is_set_wait_secs()) {
      oprot.writeI32(struct.wait_secs);
    }
  }
  @Override public void read(  org.apache.storm.thrift.protocol.TProtocol prot,  KillOptions struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
    java.util.BitSet incoming=iprot.readBitSet(1);
    if (incoming.get(0)) {
      struct.wait_secs=iprot.readI32();
      struct.set_wait_secs_isSet(true);
    }
  }
}
