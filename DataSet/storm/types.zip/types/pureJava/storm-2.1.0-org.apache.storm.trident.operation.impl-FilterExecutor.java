public class FilterExecutor implements Function {
  Filter filter;
  public FilterExecutor(  Filter filter){
    this.filter=filter;
  }
  @Override public void execute(  TridentTuple tuple,  TridentCollector collector){
    if (filter.isKeep(tuple)) {
      collector.emit(null);
    }
  }
  @Override public void prepare(  Map<String,Object> conf,  TridentOperationContext context){
    filter.prepare(conf,context);
  }
  @Override public void cleanup(){
    filter.cleanup();
  }
}
