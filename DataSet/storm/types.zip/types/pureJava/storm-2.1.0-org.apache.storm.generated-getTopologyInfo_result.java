public static class getTopologyInfo_result implements org.apache.storm.thrift.TBase<getTopologyInfo_result,getTopologyInfo_result._Fields>, java.io.Serializable, Cloneable, Comparable<getTopologyInfo_result> {
  private static final org.apache.storm.thrift.protocol.TStruct STRUCT_DESC=new org.apache.storm.thrift.protocol.TStruct("getTopologyInfo_result");
  private static final org.apache.storm.thrift.protocol.TField SUCCESS_FIELD_DESC=new org.apache.storm.thrift.protocol.TField("success",org.apache.storm.thrift.protocol.TType.STRUCT,(short)0);
  private static final org.apache.storm.thrift.protocol.TField E_FIELD_DESC=new org.apache.storm.thrift.protocol.TField("e",org.apache.storm.thrift.protocol.TType.STRUCT,(short)1);
  private static final org.apache.storm.thrift.protocol.TField AZE_FIELD_DESC=new org.apache.storm.thrift.protocol.TField("aze",org.apache.storm.thrift.protocol.TType.STRUCT,(short)2);
  private static final org.apache.storm.thrift.scheme.SchemeFactory STANDARD_SCHEME_FACTORY=new getTopologyInfo_resultStandardSchemeFactory();
  private static final org.apache.storm.thrift.scheme.SchemeFactory TUPLE_SCHEME_FACTORY=new getTopologyInfo_resultTupleSchemeFactory();
  private @org.apache.storm.thrift.annotation.Nullable TopologyInfo success;
  private @org.apache.storm.thrift.annotation.Nullable NotAliveException e;
  private @org.apache.storm.thrift.annotation.Nullable AuthorizationException aze;
  /** 
 * The set of fields this struct contains, along with convenience methods for finding and manipulating them. 
 */
  public enum _Fields implements org.apache.storm.thrift.TFieldIdEnum {  SUCCESS((short)0,"success"),   E((short)1,"e"),   AZE((short)2,"aze");   private static final java.util.Map<java.lang.String,_Fields> byName=new java.util.HashMap<java.lang.String,_Fields>();
static {
    for (    _Fields field : java.util.EnumSet.allOf(_Fields.class)) {
      byName.put(field.getFieldName(),field);
    }
  }
  /** 
 * Find the _Fields constant that matches fieldId, or null if its not found.
 */
  @org.apache.storm.thrift.annotation.Nullable public static _Fields findByThriftId(  int fieldId){
switch (fieldId) {
case 0:
      return SUCCESS;
case 1:
    return E;
case 2:
  return AZE;
default :
return null;
}
}
/** 
 * Find the _Fields constant that matches fieldId, throwing an exception if it is not found.
 */
public static _Fields findByThriftIdOrThrow(int fieldId){
_Fields fields=findByThriftId(fieldId);
if (fields == null) throw new java.lang.IllegalArgumentException("Field " + fieldId + " doesn't exist!");
return fields;
}
/** 
 * Find the _Fields constant that matches name, or null if its not found.
 */
@org.apache.storm.thrift.annotation.Nullable public static _Fields findByName(java.lang.String name){
return byName.get(name);
}
private final short _thriftId;
private final java.lang.String _fieldName;
_Fields(short thriftId,java.lang.String fieldName){
_thriftId=thriftId;
_fieldName=fieldName;
}
public short getThriftFieldId(){
return _thriftId;
}
public java.lang.String getFieldName(){
return _fieldName;
}
}
public static final java.util.Map<_Fields,org.apache.storm.thrift.meta_data.FieldMetaData> metaDataMap;
static {
java.util.Map<_Fields,org.apache.storm.thrift.meta_data.FieldMetaData> tmpMap=new java.util.EnumMap<_Fields,org.apache.storm.thrift.meta_data.FieldMetaData>(_Fields.class);
tmpMap.put(_Fields.SUCCESS,new org.apache.storm.thrift.meta_data.FieldMetaData("success",org.apache.storm.thrift.TFieldRequirementType.DEFAULT,new org.apache.storm.thrift.meta_data.StructMetaData(org.apache.storm.thrift.protocol.TType.STRUCT,TopologyInfo.class)));
tmpMap.put(_Fields.E,new org.apache.storm.thrift.meta_data.FieldMetaData("e",org.apache.storm.thrift.TFieldRequirementType.DEFAULT,new org.apache.storm.thrift.meta_data.StructMetaData(org.apache.storm.thrift.protocol.TType.STRUCT,NotAliveException.class)));
tmpMap.put(_Fields.AZE,new org.apache.storm.thrift.meta_data.FieldMetaData("aze",org.apache.storm.thrift.TFieldRequirementType.DEFAULT,new org.apache.storm.thrift.meta_data.StructMetaData(org.apache.storm.thrift.protocol.TType.STRUCT,AuthorizationException.class)));
metaDataMap=java.util.Collections.unmodifiableMap(tmpMap);
org.apache.storm.thrift.meta_data.FieldMetaData.addStructMetaDataMap(getTopologyInfo_result.class,metaDataMap);
}
public getTopologyInfo_result(){
}
public getTopologyInfo_result(TopologyInfo success,NotAliveException e,AuthorizationException aze){
this();
this.success=success;
this.e=e;
this.aze=aze;
}
/** 
 * Performs a deep copy on <i>other</i>.
 */
public getTopologyInfo_result(getTopologyInfo_result other){
if (other.is_set_success()) {
this.success=new TopologyInfo(other.success);
}
if (other.is_set_e()) {
this.e=new NotAliveException(other.e);
}
if (other.is_set_aze()) {
this.aze=new AuthorizationException(other.aze);
}
}
public getTopologyInfo_result deepCopy(){
return new getTopologyInfo_result(this);
}
@Override public void clear(){
this.success=null;
this.e=null;
this.aze=null;
}
@org.apache.storm.thrift.annotation.Nullable public TopologyInfo get_success(){
return this.success;
}
public void set_success(@org.apache.storm.thrift.annotation.Nullable TopologyInfo success){
this.success=success;
}
public void unset_success(){
this.success=null;
}
/** 
 * Returns true if field success is set (has been assigned a value) and false otherwise 
 */
public boolean is_set_success(){
return this.success != null;
}
public void set_success_isSet(boolean value){
if (!value) {
this.success=null;
}
}
@org.apache.storm.thrift.annotation.Nullable public NotAliveException get_e(){
return this.e;
}
public void set_e(@org.apache.storm.thrift.annotation.Nullable NotAliveException e){
this.e=e;
}
public void unset_e(){
this.e=null;
}
/** 
 * Returns true if field e is set (has been assigned a value) and false otherwise 
 */
public boolean is_set_e(){
return this.e != null;
}
public void set_e_isSet(boolean value){
if (!value) {
this.e=null;
}
}
@org.apache.storm.thrift.annotation.Nullable public AuthorizationException get_aze(){
return this.aze;
}
public void set_aze(@org.apache.storm.thrift.annotation.Nullable AuthorizationException aze){
this.aze=aze;
}
public void unset_aze(){
this.aze=null;
}
/** 
 * Returns true if field aze is set (has been assigned a value) and false otherwise 
 */
public boolean is_set_aze(){
return this.aze != null;
}
public void set_aze_isSet(boolean value){
if (!value) {
this.aze=null;
}
}
public void setFieldValue(_Fields field,@org.apache.storm.thrift.annotation.Nullable java.lang.Object value){
switch (field) {
case SUCCESS:
if (value == null) {
unset_success();
}
 else {
set_success((TopologyInfo)value);
}
break;
case E:
if (value == null) {
unset_e();
}
 else {
set_e((NotAliveException)value);
}
break;
case AZE:
if (value == null) {
unset_aze();
}
 else {
set_aze((AuthorizationException)value);
}
break;
}
}
@org.apache.storm.thrift.annotation.Nullable public java.lang.Object getFieldValue(_Fields field){
switch (field) {
case SUCCESS:
return get_success();
case E:
return get_e();
case AZE:
return get_aze();
}
throw new java.lang.IllegalStateException();
}
/** 
 * Returns true if field corresponding to fieldID is set (has been assigned a value) and false otherwise 
 */
public boolean isSet(_Fields field){
if (field == null) {
throw new java.lang.IllegalArgumentException();
}
switch (field) {
case SUCCESS:
return is_set_success();
case E:
return is_set_e();
case AZE:
return is_set_aze();
}
throw new java.lang.IllegalStateException();
}
@Override public boolean equals(java.lang.Object that){
if (that == null) return false;
if (that instanceof getTopologyInfo_result) return this.equals((getTopologyInfo_result)that);
return false;
}
public boolean equals(getTopologyInfo_result that){
if (that == null) return false;
if (this == that) return true;
boolean this_present_success=true && this.is_set_success();
boolean that_present_success=true && that.is_set_success();
if (this_present_success || that_present_success) {
if (!(this_present_success && that_present_success)) return false;
if (!this.success.equals(that.success)) return false;
}
boolean this_present_e=true && this.is_set_e();
boolean that_present_e=true && that.is_set_e();
if (this_present_e || that_present_e) {
if (!(this_present_e && that_present_e)) return false;
if (!this.e.equals(that.e)) return false;
}
boolean this_present_aze=true && this.is_set_aze();
boolean that_present_aze=true && that.is_set_aze();
if (this_present_aze || that_present_aze) {
if (!(this_present_aze && that_present_aze)) return false;
if (!this.aze.equals(that.aze)) return false;
}
return true;
}
@Override public int hashCode(){
int hashCode=1;
hashCode=hashCode * 8191 + ((is_set_success()) ? 131071 : 524287);
if (is_set_success()) hashCode=hashCode * 8191 + success.hashCode();
hashCode=hashCode * 8191 + ((is_set_e()) ? 131071 : 524287);
if (is_set_e()) hashCode=hashCode * 8191 + e.hashCode();
hashCode=hashCode * 8191 + ((is_set_aze()) ? 131071 : 524287);
if (is_set_aze()) hashCode=hashCode * 8191 + aze.hashCode();
return hashCode;
}
@Override public int compareTo(getTopologyInfo_result other){
if (!getClass().equals(other.getClass())) {
return getClass().getName().compareTo(other.getClass().getName());
}
int lastComparison=0;
lastComparison=java.lang.Boolean.valueOf(is_set_success()).compareTo(other.is_set_success());
if (lastComparison != 0) {
return lastComparison;
}
if (is_set_success()) {
lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.success,other.success);
if (lastComparison != 0) {
return lastComparison;
}
}
lastComparison=java.lang.Boolean.valueOf(is_set_e()).compareTo(other.is_set_e());
if (lastComparison != 0) {
return lastComparison;
}
if (is_set_e()) {
lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.e,other.e);
if (lastComparison != 0) {
return lastComparison;
}
}
lastComparison=java.lang.Boolean.valueOf(is_set_aze()).compareTo(other.is_set_aze());
if (lastComparison != 0) {
return lastComparison;
}
if (is_set_aze()) {
lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.aze,other.aze);
if (lastComparison != 0) {
return lastComparison;
}
}
return 0;
}
@org.apache.storm.thrift.annotation.Nullable public _Fields fieldForId(int fieldId){
return _Fields.findByThriftId(fieldId);
}
public void read(org.apache.storm.thrift.protocol.TProtocol iprot) throws org.apache.storm.thrift.TException {
scheme(iprot).read(iprot,this);
}
public void write(org.apache.storm.thrift.protocol.TProtocol oprot) throws org.apache.storm.thrift.TException {
scheme(oprot).write(oprot,this);
}
@Override public java.lang.String toString(){
java.lang.StringBuilder sb=new java.lang.StringBuilder("getTopologyInfo_result(");
boolean first=true;
sb.append("success:");
if (this.success == null) {
sb.append("null");
}
 else {
sb.append(this.success);
}
first=false;
if (!first) sb.append(", ");
sb.append("e:");
if (this.e == null) {
sb.append("null");
}
 else {
sb.append(this.e);
}
first=false;
if (!first) sb.append(", ");
sb.append("aze:");
if (this.aze == null) {
sb.append("null");
}
 else {
sb.append(this.aze);
}
first=false;
sb.append(")");
return sb.toString();
}
public void validate() throws org.apache.storm.thrift.TException {
if (success != null) {
success.validate();
}
}
private void writeObject(java.io.ObjectOutputStream out) throws java.io.IOException {
try {
write(new org.apache.storm.thrift.protocol.TCompactProtocol(new org.apache.storm.thrift.transport.TIOStreamTransport(out)));
}
 catch (org.apache.storm.thrift.TException te) {
throw new java.io.IOException(te);
}
}
private void readObject(java.io.ObjectInputStream in) throws java.io.IOException, java.lang.ClassNotFoundException {
try {
read(new org.apache.storm.thrift.protocol.TCompactProtocol(new org.apache.storm.thrift.transport.TIOStreamTransport(in)));
}
 catch (org.apache.storm.thrift.TException te) {
throw new java.io.IOException(te);
}
}
private static class getTopologyInfo_resultStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
public getTopologyInfo_resultStandardScheme getScheme(){
return new getTopologyInfo_resultStandardScheme();
}
}
private static class getTopologyInfo_resultStandardScheme extends org.apache.storm.thrift.scheme.StandardScheme<getTopologyInfo_result> {
public void read(org.apache.storm.thrift.protocol.TProtocol iprot,getTopologyInfo_result struct) throws org.apache.storm.thrift.TException {
org.apache.storm.thrift.protocol.TField schemeField;
iprot.readStructBegin();
while (true) {
schemeField=iprot.readFieldBegin();
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STOP) {
break;
}
switch (schemeField.id) {
case 0:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRUCT) {
struct.success=new TopologyInfo();
struct.success.read(iprot);
struct.set_success_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 1:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRUCT) {
struct.e=new NotAliveException();
struct.e.read(iprot);
struct.set_e_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 2:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRUCT) {
struct.aze=new AuthorizationException();
struct.aze.read(iprot);
struct.set_aze_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
default :
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
iprot.readFieldEnd();
}
iprot.readStructEnd();
struct.validate();
}
public void write(org.apache.storm.thrift.protocol.TProtocol oprot,getTopologyInfo_result struct) throws org.apache.storm.thrift.TException {
struct.validate();
oprot.writeStructBegin(STRUCT_DESC);
if (struct.success != null) {
oprot.writeFieldBegin(SUCCESS_FIELD_DESC);
struct.success.write(oprot);
oprot.writeFieldEnd();
}
if (struct.e != null) {
oprot.writeFieldBegin(E_FIELD_DESC);
struct.e.write(oprot);
oprot.writeFieldEnd();
}
if (struct.aze != null) {
oprot.writeFieldBegin(AZE_FIELD_DESC);
struct.aze.write(oprot);
oprot.writeFieldEnd();
}
oprot.writeFieldStop();
oprot.writeStructEnd();
}
}
private static class getTopologyInfo_resultTupleSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
public getTopologyInfo_resultTupleScheme getScheme(){
return new getTopologyInfo_resultTupleScheme();
}
}
private static class getTopologyInfo_resultTupleScheme extends org.apache.storm.thrift.scheme.TupleScheme<getTopologyInfo_result> {
@Override public void write(org.apache.storm.thrift.protocol.TProtocol prot,getTopologyInfo_result struct) throws org.apache.storm.thrift.TException {
org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
java.util.BitSet optionals=new java.util.BitSet();
if (struct.is_set_success()) {
optionals.set(0);
}
if (struct.is_set_e()) {
optionals.set(1);
}
if (struct.is_set_aze()) {
optionals.set(2);
}
oprot.writeBitSet(optionals,3);
if (struct.is_set_success()) {
struct.success.write(oprot);
}
if (struct.is_set_e()) {
struct.e.write(oprot);
}
if (struct.is_set_aze()) {
struct.aze.write(oprot);
}
}
@Override public void read(org.apache.storm.thrift.protocol.TProtocol prot,getTopologyInfo_result struct) throws org.apache.storm.thrift.TException {
org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
java.util.BitSet incoming=iprot.readBitSet(3);
if (incoming.get(0)) {
struct.success=new TopologyInfo();
struct.success.read(iprot);
struct.set_success_isSet(true);
}
if (incoming.get(1)) {
struct.e=new NotAliveException();
struct.e.read(iprot);
struct.set_e_isSet(true);
}
if (incoming.get(2)) {
struct.aze=new AuthorizationException();
struct.aze.read(iprot);
struct.set_aze_isSet(true);
}
}
}
private static <S extends org.apache.storm.thrift.scheme.IScheme>S scheme(org.apache.storm.thrift.protocol.TProtocol proto){
return (org.apache.storm.thrift.scheme.StandardScheme.class.equals(proto.getScheme()) ? STANDARD_SCHEME_FACTORY : TUPLE_SCHEME_FACTORY).getScheme();
}
}
