private static class TopologyPageInfoStandardScheme extends org.apache.storm.thrift.scheme.StandardScheme<TopologyPageInfo> {
  public void read(  org.apache.storm.thrift.protocol.TProtocol iprot,  TopologyPageInfo struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TField schemeField;
    iprot.readStructBegin();
    while (true) {
      schemeField=iprot.readFieldBegin();
      if (schemeField.type == org.apache.storm.thrift.protocol.TType.STOP) {
        break;
      }
switch (schemeField.id) {
case 1:
        if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
          struct.id=iprot.readString();
          struct.set_id_isSet(true);
        }
 else {
          org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
        }
      break;
case 2:
    if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
      struct.name=iprot.readString();
      struct.set_name_isSet(true);
    }
 else {
      org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
    }
  break;
case 3:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.I32) {
  struct.uptime_secs=iprot.readI32();
  struct.set_uptime_secs_isSet(true);
}
 else {
  org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 4:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
struct.status=iprot.readString();
struct.set_status_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 5:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.I32) {
struct.num_tasks=iprot.readI32();
struct.set_num_tasks_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 6:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.I32) {
struct.num_workers=iprot.readI32();
struct.set_num_workers_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 7:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.I32) {
struct.num_executors=iprot.readI32();
struct.set_num_executors_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 8:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
struct.topology_conf=iprot.readString();
struct.set_topology_conf_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 9:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.MAP) {
{
org.apache.storm.thrift.protocol.TMap _map482=iprot.readMapBegin();
struct.id_to_spout_agg_stats=new java.util.HashMap<java.lang.String,ComponentAggregateStats>(2 * _map482.size);
@org.apache.storm.thrift.annotation.Nullable java.lang.String _key483;
@org.apache.storm.thrift.annotation.Nullable ComponentAggregateStats _val484;
for (int _i485=0; _i485 < _map482.size; ++_i485) {
_key483=iprot.readString();
_val484=new ComponentAggregateStats();
_val484.read(iprot);
struct.id_to_spout_agg_stats.put(_key483,_val484);
}
iprot.readMapEnd();
}
struct.set_id_to_spout_agg_stats_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 10:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.MAP) {
{
org.apache.storm.thrift.protocol.TMap _map486=iprot.readMapBegin();
struct.id_to_bolt_agg_stats=new java.util.HashMap<java.lang.String,ComponentAggregateStats>(2 * _map486.size);
@org.apache.storm.thrift.annotation.Nullable java.lang.String _key487;
@org.apache.storm.thrift.annotation.Nullable ComponentAggregateStats _val488;
for (int _i489=0; _i489 < _map486.size; ++_i489) {
_key487=iprot.readString();
_val488=new ComponentAggregateStats();
_val488.read(iprot);
struct.id_to_bolt_agg_stats.put(_key487,_val488);
}
iprot.readMapEnd();
}
struct.set_id_to_bolt_agg_stats_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 11:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
struct.sched_status=iprot.readString();
struct.set_sched_status_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 12:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRUCT) {
struct.topology_stats=new TopologyStats();
struct.topology_stats.read(iprot);
struct.set_topology_stats_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 13:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
struct.owner=iprot.readString();
struct.set_owner_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 14:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRUCT) {
struct.debug_options=new DebugOptions();
struct.debug_options.read(iprot);
struct.set_debug_options_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 15:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.I32) {
struct.replication_count=iprot.readI32();
struct.set_replication_count_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 16:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.LIST) {
{
org.apache.storm.thrift.protocol.TList _list490=iprot.readListBegin();
struct.workers=new java.util.ArrayList<WorkerSummary>(_list490.size);
@org.apache.storm.thrift.annotation.Nullable WorkerSummary _elem491;
for (int _i492=0; _i492 < _list490.size; ++_i492) {
_elem491=new WorkerSummary();
_elem491.read(iprot);
struct.workers.add(_elem491);
}
iprot.readListEnd();
}
struct.set_workers_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 17:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
struct.storm_version=iprot.readString();
struct.set_storm_version_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 18:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
struct.topology_version=iprot.readString();
struct.set_topology_version_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 521:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.DOUBLE) {
struct.requested_memonheap=iprot.readDouble();
struct.set_requested_memonheap_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 522:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.DOUBLE) {
struct.requested_memoffheap=iprot.readDouble();
struct.set_requested_memoffheap_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 523:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.DOUBLE) {
struct.requested_cpu=iprot.readDouble();
struct.set_requested_cpu_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 524:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.DOUBLE) {
struct.assigned_memonheap=iprot.readDouble();
struct.set_assigned_memonheap_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 525:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.DOUBLE) {
struct.assigned_memoffheap=iprot.readDouble();
struct.set_assigned_memoffheap_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 526:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.DOUBLE) {
struct.assigned_cpu=iprot.readDouble();
struct.set_assigned_cpu_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 527:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.DOUBLE) {
struct.requested_regular_on_heap_memory=iprot.readDouble();
struct.set_requested_regular_on_heap_memory_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 528:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.DOUBLE) {
struct.requested_shared_on_heap_memory=iprot.readDouble();
struct.set_requested_shared_on_heap_memory_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 529:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.DOUBLE) {
struct.requested_regular_off_heap_memory=iprot.readDouble();
struct.set_requested_regular_off_heap_memory_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 530:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.DOUBLE) {
struct.requested_shared_off_heap_memory=iprot.readDouble();
struct.set_requested_shared_off_heap_memory_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 531:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.DOUBLE) {
struct.assigned_regular_on_heap_memory=iprot.readDouble();
struct.set_assigned_regular_on_heap_memory_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 532:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.DOUBLE) {
struct.assigned_shared_on_heap_memory=iprot.readDouble();
struct.set_assigned_shared_on_heap_memory_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 533:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.DOUBLE) {
struct.assigned_regular_off_heap_memory=iprot.readDouble();
struct.set_assigned_regular_off_heap_memory_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 534:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.DOUBLE) {
struct.assigned_shared_off_heap_memory=iprot.readDouble();
struct.set_assigned_shared_off_heap_memory_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
default :
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
iprot.readFieldEnd();
}
iprot.readStructEnd();
struct.validate();
}
public void write(org.apache.storm.thrift.protocol.TProtocol oprot,TopologyPageInfo struct) throws org.apache.storm.thrift.TException {
struct.validate();
oprot.writeStructBegin(STRUCT_DESC);
if (struct.id != null) {
oprot.writeFieldBegin(ID_FIELD_DESC);
oprot.writeString(struct.id);
oprot.writeFieldEnd();
}
if (struct.name != null) {
if (struct.is_set_name()) {
oprot.writeFieldBegin(NAME_FIELD_DESC);
oprot.writeString(struct.name);
oprot.writeFieldEnd();
}
}
if (struct.is_set_uptime_secs()) {
oprot.writeFieldBegin(UPTIME_SECS_FIELD_DESC);
oprot.writeI32(struct.uptime_secs);
oprot.writeFieldEnd();
}
if (struct.status != null) {
if (struct.is_set_status()) {
oprot.writeFieldBegin(STATUS_FIELD_DESC);
oprot.writeString(struct.status);
oprot.writeFieldEnd();
}
}
if (struct.is_set_num_tasks()) {
oprot.writeFieldBegin(NUM_TASKS_FIELD_DESC);
oprot.writeI32(struct.num_tasks);
oprot.writeFieldEnd();
}
if (struct.is_set_num_workers()) {
oprot.writeFieldBegin(NUM_WORKERS_FIELD_DESC);
oprot.writeI32(struct.num_workers);
oprot.writeFieldEnd();
}
if (struct.is_set_num_executors()) {
oprot.writeFieldBegin(NUM_EXECUTORS_FIELD_DESC);
oprot.writeI32(struct.num_executors);
oprot.writeFieldEnd();
}
if (struct.topology_conf != null) {
if (struct.is_set_topology_conf()) {
oprot.writeFieldBegin(TOPOLOGY_CONF_FIELD_DESC);
oprot.writeString(struct.topology_conf);
oprot.writeFieldEnd();
}
}
if (struct.id_to_spout_agg_stats != null) {
if (struct.is_set_id_to_spout_agg_stats()) {
oprot.writeFieldBegin(ID_TO_SPOUT_AGG_STATS_FIELD_DESC);
{
oprot.writeMapBegin(new org.apache.storm.thrift.protocol.TMap(org.apache.storm.thrift.protocol.TType.STRING,org.apache.storm.thrift.protocol.TType.STRUCT,struct.id_to_spout_agg_stats.size()));
for (java.util.Map.Entry<java.lang.String,ComponentAggregateStats> _iter493 : struct.id_to_spout_agg_stats.entrySet()) {
oprot.writeString(_iter493.getKey());
_iter493.getValue().write(oprot);
}
oprot.writeMapEnd();
}
oprot.writeFieldEnd();
}
}
if (struct.id_to_bolt_agg_stats != null) {
if (struct.is_set_id_to_bolt_agg_stats()) {
oprot.writeFieldBegin(ID_TO_BOLT_AGG_STATS_FIELD_DESC);
{
oprot.writeMapBegin(new org.apache.storm.thrift.protocol.TMap(org.apache.storm.thrift.protocol.TType.STRING,org.apache.storm.thrift.protocol.TType.STRUCT,struct.id_to_bolt_agg_stats.size()));
for (java.util.Map.Entry<java.lang.String,ComponentAggregateStats> _iter494 : struct.id_to_bolt_agg_stats.entrySet()) {
oprot.writeString(_iter494.getKey());
_iter494.getValue().write(oprot);
}
oprot.writeMapEnd();
}
oprot.writeFieldEnd();
}
}
if (struct.sched_status != null) {
if (struct.is_set_sched_status()) {
oprot.writeFieldBegin(SCHED_STATUS_FIELD_DESC);
oprot.writeString(struct.sched_status);
oprot.writeFieldEnd();
}
}
if (struct.topology_stats != null) {
if (struct.is_set_topology_stats()) {
oprot.writeFieldBegin(TOPOLOGY_STATS_FIELD_DESC);
struct.topology_stats.write(oprot);
oprot.writeFieldEnd();
}
}
if (struct.owner != null) {
if (struct.is_set_owner()) {
oprot.writeFieldBegin(OWNER_FIELD_DESC);
oprot.writeString(struct.owner);
oprot.writeFieldEnd();
}
}
if (struct.debug_options != null) {
if (struct.is_set_debug_options()) {
oprot.writeFieldBegin(DEBUG_OPTIONS_FIELD_DESC);
struct.debug_options.write(oprot);
oprot.writeFieldEnd();
}
}
if (struct.is_set_replication_count()) {
oprot.writeFieldBegin(REPLICATION_COUNT_FIELD_DESC);
oprot.writeI32(struct.replication_count);
oprot.writeFieldEnd();
}
if (struct.workers != null) {
if (struct.is_set_workers()) {
oprot.writeFieldBegin(WORKERS_FIELD_DESC);
{
oprot.writeListBegin(new org.apache.storm.thrift.protocol.TList(org.apache.storm.thrift.protocol.TType.STRUCT,struct.workers.size()));
for (WorkerSummary _iter495 : struct.workers) {
_iter495.write(oprot);
}
oprot.writeListEnd();
}
oprot.writeFieldEnd();
}
}
if (struct.storm_version != null) {
if (struct.is_set_storm_version()) {
oprot.writeFieldBegin(STORM_VERSION_FIELD_DESC);
oprot.writeString(struct.storm_version);
oprot.writeFieldEnd();
}
}
if (struct.topology_version != null) {
if (struct.is_set_topology_version()) {
oprot.writeFieldBegin(TOPOLOGY_VERSION_FIELD_DESC);
oprot.writeString(struct.topology_version);
oprot.writeFieldEnd();
}
}
if (struct.is_set_requested_memonheap()) {
oprot.writeFieldBegin(REQUESTED_MEMONHEAP_FIELD_DESC);
oprot.writeDouble(struct.requested_memonheap);
oprot.writeFieldEnd();
}
if (struct.is_set_requested_memoffheap()) {
oprot.writeFieldBegin(REQUESTED_MEMOFFHEAP_FIELD_DESC);
oprot.writeDouble(struct.requested_memoffheap);
oprot.writeFieldEnd();
}
if (struct.is_set_requested_cpu()) {
oprot.writeFieldBegin(REQUESTED_CPU_FIELD_DESC);
oprot.writeDouble(struct.requested_cpu);
oprot.writeFieldEnd();
}
if (struct.is_set_assigned_memonheap()) {
oprot.writeFieldBegin(ASSIGNED_MEMONHEAP_FIELD_DESC);
oprot.writeDouble(struct.assigned_memonheap);
oprot.writeFieldEnd();
}
if (struct.is_set_assigned_memoffheap()) {
oprot.writeFieldBegin(ASSIGNED_MEMOFFHEAP_FIELD_DESC);
oprot.writeDouble(struct.assigned_memoffheap);
oprot.writeFieldEnd();
}
if (struct.is_set_assigned_cpu()) {
oprot.writeFieldBegin(ASSIGNED_CPU_FIELD_DESC);
oprot.writeDouble(struct.assigned_cpu);
oprot.writeFieldEnd();
}
if (struct.is_set_requested_regular_on_heap_memory()) {
oprot.writeFieldBegin(REQUESTED_REGULAR_ON_HEAP_MEMORY_FIELD_DESC);
oprot.writeDouble(struct.requested_regular_on_heap_memory);
oprot.writeFieldEnd();
}
if (struct.is_set_requested_shared_on_heap_memory()) {
oprot.writeFieldBegin(REQUESTED_SHARED_ON_HEAP_MEMORY_FIELD_DESC);
oprot.writeDouble(struct.requested_shared_on_heap_memory);
oprot.writeFieldEnd();
}
if (struct.is_set_requested_regular_off_heap_memory()) {
oprot.writeFieldBegin(REQUESTED_REGULAR_OFF_HEAP_MEMORY_FIELD_DESC);
oprot.writeDouble(struct.requested_regular_off_heap_memory);
oprot.writeFieldEnd();
}
if (struct.is_set_requested_shared_off_heap_memory()) {
oprot.writeFieldBegin(REQUESTED_SHARED_OFF_HEAP_MEMORY_FIELD_DESC);
oprot.writeDouble(struct.requested_shared_off_heap_memory);
oprot.writeFieldEnd();
}
if (struct.is_set_assigned_regular_on_heap_memory()) {
oprot.writeFieldBegin(ASSIGNED_REGULAR_ON_HEAP_MEMORY_FIELD_DESC);
oprot.writeDouble(struct.assigned_regular_on_heap_memory);
oprot.writeFieldEnd();
}
if (struct.is_set_assigned_shared_on_heap_memory()) {
oprot.writeFieldBegin(ASSIGNED_SHARED_ON_HEAP_MEMORY_FIELD_DESC);
oprot.writeDouble(struct.assigned_shared_on_heap_memory);
oprot.writeFieldEnd();
}
if (struct.is_set_assigned_regular_off_heap_memory()) {
oprot.writeFieldBegin(ASSIGNED_REGULAR_OFF_HEAP_MEMORY_FIELD_DESC);
oprot.writeDouble(struct.assigned_regular_off_heap_memory);
oprot.writeFieldEnd();
}
if (struct.is_set_assigned_shared_off_heap_memory()) {
oprot.writeFieldBegin(ASSIGNED_SHARED_OFF_HEAP_MEMORY_FIELD_DESC);
oprot.writeDouble(struct.assigned_shared_off_heap_memory);
oprot.writeFieldEnd();
}
oprot.writeFieldStop();
oprot.writeStructEnd();
}
}
