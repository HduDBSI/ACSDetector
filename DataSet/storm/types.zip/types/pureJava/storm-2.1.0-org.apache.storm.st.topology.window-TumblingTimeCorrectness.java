/** 
 * Computes sliding window sum.
 */
public class TumblingTimeCorrectness implements TestableTopology {
  private static final Logger LOG=LoggerFactory.getLogger(TumblingTimeCorrectness.class);
  private final int tumbleSec;
  private final String spoutName;
  private final int spoutExecutors=2;
  private final String boltName;
  private final int boltExecutors=1;
  public TumblingTimeCorrectness(  int tumbleSec){
    this.tumbleSec=tumbleSec;
    final String prefix=this.getClass().getSimpleName() + "-tumbleSec" + tumbleSec;
    spoutName=prefix + "IncrementingSpout";
    boltName=prefix + "VerificationBolt";
  }
  @Override public String getBoltName(){
    return boltName;
  }
  @Override public String getSpoutName(){
    return spoutName;
  }
  @Override public int getBoltExecutors(){
    return boltExecutors;
  }
  @Override public int getSpoutExecutors(){
    return spoutExecutors;
  }
  @Override public StormTopology newTopology(){
    TopologyBuilder builder=new TopologyBuilder();
    builder.setSpout(getSpoutName(),new TimeDataIncrementingSpout(),spoutExecutors);
    builder.setBolt(getBoltName(),new TimeDataVerificationBolt().withTumblingWindow(new BaseWindowedBolt.Duration(tumbleSec,TimeUnit.SECONDS)).withLag(new BaseWindowedBolt.Duration(10,TimeUnit.SECONDS)).withTimestampField(TimeData.getTimestampFieldName()),boltExecutors).globalGrouping(getSpoutName());
    return builder.createTopology();
  }
}
