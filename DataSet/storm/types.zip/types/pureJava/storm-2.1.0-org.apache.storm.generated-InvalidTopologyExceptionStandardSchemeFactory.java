private static class InvalidTopologyExceptionStandardSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public InvalidTopologyExceptionStandardScheme getScheme(){
    return new InvalidTopologyExceptionStandardScheme();
  }
}
