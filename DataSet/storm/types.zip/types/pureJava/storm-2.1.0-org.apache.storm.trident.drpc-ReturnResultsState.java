public static class ReturnResultsState {
  List<TridentTuple> results=new ArrayList<>();
  String returnInfo;
  @Override public String toString(){
    return ToStringBuilder.reflectionToString(this);
  }
}
