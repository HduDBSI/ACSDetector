/** 
 * Validates each entry in a list.
 */
public static class ListEntryTypeValidator extends Validator {
  private Class<?> type;
  public ListEntryTypeValidator(  Map<String,Object> params){
    this.type=(Class<?>)params.get(ConfigValidationAnnotations.ValidatorParams.TYPE);
  }
  public static void validateField(  String name,  Class<?> type,  Object o){
    ConfigValidationUtils.NestableFieldValidator validator=ConfigValidationUtils.listFv(type,false);
    validator.validateField(name,o);
  }
  @Override public void validateField(  String name,  Object o){
    validateField(name,this.type,o);
  }
}
