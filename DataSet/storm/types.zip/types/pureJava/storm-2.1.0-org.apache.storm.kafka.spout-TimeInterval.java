public static class TimeInterval implements Serializable {
  private final long lengthNanos;
  private final TimeUnit timeUnit;
  private final long length;
  /** 
 * Creates a new TimeInterval.
 * @param length length of the time interval in the units specified by {@link TimeUnit}
 * @param timeUnit unit used to specify a time interval on which to specify a time unit
 */
  public TimeInterval(  long length,  TimeUnit timeUnit){
    this.lengthNanos=timeUnit.toNanos(length);
    this.timeUnit=timeUnit;
    this.length=length;
  }
  public static TimeInterval seconds(  long length){
    return new TimeInterval(length,TimeUnit.SECONDS);
  }
  public static TimeInterval milliSeconds(  long length){
    return new TimeInterval(length,TimeUnit.MILLISECONDS);
  }
  public static TimeInterval microSeconds(  long length){
    return new TimeInterval(length,TimeUnit.MICROSECONDS);
  }
  public long lengthNanos(){
    return lengthNanos;
  }
  public TimeUnit timeUnit(){
    return timeUnit;
  }
  @Override public String toString(){
    return "TimeInterval{" + "length=" + length + ", timeUnit="+ timeUnit+ '}';
  }
}
