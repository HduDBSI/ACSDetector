/** 
 * Container for managing JedisCluster. <p/> Note that JedisCluster doesn't need to be pooled since it's thread-safe and it stores pools internally.
 */
public class JedisClusterContainer implements JedisCommandsInstanceContainer {
  private JedisCluster jedisCluster;
  /** 
 * Constructor
 * @param jedisCluster JedisCluster instance
 */
  public JedisClusterContainer(  JedisCluster jedisCluster){
    this.jedisCluster=jedisCluster;
  }
  /** 
 * {@inheritDoc}
 */
  @Override public JedisCommands getInstance(){
    return this.jedisCluster;
  }
  /** 
 * {@inheritDoc}
 */
  @Override public void returnInstance(  JedisCommands jedisCommands){
  }
  /** 
 * {@inheritDoc}
 */
  @Override public void close(){
    try {
      this.jedisCluster.close();
    }
 catch (    IOException e) {
      e.printStackTrace();
    }
  }
}
