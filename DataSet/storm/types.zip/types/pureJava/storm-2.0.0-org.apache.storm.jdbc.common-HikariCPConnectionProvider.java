public class HikariCPConnectionProvider implements ConnectionProvider {
  private static final Logger LOG=LoggerFactory.getLogger(HikariCPConnectionProvider.class);
  private Map<String,Object> configMap;
  private transient HikariDataSource dataSource;
  public HikariCPConnectionProvider(  Map<String,Object> hikariCPConfigMap){
    this.configMap=hikariCPConfigMap;
  }
  @Override public synchronized void prepare(){
    if (dataSource == null) {
      Properties properties=new Properties();
      properties.putAll(configMap);
      HikariConfig config=new HikariConfig(properties);
      if (properties.containsKey("dataSource.url")) {
        LOG.info("DataSource Url: " + properties.getProperty("dataSource.url"));
      }
 else       if (config.getJdbcUrl() != null) {
        LOG.info("JDBC Url: " + config.getJdbcUrl());
      }
      this.dataSource=new HikariDataSource(config);
      this.dataSource.setAutoCommit(false);
    }
  }
  @Override public Connection getConnection(){
    try {
      return this.dataSource.getConnection();
    }
 catch (    SQLException e) {
      throw new RuntimeException(e);
    }
  }
  @Override public void cleanup(){
    if (dataSource != null) {
      dataSource.close();
    }
  }
}
