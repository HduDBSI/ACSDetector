private static class getComponentPendingProfileActions_argsTupleSchemeFactory implements org.apache.storm.thrift.scheme.SchemeFactory {
  public getComponentPendingProfileActions_argsTupleScheme getScheme(){
    return new getComponentPendingProfileActions_argsTupleScheme();
  }
}
