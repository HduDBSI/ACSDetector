/** 
 * This abstract class can be extended to implement concrete classes capable of (de)serializing generic avro objects across a Topology.  The methods in the AvroSchemaRegistry interface specify how schemas can be mapped to unique identifiers and vice versa.  Implementations based on pre-defining schemas or utilizing an external schema registry are provided.
 */
public abstract class AbstractAvroSerializer extends Serializer<GenericContainer> implements AvroSchemaRegistry {
  @Override public void write(  Kryo kryo,  Output output,  GenericContainer record){
    String fingerPrint=this.getFingerprint(record.getSchema());
    output.writeString(fingerPrint);
    GenericDatumWriter<GenericContainer> writer=new GenericDatumWriter<>(record.getSchema());
    BinaryEncoder encoder=EncoderFactory.get().directBinaryEncoder(output,null);
    try {
      writer.write(record,encoder);
    }
 catch (    IOException e) {
      throw new RuntimeException(e);
    }
  }
  @Override public GenericContainer read(  Kryo kryo,  Input input,  Class<GenericContainer> someClass){
    Schema theSchema=this.getSchema(input.readString());
    GenericDatumReader<GenericContainer> reader=new GenericDatumReader<>(theSchema);
    Decoder decoder=DecoderFactory.get().directBinaryDecoder(input,null);
    GenericContainer foo;
    try {
      foo=reader.read(null,decoder);
    }
 catch (    IOException e) {
      throw new RuntimeException(e);
    }
    return foo;
  }
}
