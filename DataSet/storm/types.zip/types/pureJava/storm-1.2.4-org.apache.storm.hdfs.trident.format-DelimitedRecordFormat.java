/** 
 * RecordFormat implementation that uses field and record delimiters. By default uses a comma (",") as the field delimiter and a newline ("\n") as the record delimiter.
 */
public class DelimitedRecordFormat implements RecordFormat {
  public static final String DEFAULT_FIELD_DELIMITER=",";
  public static final String DEFAULT_RECORD_DELIMITER="\n";
  private String fieldDelimiter=DEFAULT_FIELD_DELIMITER;
  private String recordDelimiter=DEFAULT_RECORD_DELIMITER;
  private Fields fields=null;
  /** 
 * Only output the specified fields.
 * @param fields
 * @return
 */
  public DelimitedRecordFormat withFields(  Fields fields){
    this.fields=fields;
    return this;
  }
  /** 
 * Overrides the default field delimiter.
 * @param delimiter
 * @return
 */
  public DelimitedRecordFormat withFieldDelimiter(  String delimiter){
    this.fieldDelimiter=delimiter;
    return this;
  }
  /** 
 * Overrides the default record delimiter.
 * @param delimiter
 * @return
 */
  public DelimitedRecordFormat withRecordDelimiter(  String delimiter){
    this.recordDelimiter=delimiter;
    return this;
  }
  @Override public byte[] format(  TridentTuple tuple){
    StringBuilder sb=new StringBuilder();
    int size=this.fields.size();
    for (int i=0; i < size; i++) {
      sb.append(tuple.getValueByField(fields.get(i)));
      if (i != size - 1) {
        sb.append(this.fieldDelimiter);
      }
    }
    sb.append(this.recordDelimiter);
    return sb.toString().getBytes();
  }
}
