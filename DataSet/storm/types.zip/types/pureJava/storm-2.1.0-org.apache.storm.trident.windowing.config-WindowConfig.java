/** 
 * Windowing configuration with window and sliding length.
 */
public interface WindowConfig extends Serializable {
  /** 
 * Returns the length of the window.
 */
  public int getWindowLength();
  /** 
 * Returns the sliding length of the moving window.
 */
  public int getSlidingLength();
  /** 
 * Gives the type of windowing. It can be any of  {@code Type} values.
 */
  public <T>WindowStrategy<T> getWindowStrategy();
  public void validate();
  public enum Type {  SLIDING_COUNT,   TUMBLING_COUNT,   SLIDING_DURATION,   TUMBLING_DURATION}
}
