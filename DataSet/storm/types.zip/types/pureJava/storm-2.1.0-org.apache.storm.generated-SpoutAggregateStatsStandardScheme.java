private static class SpoutAggregateStatsStandardScheme extends org.apache.storm.thrift.scheme.StandardScheme<SpoutAggregateStats> {
  public void read(  org.apache.storm.thrift.protocol.TProtocol iprot,  SpoutAggregateStats struct) throws org.apache.storm.thrift.TException {
    org.apache.storm.thrift.protocol.TField schemeField;
    iprot.readStructBegin();
    while (true) {
      schemeField=iprot.readFieldBegin();
      if (schemeField.type == org.apache.storm.thrift.protocol.TType.STOP) {
        break;
      }
switch (schemeField.id) {
case 1:
        if (schemeField.type == org.apache.storm.thrift.protocol.TType.DOUBLE) {
          struct.complete_latency_ms=iprot.readDouble();
          struct.set_complete_latency_ms_isSet(true);
        }
 else {
          org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
        }
      break;
default :
    org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
iprot.readFieldEnd();
}
iprot.readStructEnd();
struct.validate();
}
public void write(org.apache.storm.thrift.protocol.TProtocol oprot,SpoutAggregateStats struct) throws org.apache.storm.thrift.TException {
struct.validate();
oprot.writeStructBegin(STRUCT_DESC);
if (struct.is_set_complete_latency_ms()) {
oprot.writeFieldBegin(COMPLETE_LATENCY_MS_FIELD_DESC);
oprot.writeDouble(struct.complete_latency_ms);
oprot.writeFieldEnd();
}
oprot.writeFieldStop();
oprot.writeStructEnd();
}
}
