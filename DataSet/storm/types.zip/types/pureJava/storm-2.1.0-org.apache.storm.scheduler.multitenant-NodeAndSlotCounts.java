public static class NodeAndSlotCounts {
  public final int _nodes;
  public final int _slots;
  public NodeAndSlotCounts(  int nodes,  int slots){
    _nodes=nodes;
    _slots=slots;
  }
}
