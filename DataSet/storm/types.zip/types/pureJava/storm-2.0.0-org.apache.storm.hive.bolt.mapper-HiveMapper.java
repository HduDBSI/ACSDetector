/** 
 * Maps a <code>org.apache.storm.tuple.Tupe</code> object to a row in an Hive table.
 */
public interface HiveMapper extends Serializable {
  /** 
 * Given a endPoint, returns a RecordWriter with columnNames.
 * @param endPoint
 * @return
 */
  RecordWriter createRecordWriter(  HiveEndPoint endPoint) throws StreamingException, IOException, ClassNotFoundException ;
  void write(  TransactionBatch txnBatch,  Tuple tuple) throws StreamingException, IOException, InterruptedException ;
  /** 
 * Given a tuple, return a hive partition values list.
 * @param tuple
 * @return List<String>
 */
  List<String> mapPartitions(  Tuple tuple);
  /** 
 * Given a tuple, maps to a HiveRecord based on columnFields
 * @Param Tuple
 * @return byte[]
 */
  byte[] mapRecord(  Tuple tuple);
  /** 
 * Given a TridetnTuple, return a hive partition values list.
 * @param tuple
 * @return List<String>
 */
  List<String> mapPartitions(  TridentTuple tuple);
  /** 
 * Given a TridentTuple, maps to a HiveRecord based on columnFields
 * @Param TridentTuple
 * @return byte[]
 */
  byte[] mapRecord(  TridentTuple tuple);
}
