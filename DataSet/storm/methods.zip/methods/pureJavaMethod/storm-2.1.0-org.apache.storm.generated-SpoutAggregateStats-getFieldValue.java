@org.apache.storm.thrift.annotation.Nullable public java.lang.Object getFieldValue(_Fields field){
switch (field) {
case COMPLETE_LATENCY_MS:
    return get_complete_latency_ms();
}
throw new java.lang.IllegalStateException();
}
