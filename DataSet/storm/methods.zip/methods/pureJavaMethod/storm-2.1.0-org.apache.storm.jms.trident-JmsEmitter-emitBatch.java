@Override public void emitBatch(TransactionAttempt tx,JmsBatch coordinatorMeta,TridentCollector collector){
  long now=System.currentTimeMillis();
  if (now - lastRotate > rotateTimeMillis) {
    Map<Long,List<Message>> failed=batchMessageMap.rotate();
    for (    Long id : failed.keySet()) {
      log.warn("TIMED OUT batch with transaction id " + id + " for "+ name);
      fail(id,failed.get(id));
    }
    lastRotate=now;
  }
  if (batchMessageMap.containsKey(tx.getTransactionId())) {
    log.warn("FAILED duplicate batch with transaction id " + tx.getTransactionId() + "/"+ tx.getAttemptId()+ " for "+ name);
    fail(tx.getTransactionId(),batchMessageMap.get(tx.getTransactionId()));
  }
  List<Message> batchMessages=new ArrayList<Message>();
  for (int index=0; index < maxBatchSize; index++) {
    Message msg=queue.poll();
    if (msg == null) {
      Utils.sleep(50);
      break;
    }
    try {
      if (TridentJmsSpout.this.jmsAcknowledgeMode != Session.AUTO_ACKNOWLEDGE) {
        batchMessages.add(msg);
      }
      Values tuple=tupleProducer.toTuple(msg);
      collector.emit(tuple);
    }
 catch (    JMSException e) {
      log.warn("Failed to emit message, could not retrieve data for " + name + ": "+ e);
    }
  }
  if (!batchMessages.isEmpty()) {
    log.debug("Emitting batch with transaction id " + tx.getTransactionId() + "/"+ tx.getAttemptId()+ " and size "+ batchMessages.size()+ " for "+ name);
  }
 else {
    log.trace("No items to acknowledge for batch with transaction id " + tx.getTransactionId() + "/"+ tx.getAttemptId()+ " for "+ name);
  }
  batchMessageMap.put(tx.getTransactionId(),batchMessages);
}
