public void set_replication_factor_isSet(boolean value){
  __isset_bitfield=org.apache.storm.thrift.EncodingUtils.setBit(__isset_bitfield,__REPLICATION_FACTOR_ISSET_ID,value);
}
