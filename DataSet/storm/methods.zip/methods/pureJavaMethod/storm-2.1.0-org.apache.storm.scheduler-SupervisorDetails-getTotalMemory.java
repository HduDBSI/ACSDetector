/** 
 * Get the total Memory on this supervisor in MB.
 */
public double getTotalMemory(){
  return totalResources.getTotalMemoryMb();
}
