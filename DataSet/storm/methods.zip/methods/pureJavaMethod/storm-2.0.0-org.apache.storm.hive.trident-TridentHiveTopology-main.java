public static void main(String[] args) throws Exception {
  String metaStoreURI=args[0];
  String dbName=args[1];
  String tblName=args[2];
  Config conf=new Config();
  conf.setMaxSpoutPending(5);
  String topoName="tridentHiveTopology";
  String keytab=null;
  String principal=null;
  if (args.length > 3) {
    topoName=args[3];
  }
  if (args.length == 6) {
    keytab=args[4];
    principal=args[5];
  }
 else   if (args.length != 3 && args.length != 4) {
    LOG.info("Usage: TridentHiveTopology metastoreURI dbName tableName [topologyName] [keytab principal]");
    return;
  }
  try {
    StormSubmitter.submitTopology(args[3],conf,buildTopology(metaStoreURI,dbName,tblName,null,null));
  }
 catch (  SubmitterHookException e) {
    LOG.warn("Topology is submitted but invoking ISubmitterHook failed",e);
  }
catch (  Exception e) {
    LOG.warn("Failed to submit topology ",e);
  }
}
