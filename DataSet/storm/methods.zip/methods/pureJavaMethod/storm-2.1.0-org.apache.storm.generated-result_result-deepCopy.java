public result_result deepCopy(){
  return new result_result(this);
}
