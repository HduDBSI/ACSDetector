public void set_user(@org.apache.storm.thrift.annotation.Nullable java.lang.String user){
  this.user=user;
}
