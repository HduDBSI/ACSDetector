@Test public void testWriteBasic() throws Exception {
  DelimitedRecordHiveMapper mapper=new MockedDelemiteredRecordHiveMapper().withColumnFields(new Fields(colNames)).withPartitionFields(new Fields(partNames));
  HiveEndPoint endPoint=new HiveEndPoint(metaStoreURI,dbName,tblName,Arrays.asList(partitionVals));
  TestingHiveWriter writer=new TestingHiveWriter(endPoint,10,true,timeout,callTimeoutPool,mapper,ugi,false);
  writeTuples(writer,mapper,3);
  writer.flush(false);
  writer.close();
  Mockito.verify(writer.getMockedTxBatch(),Mockito.times(3)).write(Mockito.any(byte[].class));
}
