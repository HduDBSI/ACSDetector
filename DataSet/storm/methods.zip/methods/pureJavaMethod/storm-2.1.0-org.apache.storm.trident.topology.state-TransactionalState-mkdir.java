public void mkdir(String path){
  setData(path,7);
}
