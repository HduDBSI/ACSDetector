public BoltDeclarer globalGrouping(String componentId,String streamId){
  return grouping(componentId,streamId,Grouping.fields(new ArrayList<String>()));
}
