@Override public SqlCall createCall(SqlLiteral functionQualifier,SqlParserPos pos,SqlNode... o){
  assert functionQualifier == null;
  return new SqlCreateFunction(pos,(SqlIdentifier)o[0],o[1],o[2]);
}
