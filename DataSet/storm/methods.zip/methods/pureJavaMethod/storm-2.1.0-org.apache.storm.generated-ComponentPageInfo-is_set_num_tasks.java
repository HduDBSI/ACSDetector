/** 
 * Returns true if field num_tasks is set (has been assigned a value) and false otherwise 
 */
public boolean is_set_num_tasks(){
  return org.apache.storm.thrift.EncodingUtils.testBit(__isset_bitfield,__NUM_TASKS_ISSET_ID);
}
