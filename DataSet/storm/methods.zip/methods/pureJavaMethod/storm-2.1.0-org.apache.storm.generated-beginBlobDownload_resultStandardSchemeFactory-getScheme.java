public beginBlobDownload_resultStandardScheme getScheme(){
  return new beginBlobDownload_resultStandardScheme();
}
