@Override public void ack(Object msgId){
  if (ackFailDelegate != null) {
    ackFailDelegate.ack(msgId);
  }
}
