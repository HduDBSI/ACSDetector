public void validate() throws org.apache.storm.thrift.TException {
}
