public boolean get_bool_arg(){
  if (getSetField() == _Fields.BOOL_ARG) {
    return (java.lang.Boolean)getFieldValue();
  }
 else {
    throw new java.lang.RuntimeException("Cannot get field 'bool_arg' because union is currently set to " + getFieldDesc(getSetField()).name);
  }
}
