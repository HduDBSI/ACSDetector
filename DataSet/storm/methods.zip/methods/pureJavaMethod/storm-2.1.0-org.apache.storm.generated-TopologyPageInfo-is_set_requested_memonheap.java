/** 
 * Returns true if field requested_memonheap is set (has been assigned a value) and false otherwise 
 */
public boolean is_set_requested_memonheap(){
  return org.apache.storm.thrift.EncodingUtils.testBit(__isset_bitfield,__REQUESTED_MEMONHEAP_ISSET_ID);
}
