private Set<String> getBlacklistHosts(Cluster cluster,Set<String> blacklistIds){
  Set<String> blacklistHostSet=new HashSet<>();
  for (  String supervisor : blacklistIds) {
    String host=cluster.getHost(supervisor);
    if (host != null) {
      blacklistHostSet.add(host);
    }
 else {
      LOG.info("supervisor {} is not alive, do not need to add to blacklist.",supervisor);
    }
  }
  return blacklistHostSet;
}
