/** 
 * Returns true if field port is set (has been assigned a value) and false otherwise 
 */
public boolean is_set_port(){
  return org.apache.storm.thrift.EncodingUtils.testBit(__isset_bitfield,__PORT_ISSET_ID);
}
