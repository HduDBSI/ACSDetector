public T getVal(){
  return val;
}
