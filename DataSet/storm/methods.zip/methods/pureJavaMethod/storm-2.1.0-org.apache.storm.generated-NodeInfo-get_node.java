@org.apache.storm.thrift.annotation.Nullable public java.lang.String get_node(){
  return this.node;
}
