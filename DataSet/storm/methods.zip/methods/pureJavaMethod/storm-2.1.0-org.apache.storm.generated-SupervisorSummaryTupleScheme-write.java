@Override public void write(org.apache.storm.thrift.protocol.TProtocol prot,SupervisorSummary struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
  oprot.writeString(struct.host);
  oprot.writeI32(struct.uptime_secs);
  oprot.writeI32(struct.num_workers);
  oprot.writeI32(struct.num_used_workers);
  oprot.writeString(struct.supervisor_id);
  java.util.BitSet optionals=new java.util.BitSet();
  if (struct.is_set_version()) {
    optionals.set(0);
  }
  if (struct.is_set_total_resources()) {
    optionals.set(1);
  }
  if (struct.is_set_used_mem()) {
    optionals.set(2);
  }
  if (struct.is_set_used_cpu()) {
    optionals.set(3);
  }
  if (struct.is_set_fragmented_mem()) {
    optionals.set(4);
  }
  if (struct.is_set_fragmented_cpu()) {
    optionals.set(5);
  }
  oprot.writeBitSet(optionals,6);
  if (struct.is_set_version()) {
    oprot.writeString(struct.version);
  }
  if (struct.is_set_total_resources()) {
{
      oprot.writeI32(struct.total_resources.size());
      for (      java.util.Map.Entry<java.lang.String,java.lang.Double> _iter131 : struct.total_resources.entrySet()) {
        oprot.writeString(_iter131.getKey());
        oprot.writeDouble(_iter131.getValue());
      }
    }
  }
  if (struct.is_set_used_mem()) {
    oprot.writeDouble(struct.used_mem);
  }
  if (struct.is_set_used_cpu()) {
    oprot.writeDouble(struct.used_cpu);
  }
  if (struct.is_set_fragmented_mem()) {
    oprot.writeDouble(struct.fragmented_mem);
  }
  if (struct.is_set_fragmented_cpu()) {
    oprot.writeDouble(struct.fragmented_cpu);
  }
}
