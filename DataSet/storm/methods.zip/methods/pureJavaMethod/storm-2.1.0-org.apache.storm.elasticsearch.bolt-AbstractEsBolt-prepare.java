@Override public void prepare(Map<String,Object> map,TopologyContext topologyContext,OutputCollector outputCollector){
  try {
    this.collector=outputCollector;
synchronized (AbstractEsBolt.class) {
      if (client == null) {
        client=new StormElasticSearchClient(esConfig).construct();
      }
    }
  }
 catch (  Exception e) {
    LOG.warn("unable to initialize EsBolt ",e);
  }
}
