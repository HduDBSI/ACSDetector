public void unset_id(){
  this.id=null;
}
