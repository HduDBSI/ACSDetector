@Override public void read(org.apache.storm.thrift.protocol.TProtocol prot,activate_result struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
  java.util.BitSet incoming=iprot.readBitSet(2);
  if (incoming.get(0)) {
    struct.e=new NotAliveException();
    struct.e.read(iprot);
    struct.set_e_isSet(true);
  }
  if (incoming.get(1)) {
    struct.aze=new AuthorizationException();
    struct.aze.read(iprot);
    struct.set_aze_isSet(true);
  }
}
