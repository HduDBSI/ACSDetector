public Options withMessageProducer(JmsMessageProducer msgProducer){
  this.msgProducer=msgProducer;
  return this;
}
