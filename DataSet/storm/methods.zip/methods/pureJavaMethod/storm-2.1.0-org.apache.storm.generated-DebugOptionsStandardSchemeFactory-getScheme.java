public DebugOptionsStandardScheme getScheme(){
  return new DebugOptionsStandardScheme();
}
