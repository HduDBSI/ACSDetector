public boolean equals(TopologyInfo that){
  if (that == null)   return false;
  if (this == that)   return true;
  boolean this_present_id=true && this.is_set_id();
  boolean that_present_id=true && that.is_set_id();
  if (this_present_id || that_present_id) {
    if (!(this_present_id && that_present_id))     return false;
    if (!this.id.equals(that.id))     return false;
  }
  boolean this_present_name=true && this.is_set_name();
  boolean that_present_name=true && that.is_set_name();
  if (this_present_name || that_present_name) {
    if (!(this_present_name && that_present_name))     return false;
    if (!this.name.equals(that.name))     return false;
  }
  boolean this_present_uptime_secs=true;
  boolean that_present_uptime_secs=true;
  if (this_present_uptime_secs || that_present_uptime_secs) {
    if (!(this_present_uptime_secs && that_present_uptime_secs))     return false;
    if (this.uptime_secs != that.uptime_secs)     return false;
  }
  boolean this_present_executors=true && this.is_set_executors();
  boolean that_present_executors=true && that.is_set_executors();
  if (this_present_executors || that_present_executors) {
    if (!(this_present_executors && that_present_executors))     return false;
    if (!this.executors.equals(that.executors))     return false;
  }
  boolean this_present_status=true && this.is_set_status();
  boolean that_present_status=true && that.is_set_status();
  if (this_present_status || that_present_status) {
    if (!(this_present_status && that_present_status))     return false;
    if (!this.status.equals(that.status))     return false;
  }
  boolean this_present_errors=true && this.is_set_errors();
  boolean that_present_errors=true && that.is_set_errors();
  if (this_present_errors || that_present_errors) {
    if (!(this_present_errors && that_present_errors))     return false;
    if (!this.errors.equals(that.errors))     return false;
  }
  boolean this_present_component_debug=true && this.is_set_component_debug();
  boolean that_present_component_debug=true && that.is_set_component_debug();
  if (this_present_component_debug || that_present_component_debug) {
    if (!(this_present_component_debug && that_present_component_debug))     return false;
    if (!this.component_debug.equals(that.component_debug))     return false;
  }
  boolean this_present_storm_version=true && this.is_set_storm_version();
  boolean that_present_storm_version=true && that.is_set_storm_version();
  if (this_present_storm_version || that_present_storm_version) {
    if (!(this_present_storm_version && that_present_storm_version))     return false;
    if (!this.storm_version.equals(that.storm_version))     return false;
  }
  boolean this_present_sched_status=true && this.is_set_sched_status();
  boolean that_present_sched_status=true && that.is_set_sched_status();
  if (this_present_sched_status || that_present_sched_status) {
    if (!(this_present_sched_status && that_present_sched_status))     return false;
    if (!this.sched_status.equals(that.sched_status))     return false;
  }
  boolean this_present_owner=true && this.is_set_owner();
  boolean that_present_owner=true && that.is_set_owner();
  if (this_present_owner || that_present_owner) {
    if (!(this_present_owner && that_present_owner))     return false;
    if (!this.owner.equals(that.owner))     return false;
  }
  boolean this_present_replication_count=true && this.is_set_replication_count();
  boolean that_present_replication_count=true && that.is_set_replication_count();
  if (this_present_replication_count || that_present_replication_count) {
    if (!(this_present_replication_count && that_present_replication_count))     return false;
    if (this.replication_count != that.replication_count)     return false;
  }
  boolean this_present_requested_memonheap=true && this.is_set_requested_memonheap();
  boolean that_present_requested_memonheap=true && that.is_set_requested_memonheap();
  if (this_present_requested_memonheap || that_present_requested_memonheap) {
    if (!(this_present_requested_memonheap && that_present_requested_memonheap))     return false;
    if (this.requested_memonheap != that.requested_memonheap)     return false;
  }
  boolean this_present_requested_memoffheap=true && this.is_set_requested_memoffheap();
  boolean that_present_requested_memoffheap=true && that.is_set_requested_memoffheap();
  if (this_present_requested_memoffheap || that_present_requested_memoffheap) {
    if (!(this_present_requested_memoffheap && that_present_requested_memoffheap))     return false;
    if (this.requested_memoffheap != that.requested_memoffheap)     return false;
  }
  boolean this_present_requested_cpu=true && this.is_set_requested_cpu();
  boolean that_present_requested_cpu=true && that.is_set_requested_cpu();
  if (this_present_requested_cpu || that_present_requested_cpu) {
    if (!(this_present_requested_cpu && that_present_requested_cpu))     return false;
    if (this.requested_cpu != that.requested_cpu)     return false;
  }
  boolean this_present_assigned_memonheap=true && this.is_set_assigned_memonheap();
  boolean that_present_assigned_memonheap=true && that.is_set_assigned_memonheap();
  if (this_present_assigned_memonheap || that_present_assigned_memonheap) {
    if (!(this_present_assigned_memonheap && that_present_assigned_memonheap))     return false;
    if (this.assigned_memonheap != that.assigned_memonheap)     return false;
  }
  boolean this_present_assigned_memoffheap=true && this.is_set_assigned_memoffheap();
  boolean that_present_assigned_memoffheap=true && that.is_set_assigned_memoffheap();
  if (this_present_assigned_memoffheap || that_present_assigned_memoffheap) {
    if (!(this_present_assigned_memoffheap && that_present_assigned_memoffheap))     return false;
    if (this.assigned_memoffheap != that.assigned_memoffheap)     return false;
  }
  boolean this_present_assigned_cpu=true && this.is_set_assigned_cpu();
  boolean that_present_assigned_cpu=true && that.is_set_assigned_cpu();
  if (this_present_assigned_cpu || that_present_assigned_cpu) {
    if (!(this_present_assigned_cpu && that_present_assigned_cpu))     return false;
    if (this.assigned_cpu != that.assigned_cpu)     return false;
  }
  return true;
}
