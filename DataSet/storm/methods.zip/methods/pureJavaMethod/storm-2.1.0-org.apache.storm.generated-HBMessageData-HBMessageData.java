public HBMessageData(HBMessageData other){
  super(other);
}
