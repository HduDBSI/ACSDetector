@Override public State makeState(Map<String,Object> conf,IMetricsContext metrics,int partitionIndex,int numPartitions){
  LOG.info("makeState(partitonIndex={}, numpartitions={}",partitionIndex,numPartitions);
  TridentKafkaState<K,V> state=new TridentKafkaState<>();
  state.withKafkaTopicSelector(this.topicSelector).withTridentTupleToKafkaMapper(this.mapper);
  state.prepare(producerProperties);
  return state;
}
