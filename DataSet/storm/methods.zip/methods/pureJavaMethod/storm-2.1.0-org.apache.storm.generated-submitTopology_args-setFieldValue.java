public void setFieldValue(_Fields field,@org.apache.storm.thrift.annotation.Nullable java.lang.Object value){
switch (field) {
case NAME:
    if (value == null) {
      unset_name();
    }
 else {
      set_name((java.lang.String)value);
    }
  break;
case UPLOADED_JAR_LOCATION:
if (value == null) {
  unset_uploadedJarLocation();
}
 else {
  set_uploadedJarLocation((java.lang.String)value);
}
break;
case JSON_CONF:
if (value == null) {
unset_jsonConf();
}
 else {
set_jsonConf((java.lang.String)value);
}
break;
case TOPOLOGY:
if (value == null) {
unset_topology();
}
 else {
set_topology((StormTopology)value);
}
break;
}
}
