public long get_transferred(){
  return this.transferred;
}
