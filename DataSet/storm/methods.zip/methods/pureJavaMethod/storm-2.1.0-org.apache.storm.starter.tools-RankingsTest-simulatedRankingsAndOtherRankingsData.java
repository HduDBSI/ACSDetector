@DataProvider public Object[][] simulatedRankingsAndOtherRankingsData(){
  return new Object[][]{{Lists.newArrayList(A),Lists.newArrayList(A),Lists.newArrayList(A)},{Lists.newArrayList(A,C),Lists.newArrayList(B,D),Lists.newArrayList(D,C,B,A)},{Lists.newArrayList(B,F,A),Lists.newArrayList(C,D,E),Lists.newArrayList(F,E,D,C,B,A)},{Lists.newArrayList(G,B,F,A,C),Lists.newArrayList(D,E,H),Lists.newArrayList(H,G,F,E,D,C,B,A)}};
}
