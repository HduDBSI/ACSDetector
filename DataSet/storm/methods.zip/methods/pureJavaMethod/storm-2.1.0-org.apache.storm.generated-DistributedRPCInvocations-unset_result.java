public void unset_result(){
  this.result=null;
}
