public List<FixedTuple> getSourceTuples(){
  return tuples;
}
