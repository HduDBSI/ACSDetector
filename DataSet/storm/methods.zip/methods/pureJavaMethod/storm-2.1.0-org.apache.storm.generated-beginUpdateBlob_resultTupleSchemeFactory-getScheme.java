public beginUpdateBlob_resultTupleScheme getScheme(){
  return new beginUpdateBlob_resultTupleScheme();
}
