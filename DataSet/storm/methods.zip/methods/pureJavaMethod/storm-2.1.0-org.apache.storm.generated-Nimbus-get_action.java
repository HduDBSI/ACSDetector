/** 
 * @see ProfileAction
 */
@org.apache.storm.thrift.annotation.Nullable public ProfileAction get_action(){
  return this.action;
}
