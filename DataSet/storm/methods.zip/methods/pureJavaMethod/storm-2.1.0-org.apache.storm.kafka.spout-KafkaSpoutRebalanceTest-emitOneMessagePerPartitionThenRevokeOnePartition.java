private List<KafkaSpoutMessageId> emitOneMessagePerPartitionThenRevokeOnePartition(KafkaSpout<String,String> spout,TopicPartition partitionThatWillBeRevoked,TopicPartition assignedPartition,TopicAssigner topicAssigner){
  spout.open(conf,contextMock,collectorMock);
  spout.activate();
  ArgumentCaptor<ConsumerRebalanceListener> rebalanceListenerCapture=ArgumentCaptor.forClass(ConsumerRebalanceListener.class);
  verify(topicAssigner).assignPartitions(any(),any(),rebalanceListenerCapture.capture());
  ConsumerRebalanceListener consumerRebalanceListener=rebalanceListenerCapture.getValue();
  Set<TopicPartition> assignedPartitions=new HashSet<>();
  assignedPartitions.add(partitionThatWillBeRevoked);
  assignedPartitions.add(assignedPartition);
  consumerRebalanceListener.onPartitionsAssigned(assignedPartitions);
  when(consumerMock.assignment()).thenReturn(assignedPartitions);
  when(consumerMock.poll(anyLong())).thenReturn(new ConsumerRecords<>(Collections.singletonMap(partitionThatWillBeRevoked,SpoutWithMockedConsumerSetupHelper.createRecords(partitionThatWillBeRevoked,0,1)))).thenReturn(new ConsumerRecords<>(Collections.singletonMap(assignedPartition,SpoutWithMockedConsumerSetupHelper.createRecords(assignedPartition,0,1)))).thenReturn(new ConsumerRecords<>(Collections.emptyMap()));
  spout.nextTuple();
  ArgumentCaptor<KafkaSpoutMessageId> messageIdForRevokedPartition=ArgumentCaptor.forClass(KafkaSpoutMessageId.class);
  verify(collectorMock).emit(anyString(),anyList(),messageIdForRevokedPartition.capture());
  reset(collectorMock);
  spout.nextTuple();
  ArgumentCaptor<KafkaSpoutMessageId> messageIdForAssignedPartition=ArgumentCaptor.forClass(KafkaSpoutMessageId.class);
  verify(collectorMock).emit(anyString(),anyList(),messageIdForAssignedPartition.capture());
  consumerRebalanceListener.onPartitionsRevoked(assignedPartitions);
  consumerRebalanceListener.onPartitionsAssigned(Collections.singleton(assignedPartition));
  when(consumerMock.assignment()).thenReturn(Collections.singleton(assignedPartition));
  List<KafkaSpoutMessageId> emittedMessageIds=new ArrayList<>();
  emittedMessageIds.add(messageIdForRevokedPartition.getValue());
  emittedMessageIds.add(messageIdForAssignedPartition.getValue());
  return emittedMessageIds;
}
