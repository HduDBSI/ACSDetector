@Override public void onPartitionsRevoked(Collection<TopicPartition> partitions){
  previousAssignment=partitions;
  LOG.info("Partitions revoked. [consumer-group={}, consumer={}, topic-partitions={}]",kafkaSpoutConfig.getConsumerGroupId(),consumer,partitions);
  if (isAtLeastOnceProcessing()) {
    commitOffsetsForAckedTuples();
  }
}
