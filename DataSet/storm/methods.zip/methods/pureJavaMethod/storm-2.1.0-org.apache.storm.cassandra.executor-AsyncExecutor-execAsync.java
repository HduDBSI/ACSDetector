/** 
 * Asynchronously executes the specified select statements. Results will be passed to the  {@link AsyncResultSetHandler}once each query has succeed or failed.
 */
public SettableFuture<List<T>> execAsync(final List<Statement> statements,final List<T> inputs,Semaphore throttle,final AsyncResultSetHandler<T> handler){
  final SettableFuture<List<T>> settableFuture=SettableFuture.create();
  if (inputs.size() == 0) {
    settableFuture.set(new ArrayList<T>());
    return settableFuture;
  }
  final AsyncContext<T> asyncContext=new AsyncContext<>(inputs,throttle,settableFuture);
  for (int i=0; i < statements.size(); i++) {
    if (asyncContext.acquire()) {
      try {
        pending.incrementAndGet();
        final T input=inputs.get(i);
        final Statement statement=statements.get(i);
        ResultSetFuture future=session.executeAsync(statement);
        Futures.addCallback(future,new FutureCallback<ResultSet>(){
          @Override public void onSuccess(          ResultSet result){
            try {
              handler.success(input,result);
            }
 catch (            Throwable throwable) {
              asyncContext.exception(throwable);
            }
 finally {
              pending.decrementAndGet();
              asyncContext.release();
            }
          }
          @Override public void onFailure(          Throwable throwable){
            try {
              handler.failure(throwable,input);
            }
 catch (            Throwable throwable2) {
              asyncContext.exception(throwable2);
            }
 finally {
              asyncContext.exception(throwable).release();
              pending.decrementAndGet();
              LOG.error(String.format("Failed to execute statement '%s' ",statement),throwable);
            }
          }
        }
,executorService);
      }
 catch (      Throwable throwable) {
        asyncContext.exception(throwable).release();
        pending.decrementAndGet();
        break;
      }
    }
  }
  return settableFuture;
}
