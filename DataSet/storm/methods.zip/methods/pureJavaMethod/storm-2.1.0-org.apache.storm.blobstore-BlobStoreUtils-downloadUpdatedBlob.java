public static boolean downloadUpdatedBlob(Map<String,Object> conf,BlobStore blobStore,String key,Set<NimbusInfo> nimbusInfos) throws TTransportException {
  ClientBlobStore remoteBlobStore;
  AtomicOutputStream out=null;
  boolean isSuccess=false;
  LOG.debug("Download blob NimbusInfos {}",nimbusInfos);
  for (  NimbusInfo nimbusInfo : nimbusInfos) {
    if (isSuccess) {
      break;
    }
    try (NimbusClient client=new NimbusClient(conf,nimbusInfo.getHost(),nimbusInfo.getPort(),null)){
      remoteBlobStore=new NimbusBlobStore();
      remoteBlobStore.setClient(conf,client);
      try (InputStreamWithMeta in=remoteBlobStore.getBlob(key)){
        out=blobStore.updateBlob(key,getNimbusSubject());
        byte[] buffer=new byte[2048];
        int len=0;
        while ((len=in.read(buffer)) > 0) {
          out.write(buffer,0,len);
        }
        out.close();
        out=null;
      }
       isSuccess=true;
    }
 catch (    FileNotFoundException fnf) {
      LOG.warn("Blobstore file for key '{}' does not exist or got deleted before it could be downloaded.",key,fnf);
    }
catch (    IOException|AuthorizationException exception) {
      throw new RuntimeException(exception);
    }
catch (    KeyNotFoundException knf) {
      LOG.info("KeyNotFoundException",knf);
    }
catch (    Exception exp) {
      LOG.error("Exception",exp);
    }
 finally {
      if (out != null) {
        try {
          out.cancel();
        }
 catch (        IOException e) {
        }
      }
    }
  }
  if (!isSuccess) {
    LOG.error("Could not update the blob with key: {}",key);
  }
  return isSuccess;
}
