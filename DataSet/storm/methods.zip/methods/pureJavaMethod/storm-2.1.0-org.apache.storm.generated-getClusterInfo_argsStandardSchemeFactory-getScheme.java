public getClusterInfo_argsStandardScheme getScheme(){
  return new getClusterInfo_argsStandardScheme();
}
