@Override public void setTopologyLogConfig(String stormId,LogConfig logConfig){
  stateStorage.set_data(ClusterUtils.logConfigPath(stormId),Utils.serialize(logConfig),acls);
}
