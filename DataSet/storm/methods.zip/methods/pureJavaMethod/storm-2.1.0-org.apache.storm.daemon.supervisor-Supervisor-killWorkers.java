void killWorkers(Collection<String> workerIds,ContainerLauncher launcher) throws InterruptedException, IOException {
  HashSet<Killable> containers=new HashSet<>();
  for (  String workerId : workerIds) {
    try {
      Killable k=launcher.recoverContainer(workerId,localState);
      if (!k.areAllProcessesDead()) {
        k.kill();
        containers.add(k);
      }
 else {
        k.cleanUp();
      }
    }
 catch (    Exception e) {
      LOG.error("Error trying to kill {}",workerId,e);
    }
  }
  int shutdownSleepSecs=ObjectReader.getInt(conf.get(Config.SUPERVISOR_WORKER_SHUTDOWN_SLEEP_SECS));
  if (!containers.isEmpty()) {
    Time.sleepSecs(shutdownSleepSecs);
  }
  for (  Killable k : containers) {
    try {
      long start=Time.currentTimeMillis();
      while (!k.areAllProcessesDead()) {
        if ((Time.currentTimeMillis() - start) > 10_000) {
          throw new RuntimeException("Giving up on killing " + k + " after "+ (Time.currentTimeMillis() - start)+ " ms");
        }
        k.forceKill();
        Time.sleep(100);
      }
      k.cleanUp();
    }
 catch (    Exception e) {
      LOG.error("Error trying to clean up {}",k,e);
    }
  }
}
