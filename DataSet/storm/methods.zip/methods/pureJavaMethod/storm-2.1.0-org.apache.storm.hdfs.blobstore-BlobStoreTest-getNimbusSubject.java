public static Subject getNimbusSubject(){
  Subject nimbus=new Subject();
  nimbus.getPrincipals().add(new NimbusPrincipal());
  return nimbus;
}
