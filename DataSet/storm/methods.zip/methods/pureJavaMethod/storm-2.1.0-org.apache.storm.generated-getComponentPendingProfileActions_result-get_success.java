@org.apache.storm.thrift.annotation.Nullable public java.util.List<ProfileRequest> get_success(){
  return this.success;
}
