public void setFieldValue(_Fields field,@org.apache.storm.thrift.annotation.Nullable java.lang.Object value){
switch (field) {
case NUM_EXECUTORS:
    if (value == null) {
      unset_num_executors();
    }
 else {
      set_num_executors((java.lang.Integer)value);
    }
  break;
case NUM_TASKS:
if (value == null) {
  unset_num_tasks();
}
 else {
  set_num_tasks((java.lang.Integer)value);
}
break;
case EMITTED:
if (value == null) {
unset_emitted();
}
 else {
set_emitted((java.lang.Long)value);
}
break;
case TRANSFERRED:
if (value == null) {
unset_transferred();
}
 else {
set_transferred((java.lang.Long)value);
}
break;
case ACKED:
if (value == null) {
unset_acked();
}
 else {
set_acked((java.lang.Long)value);
}
break;
case FAILED:
if (value == null) {
unset_failed();
}
 else {
set_failed((java.lang.Long)value);
}
break;
case RESOURCES_MAP:
if (value == null) {
unset_resources_map();
}
 else {
set_resources_map((java.util.Map<java.lang.String,java.lang.Double>)value);
}
break;
}
}
