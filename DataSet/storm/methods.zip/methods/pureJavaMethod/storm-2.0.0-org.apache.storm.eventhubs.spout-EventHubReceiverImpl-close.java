@Override public void close(){
  if (receiver != null) {
    try {
      receiver.close().whenComplete((voidargs,error) -> {
        try {
          if (error != null) {
            logger.error("Exception during receiver close phase" + error.toString());
          }
          ehClient.closeSync();
        }
 catch (        Exception e) {
          logger.error("Exception during ehclient close phase" + e.toString());
        }
      }
).get();
    }
 catch (    InterruptedException e) {
      logger.error("Exception occured during close phase" + e.toString());
    }
catch (    ExecutionException e) {
      logger.error("Exception occured during close phase" + e.toString());
    }
    logger.info("closed eventhub receiver: partitionId=" + partitionId);
    receiver=null;
    ehClient=null;
  }
}
