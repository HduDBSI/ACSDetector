public static void nonEmpty(Collection<?> collection,String message){
  Assert.assertNotNull(collection,message + " Expected collection to be non-null, found: " + collection);
  greater(collection.size(),0,message + " Expected collection to be non-empty, found: " + collection);
}
