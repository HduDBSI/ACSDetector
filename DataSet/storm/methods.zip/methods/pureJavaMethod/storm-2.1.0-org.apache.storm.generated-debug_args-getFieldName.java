public java.lang.String getFieldName(){
  return _fieldName;
}
