@Override public List<List<Values>> batchRetrieve(CassandraState state,List<TridentTuple> tridentTuples){
  return state.batchRetrieve(tridentTuples);
}
