public URL getViewUrl(){
  return viewUrl;
}
