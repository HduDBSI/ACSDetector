public void read(org.apache.storm.thrift.protocol.TProtocol iprot,getBlobMeta_result struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TField schemeField;
  iprot.readStructBegin();
  while (true) {
    schemeField=iprot.readFieldBegin();
    if (schemeField.type == org.apache.storm.thrift.protocol.TType.STOP) {
      break;
    }
switch (schemeField.id) {
case 0:
      if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRUCT) {
        struct.success=new ReadableBlobMeta();
        struct.success.read(iprot);
        struct.set_success_isSet(true);
      }
 else {
        org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
      }
    break;
case 1:
  if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRUCT) {
    struct.aze=new AuthorizationException();
    struct.aze.read(iprot);
    struct.set_aze_isSet(true);
  }
 else {
    org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
  }
break;
case 2:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRUCT) {
struct.knf=new KeyNotFoundException();
struct.knf.read(iprot);
struct.set_knf_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
default :
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
iprot.readFieldEnd();
}
iprot.readStructEnd();
struct.validate();
}
