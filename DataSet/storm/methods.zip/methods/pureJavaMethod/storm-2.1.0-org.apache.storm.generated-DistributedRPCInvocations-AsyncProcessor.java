protected AsyncProcessor(I iface,java.util.Map<java.lang.String,org.apache.storm.thrift.AsyncProcessFunction<I,? extends org.apache.storm.thrift.TBase,?>> processMap){
  super(iface,getProcessMap(processMap));
}
