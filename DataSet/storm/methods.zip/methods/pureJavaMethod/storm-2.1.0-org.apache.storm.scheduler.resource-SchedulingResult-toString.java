@Override public String toString(){
  String ret=null;
  if (isSuccess()) {
    ret="Status: " + this.getStatus() + " message: "+ this.getMessage();
  }
 else {
    ret="Status: " + this.getStatus() + " error message: "+ this.getErrorMessage();
  }
  return ret;
}
