public GroupingDef getGrouping(){
  return grouping;
}
