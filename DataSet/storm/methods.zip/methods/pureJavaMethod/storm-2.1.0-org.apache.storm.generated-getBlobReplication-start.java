public void start(I iface,getBlobReplication_args args,org.apache.storm.thrift.async.AsyncMethodCallback<java.lang.Integer> resultHandler) throws org.apache.storm.thrift.TException {
  iface.getBlobReplication(args.key,resultHandler);
}
