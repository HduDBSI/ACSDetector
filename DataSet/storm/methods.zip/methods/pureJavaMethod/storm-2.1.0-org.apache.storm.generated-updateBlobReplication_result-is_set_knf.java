/** 
 * Returns true if field knf is set (has been assigned a value) and false otherwise 
 */
public boolean is_set_knf(){
  return this.knf != null;
}
