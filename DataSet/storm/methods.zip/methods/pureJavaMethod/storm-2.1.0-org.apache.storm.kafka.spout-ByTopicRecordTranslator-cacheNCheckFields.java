private void cacheNCheckFields(RecordTranslator<K,V> translator){
  for (  String stream : translator.streams()) {
    Fields fromTrans=translator.getFieldsFor(stream);
    Fields cached=streamToFields.get(stream);
    if (cached != null && !fromTrans.equals(cached)) {
      throw new IllegalArgumentException("Stream " + stream + " currently has Fields of "+ cached+ " which is not the same as those being added in "+ fromTrans);
    }
    if (cached == null) {
      streamToFields.put(stream,fromTrans);
    }
  }
}
