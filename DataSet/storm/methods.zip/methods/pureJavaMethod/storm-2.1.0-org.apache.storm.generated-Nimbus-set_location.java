public void set_location(@org.apache.storm.thrift.annotation.Nullable java.lang.String location){
  this.location=location;
}
