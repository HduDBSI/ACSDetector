public void recv_activate() throws NotAliveException, AuthorizationException, org.apache.storm.thrift.TException {
  activate_result result=new activate_result();
  receiveBase(result,"activate");
  if (result.e != null) {
    throw result.e;
  }
  if (result.aze != null) {
    throw result.aze;
  }
  return;
}
