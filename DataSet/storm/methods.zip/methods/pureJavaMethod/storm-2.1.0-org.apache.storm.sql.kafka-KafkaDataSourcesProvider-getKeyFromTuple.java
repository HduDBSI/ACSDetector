@Override public Object getKeyFromTuple(Tuple tuple){
  return tuple.getValue(0);
}
