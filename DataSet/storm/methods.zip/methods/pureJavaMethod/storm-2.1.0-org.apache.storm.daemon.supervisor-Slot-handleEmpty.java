static DynamicState handleEmpty(DynamicState dynamicState,StaticState staticState) throws InterruptedException, IOException {
  assert dynamicState.currentAssignment == null;
  assert dynamicState.container == null;
  assert dynamicState.pendingChangingBlobs.isEmpty();
  assert dynamicState.pendingChangingBlobsAssignment == null;
  assert dynamicState.pendingDownload == null;
  assert dynamicState.pendingLocalization == null;
  if (!equivalent(dynamicState.newAssignment,dynamicState.currentAssignment)) {
    return prepareForNewAssignmentNoWorkersRunning(dynamicState,staticState);
  }
  dynamicState=updateAssignmentIfNeeded(dynamicState);
  if (dynamicState.profileActions != null && !dynamicState.profileActions.isEmpty()) {
    LOG.warn("Dropping {} no topology is running",dynamicState.profileActions);
    dynamicState=dynamicState.withProfileActions(Collections.emptySet(),Collections.emptySet());
  }
  dynamicState=drainAllChangingBlobs(dynamicState);
  Time.sleep(1000);
  return dynamicState;
}
