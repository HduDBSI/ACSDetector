@Override protected SchedulingResult checkSchedulingFeasibility(){
  SchedulingResult res=super.checkSchedulingFeasibility();
  if (res != null) {
    return res;
  }
  if (!isSchedulingFeasible()) {
    return SchedulingResult.failure(SchedulingStatus.FAIL_OTHER,"Scheduling not feasible!");
  }
  return null;
}
