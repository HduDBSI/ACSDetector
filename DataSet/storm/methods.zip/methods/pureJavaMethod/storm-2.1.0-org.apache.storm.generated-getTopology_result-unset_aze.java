public void unset_aze(){
  this.aze=null;
}
