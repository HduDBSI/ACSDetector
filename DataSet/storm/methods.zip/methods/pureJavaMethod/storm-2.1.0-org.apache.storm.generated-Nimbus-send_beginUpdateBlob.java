public void send_beginUpdateBlob(java.lang.String key) throws org.apache.storm.thrift.TException {
  beginUpdateBlob_args args=new beginUpdateBlob_args();
  args.set_key(key);
  sendBase("beginUpdateBlob",args);
}
