@Override public void read(org.apache.storm.thrift.protocol.TProtocol prot,beginUpdateBlob_args struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
  java.util.BitSet incoming=iprot.readBitSet(1);
  if (incoming.get(0)) {
    struct.key=iprot.readString();
    struct.set_key_isSet(true);
  }
}
