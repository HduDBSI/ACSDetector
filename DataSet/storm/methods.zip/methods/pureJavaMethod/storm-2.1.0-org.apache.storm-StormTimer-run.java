@Override public void run(){
  while (this.active.get()) {
    QueueEntry queueEntry=null;
    try {
      queueEntry=this.queue.peek();
      if ((queueEntry != null) && (Time.currentTimeMillis() >= queueEntry.endTimeMs)) {
        this.queue.remove(queueEntry);
        queueEntry.func.run();
      }
 else       if (queueEntry != null) {
        Time.sleep(Math.min(1000,(queueEntry.endTimeMs - Time.currentTimeMillis())));
      }
 else {
        Time.sleep(1000);
      }
      if (Thread.interrupted()) {
        this.active.set(false);
      }
    }
 catch (    Throwable e) {
      if (!(Utils.exceptionCauseIsInstanceOf(InterruptedException.class,e)) && !(Utils.exceptionCauseIsInstanceOf(ClosedByInterruptException.class,e))) {
        this.setActive(false);
        this.onKill.uncaughtException(this,e);
      }
    }
  }
}
