public void add_to_errors(ErrorInfo elem){
  if (this.errors == null) {
    this.errors=new java.util.ArrayList<ErrorInfo>();
  }
  this.errors.add(elem);
}
