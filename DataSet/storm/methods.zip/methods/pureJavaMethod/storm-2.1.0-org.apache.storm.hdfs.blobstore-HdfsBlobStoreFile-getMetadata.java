@Override public SettableBlobMeta getMetadata(){
  return settableBlobMeta;
}
