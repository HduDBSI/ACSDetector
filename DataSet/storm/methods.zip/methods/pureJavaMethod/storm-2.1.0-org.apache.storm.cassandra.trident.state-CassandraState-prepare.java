public void prepare(){
  Preconditions.checkNotNull(options.cqlStatementTupleMapper,"CassandraState.Options should have cqlStatementTupleMapper");
  client=options.clientProvider.getClient(conf);
  session=client.connect();
}
