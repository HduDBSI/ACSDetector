@Override public java.lang.String toString(){
  java.lang.StringBuilder sb=new java.lang.StringBuilder("Assignment(");
  boolean first=true;
  sb.append("master_code_dir:");
  if (this.master_code_dir == null) {
    sb.append("null");
  }
 else {
    sb.append(this.master_code_dir);
  }
  first=false;
  if (is_set_node_host()) {
    if (!first)     sb.append(", ");
    sb.append("node_host:");
    if (this.node_host == null) {
      sb.append("null");
    }
 else {
      sb.append(this.node_host);
    }
    first=false;
  }
  if (is_set_executor_node_port()) {
    if (!first)     sb.append(", ");
    sb.append("executor_node_port:");
    if (this.executor_node_port == null) {
      sb.append("null");
    }
 else {
      sb.append(this.executor_node_port);
    }
    first=false;
  }
  if (is_set_executor_start_time_secs()) {
    if (!first)     sb.append(", ");
    sb.append("executor_start_time_secs:");
    if (this.executor_start_time_secs == null) {
      sb.append("null");
    }
 else {
      sb.append(this.executor_start_time_secs);
    }
    first=false;
  }
  if (is_set_worker_resources()) {
    if (!first)     sb.append(", ");
    sb.append("worker_resources:");
    if (this.worker_resources == null) {
      sb.append("null");
    }
 else {
      sb.append(this.worker_resources);
    }
    first=false;
  }
  if (is_set_total_shared_off_heap()) {
    if (!first)     sb.append(", ");
    sb.append("total_shared_off_heap:");
    if (this.total_shared_off_heap == null) {
      sb.append("null");
    }
 else {
      sb.append(this.total_shared_off_heap);
    }
    first=false;
  }
  if (is_set_owner()) {
    if (!first)     sb.append(", ");
    sb.append("owner:");
    if (this.owner == null) {
      sb.append("null");
    }
 else {
      sb.append(this.owner);
    }
    first=false;
  }
  sb.append(")");
  return sb.toString();
}
