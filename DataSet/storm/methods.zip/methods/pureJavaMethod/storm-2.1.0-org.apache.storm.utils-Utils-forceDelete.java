/** 
 * Deletes a file or directory and its contents if it exists. Does not complain if the input is null or does not exist.
 * @param path the path to the file or directory
 */
public static void forceDelete(String path) throws IOException {
  _instance.forceDeleteImpl(path);
}
