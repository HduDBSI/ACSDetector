@Override protected void standardSchemeWriteValue(org.apache.storm.thrift.protocol.TProtocol oprot) throws org.apache.storm.thrift.TException {
switch (setField_) {
case PATH:
    java.lang.String path=(java.lang.String)value_;
  oprot.writeString(path);
return;
case PULSE:
HBPulse pulse=(HBPulse)value_;
pulse.write(oprot);
return;
case BOOLVAL:
java.lang.Boolean boolval=(java.lang.Boolean)value_;
oprot.writeBool(boolval);
return;
case RECORDS:
HBRecords records=(HBRecords)value_;
records.write(oprot);
return;
case NODES:
HBNodes nodes=(HBNodes)value_;
nodes.write(oprot);
return;
case MESSAGE_BLOB:
java.nio.ByteBuffer message_blob=(java.nio.ByteBuffer)value_;
oprot.writeBinary(message_blob);
return;
default :
throw new java.lang.IllegalStateException("Cannot write union with unknown field " + setField_);
}
}
