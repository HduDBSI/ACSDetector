/** 
 * Validates key checking for potentially harmful patterns
 * @param key Key for the blob.
 */
public static final void validateKey(String key) throws AuthorizationException {
  if (!Utils.isValidKey(key)) {
    throw new AuthorizationException(key + " does not appear to be a valid blob key");
  }
}
