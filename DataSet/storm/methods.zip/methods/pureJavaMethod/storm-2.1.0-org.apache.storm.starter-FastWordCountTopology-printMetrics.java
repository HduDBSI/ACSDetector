public static void printMetrics(Nimbus.Iface client,String name) throws Exception {
  ClusterSummary summary=client.getClusterInfo();
  String id=null;
  for (  TopologySummary ts : summary.get_topologies()) {
    if (name.equals(ts.get_name())) {
      id=ts.get_id();
    }
  }
  if (id == null) {
    throw new Exception("Could not find a topology named " + name);
  }
  TopologyInfo info=client.getTopologyInfo(id);
  int uptime=info.get_uptime_secs();
  long acked=0;
  long failed=0;
  double weightedAvgTotal=0.0;
  for (  ExecutorSummary exec : info.get_executors()) {
    if ("spout".equals(exec.get_component_id())) {
      SpoutStats stats=exec.get_stats().get_specific().get_spout();
      Map<String,Long> failedMap=stats.get_failed().get(":all-time");
      Map<String,Long> ackedMap=stats.get_acked().get(":all-time");
      Map<String,Double> avgLatMap=stats.get_complete_ms_avg().get(":all-time");
      for (      String key : ackedMap.keySet()) {
        if (failedMap != null) {
          Long tmp=failedMap.get(key);
          if (tmp != null) {
            failed+=tmp;
          }
        }
        long ackVal=ackedMap.get(key);
        double latVal=avgLatMap.get(key) * ackVal;
        acked+=ackVal;
        weightedAvgTotal+=latVal;
      }
    }
  }
  double avgLatency=weightedAvgTotal / acked;
  System.out.println("uptime: " + uptime + " acked: "+ acked+ " avgLatency: "+ avgLatency+ " acked/sec: "+ (((double)acked) / uptime + " failed: " + failed));
}
