/** 
 * Returns true if field num_workers is set (has been assigned a value) and false otherwise 
 */
public boolean is_set_num_workers(){
  return org.apache.storm.thrift.EncodingUtils.testBit(__isset_bitfield,__NUM_WORKERS_ISSET_ID);
}
