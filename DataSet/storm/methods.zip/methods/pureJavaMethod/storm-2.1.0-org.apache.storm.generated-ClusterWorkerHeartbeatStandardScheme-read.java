public void read(org.apache.storm.thrift.protocol.TProtocol iprot,ClusterWorkerHeartbeat struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TField schemeField;
  iprot.readStructBegin();
  while (true) {
    schemeField=iprot.readFieldBegin();
    if (schemeField.type == org.apache.storm.thrift.protocol.TType.STOP) {
      break;
    }
switch (schemeField.id) {
case 1:
      if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
        struct.storm_id=iprot.readString();
        struct.set_storm_id_isSet(true);
      }
 else {
        org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
      }
    break;
case 2:
  if (schemeField.type == org.apache.storm.thrift.protocol.TType.MAP) {
{
      org.apache.storm.thrift.protocol.TMap _map772=iprot.readMapBegin();
      struct.executor_stats=new java.util.HashMap<ExecutorInfo,ExecutorStats>(2 * _map772.size);
      @org.apache.storm.thrift.annotation.Nullable ExecutorInfo _key773;
      @org.apache.storm.thrift.annotation.Nullable ExecutorStats _val774;
      for (int _i775=0; _i775 < _map772.size; ++_i775) {
        _key773=new ExecutorInfo();
        _key773.read(iprot);
        _val774=new ExecutorStats();
        _val774.read(iprot);
        struct.executor_stats.put(_key773,_val774);
      }
      iprot.readMapEnd();
    }
    struct.set_executor_stats_isSet(true);
  }
 else {
    org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
  }
break;
case 3:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.I32) {
struct.time_secs=iprot.readI32();
struct.set_time_secs_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
case 4:
if (schemeField.type == org.apache.storm.thrift.protocol.TType.I32) {
struct.uptime_secs=iprot.readI32();
struct.set_uptime_secs_isSet(true);
}
 else {
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
break;
default :
org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
iprot.readFieldEnd();
}
iprot.readStructEnd();
struct.validate();
}
