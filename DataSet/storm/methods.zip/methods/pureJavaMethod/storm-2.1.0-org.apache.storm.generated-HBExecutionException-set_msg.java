public void set_msg(@org.apache.storm.thrift.annotation.Nullable java.lang.String msg){
  this.msg=msg;
}
