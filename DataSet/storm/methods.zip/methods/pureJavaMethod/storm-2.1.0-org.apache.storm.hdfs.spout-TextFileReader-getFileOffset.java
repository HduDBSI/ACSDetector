@Override public Offset getFileOffset(){
  return offset.clone();
}
