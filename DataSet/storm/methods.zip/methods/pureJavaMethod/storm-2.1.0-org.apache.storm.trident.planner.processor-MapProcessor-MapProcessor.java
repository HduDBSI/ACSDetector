public MapProcessor(Fields inputFields,Function function){
  this.function=function;
  this.inputFields=inputFields;
}
