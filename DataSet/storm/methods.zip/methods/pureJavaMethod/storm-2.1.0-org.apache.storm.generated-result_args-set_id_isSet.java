public void set_id_isSet(boolean value){
  if (!value) {
    this.id=null;
  }
}
