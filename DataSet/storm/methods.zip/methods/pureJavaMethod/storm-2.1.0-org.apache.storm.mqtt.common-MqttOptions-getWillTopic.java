public String getWillTopic(){
  return willTopic;
}
