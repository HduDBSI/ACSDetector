StaticState(AsyncLocalizer localizer,long hbTimeoutMs,long firstHbTimeoutMs,long killSleepMs,long monitorFreqMs,ContainerLauncher containerLauncher,String host,int port,ISupervisor iSupervisor,LocalState localState,BlobChangingCallback changingCallback,OnlyLatestExecutor<Integer> metricsExec,WorkerMetricsProcessor metricsProcessor,SlotMetrics slotMetrics){
  this.localizer=localizer;
  this.hbTimeoutMs=hbTimeoutMs;
  this.firstHbTimeoutMs=firstHbTimeoutMs;
  this.containerLauncher=containerLauncher;
  this.killSleepMs=killSleepMs;
  this.monitorFreqMs=monitorFreqMs;
  this.host=host;
  this.port=port;
  this.iSupervisor=iSupervisor;
  this.localState=localState;
  this.changingCallback=changingCallback;
  this.metricsExec=metricsExec;
  this.metricsProcessor=metricsProcessor;
  this.slotMetrics=slotMetrics;
}
