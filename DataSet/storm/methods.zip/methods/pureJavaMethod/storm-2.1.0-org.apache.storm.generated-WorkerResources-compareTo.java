@Override public int compareTo(WorkerResources other){
  if (!getClass().equals(other.getClass())) {
    return getClass().getName().compareTo(other.getClass().getName());
  }
  int lastComparison=0;
  lastComparison=java.lang.Boolean.valueOf(is_set_mem_on_heap()).compareTo(other.is_set_mem_on_heap());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_mem_on_heap()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.mem_on_heap,other.mem_on_heap);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_mem_off_heap()).compareTo(other.is_set_mem_off_heap());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_mem_off_heap()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.mem_off_heap,other.mem_off_heap);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_cpu()).compareTo(other.is_set_cpu());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_cpu()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.cpu,other.cpu);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_shared_mem_on_heap()).compareTo(other.is_set_shared_mem_on_heap());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_shared_mem_on_heap()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.shared_mem_on_heap,other.shared_mem_on_heap);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_shared_mem_off_heap()).compareTo(other.is_set_shared_mem_off_heap());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_shared_mem_off_heap()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.shared_mem_off_heap,other.shared_mem_off_heap);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_resources()).compareTo(other.is_set_resources());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_resources()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.resources,other.resources);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_shared_resources()).compareTo(other.is_set_shared_resources());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_shared_resources()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.shared_resources,other.shared_resources);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  return 0;
}
