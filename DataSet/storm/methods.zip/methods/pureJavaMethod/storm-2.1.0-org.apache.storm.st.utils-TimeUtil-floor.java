public static DateTime floor(DateTime dateTime,int sec){
  long modValue=dateTime.getMillis() % (1000 * sec);
  return dateTime.minus(modValue);
}
