@Override public List<SqlNode> getOperandList(){
  return ImmutableNullableList.of(tblName,fieldList,inputFormatClass,outputFormatClass,location,properties,query);
}
