public uploadBlobChunk_call(java.lang.String session,java.nio.ByteBuffer chunk,org.apache.storm.thrift.async.AsyncMethodCallback<Void> resultHandler,org.apache.storm.thrift.async.TAsyncClient client,org.apache.storm.thrift.protocol.TProtocolFactory protocolFactory,org.apache.storm.thrift.transport.TNonblockingTransport transport) throws org.apache.storm.thrift.TException {
  super(client,protocolFactory,transport,resultHandler,false);
  this.session=session;
  this.chunk=chunk;
}
