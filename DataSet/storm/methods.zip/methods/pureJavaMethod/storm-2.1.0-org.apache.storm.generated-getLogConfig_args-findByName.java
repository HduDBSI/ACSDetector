/** 
 * Find the _Fields constant that matches name, or null if its not found.
 */
@org.apache.storm.thrift.annotation.Nullable public static _Fields findByName(java.lang.String name){
  return byName.get(name);
}
