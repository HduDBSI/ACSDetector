public ComponentPageInfo recv_getComponentPageInfo() throws NotAliveException, AuthorizationException, org.apache.storm.thrift.TException {
  getComponentPageInfo_result result=new getComponentPageInfo_result();
  receiveBase(result,"getComponentPageInfo");
  if (result.is_set_success()) {
    return result.success;
  }
  if (result.e != null) {
    throw result.e;
  }
  if (result.aze != null) {
    throw result.aze;
  }
  throw new org.apache.storm.thrift.TApplicationException(org.apache.storm.thrift.TApplicationException.MISSING_RESULT,"getComponentPageInfo failed: unknown result");
}
