public ListEntryCustomValidator(Map<String,Object> params){
  this.entryValidators=(Class<?>[])params.get(ConfigValidationAnnotations.ValidatorParams.ENTRY_VALIDATOR_CLASSES);
}
