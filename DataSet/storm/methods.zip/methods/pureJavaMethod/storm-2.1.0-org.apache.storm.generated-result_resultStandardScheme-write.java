public void write(org.apache.storm.thrift.protocol.TProtocol oprot,result_result struct) throws org.apache.storm.thrift.TException {
  struct.validate();
  oprot.writeStructBegin(STRUCT_DESC);
  if (struct.aze != null) {
    oprot.writeFieldBegin(AZE_FIELD_DESC);
    struct.aze.write(oprot);
    oprot.writeFieldEnd();
  }
  oprot.writeFieldStop();
  oprot.writeStructEnd();
}
