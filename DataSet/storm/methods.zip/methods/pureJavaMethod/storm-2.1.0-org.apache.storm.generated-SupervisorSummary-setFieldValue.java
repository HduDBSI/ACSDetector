public void setFieldValue(_Fields field,@org.apache.storm.thrift.annotation.Nullable java.lang.Object value){
switch (field) {
case HOST:
    if (value == null) {
      unset_host();
    }
 else {
      set_host((java.lang.String)value);
    }
  break;
case UPTIME_SECS:
if (value == null) {
  unset_uptime_secs();
}
 else {
  set_uptime_secs((java.lang.Integer)value);
}
break;
case NUM_WORKERS:
if (value == null) {
unset_num_workers();
}
 else {
set_num_workers((java.lang.Integer)value);
}
break;
case NUM_USED_WORKERS:
if (value == null) {
unset_num_used_workers();
}
 else {
set_num_used_workers((java.lang.Integer)value);
}
break;
case SUPERVISOR_ID:
if (value == null) {
unset_supervisor_id();
}
 else {
set_supervisor_id((java.lang.String)value);
}
break;
case VERSION:
if (value == null) {
unset_version();
}
 else {
set_version((java.lang.String)value);
}
break;
case TOTAL_RESOURCES:
if (value == null) {
unset_total_resources();
}
 else {
set_total_resources((java.util.Map<java.lang.String,java.lang.Double>)value);
}
break;
case USED_MEM:
if (value == null) {
unset_used_mem();
}
 else {
set_used_mem((java.lang.Double)value);
}
break;
case USED_CPU:
if (value == null) {
unset_used_cpu();
}
 else {
set_used_cpu((java.lang.Double)value);
}
break;
case FRAGMENTED_MEM:
if (value == null) {
unset_fragmented_mem();
}
 else {
set_fragmented_mem((java.lang.Double)value);
}
break;
case FRAGMENTED_CPU:
if (value == null) {
unset_fragmented_cpu();
}
 else {
set_fragmented_cpu((java.lang.Double)value);
}
break;
}
}
