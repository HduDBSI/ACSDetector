@Override public int compareTo(submitTopology_result other){
  if (!getClass().equals(other.getClass())) {
    return getClass().getName().compareTo(other.getClass().getName());
  }
  int lastComparison=0;
  lastComparison=java.lang.Boolean.valueOf(is_set_e()).compareTo(other.is_set_e());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_e()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.e,other.e);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_ite()).compareTo(other.is_set_ite());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_ite()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.ite,other.ite);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_aze()).compareTo(other.is_set_aze());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_aze()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.aze,other.aze);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  return 0;
}
