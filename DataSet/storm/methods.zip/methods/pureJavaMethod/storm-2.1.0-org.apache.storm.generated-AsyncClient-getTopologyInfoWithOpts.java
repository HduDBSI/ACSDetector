public void getTopologyInfoWithOpts(java.lang.String id,GetInfoOptions options,org.apache.storm.thrift.async.AsyncMethodCallback<TopologyInfo> resultHandler) throws org.apache.storm.thrift.TException {
  checkReady();
  getTopologyInfoWithOpts_call method_call=new getTopologyInfoWithOpts_call(id,options,resultHandler,this,___protocolFactory,___transport);
  this.___currentMethod=method_call;
  ___manager.call(method_call);
}
