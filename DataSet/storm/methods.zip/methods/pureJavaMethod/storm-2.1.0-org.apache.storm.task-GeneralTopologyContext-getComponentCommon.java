public ComponentCommon getComponentCommon(String componentId){
  return ThriftTopologyUtils.getComponentCommon(getRawTopology(),componentId);
}
