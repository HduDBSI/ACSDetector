/** 
 * Returns true if field corresponding to fieldID is set (has been assigned a value) and false otherwise 
 */
public boolean isSet(_Fields field){
  if (field == null) {
    throw new java.lang.IllegalArgumentException();
  }
switch (field) {
case COMPONENT_ID:
    return is_set_componentId();
case STREAM_ID:
  return is_set_streamId();
}
throw new java.lang.IllegalStateException();
}
