/** 
 * Release any resources from this coordinator.
 */
void close();
