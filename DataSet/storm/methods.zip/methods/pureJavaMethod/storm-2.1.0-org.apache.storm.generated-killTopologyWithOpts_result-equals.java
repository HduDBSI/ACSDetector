public boolean equals(killTopologyWithOpts_result that){
  if (that == null)   return false;
  if (this == that)   return true;
  boolean this_present_e=true && this.is_set_e();
  boolean that_present_e=true && that.is_set_e();
  if (this_present_e || that_present_e) {
    if (!(this_present_e && that_present_e))     return false;
    if (!this.e.equals(that.e))     return false;
  }
  boolean this_present_aze=true && this.is_set_aze();
  boolean that_present_aze=true && that.is_set_aze();
  if (this_present_aze || that_present_aze) {
    if (!(this_present_aze && that_present_aze))     return false;
    if (!this.aze.equals(that.aze))     return false;
  }
  return true;
}
