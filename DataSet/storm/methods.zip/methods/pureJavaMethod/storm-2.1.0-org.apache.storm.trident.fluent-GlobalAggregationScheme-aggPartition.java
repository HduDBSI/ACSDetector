IAggregatableStream aggPartition(S stream);
