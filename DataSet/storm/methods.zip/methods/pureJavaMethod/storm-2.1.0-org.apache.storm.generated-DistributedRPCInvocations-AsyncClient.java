public AsyncClient(org.apache.storm.thrift.protocol.TProtocolFactory protocolFactory,org.apache.storm.thrift.async.TAsyncClientManager clientManager,org.apache.storm.thrift.transport.TNonblockingTransport transport){
  super(protocolFactory,clientManager,transport);
}
