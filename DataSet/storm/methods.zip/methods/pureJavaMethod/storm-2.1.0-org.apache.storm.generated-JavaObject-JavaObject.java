/** 
 * Performs a deep copy on <i>other</i>.
 */
public JavaObject(JavaObject other){
  if (other.is_set_full_class_name()) {
    this.full_class_name=other.full_class_name;
  }
  if (other.is_set_args_list()) {
    java.util.List<JavaObjectArg> __this__args_list=new java.util.ArrayList<JavaObjectArg>(other.args_list.size());
    for (    JavaObjectArg other_element : other.args_list) {
      __this__args_list.add(new JavaObjectArg(other_element));
    }
    this.args_list=__this__args_list;
  }
}
