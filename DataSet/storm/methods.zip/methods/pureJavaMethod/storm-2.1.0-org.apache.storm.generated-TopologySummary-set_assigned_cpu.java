public void set_assigned_cpu(double assigned_cpu){
  this.assigned_cpu=assigned_cpu;
  set_assigned_cpu_isSet(true);
}
