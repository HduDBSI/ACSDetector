/** 
 * Update each blob listed in the topology configuration if the latest version of the blob has not been downloaded.
 * @param conf
 * @param stormId
 * @param localizer
 * @throws IOException
 */
private void updateBlobsForTopology(Map<String,Object> conf,String stormId,Localizer localizer,String user) throws IOException {
  Map<String,Object> topoConf=ConfigUtils.readSupervisorStormConf(conf,stormId);
  Map<String,Map<String,Object>> blobstoreMap=(Map<String,Map<String,Object>>)topoConf.get(Config.TOPOLOGY_BLOBSTORE_MAP);
  List<LocalResource> localresources=SupervisorUtils.blobstoreMapToLocalresources(blobstoreMap);
  try {
    localizer.updateBlobs(localresources,user);
  }
 catch (  AuthorizationException authExp) {
    LOG.error("AuthorizationException error",authExp);
  }
catch (  KeyNotFoundException knf) {
    LOG.error("KeyNotFoundException error",knf);
  }
}
