@Override public void write(org.apache.storm.thrift.protocol.TProtocol prot,failRequestV2_result struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
  java.util.BitSet optionals=new java.util.BitSet();
  if (struct.is_set_aze()) {
    optionals.set(0);
  }
  oprot.writeBitSet(optionals,1);
  if (struct.is_set_aze()) {
    struct.aze.write(oprot);
  }
}
