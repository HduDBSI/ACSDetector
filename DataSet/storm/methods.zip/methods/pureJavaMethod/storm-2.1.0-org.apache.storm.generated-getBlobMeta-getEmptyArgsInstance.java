public getBlobMeta_args getEmptyArgsInstance(){
  return new getBlobMeta_args();
}
