public void set_topology_id_isSet(boolean value){
  if (!value) {
    this.topology_id=null;
  }
}
