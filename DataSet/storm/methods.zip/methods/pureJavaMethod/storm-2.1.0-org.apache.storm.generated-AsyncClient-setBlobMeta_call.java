public setBlobMeta_call(java.lang.String key,SettableBlobMeta meta,org.apache.storm.thrift.async.AsyncMethodCallback<Void> resultHandler,org.apache.storm.thrift.async.TAsyncClient client,org.apache.storm.thrift.protocol.TProtocolFactory protocolFactory,org.apache.storm.thrift.transport.TNonblockingTransport transport) throws org.apache.storm.thrift.TException {
  super(client,protocolFactory,transport,resultHandler,false);
  this.key=key;
  this.meta=meta;
}
