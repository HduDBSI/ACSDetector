public boolean equals(debug_args that){
  if (that == null)   return false;
  if (this == that)   return true;
  boolean this_present_name=true && this.is_set_name();
  boolean that_present_name=true && that.is_set_name();
  if (this_present_name || that_present_name) {
    if (!(this_present_name && that_present_name))     return false;
    if (!this.name.equals(that.name))     return false;
  }
  boolean this_present_component=true && this.is_set_component();
  boolean that_present_component=true && that.is_set_component();
  if (this_present_component || that_present_component) {
    if (!(this_present_component && that_present_component))     return false;
    if (!this.component.equals(that.component))     return false;
  }
  boolean this_present_enable=true;
  boolean that_present_enable=true;
  if (this_present_enable || that_present_enable) {
    if (!(this_present_enable && that_present_enable))     return false;
    if (this.enable != that.enable)     return false;
  }
  boolean this_present_samplingPercentage=true;
  boolean that_present_samplingPercentage=true;
  if (this_present_samplingPercentage || that_present_samplingPercentage) {
    if (!(this_present_samplingPercentage && that_present_samplingPercentage))     return false;
    if (this.samplingPercentage != that.samplingPercentage)     return false;
  }
  return true;
}
