@Override public Number connect(Map<String,Object> conf,TopologyContext context) throws IOException, NoOutputException {
  JSONObject setupInfo=new JSONObject();
  setupInfo.put("pidDir",context.getPIDDir());
  setupInfo.put("conf",conf);
  setupInfo.put("context",context);
  writeMessage(setupInfo);
  Number pid=(Number)((JSONObject)readMessage()).get("pid");
  return pid;
}
