private void subscribeKafkaConsumer(){
  kafkaConsumer=kafkaConsumerFactory.createConsumer(kafkaSpoutConfig);
  kafkaSpoutConfig.getSubscription().subscribe(kafkaConsumer,new KafkaSpoutConsumerRebalanceListener(),context);
}
