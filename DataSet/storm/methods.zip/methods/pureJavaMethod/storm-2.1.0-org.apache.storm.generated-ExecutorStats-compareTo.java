@Override public int compareTo(ExecutorStats other){
  if (!getClass().equals(other.getClass())) {
    return getClass().getName().compareTo(other.getClass().getName());
  }
  int lastComparison=0;
  lastComparison=java.lang.Boolean.valueOf(is_set_emitted()).compareTo(other.is_set_emitted());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_emitted()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.emitted,other.emitted);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_transferred()).compareTo(other.is_set_transferred());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_transferred()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.transferred,other.transferred);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_specific()).compareTo(other.is_set_specific());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_specific()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.specific,other.specific);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_rate()).compareTo(other.is_set_rate());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_rate()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.rate,other.rate);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  return 0;
}
