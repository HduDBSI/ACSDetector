public void put_to_window_to_acked(java.lang.String key,long val){
  if (this.window_to_acked == null) {
    this.window_to_acked=new java.util.HashMap<java.lang.String,java.lang.Long>();
  }
  this.window_to_acked.put(key,val);
}
