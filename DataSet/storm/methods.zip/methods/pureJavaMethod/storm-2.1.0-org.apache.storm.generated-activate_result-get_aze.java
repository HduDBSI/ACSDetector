@org.apache.storm.thrift.annotation.Nullable public AuthorizationException get_aze(){
  return this.aze;
}
