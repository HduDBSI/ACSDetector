public uploadChunk_argsStandardScheme getScheme(){
  return new uploadChunk_argsStandardScheme();
}
