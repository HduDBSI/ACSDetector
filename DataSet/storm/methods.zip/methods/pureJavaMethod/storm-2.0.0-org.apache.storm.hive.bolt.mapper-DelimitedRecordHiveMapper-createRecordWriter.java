@Override public RecordWriter createRecordWriter(HiveEndPoint endPoint) throws StreamingException, IOException, ClassNotFoundException {
  return new DelimitedInputWriter(columnNames,fieldDelimiter,endPoint);
}
