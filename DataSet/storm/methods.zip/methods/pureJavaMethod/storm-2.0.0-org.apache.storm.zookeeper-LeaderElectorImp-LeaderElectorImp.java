public LeaderElectorImp(CuratorFramework zk,String id,LeaderListenerCallbackFactory leaderListenerCallbackFactory){
  this.zk=zk;
  this.id=id;
  this.leaderLatch=new AtomicReference<>(new LeaderLatch(zk,leaderLockPath,id));
  this.leaderListenerCallbackFactory=leaderListenerCallbackFactory;
  this.timer=new StormTimer("leader-elector-timer",Utils.createDefaultUncaughtExceptionHandler());
}
