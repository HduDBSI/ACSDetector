/** 
 * Specify a field in the tuple that represents the timestamp as a long value. If this field is not present in the incoming tuple, an {@link IllegalArgumentException} will be thrown. The field MUST contain a timestamp in milliseconds
 * @param fieldName the name of the field that contains the timestamp
 */
public BaseWindowedBolt withTimestampField(String fieldName){
  return withTimestampExtractor(TupleFieldTimestampExtractor.of(fieldName));
}
