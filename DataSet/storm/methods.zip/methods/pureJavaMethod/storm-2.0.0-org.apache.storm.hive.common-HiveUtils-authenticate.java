public static synchronized UserGroupInformation authenticate(boolean isTokenAuthEnabled,String keytab,String principal) throws AuthenticationFailed {
  if (isTokenAuthEnabled) {
    return getCurrentUser(principal);
  }
  boolean kerberosEnabled=false;
  if (principal == null && keytab == null) {
    kerberosEnabled=false;
  }
 else   if (principal != null && keytab != null) {
    kerberosEnabled=true;
  }
 else {
    throw new IllegalArgumentException("To enable Kerberos, need to set both KerberosPrincipal and  KerberosKeytab");
  }
  if (kerberosEnabled) {
    File kfile=new File(keytab);
    if (!(kfile.isFile() && kfile.canRead())) {
      throw new IllegalArgumentException("The keyTab file: " + keytab + " is nonexistent or can't read. "+ "Please specify a readable keytab file for Kerberos auth.");
    }
    try {
      principal=SecurityUtil.getServerPrincipal(principal,"");
    }
 catch (    Exception e) {
      throw new AuthenticationFailed("Host lookup error when resolving principal " + principal,e);
    }
    try {
      UserGroupInformation.loginUserFromKeytab(principal,keytab);
      return UserGroupInformation.getLoginUser();
    }
 catch (    IOException e) {
      throw new AuthenticationFailed("Login failed for principal " + principal,e);
    }
  }
  return null;
}
