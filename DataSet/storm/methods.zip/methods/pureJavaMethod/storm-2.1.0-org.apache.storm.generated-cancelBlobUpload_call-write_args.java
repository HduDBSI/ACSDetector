public void write_args(org.apache.storm.thrift.protocol.TProtocol prot) throws org.apache.storm.thrift.TException {
  prot.writeMessageBegin(new org.apache.storm.thrift.protocol.TMessage("cancelBlobUpload",org.apache.storm.thrift.protocol.TMessageType.CALL,0));
  cancelBlobUpload_args args=new cancelBlobUpload_args();
  args.set_session(session);
  args.write(prot);
  prot.writeMessageEnd();
}
