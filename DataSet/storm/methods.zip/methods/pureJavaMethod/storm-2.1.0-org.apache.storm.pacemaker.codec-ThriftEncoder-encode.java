@Override protected void encode(ChannelHandlerContext channelHandlerContext,Object msg,List<Object> out) throws Exception {
  if (msg == null) {
    return;
  }
  LOG.debug("Trying to encode: " + msg.getClass().toString() + " : "+ msg.toString());
  HBMessage message;
  ByteBufAllocator alloc=channelHandlerContext.alloc();
  if (msg instanceof INettySerializable) {
    INettySerializable nettyMsg=(INettySerializable)msg;
    HBServerMessageType type;
    if (msg instanceof ControlMessage) {
      type=HBServerMessageType.CONTROL_MESSAGE;
    }
 else     if (msg instanceof SaslMessageToken) {
      type=HBServerMessageType.SASL_MESSAGE_TOKEN;
    }
 else {
      LOG.error("Didn't recognise INettySerializable: " + nettyMsg.toString());
      throw new RuntimeException("Unrecognized INettySerializable.");
    }
    message=encodeNettySerializable(alloc,nettyMsg,type);
  }
 else {
    message=(HBMessage)msg;
  }
  try {
    byte[] serialized=Utils.thriftSerialize(message);
    ByteBuf ret=alloc.ioBuffer(serialized.length + 4);
    ret.writeInt(serialized.length);
    ret.writeBytes(serialized);
    out.add(ret);
  }
 catch (  RuntimeException e) {
    LOG.error("Failed to serialize.",e);
    throw e;
  }
}
