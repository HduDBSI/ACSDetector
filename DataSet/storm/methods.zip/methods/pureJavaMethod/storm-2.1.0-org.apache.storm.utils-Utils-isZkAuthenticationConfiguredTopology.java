/** 
 * Is the topology configured to have ZooKeeper authentication.
 * @param conf the topology configuration
 * @return true if ZK is configured else false
 */
public static boolean isZkAuthenticationConfiguredTopology(Map<String,Object> conf){
  return (conf != null && conf.get(Config.STORM_ZOOKEEPER_TOPOLOGY_AUTH_SCHEME) != null && !((String)conf.get(Config.STORM_ZOOKEEPER_TOPOLOGY_AUTH_SCHEME)).isEmpty());
}
