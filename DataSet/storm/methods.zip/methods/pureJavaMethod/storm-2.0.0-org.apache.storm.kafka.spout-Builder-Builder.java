/** 
 * Create a KafkaSpoutConfig builder with default property values and no key/value deserializers.
 * @param bootstrapServers The bootstrap servers the consumer will use
 * @param topicFilter The topic filter defining which topics and partitions the spout will read
 * @param topicPartitioner The topic partitioner defining which topics and partitions are assinged to each spout task
 */
public Builder(String bootstrapServers,TopicFilter topicFilter,ManualPartitioner topicPartitioner){
  super(bootstrapServers,topicFilter,topicPartitioner);
}
