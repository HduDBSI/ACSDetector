/** 
 * Reads a zero-compressed encoded integer from input stream and returns it.
 * @param stream Binary input stream
 * @return deserialized integer from stream.
 */
public static int readVInt(DataInput stream) throws IOException {
  return (int)readVLong(stream);
}
