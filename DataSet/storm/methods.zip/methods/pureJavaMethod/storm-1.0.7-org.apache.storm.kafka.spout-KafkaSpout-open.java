@Override public void open(Map conf,TopologyContext context,SpoutOutputCollector collector){
  this.context=context;
  this.collector=collector;
  firstPollOffsetStrategy=kafkaSpoutConfig.getFirstPollOffsetStrategy();
  retryService=kafkaSpoutConfig.getRetryService();
  tupleListener=kafkaSpoutConfig.getTupleListener();
  if (kafkaSpoutConfig.getProcessingGuarantee() != KafkaSpoutConfig.ProcessingGuarantee.AT_MOST_ONCE) {
    commitTimer=new Timer(TIMER_DELAY_MS,kafkaSpoutConfig.getOffsetsCommitPeriodMs(),TimeUnit.MILLISECONDS);
  }
  refreshSubscriptionTimer=new Timer(TIMER_DELAY_MS,kafkaSpoutConfig.getPartitionRefreshPeriodMs(),TimeUnit.MILLISECONDS);
  offsetManagers=new HashMap<>();
  emitted=new HashSet<>();
  waitingToEmit=new HashMap<>();
  commitMetadataManager=new CommitMetadataManager(context,kafkaSpoutConfig.getProcessingGuarantee());
  tupleListener.open(conf,context);
  if (canRegisterMetrics()) {
    registerMetric();
  }
  LOG.info("Kafka Spout opened with the following configuration: {}",kafkaSpoutConfig);
}
