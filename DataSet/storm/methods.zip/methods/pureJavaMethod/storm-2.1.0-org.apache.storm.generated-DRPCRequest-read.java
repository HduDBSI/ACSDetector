@Override public void read(org.apache.storm.thrift.protocol.TProtocol prot,DRPCRequest struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
  struct.func_args=iprot.readString();
  struct.set_func_args_isSet(true);
  struct.request_id=iprot.readString();
  struct.set_request_id_isSet(true);
}
