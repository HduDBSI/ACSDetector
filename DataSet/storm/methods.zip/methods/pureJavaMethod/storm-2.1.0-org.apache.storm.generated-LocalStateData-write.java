@Override public void write(org.apache.storm.thrift.protocol.TProtocol prot,LocalStateData struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
{
    oprot.writeI32(struct.serialized_parts.size());
    for (    java.util.Map.Entry<java.lang.String,ThriftSerializedObject> _iter787 : struct.serialized_parts.entrySet()) {
      oprot.writeString(_iter787.getKey());
      _iter787.getValue().write(oprot);
    }
  }
}
