public void unset_key(){
  this.key=null;
}
