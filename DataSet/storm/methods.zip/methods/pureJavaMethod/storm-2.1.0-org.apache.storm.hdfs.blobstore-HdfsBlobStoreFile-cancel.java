@Override public void cancel() throws IOException {
  checkIsNotTmp();
  delete();
}
