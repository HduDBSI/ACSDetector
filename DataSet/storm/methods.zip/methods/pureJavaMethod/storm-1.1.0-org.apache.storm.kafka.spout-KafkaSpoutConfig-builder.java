public static Builder<String,String> builder(String bootstrapServers,Pattern topics){
  return new Builder<>(bootstrapServers,StringDeserializer.class,StringDeserializer.class,topics);
}
