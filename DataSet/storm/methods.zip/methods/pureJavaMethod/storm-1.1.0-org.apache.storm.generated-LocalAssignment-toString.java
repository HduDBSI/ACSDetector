@Override public String toString(){
  StringBuilder sb=new StringBuilder("LocalAssignment(");
  boolean first=true;
  sb.append("topology_id:");
  if (this.topology_id == null) {
    sb.append("null");
  }
 else {
    sb.append(this.topology_id);
  }
  first=false;
  if (!first)   sb.append(", ");
  sb.append("executors:");
  if (this.executors == null) {
    sb.append("null");
  }
 else {
    sb.append(this.executors);
  }
  first=false;
  if (is_set_resources()) {
    if (!first)     sb.append(", ");
    sb.append("resources:");
    if (this.resources == null) {
      sb.append("null");
    }
 else {
      sb.append(this.resources);
    }
    first=false;
  }
  sb.append(")");
  return sb.toString();
}
