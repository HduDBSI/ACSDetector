/** 
 * Returns the commands of this instance. Arguments with spaces in are presented with quotes round; other arguments are presented raw
 * @return a string representation of the object.
 */
@Override public String toString(){
  StringBuilder builder=new StringBuilder();
  String[] args=getExecString();
  for (  String s : args) {
    if (s.indexOf(' ') >= 0) {
      builder.append('"').append(s).append('"');
    }
 else {
      builder.append(s);
    }
    builder.append(' ');
  }
  return builder.toString();
}
