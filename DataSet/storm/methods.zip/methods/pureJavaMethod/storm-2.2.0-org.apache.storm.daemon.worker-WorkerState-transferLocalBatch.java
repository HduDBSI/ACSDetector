private void transferLocalBatch(ArrayList<AddressedTuple> tupleBatch){
  for (int i=0; i < tupleBatch.size(); i++) {
    AddressedTuple tuple=tupleBatch.get(i);
    JCQueue queue=taskToExecutorQueue.get(tuple.dest);
    if (queue.isEmptyOverflow()) {
      if (queue.tryPublish(tuple)) {
        continue;
      }
    }
    int currOverflowCount=queue.getOverflowCount();
    BackpressureState bpState=bpTracker.getBackpressureState(tuple.dest);
    if (bpTracker.recordBackPressure(bpState)) {
      receiver.sendBackPressureStatus(bpTracker.getCurrStatus());
      bpTracker.setLastOverflowCount(bpState,currOverflowCount);
    }
 else {
      if (currOverflowCount - bpTracker.getLastOverflowCount(bpState) > RESEND_BACKPRESSURE_SIZE) {
        BackPressureStatus bpStatus=bpTracker.getCurrStatus();
        receiver.sendBackPressureStatus(bpStatus);
        bpTracker.setLastOverflowCount(bpState,currOverflowCount);
        LOG.debug("Re-sent BackPressure Status. OverflowCount = {}, BP Status ID = {}. ",currOverflowCount,bpStatus.id);
      }
    }
    if (!queue.tryPublishToOverflow(tuple)) {
      dropMessage(tuple,queue);
    }
  }
}
