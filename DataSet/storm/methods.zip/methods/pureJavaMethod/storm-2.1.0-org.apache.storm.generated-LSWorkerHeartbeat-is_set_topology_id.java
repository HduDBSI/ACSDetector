/** 
 * Returns true if field topology_id is set (has been assigned a value) and false otherwise 
 */
public boolean is_set_topology_id(){
  return this.topology_id != null;
}
