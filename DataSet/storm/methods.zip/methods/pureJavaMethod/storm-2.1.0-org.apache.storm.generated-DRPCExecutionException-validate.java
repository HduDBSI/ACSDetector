public void validate() throws org.apache.storm.thrift.TException {
  if (!is_set_msg()) {
    throw new org.apache.storm.thrift.protocol.TProtocolException("Required field 'msg' is unset! Struct:" + toString());
  }
}
