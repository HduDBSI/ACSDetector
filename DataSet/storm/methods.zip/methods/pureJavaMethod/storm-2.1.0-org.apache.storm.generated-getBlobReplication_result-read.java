@Override public void read(org.apache.storm.thrift.protocol.TProtocol prot,getBlobReplication_result struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
  java.util.BitSet incoming=iprot.readBitSet(3);
  if (incoming.get(0)) {
    struct.success=iprot.readI32();
    struct.set_success_isSet(true);
  }
  if (incoming.get(1)) {
    struct.aze=new AuthorizationException();
    struct.aze.read(iprot);
    struct.set_aze_isSet(true);
  }
  if (incoming.get(2)) {
    struct.knf=new KeyNotFoundException();
    struct.knf.read(iprot);
    struct.set_knf_isSet(true);
  }
}
