public abstract boolean isTmp();
