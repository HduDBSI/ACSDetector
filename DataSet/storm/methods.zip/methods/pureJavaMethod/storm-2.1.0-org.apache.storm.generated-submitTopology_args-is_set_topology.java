/** 
 * Returns true if field topology is set (has been assigned a value) and false otherwise 
 */
public boolean is_set_topology(){
  return this.topology != null;
}
