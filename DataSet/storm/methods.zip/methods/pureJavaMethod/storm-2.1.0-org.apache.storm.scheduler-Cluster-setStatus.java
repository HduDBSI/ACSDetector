/** 
 * set scheduler status for a topology.
 */
public void setStatus(String topologyId,String statusMessage){
  assertValidTopologyForModification(topologyId);
  LOG.info("STATUS - {} {}",topologyId,statusMessage);
  status.put(topologyId,statusMessage);
}
