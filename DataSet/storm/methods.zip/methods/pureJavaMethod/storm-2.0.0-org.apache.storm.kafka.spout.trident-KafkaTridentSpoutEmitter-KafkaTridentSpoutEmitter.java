@VisibleForTesting KafkaTridentSpoutEmitter(KafkaTridentSpoutConfig<K,V> kafkaSpoutConfig,TopologyContext topologyContext,ConsumerFactory<K,V> consumerFactory,TopicAssigner topicAssigner){
  this.kafkaSpoutConfig=kafkaSpoutConfig;
  this.consumer=consumerFactory.createConsumer(kafkaSpoutConfig.getKafkaProps());
  this.topologyContext=topologyContext;
  this.translator=kafkaSpoutConfig.getTranslator();
  this.topicAssigner=topicAssigner;
  this.pollTimeoutMs=kafkaSpoutConfig.getPollTimeoutMs();
  this.firstPollOffsetStrategy=kafkaSpoutConfig.getFirstPollOffsetStrategy();
  LOG.debug("Created {}",this.toString());
}
