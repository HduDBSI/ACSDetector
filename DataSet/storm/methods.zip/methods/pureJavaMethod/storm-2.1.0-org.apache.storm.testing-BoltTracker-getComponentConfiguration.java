@Override public Map<String,Object> getComponentConfiguration(){
  return new HashMap<String,Object>();
}
