public void submitTopologyWithOpts(java.lang.String name,java.lang.String uploadedJarLocation,java.lang.String jsonConf,StormTopology topology,SubmitOptions options,org.apache.storm.thrift.async.AsyncMethodCallback<Void> resultHandler) throws org.apache.storm.thrift.TException {
  checkReady();
  submitTopologyWithOpts_call method_call=new submitTopologyWithOpts_call(name,uploadedJarLocation,jsonConf,topology,options,resultHandler,this,___protocolFactory,___transport);
  this.___currentMethod=method_call;
  ___manager.call(method_call);
}
