public static JavaObjectArg binary_arg(byte[] value){
  JavaObjectArg x=new JavaObjectArg();
  x.set_binary_arg(java.nio.ByteBuffer.wrap(value.clone()));
  return x;
}
