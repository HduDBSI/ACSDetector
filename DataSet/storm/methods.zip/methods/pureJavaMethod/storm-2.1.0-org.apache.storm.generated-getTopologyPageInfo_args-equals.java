public boolean equals(getTopologyPageInfo_args that){
  if (that == null)   return false;
  if (this == that)   return true;
  boolean this_present_id=true && this.is_set_id();
  boolean that_present_id=true && that.is_set_id();
  if (this_present_id || that_present_id) {
    if (!(this_present_id && that_present_id))     return false;
    if (!this.id.equals(that.id))     return false;
  }
  boolean this_present_window=true && this.is_set_window();
  boolean that_present_window=true && that.is_set_window();
  if (this_present_window || that_present_window) {
    if (!(this_present_window && that_present_window))     return false;
    if (!this.window.equals(that.window))     return false;
  }
  boolean this_present_is_include_sys=true;
  boolean that_present_is_include_sys=true;
  if (this_present_is_include_sys || that_present_is_include_sys) {
    if (!(this_present_is_include_sys && that_present_is_include_sys))     return false;
    if (this.is_include_sys != that.is_include_sys)     return false;
  }
  return true;
}
