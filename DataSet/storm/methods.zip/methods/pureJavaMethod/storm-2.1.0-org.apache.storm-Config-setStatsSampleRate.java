@SuppressWarnings("checkstyle:OverloadMethodsDeclarationOrder") public void setStatsSampleRate(double rate){
  setStatsSampleRate(this,rate);
}
