public static void clearAll(){
  dbs.clear();
}
