void spoutFail(SpoutFailInfo info);
