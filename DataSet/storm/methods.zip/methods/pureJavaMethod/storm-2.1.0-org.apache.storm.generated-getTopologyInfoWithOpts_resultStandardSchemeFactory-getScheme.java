public getTopologyInfoWithOpts_resultStandardScheme getScheme(){
  return new getTopologyInfoWithOpts_resultStandardScheme();
}
