/** 
 * Find the _Fields constant that matches fieldId, or null if its not found.
 */
@org.apache.storm.thrift.annotation.Nullable public static _Fields findByThriftId(int fieldId){
switch (fieldId) {
case 1:
    return E;
case 2:
  return ITE;
case 3:
return AZE;
default :
return null;
}
}
