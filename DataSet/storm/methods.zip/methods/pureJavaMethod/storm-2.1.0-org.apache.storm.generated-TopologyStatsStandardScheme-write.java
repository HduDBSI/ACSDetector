public void write(org.apache.storm.thrift.protocol.TProtocol oprot,TopologyStats struct) throws org.apache.storm.thrift.TException {
  struct.validate();
  oprot.writeStructBegin(STRUCT_DESC);
  if (struct.window_to_emitted != null) {
    if (struct.is_set_window_to_emitted()) {
      oprot.writeFieldBegin(WINDOW_TO_EMITTED_FIELD_DESC);
{
        oprot.writeMapBegin(new org.apache.storm.thrift.protocol.TMap(org.apache.storm.thrift.protocol.TType.STRING,org.apache.storm.thrift.protocol.TType.I64,struct.window_to_emitted.size()));
        for (        java.util.Map.Entry<java.lang.String,java.lang.Long> _iter426 : struct.window_to_emitted.entrySet()) {
          oprot.writeString(_iter426.getKey());
          oprot.writeI64(_iter426.getValue());
        }
        oprot.writeMapEnd();
      }
      oprot.writeFieldEnd();
    }
  }
  if (struct.window_to_transferred != null) {
    if (struct.is_set_window_to_transferred()) {
      oprot.writeFieldBegin(WINDOW_TO_TRANSFERRED_FIELD_DESC);
{
        oprot.writeMapBegin(new org.apache.storm.thrift.protocol.TMap(org.apache.storm.thrift.protocol.TType.STRING,org.apache.storm.thrift.protocol.TType.I64,struct.window_to_transferred.size()));
        for (        java.util.Map.Entry<java.lang.String,java.lang.Long> _iter427 : struct.window_to_transferred.entrySet()) {
          oprot.writeString(_iter427.getKey());
          oprot.writeI64(_iter427.getValue());
        }
        oprot.writeMapEnd();
      }
      oprot.writeFieldEnd();
    }
  }
  if (struct.window_to_complete_latencies_ms != null) {
    if (struct.is_set_window_to_complete_latencies_ms()) {
      oprot.writeFieldBegin(WINDOW_TO_COMPLETE_LATENCIES_MS_FIELD_DESC);
{
        oprot.writeMapBegin(new org.apache.storm.thrift.protocol.TMap(org.apache.storm.thrift.protocol.TType.STRING,org.apache.storm.thrift.protocol.TType.DOUBLE,struct.window_to_complete_latencies_ms.size()));
        for (        java.util.Map.Entry<java.lang.String,java.lang.Double> _iter428 : struct.window_to_complete_latencies_ms.entrySet()) {
          oprot.writeString(_iter428.getKey());
          oprot.writeDouble(_iter428.getValue());
        }
        oprot.writeMapEnd();
      }
      oprot.writeFieldEnd();
    }
  }
  if (struct.window_to_acked != null) {
    if (struct.is_set_window_to_acked()) {
      oprot.writeFieldBegin(WINDOW_TO_ACKED_FIELD_DESC);
{
        oprot.writeMapBegin(new org.apache.storm.thrift.protocol.TMap(org.apache.storm.thrift.protocol.TType.STRING,org.apache.storm.thrift.protocol.TType.I64,struct.window_to_acked.size()));
        for (        java.util.Map.Entry<java.lang.String,java.lang.Long> _iter429 : struct.window_to_acked.entrySet()) {
          oprot.writeString(_iter429.getKey());
          oprot.writeI64(_iter429.getValue());
        }
        oprot.writeMapEnd();
      }
      oprot.writeFieldEnd();
    }
  }
  if (struct.window_to_failed != null) {
    if (struct.is_set_window_to_failed()) {
      oprot.writeFieldBegin(WINDOW_TO_FAILED_FIELD_DESC);
{
        oprot.writeMapBegin(new org.apache.storm.thrift.protocol.TMap(org.apache.storm.thrift.protocol.TType.STRING,org.apache.storm.thrift.protocol.TType.I64,struct.window_to_failed.size()));
        for (        java.util.Map.Entry<java.lang.String,java.lang.Long> _iter430 : struct.window_to_failed.entrySet()) {
          oprot.writeString(_iter430.getKey());
          oprot.writeI64(_iter430.getValue());
        }
        oprot.writeMapEnd();
      }
      oprot.writeFieldEnd();
    }
  }
  oprot.writeFieldStop();
  oprot.writeStructEnd();
}
