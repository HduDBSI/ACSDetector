public WordSpout(boolean isDistributed){
  this.isDistributed=isDistributed;
}
