@Override public Map<String,Object> getComponentConfiguration(){
  return null;
}
