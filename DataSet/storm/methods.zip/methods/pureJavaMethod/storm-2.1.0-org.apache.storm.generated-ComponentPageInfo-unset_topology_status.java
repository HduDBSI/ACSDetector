public void unset_topology_status(){
  this.topology_status=null;
}
