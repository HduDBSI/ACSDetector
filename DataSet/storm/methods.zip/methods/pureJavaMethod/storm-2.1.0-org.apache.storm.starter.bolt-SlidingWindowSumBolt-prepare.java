@Override public void prepare(Map<String,Object> topoConf,TopologyContext context,OutputCollector collector){
  this.collector=collector;
}
