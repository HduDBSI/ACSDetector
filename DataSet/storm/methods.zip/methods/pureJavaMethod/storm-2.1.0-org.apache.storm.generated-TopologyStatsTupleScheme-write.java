@Override public void write(org.apache.storm.thrift.protocol.TProtocol prot,TopologyStats struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
  java.util.BitSet optionals=new java.util.BitSet();
  if (struct.is_set_window_to_emitted()) {
    optionals.set(0);
  }
  if (struct.is_set_window_to_transferred()) {
    optionals.set(1);
  }
  if (struct.is_set_window_to_complete_latencies_ms()) {
    optionals.set(2);
  }
  if (struct.is_set_window_to_acked()) {
    optionals.set(3);
  }
  if (struct.is_set_window_to_failed()) {
    optionals.set(4);
  }
  oprot.writeBitSet(optionals,5);
  if (struct.is_set_window_to_emitted()) {
{
      oprot.writeI32(struct.window_to_emitted.size());
      for (      java.util.Map.Entry<java.lang.String,java.lang.Long> _iter431 : struct.window_to_emitted.entrySet()) {
        oprot.writeString(_iter431.getKey());
        oprot.writeI64(_iter431.getValue());
      }
    }
  }
  if (struct.is_set_window_to_transferred()) {
{
      oprot.writeI32(struct.window_to_transferred.size());
      for (      java.util.Map.Entry<java.lang.String,java.lang.Long> _iter432 : struct.window_to_transferred.entrySet()) {
        oprot.writeString(_iter432.getKey());
        oprot.writeI64(_iter432.getValue());
      }
    }
  }
  if (struct.is_set_window_to_complete_latencies_ms()) {
{
      oprot.writeI32(struct.window_to_complete_latencies_ms.size());
      for (      java.util.Map.Entry<java.lang.String,java.lang.Double> _iter433 : struct.window_to_complete_latencies_ms.entrySet()) {
        oprot.writeString(_iter433.getKey());
        oprot.writeDouble(_iter433.getValue());
      }
    }
  }
  if (struct.is_set_window_to_acked()) {
{
      oprot.writeI32(struct.window_to_acked.size());
      for (      java.util.Map.Entry<java.lang.String,java.lang.Long> _iter434 : struct.window_to_acked.entrySet()) {
        oprot.writeString(_iter434.getKey());
        oprot.writeI64(_iter434.getValue());
      }
    }
  }
  if (struct.is_set_window_to_failed()) {
{
      oprot.writeI32(struct.window_to_failed.size());
      for (      java.util.Map.Entry<java.lang.String,java.lang.Long> _iter435 : struct.window_to_failed.entrySet()) {
        oprot.writeString(_iter435.getKey());
        oprot.writeI64(_iter435.getValue());
      }
    }
  }
}
