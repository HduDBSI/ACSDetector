@org.apache.storm.thrift.annotation.Nullable public java.lang.String get_id(){
  return this.id;
}
