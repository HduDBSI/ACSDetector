/** 
 * {@inheritDoc}
 */
@Override public SimpleCQLStatementMapper build(){
  return new SimpleCQLStatementMapper(queryString,mapper,(routingKeys != null) ? new RoutingKeyGenerator(routingKeys) : null);
}
