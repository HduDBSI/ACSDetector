@Override public void received(Object mesg,String remote,Channel channel) throws InterruptedException {
  cleanPipeline(channel);
  boolean authenticated=(authMethod == ThriftNettyServerCodec.AuthMethod.NONE) || authenticatedChannels.contains(channel);
  HBMessage m=(HBMessage)mesg;
  LOG.debug("received message. Passing to handler. {} : {} : {}",handler.toString(),m.toString(),channel.toString());
  HBMessage response=handler.handleMessage(m,authenticated);
  if (response != null) {
    LOG.debug("Got Response from handler: {}",response);
    channel.writeAndFlush(response,channel.voidPromise());
  }
 else {
    LOG.info("Got null response from handler handling message: {}",m);
  }
}
