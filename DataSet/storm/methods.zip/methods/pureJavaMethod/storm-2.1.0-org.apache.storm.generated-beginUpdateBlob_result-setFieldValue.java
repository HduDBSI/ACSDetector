public void setFieldValue(_Fields field,@org.apache.storm.thrift.annotation.Nullable java.lang.Object value){
switch (field) {
case SUCCESS:
    if (value == null) {
      unset_success();
    }
 else {
      set_success((java.lang.String)value);
    }
  break;
case AZE:
if (value == null) {
  unset_aze();
}
 else {
  set_aze((AuthorizationException)value);
}
break;
case KNF:
if (value == null) {
unset_knf();
}
 else {
set_knf((KeyNotFoundException)value);
}
break;
}
}
