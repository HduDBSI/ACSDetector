public StormTopology recv_getTopology() throws NotAliveException, AuthorizationException, org.apache.storm.thrift.TException {
  getTopology_result result=new getTopology_result();
  receiveBase(result,"getTopology");
  if (result.is_set_success()) {
    return result.success;
  }
  if (result.e != null) {
    throw result.e;
  }
  if (result.aze != null) {
    throw result.aze;
  }
  throw new org.apache.storm.thrift.TApplicationException(org.apache.storm.thrift.TApplicationException.MISSING_RESULT,"getTopology failed: unknown result");
}
