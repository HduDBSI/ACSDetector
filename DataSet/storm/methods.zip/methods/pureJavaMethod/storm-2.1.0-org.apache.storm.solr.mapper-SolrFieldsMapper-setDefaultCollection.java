private void setDefaultCollection(SolrClient solrClient){
  String defaultCollection=null;
  if (solrClient instanceof CloudSolrClient) {
    defaultCollection=((CloudSolrClient)solrClient).getDefaultCollection();
  }
  this.collection=defaultCollection;
}
