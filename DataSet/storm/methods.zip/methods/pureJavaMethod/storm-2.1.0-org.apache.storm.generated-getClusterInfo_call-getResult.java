public ClusterSummary getResult() throws AuthorizationException, org.apache.storm.thrift.TException {
  if (getState() != org.apache.storm.thrift.async.TAsyncMethodCall.State.RESPONSE_READ) {
    throw new java.lang.IllegalStateException("Method call not finished!");
  }
  org.apache.storm.thrift.transport.TMemoryInputTransport memoryTransport=new org.apache.storm.thrift.transport.TMemoryInputTransport(getFrameBuffer().array());
  org.apache.storm.thrift.protocol.TProtocol prot=client.getProtocolFactory().getProtocol(memoryTransport);
  return (new Client(prot)).recv_getClusterInfo();
}
