/** 
 * called when the file is uploaded.
 * @param srcFile    - jar file to be uploaded
 * @param targetFile - destination file
 * @param totalBytes - total number of bytes of the file
 */
public void onCompleted(String srcFile,String targetFile,long totalBytes);
