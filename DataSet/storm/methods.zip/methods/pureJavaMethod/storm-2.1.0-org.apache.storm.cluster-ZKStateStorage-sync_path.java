@Override public void sync_path(String path){
  ClientZookeeper.syncPath(zkWriter,path);
}
