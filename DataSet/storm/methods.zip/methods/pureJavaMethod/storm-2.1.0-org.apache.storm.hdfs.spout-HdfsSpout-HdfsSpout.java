public HdfsSpout(){
}
