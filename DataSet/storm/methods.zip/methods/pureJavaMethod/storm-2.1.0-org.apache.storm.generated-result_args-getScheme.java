public result_argsTupleScheme getScheme(){
  return new result_argsTupleScheme();
}
