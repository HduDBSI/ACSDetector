public void unset_requested_memoffheap(){
  __isset_bitfield=org.apache.storm.thrift.EncodingUtils.clearBit(__isset_bitfield,__REQUESTED_MEMOFFHEAP_ISSET_ID);
}
