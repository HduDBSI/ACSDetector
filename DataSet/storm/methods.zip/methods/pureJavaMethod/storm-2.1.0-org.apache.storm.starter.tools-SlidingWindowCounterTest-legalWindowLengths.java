@DataProvider public Object[][] legalWindowLengths(){
  return new Object[][]{{2},{3},{20}};
}
