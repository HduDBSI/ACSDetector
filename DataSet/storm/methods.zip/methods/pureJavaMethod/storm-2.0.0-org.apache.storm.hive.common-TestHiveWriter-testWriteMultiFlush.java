@Test public void testWriteMultiFlush() throws Exception {
  DelimitedRecordHiveMapper mapper=new MockedDelemiteredRecordHiveMapper().withColumnFields(new Fields(colNames)).withPartitionFields(new Fields(partNames));
  HiveEndPoint endPoint=new HiveEndPoint(metaStoreURI,dbName,tblName,Arrays.asList(partitionVals));
  TestingHiveWriter writer=new TestingHiveWriter(endPoint,10,true,timeout,callTimeoutPool,mapper,ugi,false);
  Tuple tuple=generateTestTuple("1","abc");
  writer.write(mapper.mapRecord(tuple));
  tuple=generateTestTuple("2","def");
  writer.write(mapper.mapRecord(tuple));
  Assert.assertEquals(writer.getTotalRecords(),2);
  Mockito.verify(writer.getMockedTxBatch(),Mockito.times(2)).write(Mockito.any(byte[].class));
  Mockito.verify(writer.getMockedTxBatch(),Mockito.never()).commit();
  writer.flush(true);
  Assert.assertEquals(writer.getTotalRecords(),0);
  Mockito.verify(writer.getMockedTxBatch(),Mockito.atLeastOnce()).commit();
  tuple=generateTestTuple("3","ghi");
  writer.write(mapper.mapRecord(tuple));
  writer.flush(true);
  tuple=generateTestTuple("4","klm");
  writer.write(mapper.mapRecord(tuple));
  writer.flush(true);
  writer.close();
  Mockito.verify(writer.getMockedTxBatch(),Mockito.times(4)).write(Mockito.any(byte[].class));
}
