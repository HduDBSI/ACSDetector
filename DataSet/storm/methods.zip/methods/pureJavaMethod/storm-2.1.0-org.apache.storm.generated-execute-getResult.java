public execute_result getResult(I iface,execute_args args) throws org.apache.storm.thrift.TException {
  execute_result result=new execute_result();
  try {
    result.success=iface.execute(args.functionName,args.funcArgs);
  }
 catch (  DRPCExecutionException e) {
    result.e=e;
  }
catch (  AuthorizationException aze) {
    result.aze=aze;
  }
  return result;
}
