@Override public void read(org.apache.storm.thrift.protocol.TProtocol prot,KillOptions struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
  java.util.BitSet incoming=iprot.readBitSet(1);
  if (incoming.get(0)) {
    struct.wait_secs=iprot.readI32();
    struct.set_wait_secs_isSet(true);
  }
}
