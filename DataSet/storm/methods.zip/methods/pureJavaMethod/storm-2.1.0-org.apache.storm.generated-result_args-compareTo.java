@Override public int compareTo(result_args other){
  if (!getClass().equals(other.getClass())) {
    return getClass().getName().compareTo(other.getClass().getName());
  }
  int lastComparison=0;
  lastComparison=java.lang.Boolean.valueOf(is_set_id()).compareTo(other.is_set_id());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_id()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.id,other.id);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_result()).compareTo(other.is_set_result());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_result()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.result,other.result);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  return 0;
}
