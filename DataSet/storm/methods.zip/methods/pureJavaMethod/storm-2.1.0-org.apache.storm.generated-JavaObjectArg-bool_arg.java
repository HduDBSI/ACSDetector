public static JavaObjectArg bool_arg(boolean value){
  JavaObjectArg x=new JavaObjectArg();
  x.set_bool_arg(value);
  return x;
}
