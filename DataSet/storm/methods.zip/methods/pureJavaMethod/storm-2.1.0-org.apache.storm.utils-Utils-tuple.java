public static List<Object> tuple(Object... values){
  List<Object> ret=new ArrayList<Object>();
  for (  Object v : values) {
    ret.add(v);
  }
  return ret;
}
