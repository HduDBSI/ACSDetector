@Override public void declareOutputFields(OutputFieldsDeclarer declarer){
  declarer.declare(outputFields);
}
