@Override public String getString(int i){
  return (String)values.get(i);
}
