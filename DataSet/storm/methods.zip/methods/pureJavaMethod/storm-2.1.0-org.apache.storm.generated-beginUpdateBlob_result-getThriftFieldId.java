public short getThriftFieldId(){
  return _thriftId;
}
