public KeyTranslationIterator(Iterator<String> it,String prefix) throws IOException {
  this.it=it;
  this.prefix=prefix;
  primeNext();
}
