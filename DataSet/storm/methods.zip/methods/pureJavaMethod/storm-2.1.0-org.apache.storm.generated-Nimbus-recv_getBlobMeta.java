public ReadableBlobMeta recv_getBlobMeta() throws AuthorizationException, KeyNotFoundException, org.apache.storm.thrift.TException {
  getBlobMeta_result result=new getBlobMeta_result();
  receiveBase(result,"getBlobMeta");
  if (result.is_set_success()) {
    return result.success;
  }
  if (result.aze != null) {
    throw result.aze;
  }
  if (result.knf != null) {
    throw result.knf;
  }
  throw new org.apache.storm.thrift.TApplicationException(org.apache.storm.thrift.TApplicationException.MISSING_RESULT,"getBlobMeta failed: unknown result");
}
