public void set_aze(@org.apache.storm.thrift.annotation.Nullable AuthorizationException aze){
  this.aze=aze;
}
