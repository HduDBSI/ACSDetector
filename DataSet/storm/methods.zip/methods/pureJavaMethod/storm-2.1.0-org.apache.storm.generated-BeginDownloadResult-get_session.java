@org.apache.storm.thrift.annotation.Nullable public java.lang.String get_session(){
  return this.session;
}
