/** 
 * Prepare the emitter to handle the input partitions.
 */
public void refreshPartitions(List<KafkaTridentSpoutTopicPartition> partitionResponsibilities){
  Set<TopicPartition> assignedTps=partitionResponsibilities.stream().map(kttp -> kttp.getTopicPartition()).collect(Collectors.toSet());
  topicAssigner.assignPartitions(consumer,assignedTps,new KafkaSpoutConsumerRebalanceListener());
  LOG.debug("Assigned partitions [{}] to this task",assignedTps);
}
