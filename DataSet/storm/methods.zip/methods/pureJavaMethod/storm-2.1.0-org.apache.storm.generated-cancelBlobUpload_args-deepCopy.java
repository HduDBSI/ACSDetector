public cancelBlobUpload_args deepCopy(){
  return new cancelBlobUpload_args(this);
}
