public FreshOutputFactory(Fields selfFields){
  fieldIndex=new HashMap<>();
  for (int i=0; i < selfFields.size(); i++) {
    String field=selfFields.get(i);
    fieldIndex.put(field,new ValuePointer(0,i,field));
  }
  index=ValuePointer.buildIndex(selfFields,fieldIndex);
}
