public byte[] getValue(){
  return value;
}
