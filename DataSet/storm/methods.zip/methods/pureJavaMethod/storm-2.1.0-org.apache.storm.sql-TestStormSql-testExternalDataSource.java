@Test public void testExternalDataSource() throws Exception {
  List<String> stmt=new ArrayList<>();
  stmt.add("CREATE EXTERNAL TABLE FOO (ID INT PRIMARY KEY) LOCATION 'mock:///foo'");
  stmt.add("CREATE EXTERNAL TABLE BAR (ID INT PRIMARY KEY) LOCATION 'mock:///foo'");
  stmt.add("INSERT INTO BAR SELECT STREAM ID + 1 FROM FOO WHERE ID > 2");
  StormSqlLocalClusterImpl impl=new StormSqlLocalClusterImpl();
  List<Pair<Object,Values>> values=TestUtils.MockInsertBolt.getCollectedValues();
  impl.runLocal(cluster,stmt,(__) -> values.size() >= 2,WAIT_TIMEOUT_MS);
  Assert.assertEquals(2,values.size());
  Assert.assertEquals(4,values.get(0).getFirst());
  Assert.assertEquals(5,values.get(1).getFirst());
}
