public getComponentPageInfo_args deepCopy(){
  return new getComponentPageInfo_args(this);
}
