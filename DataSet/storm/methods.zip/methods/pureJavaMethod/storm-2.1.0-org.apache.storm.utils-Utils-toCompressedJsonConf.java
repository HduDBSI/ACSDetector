public static byte[] toCompressedJsonConf(Map<String,Object> topoConf){
  try {
    ByteArrayOutputStream bos=new ByteArrayOutputStream();
    OutputStreamWriter out=new OutputStreamWriter(new GZIPOutputStream(bos));
    JSONValue.writeJSONString(topoConf,out);
    out.close();
    return bos.toByteArray();
  }
 catch (  IOException e) {
    throw new RuntimeException(e);
  }
}
