/** 
 * Unpack matching files from a jar. Entries inside the jar that do not match the given pattern will be skipped.
 * @param jarFile the .jar file to unpack
 * @param toDir the destination directory into which to unpack the jar
 */
public static void unJar(File jarFile,File toDir) throws IOException {
  try (JarFile jar=new JarFile(jarFile)){
    extractZipFile(jar,toDir,null);
  }
 }
