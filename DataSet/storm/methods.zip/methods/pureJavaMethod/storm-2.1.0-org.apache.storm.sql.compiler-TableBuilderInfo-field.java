public TableBuilderInfo field(String name,SqlDataTypeSpec type,ColumnConstraint constraint){
  RelDataType dataType=type.deriveType(typeFactory);
  interpretConstraint(constraint,fields.size());
  fields.add(new FieldType(name,dataType));
  return this;
}
