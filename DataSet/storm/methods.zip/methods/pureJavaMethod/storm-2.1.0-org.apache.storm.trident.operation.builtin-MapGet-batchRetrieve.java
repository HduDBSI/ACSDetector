@Override public List<Object> batchRetrieve(ReadOnlyMapState map,List<TridentTuple> keys){
  return map.multiGet((List)keys);
}
