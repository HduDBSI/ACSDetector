public LSApprovedWorkersTupleScheme getScheme(){
  return new LSApprovedWorkersTupleScheme();
}
