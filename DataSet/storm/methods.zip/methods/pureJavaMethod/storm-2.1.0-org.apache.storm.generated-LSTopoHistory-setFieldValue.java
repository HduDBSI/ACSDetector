public void setFieldValue(_Fields field,@org.apache.storm.thrift.annotation.Nullable java.lang.Object value){
switch (field) {
case TOPOLOGY_ID:
    if (value == null) {
      unset_topology_id();
    }
 else {
      set_topology_id((java.lang.String)value);
    }
  break;
case TIME_STAMP:
if (value == null) {
  unset_time_stamp();
}
 else {
  set_time_stamp((java.lang.Long)value);
}
break;
case USERS:
if (value == null) {
unset_users();
}
 else {
set_users((java.util.List<java.lang.String>)value);
}
break;
case GROUPS:
if (value == null) {
unset_groups();
}
 else {
set_groups((java.util.List<java.lang.String>)value);
}
break;
}
}
