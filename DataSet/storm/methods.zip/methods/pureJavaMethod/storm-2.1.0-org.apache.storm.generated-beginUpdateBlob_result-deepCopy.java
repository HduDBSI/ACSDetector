public beginUpdateBlob_result deepCopy(){
  return new beginUpdateBlob_result(this);
}
