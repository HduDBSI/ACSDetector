@Override public void read(org.apache.storm.thrift.protocol.TProtocol prot,JavaObject struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
  struct.full_class_name=iprot.readString();
  struct.set_full_class_name_isSet(true);
{
    org.apache.storm.thrift.protocol.TList _list5=new org.apache.storm.thrift.protocol.TList(org.apache.storm.thrift.protocol.TType.STRUCT,iprot.readI32());
    struct.args_list=new java.util.ArrayList<JavaObjectArg>(_list5.size);
    @org.apache.storm.thrift.annotation.Nullable JavaObjectArg _elem6;
    for (int _i7=0; _i7 < _list5.size; ++_i7) {
      _elem6=new JavaObjectArg();
      _elem6.read(iprot);
      struct.args_list.add(_elem6);
    }
  }
  struct.set_args_list_isSet(true);
}
