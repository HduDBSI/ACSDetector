@Override public java.lang.String toString(){
  java.lang.StringBuilder sb=new java.lang.StringBuilder("ClusterSummary(");
  boolean first=true;
  sb.append("supervisors:");
  if (this.supervisors == null) {
    sb.append("null");
  }
 else {
    sb.append(this.supervisors);
  }
  first=false;
  if (!first)   sb.append(", ");
  sb.append("topologies:");
  if (this.topologies == null) {
    sb.append("null");
  }
 else {
    sb.append(this.topologies);
  }
  first=false;
  if (!first)   sb.append(", ");
  sb.append("nimbuses:");
  if (this.nimbuses == null) {
    sb.append("null");
  }
 else {
    sb.append(this.nimbuses);
  }
  first=false;
  sb.append(")");
  return sb.toString();
}
