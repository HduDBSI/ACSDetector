/** 
 * Called on expiry of events from the window due to  {@link EvictionPolicy}.
 * @param events the expired events
 */
void onExpiry(List<T> events);
