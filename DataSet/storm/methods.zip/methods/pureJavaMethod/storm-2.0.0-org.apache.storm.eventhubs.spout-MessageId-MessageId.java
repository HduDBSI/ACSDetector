public MessageId(String partitionId,String offset,long sequenceNumber){
  this.partitionId=partitionId;
  this.offset=offset;
  this.sequenceNumber=sequenceNumber;
}
