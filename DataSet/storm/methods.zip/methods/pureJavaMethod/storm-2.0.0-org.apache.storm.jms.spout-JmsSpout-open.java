/** 
 * <code>ISpout</code> implementation. <p>Connects the JMS spout to the configured JMS destination topic/queue.
 */
@Override public void open(final Map<String,Object> conf,final TopologyContext context,final SpoutOutputCollector spoutOutputCollector){
  if (jmsProvider == null) {
    throw new IllegalStateException("JMS provider has not been set.");
  }
  if (tupleProducer == null) {
    throw new IllegalStateException("JMS Tuple Producer has not been set.");
  }
  validateJmsAckMode();
  collector=spoutOutputCollector;
  try {
    ConnectionFactory cf=jmsProvider.connectionFactory();
    Destination dest=jmsProvider.destination();
    connection=cf.createConnection();
    session=messageHandler.createSession(connection);
    consumer=session.createConsumer(dest);
    connection.start();
  }
 catch (  Exception e) {
    LOG.warn("Error creating JMS connection.",e);
  }
}
