private void die(Throwable exception){
  String processInfo=process.getProcessInfoString() + process.getProcessTerminationInfoString();
  this.exception=new RuntimeException(processInfo,exception);
  String message=String.format("Halting process: ShellBolt died. Command: %s, ProcessInfo %s",Arrays.toString(command),processInfo);
  LOG.error(message,exception);
  collector.reportError(exception);
  if (!isLocalMode && (running || (exception instanceof Error))) {
    System.exit(11);
  }
}
