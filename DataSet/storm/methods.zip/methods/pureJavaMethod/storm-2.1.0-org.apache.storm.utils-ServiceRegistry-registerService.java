public static String registerService(Object service){
synchronized (_lock) {
    String id=UUID.randomUUID().toString();
    _services.put(id,service);
    return id;
  }
}
