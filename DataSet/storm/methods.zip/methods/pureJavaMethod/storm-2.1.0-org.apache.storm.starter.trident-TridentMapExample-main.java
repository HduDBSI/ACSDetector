public static void main(String[] args) throws Exception {
  Config conf=new Config();
  conf.setMaxSpoutPending(20);
  String topoName="wordCounter";
  if (args.length > 0) {
    topoName=args[0];
  }
  conf.setNumWorkers(3);
  StormSubmitter.submitTopologyWithProgressBar(topoName,conf,buildTopology());
  try (DRPCClient drpc=DRPCClient.getConfiguredClient(conf)){
    for (int i=0; i < 10; i++) {
      System.out.println("DRPC RESULT: " + drpc.execute("words","CAT THE DOG JUMPED"));
      Thread.sleep(1000);
    }
  }
 }
