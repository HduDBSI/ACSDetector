public static void main(String[] args) throws Exception {
  ConfigurableTopology.start(new ExclamationTopology(),args);
}
