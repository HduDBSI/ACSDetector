public List<ByteBuffer> getRoutingKeys(ITuple tuple){
  List<ByteBuffer> keys=new ArrayList<>(routingKeys.size());
  for (  String s : routingKeys) {
    Object value=tuple.getValueByField(s);
    ByteBuffer serialized=CodecRegistry.DEFAULT_INSTANCE.codecFor(value).serialize(value,ProtocolVersion.NEWEST_SUPPORTED);
    keys.add(serialized);
  }
  return keys;
}
