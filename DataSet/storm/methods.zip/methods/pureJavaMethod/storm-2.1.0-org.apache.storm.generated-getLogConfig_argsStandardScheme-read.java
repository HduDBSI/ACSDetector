public void read(org.apache.storm.thrift.protocol.TProtocol iprot,getLogConfig_args struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TField schemeField;
  iprot.readStructBegin();
  while (true) {
    schemeField=iprot.readFieldBegin();
    if (schemeField.type == org.apache.storm.thrift.protocol.TType.STOP) {
      break;
    }
switch (schemeField.id) {
case 1:
      if (schemeField.type == org.apache.storm.thrift.protocol.TType.STRING) {
        struct.name=iprot.readString();
        struct.set_name_isSet(true);
      }
 else {
        org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
      }
    break;
default :
  org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
iprot.readFieldEnd();
}
iprot.readStructEnd();
struct.validate();
}
