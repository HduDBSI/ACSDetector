/** 
 * Factory method that creates a Builder with String key/value deserializers.
 * @param bootstrapServers The bootstrap servers for the consumer
 * @param topics The topic pattern to subscribe to
 * @return The new builder
 */
public static Builder<String,String> builder(String bootstrapServers,Pattern topics){
  return new Builder<String,String>(bootstrapServers,topics).withStringDeserializers();
}
