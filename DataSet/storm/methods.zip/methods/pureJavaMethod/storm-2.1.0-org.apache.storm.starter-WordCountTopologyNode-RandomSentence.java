public RandomSentence(){
  super("node","randomsentence.js");
}
