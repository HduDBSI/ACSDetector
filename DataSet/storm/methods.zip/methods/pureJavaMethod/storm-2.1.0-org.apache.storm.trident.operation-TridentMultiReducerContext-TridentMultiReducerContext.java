public TridentMultiReducerContext(List<TridentTuple.Factory> factories){
  this.factories=factories;
}
