@Test public void testHandlingClusterSubscription(){
  INimbus iNimbus=new INimbusTest();
  Map<String,SupervisorDetails> supMap=genSupervisors(1,4,200,1024 * 10);
  Map<String,Map<String,Number>> resourceUserPool=userResourcePool(userRes("jerry",1_000,8_192),userRes("bobby",10_000,32_768),userRes("derek",5_000,16_384));
  Config config=createClusterConfig(10,128,0,resourceUserPool);
  Topologies topologies=new Topologies(genTopology("topo-1",config,5,15,1,1,currentTime - 2,20,"jerry"),genTopology("topo-2",config,5,15,1,1,currentTime - 8,29,"jerry"));
  Cluster cluster=new Cluster(iNimbus,new ResourceMetrics(new StormMetricsRegistry()),supMap,new HashMap<>(),topologies,config);
  scheduler=new ResourceAwareScheduler();
  scheduler.prepare(config);
  scheduler.schedule(topologies,cluster);
  assertTopologiesFullyScheduled(cluster,"topo-1");
  assertTopologiesNotScheduled(cluster,"topo-2");
}
