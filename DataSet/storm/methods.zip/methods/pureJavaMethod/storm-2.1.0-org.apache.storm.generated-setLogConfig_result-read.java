@Override public void read(org.apache.storm.thrift.protocol.TProtocol prot,setLogConfig_result struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
}
