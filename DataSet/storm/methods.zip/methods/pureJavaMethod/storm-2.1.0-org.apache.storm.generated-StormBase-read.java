@Override public void read(org.apache.storm.thrift.protocol.TProtocol prot,StormBase struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
  struct.name=iprot.readString();
  struct.set_name_isSet(true);
  struct.status=org.apache.storm.generated.TopologyStatus.findByValue(iprot.readI32());
  struct.set_status_isSet(true);
  struct.num_workers=iprot.readI32();
  struct.set_num_workers_isSet(true);
  java.util.BitSet incoming=iprot.readBitSet(8);
  if (incoming.get(0)) {
{
      org.apache.storm.thrift.protocol.TMap _map764=new org.apache.storm.thrift.protocol.TMap(org.apache.storm.thrift.protocol.TType.STRING,org.apache.storm.thrift.protocol.TType.I32,iprot.readI32());
      struct.component_executors=new java.util.HashMap<java.lang.String,java.lang.Integer>(2 * _map764.size);
      @org.apache.storm.thrift.annotation.Nullable java.lang.String _key765;
      int _val766;
      for (int _i767=0; _i767 < _map764.size; ++_i767) {
        _key765=iprot.readString();
        _val766=iprot.readI32();
        struct.component_executors.put(_key765,_val766);
      }
    }
    struct.set_component_executors_isSet(true);
  }
  if (incoming.get(1)) {
    struct.launch_time_secs=iprot.readI32();
    struct.set_launch_time_secs_isSet(true);
  }
  if (incoming.get(2)) {
    struct.owner=iprot.readString();
    struct.set_owner_isSet(true);
  }
  if (incoming.get(3)) {
    struct.topology_action_options=new TopologyActionOptions();
    struct.topology_action_options.read(iprot);
    struct.set_topology_action_options_isSet(true);
  }
  if (incoming.get(4)) {
    struct.prev_status=org.apache.storm.generated.TopologyStatus.findByValue(iprot.readI32());
    struct.set_prev_status_isSet(true);
  }
  if (incoming.get(5)) {
{
      org.apache.storm.thrift.protocol.TMap _map768=new org.apache.storm.thrift.protocol.TMap(org.apache.storm.thrift.protocol.TType.STRING,org.apache.storm.thrift.protocol.TType.STRUCT,iprot.readI32());
      struct.component_debug=new java.util.HashMap<java.lang.String,DebugOptions>(2 * _map768.size);
      @org.apache.storm.thrift.annotation.Nullable java.lang.String _key769;
      @org.apache.storm.thrift.annotation.Nullable DebugOptions _val770;
      for (int _i771=0; _i771 < _map768.size; ++_i771) {
        _key769=iprot.readString();
        _val770=new DebugOptions();
        _val770.read(iprot);
        struct.component_debug.put(_key769,_val770);
      }
    }
    struct.set_component_debug_isSet(true);
  }
  if (incoming.get(6)) {
    struct.principal=iprot.readString();
    struct.set_principal_isSet(true);
  }
  if (incoming.get(7)) {
    struct.topology_version=iprot.readString();
    struct.set_topology_version_isSet(true);
  }
}
