@Override public void prepare(Map conf,int partitionIndex,int numPartitions){
  this.partitionIndex=partitionIndex;
}
