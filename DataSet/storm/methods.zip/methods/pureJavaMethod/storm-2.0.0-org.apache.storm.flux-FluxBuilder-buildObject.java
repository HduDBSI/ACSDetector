private static Object buildObject(ObjectDef def,ExecutionContext context) throws ClassNotFoundException, IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException, NoSuchFieldException {
  Class clazz=Class.forName(def.getClassName());
  Object obj=null;
  if (def.hasConstructorArgs()) {
    LOG.debug("Found constructor arguments in definition: " + def.getConstructorArgs().getClass().getName());
    List<Object> constructorArgs=def.getConstructorArgs();
    if (def.hasReferences()) {
      constructorArgs=resolveReferences(constructorArgs,context);
    }
    Constructor con=findCompatibleConstructor(constructorArgs,clazz);
    if (con != null) {
      LOG.debug("Found something seemingly compatible, attempting invocation...");
      obj=con.newInstance(getArgsWithListCoercion(constructorArgs,con.getParameterTypes()));
    }
 else {
      String msg=String.format("Couldn't find a suitable constructor for class '%s' with arguments '%s'.",clazz.getName(),constructorArgs);
      throw new IllegalArgumentException(msg);
    }
  }
 else   if (def.hasFactory()) {
    Method method=null;
    List<Object> methodArgs=new ArrayList<>();
    if (def.hasFactoryArgs()) {
      methodArgs=def.getFactoryArgs();
      if (def.hasReferences()) {
        methodArgs=resolveReferences(methodArgs,context);
      }
    }
    method=findCompatibleMethod(methodArgs,clazz,def.getFactory());
    if (method != null) {
      obj=method.invoke(null,getArgsWithListCoercion(methodArgs,method.getParameterTypes()));
    }
 else {
      String msg=String.format("Couldn't find a suitable static method '%s' for class '%s' with arguments '%s'.",def.getFactory(),clazz.getName(),methodArgs);
      throw new IllegalArgumentException(msg);
    }
  }
 else {
    obj=clazz.newInstance();
  }
  applyProperties(def,obj,context);
  invokeConfigMethods(def,obj,context);
  return obj;
}
