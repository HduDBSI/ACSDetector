private int deriveNumWindowChunksFrom(int windowLengthInSeconds,int windowUpdateFrequencyInSeconds){
  return windowLengthInSeconds / windowUpdateFrequencyInSeconds;
}
