public getComponentPageInfo_call(java.lang.String topology_id,java.lang.String component_id,java.lang.String window,boolean is_include_sys,org.apache.storm.thrift.async.AsyncMethodCallback<ComponentPageInfo> resultHandler,org.apache.storm.thrift.async.TAsyncClient client,org.apache.storm.thrift.protocol.TProtocolFactory protocolFactory,org.apache.storm.thrift.transport.TNonblockingTransport transport) throws org.apache.storm.thrift.TException {
  super(client,protocolFactory,transport,resultHandler,false);
  this.topology_id=topology_id;
  this.component_id=component_id;
  this.window=window;
  this.is_include_sys=is_include_sys;
}
