/** 
 * Gets the Float field with a specific name.
 * @throws ClassCastException       If that field is not a Float
 * @throws IllegalArgumentException - if field does not exist
 */
public Float getFloatByField(String field);
