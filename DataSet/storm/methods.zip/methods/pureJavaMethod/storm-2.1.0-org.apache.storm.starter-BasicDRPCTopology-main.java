public static void main(String[] args) throws Exception {
  Config conf=new Config();
  String topoName="DRPCExample";
  String function="exclamation";
  if (args != null) {
    if (args.length > 0) {
      topoName=args[0];
    }
    if (args.length > 1) {
      function=args[1];
    }
  }
  LinearDRPCTopologyBuilder builder=new LinearDRPCTopologyBuilder(function);
  builder.addBolt(new ExclaimBolt(),3);
  conf.setNumWorkers(3);
  StormSubmitter.submitTopologyWithProgressBar(topoName,conf,builder.createRemoteTopology());
  if (args != null && args.length > 2) {
    try (DRPCClient drpc=DRPCClient.getConfiguredClient(conf)){
      for (int i=2; i < args.length; i++) {
        String word=args[i];
        System.out.println("Result for \"" + word + "\": "+ drpc.execute(function,word));
      }
    }
   }
}
