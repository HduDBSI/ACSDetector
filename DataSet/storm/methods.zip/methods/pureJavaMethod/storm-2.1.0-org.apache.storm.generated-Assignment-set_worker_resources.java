public void set_worker_resources(@org.apache.storm.thrift.annotation.Nullable java.util.Map<NodeInfo,WorkerResources> worker_resources){
  this.worker_resources=worker_resources;
}
