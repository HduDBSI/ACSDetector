public void setContext(ProcessorContext pc){
  this.context=pc;
}
