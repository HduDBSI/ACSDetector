KafkaConsumer<K,V> createAndSubscribeKafkaConsumer(TopologyContext context){
  kafkaConsumer=new KafkaConsumer<>(kafkaSpoutConfig.getKafkaProps());
  kafkaSpoutConfig.getSubscription().subscribe(kafkaConsumer,new KafkaSpoutConsumerRebalanceListener(),context);
  return kafkaConsumer;
}
