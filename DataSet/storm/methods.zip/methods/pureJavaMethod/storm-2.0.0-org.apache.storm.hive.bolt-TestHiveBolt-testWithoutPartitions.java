@Test public void testWithoutPartitions() throws Exception {
  DelimitedRecordHiveMapper mapper=new DelimitedRecordHiveMapper().withColumnFields(new Fields(colNames));
  HiveOptions hiveOptions=new HiveOptions(metaStoreURI,dbName1,tblName1,mapper).withTxnsPerBatch(2).withBatchSize(2).withAutoCreatePartitions(false);
  bolt=new TestingHiveBolt(hiveOptions);
  bolt.prepare(config,null,collector);
  Integer id=100;
  String msg="test-123";
  String city="sunnyvale";
  String state="ca";
  Set<Tuple> tupleSet=new HashSet<Tuple>();
  for (int i=0; i < 4; i++) {
    Tuple tuple=generateTestTuple(id,msg,city,state);
    bolt.execute(tuple);
    tupleSet.add(tuple);
  }
  List<String> partVals=Collections.emptyList();
  for (  Tuple t : tupleSet) {
    verify(collector).ack(t);
  }
  List<byte[]> recordWritten=bolt.getRecordWritten(partVals);
  Assert.assertNotNull(recordWritten);
  Assert.assertEquals(4,recordWritten.size());
  bolt.cleanup();
}
