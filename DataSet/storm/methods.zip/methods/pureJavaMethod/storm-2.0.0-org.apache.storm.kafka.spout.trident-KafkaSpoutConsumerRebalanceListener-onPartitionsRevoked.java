@Override public void onPartitionsRevoked(Collection<TopicPartition> partitions){
  LOG.info("Partitions revoked. [consumer={}, topic-partitions={}]",consumer,partitions);
}
