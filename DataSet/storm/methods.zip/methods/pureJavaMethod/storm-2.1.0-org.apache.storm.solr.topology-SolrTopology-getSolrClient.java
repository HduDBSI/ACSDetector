protected static SolrClient getSolrClient(){
  String zkHostString="127.0.0.1:9983";
  return new CloudSolrClient(zkHostString);
}
