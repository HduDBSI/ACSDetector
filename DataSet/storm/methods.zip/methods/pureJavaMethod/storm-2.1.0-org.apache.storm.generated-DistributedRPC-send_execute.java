public void send_execute(java.lang.String functionName,java.lang.String funcArgs) throws org.apache.storm.thrift.TException {
  execute_args args=new execute_args();
  args.set_functionName(functionName);
  args.set_funcArgs(funcArgs);
  sendBase("execute",args);
}
