/** 
 * Given a File input it will unzip the file in a the unzip directory passed as the second parameter
 * @param inFile The zip file as input
 * @param toDir The unzip directory where to unzip the zip file.
 * @throws IOException
 */
public static void unZip(File inFile,File toDir) throws IOException {
  try (ZipFile zipFile=new ZipFile(inFile)){
    extractZipFile(zipFile,toDir,null);
  }
 }
