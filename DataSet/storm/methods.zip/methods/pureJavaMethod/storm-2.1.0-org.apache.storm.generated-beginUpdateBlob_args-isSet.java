/** 
 * Returns true if field corresponding to fieldID is set (has been assigned a value) and false otherwise 
 */
public boolean isSet(_Fields field){
  if (field == null) {
    throw new java.lang.IllegalArgumentException();
  }
switch (field) {
case KEY:
    return is_set_key();
}
throw new java.lang.IllegalStateException();
}
