public long getByteCount(){
  return byteCount;
}
