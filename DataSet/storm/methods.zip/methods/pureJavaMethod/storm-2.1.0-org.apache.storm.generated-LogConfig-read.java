@Override public void read(org.apache.storm.thrift.protocol.TProtocol prot,LogConfig struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
  java.util.BitSet incoming=iprot.readBitSet(1);
  if (incoming.get(0)) {
{
      org.apache.storm.thrift.protocol.TMap _map858=new org.apache.storm.thrift.protocol.TMap(org.apache.storm.thrift.protocol.TType.STRING,org.apache.storm.thrift.protocol.TType.STRUCT,iprot.readI32());
      struct.named_logger_level=new java.util.HashMap<java.lang.String,LogLevel>(2 * _map858.size);
      @org.apache.storm.thrift.annotation.Nullable java.lang.String _key859;
      @org.apache.storm.thrift.annotation.Nullable LogLevel _val860;
      for (int _i861=0; _i861 < _map858.size; ++_i861) {
        _key859=iprot.readString();
        _val860=new LogLevel();
        _val860.read(iprot);
        struct.named_logger_level.put(_key859,_val860);
      }
    }
    struct.set_named_logger_level_isSet(true);
  }
}
