public DRPCRequest recv_fetchRequest() throws AuthorizationException, org.apache.storm.thrift.TException {
  fetchRequest_result result=new fetchRequest_result();
  receiveBase(result,"fetchRequest");
  if (result.is_set_success()) {
    return result.success;
  }
  if (result.aze != null) {
    throw result.aze;
  }
  throw new org.apache.storm.thrift.TApplicationException(org.apache.storm.thrift.TApplicationException.MISSING_RESULT,"fetchRequest failed: unknown result");
}
