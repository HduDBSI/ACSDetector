@Override public void read(org.apache.storm.thrift.protocol.TProtocol prot,TopologyPageInfo struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
  struct.id=iprot.readString();
  struct.set_id_isSet(true);
  java.util.BitSet incoming=iprot.readBitSet(31);
  if (incoming.get(0)) {
    struct.name=iprot.readString();
    struct.set_name_isSet(true);
  }
  if (incoming.get(1)) {
    struct.uptime_secs=iprot.readI32();
    struct.set_uptime_secs_isSet(true);
  }
  if (incoming.get(2)) {
    struct.status=iprot.readString();
    struct.set_status_isSet(true);
  }
  if (incoming.get(3)) {
    struct.num_tasks=iprot.readI32();
    struct.set_num_tasks_isSet(true);
  }
  if (incoming.get(4)) {
    struct.num_workers=iprot.readI32();
    struct.set_num_workers_isSet(true);
  }
  if (incoming.get(5)) {
    struct.num_executors=iprot.readI32();
    struct.set_num_executors_isSet(true);
  }
  if (incoming.get(6)) {
    struct.topology_conf=iprot.readString();
    struct.set_topology_conf_isSet(true);
  }
  if (incoming.get(7)) {
{
      org.apache.storm.thrift.protocol.TMap _map499=new org.apache.storm.thrift.protocol.TMap(org.apache.storm.thrift.protocol.TType.STRING,org.apache.storm.thrift.protocol.TType.STRUCT,iprot.readI32());
      struct.id_to_spout_agg_stats=new java.util.HashMap<java.lang.String,ComponentAggregateStats>(2 * _map499.size);
      @org.apache.storm.thrift.annotation.Nullable java.lang.String _key500;
      @org.apache.storm.thrift.annotation.Nullable ComponentAggregateStats _val501;
      for (int _i502=0; _i502 < _map499.size; ++_i502) {
        _key500=iprot.readString();
        _val501=new ComponentAggregateStats();
        _val501.read(iprot);
        struct.id_to_spout_agg_stats.put(_key500,_val501);
      }
    }
    struct.set_id_to_spout_agg_stats_isSet(true);
  }
  if (incoming.get(8)) {
{
      org.apache.storm.thrift.protocol.TMap _map503=new org.apache.storm.thrift.protocol.TMap(org.apache.storm.thrift.protocol.TType.STRING,org.apache.storm.thrift.protocol.TType.STRUCT,iprot.readI32());
      struct.id_to_bolt_agg_stats=new java.util.HashMap<java.lang.String,ComponentAggregateStats>(2 * _map503.size);
      @org.apache.storm.thrift.annotation.Nullable java.lang.String _key504;
      @org.apache.storm.thrift.annotation.Nullable ComponentAggregateStats _val505;
      for (int _i506=0; _i506 < _map503.size; ++_i506) {
        _key504=iprot.readString();
        _val505=new ComponentAggregateStats();
        _val505.read(iprot);
        struct.id_to_bolt_agg_stats.put(_key504,_val505);
      }
    }
    struct.set_id_to_bolt_agg_stats_isSet(true);
  }
  if (incoming.get(9)) {
    struct.sched_status=iprot.readString();
    struct.set_sched_status_isSet(true);
  }
  if (incoming.get(10)) {
    struct.topology_stats=new TopologyStats();
    struct.topology_stats.read(iprot);
    struct.set_topology_stats_isSet(true);
  }
  if (incoming.get(11)) {
    struct.owner=iprot.readString();
    struct.set_owner_isSet(true);
  }
  if (incoming.get(12)) {
    struct.debug_options=new DebugOptions();
    struct.debug_options.read(iprot);
    struct.set_debug_options_isSet(true);
  }
  if (incoming.get(13)) {
    struct.replication_count=iprot.readI32();
    struct.set_replication_count_isSet(true);
  }
  if (incoming.get(14)) {
{
      org.apache.storm.thrift.protocol.TList _list507=new org.apache.storm.thrift.protocol.TList(org.apache.storm.thrift.protocol.TType.STRUCT,iprot.readI32());
      struct.workers=new java.util.ArrayList<WorkerSummary>(_list507.size);
      @org.apache.storm.thrift.annotation.Nullable WorkerSummary _elem508;
      for (int _i509=0; _i509 < _list507.size; ++_i509) {
        _elem508=new WorkerSummary();
        _elem508.read(iprot);
        struct.workers.add(_elem508);
      }
    }
    struct.set_workers_isSet(true);
  }
  if (incoming.get(15)) {
    struct.storm_version=iprot.readString();
    struct.set_storm_version_isSet(true);
  }
  if (incoming.get(16)) {
    struct.topology_version=iprot.readString();
    struct.set_topology_version_isSet(true);
  }
  if (incoming.get(17)) {
    struct.requested_memonheap=iprot.readDouble();
    struct.set_requested_memonheap_isSet(true);
  }
  if (incoming.get(18)) {
    struct.requested_memoffheap=iprot.readDouble();
    struct.set_requested_memoffheap_isSet(true);
  }
  if (incoming.get(19)) {
    struct.requested_cpu=iprot.readDouble();
    struct.set_requested_cpu_isSet(true);
  }
  if (incoming.get(20)) {
    struct.assigned_memonheap=iprot.readDouble();
    struct.set_assigned_memonheap_isSet(true);
  }
  if (incoming.get(21)) {
    struct.assigned_memoffheap=iprot.readDouble();
    struct.set_assigned_memoffheap_isSet(true);
  }
  if (incoming.get(22)) {
    struct.assigned_cpu=iprot.readDouble();
    struct.set_assigned_cpu_isSet(true);
  }
  if (incoming.get(23)) {
    struct.requested_regular_on_heap_memory=iprot.readDouble();
    struct.set_requested_regular_on_heap_memory_isSet(true);
  }
  if (incoming.get(24)) {
    struct.requested_shared_on_heap_memory=iprot.readDouble();
    struct.set_requested_shared_on_heap_memory_isSet(true);
  }
  if (incoming.get(25)) {
    struct.requested_regular_off_heap_memory=iprot.readDouble();
    struct.set_requested_regular_off_heap_memory_isSet(true);
  }
  if (incoming.get(26)) {
    struct.requested_shared_off_heap_memory=iprot.readDouble();
    struct.set_requested_shared_off_heap_memory_isSet(true);
  }
  if (incoming.get(27)) {
    struct.assigned_regular_on_heap_memory=iprot.readDouble();
    struct.set_assigned_regular_on_heap_memory_isSet(true);
  }
  if (incoming.get(28)) {
    struct.assigned_shared_on_heap_memory=iprot.readDouble();
    struct.set_assigned_shared_on_heap_memory_isSet(true);
  }
  if (incoming.get(29)) {
    struct.assigned_regular_off_heap_memory=iprot.readDouble();
    struct.set_assigned_regular_off_heap_memory_isSet(true);
  }
  if (incoming.get(30)) {
    struct.assigned_shared_off_heap_memory=iprot.readDouble();
    struct.set_assigned_shared_off_heap_memory_isSet(true);
  }
}
