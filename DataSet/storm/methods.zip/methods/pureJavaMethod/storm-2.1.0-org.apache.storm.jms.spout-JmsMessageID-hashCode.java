@Override public int hashCode(){
  return this.sequence.hashCode();
}
