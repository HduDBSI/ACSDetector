@Override public void read(org.apache.storm.thrift.protocol.TProtocol prot,InvalidTopologyException struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
  struct.msg=iprot.readString();
  struct.set_msg_isSet(true);
}
