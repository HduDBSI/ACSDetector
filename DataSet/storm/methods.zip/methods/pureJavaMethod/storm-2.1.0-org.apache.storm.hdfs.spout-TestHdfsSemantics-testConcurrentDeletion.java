@Test public void testConcurrentDeletion() throws Exception {
  Path file=new Path(dir.toString() + Path.SEPARATOR_CHAR + "file1");
  fs.create(file).close();
  FileDeletionThread[] threads=null;
  try {
    threads=startThreads(10,file);
    int successCount=0;
    for (    FileDeletionThread thd : threads) {
      thd.join(30_000);
      if (thd.succeeded) {
        successCount++;
      }
      if (thd.exception != null) {
        Assert.assertNotNull(thd.exception);
      }
    }
    System.err.println(successCount);
    Assert.assertEquals(1,successCount);
  }
  finally {
    if (threads != null) {
      for (      FileDeletionThread thread : threads) {
        thread.interrupt();
        thread.join(30_000);
        if (thread.isAlive()) {
          throw new RuntimeException("Failed to stop threads within 30 seconds, threads may leak into other tests");
        }
      }
    }
  }
}
