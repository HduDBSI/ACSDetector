@Override public void close() throws IOException {
  try {
synchronized (client) {
      client.getClient().finishBlobUpload(session);
      client.getClient().createStateInZookeeper(key);
    }
  }
 catch (  TException e) {
    throw new RuntimeException(e);
  }
}
