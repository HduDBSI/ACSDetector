public void write_args(org.apache.storm.thrift.protocol.TProtocol prot) throws org.apache.storm.thrift.TException {
  prot.writeMessageBegin(new org.apache.storm.thrift.protocol.TMessage("failRequest",org.apache.storm.thrift.protocol.TMessageType.CALL,0));
  failRequest_args args=new failRequest_args();
  args.set_id(id);
  args.write(prot);
  prot.writeMessageEnd();
}
