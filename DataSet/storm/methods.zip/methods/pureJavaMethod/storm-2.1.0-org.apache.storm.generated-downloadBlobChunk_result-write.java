@Override public void write(org.apache.storm.thrift.protocol.TProtocol prot,downloadBlobChunk_result struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
  java.util.BitSet optionals=new java.util.BitSet();
  if (struct.is_set_success()) {
    optionals.set(0);
  }
  if (struct.is_set_aze()) {
    optionals.set(1);
  }
  oprot.writeBitSet(optionals,2);
  if (struct.is_set_success()) {
    oprot.writeBinary(struct.success);
  }
  if (struct.is_set_aze()) {
    struct.aze.write(oprot);
  }
}
