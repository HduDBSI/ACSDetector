public void write_args(org.apache.storm.thrift.protocol.TProtocol prot) throws org.apache.storm.thrift.TException {
  prot.writeMessageBegin(new org.apache.storm.thrift.protocol.TMessage("submitTopology",org.apache.storm.thrift.protocol.TMessageType.CALL,0));
  submitTopology_args args=new submitTopology_args();
  args.set_name(name);
  args.set_uploadedJarLocation(uploadedJarLocation);
  args.set_jsonConf(jsonConf);
  args.set_topology(topology);
  args.write(prot);
  prot.writeMessageEnd();
}
