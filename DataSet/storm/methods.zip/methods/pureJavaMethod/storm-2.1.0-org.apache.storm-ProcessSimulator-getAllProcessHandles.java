/** 
 * Get all process handles
 * @return
 */
public static Collection<Shutdownable> getAllProcessHandles(){
  return processMap.values();
}
