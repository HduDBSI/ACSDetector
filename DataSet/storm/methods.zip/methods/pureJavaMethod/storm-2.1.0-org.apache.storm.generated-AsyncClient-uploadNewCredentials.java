public void uploadNewCredentials(java.lang.String name,Credentials creds,org.apache.storm.thrift.async.AsyncMethodCallback<Void> resultHandler) throws org.apache.storm.thrift.TException {
  checkReady();
  uploadNewCredentials_call method_call=new uploadNewCredentials_call(name,creds,resultHandler,this,___protocolFactory,___transport);
  this.___currentMethod=method_call;
  ___manager.call(method_call);
}
