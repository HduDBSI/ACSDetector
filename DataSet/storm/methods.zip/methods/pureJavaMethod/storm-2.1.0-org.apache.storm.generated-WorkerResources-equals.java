public boolean equals(WorkerResources that){
  if (that == null)   return false;
  if (this == that)   return true;
  boolean this_present_mem_on_heap=true && this.is_set_mem_on_heap();
  boolean that_present_mem_on_heap=true && that.is_set_mem_on_heap();
  if (this_present_mem_on_heap || that_present_mem_on_heap) {
    if (!(this_present_mem_on_heap && that_present_mem_on_heap))     return false;
    if (this.mem_on_heap != that.mem_on_heap)     return false;
  }
  boolean this_present_mem_off_heap=true && this.is_set_mem_off_heap();
  boolean that_present_mem_off_heap=true && that.is_set_mem_off_heap();
  if (this_present_mem_off_heap || that_present_mem_off_heap) {
    if (!(this_present_mem_off_heap && that_present_mem_off_heap))     return false;
    if (this.mem_off_heap != that.mem_off_heap)     return false;
  }
  boolean this_present_cpu=true && this.is_set_cpu();
  boolean that_present_cpu=true && that.is_set_cpu();
  if (this_present_cpu || that_present_cpu) {
    if (!(this_present_cpu && that_present_cpu))     return false;
    if (this.cpu != that.cpu)     return false;
  }
  boolean this_present_shared_mem_on_heap=true && this.is_set_shared_mem_on_heap();
  boolean that_present_shared_mem_on_heap=true && that.is_set_shared_mem_on_heap();
  if (this_present_shared_mem_on_heap || that_present_shared_mem_on_heap) {
    if (!(this_present_shared_mem_on_heap && that_present_shared_mem_on_heap))     return false;
    if (this.shared_mem_on_heap != that.shared_mem_on_heap)     return false;
  }
  boolean this_present_shared_mem_off_heap=true && this.is_set_shared_mem_off_heap();
  boolean that_present_shared_mem_off_heap=true && that.is_set_shared_mem_off_heap();
  if (this_present_shared_mem_off_heap || that_present_shared_mem_off_heap) {
    if (!(this_present_shared_mem_off_heap && that_present_shared_mem_off_heap))     return false;
    if (this.shared_mem_off_heap != that.shared_mem_off_heap)     return false;
  }
  boolean this_present_resources=true && this.is_set_resources();
  boolean that_present_resources=true && that.is_set_resources();
  if (this_present_resources || that_present_resources) {
    if (!(this_present_resources && that_present_resources))     return false;
    if (!this.resources.equals(that.resources))     return false;
  }
  boolean this_present_shared_resources=true && this.is_set_shared_resources();
  boolean that_present_shared_resources=true && that.is_set_shared_resources();
  if (this_present_shared_resources || that_present_shared_resources) {
    if (!(this_present_shared_resources && that_present_shared_resources))     return false;
    if (!this.shared_resources.equals(that.shared_resources))     return false;
  }
  return true;
}
