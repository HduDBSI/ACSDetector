public getComponentPendingProfileActions_resultTupleScheme getScheme(){
  return new getComponentPendingProfileActions_resultTupleScheme();
}
