public static SlidingDurationWindow of(BaseWindowedBolt.Duration windowDuration,BaseWindowedBolt.Duration slidingDuration){
  return new SlidingDurationWindow(windowDuration.value,slidingDuration.value);
}
