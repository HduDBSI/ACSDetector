/** 
 * Publishes topics on connection.
 * @throws Exception if an exception during publishing occurs
 */
public static void publish() throws Exception {
  String topic="/users/tgoetz/office/1234";
  Random rand=new Random();
  LOG.info("Publishing to topic {}",topic);
  LOG.info("Cntrl+C to exit.");
  while (true) {
    int temp=rand.nextInt(TEMPERATURE_MAX);
    int hum=rand.nextInt(HUMIDITY_MAX);
    String payload=temp + "/" + hum;
    connection.publish(topic,payload.getBytes(),QoS.AT_LEAST_ONCE,false);
    Thread.sleep(WAIT_MILLIS_DEFAULT);
  }
}
