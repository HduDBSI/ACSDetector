/** 
 * Returns true if field aze is set (has been assigned a value) and false otherwise 
 */
public boolean is_set_aze(){
  return this.aze != null;
}
