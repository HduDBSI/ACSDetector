public boolean equals(LocalAssignment that){
  if (that == null)   return false;
  if (this == that)   return true;
  boolean this_present_topology_id=true && this.is_set_topology_id();
  boolean that_present_topology_id=true && that.is_set_topology_id();
  if (this_present_topology_id || that_present_topology_id) {
    if (!(this_present_topology_id && that_present_topology_id))     return false;
    if (!this.topology_id.equals(that.topology_id))     return false;
  }
  boolean this_present_executors=true && this.is_set_executors();
  boolean that_present_executors=true && that.is_set_executors();
  if (this_present_executors || that_present_executors) {
    if (!(this_present_executors && that_present_executors))     return false;
    if (!this.executors.equals(that.executors))     return false;
  }
  boolean this_present_resources=true && this.is_set_resources();
  boolean that_present_resources=true && that.is_set_resources();
  if (this_present_resources || that_present_resources) {
    if (!(this_present_resources && that_present_resources))     return false;
    if (!this.resources.equals(that.resources))     return false;
  }
  boolean this_present_total_node_shared=true && this.is_set_total_node_shared();
  boolean that_present_total_node_shared=true && that.is_set_total_node_shared();
  if (this_present_total_node_shared || that_present_total_node_shared) {
    if (!(this_present_total_node_shared && that_present_total_node_shared))     return false;
    if (this.total_node_shared != that.total_node_shared)     return false;
  }
  boolean this_present_owner=true && this.is_set_owner();
  boolean that_present_owner=true && that.is_set_owner();
  if (this_present_owner || that_present_owner) {
    if (!(this_present_owner && that_present_owner))     return false;
    if (!this.owner.equals(that.owner))     return false;
  }
  return true;
}
