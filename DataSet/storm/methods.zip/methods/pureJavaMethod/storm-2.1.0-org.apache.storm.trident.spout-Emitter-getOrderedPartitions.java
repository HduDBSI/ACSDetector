/** 
 * Sorts the partition info to produce an ordered list of partition.
 * @param allPartitionInfo The partition info for all partitions being processed by all spout tasks
 * @return The ordered list of partitions being processed by all the tasks. The ordering must be consistent for all tasks.
 */
List<PartitionT> getOrderedPartitions(PartitionsT allPartitionInfo);
