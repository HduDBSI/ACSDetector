@Override public void write(org.apache.storm.thrift.protocol.TProtocol prot,LSApprovedWorkers struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
{
    oprot.writeI32(struct.approved_workers.size());
    for (    java.util.Map.Entry<java.lang.String,java.lang.Integer> _iter805 : struct.approved_workers.entrySet()) {
      oprot.writeString(_iter805.getKey());
      oprot.writeI32(_iter805.getValue());
    }
  }
}
