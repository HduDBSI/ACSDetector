public void setActive(boolean flag){
  this.active.set(flag);
}
