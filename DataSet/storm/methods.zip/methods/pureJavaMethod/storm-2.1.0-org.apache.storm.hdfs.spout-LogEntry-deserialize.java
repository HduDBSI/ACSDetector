public static LogEntry deserialize(String line){
  String[] fields=line.split(",",NUM_FIELDS);
  return new LogEntry(Long.parseLong(fields[0]),fields[1],fields[2]);
}
