public HdfsFileOptions withRecordFormat(RecordFormat format){
  this.format=format;
  return this;
}
