@Override public void read(org.apache.storm.thrift.protocol.TProtocol prot,ClusterWorkerHeartbeat struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
  struct.storm_id=iprot.readString();
  struct.set_storm_id_isSet(true);
{
    org.apache.storm.thrift.protocol.TMap _map778=new org.apache.storm.thrift.protocol.TMap(org.apache.storm.thrift.protocol.TType.STRUCT,org.apache.storm.thrift.protocol.TType.STRUCT,iprot.readI32());
    struct.executor_stats=new java.util.HashMap<ExecutorInfo,ExecutorStats>(2 * _map778.size);
    @org.apache.storm.thrift.annotation.Nullable ExecutorInfo _key779;
    @org.apache.storm.thrift.annotation.Nullable ExecutorStats _val780;
    for (int _i781=0; _i781 < _map778.size; ++_i781) {
      _key779=new ExecutorInfo();
      _key779.read(iprot);
      _val780=new ExecutorStats();
      _val780.read(iprot);
      struct.executor_stats.put(_key779,_val780);
    }
  }
  struct.set_executor_stats_isSet(true);
  struct.time_secs=iprot.readI32();
  struct.set_time_secs_isSet(true);
  struct.uptime_secs=iprot.readI32();
  struct.set_uptime_secs_isSet(true);
}
