@Override public void nextTuple(){
  if (eventId < myCount) {
    eventId++;
    collector.emit(new Values(source,eventId),eventId);
  }
}
