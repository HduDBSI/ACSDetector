public LocalContainer(Map<String,Object> conf,String supervisorId,int supervisorPort,int port,LocalAssignment assignment,IContext sharedContext,StormMetricsRegistry metricsRegistry,ContainerMemoryTracker containerMemoryTracker,org.apache.storm.generated.Supervisor.Iface localSupervisor) throws IOException {
  super(ContainerType.LAUNCH,conf,supervisorId,supervisorPort,port,assignment,null,null,null,null,metricsRegistry,containerMemoryTracker);
  _sharedContext=sharedContext;
  _workerId=Utils.uuid();
  this.localSupervisor=localSupervisor;
}
