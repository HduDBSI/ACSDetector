@Override public void removeStorm(String stormId){
  stateStorage.delete_node(ClusterUtils.assignmentPath(stormId));
  this.assignmentsBackend.clearStateForStorm(stormId);
  stateStorage.delete_node(ClusterUtils.credentialsPath(stormId));
  stateStorage.delete_node(ClusterUtils.logConfigPath(stormId));
  stateStorage.delete_node(ClusterUtils.profilerConfigPath(stormId));
  removeStormBase(stormId);
}
