public void declare(boolean direct,Fields fields);
