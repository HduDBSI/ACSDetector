@Override public void read(org.apache.storm.thrift.protocol.TProtocol prot,ExecutorStats struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
{
    org.apache.storm.thrift.protocol.TMap _map344=new org.apache.storm.thrift.protocol.TMap(org.apache.storm.thrift.protocol.TType.STRING,org.apache.storm.thrift.protocol.TType.MAP,iprot.readI32());
    struct.emitted=new java.util.HashMap<java.lang.String,java.util.Map<java.lang.String,java.lang.Long>>(2 * _map344.size);
    @org.apache.storm.thrift.annotation.Nullable java.lang.String _key345;
    @org.apache.storm.thrift.annotation.Nullable java.util.Map<java.lang.String,java.lang.Long> _val346;
    for (int _i347=0; _i347 < _map344.size; ++_i347) {
      _key345=iprot.readString();
{
        org.apache.storm.thrift.protocol.TMap _map348=new org.apache.storm.thrift.protocol.TMap(org.apache.storm.thrift.protocol.TType.STRING,org.apache.storm.thrift.protocol.TType.I64,iprot.readI32());
        _val346=new java.util.HashMap<java.lang.String,java.lang.Long>(2 * _map348.size);
        @org.apache.storm.thrift.annotation.Nullable java.lang.String _key349;
        long _val350;
        for (int _i351=0; _i351 < _map348.size; ++_i351) {
          _key349=iprot.readString();
          _val350=iprot.readI64();
          _val346.put(_key349,_val350);
        }
      }
      struct.emitted.put(_key345,_val346);
    }
  }
  struct.set_emitted_isSet(true);
{
    org.apache.storm.thrift.protocol.TMap _map352=new org.apache.storm.thrift.protocol.TMap(org.apache.storm.thrift.protocol.TType.STRING,org.apache.storm.thrift.protocol.TType.MAP,iprot.readI32());
    struct.transferred=new java.util.HashMap<java.lang.String,java.util.Map<java.lang.String,java.lang.Long>>(2 * _map352.size);
    @org.apache.storm.thrift.annotation.Nullable java.lang.String _key353;
    @org.apache.storm.thrift.annotation.Nullable java.util.Map<java.lang.String,java.lang.Long> _val354;
    for (int _i355=0; _i355 < _map352.size; ++_i355) {
      _key353=iprot.readString();
{
        org.apache.storm.thrift.protocol.TMap _map356=new org.apache.storm.thrift.protocol.TMap(org.apache.storm.thrift.protocol.TType.STRING,org.apache.storm.thrift.protocol.TType.I64,iprot.readI32());
        _val354=new java.util.HashMap<java.lang.String,java.lang.Long>(2 * _map356.size);
        @org.apache.storm.thrift.annotation.Nullable java.lang.String _key357;
        long _val358;
        for (int _i359=0; _i359 < _map356.size; ++_i359) {
          _key357=iprot.readString();
          _val358=iprot.readI64();
          _val354.put(_key357,_val358);
        }
      }
      struct.transferred.put(_key353,_val354);
    }
  }
  struct.set_transferred_isSet(true);
  struct.specific=new ExecutorSpecificStats();
  struct.specific.read(iprot);
  struct.set_specific_isSet(true);
  struct.rate=iprot.readDouble();
  struct.set_rate_isSet(true);
}
