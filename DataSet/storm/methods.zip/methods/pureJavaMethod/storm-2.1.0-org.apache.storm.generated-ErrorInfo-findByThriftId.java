/** 
 * Find the _Fields constant that matches fieldId, or null if its not found.
 */
@org.apache.storm.thrift.annotation.Nullable public static _Fields findByThriftId(int fieldId){
switch (fieldId) {
case 1:
    return ERROR;
case 2:
  return ERROR_TIME_SECS;
case 3:
return HOST;
case 4:
return PORT;
default :
return null;
}
}
