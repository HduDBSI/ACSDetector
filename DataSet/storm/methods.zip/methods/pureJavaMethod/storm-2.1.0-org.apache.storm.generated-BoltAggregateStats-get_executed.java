public long get_executed(){
  return this.executed;
}
