@Override public void addTuplesBatch(Object batchId,List<TridentTuple> tuples){
  LOG.debug("Adding tuples to window-manager for batch: [{}]",batchId);
  for (  TridentTuple tridentTuple : tuples) {
    windowManager.add(tridentTuple);
  }
}
