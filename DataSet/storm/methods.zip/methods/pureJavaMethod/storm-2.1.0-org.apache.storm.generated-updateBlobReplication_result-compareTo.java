@Override public int compareTo(updateBlobReplication_result other){
  if (!getClass().equals(other.getClass())) {
    return getClass().getName().compareTo(other.getClass().getName());
  }
  int lastComparison=0;
  lastComparison=java.lang.Boolean.valueOf(is_set_success()).compareTo(other.is_set_success());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_success()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.success,other.success);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_aze()).compareTo(other.is_set_aze());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_aze()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.aze,other.aze);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_knf()).compareTo(other.is_set_knf());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_knf()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.knf,other.knf);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  return 0;
}
