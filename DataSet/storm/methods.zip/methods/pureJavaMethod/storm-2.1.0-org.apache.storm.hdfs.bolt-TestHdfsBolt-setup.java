@Before public void setup() throws Exception {
  fs=dfsClusterRule.getDfscluster().getFileSystem();
  hdfsURI="hdfs://localhost:" + dfsClusterRule.getDfscluster().getNameNodePort() + "/";
}
