public MockSpout(List<Values> records,Fields outputFields){
  this.records=records;
  this.outputFields=outputFields;
}
