/** 
 * Find the _Fields constant that matches fieldId, throwing an exception if it is not found.
 */
public static _Fields findByThriftIdOrThrow(int fieldId){
  _Fields fields=findByThriftId(fieldId);
  if (fields == null)   throw new java.lang.IllegalArgumentException("Field " + fieldId + " doesn't exist!");
  return fields;
}
