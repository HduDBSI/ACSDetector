@Nullable @Override public LogData apply(@Nullable String input){
  return new LogData(input);
}
