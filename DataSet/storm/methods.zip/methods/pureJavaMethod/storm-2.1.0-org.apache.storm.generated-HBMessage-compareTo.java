@Override public int compareTo(HBMessage other){
  if (!getClass().equals(other.getClass())) {
    return getClass().getName().compareTo(other.getClass().getName());
  }
  int lastComparison=0;
  lastComparison=java.lang.Boolean.valueOf(is_set_type()).compareTo(other.is_set_type());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_type()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.type,other.type);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_data()).compareTo(other.is_set_data());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_data()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.data,other.data);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_message_id()).compareTo(other.is_set_message_id());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_message_id()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.message_id,other.message_id);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  return 0;
}
