private static void runCli(CommandLine cmd) throws Exception {
  if (!cmd.hasOption(OPTION_NO_SPLASH)) {
    printSplash();
  }
  boolean dumpYaml=cmd.hasOption("dump-yaml");
  TopologyDef topologyDef=null;
  String filePath=(String)cmd.getArgList().get(0);
  String filterProps=null;
  if (cmd.hasOption(OPTION_FILTER)) {
    filterProps=cmd.getOptionValue(OPTION_FILTER);
  }
  Properties properties=null;
  boolean envFilter=cmd.hasOption(OPTION_ENV_FILTER);
  if (cmd.hasOption(OPTION_RESOURCE)) {
    printf("Parsing classpath resource: %s",filePath);
    properties=FluxParser.parseProperties(filterProps,true);
    topologyDef=FluxParser.parseResource(filePath,dumpYaml,true,properties,envFilter);
  }
 else {
    printf("Parsing file: %s",new File(filePath).getAbsolutePath());
    properties=FluxParser.parseProperties(filterProps,false);
    topologyDef=FluxParser.parseFile(filePath,dumpYaml,true,properties,envFilter);
  }
  String topologyName=topologyDef.getName();
  Config conf=FluxBuilder.buildConfig(topologyDef);
  ExecutionContext context=new ExecutionContext(topologyDef,conf);
  StormTopology topology=FluxBuilder.buildTopology(context);
  if (!cmd.hasOption(OPTION_NO_DETAIL)) {
    printTopologyInfo(context);
  }
  if (!cmd.hasOption(OPTION_DRY_RUN)) {
    SubmitOptions submitOptions=null;
    if (cmd.hasOption(OPTION_INACTIVE)) {
      LOG.info("Deploying topology in an INACTIVE state...");
      submitOptions=new SubmitOptions(TopologyInitialStatus.INACTIVE);
    }
 else {
      LOG.info("Deploying topology in an ACTIVE state...");
      submitOptions=new SubmitOptions(TopologyInitialStatus.ACTIVE);
    }
    StormSubmitter.submitTopology(topologyName,conf,topology,submitOptions,null);
  }
}
