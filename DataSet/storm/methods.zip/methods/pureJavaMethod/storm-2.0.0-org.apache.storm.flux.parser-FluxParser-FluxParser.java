private FluxParser(){
}
