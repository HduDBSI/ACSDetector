public void read(org.apache.storm.thrift.protocol.TProtocol iprot,LocalStateData struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TField schemeField;
  iprot.readStructBegin();
  while (true) {
    schemeField=iprot.readFieldBegin();
    if (schemeField.type == org.apache.storm.thrift.protocol.TType.STOP) {
      break;
    }
switch (schemeField.id) {
case 1:
      if (schemeField.type == org.apache.storm.thrift.protocol.TType.MAP) {
{
          org.apache.storm.thrift.protocol.TMap _map782=iprot.readMapBegin();
          struct.serialized_parts=new java.util.HashMap<java.lang.String,ThriftSerializedObject>(2 * _map782.size);
          @org.apache.storm.thrift.annotation.Nullable java.lang.String _key783;
          @org.apache.storm.thrift.annotation.Nullable ThriftSerializedObject _val784;
          for (int _i785=0; _i785 < _map782.size; ++_i785) {
            _key783=iprot.readString();
            _val784=new ThriftSerializedObject();
            _val784.read(iprot);
            struct.serialized_parts.put(_key783,_val784);
          }
          iprot.readMapEnd();
        }
        struct.set_serialized_parts_isSet(true);
      }
 else {
        org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
      }
    break;
default :
  org.apache.storm.thrift.protocol.TProtocolUtil.skip(iprot,schemeField.type);
}
iprot.readFieldEnd();
}
iprot.readStructEnd();
struct.validate();
}
