public void send_submitTopologyWithOpts(java.lang.String name,java.lang.String uploadedJarLocation,java.lang.String jsonConf,StormTopology topology,SubmitOptions options) throws org.apache.storm.thrift.TException {
  submitTopologyWithOpts_args args=new submitTopologyWithOpts_args();
  args.set_name(name);
  args.set_uploadedJarLocation(uploadedJarLocation);
  args.set_jsonConf(jsonConf);
  args.set_topology(topology);
  args.set_options(options);
  sendBase("submitTopologyWithOpts",args);
}
