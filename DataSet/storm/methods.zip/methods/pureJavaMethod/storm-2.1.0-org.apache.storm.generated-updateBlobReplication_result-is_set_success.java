/** 
 * Returns true if field success is set (has been assigned a value) and false otherwise 
 */
public boolean is_set_success(){
  return org.apache.storm.thrift.EncodingUtils.testBit(__isset_bitfield,__SUCCESS_ISSET_ID);
}
