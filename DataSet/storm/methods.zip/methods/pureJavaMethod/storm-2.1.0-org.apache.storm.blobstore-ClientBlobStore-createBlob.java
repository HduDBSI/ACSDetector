/** 
 * Client facing API to create a blob.
 * @param key  blob key name
 * @param meta contains ACL information
 * @return AtomicOutputStream returns an output stream into which data can be written
 */
public final AtomicOutputStream createBlob(String key,SettableBlobMeta meta) throws AuthorizationException, KeyAlreadyExistsException {
  if (meta != null && meta.is_set_acl()) {
    BlobStoreAclHandler.validateSettableACLs(key,meta.get_acl());
  }
  return createBlobToExtend(key,meta);
}
