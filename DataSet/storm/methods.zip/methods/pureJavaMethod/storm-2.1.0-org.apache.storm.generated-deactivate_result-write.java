@Override public void write(org.apache.storm.thrift.protocol.TProtocol prot,deactivate_result struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
  java.util.BitSet optionals=new java.util.BitSet();
  if (struct.is_set_e()) {
    optionals.set(0);
  }
  if (struct.is_set_aze()) {
    optionals.set(1);
  }
  oprot.writeBitSet(optionals,2);
  if (struct.is_set_e()) {
    struct.e.write(oprot);
  }
  if (struct.is_set_aze()) {
    struct.aze.write(oprot);
  }
}
