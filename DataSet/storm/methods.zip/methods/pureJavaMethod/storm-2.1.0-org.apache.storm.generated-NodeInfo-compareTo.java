@Override public int compareTo(NodeInfo other){
  if (!getClass().equals(other.getClass())) {
    return getClass().getName().compareTo(other.getClass().getName());
  }
  int lastComparison=0;
  lastComparison=java.lang.Boolean.valueOf(is_set_node()).compareTo(other.is_set_node());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_node()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.node,other.node);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_port()).compareTo(other.is_set_port());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_port()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.port,other.port);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  return 0;
}
