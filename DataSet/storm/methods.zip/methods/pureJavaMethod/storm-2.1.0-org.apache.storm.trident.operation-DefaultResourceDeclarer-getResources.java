@Override public Map<String,Number> getResources(){
  return new HashMap<String,Number>(resources);
}
