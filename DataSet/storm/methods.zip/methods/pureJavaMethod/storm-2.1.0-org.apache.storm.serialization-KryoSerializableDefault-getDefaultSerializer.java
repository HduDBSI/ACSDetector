@Override public Serializer getDefaultSerializer(Class type){
  if (override) {
    return new SerializableSerializer();
  }
 else {
    return super.getDefaultSerializer(type);
  }
}
