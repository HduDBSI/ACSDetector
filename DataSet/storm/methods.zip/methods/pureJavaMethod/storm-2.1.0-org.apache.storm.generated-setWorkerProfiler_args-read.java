@Override public void read(org.apache.storm.thrift.protocol.TProtocol prot,setWorkerProfiler_args struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TTupleProtocol iprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
  java.util.BitSet incoming=iprot.readBitSet(2);
  if (incoming.get(0)) {
    struct.id=iprot.readString();
    struct.set_id_isSet(true);
  }
  if (incoming.get(1)) {
    struct.profileRequest=new ProfileRequest();
    struct.profileRequest.read(iprot);
    struct.set_profileRequest_isSet(true);
  }
}
