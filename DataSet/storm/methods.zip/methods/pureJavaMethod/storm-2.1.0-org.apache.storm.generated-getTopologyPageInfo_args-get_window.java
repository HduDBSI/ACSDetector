@org.apache.storm.thrift.annotation.Nullable public java.lang.String get_window(){
  return this.window;
}
