public Fields getOutputFields(){
  return new Fields("field1","field2");
}
