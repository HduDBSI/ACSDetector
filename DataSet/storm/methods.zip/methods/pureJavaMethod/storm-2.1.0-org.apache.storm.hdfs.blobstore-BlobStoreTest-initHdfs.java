private AutoCloseableBlobStoreContainer initHdfs(String dirName) throws Exception {
  Map<String,Object> conf=new HashMap<>();
  conf.put(Config.BLOBSTORE_DIR,dirName);
  conf.put(Config.STORM_PRINCIPAL_TO_LOCAL_PLUGIN,"org.apache.storm.security.auth.DefaultPrincipalToLocal");
  conf.put(Config.STORM_BLOBSTORE_REPLICATION_FACTOR,3);
  HdfsBlobStore store=new HdfsBlobStore();
  store.prepareInternal(conf,null,DFS_CLUSTER_EXTENSION.getDfscluster().getConfiguration(0));
  return new AutoCloseableBlobStoreContainer(store);
}
