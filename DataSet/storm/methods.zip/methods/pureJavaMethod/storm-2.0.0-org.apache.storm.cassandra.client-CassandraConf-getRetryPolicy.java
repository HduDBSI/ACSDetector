public RetryPolicy getRetryPolicy(){
  if (this.retryPolicyName.equals(DowngradingConsistencyRetryPolicy.class.getSimpleName())) {
    return new LoggingRetryPolicy(DowngradingConsistencyRetryPolicy.INSTANCE);
  }
  if (this.retryPolicyName.equals(FallthroughRetryPolicy.class.getSimpleName())) {
    return FallthroughRetryPolicy.INSTANCE;
  }
  if (this.retryPolicyName.equals(DefaultRetryPolicy.class.getSimpleName())) {
    return DefaultRetryPolicy.INSTANCE;
  }
  throw new IllegalArgumentException("Unknown cassandra retry policy " + this.retryPolicyName);
}
