@Override public Fields getFieldsFor(String stream){
  return fields;
}
