@Override public void shutdown(){
  executor.shutdown();
  try {
    if (!executor.awaitTermination(2,TimeUnit.SECONDS)) {
      executor.shutdownNow();
    }
  }
 catch (  InterruptedException ie) {
    executor.shutdownNow();
    Thread.currentThread().interrupt();
  }
}
