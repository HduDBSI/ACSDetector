@org.apache.storm.thrift.annotation.Nullable public _Fields fieldForId(int fieldId){
  return _Fields.findByThriftId(fieldId);
}
