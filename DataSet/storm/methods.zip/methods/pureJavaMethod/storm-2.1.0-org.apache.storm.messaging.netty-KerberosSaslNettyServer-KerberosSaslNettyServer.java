KerberosSaslNettyServer(Map<String,Object> topoConf,String jaasSection,List<String> authorizedUsers){
  this.authorizedUsers=authorizedUsers;
  LOG.debug("Getting Configuration.");
  Configuration loginConf;
  try {
    loginConf=ClientAuthUtils.getConfiguration(topoConf);
  }
 catch (  Throwable t) {
    LOG.error("Failed to get loginConf: ",t);
    throw t;
  }
  LOG.debug("KerberosSaslNettyServer: authmethod {}",SaslUtils.KERBEROS);
  KerberosSaslCallbackHandler ch=new KerberosSaslNettyServer.KerberosSaslCallbackHandler(authorizedUsers);
  subject=null;
  try {
    LOG.debug("Setting Configuration to login_config: {}",loginConf);
    Configuration.setConfiguration(loginConf);
    LOG.debug("Trying to login.");
    Login login=new Login(jaasSection,ch);
    subject=login.getSubject();
    LOG.debug("Got Subject: {}",subject.toString());
  }
 catch (  LoginException ex) {
    LOG.error("Server failed to login in principal:",ex);
    throw new RuntimeException(ex);
  }
  if (subject.getPrivateCredentials(KerberosTicket.class).isEmpty()) {
    LOG.error("Failed to verifyuser principal.");
    throw new RuntimeException("Fail to verify user principal with section \"" + jaasSection + "\" in login configuration file "+ loginConf);
  }
  try {
    LOG.info("Creating Kerberos Server.");
    final CallbackHandler fch=ch;
    Principal p=(Principal)subject.getPrincipals().toArray()[0];
    KerberosName kerberosName=new KerberosName(p.getName());
    final String hostName=kerberosName.getHostName();
    final String serviceName=kerberosName.getServiceName();
    LOG.debug("Server with host: {}",hostName);
    saslServer=Subject.doAs(subject,new PrivilegedExceptionAction<SaslServer>(){
      @Override public SaslServer run(){
        try {
          Map<String,String> props=new TreeMap<String,String>();
          props.put(Sasl.QOP,"auth");
          props.put(Sasl.SERVER_AUTH,"false");
          return Sasl.createSaslServer(SaslUtils.KERBEROS,serviceName,hostName,props,fch);
        }
 catch (        Exception e) {
          LOG.error("Subject failed to create sasl server.",e);
          return null;
        }
      }
    }
);
    LOG.info("Got Server: {}",saslServer);
  }
 catch (  PrivilegedActionException e) {
    LOG.error("KerberosSaslNettyServer: Could not create SaslServer: ",e);
    throw new RuntimeException(e);
  }
}
