@Override public void ack(Object msgId){
  Long batchId=msgIdToBatchId.remove((Long)msgId);
  FinishCondition cond=finishConditions.get(batchId);
  if (cond != null) {
    cond.vals.remove((Long)msgId);
    if (cond.vals.isEmpty()) {
      finishConditions.remove(batchId);
      delegate.ack(cond.msgId);
    }
  }
}
