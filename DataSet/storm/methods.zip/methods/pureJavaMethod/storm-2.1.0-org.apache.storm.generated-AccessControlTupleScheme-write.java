@Override public void write(org.apache.storm.thrift.protocol.TProtocol prot,AccessControl struct) throws org.apache.storm.thrift.TException {
  org.apache.storm.thrift.protocol.TTupleProtocol oprot=(org.apache.storm.thrift.protocol.TTupleProtocol)prot;
  oprot.writeI32(struct.type.getValue());
  oprot.writeI32(struct.access);
  java.util.BitSet optionals=new java.util.BitSet();
  if (struct.is_set_name()) {
    optionals.set(0);
  }
  oprot.writeBitSet(optionals,1);
  if (struct.is_set_name()) {
    oprot.writeString(struct.name);
  }
}
