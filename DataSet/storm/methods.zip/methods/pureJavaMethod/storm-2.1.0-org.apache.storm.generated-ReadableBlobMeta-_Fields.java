_Fields(short thriftId,java.lang.String fieldName){
  _thriftId=thriftId;
  _fieldName=fieldName;
}
