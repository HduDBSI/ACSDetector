/** 
 * Performs a deep copy on <i>other</i>.
 */
public TopologyStats(TopologyStats other){
  if (other.is_set_window_to_emitted()) {
    java.util.Map<java.lang.String,java.lang.Long> __this__window_to_emitted=new java.util.HashMap<java.lang.String,java.lang.Long>(other.window_to_emitted);
    this.window_to_emitted=__this__window_to_emitted;
  }
  if (other.is_set_window_to_transferred()) {
    java.util.Map<java.lang.String,java.lang.Long> __this__window_to_transferred=new java.util.HashMap<java.lang.String,java.lang.Long>(other.window_to_transferred);
    this.window_to_transferred=__this__window_to_transferred;
  }
  if (other.is_set_window_to_complete_latencies_ms()) {
    java.util.Map<java.lang.String,java.lang.Double> __this__window_to_complete_latencies_ms=new java.util.HashMap<java.lang.String,java.lang.Double>(other.window_to_complete_latencies_ms);
    this.window_to_complete_latencies_ms=__this__window_to_complete_latencies_ms;
  }
  if (other.is_set_window_to_acked()) {
    java.util.Map<java.lang.String,java.lang.Long> __this__window_to_acked=new java.util.HashMap<java.lang.String,java.lang.Long>(other.window_to_acked);
    this.window_to_acked=__this__window_to_acked;
  }
  if (other.is_set_window_to_failed()) {
    java.util.Map<java.lang.String,java.lang.Long> __this__window_to_failed=new java.util.HashMap<java.lang.String,java.lang.Long>(other.window_to_failed);
    this.window_to_failed=__this__window_to_failed;
  }
}
