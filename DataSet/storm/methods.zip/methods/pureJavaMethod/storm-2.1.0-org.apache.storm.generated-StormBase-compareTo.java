@Override public int compareTo(StormBase other){
  if (!getClass().equals(other.getClass())) {
    return getClass().getName().compareTo(other.getClass().getName());
  }
  int lastComparison=0;
  lastComparison=java.lang.Boolean.valueOf(is_set_name()).compareTo(other.is_set_name());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_name()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.name,other.name);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_status()).compareTo(other.is_set_status());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_status()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.status,other.status);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_num_workers()).compareTo(other.is_set_num_workers());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_num_workers()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.num_workers,other.num_workers);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_component_executors()).compareTo(other.is_set_component_executors());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_component_executors()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.component_executors,other.component_executors);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_launch_time_secs()).compareTo(other.is_set_launch_time_secs());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_launch_time_secs()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.launch_time_secs,other.launch_time_secs);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_owner()).compareTo(other.is_set_owner());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_owner()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.owner,other.owner);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_topology_action_options()).compareTo(other.is_set_topology_action_options());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_topology_action_options()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.topology_action_options,other.topology_action_options);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_prev_status()).compareTo(other.is_set_prev_status());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_prev_status()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.prev_status,other.prev_status);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_component_debug()).compareTo(other.is_set_component_debug());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_component_debug()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.component_debug,other.component_debug);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_principal()).compareTo(other.is_set_principal());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_principal()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.principal,other.principal);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.valueOf(is_set_topology_version()).compareTo(other.is_set_topology_version());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (is_set_topology_version()) {
    lastComparison=org.apache.storm.thrift.TBaseHelper.compareTo(this.topology_version,other.topology_version);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  return 0;
}
