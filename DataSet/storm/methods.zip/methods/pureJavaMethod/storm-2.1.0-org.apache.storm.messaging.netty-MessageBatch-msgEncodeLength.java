private int msgEncodeLength(TaskMessage taskMsg){
  if (taskMsg == null) {
    return 0;
  }
  int size=6;
  if (taskMsg.message() != null) {
    size+=taskMsg.message().length;
  }
  return size;
}
