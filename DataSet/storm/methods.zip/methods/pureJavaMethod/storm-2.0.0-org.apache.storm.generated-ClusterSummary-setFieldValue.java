public void setFieldValue(_Fields field,@org.apache.storm.thrift.annotation.Nullable java.lang.Object value){
switch (field) {
case SUPERVISORS:
    if (value == null) {
      unset_supervisors();
    }
 else {
      set_supervisors((java.util.List<SupervisorSummary>)value);
    }
  break;
case TOPOLOGIES:
if (value == null) {
  unset_topologies();
}
 else {
  set_topologies((java.util.List<TopologySummary>)value);
}
break;
case NIMBUSES:
if (value == null) {
unset_nimbuses();
}
 else {
set_nimbuses((java.util.List<NimbusSummary>)value);
}
break;
}
}
