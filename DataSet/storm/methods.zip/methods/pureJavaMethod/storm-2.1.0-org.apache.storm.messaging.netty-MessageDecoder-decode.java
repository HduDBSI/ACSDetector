@Override protected void decode(ChannelHandlerContext ctx,ByteBuf buf,List<Object> out) throws Exception {
  long available=buf.readableBytes();
  if (available < 2) {
    return;
  }
  List<Object> ret=new ArrayList<>();
  while (available >= 2) {
    buf.markReaderIndex();
    short code=buf.readShort();
    available-=2;
    ControlMessage controlMessage=ControlMessage.mkMessage(code);
    if (controlMessage != null) {
      if (controlMessage == ControlMessage.EOB_MESSAGE) {
        continue;
      }
 else {
        out.add(controlMessage);
        return;
      }
    }
    if (code == SaslMessageToken.IDENTIFIER) {
      if (buf.readableBytes() < 4) {
        buf.resetReaderIndex();
        return;
      }
      int length=buf.readInt();
      if (length <= 0) {
        out.add(new SaslMessageToken(null));
        return;
      }
      if (buf.readableBytes() < length) {
        buf.resetReaderIndex();
        return;
      }
      byte[] bytes=new byte[length];
      buf.readBytes(bytes);
      out.add(new SaslMessageToken(bytes));
      return;
    }
    if (code == BackPressureStatus.IDENTIFIER) {
      available=buf.readableBytes();
      if (available < 4) {
        buf.resetReaderIndex();
        return;
      }
      int dataLen=buf.readInt();
      if (available < 4 + dataLen) {
        buf.resetReaderIndex();
        return;
      }
      byte[] bytes=new byte[dataLen];
      buf.readBytes(bytes);
      out.add(BackPressureStatus.read(bytes,deser));
      return;
    }
    if (available < 4) {
      buf.resetReaderIndex();
      break;
    }
    int length=buf.readInt();
    available-=4;
    if (length <= 0) {
      ret.add(new TaskMessage(code,null));
      break;
    }
    if (available < length) {
      buf.resetReaderIndex();
      break;
    }
    available-=length;
    byte[] bytes=new byte[length];
    buf.readBytes(bytes);
    ret.add(new TaskMessage(code,bytes));
  }
  if (!ret.isEmpty()) {
    out.add(ret);
  }
}
