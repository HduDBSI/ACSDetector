@Test public void testEmptyToEmpty() throws Exception {
  try (SimulatedTime t=new SimulatedTime(1010)){
    AsyncLocalizer localizer=mock(AsyncLocalizer.class);
    LocalState state=mock(LocalState.class);
    BlobChangingCallback cb=mock(BlobChangingCallback.class);
    ContainerLauncher containerLauncher=mock(ContainerLauncher.class);
    ISupervisor iSuper=mock(ISupervisor.class);
    SlotMetrics slotMetrics=new SlotMetrics(new StormMetricsRegistry());
    StaticState staticState=new StaticState(localizer,1000,1000,1000,1000,containerLauncher,"localhost",8080,iSuper,state,cb,null,null,slotMetrics);
    DynamicState dynamicState=new DynamicState(null,null,null,slotMetrics);
    DynamicState nextState=Slot.handleEmpty(dynamicState,staticState);
    assertEquals(MachineState.EMPTY,nextState.state);
    assertTrue(Time.currentTimeMillis() > 1000);
  }
 }
