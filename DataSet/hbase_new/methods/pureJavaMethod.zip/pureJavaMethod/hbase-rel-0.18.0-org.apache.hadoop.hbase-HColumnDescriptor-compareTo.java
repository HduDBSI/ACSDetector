public int compareTo(Object o){
  HColumnDescriptor other=(HColumnDescriptor)o;
  int result=Bytes.compareTo(this.name,other.getName());
  if (result == 0) {
    result=this.values.hashCode() - other.values.hashCode();
    if (result < 0)     result=-1;
 else     if (result > 0)     result=1;
  }
  return result;
}
