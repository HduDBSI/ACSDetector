/** 
 * Performs a deep copy on <i>other</i>.
 */
public scannerOpen_args(scannerOpen_args other){
  if (other.isSetTableName()) {
    this.tableName=other.tableName;
  }
  if (other.isSetStartRow()) {
    this.startRow=other.startRow;
  }
  if (other.isSetColumns()) {
    List<ByteBuffer> __this__columns=new ArrayList<ByteBuffer>(other.columns.size());
    for (    ByteBuffer other_element : other.columns) {
      __this__columns.add(other_element);
    }
    this.columns=__this__columns;
  }
  if (other.isSetAttributes()) {
    Map<ByteBuffer,ByteBuffer> __this__attributes=new HashMap<ByteBuffer,ByteBuffer>(other.attributes.size());
    for (    Map.Entry<ByteBuffer,ByteBuffer> other_element : other.attributes.entrySet()) {
      ByteBuffer other_element_key=other_element.getKey();
      ByteBuffer other_element_value=other_element.getValue();
      ByteBuffer __this__attributes_copy_key=other_element_key;
      ByteBuffer __this__attributes_copy_value=other_element_value;
      __this__attributes.put(__this__attributes_copy_key,__this__attributes_copy_value);
    }
    this.attributes=__this__attributes;
  }
}
