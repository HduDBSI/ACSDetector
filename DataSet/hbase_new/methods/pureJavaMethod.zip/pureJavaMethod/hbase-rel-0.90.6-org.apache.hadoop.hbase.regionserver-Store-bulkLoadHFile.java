/** 
 * This method should only be called from HRegion.  It is assumed that the  ranges of values in the HFile fit within the stores assigned region.  (assertBulkLoadHFileOk checks this)
 */
void bulkLoadHFile(String srcPathStr) throws IOException {
  Path srcPath=new Path(srcPathStr);
  FileSystem srcFs=srcPath.getFileSystem(conf);
  if (!srcFs.equals(fs)) {
    LOG.info("File " + srcPath + " on different filesystem than "+ "destination store - moving to this filesystem.");
    Path tmpPath=getTmpPath();
    FileUtil.copy(srcFs,srcPath,fs,tmpPath,false,conf);
    LOG.info("Copied to temporary path on dst filesystem: " + tmpPath);
    srcPath=tmpPath;
  }
  Path dstPath=StoreFile.getRandomFilename(fs,homedir);
  LOG.info("Renaming bulk load file " + srcPath + " to "+ dstPath);
  StoreFile.rename(fs,srcPath,dstPath);
  StoreFile sf=new StoreFile(fs,dstPath,blockcache,this.conf,this.family.getBloomFilterType(),this.inMemory);
  sf.createReader();
  LOG.info("Moved hfile " + srcPath + " into store directory "+ homedir+ " - updating store file list.");
  this.lock.writeLock().lock();
  try {
    ArrayList<StoreFile> newFiles=new ArrayList<StoreFile>(storefiles);
    newFiles.add(sf);
    this.storefiles=sortAndClone(newFiles);
    notifyChangedReadersObservers();
  }
  finally {
    this.lock.writeLock().unlock();
  }
  LOG.info("Successfully loaded store file " + srcPath + " into store "+ this+ " (new location: "+ dstPath+ ")");
}
