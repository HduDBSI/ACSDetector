public org.apache.hadoop.hbase.coprocessor.protobuf.generated.ColumnAggregationWithErrorsProtos.SumRequest build(){
  org.apache.hadoop.hbase.coprocessor.protobuf.generated.ColumnAggregationWithErrorsProtos.SumRequest result=buildPartial();
  if (!result.isInitialized()) {
    throw newUninitializedMessageException(result);
  }
  return result;
}
