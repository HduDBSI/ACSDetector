/** 
 * Compares the only the user specified portion of a Key.  This is overridden by MetaComparator.
 * @param left
 * @param right
 * @return 0 if equal, <0 if left smaller, >0 if right smaller
 */
protected int compareRowKey(final Cell left,final Cell right){
  return CellComparator.compareRows(left,right);
}
