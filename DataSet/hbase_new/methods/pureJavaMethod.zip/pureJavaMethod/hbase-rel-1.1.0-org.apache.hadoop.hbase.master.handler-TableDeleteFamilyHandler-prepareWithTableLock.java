@Override protected void prepareWithTableLock() throws IOException {
  super.prepareWithTableLock();
  HTableDescriptor htd=getTableDescriptor();
  this.familyName=hasColumnFamily(htd,familyName);
}
