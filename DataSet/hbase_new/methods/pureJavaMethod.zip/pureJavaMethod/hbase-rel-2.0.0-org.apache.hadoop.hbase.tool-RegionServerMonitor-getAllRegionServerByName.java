private Map<String,List<RegionInfo>> getAllRegionServerByName(){
  Map<String,List<RegionInfo>> rsAndRMap=new HashMap<>();
  Table table=null;
  RegionLocator regionLocator=null;
  try {
    if (LOG.isDebugEnabled()) {
      LOG.debug(String.format("reading list of tables and locations"));
    }
    HTableDescriptor[] tableDescs=this.admin.listTables();
    List<RegionInfo> regions=null;
    for (    HTableDescriptor tableDesc : tableDescs) {
      table=this.admin.getConnection().getTable(tableDesc.getTableName());
      regionLocator=this.admin.getConnection().getRegionLocator(tableDesc.getTableName());
      for (      HRegionLocation location : regionLocator.getAllRegionLocations()) {
        ServerName rs=location.getServerName();
        String rsName=rs.getHostname();
        RegionInfo r=location.getRegionInfo();
        if (rsAndRMap.containsKey(rsName)) {
          regions=rsAndRMap.get(rsName);
        }
 else {
          regions=new ArrayList<>();
          rsAndRMap.put(rsName,regions);
        }
        regions.add(r);
      }
      table.close();
    }
    for (    ServerName rs : this.admin.getClusterMetrics(EnumSet.of(Option.LIVE_SERVERS)).getLiveServerMetrics().keySet()) {
      String rsName=rs.getHostname();
      if (!rsAndRMap.containsKey(rsName)) {
        rsAndRMap.put(rsName,Collections.<RegionInfo>emptyList());
      }
    }
  }
 catch (  IOException e) {
    String msg="Get HTables info failed";
    LOG.error(msg,e);
    this.errorCode=INIT_ERROR_EXIT_CODE;
  }
 finally {
    if (table != null) {
      try {
        table.close();
      }
 catch (      IOException e) {
        LOG.warn("Close table failed",e);
      }
    }
  }
  return rsAndRMap;
}
