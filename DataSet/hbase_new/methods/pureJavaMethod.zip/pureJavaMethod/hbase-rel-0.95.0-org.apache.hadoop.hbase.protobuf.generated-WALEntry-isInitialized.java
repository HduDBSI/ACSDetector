public final boolean isInitialized(){
  if (!hasKey()) {
    return false;
  }
  if (!hasEdit()) {
    return false;
  }
  if (!getKey().isInitialized()) {
    return false;
  }
  if (!getEdit().isInitialized()) {
    return false;
  }
  return true;
}
