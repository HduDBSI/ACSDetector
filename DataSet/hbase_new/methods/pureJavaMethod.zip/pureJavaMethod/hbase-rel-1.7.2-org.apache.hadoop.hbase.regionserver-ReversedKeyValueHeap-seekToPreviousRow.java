@Override public boolean seekToPreviousRow(Cell seekKey) throws IOException {
  if (current == null) {
    return false;
  }
  heap.add(current);
  current=null;
  KeyValueScanner scanner;
  while ((scanner=heap.poll()) != null) {
    Cell topKey=scanner.peek();
    if (comparator.getComparator().compareRows(topKey.getRowArray(),topKey.getRowOffset(),topKey.getRowLength(),seekKey.getRowArray(),seekKey.getRowOffset(),seekKey.getRowLength()) < 0) {
      heap.add(scanner);
      current=pollRealKV();
      return current != null;
    }
    if (!scanner.seekToPreviousRow(seekKey)) {
      scanner.close();
    }
 else {
      heap.add(scanner);
    }
  }
  return false;
}
