/** 
 * Add key/value to file. Keys must be added in an order that agrees with the Comparator passed on construction.
 * @param cell Cell to add. Cannot be empty nor null.
 * @throws IOException
 */
@Override public void append(final Cell cell) throws IOException {
  byte[] value=cell.getValueArray();
  int voffset=cell.getValueOffset();
  int vlength=cell.getValueLength();
  boolean dupKey=checkKey(cell);
  checkValue(value,voffset,vlength);
  if (!dupKey) {
    checkBlockBoundary();
  }
  if (!fsBlockWriter.isWriting()) {
    newBlock();
  }
  fsBlockWriter.write(cell);
  totalKeyLength+=CellUtil.estimatedSerializedSizeOfKey(cell);
  totalValueLength+=vlength;
  if (firstCellInBlock == null) {
    firstCellInBlock=cell;
  }
  lastCell=cell;
  entryCount++;
  this.maxMemstoreTS=Math.max(this.maxMemstoreTS,cell.getSequenceId());
}
