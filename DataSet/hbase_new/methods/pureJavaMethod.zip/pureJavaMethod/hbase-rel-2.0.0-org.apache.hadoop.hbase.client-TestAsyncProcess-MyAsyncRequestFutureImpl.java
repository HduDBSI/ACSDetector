public MyAsyncRequestFutureImpl(AsyncProcessTask task,List<Action> actions,long nonceGroup,AsyncProcess asyncProcess){
  super(task,actions,nonceGroup,asyncProcess);
}
