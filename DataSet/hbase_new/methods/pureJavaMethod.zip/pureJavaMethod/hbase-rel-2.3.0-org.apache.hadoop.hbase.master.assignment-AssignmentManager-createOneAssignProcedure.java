/** 
 * Create one TransitRegionStateProcedure to assign a region w/o specifying a target server. This method is specified for HBCK2
 */
public TransitRegionStateProcedure createOneAssignProcedure(RegionInfo hri,boolean override){
  RegionStateNode regionNode=regionStates.getOrCreateRegionStateNode(hri);
  return createAssignProcedure(regionNode,null,override);
}
