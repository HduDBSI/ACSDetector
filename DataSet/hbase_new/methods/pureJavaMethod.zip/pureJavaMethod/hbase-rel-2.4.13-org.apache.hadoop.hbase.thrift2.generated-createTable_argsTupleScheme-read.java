@Override public void read(org.apache.thrift.protocol.TProtocol prot,createTable_args struct) throws org.apache.thrift.TException {
  org.apache.thrift.protocol.TTupleProtocol iprot=(org.apache.thrift.protocol.TTupleProtocol)prot;
  struct.desc=new TTableDescriptor();
  struct.desc.read(iprot);
  struct.setDescIsSet(true);
  java.util.BitSet incoming=iprot.readBitSet(1);
  if (incoming.get(0)) {
{
      org.apache.thrift.protocol.TList _list323=iprot.readListBegin(org.apache.thrift.protocol.TType.STRING);
      struct.splitKeys=new java.util.ArrayList<java.nio.ByteBuffer>(_list323.size);
      @org.apache.thrift.annotation.Nullable java.nio.ByteBuffer _elem324;
      for (int _i325=0; _i325 < _list323.size; ++_i325) {
        _elem324=iprot.readBinary();
        struct.splitKeys.add(_elem324);
      }
    }
    struct.setSplitKeysIsSet(true);
  }
}
