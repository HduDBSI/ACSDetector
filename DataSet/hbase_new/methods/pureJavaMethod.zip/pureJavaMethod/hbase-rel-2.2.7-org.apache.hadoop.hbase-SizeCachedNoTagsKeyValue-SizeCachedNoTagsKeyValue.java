public SizeCachedNoTagsKeyValue(byte[] bytes,int offset,int length,long seqId,int keyLen,short rowLen){
  super(bytes,offset,length,seqId,keyLen,rowLen);
}
