/** 
 * @param familyPaths pairs of { CF, file path } submitted for bulk load
 */
public void preBulkLoadHFile(final List<Pair<byte[],String>> familyPaths) throws IOException {
  execOperation(coprocEnvironments.isEmpty() ? null : new RegionObserverOperationWithoutResult(){
    @Override public void call(    RegionObserver observer) throws IOException {
      observer.preBulkLoadHFile(this,familyPaths);
    }
  }
);
}
