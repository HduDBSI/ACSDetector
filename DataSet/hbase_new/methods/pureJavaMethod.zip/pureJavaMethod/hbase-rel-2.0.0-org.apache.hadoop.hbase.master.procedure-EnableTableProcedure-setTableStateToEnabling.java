/** 
 * Mark table state to Enabling
 * @param env MasterProcedureEnv
 * @param tableName the target table
 * @throws IOException
 */
protected static void setTableStateToEnabling(final MasterProcedureEnv env,final TableName tableName) throws IOException {
  LOG.info("Attempting to enable the table " + tableName);
  env.getMasterServices().getTableStateManager().setTableState(tableName,TableState.State.ENABLING);
}
