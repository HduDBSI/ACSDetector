/** 
 * {@inheritDoc}
 */
@Override public Boolean[] exists(final List<Get> gets) throws IOException {
  if (gets.isEmpty())   return new Boolean[]{};
  if (gets.size() == 1)   return new Boolean[]{exists(gets.get(0))};
  for (  Get g : gets) {
    g.setCheckExistenceOnly(true);
  }
  Object[] r1;
  try {
    r1=batch(gets);
  }
 catch (  InterruptedException e) {
    throw new IOException(e);
  }
  Boolean[] results=new Boolean[r1.length];
  int i=0;
  for (  Object o : r1) {
    results[i++]=((Result)o).getExists();
  }
  return results;
}
