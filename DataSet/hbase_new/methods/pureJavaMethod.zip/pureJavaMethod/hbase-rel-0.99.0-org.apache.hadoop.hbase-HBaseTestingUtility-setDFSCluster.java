public void setDFSCluster(MiniDFSCluster cluster) throws IOException {
  if (dfsCluster != null && dfsCluster.isClusterUp()) {
    throw new IOException("DFSCluster is already running! Shut it down first.");
  }
  this.dfsCluster=cluster;
}
