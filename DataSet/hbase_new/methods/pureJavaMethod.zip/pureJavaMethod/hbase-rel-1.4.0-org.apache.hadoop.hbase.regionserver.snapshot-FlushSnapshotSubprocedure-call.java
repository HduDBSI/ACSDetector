@Override public Void call() throws Exception {
  LOG.debug("Starting snapshot operation on " + region);
  region.startRegionOperation(Operation.SNAPSHOT);
  try {
    if (skipFlush) {
      LOG.debug("take snapshot without flush memstore first");
    }
 else {
      LOG.debug("Flush Snapshotting region " + region.toString() + " started...");
      boolean succeeded=false;
      long readPt=region.getReadpoint(IsolationLevel.READ_COMMITTED);
      for (int i=0; i < MAX_RETRIES; i++) {
        FlushResult res=region.flush(true);
        if (res.getResult() == FlushResult.Result.CANNOT_FLUSH) {
          region.waitForFlushes();
          if (region.getMaxFlushedSeqId() >= readPt) {
            succeeded=true;
            break;
          }
        }
 else {
          succeeded=true;
          break;
        }
      }
      if (!succeeded) {
        throw new IOException("Unable to complete flush after " + MAX_RETRIES + " attempts");
      }
    }
    ((HRegion)region).addRegionToSnapshot(snapshotDesc,monitor);
    if (skipFlush) {
      LOG.debug("... SkipFlush Snapshotting region " + region.toString() + " completed.");
    }
 else {
      LOG.debug("... Flush Snapshotting region " + region.toString() + " completed.");
    }
  }
  finally {
    LOG.debug("Closing snapshot operation on " + region);
    region.closeRegionOperation(Operation.SNAPSHOT);
  }
  return null;
}
