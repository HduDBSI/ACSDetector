/** 
 * @see User#createUserForTesting(org.apache.hadoop.conf.Configuration,String,String[]) 
 */
public static User createUserForTesting(Configuration conf,String name,String[] groups){
  try {
    return new SecureHadoopUser((UserGroupInformation)callStatic("createUserForTesting",new Class[]{String.class,String[].class},new Object[]{name,groups}));
  }
 catch (  RuntimeException re) {
    throw re;
  }
catch (  Exception e) {
    throw new UndeclaredThrowableException(e,"Error creating secure test user");
  }
}
