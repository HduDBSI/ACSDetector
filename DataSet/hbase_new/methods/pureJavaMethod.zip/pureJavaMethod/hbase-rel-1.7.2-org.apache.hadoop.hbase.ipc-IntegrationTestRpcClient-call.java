@Override public Void call() throws Exception {
  try {
    testRpcWithChaosMonkey(false);
  }
 catch (  Throwable e) {
    if (e instanceof Exception) {
      throw (Exception)e;
    }
 else {
      throw new Exception(e);
    }
  }
  return null;
}
