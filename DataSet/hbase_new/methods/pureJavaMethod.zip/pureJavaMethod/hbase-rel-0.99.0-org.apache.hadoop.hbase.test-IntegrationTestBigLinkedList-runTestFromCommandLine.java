@Override public int runTestFromCommandLine() throws Exception {
  Tool tool=null;
  if (toRun.equals("Generator")) {
    tool=new Generator();
  }
 else   if (toRun.equals("Verify")) {
    tool=new Verify();
  }
 else   if (toRun.equals("Loop")) {
    Loop loop=new Loop();
    loop.it=this;
    tool=loop;
  }
 else   if (toRun.equals("Walker")) {
    tool=new Walker();
  }
 else   if (toRun.equals("Print")) {
    tool=new Print();
  }
 else   if (toRun.equals("Delete")) {
    tool=new Delete();
  }
 else {
    usage();
    throw new RuntimeException("Unknown arg");
  }
  return ToolRunner.run(getConf(),tool,otherArgs);
}
