private static MetricsRegistry copyMinusHBaseMetrics(final MetricsRegistry mr){
  MetricsRegistry copy=new MetricsRegistry();
  for (  MetricsBase metric : mr.getMetricsList()) {
    if (metric instanceof MetricsRate || metric instanceof MetricsString) {
      continue;
    }
    copy.add(metric.getName(),metric);
  }
  return copy;
}
