@Override public void createNamespace(final NamespaceDescriptor descriptor) throws IOException {
  get(createNamespaceAsync(descriptor),this.syncWaitTimeout,TimeUnit.MILLISECONDS);
}
