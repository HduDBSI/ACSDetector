private void removeLocationFromCache(HRegionLocation loc){
  TableCache tableCache=cache.get(loc.getRegion().getTable());
  if (tableCache == null) {
    return;
  }
  byte[] startKey=loc.getRegion().getStartKey();
  for (; ; ) {
    RegionLocations oldLocs=tableCache.cache.get(startKey);
    if (oldLocs == null) {
      return;
    }
    HRegionLocation oldLoc=oldLocs.getRegionLocation(loc.getRegion().getReplicaId());
    if (!canUpdateOnError(loc,oldLoc)) {
      return;
    }
    RegionLocations newLocs=removeRegionLocation(oldLocs,loc.getRegion().getReplicaId());
    if (newLocs == null) {
      if (tableCache.cache.remove(startKey,oldLocs)) {
        return;
      }
    }
 else {
      if (tableCache.cache.replace(startKey,oldLocs,newLocs)) {
        return;
      }
    }
  }
}
