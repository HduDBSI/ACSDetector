public MiniDFSCluster startMiniDFSCluster(int servers,final String racks[],String hosts[]) throws Exception {
  createDirsAndSetProperties();
  EditLogFileOutputStream.setShouldSkipFsyncForTesting(true);
  org.apache.log4j.Logger.getLogger(org.apache.hadoop.metrics2.util.MBeans.class).setLevel(org.apache.log4j.Level.ERROR);
  org.apache.log4j.Logger.getLogger(org.apache.hadoop.metrics2.impl.MetricsSystemImpl.class).setLevel(org.apache.log4j.Level.ERROR);
  TraceUtil.initTracer(conf);
  this.dfsCluster=new MiniDFSCluster(0,this.conf,servers,true,true,true,null,racks,hosts,null);
  setFs();
  this.dfsCluster.waitClusterUp();
  dataTestDirOnTestFS=null;
  String dataTestDir=getDataTestDir().toString();
  conf.set(HConstants.HBASE_DIR,dataTestDir);
  LOG.debug("Setting {} to {}",HConstants.HBASE_DIR,dataTestDir);
  return this.dfsCluster;
}
