public void publishWriteTiming(ServerName serverName,HRegionInfo region,HColumnDescriptor column,long msTime){
  LOG.info(String.format("write to region %s on regionserver %s column family %s in %dms",region.getRegionNameAsString(),serverName,column.getNameAsString(),msTime));
}
