/** 
 * {@inheritDoc}
 */
@Override public ScanQueryMatcher.MatchCode checkColumn(byte[] bytes,int offset,int length,byte type){
  assert !CellUtil.isDelete(type);
  do {
    if (done()) {
      return ScanQueryMatcher.MatchCode.SEEK_NEXT_ROW;
    }
    if (this.column == null) {
      return ScanQueryMatcher.MatchCode.SEEK_NEXT_ROW;
    }
    int ret=Bytes.compareTo(column.getBuffer(),column.getOffset(),column.getLength(),bytes,offset,length);
    if (ret == 0) {
      return ScanQueryMatcher.MatchCode.INCLUDE;
    }
    resetTS();
    if (ret > 0) {
      return ScanQueryMatcher.MatchCode.SEEK_NEXT_COL;
    }
    if (ret <= -1) {
      ++this.index;
      if (done()) {
        return ScanQueryMatcher.MatchCode.SEEK_NEXT_ROW;
      }
      this.column=this.columns[this.index];
    }
  }
 while (true);
}
