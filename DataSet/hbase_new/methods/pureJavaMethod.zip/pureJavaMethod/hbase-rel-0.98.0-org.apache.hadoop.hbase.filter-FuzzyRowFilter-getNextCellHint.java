@Override public Cell getNextCellHint(Cell currentKV){
  KeyValue v=KeyValueUtil.ensureKeyValue(currentKV);
  byte[] rowKey=v.getRow();
  byte[] nextRowKey=null;
  for (  Pair<byte[],byte[]> fuzzyData : fuzzyKeysData) {
    byte[] nextRowKeyCandidate=getNextForFuzzyRule(rowKey,fuzzyData.getFirst(),fuzzyData.getSecond());
    if (nextRowKeyCandidate == null) {
      continue;
    }
    if (nextRowKey == null || Bytes.compareTo(nextRowKeyCandidate,nextRowKey) < 0) {
      nextRowKey=nextRowKeyCandidate;
    }
  }
  if (nextRowKey == null) {
    throw new IllegalStateException("No next row key that satisfies fuzzy exists when" + " getNextKeyHint() is invoked." + " Filter: " + this.toString() + " currentKV: "+ currentKV.toString());
  }
  return KeyValue.createFirstOnRow(nextRowKey);
}
