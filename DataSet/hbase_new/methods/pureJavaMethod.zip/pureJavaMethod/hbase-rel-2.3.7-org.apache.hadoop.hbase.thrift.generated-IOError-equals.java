public boolean equals(IOError that){
  if (that == null)   return false;
  if (this == that)   return true;
  boolean this_present_message=true && this.isSetMessage();
  boolean that_present_message=true && that.isSetMessage();
  if (this_present_message || that_present_message) {
    if (!(this_present_message && that_present_message))     return false;
    if (!this.message.equals(that.message))     return false;
  }
  boolean this_present_canRetry=true;
  boolean that_present_canRetry=true;
  if (this_present_canRetry || that_present_canRetry) {
    if (!(this_present_canRetry && that_present_canRetry))     return false;
    if (this.canRetry != that.canRetry)     return false;
  }
  return true;
}
