@Override public R call() throws Exception {
  T instance=org.apache.hadoop.hbase.protobuf.ProtobufUtil.newServiceStub(service,channel);
  R result=callable.call(instance);
  byte[] region=channel.getLastRegion();
  if (callback != null) {
    callback.update(region,r,result);
  }
  return result;
}
