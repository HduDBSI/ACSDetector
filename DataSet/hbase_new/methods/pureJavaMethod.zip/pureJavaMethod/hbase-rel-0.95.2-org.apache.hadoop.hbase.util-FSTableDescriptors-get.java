/** 
 * Get the current table descriptor for the given table, or null if none exists. Uses a local cache of the descriptor but still checks the filesystem on each call to see if a newer file has been created since the cached one was read.
 */
@Override public HTableDescriptor get(final TableName tablename) throws IOException {
  invocations++;
  if (HTableDescriptor.ROOT_TABLEDESC.getTableName().equals(tablename)) {
    cachehits++;
    return HTableDescriptor.ROOT_TABLEDESC;
  }
  if (HTableDescriptor.META_TABLEDESC.getTableName().equals(tablename)) {
    cachehits++;
    return HTableDescriptor.META_TABLEDESC;
  }
  if (HConstants.HBASE_NON_USER_TABLE_DIRS.contains(tablename.getNameAsString())) {
    throw new IOException("No descriptor found for non table = " + tablename);
  }
  TableDescriptorAndModtime cachedtdm=this.cache.get(tablename);
  if (cachedtdm != null) {
    if (getTableInfoModtime(tablename) <= cachedtdm.getModtime()) {
      cachehits++;
      return cachedtdm.getTableDescriptor();
    }
  }
  TableDescriptorAndModtime tdmt=null;
  try {
    tdmt=getTableDescriptorAndModtime(tablename);
  }
 catch (  NullPointerException e) {
    LOG.debug("Exception during readTableDecriptor. Current table name = " + tablename,e);
  }
catch (  IOException ioe) {
    LOG.debug("Exception during readTableDecriptor. Current table name = " + tablename,ioe);
  }
  if (tdmt == null) {
    LOG.warn("The following folder is in HBase's root directory and " + "doesn't contain a table descriptor, " + "do consider deleting it: "+ tablename);
  }
 else {
    this.cache.put(tablename,tdmt);
  }
  return tdmt == null ? null : tdmt.getTableDescriptor();
}
