public AbstractFSReader(Algorithm compressAlgo,long fileSize,int minorVersion,HFileSystem hfs,Path path) throws IOException {
  this.compressAlgo=compressAlgo;
  this.fileSize=fileSize;
  this.minorVersion=minorVersion;
  this.hfs=hfs;
  this.path=path;
  this.hdrSize=headerSize(minorVersion);
}
