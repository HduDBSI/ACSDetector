/** 
 * Configure a MapReduce Job to perform an incremental load into the given table. This <ul> <li>Inspects the table to configure a total order partitioner</li> <li>Uploads the partitions file to the cluster and adds it to the DistributedCache</li> <li>Sets the number of reduce tasks to match the current number of regions</li> <li>Sets the output key/value class to match HFileOutputFormat's requirements</li> <li>Sets the reducer up to perform the appropriate sorting (either KeyValueSortReducer or PutSortReducer)</li> </ul> The user should be sure to set the map output value class to either KeyValue or Put before running this function.
 */
public static void configureIncrementalLoad(Job job,HTable table) throws IOException {
  Configuration conf=job.getConfiguration();
  job.setOutputKeyClass(ImmutableBytesWritable.class);
  job.setOutputValueClass(KeyValue.class);
  job.setOutputFormatClass(HFileOutputFormat.class);
  if (KeyValue.class.equals(job.getMapOutputValueClass())) {
    job.setReducerClass(KeyValueSortReducer.class);
  }
 else   if (Put.class.equals(job.getMapOutputValueClass())) {
    job.setReducerClass(PutSortReducer.class);
  }
 else {
    LOG.warn("Unknown map output value type:" + job.getMapOutputValueClass());
  }
  LOG.info("Looking up current regions for table " + table);
  List<ImmutableBytesWritable> startKeys=getRegionStartKeys(table);
  LOG.info("Configuring " + startKeys.size() + " reduce partitions "+ "to match current region count");
  job.setNumReduceTasks(startKeys.size());
  configurePartitioner(job,startKeys);
  configureCompression(table,conf);
  configureBloomType(table,conf);
  TableMapReduceUtil.addDependencyJars(job);
  LOG.info("Incremental table output configured.");
}
