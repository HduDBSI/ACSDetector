/** 
 * @return A new CatalogTracker instance; call {@link #cleanupCatalogTracker(CatalogTracker)}to cleanup the returned catalog tracker.
 * @throws ZooKeeperConnectionException
 * @throws IOException
 * @see #cleanupCatalogTracker(CatalogTracker)
 */
@VisibleForTesting synchronized CatalogTracker getCatalogTracker() throws ZooKeeperConnectionException, IOException {
  boolean succeeded=false;
  CatalogTracker ct=null;
  try {
    ct=new CatalogTracker(this.conf);
    startCatalogTracker(ct);
    succeeded=true;
  }
 catch (  InterruptedException e) {
    Thread.currentThread().interrupt();
    throw new IOException("Interrupted",e);
  }
 finally {
    if (!succeeded && ct != null) {
      try {
        ct.stop();
      }
 catch (      RuntimeException re) {
        LOG.error("Failed to clean up HBase's internal catalog tracker after a failed initialization. " + "We may have leaked network connections to ZooKeeper; they won't be cleaned up until " + "the JVM exits. If you see a large number of stale connections to ZooKeeper this is likely "+ "the cause. The following exception details will be needed for assistance from the "+ "HBase community.",re);
      }
      ct=null;
    }
  }
  return ct;
}
