@Test public void testMiscHTableStuff() throws IOException {
  final TableName tableAname=TableName.valueOf(name.getMethodName() + "A");
  final TableName tableBname=TableName.valueOf(name.getMethodName() + "B");
  final byte[] attrName=Bytes.toBytes("TESTATTR");
  final byte[] attrValue=Bytes.toBytes("somevalue");
  byte[] value=Bytes.toBytes("value");
  try (Table a=TEST_UTIL.createTable(tableAname,HConstants.CATALOG_FAMILY);Table b=TEST_UTIL.createTable(tableBname,HConstants.CATALOG_FAMILY)){
    Put put=new Put(ROW);
    put.addColumn(HConstants.CATALOG_FAMILY,null,value);
    a.put(put);
    try (Table newA=TEST_UTIL.getConnection().getTable(tableAname)){
      Scan scan=new Scan();
      scan.addFamily(HConstants.CATALOG_FAMILY);
      try (ResultScanner s=newA.getScanner(scan)){
        for (        Result r : s) {
          put=new Put(r.getRow());
          put.setDurability(Durability.SKIP_WAL);
          for (          Cell kv : r.rawCells()) {
            put.add(kv);
          }
          b.put(put);
        }
      }
     }
     try (Table anotherA=TEST_UTIL.getConnection().getTable(tableAname)){
      Get get=new Get(ROW);
      get.addFamily(HConstants.CATALOG_FAMILY);
      anotherA.get(get);
    }
     try (Admin admin=TEST_UTIL.getAdmin()){
      HTableDescriptor desc=new HTableDescriptor(a.getTableDescriptor());
      admin.disableTable(tableAname);
      desc.setValue(attrName,attrValue);
      for (      HColumnDescriptor c : desc.getFamilies()) {
        c.setValue(attrName,attrValue);
      }
      admin.modifyTable(desc);
      admin.enableTable(tableAname);
    }
     HTableDescriptor desc=a.getTableDescriptor();
    assertEquals("wrong table descriptor returned",desc.getTableName(),tableAname);
    value=desc.getValue(attrName);
    assertFalse("missing HTD attribute value",value == null);
    assertFalse("HTD attribute value is incorrect",Bytes.compareTo(value,attrValue) != 0);
    for (    HColumnDescriptor c : desc.getFamilies()) {
      value=c.getValue(attrName);
      assertFalse("missing HCD attribute value",value == null);
      assertFalse("HCD attribute value is incorrect",Bytes.compareTo(value,attrValue) != 0);
    }
  }
 }
