/** 
 * @param familyMap map of family to edits for the given family.
 * @param writeToWAL
 * @throws IOException
 */
public void delete(Map<byte[],List<KeyValue>> familyMap,UUID clusterId,boolean writeToWAL) throws IOException {
  Delete delete=new Delete();
  delete.setFamilyMap(familyMap);
  delete.setClusterId(clusterId);
  delete.setWriteToWAL(writeToWAL);
  internalDelete(delete,clusterId,writeToWAL);
}
