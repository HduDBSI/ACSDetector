private CompactionContext selectCompaction(final Region r,final Store s,int priority,CompactionRequest request) throws IOException {
  CompactionContext compaction=s.requestCompaction(priority,request);
  if (compaction == null) {
    if (LOG.isDebugEnabled()) {
      LOG.debug("Not compacting " + r.getRegionInfo().getRegionNameAsString() + " because compaction request was cancelled");
    }
    return null;
  }
  assert compaction.hasSelection();
  if (priority != Store.NO_PRIORITY) {
    compaction.getRequest().setPriority(priority);
  }
  return compaction;
}
