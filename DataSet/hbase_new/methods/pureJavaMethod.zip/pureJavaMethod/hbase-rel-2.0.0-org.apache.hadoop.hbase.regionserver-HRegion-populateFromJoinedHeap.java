/** 
 * @return true if more cells exist after this batch, false if scanner is done
 */
private boolean populateFromJoinedHeap(List<Cell> results,ScannerContext scannerContext) throws IOException {
  assert joinedContinuationRow != null;
  boolean moreValues=populateResult(results,this.joinedHeap,scannerContext,joinedContinuationRow);
  if (!scannerContext.checkAnyLimitReached(LimitScope.BETWEEN_CELLS)) {
    joinedContinuationRow=null;
  }
  sort(results,comparator);
  return moreValues;
}
