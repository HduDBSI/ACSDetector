public static ReplicationPeerConfig appendTableCFsToReplicationPeerConfig(Map<TableName,List<String>> tableCfs,ReplicationPeerConfig peerConfig){
  ReplicationPeerConfigBuilder builder=ReplicationPeerConfig.newBuilder(peerConfig);
  Map<TableName,List<String>> preTableCfs=peerConfig.getTableCFsMap();
  if (preTableCfs == null) {
    builder.setTableCFsMap(tableCfs);
  }
 else {
    Map<TableName,List<String>> newTableCfs=copyTableCFsMap(preTableCfs);
    for (    Map.Entry<TableName,? extends Collection<String>> entry : tableCfs.entrySet()) {
      TableName table=entry.getKey();
      Collection<String> appendCfs=entry.getValue();
      if (newTableCfs.containsKey(table)) {
        List<String> cfs=newTableCfs.get(table);
        if (cfs == null || appendCfs == null || appendCfs.isEmpty()) {
          newTableCfs.put(table,null);
        }
 else {
          Set<String> cfSet=new HashSet<String>(cfs);
          cfSet.addAll(appendCfs);
          newTableCfs.put(table,Lists.newArrayList(cfSet));
        }
      }
 else {
        if (appendCfs == null || appendCfs.isEmpty()) {
          newTableCfs.put(table,null);
        }
 else {
          newTableCfs.put(table,Lists.newArrayList(appendCfs));
        }
      }
    }
    builder.setTableCFsMap(newTableCfs);
  }
  return builder.build();
}
