@Override protected boolean process() throws IOException {
  for (int tries=0; tries < numRetries; tries++) {
    if (closed.get()) {
      return true;
    }
    LOG.info("region closed: " + regionInfo.getRegionName());
    if (!metaRegionAvailable()) {
      return true;
    }
    try {
      if (!this.reassignRegion) {
        HRegion.offlineRegionInMETA(getMetaServer(),metaRegionName,regionInfo);
      }
      break;
    }
 catch (    IOException e) {
      if (tries == numRetries - 1) {
        throw RemoteExceptionHandler.checkIOException(e);
      }
    }
    sleeper.sleep();
  }
  if (reassignRegion) {
    LOG.info("reassign region: " + regionInfo.getRegionName());
    unassignedRegions.put(regionInfo,ZERO_L);
  }
  return true;
}
