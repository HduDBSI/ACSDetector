@Override public Void connect(HConnection connection) throws IOException {
  ZooKeeperWatcher zkw=createZooKeeperWatcher();
  try {
    for (    TableName tableName : ZKTableStateClientSideReader.getDisabledOrDisablingTables(zkw)) {
      disabledTables.add(tableName);
    }
  }
 catch (  KeeperException ke) {
    throw new IOException(ke);
  }
catch (  InterruptedException e) {
    throw new InterruptedIOException();
  }
 finally {
    zkw.close();
  }
  return null;
}
