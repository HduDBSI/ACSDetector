/** 
 * Checks that the user has the given global permission. The generated audit log message will contain context information for the operation being authorized, based on the given parameters.
 * @param perm Action being requested
 * @param namespace  The given namespace
 */
public void requireGlobalPermission(String request,Action perm,String namespace) throws IOException {
  accessChecker.requireGlobalPermission(getActiveUser(),request,perm,namespace);
}
