/** 
 * @param get the Get request
 * @param results the result sett
 * @exception IOException Exception
 */
public void postGet(final Get get,final List<Cell> results) throws IOException {
  execOperation(coprocessors.isEmpty() ? null : new RegionOperation(){
    @Override public void call(    RegionObserver oserver,    ObserverContext<RegionCoprocessorEnvironment> ctx) throws IOException {
      oserver.postGetOp(ctx,get,results);
    }
  }
);
}
