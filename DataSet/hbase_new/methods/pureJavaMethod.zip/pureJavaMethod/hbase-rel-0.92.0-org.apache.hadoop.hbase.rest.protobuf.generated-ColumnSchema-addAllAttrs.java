public Builder addAllAttrs(java.lang.Iterable<? extends org.apache.hadoop.hbase.rest.protobuf.generated.ColumnSchemaMessage.ColumnSchema.Attribute> values){
  if (attrsBuilder_ == null) {
    ensureAttrsIsMutable();
    super.addAll(values,attrs_);
    onChanged();
  }
 else {
    attrsBuilder_.addAllMessages(values);
  }
  return this;
}
