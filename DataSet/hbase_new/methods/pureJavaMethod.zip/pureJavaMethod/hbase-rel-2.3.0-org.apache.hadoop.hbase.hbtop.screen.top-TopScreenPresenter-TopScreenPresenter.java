public TopScreenPresenter(TopScreenView topScreenView,long initialRefreshDelay,TopScreenModel topScreenModel){
  this.topScreenView=Objects.requireNonNull(topScreenView);
  this.refreshDelay=new AtomicLong(initialRefreshDelay);
  this.topScreenModel=Objects.requireNonNull(topScreenModel);
  initFieldDisplayMapAndFieldLengthMap();
}
