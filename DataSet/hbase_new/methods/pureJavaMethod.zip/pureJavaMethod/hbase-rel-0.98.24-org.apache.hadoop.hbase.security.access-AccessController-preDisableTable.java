@Override public void preDisableTable(ObserverContext<MasterCoprocessorEnvironment> c,TableName tableName) throws IOException {
  if (Bytes.equals(tableName.getName(),AccessControlLists.ACL_GLOBAL_NAME)) {
    throw new AccessDeniedException("Not allowed to disable " + AccessControlLists.ACL_TABLE_NAME + " table with AccessController installed");
  }
  requirePermission("disableTable",tableName,null,null,Action.ADMIN,Action.CREATE);
}
