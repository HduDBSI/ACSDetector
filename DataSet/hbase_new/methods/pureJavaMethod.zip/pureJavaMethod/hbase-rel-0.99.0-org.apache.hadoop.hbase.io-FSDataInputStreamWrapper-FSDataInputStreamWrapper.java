/** 
 * For use in tests. 
 */
@VisibleForTesting public FSDataInputStreamWrapper(FSDataInputStream fsdis,FSDataInputStream noChecksum){
  doCloseStreams=false;
  stream=fsdis;
  streamNoFsChecksum=noChecksum;
  path=null;
  link=null;
  hfs=null;
  useHBaseChecksumConfigured=useHBaseChecksum=false;
}
