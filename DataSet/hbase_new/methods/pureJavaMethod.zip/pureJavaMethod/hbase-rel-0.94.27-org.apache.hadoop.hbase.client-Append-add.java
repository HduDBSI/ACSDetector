/** 
 * Add the specified  {@link KeyValue} to this operation.
 * @param kv whose value should be to appended to the specified column
 * @return <tt?this</tt>
 * @throws IllegalArgumentException if the row or type does not match <tt>this</tt>
 */
public Append add(KeyValue kv){
  if (!(kv.getType() == KeyValue.Type.Put.getCode())) {
    throw new IllegalArgumentException("Added type " + KeyValue.Type.codeToType(kv.getType()) + ", but appends can only be of type "+ KeyValue.Type.Put+ ". Rowkey:"+ Bytes.toStringBinary(kv.getRow()));
  }
  if (!kv.matchingRow(row)) {
    throw new IllegalArgumentException("The row in the recently added KeyValue " + Bytes.toStringBinary(kv.getRow()) + " doesn't match the original one "+ Bytes.toStringBinary(this.row));
  }
  byte[] family=kv.getFamily();
  List<KeyValue> list=familyMap.get(family);
  if (list == null) {
    list=new ArrayList<KeyValue>();
    familyMap.put(family,list);
  }
  list.add(kv);
  return this;
}
