public Boolean call() throws IOException {
  if (LOG.isDebugEnabled()) {
    LOG.debug("process server shutdown scanning " + Bytes.toString(m.getRegionName()) + " on "+ m.getServer());
  }
  long scannerId=server.openScanner(m.getRegionName(),COLUMN_FAMILY_ARRAY,EMPTY_START_ROW,HConstants.LATEST_TIMESTAMP,null);
  scanMetaRegion(server,scannerId,m.getRegionName());
  return true;
}
