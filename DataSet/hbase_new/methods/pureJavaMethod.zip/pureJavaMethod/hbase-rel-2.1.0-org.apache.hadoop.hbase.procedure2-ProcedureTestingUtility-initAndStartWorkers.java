public static void initAndStartWorkers(ProcedureExecutor<?> procExecutor,int numThreads,boolean abortOnCorruption) throws IOException {
  procExecutor.init(numThreads,abortOnCorruption);
  procExecutor.startWorkers();
}
