public Builder addRegions(int index,org.apache.hadoop.hbase.rest.protobuf.generated.StorageClusterStatusMessage.StorageClusterStatus.Region.Builder builderForValue){
  if (regionsBuilder_ == null) {
    ensureRegionsIsMutable();
    regions_.add(index,builderForValue.build());
    onChanged();
  }
 else {
    regionsBuilder_.addMessage(index,builderForValue.build());
  }
  return this;
}
