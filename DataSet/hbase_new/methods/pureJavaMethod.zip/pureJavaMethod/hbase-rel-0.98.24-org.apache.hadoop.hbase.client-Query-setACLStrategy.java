/** 
 * @deprecated No effect
 */
@Deprecated public void setACLStrategy(boolean cellFirstStrategy){
}
