FilteredScanTest(Configuration conf,TestOptions options,Status status){
  super(conf,options,status);
}
