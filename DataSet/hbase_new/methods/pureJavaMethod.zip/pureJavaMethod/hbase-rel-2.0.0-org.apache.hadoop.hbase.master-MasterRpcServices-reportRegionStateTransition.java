@Override public ReportRegionStateTransitionResponse reportRegionStateTransition(RpcController c,ReportRegionStateTransitionRequest req) throws ServiceException {
  try {
    master.checkServiceStarted();
    return master.getAssignmentManager().reportRegionStateTransition(req);
  }
 catch (  IOException ioe) {
    throw new ServiceException(ioe);
  }
}
