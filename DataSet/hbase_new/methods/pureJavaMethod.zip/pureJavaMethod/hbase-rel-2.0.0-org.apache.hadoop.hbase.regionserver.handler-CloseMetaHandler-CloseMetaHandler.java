public CloseMetaHandler(final Server server,final RegionServerServices rsServices,final RegionInfo regionInfo,final boolean abort){
  super(server,rsServices,regionInfo,abort,EventType.M_RS_CLOSE_META,null);
}
