@Test public void testReportBadSink(){
  ServerName serverNameA=mock(ServerName.class);
  ServerName serverNameB=mock(ServerName.class);
  when(replicationPeers.getRegionServersOfConnectedPeer(PEER_CLUSTER_ID)).thenReturn(Lists.newArrayList(serverNameA,serverNameB));
  sinkManager.chooseSinks();
  assertEquals(1,sinkManager.getSinks().size());
  SinkPeer sinkPeer=new SinkPeer(serverNameA,mock(AdminService.BlockingInterface.class));
  sinkManager.reportBadSink(sinkPeer);
  assertEquals(1,sinkManager.getSinks().size());
}
