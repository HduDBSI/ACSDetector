private boolean hasExpiredStores(Collection<StoreFile> files){
  long currentTime=EnvironmentEdgeManager.currentTime();
  for (  StoreFile sf : files) {
    if (isEmptyStoreFile(sf)) {
      return true;
    }
    Long maxTs=sf.getReader().getMaxTimestamp();
    long maxTtl=storeConfigInfo.getStoreFileTtl();
    if (maxTs == null || maxTtl == Long.MAX_VALUE || (currentTime - maxTtl < maxTs)) {
      continue;
    }
 else {
      return true;
    }
  }
  return false;
}
