@Override public int hashCode(){
  HashCodeBuilder builder=new HashCodeBuilder();
  boolean present_row=true && (isSetRow());
  builder.append(present_row);
  if (present_row)   builder.append(row);
  boolean present_columns=true && (isSetColumns());
  builder.append(present_columns);
  if (present_columns)   builder.append(columns);
  boolean present_timestamp=true && (isSetTimestamp());
  builder.append(present_timestamp);
  if (present_timestamp)   builder.append(timestamp);
  boolean present_timeRange=true && (isSetTimeRange());
  builder.append(present_timeRange);
  if (present_timeRange)   builder.append(timeRange);
  boolean present_maxVersions=true && (isSetMaxVersions());
  builder.append(present_maxVersions);
  if (present_maxVersions)   builder.append(maxVersions);
  boolean present_filterString=true && (isSetFilterString());
  builder.append(present_filterString);
  if (present_filterString)   builder.append(filterString);
  boolean present_attributes=true && (isSetAttributes());
  builder.append(present_attributes);
  if (present_attributes)   builder.append(attributes);
  boolean present_authorizations=true && (isSetAuthorizations());
  builder.append(present_authorizations);
  if (present_authorizations)   builder.append(authorizations);
  return builder.toHashCode();
}
