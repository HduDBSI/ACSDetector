public Builder addColumns(int index,org.apache.hadoop.hbase.rest.protobuf.generated.ColumnSchemaMessage.ColumnSchema.Builder builderForValue){
  if (columnsBuilder_ == null) {
    ensureColumnsIsMutable();
    columns_.add(index,builderForValue.build());
    onChanged();
  }
 else {
    columnsBuilder_.addMessage(index,builderForValue.build());
  }
  return this;
}
