public Result get(long transactionId,byte[] regionName,Get get) throws IOException {
  return getTransactionalRegion(regionName).get(transactionId,get);
}
