public HTableDescriptor getHTableDescriptor(final byte[] tableName) throws IOException {
  if (tableName == null || tableName.length == 0)   return null;
  if (Bytes.equals(tableName,HConstants.ROOT_TABLE_NAME)) {
    return new UnmodifyableHTableDescriptor(HTableDescriptor.ROOT_TABLEDESC);
  }
  if (Bytes.equals(tableName,HConstants.META_TABLE_NAME)) {
    return HTableDescriptor.META_TABLEDESC;
  }
  List<String> tableNameList=new ArrayList<String>(1);
  tableNameList.add(Bytes.toString(tableName));
  HTableDescriptor[] htds=getHTableDescriptors(tableNameList);
  if (htds != null && htds.length > 0) {
    return htds[0];
  }
  throw new TableNotFoundException(Bytes.toString(tableName));
}
