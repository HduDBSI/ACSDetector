@Override public void postOpenDeployTasks(final PostOpenDeployContext context) throws KeeperException, IOException {
  HRegion r=context.getRegion();
  long masterSystemTime=context.getMasterSystemTime();
  rpcServices.checkOpen();
  LOG.info("Post open deploy tasks for " + r.getRegionNameAsString());
  for (  Store s : r.getStores().values()) {
    if (s.hasReferences() || s.needsCompaction()) {
      this.compactSplitThread.requestSystemCompaction(r,s,"Opening Region");
    }
  }
  long openSeqNum=r.getOpenSeqNum();
  if (openSeqNum == HConstants.NO_SEQNUM) {
    LOG.error("No sequence number found when opening " + r.getRegionNameAsString());
    openSeqNum=0;
  }
  updateRecoveringRegionLastFlushedSequenceId(r);
  if (r.getRegionInfo().isMetaRegion()) {
    MetaTableLocator.setMetaLocation(getZooKeeper(),serverName,State.OPEN);
  }
 else   if (useZKForAssignment) {
    MetaTableAccessor.updateRegionLocation(getConnection(),r.getRegionInfo(),this.serverName,openSeqNum,masterSystemTime);
  }
  if (!useZKForAssignment && !reportRegionStateTransition(new RegionStateTransitionContext(TransitionCode.OPENED,openSeqNum,masterSystemTime,r.getRegionInfo()))) {
    throw new IOException("Failed to report opened region to master: " + r.getRegionNameAsString());
  }
  LOG.debug("Finished post open deploy task for " + r.getRegionNameAsString());
}
