@Override public void postDeleteNamespace(ObserverContext<MasterCoprocessorEnvironment> ctx,final String namespace) throws IOException {
  final Configuration conf=ctx.getEnvironment().getConfiguration();
  User.runAsLoginUser(new PrivilegedExceptionAction<Void>(){
    @Override public Void run() throws Exception {
      try (Table table=ctx.getEnvironment().getConnection().getTable(AccessControlLists.ACL_TABLE_NAME)){
        AccessControlLists.removeNamespacePermissions(conf,namespace,table);
      }
       return null;
    }
  }
);
  getAuthManager().getZKPermissionWatcher().deleteNamespaceACLNode(namespace);
  LOG.info(namespace + " entry deleted in " + AccessControlLists.ACL_TABLE_NAME+ " table.");
}
