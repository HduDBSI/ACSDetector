/** 
 * Get the current chunk, or, if there is no current chunk, allocate a new one from the JVM.
 */
private Chunk getOrMakeChunk(){
  while (true) {
    Chunk c=curChunk.get();
    if (c != null) {
      return c;
    }
    c=(chunkPool != null) ? chunkPool.getChunk() : new Chunk(chunkSize);
    if (curChunk.compareAndSet(null,c)) {
      c.init();
      this.chunkQueue.add(c);
      return c;
    }
 else     if (chunkPool != null) {
      chunkPool.putbackChunk(c);
    }
  }
}
