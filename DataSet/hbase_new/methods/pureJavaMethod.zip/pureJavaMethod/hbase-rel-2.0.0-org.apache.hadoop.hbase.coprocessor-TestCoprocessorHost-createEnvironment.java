@Override public CoprocessorEnvironment<E> createEnvironment(final E instance,final int priority,int sequence,Configuration conf){
  return new BaseEnvironment<>(instance,priority,0,cpHostConf);
}
