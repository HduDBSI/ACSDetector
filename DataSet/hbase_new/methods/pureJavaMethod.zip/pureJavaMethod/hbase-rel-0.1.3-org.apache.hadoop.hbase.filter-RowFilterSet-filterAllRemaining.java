/** 
 * {@inheritDoc} 
 */
public boolean filterAllRemaining(){
  boolean result=operator == Operator.MUST_PASS_ONE;
  for (  RowFilterInterface filter : filters) {
    if (operator == Operator.MUST_PASS_ALL) {
      if (filter.filterAllRemaining()) {
        if (LOG.isDebugEnabled()) {
          LOG.debug("op.MPALL filterAllRemaining returning true due" + " to subfilter of type " + filter.getClass().getSimpleName());
        }
        return true;
      }
    }
 else     if (operator == Operator.MUST_PASS_ONE) {
      if (!filter.filterAllRemaining()) {
        if (LOG.isDebugEnabled()) {
          LOG.debug("op.MPONE filterAllRemaining returning false due" + " to subfilter of type " + filter.getClass().getSimpleName());
        }
        return false;
      }
    }
  }
  if (LOG.isDebugEnabled()) {
    LOG.debug("filterAllRemaining default returning " + result);
  }
  return result;
}
