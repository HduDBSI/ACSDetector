protected void readKeyValueLen(){
  int p=blockBuffer.position() + blockBuffer.arrayOffset();
  long ll=Bytes.toLong(blockBuffer.array(),p);
  this.currKeyLen=(int)(ll >> Integer.SIZE);
  this.currValueLen=(int)(Bytes.MASK_FOR_LOWER_INT_IN_LONG ^ ll);
  checkKeyValueLen();
  p+=(Bytes.SIZEOF_LONG + currKeyLen + currValueLen);
  readMvccVersion(p);
}
