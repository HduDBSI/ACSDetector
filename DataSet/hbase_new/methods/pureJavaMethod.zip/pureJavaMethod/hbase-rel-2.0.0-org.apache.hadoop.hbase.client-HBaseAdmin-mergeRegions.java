/** 
 * Merge two regions. Asynchronous operation.
 * @param nameOfRegionA encoded or full name of region a
 * @param nameOfRegionB encoded or full name of region b
 * @param forcible true if do a compulsory merge, otherwise we will only mergetwo adjacent regions
 * @throws IOException
 * @deprecated Since 2.0. Will be removed in 3.0. Use{@link #mergeRegionsAsync(byte[],byte[],boolean)} instead.
 */
@Deprecated @Override public void mergeRegions(final byte[] nameOfRegionA,final byte[] nameOfRegionB,final boolean forcible) throws IOException {
  mergeRegionsAsync(nameOfRegionA,nameOfRegionB,forcible);
}
