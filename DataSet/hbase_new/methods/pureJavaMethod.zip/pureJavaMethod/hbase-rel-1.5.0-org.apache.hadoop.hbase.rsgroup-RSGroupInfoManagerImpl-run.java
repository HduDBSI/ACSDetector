@Override public void run(){
  if (waitForGroupTableOnline()) {
    LOG.info("GroupBasedLoadBalancer is now online");
  }
}
