protected TransactionalClientScanner(final TransactionState transactionState,Scan scan){
  super(scan);
  this.transactionState=transactionState;
}
