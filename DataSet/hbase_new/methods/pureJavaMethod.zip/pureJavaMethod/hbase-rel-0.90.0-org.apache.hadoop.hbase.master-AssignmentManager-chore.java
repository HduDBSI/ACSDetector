@Override protected void chore(){
  if (this.bulkAssign)   return;
synchronized (regionsInTransition) {
    long now=System.currentTimeMillis();
    for (    RegionState regionState : regionsInTransition.values()) {
      if (regionState.getStamp() + timeout <= now) {
        HRegionInfo regionInfo=regionState.getRegion();
        LOG.info("Regions in transition timed out:  " + regionState);
switch (regionState.getState()) {
case CLOSED:
          LOG.info("Region " + regionInfo.getEncodedName() + " has been CLOSED for too long, waiting on queued "+ "ClosedRegionHandler to run or server shutdown");
synchronized (regionState) {
          regionState.update(regionState.getState());
        }
      break;
case OFFLINE:
    LOG.info("Region has been OFFLINE for too long, " + "reassigning " + regionInfo.getRegionNameAsString() + " to a random server");
  assign(regionState.getRegion(),false);
break;
case PENDING_OPEN:
LOG.info("Region has been PENDING_OPEN for too " + "long, reassigning region=" + regionInfo.getRegionNameAsString());
assign(regionState.getRegion(),false,true);
break;
case OPENING:
LOG.info("Region has been OPENING for too " + "long, reassigning region=" + regionInfo.getRegionNameAsString());
try {
String node=ZKAssign.getNodeName(watcher,regionInfo.getEncodedName());
Stat stat=new Stat();
RegionTransitionData data=ZKAssign.getDataNoWatch(watcher,node,stat);
if (data.getEventType() == EventType.RS_ZK_REGION_OPENED) {
LOG.debug("Region has transitioned to OPENED, allowing " + "watched event handlers to process");
break;
}
 else if (data.getEventType() != EventType.RS_ZK_REGION_OPENING) {
LOG.warn("While timing out a region in state OPENING, " + "found ZK node in unexpected state: " + data.getEventType());
break;
}
try {
data=new RegionTransitionData(EventType.M_ZK_REGION_OFFLINE,regionInfo.getRegionName(),master.getServerName());
if (ZKUtil.setData(watcher,node,data.getBytes(),stat.getVersion())) {
ZKUtil.getDataAndWatch(watcher,node);
LOG.info("Successfully transitioned region=" + regionInfo.getRegionNameAsString() + " into OFFLINE"+ " and forcing a new assignment");
assign(regionState,false,true);
}
}
 catch (KeeperException.NoNodeException nne) {
}
}
 catch (KeeperException ke) {
LOG.error("Unexpected ZK exception timing out CLOSING region",ke);
break;
}
break;
case OPEN:
LOG.error("Region has been OPEN for too long, " + "we don't know where region was opened so can't do anything");
break;
case PENDING_CLOSE:
LOG.info("Region has been PENDING_CLOSE for too " + "long, running forced unassign again on region=" + regionInfo.getRegionNameAsString());
try {
if (!ZKUtil.watchAndCheckExists(watcher,ZKAssign.getNodeName(watcher,regionInfo.getEncodedName()))) {
unassign(regionInfo,true);
}
}
 catch (NoNodeException e) {
LOG.debug("Node no longer existed so not forcing another " + "unassignment");
}
catch (KeeperException e) {
LOG.warn("Unexpected ZK exception timing out a region " + "close",e);
}
break;
case CLOSING:
LOG.info("Region has been CLOSING for too " + "long, this should eventually complete or the server will " + "expire, doing nothing");
break;
}
}
}
}
}
