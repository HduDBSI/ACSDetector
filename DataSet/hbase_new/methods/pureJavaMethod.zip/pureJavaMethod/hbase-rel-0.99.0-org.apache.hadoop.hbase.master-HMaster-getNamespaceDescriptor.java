@Override public NamespaceDescriptor getNamespaceDescriptor(String name) throws IOException {
  checkNamespaceManagerReady();
  NamespaceDescriptor nsd=tableNamespaceManager.get(name);
  if (nsd == null) {
    throw new NamespaceNotFoundException(name);
  }
  return nsd;
}
