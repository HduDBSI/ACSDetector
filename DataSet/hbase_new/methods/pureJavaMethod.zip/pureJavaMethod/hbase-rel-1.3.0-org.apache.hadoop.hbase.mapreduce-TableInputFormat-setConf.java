/** 
 * Sets the configuration. This is used to set the details for the table to be scanned.
 * @param configuration  The configuration to set.
 * @see org.apache.hadoop.conf.Configurable#setConf(org.apache.hadoop.conf.Configuration)
 */
@Override @edu.umd.cs.findbugs.annotations.SuppressWarnings(value="REC_CATCH_EXCEPTION",justification="Intentional") public void setConf(Configuration configuration){
  this.conf=configuration;
  Scan scan=null;
  if (conf.get(SCAN) != null) {
    try {
      scan=TableMapReduceUtil.convertStringToScan(conf.get(SCAN));
    }
 catch (    IOException e) {
      LOG.error("An error occurred.",e);
    }
  }
 else {
    try {
      scan=createScanFromConfiguration(conf);
    }
 catch (    Exception e) {
      LOG.error(StringUtils.stringifyException(e));
    }
  }
  setScan(scan);
}
