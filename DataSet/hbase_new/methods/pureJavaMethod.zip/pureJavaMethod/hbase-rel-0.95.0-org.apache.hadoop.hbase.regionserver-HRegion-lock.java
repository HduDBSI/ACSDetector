/** 
 * Try to acquire a lock.  Throw RegionTooBusyException if failed to get the lock in time. Throw InterruptedIOException if interrupted while waiting for the lock.
 */
private void lock(final Lock lock,final int multiplier) throws RegionTooBusyException, InterruptedIOException {
  try {
    final long waitTime=Math.min(maxBusyWaitDuration,busyWaitDuration * Math.min(multiplier,maxBusyWaitMultiplier));
    if (!lock.tryLock(waitTime,TimeUnit.MILLISECONDS)) {
      throw new RegionTooBusyException("failed to get a lock in " + waitTime + "ms");
    }
  }
 catch (  InterruptedException ie) {
    LOG.info("Interrupted while waiting for a lock");
    InterruptedIOException iie=new InterruptedIOException();
    iie.initCause(ie);
    throw iie;
  }
}
