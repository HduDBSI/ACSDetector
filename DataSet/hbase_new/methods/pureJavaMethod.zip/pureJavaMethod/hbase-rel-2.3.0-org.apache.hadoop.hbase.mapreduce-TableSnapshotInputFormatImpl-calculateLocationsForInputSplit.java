/** 
 * Compute block locations for snapshot files (which will get the locations for referred hfiles) only when localityEnabled is true.
 */
private static List<String> calculateLocationsForInputSplit(Configuration conf,TableDescriptor htd,HRegionInfo hri,Path tableDir,boolean localityEnabled) throws IOException {
  if (localityEnabled) {
    return getBestLocations(conf,HRegion.computeHDFSBlocksDistribution(conf,htd,hri,tableDir));
  }
 else {
    return null;
  }
}
