@Override public Object run() throws Exception {
  conf.set("testkey",UUID.randomUUID().toString());
  Table t=new HTable(conf,TEST_TABLE.getTableName());
  try {
    Scan scan=new Scan();
    Result result=t.getScanner(scan).next();
    if (result != null) {
      assertTrue("Improper exclusion",result.containsColumn(TEST_FAMILY1,TEST_Q1));
      assertFalse("Improper inclusion",result.containsColumn(TEST_FAMILY2,TEST_Q1));
      assertTrue("Improper exclusion",result.containsColumn(TEST_FAMILY2,TEST_Q2));
      return result.listCells();
    }
    return null;
  }
  finally {
    t.close();
  }
}
