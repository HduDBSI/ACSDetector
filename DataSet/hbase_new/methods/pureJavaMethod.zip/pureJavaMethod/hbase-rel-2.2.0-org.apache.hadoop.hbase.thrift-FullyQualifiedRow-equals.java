@Override public boolean equals(Object obj){
  if (this == obj)   return true;
  if (obj == null)   return false;
  if (getClass() != obj.getClass())   return false;
  FullyQualifiedRow other=(FullyQualifiedRow)obj;
  if (!Arrays.equals(family,other.family))   return false;
  if (!Arrays.equals(qualifier,other.qualifier))   return false;
  if (!Arrays.equals(rowKey,other.rowKey))   return false;
  if (!Arrays.equals(table,other.table))   return false;
  return true;
}
