/** 
 * Called by HRegionServer when it opens a new region to ensure that log sequence numbers are always greater than the latest sequence number of the region being brought on-line.
 * @param newvalue We'll set log edit/sequence number to this value if it is greater than the current value.
 */
public void setSequenceNumber(final long newvalue);
