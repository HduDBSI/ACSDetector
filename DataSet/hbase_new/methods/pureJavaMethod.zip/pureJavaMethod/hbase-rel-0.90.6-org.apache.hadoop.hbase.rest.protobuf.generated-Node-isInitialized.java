public boolean isInitialized(){
  return result.isInitialized();
}
