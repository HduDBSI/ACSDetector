@Override public void throwable(Throwable t,boolean retrying){
  if (location != null) {
    connection.updateCachedLocations(tableName,location.getRegionInfo().getRegionName(),row,t,location.getServerName());
  }
}
