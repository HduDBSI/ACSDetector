@Override public int compare(HRegionInfo left,HRegionInfo right){
  if (left == null)   return -1;
  if (right == null)   return 1;
  int result=left.getTableName().compareTo(right.getTableName());
  if (result != 0)   return result;
  result=Bytes.compareTo(left.getStartKey(),right.getStartKey());
  if (result != 0)   return result;
  result=rowEndKeyComparator.compare(left.getEndKey(),right.getEndKey());
  return -result;
}
