/** 
 * Check split inputs and prepare the transaction.
 * @return <code>true</code> if the region is splittable else<code>false</code> if it is not (e.g. its already closed, etc.).
 * @throws IOException 
 */
boolean prepare() throws IOException ;
