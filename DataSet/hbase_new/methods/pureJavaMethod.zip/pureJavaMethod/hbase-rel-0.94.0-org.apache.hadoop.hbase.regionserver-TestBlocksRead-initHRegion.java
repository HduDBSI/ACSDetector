/** 
 * Callers must afterward call  {@link HRegion#closeHRegion(HRegion)}
 * @param tableName
 * @param callingMethod
 * @param conf
 * @param families
 * @throws IOException
 * @return created and initialized region.
 */
private HRegion initHRegion(byte[] tableName,String callingMethod,HBaseConfiguration conf,String family) throws IOException {
  HTableDescriptor htd=new HTableDescriptor(tableName);
  HColumnDescriptor familyDesc;
  for (int i=0; i < BLOOM_TYPE.length; i++) {
    BloomType bloomType=BLOOM_TYPE[i];
    familyDesc=new HColumnDescriptor(family + "_" + bloomType).setBlocksize(1).setBloomFilterType(BLOOM_TYPE[i]);
    htd.addFamily(familyDesc);
  }
  HRegionInfo info=new HRegionInfo(htd.getName(),null,null,false);
  Path path=new Path(DIR + callingMethod);
  HRegion r=HRegion.createHRegion(info,path,conf,htd);
  blockCache=new CacheConfig(conf).getBlockCache();
  return r;
}
