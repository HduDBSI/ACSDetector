public Object run() throws Exception {
  Configuration c=server.getConfiguration();
  RpcClient rpcClient=RpcClientFactory.createClient(c,clusterId.toString());
  ServerName sn=ServerName.valueOf(server.getAddress().getHostName(),server.getAddress().getPort(),System.currentTimeMillis());
  try {
    BlockingRpcChannel channel=rpcClient.createBlockingRpcChannel(sn,User.getCurrent(),HConstants.DEFAULT_HBASE_RPC_TIMEOUT);
    AuthenticationProtos.AuthenticationService.BlockingInterface stub=AuthenticationProtos.AuthenticationService.newBlockingStub(channel);
    AuthenticationProtos.WhoAmIResponse response=stub.whoAmI(null,AuthenticationProtos.WhoAmIRequest.getDefaultInstance());
    String myname=response.getUsername();
    assertEquals("testuser",myname);
    String authMethod=response.getAuthMethod();
    assertEquals("TOKEN",authMethod);
  }
  finally {
    rpcClient.close();
  }
  return null;
}
