/** 
 * Create a new ReplicateWALEntryRequest from a list of HLog entries
 * @param entries the HLog entries to be replicated
 * @return a pair of ReplicateWALEntryRequest and a CellScanner over all the WALEdit valuesfound.
 */
public static Pair<AdminProtos.ReplicateWALEntryRequest,CellScanner> buildReplicateWALEntryRequest(final HLog.Entry[] entries){
  List<List<? extends Cell>> allkvs=new ArrayList<List<? extends Cell>>(entries.length);
  int size=0;
  WALProtos.FamilyScope.Builder scopeBuilder=WALProtos.FamilyScope.newBuilder();
  AdminProtos.WALEntry.Builder entryBuilder=AdminProtos.WALEntry.newBuilder();
  AdminProtos.ReplicateWALEntryRequest.Builder builder=AdminProtos.ReplicateWALEntryRequest.newBuilder();
  for (  HLog.Entry entry : entries) {
    entryBuilder.clear();
    WALProtos.WALKey.Builder keyBuilder=entryBuilder.getKeyBuilder();
    HLogKey key=entry.getKey();
    keyBuilder.setEncodedRegionName(ByteString.copyFrom(key.getEncodedRegionName()));
    keyBuilder.setTableName(ByteString.copyFrom(key.getTablename().getName()));
    keyBuilder.setLogSequenceNumber(key.getLogSeqNum());
    keyBuilder.setWriteTime(key.getWriteTime());
    UUID clusterId=key.getClusterId();
    if (clusterId != null) {
      HBaseProtos.UUID.Builder uuidBuilder=keyBuilder.getClusterIdBuilder();
      uuidBuilder.setLeastSigBits(clusterId.getLeastSignificantBits());
      uuidBuilder.setMostSigBits(clusterId.getMostSignificantBits());
    }
    WALEdit edit=entry.getEdit();
    NavigableMap<byte[],Integer> scopes=key.getScopes();
    if (scopes != null && !scopes.isEmpty()) {
      for (      Map.Entry<byte[],Integer> scope : scopes.entrySet()) {
        scopeBuilder.setFamily(ByteString.copyFrom(scope.getKey()));
        WALProtos.ScopeType scopeType=WALProtos.ScopeType.valueOf(scope.getValue().intValue());
        scopeBuilder.setScopeType(scopeType);
        keyBuilder.addScopes(scopeBuilder.build());
      }
    }
    List<KeyValue> kvs=edit.getKeyValues();
    for (    KeyValue kv : kvs) {
      size+=kv.getLength();
    }
    allkvs.add(kvs);
    entryBuilder.setAssociatedCellCount(kvs.size());
    builder.addEntry(entryBuilder.build());
  }
  return new Pair<AdminProtos.ReplicateWALEntryRequest,CellScanner>(builder.build(),getCellScanner(allkvs,size));
}
