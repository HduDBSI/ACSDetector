@Override public void run(){
  try {
    int[] messageSize=new int[]{100,1000,10000};
    for (int i=0; i < messageSize.length; i++) {
      String input=RandomStringUtils.random(messageSize[i]);
      String result=stub.echo(null,TestProtos.EchoRequestProto.newBuilder().setMessage(input).build()).getMessage();
      assertEquals(input,result);
    }
  }
 catch (  ServiceException e) {
    throw new RuntimeException(e);
  }
}
