@Override public WALEnvironment createEnvironment(final WALCoprocessor instance,final int priority,final int seq,final Configuration conf){
  return new WALEnvironment(instance,priority,seq,conf,this.wal);
}
