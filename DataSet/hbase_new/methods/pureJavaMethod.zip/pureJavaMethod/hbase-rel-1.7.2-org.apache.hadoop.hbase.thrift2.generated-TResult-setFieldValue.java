public void setFieldValue(_Fields field,@org.apache.thrift.annotation.Nullable java.lang.Object value){
switch (field) {
case ROW:
    if (value == null) {
      unsetRow();
    }
 else {
      if (value instanceof byte[]) {
        setRow((byte[])value);
      }
 else {
        setRow((java.nio.ByteBuffer)value);
      }
    }
  break;
case COLUMN_VALUES:
if (value == null) {
  unsetColumnValues();
}
 else {
  setColumnValues((java.util.List<TColumnValue>)value);
}
break;
case STALE:
if (value == null) {
unsetStale();
}
 else {
setStale((java.lang.Boolean)value);
}
break;
case PARTIAL:
if (value == null) {
unsetPartial();
}
 else {
setPartial((java.lang.Boolean)value);
}
break;
}
}
