/** 
 * Override if providing alternate Handler implementation.
 */
protected Handler getHandler(final String name,final double handlerFailureThreshhold,final BlockingQueue<CallRunner> q,final AtomicInteger activeHandlerCount){
  return new Handler(name,handlerFailureThreshhold,q,activeHandlerCount);
}
