/** 
 * remove the specified dead server
 * @param deadServerName the dead server name
 * @return true if this server was removed
 */
public synchronized boolean removeDeadServer(final ServerName deadServerName){
  if (deadServers.remove(deadServerName) == null) {
    return false;
  }
  return true;
}
