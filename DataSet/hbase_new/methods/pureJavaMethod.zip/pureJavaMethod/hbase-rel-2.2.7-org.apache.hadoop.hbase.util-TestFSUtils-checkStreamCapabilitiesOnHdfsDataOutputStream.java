@Test public void checkStreamCapabilitiesOnHdfsDataOutputStream() throws Exception {
  MiniDFSCluster cluster=htu.startMiniDFSCluster(1);
  try (FileSystem filesystem=cluster.getFileSystem()){
    FSDataOutputStream stream=filesystem.create(new Path("/tmp/foobar"));
    assertTrue(FSUtils.hasCapability(stream,"hsync"));
    assertTrue(FSUtils.hasCapability(stream,"hflush"));
    assertNotEquals("We expect HdfsDataOutputStream to say it has a dummy capability iff the " + "StreamCapabilities class is not defined.",STREAM_CAPABILITIES_IS_PRESENT,FSUtils.hasCapability(stream,"a capability that hopefully HDFS doesn't add."));
  }
  finally {
    cluster.shutdown();
  }
}
