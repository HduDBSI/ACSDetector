public boolean isTableEnabled(byte[] tableName) throws IOException {
  if (!tableExists(tableName)) {
    throw new TableNotFoundException(Bytes.toString(tableName));
  }
  if (Bytes.equals(tableName,HConstants.ROOT_TABLE_NAME)) {
    return true;
  }
  boolean result=true;
  int rowsScanned=0;
  byte[] startKey=HRegionInfo.createRegionName(tableName,null,HConstants.ZEROES);
  HRegionInfo currentRegion=null;
  do {
    if (currentRegion != null) {
      byte[] endKey=currentRegion.getEndKey();
      if (endKey == null || HStoreKey.equalsTwoRowKeys(currentRegion,endKey,HConstants.EMPTY_BYTE_ARRAY)) {
        break;
      }
    }
    HRegionInfo oldRegion=currentRegion;
    if (oldRegion != null) {
      startKey=oldRegion.getEndKey();
    }
    ScannerCallable s=new ScannerCallable(this,(Bytes.equals(tableName,HConstants.META_TABLE_NAME) ? HConstants.ROOT_TABLE_NAME : HConstants.META_TABLE_NAME),HConstants.COL_REGIONINFO_ARRAY,startKey,HConstants.LATEST_TIMESTAMP,null);
    getRegionServerWithRetries(s);
    currentRegion=s.getHRegionInfo();
    try {
      RowResult r=null;
      RowResult[] rrs=null;
      while (result && (rrs=getRegionServerWithRetries(s)) != null) {
        r=rrs[0];
        Cell c=r.get(HConstants.COL_REGIONINFO);
        if (c != null) {
          byte[] value=c.getValue();
          if (value != null) {
            HRegionInfo info=Writables.getHRegionInfoOrNull(value);
            if (info != null) {
              if (Bytes.equals(info.getTableDesc().getName(),tableName)) {
                rowsScanned+=1;
                result=!info.isOffline();
              }
            }
          }
        }
      }
    }
  finally {
      s.setClose();
      getRegionServerWithRetries(s);
    }
  }
 while (result);
  return rowsScanned > 0 && result;
}
