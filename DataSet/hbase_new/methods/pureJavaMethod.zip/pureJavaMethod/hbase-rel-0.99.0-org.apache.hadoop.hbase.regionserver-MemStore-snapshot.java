/** 
 * Creates a snapshot of the current memstore. Snapshot must be cleared by call to {@link #clearSnapshot(long)}.
 * @return {@link MemStoreSnapshot}
 */
MemStoreSnapshot snapshot();
