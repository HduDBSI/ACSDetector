@Override public void leaseExpired(){
  RegionScannerHolder rsh=scanners.remove(this.scannerName);
  if (rsh == null) {
    LOG.warn("Scanner lease {} expired but no outstanding scanner",this.scannerName);
    return;
  }
  LOG.info("Scanner lease {} expired {}",this.scannerName,rsh);
  RegionScanner s=rsh.s;
  HRegion region=null;
  try {
    region=regionServer.getRegion(s.getRegionInfo().getRegionName());
    if (region != null && region.getCoprocessorHost() != null) {
      region.getCoprocessorHost().preScannerClose(s);
    }
  }
 catch (  IOException e) {
    LOG.error("Closing scanner {} {}",this.scannerName,rsh,e);
  }
 finally {
    try {
      s.close();
      if (region != null && region.getCoprocessorHost() != null) {
        region.getCoprocessorHost().postScannerClose(s);
      }
    }
 catch (    IOException e) {
      LOG.error("Closing scanner {} {}",this.scannerName,rsh,e);
    }
  }
}
