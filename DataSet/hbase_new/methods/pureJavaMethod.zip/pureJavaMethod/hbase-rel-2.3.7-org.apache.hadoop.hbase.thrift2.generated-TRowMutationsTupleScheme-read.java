@Override public void read(org.apache.thrift.protocol.TProtocol prot,TRowMutations struct) throws org.apache.thrift.TException {
  org.apache.thrift.protocol.TTupleProtocol iprot=(org.apache.thrift.protocol.TTupleProtocol)prot;
  struct.row=iprot.readBinary();
  struct.setRowIsSet(true);
{
    org.apache.thrift.protocol.TList _list139=iprot.readListBegin(org.apache.thrift.protocol.TType.STRUCT);
    struct.mutations=new java.util.ArrayList<TMutation>(_list139.size);
    @org.apache.thrift.annotation.Nullable TMutation _elem140;
    for (int _i141=0; _i141 < _list139.size; ++_i141) {
      _elem140=new TMutation();
      _elem140.read(iprot);
      struct.mutations.add(_elem140);
    }
  }
  struct.setMutationsIsSet(true);
}
