/** 
 * Returns the HRegionLocation parsed from the given meta row Result for the given regionInfo and replicaId. The regionInfo can be the default region info for the replica.
 * @param r the meta row result
 * @param regionInfo RegionInfo for default replica
 * @param replicaId the replicaId for the HRegionLocation
 * @return HRegionLocation parsed from the given meta row Result for the given replicaId
 */
private static HRegionLocation getRegionLocation(final Result r,final RegionInfo regionInfo,final int replicaId){
  ServerName serverName=getServerName(r,replicaId);
  long seqNum=getSeqNumDuringOpen(r,replicaId);
  RegionInfo replicaInfo=RegionReplicaUtil.getRegionInfoForReplica(regionInfo,replicaId);
  return new HRegionLocation(replicaInfo,serverName,seqNum);
}
