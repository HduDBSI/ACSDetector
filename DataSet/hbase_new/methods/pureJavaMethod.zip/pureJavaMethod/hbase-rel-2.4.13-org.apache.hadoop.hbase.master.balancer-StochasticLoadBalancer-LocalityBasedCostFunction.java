LocalityBasedCostFunction(Configuration conf,LocalityType type,String localityCostKey,float defaultLocalityCost){
  super(conf);
  this.type=type;
  this.setMultiplier(conf.getFloat(localityCostKey,defaultLocalityCost));
  this.locality=0.0;
  this.bestLocality=0.0;
}
