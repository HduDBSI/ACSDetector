/** 
 * Keeps track of the number of versions for the columns asked for. It assumes that the user has already checked if the cell needs to be included by calling the {@link #checkColumn(Cell,byte)} method. The enum values returned by this methodare  {@link MatchCode#SKIP},  {@link MatchCode#INCLUDE}, {@link MatchCode#INCLUDE_AND_SEEK_NEXT_COL} and {@link MatchCode#INCLUDE_AND_SEEK_NEXT_ROW}. Implementations which include all the columns could just return  {@link MatchCode#INCLUDE} inthe  {@link #checkColumn(Cell,byte)} method and perform all the operations in thischeckVersions method.
 * @param cell
 * @param timestamp The timestamp of the cell.
 * @param type the type of the key value (Put/Delete)
 * @param ignoreCount indicates if the KV needs to be excluded while counting (used duringcompactions. We only count KV's that are older than all the scanners' read points.)
 * @return the scan query matcher match code instance
 * @throws IOException in case there is an internal consistency problem caused by a datacorruption.
 */
ScanQueryMatcher.MatchCode checkVersions(Cell cell,long timestamp,byte type,boolean ignoreCount) throws IOException ;
