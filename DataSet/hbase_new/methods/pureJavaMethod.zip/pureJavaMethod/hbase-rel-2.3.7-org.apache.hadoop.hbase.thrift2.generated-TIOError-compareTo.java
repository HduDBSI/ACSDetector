@Override public int compareTo(TIOError other){
  if (!getClass().equals(other.getClass())) {
    return getClass().getName().compareTo(other.getClass().getName());
  }
  int lastComparison=0;
  lastComparison=java.lang.Boolean.compare(isSetMessage(),other.isSetMessage());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (isSetMessage()) {
    lastComparison=org.apache.thrift.TBaseHelper.compareTo(this.message,other.message);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  lastComparison=java.lang.Boolean.compare(isSetCanRetry(),other.isSetCanRetry());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (isSetCanRetry()) {
    lastComparison=org.apache.thrift.TBaseHelper.compareTo(this.canRetry,other.canRetry);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  return 0;
}
