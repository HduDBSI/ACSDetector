/** 
 * Setup response for the IPC Call.
 * @param response buffer to serialize the response into
 * @param call {@link Call} to which we are setting up the response
 * @param status {@link Status} of the IPC call
 * @param rv return value for the IPC Call, if the call was successful
 * @param errorClass error class, if the the call failed
 * @param error error message, if the call failed
 * @throws IOException
 */
protected void setupResponse(ByteArrayOutputStream response,Call call,Status status,Writable rv,String errorClass,String error) throws IOException {
  response.reset();
  DataOutputStream out=new DataOutputStream(response);
  if (status == Status.SUCCESS) {
    try {
      rv.write(out);
      call.setResponse(rv,status,null,null);
    }
 catch (    Throwable t) {
      LOG.warn("Error serializing call response for call " + call,t);
      call.setResponse(null,status.ERROR,t.getClass().getName(),StringUtils.stringifyException(t));
    }
  }
 else {
    call.setResponse(rv,status,errorClass,error);
  }
}
