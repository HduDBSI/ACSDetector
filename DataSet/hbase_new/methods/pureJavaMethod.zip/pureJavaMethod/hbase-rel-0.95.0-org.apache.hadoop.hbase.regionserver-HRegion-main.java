/** 
 * Facility for dumping and compacting catalog tables. Only does catalog tables since these are only tables we for sure know schema on.  For usage run: <pre> ./bin/hbase org.apache.hadoop.hbase.regionserver.HRegion </pre>
 * @param args
 * @throws IOException
 */
public static void main(String[] args) throws IOException {
  if (args.length < 1) {
    printUsageAndExit(null);
  }
  boolean majorCompact=false;
  if (args.length > 1) {
    if (!args[1].toLowerCase().startsWith("major")) {
      printUsageAndExit("ERROR: Unrecognized option <" + args[1] + ">");
    }
    majorCompact=true;
  }
  final Path tableDir=new Path(args[0]);
  final Configuration c=HBaseConfiguration.create();
  final FileSystem fs=FileSystem.get(c);
  final Path logdir=new Path(c.get("hbase.tmp.dir"));
  final String logname="hlog" + tableDir.getName() + EnvironmentEdgeManager.currentTimeMillis();
  final HLog log=HLogFactory.createHLog(fs,logdir,logname,c);
  try {
    processTable(fs,tableDir,log,c,majorCompact);
  }
  finally {
    log.close();
    BlockCache bc=new CacheConfig(c).getBlockCache();
    if (bc != null)     bc.shutdown();
  }
}
