public void postSetNamespaceQuota(final String namespace,final GlobalQuotaSettings quotas) throws IOException {
  execOperation(coprocEnvironments.isEmpty() ? null : new MasterObserverOperation(){
    @Override public void call(    MasterObserver observer) throws IOException {
      observer.postSetNamespaceQuota(this,namespace,quotas);
    }
  }
);
}
