/** 
 * Checks that the given Cell's key does not violate the key order.
 * @param cell Cell whose key to check.
 * @return true if the key is duplicate
 * @throws IOException if the key or the key order is wrong
 */
protected boolean checkKey(final Cell cell) throws IOException {
  boolean isDuplicateKey=false;
  if (cell == null) {
    throw new IOException("Key cannot be null or empty");
  }
  if (lastCell != null) {
    int keyComp=PrivateCellUtil.compareKeyIgnoresMvcc(this.hFileContext.getCellComparator(),lastCell,cell);
    if (keyComp > 0) {
      String message=getLexicalErrorMessage(cell);
      throw new IOException(message);
    }
 else     if (keyComp == 0) {
      isDuplicateKey=true;
    }
  }
  return isDuplicateKey;
}
