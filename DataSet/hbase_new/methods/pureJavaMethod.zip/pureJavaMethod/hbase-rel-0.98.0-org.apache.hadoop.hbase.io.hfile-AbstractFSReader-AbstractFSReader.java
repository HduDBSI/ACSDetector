public AbstractFSReader(long fileSize,HFileSystem hfs,Path path,HFileContext fileContext) throws IOException {
  this.fileSize=fileSize;
  this.hfs=hfs;
  this.path=path;
  this.fileContext=fileContext;
  this.hdrSize=headerSize(fileContext.isUseHBaseChecksum());
}
