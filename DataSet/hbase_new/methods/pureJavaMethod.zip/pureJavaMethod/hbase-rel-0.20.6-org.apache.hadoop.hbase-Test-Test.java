/** 
 * Note that all subclasses of this class must provide a public contructor that has the exact same list of arguments.
 */
Test(final HBaseConfiguration conf,final int startRow,final int perClientRunRows,final int totalRows,final Status status,byte[] tableName){
  super();
  this.startRow=startRow;
  this.perClientRunRows=perClientRunRows;
  this.totalRows=totalRows;
  this.status=status;
  this.tableName=tableName;
  this.table=null;
  this.conf=conf;
}
