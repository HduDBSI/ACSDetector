public void postMoveTables(final Set<TableName> tables,final String targetGroup) throws IOException {
  execOperation(coprocEnvironments.isEmpty() ? null : new MasterObserverOperation(){
    @Override public void call(    MasterObserver observer) throws IOException {
      observer.postMoveTables(this,tables,targetGroup);
    }
  }
);
}
