private int count(final HRegionIncommon hri,final int flushIndex,boolean concurrent) throws IOException {
  LOG.info("Taking out counting scan");
  ScannerIncommon s=hri.getScanner(HConstants.CATALOG_FAMILY,EXPLICIT_COLS,HConstants.EMPTY_START_ROW,HConstants.LATEST_TIMESTAMP);
  List<Cell> values=new ArrayList<Cell>();
  int count=0;
  boolean justFlushed=false;
  while (s.next(values)) {
    if (justFlushed) {
      LOG.info("after next() just after next flush");
      justFlushed=false;
    }
    count++;
    if (flushIndex == count) {
      LOG.info("Starting flush at flush index " + flushIndex);
      Thread t=new Thread(){
        public void run(){
          try {
            hri.flushcache();
            LOG.info("Finishing flush");
          }
 catch (          IOException e) {
            LOG.info("Failed flush cache");
          }
        }
      }
;
      if (concurrent) {
        t.start();
      }
 else {
        t.run();
      }
      LOG.info("Continuing on after kicking off background flush");
      justFlushed=true;
    }
  }
  s.close();
  LOG.info("Found " + count + " items");
  return count;
}
