public static void restoreSnapshotAcl(SnapshotDescription snapshot,TableName newTableName,Configuration conf) throws IOException {
  if (snapshot.hasUsersAndPermissions() && snapshot.getUsersAndPermissions() != null) {
    LOG.info("Restore snapshot acl to table. snapshot: " + snapshot + ", table: "+ newTableName);
    ListMultimap<String,Permission> perms=ShadedAccessControlUtil.toUserTablePermissions(snapshot.getUsersAndPermissions());
    try (Connection conn=ConnectionFactory.createConnection(conf)){
      for (      Entry<String,Permission> e : perms.entries()) {
        String user=e.getKey();
        TablePermission tablePerm=(TablePermission)e.getValue();
        AccessControlClient.grant(conn,newTableName,user,tablePerm.getFamily(),tablePerm.getQualifier(),tablePerm.getActions());
      }
    }
 catch (    Throwable e) {
      throw new IOException("Grant acl into newly creatd table failed. snapshot: " + snapshot + ", table: "+ newTableName,e);
    }
  }
}
