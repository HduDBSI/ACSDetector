/** 
 * Generate set of puts to add to new meta.  This expects the tables to be clean with no overlaps or holes.  If there are any problems it returns null.
 * @return An array list of puts to do in bulk, null if tables have problems
 */
private ArrayList<Put> generatePuts(SortedMap<String,TableInfo> tablesInfo) throws IOException {
  ArrayList<Put> puts=new ArrayList<Put>();
  boolean hasProblems=false;
  for (  Entry<String,TableInfo> e : tablesInfo.entrySet()) {
    String name=e.getKey();
    if (Bytes.compareTo(Bytes.toBytes(name),HConstants.META_TABLE_NAME) == 0) {
      continue;
    }
    TableInfo ti=e.getValue();
    for (    Entry<byte[],Collection<HbckInfo>> spl : ti.sc.getStarts().asMap().entrySet()) {
      Collection<HbckInfo> his=spl.getValue();
      int sz=his.size();
      if (sz != 1) {
        LOG.error("Split starting at " + Bytes.toStringBinary(spl.getKey()) + " had "+ sz+ " regions instead of exactly 1.");
        hasProblems=true;
        continue;
      }
      HbckInfo hi=his.iterator().next();
      HRegionInfo hri=hi.getHdfsHRI();
      Put p=MetaEditor.makePutFromRegionInfo(hri);
      puts.add(p);
    }
  }
  return hasProblems ? null : puts;
}
