private void closeScannerIfExhausted(boolean exhausted) throws IOException {
  if (exhausted) {
    closeScanner();
  }
}
