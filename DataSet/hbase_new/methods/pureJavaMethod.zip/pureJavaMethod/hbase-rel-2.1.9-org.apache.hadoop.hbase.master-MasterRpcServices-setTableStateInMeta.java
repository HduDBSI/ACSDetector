/** 
 * Update state of the table in meta only. This is required by hbck in some situations to cleanup stuck assign/ unassign regions procedures for the table.
 * @return previous state of the table
 */
@Override public GetTableStateResponse setTableStateInMeta(RpcController controller,SetTableStateInMetaRequest request) throws ServiceException {
  TableName tn=ProtobufUtil.toTableName(request.getTableName());
  try {
    TableState prevState=this.master.getTableStateManager().getTableState(tn);
    TableState newState=TableState.convert(tn,request.getTableState());
    LOG.info("{} set table={} state from {} to {}",master.getClientIdAuditPrefix(),tn,prevState.getState(),newState.getState());
    this.master.getTableStateManager().setTableState(tn,newState.getState());
    return GetTableStateResponse.newBuilder().setTableState(prevState.convert()).build();
  }
 catch (  Exception e) {
    throw new ServiceException(e);
  }
}
