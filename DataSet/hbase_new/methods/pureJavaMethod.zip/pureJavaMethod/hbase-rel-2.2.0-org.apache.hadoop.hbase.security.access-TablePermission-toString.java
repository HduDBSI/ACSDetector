@Override public String toString(){
  return "[TablePermission: " + rawExpression() + "]";
}
