@Override public void process() throws IOException {
  boolean gotException=true;
  try {
    try {
      if (this.shouldSplitHlog) {
        if (this.services.shouldSplitMetaSeparately()) {
          LOG.info("Splitting META logs for " + serverName);
          this.services.getMasterFileSystem().splitMetaLog(serverName);
        }
 else {
          LOG.info("Splitting all logs for " + serverName);
          this.services.getMasterFileSystem().splitAllLogs(serverName);
        }
      }
    }
 catch (    IOException ioe) {
      this.services.getExecutorService().submit(this);
      this.deadServers.add(serverName);
      throw new IOException("failed log splitting for " + serverName + ", will retry",ioe);
    }
    if (isCarryingRoot()) {
      if (this.services.getAssignmentManager().isCarryingRoot(serverName)) {
        LOG.info("Server " + serverName + " was carrying ROOT. Trying to assign.");
        this.services.getAssignmentManager().regionOffline(HRegionInfo.ROOT_REGIONINFO);
        verifyAndAssignRootWithRetries();
      }
 else {
        LOG.info("ROOT has been assigned to otherwhere, skip assigning.");
      }
    }
    if (!this.services.isServerShutdownHandlerEnabled()) {
      this.services.getExecutorService().submit(this);
      this.deadServers.add(serverName);
      return;
    }
    if (isCarryingMeta()) {
      if (this.services.getAssignmentManager().isCarryingMeta(serverName)) {
        LOG.info("Server " + serverName + " was carrying META. Trying to assign.");
        this.services.getAssignmentManager().regionOffline(HRegionInfo.FIRST_META_REGIONINFO);
        this.services.getAssignmentManager().assignMeta();
      }
 else {
        LOG.info("META has been assigned to otherwhere, skip assigning.");
      }
    }
    gotException=false;
  }
  finally {
    if (gotException) {
      this.deadServers.finish(serverName);
    }
  }
  super.process();
}
