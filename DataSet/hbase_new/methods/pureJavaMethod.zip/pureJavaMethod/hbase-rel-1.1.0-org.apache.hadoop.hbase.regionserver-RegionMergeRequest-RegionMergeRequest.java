RegionMergeRequest(Region a,Region b,HRegionServer hrs,boolean forcible){
  Preconditions.checkNotNull(hrs);
  this.region_a=(HRegion)a;
  this.region_b=(HRegion)b;
  this.server=hrs;
  this.forcible=forcible;
}
