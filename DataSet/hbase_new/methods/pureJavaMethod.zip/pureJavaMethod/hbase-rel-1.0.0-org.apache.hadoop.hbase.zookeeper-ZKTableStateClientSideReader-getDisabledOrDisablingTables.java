/** 
 * Gets a list of all the tables set as disabled in zookeeper.
 * @return Set of disabled tables, empty Set if none
 * @throws KeeperException
 */
public static Set<TableName> getDisabledOrDisablingTables(ZooKeeperWatcher zkw) throws KeeperException, InterruptedException {
  return getTablesInStates(zkw,ZooKeeperProtos.Table.State.DISABLED,ZooKeeperProtos.Table.State.DISABLING);
}
