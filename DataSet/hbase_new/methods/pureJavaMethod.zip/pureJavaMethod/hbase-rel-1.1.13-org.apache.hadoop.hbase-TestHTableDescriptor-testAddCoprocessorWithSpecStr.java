@Test public void testAddCoprocessorWithSpecStr() throws IOException {
  HTableDescriptor htd=new HTableDescriptor(TableName.META_TABLE_NAME);
  String cpName="a.b.c.d";
  try {
    htd.addCoprocessorWithSpec(cpName);
    fail();
  }
 catch (  IllegalArgumentException iae) {
  }
  try {
    htd.addCoprocessorWithSpec("file:///some/path" + "|" + cpName);
    fail();
  }
 catch (  IllegalArgumentException iae) {
  }
  String spec="hdfs:///foo.jar|com.foo.FooRegionObserver|1001|arg1=1,arg2=2";
  try {
    htd.addCoprocessorWithSpec(spec);
  }
 catch (  IllegalArgumentException iae) {
    fail();
  }
  try {
    htd.addCoprocessorWithSpec(spec);
    fail();
  }
 catch (  IOException ioe) {
  }
}
