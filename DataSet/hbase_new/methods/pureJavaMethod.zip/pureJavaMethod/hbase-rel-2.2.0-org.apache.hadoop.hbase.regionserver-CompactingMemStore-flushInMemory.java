private void flushInMemory(MutableSegment currActive){
  LOG.trace("IN-MEMORY FLUSH: Pushing active segment into compaction pipeline");
  pushActiveToPipeline(currActive);
}
