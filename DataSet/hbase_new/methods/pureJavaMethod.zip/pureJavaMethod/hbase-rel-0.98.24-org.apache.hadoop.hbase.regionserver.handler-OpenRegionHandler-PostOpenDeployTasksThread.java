PostOpenDeployTasksThread(final HRegion region,final Server server,final RegionServerServices services,final AtomicBoolean signaller,final long masterSystemTime){
  super("PostOpenDeployTasks:" + region.getRegionInfo().getEncodedName());
  this.setDaemon(true);
  this.server=server;
  this.services=services;
  this.region=region;
  this.signaller=signaller;
  this.masterSystemTime=masterSystemTime;
}
