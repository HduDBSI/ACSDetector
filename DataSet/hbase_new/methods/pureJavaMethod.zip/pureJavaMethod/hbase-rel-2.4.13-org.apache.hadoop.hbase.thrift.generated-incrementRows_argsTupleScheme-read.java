@Override public void read(org.apache.thrift.protocol.TProtocol prot,incrementRows_args struct) throws org.apache.thrift.TException {
  org.apache.thrift.protocol.TTupleProtocol iprot=(org.apache.thrift.protocol.TTupleProtocol)prot;
  java.util.BitSet incoming=iprot.readBitSet(1);
  if (incoming.get(0)) {
{
      org.apache.thrift.protocol.TList _list463=iprot.readListBegin(org.apache.thrift.protocol.TType.STRUCT);
      struct.increments=new java.util.ArrayList<TIncrement>(_list463.size);
      @org.apache.thrift.annotation.Nullable TIncrement _elem464;
      for (int _i465=0; _i465 < _list463.size; ++_i465) {
        _elem464=new TIncrement();
        _elem464.read(iprot);
        struct.increments.add(_elem464);
      }
    }
    struct.setIncrementsIsSet(true);
  }
}
