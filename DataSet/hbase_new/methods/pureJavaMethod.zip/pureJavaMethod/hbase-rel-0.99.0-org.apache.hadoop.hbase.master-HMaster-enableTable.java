@Override public void enableTable(final TableName tableName) throws IOException {
  checkInitialized();
  if (cpHost != null) {
    cpHost.preEnableTable(tableName);
  }
  LOG.info(getClientIdAuditPrefix() + " enable " + tableName);
  this.service.submit(new EnableTableHandler(this,tableName,assignmentManager,tableLockManager,false).prepare());
  if (cpHost != null) {
    cpHost.postEnableTable(tableName);
  }
}
