/** 
 * return HTableDescriptor for a given tableName
 * @param tableName the table name
 * @return HTableDescriptor
 * @throws IOException
 */
protected HTableDescriptor getTableDescriptor(TableName tableName) throws IOException {
  HTableDescriptor tableDescriptor=null;
  try {
    if (this.services != null) {
      tableDescriptor=this.services.getTableDescriptors().get(tableName);
    }
  }
 catch (  FileNotFoundException fnfe) {
    LOG.debug("FileNotFoundException during getTableDescriptors." + " Current table name = " + tableName,fnfe);
  }
  return tableDescriptor;
}
