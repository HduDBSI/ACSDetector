public void start(long startKey,long endKey,int numThreads) throws IOException {
  this.startKey=startKey;
  this.endKey=endKey;
  this.numThreads=numThreads;
  (new Thread(new ProgressReporter(actionLetter))).start();
}
