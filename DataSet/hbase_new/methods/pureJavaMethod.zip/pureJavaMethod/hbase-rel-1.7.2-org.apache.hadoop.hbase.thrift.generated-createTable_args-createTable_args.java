/** 
 * Performs a deep copy on <i>other</i>.
 */
public createTable_args(createTable_args other){
  if (other.isSetTableName()) {
    this.tableName=org.apache.thrift.TBaseHelper.copyBinary(other.tableName);
  }
  if (other.isSetColumnFamilies()) {
    java.util.List<ColumnDescriptor> __this__columnFamilies=new java.util.ArrayList<ColumnDescriptor>(other.columnFamilies.size());
    for (    ColumnDescriptor other_element : other.columnFamilies) {
      __this__columnFamilies.add(new ColumnDescriptor(other_element));
    }
    this.columnFamilies=__this__columnFamilies;
  }
}
