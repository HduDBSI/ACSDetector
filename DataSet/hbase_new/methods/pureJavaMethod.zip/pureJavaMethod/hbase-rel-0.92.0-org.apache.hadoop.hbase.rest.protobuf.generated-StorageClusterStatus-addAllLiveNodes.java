public Builder addAllLiveNodes(java.lang.Iterable<? extends org.apache.hadoop.hbase.rest.protobuf.generated.StorageClusterStatusMessage.StorageClusterStatus.Node> values){
  if (liveNodesBuilder_ == null) {
    ensureLiveNodesIsMutable();
    super.addAll(values,liveNodes_);
    onChanged();
  }
 else {
    liveNodesBuilder_.addAllMessages(values);
  }
  return this;
}
