<CResult>AsyncRequestFutureImpl<CResult> createAsyncRequestFuture(TableName tableName,List<Action<Row>> actions,long nonceGroup,ExecutorService pool,Batch.Callback<CResult> callback,Object[] results,boolean needResults,PayloadCarryingServerCallable callable,int operationTimeout,int rpcTimeout){
  return new AsyncRequestFutureImpl<CResult>(tableName,actions,nonceGroup,getPool(pool),needResults,results,callback,callable,operationTimeout,rpcTimeout);
}
