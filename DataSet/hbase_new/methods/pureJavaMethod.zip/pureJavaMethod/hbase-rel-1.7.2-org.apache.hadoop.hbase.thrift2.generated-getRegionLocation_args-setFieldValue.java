public void setFieldValue(_Fields field,@org.apache.thrift.annotation.Nullable java.lang.Object value){
switch (field) {
case TABLE:
    if (value == null) {
      unsetTable();
    }
 else {
      if (value instanceof byte[]) {
        setTable((byte[])value);
      }
 else {
        setTable((java.nio.ByteBuffer)value);
      }
    }
  break;
case ROW:
if (value == null) {
  unsetRow();
}
 else {
  if (value instanceof byte[]) {
    setRow((byte[])value);
  }
 else {
    setRow((java.nio.ByteBuffer)value);
  }
}
break;
case RELOAD:
if (value == null) {
unsetReload();
}
 else {
setReload((java.lang.Boolean)value);
}
break;
}
}
