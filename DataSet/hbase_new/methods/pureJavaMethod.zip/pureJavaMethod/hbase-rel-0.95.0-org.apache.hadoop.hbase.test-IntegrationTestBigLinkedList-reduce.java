public void reduce(LongWritable key,Iterable<VLongWritable> values,Context context) throws IOException, InterruptedException {
  int defCount=0;
  refs.clear();
  for (  VLongWritable type : values) {
    if (type.get() == -1) {
      defCount++;
    }
 else {
      refs.add(type.get());
    }
  }
  if (defCount == 0 && refs.size() > 0) {
    StringBuilder sb=new StringBuilder();
    String comma="";
    for (    Long ref : refs) {
      sb.append(comma);
      comma=",";
      sb.append(String.format("%016x",ref));
    }
    context.write(new Text(String.format("%016x",key.get())),new Text(sb.toString()));
    context.getCounter(Counts.UNDEFINED).increment(1);
  }
 else   if (defCount > 0 && refs.size() == 0) {
    context.getCounter(Counts.UNREFERENCED).increment(1);
  }
 else {
    context.getCounter(Counts.REFERENCED).increment(1);
  }
}
