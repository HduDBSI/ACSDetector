@Override public String[] getExecString(){
  String at=sshUserName.isEmpty() ? "" : "@";
  String remoteCmd=StringUtils.join(super.getExecString()," ");
  String cmd=String.format(tunnelCmd,sshOptions,sshUserName,at,hostname,remoteCmd);
  LOG.info("Executing full command [" + cmd + "]");
  return new String[]{"/usr/bin/env","bash","-c",cmd};
}
