public Map<TableName,Map<ServerName,List<String>>> getTableServerRegionMap() throws IOException {
  Map<TableName,Map<ServerName,List<String>>> map=Maps.newTreeMap();
  ClusterMetrics status=TEST_UTIL.getHBaseClusterInterface().getClusterMetrics();
  for (  Map.Entry<ServerName,ServerMetrics> entry : status.getLiveServerMetrics().entrySet()) {
    ServerName serverName=entry.getKey();
    for (    RegionMetrics rl : entry.getValue().getRegionMetrics().values()) {
      TableName tableName=null;
      try {
        tableName=RegionInfo.getTable(rl.getRegionName());
      }
 catch (      IllegalArgumentException e) {
        LOG.warn("Failed parse a table name from regionname=" + Bytes.toStringBinary(rl.getRegionName()));
        continue;
      }
      if (!map.containsKey(tableName)) {
        map.put(tableName,new TreeMap<>());
      }
      if (!map.get(tableName).containsKey(serverName)) {
        map.get(tableName).put(serverName,new LinkedList<>());
      }
      map.get(tableName).get(serverName).add(rl.getNameAsString());
    }
  }
  return map;
}
