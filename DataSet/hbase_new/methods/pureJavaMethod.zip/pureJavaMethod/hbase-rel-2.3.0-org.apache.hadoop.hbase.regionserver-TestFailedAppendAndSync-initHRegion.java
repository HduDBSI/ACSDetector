/** 
 * @return A region on which you must call{@link HBaseTestingUtility#closeRegionAndWAL(HRegion)} when done.
 */
public static HRegion initHRegion(TableName tableName,byte[] startKey,byte[] stopKey,WAL wal) throws IOException {
  ChunkCreator.initialize(MemStoreLABImpl.CHUNK_SIZE_DEFAULT,false,0,0,0,null);
  return TEST_UTIL.createLocalHRegion(tableName,startKey,stopKey,false,Durability.SYNC_WAL,wal,COLUMN_FAMILY_BYTES);
}
