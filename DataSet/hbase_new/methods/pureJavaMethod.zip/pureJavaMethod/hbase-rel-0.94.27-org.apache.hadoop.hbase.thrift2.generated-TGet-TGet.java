/** 
 * Performs a deep copy on <i>other</i>.
 */
public TGet(TGet other){
  __isset_bit_vector.clear();
  __isset_bit_vector.or(other.__isset_bit_vector);
  if (other.isSetRow()) {
    this.row=org.apache.thrift.TBaseHelper.copyBinary(other.row);
    ;
  }
  if (other.isSetColumns()) {
    List<TColumn> __this__columns=new ArrayList<TColumn>();
    for (    TColumn other_element : other.columns) {
      __this__columns.add(new TColumn(other_element));
    }
    this.columns=__this__columns;
  }
  this.timestamp=other.timestamp;
  if (other.isSetTimeRange()) {
    this.timeRange=new TTimeRange(other.timeRange);
  }
  this.maxVersions=other.maxVersions;
  if (other.isSetFilterString()) {
    this.filterString=org.apache.thrift.TBaseHelper.copyBinary(other.filterString);
    ;
  }
  if (other.isSetAttributes()) {
    Map<ByteBuffer,ByteBuffer> __this__attributes=new HashMap<ByteBuffer,ByteBuffer>();
    for (    Map.Entry<ByteBuffer,ByteBuffer> other_element : other.attributes.entrySet()) {
      ByteBuffer other_element_key=other_element.getKey();
      ByteBuffer other_element_value=other_element.getValue();
      ByteBuffer __this__attributes_copy_key=org.apache.thrift.TBaseHelper.copyBinary(other_element_key);
      ;
      ByteBuffer __this__attributes_copy_value=org.apache.thrift.TBaseHelper.copyBinary(other_element_value);
      ;
      __this__attributes.put(__this__attributes_copy_key,__this__attributes_copy_value);
    }
    this.attributes=__this__attributes;
  }
}
