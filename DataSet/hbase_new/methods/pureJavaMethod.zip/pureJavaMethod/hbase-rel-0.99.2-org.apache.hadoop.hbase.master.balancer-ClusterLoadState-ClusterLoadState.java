public ClusterLoadState(Map<ServerName,List<HRegionInfo>> clusterState){
  this.numRegions=0;
  this.numServers=clusterState.size();
  this.clusterState=clusterState;
  serversByLoad=new TreeMap<ServerAndLoad,List<HRegionInfo>>();
  for (  Map.Entry<ServerName,List<HRegionInfo>> server : clusterState.entrySet()) {
    List<HRegionInfo> regions=server.getValue();
    int sz=regions.size();
    if (sz == 0)     emptyRegionServerPresent=true;
    numRegions+=sz;
    serversByLoad.put(new ServerAndLoad(server.getKey(),sz),regions);
  }
}
