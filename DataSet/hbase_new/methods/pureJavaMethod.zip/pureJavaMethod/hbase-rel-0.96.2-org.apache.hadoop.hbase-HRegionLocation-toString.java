/** 
 * @see java.lang.Object#toString()
 */
@Override public String toString(){
  return "region=" + this.regionInfo.getRegionNameAsString() + ", hostname="+ this.serverName+ ", seqNum="+ seqNum;
}
