/** 
 * Add the specified KeyValue to the list of deletes to check against for this row operation. <p> This is called when a Delete is encountered in a StoreFile.
 * @param buffer KeyValue buffer
 * @param qualifierOffset column qualifier offset
 * @param qualifierLength column qualifier length
 * @param timestamp timestamp
 * @param type delete type as byte
 */
void add(byte[] buffer,int qualifierOffset,int qualifierLength,long timestamp,byte type);
