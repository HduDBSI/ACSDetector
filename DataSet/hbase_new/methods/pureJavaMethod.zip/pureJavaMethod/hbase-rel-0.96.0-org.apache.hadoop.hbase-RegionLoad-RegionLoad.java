public RegionLoad(ClusterStatusProtos.RegionLoad regionLoadPB){
  this.regionLoadPB=regionLoadPB;
}
