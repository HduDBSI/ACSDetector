public boolean preBalanceSwitch(final boolean b) throws IOException {
  return execOperationWithResult(b,coprocessors.isEmpty() ? null : new CoprocessorOperationWithResult<Boolean>(){
    @Override public void call(    MasterObserver oserver,    ObserverContext<MasterCoprocessorEnvironment> ctx) throws IOException {
      setResult(oserver.preBalanceSwitch(ctx,getResult()));
    }
  }
);
}
