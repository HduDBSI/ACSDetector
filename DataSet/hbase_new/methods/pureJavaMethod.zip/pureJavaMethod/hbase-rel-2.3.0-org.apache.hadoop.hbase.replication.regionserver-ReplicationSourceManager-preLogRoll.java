@VisibleForTesting public void preLogRoll(Path newLog) throws IOException {
  String logName=newLog.getName();
  String logPrefix=AbstractFSWALProvider.getWALPrefixFromWALName(logName);
synchronized (this.latestPaths) {
    for (    ReplicationSourceInterface source : this.sources.values()) {
      abortAndThrowIOExceptionWhenFail(() -> this.queueStorage.addWAL(server.getServerName(),source.getQueueId(),logName));
    }
synchronized (this.walsById) {
      for (      Map.Entry<String,Map<String,NavigableSet<String>>> entry : this.walsById.entrySet()) {
        String peerId=entry.getKey();
        Map<String,NavigableSet<String>> walsByPrefix=entry.getValue();
        boolean existingPrefix=false;
        for (        Map.Entry<String,NavigableSet<String>> walsEntry : walsByPrefix.entrySet()) {
          SortedSet<String> wals=walsEntry.getValue();
          if (this.sources.isEmpty()) {
            wals.clear();
          }
          if (logPrefix.equals(walsEntry.getKey())) {
            wals.add(logName);
            existingPrefix=true;
          }
        }
        if (!existingPrefix) {
          LOG.debug("Start tracking logs for wal group {} for peer {}",logPrefix,peerId);
          NavigableSet<String> wals=new TreeSet<>();
          wals.add(logName);
          walsByPrefix.put(logPrefix,wals);
        }
      }
    }
    Iterator<Path> iterator=latestPaths.iterator();
    while (iterator.hasNext()) {
      Path path=iterator.next();
      if (path.getName().contains(logPrefix)) {
        iterator.remove();
        break;
      }
    }
    this.latestPaths.add(newLog);
  }
}
