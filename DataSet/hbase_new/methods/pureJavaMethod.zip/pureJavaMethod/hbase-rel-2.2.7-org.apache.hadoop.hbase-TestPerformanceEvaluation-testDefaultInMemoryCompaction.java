@Test public void testDefaultInMemoryCompaction(){
  PerformanceEvaluation.TestOptions defaultOpts=new PerformanceEvaluation.TestOptions();
  assertEquals(CompactingMemStore.COMPACTING_MEMSTORE_TYPE_DEFAULT,defaultOpts.getInMemoryCompaction().toString());
  HTableDescriptor htd=PerformanceEvaluation.getTableDescriptor(defaultOpts);
  for (  HColumnDescriptor hcd : htd.getFamilies()) {
    assertEquals(CompactingMemStore.COMPACTING_MEMSTORE_TYPE_DEFAULT,hcd.getInMemoryCompaction().toString());
  }
}
