@Override public Cell current(){
  if (cells == null)   return null;
  return (cellScannerIndex < 0) ? null : this.cells[cellScannerIndex];
}
