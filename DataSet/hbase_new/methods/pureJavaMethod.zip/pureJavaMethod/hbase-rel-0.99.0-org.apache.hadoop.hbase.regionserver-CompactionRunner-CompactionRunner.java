public CompactionRunner(Store store,HRegion region,CompactionContext compaction,ThreadPoolExecutor parent){
  super();
  this.store=store;
  this.region=region;
  this.compaction=compaction;
  this.queuedPriority=(this.compaction == null) ? store.getCompactPriority() : compaction.getRequest().getPriority();
  this.parent=parent;
}
