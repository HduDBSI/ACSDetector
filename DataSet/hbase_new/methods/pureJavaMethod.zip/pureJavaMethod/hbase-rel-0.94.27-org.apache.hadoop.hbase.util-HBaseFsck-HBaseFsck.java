/** 
 * Constructor
 * @param conf Configuration object
 * @throws MasterNotRunningException if the master is not running
 * @throws ZooKeeperConnectionException if unable to connect to ZooKeeper
 */
public HBaseFsck(Configuration conf,ExecutorService exec) throws MasterNotRunningException, ZooKeeperConnectionException, IOException, ClassNotFoundException {
  super(conf);
  errors=getErrorReporter(getConf());
  this.executor=exec;
}
