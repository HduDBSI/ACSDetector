public void postBalance(final List<RegionPlan> plans) throws IOException {
  execOperation(coprocEnvironments.isEmpty() ? null : new MasterObserverOperation(){
    @Override public void call(    MasterObserver observer) throws IOException {
      observer.postBalance(this,plans);
    }
  }
);
}
