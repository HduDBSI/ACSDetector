@Override public List<TableName> listTableNamesByNamespace(String name) throws IOException {
  List<TableName> tableNames=Lists.newArrayList();
  if (!isTableNamespaceManagerReady()) {
    return tableNames;
  }
  getNamespaceDescriptor(name);
  for (  HTableDescriptor descriptor : tableDescriptors.getByNamespace(name).values()) {
    tableNames.add(descriptor.getTableName());
  }
  return tableNames;
}
