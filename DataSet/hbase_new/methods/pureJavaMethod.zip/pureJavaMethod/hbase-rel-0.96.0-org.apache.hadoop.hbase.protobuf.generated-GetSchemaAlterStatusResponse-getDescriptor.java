public static final com.google.protobuf.Descriptors.Descriptor getDescriptor(){
  return org.apache.hadoop.hbase.protobuf.generated.MasterProtos.internal_static_GetSchemaAlterStatusResponse_descriptor;
}
