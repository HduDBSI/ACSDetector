@Override public HTableDescriptor get(TableName tablename) throws TableExistsException, FileNotFoundException, IOException {
  LOG.info(tablename + ", cachehits=" + this.cachehits);
  return super.get(tablename);
}
