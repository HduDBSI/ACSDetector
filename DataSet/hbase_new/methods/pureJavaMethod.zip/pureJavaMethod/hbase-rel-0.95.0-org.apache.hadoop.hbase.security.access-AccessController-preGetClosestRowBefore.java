@Override public void preGetClosestRowBefore(final ObserverContext<RegionCoprocessorEnvironment> c,final byte[] row,final byte[] family,final Result result) throws IOException {
  assert family != null;
  requirePermission("getClosestRowBefore",Permission.Action.READ,c.getEnvironment(),makeFamilyMap(family,null));
}
