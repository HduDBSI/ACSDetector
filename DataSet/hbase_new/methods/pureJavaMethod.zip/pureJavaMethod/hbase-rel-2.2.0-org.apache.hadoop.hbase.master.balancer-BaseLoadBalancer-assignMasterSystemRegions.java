/** 
 * If master is configured to carry system tables only, in here is where we figure what to assign it.
 */
protected Map<ServerName,List<RegionInfo>> assignMasterSystemRegions(Collection<RegionInfo> regions,List<ServerName> servers){
  if (servers == null || regions == null || regions.isEmpty()) {
    return null;
  }
  Map<ServerName,List<RegionInfo>> assignments=new TreeMap<>();
  if (this.maintenanceMode || this.onlySystemTablesOnMaster) {
    if (masterServerName != null && servers.contains(masterServerName)) {
      assignments.put(masterServerName,new ArrayList<>());
      for (      RegionInfo region : regions) {
        if (shouldBeOnMaster(region)) {
          assignments.get(masterServerName).add(region);
        }
      }
    }
  }
  return assignments;
}
