/** 
 * Look for an exception we know in the remote exception: - hadoop.ipc wrapped exceptions - nested exceptions Looks for: RegionMovedException / RegionOpeningException / RegionTooBusyException / ThrottlingException
 * @return null if we didn't find the exception, the exception otherwise.
 */
public static Throwable findException(Object exception){
  if (exception == null || !(exception instanceof Throwable)) {
    return null;
  }
  Throwable cur=(Throwable)exception;
  while (cur != null) {
    if (isSpecialException(cur)) {
      return cur;
    }
    if (cur instanceof RemoteException) {
      RemoteException re=(RemoteException)cur;
      cur=re.unwrapRemoteException(RegionOpeningException.class,RegionMovedException.class,RegionTooBusyException.class);
      if (cur == null) {
        cur=re.unwrapRemoteException();
      }
      if (cur == re) {
        return cur;
      }
    }
 else     if (cur.getCause() != null) {
      cur=cur.getCause();
    }
 else {
      return cur;
    }
  }
  return null;
}
