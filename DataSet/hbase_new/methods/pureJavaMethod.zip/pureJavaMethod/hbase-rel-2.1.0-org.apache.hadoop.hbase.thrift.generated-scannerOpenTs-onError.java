public void onError(Exception e){
  byte msgType=org.apache.thrift.protocol.TMessageType.REPLY;
  org.apache.thrift.TBase msg;
  scannerOpenTs_result result=new scannerOpenTs_result();
  if (e instanceof IOError) {
    result.io=(IOError)e;
    result.setIoIsSet(true);
    msg=result;
  }
 else {
    msgType=org.apache.thrift.protocol.TMessageType.EXCEPTION;
    msg=(org.apache.thrift.TBase)new org.apache.thrift.TApplicationException(org.apache.thrift.TApplicationException.INTERNAL_ERROR,e.getMessage());
  }
  try {
    fcall.sendResponse(fb,msg,msgType,seqid);
    return;
  }
 catch (  Exception ex) {
    LOGGER.error("Exception writing to internal frame buffer",ex);
  }
  fb.close();
}
