/** 
 * Do Cache full exception
 * @throws IOException
 * @throws InterruptedException
 */
@Test public void testCacheFullException() throws IOException, InterruptedException {
  this.bc.cacheBlock(this.plainKey,plainCacheable);
  RAMQueueEntry rqe=q.remove();
  RAMQueueEntry spiedRqe=Mockito.spy(rqe);
  final CacheFullException cfe=new CacheFullException(0,0);
  BucketEntry mockedBucketEntry=Mockito.mock(BucketEntry.class);
  Mockito.doThrow(cfe).doReturn(mockedBucketEntry).when(spiedRqe).writeToCache(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any());
  this.q.add(spiedRqe);
  doDrainOfOneEntry(bc,wt,q);
}
