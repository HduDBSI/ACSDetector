static Subject getSubject() throws Exception {
  if (!secure) {
    return new Subject();
  }
  LoginContext context=ClientUtils.getLoginContext();
  context.login();
  return context.getSubject();
}
