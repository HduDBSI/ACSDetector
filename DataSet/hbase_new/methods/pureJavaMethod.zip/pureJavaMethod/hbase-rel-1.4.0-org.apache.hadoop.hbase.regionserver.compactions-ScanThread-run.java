@Override public void run(){
  try {
    initiateScan(region);
  }
 catch (  IOException e) {
  }
}
