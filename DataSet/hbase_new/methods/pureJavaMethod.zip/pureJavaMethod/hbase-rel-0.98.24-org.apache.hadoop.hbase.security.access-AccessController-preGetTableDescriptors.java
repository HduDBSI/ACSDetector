@Override public void preGetTableDescriptors(ObserverContext<MasterCoprocessorEnvironment> ctx,List<TableName> tableNamesList,List<HTableDescriptor> descriptors) throws IOException {
  if (tableNamesList == null || tableNamesList.isEmpty()) {
    requireGlobalPermission("getTableDescriptors",Action.ADMIN,null,null);
  }
 else {
    MasterServices masterServices=ctx.getEnvironment().getMasterServices();
    for (    TableName tableName : tableNamesList) {
      if (masterServices.getTableDescriptors().get(tableName) == null) {
        continue;
      }
      requirePermission("getTableDescriptors",tableName,null,null,Action.ADMIN,Action.CREATE);
    }
  }
}
