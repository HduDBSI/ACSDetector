public abstract void call(RegionServerObserver oserver,ObserverContext<RegionServerCoprocessorEnvironment> ctx) throws IOException ;
