public void postSetNamespaceQuota(final String namespace,final Quotas quotas) throws IOException {
  execOperation(coprocessors.isEmpty() ? null : new CoprocessorOperation(){
    @Override public void call(    MasterObserver oserver,    ObserverContext<MasterCoprocessorEnvironment> ctx) throws IOException {
      oserver.postSetNamespaceQuota(ctx,namespace,quotas);
    }
  }
);
}
