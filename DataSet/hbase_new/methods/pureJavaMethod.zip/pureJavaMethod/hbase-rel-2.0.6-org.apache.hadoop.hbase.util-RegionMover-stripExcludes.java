/** 
 * Excludes the servername whose hostname and port portion matches the list given in exclude file
 */
private void stripExcludes(List<ServerName> regionServers) throws IOException {
  if (excludeFile != null) {
    List<String> excludes=readExcludes(excludeFile);
    Iterator<ServerName> i=regionServers.iterator();
    while (i.hasNext()) {
      String rs=i.next().getServerName();
      String rsPort=rs.split(ServerName.SERVERNAME_SEPARATOR)[0].toLowerCase() + ":" + rs.split(ServerName.SERVERNAME_SEPARATOR)[1];
      if (excludes.contains(rsPort)) {
        i.remove();
      }
    }
    LOG.info("Valid Region server targets are:" + regionServers.toString());
    LOG.info("Excluded Servers are" + excludes.toString());
  }
}
