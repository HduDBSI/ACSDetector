private TableDescriptor loadTableDescriptor() throws FileNotFoundException, IOException {
  TableDescriptor htd=this.master.getTableDescriptors().get(snapshotTable);
  if (htd == null) {
    throw new IOException("TableDescriptor missing for " + snapshotTable);
  }
  return htd;
}
