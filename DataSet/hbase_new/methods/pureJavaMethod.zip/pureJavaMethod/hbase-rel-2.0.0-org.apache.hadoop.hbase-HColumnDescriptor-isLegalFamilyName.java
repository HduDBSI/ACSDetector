/** 
 * @param b Family name.
 * @return <code>b</code>
 * @throws IllegalArgumentException If not null and not a legitimate familyname: i.e. 'printable' and ends in a ':' (Null passes are allowed because <code>b</code> can be null when deserializing).  Cannot start with a '.' either. Also Family can not be an empty value or equal "recovered.edits".
 * @deprecated Use {@link ColumnFamilyDescriptorBuilder#isLegalColumnFamilyName(byte[])}.
 */
@Deprecated public static byte[] isLegalFamilyName(final byte[] b){
  return ColumnFamilyDescriptorBuilder.isLegalColumnFamilyName(b);
}
