public static int compareQualifiers(Cell left,Cell right){
  return Bytes.compareTo(left.getQualifierArray(),left.getQualifierOffset(),left.getQualifierLength(),right.getQualifierArray(),right.getQualifierOffset(),right.getQualifierLength());
}
