public static void init(Configuration conf){
  SaslUtil.initSaslProperties(conf.get("hbase.rpc.protection",QualityOfProtection.AUTHENTICATION.name().toLowerCase()));
}
