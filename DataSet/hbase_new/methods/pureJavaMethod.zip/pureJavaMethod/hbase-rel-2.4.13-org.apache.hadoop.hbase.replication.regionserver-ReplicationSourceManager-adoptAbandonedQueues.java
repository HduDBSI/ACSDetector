private void adoptAbandonedQueues(){
  List<ServerName> currentReplicators=null;
  try {
    currentReplicators=queueStorage.getListOfReplicators();
  }
 catch (  ReplicationException e) {
    server.abort("Failed to get all replicators",e);
    return;
  }
  if (currentReplicators == null || currentReplicators.isEmpty()) {
    return;
  }
  List<ServerName> otherRegionServers=replicationTracker.getListOfRegionServers();
  LOG.info("Current list of replicators: " + currentReplicators + " other RSs: "+ otherRegionServers);
  for (  ServerName rs : currentReplicators) {
    if (!otherRegionServers.contains(rs)) {
      transferQueues(rs);
    }
  }
}
