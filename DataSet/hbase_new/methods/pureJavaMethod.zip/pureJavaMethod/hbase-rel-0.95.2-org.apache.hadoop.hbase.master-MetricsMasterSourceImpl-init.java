@Override public void init(){
  super.init();
  clusterRequestsCounter=metricsRegistry.newCounter(CLUSTER_REQUESTS_NAME,"",0l);
  ritGauge=metricsRegistry.newGauge(RIT_COUNT_NAME,"",0l);
  ritCountOverThresholdGauge=metricsRegistry.newGauge(RIT_COUNT_OVER_THRESHOLD_NAME,"",0l);
  ritOldestAgeGauge=metricsRegistry.newGauge(RIT_OLDEST_AGE_NAME,"",0l);
  splitSizeHisto=metricsRegistry.newHistogram(SPLIT_SIZE_NAME,SPLIT_SIZE_DESC);
  splitTimeHisto=metricsRegistry.newHistogram(SPLIT_TIME_NAME,SPLIT_TIME_DESC);
  snapshotTimeHisto=metricsRegistry.newStat(SNAPSHOT_TIME_NAME,SNAPSHOT_TIME_DESC,"Ops","Time",true);
  snapshotCloneTimeHisto=metricsRegistry.newStat(SNAPSHOT_CLONE_TIME_NAME,SNAPSHOT_CLONE_TIME_DESC,"Ops","Time",true);
  snapshotRestoreTimeHisto=metricsRegistry.newStat(SNAPSHOT_RESTORE_TIME_NAME,SNAPSHOT_RESTORE_TIME_DESC,"Ops","Time",true);
  metaSplitTimeHisto=metricsRegistry.newHistogram(META_SPLIT_TIME_NAME,META_SPLIT_TIME_DESC);
  metaSplitSizeHisto=metricsRegistry.newHistogram(META_SPLIT_SIZE_NAME,META_SPLIT_SIZE_DESC);
}
