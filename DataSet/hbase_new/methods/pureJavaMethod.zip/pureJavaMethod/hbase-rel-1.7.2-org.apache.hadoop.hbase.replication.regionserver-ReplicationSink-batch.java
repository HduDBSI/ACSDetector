/** 
 * Do the changes and handle the pool
 * @param tableName table to insert into
 * @param allRows list of actions
 * @param batchRowSizeThreshold rowSize threshold for batch mutation
 */
private void batch(TableName tableName,Collection<List<Row>> allRows,int batchRowSizeThreshold) throws IOException {
  if (allRows.isEmpty()) {
    return;
  }
  Table table=null;
  try {
    Connection connection=getConnection();
    table=connection.getTable(tableName);
    for (    List<Row> rows : allRows) {
      List<List<Row>> batchRows;
      if (rows.size() > batchRowSizeThreshold) {
        batchRows=Lists.partition(rows,batchRowSizeThreshold);
      }
 else {
        batchRows=Collections.singletonList(rows);
      }
      for (      List<Row> rowList : batchRows) {
        table.batch(rowList);
      }
    }
  }
 catch (  RetriesExhaustedWithDetailsException rewde) {
    for (    Throwable ex : rewde.getCauses()) {
      if (ex instanceof TableNotFoundException) {
        throw new TableNotFoundException("'" + tableName + "'");
      }
    }
    throw rewde;
  }
catch (  InterruptedException ix) {
    throw (InterruptedIOException)new InterruptedIOException().initCause(ix);
  }
 finally {
    if (table != null) {
      table.close();
    }
  }
}
