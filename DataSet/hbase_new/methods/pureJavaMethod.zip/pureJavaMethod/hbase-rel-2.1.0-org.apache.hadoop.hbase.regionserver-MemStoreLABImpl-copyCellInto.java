private Cell copyCellInto(Cell cell,int maxAlloc){
  int size=cell instanceof ExtendedCell ? ((ExtendedCell)cell).getSerializedSize() : KeyValueUtil.length(cell);
  Preconditions.checkArgument(size >= 0,"negative size");
  if (size > maxAlloc) {
    return null;
  }
  Chunk c=null;
  int allocOffset=0;
  while (true) {
    c=getOrMakeChunk();
    if (c != null) {
      allocOffset=c.alloc(size);
      if (allocOffset != -1) {
        break;
      }
      tryRetireChunk(c);
    }
  }
  return copyToChunkCell(cell,c.getData(),allocOffset,size);
}
