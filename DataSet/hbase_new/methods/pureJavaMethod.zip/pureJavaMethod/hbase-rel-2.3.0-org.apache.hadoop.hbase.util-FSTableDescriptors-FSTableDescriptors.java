public FSTableDescriptors(final FileSystem fs,final Path rootdir,final boolean fsreadonly,final boolean usecache){
  this.fs=fs;
  this.rootdir=rootdir;
  this.fsreadonly=fsreadonly;
  this.usecache=usecache;
}
