public void reduce(BytesWritable key,Iterable<BytesWritable> values,Context context) throws IOException, InterruptedException {
  int defCount=0;
  refs.clear();
  for (  BytesWritable type : values) {
    if (type.getLength() == DEF.getLength()) {
      defCount++;
    }
 else {
      byte[] bytes=new byte[type.getLength()];
      System.arraycopy(type.getBytes(),0,bytes,0,type.getLength());
      refs.add(bytes);
    }
  }
  StringBuilder refsSb=null;
  String keyString=null;
  if (defCount == 0 || refs.size() != 1) {
    refsSb=new StringBuilder();
    String comma="";
    for (    byte[] ref : refs) {
      refsSb.append(comma);
      comma=",";
      refsSb.append(Bytes.toStringBinary(ref));
    }
    byte[] bytes=new byte[key.getLength()];
    keyString=Bytes.toStringBinary(key.getBytes(),0,key.getLength());
  }
  if (defCount == 0 && refs.size() > 0) {
    context.write(new Text(keyString),new Text(refsSb.toString()));
    context.getCounter(Counts.UNDEFINED).increment(1);
  }
 else   if (defCount > 0 && refs.size() == 0) {
    context.write(new Text(keyString),new Text("none"));
    context.getCounter(Counts.UNREFERENCED).increment(1);
  }
 else {
    if (refs.size() > 1) {
      context.write(new Text(keyString),new Text(refsSb.toString()));
      context.getCounter(Counts.EXTRAREFERENCES).increment(refs.size() - 1);
    }
    context.getCounter(Counts.REFERENCED).increment(1);
  }
}
