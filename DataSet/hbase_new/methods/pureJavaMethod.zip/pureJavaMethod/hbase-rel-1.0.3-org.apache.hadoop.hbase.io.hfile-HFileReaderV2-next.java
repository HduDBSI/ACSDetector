@Override public boolean next() throws IOException {
  boolean isValid=seeker.next();
  if (!isValid) {
    block=readNextDataBlock();
    isValid=block != null;
    if (isValid) {
      updateCurrentBlock(block);
    }
  }
  return isValid;
}
