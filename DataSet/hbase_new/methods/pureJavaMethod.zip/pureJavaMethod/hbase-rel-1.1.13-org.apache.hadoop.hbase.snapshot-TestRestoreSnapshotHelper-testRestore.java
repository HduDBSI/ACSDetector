/** 
 * Execute the restore operation
 * @param snapshotDir The snapshot directory to use as "restore source"
 * @param sd The snapshot descriptor
 * @param htdClone The HTableDescriptor of the table to restore/clone.
 */
public void testRestore(final Path snapshotDir,final SnapshotDescription sd,final HTableDescriptor htdClone) throws IOException {
  LOG.debug("pre-restore table=" + htdClone.getTableName() + " snapshot="+ snapshotDir);
  FSUtils.logFileSystemState(fs,rootDir,LOG);
  new FSTableDescriptors(conf).createTableDescriptor(htdClone);
  RestoreSnapshotHelper helper=getRestoreHelper(rootDir,snapshotDir,sd,htdClone);
  helper.restoreHdfsRegions();
  LOG.debug("post-restore table=" + htdClone.getTableName() + " snapshot="+ snapshotDir);
  FSUtils.logFileSystemState(fs,rootDir,LOG);
}
