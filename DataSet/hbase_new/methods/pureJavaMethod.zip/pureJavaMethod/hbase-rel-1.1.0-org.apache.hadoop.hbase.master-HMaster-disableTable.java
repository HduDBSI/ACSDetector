@Override public long disableTable(final TableName tableName) throws IOException {
  checkInitialized();
  if (cpHost != null) {
    cpHost.preDisableTable(tableName);
  }
  LOG.info(getClientIdAuditPrefix() + " disable " + tableName);
  long procId=-1;
  if (isMasterProcedureExecutorEnabled()) {
    final ProcedurePrepareLatch prepareLatch=ProcedurePrepareLatch.createLatch();
    procId=this.procedureExecutor.submitProcedure(new DisableTableProcedure(procedureExecutor.getEnvironment(),tableName,false,prepareLatch));
    prepareLatch.await();
  }
 else {
    this.service.submit(new DisableTableHandler(this,tableName,assignmentManager,tableLockManager,false).prepare());
  }
  if (cpHost != null) {
    cpHost.postDisableTable(tableName);
  }
  return procId;
}
