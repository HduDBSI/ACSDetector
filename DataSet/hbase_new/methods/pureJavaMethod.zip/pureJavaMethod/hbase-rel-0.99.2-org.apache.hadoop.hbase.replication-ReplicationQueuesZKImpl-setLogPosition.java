@Override public void setLogPosition(String queueId,String filename,long position){
  try {
    String znode=ZKUtil.joinZNode(this.myQueuesZnode,queueId);
    znode=ZKUtil.joinZNode(znode,filename);
    ZKUtil.setData(this.zookeeper,znode,ZKUtil.positionToByteArray(position));
  }
 catch (  KeeperException e) {
    this.abortable.abort("Failed to write replication wal position (filename=" + filename + ", position="+ position+ ")",e);
  }
}
