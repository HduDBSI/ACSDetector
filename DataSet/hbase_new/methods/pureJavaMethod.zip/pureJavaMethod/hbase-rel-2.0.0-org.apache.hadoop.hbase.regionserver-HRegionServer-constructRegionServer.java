/** 
 * Utility for constructing an instance of the passed HRegionServer class.
 * @param regionServerClass
 * @param conf2
 * @return HRegionServer instance.
 */
public static HRegionServer constructRegionServer(Class<? extends HRegionServer> regionServerClass,final Configuration conf2){
  try {
    Constructor<? extends HRegionServer> c=regionServerClass.getConstructor(Configuration.class);
    return c.newInstance(conf2);
  }
 catch (  Exception e) {
    throw new RuntimeException("Failed construction of " + "Regionserver: " + regionServerClass.toString(),e);
  }
}
