protected void consumerLoop(final BlockingQueue<CallRunner> myQueue){
  boolean interrupted=false;
  double handlerFailureThreshhold=conf == null ? 1.0 : conf.getFloat(HConstants.REGION_SERVER_HANDLER_ABORT_ON_ERROR_PERCENT,HConstants.DEFAULT_REGION_SERVER_HANDLER_ABORT_ON_ERROR_PERCENT);
  try {
    while (running) {
      try {
        MonitoredRPCHandler status=RpcServer.getStatus();
        CallRunner task=myQueue.take();
        task.setStatus(status);
        try {
          activeHandlerCount.incrementAndGet();
          task.run();
        }
 catch (        Error e) {
          int failedCount=failedHandlerCount.incrementAndGet();
          if (handlerFailureThreshhold >= 0 && failedCount > handlerCount * handlerFailureThreshhold) {
            String message="Number of failed RpcServer handler exceeded threshhold " + handlerFailureThreshhold + "  with failed reason: "+ StringUtils.stringifyException(e);
            if (abortable != null) {
              abortable.abort(message,e);
            }
 else {
              LOG.error("Received " + StringUtils.stringifyException(e) + " but not aborting due to abortable being null");
              throw e;
            }
          }
 else {
            LOG.warn("RpcServer handler threads encountered errors " + StringUtils.stringifyException(e));
          }
        }
 finally {
          activeHandlerCount.decrementAndGet();
        }
      }
 catch (      InterruptedException e) {
        interrupted=true;
      }
    }
  }
  finally {
    if (interrupted) {
      Thread.currentThread().interrupt();
    }
  }
}
