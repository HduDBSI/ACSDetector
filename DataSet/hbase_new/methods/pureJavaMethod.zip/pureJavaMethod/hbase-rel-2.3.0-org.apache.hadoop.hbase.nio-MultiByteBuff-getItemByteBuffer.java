private static ByteBuffer getItemByteBuffer(ByteBuff buf,int index){
  return (buf instanceof SingleByteBuff) ? buf.nioByteBuffers()[0] : ((MultiByteBuff)buf).items[index];
}
