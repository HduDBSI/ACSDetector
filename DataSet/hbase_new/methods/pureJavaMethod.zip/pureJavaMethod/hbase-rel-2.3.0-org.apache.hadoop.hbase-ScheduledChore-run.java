/** 
 * @see java.lang.Runnable#run()
 */
@Override public void run(){
  updateTimeTrackingBeforeRun();
  if (missedStartTime() && isScheduled()) {
    onChoreMissedStartTime();
    LOG.info("Chore: {} missed its start time",getName());
  }
 else   if (stopper.isStopped() || !isScheduled()) {
    cancel(false);
    cleanup();
    LOG.info("Chore: {} was stopped",getName());
  }
 else {
    try {
      long start=0;
      if (LOG.isDebugEnabled()) {
        start=System.nanoTime();
      }
      if (!initialChoreComplete) {
        initialChoreComplete=initialChore();
      }
 else {
        chore();
      }
      if (LOG.isDebugEnabled() && start > 0) {
        long end=System.nanoTime();
        LOG.debug("{} execution time: {} ms.",getName(),TimeUnit.NANOSECONDS.toMillis(end - start));
      }
    }
 catch (    Throwable t) {
      LOG.error("Caught error",t);
      if (this.stopper.isStopped()) {
        cancel(false);
        cleanup();
      }
    }
  }
}
