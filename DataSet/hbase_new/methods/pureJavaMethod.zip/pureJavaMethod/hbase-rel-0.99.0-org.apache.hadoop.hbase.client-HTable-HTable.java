/** 
 * For internal testing.
 */
protected HTable(){
  tableName=null;
  cleanupPoolOnClose=false;
  cleanupConnectionOnClose=false;
}
