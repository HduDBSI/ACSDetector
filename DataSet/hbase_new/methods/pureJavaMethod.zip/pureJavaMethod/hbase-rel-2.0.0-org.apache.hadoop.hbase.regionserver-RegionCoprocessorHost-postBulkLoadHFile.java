/** 
 * @param familyPaths pairs of { CF, file path } submitted for bulk load
 * @param map Map of CF to List of file paths for the final loaded files
 * @throws IOException
 */
public void postBulkLoadHFile(final List<Pair<byte[],String>> familyPaths,Map<byte[],List<Path>> map) throws IOException {
  if (this.coprocEnvironments.isEmpty()) {
    return;
  }
  execOperation(coprocEnvironments.isEmpty() ? null : new RegionObserverOperationWithoutResult(){
    @Override public void call(    RegionObserver observer) throws IOException {
      observer.postBulkLoadHFile(this,familyPaths,map);
    }
  }
);
}
