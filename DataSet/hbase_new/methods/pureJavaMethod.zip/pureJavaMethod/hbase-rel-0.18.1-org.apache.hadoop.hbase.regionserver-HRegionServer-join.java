private void join(final Thread t){
  while (t.isAlive()) {
    try {
      t.join();
    }
 catch (    InterruptedException e) {
    }
  }
}
