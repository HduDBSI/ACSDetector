private void writeResult(ImmutableBytesWritable key,Result result,Context context) throws IOException, InterruptedException {
  Put put=null;
  Delete delete=null;
  if (LOG.isTraceEnabled()) {
    LOG.trace("Considering the row." + Bytes.toString(key.get(),key.getOffset(),key.getLength()));
  }
  if (filter == null || !filter.filterRowKey(key.get(),key.getOffset(),key.getLength())) {
    for (    Cell kv : result.rawCells()) {
      kv=filterKv(filter,kv);
      if (kv == null)       continue;
      kv=convertKv(kv,cfRenameMap);
      if (CellUtil.isDelete(kv)) {
        if (delete == null) {
          delete=new Delete(key.get());
        }
        delete.addDeleteMarker(kv);
      }
 else {
        if (put == null) {
          put=new Put(key.get());
        }
        put.add(kv);
      }
    }
    if (put != null) {
      if (durability != null) {
        put.setDurability(durability);
      }
      put.setClusterIds(clusterIds);
      context.write(key,put);
    }
    if (delete != null) {
      if (durability != null) {
        delete.setDurability(durability);
      }
      delete.setClusterIds(clusterIds);
      context.write(key,delete);
    }
  }
}
