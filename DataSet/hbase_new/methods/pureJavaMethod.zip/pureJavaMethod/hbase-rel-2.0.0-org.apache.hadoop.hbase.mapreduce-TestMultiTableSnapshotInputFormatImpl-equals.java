@Override public boolean equals(Object obj){
  if (!(obj instanceof ScanWithEquals)) {
    return false;
  }
  ScanWithEquals otherScan=(ScanWithEquals)obj;
  return Objects.equals(this.startRow,otherScan.startRow) && Objects.equals(this.stopRow,otherScan.stopRow);
}
