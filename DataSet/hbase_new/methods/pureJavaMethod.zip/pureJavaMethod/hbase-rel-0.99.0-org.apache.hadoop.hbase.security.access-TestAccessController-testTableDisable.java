@Test public void testTableDisable() throws Exception {
  AccessTestAction disableTable=new AccessTestAction(){
    @Override public Object run() throws Exception {
      ACCESS_CONTROLLER.preDisableTable(ObserverContext.createAndPrepare(CP_ENV,null),TEST_TABLE.getTableName());
      return null;
    }
  }
;
  AccessTestAction disableAclTable=new AccessTestAction(){
    @Override public Object run() throws Exception {
      ACCESS_CONTROLLER.preDisableTable(ObserverContext.createAndPrepare(CP_ENV,null),AccessControlLists.ACL_TABLE_NAME);
      return null;
    }
  }
;
  verifyAllowed(disableTable,SUPERUSER,USER_ADMIN,USER_CREATE,USER_OWNER);
  verifyDenied(disableTable,USER_RW,USER_RO,USER_NONE);
  verifyDenied(disableAclTable,SUPERUSER,USER_ADMIN,USER_CREATE,USER_OWNER,USER_RW,USER_RO);
}
