public void postSetTableQuota(final TableName table,final Quotas quotas) throws IOException {
  execOperation(coprocessors.isEmpty() ? null : new CoprocessorOperation(){
    @Override public void call(    MasterObserver oserver,    ObserverContext<MasterCoprocessorEnvironment> ctx) throws IOException {
      oserver.postSetTableQuota(ctx,table,quotas);
    }
  }
);
}
