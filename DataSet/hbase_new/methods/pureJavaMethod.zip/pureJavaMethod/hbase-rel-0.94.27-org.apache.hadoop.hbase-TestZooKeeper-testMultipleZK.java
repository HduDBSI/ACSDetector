@Test public void testMultipleZK(){
  try {
    HTable localMeta=new HTable(new Configuration(TEST_UTIL.getConfiguration()),HConstants.META_TABLE_NAME);
    Configuration otherConf=new Configuration(TEST_UTIL.getConfiguration());
    otherConf.set(HConstants.ZOOKEEPER_QUORUM,"127.0.0.1");
    HTable ipMeta=new HTable(otherConf,HConstants.META_TABLE_NAME);
    localMeta.exists(new Get(HConstants.LAST_ROW));
    ipMeta.exists(new Get(HConstants.LAST_ROW));
    assertFalse(HConnectionManager.getConnection(localMeta.getConfiguration()).getZooKeeperWatcher() == HConnectionManager.getConnection(otherConf).getZooKeeperWatcher());
    assertFalse(HConnectionManager.getConnection(localMeta.getConfiguration()).getZooKeeperWatcher().getQuorum().equals(HConnectionManager.getConnection(otherConf).getZooKeeperWatcher().getQuorum()));
    localMeta.close();
    ipMeta.close();
  }
 catch (  Exception e) {
    e.printStackTrace();
    fail();
  }
}
