FilteredScanTest(Connection con,TestOptions options,Status status){
  super(con,options,status);
}
