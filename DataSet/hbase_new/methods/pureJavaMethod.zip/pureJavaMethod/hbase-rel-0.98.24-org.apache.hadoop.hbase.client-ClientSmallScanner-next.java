@Override public Result next() throws IOException {
  if (cache.size() == 0 && this.closed) {
    return null;
  }
  if (cache.size() == 0) {
    loadCache();
  }
  if (cache.size() > 0) {
    return cache.poll();
  }
  writeScanMetrics();
  return null;
}
