@BeforeClass public static void beforeClass() throws Exception {
  ChunkCreator.initialize(MemStoreLAB.CHUNK_SIZE_DEFAULT,false,0,0,0,null,MemStoreLAB.INDEX_CHUNK_SIZE_PERCENTAGE_DEFAULT);
}
