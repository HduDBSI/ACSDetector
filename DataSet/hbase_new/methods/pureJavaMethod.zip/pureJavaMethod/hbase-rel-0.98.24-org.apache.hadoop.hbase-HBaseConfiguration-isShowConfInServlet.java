/** 
 * @return whether to show HBase Configuration in servlet
 */
public static boolean isShowConfInServlet(){
  boolean isShowConf=false;
  try {
    if (Class.forName("org.apache.hadoop.conf.ConfServlet") != null) {
      isShowConf=true;
    }
  }
 catch (  LinkageError e) {
    LOG.warn("Error thrown: ",e);
  }
catch (  ClassNotFoundException ce) {
    LOG.debug("ClassNotFound: ConfServlet");
  }
  return isShowConf;
}
