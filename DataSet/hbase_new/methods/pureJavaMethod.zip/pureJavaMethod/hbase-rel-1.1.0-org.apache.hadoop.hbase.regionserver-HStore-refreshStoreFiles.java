@Override public void refreshStoreFiles(Collection<String> newFiles) throws IOException {
  List<StoreFileInfo> storeFiles=new ArrayList<StoreFileInfo>(newFiles.size());
  for (  String file : newFiles) {
    storeFiles.add(fs.getStoreFileInfo(getColumnFamilyName(),file));
  }
  refreshStoreFilesInternal(storeFiles);
}
