public void preDeleteNamespace(final String namespaceName) throws IOException {
  execOperation(coprocEnvironments.isEmpty() ? null : new MasterObserverOperation(){
    @Override public void call(    MasterObserver observer) throws IOException {
      observer.preDeleteNamespace(this,namespaceName);
    }
  }
);
}
