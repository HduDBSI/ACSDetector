protected void killDataNode(ServerName server) throws IOException {
  LOG.info("Killing datanode " + server);
  cluster.killDataNode(server);
  cluster.waitForDataNodeToStop(server,killDataNodeTimeout);
  LOG.info("Killed datanode " + server + ". Reported num of rs:"+ cluster.getClusterMetrics().getLiveServerMetrics().size());
}
