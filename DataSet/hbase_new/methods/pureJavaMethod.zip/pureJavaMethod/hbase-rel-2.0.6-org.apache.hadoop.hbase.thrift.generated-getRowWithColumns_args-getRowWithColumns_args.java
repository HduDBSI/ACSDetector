/** 
 * Performs a deep copy on <i>other</i>.
 */
public getRowWithColumns_args(getRowWithColumns_args other){
  if (other.isSetTableName()) {
    this.tableName=org.apache.thrift.TBaseHelper.copyBinary(other.tableName);
  }
  if (other.isSetRow()) {
    this.row=org.apache.thrift.TBaseHelper.copyBinary(other.row);
  }
  if (other.isSetColumns()) {
    java.util.List<java.nio.ByteBuffer> __this__columns=new java.util.ArrayList<java.nio.ByteBuffer>(other.columns.size());
    for (    java.nio.ByteBuffer other_element : other.columns) {
      __this__columns.add(org.apache.thrift.TBaseHelper.copyBinary(other_element));
    }
    this.columns=__this__columns;
  }
  if (other.isSetAttributes()) {
    java.util.Map<java.nio.ByteBuffer,java.nio.ByteBuffer> __this__attributes=new java.util.HashMap<java.nio.ByteBuffer,java.nio.ByteBuffer>(other.attributes.size());
    for (    java.util.Map.Entry<java.nio.ByteBuffer,java.nio.ByteBuffer> other_element : other.attributes.entrySet()) {
      java.nio.ByteBuffer other_element_key=other_element.getKey();
      java.nio.ByteBuffer other_element_value=other_element.getValue();
      java.nio.ByteBuffer __this__attributes_copy_key=org.apache.thrift.TBaseHelper.copyBinary(other_element_key);
      java.nio.ByteBuffer __this__attributes_copy_value=org.apache.thrift.TBaseHelper.copyBinary(other_element_value);
      __this__attributes.put(__this__attributes_copy_key,__this__attributes_copy_value);
    }
    this.attributes=__this__attributes;
  }
}
