@Override public void modifyColumn(final TableName tableName,final HColumnDescriptor descriptor,final long nonceGroup,final long nonce) throws IOException {
  checkInitialized();
  checkCompression(descriptor);
  checkEncryption(conf,descriptor);
  if (cpHost != null) {
    if (cpHost.preModifyColumn(tableName,descriptor)) {
      return;
    }
  }
  LOG.info(getClientIdAuditPrefix() + " modify " + descriptor);
  long procId=this.procedureExecutor.submitProcedure(new ModifyColumnFamilyProcedure(procedureExecutor.getEnvironment(),tableName,descriptor),nonceGroup,nonce);
  ProcedureSyncWait.waitForProcedureToComplete(procedureExecutor,procId);
  if (cpHost != null) {
    cpHost.postModifyColumn(tableName,descriptor);
  }
}
