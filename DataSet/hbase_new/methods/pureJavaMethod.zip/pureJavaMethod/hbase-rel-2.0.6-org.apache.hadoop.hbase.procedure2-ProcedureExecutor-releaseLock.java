private void releaseLock(Procedure<TEnvironment> proc,boolean force){
  TEnvironment env=getEnvironment();
  if (force || !proc.holdLock(env) || proc.isFinished()) {
    proc.doReleaseLock(env,store);
  }
}
