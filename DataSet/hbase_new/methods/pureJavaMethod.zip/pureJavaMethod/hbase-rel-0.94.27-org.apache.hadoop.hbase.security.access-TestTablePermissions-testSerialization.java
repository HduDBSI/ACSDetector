@Test public void testSerialization() throws Exception {
  Configuration conf=UTIL.getConfiguration();
  ListMultimap<String,TablePermission> permissions=ArrayListMultimap.create();
  permissions.put("george",new TablePermission(TEST_TABLE,null,TablePermission.Action.READ));
  permissions.put("george",new TablePermission(TEST_TABLE,TEST_FAMILY,TablePermission.Action.WRITE));
  permissions.put("george",new TablePermission(TEST_TABLE2,null,TablePermission.Action.READ));
  permissions.put("hubert",new TablePermission(TEST_TABLE2,null,TablePermission.Action.READ,TablePermission.Action.WRITE));
  ByteArrayOutputStream bos=new ByteArrayOutputStream();
  AccessControlLists.writePermissions(new DataOutputStream(bos),permissions,conf);
  ByteArrayInputStream bis=new ByteArrayInputStream(bos.toByteArray());
  ListMultimap<String,TablePermission> copy=AccessControlLists.readPermissions(new DataInputStream(bis),conf);
  checkMultimapEqual(permissions,copy);
}
