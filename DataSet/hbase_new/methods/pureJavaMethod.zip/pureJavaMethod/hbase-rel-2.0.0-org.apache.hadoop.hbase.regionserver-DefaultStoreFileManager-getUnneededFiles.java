@Override public Collection<HStoreFile> getUnneededFiles(long maxTs,List<HStoreFile> filesCompacting){
  ImmutableList<HStoreFile> files=storefiles;
  return files.stream().limit(Math.max(0,files.size() - 1)).filter(sf -> {
    long fileTs=sf.getReader().getMaxTimestamp();
    if (fileTs < maxTs && !filesCompacting.contains(sf)) {
      LOG.info("Found an expired store file {} whose maxTimestamp is {}, which is below {}",sf.getPath(),fileTs,maxTs);
      return true;
    }
 else {
      return false;
    }
  }
).collect(Collectors.toList());
}
