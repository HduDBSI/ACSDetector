@Test public void testCleanParent() throws IOException, InterruptedException {
  HBaseTestingUtility htu=new HBaseTestingUtility();
  setRootDirAndCleanIt(htu,"testCleanParent");
  Server server=new MockServer(htu);
  try {
    MasterServices services=new MockMasterServices(server);
    CatalogJanitor janitor=new CatalogJanitor(server,services);
    HTableDescriptor htd=new HTableDescriptor("table");
    htd.addFamily(new HColumnDescriptor("f"));
    HRegionInfo parent=new HRegionInfo(htd.getName(),Bytes.toBytes("aaa"),Bytes.toBytes("eee"));
    HRegionInfo splita=new HRegionInfo(htd.getName(),Bytes.toBytes("aaa"),Bytes.toBytes("ccc"));
    HRegionInfo splitb=new HRegionInfo(htd.getName(),Bytes.toBytes("ccc"),Bytes.toBytes("eee"));
    Result r=createResult(parent,splita,splitb);
    Path rootdir=services.getMasterFileSystem().getRootDir();
    Path tabledir=HTableDescriptor.getTableDir(rootdir,htd.getName());
    Path storedir=HStore.getStoreHomedir(tabledir,splita,htd.getColumnFamilies()[0].getName());
    Reference ref=Reference.createTopReference(Bytes.toBytes("ccc"));
    long now=System.currentTimeMillis();
    Path p=new Path(storedir,Long.toString(now) + "." + parent.getEncodedName());
    FileSystem fs=services.getMasterFileSystem().getFileSystem();
    Path path=ref.write(fs,p);
    assertTrue(fs.exists(path));
    assertFalse(janitor.cleanParent(parent,r));
    assertTrue(fs.delete(p,true));
    assertTrue(janitor.cleanParent(parent,r));
  }
  finally {
    server.stop("shutdown");
  }
}
