/** 
 * Load all wals in all replication queues from ZK
 */
private Set<String> loadWALsFromQueues(){
  List<String> rss=replicationQueues.getListOfReplicators();
  if (rss == null) {
    LOG.debug("Didn't find any region server that replicates, won't prevent any deletions.");
    return ImmutableSet.of();
  }
  Set<String> wals=Sets.newHashSet();
  for (  String rs : rss) {
    List<String> listOfPeers=replicationQueues.getAllQueues(rs);
    if (listOfPeers == null) {
      continue;
    }
    for (    String id : listOfPeers) {
      List<String> peersWals=replicationQueues.getLogsInQueue(rs,id);
      if (peersWals != null) {
        wals.addAll(peersWals);
      }
    }
  }
  return wals;
}
