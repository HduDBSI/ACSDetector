private static TableDescriptor readTableDescriptor(FileSystem fs,FileStatus status) throws IOException {
  int len=Ints.checkedCast(status.getLen());
  byte[] content=new byte[len];
  FSDataInputStream fsDataInputStream=fs.open(status.getPath());
  try {
    fsDataInputStream.readFully(content);
  }
  finally {
    fsDataInputStream.close();
  }
  TableDescriptor htd=null;
  try {
    htd=TableDescriptorBuilder.parseFrom(content);
  }
 catch (  DeserializationException e) {
    throw new IOException("content=" + Bytes.toShort(content),e);
  }
  return htd;
}
