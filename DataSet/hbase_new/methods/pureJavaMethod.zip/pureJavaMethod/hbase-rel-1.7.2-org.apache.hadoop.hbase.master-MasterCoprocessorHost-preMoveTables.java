public void preMoveTables(final Set<TableName> tables,final String targetGroup) throws IOException {
  execOperation(coprocessors.isEmpty() ? null : new CoprocessorOperation(){
    @Override public void call(    MasterObserver oserver,    ObserverContext<MasterCoprocessorEnvironment> ctx) throws IOException {
      if (((MasterEnvironment)ctx.getEnvironment()).supportGroupCPs) {
        oserver.preMoveTables(ctx,tables,targetGroup);
      }
    }
  }
);
}
