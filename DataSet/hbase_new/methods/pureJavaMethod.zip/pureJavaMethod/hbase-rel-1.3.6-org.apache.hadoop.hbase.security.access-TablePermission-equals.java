@Override @edu.umd.cs.findbugs.annotations.SuppressWarnings(value="NP_NULL_ON_SOME_PATH",justification="Passed on construction except on constructor not to be used") public boolean equals(Object obj){
  if (!(obj instanceof TablePermission)) {
    return false;
  }
  TablePermission other=(TablePermission)obj;
  if (!(table.equals(other.getTableName()) && ((family == null && other.getFamily() == null) || Bytes.equals(family,other.getFamily())) && ((qualifier == null && other.getQualifier() == null) || Bytes.equals(qualifier,other.getQualifier()))&& ((namespace == null && other.getNamespace() == null) || (namespace != null && namespace.equals(other.getNamespace()))))) {
    return false;
  }
  return super.equals(other);
}
