/** 
 * Gets all the regions and their address for this table.
 * @return A map of HRegionInfo with it's server address
 * @throws IOException if a remote or network exception occurs
 * @deprecated Use {@link #getRegionLocations()} or {@link #getStartEndKeys()}
 */
public Map<HRegionInfo,HServerAddress> getRegionsInfo() throws IOException {
  final Map<HRegionInfo,HServerAddress> regionMap=new TreeMap<HRegionInfo,HServerAddress>();
  final Map<HRegionInfo,ServerName> regionLocations=getRegionLocations();
  for (  Map.Entry<HRegionInfo,ServerName> entry : regionLocations.entrySet()) {
    HServerAddress server=new HServerAddress();
    ServerName serverName=entry.getValue();
    if (serverName != null && serverName.getHostAndPort() != null) {
      server=new HServerAddress(Addressing.createInetSocketAddressFromHostAndPortStr(serverName.getHostAndPort()));
    }
    regionMap.put(entry.getKey(),server);
  }
  return regionMap;
}
