/** 
 * Checks if it is possible to execute the specified operation.
 * @param writeReqs the write requests that will be checked against the available quota
 * @param estimateWriteSize the write size that will be checked against the available quota
 * @param readReqs the read requests that will be checked against the available quota
 * @param estimateReadSize the read size that will be checked against the available quota
 * @param estimateWriteCapacityUnit the write capacity unit that will be checked against theavailable quota
 * @param estimateReadCapacityUnit the read capacity unit that will be checked against theavailable quota
 * @throws RpcThrottlingException thrown if not enough available resources to perform operation.
 */
void checkQuota(long writeReqs,long estimateWriteSize,long readReqs,long estimateReadSize,long estimateWriteCapacityUnit,long estimateReadCapacityUnit) throws RpcThrottlingException ;
