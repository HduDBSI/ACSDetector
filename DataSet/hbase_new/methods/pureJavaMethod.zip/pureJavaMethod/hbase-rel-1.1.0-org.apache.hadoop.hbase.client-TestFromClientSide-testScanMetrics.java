/** 
 * Test ScanMetrics
 * @throws Exception
 */
@Test @SuppressWarnings("unused") public void testScanMetrics() throws Exception {
  TableName TABLENAME=TableName.valueOf("testScanMetrics");
  Configuration conf=TEST_UTIL.getConfiguration();
  HTable ht=TEST_UTIL.createMultiRegionTable(TABLENAME,FAMILY);
  int numOfRegions=-1;
  try (RegionLocator r=ht.getRegionLocator()){
    numOfRegions=r.getStartKeys().length;
  }
   Put put1=new Put(Bytes.toBytes("zzz1"));
  put1.add(FAMILY,QUALIFIER,VALUE);
  Put put2=new Put(Bytes.toBytes("zzz2"));
  put2.add(FAMILY,QUALIFIER,VALUE);
  Put put3=new Put(Bytes.toBytes("zzz3"));
  put3.add(FAMILY,QUALIFIER,VALUE);
  ht.put(Arrays.asList(put1,put2,put3));
  Scan scan1=new Scan();
  int numRecords=0;
  ResultScanner scanner=ht.getScanner(scan1);
  for (  Result result : scanner) {
    numRecords++;
  }
  scanner.close();
  LOG.info("test data has " + numRecords + " records.");
  assertEquals(null,scan1.getScanMetrics());
  Scan scan2=new Scan();
  scan2.setScanMetricsEnabled(true);
  scan2.setCaching(numRecords + 1);
  scanner=ht.getScanner(scan2);
  for (  Result result : scanner.next(numRecords - 1)) {
  }
  scanner.close();
  assertNotNull(scan2.getScanMetrics());
  scan2=new Scan();
  scan2.setScanMetricsEnabled(true);
  scan2.setCaching(1);
  scanner=ht.getScanner(scan2);
  for (  Result result : scanner.next(numRecords - 1)) {
  }
  scanner.close();
  ScanMetrics scanMetrics=scan2.getScanMetrics();
  assertEquals("Did not access all the regions in the table",numOfRegions,scanMetrics.countOfRegions.get());
  Scan scanWithClose=new Scan();
  scanWithClose.setCaching(numRecords);
  scanWithClose.setScanMetricsEnabled(true);
  ResultScanner scannerWithClose=ht.getScanner(scanWithClose);
  for (  Result result : scannerWithClose.next(numRecords + 1)) {
  }
  scannerWithClose.close();
  ScanMetrics scanMetricsWithClose=getScanMetrics(scanWithClose);
  assertEquals("Did not access all the regions in the table",numOfRegions,scanMetricsWithClose.countOfRegions.get());
}
