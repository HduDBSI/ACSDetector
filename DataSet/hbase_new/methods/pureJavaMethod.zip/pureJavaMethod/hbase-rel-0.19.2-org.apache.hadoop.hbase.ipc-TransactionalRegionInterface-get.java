/** 
 * Get the specified number of versions of the specified row and column with the specified timestamp.
 * @param transactionId
 * @param regionName region name
 * @param row row key
 * @param column column key
 * @param timestamp timestamp
 * @param numVersions number of versions to return
 * @return array of values
 * @throws IOException
 */
public Cell[] get(long transactionId,final byte[] regionName,final byte[] row,final byte[] column,final long timestamp,final int numVersions) throws IOException ;
