/** 
 * Return all the data for the row that matches <i>row</i> exactly,  or the one that immediately preceeds it, at or immediately before  <i>ts</i>.
 * @param row row key
 * @param columnFamily Must include the column family delimiter character.
 * @return map of values
 * @throws IOException
 */
public RowResult getClosestRowBefore(final byte[] row,final byte[] columnFamily) throws IOException {
  HStoreKey key=null;
  checkRow(row);
  splitsAndClosesLock.readLock().lock();
  try {
    HStore store=getStore(columnFamily);
    byte[] closestKey=store.getRowKeyAtOrBefore(row);
    if (closestKey != null) {
      if (HStoreKey.equalsTwoRowKeys(regionInfo,row,closestKey)) {
        key=new HStoreKey(closestKey,this.regionInfo);
      }
      if (key == null) {
        key=new HStoreKey(closestKey,this.regionInfo);
      }
    }
    if (key == null) {
      return null;
    }
    HbaseMapWritable<byte[],Cell> cells=new HbaseMapWritable<byte[],Cell>();
    store.getFull(key,null,1,cells);
    return new RowResult(key.getRow(),cells);
  }
  finally {
    splitsAndClosesLock.readLock().unlock();
  }
}
