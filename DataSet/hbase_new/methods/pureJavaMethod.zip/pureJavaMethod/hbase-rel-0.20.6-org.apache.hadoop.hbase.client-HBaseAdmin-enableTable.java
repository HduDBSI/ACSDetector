/** 
 * Brings a table on-line (enables it). Synchronous operation.
 * @param tableName name of the table
 * @throws IOException
 */
public void enableTable(final byte[] tableName) throws IOException {
  if (this.master == null) {
    throw new MasterNotRunningException("master has been shut down");
  }
  boolean enabled=false;
  for (int tries=0; tries < this.numRetries; tries++) {
    try {
      this.master.enableTable(tableName);
    }
 catch (    RemoteException e) {
      throw RemoteExceptionHandler.decodeRemoteException(e);
    }
    enabled=isTableEnabled(tableName);
    if (enabled)     break;
    long sleep=getPauseTime(tries);
    if (LOG.isDebugEnabled()) {
      LOG.debug("Sleeping= " + sleep + "ms, waiting for all regions to be "+ "enabled in "+ Bytes.toString(tableName));
    }
    try {
      Thread.sleep(sleep);
    }
 catch (    InterruptedException e) {
    }
    if (LOG.isDebugEnabled()) {
      LOG.debug("Wake. Waiting for all regions to be enabled from " + Bytes.toString(tableName));
    }
  }
  if (!enabled)   throw new IOException("Unable to enable table " + Bytes.toString(tableName));
  LOG.info("Enabled table " + Bytes.toString(tableName));
}
