private HLog.Entry createEntry(byte[] table,int row,int qualifier,KeyValue.Type type,long ts){
  byte[] qual=Bytes.toBytes(qualifier);
  byte[] fam=Bytes.equals(table,TABLE_NAME1) ? FAM_NAME1 : FAM_NAME2;
  byte[] rowBytes=Bytes.toBytes(row);
  if (ts == -1) {
    try {
      Thread.sleep(1);
    }
 catch (    InterruptedException e) {
      LOG.info("Was interrupted while sleep, meh",e);
    }
    ts=System.currentTimeMillis();
  }
  KeyValue kv=null;
  if (type.getCode() == KeyValue.Type.Put.getCode()) {
    kv=new KeyValue(rowBytes,fam,qual,ts,KeyValue.Type.Put,Bytes.toBytes(row));
  }
 else   if (type.getCode() == KeyValue.Type.DeleteColumn.getCode()) {
    kv=new KeyValue(rowBytes,fam,qual,ts,KeyValue.Type.DeleteColumn);
  }
 else   if (type.getCode() == KeyValue.Type.DeleteFamily.getCode()) {
    kv=new KeyValue(rowBytes,fam,null,ts,KeyValue.Type.DeleteFamily);
  }
  HLogKey key=new HLogKey(table,table,ts,ts,HConstants.DEFAULT_CLUSTER_ID);
  WALEdit edit=new WALEdit();
  edit.add(kv);
  return new HLog.Entry(key,edit);
}
