public void setFieldValue(_Fields field,Object value){
switch (field) {
case TABLE_NAME:
    if (value == null) {
      unsetTableName();
    }
 else {
      setTableName((ByteBuffer)value);
    }
  break;
case SCAN:
if (value == null) {
  unsetScan();
}
 else {
  setScan((TScan)value);
}
break;
case ATTRIBUTES:
if (value == null) {
unsetAttributes();
}
 else {
setAttributes((Map<ByteBuffer,ByteBuffer>)value);
}
break;
}
}
