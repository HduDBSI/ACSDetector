private void processOpeningState(HRegionInfo regionInfo){
  LOG.info("Region has been OPENING for too long, reassigning region=" + regionInfo.getRegionNameAsString());
  try {
    String node=ZKAssign.getNodeName(watcher,regionInfo.getEncodedName());
    Stat stat=new Stat();
    byte[] data=ZKAssign.getDataNoWatch(watcher,node,stat);
    if (data == null) {
      LOG.warn("Data is null, node " + node + " no longer exists");
      return;
    }
    RegionTransition rt=RegionTransition.parseFrom(data);
    EventType et=rt.getEventType();
    if (et == EventType.RS_ZK_REGION_OPENED) {
      LOG.debug("Region has transitioned to OPENED, allowing " + "watched event handlers to process");
      return;
    }
 else     if (et != EventType.RS_ZK_REGION_OPENING && et != EventType.RS_ZK_REGION_FAILED_OPEN) {
      LOG.warn("While timing out a region, found ZK node in unexpected state: " + et);
      return;
    }
    invokeAssign(regionInfo);
  }
 catch (  KeeperException ke) {
    LOG.error("Unexpected ZK exception timing out CLOSING region",ke);
  }
catch (  DeserializationException e) {
    LOG.error("Unexpected exception parsing CLOSING region",e);
  }
}
