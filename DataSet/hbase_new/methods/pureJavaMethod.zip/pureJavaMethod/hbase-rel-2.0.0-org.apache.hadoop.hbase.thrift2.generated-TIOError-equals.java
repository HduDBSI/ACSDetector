public boolean equals(TIOError that){
  if (that == null)   return false;
  boolean this_present_message=true && this.isSetMessage();
  boolean that_present_message=true && that.isSetMessage();
  if (this_present_message || that_present_message) {
    if (!(this_present_message && that_present_message))     return false;
    if (!this.message.equals(that.message))     return false;
  }
  return true;
}
