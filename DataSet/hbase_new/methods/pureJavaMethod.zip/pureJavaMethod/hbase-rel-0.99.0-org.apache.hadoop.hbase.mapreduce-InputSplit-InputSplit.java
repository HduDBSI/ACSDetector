public InputSplit(HTableDescriptor htd,HRegionInfo regionInfo,List<String> locations){
  this.htd=htd;
  this.regionInfo=regionInfo;
  if (locations == null || locations.isEmpty()) {
    this.locations=new String[0];
  }
 else {
    this.locations=locations.toArray(new String[locations.size()]);
  }
}
