public void setFieldValue(_Fields field,Object value){
switch (field) {
case TABLE:
    if (value == null) {
      unsetTable();
    }
 else {
      setTable((ByteBuffer)value);
    }
  break;
case TSCAN:
if (value == null) {
  unsetTscan();
}
 else {
  setTscan((TScan)value);
}
break;
case NUM_ROWS:
if (value == null) {
unsetNumRows();
}
 else {
setNumRows((Integer)value);
}
break;
}
}
