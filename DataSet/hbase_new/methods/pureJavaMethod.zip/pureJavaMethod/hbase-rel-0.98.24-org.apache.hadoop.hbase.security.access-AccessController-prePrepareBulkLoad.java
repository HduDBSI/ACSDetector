/** 
 * Authorization check for SecureBulkLoadProtocol.prepareBulkLoad()
 * @param ctx the context
 * @param request the request
 * @throws IOException
 */
@Override public void prePrepareBulkLoad(ObserverContext<RegionCoprocessorEnvironment> ctx,PrepareBulkLoadRequest request) throws IOException {
  requireAccess("prePareBulkLoad",ctx.getEnvironment().getRegion().getTableDesc().getTableName(),Action.CREATE);
}
