@Override ServerManager createServerManager(MasterServices master) throws IOException {
  ServerManager sm=super.createServerManager(master);
  ServerManager spy=Mockito.spy(sm);
  return spy;
}
