private void split(final HServerAddress hsa,final HRegionInfo hri,byte[] splitPoint) throws IOException {
  HRegionInterface rs=this.connection.getHRegionConnection(hsa);
  rs.splitRegion(hri,splitPoint);
}
