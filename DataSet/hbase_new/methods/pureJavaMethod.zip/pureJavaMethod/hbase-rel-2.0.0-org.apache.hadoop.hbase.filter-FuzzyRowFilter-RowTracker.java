RowTracker(){
  nextRows=new PriorityQueue<>(fuzzyKeysData.size(),new Comparator<Pair<byte[],Pair<byte[],byte[]>>>(){
    @Override public int compare(    Pair<byte[],Pair<byte[],byte[]>> o1,    Pair<byte[],Pair<byte[],byte[]>> o2){
      return isReversed() ? Bytes.compareTo(o2.getFirst(),o1.getFirst()) : Bytes.compareTo(o1.getFirst(),o2.getFirst());
    }
  }
);
}
