public void postTableFlush(final TableName tableName) throws IOException {
  execOperation(coprocEnvironments.isEmpty() ? null : new MasterObserverOperation(){
    @Override public void call(    MasterObserver observer) throws IOException {
      observer.postTableFlush(this,tableName);
    }
  }
);
}
