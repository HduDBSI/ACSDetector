/** 
 * check that checkAndPut fails if the cell does not exist, then put in the cell, then check that the checkAndPut succeeds.
 * @throws Exception
 */
@Test public void testCheckAndPut() throws Exception {
  ThriftHBaseServiceHandler handler=createHandler();
  byte[] rowName="testCheckAndPut".getBytes();
  ByteBuffer table=ByteBuffer.wrap(tableAname);
  List<TColumnValue> columnValuesA=new ArrayList<TColumnValue>();
  TColumnValue columnValueA=new TColumnValue(ByteBuffer.wrap(familyAname),ByteBuffer.wrap(qualifierAname),ByteBuffer.wrap(valueAname));
  columnValuesA.add(columnValueA);
  TPut putA=new TPut(ByteBuffer.wrap(rowName),columnValuesA);
  putA.setColumnValues(columnValuesA);
  List<TColumnValue> columnValuesB=new ArrayList<TColumnValue>();
  TColumnValue columnValueB=new TColumnValue(ByteBuffer.wrap(familyBname),ByteBuffer.wrap(qualifierBname),ByteBuffer.wrap(valueBname));
  columnValuesB.add(columnValueB);
  TPut putB=new TPut(ByteBuffer.wrap(rowName),columnValuesB);
  putB.setColumnValues(columnValuesB);
  assertFalse(handler.checkAndPut(table,ByteBuffer.wrap(rowName),ByteBuffer.wrap(familyAname),ByteBuffer.wrap(qualifierAname),ByteBuffer.wrap(valueAname),putB));
  TGet get=new TGet(ByteBuffer.wrap(rowName));
  TResult result=handler.get(table,get);
  assertEquals(0,result.getColumnValuesSize());
  handler.put(table,putA);
  assertTrue(handler.checkAndPut(table,ByteBuffer.wrap(rowName),ByteBuffer.wrap(familyAname),ByteBuffer.wrap(qualifierAname),ByteBuffer.wrap(valueAname),putB));
  result=handler.get(table,get);
  assertArrayEquals(rowName,result.getRow());
  List<TColumnValue> returnedColumnValues=result.getColumnValues();
  List<TColumnValue> expectedColumnValues=new ArrayList<TColumnValue>();
  expectedColumnValues.add(columnValueA);
  expectedColumnValues.add(columnValueB);
  assertTColumnValuesEqual(expectedColumnValues,returnedColumnValues);
}
