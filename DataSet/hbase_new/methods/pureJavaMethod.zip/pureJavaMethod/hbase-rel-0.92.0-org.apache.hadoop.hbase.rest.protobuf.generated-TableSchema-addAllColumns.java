public Builder addAllColumns(java.lang.Iterable<? extends org.apache.hadoop.hbase.rest.protobuf.generated.ColumnSchemaMessage.ColumnSchema> values){
  if (columnsBuilder_ == null) {
    ensureColumnsIsMutable();
    super.addAll(values,columns_);
    onChanged();
  }
 else {
    columnsBuilder_.addAllMessages(values);
  }
  return this;
}
