private void refreshCache() throws IOException {
  FileStatus[] snapshotDirs=FSUtils.listStatus(fs,snapshotDir,new PathFilter(){
    @Override public boolean accept(    Path path){
      return !path.getName().equals(SnapshotDescriptionUtils.SNAPSHOT_TMP_DIR_NAME);
    }
  }
);
  this.cache.clear();
  if (ArrayUtils.isEmpty(snapshotDirs)) {
    if (LOG.isDebugEnabled() && this.snapshots.size() > 0) {
      LOG.debug("No snapshots on-disk, clear cache");
    }
    this.snapshots.clear();
    return;
  }
  Map<String,SnapshotDirectoryInfo> newSnapshots=new HashMap<>();
  for (  FileStatus snapshotDir : snapshotDirs) {
    String name=snapshotDir.getPath().getName();
    SnapshotDirectoryInfo files=this.snapshots.remove(name);
    if (files == null || files.hasBeenModified(snapshotDir.getModificationTime())) {
      Collection<String> storedFiles=fileInspector.filesUnderSnapshot(snapshotDir.getPath());
      files=new SnapshotDirectoryInfo(snapshotDir.getModificationTime(),storedFiles);
    }
    this.cache.addAll(files.getFiles());
    newSnapshots.put(name,files);
  }
  this.snapshots.clear();
  this.snapshots.putAll(newSnapshots);
}
