@Override void testTakedown() throws IOException {
  if (this.testScanner != null) {
    this.testScanner.close();
  }
  super.testTakedown();
}
