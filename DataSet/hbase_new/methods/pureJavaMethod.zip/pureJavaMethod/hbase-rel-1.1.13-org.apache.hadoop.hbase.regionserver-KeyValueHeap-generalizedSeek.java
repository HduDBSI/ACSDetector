/** 
 * @param isLazy whether we are trying to seek to exactly the given row/col.Enables Bloom filter and most-recent-file-first optimizations for multi-column get/scan queries.
 * @param seekKey key to seek to
 * @param forward whether to seek forward (also known as reseek)
 * @param useBloom whether to optimize seeks using Bloom filters
 */
private boolean generalizedSeek(boolean isLazy,Cell seekKey,boolean forward,boolean useBloom) throws IOException {
  if (!isLazy && useBloom) {
    throw new IllegalArgumentException("Multi-column Bloom filter " + "optimization requires a lazy seek");
  }
  if (current == null) {
    return false;
  }
  heap.add(current);
  current=null;
  KeyValueScanner scanner=null;
  try {
    while ((scanner=heap.poll()) != null) {
      Cell topKey=scanner.peek();
      if (comparator.getComparator().compare(seekKey,topKey) <= 0) {
        heap.add(scanner);
        scanner=null;
        current=pollRealKV();
        return current != null;
      }
      boolean seekResult;
      if (isLazy && heap.size() > 0) {
        seekResult=scanner.requestSeek(seekKey,forward,useBloom);
      }
 else {
        seekResult=NonLazyKeyValueScanner.doRealSeek(scanner,seekKey,forward);
      }
      if (!seekResult) {
        scanner.close();
      }
 else {
        heap.add(scanner);
      }
    }
  }
 catch (  Exception e) {
    if (scanner != null) {
      try {
        scanner.close();
      }
 catch (      Exception ce) {
        LOG.warn("close KeyValueScanner error",ce);
      }
    }
    throw e;
  }
  return false;
}
