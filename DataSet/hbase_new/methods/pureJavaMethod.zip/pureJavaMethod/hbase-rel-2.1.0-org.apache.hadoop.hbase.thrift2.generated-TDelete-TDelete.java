/** 
 * Performs a deep copy on <i>other</i>.
 */
public TDelete(TDelete other){
  __isset_bitfield=other.__isset_bitfield;
  if (other.isSetRow()) {
    this.row=org.apache.thrift.TBaseHelper.copyBinary(other.row);
  }
  if (other.isSetColumns()) {
    List<TColumn> __this__columns=new ArrayList<TColumn>(other.columns.size());
    for (    TColumn other_element : other.columns) {
      __this__columns.add(new TColumn(other_element));
    }
    this.columns=__this__columns;
  }
  this.timestamp=other.timestamp;
  if (other.isSetDeleteType()) {
    this.deleteType=other.deleteType;
  }
  if (other.isSetAttributes()) {
    Map<ByteBuffer,ByteBuffer> __this__attributes=new HashMap<ByteBuffer,ByteBuffer>(other.attributes);
    this.attributes=__this__attributes;
  }
  if (other.isSetDurability()) {
    this.durability=other.durability;
  }
}
