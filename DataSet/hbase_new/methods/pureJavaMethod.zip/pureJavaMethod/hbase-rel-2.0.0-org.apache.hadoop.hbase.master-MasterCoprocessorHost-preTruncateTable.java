public void preTruncateTable(final TableName tableName) throws IOException {
  execOperation(coprocEnvironments.isEmpty() ? null : new MasterObserverOperation(){
    @Override public void call(    MasterObserver observer) throws IOException {
      observer.preTruncateTable(this,tableName);
    }
  }
);
}
