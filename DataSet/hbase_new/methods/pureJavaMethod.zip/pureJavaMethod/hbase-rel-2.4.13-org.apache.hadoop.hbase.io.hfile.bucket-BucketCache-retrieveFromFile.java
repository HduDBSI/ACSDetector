/** 
 * @see #persistToFile()
 */
private void retrieveFromFile(int[] bucketSizes) throws IOException {
  File persistenceFile=new File(persistencePath);
  if (!persistenceFile.exists()) {
    return;
  }
  assert !cacheEnabled;
  try (FileInputStream in=deleteFileOnClose(persistenceFile)){
    int pblen=ProtobufMagic.lengthOfPBMagic();
    byte[] pbuf=new byte[pblen];
    IOUtils.readFully(in,pbuf,0,pblen);
    if (!ProtobufMagic.isPBMagicPrefix(pbuf)) {
      throw new IOException("Persistence file does not start with protobuf magic number. " + persistencePath);
    }
    parsePB(BucketCacheProtos.BucketCacheEntry.parseDelimitedFrom(in));
    bucketAllocator=new BucketAllocator(cacheCapacity,bucketSizes,backingMap,realCacheSize);
    blockNumber.add(backingMap.size());
  }
 }
