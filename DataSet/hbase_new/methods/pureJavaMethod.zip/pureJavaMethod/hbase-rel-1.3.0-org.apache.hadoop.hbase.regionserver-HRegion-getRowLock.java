private RowLockImpl getRowLock(Lock l){
  count.incrementAndGet();
synchronized (lock) {
    if (usable.get()) {
      return new RowLockImpl(this,l);
    }
 else {
      return null;
    }
  }
}
