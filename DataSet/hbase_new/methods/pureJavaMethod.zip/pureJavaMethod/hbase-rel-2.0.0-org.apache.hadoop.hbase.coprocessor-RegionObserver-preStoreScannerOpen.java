/** 
 * Called before a store opens a new scanner. <p> This hook is called when a "user" scanner is opened. Use  {@code preFlushScannerOpen} and{@code preCompactScannerOpen} to inject flush/compaction.<p> Notice that, this method is used to change the inherent max versions and TTL for a Store. For example, you can change the max versions option for a  {@link Scan} object to 10 in{@code preScannerOpen}, but if the max versions config on the Store is 1, then you still can only read 1 version. You need also to inject here to change the max versions to 10 if you want to get more versions.
 * @param ctx the environment provided by the region server
 * @param store the store which we want to get scanner from
 * @param options used to change max versions and TTL for the scanner being opened
 * @see #preFlushScannerOpen(ObserverContext,Store,ScanOptions,FlushLifeCycleTracker)
 * @see #preCompactScannerOpen(ObserverContext,Store,ScanType,ScanOptions,CompactionLifeCycleTracker,CompactionRequest)
 */
default void preStoreScannerOpen(ObserverContext<RegionCoprocessorEnvironment> ctx,Store store,ScanOptions options) throws IOException {
}
