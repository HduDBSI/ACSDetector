private static TransparentCryptoHelper createTransparentCryptoHelper() throws NoSuchMethodException, ClassNotFoundException {
  try {
    return createTransparentCryptoHelper27();
  }
 catch (  NoSuchMethodException e) {
    LOG.debug("No decryptEncryptedDataEncryptionKey method in DFSClient, should be hadoop 2.8+",e);
  }
  return createTransparentCryptoHelper28();
}
