/** 
 * Main program
 * @param args
 * @throws Exception
 */
public static void main(String[] args) throws Exception {
  Configuration conf=HBaseConfiguration.create();
  Path hbasedir=new Path(conf.get(HConstants.HBASE_DIR));
  URI defaultFs=hbasedir.getFileSystem(conf).getUri();
  conf.set("fs.defaultFS",defaultFs.toString());
  conf.set("fs.default.name",defaultFs.toString());
  int ret=ToolRunner.run(new HBaseFsck(conf),args);
  System.exit(ret);
}
