public void mutateRowTs(byte[] tableName,byte[] row,List<Mutation> mutations,long timestamp) throws IOError, IllegalArgument {
  HTable table=null;
  try {
    table=getTable(tableName);
    BatchUpdate batchUpdate=new BatchUpdate(row,timestamp);
    for (    Mutation m : mutations) {
      if (m.isDelete) {
        batchUpdate.delete(m.column);
      }
 else {
        batchUpdate.put(m.column,m.value);
      }
    }
    table.commit(batchUpdate);
  }
 catch (  IOException e) {
    throw new IOError(e.getMessage());
  }
catch (  IllegalArgumentException e) {
    throw new IllegalArgument(e.getMessage());
  }
}
