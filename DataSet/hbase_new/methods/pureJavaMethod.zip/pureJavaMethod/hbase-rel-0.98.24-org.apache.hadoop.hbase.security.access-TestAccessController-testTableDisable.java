@Test public void testTableDisable() throws Exception {
  AccessTestAction disableTable=new AccessTestAction(){
    @Override public Object run() throws Exception {
      ACCESS_CONTROLLER.preDisableTable(ObserverContext.createAndPrepare(CP_ENV,null),TEST_TABLE);
      return null;
    }
  }
;
  AccessTestAction disableAclTable=new AccessTestAction(){
    @Override public Object run() throws Exception {
      ACCESS_CONTROLLER.preDisableTable(ObserverContext.createAndPrepare(CP_ENV,null),AccessControlLists.ACL_TABLE_NAME);
      return null;
    }
  }
;
  verifyAllowed(disableTable,SUPERUSER,USER_ADMIN,USER_CREATE,USER_OWNER,USER_GROUP_CREATE,USER_GROUP_ADMIN);
  verifyDenied(disableTable,USER_RW,USER_RO,USER_NONE,USER_GROUP_READ,USER_GROUP_WRITE);
  verifyDenied(disableAclTable,SUPERUSER,USER_ADMIN,USER_CREATE,USER_OWNER,USER_RW,USER_RO,USER_GROUP_CREATE,USER_GROUP_ADMIN,USER_GROUP_READ,USER_GROUP_WRITE);
}
