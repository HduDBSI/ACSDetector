/** 
 * An internal method that flushes the compressing stream (if using compression), serializes the header, and takes care of the separate uncompressed stream for caching on write, if applicable. Sets block write state to "block ready".
 */
private void finishBlock() throws IOException {
  userDataStream.flush();
  uncompressedBytesWithHeader=baosInMemory.toByteArray();
  LOG.warn("Writer.finishBlock user data size with header before compression " + uncompressedBytesWithHeader.length);
  prevOffset=prevOffsetByType[blockType.getId()];
  state=State.BLOCK_READY;
  encodeDataBlockForDisk();
  doCompression();
  putHeader(uncompressedBytesWithHeader,0,onDiskBytesWithHeader.length,uncompressedBytesWithHeader.length);
}
