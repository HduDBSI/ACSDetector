protected Monitor(Configuration config,String[] monitorTargets,boolean useRegExp,Sink sink){
  if (null == config)   throw new IllegalArgumentException("config shall not be null");
  this.config=config;
  this.targets=monitorTargets;
  this.useRegExp=useRegExp;
  this.sink=sink;
}
