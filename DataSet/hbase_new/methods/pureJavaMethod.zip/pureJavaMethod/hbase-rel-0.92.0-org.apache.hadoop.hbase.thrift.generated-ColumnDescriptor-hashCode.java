@Override public int hashCode(){
  return 0;
}
