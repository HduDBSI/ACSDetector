/** 
 * Returns true if field corresponding to fieldID is set (has been assigned a value) and false otherwise 
 */
public boolean isSet(_Fields field){
  if (field == null) {
    throw new IllegalArgumentException();
  }
switch (field) {
case ROW:
    return isSetRow();
case COLUMNS:
  return isSetColumns();
case TIMESTAMP:
return isSetTimestamp();
case TIME_RANGE:
return isSetTimeRange();
case MAX_VERSIONS:
return isSetMaxVersions();
}
throw new IllegalStateException();
}
