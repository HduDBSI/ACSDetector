/** 
 * Set up correct timestamps in the KVs in Delete object. <p>Caller should have the row and region locks.
 * @param mutation
 * @param familyMap
 * @param byteNow
 * @throws IOException
 */
public void prepareDeleteTimestamps(Mutation mutation,Map<byte[],List<Cell>> familyMap,byte[] byteNow) throws IOException {
  for (  Map.Entry<byte[],List<Cell>> e : familyMap.entrySet()) {
    byte[] family=e.getKey();
    List<Cell> cells=e.getValue();
    assert cells instanceof RandomAccess;
    Map<byte[],Integer> kvCount=new TreeMap<>(Bytes.BYTES_COMPARATOR);
    int listSize=cells.size();
    for (int i=0; i < listSize; i++) {
      Cell cell=cells.get(i);
      if (cell.getTimestamp() == HConstants.LATEST_TIMESTAMP && PrivateCellUtil.isDeleteType(cell)) {
        byte[] qual=CellUtil.cloneQualifier(cell);
        Integer count=kvCount.get(qual);
        if (count == null) {
          kvCount.put(qual,1);
        }
 else {
          kvCount.put(qual,count + 1);
        }
        count=kvCount.get(qual);
        Get get=new Get(CellUtil.cloneRow(cell));
        get.setMaxVersions(count);
        get.addColumn(family,qual);
        if (coprocessorHost != null) {
          if (!coprocessorHost.prePrepareTimeStampForDeleteVersion(mutation,cell,byteNow,get)) {
            updateDeleteLatestVersionTimestamp(cell,get,count,byteNow);
          }
        }
 else {
          updateDeleteLatestVersionTimestamp(cell,get,count,byteNow);
        }
      }
 else {
        PrivateCellUtil.updateLatestStamp(cell,byteNow);
      }
    }
  }
}
