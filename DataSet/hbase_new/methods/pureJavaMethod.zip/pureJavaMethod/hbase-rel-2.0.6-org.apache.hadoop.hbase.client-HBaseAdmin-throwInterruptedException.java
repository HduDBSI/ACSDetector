@Override public void throwInterruptedException() throws InterruptedIOException {
  throw new InterruptedIOException("Interrupted while waiting for " + getDescription());
}
