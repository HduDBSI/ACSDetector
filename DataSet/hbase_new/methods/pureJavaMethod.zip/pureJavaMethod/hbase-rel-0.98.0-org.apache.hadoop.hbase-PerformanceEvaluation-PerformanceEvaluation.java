/** 
 * Constructor
 * @param conf Configuration object
 */
public PerformanceEvaluation(final Configuration conf){
  super(conf);
  addCommandDescriptor(RandomReadTest.class,"randomRead","Run random read test");
  addCommandDescriptor(RandomSeekScanTest.class,"randomSeekScan","Run random seek and scan 100 test");
  addCommandDescriptor(RandomScanWithRange10Test.class,"scanRange10","Run random seek scan with both start and stop row (max 10 rows)");
  addCommandDescriptor(RandomScanWithRange100Test.class,"scanRange100","Run random seek scan with both start and stop row (max 100 rows)");
  addCommandDescriptor(RandomScanWithRange1000Test.class,"scanRange1000","Run random seek scan with both start and stop row (max 1000 rows)");
  addCommandDescriptor(RandomScanWithRange10000Test.class,"scanRange10000","Run random seek scan with both start and stop row (max 10000 rows)");
  addCommandDescriptor(RandomWriteTest.class,"randomWrite","Run random write test");
  addCommandDescriptor(SequentialReadTest.class,"sequentialRead","Run sequential read test");
  addCommandDescriptor(SequentialWriteTest.class,"sequentialWrite","Run sequential write test");
  addCommandDescriptor(ScanTest.class,"scan","Run scan test (read every row)");
  addCommandDescriptor(FilteredScanTest.class,"filterScan","Run scan test using a filter to find a specific row based on it's value (make sure to use --rows=20)");
}
