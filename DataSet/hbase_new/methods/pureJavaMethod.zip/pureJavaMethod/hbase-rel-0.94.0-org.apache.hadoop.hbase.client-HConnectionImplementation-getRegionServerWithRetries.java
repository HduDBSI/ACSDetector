public <T>T getRegionServerWithRetries(ServerCallable<T> callable) throws IOException, RuntimeException {
  return callable.withRetries();
}
