public void postGetTableNames(final List<HTableDescriptor> descriptors,final String regex) throws IOException {
  execOperation(coprocessors.isEmpty() ? null : new CoprocessorOperation(){
    @Override public void call(    MasterObserver oserver,    ObserverContext<MasterCoprocessorEnvironment> ctx) throws IOException {
      oserver.postGetTableNames(ctx,descriptors,regex);
    }
  }
);
}
