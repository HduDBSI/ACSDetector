private static HConnection createHConnection() throws IOException {
  HConnection hc=Mockito.mock(HConnection.class);
  Mockito.when(hc.getRegionLocation(Mockito.eq(DUMMY_TABLE),Mockito.eq(DUMMY_BYTES_1),Mockito.anyBoolean())).thenReturn(loc1);
  Mockito.when(hc.locateRegion(Mockito.eq(DUMMY_TABLE),Mockito.eq(DUMMY_BYTES_1))).thenReturn(loc1);
  Mockito.when(hc.getRegionLocation(Mockito.eq(DUMMY_TABLE),Mockito.eq(DUMMY_BYTES_2),Mockito.anyBoolean())).thenReturn(loc2);
  Mockito.when(hc.locateRegion(Mockito.eq(DUMMY_TABLE),Mockito.eq(DUMMY_BYTES_2))).thenReturn(loc2);
  Mockito.when(hc.getRegionLocation(Mockito.eq(DUMMY_TABLE),Mockito.eq(DUMMY_BYTES_3),Mockito.anyBoolean())).thenReturn(loc2);
  Mockito.when(hc.locateRegion(Mockito.eq(DUMMY_TABLE),Mockito.eq(DUMMY_BYTES_3))).thenReturn(loc3);
  Mockito.when(hc.getRegionLocation(Mockito.eq(DUMMY_TABLE),Mockito.eq(FAILS),Mockito.anyBoolean())).thenReturn(loc2);
  Mockito.when(hc.locateRegion(Mockito.eq(DUMMY_TABLE),Mockito.eq(FAILS))).thenReturn(loc2);
  return hc;
}
