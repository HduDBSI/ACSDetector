public void readFields(DataInput in) throws IOException {
  kvs.clear();
  scopes.clear();
  Decoder decoder=this.codec.getDecoder((DataInputStream)in);
  int versionOrLength=in.readInt();
  int length=versionOrLength;
  if (versionOrLength == VERSION_2) {
    length=in.readInt();
  }
  kvs.ensureCapacity(length);
  for (int i=0; i < length && decoder.advance(); i++) {
    kvs.add(decoder.current());
  }
  if (versionOrLength == VERSION_2) {
    int numEntries=in.readInt();
    if (numEntries > 0) {
      for (int i=0; i < numEntries; i++) {
        byte[] key=Bytes.readByteArray(in);
        int scope=in.readInt();
        scopes.put(key,scope);
      }
    }
  }
}
