/** 
 * Complete taking the snapshot on the region. Writes the region info and adds references to the working snapshot directory. TODO for api consistency, consider adding another version with no  {@link ForeignExceptionSnare}arg.  (In the future other cancellable HRegion methods could eventually add a {@link ForeignExceptionSnare}, or we could do something fancier).
 * @param desc snasphot description object
 * @param exnSnare ForeignExceptionSnare that captures external exeptions in case we need tobail out.  This is allowed to be null and will just be ignored in that case.
 * @throws IOException if there is an external or internal error causing the snapshot to fail
 */
public void addRegionToSnapshot(SnapshotDescription desc,ForeignExceptionSnare exnSnare) throws IOException {
  Path rootDir=FSUtils.getRootDir(this.rsServices.getConfiguration());
  Path snapshotDir=SnapshotDescriptionUtils.getWorkingSnapshotDir(desc,rootDir);
  LOG.debug("Storing region-info for snapshot.");
  HRegionFileSystem snapshotRegionFs=HRegionFileSystem.createRegionOnFileSystem(conf,this.fs.getFileSystem(),snapshotDir,getRegionInfo());
  LOG.debug("Creating references for hfiles");
  for (  Store store : stores.values()) {
    Path dstStoreDir=snapshotRegionFs.getStoreDir(store.getFamily().getNameAsString());
    List<StoreFile> storeFiles=new ArrayList<StoreFile>(store.getStorefiles());
    if (LOG.isDebugEnabled()) {
      LOG.debug("Adding snapshot references for " + storeFiles + " hfiles");
    }
    int sz=storeFiles.size();
    for (int i=0; i < sz; i++) {
      if (exnSnare != null) {
        exnSnare.rethrowException();
      }
      StoreFile storeFile=storeFiles.get(i);
      Path file=storeFile.getPath();
      LOG.debug("Creating reference for file (" + (i + 1) + "/"+ sz+ ") : "+ file);
      Path referenceFile=new Path(dstStoreDir,file.getName());
      boolean success=true;
      if (storeFile.isReference()) {
        storeFile.getFileInfo().getReference().write(fs.getFileSystem(),referenceFile);
      }
 else {
        success=fs.getFileSystem().createNewFile(referenceFile);
      }
      if (!success) {
        throw new IOException("Failed to create reference file:" + referenceFile);
      }
    }
  }
}
