/** 
 * Fully specify all necessary components of a snapshot manager. Exposed for testing.
 * @param master services for the master where the manager is running
 * @param coordinator procedure coordinator instance.  exposed for testing.
 * @param pool HBase ExecutorServcie instance, exposed for testing.
 */
public SnapshotManager(final MasterServices master,final MetricsMaster metricsMaster,ProcedureCoordinator coordinator,ExecutorService pool) throws IOException, UnsupportedOperationException {
  this.master=master;
  this.rootDir=master.getMasterFileSystem().getRootDir();
  checkSnapshotSupport(master.getConfiguration(),master.getMasterFileSystem());
  this.coordinator=coordinator;
  this.executorService=pool;
  resetTempDir();
}
