public Void call() throws IOException {
  f.closeReader(true);
  return null;
}
