/** 
 * Perform a transactional Get operation.
 * @param regionName name of region to get from
 * @param get Get operation
 * @return Result
 * @throws IOException
 */
public Result get(long transactionId,byte[] regionName,Get get) throws IOException ;
