LimitFields(int batch,LimitScope sizeScope,long size,long heapSize,LimitScope timeScope,long time){
  setFields(batch,sizeScope,size,heapSize,timeScope,time);
}
