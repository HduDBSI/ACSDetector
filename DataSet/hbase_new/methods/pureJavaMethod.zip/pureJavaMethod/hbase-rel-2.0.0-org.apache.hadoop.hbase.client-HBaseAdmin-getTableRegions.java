/** 
 * @param tableName
 * @return List of {@link HRegionInfo}.
 * @throws IOException
 * @deprecated As of release 2.0.0, this will be removed in HBase 3.0.0Use  {@link #getRegions(TableName)}.
 */
@Deprecated @Override public List<HRegionInfo> getTableRegions(final TableName tableName) throws IOException {
  return getRegions(tableName).stream().map(ImmutableHRegionInfo::new).collect(Collectors.toList());
}
