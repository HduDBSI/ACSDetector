@Override public void write(DataOutput out) throws IOException {
  MapReduceProtos.TableSnapshotRegionSplit.Builder builder=MapReduceProtos.TableSnapshotRegionSplit.newBuilder().setRegion(RegionSpecifier.newBuilder().setType(RegionSpecifierType.ENCODED_REGION_NAME).setValue(HBaseZeroCopyByteString.wrap(Bytes.toBytes(regionName))).build());
  for (  String location : locations) {
    builder.addLocations(location);
  }
  MapReduceProtos.TableSnapshotRegionSplit split=builder.build();
  ByteArrayOutputStream baos=new ByteArrayOutputStream();
  split.writeTo(baos);
  baos.close();
  byte[] buf=baos.toByteArray();
  out.writeInt(buf.length);
  out.write(buf);
}
