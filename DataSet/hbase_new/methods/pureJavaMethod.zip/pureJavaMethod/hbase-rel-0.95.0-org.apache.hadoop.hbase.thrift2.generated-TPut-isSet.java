/** 
 * Returns true if field corresponding to fieldID is set (has been assigned a value) and false otherwise 
 */
public boolean isSet(_Fields field){
  if (field == null) {
    throw new IllegalArgumentException();
  }
switch (field) {
case ROW:
    return isSetRow();
case COLUMN_VALUES:
  return isSetColumnValues();
case TIMESTAMP:
return isSetTimestamp();
case WRITE_TO_WAL:
return isSetWriteToWal();
}
throw new IllegalStateException();
}
