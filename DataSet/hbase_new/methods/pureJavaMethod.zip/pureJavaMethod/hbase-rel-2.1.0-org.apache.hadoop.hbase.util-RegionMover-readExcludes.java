/** 
 * @return List of servers from the exclude file in format 'hostname:port'.
 */
private ArrayList<String> readExcludes(String excludeFile) throws IOException {
  ArrayList<String> excludeServers=new ArrayList<>();
  if (excludeFile == null) {
    return excludeServers;
  }
 else {
    File f=new File(excludeFile);
    String line;
    BufferedReader br=null;
    try {
      br=new BufferedReader(new FileReader(f));
      while ((line=br.readLine()) != null) {
        line=line.trim();
        if (!line.equals("")) {
          excludeServers.add(line);
        }
      }
    }
 catch (    IOException e) {
      LOG.warn("Exception while reading excludes file,continuing anyways",e);
    }
 finally {
      if (br != null) {
        br.close();
      }
    }
    return excludeServers;
  }
}
