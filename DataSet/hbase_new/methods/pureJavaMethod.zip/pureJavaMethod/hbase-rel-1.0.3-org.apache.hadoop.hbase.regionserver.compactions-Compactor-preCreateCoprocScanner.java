protected InternalScanner preCreateCoprocScanner(final CompactionRequest request,final ScanType scanType,final long earliestPutTs,final List<StoreFileScanner> scanners,User user) throws IOException {
  if (store.getCoprocessorHost() == null)   return null;
  if (user == null) {
    return store.getCoprocessorHost().preCompactScannerOpen(store,scanners,scanType,earliestPutTs,request);
  }
 else {
    try {
      return user.getUGI().doAs(new PrivilegedExceptionAction<InternalScanner>(){
        @Override public InternalScanner run() throws Exception {
          return store.getCoprocessorHost().preCompactScannerOpen(store,scanners,scanType,earliestPutTs,request);
        }
      }
);
    }
 catch (    InterruptedException ie) {
      InterruptedIOException iioe=new InterruptedIOException();
      iioe.initCause(ie);
      throw iioe;
    }
  }
}
