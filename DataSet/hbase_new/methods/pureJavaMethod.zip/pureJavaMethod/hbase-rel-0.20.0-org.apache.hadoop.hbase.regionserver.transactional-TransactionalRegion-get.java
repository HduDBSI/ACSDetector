public Result get(final long transactionId,Get get) throws IOException {
  checkClosing();
  TransactionState state=getTransactionState(transactionId);
  state.addRead(get.getRow());
  Result superGet=super.get(get,null);
  Result localGet=state.localGet(get);
  if (localGet != null) {
    LOG.trace("Transactional get of something we've written in the same transaction " + transactionId);
    List<KeyValue> mergedGet=new ArrayList<KeyValue>(Arrays.asList(localGet.raw()));
    if (superGet != null && !superGet.isEmpty()) {
      for (      KeyValue kv : superGet.raw()) {
        if (!localGet.containsColumn(kv.getFamily(),kv.getQualifier())) {
          mergedGet.add(kv);
        }
      }
    }
    return new Result(mergedGet);
  }
  return superGet;
}
