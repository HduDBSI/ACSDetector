protected void addToMovedRegions(String encodedName,ServerName destination,long closeSeqNum){
  if (ServerName.isSameHostnameAndPort(destination,this.getServerName())) {
    LOG.warn("Not adding moved region record: " + encodedName + " to self.");
    return;
  }
  LOG.info("Adding moved region record: " + encodedName + " to "+ destination+ " as of "+ closeSeqNum);
  movedRegions.put(encodedName,new MovedRegionInfo(destination,closeSeqNum));
}
