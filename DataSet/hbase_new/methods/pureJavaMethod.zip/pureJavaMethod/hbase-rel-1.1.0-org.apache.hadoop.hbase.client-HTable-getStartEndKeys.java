/** 
 * @deprecated Use {@link RegionLocator#getStartEndKeys()} instead;
 */
@Override @Deprecated public Pair<byte[][],byte[][]> getStartEndKeys() throws IOException {
  return locator.getStartEndKeys();
}
