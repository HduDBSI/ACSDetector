/** 
 * Get a scanner on the current table starting at the specified row. Return the specified columns.
 * @param transactionState
 * @param columns columns to scan. If column name is a column family, allcolumns of the specified column family are returned. Its also possible to pass a regex in the column qualifier. A column qualifier is judged to be a regex if it contains at least one of the following characters: <code>\+|^&*$[]]}{)(</code>.
 * @param startRow starting row in table to scan
 * @param timestamp only return results whose timestamp <= this value
 * @param filter a row filter using row-key regexp and/or column data filter.
 * @return scanner
 * @throws IOException
 */
public Scanner getScanner(final TransactionState transactionState,final byte[][] columns,final byte[] startRow,final long timestamp,final RowFilterInterface filter) throws IOException {
  ClientScanner scanner=new TransactionalClientScanner(transactionState,columns,startRow,timestamp,filter);
  scanner.initialize();
  return scanner;
}
