@Override public MatchCode checkColumn(Cell cell,byte type) throws IOException {
  if (columns == null) {
    return MatchCode.INCLUDE;
  }
  while (!done()) {
    int c=CellUtil.compareQualifiers(cell,columns[columnIndex],0,columns[columnIndex].length);
    if (c < 0) {
      return MatchCode.SEEK_NEXT_COL;
    }
    if (c == 0) {
      return MatchCode.INCLUDE;
    }
    columnIndex++;
  }
  return MatchCode.SEEK_NEXT_ROW;
}
