public void setFieldValue(_Fields field,Object value){
switch (field) {
case ROW:
    if (value == null) {
      unsetRow();
    }
 else {
      setRow((ByteBuffer)value);
    }
  break;
case COLUMN_VALUES:
if (value == null) {
  unsetColumnValues();
}
 else {
  setColumnValues((List<TColumnValue>)value);
}
break;
}
}
