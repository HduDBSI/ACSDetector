public RecordWriter<ImmutableBytesWritable,KeyValue> getRecordWriter(final TaskAttemptContext context) throws IOException, InterruptedException {
  final Path outputPath=FileOutputFormat.getOutputPath(context);
  final Path outputdir=new FileOutputCommitter(outputPath,context).getWorkPath();
  final Configuration conf=context.getConfiguration();
  final FileSystem fs=outputdir.getFileSystem(conf);
  final long maxsize=conf.getLong(HConstants.HREGION_MAX_FILESIZE,HConstants.DEFAULT_MAX_FILE_SIZE);
  final String defaultCompression=conf.get("hfile.compression",Compression.Algorithm.NONE.getName());
  final boolean compactionExclude=conf.getBoolean("hbase.mapreduce.hfileoutputformat.compaction.exclude",false);
  final Map<byte[],String> compressionMap=createFamilyCompressionMap(conf);
  final Map<byte[],String> bloomTypeMap=createFamilyBloomMap(conf);
  final Map<byte[],String> blockSizeMap=createFamilyBlockSizeMap(conf);
  String dataBlockEncodingStr=conf.get(DATABLOCK_ENCODING_CONF_KEY);
  final HFileDataBlockEncoder encoder;
  if (dataBlockEncodingStr == null) {
    encoder=NoOpDataBlockEncoder.INSTANCE;
  }
 else {
    try {
      encoder=new HFileDataBlockEncoderImpl(DataBlockEncoding.valueOf(dataBlockEncodingStr));
    }
 catch (    IllegalArgumentException ex) {
      throw new RuntimeException("Invalid data block encoding type configured for the param " + DATABLOCK_ENCODING_CONF_KEY + " : "+ dataBlockEncodingStr);
    }
  }
  return new RecordWriter<ImmutableBytesWritable,KeyValue>(){
    private final Map<byte[],WriterLength> writers=new TreeMap<byte[],WriterLength>(Bytes.BYTES_COMPARATOR);
    private byte[] previousRow=HConstants.EMPTY_BYTE_ARRAY;
    private final byte[] now=Bytes.toBytes(System.currentTimeMillis());
    private boolean rollRequested=false;
    public void write(    ImmutableBytesWritable row,    KeyValue kv) throws IOException {
      if (row == null && kv == null) {
        rollWriters();
        return;
      }
      byte[] rowKey=kv.getRow();
      long length=kv.getLength();
      byte[] family=kv.getFamily();
      WriterLength wl=this.writers.get(family);
      if (wl == null) {
        fs.mkdirs(new Path(outputdir,Bytes.toString(family)));
      }
      if (wl != null && wl.written + length >= maxsize) {
        this.rollRequested=true;
      }
      if (rollRequested && Bytes.compareTo(this.previousRow,rowKey) != 0) {
        rollWriters();
      }
      if (wl == null || wl.writer == null) {
        wl=getNewWriter(family,conf);
      }
      kv.updateLatestStamp(this.now);
      wl.writer.append(kv);
      wl.written+=length;
      this.previousRow=rowKey;
    }
    private void rollWriters() throws IOException {
      for (      WriterLength wl : this.writers.values()) {
        if (wl.writer != null) {
          LOG.info("Writer=" + wl.writer.getPath() + ((wl.written == 0) ? "" : ", wrote=" + wl.written));
          close(wl.writer);
        }
        wl.writer=null;
        wl.written=0;
      }
      this.rollRequested=false;
    }
    private WriterLength getNewWriter(    byte[] family,    Configuration conf) throws IOException {
      WriterLength wl=new WriterLength();
      Path familydir=new Path(outputdir,Bytes.toString(family));
      String compression=compressionMap.get(family);
      compression=compression == null ? defaultCompression : compression;
      String bloomTypeStr=bloomTypeMap.get(family);
      BloomType bloomType=BloomType.NONE;
      if (bloomTypeStr != null) {
        bloomType=BloomType.valueOf(bloomTypeStr);
      }
      String blockSizeString=blockSizeMap.get(family);
      int blockSize=blockSizeString == null ? HConstants.DEFAULT_BLOCKSIZE : Integer.parseInt(blockSizeString);
      Configuration tempConf=new Configuration(conf);
      tempConf.setFloat(HConstants.HFILE_BLOCK_CACHE_SIZE_KEY,0.0f);
      wl.writer=new StoreFile.WriterBuilder(conf,new CacheConfig(tempConf),fs,blockSize).withOutputDir(familydir).withCompression(AbstractHFileWriter.compressionByName(compression)).withBloomType(bloomType).withComparator(KeyValue.COMPARATOR).withDataBlockEncoder(encoder).withChecksumType(HStore.getChecksumType(conf)).withBytesPerChecksum(HStore.getBytesPerChecksum(conf)).build();
      this.writers.put(family,wl);
      return wl;
    }
    private void close(    final StoreFile.Writer w) throws IOException {
      if (w != null) {
        w.appendFileInfo(StoreFile.BULKLOAD_TIME_KEY,Bytes.toBytes(System.currentTimeMillis()));
        w.appendFileInfo(StoreFile.BULKLOAD_TASK_KEY,Bytes.toBytes(context.getTaskAttemptID().toString()));
        w.appendFileInfo(StoreFile.MAJOR_COMPACTION_KEY,Bytes.toBytes(true));
        w.appendFileInfo(StoreFile.EXCLUDE_FROM_MINOR_COMPACTION_KEY,Bytes.toBytes(compactionExclude));
        w.appendTrackedTimestampsToMetadata();
        w.close();
      }
    }
    public void close(    TaskAttemptContext c) throws IOException, InterruptedException {
      for (      WriterLength wl : this.writers.values()) {
        close(wl.writer);
      }
    }
  }
;
}
