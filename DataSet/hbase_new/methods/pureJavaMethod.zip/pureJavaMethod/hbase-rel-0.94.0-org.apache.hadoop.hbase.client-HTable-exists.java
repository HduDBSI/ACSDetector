/** 
 * {@inheritDoc}
 */
@Override public boolean exists(final Get get) throws IOException {
  return new ServerCallable<Boolean>(connection,tableName,get.getRow(),operationTimeout){
    public Boolean call() throws IOException {
      return server.exists(location.getRegionInfo().getRegionName(),get);
    }
  }
.withRetries();
}
