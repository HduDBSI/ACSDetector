/** 
 * Updates the hbase:quota table with the new quota policy for this <code>table</code> if necessary.
 * @param table The table being checked
 * @param currentSnapshot The state of the quota on this table from the previous invocation.
 * @param targetSnapshot The state the quota should be in for this table.
 */
void updateTableQuota(TableName table,SpaceQuotaSnapshot currentSnapshot,SpaceQuotaSnapshot targetSnapshot) throws IOException {
  final SpaceQuotaStatus currentStatus=currentSnapshot.getQuotaStatus();
  final SpaceQuotaStatus targetStatus=targetSnapshot.getQuotaStatus();
  if (!currentSnapshot.equals(targetSnapshot)) {
    if (!targetStatus.isInViolation()) {
      if (LOG.isDebugEnabled()) {
        LOG.debug(table + " moving into observance of table space quota.");
      }
    }
 else     if (LOG.isDebugEnabled()) {
      LOG.debug(table + " moving into violation of table space quota with policy of " + targetStatus.getPolicy());
    }
    this.snapshotNotifier.transitionTable(table,targetSnapshot);
    tableSnapshotStore.setCurrentState(table,targetSnapshot);
  }
 else   if (LOG.isTraceEnabled()) {
    if (!currentStatus.isInViolation()) {
      LOG.trace(table + " remains in observance of quota.");
    }
 else {
      LOG.trace(table + " remains in violation of quota.");
    }
  }
}
