public void postAddRSGroup(final String name) throws IOException {
  execOperation(coprocessors.isEmpty() ? null : new CoprocessorOperation(){
    @Override public void call(    MasterObserver oserver,    ObserverContext<MasterCoprocessorEnvironment> ctx) throws IOException {
      if (((MasterEnvironment)ctx.getEnvironment()).supportGroupCPs) {
        oserver.postAddRSGroup(ctx,name);
      }
    }
  }
);
}
