/** 
 * Set the age of the last edit that was shipped group by table
 * @param timestamp write time of the edit
 * @param tableName String as group and tableName
 */
public void setAgeOfLastShippedOpByTable(long timestamp,String tableName){
  getSourceForTable(tableName).setLastShippedAge(EnvironmentEdgeManager.currentTime() - timestamp);
}
