private static boolean checkForMatchingVisibilityTagsWithSortedOrder(List<Tag> putVisTags,List<Tag> deleteVisTags){
  if (putVisTags.isEmpty() && deleteVisTags.isEmpty()) {
    return true;
  }
  boolean matchFound=false;
  if ((deleteVisTags.size()) == putVisTags.size()) {
    for (    Tag tag : deleteVisTags) {
      matchFound=false;
      for (      Tag givenTag : putVisTags) {
        if (Tag.matchingValue(tag,givenTag)) {
          matchFound=true;
          break;
        }
      }
      if (!matchFound)       break;
    }
  }
  return matchFound;
}
