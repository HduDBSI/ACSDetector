@Override public boolean equals(Object obj){
  if (obj == null) {
    return false;
  }
  if (!(obj instanceof MemStoreSize)) {
    return false;
  }
  MemStoreSize other=(MemStoreSize)obj;
  return this.dataSize == other.dataSize && this.heapSize == other.heapSize && this.offHeapSize == other.offHeapSize;
}
