private void writeMaxSequenceIdFile(MasterProcedureEnv env) throws IOException {
  MasterFileSystem fs=env.getMasterFileSystem();
  long maxSequenceId=WALSplitter.getMaxRegionSequenceId(env.getMasterConfiguration(),getParentRegion(),fs::getFileSystem,fs::getWALFileSystem);
  if (maxSequenceId > 0) {
    WALSplitter.writeRegionSequenceIdFile(fs.getWALFileSystem(),getWALRegionDir(env,daughter_1_RI),maxSequenceId);
    WALSplitter.writeRegionSequenceIdFile(fs.getWALFileSystem(),getWALRegionDir(env,daughter_2_RI),maxSequenceId);
  }
}
