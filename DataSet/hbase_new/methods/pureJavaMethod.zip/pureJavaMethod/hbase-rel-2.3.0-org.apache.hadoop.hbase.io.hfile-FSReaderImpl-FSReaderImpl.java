FSReaderImpl(ReaderContext readerContext,HFileContext fileContext,ByteBuffAllocator allocator) throws IOException {
  this.fileSize=readerContext.getFileSize();
  this.hfs=readerContext.getFileSystem();
  if (readerContext.getFilePath() != null) {
    this.pathName=readerContext.getFilePath().toString();
  }
  this.fileContext=fileContext;
  this.hdrSize=headerSize(fileContext.isUseHBaseChecksum());
  this.allocator=allocator;
  this.streamWrapper=readerContext.getInputStreamWrapper();
  this.streamWrapper.prepareForBlockReader(!fileContext.isUseHBaseChecksum());
  defaultDecodingCtx=new HFileBlockDefaultDecodingContext(fileContext);
  encodedBlockDecodingCtx=defaultDecodingCtx;
}
