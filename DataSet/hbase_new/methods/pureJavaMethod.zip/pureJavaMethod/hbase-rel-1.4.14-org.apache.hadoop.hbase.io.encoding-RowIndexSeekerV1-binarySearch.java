private int binarySearch(Cell seekCell,boolean seekBefore){
  int low=0;
  int high=rowNumber - 1;
  int mid=(low + high) >>> 1;
  int comp=0;
  SimpleMutableByteRange row=new SimpleMutableByteRange();
  while (low <= high) {
    mid=(low + high) >>> 1;
    getRow(mid,row);
    comp=comparator.compareRows(row.getBytes(),row.getOffset(),row.getLength(),seekCell.getRowArray(),seekCell.getRowOffset(),seekCell.getRowLength());
    if (comp < 0) {
      low=mid + 1;
    }
 else     if (comp > 0) {
      high=mid - 1;
    }
 else {
      if (seekBefore) {
        return mid - 1;
      }
 else {
        return mid;
      }
    }
  }
  if (comp > 0) {
    return mid - 1;
  }
 else {
    return mid;
  }
}
