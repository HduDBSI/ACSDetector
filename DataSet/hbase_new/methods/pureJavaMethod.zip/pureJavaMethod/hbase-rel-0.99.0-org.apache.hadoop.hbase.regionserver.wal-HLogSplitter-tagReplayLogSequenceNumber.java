/** 
 * Tag original sequence number for each edit to be replayed
 * @param seqId
 * @param cell
 */
private static Cell tagReplayLogSequenceNumber(long seqId,Cell cell){
  boolean needAddRecoveryTag=true;
  if (cell.getTagsLength() > 0) {
    Tag tmpTag=Tag.getTag(cell.getTagsArray(),cell.getTagsOffset(),cell.getTagsLength(),TagType.LOG_REPLAY_TAG_TYPE);
    if (tmpTag != null) {
      needAddRecoveryTag=false;
    }
  }
  if (needAddRecoveryTag) {
    List<Tag> newTags=new ArrayList<Tag>();
    Tag replayTag=new Tag(TagType.LOG_REPLAY_TAG_TYPE,Bytes.toBytes(seqId));
    newTags.add(replayTag);
    return KeyValue.cloneAndAddTags(cell,newTags);
  }
  return cell;
}
