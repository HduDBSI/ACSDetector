/** 
 * {@inheritDoc}
 */
@Override public boolean exists(final Get get) throws IOException {
  return connection.getRegionServerWithRetries(new ServerCallable<Boolean>(connection,tableName,get.getRow(),operationTimeout){
    public Boolean call() throws IOException {
      return server.exists(location.getRegionInfo().getRegionName(),get);
    }
  }
);
}
