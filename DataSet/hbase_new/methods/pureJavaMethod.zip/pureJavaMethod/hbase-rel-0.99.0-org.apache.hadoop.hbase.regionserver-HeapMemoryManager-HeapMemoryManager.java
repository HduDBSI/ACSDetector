@VisibleForTesting HeapMemoryManager(ResizableBlockCache blockCache,FlushRequester memStoreFlusher,Server server){
  this.blockCache=blockCache;
  this.memStoreFlusher=memStoreFlusher;
  this.server=server;
  this.tunerOn=doInit(server.getConfiguration());
}
