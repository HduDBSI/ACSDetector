@Override public int compareTo(IOError other){
  if (!getClass().equals(other.getClass())) {
    return getClass().getName().compareTo(other.getClass().getName());
  }
  int lastComparison=0;
  lastComparison=Boolean.valueOf(isSetMessage()).compareTo(other.isSetMessage());
  if (lastComparison != 0) {
    return lastComparison;
  }
  if (isSetMessage()) {
    lastComparison=org.apache.thrift.TBaseHelper.compareTo(this.message,other.message);
    if (lastComparison != 0) {
      return lastComparison;
    }
  }
  return 0;
}
