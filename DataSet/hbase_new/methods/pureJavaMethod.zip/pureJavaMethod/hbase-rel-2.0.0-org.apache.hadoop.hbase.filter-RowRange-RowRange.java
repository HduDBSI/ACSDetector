public RowRange(byte[] startRow,boolean startRowInclusive,byte[] stopRow,boolean stopRowInclusive){
  this.startRow=(startRow == null) ? HConstants.EMPTY_BYTE_ARRAY : startRow;
  this.startRowInclusive=startRowInclusive;
  this.stopRow=(stopRow == null) ? HConstants.EMPTY_BYTE_ARRAY : stopRow;
  this.stopRowInclusive=stopRowInclusive;
}
