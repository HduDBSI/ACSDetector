/** 
 * Mark the  {@link WriteEntry} as complete and advance the read point asmuch as possible. How much is the read point advanced? Let S be the set of all write numbers that are completed and where all previous write numbers are also completed.  Then, the read point is advanced to the supremum of S.
 * @param e
 * @return true if e is visible to MVCC readers (that is, readpoint >= e.writeNumber)
 */
boolean advanceMemstore(WriteEntry e){
  long nextReadValue=-1;
synchronized (writeQueue) {
    e.markCompleted();
    while (!writeQueue.isEmpty()) {
      WriteEntry queueFirst=writeQueue.getFirst();
      if (queueFirst.isCompleted()) {
        nextReadValue=Math.max(nextReadValue,queueFirst.getWriteNumber());
        writeQueue.removeFirst();
      }
 else {
        break;
      }
    }
    if (nextReadValue > memstoreRead) {
      memstoreRead=nextReadValue;
    }
    writeQueue.notifyAll();
  }
  if (nextReadValue > 0) {
synchronized (readWaiters) {
      readWaiters.notifyAll();
    }
  }
  if (memstoreRead >= e.getWriteNumber()) {
    return true;
  }
  return false;
}
