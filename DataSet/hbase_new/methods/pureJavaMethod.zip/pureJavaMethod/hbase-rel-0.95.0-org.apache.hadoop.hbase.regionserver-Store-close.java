/** 
 * Close all the readers We don't need to worry about subsequent requests because the HRegion holds a write lock that will prevent any more reads or writes.
 * @return the {@link StoreFile StoreFiles} that were previously being used.
 * @throws IOException on failure
 */
public Collection<StoreFile> close() throws IOException ;
