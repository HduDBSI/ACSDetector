@Test public void testBalanceSwitch() throws Exception {
  AccessTestAction action=new AccessTestAction(){
    @Override public Object run() throws Exception {
      ACCESS_CONTROLLER.preBalanceSwitch(ObserverContext.createAndPrepare(CP_ENV,null),true);
      return null;
    }
  }
;
  verifyAllowed(action,SUPERUSER,USER_ADMIN);
  verifyDenied(action,USER_CREATE,USER_OWNER,USER_RW,USER_RO,USER_NONE);
}
