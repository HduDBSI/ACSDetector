private int compareColumns(final Cell left,final int leftFamLen,final int leftQualLen,final Cell right,final int rightFamLen,final int rightQualLen){
  int diff=compareFamilies(left,leftFamLen,right,rightFamLen);
  if (diff != 0) {
    return diff;
  }
  return compareQualifiers(left,leftQualLen,right,rightQualLen);
}
