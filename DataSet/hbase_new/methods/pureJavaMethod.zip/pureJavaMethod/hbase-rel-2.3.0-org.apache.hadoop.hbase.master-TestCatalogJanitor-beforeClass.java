@BeforeClass public static void beforeClass() throws Exception {
  ChunkCreator.initialize(MemStoreLABImpl.CHUNK_SIZE_DEFAULT,false,0,0,0,null);
}
