/** 
 * Performs a deep copy on <i>other</i>.
 */
public deleteAllRowTs_args(deleteAllRowTs_args other){
  __isset_bitfield=other.__isset_bitfield;
  if (other.isSetTableName()) {
    this.tableName=other.tableName;
  }
  if (other.isSetRow()) {
    this.row=other.row;
  }
  this.timestamp=other.timestamp;
  if (other.isSetAttributes()) {
    Map<ByteBuffer,ByteBuffer> __this__attributes=new HashMap<ByteBuffer,ByteBuffer>(other.attributes.size());
    for (    Map.Entry<ByteBuffer,ByteBuffer> other_element : other.attributes.entrySet()) {
      ByteBuffer other_element_key=other_element.getKey();
      ByteBuffer other_element_value=other_element.getValue();
      ByteBuffer __this__attributes_copy_key=other_element_key;
      ByteBuffer __this__attributes_copy_value=other_element_value;
      __this__attributes.put(__this__attributes_copy_key,__this__attributes_copy_value);
    }
    this.attributes=__this__attributes;
  }
}
