/** 
 * Performs a deep copy on <i>other</i>.
 */
public TIncrement(TIncrement other){
  if (other.isSetRow()) {
    this.row=org.apache.thrift.TBaseHelper.copyBinary(other.row);
  }
  if (other.isSetColumns()) {
    List<TColumnIncrement> __this__columns=new ArrayList<TColumnIncrement>(other.columns.size());
    for (    TColumnIncrement other_element : other.columns) {
      __this__columns.add(new TColumnIncrement(other_element));
    }
    this.columns=__this__columns;
  }
  if (other.isSetAttributes()) {
    Map<ByteBuffer,ByteBuffer> __this__attributes=new HashMap<ByteBuffer,ByteBuffer>(other.attributes);
    this.attributes=__this__attributes;
  }
  if (other.isSetDurability()) {
    this.durability=other.durability;
  }
  if (other.isSetCellVisibility()) {
    this.cellVisibility=new TCellVisibility(other.cellVisibility);
  }
}
