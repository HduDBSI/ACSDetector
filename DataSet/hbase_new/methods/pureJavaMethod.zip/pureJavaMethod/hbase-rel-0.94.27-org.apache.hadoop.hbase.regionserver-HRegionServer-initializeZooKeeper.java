/** 
 * Bring up connection to zk ensemble and then wait until a master for this cluster and then after that, wait until cluster 'up' flag has been set. This is the order in which master does things. Finally put up a catalog tracker.
 * @throws IOException
 * @throws InterruptedException
 */
private void initializeZooKeeper() throws IOException, InterruptedException {
  this.zooKeeper=new ZooKeeperWatcher(conf,REGIONSERVER + ":" + this.isa.getPort(),this);
  this.masterAddressManager=new MasterAddressTracker(this.zooKeeper,this);
  this.masterAddressManager.start();
  blockAndCheckIfStopped(this.masterAddressManager);
  this.clusterStatusTracker=new ClusterStatusTracker(this.zooKeeper,this);
  this.clusterStatusTracker.start();
  blockAndCheckIfStopped(this.clusterStatusTracker);
  this.catalogTracker=new CatalogTracker(this.zooKeeper,this.conf,this);
  catalogTracker.start();
  try {
    this.snapshotManager=new RegionServerSnapshotManager(this);
  }
 catch (  KeeperException e) {
    this.abort("Failed to reach zk cluster when creating snapshot handler.");
  }
}
