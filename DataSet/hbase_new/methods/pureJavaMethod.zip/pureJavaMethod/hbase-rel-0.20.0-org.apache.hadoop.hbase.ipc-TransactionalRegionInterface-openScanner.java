/** 
 * Opens a remote transactional scanner with a RowFilter.
 * @param regionName name of region to scan
 * @param scan configured scan object
 * @return scannerId scanner identifier used in other calls
 * @throws IOException
 */
public long openScanner(long transactionId,final byte[] regionName,final Scan scan) throws IOException ;
