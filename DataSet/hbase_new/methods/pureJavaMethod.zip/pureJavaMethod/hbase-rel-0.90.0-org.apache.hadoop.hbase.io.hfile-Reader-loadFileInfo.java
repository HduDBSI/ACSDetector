/** 
 * Read in the index and file info.
 * @return A map of fileinfo data.See  {@link Writer#appendFileInfo(byte[],byte[])}.
 * @throws IOException
 */
public Map<byte[],byte[]> loadFileInfo() throws IOException {
  this.trailer=readTrailer();
  this.istream.seek(this.trailer.fileinfoOffset);
  FileInfo fi=new FileInfo();
  fi.readFields(this.istream);
  this.lastkey=fi.get(FileInfo.LASTKEY);
  this.avgKeyLen=Bytes.toInt(fi.get(FileInfo.AVG_KEY_LEN));
  this.avgValueLen=Bytes.toInt(fi.get(FileInfo.AVG_VALUE_LEN));
  String clazzName=Bytes.toString(fi.get(FileInfo.COMPARATOR));
  this.comparator=getComparator(clazzName);
  int allIndexSize=(int)(this.fileSize - this.trailer.dataIndexOffset - FixedFileTrailer.trailerSize());
  byte[] dataAndMetaIndex=readAllIndex(this.istream,this.trailer.dataIndexOffset,allIndexSize);
  ByteArrayInputStream bis=new ByteArrayInputStream(dataAndMetaIndex);
  DataInputStream dis=new DataInputStream(bis);
  this.blockIndex=BlockIndex.readIndex(this.comparator,dis,this.trailer.dataIndexCount);
  if (trailer.metaIndexCount > 0) {
    this.metaIndex=BlockIndex.readIndex(Bytes.BYTES_RAWCOMPARATOR,dis,this.trailer.metaIndexCount);
  }
  this.fileInfoLoaded=true;
  if (null != dis) {
    dis.close();
  }
  return fi;
}
