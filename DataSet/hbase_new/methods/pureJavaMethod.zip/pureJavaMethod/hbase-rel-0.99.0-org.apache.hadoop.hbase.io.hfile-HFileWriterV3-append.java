/** 
 * Add key/value to file. Keys must be added in an order that agrees with the Comparator passed on construction.
 * @param key Key to add. Cannot be empty nor null.
 * @param value Value to add. Cannot be empty nor null.
 * @param tag Tag t add. Cannot be empty or null.
 * @throws IOException
 */
@Override public void append(final byte[] key,final byte[] value,byte[] tag) throws IOException {
  int kvlen=(int)KeyValue.getKeyValueDataStructureSize(key.length,value.length,tag.length);
  byte[] b=new byte[kvlen];
  int pos=0;
  pos=Bytes.putInt(b,pos,key.length);
  pos=Bytes.putInt(b,pos,value.length);
  pos=Bytes.putBytes(b,pos,key,0,key.length);
  pos=Bytes.putBytes(b,pos,value,0,value.length);
  if (tag.length > 0) {
    pos=Bytes.putAsShort(b,pos,tag.length);
    Bytes.putBytes(b,pos,tag,0,tag.length);
  }
  append(new KeyValue(b,0,kvlen));
}
