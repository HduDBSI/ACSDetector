/** 
 * Construct a table:family:qualifier permission.
 * @param table table name
 * @param family family name
 * @param qualifier qualifier name
 * @param assigned assigned actions
 */
TablePermission(TableName table,byte[] family,byte[] qualifier,Action... assigned){
  super(assigned);
  this.table=table;
  this.family=family;
  this.qualifier=qualifier;
  this.scope=Scope.TABLE;
}
