public static ReplicationPeerConfig appendTableCFsToReplicationPeerConfig(Map<TableName,List<String>> tableCfs,ReplicationPeerConfig peerConfig){
  ReplicationPeerConfigBuilder builder=ReplicationPeerConfig.newBuilder(peerConfig);
  Map<TableName,List<String>> preTableCfs=peerConfig.getTableCFsMap();
  if (preTableCfs == null) {
    builder.setTableCFsMap(tableCfs);
  }
 else {
    builder.setTableCFsMap(mergeTableCFs(preTableCfs,tableCfs));
  }
  return builder.build();
}
