@BeforeClass public static void setupBeforeClass() throws Exception {
  util.getConfiguration().set(CoprocessorHost.REGION_COPROCESSOR_CONF_KEY,PingHandler.class.getName());
  util.startMiniCluster();
}
