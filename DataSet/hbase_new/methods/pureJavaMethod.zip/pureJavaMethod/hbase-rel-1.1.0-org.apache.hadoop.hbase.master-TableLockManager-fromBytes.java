/** 
 * Public for hbck 
 */
public static ZooKeeperProtos.TableLock fromBytes(byte[] bytes){
  int pblen=ProtobufUtil.lengthOfPBMagic();
  if (bytes == null || bytes.length < pblen) {
    return null;
  }
  try {
    ZooKeeperProtos.TableLock data=ZooKeeperProtos.TableLock.newBuilder().mergeFrom(bytes,pblen,bytes.length - pblen).build();
    return data;
  }
 catch (  InvalidProtocolBufferException ex) {
    LOG.warn("Exception in deserialization",ex);
  }
  return null;
}
