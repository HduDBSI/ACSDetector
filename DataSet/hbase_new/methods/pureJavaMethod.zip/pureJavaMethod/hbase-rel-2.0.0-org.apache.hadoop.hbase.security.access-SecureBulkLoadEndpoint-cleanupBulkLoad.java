@Override public void cleanupBulkLoad(RpcController controller,CleanupBulkLoadRequest request,RpcCallback<CleanupBulkLoadResponse> done){
  try {
    SecureBulkLoadManager secureBulkLoadManager=this.rsServices.getSecureBulkLoadManager();
    secureBulkLoadManager.cleanupBulkLoad((HRegion)this.env.getRegion(),convert(request));
    done.run(CleanupBulkLoadResponse.newBuilder().build());
  }
 catch (  IOException e) {
    CoprocessorRpcUtils.setControllerException(controller,e);
  }
  done.run(null);
}
