@Override public void write(Cell cell) throws IOException {
  checkFlushed();
  CellProtos.Cell.Builder builder=CellProtos.Cell.newBuilder();
  builder.setRow(ByteStringer.wrap(cell.getRowArray(),cell.getRowOffset(),cell.getRowLength()));
  builder.setFamily(ByteStringer.wrap(cell.getFamilyArray(),cell.getFamilyOffset(),cell.getFamilyLength()));
  builder.setQualifier(ByteStringer.wrap(cell.getQualifierArray(),cell.getQualifierOffset(),cell.getQualifierLength()));
  builder.setTimestamp(cell.getTimestamp());
  builder.setCellType(CellProtos.CellType.valueOf(cell.getTypeByte()));
  builder.setValue(ByteStringer.wrap(cell.getValueArray(),cell.getValueOffset(),cell.getValueLength()));
  CellProtos.Cell pbcell=builder.build();
  pbcell.writeDelimitedTo(this.out);
}
