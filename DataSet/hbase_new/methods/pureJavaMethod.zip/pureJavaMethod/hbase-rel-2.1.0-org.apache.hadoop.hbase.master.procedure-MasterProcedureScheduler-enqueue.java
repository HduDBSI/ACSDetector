@Override protected void enqueue(final Procedure proc,final boolean addFront){
  if (isMetaProcedure(proc)) {
    doAdd(metaRunQueue,getMetaQueue(),proc,addFront);
  }
 else   if (isTableProcedure(proc)) {
    doAdd(tableRunQueue,getTableQueue(getTableName(proc)),proc,addFront);
  }
 else   if (isServerProcedure(proc)) {
    ServerProcedureInterface spi=(ServerProcedureInterface)proc;
    doAdd(serverRunQueue,getServerQueue(spi.getServerName(),spi),proc,addFront);
  }
 else   if (isPeerProcedure(proc)) {
    doAdd(peerRunQueue,getPeerQueue(getPeerId(proc)),proc,addFront);
  }
 else {
    throw new UnsupportedOperationException("RQs for non-table/non-server procedures are not implemented yet: " + proc);
  }
}
