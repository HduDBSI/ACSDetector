/** 
 * Wake the procedures waiting for the specified namespace
 * @see #waitNamespaceExclusiveLock(Procedure,String)
 * @param procedure the procedure releasing the lock
 * @param namespace the namespace that has the exclusive lock
 */
public void wakeNamespaceExclusiveLock(final Procedure<?> procedure,final String namespace){
  schedLock();
  try {
    final LockAndQueue namespaceLock=locking.getNamespaceLock(namespace);
    final LockAndQueue systemNamespaceTableLock=locking.getTableLock(TableName.NAMESPACE_TABLE_NAME);
    int waitingCount=0;
    if (namespaceLock.releaseExclusiveLock(procedure)) {
      waitingCount+=wakeWaitingProcedures(namespaceLock);
    }
    if (systemNamespaceTableLock.releaseSharedLock()) {
      addToRunQueue(tableRunQueue,getTableQueue(TableName.NAMESPACE_TABLE_NAME),() -> procedure + " released namespace exclusive lock");
      waitingCount+=wakeWaitingProcedures(systemNamespaceTableLock);
    }
    wakePollIfNeeded(waitingCount);
  }
  finally {
    schedUnlock();
  }
}
