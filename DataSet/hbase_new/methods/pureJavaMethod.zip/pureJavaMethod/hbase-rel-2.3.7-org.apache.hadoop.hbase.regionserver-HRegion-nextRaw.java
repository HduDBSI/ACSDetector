@Override public boolean nextRaw(List<Cell> outResults,ScannerContext scannerContext) throws IOException {
  if (storeHeap == null) {
    throw new UnknownScannerException("Scanner was closed");
  }
  boolean moreValues=false;
  if (outResults.isEmpty()) {
    moreValues=nextInternal(outResults,scannerContext);
  }
 else {
    List<Cell> tmpList=new ArrayList<>();
    moreValues=nextInternal(tmpList,scannerContext);
    outResults.addAll(tmpList);
  }
  readRequestsCount.increment();
  if (metricsRegion != null) {
    metricsRegion.updateReadRequestCount();
  }
  if (!scannerContext.mayHaveMoreCellsInRow()) {
    resetFilters();
  }
  if (isFilterDoneInternal()) {
    moreValues=false;
  }
  return moreValues;
}
