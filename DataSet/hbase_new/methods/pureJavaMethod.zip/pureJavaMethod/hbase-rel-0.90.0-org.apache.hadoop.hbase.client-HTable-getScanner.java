@Override public ResultScanner getScanner(byte[] family,byte[] qualifier) throws IOException {
  Scan scan=new Scan();
  scan.addColumn(family,qualifier);
  return getScanner(scan);
}
