@Override public Cacheable getBlock(BlockCacheKey cacheKey,boolean caching,boolean repeat,boolean updateCacheMetrics){
  Cacheable value=cache.getIfPresent(cacheKey);
  if (value == null) {
    if (repeat) {
      return null;
    }
    if (updateCacheMetrics) {
      stats.miss(caching,cacheKey.isPrimary(),cacheKey.getBlockType());
    }
    if (victimCache != null) {
      value=victimCache.getBlock(cacheKey,caching,repeat,updateCacheMetrics);
      if ((value != null) && caching) {
        if ((value instanceof HFileBlock) && ((HFileBlock)value).isSharedMem()) {
          value=HFileBlock.deepCloneOnHeap((HFileBlock)value);
        }
        cacheBlock(cacheKey,value);
      }
    }
  }
 else   if (updateCacheMetrics) {
    stats.hit(caching,cacheKey.isPrimary(),cacheKey.getBlockType());
  }
  return value;
}
