@Override public MatchCode match(Cell cell) throws IOException {
  MatchCode returnCode=preCheck(cell);
  if (returnCode != null) {
    return returnCode;
  }
  long timestamp=cell.getTimestamp();
  long mvccVersion=cell.getSequenceId();
  byte typeByte=cell.getTypeByte();
  if (PrivateCellUtil.isDelete(typeByte)) {
    if (mvccVersion > maxReadPointToTrackVersions) {
      return MatchCode.INCLUDE;
    }
    trackDelete(cell);
    returnCode=tryDropDelete(cell);
    if (returnCode != null) {
      return returnCode;
    }
  }
 else {
    returnCode=checkDeleted(deletes,cell);
    if (returnCode != null) {
      return returnCode;
    }
  }
  return columns.checkVersions(cell,timestamp,typeByte,mvccVersion > maxReadPointToTrackVersions);
}
