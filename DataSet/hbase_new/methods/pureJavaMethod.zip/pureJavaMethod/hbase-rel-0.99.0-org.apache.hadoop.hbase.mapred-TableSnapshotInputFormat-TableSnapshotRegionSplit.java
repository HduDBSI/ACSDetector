public TableSnapshotRegionSplit(HTableDescriptor htd,HRegionInfo regionInfo,List<String> locations){
  this.delegate=new TableSnapshotInputFormatImpl.InputSplit(htd,regionInfo,locations);
}
