/** 
 * Constructor, allowing to define custom trust store (only for SSL connections)
 * @param cluster the cluster definition
 * @param trustStorePath custom trust store to use for SSL connections
 * @param trustStorePassword password to use for custom trust store
 * @param trustStoreType type of custom trust store
 * @throws ClientTrustStoreInitializationException if the trust store file can not be loaded
 */
public Client(Cluster cluster,String trustStorePath,Optional<String> trustStorePassword,Optional<String> trustStoreType){
  char[] password=trustStorePassword.map(String::toCharArray).orElse(null);
  String type=trustStoreType.orElse(KeyStore.getDefaultType());
  KeyStore trustStore;
  try (FileInputStream inputStream=new FileInputStream(new File(trustStorePath))){
    trustStore=KeyStore.getInstance(type);
    trustStore.load(inputStream,password);
  }
 catch (  KeyStoreException e) {
    throw new ClientTrustStoreInitializationException("Invalid trust store type: " + type,e);
  }
catch (  CertificateException|NoSuchAlgorithmException|IOException e) {
    throw new ClientTrustStoreInitializationException("Trust store load error: " + trustStorePath,e);
  }
  initialize(cluster,true,Optional.of(trustStore));
}
