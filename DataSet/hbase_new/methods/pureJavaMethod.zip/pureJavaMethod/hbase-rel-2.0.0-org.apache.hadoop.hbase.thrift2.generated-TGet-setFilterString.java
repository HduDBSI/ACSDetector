public TGet setFilterString(ByteBuffer filterString){
  this.filterString=org.apache.thrift.TBaseHelper.copyBinary(filterString);
  return this;
}
