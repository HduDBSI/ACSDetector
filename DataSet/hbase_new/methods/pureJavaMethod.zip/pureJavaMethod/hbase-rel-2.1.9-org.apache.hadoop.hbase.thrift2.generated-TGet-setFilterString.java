public TGet setFilterString(@org.apache.thrift.annotation.Nullable java.nio.ByteBuffer filterString){
  this.filterString=org.apache.thrift.TBaseHelper.copyBinary(filterString);
  return this;
}
