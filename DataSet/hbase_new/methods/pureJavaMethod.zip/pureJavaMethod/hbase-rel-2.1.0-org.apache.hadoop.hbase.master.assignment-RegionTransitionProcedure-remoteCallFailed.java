@Override public synchronized void remoteCallFailed(final MasterProcedureEnv env,final ServerName serverName,final IOException exception){
  final RegionStateNode regionNode=getRegionState(env);
  LOG.warn("Remote call failed {}; {}; {}; exception={}",serverName,this,regionNode.toShortString(),exception.getClass().getSimpleName());
  if (remoteCallFailed(env,regionNode,exception)) {
    regionNode.getProcedureEvent().wake(env.getProcedureScheduler());
  }
}
