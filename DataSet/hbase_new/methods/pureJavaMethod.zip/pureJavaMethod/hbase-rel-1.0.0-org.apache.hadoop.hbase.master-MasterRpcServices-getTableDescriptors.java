/** 
 * Get list of TableDescriptors for requested tables.
 * @param c Unused (set to null).
 * @param req GetTableDescriptorsRequest that contains:- tableNames: requested tables, or if empty, all are requested
 * @return GetTableDescriptorsResponse
 * @throws ServiceException
 */
@Override public GetTableDescriptorsResponse getTableDescriptors(RpcController c,GetTableDescriptorsRequest req) throws ServiceException {
  try {
    master.checkInitialized();
    final String regex=req.hasRegex() ? req.getRegex() : null;
    final String namespace=req.hasNamespace() ? req.getNamespace() : null;
    List<TableName> tableNameList=null;
    if (req.getTableNamesCount() > 0) {
      tableNameList=new ArrayList<TableName>(req.getTableNamesCount());
      for (      HBaseProtos.TableName tableNamePB : req.getTableNamesList()) {
        tableNameList.add(ProtobufUtil.toTableName(tableNamePB));
      }
    }
    List<HTableDescriptor> descriptors=master.listTableDescriptors(namespace,regex,tableNameList,req.getIncludeSysTables());
    GetTableDescriptorsResponse.Builder builder=GetTableDescriptorsResponse.newBuilder();
    if (descriptors != null && descriptors.size() > 0) {
      for (      HTableDescriptor htd : descriptors) {
        builder.addTableSchema(htd.convert());
      }
    }
    return builder.build();
  }
 catch (  IOException ioe) {
    throw new ServiceException(ioe);
  }
}
