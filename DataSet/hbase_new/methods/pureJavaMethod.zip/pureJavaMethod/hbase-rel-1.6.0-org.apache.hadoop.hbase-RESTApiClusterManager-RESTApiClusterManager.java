RESTApiClusterManager(){
  hBaseClusterManager=ReflectionUtils.newInstance(HBaseClusterManager.class,new IntegrationTestingUtility().getConfiguration());
}
