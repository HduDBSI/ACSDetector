@Override public int runTestFromCommandLine() throws Exception {
  Tool tool=null;
  if (toRun.equals("Generator")) {
    tool=new Generator();
  }
 else   if (toRun.equalsIgnoreCase("Verify")) {
    tool=new Verify();
  }
 else   if (toRun.equalsIgnoreCase("Loop")) {
    Loop loop=new Loop();
    loop.it=this;
    tool=loop;
  }
 else   if (toRun.equalsIgnoreCase("Walker")) {
    tool=new Walker();
  }
 else   if (toRun.equalsIgnoreCase("Print")) {
    tool=new Print();
  }
 else   if (toRun.equalsIgnoreCase("Delete")) {
    tool=new Delete();
  }
 else   if (toRun.equalsIgnoreCase("Clean")) {
    tool=new Clean();
  }
 else {
    usage();
    throw new RuntimeException("Unknown arg");
  }
  return ToolRunner.run(getConf(),tool,otherArgs);
}
