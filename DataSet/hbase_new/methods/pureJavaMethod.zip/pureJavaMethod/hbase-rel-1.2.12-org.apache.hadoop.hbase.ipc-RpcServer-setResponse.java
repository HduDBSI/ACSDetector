protected synchronized void setResponse(Object m,final CellScanner cells,Throwable t,String errorMsg){
  if (this.isError)   return;
  if (t != null)   this.isError=true;
  BufferChain bc=null;
  try {
    ResponseHeader.Builder headerBuilder=ResponseHeader.newBuilder();
    Message result=(Message)m;
    headerBuilder.setCallId(this.id);
    if (t != null) {
      ExceptionResponse.Builder exceptionBuilder=ExceptionResponse.newBuilder();
      exceptionBuilder.setExceptionClassName(t.getClass().getName());
      exceptionBuilder.setStackTrace(errorMsg);
      exceptionBuilder.setDoNotRetry(t instanceof DoNotRetryIOException || t instanceof NeedUnmanagedConnectionException);
      if (t instanceof RegionMovedException) {
        RegionMovedException rme=(RegionMovedException)t;
        exceptionBuilder.setHostname(rme.getHostname());
        exceptionBuilder.setPort(rme.getPort());
      }
      headerBuilder.setException(exceptionBuilder.build());
    }
    this.cellBlock=ipcUtil.buildCellBlock(this.connection.codec,this.connection.compressionCodec,cells,reservoir);
    if (this.cellBlock != null) {
      CellBlockMeta.Builder cellBlockBuilder=CellBlockMeta.newBuilder();
      cellBlockBuilder.setLength(this.cellBlock.limit());
      headerBuilder.setCellBlockMeta(cellBlockBuilder.build());
    }
    Message header=headerBuilder.build();
    ByteBuffer bbHeader=IPCUtil.getDelimitedMessageAsByteBuffer(header);
    ByteBuffer bbResult=IPCUtil.getDelimitedMessageAsByteBuffer(result);
    int totalSize=bbHeader.capacity() + (bbResult == null ? 0 : bbResult.limit()) + (this.cellBlock == null ? 0 : this.cellBlock.limit());
    ByteBuffer bbTotalSize=ByteBuffer.wrap(Bytes.toBytes(totalSize));
    bc=new BufferChain(bbTotalSize,bbHeader,bbResult,this.cellBlock);
    if (connection.useWrap) {
      bc=wrapWithSasl(bc);
    }
  }
 catch (  IOException e) {
    LOG.warn("Exception while creating response " + e);
  }
  this.response=bc;
}
