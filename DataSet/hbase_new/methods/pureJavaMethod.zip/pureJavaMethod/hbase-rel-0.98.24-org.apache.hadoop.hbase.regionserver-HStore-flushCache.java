@Override public void flushCache(MonitoredTask status) throws IOException {
  tempFiles=HStore.this.flushCache(cacheFlushSeqNum,snapshot,snapshotTimeRangeTracker,flushedSize,status);
}
