public MetaServerShutdownHandler(final Server server,final MasterServices services,final DeadServer deadServers,final ServerName serverName,final boolean carryingRoot,final boolean carryingMeta){
  super(server,services,deadServers,serverName,EventType.M_META_SERVER_SHUTDOWN,true);
  this.carryingRoot=carryingRoot;
  this.carryingMeta=carryingMeta;
}
