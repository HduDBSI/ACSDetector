@Test public void testPostGrantRevokeAtQualifierLevel() throws Exception {
  final TableName tableName=TableName.valueOf("testGrantRevokeAtQualifierLevel");
  final byte[] family1=Bytes.toBytes("f1");
  final byte[] family2=Bytes.toBytes("f2");
  final byte[] qualifier=Bytes.toBytes("q");
  HBaseAdmin admin=TEST_UTIL.getHBaseAdmin();
  if (admin.tableExists(tableName)) {
    admin.disableTable(tableName);
    admin.deleteTable(tableName);
  }
  HTableDescriptor htd=new HTableDescriptor(tableName);
  htd.addFamily(new HColumnDescriptor(family1));
  htd.addFamily(new HColumnDescriptor(family2));
  admin.createTable(htd);
  TEST_UTIL.waitUntilAllRegionsAssigned(tableName);
  try {
    User user=User.createUserForTesting(TEST_UTIL.getConfiguration(),"user",new String[0]);
    AccessTestAction getQualifierAction=new AccessTestAction(){
      @Override public Object run() throws Exception {
        Get g=new Get(TEST_ROW);
        g.addColumn(family1,qualifier);
        HTable t=new HTable(conf,tableName);
        try {
          t.get(g);
        }
  finally {
          t.close();
        }
        return null;
      }
    }
;
    AccessTestAction putQualifierAction=new AccessTestAction(){
      @Override public Object run() throws Exception {
        Put p=new Put(TEST_ROW);
        p.add(family1,qualifier,Bytes.toBytes("v1"));
        HTable t=new HTable(conf,tableName);
        try {
          t.put(p);
        }
  finally {
          t.close();
        }
        return null;
      }
    }
;
    AccessTestAction deleteQualifierAction=new AccessTestAction(){
      @Override public Object run() throws Exception {
        Delete d=new Delete(TEST_ROW);
        d.deleteColumn(family1,qualifier);
        HTable t=new HTable(conf,tableName);
        try {
          t.delete(d);
        }
  finally {
          t.close();
        }
        return null;
      }
    }
;
    revokeFromTable(TEST_UTIL,user.getShortName(),tableName,family1,null);
    verifyDenied(user,getQualifierAction);
    verifyDenied(user,putQualifierAction);
    verifyDenied(user,deleteQualifierAction);
    grantOnTable(TEST_UTIL,user.getShortName(),tableName,family1,qualifier,Permission.Action.READ);
    verifyAllowed(user,getQualifierAction);
    verifyDenied(user,putQualifierAction);
    verifyDenied(user,deleteQualifierAction);
    grantOnTable(TEST_UTIL,user.getShortName(),tableName,family1,qualifier,Permission.Action.WRITE);
    verifyDenied(user,getQualifierAction);
    verifyAllowed(user,putQualifierAction);
    verifyAllowed(user,deleteQualifierAction);
    grantOnTable(TEST_UTIL,user.getShortName(),tableName,family1,qualifier,Permission.Action.READ,Permission.Action.WRITE);
    verifyAllowed(user,getQualifierAction);
    verifyAllowed(user,putQualifierAction);
    verifyAllowed(user,deleteQualifierAction);
    revokeFromTable(TEST_UTIL,user.getShortName(),tableName,family1,qualifier);
    verifyDenied(user,getQualifierAction);
    verifyDenied(user,putQualifierAction);
    verifyDenied(user,deleteQualifierAction);
    admin.disableTable(tableName);
    admin.deleteTable(tableName);
  }
  finally {
    try {
      TEST_UTIL.deleteTable(tableName);
    }
 catch (    IOException ignore) {
      LOG.debug("Failed to delete table in cleanup. May be already deleted.");
    }
  }
}
