/** 
 * Do compression if it is enabled, or re-use the uncompressed buffer if it is not. Fills in the compressed block's header if doing compression. Also, compute the checksums. In the case of no-compression, write the checksums to its own seperate data structure called onDiskChecksum. In the case when compression is enabled, the checksums are written to the outputbyte stream 'baos'.
 */
private void doCompressionAndChecksumming() throws IOException {
  if (minorVersion <= MINOR_VERSION_NO_CHECKSUM) {
    version20compression();
  }
 else {
    version21ChecksumAndCompression();
  }
}
