Writer(AtomicBoolean finished,MultiVersionConcurrencyControl mvcc,AtomicBoolean status){
  this.finished=finished;
  this.mvcc=mvcc;
  this.status=status;
}
