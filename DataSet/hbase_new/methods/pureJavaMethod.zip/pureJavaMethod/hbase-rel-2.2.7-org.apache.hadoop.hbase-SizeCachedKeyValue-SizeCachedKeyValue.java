public SizeCachedKeyValue(byte[] bytes,int offset,int length,long seqId,int keyLen,short rowLen){
  super(bytes,offset,length);
  this.rowLen=rowLen;
  this.keyLen=keyLen;
  setSequenceId(seqId);
}
