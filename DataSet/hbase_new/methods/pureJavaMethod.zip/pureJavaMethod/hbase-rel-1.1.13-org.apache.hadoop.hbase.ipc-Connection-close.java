protected synchronized void close(){
  disposeSasl();
  data=null;
  if (!channel.isOpen())   return;
  try {
    socket.shutdownOutput();
  }
 catch (  Exception ignored) {
  }
  if (channel.isOpen()) {
    try {
      channel.close();
    }
 catch (    Exception ignored) {
    }
  }
  try {
    socket.close();
  }
 catch (  Exception ignored) {
  }
}
