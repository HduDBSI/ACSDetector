/** 
 * @param currentRowCell
 * @return true when the joined heap may have data for the current row
 * @throws IOException
 */
private boolean joinedHeapMayHaveData(Cell currentRowCell) throws IOException {
  Cell nextJoinedKv=joinedHeap.peek();
  boolean matchCurrentRow=nextJoinedKv != null && CellUtil.matchingRows(nextJoinedKv,currentRowCell);
  boolean matchAfterSeek=false;
  if (!matchCurrentRow) {
    Cell firstOnCurrentRow=PrivateCellUtil.createFirstOnRow(currentRowCell);
    boolean seekSuccessful=this.joinedHeap.requestSeek(firstOnCurrentRow,true,true);
    matchAfterSeek=seekSuccessful && joinedHeap.peek() != null && CellUtil.matchingRows(joinedHeap.peek(),currentRowCell);
  }
  return matchCurrentRow || matchAfterSeek;
}
