private void add(final List<String> servers) throws IOException {
synchronized (this.regionServers) {
    this.regionServers.clear();
    for (    String n : servers) {
      ServerName sn=ServerName.parseServerName(ZKUtil.getNodeName(n));
      if (regionServers.get(sn) == null) {
        RegionServerInfo.Builder rsInfoBuilder=RegionServerInfo.newBuilder();
        try {
          String nodePath=ZKUtil.joinZNode(watcher.rsZNode,n);
          byte[] data=ZKUtil.getData(watcher,nodePath);
          LOG.info("Added tracking of RS " + nodePath);
          if (data != null && data.length > 0 && ProtobufUtil.isPBMagicPrefix(data)) {
            int magicLen=ProtobufUtil.lengthOfPBMagic();
            rsInfoBuilder.mergeFrom(data,magicLen,data.length - magicLen);
          }
        }
 catch (        KeeperException e) {
          LOG.warn("Get Rs info port from ephemeral node",e);
        }
catch (        IOException e) {
          LOG.warn("Illegal data from ephemeral node",e);
        }
        this.regionServers.put(sn,rsInfoBuilder.build());
      }
    }
  }
}
