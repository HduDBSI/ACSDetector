@Override protected void chore(){
  if (this.bulkAssign)   return;
  boolean allRSsOffline=this.serverManager.getOnlineServersList().isEmpty();
  List<HRegionInfo> unassigns=new ArrayList<HRegionInfo>();
  Map<HRegionInfo,Boolean> assigns=new HashMap<HRegionInfo,Boolean>();
synchronized (regionsInTransition) {
    long now=System.currentTimeMillis();
    for (    RegionState regionState : regionsInTransition.values()) {
      HRegionInfo regionInfo=regionState.getRegion();
      if (regionState.getStamp() + timeout <= now) {
        actOnTimeOut(unassigns,assigns,regionState,regionInfo);
      }
 else       if (this.allRegionServersOffline && !allRSsOffline) {
        actOnTimeOut(unassigns,assigns,regionState,regionInfo);
      }
    }
  }
  setAllRegionServersOffline(allRSsOffline);
  for (  HRegionInfo hri : unassigns) {
    unassign(hri,true);
  }
  for (  Map.Entry<HRegionInfo,Boolean> e : assigns.entrySet()) {
    assign(e.getKey(),false,e.getValue());
  }
}
