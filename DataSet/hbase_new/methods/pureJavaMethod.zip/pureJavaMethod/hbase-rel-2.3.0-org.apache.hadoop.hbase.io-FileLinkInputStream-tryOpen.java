/** 
 * Try to open the file from one of the available locations.
 * @return FSDataInputStream stream of the opened file link
 * @throws IOException on unexpected error, or file not found.
 */
private FSDataInputStream tryOpen() throws IOException {
  IOException exception=null;
  for (  Path path : fileLink.getLocations()) {
    if (path.equals(currentPath))     continue;
    try {
      in=fs.open(path,bufferSize);
      if (pos != 0)       in.seek(pos);
      assert (in.getPos() == pos) : "Link unable to seek to the right position=" + pos;
      if (LOG.isTraceEnabled()) {
        if (currentPath == null) {
          LOG.debug("link open path=" + path);
        }
 else {
          LOG.trace("link switch from path=" + currentPath + " to path="+ path);
        }
      }
      currentPath=path;
      return (in);
    }
 catch (    FileNotFoundException|AccessControlException|RemoteException e) {
      exception=FileLink.handleAccessLocationException(fileLink,e,exception);
    }
  }
  throw exception;
}
