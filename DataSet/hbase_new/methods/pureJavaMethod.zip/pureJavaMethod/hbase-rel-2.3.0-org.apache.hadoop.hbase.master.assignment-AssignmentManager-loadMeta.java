private void loadMeta() throws IOException {
  regionStateStore.visitMeta(new RegionMetaLoadingVisitor());
  wakeMetaLoadedEvent();
}
