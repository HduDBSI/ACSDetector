/** 
 * Take the list of the connections that want to write, and register them in the selector.
 */
private void registerWrites(){
  Iterator<Connection> it=writingCons.iterator();
  while (it.hasNext()) {
    Connection c=it.next();
    it.remove();
    SelectionKey sk=c.channel.keyFor(writeSelector);
    if (sk == null) {
      try {
        c.channel.register(writeSelector,SelectionKey.OP_WRITE,c);
      }
 catch (      ClosedChannelException e) {
      }
    }
 else {
      sk.interestOps(SelectionKey.OP_WRITE);
    }
  }
}
