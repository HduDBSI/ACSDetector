public void dumpSidelinedRegions(Map<Path,HbckInfo> regions){
  for (  Path k : regions.keySet()) {
    System.out.println("To be bulk loaded sidelined region dir: " + k.toString());
  }
}
