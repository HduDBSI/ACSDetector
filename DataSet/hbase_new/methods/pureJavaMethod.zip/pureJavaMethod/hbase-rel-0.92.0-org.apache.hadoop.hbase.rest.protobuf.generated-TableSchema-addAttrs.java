public Builder addAttrs(int index,org.apache.hadoop.hbase.rest.protobuf.generated.TableSchemaMessage.TableSchema.Attribute.Builder builderForValue){
  if (attrsBuilder_ == null) {
    ensureAttrsIsMutable();
    attrs_.add(index,builderForValue.build());
    onChanged();
  }
 else {
    attrsBuilder_.addMessage(index,builderForValue.build());
  }
  return this;
}
