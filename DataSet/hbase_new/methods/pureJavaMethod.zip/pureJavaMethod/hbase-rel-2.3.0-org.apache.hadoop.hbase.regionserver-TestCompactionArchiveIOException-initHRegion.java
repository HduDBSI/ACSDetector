private HRegion initHRegion(TableDescriptor htd,RegionInfo info) throws IOException {
  Configuration conf=testUtil.getConfiguration();
  ChunkCreator.initialize(MemStoreLABImpl.CHUNK_SIZE_DEFAULT,false,0,0,0,null);
  Path tableDir=CommonFSUtils.getTableDir(testDir,htd.getTableName());
  Path regionDir=new Path(tableDir,info.getEncodedName());
  Path storeDir=new Path(regionDir,htd.getColumnFamilies()[0].getNameAsString());
  FileSystem errFS=spy(testUtil.getTestFileSystem());
  doThrow(new IOException("Error for test")).when(errFS).rename(eq(new Path(storeDir,ERROR_FILE)),any());
  HRegionFileSystem fs=new HRegionFileSystem(conf,errFS,tableDir,info);
  final Configuration walConf=new Configuration(conf);
  CommonFSUtils.setRootDir(walConf,tableDir);
  final WALFactory wals=new WALFactory(walConf,"log_" + info.getEncodedName());
  HRegion region=new HRegion(fs,wals.getWAL(info),conf,htd,null);
  region.initialize();
  return region;
}
