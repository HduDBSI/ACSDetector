private synchronized void refresh(){
  List<String> names;
  try {
    names=ZKUtil.listChildrenAndWatchForNewChildren(watcher,watcher.getZNodePaths().rsZNode);
  }
 catch (  KeeperException e) {
    server.abort("Unexpected zk exception getting RS nodes",e);
    return;
  }
  Set<ServerName> servers=names.stream().map(ServerName::parseServerName).collect(Collectors.toSet());
  for (Iterator<ServerName> iter=regionServers.iterator(); iter.hasNext(); ) {
    ServerName sn=iter.next();
    if (!servers.contains(sn)) {
      LOG.info("RegionServer ephemeral node deleted, processing expiration [{}]",sn);
      serverManager.expireServer(sn);
      iter.remove();
    }
  }
  boolean newServerAdded=false;
  for (  ServerName sn : servers) {
    if (regionServers.add(sn)) {
      newServerAdded=true;
      LOG.info("RegionServer ephemeral node created, adding [" + sn + "]");
    }
  }
  if (newServerAdded && server.isInitialized()) {
    server.checkIfShouldMoveSystemRegionAsync();
  }
}
