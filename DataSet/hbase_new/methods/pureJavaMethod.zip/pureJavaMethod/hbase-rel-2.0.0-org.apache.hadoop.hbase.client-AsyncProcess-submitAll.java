/** 
 * Submit immediately the list of rows, whatever the server status. Kept for backward compatibility: it allows to be used with the batch interface that return an array of objects.
 * @param task The setting and data
 */
private <CResult>AsyncRequestFuture submitAll(AsyncProcessTask task){
  RowAccess<? extends Row> rows=task.getRowAccess();
  List<Action> actions=new ArrayList<>(rows.size());
  int posInList=-1;
  NonceGenerator ng=this.connection.getNonceGenerator();
  int highestPriority=HConstants.PRIORITY_UNSET;
  for (  Row r : rows) {
    posInList++;
    if (r instanceof Put) {
      Put put=(Put)r;
      if (put.isEmpty()) {
        throw new IllegalArgumentException("No columns to insert for #" + (posInList + 1) + " item");
      }
      highestPriority=Math.max(put.getPriority(),highestPriority);
    }
    Action action=new Action(r,posInList,highestPriority);
    setNonce(ng,r,action);
    actions.add(action);
  }
  AsyncRequestFutureImpl<CResult> ars=createAsyncRequestFuture(task,actions,ng.getNonceGroup());
  ars.groupAndSendMultiAction(actions,1);
  return ars;
}
