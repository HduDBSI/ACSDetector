/** 
 * Called when a new Coprocessor class is loaded
 */
public abstract E createEnvironment(Class<?> implClass,Coprocessor instance,int priority,int sequence,Configuration conf);
