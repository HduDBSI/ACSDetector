/** 
 * This function returns region server name from a log file name which is in one of the following formats: <ul> <li>hdfs://&lt;name node&gt;/hbase/.logs/&lt;server name&gt;-splitting/...</li> <li>hdfs://&lt;name node&gt;/hbase/.logs/&lt;server name&gt;/...</li> </ul>
 * @param logFile
 * @return null if the passed in logFile isn't a valid WAL file path
 */
public static ServerName getServerNameFromWALDirectoryName(Path logFile){
  String logDirName=logFile.getParent().getName();
  if (logDirName.equals(HConstants.HREGION_LOGDIR_NAME)) {
    logDirName=logFile.getName();
  }
  ServerName serverName=null;
  if (logDirName.endsWith(SPLITTING_EXT)) {
    logDirName=logDirName.substring(0,logDirName.length() - SPLITTING_EXT.length());
  }
  try {
    serverName=ServerName.parseServerName(logDirName);
  }
 catch (  IllegalArgumentException ex) {
    serverName=null;
    LOG.warn("Cannot parse a server name from path=" + logFile + "; "+ ex.getMessage());
  }
  if (serverName != null && serverName.getStartcode() < 0) {
    LOG.warn("Invalid log file path=" + logFile);
    serverName=null;
  }
  return serverName;
}
