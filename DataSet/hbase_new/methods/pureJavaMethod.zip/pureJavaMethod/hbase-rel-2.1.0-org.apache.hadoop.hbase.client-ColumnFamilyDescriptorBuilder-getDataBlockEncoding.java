@Override public DataBlockEncoding getDataBlockEncoding(){
  return getStringOrDefault(DATA_BLOCK_ENCODING_BYTES,DataBlockEncoding::valueOf,DataBlockEncoding.NONE);
}
