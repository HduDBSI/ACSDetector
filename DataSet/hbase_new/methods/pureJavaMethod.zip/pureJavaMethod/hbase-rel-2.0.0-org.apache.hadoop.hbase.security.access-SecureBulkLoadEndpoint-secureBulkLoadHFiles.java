@Override public void secureBulkLoadHFiles(RpcController controller,SecureBulkLoadHFilesRequest request,RpcCallback<SecureBulkLoadHFilesResponse> done){
  boolean loaded=false;
  Map<byte[],List<Path>> map=null;
  try {
    SecureBulkLoadManager secureBulkLoadManager=this.rsServices.getSecureBulkLoadManager();
    BulkLoadHFileRequest bulkLoadHFileRequest=ConvertSecureBulkLoadHFilesRequest(request);
    map=secureBulkLoadManager.secureBulkLoadHFiles((HRegion)this.env.getRegion(),convert(bulkLoadHFileRequest));
    loaded=map != null && !map.isEmpty();
  }
 catch (  IOException e) {
    CoprocessorRpcUtils.setControllerException(controller,e);
  }
  done.run(SecureBulkLoadHFilesResponse.newBuilder().setLoaded(loaded).build());
}
