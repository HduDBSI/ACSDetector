public static void initAndStartWorkers(ProcedureExecutor<?> procExecutor,int numThreads,boolean abortOnCorruption,boolean startWorkers) throws IOException {
  procExecutor.init(numThreads,abortOnCorruption);
  if (startWorkers) {
    procExecutor.startWorkers();
  }
}
