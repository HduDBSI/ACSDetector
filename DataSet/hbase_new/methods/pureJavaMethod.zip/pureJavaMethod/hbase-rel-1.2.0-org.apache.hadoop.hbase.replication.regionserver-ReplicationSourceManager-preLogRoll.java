void preLogRoll(Path newLog) throws IOException {
  recordLog(newLog);
  String logName=newLog.getName();
  String logPrefix=DefaultWALProvider.getWALPrefixFromWALName(logName);
synchronized (latestPaths) {
    Iterator<Path> iterator=latestPaths.iterator();
    while (iterator.hasNext()) {
      Path path=iterator.next();
      if (path.getName().contains(logPrefix)) {
        iterator.remove();
        break;
      }
    }
    this.latestPaths.add(newLog);
  }
}
