public void setFieldValue(_Fields field,@org.apache.thrift.annotation.Nullable java.lang.Object value){
switch (field) {
case TABLE_NAME:
    if (value == null) {
      unsetTableName();
    }
 else {
      if (value instanceof byte[]) {
        setTableName((byte[])value);
      }
 else {
        setTableName((java.nio.ByteBuffer)value);
      }
    }
  break;
case SCAN:
if (value == null) {
  unsetScan();
}
 else {
  setScan((TScan)value);
}
break;
case ATTRIBUTES:
if (value == null) {
unsetAttributes();
}
 else {
setAttributes((java.util.Map<java.nio.ByteBuffer,java.nio.ByteBuffer>)value);
}
break;
}
}
