/** 
 * See  {@link ClientTokenUtil#toToken(org.apache.hadoop.security.token.Token)}.
 * @deprecated External users should not use this method. Please post onthe HBase dev mailing list if you need this method. Internal HBase code should use  {@link ClientTokenUtil} instead.
 */
@Deprecated public static Token<AuthenticationTokenIdentifier> toToken(AuthenticationProtos.Token proto){
  return ClientTokenUtil.toToken(proto);
}
