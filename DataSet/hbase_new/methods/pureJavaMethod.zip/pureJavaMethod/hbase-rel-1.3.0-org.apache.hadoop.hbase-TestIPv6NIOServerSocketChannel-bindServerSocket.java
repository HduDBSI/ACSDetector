/** 
 * Creates and binds a regular ServerSocket.
 */
private void bindServerSocket(InetAddress inetAddr) throws IOException {
  while (true) {
    int port=HBaseTestingUtility.randomFreePort();
    InetSocketAddress addr=new InetSocketAddress(inetAddr,port);
    ServerSocket serverSocket=null;
    try {
      serverSocket=new ServerSocket();
      serverSocket.bind(addr);
      break;
    }
 catch (    BindException ex) {
    }
 finally {
      if (serverSocket != null) {
        serverSocket.close();
      }
    }
  }
}
