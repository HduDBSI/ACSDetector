@Override public int compareTo(HRegionInfo o){
  if (o == null) {
    return 1;
  }
  int result=this.tableName.compareTo(o.tableName);
  if (result != 0) {
    return result;
  }
  result=Bytes.compareTo(this.startKey,o.startKey);
  if (result != 0) {
    return result;
  }
  result=Bytes.compareTo(this.endKey,o.endKey);
  if (result != 0) {
    if (this.getStartKey().length != 0 && this.getEndKey().length == 0) {
      return 1;
    }
    if (o.getStartKey().length != 0 && o.getEndKey().length == 0) {
      return -1;
    }
    return result;
  }
  if (this.regionId > o.regionId) {
    return 1;
  }
 else   if (this.regionId < o.regionId) {
    return -1;
  }
  int replicaDiff=this.getReplicaId() - o.getReplicaId();
  if (replicaDiff != 0)   return replicaDiff;
  if (this.offLine == o.offLine)   return 0;
  if (this.offLine == true)   return -1;
  return 1;
}
