/** 
 * Add updates first to the hlog (if writeToWal) and then add values to memstore. Warning: Assumption is caller has lock on passed in row.
 * @param familyMap map of family to edits for the given family.
 * @param writeToWAL if true, then we should write to the log
 * @throws IOException
 */
private void put(final Map<byte[],List<KeyValue>> familyMap,boolean writeToWAL) throws IOException {
  long now=EnvironmentEdgeManager.currentTimeMillis();
  byte[] byteNow=Bytes.toBytes(now);
  boolean flush=false;
  this.updatesLock.readLock().lock();
  try {
    checkFamilies(familyMap.keySet());
    updateKVTimestamps(familyMap.values(),byteNow);
    if (writeToWAL) {
      WALEdit walEdit=new WALEdit();
      addFamilyMapToWALEdit(familyMap,walEdit);
      this.log.append(regionInfo,regionInfo.getTableDesc().getName(),walEdit,now);
    }
    long addedSize=applyFamilyMapToMemstore(familyMap);
    flush=isFlushSize(memstoreSize.addAndGet(addedSize));
  }
  finally {
    this.updatesLock.readLock().unlock();
  }
  if (flush) {
    requestFlush();
  }
}
