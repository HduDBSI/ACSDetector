/** 
 * An optional interface to 'size' writables.
 */
public interface WritableWithSize {
  /** 
 * Provide a size hint to the caller. write() should ideally not go beyond this if at all possible. You can return 0 if there is no size hint.
 * @return the size of the writable
 */
  public long getWritableSize();
}
