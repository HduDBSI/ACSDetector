static class MockStoreFile extends StoreFile {
  long length=0;
  boolean isRef=false;
  TimeRangeTracker timeRangeTracker;
  long entryCount;
  MockStoreFile(  long length,  boolean isRef) throws IOException {
    super(TEST_UTIL.getTestFileSystem(),TEST_FILE,TEST_UTIL.getConfiguration(),new CacheConfig(TEST_UTIL.getConfiguration()),BloomType.NONE,NoOpDataBlockEncoder.INSTANCE);
    this.length=length;
    this.isRef=isRef;
  }
  void setLength(  long newLen){
    this.length=newLen;
  }
  @Override boolean isMajorCompaction(){
    return false;
  }
  @Override boolean isReference(){
    return this.isRef;
  }
  void setTimeRangeTracker(  TimeRangeTracker timeRangeTracker){
    this.timeRangeTracker=timeRangeTracker;
  }
  void setEntries(  long entryCount){
    this.entryCount=entryCount;
  }
  @Override public StoreFile.Reader getReader(){
    final long len=this.length;
    final TimeRangeTracker timeRange=this.timeRangeTracker;
    final long entries=this.entryCount;
    return new StoreFile.Reader(){
      @Override public long length(){
        return len;
      }
      @Override public long getMaxTimestamp(){
        return timeRange == null ? Long.MAX_VALUE : timeRange.maximumTimestamp;
      }
      @Override public long getEntries(){
        return entries;
      }
    }
;
  }
}
