/** 
 * Tool for reading ZooKeeper servers from HBase XML configuration and producing a line-by-line list for use by bash scripts.
 */
@InterfaceAudience.Public @InterfaceStability.Evolving public class ZKServerTool {
  public static ServerName[] readZKNodes(  Configuration conf){
    List<ServerName> hosts=new LinkedList<ServerName>();
    Properties zkProps=ZKConfig.makeZKProps(conf);
    for (    Entry<Object,Object> entry : zkProps.entrySet()) {
      String key=entry.getKey().toString().trim();
      String value=entry.getValue().toString().trim();
      if (key.startsWith("server.")) {
        String[] parts=value.split(":");
        String host=parts[0];
        int port=HConstants.DEFAULT_ZOOKEPER_CLIENT_PORT;
        if (parts.length > 1) {
          port=Integer.parseInt(parts[1]);
        }
        hosts.add(ServerName.valueOf(host,port,-1));
      }
    }
    return hosts.toArray(new ServerName[hosts.size()]);
  }
  /** 
 * Run the tool.
 * @param args Command line arguments.
 */
  public static void main(  String args[]){
    for (    ServerName server : readZKNodes(HBaseConfiguration.create())) {
      System.out.println("ZK host: " + server.getHostname());
    }
  }
}
