static class ZookeeperStub extends ZooKeeper {
  private int throwExceptionInNumOperations;
  ZookeeperStub(  String connectString,  int sessionTimeout,  Watcher watcher) throws IOException {
    super(connectString,sessionTimeout,watcher);
  }
  void setThrowExceptionInNumOperations(  int throwExceptionInNumOperations){
    this.throwExceptionInNumOperations=throwExceptionInNumOperations;
  }
  private void checkThrowKeeperException() throws KeeperException {
    if (throwExceptionInNumOperations == 1) {
      throwExceptionInNumOperations=0;
      throw new KeeperException.ConnectionLossException();
    }
    if (throwExceptionInNumOperations > 0) {
      throwExceptionInNumOperations--;
    }
  }
  @Override public Stat setData(  String path,  byte[] data,  int version) throws KeeperException, InterruptedException {
    Stat stat=super.setData(path,data,version);
    checkThrowKeeperException();
    return stat;
  }
}
