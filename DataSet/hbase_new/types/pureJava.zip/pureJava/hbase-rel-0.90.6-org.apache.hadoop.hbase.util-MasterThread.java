/** 
 * Datastructure to hold Master Thread and Master instance
 */
public static class MasterThread extends Thread {
  private final HMaster master;
  public MasterThread(  final HMaster m,  final int index){
    super(m,"Master:" + index + ";"+ m.getServerName());
    this.master=m;
  }
  /** 
 * @return the master 
 */
  public HMaster getMaster(){
    return this.master;
  }
  /** 
 * Block until the master has come online, indicating it is ready to be used.
 */
  public void waitForServerOnline(){
    while (!this.master.isMasterRunning() && !this.master.isStopped()) {
      try {
        Thread.sleep(1000);
      }
 catch (      InterruptedException e) {
      }
    }
  }
}
