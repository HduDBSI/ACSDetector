/** 
 * Flush cache upon request 
 */
class Flusher extends Thread implements CacheFlushListener {
  private final DelayQueue<QueueEntry> flushQueue=new DelayQueue<QueueEntry>();
  private final long optionalFlushPeriod;
  /** 
 * constructor 
 */
  public Flusher(){
    super();
    this.optionalFlushPeriod=conf.getLong("hbase.regionserver.optionalcacheflushinterval",30 * 60 * 1000L);
  }
  /** 
 * {@inheritDoc} 
 */
  @Override public void run(){
    while (!stopRequested.get()) {
      QueueEntry e=null;
      try {
        e=flushQueue.poll(threadWakeFrequency,TimeUnit.MILLISECONDS);
        if (e == null) {
          continue;
        }
synchronized (cacheFlusherLock) {
          if (e.getRegion().flushcache()) {
            compactSplitThread.compactionRequested(e);
          }
          e.setExpirationTime(System.currentTimeMillis() + optionalFlushPeriod);
          flushQueue.add(e);
        }
        Set<HRegion> regions=getRegionsToCheck();
        for (        HRegion r : regions) {
          e=new QueueEntry(r,r.getLastFlushTime() + optionalFlushPeriod);
synchronized (flushQueue) {
            if (!flushQueue.contains(e)) {
              flushQueue.add(e);
            }
          }
        }
synchronized (flushQueue) {
          for (Iterator<QueueEntry> i=flushQueue.iterator(); i.hasNext(); ) {
            e=i.next();
            if (!regions.contains(e.getRegion())) {
              i.remove();
            }
          }
        }
      }
 catch (      InterruptedException ex) {
        continue;
      }
catch (      ConcurrentModificationException ex) {
        continue;
      }
catch (      DroppedSnapshotException ex) {
        LOG.fatal("Replay of hlog required. Forcing server restart",ex);
        if (!checkFileSystem()) {
          break;
        }
        HRegionServer.this.stop();
      }
catch (      IOException ex) {
        LOG.error("Cache flush failed" + (e != null ? (" for region " + e.getRegion().getRegionName()) : ""),RemoteExceptionHandler.checkIOException(ex));
        if (!checkFileSystem()) {
          break;
        }
      }
catch (      Exception ex) {
        LOG.error("Cache flush failed" + (e != null ? (" for region " + e.getRegion().getRegionName()) : ""),ex);
        if (!checkFileSystem()) {
          break;
        }
      }
    }
    flushQueue.clear();
    LOG.info(getName() + " exiting");
  }
  /** 
 * {@inheritDoc} 
 */
  public void flushRequested(  HRegion region){
    if (region == null) {
      return;
    }
    QueueEntry e=new QueueEntry(region,System.currentTimeMillis());
synchronized (flushQueue) {
      if (flushQueue.contains(e)) {
        flushQueue.remove(e);
      }
      flushQueue.add(e);
    }
  }
}
