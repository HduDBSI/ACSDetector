public abstract class AbstractTestShell {
  protected final static HBaseTestingUtility TEST_UTIL=new HBaseTestingUtility();
  protected final static ScriptingContainer jruby=new ScriptingContainer();
  @BeforeClass public static void setUpBeforeClass() throws Exception {
    TEST_UTIL.getConfiguration().setInt("hbase.regionserver.msginterval",100);
    TEST_UTIL.getConfiguration().setInt("hbase.client.pause",250);
    TEST_UTIL.getConfiguration().setBoolean("hbase.quota.enabled",true);
    TEST_UTIL.getConfiguration().setInt(HConstants.HBASE_CLIENT_RETRIES_NUMBER,6);
    TEST_UTIL.getConfiguration().setBoolean(CoprocessorHost.ABORT_ON_ERROR_KEY,false);
    TEST_UTIL.getConfiguration().setInt("hfile.format.version",3);
    TEST_UTIL.getConfiguration().setInt(HConstants.MASTER_INFO_PORT,0);
    TEST_UTIL.getConfiguration().setInt(HConstants.REGIONSERVER_INFO_PORT,0);
    TEST_UTIL.getConfiguration().setBoolean(HConstants.REGIONSERVER_INFO_PORT_AUTO,true);
    SecureTestUtil.enableSecurity(TEST_UTIL.getConfiguration());
    VisibilityTestUtil.enableVisiblityLabels(TEST_UTIL.getConfiguration());
    TEST_UTIL.startMiniCluster();
    List<String> loadPaths=new ArrayList<>(2);
    loadPaths.add("src/main/ruby");
    loadPaths.add("src/test/ruby");
    jruby.setLoadPaths(loadPaths);
    jruby.put("$TEST_CLUSTER",TEST_UTIL);
    System.setProperty("jruby.jit.logging.verbose","true");
    System.setProperty("jruby.jit.logging","true");
    System.setProperty("jruby.native.verbose","true");
  }
  @AfterClass public static void tearDownAfterClass() throws Exception {
    TEST_UTIL.shutdownMiniCluster();
  }
}
