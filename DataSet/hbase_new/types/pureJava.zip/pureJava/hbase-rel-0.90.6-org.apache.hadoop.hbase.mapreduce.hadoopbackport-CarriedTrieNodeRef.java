/** 
 * This object contains a TrieNodeRef if there is such a thing that can be repeated.  Two adjacent trie node slots that contain no  split points can be filled with the same trie node, even if they are not on the same level.  See buildTreeRec, below.
 */
private class CarriedTrieNodeRef {
  TrieNode content;
  CarriedTrieNodeRef(){
    content=null;
  }
}
