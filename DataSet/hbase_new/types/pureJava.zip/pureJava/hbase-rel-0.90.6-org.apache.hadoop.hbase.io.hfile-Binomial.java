/** 
 * Binomial distribution. P(k)=select(n, k)*p^k*(1-p)^(n-k) (k = 0, 1, ..., n) P(k)=select(max-min-1, k-min)*p^(k-min)*(1-p)^(k-min)*(1-p)^(max-k-1)
 */
public static final class Binomial implements DiscreteRNG {
  private final Random random;
  private final int min;
  private final int n;
  private final double[] v;
  private static double select(  int n,  int k){
    double ret=1.0;
    for (int i=k + 1; i <= n; ++i) {
      ret*=(double)i / (i - k);
    }
    return ret;
  }
  private static double power(  double p,  int k){
    return Math.exp(k * Math.log(p));
  }
  /** 
 * Generate random integers from min (inclusive) to max (exclusive) following Binomial distribution.
 * @param random The basic random number generator.
 * @param min Minimum integer
 * @param max maximum integer (exclusive).
 * @param p parameter.
 */
  public Binomial(  Random random,  int min,  int max,  double p){
    if (min >= max) {
      throw new IllegalArgumentException("Invalid range");
    }
    this.random=random;
    this.min=min;
    this.n=max - min - 1;
    if (n > 0) {
      v=new double[n + 1];
      double sum=0.0;
      for (int i=0; i <= n; ++i) {
        sum+=select(n,i) * power(p,i) * power(1 - p,n - i);
        v[i]=sum;
      }
      for (int i=0; i <= n; ++i) {
        v[i]/=sum;
      }
    }
 else {
      v=null;
    }
  }
  /** 
 * @see DiscreteRNG#nextInt()
 */
  @Override public int nextInt(){
    if (v == null) {
      return min;
    }
    double d=random.nextDouble();
    int idx=Arrays.binarySearch(v,d);
    if (idx > 0) {
      ++idx;
    }
 else {
      idx=-(idx + 1);
    }
    if (idx >= v.length) {
      idx=v.length - 1;
    }
    return idx + min;
  }
}
