/** 
 * Represents an HFile waiting to be loaded. An queue is used in this class in order to support the case where a region has split during the process of the load. When this happens, the HFile is split into two physical parts across the new region boundary, and each part is added back into the queue. The import process finishes when the queue is empty.
 */
static class LoadQueueItem {
  final byte[] family;
  final Path hfilePath;
  public LoadQueueItem(  byte[] family,  Path hfilePath){
    this.family=family;
    this.hfilePath=hfilePath;
  }
  public String toString(){
    return "family:" + Bytes.toString(family) + " path:"+ hfilePath.toString();
  }
}
