/** 
 * Thread that does single-row reads in a table, looking for partially completed rows.
 */
public static class AtomicGetReader extends RepeatingTestThread {
  byte targetRow[];
  byte targetFamilies[][];
  HTable table;
  int numVerified=0;
  AtomicLong numRead=new AtomicLong();
  public AtomicGetReader(  TestContext ctx,  byte targetRow[],  byte targetFamilies[][]) throws IOException {
    super(ctx);
    this.targetRow=targetRow;
    this.targetFamilies=targetFamilies;
    table=new HTable(ctx.getConf(),TABLE_NAME);
  }
  public void doAnAction() throws Exception {
    Get g=new Get(targetRow);
    Result res=table.get(g);
    byte[] gotValue=null;
    if (res.getRow() == null) {
      return;
    }
    for (    byte[] family : targetFamilies) {
      for (int i=0; i < NUM_COLS_TO_CHECK; i++) {
        byte qualifier[]=Bytes.toBytes("col" + i);
        byte thisValue[]=res.getValue(family,qualifier);
        if (gotValue != null && !Bytes.equals(gotValue,thisValue)) {
          gotFailure(gotValue,res);
        }
        numVerified++;
        gotValue=thisValue;
      }
    }
    numRead.getAndIncrement();
  }
  private void gotFailure(  byte[] expected,  Result res){
    StringBuilder msg=new StringBuilder();
    msg.append("Failed after ").append(numVerified).append("!");
    msg.append("Expected=").append(Bytes.toStringBinary(expected));
    msg.append("Got:\n");
    for (    KeyValue kv : res.list()) {
      msg.append(kv.toString());
      msg.append(" val= ");
      msg.append(Bytes.toStringBinary(kv.getValue()));
      msg.append("\n");
    }
    throw new RuntimeException(msg.toString());
  }
}
