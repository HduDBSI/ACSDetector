public static final class Builder {
  boolean keepProgress=DEFAULT_KEEP_PROGRESS;
  LimitFields limits=new LimitFields();
  private Builder(){
  }
  private Builder(  boolean keepProgress){
    this.keepProgress=keepProgress;
  }
  public Builder setKeepProgress(  boolean keepProgress){
    this.keepProgress=keepProgress;
    return this;
  }
  public Builder setSizeLimit(  LimitScope sizeScope,  long sizeLimit){
    limits.setSize(sizeLimit);
    limits.setSizeScope(sizeScope);
    return this;
  }
  public Builder setTimeLimit(  LimitScope timeScope,  long timeLimit){
    limits.setTime(timeLimit);
    limits.setTimeScope(timeScope);
    return this;
  }
  public Builder setBatchLimit(  int batchLimit){
    limits.setBatch(batchLimit);
    return this;
  }
  public ScannerContext build(){
    return new ScannerContext(keepProgress,limits);
  }
}
