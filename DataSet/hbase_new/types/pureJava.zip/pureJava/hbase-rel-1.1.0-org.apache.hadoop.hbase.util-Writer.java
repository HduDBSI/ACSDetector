/** 
 * Use dumping out mbeans as JSON.
 */
public interface Writer extends Closeable {
  void write(  final String key,  final String value) throws JsonGenerationException, IOException ;
  int write(  final MBeanServer mBeanServer,  ObjectName qry,  String attribute,  final boolean description) throws IOException ;
  void flush() throws IOException ;
}
