/** 
 * Returns our async process.
 */
static class MyConnectionImpl extends ConnectionManager.HConnectionImplementation {
public static class TestRegistry implements Registry {
    @Override public void init(    Connection connection){
    }
    @Override public RegionLocations getMetaRegionLocation() throws IOException {
      return null;
    }
    @Override public String getClusterId(){
      return "testClusterId";
    }
    @Override public boolean isTableOnlineState(    TableName tableName,    boolean enabled) throws IOException {
      return false;
    }
    @Override public int getCurrentNrHRS() throws IOException {
      return 1;
    }
  }
  final AtomicInteger nbThreads=new AtomicInteger(0);
  protected MyConnectionImpl(  Configuration conf) throws IOException {
    super(setupConf(conf),false);
  }
  private static Configuration setupConf(  Configuration conf){
    conf.setClass(RegistryFactory.REGISTRY_IMPL_CONF_KEY,TestRegistry.class,Registry.class);
    return conf;
  }
  @Override public RegionLocations locateRegion(  TableName tableName,  byte[] row,  boolean useCache,  boolean retry,  int replicaId) throws IOException {
    return new RegionLocations(loc1);
  }
  @Override public boolean hasCellBlockSupport(){
    return false;
  }
}
