public class DemoClient {
  protected int port=9090;
  CharsetDecoder decoder=null;
  public static void main(  String[] args) throws IOError, TException, NotFound, UnsupportedEncodingException, IllegalArgument, AlreadyExists {
    DemoClient client=new DemoClient();
    client.run();
  }
  DemoClient(){
    decoder=Charset.forName("UTF-8").newDecoder();
  }
  private String utf8(  byte[] buf){
    try {
      return decoder.decode(ByteBuffer.wrap(buf)).toString();
    }
 catch (    CharacterCodingException e) {
      return "[INVALID UTF-8]";
    }
  }
  private byte[] bytes(  String s){
    try {
      return s.getBytes("UTF-8");
    }
 catch (    UnsupportedEncodingException e) {
      e.printStackTrace();
      return null;
    }
  }
  private void run() throws IOError, TException, NotFound, IllegalArgument, AlreadyExists {
    TTransport transport=new TSocket("localhost",port);
    TProtocol protocol=new TBinaryProtocol(transport,true,true);
    Hbase.Client client=new Hbase.Client(protocol);
    transport.open();
    byte[] t=bytes("demo_table");
    System.out.println("scanning tables...");
    for (    byte[] name : client.getTableNames()) {
      System.out.println("  found: " + utf8(name));
      if (utf8(name).equals(utf8(t))) {
        if (client.isTableEnabled(name)) {
          System.out.println("    disabling table: " + utf8(name));
          client.disableTable(name);
        }
        System.out.println("    deleting table: " + utf8(name));
        client.deleteTable(name);
      }
    }
    ArrayList<ColumnDescriptor> columns=new ArrayList<ColumnDescriptor>();
    ColumnDescriptor col=null;
    col=new ColumnDescriptor();
    col.name=bytes("entry:");
    col.maxVersions=10;
    columns.add(col);
    col=new ColumnDescriptor();
    col.name=bytes("unused:");
    columns.add(col);
    System.out.println("creating table: " + utf8(t));
    try {
      client.createTable(t,columns);
    }
 catch (    AlreadyExists ae) {
      System.out.println("WARN: " + ae.message);
    }
    System.out.println("column families in " + utf8(t) + ": ");
    Map<byte[],ColumnDescriptor> columnMap=client.getColumnDescriptors(t);
    for (    ColumnDescriptor col2 : columnMap.values()) {
      System.out.println("  column: " + utf8(col2.name) + ", maxVer: "+ Integer.toString(col2.maxVersions));
    }
    byte[] invalid={(byte)'f',(byte)'o',(byte)'o',(byte)'-',(byte)0xfc,(byte)0xa1,(byte)0xa1,(byte)0xa1,(byte)0xa1};
    byte[] valid={(byte)'f',(byte)'o',(byte)'o',(byte)'-',(byte)0xE7,(byte)0x94,(byte)0x9F,(byte)0xE3,(byte)0x83,(byte)0x93,(byte)0xE3,(byte)0x83,(byte)0xBC,(byte)0xE3,(byte)0x83,(byte)0xAB};
    ArrayList<Mutation> mutations;
    mutations=new ArrayList<Mutation>();
    mutations.add(new Mutation(false,bytes("entry:foo"),invalid));
    client.mutateRow(t,bytes("foo"),mutations);
    mutations=new ArrayList<Mutation>();
    mutations.add(new Mutation(false,bytes("entry:"),bytes("")));
    client.mutateRow(t,bytes(""),mutations);
    mutations=new ArrayList<Mutation>();
    mutations.add(new Mutation(false,bytes("entry:foo"),valid));
    client.mutateRow(t,valid,mutations);
    try {
      mutations=new ArrayList<Mutation>();
      mutations.add(new Mutation(false,bytes("entry:foo"),invalid));
      client.mutateRow(t,invalid,mutations);
      System.out.println("FATAL: shouldn't get here");
      System.exit(-1);
    }
 catch (    IOError e) {
      System.out.println("expected error: " + e.message);
    }
    ArrayList<byte[]> columnNames=new ArrayList<byte[]>();
    columnNames.add(bytes("entry:"));
    System.out.println("Starting scanner...");
    int scanner=client.scannerOpen(t,bytes(""),columnNames);
    try {
      while (true) {
        TRowResult entry=client.scannerGet(scanner);
        printRow(entry);
      }
    }
 catch (    NotFound nf) {
      client.scannerClose(scanner);
      System.out.println("Scanner finished");
    }
    for (int i=100; i >= 0; --i) {
      NumberFormat nf=NumberFormat.getInstance();
      nf.setMinimumIntegerDigits(5);
      nf.setGroupingUsed(false);
      byte[] row=bytes(nf.format(i));
      mutations=new ArrayList<Mutation>();
      mutations.add(new Mutation(false,bytes("unused:"),bytes("DELETE_ME")));
      client.mutateRow(t,row,mutations);
      printRow(client.getRow(t,row));
      client.deleteAllRow(t,row);
      mutations=new ArrayList<Mutation>();
      mutations.add(new Mutation(false,bytes("entry:num"),bytes("0")));
      mutations.add(new Mutation(false,bytes("entry:foo"),bytes("FOO")));
      client.mutateRow(t,row,mutations);
      printRow(client.getRow(t,row));
      Mutation m=null;
      mutations=new ArrayList<Mutation>();
      m=new Mutation();
      m.column=bytes("entry:foo");
      m.isDelete=true;
      mutations.add(m);
      m=new Mutation();
      m.column=bytes("entry:num");
      m.value=bytes("-1");
      mutations.add(m);
      client.mutateRow(t,row,mutations);
      printRow(client.getRow(t,row));
      mutations=new ArrayList<Mutation>();
      mutations.add(new Mutation(false,bytes("entry:num"),bytes(Integer.toString(i))));
      mutations.add(new Mutation(false,bytes("entry:sqr"),bytes(Integer.toString(i * i))));
      client.mutateRow(t,row,mutations);
      printRow(client.getRow(t,row));
      try {
        Thread.sleep(50);
      }
 catch (      InterruptedException e) {
      }
      mutations.clear();
      m=new Mutation();
      m.column=bytes("entry:num");
      m.value=bytes("-999");
      mutations.add(m);
      m=new Mutation();
      m.column=bytes("entry:sqr");
      m.isDelete=true;
      client.mutateRowTs(t,row,mutations,1);
      printRow(client.getRow(t,row));
      List<TCell> versions=client.getVer(t,row,bytes("entry:num"),10);
      printVersions(row,versions);
      if (versions.size() != 4) {
        System.out.println("FATAL: wrong # of versions");
        System.exit(-1);
      }
      try {
        client.get(t,row,bytes("entry:foo"));
        System.out.println("FATAL: shouldn't get here");
        System.exit(-1);
      }
 catch (      NotFound nf2) {
      }
      System.out.println("");
    }
    columnNames.clear();
    for (    ColumnDescriptor col2 : client.getColumnDescriptors(t).values()) {
      System.out.println("column with name: " + new String(col2.name));
      System.out.println(col2.toString());
      columnNames.add((utf8(col2.name) + ":").getBytes());
    }
    System.out.println("Starting scanner...");
    scanner=client.scannerOpenWithStop(t,bytes("00020"),bytes("00040"),columnNames);
    try {
      while (true) {
        TRowResult entry=client.scannerGet(scanner);
        printRow(entry);
      }
    }
 catch (    NotFound nf) {
      client.scannerClose(scanner);
      System.out.println("Scanner finished");
    }
    transport.close();
  }
  private final void printVersions(  byte[] row,  List<TCell> versions){
    StringBuilder rowStr=new StringBuilder();
    for (    TCell cell : versions) {
      rowStr.append(utf8(cell.value));
      rowStr.append("; ");
    }
    System.out.println("row: " + utf8(row) + ", values: "+ rowStr);
  }
  private final void printRow(  TRowResult rowResult){
    TreeMap<String,TCell> sorted=new TreeMap<String,TCell>();
    for (    Map.Entry<byte[],TCell> column : rowResult.columns.entrySet()) {
      sorted.put(utf8(column.getKey()),column.getValue());
    }
    StringBuilder rowStr=new StringBuilder();
    for (    SortedMap.Entry<String,TCell> entry : sorted.entrySet()) {
      rowStr.append(entry.getKey());
      rowStr.append(" => ");
      rowStr.append(utf8(entry.getValue().value));
      rowStr.append("; ");
    }
    System.out.println("row: " + utf8(rowResult.row) + ", cols: "+ rowStr);
  }
}
