static abstract class Test {
  private static final Random randomSeed=new Random(System.currentTimeMillis());
  private static long nextRandomSeed(){
    return randomSeed.nextLong();
  }
  protected final Random rand=new Random(nextRandomSeed());
  protected final int startRow;
  protected final int perClientRunRows;
  protected final int totalRows;
  protected final Status status;
  protected byte[] tableName;
  protected RemoteHTable table;
  protected volatile Configuration conf;
  /** 
 * Note that all subclasses of this class must provide a public contructor that has the exact same list of arguments.
 */
  Test(  final Configuration conf,  final TestOptions options,  final Status status){
    super();
    this.startRow=options.getStartRow();
    this.perClientRunRows=options.getPerClientRunRows();
    this.totalRows=options.getTotalRows();
    this.status=status;
    this.tableName=options.getTableName();
    this.table=null;
    this.conf=conf;
  }
  protected String generateStatus(  final int sr,  final int i,  final int lr){
    return sr + "/" + i+ "/"+ lr;
  }
  protected int getReportingPeriod(){
    int period=this.perClientRunRows / 10;
    return period == 0 ? this.perClientRunRows : period;
  }
  void testSetup() throws IOException {
    this.table=new RemoteHTable(new Client(cluster),conf,tableName,accessToken);
  }
  void testTakedown() throws IOException {
    this.table.close();
  }
  long test() throws IOException {
    long elapsedTime;
    testSetup();
    long startTime=System.currentTimeMillis();
    try {
      testTimed();
      elapsedTime=System.currentTimeMillis() - startTime;
    }
  finally {
      testTakedown();
    }
    return elapsedTime;
  }
  /** 
 * Provides an extension point for tests that don't want a per row invocation.
 */
  void testTimed() throws IOException {
    int lastRow=this.startRow + this.perClientRunRows;
    for (int i=this.startRow; i < lastRow; i++) {
      testRow(i);
      if (status != null && i > 0 && (i % getReportingPeriod()) == 0) {
        status.setStatus(generateStatus(this.startRow,i,lastRow));
      }
    }
  }
  void testRow(  final int i) throws IOException {
  }
}
