/** 
 * Handler to create a table.
 */
@InterfaceAudience.Private public class CreateTableHandler extends EventHandler {
  private static final Log LOG=LogFactory.getLog(CreateTableHandler.class);
  protected MasterFileSystem fileSystemManager;
  protected final HTableDescriptor hTableDescriptor;
  protected Configuration conf;
  protected final AssignmentManager assignmentManager;
  protected final CatalogTracker catalogTracker;
  protected final ServerManager serverManager;
  private final HRegionInfo[] newRegions;
  public CreateTableHandler(  Server server,  MasterFileSystem fileSystemManager,  ServerManager serverManager,  HTableDescriptor hTableDescriptor,  Configuration conf,  HRegionInfo[] newRegions,  CatalogTracker catalogTracker,  AssignmentManager assignmentManager) throws NotAllMetaRegionsOnlineException, TableExistsException, IOException {
    super(server,EventType.C_M_CREATE_TABLE);
    this.fileSystemManager=fileSystemManager;
    this.serverManager=serverManager;
    this.hTableDescriptor=hTableDescriptor;
    this.conf=conf;
    this.newRegions=newRegions;
    this.catalogTracker=catalogTracker;
    this.assignmentManager=assignmentManager;
    int timeout=conf.getInt("hbase.client.catalog.timeout",10000);
    try {
      if (catalogTracker.waitForMeta(timeout) == null) {
        throw new NotAllMetaRegionsOnlineException();
      }
    }
 catch (    InterruptedException e) {
      LOG.warn("Interrupted waiting for meta availability",e);
      throw new IOException(e);
    }
    String tableName=this.hTableDescriptor.getNameAsString();
    if (MetaReader.tableExists(catalogTracker,tableName)) {
      throw new TableExistsException(tableName);
    }
    try {
      if (!this.assignmentManager.getZKTable().checkAndSetEnablingTable(tableName))       throw new TableExistsException(tableName);
    }
 catch (    KeeperException e) {
      throw new IOException("Unable to ensure that the table will be" + " enabling because of a ZooKeeper issue",e);
    }
  }
  @Override public String toString(){
    String name="UnknownServerName";
    if (server != null && server.getServerName() != null) {
      name=server.getServerName().toString();
    }
    return getClass().getSimpleName() + "-" + name+ "-"+ getSeqid()+ "-"+ this.hTableDescriptor.getNameAsString();
  }
  @Override public void process(){
    String tableName=this.hTableDescriptor.getNameAsString();
    try {
      LOG.info("Attempting to create the table " + tableName);
      handleCreateTable(tableName);
      completed(null);
    }
 catch (    Throwable e) {
      LOG.error("Error trying to create the table " + tableName,e);
      completed(e);
    }
  }
  /** 
 * Called after that process() is completed.
 * @param exception null if process() is successful or not null if something has failed.
 */
  protected void completed(  final Throwable exception){
    if (exception != null) {
      try {
        this.assignmentManager.getZKTable().removeEnablingTable(this.hTableDescriptor.getNameAsString(),false);
      }
 catch (      KeeperException e) {
        LOG.error("Got a keeper exception while removing the ENABLING table znode " + this.hTableDescriptor.getNameAsString(),e);
      }
    }
  }
  /** 
 * Responsible of table creation (on-disk and META) and assignment. - Create the table directory and descriptor (temp folder) - Create the on-disk regions (temp folder) [If something fails here: we've just some trash in temp] - Move the table from temp to the root directory [If something fails here: we've the table in place but some of the rows required present in META. (hbck needed)] - Add regions to META [If something fails here: we don't have regions assigned: table disabled] - Assign regions to Region Servers [If something fails here: we still have the table in disabled state] - Update ZooKeeper with the enabled state
 */
  private void handleCreateTable(  String tableName) throws IOException, KeeperException {
    Path tempdir=fileSystemManager.getTempDir();
    FileSystem fs=fileSystemManager.getFileSystem();
    FSTableDescriptors.createTableDescriptor(fs,tempdir,this.hTableDescriptor);
    Path tempTableDir=new Path(tempdir,tableName);
    Path tableDir=new Path(fileSystemManager.getRootDir(),tableName);
    List<HRegionInfo> regionInfos=handleCreateHdfsRegions(tempdir,tableName);
    if (!HBaseFileSystem.renameDirForFileSystem(fs,tempTableDir,tableDir)) {
      throw new IOException("Unable to move table from temp=" + tempTableDir + " to hbase root="+ tableDir);
    }
    if (regionInfos != null && regionInfos.size() > 0) {
      addRegionsToMeta(this.catalogTracker,regionInfos);
      List<ServerName> servers=serverManager.getOnlineServersList();
      assignmentManager.removeDeadNotExpiredServers(servers);
      try {
        this.assignmentManager.assignUserRegions(regionInfos,servers);
      }
 catch (      InterruptedException e) {
        LOG.error("Caught " + e + " during round-robin assignment");
        InterruptedIOException ie=new InterruptedIOException(e.getMessage());
        ie.initCause(e);
        throw ie;
      }
    }
    try {
      assignmentManager.getZKTable().setEnabledTable(tableName);
    }
 catch (    KeeperException e) {
      throw new IOException("Unable to ensure that " + tableName + " will be"+ " enabled because of a ZooKeeper issue",e);
    }
  }
  /** 
 * Create the on-disk structure for the table, and returns the regions info.
 * @param tableRootDir directory where the table is being created
 * @param tableName name of the table under construction
 * @return the list of regions created
 */
  protected List<HRegionInfo> handleCreateHdfsRegions(  final Path tableRootDir,  final String tableName) throws IOException {
    return ModifyRegionUtils.createRegions(conf,tableRootDir,hTableDescriptor,newRegions,null);
  }
  /** 
 * Add the specified set of regions to the META table.
 */
  protected void addRegionsToMeta(  final CatalogTracker ct,  final List<HRegionInfo> regionInfos) throws IOException {
    MetaEditor.addRegionsToMeta(this.catalogTracker,regionInfos);
  }
}
