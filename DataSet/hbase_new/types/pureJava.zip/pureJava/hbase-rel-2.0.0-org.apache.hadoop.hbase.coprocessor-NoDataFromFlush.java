/** 
 * Don't allow any data in a flush by creating a custom  {@link StoreScanner}.
 */
public static class NoDataFromFlush implements RegionCoprocessor, RegionObserver {
  @Override public Optional<RegionObserver> getRegionObserver(){
    return Optional.of(this);
  }
  @Override public InternalScanner preFlush(  ObserverContext<RegionCoprocessorEnvironment> c,  Store store,  InternalScanner scanner,  FlushLifeCycleTracker tracker) throws IOException {
    return NO_DATA;
  }
}
