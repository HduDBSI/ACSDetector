public static class getColumnDescriptors_call extends org.apache.thrift.async.TAsyncMethodCall {
  private ByteBuffer tableName;
  public getColumnDescriptors_call(  ByteBuffer tableName,  org.apache.thrift.async.AsyncMethodCallback<getColumnDescriptors_call> resultHandler,  org.apache.thrift.async.TAsyncClient client,  org.apache.thrift.protocol.TProtocolFactory protocolFactory,  org.apache.thrift.transport.TNonblockingTransport transport) throws org.apache.thrift.TException {
    super(client,protocolFactory,transport,resultHandler,false);
    this.tableName=tableName;
  }
  public void write_args(  org.apache.thrift.protocol.TProtocol prot) throws org.apache.thrift.TException {
    prot.writeMessageBegin(new org.apache.thrift.protocol.TMessage("getColumnDescriptors",org.apache.thrift.protocol.TMessageType.CALL,0));
    getColumnDescriptors_args args=new getColumnDescriptors_args();
    args.setTableName(tableName);
    args.write(prot);
    prot.writeMessageEnd();
  }
  public Map<ByteBuffer,ColumnDescriptor> getResult() throws IOError, org.apache.thrift.TException {
    if (getState() != org.apache.thrift.async.TAsyncMethodCall.State.RESPONSE_READ) {
      throw new IllegalStateException("Method call not finished!");
    }
    org.apache.thrift.transport.TMemoryInputTransport memoryTransport=new org.apache.thrift.transport.TMemoryInputTransport(getFrameBuffer().array());
    org.apache.thrift.protocol.TProtocol prot=client.getProtocolFactory().getProtocol(memoryTransport);
    return (new Client(prot)).recv_getColumnDescriptors();
  }
}
