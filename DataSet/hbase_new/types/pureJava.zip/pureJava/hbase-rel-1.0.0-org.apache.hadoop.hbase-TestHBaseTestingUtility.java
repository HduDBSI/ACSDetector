/** 
 * Test our testing utility class
 */
@Category(LargeTests.class) public class TestHBaseTestingUtility {
  private final Log LOG=LogFactory.getLog(this.getClass());
  /** 
 * Basic sanity test that spins up multiple HDFS and HBase clusters that share the same ZK ensemble. We then create the same table in both and make sure that what we insert in one place doesn't end up in the other.
 * @throws Exception
 */
  @Test(timeout=180000) public void testMultiClusters() throws Exception {
    HBaseTestingUtility htu1=new HBaseTestingUtility();
    htu1.getConfiguration().set(HConstants.ZOOKEEPER_ZNODE_PARENT,"/1");
    htu1.startMiniZKCluster();
    HBaseTestingUtility htu2=new HBaseTestingUtility();
    htu2.getConfiguration().set(HConstants.ZOOKEEPER_ZNODE_PARENT,"/2");
    htu2.getConfiguration().set(HConstants.ZOOKEEPER_CLIENT_PORT,htu1.getConfiguration().get(HConstants.ZOOKEEPER_CLIENT_PORT,"-1"));
    htu2.setZkCluster(htu1.getZkCluster());
    HBaseTestingUtility htu3=new HBaseTestingUtility();
    htu3.getConfiguration().set(HConstants.ZOOKEEPER_ZNODE_PARENT,"/3");
    htu3.getConfiguration().set(HConstants.ZOOKEEPER_CLIENT_PORT,htu1.getConfiguration().get(HConstants.ZOOKEEPER_CLIENT_PORT,"-1"));
    htu3.setZkCluster(htu1.getZkCluster());
    try {
      htu1.startMiniCluster();
      htu2.startMiniCluster();
      htu3.startMiniCluster();
      final TableName TABLE_NAME=TableName.valueOf("test");
      final byte[] FAM_NAME=Bytes.toBytes("fam");
      final byte[] ROW=Bytes.toBytes("row");
      final byte[] QUAL_NAME=Bytes.toBytes("qual");
      final byte[] VALUE=Bytes.toBytes("value");
      Table table1=htu1.createTable(TABLE_NAME,FAM_NAME);
      Table table2=htu2.createTable(TABLE_NAME,FAM_NAME);
      Put put=new Put(ROW);
      put.add(FAM_NAME,QUAL_NAME,VALUE);
      table1.put(put);
      Get get=new Get(ROW);
      get.addColumn(FAM_NAME,QUAL_NAME);
      Result res=table1.get(get);
      assertEquals(1,res.size());
      res=table2.get(get);
      assertEquals(0,res.size());
      table1.close();
      table2.close();
    }
  finally {
      htu3.shutdownMiniCluster();
      htu2.shutdownMiniCluster();
      htu1.shutdownMiniCluster();
    }
  }
  @Test public void testMiniCluster() throws Exception {
    HBaseTestingUtility hbt=new HBaseTestingUtility();
    MiniHBaseCluster cluster=hbt.startMiniCluster();
    try {
      assertEquals(1,cluster.getLiveRegionServerThreads().size());
    }
  finally {
      hbt.shutdownMiniCluster();
    }
  }
  @Test public void testMiniClusterBindToWildcard() throws Exception {
    HBaseTestingUtility hbt=new HBaseTestingUtility();
    hbt.getConfiguration().set("hbase.regionserver.ipc.address","0.0.0.0");
    MiniHBaseCluster cluster=hbt.startMiniCluster();
    try {
      assertEquals(1,cluster.getLiveRegionServerThreads().size());
    }
  finally {
      hbt.shutdownMiniCluster();
    }
  }
  @Test public void testMiniClusterWithSSLOn() throws Exception {
    final String BASEDIR=System.getProperty("test.build.dir","target/test-dir") + "/" + TestHBaseTestingUtility.class.getSimpleName();
    String sslConfDir=KeyStoreTestUtil.getClasspathDir(TestHBaseTestingUtility.class);
    String keystoresDir=new File(BASEDIR).getAbsolutePath();
    HBaseTestingUtility hbt=new HBaseTestingUtility();
    File base=new File(BASEDIR);
    FileUtil.fullyDelete(base);
    base.mkdirs();
    KeyStoreTestUtil.setupSSLConfig(keystoresDir,sslConfDir,hbt.getConfiguration(),false);
    hbt.getConfiguration().set("hbase.ssl.enabled","true");
    hbt.getConfiguration().addResource("ssl-server.xml");
    hbt.getConfiguration().addResource("ssl-client.xml");
    MiniHBaseCluster cluster=hbt.startMiniCluster();
    try {
      assertEquals(1,cluster.getLiveRegionServerThreads().size());
    }
  finally {
      hbt.shutdownMiniCluster();
    }
  }
  /** 
 * Test that we can start and stop multiple time a cluster with the same HBaseTestingUtility.
 */
  @Test public void testMultipleStartStop() throws Exception {
    HBaseTestingUtility htu1=new HBaseTestingUtility();
    Path foo=new Path("foo");
    htu1.startMiniCluster();
    htu1.getDFSCluster().getFileSystem().create(foo);
    assertTrue(htu1.getDFSCluster().getFileSystem().exists(foo));
    htu1.shutdownMiniCluster();
    htu1.startMiniCluster();
    assertFalse(htu1.getDFSCluster().getFileSystem().exists(foo));
    htu1.getDFSCluster().getFileSystem().create(foo);
    assertTrue(htu1.getDFSCluster().getFileSystem().exists(foo));
    htu1.shutdownMiniCluster();
  }
  @Test public void testMiniZooKeeper() throws Exception {
    HBaseTestingUtility hbt=new HBaseTestingUtility();
    MiniZooKeeperCluster cluster1=hbt.startMiniZKCluster();
    try {
      assertEquals(0,cluster1.getBackupZooKeeperServerNum());
      assertTrue((cluster1.killCurrentActiveZooKeeperServer() == -1));
    }
  finally {
      hbt.shutdownMiniZKCluster();
    }
    MiniZooKeeperCluster cluster2=hbt.startMiniZKCluster(5);
    int defaultClientPort=21818;
    cluster2.setDefaultClientPort(defaultClientPort);
    try {
      assertEquals(4,cluster2.getBackupZooKeeperServerNum());
      int currentActivePort=cluster2.killCurrentActiveZooKeeperServer();
      assertTrue(currentActivePort >= defaultClientPort);
      assertTrue(cluster2.getClientPort() == currentActivePort);
      currentActivePort=cluster2.killCurrentActiveZooKeeperServer();
      assertTrue(currentActivePort >= defaultClientPort);
      assertTrue(cluster2.getClientPort() == currentActivePort);
      assertEquals(2,cluster2.getBackupZooKeeperServerNum());
      assertEquals(3,cluster2.getZooKeeperServerNum());
      cluster2.killOneBackupZooKeeperServer();
      cluster2.killOneBackupZooKeeperServer();
      assertEquals(0,cluster2.getBackupZooKeeperServerNum());
      assertEquals(1,cluster2.getZooKeeperServerNum());
      currentActivePort=cluster2.killCurrentActiveZooKeeperServer();
      assertTrue(currentActivePort == -1);
      assertTrue(cluster2.getClientPort() == currentActivePort);
      cluster2.killOneBackupZooKeeperServer();
      assertEquals(-1,cluster2.getBackupZooKeeperServerNum());
      assertEquals(0,cluster2.getZooKeeperServerNum());
    }
  finally {
      hbt.shutdownMiniZKCluster();
    }
  }
  @Test public void testMiniDFSCluster() throws Exception {
    HBaseTestingUtility hbt=new HBaseTestingUtility();
    MiniDFSCluster cluster=hbt.startMiniDFSCluster(null);
    FileSystem dfs=cluster.getFileSystem();
    Path dir=new Path("dir");
    Path qualifiedDir=dfs.makeQualified(dir);
    LOG.info("dir=" + dir + ", qualifiedDir="+ qualifiedDir);
    assertFalse(dfs.exists(qualifiedDir));
    assertTrue(dfs.mkdirs(qualifiedDir));
    assertTrue(dfs.delete(qualifiedDir,true));
    hbt.shutdownMiniCluster();
  }
  @Test public void testSetupClusterTestBuildDir() throws Exception {
    HBaseTestingUtility hbt=new HBaseTestingUtility();
    Path testdir=hbt.getClusterTestDir();
    LOG.info("uuid-subdir=" + testdir);
    FileSystem fs=hbt.getTestFileSystem();
    assertFalse(fs.exists(testdir));
    hbt.startMiniDFSCluster(null);
    assertTrue(fs.exists(testdir));
    hbt.shutdownMiniCluster();
    assertFalse(fs.exists(testdir));
  }
  @Test public void testTestDir() throws Exception {
    HBaseTestingUtility hbt=new HBaseTestingUtility();
    Path testdir=hbt.getDataTestDir();
    LOG.info("testdir=" + testdir);
    FileSystem fs=hbt.getTestFileSystem();
    assertTrue(!fs.exists(testdir));
    assertTrue(fs.mkdirs(testdir));
    assertTrue(hbt.cleanupTestDir());
  }
}
