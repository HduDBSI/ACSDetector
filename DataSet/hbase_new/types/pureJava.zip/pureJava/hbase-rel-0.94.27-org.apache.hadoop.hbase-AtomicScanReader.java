/** 
 * Thread that does full scans of the table looking for any partially completed rows.
 */
public static class AtomicScanReader extends RepeatingTestThread {
  byte targetFamilies[][];
  HTable table;
  AtomicLong numScans=new AtomicLong();
  AtomicLong numRowsScanned=new AtomicLong();
  public AtomicScanReader(  TestContext ctx,  byte targetFamilies[][]) throws IOException {
    super(ctx);
    this.targetFamilies=targetFamilies;
    table=new HTable(ctx.getConf(),TABLE_NAME);
  }
  public void doAnAction() throws Exception {
    Scan s=new Scan();
    for (    byte[] family : targetFamilies) {
      s.addFamily(family);
    }
    ResultScanner scanner=table.getScanner(s);
    for (    Result res : scanner) {
      byte[] gotValue=null;
      for (      byte[] family : targetFamilies) {
        for (int i=0; i < NUM_COLS_TO_CHECK; i++) {
          byte qualifier[]=Bytes.toBytes("col" + i);
          byte thisValue[]=res.getValue(family,qualifier);
          if (gotValue != null && !Bytes.equals(gotValue,thisValue)) {
            gotFailure(gotValue,res);
          }
          gotValue=thisValue;
        }
      }
      numRowsScanned.getAndIncrement();
    }
    numScans.getAndIncrement();
  }
  private void gotFailure(  byte[] expected,  Result res){
    StringBuilder msg=new StringBuilder();
    msg.append("Failed after ").append(numRowsScanned).append("!");
    msg.append("Expected=").append(Bytes.toStringBinary(expected));
    msg.append("Got:\n");
    for (    KeyValue kv : res.list()) {
      msg.append(kv.toString());
      msg.append(" val= ");
      msg.append(Bytes.toStringBinary(kv.getValue()));
      msg.append("\n");
    }
    throw new RuntimeException(msg.toString());
  }
}
