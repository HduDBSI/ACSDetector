/** 
 * Simple representation of the version of the storage cluster <pre> &lt;complexType name="StorageClusterVersion"&gt; &lt;attribute name="version" type="string"&gt;&lt;/attribute&gt; &lt;/complexType&gt; </pre>
 */
@XmlRootElement(name="ClusterVersion") public class StorageClusterVersionModel implements Serializable {
  private static final long serialVersionUID=1L;
  private String version;
  /** 
 * @return the storage cluster version
 */
  @XmlValue public String getVersion(){
    return version;
  }
  /** 
 * @param version the storage cluster version
 */
  public void setVersion(  String version){
    this.version=version;
  }
  @Override public String toString(){
    return version;
  }
}
