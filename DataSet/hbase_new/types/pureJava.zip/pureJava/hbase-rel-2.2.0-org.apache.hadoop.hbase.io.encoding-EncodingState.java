/** 
 * Keeps track of the encoding state.
 */
@InterfaceAudience.Private public class EncodingState {
  /** 
 * The previous Cell the encoder encoded.
 */
  protected Cell prevCell=null;
}
