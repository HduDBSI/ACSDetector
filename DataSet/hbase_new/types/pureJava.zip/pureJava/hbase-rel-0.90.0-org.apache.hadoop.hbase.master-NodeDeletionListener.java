public static class NodeDeletionListener extends ZooKeeperListener {
  private static final Log LOG=LogFactory.getLog(NodeDeletionListener.class);
  private Semaphore lock;
  private String node;
  public NodeDeletionListener(  ZooKeeperWatcher watcher,  String node){
    super(watcher);
    lock=new Semaphore(0);
    this.node=node;
  }
  @Override public void nodeDeleted(  String path){
    if (path.equals(node)) {
      LOG.debug("nodeDeleted(" + path + ")");
      lock.release();
    }
  }
  public void waitForDeletion() throws InterruptedException {
    lock.acquire();
  }
}
