/** 
 * Thread that flushes cache on request
 * @see FlushRequester
 */
private class Flusher extends Thread implements FlushRequester {
  private final BlockingQueue<HRegion> flushQueue=new LinkedBlockingQueue<HRegion>();
  private final HashSet<HRegion> regionsInQueue=new HashSet<HRegion>();
  private final ReentrantLock workingLock=new ReentrantLock();
  private final long optionalFlushPeriod;
  private final long globalMemcacheLimit;
  private final long globalMemcacheLimitLowMark;
  /** 
 * constructor 
 */
  public Flusher(){
    super();
    this.optionalFlushPeriod=conf.getLong("hbase.regionserver.optionalcacheflushinterval",30 * 60 * 1000L);
    globalMemcacheLimit=conf.getLong("hbase.regionserver.globalMemcacheLimit",512 * 1024 * 1024);
    globalMemcacheLimitLowMark=conf.getLong("hbase.regionserver.globalMemcacheLimitLowMark",globalMemcacheLimit / 2);
  }
  /** 
 * {@inheritDoc} 
 */
  @Override public void run(){
    while (!stopRequested.get()) {
      HRegion r=null;
      try {
        enqueueOptionalFlushRegions();
        r=flushQueue.poll(threadWakeFrequency,TimeUnit.MILLISECONDS);
        if (r == null) {
          continue;
        }
        if (!flushRegion(r,false)) {
          break;
        }
      }
 catch (      InterruptedException ex) {
        continue;
      }
catch (      ConcurrentModificationException ex) {
        continue;
      }
catch (      Exception ex) {
        LOG.error("Cache flush failed" + (r != null ? (" for region " + r.getRegionName()) : ""),ex);
        if (!checkFileSystem()) {
          break;
        }
      }
    }
    regionsInQueue.clear();
    flushQueue.clear();
    LOG.info(getName() + " exiting");
  }
  /** 
 * Flush a region right away, while respecting concurrency with the async flushing that is always going on.
 * @param region the region to be flushed
 * @param removeFromQueue true if the region needs to be removed from theflush queue. False if called from the main run loop and true if called from flushSomeRegions to relieve memory pressure from the region server. <p>In the main run loop, regions have already been removed from the flush queue, and if this method is called for the relief of memory pressure, this may not be necessarily true. We want to avoid trying to remove  region from the queue because if it has already been removed, it reqires a sequential scan of the queue to determine that it is not in the queue. <p>If called from flushSomeRegions, the region may be in the queue but it may have been determined that the region had a significant amout of  memory in use and needed to be flushed to relieve memory pressure. In this case, its flush may preempt the pending request in the queue, and if so, it needs to be removed from the queue to avoid flushing the region multiple times.
 * @return true if the region was successfully flushed, false otherwise. If false, we exit the Flusher thread.
 */
  private boolean flushRegion(  HRegion region,  boolean removeFromQueue){
synchronized (regionsInQueue) {
      if (regionsInQueue.remove(region) && removeFromQueue) {
        flushQueue.remove(region);
      }
      workingLock.lock();
      try {
        if (region.flushcache()) {
          compactSplitThread.compactionRequested(region);
        }
      }
 catch (      DroppedSnapshotException ex) {
        LOG.fatal("Replay of hlog required. Forcing server restart",ex);
        abort();
        return false;
      }
catch (      IOException ex) {
        LOG.error("Cache flush failed" + (region != null ? (" for region " + region.getRegionName()) : ""),RemoteExceptionHandler.checkIOException(ex));
        if (!checkFileSystem()) {
          return false;
        }
      }
 finally {
        workingLock.unlock();
      }
    }
    return true;
  }
  /** 
 * Find the regions that should be optionally flushed and put them on the flush queue.
 */
  private void enqueueOptionalFlushRegions(){
    long now=System.currentTimeMillis();
    for (    HRegion region : getRegionsToCheck()) {
      optionallyAddRegion(region,now);
    }
  }
  private void optionallyAddRegion(  final HRegion r,  final long now){
synchronized (regionsInQueue) {
      if (!regionsInQueue.contains(r) && (System.currentTimeMillis() - optionalFlushPeriod) > r.getLastFlushTime()) {
        addRegion(r,now);
      }
    }
  }
  private void addRegion(  final HRegion r,  final long now){
synchronized (regionsInQueue) {
      if (!regionsInQueue.contains(r)) {
        regionsInQueue.add(r);
        flushQueue.add(r);
        r.setLastFlushTime(now);
      }
    }
  }
  /** 
 * {@inheritDoc} 
 */
  public void request(  HRegion r){
    addRegion(r,System.currentTimeMillis());
  }
  /** 
 * Check if the regionserver's memcache memory usage is greater than the  limit. If so, flush regions with the biggest memcaches until we're down to the lower limit. This method blocks callers until we're down to a safe amount of memcache consumption.
 */
  public synchronized void reclaimMemcacheMemory(){
    long globalMemory=getGlobalMemcacheSize();
    if (globalMemory >= globalMemcacheLimit) {
      LOG.info("Global cache memory in use " + globalMemory + " >= "+ globalMemcacheLimit+ " configured maximum."+ " Forcing cache flushes to relieve memory pressure.");
      flushSomeRegions();
    }
  }
  private void flushSomeRegions(){
    SortedMap<Long,HRegion> sortedRegions=new TreeMap<Long,HRegion>(new Comparator<Long>(){
      public int compare(      Long a,      Long b){
        return -1 * a.compareTo(b);
      }
    }
);
    for (    HRegion region : getRegionsToCheck()) {
      sortedRegions.put(region.memcacheSize.get(),region);
    }
    while (getGlobalMemcacheSize() >= globalMemcacheLimitLowMark) {
      HRegion biggestMemcacheRegion=sortedRegions.remove(sortedRegions.firstKey());
      LOG.info("Force flush of region " + biggestMemcacheRegion.getRegionName());
      if (!flushRegion(biggestMemcacheRegion,true)) {
        break;
      }
    }
  }
  /** 
 * Only interrupt once it's done with a run through the work loop.
 */
  void interruptIfNecessary(){
    if (workingLock.tryLock()) {
      this.interrupt();
    }
  }
}
