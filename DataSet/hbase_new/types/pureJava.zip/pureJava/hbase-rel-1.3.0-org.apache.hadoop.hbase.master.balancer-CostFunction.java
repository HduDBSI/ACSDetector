/** 
 * Base class of StochasticLoadBalancer's Cost Functions.
 */
abstract static class CostFunction {
  private float multiplier=0;
  protected Cluster cluster;
  CostFunction(  Configuration c){
  }
  float getMultiplier(){
    return multiplier;
  }
  void setMultiplier(  float m){
    this.multiplier=m;
  }
  /** 
 * Called once per LB invocation to give the cost function to initialize it's state, and perform any costly calculation.
 */
  void init(  Cluster cluster){
    this.cluster=cluster;
  }
  /** 
 * Called once per cluster Action to give the cost function an opportunity to update it's state. postAction() is always called at least once before cost() is called with the cluster that this action is performed on. 
 */
  void postAction(  Action action){
switch (action.type) {
case NULL:
      break;
case ASSIGN_REGION:
    AssignRegionAction ar=(AssignRegionAction)action;
  regionMoved(ar.region,-1,ar.server);
break;
case MOVE_REGION:
MoveRegionAction mra=(MoveRegionAction)action;
regionMoved(mra.region,mra.fromServer,mra.toServer);
break;
case SWAP_REGIONS:
SwapRegionsAction a=(SwapRegionsAction)action;
regionMoved(a.fromRegion,a.fromServer,a.toServer);
regionMoved(a.toRegion,a.toServer,a.fromServer);
break;
default :
throw new RuntimeException("Uknown action:" + action.type);
}
}
protected void regionMoved(int region,int oldServer,int newServer){
}
abstract double cost();
/** 
 * Function to compute a scaled cost using  {@link DescriptiveStatistics}. It assumes that this is a zero sum set of costs.  It assumes that the worst case possible is all of the elements in one region server and the rest having 0.
 * @param stats the costs
 * @return a scaled set of costs.
 */
protected double costFromArray(double[] stats){
double totalCost=0;
double total=getSum(stats);
double count=stats.length;
double mean=total / count;
double max=((count - 1) * mean) + (total - mean);
double min;
if (count > total) {
min=((count - total) * mean) + ((1 - mean) * total);
}
 else {
int numHigh=(int)(total - (Math.floor(mean) * count));
int numLow=(int)(count - numHigh);
min=(numHigh * (Math.ceil(mean) - mean)) + (numLow * (mean - Math.floor(mean)));
}
min=Math.max(0,min);
for (int i=0; i < stats.length; i++) {
double n=stats[i];
double diff=Math.abs(mean - n);
totalCost+=diff;
}
double scaled=scale(min,max,totalCost);
return scaled;
}
private double getSum(double[] stats){
double total=0;
for (double s : stats) {
total+=s;
}
return total;
}
/** 
 * Scale the value between 0 and 1.
 * @param min   Min value
 * @param max   The Max value
 * @param value The value to be scaled.
 * @return The scaled value.
 */
protected double scale(double min,double max,double value){
if (max <= min || value <= min) {
return 0;
}
if ((max - min) == 0) return 0;
return Math.max(0d,Math.min(1d,(value - min) / (max - min)));
}
}
