/** 
 * Add timestamp to  {@link org.apache.hadoop.metrics.file.FileContext#emitRecord(String,String,OutputRecord)}.
 */
public class TimeStampingFileContext extends FileContext {
  private File file=null;
  private PrintWriter writer=null;
  private final SimpleDateFormat sdf;
  public TimeStampingFileContext(){
    super();
    this.sdf=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
  }
  @Override public void init(  String contextName,  ContextFactory factory){
    super.init(contextName,factory);
    String fileName=getAttribute(FILE_NAME_PROPERTY);
    if (fileName != null) {
      file=new File(fileName);
    }
  }
  @Override public void startMonitoring() throws IOException {
    if (file == null) {
      writer=new PrintWriter(new BufferedOutputStream(System.out));
    }
 else {
      writer=new PrintWriter(new FileWriter(file,true));
    }
    super.startMonitoring();
  }
  @Override public void stopMonitoring(){
    super.stopMonitoring();
    if (writer != null) {
      writer.close();
      writer=null;
    }
  }
  private synchronized String iso8601(){
    return this.sdf.format(new Date());
  }
  @Override public void emitRecord(  String contextName,  String recordName,  OutputRecord outRec){
    writer.print(iso8601());
    writer.print(" ");
    writer.print(contextName);
    writer.print(".");
    writer.print(recordName);
    String separator=": ";
    for (    String tagName : outRec.getTagNames()) {
      writer.print(separator);
      separator=", ";
      writer.print(tagName);
      writer.print("=");
      writer.print(outRec.getTag(tagName));
    }
    for (    String metricName : outRec.getMetricNames()) {
      writer.print(separator);
      separator=", ";
      writer.print(metricName);
      writer.print("=");
      writer.print(outRec.getMetric(metricName));
    }
    writer.println();
  }
  @Override public void flush(){
    writer.flush();
  }
}
