/** 
 * Thrown when we are asked to operate on a region we know nothing about.
 */
public class UnknownRegionException extends IOException {
  private static final long serialVersionUID=1968858760475205392L;
  public UnknownRegionException(  String regionName){
    super(regionName);
  }
}
