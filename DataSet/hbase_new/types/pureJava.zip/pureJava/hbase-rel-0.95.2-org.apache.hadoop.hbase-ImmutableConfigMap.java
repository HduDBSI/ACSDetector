private interface ImmutableConfigMap extends Iterable<Map.Entry<String,String>> {
  String get(  String key);
  String getRaw(  String key);
  Class<?> getClassByName(  String name) throws ClassNotFoundException ;
  int size();
}
