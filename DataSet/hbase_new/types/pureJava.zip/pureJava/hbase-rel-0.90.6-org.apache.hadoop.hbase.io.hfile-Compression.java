/** 
 * Compression related stuff. Copied from hadoop-3315 tfile.
 */
public final class Compression {
  static final Log LOG=LogFactory.getLog(Compression.class);
  /** 
 * Prevent the instantiation of class.
 */
  private Compression(){
    super();
  }
static class FinishOnFlushCompressionStream extends FilterOutputStream {
    public FinishOnFlushCompressionStream(    CompressionOutputStream cout){
      super(cout);
    }
    @Override public void write(    byte b[],    int off,    int len) throws IOException {
      out.write(b,off,len);
    }
    @Override public void flush() throws IOException {
      CompressionOutputStream cout=(CompressionOutputStream)out;
      cout.finish();
      cout.flush();
      cout.resetState();
    }
  }
  /** 
 * Compression algorithms. The ordinal of these cannot change or else you risk breaking all existing HFiles out there.  Even the ones that are not compressed! (They use the NONE algorithm)
 */
  public static enum Algorithm {  LZO("lzo"){
    private transient CompressionCodec lzoCodec;
    @Override CompressionCodec getCodec(    Configuration conf){
      if (lzoCodec == null) {
        try {
          Class<?> externalCodec=ClassLoader.getSystemClassLoader().loadClass("com.hadoop.compression.lzo.LzoCodec");
          lzoCodec=(CompressionCodec)ReflectionUtils.newInstance(externalCodec,new Configuration(conf));
        }
 catch (        ClassNotFoundException e) {
          throw new RuntimeException(e);
        }
      }
      return lzoCodec;
    }
  }
,   GZ("gz"){
    private transient GzipCodec codec;
    @Override DefaultCodec getCodec(    Configuration conf){
      if (codec == null) {
        codec=new GzipCodec();
        codec.setConf(new Configuration(conf));
      }
      return codec;
    }
  }
,   NONE("none"){
    @Override DefaultCodec getCodec(    Configuration conf){
      return null;
    }
    @Override public synchronized InputStream createDecompressionStream(    InputStream downStream,    Decompressor decompressor,    int downStreamBufferSize) throws IOException {
      if (downStreamBufferSize > 0) {
        return new BufferedInputStream(downStream,downStreamBufferSize);
      }
      return downStream;
    }
    @Override public synchronized OutputStream createCompressionStream(    OutputStream downStream,    Compressor compressor,    int downStreamBufferSize) throws IOException {
      if (downStreamBufferSize > 0) {
        return new BufferedOutputStream(downStream,downStreamBufferSize);
      }
      return downStream;
    }
  }
;   private final Configuration conf;
  private final String compressName;
  private static final int DATA_IBUF_SIZE=1 * 1024;
  private static final int DATA_OBUF_SIZE=4 * 1024;
  Algorithm(  String name){
    this.conf=new Configuration();
    this.conf.setBoolean("hadoop.native.lib",true);
    this.compressName=name;
  }
  abstract CompressionCodec getCodec(  Configuration conf);
  public InputStream createDecompressionStream(  InputStream downStream,  Decompressor decompressor,  int downStreamBufferSize) throws IOException {
    CompressionCodec codec=getCodec(conf);
    if (downStreamBufferSize > 0) {
      ((Configurable)codec).getConf().setInt("io.file.buffer.size",downStreamBufferSize);
    }
    CompressionInputStream cis=codec.createInputStream(downStream,decompressor);
    BufferedInputStream bis2=new BufferedInputStream(cis,DATA_IBUF_SIZE);
    return bis2;
  }
  public OutputStream createCompressionStream(  OutputStream downStream,  Compressor compressor,  int downStreamBufferSize) throws IOException {
    CompressionCodec codec=getCodec(conf);
    OutputStream bos1=null;
    if (downStreamBufferSize > 0) {
      bos1=new BufferedOutputStream(downStream,downStreamBufferSize);
    }
 else {
      bos1=downStream;
    }
    ((Configurable)codec).getConf().setInt("io.file.buffer.size",32 * 1024);
    CompressionOutputStream cos=codec.createOutputStream(bos1,compressor);
    BufferedOutputStream bos2=new BufferedOutputStream(new FinishOnFlushCompressionStream(cos),DATA_OBUF_SIZE);
    return bos2;
  }
  public Compressor getCompressor(){
    CompressionCodec codec=getCodec(conf);
    if (codec != null) {
      Compressor compressor=CodecPool.getCompressor(codec);
      if (compressor != null) {
        if (compressor.finished()) {
          LOG.warn("Compressor obtained from CodecPool is already finished()");
        }
        compressor.reset();
      }
      return compressor;
    }
    return null;
  }
  public void returnCompressor(  Compressor compressor){
    if (compressor != null) {
      CodecPool.returnCompressor(compressor);
    }
  }
  public Decompressor getDecompressor(){
    CompressionCodec codec=getCodec(conf);
    if (codec != null) {
      Decompressor decompressor=CodecPool.getDecompressor(codec);
      if (decompressor != null) {
        if (decompressor.finished()) {
          LOG.warn("Deompressor obtained from CodecPool is already finished()");
        }
        decompressor.reset();
      }
      return decompressor;
    }
    return null;
  }
  public void returnDecompressor(  Decompressor decompressor){
    if (decompressor != null) {
      CodecPool.returnDecompressor(decompressor);
    }
  }
  public String getName(){
    return compressName;
  }
}
  public static Algorithm getCompressionAlgorithmByName(  String compressName){
    Algorithm[] algos=Algorithm.class.getEnumConstants();
    for (    Algorithm a : algos) {
      if (a.getName().equals(compressName)) {
        return a;
      }
    }
    throw new IllegalArgumentException("Unsupported compression algorithm name: " + compressName);
  }
  static String[] getSupportedAlgorithms(){
    Algorithm[] algos=Algorithm.class.getEnumConstants();
    String[] ret=new String[algos.length];
    int i=0;
    for (    Algorithm a : algos) {
      ret[i++]=a.getName();
    }
    return ret;
  }
}
