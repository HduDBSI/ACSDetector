public class HBaseRESTTestingUtility {
  static final Log LOG=LogFactory.getLog(HBaseRESTTestingUtility.class);
  private int testServletPort;
  private Server server;
  public int getServletPort(){
    return testServletPort;
  }
  public void startServletContainer(  Configuration conf) throws Exception {
    if (server != null) {
      LOG.error("ServletContainer already running");
      return;
    }
    RESTServlet.getInstance(conf);
    ServletHolder sh=new ServletHolder(ServletContainer.class);
    sh.setInitParameter("com.sun.jersey.config.property.resourceConfigClass",ResourceConfig.class.getCanonicalName());
    sh.setInitParameter("com.sun.jersey.config.property.packages","jetty");
    LOG.info("configured " + ServletContainer.class.getName());
    server=new Server(0);
    server.setSendServerVersion(false);
    server.setSendDateHeader(false);
    Context context=new Context(server,"/",Context.SESSIONS);
    context.addServlet(sh,"/*");
    context.addFilter(GzipFilter.class,"/*",0);
    server.start();
    testServletPort=server.getConnectors()[0].getLocalPort();
    LOG.info("started " + server.getClass().getName() + " on port "+ testServletPort);
  }
  public void shutdownServletContainer(){
    if (server != null)     try {
      server.stop();
      server=null;
      RESTServlet.stop();
    }
 catch (    Exception e) {
      LOG.warn(StringUtils.stringifyException(e));
    }
  }
}
