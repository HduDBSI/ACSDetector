/** 
 * Class that transitions metrics from HLog's MetricsWAL into the metrics subsystem. Implements BaseSource through BaseSourceImpl, following the pattern.
 */
@InterfaceAudience.Private public class MetricsWALSourceImpl extends BaseSourceImpl implements MetricsWALSource {
  private final MetricHistogram appendSizeHisto;
  private final MetricHistogram appendTimeHisto;
  private final MetricHistogram syncTimeHisto;
  private final MutableCounterLong appendCount;
  private final MutableCounterLong slowAppendCount;
  public MetricsWALSourceImpl(){
    this(METRICS_NAME,METRICS_DESCRIPTION,METRICS_CONTEXT,METRICS_JMX_CONTEXT);
  }
  public MetricsWALSourceImpl(  String metricsName,  String metricsDescription,  String metricsContext,  String metricsJmxContext){
    super(metricsName,metricsDescription,metricsContext,metricsJmxContext);
    appendTimeHisto=this.getMetricsRegistry().newHistogram(APPEND_TIME,APPEND_TIME_DESC);
    appendSizeHisto=this.getMetricsRegistry().newHistogram(APPEND_SIZE,APPEND_SIZE_DESC);
    appendCount=this.getMetricsRegistry().newCounter(APPEND_COUNT,APPEND_COUNT_DESC,0l);
    slowAppendCount=this.getMetricsRegistry().newCounter(SLOW_APPEND_COUNT,SLOW_APPEND_COUNT_DESC,0l);
    syncTimeHisto=this.getMetricsRegistry().newHistogram(SYNC_TIME,SYNC_TIME_DESC);
  }
  @Override public void incrementAppendSize(  long size){
    appendSizeHisto.add(size);
  }
  @Override public void incrementAppendTime(  long time){
    appendTimeHisto.add(time);
  }
  @Override public void incrementAppendCount(){
    appendCount.incr();
  }
  @Override public void incrementSlowAppendCount(){
    slowAppendCount.incr();
  }
  @Override public void incrementSyncTime(  long time){
    syncTimeHisto.add(time);
  }
}
