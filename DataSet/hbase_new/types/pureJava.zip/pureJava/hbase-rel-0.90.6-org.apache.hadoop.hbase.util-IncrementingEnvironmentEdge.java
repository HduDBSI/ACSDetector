/** 
 * Uses an incrementing algorithm instead of the default.
 */
public class IncrementingEnvironmentEdge implements EnvironmentEdge {
  private long timeIncrement=1;
  /** 
 * {@inheritDoc}<p/> This method increments a known value for the current time each time this method is called. The first value is 1.
 */
  @Override public synchronized long currentTimeMillis(){
    return timeIncrement++;
  }
}
