@Category(SmallTests.class) public class TestFuzzyRowFilter {
  @Test public void testSatisfiesForward(){
    Assert.assertEquals(FuzzyRowFilter.SatisfiesCode.NEXT_EXISTS,FuzzyRowFilter.satisfies(false,new byte[]{1,(byte)-128,0,0,1},new byte[]{1,0,1},new byte[]{0,1,0}));
    Assert.assertEquals(FuzzyRowFilter.SatisfiesCode.YES,FuzzyRowFilter.satisfies(false,new byte[]{1,(byte)-128,1,0,1},new byte[]{1,0,1},new byte[]{0,1,0}));
    Assert.assertEquals(FuzzyRowFilter.SatisfiesCode.NEXT_EXISTS,FuzzyRowFilter.satisfies(false,new byte[]{1,(byte)-128,2,0,1},new byte[]{1,0,1},new byte[]{0,1,0}));
    Assert.assertEquals(FuzzyRowFilter.SatisfiesCode.NO_NEXT,FuzzyRowFilter.satisfies(false,new byte[]{2,3,1,1,1},new byte[]{1,0,1},new byte[]{0,1,0}));
    Assert.assertEquals(FuzzyRowFilter.SatisfiesCode.YES,FuzzyRowFilter.satisfies(false,new byte[]{1,2,1,3,3},new byte[]{1,2,0,3},new byte[]{0,0,1,0}));
    Assert.assertEquals(FuzzyRowFilter.SatisfiesCode.NEXT_EXISTS,FuzzyRowFilter.satisfies(false,new byte[]{1,1,1,3,0},new byte[]{1,2,0,3},new byte[]{0,0,1,0}));
    Assert.assertEquals(FuzzyRowFilter.SatisfiesCode.NEXT_EXISTS,FuzzyRowFilter.satisfies(false,new byte[]{1,1,1,3,0},new byte[]{1,(byte)245,0,3},new byte[]{0,0,1,0}));
    Assert.assertEquals(FuzzyRowFilter.SatisfiesCode.NO_NEXT,FuzzyRowFilter.satisfies(false,new byte[]{1,(byte)245,1,3,0},new byte[]{1,1,0,3},new byte[]{0,0,1,0}));
    Assert.assertEquals(FuzzyRowFilter.SatisfiesCode.NO_NEXT,FuzzyRowFilter.satisfies(false,new byte[]{1,3,1,3,0},new byte[]{1,2,0,3},new byte[]{0,0,1,0}));
    Assert.assertEquals(FuzzyRowFilter.SatisfiesCode.NO_NEXT,FuzzyRowFilter.satisfies(false,new byte[]{2,1,1,1,0},new byte[]{1,2,0,3},new byte[]{0,0,1,0}));
    Assert.assertEquals(FuzzyRowFilter.SatisfiesCode.NEXT_EXISTS,FuzzyRowFilter.satisfies(false,new byte[]{1,2,1,0,1},new byte[]{0,1,2},new byte[]{1,0,0}));
  }
  @Test public void testSatisfiesReverse(){
    Assert.assertEquals(FuzzyRowFilter.SatisfiesCode.NO_NEXT,FuzzyRowFilter.satisfies(true,new byte[]{1,(byte)-128,0,0,1},new byte[]{1,0,1},new byte[]{0,1,0}));
    Assert.assertEquals(FuzzyRowFilter.SatisfiesCode.YES,FuzzyRowFilter.satisfies(true,new byte[]{1,(byte)-128,1,0,1},new byte[]{1,0,1},new byte[]{0,1,0}));
    Assert.assertEquals(FuzzyRowFilter.SatisfiesCode.NEXT_EXISTS,FuzzyRowFilter.satisfies(true,new byte[]{1,(byte)-128,2,0,1},new byte[]{1,0,1},new byte[]{0,1,0}));
    Assert.assertEquals(FuzzyRowFilter.SatisfiesCode.NEXT_EXISTS,FuzzyRowFilter.satisfies(true,new byte[]{2,3,1,1,1},new byte[]{1,0,1},new byte[]{0,1,0}));
    Assert.assertEquals(FuzzyRowFilter.SatisfiesCode.YES,FuzzyRowFilter.satisfies(true,new byte[]{1,2,1,3,3},new byte[]{1,2,0,3},new byte[]{0,0,1,0}));
    Assert.assertEquals(FuzzyRowFilter.SatisfiesCode.NO_NEXT,FuzzyRowFilter.satisfies(true,new byte[]{1,1,1,3,0},new byte[]{1,2,0,3},new byte[]{0,0,1,0}));
    Assert.assertEquals(FuzzyRowFilter.SatisfiesCode.NO_NEXT,FuzzyRowFilter.satisfies(true,new byte[]{1,1,1,3,0},new byte[]{1,(byte)245,0,3},new byte[]{0,0,1,0}));
    Assert.assertEquals(FuzzyRowFilter.SatisfiesCode.NEXT_EXISTS,FuzzyRowFilter.satisfies(true,new byte[]{1,(byte)245,1,3,0},new byte[]{1,1,0,3},new byte[]{0,0,1,0}));
    Assert.assertEquals(FuzzyRowFilter.SatisfiesCode.NEXT_EXISTS,FuzzyRowFilter.satisfies(true,new byte[]{1,3,1,3,0},new byte[]{1,2,0,3},new byte[]{0,0,1,0}));
    Assert.assertEquals(FuzzyRowFilter.SatisfiesCode.NEXT_EXISTS,FuzzyRowFilter.satisfies(true,new byte[]{2,1,1,1,0},new byte[]{1,2,0,3},new byte[]{0,0,1,0}));
    Assert.assertEquals(FuzzyRowFilter.SatisfiesCode.NEXT_EXISTS,FuzzyRowFilter.satisfies(true,new byte[]{1,2,1,0,1},new byte[]{0,1,2},new byte[]{1,0,0}));
  }
  @Test public void testGetNextForFuzzyRuleForward(){
    assertNext(false,new byte[]{0,1,2},new byte[]{1,0,0},new byte[]{1,2,1,0,1},new byte[]{2,1,2,0,0});
    assertNext(false,new byte[]{0,1,2},new byte[]{1,0,0},new byte[]{1,1,2,0,1},new byte[]{1,1,2,0,2});
    assertNext(false,new byte[]{0,1,0,2,0},new byte[]{1,0,1,0,1},new byte[]{1,0,2,0,1},new byte[]{1,1,0,2,0});
    assertNext(false,new byte[]{1,0,1},new byte[]{0,1,0},new byte[]{1,(byte)128,2,0,1},new byte[]{1,(byte)129,1,0,0});
    assertNext(false,new byte[]{0,1,0,1},new byte[]{1,0,1,0},new byte[]{5,1,0,1},new byte[]{5,1,1,1});
    assertNext(false,new byte[]{0,1,0,1},new byte[]{1,0,1,0},new byte[]{5,1,0,1,1},new byte[]{5,1,0,1,2});
    assertNext(false,new byte[]{0,1,0,0},new byte[]{1,0,1,1},new byte[]{5,1,(byte)255,1},new byte[]{5,1,(byte)255,2});
    assertNext(false,new byte[]{0,1,0,1},new byte[]{1,0,1,0},new byte[]{5,1,(byte)255,1},new byte[]{6,1,0,1});
    assertNext(false,new byte[]{0,1,0,1},new byte[]{1,0,1,0},new byte[]{5,1,(byte)255,0},new byte[]{5,1,(byte)255,1});
    assertNext(false,new byte[]{5,1,1,0},new byte[]{0,0,1,1},new byte[]{5,1,(byte)255,1},new byte[]{5,1,(byte)255,2});
    assertNext(false,new byte[]{1,1,1,1},new byte[]{0,0,1,1},new byte[]{1,1,2,2},new byte[]{1,1,2,3});
    assertNext(false,new byte[]{1,1,1,1},new byte[]{0,0,1,1},new byte[]{1,1,3,2},new byte[]{1,1,3,3});
    assertNext(false,new byte[]{1,1,1,1},new byte[]{1,1,1,1},new byte[]{1,1,2,3},new byte[]{1,1,2,4});
    assertNext(false,new byte[]{1,1,1,1},new byte[]{1,1,1,1},new byte[]{1,1,3,2},new byte[]{1,1,3,3});
    assertNext(false,new byte[]{1,1,0,0},new byte[]{0,0,1,1},new byte[]{0,1,3,2},new byte[]{1,1,0,0});
    Assert.assertNull(FuzzyRowFilter.getNextForFuzzyRule(new byte[]{2,3,1,1,1},new byte[]{1,0,1},new byte[]{0,1,0}));
    Assert.assertNull(FuzzyRowFilter.getNextForFuzzyRule(new byte[]{1,(byte)245,1,3,0},new byte[]{1,1,0,3},new byte[]{0,0,1,0}));
    Assert.assertNull(FuzzyRowFilter.getNextForFuzzyRule(new byte[]{1,3,1,3,0},new byte[]{1,2,0,3},new byte[]{0,0,1,0}));
    Assert.assertNull(FuzzyRowFilter.getNextForFuzzyRule(new byte[]{2,1,1,1,0},new byte[]{1,2,0,3},new byte[]{0,0,1,0}));
  }
  @Test public void testGetNextForFuzzyRuleReverse(){
    assertNext(true,new byte[]{0,1,2},new byte[]{1,0,0},new byte[]{1,2,1,0,1},new byte[]{1,1,2,(byte)0xFF,(byte)0xFF});
    assertNext(true,new byte[]{0,1,0,2,0},new byte[]{1,0,1,0,1},new byte[]{1,2,1,3,1},new byte[]{1,1,0,2,0});
    assertNext(true,new byte[]{1,0,1},new byte[]{0,1,0},new byte[]{1,(byte)128,2,0,1},new byte[]{1,(byte)128,1,(byte)0xFF,(byte)0xFF});
    assertNext(true,new byte[]{0,1,0,1},new byte[]{1,0,1,0},new byte[]{5,1,0,2,1},new byte[]{5,1,0,1,(byte)0xFF});
    assertNext(true,new byte[]{0,1,0,0},new byte[]{1,0,1,1},new byte[]{5,1,(byte)255,1},new byte[]{5,1,(byte)255,0});
    assertNext(true,new byte[]{0,1,0,1},new byte[]{1,0,1,0},new byte[]{5,1,0,1},new byte[]{4,1,(byte)255,1});
    assertNext(true,new byte[]{0,1,0,1},new byte[]{1,0,1,0},new byte[]{5,1,(byte)255,0},new byte[]{5,1,(byte)254,1});
    assertNext(true,new byte[]{1,1,0,0},new byte[]{0,0,1,1},new byte[]{2,1,3,2},new byte[]{1,1,0,0});
    assertNext(true,new byte[]{1,0,1},new byte[]{0,1,0},new byte[]{2,3,1,1,1},new byte[]{1,0,1,(byte)0xFF,(byte)0xFF});
    assertNext(true,new byte[]{1,1,0,3},new byte[]{0,0,1,0},new byte[]{1,(byte)245,1,3,0},new byte[]{1,1,0,3,(byte)0xFF});
    assertNext(true,new byte[]{1,2,0,3},new byte[]{0,0,1,0},new byte[]{1,3,1,3,0},new byte[]{1,2,0,3,(byte)0xFF});
    assertNext(true,new byte[]{1,2,0,3},new byte[]{0,0,1,0},new byte[]{2,1,1,1,0},new byte[]{1,2,0,3,(byte)0xFF});
    assertNext(true,new byte[]{1,0,1},new byte[]{0,1,0},new byte[]{1,(byte)128,2},new byte[]{1,(byte)128,1});
    assertNext(true,new byte[]{0,1,0,1},new byte[]{1,0,1,0},new byte[]{5,1,0,2},new byte[]{5,1,0,1});
    assertNext(true,new byte[]{5,1,1,0},new byte[]{0,0,1,1},new byte[]{5,1,(byte)0xFF,1},new byte[]{5,1,(byte)0xFF,0});
    assertNext(true,new byte[]{1,1,1,1},new byte[]{0,0,1,1},new byte[]{1,1,2,2},new byte[]{1,1,2,1});
    assertNext(true,new byte[]{1,1,1,1},new byte[]{1,1,1,1},new byte[]{1,1,2,3},new byte[]{1,1,2,2});
    Assert.assertNull(FuzzyRowFilter.getNextForFuzzyRule(true,new byte[]{1,1,1,3,0},new byte[]{1,2,0,3},new byte[]{0,0,1,0}));
  }
  private static void assertNext(  boolean reverse,  byte[] fuzzyRow,  byte[] mask,  byte[] current,  byte[] expected){
    byte[] nextForFuzzyRule=FuzzyRowFilter.getNextForFuzzyRule(reverse,current,fuzzyRow,mask);
    Assert.assertEquals(Bytes.toStringBinary(expected),Bytes.toStringBinary(nextForFuzzyRule));
  }
}
