/** 
 * A version mismatch for the RPC protocol.
 */
@SuppressWarnings("serial") public static class VersionMismatch extends IOException {
  private static final long serialVersionUID=0;
  private String interfaceName;
  private long clientVersion;
  private long serverVersion;
  /** 
 * Create a version mismatch exception
 * @param interfaceName the name of the protocol mismatch
 * @param clientVersion the client's version of the protocol
 * @param serverVersion the server's version of the protocol
 */
  public VersionMismatch(  String interfaceName,  long clientVersion,  long serverVersion){
    super("Protocol " + interfaceName + " version mismatch. (client = "+ clientVersion+ ", server = "+ serverVersion+ ")");
    this.interfaceName=interfaceName;
    this.clientVersion=clientVersion;
    this.serverVersion=serverVersion;
  }
  /** 
 * Get the interface name
 * @return the java class name(eg. org.apache.hadoop.mapred.InterTrackerProtocol)
 */
  public String getInterfaceName(){
    return interfaceName;
  }
  /** 
 * @return the client's preferred version
 */
  public long getClientVersion(){
    return clientVersion;
  }
  /** 
 * @return the server's agreed to version.
 */
  public long getServerVersion(){
    return serverVersion;
  }
}
