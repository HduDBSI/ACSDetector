/** 
 * Tests for various kinds of TableNames.
 */
@Category({MiscTests.class,SmallTests.class}) public class TestTableName {
  private static String[] emptyNames={""," "};
  private static String[] invalidNamespace={":a","%:a"};
  private static String[] legalTableNames={"foo","with-dash_under.dot","_under_start_ok","with-dash.with_underscore","02-01-2012.my_table_01-02","xyz._mytable_","9_9_0.table_02","dot1.dot2.table","new.-mytable","with-dash.with.dot","legal..t2","legal..legal.t2","trailingdots..","trailing.dots...","ns:mytable","ns:_mytable_","ns:my_table_01-02"};
  private static String[] illegalTableNames={".dot_start_illegal","-dash_start_illegal","spaces not ok","-dash-.start_illegal","new.table with space","01 .table","ns:-illegaldash","new:.illegaldot","new:illegalcolon1:","new:illegalcolon1:2"};
static class Names {
    String ns;
    byte[] nsb;
    String tn;
    byte[] tnb;
    String nn;
    byte[] nnb;
    Names(    String ns,    String tn){
      this.ns=ns;
      nsb=Bytes.toBytes(ns);
      this.tn=tn;
      tnb=Bytes.toBytes(tn);
      nn=this.ns + ":" + this.tn;
      nnb=Bytes.toBytes(nn);
    }
    @Override public boolean equals(    Object o){
      if (this == o) {
        return true;
      }
      if (o == null || getClass() != o.getClass()) {
        return false;
      }
      Names names=(Names)o;
      if (!ns.equals(names.ns)) {
        return false;
      }
      if (!tn.equals(names.tn)) {
        return false;
      }
      return true;
    }
    @Override public int hashCode(){
      int result=ns.hashCode();
      result=31 * result + tn.hashCode();
      return result;
    }
  }
  private static Names[] names=new Names[]{new Names("n1","n1"),new Names("n2","n2"),new Names("table1","table1"),new Names("table2","table2"),new Names("table2","table1"),new Names("table1","table2"),new Names("n1","table1"),new Names("n1","table1"),new Names("n2","table2"),new Names("n2","table2")};
  @Test public void testInvalidNamespace(){
    for (    String tn : invalidNamespace) {
      try {
        TableName.isLegalFullyQualifiedTableName(Bytes.toBytes(tn));
      }
 catch (      IllegalArgumentException ie) {
        continue;
      }
      fail("Exception not thrown for ns: " + tn);
    }
  }
  @Test public void testEmptyNamespaceName(){
    for (    String nn : emptyNames) {
      try {
        TableName.isLegalNamespaceName(Bytes.toBytes(nn));
      }
 catch (      IllegalArgumentException iae) {
        continue;
      }
      fail("Exception not thrown for ns: " + nn);
    }
  }
  @Test public void testEmptyTableName(){
    for (    String tn : emptyNames) {
      try {
        TableName.isLegalFullyQualifiedTableName(Bytes.toBytes(tn));
      }
 catch (      IllegalArgumentException iae) {
        continue;
      }
      fail("Exception not thrown for table name: " + tn);
    }
  }
  @Test public void testLegalHTableNames(){
    for (    String tn : legalTableNames) {
      TableName.isLegalFullyQualifiedTableName(Bytes.toBytes(tn));
    }
  }
  @Test public void testIllegalHTableNames(){
    for (    String tn : illegalTableNames) {
      try {
        TableName.isLegalFullyQualifiedTableName(Bytes.toBytes(tn));
      }
 catch (      Exception e) {
        continue;
      }
      fail("Exception not thrown for table name: " + tn);
    }
  }
  @Test public void testValueOf(){
    Map<String,TableName> inCache=new HashMap<>();
    for (    Names name : names) {
      inCache.put(name.nn,TableName.valueOf(name.ns,name.tn));
    }
    for (    Names name : names) {
      assertSame(inCache.get(name.nn),validateNames(TableName.valueOf(name.ns,name.tn),name));
      assertSame(inCache.get(name.nn),validateNames(TableName.valueOf(name.nsb,name.tnb),name));
      assertSame(inCache.get(name.nn),validateNames(TableName.valueOf(name.nn),name));
      assertSame(inCache.get(name.nn),validateNames(TableName.valueOf(name.nnb),name));
      assertSame(inCache.get(name.nn),validateNames(TableName.valueOf(ByteBuffer.wrap(name.nsb),ByteBuffer.wrap(name.tnb)),name));
    }
  }
  private TableName validateNames(  TableName expected,  Names names){
    assertEquals(expected.getNameAsString(),names.nn);
    assertArrayEquals(expected.getName(),names.nnb);
    assertEquals(expected.getQualifierAsString(),names.tn);
    assertArrayEquals(expected.getQualifier(),names.tnb);
    assertEquals(expected.getNamespaceAsString(),names.ns);
    assertArrayEquals(expected.getNamespace(),names.nsb);
    return expected;
  }
}
