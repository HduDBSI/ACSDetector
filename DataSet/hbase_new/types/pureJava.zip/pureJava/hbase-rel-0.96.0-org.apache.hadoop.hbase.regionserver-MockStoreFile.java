static class MockStoreFile extends StoreFile {
  long length=0;
  boolean isRef=false;
  long ageInDisk;
  long sequenceid;
  MockStoreFile(  long length,  long ageInDisk,  boolean isRef,  long sequenceid) throws IOException {
    super(TEST_UTIL.getTestFileSystem(),TEST_FILE,TEST_UTIL.getConfiguration(),new CacheConfig(TEST_UTIL.getConfiguration()),BloomType.NONE,NoOpDataBlockEncoder.INSTANCE);
    this.length=length;
    this.isRef=isRef;
    this.ageInDisk=ageInDisk;
    this.sequenceid=sequenceid;
  }
  void setLength(  long newLen){
    this.length=newLen;
  }
  @Override public long getMaxSequenceId(){
    return sequenceid;
  }
  @Override public boolean isMajorCompaction(){
    return false;
  }
  @Override public boolean isReference(){
    return this.isRef;
  }
  @Override public StoreFile.Reader getReader(){
    final long len=this.length;
    return new StoreFile.Reader(){
      @Override public long length(){
        return len;
      }
    }
;
  }
  @Override public String toString(){
    return "MockStoreFile{" + "length=" + length + ", isRef="+ isRef+ ", ageInDisk="+ ageInDisk+ ", sequenceid="+ sequenceid+ '}';
  }
}
