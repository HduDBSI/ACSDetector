private static class HFileBlockPair {
  BlockCacheKey blockName;
  HFileBlock block;
}
