/** 
 * Simple filter that returns first N columns on row only. This filter was written to test filters in Get and as soon as it gets its quota of columns,  {@link #filterAllRemaining()} returns true.  Thismakes this filter unsuitable as a Scan filter.
 */
@InterfaceAudience.Public @InterfaceStability.Stable public class ColumnCountGetFilter extends FilterBase {
  private int limit=0;
  private int count=0;
  public ColumnCountGetFilter(  final int n){
    Preconditions.checkArgument(n >= 0,"limit be positive %s",n);
    this.limit=n;
  }
  public int getLimit(){
    return limit;
  }
  @Override public boolean filterAllRemaining(){
    return this.count > this.limit;
  }
  @Override public ReturnCode filterKeyValue(  Cell v){
    this.count++;
    return filterAllRemaining() ? ReturnCode.NEXT_COL : ReturnCode.INCLUDE_AND_NEXT_COL;
  }
  @Override public void reset(){
    this.count=0;
  }
  public static Filter createFilterFromArguments(  ArrayList<byte[]> filterArguments){
    Preconditions.checkArgument(filterArguments.size() == 1,"Expected 1 but got: %s",filterArguments.size());
    int limit=ParseFilter.convertByteArrayToInt(filterArguments.get(0));
    return new ColumnCountGetFilter(limit);
  }
  /** 
 * @return The filter serialized using pb
 */
  public byte[] toByteArray(){
    FilterProtos.ColumnCountGetFilter.Builder builder=FilterProtos.ColumnCountGetFilter.newBuilder();
    builder.setLimit(this.limit);
    return builder.build().toByteArray();
  }
  /** 
 * @param pbBytes A pb serialized {@link ColumnCountGetFilter} instance
 * @return An instance of {@link ColumnCountGetFilter} made from <code>bytes</code>
 * @throws org.apache.hadoop.hbase.exceptions.DeserializationException
 * @see #toByteArray
 */
  public static ColumnCountGetFilter parseFrom(  final byte[] pbBytes) throws DeserializationException {
    FilterProtos.ColumnCountGetFilter proto;
    try {
      proto=FilterProtos.ColumnCountGetFilter.parseFrom(pbBytes);
    }
 catch (    InvalidProtocolBufferException e) {
      throw new DeserializationException(e);
    }
    return new ColumnCountGetFilter(proto.getLimit());
  }
  /** 
 * @param other
 * @return true if and only if the fields of the filter that are serializedare equal to the corresponding fields in other.  Used for testing.
 */
  boolean areSerializedFieldsEqual(  Filter o){
    if (o == this)     return true;
    if (!(o instanceof ColumnCountGetFilter))     return false;
    ColumnCountGetFilter other=(ColumnCountGetFilter)o;
    return this.getLimit() == other.getLimit();
  }
  @Override public String toString(){
    return this.getClass().getSimpleName() + " " + this.limit;
  }
}
