/** 
 * Client used for managing region server group information.
 */
@InterfaceAudience.Private public class RSGroupAdminClient implements RSGroupAdmin {
  private RSGroupAdminService.BlockingInterface stub;
  private Admin admin;
  public RSGroupAdminClient(  Connection conn) throws IOException {
    admin=conn.getAdmin();
    stub=RSGroupAdminService.newBlockingStub(admin.coprocessorService());
  }
  @Override public RSGroupInfo getRSGroupInfo(  String groupName) throws IOException {
    try {
      GetRSGroupInfoResponse resp=stub.getRSGroupInfo(null,GetRSGroupInfoRequest.newBuilder().setRSGroupName(groupName).build());
      if (resp.hasRSGroupInfo()) {
        return RSGroupProtobufUtil.toGroupInfo(resp.getRSGroupInfo());
      }
      return null;
    }
 catch (    ServiceException e) {
      throw ProtobufUtil.handleRemoteException(e);
    }
  }
  @Override public RSGroupInfo getRSGroupInfoOfTable(  TableName tableName) throws IOException {
    GetRSGroupInfoOfTableRequest request=GetRSGroupInfoOfTableRequest.newBuilder().setTableName(ProtobufUtil.toProtoTableName(tableName)).build();
    try {
      GetRSGroupInfoOfTableResponse resp=stub.getRSGroupInfoOfTable(null,request);
      if (resp.hasRSGroupInfo()) {
        return RSGroupProtobufUtil.toGroupInfo(resp.getRSGroupInfo());
      }
      return null;
    }
 catch (    ServiceException e) {
      throw ProtobufUtil.handleRemoteException(e);
    }
  }
  @Override public void moveServers(  Set<Address> servers,  String targetGroup) throws IOException {
    Set<HBaseProtos.ServerName> hostPorts=Sets.newHashSet();
    for (    Address el : servers) {
      hostPorts.add(HBaseProtos.ServerName.newBuilder().setHostName(el.getHostname()).setPort(el.getPort()).build());
    }
    MoveServersRequest request=MoveServersRequest.newBuilder().setTargetGroup(targetGroup).addAllServers(hostPorts).build();
    try {
      stub.moveServers(null,request);
    }
 catch (    ServiceException e) {
      throw ProtobufUtil.handleRemoteException(e);
    }
  }
  @Override public void moveTables(  Set<TableName> tables,  String targetGroup) throws IOException {
    MoveTablesRequest.Builder builder=MoveTablesRequest.newBuilder().setTargetGroup(targetGroup);
    for (    TableName tableName : tables) {
      builder.addTableName(ProtobufUtil.toProtoTableName(tableName));
      if (!admin.tableExists(tableName)) {
        throw new TableNotFoundException(tableName);
      }
    }
    try {
      stub.moveTables(null,builder.build());
    }
 catch (    ServiceException e) {
      throw ProtobufUtil.handleRemoteException(e);
    }
  }
  @Override public void addRSGroup(  String groupName) throws IOException {
    AddRSGroupRequest request=AddRSGroupRequest.newBuilder().setRSGroupName(groupName).build();
    try {
      stub.addRSGroup(null,request);
    }
 catch (    ServiceException e) {
      throw ProtobufUtil.handleRemoteException(e);
    }
  }
  @Override public void removeRSGroup(  String name) throws IOException {
    RemoveRSGroupRequest request=RemoveRSGroupRequest.newBuilder().setRSGroupName(name).build();
    try {
      stub.removeRSGroup(null,request);
    }
 catch (    ServiceException e) {
      throw ProtobufUtil.handleRemoteException(e);
    }
  }
  @Override public boolean balanceRSGroup(  String groupName) throws IOException {
    BalanceRSGroupRequest request=BalanceRSGroupRequest.newBuilder().setRSGroupName(groupName).build();
    try {
      return stub.balanceRSGroup(null,request).getBalanceRan();
    }
 catch (    ServiceException e) {
      throw ProtobufUtil.handleRemoteException(e);
    }
  }
  @Override public List<RSGroupInfo> listRSGroups() throws IOException {
    try {
      List<RSGroupProtos.RSGroupInfo> resp=stub.listRSGroupInfos(null,ListRSGroupInfosRequest.getDefaultInstance()).getRSGroupInfoList();
      List<RSGroupInfo> result=new ArrayList<>(resp.size());
      for (      RSGroupProtos.RSGroupInfo entry : resp) {
        result.add(RSGroupProtobufUtil.toGroupInfo(entry));
      }
      return result;
    }
 catch (    ServiceException e) {
      throw ProtobufUtil.handleRemoteException(e);
    }
  }
  @Override public RSGroupInfo getRSGroupOfServer(  Address hostPort) throws IOException {
    GetRSGroupInfoOfServerRequest request=GetRSGroupInfoOfServerRequest.newBuilder().setServer(HBaseProtos.ServerName.newBuilder().setHostName(hostPort.getHostname()).setPort(hostPort.getPort()).build()).build();
    try {
      GetRSGroupInfoOfServerResponse resp=stub.getRSGroupInfoOfServer(null,request);
      if (resp.hasRSGroupInfo()) {
        return RSGroupProtobufUtil.toGroupInfo(resp.getRSGroupInfo());
      }
      return null;
    }
 catch (    ServiceException e) {
      throw ProtobufUtil.handleRemoteException(e);
    }
  }
  @Override public void moveServersAndTables(  Set<Address> servers,  Set<TableName> tables,  String targetGroup) throws IOException {
    MoveServersAndTablesRequest.Builder builder=MoveServersAndTablesRequest.newBuilder().setTargetGroup(targetGroup);
    for (    Address el : servers) {
      builder.addServers(HBaseProtos.ServerName.newBuilder().setHostName(el.getHostname()).setPort(el.getPort()).build());
    }
    for (    TableName tableName : tables) {
      builder.addTableName(ProtobufUtil.toProtoTableName(tableName));
      if (!admin.tableExists(tableName)) {
        throw new TableNotFoundException(tableName);
      }
    }
    try {
      stub.moveServersAndTables(null,builder.build());
    }
 catch (    ServiceException e) {
      throw ProtobufUtil.handleRemoteException(e);
    }
  }
  @Override public void removeServers(  Set<Address> servers) throws IOException {
    Set<HBaseProtos.ServerName> hostPorts=Sets.newHashSet();
    for (    Address el : servers) {
      hostPorts.add(HBaseProtos.ServerName.newBuilder().setHostName(el.getHostname()).setPort(el.getPort()).build());
    }
    RemoveServersRequest request=RemoveServersRequest.newBuilder().addAllServers(hostPorts).build();
    try {
      stub.removeServers(null,request);
    }
 catch (    ServiceException e) {
      throw ProtobufUtil.handleRemoteException(e);
    }
  }
  @Override public void renameRSGroup(  String oldName,  String newName) throws IOException {
    RenameRSGroupRequest request=RenameRSGroupRequest.newBuilder().setOldRsgroupName(oldName).setNewRsgroupName(newName).build();
    try {
      stub.renameRSGroup(null,request);
    }
 catch (    ServiceException e) {
      throw ProtobufUtil.handleRemoteException(e);
    }
  }
}
