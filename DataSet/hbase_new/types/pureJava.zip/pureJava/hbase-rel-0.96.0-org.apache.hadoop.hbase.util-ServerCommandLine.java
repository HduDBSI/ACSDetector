/** 
 * Base class for command lines that start up various HBase daemons.
 */
@InterfaceAudience.Private public abstract class ServerCommandLine extends Configured implements Tool {
  private static final Log LOG=LogFactory.getLog(ServerCommandLine.class);
  @SuppressWarnings("serial") private static final Set<String> DEFAULT_SKIP_WORDS=new HashSet<String>(){
{
      add("secret");
      add("passwd");
      add("password");
      add("credential");
    }
  }
;
  /** 
 * Implementing subclasses should return a usage string to print out.
 */
  protected abstract String getUsage();
  /** 
 * Print usage information for this command line.
 * @param message if not null, print this message before the usage info.
 */
  protected void usage(  String message){
    if (message != null) {
      System.err.println(message);
      System.err.println("");
    }
    System.err.println(getUsage());
  }
  /** 
 * Log information about the currently running JVM.
 */
  public static void logJVMInfo(){
    RuntimeMXBean runtime=ManagementFactory.getRuntimeMXBean();
    if (runtime != null) {
      LOG.info("vmName=" + runtime.getVmName() + ", vmVendor="+ runtime.getVmVendor()+ ", vmVersion="+ runtime.getVmVersion());
      LOG.info("vmInputArguments=" + runtime.getInputArguments());
    }
  }
  /** 
 * Logs information about the currently running JVM process including the environment variables. Logging of env vars can be disabled by setting  {@code "hbase.envvars.logging.disabled"} to {@code "true"}. <p>If enabled, you can also exclude environment variables containing certain substrings by setting  {@code "hbase.envvars.logging.skipwords"}to comma separated list of such substrings.
 */
  public static void logProcessInfo(  Configuration conf){
    if (conf == null || !conf.getBoolean("hbase.envvars.logging.disabled",false)) {
      Set<String> skipWords=new HashSet<String>(DEFAULT_SKIP_WORDS);
      if (conf != null) {
        String[] confSkipWords=conf.getStrings("hbase.envvars.logging.skipwords");
        if (confSkipWords != null) {
          skipWords.addAll(Arrays.asList(confSkipWords));
        }
      }
      nextEnv:       for (      Entry<String,String> entry : System.getenv().entrySet()) {
        String key=entry.getKey().toLowerCase();
        String value=entry.getValue().toLowerCase();
        for (        String skipWord : skipWords) {
          if (key.contains(skipWord) || value.contains(skipWord))           continue nextEnv;
        }
        LOG.info("env:" + entry);
      }
    }
    logJVMInfo();
  }
  /** 
 * Parse and run the given command line. This may exit the JVM if a nonzero exit code is returned from <code>run()</code>.
 */
  public void doMain(  String args[]){
    try {
      int ret=ToolRunner.run(HBaseConfiguration.create(),this,args);
      if (ret != 0) {
        System.exit(ret);
      }
    }
 catch (    Exception e) {
      LOG.error("Failed to run",e);
      System.exit(-1);
    }
  }
}
