/** 
 * Stores additional per-server information about the regions added/removed during the run of the balancing algorithm. For servers that receive additional regions, we are not updating the number of regions in HServerInfo once we decide to reassign regions to a server, but we need this information later in the algorithm.  This is stored in <b>numRegionsAdded</b>. For servers that shed regions, we need to track which regions we have already shed.  <b>nextRegionForUnload</b> contains the index in the list of regions on the server that is the next to be shed.
 */
private static class BalanceInfo {
  private final int nextRegionForUnload;
  private final int numRegionsAdded;
  public BalanceInfo(  int nextRegionForUnload,  int numRegionsAdded){
    this.nextRegionForUnload=nextRegionForUnload;
    this.numRegionsAdded=numRegionsAdded;
  }
  public int getNextRegionForUnload(){
    return nextRegionForUnload;
  }
  public int getNumRegionsAdded(){
    return numRegionsAdded;
  }
}
