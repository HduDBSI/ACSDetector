/** 
 * Accounting of current heap and data sizes. Thread-safe. Many threads can do updates against this single instance.
 * @see NonThreadSafeMemStoreSizing
 * @see MemStoreSize
 */
@InterfaceAudience.Private class ThreadSafeMemStoreSizing implements MemStoreSizing {
  private final AtomicLong dataSize=new AtomicLong();
  private final AtomicLong heapSize=new AtomicLong();
  private final AtomicLong offHeapSize=new AtomicLong();
  private final AtomicInteger cellsCount=new AtomicInteger();
  ThreadSafeMemStoreSizing(){
    this(0,0,0,0);
  }
  ThreadSafeMemStoreSizing(  MemStoreSize mss){
    this(mss.getDataSize(),mss.getHeapSize(),mss.getOffHeapSize(),mss.getCellsCount());
  }
  ThreadSafeMemStoreSizing(  long dataSize,  long heapSize,  long offHeapSize,  int cellsCount){
    incMemStoreSize(dataSize,heapSize,offHeapSize,cellsCount);
  }
  public MemStoreSize getMemStoreSize(){
    return new MemStoreSize(getDataSize(),getHeapSize(),getOffHeapSize(),getCellsCount());
  }
  @Override public long incMemStoreSize(  long dataSizeDelta,  long heapSizeDelta,  long offHeapSizeDelta,  int cellsCountDelta){
    this.offHeapSize.addAndGet(offHeapSizeDelta);
    this.heapSize.addAndGet(heapSizeDelta);
    this.cellsCount.addAndGet(cellsCountDelta);
    return this.dataSize.addAndGet(dataSizeDelta);
  }
  @Override public boolean compareAndSetDataSize(  long expected,  long updated){
    return dataSize.compareAndSet(expected,updated);
  }
  @Override public long getDataSize(){
    return dataSize.get();
  }
  @Override public long getHeapSize(){
    return heapSize.get();
  }
  @Override public long getOffHeapSize(){
    return offHeapSize.get();
  }
  @Override public int getCellsCount(){
    return cellsCount.get();
  }
  @Override public String toString(){
    return getMemStoreSize().toString();
  }
}
