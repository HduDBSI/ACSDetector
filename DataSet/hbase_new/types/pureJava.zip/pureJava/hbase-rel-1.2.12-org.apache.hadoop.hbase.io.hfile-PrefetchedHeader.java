/** 
 * We always prefetch the header of the next block, so that we know its on-disk size in advance and can read it in one operation.
 */
private static class PrefetchedHeader {
  long offset=-1;
  byte[] header=new byte[HConstants.HFILEBLOCK_HEADER_SIZE];
  final ByteBuffer buf=ByteBuffer.wrap(header,0,HConstants.HFILEBLOCK_HEADER_SIZE);
}
