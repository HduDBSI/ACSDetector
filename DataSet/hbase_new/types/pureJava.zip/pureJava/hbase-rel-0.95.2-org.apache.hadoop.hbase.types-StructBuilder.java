/** 
 * A helper for building  {@link Struct} instances.
 */
@InterfaceAudience.Public @InterfaceStability.Evolving public class StructBuilder {
  protected final List<DataType<?>> fields=new ArrayList<DataType<?>>();
  /** 
 * Create an empty  {@code StructBuilder}.
 */
  public StructBuilder(){
  }
  /** 
 * Append  {@code field} to the sequence of accumulated fields.
 */
  public StructBuilder add(  DataType<?> field){
    fields.add(field);
    return this;
  }
  /** 
 * Retrieve the  {@link Struct} represented by {@code this}.
 */
  public Struct toStruct(){
    return new Struct(fields.toArray(new DataType<?>[fields.size()]));
  }
  /** 
 * Reset the sequence of accumulated fields.
 */
  public StructBuilder reset(){
    fields.clear();
    return this;
  }
}
