public class FaultySequenceFileLogReader extends SequenceFileLogReader {
  enum FailureType {  BEGINNING,   MIDDLE,   END,   NONE}
  Queue<Entry> nextQueue=new LinkedList<Entry>();
  int numberOfFileEntries=0;
  FailureType getFailureType(){
    return FailureType.valueOf(conf.get("faultysequencefilelogreader.failuretype","NONE"));
  }
  @Override public HLog.Entry next(  HLog.Entry reuse) throws IOException {
    this.entryStart=this.reader.getPosition();
    boolean b=true;
    if (nextQueue.isEmpty()) {
      while (b == true) {
        HLogKey key=HLog.newKey(conf);
        WALEdit val=new WALEdit();
        HLog.Entry e=new HLog.Entry(key,val);
        b=this.reader.next(e.getKey(),e.getEdit());
        nextQueue.offer(e);
        numberOfFileEntries++;
      }
    }
    if (nextQueue.size() == this.numberOfFileEntries && getFailureType() == FailureType.BEGINNING) {
      throw this.addFileInfoToException(new IOException("fake Exception"));
    }
 else     if (nextQueue.size() == this.numberOfFileEntries / 2 && getFailureType() == FailureType.MIDDLE) {
      throw this.addFileInfoToException(new IOException("fake Exception"));
    }
 else     if (nextQueue.size() == 1 && getFailureType() == FailureType.END) {
      throw this.addFileInfoToException(new IOException("fake Exception"));
    }
    if (nextQueue.peek() != null) {
      edit++;
    }
    Entry e=nextQueue.poll();
    if (e.getEdit().isEmpty()) {
      return null;
    }
    return e;
  }
}
