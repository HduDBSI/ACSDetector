/** 
 * Like  {@link TestRegionMergeTransaction} in that we're testing{@link RegionMergeTransaction} only the below tests are against a runningcluster where  {@link TestRegionMergeTransaction} is tests against bare{@link HRegion}.
 */
@Category(LargeTests.class) public class TestRegionMergeTransactionOnCluster {
  private static final Log LOG=LogFactory.getLog(TestRegionMergeTransactionOnCluster.class);
  private static final int NB_SERVERS=3;
  private static final byte[] FAMILYNAME=Bytes.toBytes("fam");
  private static final byte[] QUALIFIER=Bytes.toBytes("q");
  private static byte[] ROW=Bytes.toBytes("testRow");
  private static final int INITIAL_REGION_NUM=10;
  private static final int ROWSIZE=200;
  private static byte[][] ROWS=makeN(ROW,ROWSIZE);
  private static int waitTime=60 * 1000;
  static final HBaseTestingUtility TEST_UTIL=new HBaseTestingUtility();
  private static HMaster master;
  private static HBaseAdmin admin;
  static void setupOnce() throws Exception {
    TEST_UTIL.startMiniCluster(NB_SERVERS);
    MiniHBaseCluster cluster=TEST_UTIL.getHBaseCluster();
    master=cluster.getMaster();
    master.balanceSwitch(false);
    admin=TEST_UTIL.getHBaseAdmin();
  }
  @BeforeClass public static void beforeAllTests() throws Exception {
    TEST_UTIL.getConfiguration().setBoolean("hbase.assignment.usezk",true);
    setupOnce();
  }
  @AfterClass public static void afterAllTests() throws Exception {
    TEST_UTIL.shutdownMiniCluster();
  }
  @Test public void testWholesomeMerge() throws Exception {
    LOG.info("Starting testWholesomeMerge");
    final TableName tableName=TableName.valueOf("testWholesomeMerge");
    HTable table=createTableAndLoadData(master,tableName);
    mergeRegionsAndVerifyRegionNum(master,tableName,0,1,INITIAL_REGION_NUM - 1);
    PairOfSameType<HRegionInfo> mergedRegions=mergeRegionsAndVerifyRegionNum(master,tableName,1,2,INITIAL_REGION_NUM - 2);
    verifyRowCount(table,ROWSIZE);
    HRegionInfo hri=RandomUtils.nextBoolean() ? mergedRegions.getFirst() : mergedRegions.getSecond();
    MiniHBaseCluster cluster=TEST_UTIL.getHBaseCluster();
    AssignmentManager am=cluster.getMaster().getAssignmentManager();
    RegionStates regionStates=am.getRegionStates();
    long start=EnvironmentEdgeManager.currentTimeMillis();
    while (!regionStates.isRegionInState(hri,State.MERGED)) {
      assertFalse("Timed out in waiting one merged region to be in state MERGED",EnvironmentEdgeManager.currentTimeMillis() - start > 60000);
      Thread.sleep(500);
    }
    am.assign(hri,true,true);
    assertFalse("Merged region can't be assigned",regionStates.isRegionInTransition(hri));
    assertTrue(regionStates.isRegionInState(hri,State.MERGED));
    am.unassign(hri,true,null);
    assertFalse("Merged region can't be unassigned",regionStates.isRegionInTransition(hri));
    assertTrue(regionStates.isRegionInState(hri,State.MERGED));
    table.close();
  }
  @Test public void testCleanMergeReference() throws Exception {
    LOG.info("Starting testCleanMergeReference");
    admin.enableCatalogJanitor(false);
    try {
      final TableName tableName=TableName.valueOf("testCleanMergeReference");
      HTable table=createTableAndLoadData(master,tableName);
      mergeRegionsAndVerifyRegionNum(master,tableName,0,1,INITIAL_REGION_NUM - 1);
      verifyRowCount(table,ROWSIZE);
      table.close();
      List<Pair<HRegionInfo,ServerName>> tableRegions=MetaReader.getTableRegionsAndLocations(master.getCatalogTracker(),tableName);
      HRegionInfo mergedRegionInfo=tableRegions.get(0).getFirst();
      HTableDescriptor tableDescritor=master.getTableDescriptors().get(tableName);
      Result mergedRegionResult=MetaReader.getRegionResult(master.getCatalogTracker(),mergedRegionInfo.getRegionName());
      assertTrue(mergedRegionResult.getValue(HConstants.CATALOG_FAMILY,HConstants.MERGEA_QUALIFIER) != null);
      assertTrue(mergedRegionResult.getValue(HConstants.CATALOG_FAMILY,HConstants.MERGEB_QUALIFIER) != null);
      HRegionInfo regionA=HRegionInfo.getHRegionInfo(mergedRegionResult,HConstants.MERGEA_QUALIFIER);
      HRegionInfo regionB=HRegionInfo.getHRegionInfo(mergedRegionResult,HConstants.MERGEB_QUALIFIER);
      FileSystem fs=master.getMasterFileSystem().getFileSystem();
      Path rootDir=master.getMasterFileSystem().getRootDir();
      Path tabledir=FSUtils.getTableDir(rootDir,mergedRegionInfo.getTable());
      Path regionAdir=new Path(tabledir,regionA.getEncodedName());
      Path regionBdir=new Path(tabledir,regionB.getEncodedName());
      assertTrue(fs.exists(regionAdir));
      assertTrue(fs.exists(regionBdir));
      admin.compact(mergedRegionInfo.getRegionName());
      long timeout=System.currentTimeMillis() + waitTime;
      HRegionFileSystem hrfs=new HRegionFileSystem(TEST_UTIL.getConfiguration(),fs,tabledir,mergedRegionInfo);
      while (System.currentTimeMillis() < timeout) {
        if (!hrfs.hasReferences(tableDescritor)) {
          break;
        }
        Thread.sleep(50);
      }
      assertFalse(hrfs.hasReferences(tableDescritor));
      int cleaned=admin.runCatalogScan();
      assertTrue(cleaned > 0);
      assertFalse(fs.exists(regionAdir));
      assertFalse(fs.exists(regionBdir));
      mergedRegionResult=MetaReader.getRegionResult(master.getCatalogTracker(),mergedRegionInfo.getRegionName());
      assertFalse(mergedRegionResult.getValue(HConstants.CATALOG_FAMILY,HConstants.MERGEA_QUALIFIER) != null);
      assertFalse(mergedRegionResult.getValue(HConstants.CATALOG_FAMILY,HConstants.MERGEB_QUALIFIER) != null);
    }
  finally {
      admin.enableCatalogJanitor(true);
    }
  }
  /** 
 * This test tests 1, merging region not online; 2, merging same two regions; 3, merging unknown regions. They are in one test case so that we don't have to create many tables, and these tests are simple.
 */
  @Test public void testMerge() throws Exception {
    LOG.info("Starting testMerge");
    final TableName tableName=TableName.valueOf("testMerge");
    try {
      HTable table=createTableAndLoadData(master,tableName);
      RegionStates regionStates=master.getAssignmentManager().getRegionStates();
      List<HRegionInfo> regions=regionStates.getRegionsOfTable(tableName);
      HRegionInfo a=regions.get(0);
      HRegionInfo b=regions.get(1);
      regionStates.regionOffline(a);
      try {
        admin.mergeRegions(a.getEncodedNameAsBytes(),b.getEncodedNameAsBytes(),false);
        fail("Offline regions should not be able to merge");
      }
 catch (      IOException ie) {
        assertTrue("Exception should mention regions not online",ie.getMessage().contains("regions not online") && ie instanceof MergeRegionException);
      }
      try {
        admin.mergeRegions(b.getEncodedNameAsBytes(),b.getEncodedNameAsBytes(),true);
        fail("A region should not be able to merge with itself, even forcifully");
      }
 catch (      IOException ie) {
        assertTrue("Exception should mention regions not online",ie.getMessage().contains("region to itself") && ie instanceof MergeRegionException);
      }
      try {
        admin.mergeRegions(Bytes.toBytes("-f1"),Bytes.toBytes("-f2"),true);
        fail("Unknown region could not be merged");
      }
 catch (      IOException ie) {
        assertTrue("UnknownRegionException should be thrown",ie instanceof UnknownRegionException);
      }
      table.close();
    }
  finally {
      TEST_UTIL.deleteTable(tableName);
    }
  }
  private PairOfSameType<HRegionInfo> mergeRegionsAndVerifyRegionNum(  HMaster master,  TableName tablename,  int regionAnum,  int regionBnum,  int expectedRegionNum) throws Exception {
    PairOfSameType<HRegionInfo> mergedRegions=requestMergeRegion(master,tablename,regionAnum,regionBnum);
    waitAndVerifyRegionNum(master,tablename,expectedRegionNum);
    return mergedRegions;
  }
  private PairOfSameType<HRegionInfo> requestMergeRegion(  HMaster master,  TableName tablename,  int regionAnum,  int regionBnum) throws Exception {
    List<Pair<HRegionInfo,ServerName>> tableRegions=MetaReader.getTableRegionsAndLocations(master.getCatalogTracker(),tablename);
    HRegionInfo regionA=tableRegions.get(regionAnum).getFirst();
    HRegionInfo regionB=tableRegions.get(regionBnum).getFirst();
    TEST_UTIL.getHBaseAdmin().mergeRegions(regionA.getEncodedNameAsBytes(),regionB.getEncodedNameAsBytes(),false);
    return new PairOfSameType<HRegionInfo>(regionA,regionB);
  }
  private void waitAndVerifyRegionNum(  HMaster master,  TableName tablename,  int expectedRegionNum) throws Exception {
    List<Pair<HRegionInfo,ServerName>> tableRegionsInMeta;
    List<HRegionInfo> tableRegionsInMaster;
    long timeout=System.currentTimeMillis() + waitTime;
    while (System.currentTimeMillis() < timeout) {
      tableRegionsInMeta=MetaReader.getTableRegionsAndLocations(master.getCatalogTracker(),tablename);
      tableRegionsInMaster=master.getAssignmentManager().getRegionStates().getRegionsOfTable(tablename);
      if (tableRegionsInMeta.size() == expectedRegionNum && tableRegionsInMaster.size() == expectedRegionNum) {
        break;
      }
      Thread.sleep(250);
    }
    tableRegionsInMeta=MetaReader.getTableRegionsAndLocations(master.getCatalogTracker(),tablename);
    LOG.info("Regions after merge:" + Joiner.on(',').join(tableRegionsInMeta));
    assertEquals(expectedRegionNum,tableRegionsInMeta.size());
  }
  private HTable createTableAndLoadData(  HMaster master,  TableName tablename) throws Exception {
    return createTableAndLoadData(master,tablename,INITIAL_REGION_NUM);
  }
  private HTable createTableAndLoadData(  HMaster master,  TableName tablename,  int numRegions) throws Exception {
    assertTrue("ROWSIZE must > numregions:" + numRegions,ROWSIZE > numRegions);
    byte[][] splitRows=new byte[numRegions - 1][];
    for (int i=0; i < splitRows.length; i++) {
      splitRows[i]=ROWS[(i + 1) * ROWSIZE / numRegions];
    }
    HTable table=TEST_UTIL.createTable(tablename,FAMILYNAME,splitRows);
    loadData(table);
    verifyRowCount(table,ROWSIZE);
    long timeout=System.currentTimeMillis() + waitTime;
    List<Pair<HRegionInfo,ServerName>> tableRegions;
    while (System.currentTimeMillis() < timeout) {
      tableRegions=MetaReader.getTableRegionsAndLocations(master.getCatalogTracker(),tablename);
      if (tableRegions.size() == numRegions)       break;
      Thread.sleep(250);
    }
    tableRegions=MetaReader.getTableRegionsAndLocations(master.getCatalogTracker(),tablename);
    LOG.info("Regions after load: " + Joiner.on(',').join(tableRegions));
    assertEquals(numRegions,tableRegions.size());
    return table;
  }
  private static byte[][] makeN(  byte[] base,  int n){
    byte[][] ret=new byte[n][];
    for (int i=0; i < n; i++) {
      ret[i]=Bytes.add(base,Bytes.toBytes(String.format("%04d",i)));
    }
    return ret;
  }
  private void loadData(  HTable table) throws IOException {
    for (int i=0; i < ROWSIZE; i++) {
      Put put=new Put(ROWS[i]);
      put.add(FAMILYNAME,QUALIFIER,Bytes.toBytes(i));
      table.put(put);
    }
  }
  private void verifyRowCount(  HTable table,  int expectedRegionNum) throws IOException {
    ResultScanner scanner=table.getScanner(new Scan());
    int rowCount=0;
    while (scanner.next() != null) {
      rowCount++;
    }
    assertEquals(expectedRegionNum,rowCount);
    scanner.close();
  }
}
