class KeySampler {
  Random random;
  int min, max;
  DiscreteRNG keyLenRNG;
  private static final int MIN_KEY_LEN=4;
  public KeySampler(  Random random,  byte[] first,  byte[] last,  DiscreteRNG keyLenRNG){
    this.random=random;
    min=keyPrefixToInt(first);
    max=keyPrefixToInt(last);
    this.keyLenRNG=keyLenRNG;
  }
  private int keyPrefixToInt(  byte[] key){
    byte[] b=key;
    int o=0;
    return (b[o] & 0xff) << 24 | (b[o + 1] & 0xff) << 16 | (b[o + 2] & 0xff) << 8 | (b[o + 3] & 0xff);
  }
  public void next(  BytesWritable key){
    key.setSize(Math.max(MIN_KEY_LEN,keyLenRNG.nextInt()));
    random.nextBytes(key.get());
    int n=random.nextInt(max - min) + min;
    byte[] b=key.get();
    b[0]=(byte)(n >> 24);
    b[1]=(byte)(n >> 16);
    b[2]=(byte)(n >> 8);
    b[3]=(byte)n;
  }
}
