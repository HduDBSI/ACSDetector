/** 
 * Test log deletion as logs are rolled.
 */
public class TestLogRolling {
  private static final Log LOG=LogFactory.getLog(TestLogRolling.class);
  private HRegionServer server;
  private HLog log;
  private String tableName;
  private byte[] value;
  private static FileSystem fs;
  private static MiniDFSCluster dfsCluster;
  private static HBaseAdmin admin;
  private static MiniHBaseCluster cluster;
  private final static HBaseTestingUtility TEST_UTIL=new HBaseTestingUtility();
{
    ((Log4JLogger)DataNode.LOG).getLogger().setLevel(Level.ALL);
    ((Log4JLogger)LeaseManager.LOG).getLogger().setLevel(Level.ALL);
    ((Log4JLogger)FSNamesystem.LOG).getLogger().setLevel(Level.ALL);
    ((Log4JLogger)DFSClient.LOG).getLogger().setLevel(Level.ALL);
    ((Log4JLogger)HRegionServer.LOG).getLogger().setLevel(Level.ALL);
    ((Log4JLogger)HRegion.LOG).getLogger().setLevel(Level.ALL);
    ((Log4JLogger)HLog.LOG).getLogger().setLevel(Level.ALL);
  }
  /** 
 * constructor
 * @throws Exception
 */
  public TestLogRolling(){
    super();
    this.server=null;
    this.log=null;
    this.tableName=null;
    this.value=null;
    String className=this.getClass().getName();
    StringBuilder v=new StringBuilder(className);
    while (v.length() < 1000) {
      v.append(className);
    }
    value=Bytes.toBytes(v.toString());
  }
  @BeforeClass public static void setUpBeforeClass() throws Exception {
    TEST_UTIL.getConfiguration().setLong("hbase.hregion.max.filesize",768L * 1024L);
    TEST_UTIL.getConfiguration().setInt("hbase.regionserver.maxlogentries",32);
    TEST_UTIL.getConfiguration().setInt("hbase.hregion.memstore.optionalflushcount",2);
    TEST_UTIL.getConfiguration().setInt("hbase.hregion.memstore.flush.size",8192);
    TEST_UTIL.getConfiguration().setLong("hbase.client.pause",15 * 1000);
    TEST_UTIL.getConfiguration().setInt(HConstants.THREAD_WAKE_FREQUENCY,2 * 1000);
    TEST_UTIL.getConfiguration().setBoolean("dfs.support.append",true);
    TEST_UTIL.getConfiguration().setInt("heartbeat.recheck.interval",5000);
    TEST_UTIL.getConfiguration().setInt("dfs.heartbeat.interval",1);
    TEST_UTIL.getConfiguration().setInt("dfs.client.block.write.retries",30);
    TEST_UTIL.startMiniCluster(2);
    cluster=TEST_UTIL.getHBaseCluster();
    dfsCluster=TEST_UTIL.getDFSCluster();
    fs=TEST_UTIL.getTestFileSystem();
    admin=TEST_UTIL.getHBaseAdmin();
  }
  @AfterClass public static void tearDownAfterClass() throws IOException {
    TEST_UTIL.cleanupTestDir();
    TEST_UTIL.shutdownMiniCluster();
  }
  private void startAndWriteData() throws IOException {
    new HTable(TEST_UTIL.getConfiguration(),HConstants.META_TABLE_NAME);
    this.server=cluster.getRegionServerThreads().get(0).getRegionServer();
    this.log=server.getWAL();
    HTableDescriptor desc=new HTableDescriptor(tableName);
    desc.addFamily(new HColumnDescriptor(HConstants.CATALOG_FAMILY));
    admin.createTable(desc);
    HTable table=new HTable(TEST_UTIL.getConfiguration(),tableName);
    server=TEST_UTIL.getRSForFirstRegionInTable(Bytes.toBytes(tableName));
    this.log=server.getWAL();
    for (int i=1; i <= 256; i++) {
      Put put=new Put(Bytes.toBytes("row" + String.format("%1$04d",i)));
      put.add(HConstants.CATALOG_FAMILY,null,value);
      table.put(put);
      if (i % 32 == 0) {
        try {
          Thread.sleep(2000);
        }
 catch (        InterruptedException e) {
        }
      }
    }
  }
  /** 
 * Tests that logs are deleted
 * @throws IOException
 * @throws FailedLogCloseException
 */
  @Test public void testLogRolling() throws FailedLogCloseException, IOException {
    this.tableName=getName();
    startAndWriteData();
    LOG.info("after writing there are " + log.getNumLogFiles() + " log files");
    List<HRegion> regions=new ArrayList<HRegion>(server.getOnlineRegionsLocalContext());
    for (    HRegion r : regions) {
      r.flushcache();
    }
    log.rollWriter();
    int count=log.getNumLogFiles();
    LOG.info("after flushing all regions and rolling logs there are " + log.getNumLogFiles() + " log files");
    assertTrue(("actual count: " + count),count <= 2);
  }
  private static String getName(){
    return "TestLogRolling";
  }
  void writeData(  HTable table,  int rownum) throws IOException {
    Put put=new Put(Bytes.toBytes("row" + String.format("%1$04d",rownum)));
    put.add(HConstants.CATALOG_FAMILY,null,value);
    table.put(put);
    try {
      Thread.sleep(2000);
    }
 catch (    InterruptedException e) {
    }
  }
  /** 
 * Give me the HDFS pipeline for this log file
 */
  DatanodeInfo[] getPipeline(  HLog log) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
    OutputStream stm=log.getOutputStream();
    Method getPipeline=null;
    for (    Method m : stm.getClass().getDeclaredMethods()) {
      if (m.getName().endsWith("getPipeline")) {
        getPipeline=m;
        getPipeline.setAccessible(true);
        break;
      }
    }
    assertTrue("Need DFSOutputStream.getPipeline() for this test",null != getPipeline);
    Object repl=getPipeline.invoke(stm,new Object[]{});
    return (DatanodeInfo[])repl;
  }
  /** 
 * Tests that logs are rolled upon detecting datanode death Requires an HDFS jar with HDFS-826 & syncFs() support (HDFS-200)
 * @throws IOException
 * @throws InterruptedException
 * @throws InvocationTargetException 
 * @throws IllegalAccessException
 * @throws IllegalArgumentException 
 */
  @Test public void testLogRollOnDatanodeDeath() throws IOException, InterruptedException, IllegalArgumentException, IllegalAccessException, InvocationTargetException {
    assertTrue("This test requires HLog file replication.",fs.getDefaultReplication() > 1);
    LOG.info("Replication=" + fs.getDefaultReplication());
    new HTable(TEST_UTIL.getConfiguration(),HConstants.META_TABLE_NAME);
    this.server=cluster.getRegionServer(0);
    this.log=server.getWAL();
    String tableName=getName();
    HTableDescriptor desc=new HTableDescriptor(tableName);
    desc.addFamily(new HColumnDescriptor(HConstants.CATALOG_FAMILY));
    if (admin.tableExists(tableName)) {
      admin.disableTable(tableName);
      admin.deleteTable(tableName);
    }
    admin.createTable(desc);
    HTable table=new HTable(TEST_UTIL.getConfiguration(),tableName);
    server=TEST_UTIL.getRSForFirstRegionInTable(Bytes.toBytes(tableName));
    this.log=server.getWAL();
    assertTrue("Need HDFS-826 for this test",log.canGetCurReplicas());
    assertTrue("Need append support for this test",FSUtils.isAppendSupported(TEST_UTIL.getConfiguration()));
    dfsCluster.startDataNodes(TEST_UTIL.getConfiguration(),1,true,null,null);
    dfsCluster.waitActive();
    assertTrue(dfsCluster.getDataNodes().size() >= fs.getDefaultReplication() + 1);
    writeData(table,2);
    table.setAutoFlush(true);
    long curTime=System.currentTimeMillis();
    long oldFilenum=log.getFilenum();
    assertTrue("Log should have a timestamp older than now",curTime > oldFilenum && oldFilenum != -1);
    assertTrue("The log shouldn't have rolled yet",oldFilenum == log.getFilenum());
    DatanodeInfo[] pipeline=getPipeline(log);
    assertTrue(pipeline.length == fs.getDefaultReplication());
    assertTrue(dfsCluster.stopDataNode(pipeline[0].getName()) != null);
    Thread.sleep(10000);
    writeData(table,2);
    long newFilenum=log.getFilenum();
    assertTrue("Missing datanode should've triggered a log roll",newFilenum > oldFilenum && newFilenum > curTime);
    writeData(table,3);
    assertTrue("The log should not roll again.",log.getFilenum() == newFilenum);
    assertTrue("New log file should have the default replication",log.getLogReplication() == fs.getDefaultReplication());
  }
}
