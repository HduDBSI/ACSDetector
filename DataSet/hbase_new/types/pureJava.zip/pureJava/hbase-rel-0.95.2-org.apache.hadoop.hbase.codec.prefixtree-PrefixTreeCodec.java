/** 
 * This class is created via reflection in DataBlockEncoding enum. Update the enum if class name or package changes. <p/> PrefixTreeDataBlockEncoder implementation of DataBlockEncoder. This is the primary entry point for PrefixTree encoding and decoding. Encoding is delegated to instances of {@link PrefixTreeEncoder}, and decoding is delegated to instances of {@link org.apache.hadoop.hbase.codec.prefixtree.scanner.CellSearcher}. Encoder and decoder instances are created and recycled by static PtEncoderFactory and PtDecoderFactory.
 */
@InterfaceAudience.Private public class PrefixTreeCodec implements DataBlockEncoder {
  /** 
 * no-arg constructor for reflection
 */
  public PrefixTreeCodec(){
  }
  /** 
 * Copied from BufferedDataBlockEncoder. Almost definitely can be improved, but i'm not familiar enough with the concept of the HFileBlockEncodingContext.
 */
  @Override public void encodeKeyValues(  ByteBuffer in,  boolean includesMvccVersion,  HFileBlockEncodingContext blkEncodingCtx) throws IOException {
    if (blkEncodingCtx.getClass() != HFileBlockDefaultEncodingContext.class) {
      throw new IOException(this.getClass().getName() + " only accepts " + HFileBlockDefaultEncodingContext.class.getName()+ " as the "+ "encoding context.");
    }
    HFileBlockDefaultEncodingContext encodingCtx=(HFileBlockDefaultEncodingContext)blkEncodingCtx;
    encodingCtx.prepareEncoding();
    DataOutputStream dataOut=encodingCtx.getOutputStreamForEncoder();
    internalEncodeKeyValues(dataOut,in,includesMvccVersion);
    if (encodingCtx.getDataBlockEncoding() != DataBlockEncoding.NONE) {
      encodingCtx.postEncoding(BlockType.ENCODED_DATA);
    }
 else {
      encodingCtx.postEncoding(BlockType.DATA);
    }
  }
  private void internalEncodeKeyValues(  DataOutputStream encodedOutputStream,  ByteBuffer rawKeyValues,  boolean includesMvccVersion) throws IOException {
    rawKeyValues.rewind();
    PrefixTreeEncoder builder=EncoderFactory.checkOut(encodedOutputStream,includesMvccVersion);
    try {
      KeyValue kv;
      while ((kv=KeyValueUtil.nextShallowCopy(rawKeyValues,includesMvccVersion)) != null) {
        builder.write(kv);
      }
      builder.flush();
    }
  finally {
      EncoderFactory.checkIn(builder);
    }
  }
  @Override public ByteBuffer decodeKeyValues(  DataInputStream source,  boolean includesMvccVersion) throws IOException {
    return decodeKeyValues(source,0,0,includesMvccVersion);
  }
  /** 
 * I don't think this method is called during normal HBase operation, so efficiency is not important.
 */
  @Override public ByteBuffer decodeKeyValues(  DataInputStream source,  int allocateHeaderLength,  int skipLastBytes,  boolean includesMvccVersion) throws IOException {
    ByteBuffer sourceAsBuffer=ByteBufferUtils.drainInputStreamToBuffer(source);
    sourceAsBuffer.mark();
    PrefixTreeBlockMeta blockMeta=new PrefixTreeBlockMeta(sourceAsBuffer);
    sourceAsBuffer.rewind();
    int numV1BytesWithHeader=allocateHeaderLength + blockMeta.getNumKeyValueBytes();
    byte[] keyValueBytesWithHeader=new byte[numV1BytesWithHeader];
    ByteBuffer result=ByteBuffer.wrap(keyValueBytesWithHeader);
    result.rewind();
    CellSearcher searcher=null;
    try {
      searcher=DecoderFactory.checkOut(sourceAsBuffer,includesMvccVersion);
      while (searcher.advance()) {
        KeyValue currentCell=KeyValueUtil.copyToNewKeyValue(searcher.current());
        int offset=result.arrayOffset() + result.position();
        KeyValueUtil.appendToByteArray(currentCell,result.array(),offset);
        int keyValueLength=KeyValueUtil.length(currentCell);
        ByteBufferUtils.skip(result,keyValueLength);
        offset+=keyValueLength;
        if (includesMvccVersion) {
          ByteBufferUtils.writeVLong(result,currentCell.getMvccVersion());
        }
      }
      result.position(result.limit());
      return result;
    }
  finally {
      DecoderFactory.checkIn(searcher);
    }
  }
  @Override public ByteBuffer getFirstKeyInBlock(  ByteBuffer block){
    block.rewind();
    PrefixTreeArraySearcher searcher=null;
    try {
      searcher=DecoderFactory.checkOut(block,true);
      if (!searcher.positionAtFirstCell()) {
        return null;
      }
      return KeyValueUtil.copyKeyToNewByteBuffer(searcher.current());
    }
  finally {
      DecoderFactory.checkIn(searcher);
    }
  }
  @Override public HFileBlockEncodingContext newDataBlockEncodingContext(  Algorithm compressionAlgorithm,  DataBlockEncoding encoding,  byte[] header){
    if (DataBlockEncoding.PREFIX_TREE != encoding) {
      throw new IllegalArgumentException("only DataBlockEncoding.PREFIX_TREE supported");
    }
    return new HFileBlockDefaultEncodingContext(compressionAlgorithm,encoding,header);
  }
  @Override public HFileBlockDecodingContext newDataBlockDecodingContext(  Algorithm compressionAlgorithm){
    return new HFileBlockDefaultDecodingContext(compressionAlgorithm);
  }
  /** 
 * Is this the correct handling of an illegal comparator?  How to prevent that from getting all the way to this point.
 */
  @Override public EncodedSeeker createSeeker(  RawComparator<byte[]> comparator,  boolean includesMvccVersion){
    if (!(comparator instanceof KeyComparator)) {
      throw new IllegalArgumentException("comparator must be KeyValue.KeyComparator");
    }
    if (comparator instanceof MetaKeyComparator) {
      throw new IllegalArgumentException("DataBlockEncoding.PREFIX_TREE not compatible with META " + "table");
    }
    return new PrefixTreeSeeker(includesMvccVersion);
  }
}
