/** 
 * Keeps track of the columns for a scan if they are not explicitly specified
 */
public class ScanWildcardColumnTracker implements ColumnTracker {
  private static final Log LOG=LogFactory.getLog(ScanWildcardColumnTracker.class);
  private byte[] columnBuffer=null;
  private int columnOffset=0;
  private int columnLength=0;
  private int currentCount=0;
  private int maxVersions;
  private long latestTSOfCurrentColumn;
  /** 
 * Return maxVersions of every row.
 * @param maxVersion
 */
  public ScanWildcardColumnTracker(  int maxVersion){
    this.maxVersions=maxVersion;
  }
  /** 
 * Can only return INCLUDE or SKIP, since returning "NEXT" or "DONE" would imply we have finished with this row, when this class can't figure that out.
 * @param bytes
 * @param offset
 * @param length
 * @param timestamp
 * @return The match code instance.
 */
  @Override public MatchCode checkColumn(  byte[] bytes,  int offset,  int length,  long timestamp){
    if (columnBuffer == null) {
      columnBuffer=bytes;
      columnOffset=offset;
      columnLength=length;
      currentCount=0;
      if (++currentCount > maxVersions) {
        return ScanQueryMatcher.MatchCode.SEEK_NEXT_COL;
      }
      setTS(timestamp);
      return ScanQueryMatcher.MatchCode.INCLUDE;
    }
    int cmp=Bytes.compareTo(bytes,offset,length,columnBuffer,columnOffset,columnLength);
    if (cmp == 0) {
      if (sameAsPreviousTS(timestamp)) {
        return ScanQueryMatcher.MatchCode.SKIP;
      }
      if (++currentCount > maxVersions) {
        return ScanQueryMatcher.MatchCode.SEEK_NEXT_COL;
      }
      setTS(timestamp);
      return ScanQueryMatcher.MatchCode.INCLUDE;
    }
    resetTS();
    if (cmp > 0) {
      columnBuffer=bytes;
      columnOffset=offset;
      columnLength=length;
      currentCount=0;
      if (++currentCount > maxVersions)       return ScanQueryMatcher.MatchCode.SEEK_NEXT_COL;
      setTS(timestamp);
      return ScanQueryMatcher.MatchCode.INCLUDE;
    }
    LOG.error("ScanWildcardColumnTracker.checkColumn ran " + "into a column actually smaller than the previous column: " + Bytes.toStringBinary(bytes,offset,length));
    columnBuffer=bytes;
    columnOffset=offset;
    columnLength=length;
    currentCount=0;
    if (++currentCount > maxVersions) {
      return ScanQueryMatcher.MatchCode.SEEK_NEXT_COL;
    }
    setTS(timestamp);
    return ScanQueryMatcher.MatchCode.INCLUDE;
  }
  @Override public void update(){
    throw new UnsupportedOperationException("ScanWildcardColumnTracker.update should never be called!");
  }
  @Override public void reset(){
    columnBuffer=null;
    resetTS();
  }
  private void resetTS(){
    latestTSOfCurrentColumn=HConstants.LATEST_TIMESTAMP;
  }
  private void setTS(  long timestamp){
    latestTSOfCurrentColumn=timestamp;
  }
  private boolean sameAsPreviousTS(  long timestamp){
    return timestamp == latestTSOfCurrentColumn;
  }
  /** 
 * Used by matcher and scan/get to get a hint of the next column to seek to after checkColumn() returns SKIP.  Returns the next interesting column we want, or NULL there is none (wildcard scanner).
 * @return The column count.
 */
  public ColumnCount getColumnHint(){
    return null;
  }
  /** 
 * We can never know a-priori if we are done, so always return false.
 * @return false
 */
  @Override public boolean done(){
    return false;
  }
}
