/** 
 * The MemStoreCompactorSegmentsIterator extends MemStoreSegmentsIterator and performs the scan for compaction operation meaning it is based on SQM
 */
@InterfaceAudience.Private public class MemStoreCompactorSegmentsIterator extends MemStoreSegmentsIterator {
  private static final Logger LOG=LoggerFactory.getLogger(MemStoreCompactorSegmentsIterator.class);
  private final List<Cell> kvs=new ArrayList<>();
  private boolean hasMore=true;
  private Iterator<Cell> kvsIterator;
  private InternalScanner compactingScanner;
  public MemStoreCompactorSegmentsIterator(  List<ImmutableSegment> segments,  CellComparator comparator,  int compactionKVMax,  HStore store) throws IOException {
    super(compactionKVMax);
    List<KeyValueScanner> scanners=new ArrayList<KeyValueScanner>();
    int order=segments.size();
    AbstractMemStore.addToScanners(segments,Long.MAX_VALUE,order,scanners);
    compactingScanner=createScanner(store,scanners);
    refillKVS();
  }
  @Override public boolean hasNext(){
    if (kvsIterator == null) {
      return false;
    }
    return kvsIterator.hasNext() || refillKVS();
  }
  @Override public Cell next(){
    if (!hasNext()) {
      throw new NoSuchElementException();
    }
    return kvsIterator.next();
  }
  @Override public void close(){
    try {
      compactingScanner.close();
    }
 catch (    IOException e) {
      LOG.warn("close store scanner failed",e);
    }
    compactingScanner=null;
    kvs.clear();
  }
  @Override public void remove(){
    throw new UnsupportedOperationException();
  }
  /** 
 * Creates the scanner for compacting the pipeline.
 * @return the scanner
 */
  private InternalScanner createScanner(  HStore store,  List<KeyValueScanner> scanners) throws IOException {
    InternalScanner scanner=null;
    boolean success=false;
    try {
      RegionCoprocessorHost cpHost=store.getCoprocessorHost();
      ScanInfo scanInfo;
      if (cpHost != null) {
        scanInfo=cpHost.preMemStoreCompactionCompactScannerOpen(store);
      }
 else {
        scanInfo=store.getScanInfo();
      }
      scanner=new StoreScanner(store,scanInfo,scanners,ScanType.COMPACT_RETAIN_DELETES,store.getSmallestReadPoint(),HConstants.OLDEST_TIMESTAMP);
      if (cpHost != null) {
        InternalScanner scannerFromCp=cpHost.preMemStoreCompactionCompact(store,scanner);
        if (scannerFromCp == null) {
          throw new CoprocessorException("Got a null InternalScanner when calling" + " preMemStoreCompactionCompact which is not acceptable");
        }
        success=true;
        return scannerFromCp;
      }
 else {
        success=true;
        return scanner;
      }
    }
  finally {
      if (!success) {
        Closeables.close(scanner,true);
        scanners.forEach(KeyValueScanner::close);
      }
    }
  }
  private boolean refillKVS(){
    if (!hasMore) {
      return false;
    }
    kvs.clear();
    for (; ; ) {
      try {
        hasMore=compactingScanner.next(kvs,scannerContext);
      }
 catch (      IOException e) {
        throw new IllegalStateException(e);
      }
      if (!kvs.isEmpty()) {
        kvsIterator=kvs.iterator();
        return true;
      }
 else       if (!hasMore) {
        return false;
      }
    }
  }
}
