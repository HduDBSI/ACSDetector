/** 
 * The MemStoreMergerSegmentsIterator extends MemStoreSegmentsIterator and performs the scan for simple merge operation meaning it is NOT based on SQM
 */
@InterfaceAudience.Private public class MemStoreMergerSegmentsIterator extends MemStoreSegmentsIterator {
  private KeyValueHeap heap=null;
  List<KeyValueScanner> scanners=new ArrayList<KeyValueScanner>();
  private boolean closed=false;
  public MemStoreMergerSegmentsIterator(  List<ImmutableSegment> segments,  CellComparator comparator,  int compactionKVMax) throws IOException {
    super(compactionKVMax);
    AbstractMemStore.addToScanners(segments,Long.MAX_VALUE,scanners);
    heap=new KeyValueHeap(scanners,comparator);
  }
  @Override public boolean hasNext(){
    if (closed) {
      return false;
    }
    if (this.heap != null) {
      return (this.heap.peek() != null);
    }
    return false;
  }
  @Override public Cell next(){
    try {
      if (!closed && heap != null) {
        return heap.next();
      }
    }
 catch (    IOException ie) {
      throw new IllegalStateException(ie);
    }
    return null;
  }
  @Override public void close(){
    if (closed) {
      return;
    }
    if (heap != null) {
      heap.close();
      heap=null;
    }
 else {
      for (      KeyValueScanner scanner : scanners) {
        scanner.close();
      }
    }
    closed=true;
  }
  @Override public void remove(){
    throw new UnsupportedOperationException();
  }
}
