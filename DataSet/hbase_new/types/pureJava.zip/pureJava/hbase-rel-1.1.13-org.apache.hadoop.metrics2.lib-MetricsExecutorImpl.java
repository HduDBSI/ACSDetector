/** 
 * Class to handle the ScheduledExecutorService {@link ScheduledExecutorService} used by MetricMutableQuantiles{@link MetricMutableQuantiles}
 */
@InterfaceAudience.Private public class MetricsExecutorImpl implements MetricsExecutor {
  @Override public ScheduledExecutorService getExecutor(){
    return ExecutorSingleton.INSTANCE.scheduler;
  }
  @Override public void stop(){
    if (!getExecutor().isShutdown()) {
      getExecutor().shutdown();
    }
  }
  private enum ExecutorSingleton {  INSTANCE;   private final ScheduledExecutorService scheduler=new ScheduledThreadPoolExecutor(1,new ThreadPoolExecutorThreadFactory("HBase-Metrics2-"));
}
private static class ThreadPoolExecutorThreadFactory implements ThreadFactory {
    private final String name;
    private final AtomicInteger threadNumber=new AtomicInteger(1);
    private ThreadPoolExecutorThreadFactory(    String name){
      this.name=name;
    }
    @Override public Thread newThread(    Runnable runnable){
      Thread t=new Thread(runnable,name + threadNumber.getAndIncrement());
      t.setDaemon(true);
      return t;
    }
  }
}
