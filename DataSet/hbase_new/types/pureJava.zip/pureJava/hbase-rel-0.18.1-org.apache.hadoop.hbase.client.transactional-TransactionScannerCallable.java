class TransactionScannerCallable extends ScannerCallable {
  private TransactionState transactionState;
  TransactionScannerCallable(  final TransactionState transactionState,  final HConnection connection,  final byte[] tableName,  final byte[][] columns,  final byte[] startRow,  final long timestamp,  final RowFilterInterface filter){
    super(connection,tableName,columns,startRow,timestamp,filter);
    this.transactionState=transactionState;
  }
  @Override protected long openScanner() throws IOException {
    if (transactionState.addRegion(location)) {
      ((TransactionalRegionInterface)server).beginTransaction(transactionState.getTransactionId(),location.getRegionInfo().getRegionName());
    }
    return ((TransactionalRegionInterface)server).openScanner(transactionState.getTransactionId(),this.location.getRegionInfo().getRegionName(),getColumns(),row,getTimestamp(),getFilter());
  }
}
