/** 
 * A scanner that iterates through HStore files
 */
class StoreFileScanner extends HAbstractScanner {
  private volatile HStoreKey keys[];
  private volatile byte[][] vals;
  private volatile MapFile.Reader[] readers;
  private final HStore store;
  private final ReentrantReadWriteLock lock=new ReentrantReadWriteLock();
  /** 
 * @param store
 * @param timestamp
 * @param targetCols
 * @param firstRow
 * @throws IOException
 */
  public StoreFileScanner(  final HStore store,  final long timestamp,  final byte[][] targetCols,  final byte[] firstRow) throws IOException {
    super(timestamp,targetCols);
    this.store=store;
    try {
      openReaders(firstRow,-1);
    }
 catch (    Exception ex) {
      close();
      IOException e=new IOException("HStoreScanner failed construction");
      e.initCause(ex);
      throw e;
    }
  }
  private void openReaders(  final byte[] firstRow,  final long sequenceid) throws IOException {
    SortedMap<Long,HStoreFile> storefiles=this.store.getStorefiles();
    if (this.readers != null && this.readers.length + 1 == storefiles.size() && storefiles.lastKey().longValue() == sequenceid) {
      HStoreFile hsf=storefiles.get(Long.valueOf(sequenceid));
      if (hsf == null) {
        LOG.warn("Failed getting file for " + sequenceid + "; falling back on close and reopen of all Readers");
      }
 else {
        int nonulls=0;
        for (int i=0; i < this.readers.length; i++) {
          if (this.readers[i] != null)           nonulls++;
        }
        MapFile.Reader[] newReaders=new MapFile.Reader[nonulls + 1];
        newReaders[0]=hsf.getReader(store.fs,false,false);
        int j=1;
        for (int i=0; i < this.readers.length; i++) {
          MapFile.Reader r=this.readers[i];
          if (r != null) {
            newReaders[j++]=r;
          }
        }
        this.readers=newReaders;
        advance(firstRow);
        return;
      }
    }
    if (this.readers != null) {
      for (int i=0; i < this.readers.length; i++) {
        if (this.readers[i] != null) {
          this.readers[i].close();
        }
      }
    }
    this.readers=new MapFile.Reader[storefiles.size()];
    int i=readers.length - 1;
    for (    HStoreFile curHSF : storefiles.values()) {
      readers[i--]=curHSF.getReader(store.fs,false,false);
    }
    advance(firstRow);
  }
  private void advance(  final byte[] firstRow) throws IOException {
    this.keys=new HStoreKey[readers.length];
    this.vals=new byte[readers.length][];
    for (int i=0; i < readers.length; i++) {
      keys[i]=new HStoreKey(HConstants.EMPTY_BYTE_ARRAY,this.store.getHRegionInfo());
      if (firstRow != null && firstRow.length != 0) {
        if (findFirstRow(i,firstRow)) {
          continue;
        }
      }
      while (getNext(i)) {
        if (columnMatch(i)) {
          break;
        }
      }
    }
  }
  /** 
 * For a particular column i, find all the matchers defined for the column. Compare the column family and column key using the matchers. The first one that matches returns true. If no matchers are successful, return false.
 * @param i index into the keys array
 * @return true if any of the matchers for the column match the column familyand the column key.
 * @throws IOException
 */
  boolean columnMatch(  int i) throws IOException {
    return columnMatch(keys[i].getColumn());
  }
  /** 
 * Get the next set of values for this scanner.
 * @param key The key that matched
 * @param results All the results for <code>key</code>
 * @return true if a match was found
 * @throws IOException
 * @see org.apache.hadoop.hbase.regionserver.InternalScanner#next(org.apache.hadoop.hbase.HStoreKey,java.util.SortedMap)
 */
  @Override public boolean next(  HStoreKey key,  SortedMap<byte[],Cell> results) throws IOException {
    if (this.scannerClosed) {
      return false;
    }
    this.lock.readLock().lock();
    try {
      ViableRow viableRow=getNextViableRow();
      boolean insertedItem=false;
      if (viableRow.getRow() != null) {
        key.setRow(viableRow.getRow());
        key.setVersion(viableRow.getTimestamp());
        for (int i=0; i < keys.length; i++) {
          while ((keys[i] != null) && (HStoreKey.compareTwoRowKeys(store.getHRegionInfo(),keys[i].getRow(),viableRow.getRow()) == 0)) {
            if (!isWildcardScanner() && !isMultipleMatchScanner() && (keys[i].getTimestamp() != viableRow.getTimestamp())) {
              break;
            }
            if (columnMatch(i)) {
              if (!results.containsKey(keys[i].getColumn())) {
                results.put(keys[i].getColumn(),new Cell(vals[i],keys[i].getTimestamp()));
                insertedItem=true;
              }
            }
            if (!getNext(i)) {
              closeSubScanner(i);
            }
          }
          while ((keys[i] != null) && ((HStoreKey.compareTwoRowKeys(store.getHRegionInfo(),keys[i].getRow(),viableRow.getRow()) <= 0) || (keys[i].getTimestamp() > this.timestamp) || (!columnMatch(i)))) {
            getNext(i);
          }
        }
      }
      return insertedItem;
    }
  finally {
      this.lock.readLock().unlock();
    }
  }
class ViableRow {
    private final byte[] row;
    private final long ts;
    ViableRow(    final byte[] r,    final long t){
      this.row=r;
      this.ts=t;
    }
    byte[] getRow(){
      return this.row;
    }
    long getTimestamp(){
      return this.ts;
    }
  }
  private ViableRow getNextViableRow() throws IOException {
    byte[] viableRow=null;
    long viableTimestamp=-1;
    long now=System.currentTimeMillis();
    long ttl=store.ttl;
    for (int i=0; i < keys.length; i++) {
      while (keys[i] != null && keys[i].getTimestamp() > this.timestamp && columnMatch(i) && getNext(i)) {
        if (columnMatch(i)) {
          break;
        }
      }
      if ((keys[i] != null) && ((viableRow == null) || (HStoreKey.compareTwoRowKeys(store.getHRegionInfo(),keys[i].getRow(),viableRow) < 0) || ((HStoreKey.compareTwoRowKeys(store.getHRegionInfo(),keys[i].getRow(),viableRow) == 0) && (keys[i].getTimestamp() > viableTimestamp)))) {
        if (ttl == HConstants.FOREVER || now < keys[i].getTimestamp() + ttl) {
          viableRow=keys[i].getRow();
          viableTimestamp=keys[i].getTimestamp();
        }
 else {
          if (LOG.isDebugEnabled()) {
            LOG.debug("getNextViableRow :" + keys[i] + ": expired, skipped");
          }
        }
      }
    }
    return new ViableRow(viableRow,viableTimestamp);
  }
  /** 
 * The user didn't want to start scanning at the first row. This method seeks to the requested row.
 * @param i which iterator to advance
 * @param firstRow seek to this row
 * @return true if this is the first row or if the row was not found
 */
  private boolean findFirstRow(  int i,  final byte[] firstRow) throws IOException {
    ImmutableBytesWritable ibw=new ImmutableBytesWritable();
    HStoreKey firstKey=(HStoreKey)readers[i].getClosest(new HStoreKey(firstRow,this.store.getHRegionInfo()),ibw);
    if (firstKey == null) {
      closeSubScanner(i);
      return true;
    }
    long now=System.currentTimeMillis();
    long ttl=store.ttl;
    if (ttl != HConstants.FOREVER && now >= firstKey.getTimestamp() + ttl) {
      closeSubScanner(i);
      return true;
    }
    this.vals[i]=ibw.get();
    keys[i].setRow(firstKey.getRow());
    keys[i].setColumn(firstKey.getColumn());
    keys[i].setVersion(firstKey.getTimestamp());
    return columnMatch(i);
  }
  /** 
 * Get the next value from the specified reader.
 * @param i which reader to fetch next value from
 * @return true if there is more data available
 */
  private boolean getNext(  int i) throws IOException {
    boolean result=false;
    ImmutableBytesWritable ibw=new ImmutableBytesWritable();
    long now=System.currentTimeMillis();
    long ttl=store.ttl;
    while (true) {
      if (!readers[i].next(keys[i],ibw)) {
        closeSubScanner(i);
        break;
      }
      if (keys[i].getTimestamp() <= this.timestamp) {
        if (ttl == HConstants.FOREVER || now < keys[i].getTimestamp() + ttl) {
          vals[i]=ibw.get();
          result=true;
          break;
        }
        if (LOG.isDebugEnabled()) {
          LOG.debug("getNext: " + keys[i] + ": expired, skipped");
        }
      }
    }
    return result;
  }
  /** 
 * Close down the indicated reader. 
 */
  private void closeSubScanner(  int i){
    try {
      if (readers[i] != null) {
        try {
          readers[i].close();
        }
 catch (        IOException e) {
          LOG.error(store.storeName + " closing sub-scanner",e);
        }
      }
    }
  finally {
      readers[i]=null;
      keys[i]=null;
      vals[i]=null;
    }
  }
  /** 
 * Shut it down! 
 */
  public void close(){
    if (!this.scannerClosed) {
      try {
        for (int i=0; i < readers.length; i++) {
          if (readers[i] != null) {
            try {
              readers[i].close();
            }
 catch (            IOException e) {
              LOG.error(store.storeName + " closing scanner",e);
            }
          }
        }
      }
  finally {
        this.scannerClosed=true;
      }
    }
  }
  /** 
 * Called by hosting  {@link HStoreScanner}.
 * @param sequenceid
 * @param previousNextRow
 * @throws IOException
 */
  void updateReaders(  final long sequenceid,  final byte[] previousNextRow) throws IOException {
    this.lock.writeLock().lock();
    try {
      openReaders(previousNextRow,sequenceid);
      LOG.debug("Replaced Scanner Readers at row " + (previousNextRow == null ? "null" : Bytes.toString(previousNextRow)));
    }
  finally {
      this.lock.writeLock().unlock();
    }
  }
}
