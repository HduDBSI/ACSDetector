/** 
 * Information about a field. This has a  {@link Field} itself and additional information (e.g. {@code defaultLength} and{@code displayByDefault}). This additional information is different between the {@link org.apache.hadoop.hbase.hbtop.mode.Mode}s even when the field is the same. That's why the additional information is separated from  {@link Field}.
 */
@InterfaceAudience.Private public class FieldInfo {
  private final Field field;
  private final int defaultLength;
  private final boolean displayByDefault;
  public FieldInfo(  Field field,  int defaultLength,  boolean displayByDefault){
    this.field=Objects.requireNonNull(field);
    this.defaultLength=defaultLength;
    this.displayByDefault=displayByDefault;
  }
  public Field getField(){
    return field;
  }
  public int getDefaultLength(){
    return defaultLength;
  }
  public boolean isDisplayByDefault(){
    return displayByDefault;
  }
}
