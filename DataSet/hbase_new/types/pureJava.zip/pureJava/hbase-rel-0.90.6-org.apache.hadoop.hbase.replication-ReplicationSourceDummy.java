/** 
 * Source that does nothing at all, helpful to test ReplicationSourceManager
 */
public class ReplicationSourceDummy implements ReplicationSourceInterface {
  ReplicationSourceManager manager;
  String peerClusterId;
  Path currentPath;
  @Override public void init(  Configuration conf,  FileSystem fs,  ReplicationSourceManager manager,  Stoppable stopper,  AtomicBoolean replicating,  String peerClusterId) throws IOException {
    this.manager=manager;
    this.peerClusterId=peerClusterId;
  }
  @Override public void enqueueLog(  Path log){
    this.currentPath=log;
  }
  @Override public Path getCurrentPath(){
    return this.currentPath;
  }
  @Override public void startup(){
  }
  @Override public void terminate(  String reason){
  }
  @Override public void terminate(  String reason,  Exception e){
  }
  @Override public String getPeerClusterZnode(){
    return peerClusterId;
  }
  @Override public String getPeerClusterId(){
    return peerClusterId;
  }
  @Override public void setSourceEnabled(  boolean status){
  }
}
