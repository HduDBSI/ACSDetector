protected class PutThread extends Thread {
  private volatile boolean done;
  private volatile int numPutsFinished=0;
  private Throwable error=null;
  private int numRows;
  private byte[][] families;
  private byte[][] qualifiers;
  private PutThread(  int numRows,  byte[][] families,  byte[][] qualifiers){
    this.numRows=numRows;
    this.families=families;
    this.qualifiers=qualifiers;
  }
  /** 
 * Block until this thread has put at least one row.
 */
  public void waitForFirstPut() throws InterruptedException {
    while (numPutsFinished == 0) {
      checkNoError();
      Thread.sleep(50);
    }
  }
  public void done(){
    done=true;
synchronized (this) {
      interrupt();
    }
  }
  public void checkNoError(){
    if (error != null) {
      assertNull(error);
    }
  }
  @Override public void run(){
    done=false;
    while (!done) {
      try {
        for (int r=0; r < numRows; r++) {
          byte[] row=Bytes.toBytes("row" + r);
          Put put=new Put(row);
          for (          byte[] family : families) {
            for (            byte[] qualifier : qualifiers) {
              put.add(family,qualifier,(long)numPutsFinished,Bytes.toBytes(numPutsFinished));
            }
          }
          region.put(put);
          numPutsFinished++;
          if (numPutsFinished > 0 && numPutsFinished % 47 == 0) {
            System.out.println("put iteration = " + numPutsFinished);
            Delete delete=new Delete(row,(long)numPutsFinished - 30,null);
            region.delete(delete,null,true);
          }
          numPutsFinished++;
        }
      }
 catch (      IOException e) {
        LOG.error("error while putting records",e);
        error=e;
        break;
      }
    }
  }
}
