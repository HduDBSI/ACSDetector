/** 
 * Keeps track of the encoding state.
 */
@InterfaceAudience.Private public class EncodingState {
  /** 
 * The previous Cell the encoder encoded.
 */
  protected Cell prevCell=null;
  public void beforeShipped(){
    if (this.prevCell != null) {
      this.prevCell=KeyValueUtil.copyToNewKeyValue(this.prevCell);
    }
  }
}
