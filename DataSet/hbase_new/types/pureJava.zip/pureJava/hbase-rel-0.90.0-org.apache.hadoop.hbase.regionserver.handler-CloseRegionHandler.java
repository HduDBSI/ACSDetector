/** 
 * Handles closing of a region on a region server.
 */
public class CloseRegionHandler extends EventHandler {
  private static final Log LOG=LogFactory.getLog(CloseRegionHandler.class);
  private final int FAILED=-1;
  private final RegionServerServices rsServices;
  private final HRegionInfo regionInfo;
  private final boolean abort;
  private final boolean zk;
  public CloseRegionHandler(  final Server server,  final RegionServerServices rsServices,  HRegionInfo regionInfo){
    this(server,rsServices,regionInfo,false,true);
  }
  /** 
 * This method used internally by the RegionServer to close out regions.
 * @param server
 * @param rsServices
 * @param regionInfo
 * @param abort If the regionserver is aborting.
 * @param zk If the close should be noted out in zookeeper.
 */
  public CloseRegionHandler(  final Server server,  final RegionServerServices rsServices,  final HRegionInfo regionInfo,  final boolean abort,  final boolean zk){
    this(server,rsServices,regionInfo,abort,zk,EventType.M_RS_CLOSE_REGION);
  }
  protected CloseRegionHandler(  final Server server,  final RegionServerServices rsServices,  HRegionInfo regionInfo,  boolean abort,  final boolean zk,  EventType eventType){
    super(server,eventType);
    this.server=server;
    this.rsServices=rsServices;
    this.regionInfo=regionInfo;
    this.abort=abort;
    this.zk=zk;
  }
  public HRegionInfo getRegionInfo(){
    return regionInfo;
  }
  @Override public void process(){
    String name=regionInfo.getRegionNameAsString();
    LOG.debug("Processing close of " + name);
    String encodedRegionName=regionInfo.getEncodedName();
    HRegion region=this.rsServices.getFromOnlineRegions(encodedRegionName);
    if (region == null) {
      LOG.warn("Received CLOSE for region " + name + " but currently not serving");
      return;
    }
    int expectedVersion=FAILED;
    if (this.zk) {
      expectedVersion=setClosingState();
      if (expectedVersion == FAILED)       return;
    }
    try {
      if (region.close(abort) == null) {
        LOG.warn("Can't close region: was already closed during close(): " + regionInfo.getRegionNameAsString());
        return;
      }
    }
 catch (    IOException e) {
      LOG.error("Unrecoverable exception while closing region " + regionInfo.getRegionNameAsString() + ", still finishing close",e);
    }
    this.rsServices.removeFromOnlineRegions(regionInfo.getEncodedName());
    if (this.zk)     setClosedState(expectedVersion,region);
    LOG.debug("Closed region " + region.getRegionNameAsString());
  }
  /** 
 * Transition ZK node to CLOSED
 * @param expectedVersion
 */
  private void setClosedState(  final int expectedVersion,  final HRegion region){
    try {
      if (ZKAssign.transitionNodeClosed(server.getZooKeeper(),regionInfo,server.getServerName(),expectedVersion) == FAILED) {
        LOG.warn("Completed the CLOSE of a region but when transitioning from " + " CLOSING to CLOSED got a version mismatch, someone else clashed " + "so now unassigning");
        region.close();
        return;
      }
    }
 catch (    NullPointerException e) {
      LOG.warn("NPE during close -- catching and continuing...",e);
    }
catch (    KeeperException e) {
      LOG.error("Failed transitioning node from CLOSING to CLOSED",e);
      return;
    }
catch (    IOException e) {
      LOG.error("Failed to close region after failing to transition",e);
      return;
    }
  }
  /** 
 * Create ZK node in CLOSING state.
 * @return The expectedVersion.  If -1, we failed setting CLOSING.
 */
  private int setClosingState(){
    int expectedVersion=FAILED;
    try {
      if ((expectedVersion=ZKAssign.createNodeClosing(server.getZooKeeper(),regionInfo,server.getServerName())) == FAILED) {
        LOG.warn("Error creating node in CLOSING state, aborting close of " + regionInfo.getRegionNameAsString());
      }
    }
 catch (    KeeperException e) {
      LOG.warn("Error creating node in CLOSING state, aborting close of " + regionInfo.getRegionNameAsString());
    }
    return expectedVersion;
  }
}
