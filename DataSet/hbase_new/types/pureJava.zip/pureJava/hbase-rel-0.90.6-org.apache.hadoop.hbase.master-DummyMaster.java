/** 
 * Dummy Master Implementation.
 */
public static class DummyMaster implements Server {
  private volatile boolean stopped;
  @Override public void abort(  final String msg,  final Throwable t){
  }
  @Override public Configuration getConfiguration(){
    return null;
  }
  @Override public ZooKeeperWatcher getZooKeeper(){
    return null;
  }
  @Override public String getServerName(){
    return null;
  }
  @Override public boolean isStopped(){
    return this.stopped;
  }
  @Override public void stop(  String why){
    this.stopped=true;
  }
  @Override public CatalogTracker getCatalogTracker(){
    return null;
  }
}
