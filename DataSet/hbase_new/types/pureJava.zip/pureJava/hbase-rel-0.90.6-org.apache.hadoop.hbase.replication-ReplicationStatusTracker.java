/** 
 * Tracker for status of the replication
 */
public class ReplicationStatusTracker extends ZooKeeperNodeTracker {
  public ReplicationStatusTracker(  ZooKeeperWatcher watcher,  Abortable abortable){
    super(watcher,getRepStateNode(),abortable);
  }
  @Override public synchronized void nodeDataChanged(  String path){
    if (path.equals(node)) {
      super.nodeDataChanged(path);
      readReplicationStateZnode();
    }
  }
}
