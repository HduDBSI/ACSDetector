/** 
 * A  {@link KVComparator} for <code>.META.</code> catalog table{@link KeyValue}s.
 */
public static class MetaComparator extends KVComparator {
  private final KeyComparator rawcomparator=new MetaKeyComparator();
  public KeyComparator getRawComparator(){
    return this.rawcomparator;
  }
  @Override protected Object clone() throws CloneNotSupportedException {
    return new MetaComparator();
  }
}
