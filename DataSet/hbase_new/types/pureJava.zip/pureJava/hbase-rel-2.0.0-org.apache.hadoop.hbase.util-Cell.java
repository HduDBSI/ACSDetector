private static class Cell {
  @SuppressWarnings("unused") volatile long p0, p1, p2, p3, p4, p5, p6;
  volatile long value;
  @SuppressWarnings("unused") volatile long q0, q1, q2, q3, q4, q5, q6;
  static final AtomicLongFieldUpdater<Cell> valueUpdater=AtomicLongFieldUpdater.newUpdater(Cell.class,"value");
  Cell(){
  }
  Cell(  long initValue){
    value=initValue;
  }
  long get(){
    return value;
  }
  boolean add(  long delta){
    long current=value;
    return valueUpdater.compareAndSet(this,current,current + delta);
  }
}
