@InterfaceAudience.Private public class TruncateTableProcedure extends StateMachineProcedure<MasterProcedureEnv,TruncateTableState> implements TableProcedureInterface {
  private static final Log LOG=LogFactory.getLog(TruncateTableProcedure.class);
  private boolean preserveSplits;
  private List<HRegionInfo> regions;
  private UserGroupInformation user;
  private HTableDescriptor hTableDescriptor;
  private TableName tableName;
  public TruncateTableProcedure(){
  }
  public TruncateTableProcedure(  final MasterProcedureEnv env,  final TableName tableName,  boolean preserveSplits){
    this.tableName=tableName;
    this.preserveSplits=preserveSplits;
    this.user=env.getRequestUser().getUGI();
    this.setOwner(this.user.getShortUserName());
  }
  @Override protected Flow executeFromState(  final MasterProcedureEnv env,  TruncateTableState state){
    if (LOG.isTraceEnabled()) {
      LOG.trace(this + " execute state=" + state);
    }
    try {
switch (state) {
case TRUNCATE_TABLE_PRE_OPERATION:
        if (!prepareTruncate(env)) {
          assert isFailed() : "the truncate should have an exception here";
          return Flow.NO_MORE_STATE;
        }
      LOG.debug("waiting for '" + getTableName() + "' regions in transition");
    regions=ProcedureSyncWait.getRegionsFromMeta(env,getTableName());
  assert regions != null && !regions.isEmpty() : "unexpected 0 regions";
ProcedureSyncWait.waitRegionInTransition(env,regions);
preTruncate(env);
setNextState(TruncateTableState.TRUNCATE_TABLE_REMOVE_FROM_META);
break;
case TRUNCATE_TABLE_REMOVE_FROM_META:
hTableDescriptor=env.getMasterServices().getTableDescriptors().get(tableName);
DeleteTableProcedure.deleteFromMeta(env,getTableName(),regions);
DeleteTableProcedure.deleteAssignmentState(env,getTableName());
setNextState(TruncateTableState.TRUNCATE_TABLE_CLEAR_FS_LAYOUT);
break;
case TRUNCATE_TABLE_CLEAR_FS_LAYOUT:
DeleteTableProcedure.deleteFromFs(env,getTableName(),regions,true);
if (!preserveSplits) {
regions=Arrays.asList(ModifyRegionUtils.createHRegionInfos(hTableDescriptor,null));
}
 else {
regions=recreateRegionInfo(regions);
}
setNextState(TruncateTableState.TRUNCATE_TABLE_CREATE_FS_LAYOUT);
break;
case TRUNCATE_TABLE_CREATE_FS_LAYOUT:
regions=CreateTableProcedure.createFsLayout(env,hTableDescriptor,regions);
CreateTableProcedure.updateTableDescCache(env,getTableName());
setNextState(TruncateTableState.TRUNCATE_TABLE_ADD_TO_META);
break;
case TRUNCATE_TABLE_ADD_TO_META:
regions=CreateTableProcedure.addTableToMeta(env,hTableDescriptor,regions);
setNextState(TruncateTableState.TRUNCATE_TABLE_ASSIGN_REGIONS);
break;
case TRUNCATE_TABLE_ASSIGN_REGIONS:
CreateTableProcedure.assignRegions(env,getTableName(),regions);
setNextState(TruncateTableState.TRUNCATE_TABLE_POST_OPERATION);
hTableDescriptor=null;
regions=null;
break;
case TRUNCATE_TABLE_POST_OPERATION:
postTruncate(env);
LOG.debug("truncate '" + getTableName() + "' completed");
return Flow.NO_MORE_STATE;
default :
throw new UnsupportedOperationException("unhandled state=" + state);
}
}
 catch (HBaseException|IOException e) {
LOG.warn("Retriable error trying to truncate table=" + getTableName() + " state="+ state,e);
}
catch (InterruptedException e) {
LOG.warn("Interrupted trying to truncate table=" + getTableName() + " state="+ state,e);
}
return Flow.HAS_MORE_STATE;
}
@Override protected void rollbackState(final MasterProcedureEnv env,final TruncateTableState state){
if (state == TruncateTableState.TRUNCATE_TABLE_PRE_OPERATION) {
return;
}
throw new UnsupportedOperationException("unhandled state=" + state);
}
@Override protected TruncateTableState getState(final int stateId){
return TruncateTableState.valueOf(stateId);
}
@Override protected int getStateId(final TruncateTableState state){
return state.getNumber();
}
@Override protected TruncateTableState getInitialState(){
return TruncateTableState.TRUNCATE_TABLE_PRE_OPERATION;
}
@Override public TableName getTableName(){
return tableName;
}
@Override public TableOperationType getTableOperationType(){
return TableOperationType.EDIT;
}
@Override public boolean abort(final MasterProcedureEnv env){
return false;
}
@Override protected boolean acquireLock(final MasterProcedureEnv env){
if (!env.isInitialized()) return false;
return env.getProcedureQueue().tryAcquireTableWrite(getTableName(),"truncate table");
}
@Override protected void releaseLock(final MasterProcedureEnv env){
env.getProcedureQueue().releaseTableWrite(getTableName());
}
@Override public void toStringClassDetails(StringBuilder sb){
sb.append(getClass().getSimpleName());
sb.append(" (table=");
sb.append(getTableName());
sb.append(" preserveSplits=");
sb.append(preserveSplits);
sb.append(")");
}
@Override public void serializeStateData(final OutputStream stream) throws IOException {
super.serializeStateData(stream);
MasterProcedureProtos.TruncateTableStateData.Builder state=MasterProcedureProtos.TruncateTableStateData.newBuilder().setUserInfo(MasterProcedureUtil.toProtoUserInfo(this.user)).setPreserveSplits(preserveSplits);
if (hTableDescriptor != null) {
state.setTableSchema(hTableDescriptor.convert());
}
 else {
state.setTableName(ProtobufUtil.toProtoTableName(tableName));
}
if (regions != null) {
for (HRegionInfo hri : regions) {
state.addRegionInfo(HRegionInfo.convert(hri));
}
}
state.build().writeDelimitedTo(stream);
}
@Override public void deserializeStateData(final InputStream stream) throws IOException {
super.deserializeStateData(stream);
MasterProcedureProtos.TruncateTableStateData state=MasterProcedureProtos.TruncateTableStateData.parseDelimitedFrom(stream);
user=MasterProcedureUtil.toUserInfo(state.getUserInfo());
if (state.hasTableSchema()) {
hTableDescriptor=HTableDescriptor.convert(state.getTableSchema());
tableName=hTableDescriptor.getTableName();
}
 else {
tableName=ProtobufUtil.toTableName(state.getTableName());
}
preserveSplits=state.getPreserveSplits();
if (state.getRegionInfoCount() == 0) {
regions=null;
}
 else {
regions=new ArrayList<HRegionInfo>(state.getRegionInfoCount());
for (HBaseProtos.RegionInfo hri : state.getRegionInfoList()) {
regions.add(HRegionInfo.convert(hri));
}
}
}
private static List<HRegionInfo> recreateRegionInfo(final List<HRegionInfo> regions){
ArrayList<HRegionInfo> newRegions=new ArrayList<HRegionInfo>(regions.size());
for (HRegionInfo hri : regions) {
newRegions.add(new HRegionInfo(hri.getTable(),hri.getStartKey(),hri.getEndKey()));
}
return newRegions;
}
private boolean prepareTruncate(final MasterProcedureEnv env) throws IOException {
try {
env.getMasterServices().checkTableModifiable(getTableName());
}
 catch (TableNotFoundException|TableNotDisabledException e) {
setFailure("master-truncate-table",e);
return false;
}
return true;
}
private boolean preTruncate(final MasterProcedureEnv env) throws IOException, InterruptedException {
final MasterCoprocessorHost cpHost=env.getMasterCoprocessorHost();
if (cpHost != null) {
final TableName tableName=getTableName();
user.doAs(new PrivilegedExceptionAction<Void>(){
@Override public Void run() throws Exception {
cpHost.preTruncateTableHandler(tableName);
return null;
}
}
);
}
return true;
}
private void postTruncate(final MasterProcedureEnv env) throws IOException, InterruptedException {
final MasterCoprocessorHost cpHost=env.getMasterCoprocessorHost();
if (cpHost != null) {
final TableName tableName=getTableName();
user.doAs(new PrivilegedExceptionAction<Void>(){
@Override public Void run() throws Exception {
cpHost.postTruncateTableHandler(tableName);
return null;
}
}
);
}
}
}
