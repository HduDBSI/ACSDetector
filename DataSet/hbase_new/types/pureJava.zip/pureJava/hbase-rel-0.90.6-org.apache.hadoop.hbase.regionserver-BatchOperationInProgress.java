/** 
 * Struct-like class that tracks the progress of a batch operation, accumulating status codes and tracking the index at which processing is proceeding.
 */
private static class BatchOperationInProgress<T> {
  T[] operations;
  int nextIndexToProcess=0;
  OperationStatus[] retCodeDetails;
  public BatchOperationInProgress(  T[] operations){
    this.operations=operations;
    this.retCodeDetails=new OperationStatus[operations.length];
    Arrays.fill(this.retCodeDetails,new OperationStatus(OperationStatusCode.NOT_RUN));
  }
  public boolean isDone(){
    return nextIndexToProcess == operations.length;
  }
}
