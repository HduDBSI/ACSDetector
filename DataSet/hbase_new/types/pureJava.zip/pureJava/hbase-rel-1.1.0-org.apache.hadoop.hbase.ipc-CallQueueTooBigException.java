@SuppressWarnings("serial") public static class CallQueueTooBigException extends IOException {
  CallQueueTooBigException(){
    super();
  }
}
