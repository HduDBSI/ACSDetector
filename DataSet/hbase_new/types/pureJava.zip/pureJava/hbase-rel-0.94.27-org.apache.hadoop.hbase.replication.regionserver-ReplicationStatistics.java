/** 
 * Exports metrics recorded by  {@link ReplicationSourceMetrics} as an MBeanfor JMX monitoring.
 */
public class ReplicationStatistics extends MetricsMBeanBase {
  private final ObjectName mbeanName;
  /** 
 * Constructor to register the MBean
 * @param registry which rehistry to use
 * @param name name to get to this bean
 */
  public ReplicationStatistics(  MetricsRegistry registry,  String name){
    super(registry,name);
    mbeanName=MBeanUtil.registerMBean("Replication",name,this);
  }
  public void unRegisterMBean(){
    if (mbeanName != null) {
      MBeanUtil.unregisterMBean(mbeanName);
    }
  }
}
