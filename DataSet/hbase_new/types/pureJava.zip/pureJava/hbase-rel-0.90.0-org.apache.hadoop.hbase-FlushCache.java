/** 
 * Implementors can flushcache.
 */
public static interface FlushCache {
  /** 
 * @throws IOException
 */
  public void flushcache() throws IOException ;
}
