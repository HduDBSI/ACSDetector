public static class createTable_call extends org.apache.thrift.async.TAsyncMethodCall {
  private ByteBuffer tableName;
  private List<ColumnDescriptor> columnFamilies;
  public createTable_call(  ByteBuffer tableName,  List<ColumnDescriptor> columnFamilies,  org.apache.thrift.async.AsyncMethodCallback<createTable_call> resultHandler,  org.apache.thrift.async.TAsyncClient client,  org.apache.thrift.protocol.TProtocolFactory protocolFactory,  org.apache.thrift.transport.TNonblockingTransport transport) throws org.apache.thrift.TException {
    super(client,protocolFactory,transport,resultHandler,false);
    this.tableName=tableName;
    this.columnFamilies=columnFamilies;
  }
  public void write_args(  org.apache.thrift.protocol.TProtocol prot) throws org.apache.thrift.TException {
    prot.writeMessageBegin(new org.apache.thrift.protocol.TMessage("createTable",org.apache.thrift.protocol.TMessageType.CALL,0));
    createTable_args args=new createTable_args();
    args.setTableName(tableName);
    args.setColumnFamilies(columnFamilies);
    args.write(prot);
    prot.writeMessageEnd();
  }
  public void getResult() throws IOError, IllegalArgument, AlreadyExists, org.apache.thrift.TException {
    if (getState() != org.apache.thrift.async.TAsyncMethodCall.State.RESPONSE_READ) {
      throw new IllegalStateException("Method call not finished!");
    }
    org.apache.thrift.transport.TMemoryInputTransport memoryTransport=new org.apache.thrift.transport.TMemoryInputTransport(getFrameBuffer().array());
    org.apache.thrift.protocol.TProtocol prot=client.getProtocolFactory().getProtocol(memoryTransport);
    (new Client(prot)).recv_createTable();
  }
}
