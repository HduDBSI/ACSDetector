@InterfaceAudience.Private public interface MetricsReplicationTableSource extends BaseSource {
  void setLastShippedAge(  long age);
  void incrShippedBytes(  long size);
  long getShippedBytes();
  void clear();
  long getLastShippedAge();
}
