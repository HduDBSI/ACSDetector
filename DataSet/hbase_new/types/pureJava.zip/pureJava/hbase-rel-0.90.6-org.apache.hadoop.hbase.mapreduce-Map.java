/** 
 * Internal Mapper to be run by Hadoop.
 */
public static class Map extends Mapper<ImmutableBytesWritable,Result,ImmutableBytesWritable,Writable> {
  private byte[] family;
  private HashMap<byte[],ImmutableBytesWritable> indexes;
  @Override protected void map(  ImmutableBytesWritable rowKey,  Result result,  Context context) throws IOException, InterruptedException {
    for (    java.util.Map.Entry<byte[],ImmutableBytesWritable> index : indexes.entrySet()) {
      byte[] qualifier=index.getKey();
      ImmutableBytesWritable tableName=index.getValue();
      byte[] value=result.getValue(family,qualifier);
      if (value != null) {
        Put put=new Put(value);
        put.add(INDEX_COLUMN,INDEX_QUALIFIER,rowKey.get());
        context.write(tableName,put);
      }
    }
  }
  @Override protected void setup(  Context context) throws IOException, InterruptedException {
    Configuration configuration=context.getConfiguration();
    String tableName=configuration.get("index.tablename");
    String[] fields=configuration.getStrings("index.fields");
    String familyName=configuration.get("index.familyname");
    family=Bytes.toBytes(familyName);
    indexes=new HashMap<byte[],ImmutableBytesWritable>();
    for (    String field : fields) {
      indexes.put(Bytes.toBytes(field),new ImmutableBytesWritable(Bytes.toBytes(tableName + "-" + field)));
    }
  }
}
