/** 
 * Byte array comparator class.
 */
public static class ByteArrayComparator implements RawComparator<byte[]> {
  /** 
 * Constructor
 */
  public ByteArrayComparator(){
    super();
  }
  public int compare(  byte[] left,  byte[] right){
    return compareTo(left,right);
  }
  public int compare(  byte[] b1,  int s1,  int l1,  byte[] b2,  int s2,  int l2){
    return LexicographicalComparerHolder.BEST_COMPARER.compareTo(b1,s1,l1,b2,s2,l2);
  }
}
