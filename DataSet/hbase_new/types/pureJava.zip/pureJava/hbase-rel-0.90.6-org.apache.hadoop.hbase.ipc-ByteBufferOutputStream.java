/** 
 * Not thread safe!
 */
public class ByteBufferOutputStream extends OutputStream {
  protected ByteBuffer buf;
  public ByteBufferOutputStream(  int capacity){
    this(capacity,false);
  }
  public ByteBufferOutputStream(  int capacity,  boolean useDirectByteBuffer){
    if (useDirectByteBuffer) {
      buf=ByteBuffer.allocateDirect(capacity);
    }
 else {
      buf=ByteBuffer.allocate(capacity);
    }
  }
  public int size(){
    return buf.position();
  }
  /** 
 * This flips the underlying BB so be sure to use it _last_!
 * @return ByteBuffer
 */
  public ByteBuffer getByteBuffer(){
    buf.flip();
    return buf;
  }
  private void checkSizeAndGrow(  int extra){
    if ((buf.position() + extra) > buf.limit()) {
      int newSize=(int)Math.min((((long)buf.capacity()) * 2),(long)(Integer.MAX_VALUE));
      newSize=Math.max(newSize,buf.position() + extra);
      ByteBuffer newBuf=ByteBuffer.allocate(newSize);
      buf.flip();
      newBuf.put(buf);
      buf=newBuf;
    }
  }
  @Override public void write(  int b) throws IOException {
    checkSizeAndGrow(Bytes.SIZEOF_BYTE);
    buf.put((byte)b);
  }
  @Override public void write(  byte[] b) throws IOException {
    checkSizeAndGrow(b.length);
    buf.put(b);
  }
  @Override public void write(  byte[] b,  int off,  int len) throws IOException {
    checkSizeAndGrow(len);
    buf.put(b,off,len);
  }
  @Override public void flush() throws IOException {
  }
  @Override public void close() throws IOException {
  }
}
