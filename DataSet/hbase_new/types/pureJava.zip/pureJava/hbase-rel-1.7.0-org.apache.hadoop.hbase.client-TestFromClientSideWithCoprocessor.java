/** 
 * Test all client operations with a coprocessor that just implements the default flush/compact/scan policy.
 */
@Category(LargeTests.class) public class TestFromClientSideWithCoprocessor extends TestFromClientSide {
  @Parameterized.Parameters public static Collection parameters(){
    return Arrays.asList(new Object[][]{{ZKConnectionRegistry.class}});
  }
  public TestFromClientSideWithCoprocessor(  Class registry) throws Exception {
    initialize(registry);
  }
  public static void initialize(  Class<? extends ConnectionRegistry> registry) throws Exception {
    if (isSameParameterizedCluster(registry)) {
      return;
    }
    if (TEST_UTIL != null) {
      TEST_UTIL.shutdownMiniCluster();
    }
    TEST_UTIL=new HBaseTestingUtility();
    Configuration conf=TEST_UTIL.getConfiguration();
    conf.setStrings(CoprocessorHost.REGION_COPROCESSOR_CONF_KEY,MultiRowMutationEndpoint.class.getName(),NoOpScanPolicyObserver.class.getName());
    conf.setBoolean("hbase.table.sanity.checks",true);
    conf.setClass(HConstants.REGISTRY_IMPL_CONF_KEY,registry,ConnectionRegistry.class);
    TEST_UTIL.startMiniCluster(SLAVES);
  }
}
