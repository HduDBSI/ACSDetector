/** 
 * A  {@link RegionSplitPolicy} that disables region splits.This should be used with care, since it will disable automatic sharding. Most of the time, using  {@link ConstantSizeRegionSplitPolicy} with alarge region size (10GB, etc) is safer.
 */
public class DisabledRegionSplitPolicy extends RegionSplitPolicy {
  @Override protected boolean shouldSplit(){
    return false;
  }
}
