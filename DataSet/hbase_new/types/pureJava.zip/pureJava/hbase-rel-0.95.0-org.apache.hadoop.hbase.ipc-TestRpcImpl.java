private static class TestRpcImpl implements TestRpc {
  /** 
 * Should the return value of delayed call be set at the end of the delay or at call return.
 */
  private boolean delayReturnValue;
  /** 
 * @param delayReturnValue Should the response to the delayed call be setat the start or the end of the delay.
 */
  public TestRpcImpl(  boolean delayReturnValue){
    this.delayReturnValue=delayReturnValue;
  }
  @Override public TestResponse test(  final Object rpcController,  final TestArg testArg) throws ServiceException {
    boolean delay=testArg.getDelay();
    TestResponse.Builder responseBuilder=TestResponse.newBuilder();
    if (!delay) {
      responseBuilder.setResponse(UNDELAYED);
      return responseBuilder.build();
    }
    final Delayable call=HBaseServer.getCurrentCall();
    call.startDelay(delayReturnValue);
    new Thread(){
      public void run(){
        try {
          Thread.sleep(500);
          TestResponse.Builder responseBuilder=TestResponse.newBuilder();
          call.endDelay(delayReturnValue ? responseBuilder.setResponse(DELAYED).build() : null);
        }
 catch (        Exception e) {
          e.printStackTrace();
        }
      }
    }
.start();
    responseBuilder.setResponse(0xDEADBEEF);
    return responseBuilder.build();
  }
}
