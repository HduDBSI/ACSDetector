/** 
 * Returns our async process.
 */
static class MyConnectionImpl2 extends MyConnectionImpl {
  List<HRegionLocation> hrl;
  final boolean usedRegions[];
  protected MyConnectionImpl2(  List<HRegionLocation> hrl) throws IOException {
    super(conf);
    this.hrl=hrl;
    this.usedRegions=new boolean[hrl.size()];
  }
  @Override public RegionLocations locateRegion(  TableName tableName,  byte[] row,  boolean useCache,  boolean retry,  int replicaId) throws IOException {
    int i=0;
    for (    HRegionLocation hr : hrl) {
      if (Arrays.equals(row,hr.getRegionInfo().getStartKey())) {
        usedRegions[i]=true;
        return new RegionLocations(hr);
      }
      i++;
    }
    return null;
  }
}
