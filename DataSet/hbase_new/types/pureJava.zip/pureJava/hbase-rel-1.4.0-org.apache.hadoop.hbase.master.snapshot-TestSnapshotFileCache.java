/** 
 * Test that we correctly reload the cache, filter directories, etc.
 */
@Category(MediumTests.class) public class TestSnapshotFileCache {
  private static final Log LOG=LogFactory.getLog(TestSnapshotFileCache.class);
  private static final HBaseTestingUtility UTIL=new HBaseTestingUtility();
  private static FileSystem fs;
  private static Path rootDir;
  @BeforeClass public static void startCluster() throws Exception {
    UTIL.startMiniDFSCluster(1);
    fs=UTIL.getDFSCluster().getFileSystem();
    rootDir=UTIL.getDefaultRootDirPath();
  }
  @AfterClass public static void stopCluster() throws Exception {
    UTIL.shutdownMiniDFSCluster();
  }
  @After public void cleanupFiles() throws Exception {
    Path snapshotDir=SnapshotDescriptionUtils.getSnapshotsDir(rootDir);
    fs.delete(snapshotDir,true);
  }
  @Test(timeout=10000000) @Ignore("See HBASE-19275") public void testLoadAndDelete() throws IOException {
    long period=Long.MAX_VALUE;
    SnapshotFileCache cache=new SnapshotFileCache(fs,rootDir,period,10000000,"test-snapshot-file-cache-refresh",new SnapshotFiles());
    createAndTestSnapshotV1(cache,"snapshot1a",false,true);
    createAndTestSnapshotV1(cache,"snapshot1b",true,true);
    createAndTestSnapshotV2(cache,"snapshot2a",false,true);
    createAndTestSnapshotV2(cache,"snapshot2b",true,true);
  }
  @Test @Ignore("See HBASE-19275") public void testReloadModifiedDirectory() throws IOException {
    long period=Long.MAX_VALUE;
    SnapshotFileCache cache=new SnapshotFileCache(fs,rootDir,period,10000000,"test-snapshot-file-cache-refresh",new SnapshotFiles());
    createAndTestSnapshotV1(cache,"snapshot1",false,true);
    createAndTestSnapshotV1(cache,"snapshot1",false,false);
    createAndTestSnapshotV2(cache,"snapshot2",false,true);
    createAndTestSnapshotV2(cache,"snapshot2",false,false);
  }
  @Test public void testSnapshotTempDirReload() throws IOException {
    long period=Long.MAX_VALUE;
    SnapshotFileCache cache=new SnapshotFileCache(fs,rootDir,period,10000000,"test-snapshot-file-cache-refresh",new SnapshotFiles());
    createAndTestSnapshotV1(cache,"snapshot0v1",false,false);
    createAndTestSnapshotV1(cache,"snapshot0v2",false,false);
    createAndTestSnapshotV2(cache,"snapshot1",true,false);
    createAndTestSnapshotV2(cache,"snapshot2",true,false);
  }
  @Test public void testWeNeverCacheTmpDirAndLoadIt() throws Exception {
    final AtomicInteger count=new AtomicInteger(0);
    long period=Long.MAX_VALUE;
    SnapshotFileCache cache=new SnapshotFileCache(fs,rootDir,period,10000000,"test-snapshot-file-cache-refresh",new SnapshotFiles()){
      @Override List<String> getSnapshotsInProgress() throws IOException {
        List<String> result=super.getSnapshotsInProgress();
        count.incrementAndGet();
        return result;
      }
      @Override public void triggerCacheRefreshForTesting(){
        super.triggerCacheRefreshForTesting();
      }
    }
;
    SnapshotMock.SnapshotBuilder complete=createAndTestSnapshotV1(cache,"snapshot",false,false);
    int countBeforeCheck=count.get();
    FSUtils.logFileSystemState(fs,rootDir,LOG);
    List<FileStatus> allStoreFiles=getStoreFilesForSnapshot(complete);
    Iterable<FileStatus> deletableFiles=cache.getUnreferencedFiles(allStoreFiles);
    assertTrue(Iterables.isEmpty(deletableFiles));
    assertEquals(0,count.get() - countBeforeCheck);
    FileStatus randomFile=mockStoreFile(UUID.randomUUID().toString());
    allStoreFiles.add(randomFile);
    deletableFiles=cache.getUnreferencedFiles(allStoreFiles);
    assertEquals(randomFile,Iterables.getOnlyElement(deletableFiles));
    assertEquals(1,count.get() - countBeforeCheck);
  }
  private List<FileStatus> getStoreFilesForSnapshot(  SnapshotMock.SnapshotBuilder builder) throws IOException {
    final List<FileStatus> allStoreFiles=Lists.newArrayList();
    SnapshotReferenceUtil.visitReferencedFiles(UTIL.getConfiguration(),fs,builder.getSnapshotsDir(),new SnapshotReferenceUtil.SnapshotVisitor(){
      @Override public void storeFile(      HRegionInfo regionInfo,      String familyName,      SnapshotProtos.SnapshotRegionManifest.StoreFile storeFile) throws IOException {
        FileStatus status=mockStoreFile(storeFile.getName());
        allStoreFiles.add(status);
      }
    }
);
    return allStoreFiles;
  }
  private FileStatus mockStoreFile(  String storeFileName){
    FileStatus status=mock(FileStatus.class);
    Path path=mock(Path.class);
    when(path.getName()).thenReturn(storeFileName);
    when(status.getPath()).thenReturn(path);
    return status;
  }
class SnapshotFiles implements SnapshotFileCache.SnapshotFileInspector {
    public Collection<String> filesUnderSnapshot(    final Path snapshotDir) throws IOException {
      Collection<String> files=new HashSet<String>();
      files.addAll(SnapshotReferenceUtil.getHFileNames(UTIL.getConfiguration(),fs,snapshotDir));
      return files;
    }
  }
  private SnapshotMock.SnapshotBuilder createAndTestSnapshotV1(  final SnapshotFileCache cache,  final String name,  final boolean tmp,  final boolean removeOnExit) throws IOException {
    SnapshotMock snapshotMock=new SnapshotMock(UTIL.getConfiguration(),fs,rootDir);
    SnapshotMock.SnapshotBuilder builder=snapshotMock.createSnapshotV1(name,name);
    createAndTestSnapshot(cache,builder,tmp,removeOnExit);
    return builder;
  }
  private void createAndTestSnapshotV2(  final SnapshotFileCache cache,  final String name,  final boolean tmp,  final boolean removeOnExit) throws IOException {
    SnapshotMock snapshotMock=new SnapshotMock(UTIL.getConfiguration(),fs,rootDir);
    SnapshotMock.SnapshotBuilder builder=snapshotMock.createSnapshotV2(name,name);
    createAndTestSnapshot(cache,builder,tmp,removeOnExit);
  }
  private void createAndTestSnapshot(  final SnapshotFileCache cache,  final SnapshotMock.SnapshotBuilder builder,  final boolean tmp,  final boolean removeOnExit) throws IOException {
    List<Path> files=new ArrayList<Path>();
    for (int i=0; i < 3; ++i) {
      for (      Path filePath : builder.addRegion()) {
        if (tmp) {
          FSUtils.logFileSystemState(fs,rootDir,LOG);
          assertFalse("Cache didn't find " + filePath,contains(getNonSnapshotFiles(cache,filePath),filePath));
        }
        files.add(filePath);
      }
    }
    if (!tmp) {
      builder.commit();
    }
    for (    Path path : files) {
      assertFalse("Cache didn't find " + path,contains(getNonSnapshotFiles(cache,path),path));
    }
    FSUtils.logFileSystemState(fs,rootDir,LOG);
    if (removeOnExit) {
      LOG.debug("Deleting snapshot.");
      fs.delete(builder.getSnapshotsDir(),true);
      FSUtils.logFileSystemState(fs,rootDir,LOG);
      for (      Path filePath : files) {
        assertFalse("Cache didn't find " + filePath,contains(getNonSnapshotFiles(cache,filePath),filePath));
      }
      cache.triggerCacheRefreshForTesting();
      for (      Path filePath : files) {
        assertFalse("Cache found '" + filePath + "', but it shouldn't have.",contains(getNonSnapshotFiles(cache,filePath),filePath));
      }
    }
  }
  private static boolean contains(  Iterable<FileStatus> files,  Path filePath){
    for (    FileStatus status : files) {
      if (filePath.equals(status.getPath())) {
        return true;
      }
    }
    return false;
  }
  private static Iterable<FileStatus> getNonSnapshotFiles(  SnapshotFileCache cache,  Path storeFile) throws IOException {
    return cache.getUnreferencedFiles(Arrays.asList(FSUtils.listStatus(fs,storeFile.getParent())));
  }
}
