/** 
 * Client-side call timeout
 */
@SuppressWarnings("serial") @InterfaceAudience.Public @InterfaceStability.Evolving public class CallTimeoutException extends IOException {
  public CallTimeoutException(  final String msg){
    super(msg);
  }
}
