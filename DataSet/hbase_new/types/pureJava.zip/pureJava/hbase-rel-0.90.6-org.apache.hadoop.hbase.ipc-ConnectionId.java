/** 
 * This class holds the address and the user ticket. The client connections to servers are uniquely identified by <remoteAddress, ticket>
 */
private static class ConnectionId {
  final InetSocketAddress address;
  final UserGroupInformation ticket;
  final private int rpcTimeout;
  ConnectionId(  InetSocketAddress address,  UserGroupInformation ticket,  int rpcTimeout){
    this.address=address;
    this.ticket=ticket;
    this.rpcTimeout=rpcTimeout;
  }
  InetSocketAddress getAddress(){
    return address;
  }
  UserGroupInformation getTicket(){
    return ticket;
  }
  @Override public boolean equals(  Object obj){
    if (obj instanceof ConnectionId) {
      ConnectionId id=(ConnectionId)obj;
      return address.equals(id.address) && ticket == id.ticket && rpcTimeout == id.rpcTimeout;
    }
    return false;
  }
  @Override public int hashCode(){
    return address.hashCode() ^ System.identityHashCode(ticket) ^ rpcTimeout;
  }
}
