/** 
 * The HTTP result code, response headers, and body of a HTTP response.
 */
public class Response {
  private int code;
  private Header[] headers;
  private byte[] body;
  /** 
 * Constructor
 * @param code the HTTP response code
 */
  public Response(  int code){
    this(code,null,null);
  }
  /** 
 * Constructor
 * @param code the HTTP response code
 * @param headers the HTTP response headers
 */
  public Response(  int code,  Header[] headers){
    this(code,headers,null);
  }
  /** 
 * Constructor
 * @param code the HTTP response code
 * @param headers the HTTP response headers
 * @param body the response body, can be null
 */
  public Response(  int code,  Header[] headers,  byte[] body){
    this.code=code;
    this.headers=headers;
    this.body=body;
  }
  /** 
 * @return the HTTP response code
 */
  public int getCode(){
    return code;
  }
  /** 
 * @return the HTTP response headers
 */
  public Header[] getHeaders(){
    return headers;
  }
  public String getHeader(  String key){
    for (    Header header : headers) {
      if (header.getName().equalsIgnoreCase(key)) {
        return header.getValue();
      }
    }
    return null;
  }
  /** 
 * @return the value of the Location header
 */
  public String getLocation(){
    return getHeader("Location");
  }
  /** 
 * @return true if a response body was sent
 */
  public boolean hasBody(){
    return body != null;
  }
  /** 
 * @return the HTTP response body
 */
  public byte[] getBody(){
    return body;
  }
  /** 
 * @param code the HTTP response code
 */
  public void setCode(  int code){
    this.code=code;
  }
  /** 
 * @param headers the HTTP response headers
 */
  public void setHeaders(  Header[] headers){
    this.headers=headers;
  }
  /** 
 * @param body the response body
 */
  public void setBody(  byte[] body){
    this.body=body;
  }
}
