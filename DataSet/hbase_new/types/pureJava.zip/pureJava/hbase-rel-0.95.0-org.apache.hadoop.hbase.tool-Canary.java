/** 
 * HBase Canary Tool, that that can be used to do "canary monitoring" of a running HBase cluster. Foreach region tries to get one row per column family and outputs some information about failure or latency.
 */
public final class Canary implements Tool {
public interface Sink {
    public void publishReadFailure(    HRegionInfo region);
    public void publishReadFailure(    HRegionInfo region,    HColumnDescriptor column);
    public void publishReadTiming(    HRegionInfo region,    HColumnDescriptor column,    long msTime);
  }
public static class StdOutSink implements Sink {
    @Override public void publishReadFailure(    HRegionInfo region){
      LOG.error(String.format("read from region %s failed",region.getRegionNameAsString()));
    }
    @Override public void publishReadFailure(    HRegionInfo region,    HColumnDescriptor column){
      LOG.error(String.format("read from region %s column family %s failed",region.getRegionNameAsString(),column.getNameAsString()));
    }
    @Override public void publishReadTiming(    HRegionInfo region,    HColumnDescriptor column,    long msTime){
      LOG.info(String.format("read from region %s column family %s in %dms",region.getRegionNameAsString(),column.getNameAsString(),msTime));
    }
  }
  private static final long DEFAULT_INTERVAL=6000;
  private static final Log LOG=LogFactory.getLog(Canary.class);
  private Configuration conf=null;
  private HBaseAdmin admin=null;
  private long interval=0;
  private Sink sink=null;
  public Canary(){
    this(new StdOutSink());
  }
  public Canary(  Sink sink){
    this.sink=sink;
  }
  @Override public Configuration getConf(){
    return conf;
  }
  @Override public void setConf(  Configuration conf){
    this.conf=conf;
  }
  @Override public int run(  String[] args) throws Exception {
    int tables_index=-1;
    for (int i=0; i < args.length; i++) {
      String cmd=args[i];
      if (cmd.startsWith("-")) {
        if (tables_index >= 0) {
          System.err.println("Invalid command line options");
          printUsageAndExit();
        }
        if (cmd.equals("-help")) {
          printUsageAndExit();
        }
 else         if (cmd.equals("-daemon") && interval == 0) {
          interval=DEFAULT_INTERVAL;
        }
 else         if (cmd.equals("-interval")) {
          i++;
          if (i == args.length) {
            System.err.println("-interval needs a numeric value argument.");
            printUsageAndExit();
          }
          try {
            interval=Long.parseLong(args[i]) * 1000;
          }
 catch (          NumberFormatException e) {
            System.err.println("-interval needs a numeric value argument.");
            printUsageAndExit();
          }
        }
 else {
          System.err.println(cmd + " options is invalid.");
          printUsageAndExit();
        }
      }
 else       if (tables_index < 0) {
        tables_index=i;
      }
    }
    if (conf == null)     conf=HBaseConfiguration.create();
    admin=new HBaseAdmin(conf);
    do {
      if (admin.isAborted()) {
        LOG.error("HBaseAdmin aborted");
        return (1);
      }
      if (tables_index >= 0) {
        for (int i=tables_index; i < args.length; i++) {
          sniff(args[i]);
        }
      }
 else {
        sniff();
      }
      Thread.sleep(interval);
    }
 while (interval > 0);
    return (0);
  }
  private void printUsageAndExit(){
    System.err.printf("Usage: bin/hbase %s [opts] [table 1 [table 2...]]%n",getClass().getName());
    System.err.println(" where [opts] are:");
    System.err.println("   -help          Show this help and exit.");
    System.err.println("   -daemon        Continuous check at defined intervals.");
    System.err.println("   -interval <N>  Interval between checks (sec)");
    System.exit(1);
  }
  private void sniff() throws Exception {
    for (    HTableDescriptor table : admin.listTables()) {
      sniff(table);
    }
  }
  private void sniff(  String tableName) throws Exception {
    if (admin.isTableAvailable(tableName)) {
      sniff(admin.getTableDescriptor(tableName.getBytes()));
    }
 else {
      LOG.warn(String.format("Table %s is not available",tableName));
    }
  }
  private void sniff(  HTableDescriptor tableDesc) throws Exception {
    HTable table=null;
    try {
      table=new HTable(admin.getConfiguration(),tableDesc.getName());
    }
 catch (    TableNotFoundException e) {
      return;
    }
    for (    HRegionInfo region : admin.getTableRegions(tableDesc.getName())) {
      try {
        sniffRegion(region,table);
      }
 catch (      Exception e) {
        sink.publishReadFailure(region);
      }
    }
  }
  private void sniffRegion(  HRegionInfo region,  HTable table) throws Exception {
    HTableDescriptor tableDesc=table.getTableDescriptor();
    for (    HColumnDescriptor column : tableDesc.getColumnFamilies()) {
      Get get=new Get(region.getStartKey());
      get.addFamily(column.getName());
      try {
        long startTime=System.currentTimeMillis();
        table.get(get);
        long time=System.currentTimeMillis() - startTime;
        sink.publishReadTiming(region,column,time);
      }
 catch (      Exception e) {
        sink.publishReadFailure(region,column);
      }
    }
  }
  public static void main(  String[] args) throws Exception {
    int exitCode=ToolRunner.run(new Canary(),args);
    System.exit(exitCode);
  }
}
