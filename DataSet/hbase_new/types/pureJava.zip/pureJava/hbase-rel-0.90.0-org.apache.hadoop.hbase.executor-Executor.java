/** 
 * Executor instance.
 */
static class Executor {
  final long keepAliveTimeInMillis=1000;
  final ThreadPoolExecutor threadPoolExecutor;
  final BlockingQueue<Runnable> q=new LinkedBlockingQueue<Runnable>();
  private final String name;
  private final Map<EventHandler.EventType,EventHandlerListener> eventHandlerListeners;
  protected Executor(  String name,  int maxThreads,  final Map<EventHandler.EventType,EventHandlerListener> eventHandlerListeners){
    this.name=name;
    this.eventHandlerListeners=eventHandlerListeners;
    this.threadPoolExecutor=new ThreadPoolExecutor(maxThreads,maxThreads,keepAliveTimeInMillis,TimeUnit.MILLISECONDS,q);
    ThreadFactoryBuilder tfb=new ThreadFactoryBuilder();
    tfb.setNameFormat(this.name + "-%d");
    this.threadPoolExecutor.setThreadFactory(tfb.build());
  }
  /** 
 * Submit the event to the queue for handling.
 * @param event
 */
  void submit(  final EventHandler event){
    EventHandlerListener listener=this.eventHandlerListeners.get(event.getEventType());
    if (listener != null) {
      event.setListener(listener);
    }
    this.threadPoolExecutor.execute(event);
  }
}
