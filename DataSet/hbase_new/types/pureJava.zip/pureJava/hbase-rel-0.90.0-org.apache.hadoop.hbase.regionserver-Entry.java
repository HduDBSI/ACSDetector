/** 
 * Entry to store key/value mappings. <p> Contains previous and next pointers for the doubly linked-list which is used for LRU eviction. <p> Instantiations of this class are memory aware.  Both the key and value classes used must also implement <code>HeapSize</code>.
 */
protected static class Entry<K extends HeapSize,V extends HeapSize> implements Map.Entry<K,V>, HeapSize {
  /** 
 * The baseline overhead memory usage of this class 
 */
  static final int OVERHEAD=1 * Bytes.SIZEOF_LONG + 5 * ClassSize.REFERENCE + 2 * Bytes.SIZEOF_INT;
  /** 
 * The key 
 */
  protected final K key;
  /** 
 * The value 
 */
  protected V value;
  /** 
 * The hash value for this entries key 
 */
  protected final int hash;
  /** 
 * The next entry in the hash chain (for collisions) 
 */
  protected Entry<K,V> next;
  /** 
 * The previous entry in the LRU list (towards LRU) 
 */
  protected Entry<K,V> prevPtr;
  /** 
 * The next entry in the LRU list (towards MRU) 
 */
  protected Entry<K,V> nextPtr;
  /** 
 * The precomputed heap size of this entry 
 */
  protected long heapSize;
  /** 
 * Create a new entry.
 * @param h the hash value of the key
 * @param k the key
 * @param v the value
 * @param nextChainPtr the next entry in the hash chain, null if none
 * @param prevLruPtr the previous entry in the LRU
 */
  Entry(  int h,  K k,  V v,  Entry<K,V> nextChainPtr,  Entry<K,V> prevLruPtr){
    value=v;
    next=nextChainPtr;
    key=k;
    hash=h;
    prevPtr=prevLruPtr;
    nextPtr=null;
    heapSize=OVERHEAD + k.heapSize() + v.heapSize();
  }
  /** 
 * Get the key of this entry.
 * @return the key associated with this entry
 */
  public K getKey(){
    return key;
  }
  /** 
 * Get the value of this entry.
 * @return the value currently associated with this entry
 */
  public V getValue(){
    return value;
  }
  /** 
 * Set the value of this entry. It is not recommended to use this method when changing the value. Rather, using <code>replaceValue</code> will return the difference in heap usage between the previous and current values.
 * @param newValue the new value to associate with this entry
 * @return the value previously associated with this entry
 */
  public V setValue(  V newValue){
    V oldValue=value;
    value=newValue;
    return oldValue;
  }
  /** 
 * Replace the value of this entry. Computes and returns the difference in heap size when changing the value associated with this entry.
 * @param newValue the new value to associate with this entry
 * @return the change in heap usage of this entry in bytes
 */
  protected long replaceValue(  V newValue){
    long sizeDiff=newValue.heapSize() - value.heapSize();
    value=newValue;
    heapSize+=sizeDiff;
    return sizeDiff;
  }
  /** 
 * Returns true is the specified entry has the same key and the same value as this entry.
 * @param o entry to test against current
 * @return true is entries have equal key and value, false if no
 */
  public boolean equals(  Object o){
    if (!(o instanceof Map.Entry))     return false;
    Map.Entry e=(Map.Entry)o;
    Object k1=getKey();
    Object k2=e.getKey();
    if (k1 == k2 || (k1 != null && k1.equals(k2))) {
      Object v1=getValue();
      Object v2=e.getValue();
      if (v1 == v2 || (v1 != null && v1.equals(v2)))       return true;
    }
    return false;
  }
  /** 
 * Returns the hash code of the entry by xor'ing the hash values of the key and value of this entry.
 * @return hash value of this entry
 */
  public int hashCode(){
    return (key.hashCode() ^ value.hashCode());
  }
  /** 
 * Returns String representation of the entry in form "key=value"
 * @return string value of entry
 */
  public String toString(){
    return getKey() + "=" + getValue();
  }
  /** 
 * Sets the previous pointer for the entry in the LRU.
 * @param prevPtr previous entry
 */
  protected void setPrevPtr(  Entry<K,V> prevPtr){
    this.prevPtr=prevPtr;
  }
  /** 
 * Returns the previous pointer for the entry in the LRU.
 * @return previous entry
 */
  protected Entry<K,V> getPrevPtr(){
    return prevPtr;
  }
  /** 
 * Sets the next pointer for the entry in the LRU.
 * @param nextPtr next entry
 */
  protected void setNextPtr(  Entry<K,V> nextPtr){
    this.nextPtr=nextPtr;
  }
  /** 
 * Returns the next pointer for the entry in teh LRU.
 * @return next entry
 */
  protected Entry<K,V> getNextPtr(){
    return nextPtr;
  }
  /** 
 * Returns the pre-computed and "deep" size of the Entry
 * @return size of the entry in bytes
 */
  public long heapSize(){
    return heapSize;
  }
}
