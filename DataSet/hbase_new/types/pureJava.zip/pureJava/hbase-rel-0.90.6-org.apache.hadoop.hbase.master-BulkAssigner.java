/** 
 * Base class used bulk assigning and unassigning regions. Encapsulates a fixed size thread pool of executors to run assignment/unassignment. Implement  {@link #populatePool(java.util.concurrent.ExecutorService)} and{@link #waitUntilDone(long)}.  The default implementation of the  {@link #getUncaughtExceptionHandler()} is to abort the hostingServer.
 */
public abstract class BulkAssigner {
  final Server server;
  /** 
 * @param server An instance of Server
 */
  public BulkAssigner(  final Server server){
    this.server=server;
  }
  /** 
 * @return What to use for a thread prefix when executor runs.
 */
  protected String getThreadNamePrefix(){
    return this.server.getServerName() + "-" + this.getClass().getName();
  }
  protected UncaughtExceptionHandler getUncaughtExceptionHandler(){
    return new UncaughtExceptionHandler(){
      @Override public void uncaughtException(      Thread t,      Throwable e){
        server.abort("Uncaught exception in " + t.getName(),e);
      }
    }
;
  }
  protected int getThreadCount(){
    return this.server.getConfiguration().getInt("hbase.bulk.assignment.threadpool.size",20);
  }
  protected long getTimeoutOnRIT(){
    return this.server.getConfiguration().getLong("hbase.bulk.assignment.waiton.empty.rit",5 * 60 * 1000);
  }
  protected abstract void populatePool(  final java.util.concurrent.ExecutorService pool);
  public boolean bulkAssign() throws InterruptedException {
    return bulkAssign(true);
  }
  /** 
 * Run the bulk assign.
 * @param sync Whether to assign synchronously.
 * @throws InterruptedException
 * @return True if done.
 */
  public boolean bulkAssign(  boolean sync) throws InterruptedException {
    boolean result=false;
    ThreadFactoryBuilder builder=new ThreadFactoryBuilder();
    builder.setDaemon(true);
    builder.setNameFormat(getThreadNamePrefix() + "-%1$d");
    builder.setUncaughtExceptionHandler(getUncaughtExceptionHandler());
    int threadCount=getThreadCount();
    java.util.concurrent.ExecutorService pool=Executors.newFixedThreadPool(threadCount,builder.build());
    try {
      populatePool(pool);
      if (sync)       result=waitUntilDone(getTimeoutOnRIT());
    }
  finally {
      pool.shutdown();
    }
    return result;
  }
  /** 
 * Wait until bulk assign is done.
 * @param timeout How long to wait.
 * @throws InterruptedException
 * @return True if the condition we were waiting on happened.
 */
  protected abstract boolean waitUntilDone(  final long timeout) throws InterruptedException ;
}
