/** 
 * Comparator used to compare logs together based on their start time
 */
public static class LogsComparator implements Comparator<Path> {
  @Override public int compare(  Path o1,  Path o2){
    return Long.valueOf(getTS(o1)).compareTo(getTS(o2));
  }
  /** 
 * Split a path to get the start time For example: 10.20.20.171%3A60020.1277499063250
 * @param p path to split
 * @return start time
 */
  private static long getTS(  Path p){
    int tsIndex=p.getName().lastIndexOf('.') + 1;
    return Long.parseLong(p.getName().substring(tsIndex));
  }
}
