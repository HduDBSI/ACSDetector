public static class ObserverB extends BaseRegionObserver {
  long id;
  @Override public void postPut(  final ObserverContext<RegionCoprocessorEnvironment> c,  final Put put,  final WALEdit edit,  final boolean writeToWAL) throws IOException {
    id=System.currentTimeMillis();
    try {
      Thread.sleep(10);
    }
 catch (    InterruptedException ex) {
    }
  }
}
