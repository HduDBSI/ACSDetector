/** 
 * Factory for creating HTable instances.
 * @deprecated as of 0.98.1. See {@link HConnectionManager#createConnection(Configuration)}.
 */
@InterfaceAudience.Public @InterfaceStability.Stable @Deprecated public class HTableFactory implements HTableInterfaceFactory {
  @Override public HTableInterface createHTableInterface(  Configuration config,  byte[] tableName){
    try {
      return new HTable(config,tableName);
    }
 catch (    IOException ioe) {
      throw new RuntimeException(ioe);
    }
  }
  @Override public void releaseHTableInterface(  HTableInterface table) throws IOException {
    table.close();
  }
}
