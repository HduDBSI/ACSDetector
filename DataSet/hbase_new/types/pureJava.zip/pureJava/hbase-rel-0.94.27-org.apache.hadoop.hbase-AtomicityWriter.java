/** 
 * Thread that does random full-row writes into a table.
 */
public static class AtomicityWriter extends RepeatingTestThread {
  Random rand=new Random();
  byte data[]=new byte[10];
  byte targetRows[][];
  byte targetFamilies[][];
  HTable table;
  AtomicLong numWritten=new AtomicLong();
  public AtomicityWriter(  TestContext ctx,  byte targetRows[][],  byte targetFamilies[][]) throws IOException {
    super(ctx);
    this.targetRows=targetRows;
    this.targetFamilies=targetFamilies;
    table=new HTable(ctx.getConf(),TABLE_NAME);
  }
  public void doAnAction() throws Exception {
    byte[] targetRow=targetRows[rand.nextInt(targetRows.length)];
    Put p=new Put(targetRow);
    rand.nextBytes(data);
    for (    byte[] family : targetFamilies) {
      for (int i=0; i < NUM_COLS_TO_CHECK; i++) {
        byte qualifier[]=Bytes.toBytes("col" + i);
        p.add(family,qualifier,data);
      }
    }
    table.put(p);
    numWritten.getAndIncrement();
  }
}
