class LatchedProcedure extends Procedure {
  CountDownLatch startedAcquireBarrier=new CountDownLatch(1);
  CountDownLatch startedDuringBarrier=new CountDownLatch(1);
  CountDownLatch completedProcedure=new CountDownLatch(1);
  public LatchedProcedure(  ProcedureCoordinator coord,  ForeignExceptionDispatcher monitor,  long wakeFreq,  long timeout,  String opName,  byte[] data,  List<String> expectedMembers){
    super(coord,monitor,wakeFreq,timeout,opName,data,expectedMembers);
  }
  @Override public void sendGlobalBarrierStart(){
    startedAcquireBarrier.countDown();
  }
  @Override public void sendGlobalBarrierReached(){
    startedDuringBarrier.countDown();
  }
  @Override public void sendGlobalBarrierComplete(){
    completedProcedure.countDown();
  }
}
