public static class TestCoprocessor implements RegionCoprocessor, RegionObserver {
  static AtomicInteger PREPUT_INVOCATIONS=new AtomicInteger(0);
  static AtomicInteger PREPUT_BYPASSES=new AtomicInteger(0);
  @Override public Optional<RegionObserver> getRegionObserver(){
    return Optional.of(this);
  }
  @Override public void prePut(  final ObserverContext<RegionCoprocessorEnvironment> e,  final Put put,  final WALEdit edit,  final Durability durability) throws IOException {
    PREPUT_INVOCATIONS.incrementAndGet();
    Map<byte[],List<Cell>> familyMap=put.getFamilyCellMap();
    if (familyMap.containsKey(test)) {
      PREPUT_BYPASSES.incrementAndGet();
      e.bypass();
    }
  }
}
