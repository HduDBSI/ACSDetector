/** 
 * Thrown during flush if the possibility snapshot content was not properly persisted into store files.  Response should include replay of hlog content.
 */
public class DroppedSnapshotException extends IOException {
  public DroppedSnapshotException(  String msg){
    super(msg);
  }
  public DroppedSnapshotException(){
    super();
  }
}
