/** 
 * RegionServerObserver that has a Counter for rollWAL requests.
 */
public static class CustomRegionServerObserver implements RegionServerCoprocessor, RegionServerObserver {
  /** 
 * This is the Counter metric object to keep track of the current count across invocations 
 */
  private Counter rollWALCounter;
  @Override public Optional<RegionServerObserver> getRegionServerObserver(){
    return Optional.of(this);
  }
  @Override public void postRollWALWriterRequest(  ObserverContext<RegionServerCoprocessorEnvironment> ctx) throws IOException {
    rollWALCounter.increment();
  }
  @Override public void start(  CoprocessorEnvironment env) throws IOException {
    if (env instanceof RegionServerCoprocessorEnvironment) {
      MetricRegistry registry=((RegionServerCoprocessorEnvironment)env).getMetricRegistryForRegionServer();
      if (rollWALCounter == null) {
        rollWALCounter=registry.counter("rollWALRequests");
      }
    }
  }
}
