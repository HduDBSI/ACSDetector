/** 
 * A collection of exposed metrics for space quotas from an HBase RegionServer.
 */
@InterfaceAudience.Private public interface MetricsRegionServerQuotaSource extends BaseSource {
  String METRICS_NAME="Quotas";
  String METRICS_CONTEXT="regionserver";
  String METRICS_DESCRIPTION="Metrics about HBase RegionServer Quotas";
  String METRICS_JMX_CONTEXT="RegionServer,sub=" + METRICS_NAME;
  /** 
 * Updates the metric tracking how many tables this RegionServer has marked as in violation of their space quota.
 */
  void updateNumTablesInSpaceQuotaViolation(  long tablesInViolation);
  /** 
 * Updates the metric tracking how many tables this RegionServer has received {@code SpaceQuotaSnapshot}s for.
 * @param numSnapshots The number of {@code SpaceQuotaSnapshot}s received from the Master.
 */
  void updateNumTableSpaceQuotaSnapshots(  long numSnapshots);
  /** 
 * Updates the metric tracking how much time was spent scanning the filesystem to compute the size of each region hosted by this RegionServer.
 * @param time The execution time of the chore in milliseconds.
 */
  void incrementSpaceQuotaFileSystemScannerChoreTime(  long time);
  /** 
 * Updates the metric tracking how much time was spent updating the RegionServer with the latest information on space quotas from the  {@code hbase:quota} table.
 * @param time The execution time of the chore in milliseconds.
 */
  void incrementSpaceQuotaRefresherChoreTime(  long time);
}
