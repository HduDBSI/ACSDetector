/** 
 * Exports the  {@link MasterMetrics} statistics as an MBeanfor JMX.
 */
public class MasterStatistics extends MetricsMBeanBase {
  private final ObjectName mbeanName;
  public MasterStatistics(  MetricsRegistry registry){
    super(registry,"MasterStatistics");
    mbeanName=MBeanUtil.registerMBean("Master","MasterStatistics",this);
  }
  public void shutdown(){
    if (mbeanName != null)     MBeanUtil.unregisterMBean(mbeanName);
  }
}
