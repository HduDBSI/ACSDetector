@InterfaceAudience.Public @InterfaceStability.Evolving public static class Builder {
  private String bName;
  private Map<String,String> bConfiguration=new TreeMap<String,String>();
  private Builder(  NamespaceDescriptor ns){
    this.bName=ns.name;
    this.bConfiguration=ns.configuration;
  }
  private Builder(  String name){
    this.bName=name;
  }
  public Builder addConfiguration(  Map<String,String> configuration){
    this.bConfiguration.putAll(configuration);
    return this;
  }
  public Builder addConfiguration(  String key,  String value){
    this.bConfiguration.put(key,value);
    return this;
  }
  public Builder removeConfiguration(  String key){
    this.bConfiguration.remove(key);
    return this;
  }
  public NamespaceDescriptor build(){
    if (this.bName == null) {
      throw new IllegalArgumentException("A name has to be specified in a namespace.");
    }
    NamespaceDescriptor desc=new NamespaceDescriptor(this.bName);
    desc.configuration=this.bConfiguration;
    return desc;
  }
}
