/** 
 * A job with a map to count rows. Map outputs table rows IF the input row has columns that have content. Uses an  {@link IdentityReducer}
 */
@Deprecated public class RowCounter extends Configured implements Tool {
  static final String NAME="rowcounter";
  /** 
 * Mapper that runs the count.
 */
static class RowCounterMapper implements TableMap<ImmutableBytesWritable,Result> {
    private static enum Counters {    ROWS}
    public void map(    ImmutableBytesWritable row,    Result values,    OutputCollector<ImmutableBytesWritable,Result> output,    Reporter reporter) throws IOException {
      boolean content=false;
      for (      KeyValue value : values.list()) {
        if (value.getValue().length > 0) {
          content=true;
          break;
        }
      }
      if (!content) {
        return;
      }
      reporter.incrCounter(Counters.ROWS,1);
    }
    public void configure(    JobConf jc){
    }
    public void close() throws IOException {
    }
  }
  /** 
 * @param args
 * @return the JobConf
 * @throws IOException
 */
  public JobConf createSubmittableJob(  String[] args) throws IOException {
    JobConf c=new JobConf(getConf(),getClass());
    c.setJobName(NAME);
    StringBuilder sb=new StringBuilder();
    final int columnoffset=2;
    for (int i=columnoffset; i < args.length; i++) {
      if (i > columnoffset) {
        sb.append(" ");
      }
      sb.append(args[i]);
    }
    TableMapReduceUtil.initTableMapJob(args[1],sb.toString(),RowCounterMapper.class,ImmutableBytesWritable.class,Result.class,c);
    c.setNumReduceTasks(0);
    FileOutputFormat.setOutputPath(c,new Path(args[0]));
    return c;
  }
  static int printUsage(){
    System.out.println(NAME + " <outputdir> <tablename> <column1> [<column2>...]");
    return -1;
  }
  public int run(  final String[] args) throws Exception {
    if (args.length < 3) {
      System.err.println("ERROR: Wrong number of parameters: " + args.length);
      return printUsage();
    }
    JobClient.runJob(createSubmittableJob(args));
    return 0;
  }
  /** 
 * @param args
 * @throws Exception
 */
  public static void main(  String[] args) throws Exception {
    int errCode=ToolRunner.run(HBaseConfiguration.create(),new RowCounter(),args);
    System.exit(errCode);
  }
}
