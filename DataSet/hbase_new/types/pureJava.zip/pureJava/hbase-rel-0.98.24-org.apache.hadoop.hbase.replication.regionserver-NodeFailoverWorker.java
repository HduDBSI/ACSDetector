/** 
 * Class responsible to setup new ReplicationSources to take care of the queues from dead region servers.
 */
class NodeFailoverWorker extends Thread {
  private String rsZnode;
  private final ReplicationQueues rq;
  private final ReplicationPeers rp;
  private final UUID clusterId;
  /** 
 * @param rsZnode
 */
  public NodeFailoverWorker(  String rsZnode){
    this(rsZnode,replicationQueues,replicationPeers,ReplicationSourceManager.this.clusterId);
  }
  public NodeFailoverWorker(  String rsZnode,  final ReplicationQueues replicationQueues,  final ReplicationPeers replicationPeers,  final UUID clusterId){
    super("Failover-for-" + rsZnode);
    this.rsZnode=rsZnode;
    this.rq=replicationQueues;
    this.rp=replicationPeers;
    this.clusterId=clusterId;
  }
  @Override public void run(){
    if (this.rq.isThisOurZnode(rsZnode)) {
      return;
    }
    try {
      Thread.sleep(sleepBeforeFailover + (long)(rand.nextFloat() * sleepBeforeFailover));
    }
 catch (    InterruptedException e) {
      LOG.warn("Interrupted while waiting before transferring a queue.");
      Thread.currentThread().interrupt();
    }
    if (server.isStopped()) {
      LOG.info("Not transferring queue since we are shutting down");
      return;
    }
    SortedMap<String,SortedSet<String>> newQueues=null;
    newQueues=this.rq.claimQueues(rsZnode);
    if (newQueues.isEmpty()) {
      return;
    }
    for (    Map.Entry<String,SortedSet<String>> entry : newQueues.entrySet()) {
      String peerId=entry.getKey();
      SortedSet<String> walsSet=entry.getValue();
      try {
        ReplicationQueueInfo replicationQueueInfo=new ReplicationQueueInfo(peerId);
        String actualPeerId=replicationQueueInfo.getPeerId();
        ReplicationPeer peer=replicationPeers.getPeer(actualPeerId);
        ReplicationPeerConfig peerConfig=null;
        try {
          peerConfig=replicationPeers.getReplicationPeerConfig(actualPeerId);
        }
 catch (        ReplicationException ex) {
          LOG.warn("Received exception while getting replication peer config, skipping replay" + ex);
        }
        if (peer == null || peerConfig == null) {
          LOG.warn("Skipping failover for peer:" + actualPeerId + " of node"+ rsZnode);
          replicationQueues.removeQueue(peerId);
          continue;
        }
        ReplicationSourceInterface src=getReplicationSource(conf,fs,ReplicationSourceManager.this,this.rq,this.rp,server,peerId,this.clusterId,peerConfig,peer);
synchronized (oldsources) {
          if (!this.rp.getPeerIds().contains(src.getPeerClusterId())) {
            src.terminate("Recovered queue doesn't belong to any current peer");
            closeRecoveredQueue(src);
            continue;
          }
          oldsources.add(src);
          for (          String wal : walsSet) {
            src.enqueueLog(new Path(oldLogDir,wal));
          }
          src.startup();
        }
        hlogsByIdRecoveredQueues.put(peerId,walsSet);
      }
 catch (      IOException e) {
        LOG.error("Failed creating a source",e);
      }
    }
  }
}
