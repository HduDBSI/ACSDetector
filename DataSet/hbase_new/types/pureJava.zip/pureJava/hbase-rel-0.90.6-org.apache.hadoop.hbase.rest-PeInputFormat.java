/** 
 * InputFormat of Performance Evaluation MapReduce job. It extends from FileInputFormat, want to use it's methods such as setInputPaths(). 
 */
public static class PeInputFormat extends FileInputFormat<NullWritable,PeInputSplit> {
  @Override public List<InputSplit> getSplits(  JobContext job) throws IOException {
    List<InputSplit> splitList=new ArrayList<InputSplit>();
    for (    FileStatus file : listStatus(job)) {
      Path path=file.getPath();
      FileSystem fs=path.getFileSystem(job.getConfiguration());
      FSDataInputStream fileIn=fs.open(path);
      LineReader in=new LineReader(fileIn,job.getConfiguration());
      int lineLen=0;
      while (true) {
        Text lineText=new Text();
        lineLen=in.readLine(lineText);
        if (lineLen <= 0) {
          break;
        }
        Matcher m=LINE_PATTERN.matcher(lineText.toString());
        if ((m != null) && m.matches()) {
          int startRow=Integer.parseInt(m.group(1));
          int rows=Integer.parseInt(m.group(2));
          int totalRows=Integer.parseInt(m.group(3));
          int clients=Integer.parseInt(m.group(4));
          int rowsPerPut=Integer.parseInt(m.group(5));
          LOG.debug("split[" + splitList.size() + "] "+ " startRow="+ startRow+ " rows="+ rows+ " totalRows="+ totalRows+ " clients="+ clients+ " rowsPerPut="+ rowsPerPut);
          PeInputSplit newSplit=new PeInputSplit(startRow,rows,totalRows,clients,rowsPerPut);
          splitList.add(newSplit);
        }
      }
      in.close();
    }
    LOG.info("Total # of splits: " + splitList.size());
    return splitList;
  }
  @Override public RecordReader<NullWritable,PeInputSplit> createRecordReader(  InputSplit split,  TaskAttemptContext context){
    return new PeRecordReader();
  }
public static class PeRecordReader extends RecordReader<NullWritable,PeInputSplit> {
    private boolean readOver=false;
    private PeInputSplit split=null;
    private NullWritable key=null;
    private PeInputSplit value=null;
    @Override public void initialize(    InputSplit split,    TaskAttemptContext context) throws IOException, InterruptedException {
      this.readOver=false;
      this.split=(PeInputSplit)split;
    }
    @Override public boolean nextKeyValue() throws IOException, InterruptedException {
      if (readOver) {
        return false;
      }
      key=NullWritable.get();
      value=(PeInputSplit)split;
      readOver=true;
      return true;
    }
    @Override public NullWritable getCurrentKey() throws IOException, InterruptedException {
      return key;
    }
    @Override public PeInputSplit getCurrentValue() throws IOException, InterruptedException {
      return value;
    }
    @Override public float getProgress() throws IOException, InterruptedException {
      if (readOver) {
        return 1.0f;
      }
 else {
        return 0.0f;
      }
    }
    @Override public void close() throws IOException {
    }
  }
}
