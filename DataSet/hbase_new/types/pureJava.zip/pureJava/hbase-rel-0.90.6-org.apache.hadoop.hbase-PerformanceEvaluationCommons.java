/** 
 * Code shared by PE tests.
 */
public class PerformanceEvaluationCommons {
  static final Log LOG=LogFactory.getLog(PerformanceEvaluationCommons.class.getName());
  public static void assertValueSize(  final int expectedSize,  final int got){
    if (got != expectedSize) {
      throw new AssertionError("Expected " + expectedSize + " but got "+ got);
    }
  }
  public static void assertKey(  final byte[] expected,  final ByteBuffer got){
    byte[] b=new byte[got.limit()];
    got.get(b,0,got.limit());
    assertKey(expected,b);
  }
  public static void assertKey(  final byte[] expected,  final byte[] got){
    if (!org.apache.hadoop.hbase.util.Bytes.equals(expected,got)) {
      throw new AssertionError("Expected " + org.apache.hadoop.hbase.util.Bytes.toString(expected) + " but got "+ org.apache.hadoop.hbase.util.Bytes.toString(got));
    }
  }
  public static void concurrentReads(  final Runnable r){
    final int count=1;
    long now=System.currentTimeMillis();
    List<Thread> threads=new ArrayList<Thread>(count);
    for (int i=0; i < count; i++) {
      Thread t=new Thread(r);
      t.setName("" + i);
      threads.add(t);
    }
    for (    Thread t : threads) {
      t.start();
    }
    for (    Thread t : threads) {
      try {
        t.join();
      }
 catch (      InterruptedException e) {
        e.printStackTrace();
      }
    }
    LOG.info("Test took " + (System.currentTimeMillis() - now));
  }
}
