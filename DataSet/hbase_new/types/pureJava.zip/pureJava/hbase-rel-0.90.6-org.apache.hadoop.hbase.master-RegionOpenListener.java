static class RegionOpenListener implements EventHandlerListener {
  CountDownLatch aboutToOpen, proceed;
  public RegionOpenListener(  CountDownLatch aboutToOpen,  CountDownLatch proceed){
    this.aboutToOpen=aboutToOpen;
    this.proceed=proceed;
  }
  @Override public void afterProcess(  EventHandler event){
    if (event.getEventType() != EventType.RS_ZK_REGION_OPENED) {
      return;
    }
    try {
      aboutToOpen.countDown();
      proceed.await(60,TimeUnit.SECONDS);
    }
 catch (    InterruptedException ie) {
      throw new RuntimeException(ie);
    }
    return;
  }
  @Override public void beforeProcess(  EventHandler event){
  }
}
