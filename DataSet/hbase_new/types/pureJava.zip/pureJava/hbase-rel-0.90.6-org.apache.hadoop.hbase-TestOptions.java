/** 
 * Wraps up options passed to  {@link org.apache.hadoop.hbase.PerformanceEvaluation.Test tests}.  This makes the reflection logic a little easier to understand...
 */
static class TestOptions {
  private int startRow;
  private int perClientRunRows;
  private int totalRows;
  private byte[] tableName;
  private boolean flushCommits;
  private boolean writeToWAL=true;
  TestOptions(){
  }
  TestOptions(  int startRow,  int perClientRunRows,  int totalRows,  byte[] tableName,  boolean flushCommits,  boolean writeToWAL){
    this.startRow=startRow;
    this.perClientRunRows=perClientRunRows;
    this.totalRows=totalRows;
    this.tableName=tableName;
    this.flushCommits=flushCommits;
    this.writeToWAL=writeToWAL;
  }
  public int getStartRow(){
    return startRow;
  }
  public int getPerClientRunRows(){
    return perClientRunRows;
  }
  public int getTotalRows(){
    return totalRows;
  }
  public byte[] getTableName(){
    return tableName;
  }
  public boolean isFlushCommits(){
    return flushCommits;
  }
  public boolean isWriteToWAL(){
    return writeToWAL;
  }
}
