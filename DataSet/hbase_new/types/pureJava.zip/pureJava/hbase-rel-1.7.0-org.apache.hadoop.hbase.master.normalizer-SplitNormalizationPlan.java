/** 
 * Normalization plan to split region.
 */
@InterfaceAudience.Private public class SplitNormalizationPlan implements NormalizationPlan {
  private static final Log LOG=LogFactory.getLog(SplitNormalizationPlan.class.getName());
  private HRegionInfo regionInfo;
  private byte[] splitPoint;
  public SplitNormalizationPlan(  HRegionInfo regionInfo,  byte[] splitPoint){
    this.regionInfo=regionInfo;
    this.splitPoint=splitPoint;
  }
  @Override public PlanType getType(){
    return PlanType.SPLIT;
  }
  public HRegionInfo getRegionInfo(){
    return regionInfo;
  }
  public void setRegionInfo(  HRegionInfo regionInfo){
    this.regionInfo=regionInfo;
  }
  public byte[] getSplitPoint(){
    return splitPoint;
  }
  public void setSplitPoint(  byte[] splitPoint){
    this.splitPoint=splitPoint;
  }
  @Override public String toString(){
    return "SplitNormalizationPlan{" + "regionInfo=" + regionInfo + ", splitPoint="+ Arrays.toString(splitPoint)+ '}';
  }
  /** 
 * {@inheritDoc}
 */
  @Override public void execute(  Admin admin){
    LOG.info("Executing splitting normalization plan: " + this);
    try {
      admin.splitRegion(regionInfo.getRegionName());
    }
 catch (    IOException ex) {
      LOG.error("Error during region split: ",ex);
    }
  }
}
