/** 
 * Compare HRegionInfos in a way that has split parents sort BEFORE their daughters.
 */
static class SplitParentFirstComparator implements Comparator<HRegionInfo> {
  Comparator<byte[]> rowEndKeyComparator=new Bytes.RowEndKeyComparator();
  @Override public int compare(  HRegionInfo left,  HRegionInfo right){
    if (left == null)     return -1;
    if (right == null)     return 1;
    int result=Bytes.compareTo(left.getTableName(),right.getTableName());
    if (result != 0)     return result;
    result=Bytes.compareTo(left.getStartKey(),right.getStartKey());
    if (result != 0)     return result;
    result=rowEndKeyComparator.compare(left.getEndKey(),right.getEndKey());
    return -result;
  }
}
