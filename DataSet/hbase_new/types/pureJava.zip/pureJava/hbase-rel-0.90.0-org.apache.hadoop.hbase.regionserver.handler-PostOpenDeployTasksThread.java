/** 
 * Thread to run region post open tasks.  Call  {@link #getException()} afterthe thread finishes to check for exceptions running {@link RegionServerServices#postOpenDeployTasks(HRegion,org.apache.hadoop.hbase.catalog.CatalogTracker,boolean)}.
 */
static class PostOpenDeployTasksThread extends Thread {
  private Exception exception=null;
  private final Server server;
  private final RegionServerServices services;
  private final HRegion region;
  private final AtomicBoolean signaller;
  PostOpenDeployTasksThread(  final HRegion region,  final Server server,  final RegionServerServices services,  final AtomicBoolean signaller){
    super("PostOpenDeployTasks:" + region.getRegionInfo().getEncodedName());
    this.setDaemon(true);
    this.server=server;
    this.services=services;
    this.region=region;
    this.signaller=signaller;
  }
  public void run(){
    try {
      this.services.postOpenDeployTasks(this.region,this.server.getCatalogTracker(),false);
    }
 catch (    Exception e) {
      LOG.warn("Exception running postOpenDeployTasks; region=" + this.region.getRegionInfo().getEncodedName(),e);
      this.exception=e;
    }
    this.signaller.set(true);
synchronized (this.signaller) {
      this.signaller.notify();
    }
  }
  /** 
 * @return Null or the run exception; call this method after thread is done.
 */
  Exception getException(){
    return this.exception;
  }
}
