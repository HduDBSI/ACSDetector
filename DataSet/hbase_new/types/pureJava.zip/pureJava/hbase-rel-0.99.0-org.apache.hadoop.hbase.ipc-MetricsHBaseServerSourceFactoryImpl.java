@InterfaceAudience.Private public class MetricsHBaseServerSourceFactoryImpl extends MetricsHBaseServerSourceFactory {
  private static enum SourceStorage {  INSTANCE;   HashMap<String,MetricsHBaseServerSource> sources=new HashMap<String,MetricsHBaseServerSource>();
}
  @Override public MetricsHBaseServerSource create(  String serverName,  MetricsHBaseServerWrapper wrapper){
    return getSource(serverName,wrapper);
  }
  private static synchronized MetricsHBaseServerSource getSource(  String serverName,  MetricsHBaseServerWrapper wrapper){
    String context=createContextName(serverName);
    MetricsHBaseServerSource source=SourceStorage.INSTANCE.sources.get(context);
    if (source == null) {
      source=new MetricsHBaseServerSourceImpl(METRICS_NAME,METRICS_DESCRIPTION,context.toLowerCase(),context + METRICS_JMX_CONTEXT_SUFFIX,wrapper);
      SourceStorage.INSTANCE.sources.put(context,source);
    }
    return source;
  }
}
