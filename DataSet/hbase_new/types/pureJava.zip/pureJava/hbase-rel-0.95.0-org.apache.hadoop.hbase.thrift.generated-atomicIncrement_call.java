public static class atomicIncrement_call extends org.apache.thrift.async.TAsyncMethodCall {
  private ByteBuffer tableName;
  private ByteBuffer row;
  private ByteBuffer column;
  private long value;
  public atomicIncrement_call(  ByteBuffer tableName,  ByteBuffer row,  ByteBuffer column,  long value,  org.apache.thrift.async.AsyncMethodCallback<atomicIncrement_call> resultHandler,  org.apache.thrift.async.TAsyncClient client,  org.apache.thrift.protocol.TProtocolFactory protocolFactory,  org.apache.thrift.transport.TNonblockingTransport transport) throws org.apache.thrift.TException {
    super(client,protocolFactory,transport,resultHandler,false);
    this.tableName=tableName;
    this.row=row;
    this.column=column;
    this.value=value;
  }
  public void write_args(  org.apache.thrift.protocol.TProtocol prot) throws org.apache.thrift.TException {
    prot.writeMessageBegin(new org.apache.thrift.protocol.TMessage("atomicIncrement",org.apache.thrift.protocol.TMessageType.CALL,0));
    atomicIncrement_args args=new atomicIncrement_args();
    args.setTableName(tableName);
    args.setRow(row);
    args.setColumn(column);
    args.setValue(value);
    args.write(prot);
    prot.writeMessageEnd();
  }
  public long getResult() throws IOError, IllegalArgument, org.apache.thrift.TException {
    if (getState() != org.apache.thrift.async.TAsyncMethodCall.State.RESPONSE_READ) {
      throw new IllegalStateException("Method call not finished!");
    }
    org.apache.thrift.transport.TMemoryInputTransport memoryTransport=new org.apache.thrift.transport.TMemoryInputTransport(getFrameBuffer().array());
    org.apache.thrift.protocol.TProtocol prot=client.getProtocolFactory().getProtocol(memoryTransport);
    return (new Client(prot)).recv_atomicIncrement();
  }
}
