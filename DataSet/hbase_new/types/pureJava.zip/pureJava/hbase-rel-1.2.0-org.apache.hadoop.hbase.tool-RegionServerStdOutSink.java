public static class RegionServerStdOutSink extends StdOutSink implements ExtendedSink {
  @Override public void publishReadFailure(  String table,  String server){
    LOG.error(String.format("Read from table:%s on region server:%s",table,server));
  }
  @Override public void publishReadTiming(  String table,  String server,  long msTime){
    LOG.info(String.format("Read from table:%s on region server:%s in %dms",table,server,msTime));
  }
}
