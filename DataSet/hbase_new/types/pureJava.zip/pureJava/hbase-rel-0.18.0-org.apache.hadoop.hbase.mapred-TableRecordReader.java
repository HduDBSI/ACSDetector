/** 
 * Iterate over an HBase table data, return (Text, RowResult) pairs
 */
protected class TableRecordReader implements RecordReader<ImmutableBytesWritable,RowResult> {
  private byte[] startRow;
  private byte[] endRow;
  private byte[] lastRow;
  private RowFilterInterface trrRowFilter;
  private Scanner scanner;
  private HTable htable;
  private byte[][] trrInputColumns;
  /** 
 * Restart from survivable exceptions by creating a new scanner.
 * @param firstRow
 * @throws IOException
 */
  public void restart(  byte[] firstRow) throws IOException {
    if ((endRow != null) && (endRow.length > 0)) {
      if (trrRowFilter != null) {
        final Set<RowFilterInterface> rowFiltersSet=new HashSet<RowFilterInterface>();
        rowFiltersSet.add(new StopRowFilter(endRow));
        rowFiltersSet.add(trrRowFilter);
        this.scanner=this.htable.getScanner(trrInputColumns,startRow,new RowFilterSet(RowFilterSet.Operator.MUST_PASS_ALL,rowFiltersSet));
      }
 else {
        this.scanner=this.htable.getScanner(trrInputColumns,firstRow,endRow);
      }
    }
 else {
      this.scanner=this.htable.getScanner(trrInputColumns,firstRow,trrRowFilter);
    }
  }
  /** 
 * Build the scanner. Not done in constructor to allow for extension.
 * @throws IOException
 */
  public void init() throws IOException {
    restart(startRow);
  }
  /** 
 * @param htable the {@link HTable} to scan.
 */
  public void setHTable(  HTable htable){
    this.htable=htable;
  }
  /** 
 * @param inputColumns the columns to be placed in {@link RowResult}.
 */
  public void setInputColumns(  final byte[][] inputColumns){
    this.trrInputColumns=inputColumns;
  }
  /** 
 * @param startRow the first row in the split
 */
  public void setStartRow(  final byte[] startRow){
    this.startRow=startRow;
  }
  /** 
 * @param endRow the last row in the split
 */
  public void setEndRow(  final byte[] endRow){
    this.endRow=endRow;
  }
  /** 
 * @param rowFilter the {@link RowFilterInterface} to be used.
 */
  public void setRowFilter(  RowFilterInterface rowFilter){
    this.trrRowFilter=rowFilter;
  }
  public void close(){
    this.scanner.close();
  }
  /** 
 * @return ImmutableBytesWritable
 * @see org.apache.hadoop.mapred.RecordReader#createKey()
 */
  public ImmutableBytesWritable createKey(){
    return new ImmutableBytesWritable();
  }
  /** 
 * @return RowResult
 * @see org.apache.hadoop.mapred.RecordReader#createValue()
 */
  public RowResult createValue(){
    return new RowResult();
  }
  public long getPos(){
    return 0;
  }
  public float getProgress(){
    return 0;
  }
  /** 
 * @param key HStoreKey as input key.
 * @param value MapWritable as input value
 * @return true if there was more data
 * @throws IOException
 */
  @SuppressWarnings("unchecked") public boolean next(  ImmutableBytesWritable key,  RowResult value) throws IOException {
    RowResult result;
    try {
      result=this.scanner.next();
    }
 catch (    UnknownScannerException e) {
      LOG.debug("recovered from " + StringUtils.stringifyException(e));
      restart(lastRow);
      this.scanner.next();
      result=this.scanner.next();
    }
    boolean hasMore=result != null && result.size() > 0;
    if (hasMore) {
      key.set(result.getRow());
      lastRow=key.get();
      Writables.copyWritable(result,value);
    }
    return hasMore;
  }
}
