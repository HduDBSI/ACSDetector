public static class StdOutSink implements Sink {
  private AtomicLong readFailureCount=new AtomicLong(0), writeFailureCount=new AtomicLong(0);
  private Map<String,String> readFailures=new ConcurrentHashMap<>();
  private Map<String,String> writeFailures=new ConcurrentHashMap<>();
  @Override public long getReadFailureCount(){
    return readFailureCount.get();
  }
  @Override public long incReadFailureCount(){
    return readFailureCount.incrementAndGet();
  }
  @Override public Map<String,String> getReadFailures(){
    return readFailures;
  }
  @Override public void updateReadFailures(  String regionName,  String serverName){
    readFailures.put(regionName,serverName);
  }
  @Override public long getWriteFailureCount(){
    return writeFailureCount.get();
  }
  @Override public long incWriteFailureCount(){
    return writeFailureCount.incrementAndGet();
  }
  @Override public Map<String,String> getWriteFailures(){
    return writeFailures;
  }
  @Override public void updateWriteFailures(  String regionName,  String serverName){
    writeFailures.put(regionName,serverName);
  }
}
