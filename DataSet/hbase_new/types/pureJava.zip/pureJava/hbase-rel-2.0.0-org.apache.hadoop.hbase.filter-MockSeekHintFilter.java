static class MockSeekHintFilter extends FilterBase {
  private Cell returnCell;
  public MockSeekHintFilter(  Cell returnCell){
    this.returnCell=returnCell;
  }
  @Override public ReturnCode filterCell(  final Cell v) throws IOException {
    return ReturnCode.SEEK_NEXT_USING_HINT;
  }
  @Override public Cell getNextCellHint(  Cell currentCell) throws IOException {
    return this.returnCell;
  }
}
