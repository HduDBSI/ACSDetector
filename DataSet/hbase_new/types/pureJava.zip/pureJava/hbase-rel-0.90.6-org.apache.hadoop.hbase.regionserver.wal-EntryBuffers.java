/** 
 * Class which accumulates edits and separates them into a buffer per region while simultaneously accounting RAM usage. Blocks if the RAM usage crosses a predefined threshold. Writer threads then pull region-specific buffers from this class.
 */
class EntryBuffers {
  Map<byte[],RegionEntryBuffer> buffers=new TreeMap<byte[],RegionEntryBuffer>(Bytes.BYTES_COMPARATOR);
  Set<byte[]> currentlyWriting=new TreeSet<byte[]>(Bytes.BYTES_COMPARATOR);
  long totalBuffered=0;
  long maxHeapUsage;
  EntryBuffers(  long maxHeapUsage){
    this.maxHeapUsage=maxHeapUsage;
  }
  /** 
 * Append a log entry into the corresponding region buffer. Blocks if the total heap usage has crossed the specified threshold.
 * @throws InterruptedException
 * @throws IOException 
 */
  void appendEntry(  Entry entry) throws InterruptedException, IOException {
    HLogKey key=entry.getKey();
    RegionEntryBuffer buffer;
    long incrHeap;
synchronized (this) {
      buffer=buffers.get(key.getEncodedRegionName());
      if (buffer == null) {
        buffer=new RegionEntryBuffer(key.getTablename(),key.getEncodedRegionName());
        buffers.put(key.getEncodedRegionName(),buffer);
      }
      incrHeap=buffer.appendEntry(entry);
    }
synchronized (dataAvailable) {
      totalBuffered+=incrHeap;
      while (totalBuffered > maxHeapUsage && thrown.get() == null) {
        LOG.debug("Used " + totalBuffered + " bytes of buffered edits, waiting for IO threads...");
        dataAvailable.wait(3000);
      }
      dataAvailable.notifyAll();
    }
    checkForErrors();
  }
  synchronized RegionEntryBuffer getChunkToWrite(){
    long biggestSize=0;
    byte[] biggestBufferKey=null;
    for (    Map.Entry<byte[],RegionEntryBuffer> entry : buffers.entrySet()) {
      long size=entry.getValue().heapSize();
      if (size > biggestSize && !currentlyWriting.contains(entry.getKey())) {
        biggestSize=size;
        biggestBufferKey=entry.getKey();
      }
    }
    if (biggestBufferKey == null) {
      return null;
    }
    RegionEntryBuffer buffer=buffers.remove(biggestBufferKey);
    currentlyWriting.add(biggestBufferKey);
    return buffer;
  }
  void doneWriting(  RegionEntryBuffer buffer){
synchronized (this) {
      boolean removed=currentlyWriting.remove(buffer.encodedRegionName);
      assert removed;
    }
    long size=buffer.heapSize();
synchronized (dataAvailable) {
      totalBuffered-=size;
      dataAvailable.notifyAll();
    }
  }
  synchronized boolean isRegionCurrentlyWriting(  byte[] region){
    return currentlyWriting.contains(region);
  }
}
