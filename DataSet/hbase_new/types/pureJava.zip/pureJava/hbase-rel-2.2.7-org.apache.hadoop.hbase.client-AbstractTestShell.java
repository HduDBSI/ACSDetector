public abstract class AbstractTestShell {
  protected final static HBaseTestingUtility TEST_UTIL=new HBaseTestingUtility();
  protected final static ScriptingContainer jruby=new ScriptingContainer();
  protected static void setUpConfig() throws IOException {
    Configuration conf=TEST_UTIL.getConfiguration();
    conf.setInt("hbase.regionserver.msginterval",100);
    conf.setInt("hbase.client.pause",250);
    conf.setBoolean("hbase.quota.enabled",true);
    conf.setInt(HConstants.HBASE_CLIENT_RETRIES_NUMBER,6);
    conf.setBoolean(CoprocessorHost.ABORT_ON_ERROR_KEY,false);
    conf.setInt("hfile.format.version",3);
    conf.setInt(HConstants.MASTER_INFO_PORT,0);
    conf.setInt(HConstants.REGIONSERVER_INFO_PORT,0);
    conf.setBoolean(HConstants.REGIONSERVER_INFO_PORT_AUTO,true);
    SecureTestUtil.enableSecurity(conf);
    VisibilityTestUtil.enableVisiblityLabels(conf);
  }
  protected static void setUpJRubyRuntime(){
    List<String> loadPaths=new ArrayList<>(2);
    loadPaths.add("src/main/ruby");
    loadPaths.add("src/test/ruby");
    jruby.setLoadPaths(loadPaths);
    jruby.put("$TEST_CLUSTER",TEST_UTIL);
    System.setProperty("jruby.jit.logging.verbose","true");
    System.setProperty("jruby.jit.logging","true");
    System.setProperty("jruby.native.verbose","true");
  }
  @BeforeClass public static void setUpBeforeClass() throws Exception {
    setUpConfig();
    TEST_UTIL.startMiniCluster(1);
    setUpJRubyRuntime();
  }
  @AfterClass public static void tearDownAfterClass() throws Exception {
    TEST_UTIL.shutdownMiniCluster();
  }
}
