/** 
 * A list of 'host:port' addresses of HTTP servers operating as a single entity, for example multiple redundant web service gateways.
 */
public class Cluster {
  protected List<String> nodes=Collections.synchronizedList(new ArrayList<String>());
  protected String lastHost;
  /** 
 * Constructor
 */
  public Cluster(){
  }
  /** 
 * Constructor
 * @param nodes a list of service locations, in 'host:port' format
 */
  public Cluster(  List<String> nodes){
    nodes.addAll(nodes);
  }
  /** 
 * @return true if no locations have been added, false otherwise
 */
  public boolean isEmpty(){
    return nodes.isEmpty();
  }
  /** 
 * Add a node to the cluster
 * @param node the service location in 'host:port' format
 */
  public Cluster add(  String node){
    nodes.add(node);
    return this;
  }
  /** 
 * Add a node to the cluster
 * @param name host name
 * @param port service port
 */
  public Cluster add(  String name,  int port){
    StringBuilder sb=new StringBuilder();
    sb.append(name);
    sb.append(':');
    sb.append(port);
    return add(sb.toString());
  }
  /** 
 * Remove a node from the cluster
 * @param node the service location in 'host:port' format
 */
  public Cluster remove(  String node){
    nodes.remove(node);
    return this;
  }
  /** 
 * Remove a node from the cluster
 * @param name host name
 * @param port service port
 */
  public Cluster remove(  String name,  int port){
    StringBuilder sb=new StringBuilder();
    sb.append(name);
    sb.append(':');
    sb.append(port);
    return remove(sb.toString());
  }
}
