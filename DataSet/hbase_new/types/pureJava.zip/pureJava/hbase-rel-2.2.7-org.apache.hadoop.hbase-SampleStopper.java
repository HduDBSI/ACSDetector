/** 
 * Straight forward stopper implementation that is used by default when one is not provided
 */
public static class SampleStopper implements Stoppable {
  private boolean stopped=false;
  @Override public void stop(  String why){
    stopped=true;
  }
  @Override public boolean isStopped(){
    return stopped;
  }
}
