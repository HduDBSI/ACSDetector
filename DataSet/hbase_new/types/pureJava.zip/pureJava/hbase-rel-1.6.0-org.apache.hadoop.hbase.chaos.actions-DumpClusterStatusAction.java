/** 
 * Action to dump the cluster status.
 */
public class DumpClusterStatusAction extends Action {
  private static final Logger LOG=LoggerFactory.getLogger(DumpClusterStatusAction.class);
  @Override public void init(  ActionContext context) throws IOException {
    super.init(context);
  }
  @Override public void perform() throws Exception {
    LOG.debug("Performing action: Dump cluster status");
    LOG.info("Cluster status\n" + cluster.getClusterStatus());
  }
}
