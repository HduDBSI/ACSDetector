/** 
 * Normalization plan to merge regions (smallest region in the table with its smallest neighbor).
 */
@InterfaceAudience.Private public class MergeNormalizationPlan implements NormalizationPlan {
  private static final Log LOG=LogFactory.getLog(MergeNormalizationPlan.class.getName());
  private final HRegionInfo firstRegion;
  private final HRegionInfo secondRegion;
  public MergeNormalizationPlan(  HRegionInfo firstRegion,  HRegionInfo secondRegion){
    this.firstRegion=firstRegion;
    this.secondRegion=secondRegion;
  }
  @Override public PlanType getType(){
    return PlanType.MERGE;
  }
  HRegionInfo getFirstRegion(){
    return firstRegion;
  }
  HRegionInfo getSecondRegion(){
    return secondRegion;
  }
  @Override public String toString(){
    return "MergeNormalizationPlan{" + "firstRegion=" + firstRegion + ", secondRegion="+ secondRegion+ '}';
  }
  /** 
 * {@inheritDoc}
 */
  @Override public void execute(  Admin admin){
    LOG.info("Executing merging normalization plan: " + this);
    try {
      admin.mergeRegions(firstRegion.getEncodedNameAsBytes(),secondRegion.getEncodedNameAsBytes(),false);
    }
 catch (    IOException ex) {
      LOG.error("Error during region merge of " + firstRegion.getEncodedName() + " and "+ secondRegion.getEncodedName()+ " : ",ex);
    }
  }
}
