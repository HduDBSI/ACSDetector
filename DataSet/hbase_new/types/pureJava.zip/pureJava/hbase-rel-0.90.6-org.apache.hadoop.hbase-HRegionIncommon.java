/** 
 * A class that makes a  {@link Incommon} out of a {@link HRegion}
 */
public static class HRegionIncommon implements Incommon, FlushCache {
  final HRegion region;
  /** 
 * @param HRegion
 */
  public HRegionIncommon(  final HRegion HRegion){
    this.region=HRegion;
  }
  public void put(  Put put) throws IOException {
    region.put(put);
  }
  public void delete(  Delete delete,  Integer lockid,  boolean writeToWAL) throws IOException {
    this.region.delete(delete,lockid,writeToWAL);
  }
  public Result get(  Get get) throws IOException {
    return region.get(get,null);
  }
  public ScannerIncommon getScanner(  byte[] family,  byte[][] qualifiers,  byte[] firstRow,  long ts) throws IOException {
    Scan scan=new Scan(firstRow);
    if (qualifiers == null || qualifiers.length == 0) {
      scan.addFamily(family);
    }
 else {
      for (int i=0; i < qualifiers.length; i++) {
        scan.addColumn(HConstants.CATALOG_FAMILY,qualifiers[i]);
      }
    }
    scan.setTimeRange(0,ts);
    return new InternalScannerIncommon(region.getScanner(scan));
  }
  public Result get(  Get get,  Integer lockid) throws IOException {
    return this.region.get(get,lockid);
  }
  public void flushcache() throws IOException {
    this.region.flushcache();
  }
}
