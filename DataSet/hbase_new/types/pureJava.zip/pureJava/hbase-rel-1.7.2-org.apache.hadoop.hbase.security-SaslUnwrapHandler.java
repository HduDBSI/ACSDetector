/** 
 * Unwrap sasl messages. Should be placed after a {@link io.netty.handler.codec.LengthFieldBasedFrameDecoder}
 */
@InterfaceAudience.Private public class SaslUnwrapHandler extends SimpleChannelInboundHandler<ByteBuf> {
  private final SaslClient saslClient;
  public SaslUnwrapHandler(  SaslClient saslClient){
    this.saslClient=saslClient;
  }
  @Override public void channelInactive(  ChannelHandlerContext ctx) throws Exception {
    SaslUtil.safeDispose(saslClient);
    ctx.fireChannelInactive();
  }
  @Override protected void channelRead0(  ChannelHandlerContext ctx,  ByteBuf msg) throws Exception {
    byte[] bytes=new byte[msg.readableBytes()];
    msg.readBytes(bytes);
    ctx.fireChannelRead(Unpooled.wrappedBuffer(saslClient.unwrap(bytes,0,bytes.length)));
  }
}
