/** 
 * Pass results that have same row prefix.
 */
@InterfaceAudience.Public @InterfaceStability.Stable public class PrefixFilter extends FilterBase {
  protected byte[] prefix=null;
  protected boolean passedPrefix=false;
  protected boolean filterRow=true;
  public PrefixFilter(  final byte[] prefix){
    this.prefix=prefix;
  }
  public byte[] getPrefix(){
    return prefix;
  }
  public boolean filterRowKey(  byte[] buffer,  int offset,  int length){
    if (buffer == null || this.prefix == null)     return true;
    if (length < prefix.length)     return true;
    int cmp=Bytes.compareTo(buffer,offset,this.prefix.length,this.prefix,0,this.prefix.length);
    if ((!isReversed() && cmp > 0) || (isReversed() && cmp < 0)) {
      passedPrefix=true;
    }
    filterRow=(cmp != 0);
    return filterRow;
  }
  public boolean filterRow(){
    return filterRow;
  }
  public void reset(){
    filterRow=true;
  }
  public boolean filterAllRemaining(){
    return passedPrefix;
  }
  public static Filter createFilterFromArguments(  ArrayList<byte[]> filterArguments){
    Preconditions.checkArgument(filterArguments.size() == 1,"Expected 1 but got: %s",filterArguments.size());
    byte[] prefix=ParseFilter.removeQuotesFromByteArray(filterArguments.get(0));
    return new PrefixFilter(prefix);
  }
  /** 
 * @return The filter serialized using pb
 */
  public byte[] toByteArray(){
    FilterProtos.PrefixFilter.Builder builder=FilterProtos.PrefixFilter.newBuilder();
    if (this.prefix != null)     builder.setPrefix(HBaseZeroCopyByteString.wrap(this.prefix));
    return builder.build().toByteArray();
  }
  /** 
 * @param pbBytes A pb serialized {@link PrefixFilter} instance
 * @return An instance of {@link PrefixFilter} made from <code>bytes</code>
 * @throws org.apache.hadoop.hbase.exceptions.DeserializationException
 * @see #toByteArray
 */
  public static PrefixFilter parseFrom(  final byte[] pbBytes) throws DeserializationException {
    FilterProtos.PrefixFilter proto;
    try {
      proto=FilterProtos.PrefixFilter.parseFrom(pbBytes);
    }
 catch (    InvalidProtocolBufferException e) {
      throw new DeserializationException(e);
    }
    return new PrefixFilter(proto.hasPrefix() ? proto.getPrefix().toByteArray() : null);
  }
  /** 
 * @param other
 * @return true if and only if the fields of the filter that are serializedare equal to the corresponding fields in other.  Used for testing.
 */
  boolean areSerializedFieldsEqual(  Filter o){
    if (o == this)     return true;
    if (!(o instanceof PrefixFilter))     return false;
    PrefixFilter other=(PrefixFilter)o;
    return Bytes.equals(this.getPrefix(),other.getPrefix());
  }
  @Override public String toString(){
    return this.getClass().getSimpleName() + " " + Bytes.toStringBinary(this.prefix);
  }
}
