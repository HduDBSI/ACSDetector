static class WorkItemOverlapMerge implements Callable<Void> {
  private TableIntegrityErrorHandler handler;
  Collection<HbckInfo> overlapgroup;
  WorkItemOverlapMerge(  Collection<HbckInfo> overlapgroup,  TableIntegrityErrorHandler handler){
    this.handler=handler;
    this.overlapgroup=overlapgroup;
  }
  @Override public Void call() throws Exception {
    handler.handleOverlapGroup(overlapgroup);
    return null;
  }
}
