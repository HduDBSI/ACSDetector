/** 
 * Interface which abstracts implementations on log sequenceId assignment
 */
@InterfaceAudience.Private public interface SequenceId {
  /** 
 * Used to represent when a particular wal key doesn't know/care about the sequence ordering.
 */
  long NO_SEQUENCE_ID=-1;
  default long getSequenceId(){
    return NO_SEQUENCE_ID;
  }
}
