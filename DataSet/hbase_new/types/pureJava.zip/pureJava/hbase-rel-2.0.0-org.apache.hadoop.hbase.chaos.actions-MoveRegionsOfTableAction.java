/** 
 * Action that tries to move every region of a table.
 */
public class MoveRegionsOfTableAction extends Action {
  private final long sleepTime;
  private final TableName tableName;
  private final long maxTime;
  public MoveRegionsOfTableAction(  TableName tableName){
    this(-1,MonkeyConstants.DEFAULT_MOVE_REGIONS_MAX_TIME,tableName);
  }
  public MoveRegionsOfTableAction(  long sleepTime,  long maxSleepTime,  TableName tableName){
    this.sleepTime=sleepTime;
    this.tableName=tableName;
    this.maxTime=maxSleepTime;
  }
  @Override public void perform() throws Exception {
    if (sleepTime > 0) {
      Thread.sleep(sleepTime);
    }
    Admin admin=this.context.getHBaseIntegrationTestingUtility().getAdmin();
    ServerName[] servers=getServers(admin);
    LOG.info("Performing action: Move regions of table {}",tableName);
    List<HRegionInfo> regions=admin.getTableRegions(tableName);
    if (regions == null || regions.isEmpty()) {
      LOG.info("Table {} doesn't have regions to move",tableName);
      return;
    }
    Collections.shuffle(regions);
    long start=System.currentTimeMillis();
    for (    HRegionInfo regionInfo : regions) {
      if (context.isStopping()) {
        return;
      }
      moveRegion(admin,servers,regionInfo);
      if (sleepTime > 0) {
        Thread.sleep(sleepTime);
      }
      if (System.currentTimeMillis() - start > maxTime) {
        break;
      }
    }
  }
  static ServerName[] getServers(  Admin admin) throws IOException {
    Collection<ServerName> serversList=admin.getClusterMetrics(EnumSet.of(Option.LIVE_SERVERS)).getLiveServerMetrics().keySet();
    return serversList.toArray(new ServerName[serversList.size()]);
  }
  static void moveRegion(  Admin admin,  ServerName[] servers,  RegionInfo regionInfo){
    try {
      String destServerName=servers[RandomUtils.nextInt(0,servers.length)].getServerName();
      LOG.debug("Moving {} to {}",regionInfo.getRegionNameAsString(),destServerName);
      admin.move(regionInfo.getEncodedNameAsBytes(),Bytes.toBytes(destServerName));
    }
 catch (    Exception ex) {
      LOG.warn("Move failed, might be caused by other chaos: {}",ex.getMessage());
    }
  }
}
