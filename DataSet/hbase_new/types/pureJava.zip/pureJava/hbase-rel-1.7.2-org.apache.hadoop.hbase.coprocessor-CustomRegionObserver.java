/** 
 * RegionObserver that has a Counter for preGet()
 */
public static class CustomRegionObserver extends BaseRegionObserver {
  private Counter preGetCounter;
  @Override public void preGetOp(  ObserverContext<RegionCoprocessorEnvironment> e,  Get get,  List<Cell> results) throws IOException {
    super.preGetOp(e,get,results);
    preGetCounter.increment();
  }
  @Override public void start(  CoprocessorEnvironment env) throws IOException {
    super.start(env);
    if (env instanceof RegionCoprocessorEnvironment) {
      MetricRegistry registry=((RegionCoprocessorEnvironment)env).getMetricRegistryForRegionServer();
      if (preGetCounter == null) {
        preGetCounter=registry.counter("preGetRequests");
      }
    }
  }
}
