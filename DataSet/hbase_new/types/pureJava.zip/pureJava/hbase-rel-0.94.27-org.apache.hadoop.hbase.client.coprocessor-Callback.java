/** 
 * Defines a generic callback to be triggered for each  {@link Batch.Call#call(Object)}result. <p> When used with {@link org.apache.hadoop.hbase.client.HTable#coprocessorExec(Class,byte[],byte[],org.apache.hadoop.hbase.client.coprocessor.Batch.Call,org.apache.hadoop.hbase.client.coprocessor.Batch.Callback)}, the implementation's  {@link Batch.Callback#update(byte[],byte[],Object)}method will be called with the  {@link Batch.Call#call(Object)} return valuefrom each region in the selected range. </p>
 * @param < R > the return type from the associated {@link Batch.Call#call(Object)}
 * @see org.apache.hadoop.hbase.client.HTable#coprocessorExec(Class,byte[],byte[],org.apache.hadoop.hbase.client.coprocessor.Batch.Call,org.apache.hadoop.hbase.client.coprocessor.Batch.Callback)
 */
public static interface Callback<R> {
  public void update(  byte[] region,  byte[] row,  R result);
}
