static class DummyConfigurationObserver implements ConfigurationObserver {
  private boolean notifiedOnChange=false;
  private final ConfigurationManager cm;
  public DummyConfigurationObserver(  ConfigurationManager cm){
    this.cm=cm;
    register();
  }
  @Override public void onConfigurationChange(  Configuration conf){
    notifiedOnChange=true;
  }
  public boolean wasNotifiedOnChange(){
    return notifiedOnChange;
  }
  public void resetNotifiedOnChange(){
    notifiedOnChange=false;
  }
  public void register(){
    cm.registerObserver(this);
  }
  public void deregister(){
    cm.deregisterObserver(this);
  }
}
