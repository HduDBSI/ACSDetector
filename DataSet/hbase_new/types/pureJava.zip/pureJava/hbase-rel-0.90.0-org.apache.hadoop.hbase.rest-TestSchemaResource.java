public class TestSchemaResource {
  private static String TABLE1="TestSchemaResource1";
  private static String TABLE2="TestSchemaResource2";
  private static final HBaseTestingUtility TEST_UTIL=new HBaseTestingUtility();
  private static final HBaseRESTTestingUtility REST_TEST_UTIL=new HBaseRESTTestingUtility();
  private static Client client;
  private static JAXBContext context;
  private static Configuration conf;
  @BeforeClass public static void setUpBeforeClass() throws Exception {
    conf=TEST_UTIL.getConfiguration();
    TEST_UTIL.startMiniCluster(3);
    REST_TEST_UTIL.startServletContainer(conf);
    client=new Client(new Cluster().add("localhost",REST_TEST_UTIL.getServletPort()));
    context=JAXBContext.newInstance(ColumnSchemaModel.class,TableSchemaModel.class);
  }
  @AfterClass public static void tearDownAfterClass() throws Exception {
    REST_TEST_UTIL.shutdownServletContainer();
    TEST_UTIL.shutdownMiniCluster();
  }
  private static byte[] toXML(  TableSchemaModel model) throws JAXBException {
    StringWriter writer=new StringWriter();
    context.createMarshaller().marshal(model,writer);
    return Bytes.toBytes(writer.toString());
  }
  private static TableSchemaModel fromXML(  byte[] content) throws JAXBException {
    return (TableSchemaModel)context.createUnmarshaller().unmarshal(new ByteArrayInputStream(content));
  }
  @Test public void testTableCreateAndDeleteXML() throws IOException, JAXBException {
    String schemaPath="/" + TABLE1 + "/schema";
    TableSchemaModel model;
    Response response;
    HBaseAdmin admin=TEST_UTIL.getHBaseAdmin();
    assertFalse(admin.tableExists(TABLE1));
    model=TestTableSchemaModel.buildTestModel(TABLE1);
    TestTableSchemaModel.checkModel(model,TABLE1);
    response=client.put(schemaPath,Constants.MIMETYPE_XML,toXML(model));
    assertEquals(response.getCode(),201);
    conf.set("hbase.rest.readonly","true");
    response=client.put(schemaPath,Constants.MIMETYPE_XML,toXML(model));
    assertEquals(response.getCode(),403);
    admin.enableTable(TABLE1);
    response=client.get(schemaPath,Constants.MIMETYPE_XML);
    assertEquals(response.getCode(),200);
    model=fromXML(response.getBody());
    TestTableSchemaModel.checkModel(model,TABLE1);
    client.delete(schemaPath);
    assertFalse(admin.tableExists(TABLE1));
    conf.set("hbase.rest.readonly","false");
  }
  @Test public void testTableCreateAndDeletePB() throws IOException, JAXBException {
    String schemaPath="/" + TABLE2 + "/schema";
    TableSchemaModel model;
    Response response;
    HBaseAdmin admin=TEST_UTIL.getHBaseAdmin();
    assertFalse(admin.tableExists(TABLE2));
    model=TestTableSchemaModel.buildTestModel(TABLE2);
    TestTableSchemaModel.checkModel(model,TABLE2);
    response=client.put(schemaPath,Constants.MIMETYPE_PROTOBUF,model.createProtobufOutput());
    assertEquals(response.getCode(),201);
    conf.set("hbase.rest.readonly","true");
    response=client.put(schemaPath,Constants.MIMETYPE_PROTOBUF,model.createProtobufOutput());
    assertEquals(response.getCode(),403);
    admin.enableTable(TABLE2);
    response=client.get(schemaPath,Constants.MIMETYPE_PROTOBUF);
    assertEquals(response.getCode(),200);
    model=new TableSchemaModel();
    model.getObjectFromMessage(response.getBody());
    TestTableSchemaModel.checkModel(model,TABLE2);
    client.delete(schemaPath);
    assertFalse(admin.tableExists(TABLE2));
    conf.set("hbase.rest.readonly","false");
  }
}
