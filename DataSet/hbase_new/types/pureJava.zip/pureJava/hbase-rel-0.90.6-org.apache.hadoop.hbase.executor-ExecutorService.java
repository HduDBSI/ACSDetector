/** 
 * This is a generic executor service. This component abstracts a threadpool, a queue to which  {@link EventHandler.EventType}s can be submitted, and a <code>Runnable</code> that handles the object that is added to the queue. <p>In order to create a new service, create an instance of this class and then do: <code>instance.startExecutorService("myService");</code>.  When done call  {@link #shutdown()}. <p>In order to use the service created above, call {@link #submit(EventHandler)}. Register pre- and post- processing listeners by registering your implementation of  {@link EventHandler.EventHandlerListener}with  {@link #registerListener(EventHandler.EventType,EventHandler.EventHandlerListener)}.  Be sure to deregister your listener when done via  {@link #unregisterListener(EventHandler.EventType)}.
 */
public class ExecutorService {
  private static final Log LOG=LogFactory.getLog(ExecutorService.class);
  private final ConcurrentHashMap<String,Executor> executorMap=new ConcurrentHashMap<String,Executor>();
  private ConcurrentHashMap<EventHandler.EventType,EventHandlerListener> eventHandlerListeners=new ConcurrentHashMap<EventHandler.EventType,EventHandlerListener>();
  private final String servername;
  /** 
 * The following is a list of all executor types, both those that run in the master and those that run in the regionserver.
 */
  public enum ExecutorType {  MASTER_CLOSE_REGION(1),   MASTER_OPEN_REGION(2),   MASTER_SERVER_OPERATIONS(3),   MASTER_TABLE_OPERATIONS(4),   MASTER_RS_SHUTDOWN(5),   MASTER_META_SERVER_OPERATIONS(6),   RS_OPEN_REGION(20),   RS_OPEN_ROOT(21),   RS_OPEN_META(22),   RS_CLOSE_REGION(23),   RS_CLOSE_ROOT(24),   RS_CLOSE_META(25);   ExecutorType(  int value){
  }
  /** 
 * @param serverName
 * @return Conflation of the executor type and the passed servername.
 */
  String getExecutorName(  String serverName){
    return this.toString() + "-" + serverName;
  }
}
  /** 
 * Returns the executor service type (the thread pool instance) for the passed event handler type.
 * @param type EventHandler type.
 */
  public ExecutorType getExecutorServiceType(  final EventHandler.EventType type){
switch (type) {
case RS_ZK_REGION_CLOSED:
case RS_ZK_REGION_FAILED_OPEN:
      return ExecutorType.MASTER_CLOSE_REGION;
case RS_ZK_REGION_OPENED:
    return ExecutorType.MASTER_OPEN_REGION;
case M_SERVER_SHUTDOWN:
  return ExecutorType.MASTER_SERVER_OPERATIONS;
case M_META_SERVER_SHUTDOWN:
return ExecutorType.MASTER_META_SERVER_OPERATIONS;
case C_M_DELETE_TABLE:
case C_M_DISABLE_TABLE:
case C_M_ENABLE_TABLE:
case C_M_MODIFY_TABLE:
return ExecutorType.MASTER_TABLE_OPERATIONS;
case M_RS_OPEN_REGION:
return ExecutorType.RS_OPEN_REGION;
case M_RS_OPEN_ROOT:
return ExecutorType.RS_OPEN_ROOT;
case M_RS_OPEN_META:
return ExecutorType.RS_OPEN_META;
case M_RS_CLOSE_REGION:
return ExecutorType.RS_CLOSE_REGION;
case M_RS_CLOSE_ROOT:
return ExecutorType.RS_CLOSE_ROOT;
case M_RS_CLOSE_META:
return ExecutorType.RS_CLOSE_META;
default :
throw new RuntimeException("Unhandled event type " + type);
}
}
/** 
 * Default constructor.
 * @param servername Name of the hosting server.
 */
public ExecutorService(final String servername){
super();
this.servername=servername;
}
/** 
 * Start an executor service with a given name. If there was a service already started with the same name, this throws a RuntimeException.
 * @param name Name of the service to start.
 */
void startExecutorService(String name,int maxThreads){
if (this.executorMap.get(name) != null) {
throw new RuntimeException("An executor service with the name " + name + " is already running!");
}
Executor hbes=new Executor(name,maxThreads,this.eventHandlerListeners);
if (this.executorMap.putIfAbsent(name,hbes) != null) {
throw new RuntimeException("An executor service with the name " + name + " is already running (2)!");
}
LOG.debug("Starting executor service name=" + name + ", corePoolSize="+ hbes.threadPoolExecutor.getCorePoolSize()+ ", maxPoolSize="+ hbes.threadPoolExecutor.getMaximumPoolSize());
}
boolean isExecutorServiceRunning(String name){
return this.executorMap.containsKey(name);
}
public void shutdown(){
for (Entry<String,Executor> entry : this.executorMap.entrySet()) {
List<Runnable> wasRunning=entry.getValue().threadPoolExecutor.shutdownNow();
if (!wasRunning.isEmpty()) {
LOG.info(entry.getKey() + " had " + wasRunning+ " on shutdown");
}
}
this.executorMap.clear();
}
Executor getExecutor(final ExecutorType type){
return getExecutor(type.getExecutorName(this.servername));
}
Executor getExecutor(String name){
Executor executor=this.executorMap.get(name);
return executor;
}
public void startExecutorService(final ExecutorType type,final int maxThreads){
String name=type.getExecutorName(this.servername);
if (isExecutorServiceRunning(name)) {
LOG.debug("Executor service " + toString() + " already running on "+ this.servername);
return;
}
startExecutorService(name,maxThreads);
}
public void submit(final EventHandler eh){
Executor executor=getExecutor(getExecutorServiceType(eh.getEventType()));
if (executor == null) {
LOG.error("Cannot submit [" + eh + "] because the executor is missing."+ " Is this process shutting down?");
}
 else {
executor.submit(eh);
}
}
/** 
 * Subscribe to updates before and after processing instances of {@link EventHandler.EventType}.  Currently only one listener per event type.
 * @param type Type of event we're registering listener for
 * @param listener The listener to run.
 */
public void registerListener(final EventHandler.EventType type,final EventHandlerListener listener){
this.eventHandlerListeners.put(type,listener);
}
/** 
 * Stop receiving updates before and after processing instances of {@link EventHandler.EventType}
 * @param type Type of event we're registering listener for
 * @return The listener we removed or null if we did not remove it.
 */
public EventHandlerListener unregisterListener(final EventHandler.EventType type){
return this.eventHandlerListeners.remove(type);
}
/** 
 * Executor instance.
 */
static class Executor {
final long keepAliveTimeInMillis=1000;
final ThreadPoolExecutor threadPoolExecutor;
final BlockingQueue<Runnable> q=new LinkedBlockingQueue<Runnable>();
private final String name;
private final Map<EventHandler.EventType,EventHandlerListener> eventHandlerListeners;
protected Executor(String name,int maxThreads,final Map<EventHandler.EventType,EventHandlerListener> eventHandlerListeners){
this.name=name;
this.eventHandlerListeners=eventHandlerListeners;
this.threadPoolExecutor=new ThreadPoolExecutor(maxThreads,maxThreads,keepAliveTimeInMillis,TimeUnit.MILLISECONDS,q);
ThreadFactoryBuilder tfb=new ThreadFactoryBuilder();
tfb.setNameFormat(this.name + "-%d");
this.threadPoolExecutor.setThreadFactory(tfb.build());
}
/** 
 * Submit the event to the queue for handling.
 * @param event
 */
void submit(final EventHandler event){
EventHandlerListener listener=this.eventHandlerListeners.get(event.getEventType());
if (listener != null) {
event.setListener(listener);
}
this.threadPoolExecutor.execute(event);
}
}
}
