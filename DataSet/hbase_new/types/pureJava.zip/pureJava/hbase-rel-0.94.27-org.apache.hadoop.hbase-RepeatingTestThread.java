/** 
 * A test thread that performs a repeating operation.
 */
public static abstract class RepeatingTestThread extends TestThread {
  public RepeatingTestThread(  TestContext ctx){
    super(ctx);
  }
  public final void doWork() throws Exception {
    while (ctx.shouldRun() && !stopped) {
      doAnAction();
    }
  }
  public abstract void doAnAction() throws Exception ;
}
