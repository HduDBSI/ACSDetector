/** 
 * This class works as the InputSplit of Performance Evaluation MapReduce InputFormat, and the Record Value of RecordReader.  Each map task will only read one record from a PeInputSplit,  the record value is the PeInputSplit itself.
 */
public static class PeInputSplit extends InputSplit implements Writable {
  private int startRow=0;
  private int rows=0;
  private int totalRows=0;
  private int clients=0;
  private int rowsPerPut=1;
  public PeInputSplit(){
    this.startRow=0;
    this.rows=0;
    this.totalRows=0;
    this.clients=0;
    this.rowsPerPut=1;
  }
  public PeInputSplit(  int startRow,  int rows,  int totalRows,  int clients,  int rowsPerPut){
    this.startRow=startRow;
    this.rows=rows;
    this.totalRows=totalRows;
    this.clients=clients;
    this.rowsPerPut=1;
  }
  @Override public void readFields(  DataInput in) throws IOException {
    this.startRow=in.readInt();
    this.rows=in.readInt();
    this.totalRows=in.readInt();
    this.clients=in.readInt();
    this.rowsPerPut=in.readInt();
  }
  @Override public void write(  DataOutput out) throws IOException {
    out.writeInt(startRow);
    out.writeInt(rows);
    out.writeInt(totalRows);
    out.writeInt(clients);
    out.writeInt(rowsPerPut);
  }
  @Override public long getLength() throws IOException, InterruptedException {
    return 0;
  }
  @Override public String[] getLocations() throws IOException, InterruptedException {
    return new String[0];
  }
  public int getStartRow(){
    return startRow;
  }
  public int getRows(){
    return rows;
  }
  public int getTotalRows(){
    return totalRows;
  }
  public int getClients(){
    return clients;
  }
  public int getRowsPerPut(){
    return rowsPerPut;
  }
}
