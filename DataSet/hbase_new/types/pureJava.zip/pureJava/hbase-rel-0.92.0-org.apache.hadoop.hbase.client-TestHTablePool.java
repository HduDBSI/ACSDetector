/** 
 * Tests HTablePool.
 */
@RunWith(Suite.class) @Suite.SuiteClasses({TestHTablePool.TestHTableReusablePool.class,TestHTablePool.TestHTableThreadLocalPool.class}) public class TestHTablePool {
  private static HBaseTestingUtility TEST_UTIL=new HBaseTestingUtility();
  private final static byte[] TABLENAME=Bytes.toBytes("TestHTablePool");
  @BeforeClass public static void setUpBeforeClass() throws Exception {
    TEST_UTIL.startMiniCluster(1);
    TEST_UTIL.createTable(TABLENAME,HConstants.CATALOG_FAMILY);
  }
  @AfterClass public static void tearDownAfterClass() throws Exception {
    TEST_UTIL.shutdownMiniCluster();
  }
public abstract static class TestHTablePoolType extends TestCase {
    protected abstract PoolType getPoolType();
    @Test public void testTableWithStringName() throws Exception {
      HTablePool pool=new HTablePool(TEST_UTIL.getConfiguration(),Integer.MAX_VALUE,getPoolType());
      String tableName=Bytes.toString(TABLENAME);
      HTableInterface table=pool.getTable(tableName);
      Assert.assertNotNull(table);
      table.close();
      HTableInterface sameTable=pool.getTable(tableName);
      Assert.assertSame(((HTablePool.PooledHTable)table).getWrappedTable(),((HTablePool.PooledHTable)sameTable).getWrappedTable());
    }
    @Test public void testTableWithByteArrayName() throws IOException {
      HTablePool pool=new HTablePool(TEST_UTIL.getConfiguration(),Integer.MAX_VALUE,getPoolType());
      HTableInterface table=pool.getTable(TABLENAME);
      Assert.assertNotNull(table);
      table.close();
      HTableInterface sameTable=pool.getTable(TABLENAME);
      Assert.assertSame(((HTablePool.PooledHTable)table).getWrappedTable(),((HTablePool.PooledHTable)sameTable).getWrappedTable());
    }
    @Test public void testTablesWithDifferentNames() throws IOException {
      HTablePool pool=new HTablePool(TEST_UTIL.getConfiguration(),Integer.MAX_VALUE,getPoolType());
      byte[] otherTable=Bytes.toBytes("OtherTable_" + getClass().getSimpleName());
      TEST_UTIL.createTable(otherTable,HConstants.CATALOG_FAMILY);
      HTableInterface table1=pool.getTable(TABLENAME);
      HTableInterface table2=pool.getTable(otherTable);
      Assert.assertNotNull(table2);
      table1.close();
      table2.close();
      HTableInterface sameTable1=pool.getTable(TABLENAME);
      HTableInterface sameTable2=pool.getTable(otherTable);
      Assert.assertSame(((HTablePool.PooledHTable)table1).getWrappedTable(),((HTablePool.PooledHTable)sameTable1).getWrappedTable());
      Assert.assertSame(((HTablePool.PooledHTable)table2).getWrappedTable(),((HTablePool.PooledHTable)sameTable2).getWrappedTable());
    }
    @Test public void testProxyImplementationReturned(){
      HTablePool pool=new HTablePool(TEST_UTIL.getConfiguration(),Integer.MAX_VALUE);
      String tableName=Bytes.toString(TABLENAME);
      HTableInterface table=pool.getTable(tableName);
      Assert.assertTrue(table instanceof HTablePool.PooledHTable);
    }
    @Test public void testDeprecatedUsagePattern() throws IOException {
      HTablePool pool=new HTablePool(TEST_UTIL.getConfiguration(),Integer.MAX_VALUE);
      String tableName=Bytes.toString(TABLENAME);
      HTableInterface table=pool.getTable(tableName);
      pool.putTable(table);
      HTableInterface sameTable=pool.getTable(tableName);
      Assert.assertSame(((HTablePool.PooledHTable)table).getWrappedTable(),((HTablePool.PooledHTable)sameTable).getWrappedTable());
    }
    @Test public void testReturnDifferentTable() throws IOException {
      HTablePool pool=new HTablePool(TEST_UTIL.getConfiguration(),Integer.MAX_VALUE);
      String tableName=Bytes.toString(TABLENAME);
      final HTableInterface table=pool.getTable(tableName);
      HTableInterface alienTable=new HTable(TEST_UTIL.getConfiguration(),TABLENAME){
      }
;
      try {
        pool.putTable(alienTable);
        Assert.fail("alien table accepted in pool");
      }
 catch (      IllegalArgumentException e) {
        Assert.assertTrue("alien table rejected",true);
      }
    }
    @Test public void testClassCastException(){
      HTablePool pool=new HTablePool(TEST_UTIL.getConfiguration(),Integer.MAX_VALUE);
      String tableName=Bytes.toString(TABLENAME);
      try {
        HTable table=(HTable)pool.getTable(tableName);
        Assert.assertTrue("return type is HTable as expected",true);
      }
 catch (      ClassCastException e) {
        Assert.fail("return type is not HTable");
      }
    }
  }
public static class TestHTableReusablePool extends TestHTablePoolType {
    @Override protected PoolType getPoolType(){
      return PoolType.Reusable;
    }
    @Test public void testTableWithMaxSize() throws Exception {
      HTablePool pool=new HTablePool(TEST_UTIL.getConfiguration(),2,getPoolType());
      HTableInterface table1=pool.getTable(TABLENAME);
      HTableInterface table2=pool.getTable(TABLENAME);
      HTableInterface table3=pool.getTable(TABLENAME);
      table1.close();
      table2.close();
      table3.close();
      HTableInterface sameTable1=pool.getTable(TABLENAME);
      HTableInterface sameTable2=pool.getTable(TABLENAME);
      HTableInterface sameTable3=pool.getTable(TABLENAME);
      Assert.assertSame(((HTablePool.PooledHTable)table1).getWrappedTable(),((HTablePool.PooledHTable)sameTable1).getWrappedTable());
      Assert.assertSame(((HTablePool.PooledHTable)table2).getWrappedTable(),((HTablePool.PooledHTable)sameTable2).getWrappedTable());
      Assert.assertNotSame(((HTablePool.PooledHTable)table3).getWrappedTable(),((HTablePool.PooledHTable)sameTable3).getWrappedTable());
    }
    @Test public void testCloseTablePool() throws IOException {
      HTablePool pool=new HTablePool(TEST_UTIL.getConfiguration(),4,getPoolType());
      HBaseAdmin admin=new HBaseAdmin(TEST_UTIL.getConfiguration());
      if (admin.tableExists(TABLENAME)) {
        admin.disableTable(TABLENAME);
        admin.deleteTable(TABLENAME);
      }
      HTableDescriptor tableDescriptor=new HTableDescriptor(TABLENAME);
      tableDescriptor.addFamily(new HColumnDescriptor("randomFamily"));
      admin.createTable(tableDescriptor);
      HTableInterface[] tables=new HTableInterface[4];
      for (int i=0; i < 4; ++i) {
        tables[i]=pool.getTable(TABLENAME);
      }
      pool.closeTablePool(TABLENAME);
      for (int i=0; i < 4; ++i) {
        tables[i].close();
      }
      Assert.assertEquals(4,pool.getCurrentPoolSize(Bytes.toString(TABLENAME)));
      pool.closeTablePool(TABLENAME);
      Assert.assertEquals(0,pool.getCurrentPoolSize(Bytes.toString(TABLENAME)));
    }
  }
public static class TestHTableThreadLocalPool extends TestHTablePoolType {
    @Override protected PoolType getPoolType(){
      return PoolType.ThreadLocal;
    }
    @Test public void testTableWithMaxSize() throws Exception {
      HTablePool pool=new HTablePool(TEST_UTIL.getConfiguration(),2,getPoolType());
      HTableInterface table1=pool.getTable(TABLENAME);
      HTableInterface table2=pool.getTable(TABLENAME);
      HTableInterface table3=pool.getTable(TABLENAME);
      table1.close();
      table2.close();
      table3.close();
      HTableInterface sameTable1=pool.getTable(TABLENAME);
      HTableInterface sameTable2=pool.getTable(TABLENAME);
      HTableInterface sameTable3=pool.getTable(TABLENAME);
      Assert.assertSame(((HTablePool.PooledHTable)table3).getWrappedTable(),((HTablePool.PooledHTable)sameTable1).getWrappedTable());
      Assert.assertSame(((HTablePool.PooledHTable)table3).getWrappedTable(),((HTablePool.PooledHTable)sameTable2).getWrappedTable());
      Assert.assertSame(((HTablePool.PooledHTable)table3).getWrappedTable(),((HTablePool.PooledHTable)sameTable3).getWrappedTable());
    }
    @Test public void testCloseTablePool() throws IOException {
      HTablePool pool=new HTablePool(TEST_UTIL.getConfiguration(),4,getPoolType());
      HBaseAdmin admin=new HBaseAdmin(TEST_UTIL.getConfiguration());
      if (admin.tableExists(TABLENAME)) {
        admin.disableTable(TABLENAME);
        admin.deleteTable(TABLENAME);
      }
      HTableDescriptor tableDescriptor=new HTableDescriptor(TABLENAME);
      tableDescriptor.addFamily(new HColumnDescriptor("randomFamily"));
      admin.createTable(tableDescriptor);
      HTableInterface[] tables=new HTableInterface[4];
      for (int i=0; i < 4; ++i) {
        tables[i]=pool.getTable(TABLENAME);
      }
      pool.closeTablePool(TABLENAME);
      for (int i=0; i < 4; ++i) {
        tables[i].close();
      }
      Assert.assertEquals(1,pool.getCurrentPoolSize(Bytes.toString(TABLENAME)));
      pool.closeTablePool(TABLENAME);
      Assert.assertEquals(0,pool.getCurrentPoolSize(Bytes.toString(TABLENAME)));
    }
  }
}
