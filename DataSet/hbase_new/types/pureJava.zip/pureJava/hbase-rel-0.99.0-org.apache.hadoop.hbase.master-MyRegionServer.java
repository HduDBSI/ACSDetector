public static class MyRegionServer extends MiniHBaseClusterRegionServer {
  static volatile ServerName abortedServer=null;
  static volatile boolean simulateRetry=false;
  public MyRegionServer(  Configuration conf,  CoordinatedStateManager cp) throws IOException, KeeperException, InterruptedException {
    super(conf,cp);
  }
  @Override public boolean reportRegionStateTransition(  TransitionCode code,  long openSeqNum,  HRegionInfo... hris){
    if (simulateRetry) {
      super.reportRegionStateTransition(code,openSeqNum,hris);
      return super.reportRegionStateTransition(code,openSeqNum,hris);
    }
    return super.reportRegionStateTransition(code,openSeqNum,hris);
  }
  @Override public boolean isAborted(){
    return getServerName().equals(abortedServer) || super.isAborted();
  }
}
