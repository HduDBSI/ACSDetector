public interface ErrorReporter {
  public static enum ERROR_CODE {  UNKNOWN,   NO_META_REGION,   NULL_ROOT_REGION,   NO_VERSION_FILE,   NOT_IN_META_HDFS,   NOT_IN_META,   NOT_IN_META_OR_DEPLOYED,   NOT_IN_HDFS_OR_DEPLOYED,   NOT_IN_HDFS,   SERVER_DOES_NOT_MATCH_META,   NOT_DEPLOYED,   MULTI_DEPLOYED,   SHOULD_NOT_BE_DEPLOYED,   MULTI_META_REGION,   RS_CONNECT_FAILURE,   FIRST_REGION_STARTKEY_NOT_EMPTY,   DUPE_STARTKEYS,   HOLE_IN_REGION_CHAIN,   OVERLAP_IN_REGION_CHAIN,   REGION_CYCLE,   DEGENERATE_REGION}
  public void clear();
  public void report(  String message);
  public void reportError(  String message);
  public void reportError(  ERROR_CODE errorCode,  String message);
  public void reportError(  ERROR_CODE errorCode,  String message,  TInfo table,  HbckInfo info);
  public void reportError(  ERROR_CODE errorCode,  String message,  TInfo table,  HbckInfo info1,  HbckInfo info2);
  public int summarize();
  public void detail(  String details);
  public ArrayList<ERROR_CODE> getErrorList();
  public void progress();
  public void print(  String message);
  public void resetErrors();
  public boolean tableHasErrors(  TInfo table);
}
