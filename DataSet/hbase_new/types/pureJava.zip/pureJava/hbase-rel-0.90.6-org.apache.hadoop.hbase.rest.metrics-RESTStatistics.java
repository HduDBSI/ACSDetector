public class RESTStatistics extends MetricsMBeanBase {
  private final ObjectName mbeanName;
  public RESTStatistics(  MetricsRegistry registry){
    super(registry,"restStatistics");
    mbeanName=MBeanUtil.registerMBean("rest","restStatistics",this);
  }
  public void shutdown(){
    if (mbeanName != null) {
      MBeanUtil.unregisterMBean(mbeanName);
    }
  }
}
