/** 
 * Adds HBase configuration files to a Configuration
 */
public class HBaseConfiguration extends Configuration {
  private static final Log LOG=LogFactory.getLog(HBaseConfiguration.class);
  /** 
 * Instantinating HBaseConfiguration() is deprecated. Please use HBaseConfiguration#create() to construct a plain Configuration
 */
  @Deprecated public HBaseConfiguration(){
    super();
    addHbaseResources(this);
    LOG.warn("instantiating HBaseConfiguration() is deprecated. Please use" + " HBaseConfiguration#create() to construct a plain Configuration");
  }
  /** 
 * Instantiating HBaseConfiguration() is deprecated. Please use HBaseConfiguration#create(conf) to construct a plain Configuration
 */
  @Deprecated public HBaseConfiguration(  final Configuration c){
    this();
    for (    Entry<String,String> e : c) {
      set(e.getKey(),e.getValue());
    }
  }
  private static void checkDefaultsVersion(  Configuration conf){
    String defaultsVersion=conf.get("hbase.defaults.for.version");
    String thisVersion=VersionInfo.getVersion();
    if (!thisVersion.equals(defaultsVersion)) {
      throw new RuntimeException("hbase-default.xml file seems to be for and old version of HBase (" + defaultsVersion + "), this version is "+ thisVersion);
    }
  }
  private static void checkForClusterFreeMemoryLimit(  Configuration conf){
    float globalMemstoreLimit=conf.getFloat("hbase.regionserver.global.memstore.upperLimit",0.4f);
    float blockCacheUpperLimit=conf.getFloat("hfile.block.cache.size",0.2f);
    if (1.0f - (globalMemstoreLimit + blockCacheUpperLimit) < HConstants.HBASE_CLUSTER_MINIMUM_MEMORY_THRESHOLD) {
      throw new RuntimeException("Current heap configuration for MemStore and BlockCache exceeds the threshold required for " + "successful cluster operation. The combined value cannot exceed 0.8. Please check " + "the settings for hbase.regionserver.global.memstore.upperLimit and"+ " hfile.block.cache.size in your configuration.");
    }
  }
  public static Configuration addHbaseResources(  Configuration conf){
    conf.addResource("hbase-default.xml");
    conf.addResource("hbase-site.xml");
    checkDefaultsVersion(conf);
    checkForClusterFreeMemoryLimit(conf);
    return conf;
  }
  /** 
 * Creates a Configuration with HBase resources
 * @return a Configuration with HBase resources
 */
  public static Configuration create(){
    Configuration conf=new Configuration();
    return addHbaseResources(conf);
  }
  /** 
 * Creates a clone of passed configuration.
 * @param that Configuration to clone.
 * @return a Configuration created with the hbase-*.xml files plusthe given configuration.
 */
  public static Configuration create(  final Configuration that){
    Configuration conf=create();
    for (    Entry<String,String> e : that) {
      conf.set(e.getKey(),e.getValue());
    }
    return conf;
  }
}
