public class HBaseFsckRepair {
  /** 
 * Fix dupe assignment by doing silent closes on each RS hosting the region and then force ZK unassigned node to OFFLINE to trigger assignment by master.
 * @param conf
 * @param region
 * @param servers
 * @throws IOException
 * @throws KeeperException
 * @throws InterruptedException
 */
  public static void fixDupeAssignment(  Configuration conf,  HRegionInfo region,  List<HServerAddress> servers) throws IOException, KeeperException, InterruptedException {
    HRegionInfo actualRegion=new HRegionInfo(region);
    for (    HServerAddress server : servers) {
      closeRegionSilentlyAndWait(conf,server,actualRegion);
    }
    forceOfflineInZK(conf,actualRegion);
  }
  /** 
 * Fix unassigned by creating/transition the unassigned ZK node for this region to OFFLINE state with a special flag to tell the master that this is a forced operation by HBCK.
 * @param conf
 * @param region
 * @throws IOException
 * @throws KeeperException
 */
  public static void fixUnassigned(  Configuration conf,  HRegionInfo region) throws IOException, KeeperException {
    HRegionInfo actualRegion=new HRegionInfo(region);
    forceOfflineInZK(conf,actualRegion);
  }
  private static void forceOfflineInZK(  Configuration conf,  final HRegionInfo region) throws ZooKeeperConnectionException, KeeperException, IOException {
    HConnectionManager.execute(new HConnectable<Void>(conf){
      @Override public Void connect(      HConnection connection) throws IOException {
        try {
          ZKAssign.createOrForceNodeOffline(connection.getZooKeeperWatcher(),region,HConstants.HBCK_CODE_NAME);
        }
 catch (        KeeperException ke) {
          throw new IOException(ke);
        }
        return null;
      }
    }
);
  }
  protected static void closeRegionSilentlyAndWait(  Configuration conf,  HServerAddress server,  HRegionInfo region) throws IOException, InterruptedException {
    HConnection connection=HConnectionManager.getConnection(conf);
    boolean success=false;
    try {
      HRegionInterface rs=connection.getHRegionConnection(server);
      rs.closeRegion(region,false);
      long timeout=conf.getLong("hbase.hbck.close.timeout",120000);
      long expiration=timeout + System.currentTimeMillis();
      while (System.currentTimeMillis() < expiration) {
        try {
          HRegionInfo rsRegion=rs.getRegionInfo(region.getRegionName());
          if (rsRegion == null)           throw new NotServingRegionException();
        }
 catch (        Exception e) {
          success=true;
          return;
        }
        Thread.sleep(1000);
      }
      throw new IOException("Region " + region + " failed to close within"+ " timeout "+ timeout);
    }
  finally {
      try {
        connection.close();
      }
 catch (      IOException ioe) {
        if (success) {
          throw ioe;
        }
      }
    }
  }
}
