/** 
 * An interface which enable to seek while underlying data is encoded. It works on one HFileBlock, but it is reusable. See {@link #setCurrentBuffer(ByteBuffer)}.
 */
public static interface EncodedSeeker {
  /** 
 * Set on which buffer there will be done seeking.
 * @param buffer Used for seeking.
 */
  public void setCurrentBuffer(  ByteBuffer buffer);
  /** 
 * Does a deep copy of the key at the current position. A deep copy is necessary because buffers are reused in the decoder.
 * @return key at current position
 */
  public ByteBuffer getKeyDeepCopy();
  /** 
 * Does a shallow copy of the value at the current position. A shallow copy is possible because the returned buffer refers to the backing array of the original encoded buffer.
 * @return value at current position
 */
  public ByteBuffer getValueShallowCopy();
  /** 
 * @return key value at current position with position set to limit 
 */
  public ByteBuffer getKeyValueBuffer();
  /** 
 * @return the KeyValue object at the current position. Includes memstoretimestamp.
 */
  public KeyValue getKeyValue();
  /** 
 * Set position to beginning of given block 
 */
  public void rewind();
  /** 
 * Move to next position
 * @return true on success, false if there is no more positions.
 */
  public boolean next();
  /** 
 * Moves the seeker position within the current block to: <ul> <li>the last key that that is less than or equal to the given key if <code>seekBefore</code> is false</li> <li>the last key that is strictly less than the given key if <code> seekBefore</code> is true. The caller is responsible for loading the previous block if the requested key turns out to be the first key of the current block.</li> </ul>
 * @param key byte array containing the key
 * @param offset key position the array
 * @param length key length in bytes
 * @param seekBefore find the key strictly less than the given key in caseof an exact match. Does not matter in case of an inexact match.
 * @return 0 on exact match, 1 on inexact match.
 */
  public int seekToKeyInBlock(  byte[] key,  int offset,  int length,  boolean seekBefore);
}
