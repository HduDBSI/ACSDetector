@InterfaceAudience.Private public class MetricsRegionAggregateSourceImpl extends BaseSourceImpl implements MetricsRegionAggregateSource {
  private final ReentrantReadWriteLock lock=new ReentrantReadWriteLock();
  private final TreeSet<MetricsRegionSourceImpl> regionSources=new TreeSet<MetricsRegionSourceImpl>();
  public MetricsRegionAggregateSourceImpl(){
    this(METRICS_NAME,METRICS_DESCRIPTION,METRICS_CONTEXT,METRICS_JMX_CONTEXT);
  }
  public MetricsRegionAggregateSourceImpl(  String metricsName,  String metricsDescription,  String metricsContext,  String metricsJmxContext){
    super(metricsName,metricsDescription,metricsContext,metricsJmxContext);
  }
  @Override public void register(  MetricsRegionSource source){
    lock.writeLock().lock();
    try {
      regionSources.add((MetricsRegionSourceImpl)source);
    }
  finally {
      lock.writeLock().unlock();
    }
  }
  @Override public void deregister(  MetricsRegionSource source){
    lock.writeLock().lock();
    try {
      regionSources.remove(source);
    }
  finally {
      lock.writeLock().unlock();
    }
  }
  /** 
 * Yes this is a get function that doesn't return anything.  Thanks Hadoop for breaking all expectations of java programmers.  Instead of returning anything Hadoop metrics expects getMetrics to push the metrics into the collector.
 * @param collector the collector
 * @param all       get all the metrics regardless of when they last changed.
 */
  @Override public void getMetrics(  MetricsCollector collector,  boolean all){
    MetricsRecordBuilder mrb=collector.addRecord(metricsName).setContext(metricsContext);
    if (regionSources != null) {
      lock.readLock().lock();
      try {
        for (        MetricsRegionSourceImpl regionMetricSource : regionSources) {
          regionMetricSource.snapshot(mrb,all);
        }
      }
  finally {
        lock.readLock().unlock();
      }
    }
    metricsRegistry.snapshot(mrb,all);
  }
}
