/** 
 * Driver for hbase mapreduce jobs. Select which to run by passing name of job to this main.
 */
@Deprecated @InterfaceAudience.Public @InterfaceStability.Stable public class Driver {
  /** 
 * @param args
 * @throws Throwable
 */
  public static void main(  String[] args) throws Throwable {
    ProgramDriver pgd=new ProgramDriver();
    pgd.addClass(RowCounter.NAME,RowCounter.class,"Count rows in HBase table");
    ProgramDriver.class.getMethod("driver",new Class[]{String[].class}).invoke(pgd,new Object[]{args});
  }
}
