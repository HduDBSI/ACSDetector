/** 
 * An output stream that writes to two streams on each operation. Does not attempt to handle exceptions gracefully. If any operation other than {@link #close()} fails on the first stream, it is not called on the secondstream.
 */
public class DoubleOutputStream extends OutputStream {
  private OutputStream out1;
  private OutputStream out2;
  public DoubleOutputStream(  OutputStream out1,  OutputStream out2){
    this.out1=out1;
    this.out2=out2;
  }
  @Override public void write(  int b) throws IOException {
    out1.write(b);
    out2.write(b);
  }
  @Override public void write(  byte b[]) throws IOException {
    out1.write(b,0,b.length);
    out2.write(b,0,b.length);
  }
  @Override public void write(  byte b[],  int off,  int len) throws IOException {
    out1.write(b,off,len);
    out2.write(b,off,len);
  }
  @Override public void flush() throws IOException {
    out1.flush();
    out2.flush();
  }
  @Override public void close() throws IOException {
    try {
      out1.close();
    }
  finally {
      out2.close();
    }
  }
}
