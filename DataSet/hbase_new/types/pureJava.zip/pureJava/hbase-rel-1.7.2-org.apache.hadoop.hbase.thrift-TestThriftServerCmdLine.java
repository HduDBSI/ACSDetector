/** 
 * Start the HBase Thrift server on a random port through the command-line interface and talk to it from client side.
 */
@Category({ClientTests.class,LargeTests.class}) @RunWith(Parameterized.class) public class TestThriftServerCmdLine {
  private static final Log LOG=LogFactory.getLog(TestThriftServerCmdLine.class);
  protected final ImplType implType;
  protected boolean specifyFramed;
  protected boolean specifyBindIP;
  protected boolean specifyCompact;
  protected static final HBaseTestingUtility TEST_UTIL=new HBaseTestingUtility();
  @Parameters public static Collection<Object[]> getParameters(){
    Collection<Object[]> parameters=new ArrayList<>();
    for (    ImplType implType : ImplType.values()) {
      for (      boolean specifyFramed : new boolean[]{false,true}) {
        for (        boolean specifyBindIP : new boolean[]{false,true}) {
          if (specifyBindIP && !implType.canSpecifyBindIP) {
            continue;
          }
          for (          boolean specifyCompact : new boolean[]{false,true}) {
            parameters.add(new Object[]{implType,specifyFramed,specifyBindIP,specifyCompact});
          }
        }
      }
    }
    return parameters;
  }
  public TestThriftServerCmdLine(  ImplType implType,  boolean specifyFramed,  boolean specifyBindIP,  boolean specifyCompact){
    this.implType=implType;
    this.specifyFramed=specifyFramed;
    this.specifyBindIP=specifyBindIP;
    this.specifyCompact=specifyCompact;
    LOG.debug(getParametersString());
  }
  private String getParametersString(){
    return "implType=" + implType + ", "+ "specifyFramed="+ specifyFramed+ ", "+ "specifyBindIP="+ specifyBindIP+ ", "+ "specifyCompact="+ specifyCompact;
  }
  @BeforeClass public static void setUpBeforeClass() throws Exception {
    TEST_UTIL.startMiniCluster();
    EnvironmentEdgeManagerTestHelper.injectEdge(new IncrementingEnvironmentEdge());
  }
  @AfterClass public static void tearDownAfterClass() throws Exception {
    TEST_UTIL.shutdownMiniCluster();
    EnvironmentEdgeManager.reset();
  }
  static ThriftServerRunner startCmdLineThread(  Supplier<ThriftServer> supplier,  final String[] args){
    LOG.info("Starting HBase Thrift server with command line: " + join(" ",args));
    ThriftServerRunner tsr=new ThriftServerRunner(supplier.get(),args);
    tsr.setName(ThriftServer.class.getSimpleName() + "-cmdline");
    tsr.start();
    return tsr;
  }
  static int getRandomPort(){
    return HBaseTestingUtility.randomFreePort();
  }
  protected Supplier<ThriftServer> getThriftServerSupplier(){
    return new Supplier<ThriftServer>(){
      @Override public ThriftServer get(){
        return new ThriftServer(TEST_UTIL.getConfiguration());
      }
    }
;
  }
  static ThriftServerRunner createBoundServer(  Supplier<ThriftServer> thriftServerSupplier) throws Exception {
    return createBoundServer(thriftServerSupplier,false,false);
  }
  static ThriftServerRunner createBoundServer(  Supplier<ThriftServer> thriftServerSupplier,  boolean protocolPortClash,  boolean infoPortClash) throws Exception {
    return createBoundServer(thriftServerSupplier,null,false,false,false,protocolPortClash,infoPortClash);
  }
  static ThriftServerRunner createBoundServer(  Supplier<ThriftServer> thriftServerSupplier,  ImplType implType,  boolean specifyFramed,  boolean specifyCompact,  boolean specifyBindIP) throws Exception {
    return createBoundServer(thriftServerSupplier,implType,specifyFramed,specifyCompact,specifyBindIP,false,false);
  }
  /** 
 * @param protocolPortClash This param is just so we can manufacture a port clash so we can testthe code does the right thing when this happens during actual test runs. Ugly but works.
 */
  static ThriftServerRunner createBoundServer(  Supplier<ThriftServer> thriftServerSupplier,  ImplType implType,  boolean specifyFramed,  boolean specifyCompact,  boolean specifyBindIP,  boolean protocolPortClash,  boolean infoPortClash) throws Exception {
    if (protocolPortClash && infoPortClash) {
      throw new RuntimeException("Can't set both at same time");
    }
    boolean testClashOfFirstProtocolPort=protocolPortClash;
    boolean testClashOfFirstInfoPort=infoPortClash;
    List<String> args=new ArrayList<>();
    BoundSocketMaker bsm=null;
    int port=-1;
    ThriftServerRunner tsr=null;
    for (int i=0; i < 100; i++) {
      args.clear();
      if (implType != null) {
        String serverTypeOption=implType.toString();
        assertTrue(serverTypeOption.startsWith("-"));
        args.add(serverTypeOption);
      }
      if (testClashOfFirstProtocolPort) {
        bsm=new BoundSocketMaker(new Supplier<Integer>(){
          @Override public Integer get(){
            return getRandomPort();
          }
        }
);
        port=bsm.getPort();
        testClashOfFirstProtocolPort=false;
      }
 else {
        port=getRandomPort();
      }
      args.add("-" + PORT_OPTION);
      args.add(String.valueOf(port));
      args.add("-" + INFOPORT_OPTION);
      int infoPort;
      if (testClashOfFirstInfoPort) {
        bsm=new BoundSocketMaker(new Supplier<Integer>(){
          @Override public Integer get(){
            return getRandomPort();
          }
        }
);
        infoPort=bsm.getPort();
        testClashOfFirstInfoPort=false;
      }
 else {
        infoPort=getRandomPort();
      }
      args.add(String.valueOf(infoPort));
      if (specifyFramed) {
        args.add("-" + FRAMED_OPTION);
      }
      if (specifyBindIP) {
        args.add("-" + BIND_OPTION);
        args.add(InetAddress.getLoopbackAddress().getHostName());
      }
      if (specifyCompact) {
        args.add("-" + COMPACT_OPTION);
      }
      args.add("start");
      tsr=startCmdLineThread(thriftServerSupplier,args.toArray(new String[args.size()]));
      for (int ii=0; ii < 100 && (tsr.getThriftServer().tserver == null && tsr.getRunException() == null); ii++) {
        Threads.sleep(100);
      }
      if (isBindException(tsr.getRunException())) {
        LOG.info("BindException; trying new port",tsr.getRunException());
        try {
          tsr.close();
          tsr.join();
        }
 catch (        IOException|InterruptedException ioe) {
          LOG.warn("Exception closing",ioe);
        }
        continue;
      }
      break;
    }
    if (bsm != null) {
      try {
        bsm.close();
      }
 catch (      IOException ioe) {
        LOG.warn("Failed close",ioe);
      }
    }
    if (tsr.getRunException() != null) {
      throw tsr.getRunException();
    }
    if (tsr.getThriftServer().tserver != null) {
      Class<? extends TServer> expectedClass=implType != null ? implType.serverClass : TBoundedThreadPoolServer.class;
      assertEquals(expectedClass,tsr.getThriftServer().tserver.getClass());
    }
    return tsr;
  }
  private static boolean isBindException(  Exception cmdLineException){
    if (cmdLineException == null) {
      return false;
    }
    if (cmdLineException instanceof BindException) {
      return true;
    }
    if (cmdLineException.getCause() != null && cmdLineException.getCause() instanceof BindException) {
      return true;
    }
    return false;
  }
  @Test public void testRunThriftServer() throws Exception {
    Exception clientSideException=null;
    for (int i=0; i < 10; i++) {
      clientSideException=null;
      ThriftServerRunner thriftServerRunner=createBoundServer(getThriftServerSupplier(),this.implType,this.specifyFramed,this.specifyCompact,this.specifyBindIP);
      try {
        talkToThriftServer(thriftServerRunner.getThriftServer().listenPort);
        break;
      }
 catch (      Exception ex) {
        clientSideException=ex;
        LOG.info("Exception",ex);
      }
 finally {
        LOG.debug("Stopping " + this.implType.simpleClassName() + " Thrift server");
        thriftServerRunner.close();
        thriftServerRunner.join();
        if (thriftServerRunner.getRunException() != null) {
          LOG.error("Command-line invocation of HBase Thrift server threw exception",thriftServerRunner.getRunException());
          throw thriftServerRunner.getRunException();
        }
      }
    }
    if (clientSideException != null) {
      LOG.error(String.format("Thrift Client; parameters=%s",getParametersString()),clientSideException);
      throw new Exception(clientSideException);
    }
  }
  protected static volatile boolean tableCreated=false;
  protected void talkToThriftServer(  int port) throws Exception {
    LOG.info(String.format("Talking to port=%d",port));
    TSocket sock=new TSocket(InetAddress.getLoopbackAddress().getHostName(),port);
    TTransport transport=sock;
    if (specifyFramed || implType.isAlwaysFramed) {
      transport=new TFramedTransport(transport);
    }
    sock.open();
    try {
      TProtocol prot;
      if (specifyCompact) {
        prot=new TCompactProtocol(transport);
      }
 else {
        prot=new TBinaryProtocol(transport);
      }
      Hbase.Client client=new Hbase.Client(prot);
      if (!tableCreated) {
        TestThriftServer.createTestTables(client);
        tableCreated=true;
      }
      TestThriftServer.checkTableList(client);
    }
  finally {
      sock.close();
    }
  }
}
