@InterfaceAudience.Private abstract class Queue<TKey extends Comparable<TKey>> extends AvlLinkedNode<Queue<TKey>> {
  /** 
 * @param proc must not be null
 */
  abstract boolean requireExclusiveLock(  Procedure<?> proc);
  private final TKey key;
  private final int priority;
  private final ProcedureDeque runnables=new ProcedureDeque();
  private final LockStatus lockStatus;
  protected Queue(  TKey key,  LockStatus lockStatus){
    this(key,1,lockStatus);
  }
  protected Queue(  TKey key,  int priority,  LockStatus lockStatus){
    assert priority >= 1 : "priority must be greater than or equal to 1";
    this.key=key;
    this.priority=priority;
    this.lockStatus=lockStatus;
  }
  protected TKey getKey(){
    return key;
  }
  public int getPriority(){
    return priority;
  }
  protected LockStatus getLockStatus(){
    return lockStatus;
  }
  public boolean isAvailable(){
    return !lockStatus.hasExclusiveLock() && !isEmpty();
  }
  public void add(  Procedure<?> proc,  boolean addToFront){
    if (addToFront) {
      runnables.addFirst(proc);
    }
 else {
      runnables.addLast(proc);
    }
  }
  public Procedure<?> peek(){
    return runnables.peek();
  }
  public Procedure<?> poll(){
    return runnables.poll();
  }
  public boolean isEmpty(){
    return runnables.isEmpty();
  }
  public int size(){
    return runnables.size();
  }
  public int compareKey(  TKey cmpKey){
    return key.compareTo(cmpKey);
  }
  @Override public int compareTo(  Queue<TKey> other){
    return compareKey(other.key);
  }
  @Override public String toString(){
    return String.format("%s(%s, xlock=%s sharedLock=%s size=%s)",getClass().getSimpleName(),key,lockStatus.hasExclusiveLock() ? "true (" + lockStatus.getExclusiveLockProcIdOwner() + ")" : "false",lockStatus.getSharedLockCount(),size());
  }
}
