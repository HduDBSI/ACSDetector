/** 
 * Subclass so can get at protected methods (none at moment).  Also, creates a FileSystem instance per instantiation.  Adds a shutdown own FileSystem on the way out. Shuts down own Filesystem only, not All filesystems as the FileSystem system exit hook does.
 */
public static class MiniHBaseClusterRegionServer extends HRegionServer {
  private Thread shutdownThread=null;
  private User user=null;
  /** 
 * List of RegionServers killed so far. ServerName also comprises startCode of a server, so any restarted instances of the same server will have different ServerName and will not coincide with past dead ones. So there's no need to cleanup this list.
 */
  static Set<ServerName> killedServers=new HashSet<>();
  public MiniHBaseClusterRegionServer(  Configuration conf) throws IOException, InterruptedException {
    super(conf);
    this.user=User.getCurrent();
  }
  @Override protected void handleReportForDutyResponse(  final RegionServerStartupResponse c) throws IOException {
    super.handleReportForDutyResponse(c);
    this.shutdownThread=new SingleFileSystemShutdownThread(getFileSystem());
  }
  @Override public void run(){
    try {
      this.user.runAs(new PrivilegedAction<Object>(){
        @Override public Object run(){
          runRegionServer();
          return null;
        }
      }
);
    }
 catch (    Throwable t) {
      LOG.error("Exception in run",t);
    }
 finally {
      if (this.shutdownThread != null) {
        this.shutdownThread.start();
        Threads.shutdown(this.shutdownThread,30000);
      }
    }
  }
  private void runRegionServer(){
    super.run();
  }
  @Override protected void kill(){
    killedServers.add(getServerName());
    super.kill();
  }
  @Override public void abort(  final String reason,  final Throwable cause){
    this.user.runAs(new PrivilegedAction<Object>(){
      @Override public Object run(){
        abortRegionServer(reason,cause);
        return null;
      }
    }
);
  }
  private void abortRegionServer(  String reason,  Throwable cause){
    super.abort(reason,cause);
  }
}
