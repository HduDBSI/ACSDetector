/** 
 * A KeyValue scanner that iterates over a single HFile
 */
class StoreFileScanner implements KeyValueScanner {
  private HFileScanner hfs;
  private KeyValue cur=null;
  /** 
 * Implements a  {@link KeyValueScanner} on top of the specified {@link HFileScanner}
 * @param hfs HFile scanner
 */
  public StoreFileScanner(  HFileScanner hfs){
    this.hfs=hfs;
  }
  public String toString(){
    return "StoreFileScanner[" + hfs.toString() + ", cur="+ cur+ "]";
  }
  public KeyValue peek(){
    return cur;
  }
  public KeyValue next(){
    KeyValue retKey=cur;
    cur=hfs.getKeyValue();
    try {
      if (cur != null)       hfs.next();
    }
 catch (    IOException e) {
      throw new RuntimeException(e);
    }
    return retKey;
  }
  public boolean seek(  KeyValue key){
    try {
      if (!seekAtOrAfter(hfs,key)) {
        close();
        return false;
      }
      cur=hfs.getKeyValue();
      hfs.next();
      return true;
    }
 catch (    IOException ioe) {
      close();
      return false;
    }
  }
  public void close(){
    cur=null;
  }
  /** 
 * @param s
 * @param k
 * @return
 * @throws IOException
 */
  public static boolean seekAtOrAfter(  HFileScanner s,  KeyValue k) throws IOException {
    int result=s.seekTo(k.getBuffer(),k.getKeyOffset(),k.getKeyLength());
    if (result < 0) {
      return s.seekTo();
    }
 else     if (result > 0) {
      return s.next();
    }
    return true;
  }
}
