/** 
 * Tests user specifiable time stamps putting, getting and scanning.  Also tests same in presence of deletes.  Test cores are written so can be run against an HRegion and against an HTable: i.e. both local and remote.
 */
public class TimestampTestBase extends HBaseTestCase {
  private static final long T0=10L;
  private static final long T1=100L;
  private static final long T2=200L;
  private static final byte[] FAMILY_NAME=Bytes.toBytes("colfamily1");
  private static final byte[] QUALIFIER_NAME=Bytes.toBytes("contents");
  private static final byte[] ROW=Bytes.toBytes("row");
  public static void doTestDelete(  final Incommon incommon,  FlushCache flusher) throws IOException {
    put(incommon,T0);
    put(incommon,T1);
    put(incommon,T2);
    put(incommon);
    assertVersions(incommon,new long[]{HConstants.LATEST_TIMESTAMP,T2,T1});
    delete(incommon);
    assertVersions(incommon,new long[]{T2,T1,T0});
    flusher.flushcache();
    assertVersions(incommon,new long[]{T2,T1,T0});
    put(incommon);
    assertVersions(incommon,new long[]{HConstants.LATEST_TIMESTAMP,T2,T1});
    delete(incommon,T2);
    assertVersions(incommon,new long[]{HConstants.LATEST_TIMESTAMP,T1,T0});
    flusher.flushcache();
    assertVersions(incommon,new long[]{HConstants.LATEST_TIMESTAMP,T1,T0});
    put(incommon,T2);
    delete(incommon,T1);
    put(incommon,T1);
    Delete delete=new Delete(ROW);
    delete.deleteColumns(FAMILY_NAME,QUALIFIER_NAME,T2);
    incommon.delete(delete,null,true);
    assertOnlyLatest(incommon,HConstants.LATEST_TIMESTAMP);
    flusher.flushcache();
    assertOnlyLatest(incommon,HConstants.LATEST_TIMESTAMP);
  }
  private static void assertOnlyLatest(  final Incommon incommon,  final long currentTime) throws IOException {
    Get get=null;
    get=new Get(ROW);
    get.addColumn(FAMILY_NAME,QUALIFIER_NAME);
    get.setMaxVersions(3);
    Result result=incommon.get(get);
    assertEquals(1,result.size());
    long time=Bytes.toLong(result.sorted()[0].getValue());
    assertEquals(time,currentTime);
  }
  public static void assertVersions(  final Incommon incommon,  final long[] tss) throws IOException {
    Get get=null;
    get=new Get(ROW);
    get.addColumn(FAMILY_NAME,QUALIFIER_NAME);
    Result r=incommon.get(get);
    byte[] bytes=r.getValue(FAMILY_NAME,QUALIFIER_NAME);
    long t=Bytes.toLong(bytes);
    assertEquals(tss[0],t);
    get=new Get(ROW);
    get.addColumn(FAMILY_NAME,QUALIFIER_NAME);
    get.setMaxVersions(tss.length);
    Result result=incommon.get(get);
    KeyValue[] kvs=result.sorted();
    assertEquals(kvs.length,tss.length);
    for (int i=0; i < kvs.length; i++) {
      t=Bytes.toLong(kvs[i].getValue());
      assertEquals(tss[i],t);
    }
    long maxStamp=kvs[0].getTimestamp();
    get=new Get(ROW);
    get.addColumn(FAMILY_NAME,QUALIFIER_NAME);
    get.setTimeRange(0,maxStamp);
    get.setMaxVersions(kvs.length - 1);
    result=incommon.get(get);
    kvs=result.sorted();
    assertEquals(kvs.length,tss.length - 1);
    for (int i=1; i < kvs.length; i++) {
      t=Bytes.toLong(kvs[i - 1].getValue());
      assertEquals(tss[i],t);
    }
    assertScanContentTimestamp(incommon,tss[0]);
  }
  public static void doTestTimestampScanning(  final Incommon incommon,  final FlushCache flusher) throws IOException {
    put(incommon,T0);
    put(incommon,T1);
    put(incommon,HConstants.LATEST_TIMESTAMP);
    int count=assertScanContentTimestamp(incommon,HConstants.LATEST_TIMESTAMP);
    assertEquals(count,assertScanContentTimestamp(incommon,T0));
    assertEquals(count,assertScanContentTimestamp(incommon,T1));
    flusher.flushcache();
    assertEquals(count,assertScanContentTimestamp(incommon,T0));
    assertEquals(count,assertScanContentTimestamp(incommon,T1));
  }
  public static int assertScanContentTimestamp(  final Incommon in,  final long ts) throws IOException {
    ScannerIncommon scanner=in.getScanner(COLUMNS[0],null,HConstants.EMPTY_START_ROW,ts);
    int count=0;
    try {
    }
  finally {
      scanner.close();
    }
    return count;
  }
  public static void put(  final Incommon loader,  final long ts) throws IOException {
    put(loader,Bytes.toBytes(ts),ts);
  }
  public static void put(  final Incommon loader) throws IOException {
    long ts=HConstants.LATEST_TIMESTAMP;
    put(loader,Bytes.toBytes(ts),ts);
  }
  public static void put(  final Incommon loader,  final byte[] bytes,  final long ts) throws IOException {
    Put put=new Put(ROW,ts,null);
    put.add(FAMILY_NAME,QUALIFIER_NAME,bytes);
    loader.put(put);
  }
  public static void delete(  final Incommon loader) throws IOException {
    delete(loader,null);
  }
  public static void delete(  final Incommon loader,  final byte[] column) throws IOException {
    delete(loader,column,HConstants.LATEST_TIMESTAMP);
  }
  public static void delete(  final Incommon loader,  final long ts) throws IOException {
    delete(loader,null,ts);
  }
  public static void delete(  final Incommon loader,  final byte[] column,  final long ts) throws IOException {
    Delete delete=ts == HConstants.LATEST_TIMESTAMP ? new Delete(ROW) : new Delete(ROW,ts,null);
    delete.deleteColumn(FAMILY_NAME,QUALIFIER_NAME,ts);
    loader.delete(delete,null,true);
  }
  public static Result get(  final Incommon loader) throws IOException {
    return loader.get(new Get(ROW));
  }
}
