static class LocalityBasedCandidateGenerator extends CandidateGenerator {
  private MasterServices masterServices;
  LocalityBasedCandidateGenerator(  MasterServices masterServices){
    this.masterServices=masterServices;
  }
  @Override Cluster.Action generate(  Cluster cluster){
    if (this.masterServices == null) {
      int thisServer=pickRandomServer(cluster);
      int otherServer=pickOtherRandomServer(cluster,thisServer);
      return pickRandomRegions(cluster,thisServer,otherServer);
    }
    int thisServer=pickRandomServer(cluster);
    int thisRegion;
    if (thisServer == -1) {
      LOG.warn("Could not pick lowest locality region server");
      return Cluster.NullAction;
    }
 else {
      thisRegion=pickLowestLocalityRegionOnServer(cluster,thisServer);
    }
    if (thisRegion == -1) {
      return Cluster.NullAction;
    }
    int otherServer=cluster.getLeastLoadedTopServerForRegion(thisRegion,thisServer);
    if (otherServer == -1) {
      return Cluster.NullAction;
    }
    int otherRegion=-1;
    return getAction(thisServer,thisRegion,otherServer,otherRegion);
  }
  private int pickLowestLocalityServer(  Cluster cluster){
    return cluster.getLowestLocalityRegionServer();
  }
  private int pickLowestLocalityRegionOnServer(  Cluster cluster,  int server){
    return cluster.getLowestLocalityRegionOnServer(server);
  }
  void setServices(  MasterServices services){
    this.masterServices=services;
  }
}
