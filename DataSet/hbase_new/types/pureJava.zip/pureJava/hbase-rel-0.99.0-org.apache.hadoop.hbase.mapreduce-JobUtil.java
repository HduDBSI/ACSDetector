/** 
 * Utility methods to interact with a job.
 */
@InterfaceAudience.Private @InterfaceStability.Evolving public abstract class JobUtil {
  private static final Log LOG=LogFactory.getLog(JobUtil.class);
  protected JobUtil(){
    super();
  }
  /** 
 * Initializes the staging directory and returns the path.
 * @param conf system configuration
 * @return staging directory path
 * @throws IOException
 * @throws InterruptedException
 */
  public static Path getStagingDir(  Configuration conf) throws IOException, InterruptedException {
    return JobSubmissionFiles.getStagingDir(new Cluster(conf),conf);
  }
}
