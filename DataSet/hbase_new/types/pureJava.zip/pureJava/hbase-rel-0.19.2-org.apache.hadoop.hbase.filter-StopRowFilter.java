/** 
 * Implementation of RowFilterInterface that filters out rows greater than or  equal to a specified rowKey.
 */
public class StopRowFilter implements RowFilterInterface {
  private byte[] stopRowKey;
  /** 
 * Default constructor, filters nothing. Required though for RPC deserialization.
 */
  public StopRowFilter(){
    super();
  }
  /** 
 * Constructor that takes a stopRowKey on which to filter
 * @param stopRowKey rowKey to filter on.
 */
  public StopRowFilter(  final byte[] stopRowKey){
    this.stopRowKey=stopRowKey;
  }
  /** 
 * An accessor for the stopRowKey
 * @return the filter's stopRowKey
 */
  public byte[] getStopRowKey(){
    return this.stopRowKey;
  }
  public void validate(  final byte[][] columns){
  }
  public void reset(){
  }
  public void rowProcessed(  boolean filtered,  byte[] rowKey){
  }
  public boolean processAlways(){
    return false;
  }
  public boolean filterAllRemaining(){
    return false;
  }
  public boolean filterRowKey(  final byte[] rowKey){
    if (rowKey == null) {
      if (this.stopRowKey == null) {
        return true;
      }
      return false;
    }
    return Bytes.compareTo(stopRowKey,rowKey) <= 0;
  }
  /** 
 * Because StopRowFilter does not examine column information, this method  defaults to calling the rowKey-only version of filter.
 */
  public boolean filterColumn(  final byte[] rowKey,  final byte[] colKey,  final byte[] data){
    return filterRowKey(rowKey);
  }
  /** 
 * Because StopRowFilter does not examine column information, this method  defaults to calling filterAllRemaining().
 */
  public boolean filterRow(  final SortedMap<byte[],Cell> columns){
    return filterAllRemaining();
  }
  public void readFields(  DataInput in) throws IOException {
    this.stopRowKey=Bytes.readByteArray(in);
  }
  public void write(  DataOutput out) throws IOException {
    Bytes.writeByteArray(out,this.stopRowKey);
  }
}
