/** 
 * CommandProvider to manage the service using bin/hbase-* scripts
 */
static class HBaseShellCommandProvider extends CommandProvider {
  private final String hbaseHome;
  private final String confDir;
  HBaseShellCommandProvider(  Configuration conf){
    hbaseHome=conf.get("hbase.it.clustermanager.hbase.home",System.getenv("HBASE_HOME"));
    String tmp=conf.get("hbase.it.clustermanager.hbase.conf.dir",System.getenv("HBASE_CONF_DIR"));
    if (tmp != null) {
      confDir=String.format("--config %s",tmp);
    }
 else {
      confDir="";
    }
  }
  @Override public String getCommand(  ServiceType service,  Operation op){
    return String.format("%s/bin/hbase-daemon.sh %s %s %s",hbaseHome,confDir,op.toString().toLowerCase(Locale.ROOT),service);
  }
}
