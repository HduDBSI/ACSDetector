/** 
 * WALObserver that has a Counter for walEdits written.
 */
public static class CustomWALObserver implements WALCoprocessor, WALObserver {
  private Counter walEditsCount;
  @Override public void postWALWrite(  ObserverContext<? extends WALCoprocessorEnvironment> ctx,  RegionInfo info,  WALKey logKey,  WALEdit logEdit) throws IOException {
    walEditsCount.increment();
  }
  @Override public void start(  CoprocessorEnvironment env) throws IOException {
    if (env instanceof WALCoprocessorEnvironment) {
      MetricRegistry registry=((WALCoprocessorEnvironment)env).getMetricRegistryForRegionServer();
      if (walEditsCount == null) {
        walEditsCount=registry.counter("walEditsCount");
      }
    }
  }
  @Override public Optional<WALObserver> getWALObserver(){
    return Optional.of(this);
  }
}
