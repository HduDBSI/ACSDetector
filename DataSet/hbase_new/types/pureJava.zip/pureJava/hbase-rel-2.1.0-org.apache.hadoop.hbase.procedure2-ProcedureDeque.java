/** 
 * Type class. For conceptual purpose only. Seeing ProcedureDeque as type instead of just ArrayDeque gives more understanding that it's a queue of waiting procedures.
 */
@InterfaceAudience.Private public class ProcedureDeque extends ArrayDeque<Procedure> {
}
