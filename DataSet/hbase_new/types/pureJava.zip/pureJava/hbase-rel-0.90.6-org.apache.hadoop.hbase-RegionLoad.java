/** 
 * Encapsulates per-region loading metrics.
 */
public static class RegionLoad implements Writable {
  /** 
 * the region name 
 */
  private byte[] name;
  /** 
 * the number of stores for the region 
 */
  private int stores;
  /** 
 * the number of storefiles for the region 
 */
  private int storefiles;
  /** 
 * the current total size of the store files for the region, in MB 
 */
  private int storefileSizeMB;
  /** 
 * the current size of the memstore for the region, in MB 
 */
  private int memstoreSizeMB;
  /** 
 * the current total size of storefile indexes for the region, in MB 
 */
  private int storefileIndexSizeMB;
  /** 
 * Constructor, for Writable
 */
  public RegionLoad(){
    super();
  }
  /** 
 * @param name
 * @param stores
 * @param storefiles
 * @param storefileSizeMB
 * @param memstoreSizeMB
 * @param storefileIndexSizeMB
 */
  public RegionLoad(  final byte[] name,  final int stores,  final int storefiles,  final int storefileSizeMB,  final int memstoreSizeMB,  final int storefileIndexSizeMB){
    this.name=name;
    this.stores=stores;
    this.storefiles=storefiles;
    this.storefileSizeMB=storefileSizeMB;
    this.memstoreSizeMB=memstoreSizeMB;
    this.storefileIndexSizeMB=storefileIndexSizeMB;
  }
  /** 
 * @return the region name
 */
  public byte[] getName(){
    return name;
  }
  /** 
 * @return the region name as a string
 */
  public String getNameAsString(){
    return Bytes.toString(name);
  }
  /** 
 * @return the number of stores
 */
  public int getStores(){
    return stores;
  }
  /** 
 * @return the number of storefiles
 */
  public int getStorefiles(){
    return storefiles;
  }
  /** 
 * @return the total size of the storefiles, in MB
 */
  public int getStorefileSizeMB(){
    return storefileSizeMB;
  }
  /** 
 * @return the memstore size, in MB
 */
  public int getMemStoreSizeMB(){
    return memstoreSizeMB;
  }
  /** 
 * @return the approximate size of storefile indexes on the heap, in MB
 */
  public int getStorefileIndexSizeMB(){
    return storefileIndexSizeMB;
  }
  /** 
 * @param name the region name
 */
  public void setName(  byte[] name){
    this.name=name;
  }
  /** 
 * @param stores the number of stores
 */
  public void setStores(  int stores){
    this.stores=stores;
  }
  /** 
 * @param storefiles the number of storefiles
 */
  public void setStorefiles(  int storefiles){
    this.storefiles=storefiles;
  }
  /** 
 * @param memstoreSizeMB the memstore size, in MB
 */
  public void setMemStoreSizeMB(  int memstoreSizeMB){
    this.memstoreSizeMB=memstoreSizeMB;
  }
  /** 
 * @param storefileIndexSizeMB the approximate size of storefile indexeson the heap, in MB
 */
  public void setStorefileIndexSizeMB(  int storefileIndexSizeMB){
    this.storefileIndexSizeMB=storefileIndexSizeMB;
  }
  public void readFields(  DataInput in) throws IOException {
    int namelen=in.readInt();
    this.name=new byte[namelen];
    in.readFully(this.name);
    this.stores=in.readInt();
    this.storefiles=in.readInt();
    this.storefileSizeMB=in.readInt();
    this.memstoreSizeMB=in.readInt();
    this.storefileIndexSizeMB=in.readInt();
  }
  public void write(  DataOutput out) throws IOException {
    out.writeInt(name.length);
    out.write(name);
    out.writeInt(stores);
    out.writeInt(storefiles);
    out.writeInt(storefileSizeMB);
    out.writeInt(memstoreSizeMB);
    out.writeInt(storefileIndexSizeMB);
  }
  /** 
 * @see java.lang.Object#toString()
 */
  @Override public String toString(){
    StringBuilder sb=Strings.appendKeyValue(new StringBuilder(),"stores",Integer.valueOf(this.stores));
    sb=Strings.appendKeyValue(sb,"storefiles",Integer.valueOf(this.storefiles));
    sb=Strings.appendKeyValue(sb,"storefileSizeMB",Integer.valueOf(this.storefileSizeMB));
    sb=Strings.appendKeyValue(sb,"memstoreSizeMB",Integer.valueOf(this.memstoreSizeMB));
    sb=Strings.appendKeyValue(sb,"storefileIndexSizeMB",Integer.valueOf(this.storefileIndexSizeMB));
    return sb.toString();
  }
}
