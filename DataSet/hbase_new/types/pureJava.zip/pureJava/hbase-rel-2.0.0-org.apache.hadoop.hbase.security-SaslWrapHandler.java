/** 
 * wrap sasl messages.
 */
@InterfaceAudience.Private public class SaslWrapHandler extends ChannelOutboundHandlerAdapter {
  private final SaslClient saslClient;
  private CoalescingBufferQueue queue;
  public SaslWrapHandler(  SaslClient saslClient){
    this.saslClient=saslClient;
  }
  @Override public void handlerAdded(  ChannelHandlerContext ctx) throws Exception {
    queue=new CoalescingBufferQueue(ctx.channel());
  }
  @Override public void write(  ChannelHandlerContext ctx,  Object msg,  ChannelPromise promise) throws Exception {
    if (msg instanceof ByteBuf) {
      queue.add((ByteBuf)msg,promise);
    }
 else {
      ctx.write(msg,promise);
    }
  }
  @Override public void flush(  ChannelHandlerContext ctx) throws Exception {
    if (queue.isEmpty()) {
      return;
    }
    ByteBuf buf=null;
    try {
      ChannelPromise promise=ctx.newPromise();
      int readableBytes=queue.readableBytes();
      buf=queue.remove(readableBytes,promise);
      byte[] bytes=new byte[readableBytes];
      buf.readBytes(bytes);
      byte[] wrapperBytes=saslClient.wrap(bytes,0,bytes.length);
      ChannelPromise lenPromise=ctx.newPromise();
      ctx.write(ctx.alloc().buffer(4).writeInt(wrapperBytes.length),lenPromise);
      ChannelPromise contentPromise=ctx.newPromise();
      ctx.write(Unpooled.wrappedBuffer(wrapperBytes),contentPromise);
      PromiseCombiner combiner=new PromiseCombiner();
      combiner.addAll(lenPromise,contentPromise);
      combiner.finish(promise);
      ctx.flush();
    }
  finally {
      if (buf != null) {
        ReferenceCountUtil.safeRelease(buf);
      }
    }
  }
  @Override public void close(  ChannelHandlerContext ctx,  ChannelPromise promise) throws Exception {
    if (!queue.isEmpty()) {
      queue.releaseAndFailAll(new IOException("Connection closed"));
    }
    ctx.close(promise);
  }
}
