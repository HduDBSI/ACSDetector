/** 
 * Exception thrown when a blocking operation times out.
 */
@SuppressWarnings("serial") @InterfaceAudience.Private public class TimeoutIOException extends IOException {
  public TimeoutIOException(){
    super();
  }
  public TimeoutIOException(  final String message){
    super(message);
  }
  public TimeoutIOException(  final String message,  final Throwable t){
    super(message,t);
  }
  public TimeoutIOException(  final Throwable t){
    super(t);
  }
}
