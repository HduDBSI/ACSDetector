/** 
 * Interface for both Comparable<byte []> and Writable. 
 */
public interface WritableByteArrayComparable extends Writable, Comparable<byte[]> {
}
