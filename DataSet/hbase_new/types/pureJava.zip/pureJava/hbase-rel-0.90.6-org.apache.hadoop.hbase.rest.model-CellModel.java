/** 
 * Representation of a cell. A cell is a single value associated a column and optional qualifier, and either the timestamp when it was stored or the user- provided timestamp if one was explicitly supplied. <pre> &lt;complexType name="Cell"&gt; &lt;sequence&gt; &lt;element name="value" maxOccurs="1" minOccurs="1"&gt; &lt;simpleType&gt; &lt;restriction base="base64Binary"/&gt; &lt;/simpleType&gt; &lt;/element&gt; &lt;/sequence&gt; &lt;attribute name="column" type="base64Binary" /&gt; &lt;attribute name="timestamp" type="int" /&gt; &lt;/complexType&gt; </pre>
 */
@XmlRootElement(name="Cell") public class CellModel implements ProtobufMessageHandler, Serializable {
  private static final long serialVersionUID=1L;
  private long timestamp=HConstants.LATEST_TIMESTAMP;
  private byte[] column;
  private byte[] value;
  /** 
 * Default constructor
 */
  public CellModel(){
  }
  /** 
 * Constructor
 * @param column
 * @param value
 */
  public CellModel(  byte[] column,  byte[] value){
    this(column,HConstants.LATEST_TIMESTAMP,value);
  }
  /** 
 * Constructor
 * @param column
 * @param qualifier
 * @param value
 */
  public CellModel(  byte[] column,  byte[] qualifier,  byte[] value){
    this(column,qualifier,HConstants.LATEST_TIMESTAMP,value);
  }
  /** 
 * Constructor from KeyValue
 * @param kv
 */
  public CellModel(  KeyValue kv){
    this(kv.getFamily(),kv.getQualifier(),kv.getTimestamp(),kv.getValue());
  }
  /** 
 * Constructor
 * @param column
 * @param timestamp
 * @param value
 */
  public CellModel(  byte[] column,  long timestamp,  byte[] value){
    this.column=column;
    this.timestamp=timestamp;
    this.value=value;
  }
  /** 
 * Constructor
 * @param column
 * @param qualifier
 * @param timestamp
 * @param value
 */
  public CellModel(  byte[] column,  byte[] qualifier,  long timestamp,  byte[] value){
    this.column=KeyValue.makeColumn(column,qualifier);
    this.timestamp=timestamp;
    this.value=value;
  }
  /** 
 * @return the column
 */
  @XmlAttribute public byte[] getColumn(){
    return column;
  }
  /** 
 * @param column the column to set
 */
  public void setColumn(  byte[] column){
    this.column=column;
  }
  /** 
 * @return true if the timestamp property has been specified by theuser
 */
  public boolean hasUserTimestamp(){
    return timestamp != HConstants.LATEST_TIMESTAMP;
  }
  /** 
 * @return the timestamp
 */
  @XmlAttribute public long getTimestamp(){
    return timestamp;
  }
  /** 
 * @param timestamp the timestamp to set
 */
  public void setTimestamp(  long timestamp){
    this.timestamp=timestamp;
  }
  /** 
 * @return the value
 */
  @XmlValue public byte[] getValue(){
    return value;
  }
  /** 
 * @param value the value to set
 */
  public void setValue(  byte[] value){
    this.value=value;
  }
  @Override public byte[] createProtobufOutput(){
    Cell.Builder builder=Cell.newBuilder();
    builder.setColumn(ByteString.copyFrom(getColumn()));
    builder.setData(ByteString.copyFrom(getValue()));
    if (hasUserTimestamp()) {
      builder.setTimestamp(getTimestamp());
    }
    return builder.build().toByteArray();
  }
  @Override public ProtobufMessageHandler getObjectFromMessage(  byte[] message) throws IOException {
    Cell.Builder builder=Cell.newBuilder();
    builder.mergeFrom(message);
    setColumn(builder.getColumn().toByteArray());
    setValue(builder.getData().toByteArray());
    if (builder.hasTimestamp()) {
      setTimestamp(builder.getTimestamp());
    }
    return this;
  }
}
