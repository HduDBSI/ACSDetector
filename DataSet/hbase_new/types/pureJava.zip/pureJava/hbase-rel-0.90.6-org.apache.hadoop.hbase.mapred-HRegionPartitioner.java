/** 
 * This is used to partition the output keys into groups of keys. Keys are grouped according to the regions that currently exist so that each reducer fills a single region so load is distributed.
 * @param < K2 >
 * @param < V2 >
 */
@Deprecated public class HRegionPartitioner<K2,V2> implements Partitioner<ImmutableBytesWritable,V2> {
  private final Log LOG=LogFactory.getLog(TableInputFormat.class);
  private HTable table;
  private byte[][] startKeys;
  public void configure(  JobConf job){
    try {
      this.table=new HTable(HBaseConfiguration.create(job),job.get(TableOutputFormat.OUTPUT_TABLE));
    }
 catch (    IOException e) {
      LOG.error(e);
    }
    try {
      this.startKeys=this.table.getStartKeys();
    }
 catch (    IOException e) {
      LOG.error(e);
    }
  }
  public int getPartition(  ImmutableBytesWritable key,  V2 value,  int numPartitions){
    byte[] region=null;
    if (this.startKeys.length == 1) {
      return 0;
    }
    try {
      region=table.getRegionLocation(key.get()).getRegionInfo().getStartKey();
    }
 catch (    IOException e) {
      LOG.error(e);
    }
    for (int i=0; i < this.startKeys.length; i++) {
      if (Bytes.compareTo(region,this.startKeys[i]) == 0) {
        if (i >= numPartitions - 1) {
          return (Integer.toString(i).hashCode() & Integer.MAX_VALUE) % numPartitions;
        }
        return i;
      }
    }
    return 0;
  }
}
