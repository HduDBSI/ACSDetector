/** 
 * Callback handler for create unassigned znodes used during bulk assign.
 */
static class CreateUnassignedAsyncCallback implements AsyncCallback.StringCallback {
  private final Log LOG=LogFactory.getLog(CreateUnassignedAsyncCallback.class);
  private final ZooKeeperWatcher zkw;
  private final HServerInfo destination;
  private final AtomicInteger counter;
  CreateUnassignedAsyncCallback(  final ZooKeeperWatcher zkw,  final HServerInfo destination,  final AtomicInteger counter){
    this.zkw=zkw;
    this.destination=destination;
    this.counter=counter;
  }
  @Override public void processResult(  int rc,  String path,  Object ctx,  String name){
    if (rc != 0) {
      LOG.warn("rc != 0 for " + path + " -- retryable connectionloss -- "+ "FIX see http://wiki.apache.org/hadoop/ZooKeeper/FAQ#A2");
      this.zkw.abort("Connectionloss writing unassigned at " + path + ", rc="+ rc,null);
      return;
    }
    LOG.debug("rs=" + (RegionState)ctx + ", server="+ this.destination.getServerName());
    this.zkw.getZooKeeper().exists(path,this.zkw,new ExistsUnassignedAsyncCallback(this.counter),ctx);
  }
}
