/** 
 * Coprocessor environment extension providing access to master related services.
 */
static class MasterEnvironment extends CoprocessorHost.Environment implements MasterCoprocessorEnvironment {
  private MasterServices masterServices;
  public MasterEnvironment(  final Class<?> implClass,  final Coprocessor impl,  final int priority,  final int seq,  final Configuration conf,  final MasterServices services){
    super(impl,priority,seq,conf);
    this.masterServices=services;
  }
  public MasterServices getMasterServices(){
    return masterServices;
  }
}
