/** 
 * Driver for hbase mapreduce jobs. Select which to run by passing name of job to this main.
 */
@Deprecated @InterfaceAudience.Public @InterfaceStability.Stable public class Driver {
  private static ProgramDriver pgd=new ProgramDriver();
  @VisibleForTesting static void setProgramDriver(  ProgramDriver pgd0){
    pgd=pgd0;
  }
  /** 
 * @param args
 * @throws Throwable
 */
  public static void main(  String[] args) throws Throwable {
    pgd.addClass(RowCounter.NAME,RowCounter.class,"Count rows in HBase table");
    ProgramDriver.class.getMethod("driver",new Class[]{String[].class}).invoke(pgd,new Object[]{args});
  }
}
