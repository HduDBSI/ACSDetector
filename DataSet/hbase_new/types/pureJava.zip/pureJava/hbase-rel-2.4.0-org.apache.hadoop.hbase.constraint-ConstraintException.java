/** 
 * Exception that a user defined constraint throws on failure of a {@link org.apache.hadoop.hbase.client.Put}. <p>Does <b>NOT</b> attempt the {@link org.apache.hadoop.hbase.client.Put} multiple times, since the constraint <b>should</b> fail every time for the same  {@link org.apache.hadoop.hbase.client.Put} (it should beidempotent).
 */
@InterfaceAudience.Private public class ConstraintException extends org.apache.hadoop.hbase.DoNotRetryIOException {
  private static final long serialVersionUID=1197446454511704140L;
  public ConstraintException(){
    super();
  }
  public ConstraintException(  String msg){
    super(msg);
  }
  public ConstraintException(  String msg,  Throwable cause){
    super(msg,cause);
  }
}
