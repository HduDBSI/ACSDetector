static class DummyServer implements Server {
  String hostname;
  DummyServer(){
    hostname="hostname.example.org";
  }
  DummyServer(  String hostname){
    this.hostname=hostname;
  }
  @Override public Configuration getConfiguration(){
    return conf;
  }
  @Override public ZooKeeperWatcher getZooKeeper(){
    return zkw;
  }
  @Override public CoordinatedStateManager getCoordinatedStateManager(){
    return null;
  }
  @Override public ClusterConnection getConnection(){
    return null;
  }
  @Override public MetaTableLocator getMetaTableLocator(){
    return null;
  }
  @Override public ServerName getServerName(){
    return ServerName.valueOf(hostname,1234,1L);
  }
  @Override public void abort(  String why,  Throwable e){
  }
  @Override public boolean isAborted(){
    return false;
  }
  @Override public void stop(  String why){
  }
  @Override public boolean isStopped(){
    return false;
  }
  @Override public ChoreService getChoreService(){
    return null;
  }
}
