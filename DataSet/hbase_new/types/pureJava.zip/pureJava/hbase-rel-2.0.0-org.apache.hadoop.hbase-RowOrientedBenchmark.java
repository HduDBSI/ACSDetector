static abstract class RowOrientedBenchmark {
  protected final Configuration conf;
  protected final FileSystem fs;
  protected final Path mf;
  protected final int totalRows;
  protected String codec="none";
  protected String cipher="none";
  public RowOrientedBenchmark(  Configuration conf,  FileSystem fs,  Path mf,  int totalRows,  String codec,  String cipher){
    this.conf=conf;
    this.fs=fs;
    this.mf=mf;
    this.totalRows=totalRows;
    this.codec=codec;
    this.cipher=cipher;
  }
  public RowOrientedBenchmark(  Configuration conf,  FileSystem fs,  Path mf,  int totalRows){
    this.conf=conf;
    this.fs=fs;
    this.mf=mf;
    this.totalRows=totalRows;
  }
  void setUp() throws Exception {
  }
  abstract void doRow(  int i) throws Exception ;
  protected int getReportingPeriod(){
    return this.totalRows / 10;
  }
  void tearDown() throws Exception {
  }
  /** 
 * Run benchmark
 * @return elapsed time.
 * @throws Exception
 */
  long run() throws Exception {
    long elapsedTime;
    setUp();
    long startTime=System.currentTimeMillis();
    try {
      for (int i=0; i < totalRows; i++) {
        if (i > 0 && i % getReportingPeriod() == 0) {
          LOG.info("Processed " + i + " rows.");
        }
        doRow(i);
      }
      elapsedTime=System.currentTimeMillis() - startTime;
    }
  finally {
      tearDown();
    }
    return elapsedTime;
  }
}
