/** 
 * This class tracks a single Lease. 
 */
static class Lease implements Delayed {
  private final String leaseName;
  private final LeaseListener listener;
  private long expirationTime;
  Lease(  final String leaseName,  LeaseListener listener){
    this(leaseName,listener,0);
  }
  Lease(  final String leaseName,  LeaseListener listener,  long expirationTime){
    this.leaseName=leaseName;
    this.listener=listener;
    this.expirationTime=expirationTime;
  }
  /** 
 * @return the lease name 
 */
  public String getLeaseName(){
    return leaseName;
  }
  /** 
 * @return listener 
 */
  public LeaseListener getListener(){
    return this.listener;
  }
  @Override public boolean equals(  Object obj){
    if (this == obj) {
      return true;
    }
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    return this.hashCode() == ((Lease)obj).hashCode();
  }
  @Override public int hashCode(){
    return this.leaseName.hashCode();
  }
  public long getDelay(  TimeUnit unit){
    return unit.convert(this.expirationTime - System.currentTimeMillis(),TimeUnit.MILLISECONDS);
  }
  public int compareTo(  Delayed o){
    long delta=this.getDelay(TimeUnit.MILLISECONDS) - o.getDelay(TimeUnit.MILLISECONDS);
    return this.equals(o) ? 0 : (delta > 0 ? 1 : -1);
  }
  /** 
 * @param expirationTime the expirationTime to set 
 */
  public void setExpirationTime(  long expirationTime){
    this.expirationTime=expirationTime;
  }
}
