public class HbckTestingUtil {
  public static HBaseFsck doFsck(  Configuration conf,  boolean fix) throws Exception {
    return doFsck(conf,fix,null);
  }
  public static HBaseFsck doFsck(  Configuration conf,  boolean fix,  String table) throws Exception {
    return doFsck(conf,fix,fix,fix,fix,fix,fix,table);
  }
  public static HBaseFsck doFsck(  Configuration conf,  boolean fixAssignments,  boolean fixMeta,  boolean fixHdfsHoles,  boolean fixHdfsOverlaps,  boolean fixHdfsOrphans,  boolean fixVersionFile,  String table) throws Exception {
    HBaseFsck fsck=new HBaseFsck(conf);
    fsck.connect();
    fsck.setDisplayFullReport();
    fsck.setTimeLag(0);
    fsck.setFixAssignments(fixAssignments);
    fsck.setFixMeta(fixMeta);
    fsck.setFixHdfsHoles(fixHdfsHoles);
    fsck.setFixHdfsOverlaps(fixHdfsOverlaps);
    fsck.setFixHdfsOrphans(fixHdfsOrphans);
    fsck.setFixVersionFile(fixVersionFile);
    if (table != null) {
      fsck.includeTable(table);
    }
    fsck.onlineHbck();
    return fsck;
  }
  /** 
 * Runs hbck with the -sidelineCorruptHFiles option
 * @param conf
 * @param table table constraint
 * @return <returncode, hbckInstance>
 * @throws Exception
 */
  public static HBaseFsck doHFileQuarantine(  Configuration conf,  String table) throws Exception {
    String[] args={"-sidelineCorruptHFiles","-ignorePreCheckPermission",table};
    ExecutorService exec=new ScheduledThreadPoolExecutor(10);
    HBaseFsck hbck=new HBaseFsck(conf,exec);
    hbck.exec(exec,args);
    return hbck;
  }
  public static void assertNoErrors(  HBaseFsck fsck) throws Exception {
    List<ERROR_CODE> errs=fsck.getErrors().getErrorList();
    assertEquals(new ArrayList<ERROR_CODE>(),errs);
  }
  public static void assertErrors(  HBaseFsck fsck,  ERROR_CODE[] expectedErrors){
    List<ERROR_CODE> errs=fsck.getErrors().getErrorList();
    assertEquals(Arrays.asList(expectedErrors),errs);
  }
}
