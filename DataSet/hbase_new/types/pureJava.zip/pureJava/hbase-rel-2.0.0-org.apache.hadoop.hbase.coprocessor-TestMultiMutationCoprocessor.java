public static class TestMultiMutationCoprocessor implements RegionCoprocessor, RegionObserver {
  @Override public Optional<RegionObserver> getRegionObserver(){
    return Optional.of(this);
  }
  @Override public void preBatchMutate(  ObserverContext<RegionCoprocessorEnvironment> c,  MiniBatchOperationInProgress<Mutation> miniBatchOp) throws IOException {
    Mutation mut=miniBatchOp.getOperation(0);
    List<Cell> cells=mut.getFamilyCellMap().get(test);
    Put[] puts=new Put[]{new Put(row1).addColumn(test,dummy,cells.get(0).getTimestamp(),Bytes.toBytes("cpdummy")),new Put(row2).addColumn(test,dummy,cells.get(0).getTimestamp(),dummy),new Put(row3).addColumn(test,dummy,cells.get(0).getTimestamp(),dummy)};
    LOG.info("Putting:" + Arrays.toString(puts));
    miniBatchOp.addOperationsFromCP(0,puts);
  }
}
