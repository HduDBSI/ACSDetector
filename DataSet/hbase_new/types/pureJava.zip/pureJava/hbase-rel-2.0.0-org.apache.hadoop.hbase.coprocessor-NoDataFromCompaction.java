/** 
 * Don't allow any data to be written out in the compaction by creating a custom {@link StoreScanner}.
 */
public static class NoDataFromCompaction implements RegionCoprocessor, RegionObserver {
  @Override public Optional<RegionObserver> getRegionObserver(){
    return Optional.of(this);
  }
  @Override public InternalScanner preCompact(  ObserverContext<RegionCoprocessorEnvironment> c,  Store store,  InternalScanner scanner,  ScanType scanType,  CompactionLifeCycleTracker tracker,  CompactionRequest request) throws IOException {
    return NO_DATA;
  }
}
