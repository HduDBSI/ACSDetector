interface Comparer<T> {
  int compareTo(  T buffer1,  int offset1,  int length1,  T buffer2,  int offset2,  int length2);
}
