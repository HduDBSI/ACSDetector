static class MockSeekHintFilter extends FilterBase {
  private Cell returnCell;
  public MockSeekHintFilter(  Cell returnCell){
    this.returnCell=returnCell;
  }
  @Override public ReturnCode filterCell(  final Cell v) throws IOException {
    return ReturnCode.SEEK_NEXT_USING_HINT;
  }
  @Override public Cell getNextCellHint(  Cell currentCell) throws IOException {
    return this.returnCell;
  }
  @Override public boolean equals(  Object obj){
    if (obj == null || !(obj instanceof MockSeekHintFilter)) {
      return false;
    }
    if (obj == this) {
      return true;
    }
    MockSeekHintFilter f=(MockSeekHintFilter)obj;
    return this.returnCell.equals(f.returnCell);
  }
  @Override public int hashCode(){
    return Objects.hash(this.returnCell);
  }
}
