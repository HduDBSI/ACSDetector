/** 
 * Test log deletion as logs are rolled.
 */
public class TestLogRolling {
  private static final Log LOG=LogFactory.getLog(TestLogRolling.class);
  private HRegionServer server;
  private HLog log;
  private String tableName;
  private byte[] value;
  private static FileSystem fs;
  private static MiniDFSCluster dfsCluster;
  private static HBaseAdmin admin;
  private static MiniHBaseCluster cluster;
  private final static HBaseTestingUtility TEST_UTIL=new HBaseTestingUtility();
{
    ((Log4JLogger)DataNode.LOG).getLogger().setLevel(Level.ALL);
    ((Log4JLogger)LeaseManager.LOG).getLogger().setLevel(Level.ALL);
    ((Log4JLogger)FSNamesystem.LOG).getLogger().setLevel(Level.ALL);
    ((Log4JLogger)DFSClient.LOG).getLogger().setLevel(Level.ALL);
    ((Log4JLogger)HRegionServer.LOG).getLogger().setLevel(Level.ALL);
    ((Log4JLogger)HRegion.LOG).getLogger().setLevel(Level.ALL);
    ((Log4JLogger)HLog.LOG).getLogger().setLevel(Level.ALL);
  }
  /** 
 * constructor
 * @throws Exception
 */
  public TestLogRolling(){
    super();
    this.server=null;
    this.log=null;
    this.tableName=null;
    this.value=null;
    String className=this.getClass().getName();
    StringBuilder v=new StringBuilder(className);
    while (v.length() < 1000) {
      v.append(className);
    }
    value=Bytes.toBytes(v.toString());
  }
  @BeforeClass public static void setUpBeforeClass() throws Exception {
    TEST_UTIL.getConfiguration().setLong("hbase.hregion.max.filesize",768L * 1024L);
    TEST_UTIL.getConfiguration().setInt("hbase.regionserver.maxlogentries",32);
    TEST_UTIL.getConfiguration().setInt("hbase.regionserver.logroll.errors.tolerated",2);
    TEST_UTIL.getConfiguration().setInt("ipc.ping.interval",10 * 1000);
    TEST_UTIL.getConfiguration().setInt("ipc.socket.timeout",10 * 1000);
    TEST_UTIL.getConfiguration().setInt("hbase.rpc.timeout",10 * 1000);
    TEST_UTIL.getConfiguration().setInt("hbase.hregion.memstore.optionalflushcount",2);
    TEST_UTIL.getConfiguration().setInt("hbase.hregion.memstore.flush.size",8192);
    TEST_UTIL.getConfiguration().setLong("hbase.client.pause",10 * 1000);
    TEST_UTIL.getConfiguration().setInt(HConstants.THREAD_WAKE_FREQUENCY,2 * 1000);
    TEST_UTIL.getConfiguration().setBoolean("dfs.support.append",true);
    TEST_UTIL.getConfiguration().setInt("heartbeat.recheck.interval",5000);
    TEST_UTIL.getConfiguration().setInt("dfs.heartbeat.interval",1);
    TEST_UTIL.getConfiguration().setInt("dfs.client.block.write.retries",30);
    TEST_UTIL.getConfiguration().setInt("hbase.regionserver.hlog.tolerable.lowreplication",2);
    TEST_UTIL.getConfiguration().setInt("hbase.regionserver.hlog.lowreplication.rolllimit",3);
    TEST_UTIL.startMiniCluster(2);
    cluster=TEST_UTIL.getHBaseCluster();
    dfsCluster=TEST_UTIL.getDFSCluster();
    fs=TEST_UTIL.getTestFileSystem();
    admin=TEST_UTIL.getHBaseAdmin();
    cluster.getMaster().balanceSwitch(false);
  }
  @AfterClass public static void tearDown() throws IOException {
    TEST_UTIL.cleanupTestDir();
    TEST_UTIL.shutdownMiniCluster();
  }
  private void startAndWriteData() throws IOException {
    new HTable(TEST_UTIL.getConfiguration(),HConstants.META_TABLE_NAME);
    this.server=cluster.getRegionServerThreads().get(0).getRegionServer();
    this.log=server.getWAL();
    HTableDescriptor desc=new HTableDescriptor(tableName);
    desc.addFamily(new HColumnDescriptor(HConstants.CATALOG_FAMILY));
    admin.createTable(desc);
    HTable table=new HTable(TEST_UTIL.getConfiguration(),tableName);
    server=TEST_UTIL.getRSForFirstRegionInTable(Bytes.toBytes(tableName));
    this.log=server.getWAL();
    for (int i=1; i <= 256; i++) {
      Put put=new Put(Bytes.toBytes("row" + String.format("%1$04d",i)));
      put.add(HConstants.CATALOG_FAMILY,null,value);
      table.put(put);
      if (i % 32 == 0) {
        try {
          Thread.sleep(2000);
        }
 catch (        InterruptedException e) {
        }
      }
    }
  }
  /** 
 * Tests that logs are deleted
 * @throws IOException
 * @throws FailedLogCloseException
 */
  @Test public void testLogRolling() throws FailedLogCloseException, IOException {
    this.tableName=getName();
    startAndWriteData();
    LOG.info("after writing there are " + log.getNumLogFiles() + " log files");
    List<HRegion> regions=new ArrayList<HRegion>(server.getOnlineRegionsLocalContext());
    for (    HRegion r : regions) {
      r.flushcache();
    }
    log.rollWriter();
    int count=log.getNumLogFiles();
    LOG.info("after flushing all regions and rolling logs there are " + log.getNumLogFiles() + " log files");
    assertTrue(("actual count: " + count),count <= 2);
  }
  private static String getName(){
    return "TestLogRolling";
  }
  void writeData(  HTable table,  int rownum) throws IOException {
    Put put=new Put(Bytes.toBytes("row" + String.format("%1$04d",rownum)));
    put.add(HConstants.CATALOG_FAMILY,null,value);
    table.put(put);
    try {
      Thread.sleep(2000);
    }
 catch (    InterruptedException e) {
    }
  }
  void batchWriteAndWait(  HTable table,  int start,  boolean expect,  int timeout) throws IOException {
    for (int i=0; i < 10; i++) {
      Put put=new Put(Bytes.toBytes("row" + String.format("%1$04d",(start + i))));
      put.add(HConstants.CATALOG_FAMILY,null,value);
      table.put(put);
    }
    long startTime=System.currentTimeMillis();
    long remaining=timeout;
    while (remaining > 0) {
      if (log.isLowReplicationRollEnabled() == expect) {
        break;
      }
 else {
        try {
          Thread.sleep(200);
        }
 catch (        InterruptedException e) {
        }
        remaining=timeout - (System.currentTimeMillis() - startTime);
      }
    }
  }
  /** 
 * Give me the HDFS pipeline for this log file
 */
  DatanodeInfo[] getPipeline(  HLog log) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
    OutputStream stm=log.getOutputStream();
    Method getPipeline=null;
    for (    Method m : stm.getClass().getDeclaredMethods()) {
      if (m.getName().endsWith("getPipeline")) {
        getPipeline=m;
        getPipeline.setAccessible(true);
        break;
      }
    }
    assertTrue("Need DFSOutputStream.getPipeline() for this test",null != getPipeline);
    Object repl=getPipeline.invoke(stm,new Object[]{});
    return (DatanodeInfo[])repl;
  }
  /** 
 * Tests that logs are rolled upon detecting datanode death Requires an HDFS jar with HDFS-826 & syncFs() support (HDFS-200)
 * @throws IOException
 * @throws InterruptedException
 * @throws InvocationTargetException 
 * @throws IllegalAccessException
 * @throws IllegalArgumentException 
 */
  @Test public void testLogRollOnDatanodeDeath() throws IOException, InterruptedException, IllegalArgumentException, IllegalAccessException, InvocationTargetException {
    assertTrue("This test requires HLog file replication.",fs.getDefaultReplication() > 1);
    LOG.info("Replication=" + fs.getDefaultReplication());
    new HTable(TEST_UTIL.getConfiguration(),HConstants.META_TABLE_NAME);
    this.server=cluster.getRegionServer(0);
    this.log=server.getWAL();
    String tableName=getName();
    HTableDescriptor desc=new HTableDescriptor(tableName);
    desc.addFamily(new HColumnDescriptor(HConstants.CATALOG_FAMILY));
    if (admin.tableExists(tableName)) {
      admin.disableTable(tableName);
      admin.deleteTable(tableName);
    }
    admin.createTable(desc);
    HTable table=new HTable(TEST_UTIL.getConfiguration(),tableName);
    server=TEST_UTIL.getRSForFirstRegionInTable(Bytes.toBytes(tableName));
    this.log=server.getWAL();
    assertTrue("Need HDFS-826 for this test",log.canGetCurReplicas());
    assertTrue("Need append support for this test",FSUtils.isAppendSupported(TEST_UTIL.getConfiguration()));
    dfsCluster.startDataNodes(TEST_UTIL.getConfiguration(),1,true,null,null);
    dfsCluster.waitActive();
    assertTrue(dfsCluster.getDataNodes().size() >= fs.getDefaultReplication() + 1);
    writeData(table,2);
    table.setAutoFlush(true);
    long curTime=System.currentTimeMillis();
    long oldFilenum=log.getFilenum();
    assertTrue("Log should have a timestamp older than now",curTime > oldFilenum && oldFilenum != -1);
    assertTrue("The log shouldn't have rolled yet",oldFilenum == log.getFilenum());
    DatanodeInfo[] pipeline=getPipeline(log);
    assertTrue(pipeline.length == fs.getDefaultReplication());
    assertTrue(dfsCluster.stopDataNode(pipeline[0].getName()) != null);
    Thread.sleep(10000);
    writeData(table,2);
    long newFilenum=log.getFilenum();
    assertTrue("Missing datanode should've triggered a log roll",newFilenum > oldFilenum && newFilenum > curTime);
    writeData(table,3);
    assertTrue("The log should not roll again.",log.getFilenum() == newFilenum);
    assertTrue(dfsCluster.stopDataNode(pipeline[1].getName()) != null);
    Thread.sleep(10000);
    batchWriteAndWait(table,4,false,10000);
    assertTrue("LowReplication Roller should've been disabled",!log.isLowReplicationRollEnabled());
    dfsCluster.startDataNodes(TEST_UTIL.getConfiguration(),1,true,null,null);
    dfsCluster.waitActive();
    log.rollWriter(true);
    batchWriteAndWait(table,13,true,10000);
    assertTrue("New log file should have the default replication",log.getLogReplication() == fs.getDefaultReplication());
    assertTrue("LowReplication Roller should've been enabled",log.isLowReplicationRollEnabled());
  }
  /** 
 * Test that HLog is rolled when all data nodes in the pipeline have been restarted.
 * @throws Exception
 */
  @Test public void testLogRollOnPipelineRestart() throws Exception {
    LOG.info("Starting testLogRollOnPipelineRestart");
    assertTrue("This test requires HLog file replication.",fs.getDefaultReplication() > 1);
    LOG.info("Replication=" + fs.getDefaultReplication());
    new HTable(TEST_UTIL.getConfiguration(),HConstants.META_TABLE_NAME);
    this.server=cluster.getRegionServer(0);
    this.log=server.getWAL();
    String tableName=getName();
    HTableDescriptor desc=new HTableDescriptor(tableName);
    desc.addFamily(new HColumnDescriptor(HConstants.CATALOG_FAMILY));
    if (admin.tableExists(tableName)) {
      admin.disableTable(tableName);
      admin.deleteTable(tableName);
    }
    admin.createTable(desc);
    HTable table=new HTable(TEST_UTIL.getConfiguration(),tableName);
    server=TEST_UTIL.getRSForFirstRegionInTable(Bytes.toBytes(tableName));
    this.log=server.getWAL();
    final List<Path> paths=new ArrayList<Path>();
    paths.add(log.computeFilename());
    log.registerWALActionsListener(new WALObserver(){
      @Override public void logRolled(      Path newFile){
        paths.add(newFile);
      }
      @Override public void logRollRequested(){
      }
      @Override public void logCloseRequested(){
      }
      @Override public void visitLogEntryBeforeWrite(      HRegionInfo info,      HLogKey logKey,      WALEdit logEdit){
      }
    }
);
    assertTrue("Need HDFS-826 for this test",log.canGetCurReplicas());
    assertTrue("Need append support for this test",FSUtils.isAppendSupported(TEST_UTIL.getConfiguration()));
    writeData(table,1002);
    table.setAutoFlush(true);
    long curTime=System.currentTimeMillis();
    long oldFilenum=log.getFilenum();
    assertTrue("Log should have a timestamp older than now",curTime > oldFilenum && oldFilenum != -1);
    assertTrue("The log shouldn't have rolled yet",oldFilenum == log.getFilenum());
    dfsCluster.restartDataNodes();
    Thread.sleep(10000);
    dfsCluster.waitActive();
    LOG.info("Data Nodes restarted");
    writeData(table,1003);
    long newFilenum=log.getFilenum();
    assertTrue("Missing datanode should've triggered a log roll",newFilenum > oldFilenum && newFilenum > curTime);
    writeData(table,1004);
    dfsCluster.restartDataNodes();
    Thread.sleep(10000);
    dfsCluster.waitActive();
    LOG.info("Data Nodes restarted");
    writeData(table,1005);
    log.rollWriter(true);
    Set<String> loggedRows=new HashSet<String>();
    for (    Path p : paths) {
      LOG.debug("Reading HLog " + FSUtils.getPath(p));
      HLog.Reader reader=null;
      try {
        reader=HLog.getReader(fs,p,TEST_UTIL.getConfiguration());
        HLog.Entry entry;
        while ((entry=reader.next()) != null) {
          LOG.debug("#" + entry.getKey().getLogSeqNum() + ": "+ entry.getEdit().getKeyValues());
          for (          KeyValue kv : entry.getEdit().getKeyValues()) {
            loggedRows.add(Bytes.toStringBinary(kv.getRow()));
          }
        }
      }
 catch (      EOFException e) {
        LOG.debug("EOF reading file " + FSUtils.getPath(p));
      }
 finally {
        if (reader != null)         reader.close();
      }
    }
    assertTrue(loggedRows.contains("row1002"));
    assertTrue(loggedRows.contains("row1003"));
    assertTrue(loggedRows.contains("row1004"));
    assertTrue(loggedRows.contains("row1005"));
    List<HRegion> regions=new ArrayList<HRegion>(server.getOnlineRegionsLocalContext());
    for (    HRegion r : regions) {
      r.flushcache();
    }
    ResultScanner scanner=table.getScanner(new Scan());
    try {
      for (int i=2; i <= 5; i++) {
        Result r=scanner.next();
        assertNotNull(r);
        assertFalse(r.isEmpty());
        assertEquals("row100" + i,Bytes.toString(r.getRow()));
      }
    }
  finally {
      scanner.close();
    }
  }
}
