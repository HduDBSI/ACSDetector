public interface ScannerIncommon extends Iterable<Result> {
  public boolean next(  List<KeyValue> values) throws IOException ;
  public void close() throws IOException ;
}
