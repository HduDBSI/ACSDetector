/** 
 * Use a coprocessor to count puts and deletes. as KVs would be replicated back with the same timestamp there is otherwise no way to count them.
 */
public static class CoprocessorCounter extends BaseRegionObserver {
  private int nCount=0;
  private int nDelete=0;
  @Override public void prePut(  final ObserverContext<RegionCoprocessorEnvironment> e,  final Put put,  final WALEdit edit,  final boolean writeToWAL) throws IOException {
    nCount++;
  }
  @Override public void postDelete(  final ObserverContext<RegionCoprocessorEnvironment> c,  final Delete delete,  final WALEdit edit,  final boolean writeToWAL) throws IOException {
    nDelete++;
  }
  @Override public void preGet(  final ObserverContext<RegionCoprocessorEnvironment> c,  final Get get,  final List<KeyValue> result) throws IOException {
    if (get.getAttribute("count") != null) {
      result.clear();
      result.add(new KeyValue(count,count,delete,Bytes.toBytes(nDelete)));
      result.add(new KeyValue(count,count,put,Bytes.toBytes(nCount)));
      c.bypass();
    }
  }
}
