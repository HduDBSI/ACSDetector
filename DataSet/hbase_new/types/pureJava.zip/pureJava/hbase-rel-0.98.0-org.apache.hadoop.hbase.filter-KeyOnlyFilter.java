/** 
 * A filter that will only return the key component of each KV (the value will be rewritten as empty). <p> This filter can be used to grab all of the keys without having to also grab the values.
 */
@InterfaceAudience.Public @InterfaceStability.Stable public class KeyOnlyFilter extends FilterBase {
  boolean lenAsVal;
  public KeyOnlyFilter(){
    this(false);
  }
  public KeyOnlyFilter(  boolean lenAsVal){
    this.lenAsVal=lenAsVal;
  }
  @Override public Cell transformCell(  Cell kv){
    KeyValue v=KeyValueUtil.ensureKeyValue(kv);
    return v.createKeyOnly(this.lenAsVal);
  }
  public static Filter createFilterFromArguments(  ArrayList<byte[]> filterArguments){
    Preconditions.checkArgument((filterArguments.size() == 0 || filterArguments.size() == 1),"Expected: 0 or 1 but got: %s",filterArguments.size());
    KeyOnlyFilter filter=new KeyOnlyFilter();
    if (filterArguments.size() == 1) {
      filter.lenAsVal=ParseFilter.convertByteArrayToBoolean(filterArguments.get(0));
    }
    return filter;
  }
  /** 
 * @return The filter serialized using pb
 */
  public byte[] toByteArray(){
    FilterProtos.KeyOnlyFilter.Builder builder=FilterProtos.KeyOnlyFilter.newBuilder();
    builder.setLenAsVal(this.lenAsVal);
    return builder.build().toByteArray();
  }
  /** 
 * @param pbBytes A pb serialized {@link KeyOnlyFilter} instance
 * @return An instance of {@link KeyOnlyFilter} made from <code>bytes</code>
 * @throws DeserializationException
 * @see #toByteArray
 */
  public static KeyOnlyFilter parseFrom(  final byte[] pbBytes) throws DeserializationException {
    FilterProtos.KeyOnlyFilter proto;
    try {
      proto=FilterProtos.KeyOnlyFilter.parseFrom(pbBytes);
    }
 catch (    InvalidProtocolBufferException e) {
      throw new DeserializationException(e);
    }
    return new KeyOnlyFilter(proto.getLenAsVal());
  }
  /** 
 * @param other
 * @return true if and only if the fields of the filter that are serializedare equal to the corresponding fields in other.  Used for testing.
 */
  boolean areSerializedFieldsEqual(  Filter o){
    if (o == this)     return true;
    if (!(o instanceof KeyOnlyFilter))     return false;
    KeyOnlyFilter other=(KeyOnlyFilter)o;
    return this.lenAsVal == other.lenAsVal;
  }
}
