private static class RowIndexEncodingState extends EncodingState {
  RowIndexEncoderV1 encoder=null;
  @Override public void beforeShipped(){
    if (encoder != null) {
      encoder.beforeShipped();
    }
  }
}
