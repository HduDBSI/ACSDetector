/** 
 * All hbase specific IOExceptions should be subclasses of HBaseIOException
 */
@InterfaceAudience.Public public class HBaseIOException extends IOException {
  private static final long serialVersionUID=1L;
  public HBaseIOException(){
    super();
  }
  public HBaseIOException(  String message){
    super(message);
  }
  public HBaseIOException(  String message,  Throwable cause){
    super(message,cause);
  }
  public HBaseIOException(  Throwable cause){
    super(cause);
  }
}
