/** 
 * Exception thrown by access-related methods.
 */
@InterfaceAudience.Public @InterfaceStability.Evolving public class AccessDeniedException extends DoNotRetryIOException {
  private static final long serialVersionUID=1913879564363001780L;
  public AccessDeniedException(){
    super();
  }
  public AccessDeniedException(  Class<?> clazz,  String s){
    super("AccessDenied [" + clazz.getName() + "]: "+ s);
  }
  public AccessDeniedException(  String s){
    super(s);
  }
  public AccessDeniedException(  Throwable cause){
    super(cause);
  }
}
