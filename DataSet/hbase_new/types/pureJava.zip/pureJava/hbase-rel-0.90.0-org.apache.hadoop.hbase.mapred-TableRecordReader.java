/** 
 * Iterate over an HBase table data, return (Text, RowResult) pairs
 */
public class TableRecordReader implements RecordReader<ImmutableBytesWritable,Result> {
  private TableRecordReaderImpl recordReaderImpl=new TableRecordReaderImpl();
  /** 
 * Restart from survivable exceptions by creating a new scanner.
 * @param firstRow
 * @throws IOException
 */
  public void restart(  byte[] firstRow) throws IOException {
    this.recordReaderImpl.restart(firstRow);
  }
  /** 
 * Build the scanner. Not done in constructor to allow for extension.
 * @throws IOException
 */
  public void init() throws IOException {
    this.recordReaderImpl.restart(this.recordReaderImpl.getStartRow());
  }
  /** 
 * @param htable the {@link HTable} to scan.
 */
  public void setHTable(  HTable htable){
    this.recordReaderImpl.setHTable(htable);
  }
  /** 
 * @param inputColumns the columns to be placed in {@link Result}.
 */
  public void setInputColumns(  final byte[][] inputColumns){
    this.recordReaderImpl.setInputColumns(inputColumns);
  }
  /** 
 * @param startRow the first row in the split
 */
  public void setStartRow(  final byte[] startRow){
    this.recordReaderImpl.setStartRow(startRow);
  }
  /** 
 * @param endRow the last row in the split
 */
  public void setEndRow(  final byte[] endRow){
    this.recordReaderImpl.setEndRow(endRow);
  }
  /** 
 * @param rowFilter the {@link Filter} to be used.
 */
  public void setRowFilter(  Filter rowFilter){
    this.recordReaderImpl.setRowFilter(rowFilter);
  }
  public void close(){
    this.recordReaderImpl.close();
  }
  /** 
 * @return ImmutableBytesWritable
 * @see org.apache.hadoop.mapred.RecordReader#createKey()
 */
  public ImmutableBytesWritable createKey(){
    return this.recordReaderImpl.createKey();
  }
  /** 
 * @return RowResult
 * @see org.apache.hadoop.mapred.RecordReader#createValue()
 */
  public Result createValue(){
    return this.recordReaderImpl.createValue();
  }
  public long getPos(){
    return this.recordReaderImpl.getPos();
  }
  public float getProgress(){
    return this.recordReaderImpl.getPos();
  }
  /** 
 * @param key HStoreKey as input key.
 * @param value MapWritable as input value
 * @return true if there was more data
 * @throws IOException
 */
  public boolean next(  ImmutableBytesWritable key,  Result value) throws IOException {
    return this.recordReaderImpl.next(key,value);
  }
}
