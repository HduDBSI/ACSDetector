static class CorruptedLogFileException extends Exception {
  private static final long serialVersionUID=1L;
  CorruptedLogFileException(  String s){
    super(s);
  }
}
