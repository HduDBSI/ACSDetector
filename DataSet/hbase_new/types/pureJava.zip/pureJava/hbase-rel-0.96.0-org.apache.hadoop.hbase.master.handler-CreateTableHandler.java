/** 
 * Handler to create a table.
 */
@InterfaceAudience.Private public class CreateTableHandler extends EventHandler {
  private static final Log LOG=LogFactory.getLog(CreateTableHandler.class);
  protected final MasterFileSystem fileSystemManager;
  protected final HTableDescriptor hTableDescriptor;
  protected final Configuration conf;
  private final AssignmentManager assignmentManager;
  private final CatalogTracker catalogTracker;
  private final TableLockManager tableLockManager;
  private final HRegionInfo[] newRegions;
  private final TableLock tableLock;
  public CreateTableHandler(  Server server,  MasterFileSystem fileSystemManager,  HTableDescriptor hTableDescriptor,  Configuration conf,  HRegionInfo[] newRegions,  MasterServices masterServices){
    super(server,EventType.C_M_CREATE_TABLE);
    this.fileSystemManager=fileSystemManager;
    this.hTableDescriptor=hTableDescriptor;
    this.conf=conf;
    this.newRegions=newRegions;
    this.catalogTracker=masterServices.getCatalogTracker();
    this.assignmentManager=masterServices.getAssignmentManager();
    this.tableLockManager=masterServices.getTableLockManager();
    this.tableLock=this.tableLockManager.writeLock(this.hTableDescriptor.getTableName(),EventType.C_M_CREATE_TABLE.toString());
  }
  public CreateTableHandler prepare() throws NotAllMetaRegionsOnlineException, TableExistsException, IOException {
    int timeout=conf.getInt("hbase.client.catalog.timeout",10000);
    try {
      if (catalogTracker.waitForMeta(timeout) == null) {
        throw new NotAllMetaRegionsOnlineException();
      }
    }
 catch (    InterruptedException e) {
      LOG.warn("Interrupted waiting for meta availability",e);
      InterruptedIOException ie=new InterruptedIOException(e.getMessage());
      ie.initCause(e);
      throw ie;
    }
    this.tableLock.acquire();
    boolean success=false;
    try {
      TableName tableName=this.hTableDescriptor.getTableName();
      if (MetaReader.tableExists(catalogTracker,tableName)) {
        throw new TableExistsException(tableName);
      }
      try {
        if (!this.assignmentManager.getZKTable().checkAndSetEnablingTable(tableName)) {
          throw new TableExistsException(tableName);
        }
      }
 catch (      KeeperException e) {
        throw new IOException("Unable to ensure that the table will be" + " enabling because of a ZooKeeper issue",e);
      }
      success=true;
    }
  finally {
      if (!success) {
        releaseTableLock();
      }
    }
    return this;
  }
  @Override public String toString(){
    String name="UnknownServerName";
    if (server != null && server.getServerName() != null) {
      name=server.getServerName().toString();
    }
    return getClass().getSimpleName() + "-" + name+ "-"+ getSeqid()+ "-"+ this.hTableDescriptor.getTableName();
  }
  @Override public void process(){
    TableName tableName=this.hTableDescriptor.getTableName();
    LOG.info("Create table " + tableName);
    try {
      MasterCoprocessorHost cpHost=((HMaster)this.server).getCoprocessorHost();
      if (cpHost != null) {
        cpHost.preCreateTableHandler(this.hTableDescriptor,this.newRegions);
      }
      handleCreateTable(tableName);
      completed(null);
      if (cpHost != null) {
        cpHost.postCreateTableHandler(this.hTableDescriptor,this.newRegions);
      }
    }
 catch (    Throwable e) {
      LOG.error("Error trying to create the table " + tableName,e);
      completed(e);
    }
  }
  /** 
 * Called after that process() is completed.
 * @param exception null if process() is successful or not null if something has failed.
 */
  protected void completed(  final Throwable exception){
    releaseTableLock();
    if (exception != null) {
      try {
        this.assignmentManager.getZKTable().removeEnablingTable(this.hTableDescriptor.getTableName(),false);
      }
 catch (      KeeperException e) {
        LOG.error("Got a keeper exception while removing the ENABLING table znode " + this.hTableDescriptor.getTableName(),e);
      }
    }
  }
  /** 
 * Responsible of table creation (on-disk and META) and assignment. - Create the table directory and descriptor (temp folder) - Create the on-disk regions (temp folder) [If something fails here: we've just some trash in temp] - Move the table from temp to the root directory [If something fails here: we've the table in place but some of the rows required present in META. (hbck needed)] - Add regions to META [If something fails here: we don't have regions assigned: table disabled] - Assign regions to Region Servers [If something fails here: we still have the table in disabled state] - Update ZooKeeper with the enabled state
 */
  private void handleCreateTable(  TableName tableName) throws IOException, KeeperException {
    Path tempdir=fileSystemManager.getTempDir();
    FileSystem fs=fileSystemManager.getFileSystem();
    Path tempTableDir=FSUtils.getTableDir(tempdir,tableName);
    new FSTableDescriptors(this.conf).createTableDescriptorForTableDirectory(tempTableDir,this.hTableDescriptor,false);
    Path tableDir=FSUtils.getTableDir(fileSystemManager.getRootDir(),tableName);
    List<HRegionInfo> regionInfos=handleCreateHdfsRegions(tempdir,tableName);
    if (!fs.rename(tempTableDir,tableDir)) {
      throw new IOException("Unable to move table from temp=" + tempTableDir + " to hbase root="+ tableDir);
    }
    if (regionInfos != null && regionInfos.size() > 0) {
      addRegionsToMeta(this.catalogTracker,regionInfos);
      try {
        assignmentManager.getRegionStates().createRegionStates(regionInfos);
        assignmentManager.assign(regionInfos);
      }
 catch (      InterruptedException e) {
        LOG.error("Caught " + e + " during round-robin assignment");
        InterruptedIOException ie=new InterruptedIOException(e.getMessage());
        ie.initCause(e);
        throw ie;
      }
    }
    try {
      assignmentManager.getZKTable().setEnabledTable(tableName);
    }
 catch (    KeeperException e) {
      throw new IOException("Unable to ensure that " + tableName + " will be"+ " enabled because of a ZooKeeper issue",e);
    }
  }
  private void releaseTableLock(){
    if (this.tableLock != null) {
      try {
        this.tableLock.release();
      }
 catch (      IOException ex) {
        LOG.warn("Could not release the table lock",ex);
      }
    }
  }
  /** 
 * Create the on-disk structure for the table, and returns the regions info.
 * @param tableRootDir directory where the table is being created
 * @param tableName name of the table under construction
 * @return the list of regions created
 */
  protected List<HRegionInfo> handleCreateHdfsRegions(  final Path tableRootDir,  final TableName tableName) throws IOException {
    return ModifyRegionUtils.createRegions(conf,tableRootDir,hTableDescriptor,newRegions,null);
  }
  /** 
 * Add the specified set of regions to the hbase:meta table.
 */
  protected void addRegionsToMeta(  final CatalogTracker ct,  final List<HRegionInfo> regionInfos) throws IOException {
    MetaEditor.addRegionsToMeta(this.catalogTracker,regionInfos);
  }
}
