private static class ReadOwnWritesTester extends Thread {
  static final int NUM_TRIES=1000;
  final byte[] row;
  final byte[] f=Bytes.toBytes("family");
  final byte[] q1=Bytes.toBytes("q1");
  final ReadWriteConsistencyControl rwcc;
  final MemStore memstore;
  AtomicReference<Throwable> caughtException;
  public ReadOwnWritesTester(  int id,  MemStore memstore,  ReadWriteConsistencyControl rwcc,  AtomicReference<Throwable> caughtException){
    this.rwcc=rwcc;
    this.memstore=memstore;
    this.caughtException=caughtException;
    row=Bytes.toBytes(id);
  }
  public void run(){
    try {
      internalRun();
    }
 catch (    Throwable t) {
      caughtException.compareAndSet(null,t);
    }
  }
  private void internalRun() throws IOException {
    for (long i=0; i < NUM_TRIES && caughtException.get() == null; i++) {
      ReadWriteConsistencyControl.WriteEntry w=rwcc.beginMemstoreInsert();
      byte[] v=Bytes.toBytes(i);
      KeyValue kv=new KeyValue(row,f,q1,i,v);
      kv.setMemstoreTS(w.getWriteNumber());
      memstore.add(kv);
      rwcc.completeMemstoreInsert(w);
      ReadWriteConsistencyControl.resetThreadReadPoint(rwcc);
      KeyValueScanner s=this.memstore.getScanners().get(0);
      s.seek(kv);
      KeyValue ret=s.next();
      assertNotNull("Didnt find own write at all",ret);
      assertEquals("Didnt read own writes",kv.getTimestamp(),ret.getTimestamp());
    }
  }
}
