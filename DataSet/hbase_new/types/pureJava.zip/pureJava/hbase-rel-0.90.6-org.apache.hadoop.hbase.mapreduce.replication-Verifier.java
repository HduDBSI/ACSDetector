/** 
 * Map-only comparator for 2 tables
 */
public static class Verifier extends TableMapper<ImmutableBytesWritable,Put> {
  public static enum Counters {  GOODROWS,   BADROWS}
  private ResultScanner replicatedScanner;
  /** 
 * Map method that compares every scanned row with the equivalent from a distant cluster.
 * @param row  The current table row key.
 * @param value  The columns.
 * @param context  The current context.
 * @throws IOException When something is broken with the data.
 */
  @Override public void map(  ImmutableBytesWritable row,  final Result value,  Context context) throws IOException {
    if (replicatedScanner == null) {
      Configuration conf=context.getConfiguration();
      final Scan scan=new Scan();
      scan.setCaching(conf.getInt(TableInputFormat.SCAN_CACHEDROWS,1));
      long startTime=conf.getLong(NAME + ".startTime",0);
      long endTime=conf.getLong(NAME + ".endTime",0);
      String families=conf.get(NAME + ".families",null);
      if (families != null) {
        String[] fams=families.split(",");
        for (        String fam : fams) {
          scan.addFamily(Bytes.toBytes(fam));
        }
      }
      if (startTime != 0) {
        scan.setTimeRange(startTime,endTime == 0 ? HConstants.LATEST_TIMESTAMP : endTime);
      }
      HConnectionManager.execute(new HConnectable<Void>(conf){
        @Override public Void connect(        HConnection conn) throws IOException {
          try {
            ReplicationZookeeper zk=new ReplicationZookeeper(conn,conf,conn.getZooKeeperWatcher());
            ReplicationPeer peer=zk.getPeer(conf.get(NAME + ".peerId"));
            HTable replicatedTable=new HTable(peer.getConfiguration(),conf.get(NAME + ".tableName"));
            scan.setStartRow(value.getRow());
            replicatedScanner=replicatedTable.getScanner(scan);
          }
 catch (          KeeperException e) {
            throw new IOException("Got a ZK exception",e);
          }
          return null;
        }
      }
);
    }
    Result res=replicatedScanner.next();
    try {
      Result.compareResults(value,res);
      context.getCounter(Counters.GOODROWS).increment(1);
    }
 catch (    Exception e) {
      LOG.warn("Bad row",e);
      context.getCounter(Counters.BADROWS).increment(1);
    }
  }
  protected void cleanup(  Context context){
    replicatedScanner.close();
  }
}
