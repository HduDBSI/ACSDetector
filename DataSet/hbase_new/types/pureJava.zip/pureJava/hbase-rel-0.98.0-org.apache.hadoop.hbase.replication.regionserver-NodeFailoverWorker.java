/** 
 * Class responsible to setup new ReplicationSources to take care of the queues from dead region servers.
 */
class NodeFailoverWorker extends Thread {
  private String rsZnode;
  private final ReplicationQueues rq;
  private final ReplicationPeers rp;
  private final UUID clusterId;
  /** 
 * @param rsZnode
 */
  public NodeFailoverWorker(  String rsZnode,  final ReplicationQueues replicationQueues,  final ReplicationPeers replicationPeers,  final UUID clusterId){
    super("Failover-for-" + rsZnode);
    this.rsZnode=rsZnode;
    this.rq=replicationQueues;
    this.rp=replicationPeers;
    this.clusterId=clusterId;
  }
  @Override public void run(){
    if (this.rq.isThisOurZnode(rsZnode)) {
      return;
    }
    try {
      Thread.sleep(sleepBeforeFailover + (long)(rand.nextFloat() * sleepBeforeFailover));
    }
 catch (    InterruptedException e) {
      LOG.warn("Interrupted while waiting before transferring a queue.");
      Thread.currentThread().interrupt();
    }
    if (stopper.isStopped()) {
      LOG.info("Not transferring queue since we are shutting down");
      return;
    }
    SortedMap<String,SortedSet<String>> newQueues=null;
    newQueues=this.rq.claimQueues(rsZnode);
    if (newQueues.isEmpty()) {
      return;
    }
    for (    Map.Entry<String,SortedSet<String>> entry : newQueues.entrySet()) {
      String peerId=entry.getKey();
      try {
        ReplicationSourceInterface src=getReplicationSource(conf,fs,ReplicationSourceManager.this,this.rq,this.rp,stopper,peerId,this.clusterId);
        if (!this.rp.getConnectedPeers().contains((src.getPeerClusterId()))) {
          src.terminate("Recovered queue doesn't belong to any current peer");
          break;
        }
        oldsources.add(src);
        for (        String hlog : entry.getValue()) {
          src.enqueueLog(new Path(oldLogDir,hlog));
        }
        src.startup();
      }
 catch (      IOException e) {
        LOG.error("Failed creating a source",e);
      }
    }
  }
}
