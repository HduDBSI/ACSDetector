public interface BlockingInterface {
  public org.apache.hadoop.hbase.ipc.protobuf.generated.TestProtos.EmptyResponseProto ping(  com.google.protobuf.RpcController controller,  org.apache.hadoop.hbase.ipc.protobuf.generated.TestProtos.EmptyRequestProto request) throws com.google.protobuf.ServiceException ;
  public org.apache.hadoop.hbase.ipc.protobuf.generated.TestProtos.EchoResponseProto echo(  com.google.protobuf.RpcController controller,  org.apache.hadoop.hbase.ipc.protobuf.generated.TestProtos.EchoRequestProto request) throws com.google.protobuf.ServiceException ;
  public org.apache.hadoop.hbase.ipc.protobuf.generated.TestProtos.EmptyResponseProto error(  com.google.protobuf.RpcController controller,  org.apache.hadoop.hbase.ipc.protobuf.generated.TestProtos.EmptyRequestProto request) throws com.google.protobuf.ServiceException ;
}
