public static class incrementRows_call extends org.apache.thrift.async.TAsyncMethodCall {
  private List<TIncrement> increments;
  public incrementRows_call(  List<TIncrement> increments,  org.apache.thrift.async.AsyncMethodCallback<incrementRows_call> resultHandler,  org.apache.thrift.async.TAsyncClient client,  org.apache.thrift.protocol.TProtocolFactory protocolFactory,  org.apache.thrift.transport.TNonblockingTransport transport) throws org.apache.thrift.TException {
    super(client,protocolFactory,transport,resultHandler,false);
    this.increments=increments;
  }
  public void write_args(  org.apache.thrift.protocol.TProtocol prot) throws org.apache.thrift.TException {
    prot.writeMessageBegin(new org.apache.thrift.protocol.TMessage("incrementRows",org.apache.thrift.protocol.TMessageType.CALL,0));
    incrementRows_args args=new incrementRows_args();
    args.setIncrements(increments);
    args.write(prot);
    prot.writeMessageEnd();
  }
  public void getResult() throws IOError, org.apache.thrift.TException {
    if (getState() != org.apache.thrift.async.TAsyncMethodCall.State.RESPONSE_READ) {
      throw new IllegalStateException("Method call not finished!");
    }
    org.apache.thrift.transport.TMemoryInputTransport memoryTransport=new org.apache.thrift.transport.TMemoryInputTransport(getFrameBuffer().array());
    org.apache.thrift.protocol.TProtocol prot=client.getProtocolFactory().getProtocol(memoryTransport);
    (new Client(prot)).recv_incrementRows();
  }
}
