private static class SaslClientCallbackHandler implements CallbackHandler {
  private final String userName;
  private final char[] userPassword;
  public SaslClientCallbackHandler(  Token<? extends TokenIdentifier> token){
    this.userName=SaslUtil.encodeIdentifier(token.getIdentifier());
    this.userPassword=SaslUtil.encodePassword(token.getPassword());
  }
  public void handle(  Callback[] callbacks) throws UnsupportedCallbackException {
    NameCallback nc=null;
    PasswordCallback pc=null;
    RealmCallback rc=null;
    for (    Callback callback : callbacks) {
      if (callback instanceof RealmChoiceCallback) {
        continue;
      }
 else       if (callback instanceof NameCallback) {
        nc=(NameCallback)callback;
      }
 else       if (callback instanceof PasswordCallback) {
        pc=(PasswordCallback)callback;
      }
 else       if (callback instanceof RealmCallback) {
        rc=(RealmCallback)callback;
      }
 else {
        throw new UnsupportedCallbackException(callback,"Unrecognized SASL client callback");
      }
    }
    if (nc != null) {
      if (LOG.isDebugEnabled())       LOG.debug("SASL client callback: setting username: " + userName);
      nc.setName(userName);
    }
    if (pc != null) {
      if (LOG.isDebugEnabled())       LOG.debug("SASL client callback: setting userPassword");
      pc.setPassword(userPassword);
    }
    if (rc != null) {
      if (LOG.isDebugEnabled())       LOG.debug("SASL client callback: setting realm: " + rc.getDefaultText());
      rc.setText(rc.getDefaultText());
    }
  }
}
