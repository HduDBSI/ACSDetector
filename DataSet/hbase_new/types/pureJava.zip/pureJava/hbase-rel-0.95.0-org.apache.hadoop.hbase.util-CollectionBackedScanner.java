/** 
 * Utility scanner that wraps a sortable collection and serves as a KeyValueScanner.
 */
@InterfaceAudience.Private public class CollectionBackedScanner extends NonLazyKeyValueScanner {
  final private Iterable<KeyValue> data;
  final KeyValue.KVComparator comparator;
  private Iterator<KeyValue> iter;
  private KeyValue current;
  public CollectionBackedScanner(  SortedSet<KeyValue> set){
    this(set,KeyValue.COMPARATOR);
  }
  public CollectionBackedScanner(  SortedSet<KeyValue> set,  KeyValue.KVComparator comparator){
    this.comparator=comparator;
    data=set;
    init();
  }
  public CollectionBackedScanner(  List<KeyValue> list){
    this(list,KeyValue.COMPARATOR);
  }
  public CollectionBackedScanner(  List<KeyValue> list,  KeyValue.KVComparator comparator){
    Collections.sort(list,comparator);
    this.comparator=comparator;
    data=list;
    init();
  }
  public CollectionBackedScanner(  KeyValue.KVComparator comparator,  KeyValue... array){
    this.comparator=comparator;
    List<KeyValue> tmp=new ArrayList<KeyValue>(array.length);
    for (int i=0; i < array.length; ++i) {
      tmp.add(array[i]);
    }
    Collections.sort(tmp,comparator);
    data=tmp;
    init();
  }
  private void init(){
    iter=data.iterator();
    if (iter.hasNext()) {
      current=iter.next();
    }
  }
  @Override public KeyValue peek(){
    return current;
  }
  @Override public KeyValue next(){
    KeyValue oldCurrent=current;
    if (iter.hasNext()) {
      current=iter.next();
    }
 else {
      current=null;
    }
    return oldCurrent;
  }
  @Override public boolean seek(  KeyValue seekKv){
    iter=data.iterator();
    return reseek(seekKv);
  }
  @Override public boolean reseek(  KeyValue seekKv){
    while (iter.hasNext()) {
      KeyValue next=iter.next();
      int ret=comparator.compare(next,seekKv);
      if (ret >= 0) {
        current=next;
        return true;
      }
    }
    return false;
  }
  @Override public long getSequenceID(){
    return 0;
  }
  @Override public void close(){
  }
}
