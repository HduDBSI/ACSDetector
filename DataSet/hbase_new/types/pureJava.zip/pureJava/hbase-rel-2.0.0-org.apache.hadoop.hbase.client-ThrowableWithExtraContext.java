/** 
 * Datastructure that allows adding more info around Throwable incident.
 */
@InterfaceAudience.Private public static class ThrowableWithExtraContext {
  private final Throwable t;
  private final long when;
  private final String extras;
  public ThrowableWithExtraContext(  final Throwable t,  final long when,  final String extras){
    this.t=t;
    this.when=when;
    this.extras=extras;
  }
  @Override public String toString(){
    return new Date(this.when).toString() + ", " + extras+ ", "+ t.toString();
  }
}
