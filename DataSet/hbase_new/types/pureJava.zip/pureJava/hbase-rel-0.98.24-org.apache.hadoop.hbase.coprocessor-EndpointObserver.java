/** 
 * Coprocessors implement this interface to observe and mediate endpoint invocations on a region.
 */
@InterfaceAudience.LimitedPrivate(HBaseInterfaceAudience.COPROC) @InterfaceStability.Evolving public interface EndpointObserver extends Coprocessor {
  /** 
 * Called before an Endpoint service method is invoked. The request message can be altered by returning a new instance. Throwing an exception will abort the invocation. Calling  {@link org.apache.hadoop.hbase.coprocessor.ObserverContext#bypass()} has noeffect in this hook.
 * @param ctx the environment provided by the region server
 * @param service the endpoint service
 * @param methodName the invoked service method
 * @param request the request message
 * @return the possibly modified message
 * @throws IOException
 */
  Message preEndpointInvocation(  ObserverContext<RegionCoprocessorEnvironment> ctx,  Service service,  String methodName,  Message request) throws IOException ;
  /** 
 * Called after an Endpoint service method is invoked. The response message can be altered using the builder.
 * @param ctx the environment provided by the region server
 * @param service the endpoint service
 * @param methodName the invoked service method
 * @param request the request message
 * @param responseBuilder the response message builder
 * @throws IOException
 */
  void postEndpointInvocation(  ObserverContext<RegionCoprocessorEnvironment> ctx,  Service service,  String methodName,  Message request,  Message.Builder responseBuilder) throws IOException ;
}
