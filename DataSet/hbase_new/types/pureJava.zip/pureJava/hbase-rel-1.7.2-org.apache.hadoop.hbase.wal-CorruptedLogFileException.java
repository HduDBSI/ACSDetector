static class CorruptedLogFileException extends Exception {
  private static final long serialVersionUID=1L;
  CorruptedLogFileException(  String s){
    super(s);
  }
  /** 
 * CorruptedLogFileException with cause
 * @param message the message for this exception
 * @param cause the cause for this exception
 */
  CorruptedLogFileException(  String message,  Throwable cause){
    super(message,cause);
  }
}
