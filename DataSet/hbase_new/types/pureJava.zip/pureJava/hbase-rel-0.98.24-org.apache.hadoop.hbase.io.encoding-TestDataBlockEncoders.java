/** 
 * Test all of the data block encoding algorithms for correctness. Most of the class generate data which will test different branches in code.
 */
@Category(LargeTests.class) @RunWith(Parameterized.class) public class TestDataBlockEncoders {
  private static int NUMBER_OF_KV=10000;
  private static int NUM_RANDOM_SEEKS=10000;
  private static int ENCODED_DATA_OFFSET=HConstants.HFILEBLOCK_HEADER_SIZE + DataBlockEncoding.ID_SIZE;
  private RedundantKVGenerator generator=new RedundantKVGenerator();
  private Random randomizer=new Random(42l);
  private final boolean includesMemstoreTS;
  private final boolean includesTags;
  @Parameters public static Collection<Object[]> parameters(){
    return HBaseTestingUtility.MEMSTORETS_TAGS_PARAMETRIZED;
  }
  public TestDataBlockEncoders(  boolean includesMemstoreTS,  boolean includesTag){
    this.includesMemstoreTS=includesMemstoreTS;
    this.includesTags=includesTag;
  }
  private HFileBlockEncodingContext getEncodingContext(  Compression.Algorithm algo,  DataBlockEncoding encoding){
    DataBlockEncoder encoder=encoding.getEncoder();
    HFileContext meta=new HFileContextBuilder().withHBaseCheckSum(false).withIncludesMvcc(includesMemstoreTS).withIncludesTags(includesTags).withCompression(algo).build();
    if (encoder != null) {
      return encoder.newDataBlockEncodingContext(encoding,HConstants.HFILEBLOCK_DUMMY_HEADER,meta);
    }
 else {
      return new HFileBlockDefaultEncodingContext(encoding,HConstants.HFILEBLOCK_DUMMY_HEADER,meta);
    }
  }
  private byte[] encodeBytes(  DataBlockEncoding encoding,  ByteBuffer dataset) throws IOException {
    DataBlockEncoder encoder=encoding.getEncoder();
    HFileBlockEncodingContext encodingCtx=getEncodingContext(Compression.Algorithm.NONE,encoding);
    encoder.encodeKeyValues(dataset,encodingCtx);
    byte[] encodedBytesWithHeader=encodingCtx.getUncompressedBytesWithHeader();
    byte[] encodedData=new byte[encodedBytesWithHeader.length - ENCODED_DATA_OFFSET];
    System.arraycopy(encodedBytesWithHeader,ENCODED_DATA_OFFSET,encodedData,0,encodedData.length);
    return encodedData;
  }
  private void testAlgorithm(  ByteBuffer dataset,  DataBlockEncoding encoding,  List<KeyValue> kvList) throws IOException {
    byte[] encodedBytes=encodeBytes(encoding,dataset);
    ByteArrayInputStream bais=new ByteArrayInputStream(encodedBytes);
    DataInputStream dis=new DataInputStream(bais);
    ByteBuffer actualDataset;
    DataBlockEncoder encoder=encoding.getEncoder();
    HFileContext meta=new HFileContextBuilder().withHBaseCheckSum(false).withIncludesMvcc(includesMemstoreTS).withIncludesTags(includesTags).withCompression(Compression.Algorithm.NONE).build();
    actualDataset=encoder.decodeKeyValues(dis,encoder.newDataBlockDecodingContext(meta));
    dataset.rewind();
    actualDataset.rewind();
    assertEquals("Encoding -> decoding gives different results for " + encoder,Bytes.toStringBinary(dataset),Bytes.toStringBinary(actualDataset));
  }
  /** 
 * Test data block encoding of empty KeyValue.
 * @throws IOException On test failure.
 */
  @Test public void testEmptyKeyValues() throws IOException {
    List<KeyValue> kvList=new ArrayList<KeyValue>();
    byte[] row=new byte[0];
    byte[] family=new byte[0];
    byte[] qualifier=new byte[0];
    byte[] value=new byte[0];
    if (!includesTags) {
      kvList.add(new KeyValue(row,family,qualifier,0l,value));
      kvList.add(new KeyValue(row,family,qualifier,0l,value));
    }
 else {
      byte[] metaValue1=Bytes.toBytes("metaValue1");
      byte[] metaValue2=Bytes.toBytes("metaValue2");
      kvList.add(new KeyValue(row,family,qualifier,0l,value,new Tag[]{new Tag((byte)1,metaValue1)}));
      kvList.add(new KeyValue(row,family,qualifier,0l,value,new Tag[]{new Tag((byte)1,metaValue2)}));
    }
    testEncodersOnDataset(RedundantKVGenerator.convertKvToByteBuffer(kvList,includesMemstoreTS),kvList);
  }
  /** 
 * Test KeyValues with negative timestamp.
 * @throws IOException On test failure.
 */
  @Test public void testNegativeTimestamps() throws IOException {
    List<KeyValue> kvList=new ArrayList<KeyValue>();
    byte[] row=new byte[0];
    byte[] family=new byte[0];
    byte[] qualifier=new byte[0];
    byte[] value=new byte[0];
    if (includesTags) {
      byte[] metaValue1=Bytes.toBytes("metaValue1");
      byte[] metaValue2=Bytes.toBytes("metaValue2");
      kvList.add(new KeyValue(row,family,qualifier,0l,value,new Tag[]{new Tag((byte)1,metaValue1)}));
      kvList.add(new KeyValue(row,family,qualifier,0l,value,new Tag[]{new Tag((byte)1,metaValue2)}));
    }
 else {
      kvList.add(new KeyValue(row,family,qualifier,-1l,Type.Put,value));
      kvList.add(new KeyValue(row,family,qualifier,-2l,Type.Put,value));
    }
    testEncodersOnDataset(RedundantKVGenerator.convertKvToByteBuffer(kvList,includesMemstoreTS),kvList);
  }
  /** 
 * Test whether compression -> decompression gives the consistent results on pseudorandom sample.
 * @throws IOException On test failure.
 */
  @Test public void testExecutionOnSample() throws IOException {
    List<KeyValue> kvList=generator.generateTestKeyValues(NUMBER_OF_KV,includesTags);
    testEncodersOnDataset(RedundantKVGenerator.convertKvToByteBuffer(kvList,includesMemstoreTS),kvList);
  }
  /** 
 * Test seeking while file is encoded.
 */
  @Test public void testSeekingOnSample() throws IOException {
    List<KeyValue> sampleKv=generator.generateTestKeyValues(NUMBER_OF_KV,includesTags);
    ByteBuffer originalBuffer=RedundantKVGenerator.convertKvToByteBuffer(sampleKv,includesMemstoreTS);
    List<DataBlockEncoder.EncodedSeeker> encodedSeekers=new ArrayList<DataBlockEncoder.EncodedSeeker>();
    for (    DataBlockEncoding encoding : DataBlockEncoding.values()) {
      if (encoding.getEncoder() == null) {
        continue;
      }
      ByteBuffer encodedBuffer=ByteBuffer.wrap(encodeBytes(encoding,originalBuffer));
      DataBlockEncoder encoder=encoding.getEncoder();
      HFileContext meta=new HFileContextBuilder().withHBaseCheckSum(false).withIncludesMvcc(includesMemstoreTS).withIncludesTags(includesTags).withCompression(Compression.Algorithm.NONE).build();
      DataBlockEncoder.EncodedSeeker seeker=encoder.createSeeker(KeyValue.COMPARATOR,encoder.newDataBlockDecodingContext(meta));
      seeker.setCurrentBuffer(encodedBuffer);
      encodedSeekers.add(seeker);
    }
    for (    boolean seekBefore : new boolean[]{false,true}) {
      for (int i=0; i < NUM_RANDOM_SEEKS; ++i) {
        int keyValueId;
        if (!seekBefore) {
          keyValueId=randomizer.nextInt(sampleKv.size());
        }
 else {
          keyValueId=randomizer.nextInt(sampleKv.size() - 1) + 1;
        }
        KeyValue keyValue=sampleKv.get(keyValueId);
        checkSeekingConsistency(encodedSeekers,seekBefore,keyValue);
      }
    }
    checkSeekingConsistency(encodedSeekers,false,sampleKv.get(0));
    for (    boolean seekBefore : new boolean[]{false,true}) {
      checkSeekingConsistency(encodedSeekers,seekBefore,sampleKv.get(sampleKv.size() - 1));
      KeyValue midKv=sampleKv.get(sampleKv.size() / 2);
      KeyValue lastMidKv=midKv.createLastOnRowCol();
      checkSeekingConsistency(encodedSeekers,seekBefore,lastMidKv);
    }
  }
  @Test public void testNextOnSample(){
    List<KeyValue> sampleKv=generator.generateTestKeyValues(NUMBER_OF_KV,includesTags);
    ByteBuffer originalBuffer=RedundantKVGenerator.convertKvToByteBuffer(sampleKv,includesMemstoreTS);
    for (    DataBlockEncoding encoding : DataBlockEncoding.values()) {
      if (encoding.getEncoder() == null) {
        continue;
      }
      DataBlockEncoder encoder=encoding.getEncoder();
      ByteBuffer encodedBuffer=null;
      try {
        encodedBuffer=ByteBuffer.wrap(encodeBytes(encoding,originalBuffer));
      }
 catch (      IOException e) {
        throw new RuntimeException(String.format("Bug while encoding using '%s'",encoder.toString()),e);
      }
      HFileContext meta=new HFileContextBuilder().withHBaseCheckSum(false).withIncludesMvcc(includesMemstoreTS).withIncludesTags(includesTags).withCompression(Compression.Algorithm.NONE).build();
      DataBlockEncoder.EncodedSeeker seeker=encoder.createSeeker(KeyValue.COMPARATOR,encoder.newDataBlockDecodingContext(meta));
      seeker.setCurrentBuffer(encodedBuffer);
      int i=0;
      do {
        KeyValue expectedKeyValue=sampleKv.get(i);
        KeyValue keyValue=seeker.getKeyValue();
        if (0 != Bytes.compareTo(keyValue.getBuffer(),keyValue.getOffset(),keyValue.getLength(),expectedKeyValue.getBuffer(),expectedKeyValue.getOffset(),expectedKeyValue.getLength())) {
          int commonPrefix=0;
          byte[] left=keyValue.getBuffer();
          byte[] right=expectedKeyValue.getBuffer();
          int leftOff=keyValue.getOffset();
          int rightOff=expectedKeyValue.getOffset();
          int length=Math.min(keyValue.getLength(),expectedKeyValue.getLength());
          while (commonPrefix < length && left[commonPrefix + leftOff] == right[commonPrefix + rightOff]) {
            commonPrefix++;
          }
          fail(String.format("next() produces wrong results " + "encoder: %s i: %d commonPrefix: %d" + "\n expected %s\n actual   %s",encoder.toString(),i,commonPrefix,Bytes.toStringBinary(expectedKeyValue.getBuffer(),expectedKeyValue.getOffset(),expectedKeyValue.getLength()),Bytes.toStringBinary(keyValue.getBuffer())));
        }
        i++;
      }
 while (seeker.next());
    }
  }
  /** 
 * Test whether the decompression of first key is implemented correctly.
 */
  @Test public void testFirstKeyInBlockOnSample(){
    List<KeyValue> sampleKv=generator.generateTestKeyValues(NUMBER_OF_KV,includesTags);
    ByteBuffer originalBuffer=RedundantKVGenerator.convertKvToByteBuffer(sampleKv,includesMemstoreTS);
    for (    DataBlockEncoding encoding : DataBlockEncoding.values()) {
      if (encoding.getEncoder() == null) {
        continue;
      }
      DataBlockEncoder encoder=encoding.getEncoder();
      ByteBuffer encodedBuffer=null;
      try {
        encodedBuffer=ByteBuffer.wrap(encodeBytes(encoding,originalBuffer));
      }
 catch (      IOException e) {
        throw new RuntimeException(String.format("Bug while encoding using '%s'",encoder.toString()),e);
      }
      ByteBuffer keyBuffer=encoder.getFirstKeyInBlock(encodedBuffer);
      KeyValue firstKv=sampleKv.get(0);
      if (0 != Bytes.compareTo(keyBuffer.array(),keyBuffer.arrayOffset(),keyBuffer.limit(),firstKv.getBuffer(),firstKv.getKeyOffset(),firstKv.getKeyLength())) {
        int commonPrefix=0;
        int length=Math.min(keyBuffer.limit(),firstKv.getKeyLength());
        while (commonPrefix < length && keyBuffer.array()[keyBuffer.arrayOffset() + commonPrefix] == firstKv.getBuffer()[firstKv.getKeyOffset() + commonPrefix]) {
          commonPrefix++;
        }
        fail(String.format("Bug in '%s' commonPrefix %d",encoder.toString(),commonPrefix));
      }
    }
  }
  private void checkSeekingConsistency(  List<DataBlockEncoder.EncodedSeeker> encodedSeekers,  boolean seekBefore,  KeyValue keyValue){
    KeyValue expectedKeyValue=null;
    ByteBuffer expectedKey=null;
    ByteBuffer expectedValue=null;
    for (    DataBlockEncoder.EncodedSeeker seeker : encodedSeekers) {
      seeker.seekToKeyInBlock(keyValue.getBuffer(),keyValue.getKeyOffset(),keyValue.getKeyLength(),seekBefore);
      seeker.rewind();
      KeyValue actualKeyValue=seeker.getKeyValue();
      ByteBuffer actualKey=seeker.getKeyDeepCopy();
      ByteBuffer actualValue=seeker.getValueShallowCopy();
      if (expectedKeyValue != null) {
        assertEquals(expectedKeyValue,actualKeyValue);
      }
 else {
        expectedKeyValue=actualKeyValue;
      }
      if (expectedKey != null) {
        assertEquals(expectedKey,actualKey);
      }
 else {
        expectedKey=actualKey;
      }
      if (expectedValue != null) {
        assertEquals(expectedValue,actualValue);
      }
 else {
        expectedValue=actualValue;
      }
    }
  }
  private void testEncodersOnDataset(  ByteBuffer onDataset,  List<KeyValue> kvList) throws IOException {
    ByteBuffer dataset=ByteBuffer.allocate(onDataset.capacity());
    onDataset.rewind();
    dataset.put(onDataset);
    onDataset.rewind();
    dataset.flip();
    for (    DataBlockEncoding encoding : DataBlockEncoding.values()) {
      if (encoding.getEncoder() == null) {
        continue;
      }
      testAlgorithm(dataset,encoding,kvList);
      dataset.rewind();
      assertEquals("Input of two methods is changed",onDataset,dataset);
    }
  }
  @Test public void testZeroByte() throws IOException {
    List<KeyValue> kvList=new ArrayList<KeyValue>();
    byte[] row=Bytes.toBytes("abcd");
    byte[] family=new byte[]{'f'};
    byte[] qualifier0=new byte[]{'b'};
    byte[] qualifier1=new byte[]{'c'};
    byte[] value0=new byte[]{'d'};
    byte[] value1=new byte[]{0x00};
    if (includesTags) {
      kvList.add(new KeyValue(row,family,qualifier0,0,value0,new Tag[]{new Tag((byte)1,"value1")}));
      kvList.add(new KeyValue(row,family,qualifier1,0,value1,new Tag[]{new Tag((byte)1,"value1")}));
    }
 else {
      kvList.add(new KeyValue(row,family,qualifier0,0,Type.Put,value0));
      kvList.add(new KeyValue(row,family,qualifier1,0,Type.Put,value1));
    }
    testEncodersOnDataset(RedundantKVGenerator.convertKvToByteBuffer(kvList,includesMemstoreTS),kvList);
  }
}
