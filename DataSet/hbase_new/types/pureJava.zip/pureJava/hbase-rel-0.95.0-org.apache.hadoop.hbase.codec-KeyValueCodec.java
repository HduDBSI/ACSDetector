/** 
 * Codec that does KeyValue version 1 serialization. <p>Encodes by casting Cell to KeyValue and writing out the backing array with a length prefix. This is how KVs were serialized in Puts, Deletes and Results pre-0.96.  Its what would happen if you called the Writable#write KeyValue implementation.  This encoder will fail if the passed Cell is not an old-school pre-0.96 KeyValue.  Does not copy bytes writing. It just writes them direct to the passed stream. <p>If you wrote two KeyValues to this encoder, it would look like this in the stream: <pre> length-of-KeyValue1 // A java int with the length of KeyValue1 backing array KeyValue1 backing array filled with a KeyValue serialized in its particular format length-of-KeyValue2 KeyValue2 backing array </pre>
 */
public class KeyValueCodec implements Codec {
static class KeyValueEncoder extends BaseEncoder {
    KeyValueEncoder(    final OutputStream out){
      super(out);
    }
    @Override public void write(    Cell cell) throws IOException {
      checkFlushed();
      try {
        KeyValue.oswrite((KeyValue)KeyValueUtil.ensureKeyValue(cell),this.out);
      }
 catch (      IOException e) {
        throw new CodecException(e);
      }
    }
  }
static class KeyValueDecoder extends BaseDecoder {
    KeyValueDecoder(    final InputStream in){
      super(in);
    }
    protected Cell parseCell() throws IOException {
      return KeyValue.iscreate(in);
    }
  }
  /** 
 * Implementation depends on  {@link InputStream#available()}
 */
  @Override public Decoder getDecoder(  final InputStream is){
    return new KeyValueDecoder(is);
  }
  @Override public Encoder getEncoder(  OutputStream os){
    return new KeyValueEncoder(os);
  }
}
