public class KeyValueTestUtil {
  public static KeyValue create(  String row,  String family,  String qualifier,  long timestamp,  String value){
    return create(row,family,qualifier,timestamp,KeyValue.Type.Put,value);
  }
  public static KeyValue create(  String row,  String family,  String qualifier,  long timestamp,  KeyValue.Type type,  String value){
    return new KeyValue(Bytes.toBytes(row),Bytes.toBytes(family),Bytes.toBytes(qualifier),timestamp,type,Bytes.toBytes(value));
  }
}
