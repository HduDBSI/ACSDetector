/** 
 * Maintain information about a particular table.
 */
private class TInfo {
  String tableName;
  TreeSet<HServerAddress> deployedOn;
  final List<HbckInfo> backwards=new ArrayList<HbckInfo>();
  final RegionSplitCalculator<HbckInfo> sc=new RegionSplitCalculator<HbckInfo>(cmp);
  final Multimap<byte[],HbckInfo> overlapGroups=TreeMultimap.create(RegionSplitCalculator.BYTES_COMPARATOR,cmp);
  TInfo(  String name){
    this.tableName=name;
    deployedOn=new TreeSet<HServerAddress>();
  }
  public void addRegionInfo(  HbckInfo hir){
    if (Bytes.equals(hir.getEndKey(),HConstants.EMPTY_END_ROW)) {
      sc.add(hir);
      return;
    }
    if (Bytes.compareTo(hir.getStartKey(),hir.getEndKey()) > 0) {
      errors.reportError(ERROR_CODE.REGION_CYCLE,String.format("The endkey for this region comes before the " + "startkey, startkey=%s, endkey=%s",Bytes.toStringBinary(hir.getStartKey()),Bytes.toStringBinary(hir.getEndKey())),this,hir);
      backwards.add(hir);
      return;
    }
    sc.add(hir);
  }
  public void addServer(  HServerAddress server){
    this.deployedOn.add(server);
  }
  public String getName(){
    return tableName;
  }
  public int getNumRegions(){
    return sc.getStarts().size() + backwards.size();
  }
  /** 
 * Check the region chain (from META) of this table.  We are looking for holes, overlaps, and cycles.
 * @return false if there are errors
 */
  public boolean checkRegionChain(){
    int originalErrorsCount=errors.getErrorList().size();
    Multimap<byte[],HbckInfo> regions=sc.calcCoverage();
    SortedSet<byte[]> splits=sc.getSplits();
    byte[] prevKey=null;
    byte[] problemKey=null;
    for (    byte[] key : splits) {
      Collection<HbckInfo> ranges=regions.get(key);
      if (prevKey == null && !Bytes.equals(key,HConstants.EMPTY_BYTE_ARRAY)) {
        for (        HbckInfo rng : ranges) {
          errors.reportError(ERROR_CODE.FIRST_REGION_STARTKEY_NOT_EMPTY,"First region should start with an empty key.  You need to " + " create a new region and regioninfo in HDFS to plug the hole.",this,rng);
        }
      }
      for (      HbckInfo rng : ranges) {
        byte[] endKey=rng.getEndKey();
        endKey=(endKey.length == 0) ? null : endKey;
        if (Bytes.equals(rng.getStartKey(),endKey)) {
          errors.reportError(ERROR_CODE.DEGENERATE_REGION,"Region has the same start and end key.",this,rng);
        }
      }
      if (ranges.size() == 1) {
        if (problemKey != null) {
          LOG.warn("reached end of problem group: " + Bytes.toStringBinary(key));
        }
        problemKey=null;
      }
 else       if (ranges.size() > 1) {
        if (problemKey == null) {
          LOG.warn("Naming new problem group: " + Bytes.toStringBinary(key));
          problemKey=key;
        }
        overlapGroups.putAll(problemKey,ranges);
        ArrayList<HbckInfo> subRange=new ArrayList<HbckInfo>(ranges);
        for (        HbckInfo r1 : ranges) {
          subRange.remove(r1);
          for (          HbckInfo r2 : subRange) {
            if (Bytes.compareTo(r1.getStartKey(),r2.getStartKey()) == 0) {
              errors.reportError(ERROR_CODE.DUPE_STARTKEYS,"Multiple regions have the same startkey: " + Bytes.toStringBinary(key),this,r1);
              errors.reportError(ERROR_CODE.DUPE_STARTKEYS,"Multiple regions have the same startkey: " + Bytes.toStringBinary(key),this,r2);
            }
 else {
              errors.reportError(ERROR_CODE.OVERLAP_IN_REGION_CHAIN,"There is an overlap in the region chain.",this,r1);
            }
          }
        }
      }
 else       if (ranges.size() == 0) {
        if (problemKey != null) {
          LOG.warn("reached end of problem group: " + Bytes.toStringBinary(key));
        }
        problemKey=null;
        byte[] holeStopKey=sc.getSplits().higher(key);
        if (holeStopKey != null) {
          errors.reportError(ERROR_CODE.HOLE_IN_REGION_CHAIN,"There is a hole in the region chain between " + Bytes.toStringBinary(key) + " and "+ Bytes.toStringBinary(holeStopKey)+ ".  You need to create a new regioninfo and region "+ "dir in hdfs to plug the hole.");
        }
      }
      prevKey=key;
    }
    if (details) {
      System.out.println("---- Table '" + this.tableName + "': region split map");
      dump(splits,regions);
      System.out.println("---- Table '" + this.tableName + "': overlap groups");
      dumpOverlapProblems(overlapGroups);
      System.out.println("There are " + overlapGroups.keySet().size() + " overlap groups with "+ overlapGroups.size()+ " overlapping regions");
    }
    return errors.getErrorList().size() == originalErrorsCount;
  }
  /** 
 * This dumps data in a visually reasonable way for visual debugging
 * @param splits
 * @param regions
 */
  void dump(  SortedSet<byte[]> splits,  Multimap<byte[],HbckInfo> regions){
    for (    byte[] k : splits) {
      System.out.print(Bytes.toStringBinary(k) + ":\t");
      for (      HbckInfo r : regions.get(k)) {
        System.out.print("[ " + r.toString() + ", "+ Bytes.toStringBinary(r.getEndKey())+ "]\t");
      }
      System.out.println();
    }
  }
}
