/** 
 * A filter that will only return the first KV from each row. <p> This filter can be used to more efficiently perform row count operations.
 */
public class FirstKeyOnlyFilter extends FilterBase {
  private boolean foundKV=false;
  public FirstKeyOnlyFilter(){
  }
  public void reset(){
    foundKV=false;
  }
  public ReturnCode filterKeyValue(  KeyValue v){
    if (foundKV)     return ReturnCode.NEXT_ROW;
    foundKV=true;
    return ReturnCode.INCLUDE;
  }
  public static Filter createFilterFromArguments(  ArrayList<byte[]> filterArguments){
    Preconditions.checkArgument(filterArguments.size() == 0,"Expected 0 but got: %s",filterArguments.size());
    return new FirstKeyOnlyFilter();
  }
  public void write(  DataOutput out) throws IOException {
  }
  public void readFields(  DataInput in) throws IOException {
  }
}
