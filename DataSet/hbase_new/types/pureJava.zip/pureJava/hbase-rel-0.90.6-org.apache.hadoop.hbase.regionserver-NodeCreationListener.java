public static class NodeCreationListener extends ZooKeeperListener {
  private static final Log LOG=LogFactory.getLog(NodeCreationListener.class);
  private Semaphore lock;
  private String node;
  public NodeCreationListener(  ZooKeeperWatcher watcher,  String node){
    super(watcher);
    lock=new Semaphore(0);
    this.node=node;
  }
  @Override public void nodeCreated(  String path){
    if (path.equals(node)) {
      LOG.debug("nodeCreated(" + path + ")");
      lock.release();
    }
  }
  public void waitForCreation() throws InterruptedException {
    lock.acquire();
  }
}
