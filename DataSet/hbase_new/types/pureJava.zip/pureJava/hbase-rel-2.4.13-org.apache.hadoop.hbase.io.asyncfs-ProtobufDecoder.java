/** 
 * Modified based on io.netty.handler.codec.protobuf.ProtobufDecoder. The Netty's ProtobufDecode supports unshaded protobuf messages (com.google.protobuf). Hadoop 3.3.0 and above relocates protobuf classes to a shaded jar (hadoop-thirdparty), and so we must use reflection to detect which one (relocated or not) to use. Do not use this to process HBase's shaded protobuf messages. This is meant to process the protobuf messages in HDFS for the asyncfs use case.
 */
@InterfaceAudience.Private public class ProtobufDecoder extends MessageToMessageDecoder<ByteBuf> {
  private static final Logger LOG=LoggerFactory.getLogger(ProtobufDecoder.class);
  private static Class<?> protobufMessageLiteClass=null;
  private static Class<?> protobufMessageLiteBuilderClass=null;
  private static final boolean HAS_PARSER;
  private static Method getParserForTypeMethod;
  private static Method newBuilderForTypeMethod;
  private Method parseFromMethod;
  private Method mergeFromMethod;
  private Method buildMethod;
  private Object parser;
  private Object builder;
  public ProtobufDecoder(  Object prototype){
    try {
      Method getDefaultInstanceForTypeMethod=protobufMessageLiteClass.getMethod("getDefaultInstanceForType");
      Object prototype1=getDefaultInstanceForTypeMethod.invoke(ObjectUtil.checkNotNull(prototype,"prototype"));
      parser=getParserForTypeMethod.invoke(prototype1);
      parseFromMethod=parser.getClass().getMethod("parseFrom",byte[].class,int.class,int.class);
      builder=newBuilderForTypeMethod.invoke(prototype1);
      mergeFromMethod=builder.getClass().getMethod("mergeFrom",byte[].class,int.class,int.class);
      buildMethod=protobufMessageLiteBuilderClass.getDeclaredMethod("build");
    }
 catch (    IllegalAccessException|NoSuchMethodException e) {
      throw new RuntimeException(e);
    }
catch (    InvocationTargetException e) {
      throw new RuntimeException(e.getTargetException());
    }
  }
  protected void decode(  ChannelHandlerContext ctx,  ByteBuf msg,  List<Object> out) throws Exception {
    int length=msg.readableBytes();
    byte[] array;
    int offset;
    if (msg.hasArray()) {
      array=msg.array();
      offset=msg.arrayOffset() + msg.readerIndex();
    }
 else {
      array=ByteBufUtil.getBytes(msg,msg.readerIndex(),length,false);
      offset=0;
    }
    Object addObj;
    if (HAS_PARSER) {
      addObj=parseFromMethod.invoke(parser,array,offset,length);
    }
 else {
      Object builderObj=mergeFromMethod.invoke(builder,array,offset,length);
      addObj=buildMethod.invoke(builderObj);
    }
    out.add(addObj);
  }
static {
    boolean hasParser=false;
    protobufMessageLiteClass=com.google.protobuf.MessageLite.class;
    protobufMessageLiteBuilderClass=com.google.protobuf.MessageLite.Builder.class;
    try {
      protobufMessageLiteClass=Class.forName("org.apache.hadoop.thirdparty.protobuf.MessageLite");
      protobufMessageLiteBuilderClass=Class.forName("org.apache.hadoop.thirdparty.protobuf.MessageLite$Builder");
      LOG.debug("Hadoop 3.3 and above shades protobuf.");
    }
 catch (    ClassNotFoundException e) {
      LOG.debug("Hadoop 3.2 and below use unshaded protobuf.",e);
    }
    try {
      getParserForTypeMethod=protobufMessageLiteClass.getDeclaredMethod("getParserForType");
      newBuilderForTypeMethod=protobufMessageLiteClass.getDeclaredMethod("newBuilderForType");
      hasParser=true;
    }
 catch (    NoSuchMethodException e) {
      throw new RuntimeException(e);
    }
    HAS_PARSER=hasParser;
  }
}
