/** 
 * This comparator is for use with ColumnValueFilter, for filtering based on the value of a given column. Use it to test if a given substring appears in a cell value in the column. The comparison is case insensitive. <p> Only EQUAL or NOT_EQUAL tests are valid with this comparator. <p> For example: <p> <pre> ColumnValueFilter cvf = new ColumnValueFilter("col", ColumnValueFilter.CompareOp.EQUAL, new SubstringComparator("substr")); </pre>
 */
public class SubstringComparator extends WritableByteArrayComparable {
  private String substr;
  /** 
 * Nullary constructor for Writable, do not use 
 */
  public SubstringComparator(){
    super();
  }
  /** 
 * Constructor
 * @param substr the substring
 */
  public SubstringComparator(  String substr){
    super(Bytes.toBytes(substr.toLowerCase()));
    this.substr=substr.toLowerCase();
  }
  @Override public byte[] getValue(){
    return Bytes.toBytes(substr);
  }
  @Override public int compareTo(  byte[] value){
    return Bytes.toString(value).toLowerCase().contains(substr) ? 0 : 1;
  }
  @Override public void readFields(  DataInput in) throws IOException {
    String substr=in.readUTF();
    this.value=Bytes.toBytes(substr);
    this.substr=substr;
  }
  @Override public void write(  DataOutput out) throws IOException {
    out.writeUTF(substr);
  }
}
