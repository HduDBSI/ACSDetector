/** 
 * Interface for discrete (integer) random distributions.
 */
public static interface DiscreteRNG {
  /** 
 * Get the next random number
 * @return the next random number.
 */
  public int nextInt();
}
