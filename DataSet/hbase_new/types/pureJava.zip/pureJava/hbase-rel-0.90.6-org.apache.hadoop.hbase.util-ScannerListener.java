/** 
 * Used by scanRootRegion and scanMetaRegion to call back the caller so it can process the data for a row.
 */
public interface ScannerListener {
  /** 
 * Callback so client of scanner can process row contents
 * @param info HRegionInfo for row
 * @return false to terminate the scan
 * @throws IOException e
 */
  public boolean processRow(  HRegionInfo info) throws IOException ;
}
