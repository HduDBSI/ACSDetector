/** 
 * Publishes a string to the metrics collector
 */
public class MetricsString extends MetricsBase {
  private static final Log LOG=LogFactory.getLog("org.apache.hadoop.hbase.metrics");
  private String value;
  public MetricsString(  final String name,  final MetricsRegistry registry,  final String value){
    super(name,NO_DESCRIPTION);
    this.value=value;
    registry.add(name,this);
  }
  public MetricsString(  final String name,  final String description,  final MetricsRegistry registry,  final String value){
    super(name,description);
    this.value=value;
    registry.add(name,this);
  }
  public String getValue(){
    return this.value;
  }
  @Override public synchronized void pushMetric(  final MetricsRecord mr){
  }
}
