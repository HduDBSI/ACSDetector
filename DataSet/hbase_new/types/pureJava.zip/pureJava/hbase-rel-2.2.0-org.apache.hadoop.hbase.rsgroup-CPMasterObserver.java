public static class CPMasterObserver implements MasterCoprocessor, MasterObserver {
  boolean preBalanceRSGroupCalled=false;
  boolean postBalanceRSGroupCalled=false;
  boolean preMoveServersCalled=false;
  boolean postMoveServersCalled=false;
  boolean preMoveTablesCalled=false;
  boolean postMoveTablesCalled=false;
  boolean preAddRSGroupCalled=false;
  boolean postAddRSGroupCalled=false;
  boolean preRemoveRSGroupCalled=false;
  boolean postRemoveRSGroupCalled=false;
  boolean preRemoveServersCalled=false;
  boolean postRemoveServersCalled=false;
  boolean preMoveServersAndTables=false;
  boolean postMoveServersAndTables=false;
  public void resetFlags(){
    preBalanceRSGroupCalled=false;
    postBalanceRSGroupCalled=false;
    preMoveServersCalled=false;
    postMoveServersCalled=false;
    preMoveTablesCalled=false;
    postMoveTablesCalled=false;
    preAddRSGroupCalled=false;
    postAddRSGroupCalled=false;
    preRemoveRSGroupCalled=false;
    postRemoveRSGroupCalled=false;
    preRemoveServersCalled=false;
    postRemoveServersCalled=false;
    preMoveServersAndTables=false;
    postMoveServersAndTables=false;
  }
  @Override public Optional<MasterObserver> getMasterObserver(){
    return Optional.of(this);
  }
  @Override public void preMoveServersAndTables(  final ObserverContext<MasterCoprocessorEnvironment> ctx,  Set<Address> servers,  Set<TableName> tables,  String targetGroup) throws IOException {
    preMoveServersAndTables=true;
  }
  @Override public void postMoveServersAndTables(  final ObserverContext<MasterCoprocessorEnvironment> ctx,  Set<Address> servers,  Set<TableName> tables,  String targetGroup) throws IOException {
    postMoveServersAndTables=true;
  }
  @Override public void preRemoveServers(  final ObserverContext<MasterCoprocessorEnvironment> ctx,  Set<Address> servers) throws IOException {
    preRemoveServersCalled=true;
  }
  @Override public void postRemoveServers(  final ObserverContext<MasterCoprocessorEnvironment> ctx,  Set<Address> servers) throws IOException {
    postRemoveServersCalled=true;
  }
  @Override public void preRemoveRSGroup(  final ObserverContext<MasterCoprocessorEnvironment> ctx,  String name) throws IOException {
    preRemoveRSGroupCalled=true;
  }
  @Override public void postRemoveRSGroup(  final ObserverContext<MasterCoprocessorEnvironment> ctx,  String name) throws IOException {
    postRemoveRSGroupCalled=true;
  }
  @Override public void preAddRSGroup(  final ObserverContext<MasterCoprocessorEnvironment> ctx,  String name) throws IOException {
    preAddRSGroupCalled=true;
  }
  @Override public void postAddRSGroup(  final ObserverContext<MasterCoprocessorEnvironment> ctx,  String name) throws IOException {
    postAddRSGroupCalled=true;
  }
  @Override public void preMoveTables(  final ObserverContext<MasterCoprocessorEnvironment> ctx,  Set<TableName> tables,  String targetGroup) throws IOException {
    preMoveTablesCalled=true;
  }
  @Override public void postMoveTables(  final ObserverContext<MasterCoprocessorEnvironment> ctx,  Set<TableName> tables,  String targetGroup) throws IOException {
    postMoveTablesCalled=true;
  }
  @Override public void preMoveServers(  final ObserverContext<MasterCoprocessorEnvironment> ctx,  Set<Address> servers,  String targetGroup) throws IOException {
    preMoveServersCalled=true;
  }
  @Override public void postMoveServers(  final ObserverContext<MasterCoprocessorEnvironment> ctx,  Set<Address> servers,  String targetGroup) throws IOException {
    postMoveServersCalled=true;
  }
  @Override public void preBalanceRSGroup(  final ObserverContext<MasterCoprocessorEnvironment> ctx,  String groupName) throws IOException {
    preBalanceRSGroupCalled=true;
  }
  @Override public void postBalanceRSGroup(  final ObserverContext<MasterCoprocessorEnvironment> ctx,  String groupName,  boolean balancerRan) throws IOException {
    postBalanceRSGroupCalled=true;
  }
}
