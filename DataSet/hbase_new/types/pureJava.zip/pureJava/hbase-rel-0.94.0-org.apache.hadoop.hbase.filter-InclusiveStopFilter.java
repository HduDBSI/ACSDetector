/** 
 * A Filter that stops after the given row.  There is no "RowStopFilter" because the Scan spec allows you to specify a stop row. Use this filter to include the stop row, eg: [A,Z].
 */
public class InclusiveStopFilter extends FilterBase {
  private byte[] stopRowKey;
  private boolean done=false;
  public InclusiveStopFilter(){
    super();
  }
  public InclusiveStopFilter(  final byte[] stopRowKey){
    this.stopRowKey=stopRowKey;
  }
  public byte[] getStopRowKey(){
    return this.stopRowKey;
  }
  public boolean filterRowKey(  byte[] buffer,  int offset,  int length){
    if (buffer == null) {
      if (this.stopRowKey == null) {
        return true;
      }
      return false;
    }
    int cmp=Bytes.compareTo(stopRowKey,0,stopRowKey.length,buffer,offset,length);
    if (cmp < 0) {
      done=true;
    }
    return done;
  }
  public boolean filterAllRemaining(){
    return done;
  }
  public static Filter createFilterFromArguments(  ArrayList<byte[]> filterArguments){
    Preconditions.checkArgument(filterArguments.size() == 1,"Expected 1 but got: %s",filterArguments.size());
    byte[] stopRowKey=ParseFilter.removeQuotesFromByteArray(filterArguments.get(0));
    return new InclusiveStopFilter(stopRowKey);
  }
  public void write(  DataOutput out) throws IOException {
    Bytes.writeByteArray(out,this.stopRowKey);
  }
  public void readFields(  DataInput in) throws IOException {
    this.stopRowKey=Bytes.readByteArray(in);
  }
  @Override public String toString(){
    return this.getClass().getSimpleName() + " " + Bytes.toStringBinary(this.stopRowKey);
  }
}
