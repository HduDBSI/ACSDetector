public static class DummyCompactor extends DefaultCompactor {
  public DummyCompactor(  Configuration conf,  Store store){
    super(conf,store);
  }
}
