/** 
 * Similar to RegionException, but disables retries.
 */
@InterfaceAudience.Public public class DoNotRetryRegionException extends DoNotRetryIOException {
  private static final long serialVersionUID=6907047686199321701L;
  public DoNotRetryRegionException(){
    super();
  }
  public DoNotRetryRegionException(  String s){
    super(s);
  }
  public DoNotRetryRegionException(  Throwable cause){
    super(cause);
  }
}
