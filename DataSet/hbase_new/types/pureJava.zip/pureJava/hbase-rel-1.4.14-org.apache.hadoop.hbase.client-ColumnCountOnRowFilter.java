@InterfaceAudience.Private public final class ColumnCountOnRowFilter extends FilterBase {
  private final int limit;
  private int count=0;
  public ColumnCountOnRowFilter(  int limit){
    this.limit=limit;
  }
  @Override public ReturnCode filterKeyValue(  Cell v) throws IOException {
    count++;
    return count > limit ? ReturnCode.NEXT_ROW : ReturnCode.INCLUDE;
  }
  @Override public void reset() throws IOException {
    this.count=0;
  }
  @Override public byte[] toByteArray() throws IOException {
    return Bytes.toBytes(limit);
  }
  public static ColumnCountOnRowFilter parseFrom(  byte[] bytes) throws DeserializationException {
    return new ColumnCountOnRowFilter(Bytes.toInt(bytes));
  }
  @Override public boolean equals(  Object obj){
    if (!(obj instanceof ColumnCountOnRowFilter)) {
      return false;
    }
    if (this == obj) {
      return true;
    }
    ColumnCountOnRowFilter f=(ColumnCountOnRowFilter)obj;
    return this.limit == f.limit;
  }
  @Override public int hashCode(){
    return Objects.hash(this.limit);
  }
}
