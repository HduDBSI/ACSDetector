/** 
 * Emits sorted Puts. Reads in all Puts from passed Iterator, sorts them, then emits Puts in sorted order.  If lots of columns per row, it will use lots of memory sorting.
 * @see HFileOutputFormat
 * @see KeyValueSortReducer
 */
public class PutSortReducer extends Reducer<ImmutableBytesWritable,Put,ImmutableBytesWritable,KeyValue> {
  @Override protected void reduce(  ImmutableBytesWritable row,  java.lang.Iterable<Put> puts,  Reducer<ImmutableBytesWritable,Put,ImmutableBytesWritable,KeyValue>.Context context) throws java.io.IOException, InterruptedException {
    TreeSet<KeyValue> map=new TreeSet<KeyValue>(KeyValue.COMPARATOR);
    for (    Put p : puts) {
      for (      List<KeyValue> kvs : p.getFamilyMap().values()) {
        for (        KeyValue kv : kvs) {
          map.add(kv.clone());
        }
      }
    }
    context.setStatus("Read " + map.getClass());
    int index=0;
    for (    KeyValue kv : map) {
      context.write(row,kv);
      if (index > 0 && index % 100 == 0)       context.setStatus("Wrote " + index);
    }
  }
}
