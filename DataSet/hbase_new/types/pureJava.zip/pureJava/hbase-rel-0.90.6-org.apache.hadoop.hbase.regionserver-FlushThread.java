protected class FlushThread extends Thread {
  private volatile boolean done;
  private Throwable error=null;
  public void done(){
    done=true;
synchronized (this) {
      interrupt();
    }
  }
  public void checkNoError(){
    if (error != null) {
      assertNull(error);
    }
  }
  @Override public void run(){
    done=false;
    while (!done) {
synchronized (this) {
        try {
          wait();
        }
 catch (        InterruptedException ignored) {
          if (done) {
            break;
          }
        }
      }
      try {
        region.flushcache();
      }
 catch (      IOException e) {
        if (!done) {
          LOG.error("Error while flusing cache",e);
          error=e;
        }
        break;
      }
    }
  }
  public void flush(){
synchronized (this) {
      notify();
    }
  }
}
