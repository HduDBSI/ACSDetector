public static class TestDeleteRowCoprocessor implements RegionCoprocessor, RegionObserver {
  @Override public Optional<RegionObserver> getRegionObserver(){
    return Optional.of(this);
  }
  @Override public void preBatchMutate(  ObserverContext<RegionCoprocessorEnvironment> c,  MiniBatchOperationInProgress<Mutation> miniBatchOp) throws IOException {
    Mutation mut=miniBatchOp.getOperation(0);
    if (mut instanceof Delete) {
      List<Cell> cells=mut.getFamilyCellMap().get(test);
      Delete[] deletes=new Delete[]{new Delete(row1,cells.get(0).getTimestamp()),new Delete(row2,cells.get(0).getTimestamp())};
      LOG.info("Deleting:" + Arrays.toString(deletes));
      miniBatchOp.addOperationsFromCP(0,deletes);
    }
  }
}
