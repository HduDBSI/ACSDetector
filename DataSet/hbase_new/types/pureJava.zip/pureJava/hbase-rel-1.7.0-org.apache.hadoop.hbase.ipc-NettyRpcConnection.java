/** 
 * RPC connection implementation based on netty. <p> Most operations are executed in handlers. Netty handler is always executed in the same thread(EventLoop) so no lock is needed.
 */
@InterfaceAudience.Private class NettyRpcConnection extends RpcConnection {
  private static final Log LOG=LogFactory.getLog(NettyRpcConnection.class);
  private static final ScheduledExecutorService RELOGIN_EXECUTOR=Executors.newSingleThreadScheduledExecutor(Threads.newDaemonThreadFactory("Relogin"));
  private final NettyRpcClient rpcClient;
  private ByteBuf connectionHeaderPreamble;
  private ByteBuf connectionHeaderWithLength;
  @edu.umd.cs.findbugs.annotations.SuppressWarnings(value="IS2_INCONSISTENT_SYNC",justification="connect is also under lock as notifyOnCancel will call our action directly") private Channel channel;
  NettyRpcConnection(  NettyRpcClient rpcClient,  ConnectionId remoteId) throws IOException {
    super(rpcClient.conf,AbstractRpcClient.WHEEL_TIMER,remoteId,rpcClient.clusterId,rpcClient.userProvider.isHBaseSecurityEnabled(),rpcClient.codec,rpcClient.compressor,rpcClient.metrics);
    this.rpcClient=rpcClient;
    byte[] connectionHeaderPreamble=getConnectionHeaderPreamble();
    this.connectionHeaderPreamble=Unpooled.directBuffer(connectionHeaderPreamble.length).writeBytes(connectionHeaderPreamble);
    ConnectionHeader header=getConnectionHeader();
    this.connectionHeaderWithLength=Unpooled.directBuffer(4 + header.getSerializedSize());
    this.connectionHeaderWithLength.writeInt(header.getSerializedSize());
    header.writeTo(new ByteBufOutputStream(this.connectionHeaderWithLength));
  }
  @Override protected synchronized void callTimeout(  Call call){
    if (channel != null) {
      channel.pipeline().fireUserEventTriggered(new CallEvent(TIMEOUT,call));
    }
  }
  @Override public synchronized boolean isActive(){
    return channel != null;
  }
  private void shutdown0(){
    if (channel != null) {
      channel.close();
      channel=null;
    }
  }
  @Override public synchronized void shutdown(){
    shutdown0();
  }
  @Override public synchronized void cleanupConnection(){
    if (connectionHeaderPreamble != null) {
      ReferenceCountUtil.safeRelease(connectionHeaderPreamble);
    }
    if (connectionHeaderWithLength != null) {
      ReferenceCountUtil.safeRelease(connectionHeaderWithLength);
    }
  }
  private void established(  Channel ch){
    ch.write(connectionHeaderWithLength.retainedDuplicate());
    ChannelPipeline p=ch.pipeline();
    String addBeforeHandler=p.context(BufferCallBeforeInitHandler.class).name();
    p.addBefore(addBeforeHandler,null,new IdleStateHandler(0,rpcClient.minIdleTimeBeforeClose,0,TimeUnit.MILLISECONDS));
    p.addBefore(addBeforeHandler,null,new LengthFieldBasedFrameDecoder(Integer.MAX_VALUE,0,4));
    p.addBefore(addBeforeHandler,null,new NettyRpcDuplexHandler(this,rpcClient.cellBlockBuilder,codec,compressor));
    p.fireUserEventTriggered(BufferCallEvent.success());
  }
  private boolean reloginInProgress;
  private void scheduleRelogin(  Throwable error){
    if (error instanceof FallbackDisallowedException) {
      return;
    }
synchronized (this) {
      if (reloginInProgress) {
        return;
      }
      reloginInProgress=true;
      RELOGIN_EXECUTOR.schedule(new Runnable(){
        @Override public void run(){
          try {
            if (shouldAuthenticateOverKrb()) {
              relogin();
            }
          }
 catch (          IOException e) {
            LOG.warn("relogin failed",e);
          }
synchronized (this) {
            reloginInProgress=false;
          }
        }
      }
,ThreadLocalRandom.current().nextInt(reloginMaxBackoff),TimeUnit.MILLISECONDS);
    }
  }
  private void failInit(  Channel ch,  IOException e){
synchronized (this) {
      ch.pipeline().fireUserEventTriggered(BufferCallEvent.fail(e));
      shutdown0();
      return;
    }
  }
  private void saslNegotiate(  final Channel ch){
    UserGroupInformation ticket=getUGI();
    if (ticket == null) {
      failInit(ch,new FatalConnectionException("ticket/user is null"));
      return;
    }
    Promise<Boolean> saslPromise=ch.eventLoop().newPromise();
    ChannelHandler saslHandler;
    try {
      saslHandler=new NettyHBaseSaslRpcClientHandler(saslPromise,ticket,authMethod,token,serverPrincipal,rpcClient.fallbackAllowed,this.rpcClient.conf.get("hbase.rpc.protection",QualityOfProtection.AUTHENTICATION.name().toLowerCase()));
    }
 catch (    IOException e) {
      failInit(ch,e);
      return;
    }
    ch.pipeline().addFirst(new SaslChallengeDecoder(),saslHandler);
    saslPromise.addListener(new FutureListener<Boolean>(){
      @Override public void operationComplete(      Future<Boolean> future) throws Exception {
        if (future.isSuccess()) {
          ChannelPipeline p=ch.pipeline();
          p.remove(SaslChallengeDecoder.class);
          p.remove(NettyHBaseSaslRpcClientHandler.class);
          established(ch);
        }
 else {
          final Throwable error=future.cause();
          scheduleRelogin(error);
          failInit(ch,toIOE(error));
        }
      }
    }
);
  }
  private void connect() throws UnknownHostException {
    if (LOG.isDebugEnabled()) {
      LOG.debug("Connecting to " + remoteId.getAddress());
    }
    if (this.rpcClient.metrics != null) {
      this.rpcClient.metrics.incrNsLookups();
    }
    InetSocketAddress remoteAddr=remoteId.getAddress().toSocketAddress();
    if (remoteAddr.isUnresolved()) {
      if (this.rpcClient.metrics != null) {
        this.rpcClient.metrics.incrNsLookupsFailed();
      }
      throw new UnknownHostException(remoteId.getAddress() + " could not be resolved");
    }
    this.channel=new Bootstrap().group(rpcClient.group).channel(rpcClient.channelClass).option(ChannelOption.TCP_NODELAY,rpcClient.isTcpNoDelay()).option(ChannelOption.SO_KEEPALIVE,rpcClient.tcpKeepAlive).option(ChannelOption.CONNECT_TIMEOUT_MILLIS,rpcClient.connectTO).handler(new BufferCallBeforeInitHandler()).localAddress(rpcClient.localAddr).remoteAddress(remoteAddr).connect().addListener(new ChannelFutureListener(){
      @Override public void operationComplete(      ChannelFuture future) throws Exception {
        Channel ch=future.channel();
        if (!future.isSuccess()) {
          failInit(ch,toIOE(future.cause()));
          rpcClient.failedServers.addToFailedServers(remoteId.getAddress(),future.cause());
          return;
        }
        ch.writeAndFlush(connectionHeaderPreamble.retainedDuplicate());
        if (useSasl) {
          saslNegotiate(ch);
        }
 else {
          established(ch);
        }
      }
    }
).channel();
  }
  private void write(  Channel ch,  final Call call){
    ch.writeAndFlush(call).addListener(new ChannelFutureListener(){
      @Override public void operationComplete(      ChannelFuture future) throws Exception {
        if (!future.isSuccess()) {
          call.setException(toIOE(future.cause()));
        }
      }
    }
);
  }
  @Override public synchronized void sendRequest(  final Call call,  HBaseRpcController hrc) throws IOException {
    if (reloginInProgress) {
      throw new IOException("Can not send request because relogin is in progress.");
    }
    hrc.notifyOnCancel(new RpcCallback<Object>(){
      @Override public void run(      Object parameter){
        setCancelled(call);
synchronized (this) {
          if (channel != null) {
            channel.pipeline().fireUserEventTriggered(new CallEvent(CANCELLED,call));
          }
        }
      }
    }
,new CancellationCallback(){
      @Override public void run(      boolean cancelled) throws IOException {
        if (cancelled) {
          setCancelled(call);
        }
 else {
          if (channel == null) {
            connect();
          }
          scheduleTimeoutTask(call);
          final Channel ch=channel;
          if (ch.eventLoop().inEventLoop()) {
            write(ch,call);
          }
 else {
            ch.eventLoop().execute(new Runnable(){
              @Override public void run(){
                write(ch,call);
              }
            }
);
          }
        }
      }
    }
);
  }
}
