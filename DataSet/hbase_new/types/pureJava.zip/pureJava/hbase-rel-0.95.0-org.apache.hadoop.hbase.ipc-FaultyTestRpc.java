/** 
 * Delayed calls to this class throw an exception.
 */
private static class FaultyTestRpc implements TestRpc {
  @Override public TestResponse test(  Object rpcController,  TestArg arg){
    if (!arg.getDelay())     return TestResponse.newBuilder().setResponse(UNDELAYED).build();
    Delayable call=HBaseServer.getCurrentCall();
    call.startDelay(true);
    try {
      call.endDelayThrowing(new Exception("Something went wrong"));
    }
 catch (    IOException e) {
      e.printStackTrace();
    }
    return TestResponse.newBuilder().setResponse(DELAYED).build();
  }
}
