public static class ObserverC implements RegionCoprocessor, RegionObserver {
  long id;
  @Override public Optional<RegionObserver> getRegionObserver(){
    return Optional.of(this);
  }
  @Override public void postPut(  final ObserverContext<RegionCoprocessorEnvironment> c,  final Put put,  final WALEdit edit,  final Durability durability) throws IOException {
    id=System.currentTimeMillis();
    try {
      Thread.sleep(10);
    }
 catch (    InterruptedException ex) {
    }
  }
}
