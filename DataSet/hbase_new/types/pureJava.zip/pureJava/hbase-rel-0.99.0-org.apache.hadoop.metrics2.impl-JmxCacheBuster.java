/** 
 * JMX caches the beans that have been exported; even after the values are removed from hadoop's metrics system the keys and old values will still remain.  This class stops and restarts the Hadoop metrics system, forcing JMX to clear the cache of exported metrics. This class need to be in the o.a.h.metrics2.impl namespace as many of the variables/calls used are package private.
 */
@edu.umd.cs.findbugs.annotations.SuppressWarnings(value="LI_LAZY_INIT_STATIC",justification="Yeah, its weird but its what we want") @InterfaceAudience.Private public class JmxCacheBuster {
  private static final Log LOG=LogFactory.getLog(JmxCacheBuster.class);
  private static Object lock=new Object();
  private static ScheduledFuture fut=null;
  private static MetricsExecutor executor=new MetricsExecutorImpl();
  /** 
 * For JMX to forget about all previously exported metrics.
 */
  public static void clearJmxCache(){
    if (fut == null || (!fut.isDone() && fut.getDelay(TimeUnit.MILLISECONDS) > 100))     return;
synchronized (lock) {
      fut=executor.getExecutor().schedule(new JmxCacheBusterRunnable(),5,TimeUnit.SECONDS);
    }
  }
static class JmxCacheBusterRunnable implements Runnable {
    @Override public void run(){
      LOG.trace("Clearing JMX mbean cache.");
      try {
        if (DefaultMetricsSystem.instance() != null) {
          DefaultMetricsSystem.instance().stop();
          DefaultMetricsSystem.instance().start();
        }
      }
 catch (      Exception exception) {
        LOG.debug("error clearing the jmx it appears the metrics system hasn't been started",exception);
      }
    }
  }
}
