public static class getRowTs_call extends org.apache.thrift.async.TAsyncMethodCall {
  private ByteBuffer tableName;
  private ByteBuffer row;
  private long timestamp;
  private Map<ByteBuffer,ByteBuffer> attributes;
  public getRowTs_call(  ByteBuffer tableName,  ByteBuffer row,  long timestamp,  Map<ByteBuffer,ByteBuffer> attributes,  org.apache.thrift.async.AsyncMethodCallback<getRowTs_call> resultHandler,  org.apache.thrift.async.TAsyncClient client,  org.apache.thrift.protocol.TProtocolFactory protocolFactory,  org.apache.thrift.transport.TNonblockingTransport transport) throws org.apache.thrift.TException {
    super(client,protocolFactory,transport,resultHandler,false);
    this.tableName=tableName;
    this.row=row;
    this.timestamp=timestamp;
    this.attributes=attributes;
  }
  public void write_args(  org.apache.thrift.protocol.TProtocol prot) throws org.apache.thrift.TException {
    prot.writeMessageBegin(new org.apache.thrift.protocol.TMessage("getRowTs",org.apache.thrift.protocol.TMessageType.CALL,0));
    getRowTs_args args=new getRowTs_args();
    args.setTableName(tableName);
    args.setRow(row);
    args.setTimestamp(timestamp);
    args.setAttributes(attributes);
    args.write(prot);
    prot.writeMessageEnd();
  }
  public List<TRowResult> getResult() throws IOError, org.apache.thrift.TException {
    if (getState() != org.apache.thrift.async.TAsyncMethodCall.State.RESPONSE_READ) {
      throw new IllegalStateException("Method call not finished!");
    }
    org.apache.thrift.transport.TMemoryInputTransport memoryTransport=new org.apache.thrift.transport.TMemoryInputTransport(getFrameBuffer().array());
    org.apache.thrift.protocol.TProtocol prot=client.getProtocolFactory().getProtocol(memoryTransport);
    return (new Client(prot)).recv_getRowTs();
  }
}
