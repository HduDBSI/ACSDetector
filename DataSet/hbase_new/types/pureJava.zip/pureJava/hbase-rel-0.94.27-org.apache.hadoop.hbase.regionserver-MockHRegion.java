public static class MockHRegion extends HRegion {
  public MockHRegion(  Path tableDir,  HLog log,  FileSystem fs,  Configuration conf,  final HRegionInfo regionInfo,  final HTableDescriptor htd,  RegionServerServices rsServices){
    super(tableDir,log,fs,conf,regionInfo,htd,rsServices);
  }
  @Override public void releaseRowLock(  Integer lockId){
    if (testStep == TestStep.INIT) {
      super.releaseRowLock(lockId);
      return;
    }
    if (testStep == TestStep.PUT_STARTED) {
      try {
        testStep=TestStep.PUT_COMPLETED;
        super.releaseRowLock(lockId);
        latch.await();
        Thread.sleep(1000);
      }
 catch (      InterruptedException e) {
        Thread.currentThread().interrupt();
      }
    }
 else     if (testStep == TestStep.CHECKANDPUT_STARTED) {
      super.releaseRowLock(lockId);
    }
  }
  @Override public Integer getLock(  Integer lockid,  HashedBytes row,  boolean waitForLock) throws IOException {
    if (testStep == TestStep.CHECKANDPUT_STARTED) {
      latch.countDown();
    }
    return super.getLock(lockid,row,waitForLock);
  }
}
