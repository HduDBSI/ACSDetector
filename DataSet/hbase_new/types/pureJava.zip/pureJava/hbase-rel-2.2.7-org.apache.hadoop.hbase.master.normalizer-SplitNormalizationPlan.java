/** 
 * Normalization plan to split region.
 */
@InterfaceAudience.Private public class SplitNormalizationPlan implements NormalizationPlan {
  private static final Logger LOG=LoggerFactory.getLogger(SplitNormalizationPlan.class.getName());
  private RegionInfo regionInfo;
  private byte[] splitPoint;
  public SplitNormalizationPlan(  RegionInfo regionInfo,  byte[] splitPoint){
    this.regionInfo=regionInfo;
    this.splitPoint=splitPoint;
  }
  @Override public PlanType getType(){
    return PlanType.SPLIT;
  }
  public RegionInfo getRegionInfo(){
    return regionInfo;
  }
  public void setRegionInfo(  RegionInfo regionInfo){
    this.regionInfo=regionInfo;
  }
  public byte[] getSplitPoint(){
    return splitPoint;
  }
  public void setSplitPoint(  byte[] splitPoint){
    this.splitPoint=splitPoint;
  }
  @Override public String toString(){
    return "SplitNormalizationPlan{" + "regionInfo=" + regionInfo + ", splitPoint="+ Arrays.toString(splitPoint)+ '}';
  }
  /** 
 * {@inheritDoc}
 */
  @Override public void execute(  Admin admin){
    LOG.info("Executing splitting normalization plan: " + this);
    try {
      admin.splitRegionAsync(regionInfo.getRegionName()).get();
    }
 catch (    Exception ex) {
      LOG.error("Error during region split: ",ex);
    }
  }
}
