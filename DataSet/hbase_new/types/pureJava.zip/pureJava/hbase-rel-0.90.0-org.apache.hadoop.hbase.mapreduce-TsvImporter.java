/** 
 * Write table content out to files in hdfs.
 */
static class TsvImporter extends Mapper<LongWritable,Text,ImmutableBytesWritable,Put> {
  /** 
 * Timestamp for all inserted rows 
 */
  private long ts;
  /** 
 * Should skip bad lines 
 */
  private boolean skipBadLines;
  private Counter badLineCount;
  private TsvParser parser;
  @Override protected void setup(  Context context){
    Configuration conf=context.getConfiguration();
    parser=new TsvParser(conf.get(COLUMNS_CONF_KEY),conf.get(SEPARATOR_CONF_KEY,DEFAULT_SEPARATOR));
    if (parser.getRowKeyColumnIndex() == -1) {
      throw new RuntimeException("No row key column specified");
    }
    ts=System.currentTimeMillis();
    skipBadLines=context.getConfiguration().getBoolean(SKIP_LINES_CONF_KEY,true);
    badLineCount=context.getCounter("ImportTsv","Bad Lines");
  }
  /** 
 * Convert a line of TSV text into an HBase table row.
 */
  @Override public void map(  LongWritable offset,  Text value,  Context context) throws IOException {
    byte[] lineBytes=value.getBytes();
    try {
      TsvParser.ParsedLine parsed=parser.parse(lineBytes,value.getLength());
      ImmutableBytesWritable rowKey=new ImmutableBytesWritable(lineBytes,parsed.getRowKeyOffset(),parsed.getRowKeyLength());
      Put put=new Put(rowKey.copyBytes());
      for (int i=0; i < parsed.getColumnCount(); i++) {
        if (i == parser.getRowKeyColumnIndex())         continue;
        KeyValue kv=new KeyValue(lineBytes,parsed.getRowKeyOffset(),parsed.getRowKeyLength(),parser.getFamily(i),0,parser.getFamily(i).length,parser.getQualifier(i),0,parser.getQualifier(i).length,ts,KeyValue.Type.Put,lineBytes,parsed.getColumnOffset(i),parsed.getColumnLength(i));
        put.add(kv);
      }
      context.write(rowKey,put);
    }
 catch (    BadTsvLineException badLine) {
      if (skipBadLines) {
        System.err.println("Bad line at offset: " + offset.get() + ":\n"+ badLine.getMessage());
        badLineCount.increment(1);
        return;
      }
 else {
        throw new IOException(badLine);
      }
    }
catch (    InterruptedException e) {
      e.printStackTrace();
    }
  }
}
