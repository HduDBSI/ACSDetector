/** 
 * This class is for testing HCM features
 */
public class TestHCM {
  private static final Log LOG=LogFactory.getLog(TestHCM.class);
  private final static HBaseTestingUtility TEST_UTIL=new HBaseTestingUtility();
  private static final byte[] TABLE_NAME=Bytes.toBytes("test");
  private static final byte[] FAM_NAM=Bytes.toBytes("f");
  private static final byte[] ROW=Bytes.toBytes("bbb");
  @BeforeClass public static void setUpBeforeClass() throws Exception {
    TEST_UTIL.startMiniCluster(1);
  }
  @AfterClass public static void tearDownAfterClass() throws Exception {
    TEST_UTIL.shutdownMiniCluster();
  }
  /** 
 * @throws InterruptedException 
 * @throws IllegalAccessException 
 * @throws NoSuchFieldException 
 * @throws ZooKeeperConnectionException 
 * @throws IllegalArgumentException 
 * @throws SecurityException 
 * @see https://issues.apache.org/jira/browse/HBASE-2925
 */
  @Test public void testManyNewConnectionsDoesnotOOME() throws SecurityException, IllegalArgumentException, ZooKeeperConnectionException, NoSuchFieldException, IllegalAccessException, InterruptedException {
    createNewConfigurations();
  }
  private static Random _randy=new Random();
  public static void createNewConfigurations() throws SecurityException, IllegalArgumentException, NoSuchFieldException, IllegalAccessException, InterruptedException, ZooKeeperConnectionException {
    int startingHConnectionManagerCacheSize=getHConnectionManagerCacheSize();
    HConnection last=null;
    for (int i=0; i <= 100; i++) {
      Configuration configuration=HBaseConfiguration.create();
      configuration.set(HConstants.HBASE_CONNECTION_PER_CONFIG,"false");
      configuration.set("somekey",String.valueOf(_randy.nextInt()));
      System.out.println("Hash Code: " + configuration.hashCode());
      HConnection connection=HConnectionManager.getConnection(configuration);
      if (last != null) {
        if (last == connection) {
          System.out.println("!! Got same connection for once !!");
        }
      }
      configuration.set("someotherkey",String.valueOf(_randy.nextInt()));
      last=connection;
      LOG.info("Cache Size: " + getHConnectionManagerCacheSize());
      Thread.sleep(100);
    }
    int sz=getHConnectionManagerCacheSize();
    Assert.assertTrue(sz <= startingHConnectionManagerCacheSize + 1);
  }
  private static int getHConnectionManagerCacheSize() throws SecurityException, NoSuchFieldException, IllegalArgumentException, IllegalAccessException {
    Field cacheField=HConnectionManager.class.getDeclaredField("HBASE_INSTANCES");
    cacheField.setAccessible(true);
    Map<?,?> cache=(Map<?,?>)cacheField.get(null);
    return cache.size();
  }
  /** 
 * Test that when we delete a location using the first row of a region that we really delete it.
 * @throws Exception
 */
  @Test public void testRegionCaching() throws Exception {
    HTable table=TEST_UTIL.createTable(TABLE_NAME,FAM_NAM);
    TEST_UTIL.createMultiRegions(table,FAM_NAM);
    Put put=new Put(ROW);
    put.add(FAM_NAM,ROW,ROW);
    table.put(put);
    HConnectionManager.HConnectionImplementation conn=(HConnectionManager.HConnectionImplementation)table.getConnection();
    assertNotNull(conn.getCachedLocation(TABLE_NAME,ROW));
    conn.deleteCachedLocation(TABLE_NAME,ROW);
    HRegionLocation rl=conn.getCachedLocation(TABLE_NAME,ROW);
    assertNull("What is this location?? " + rl,rl);
  }
  /** 
 * Make sure that  {@link HConfiguration} instances that are essentially thesame map to the same  {@link HConnection} instance.
 */
  @Test public void testConnectionSameness() throws Exception {
    HConnection previousConnection=null;
    for (int i=0; i < 2; i++) {
      Configuration configuration=TEST_UTIL.getConfiguration();
      configuration.set(HConstants.HBASE_CONNECTION_PER_CONFIG,"false");
      configuration.set("some_key",String.valueOf(_randy.nextInt()));
      LOG.info("The hash code of the current configuration is: " + configuration.hashCode());
      HConnection currentConnection=HConnectionManager.getConnection(configuration);
      if (previousConnection != null) {
        assertTrue("Did not get the same connection even though its key didn't change",previousConnection == currentConnection);
      }
      previousConnection=currentConnection;
      configuration.set("other_key",String.valueOf(_randy.nextInt()));
    }
  }
  /** 
 * Makes sure that there is no leaking of {@link HConnectionManager.TableServers} in the {@link HConnectionManager}class.
 */
  @Test public void testConnectionUniqueness() throws Exception {
    HConnection previousConnection=null;
    for (int i=0; i < 50; i++) {
      Configuration configuration=TEST_UTIL.getConfiguration();
      configuration.set(HConstants.HBASE_CONNECTION_PER_CONFIG,"false");
      configuration.set("some_key",String.valueOf(_randy.nextInt()));
      configuration.set(HConstants.HBASE_CLIENT_INSTANCE_ID,String.valueOf(_randy.nextInt()));
      LOG.info("The hash code of the current configuration is: " + configuration.hashCode());
      HConnection currentConnection=HConnectionManager.getConnection(configuration);
      if (previousConnection != null) {
        assertTrue("Got the same connection even though its key changed!",previousConnection != currentConnection);
      }
      configuration.set("other_key",String.valueOf(_randy.nextInt()));
      previousConnection=currentConnection;
      LOG.info("The current HConnectionManager#HBASE_INSTANCES cache size is: " + getHConnectionManagerCacheSize());
      Thread.sleep(50);
    }
  }
}
