private static class CachedItem implements Cacheable {
  BlockCacheKey cacheKey;
  int size;
  CachedItem(  String blockName,  int size,  int offset){
    this.cacheKey=new BlockCacheKey(blockName,offset);
    this.size=size;
  }
  CachedItem(  String blockName,  int size){
    this.cacheKey=new BlockCacheKey(blockName,0);
    this.size=size;
  }
  /** 
 * The size of this item reported to the block cache layer 
 */
  @Override public long heapSize(){
    return ClassSize.align(size);
  }
  /** 
 * Size of the cache block holding this item. Used for verification. 
 */
  public long cacheBlockHeapSize(){
    return LruCachedBlock.PER_BLOCK_OVERHEAD + ClassSize.align(cacheKey.heapSize()) + ClassSize.align(size);
  }
  @Override public int getSerializedLength(){
    return 0;
  }
  @Override public CacheableDeserializer<Cacheable> getDeserializer(){
    return null;
  }
  @Override public void serialize(  ByteBuffer destination){
  }
  @Override public BlockType getBlockType(){
    return BlockType.DATA;
  }
}
