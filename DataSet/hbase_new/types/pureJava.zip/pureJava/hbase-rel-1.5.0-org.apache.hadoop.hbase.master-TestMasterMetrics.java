@Category(MediumTests.class) public class TestMasterMetrics {
  private static final Log LOG=LogFactory.getLog(TestMasterMetrics.class);
  private static final MetricsAssertHelper metricsHelper=CompatibilityFactory.getInstance(MetricsAssertHelper.class);
  private static MiniHBaseCluster cluster;
  private static HMaster master;
  private static HBaseTestingUtility TEST_UTIL;
public static class MyMaster extends HMaster {
    public MyMaster(    Configuration conf,    CoordinatedStateManager cp) throws IOException, KeeperException, InterruptedException {
      super(conf,cp);
    }
    @Override protected void tryRegionServerReport(    long reportStartTime,    long reportEndTime){
    }
  }
  @BeforeClass public static void startCluster() throws Exception {
    LOG.info("Starting cluster");
    TEST_UTIL=new HBaseTestingUtility();
    TEST_UTIL.startMiniCluster(1,1,1,null,MyMaster.class,null);
    cluster=TEST_UTIL.getHBaseCluster();
    LOG.info("Waiting for active/ready master");
    cluster.waitForActiveAndReadyMaster();
    master=cluster.getMaster();
  }
  @AfterClass public static void after() throws Exception {
    if (TEST_UTIL != null) {
      TEST_UTIL.shutdownMiniCluster();
    }
  }
  @Test(timeout=300000) public void testClusterRequests() throws Exception {
    RegionServerStatusProtos.RegionServerReportRequest.Builder request=RegionServerStatusProtos.RegionServerReportRequest.newBuilder();
    ServerName serverName=cluster.getMaster(0).getServerName();
    request.setServer(ProtobufUtil.toServerName(serverName));
    MetricsMasterSource masterSource=master.getMasterMetrics().getMetricsSource();
    ClusterStatusProtos.ServerLoad sl=ClusterStatusProtos.ServerLoad.newBuilder().setTotalNumberOfRequests(10000).build();
    masterSource.init();
    request.setLoad(sl);
    master.getMasterRpcServices().regionServerReport(null,request.build());
    metricsHelper.assertCounter("cluster_requests",10000,masterSource);
    sl=ClusterStatusProtos.ServerLoad.newBuilder().setTotalNumberOfRequests(15000).build();
    request.setLoad(sl);
    master.getMasterRpcServices().regionServerReport(null,request.build());
    metricsHelper.assertCounter("cluster_requests",15000,masterSource);
    master.getMasterRpcServices().regionServerReport(null,request.build());
    metricsHelper.assertCounter("cluster_requests",15000,masterSource);
    master.stopMaster();
  }
  @Test public void testDefaultMasterMetrics() throws Exception {
    MetricsMasterSource masterSource=master.getMasterMetrics().getMetricsSource();
    metricsHelper.assertGauge("numRegionServers",1,masterSource);
    metricsHelper.assertGauge("averageLoad",2,masterSource);
    metricsHelper.assertGauge("numDeadRegionServers",0,masterSource);
    metricsHelper.assertGauge("masterStartTime",master.getMasterStartTime(),masterSource);
    metricsHelper.assertGauge("masterActiveTime",master.getMasterActiveTime(),masterSource);
    metricsHelper.assertTag("isActiveMaster","true",masterSource);
    metricsHelper.assertTag("serverName",master.getServerName().toString(),masterSource);
    metricsHelper.assertTag("clusterId",master.getClusterId(),masterSource);
    metricsHelper.assertTag("zookeeperQuorum",master.getZooKeeper().getQuorum(),masterSource);
  }
  @Test public void testDefaultMasterProcMetrics() throws Exception {
    MetricsMasterProcSource masterSource=master.getMasterMetrics().getMetricsProcSource();
    metricsHelper.assertGauge("numMasterWALs",master.getNumWALFiles(),masterSource);
  }
}
