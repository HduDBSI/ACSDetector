/** 
 * Provides command strings for services to be executed by Shell. CommandProviders are pluggable, and different deployments(windows, bigtop, etc) can be managed by plugging-in custom CommandProvider's or ClusterManager's.
 */
static abstract class CommandProvider {
  enum Operation {  START,   STOP,   RESTART}
  public abstract String getCommand(  ServiceType service,  Operation op);
  public String isRunningCommand(  ServiceType service){
    return findPidCommand(service);
  }
  protected String findPidCommand(  ServiceType service){
    return String.format("ps ux | grep proc_%s | grep -v grep | tr -s ' ' | cut -d ' ' -f2",service);
  }
  public String signalCommand(  ServiceType service,  String signal){
    return String.format("%s | xargs kill -s %s",findPidCommand(service),signal);
  }
}
