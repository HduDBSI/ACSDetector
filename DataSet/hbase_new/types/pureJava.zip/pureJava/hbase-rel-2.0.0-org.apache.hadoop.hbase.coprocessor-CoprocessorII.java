public static class CoprocessorII implements RegionCoprocessor {
  private ConcurrentMap<String,Object> sharedData;
  @Override public void start(  CoprocessorEnvironment e){
    sharedData=((RegionCoprocessorEnvironment)e).getSharedData();
    sharedData.putIfAbsent("test2",new Object());
  }
  @Override public void stop(  CoprocessorEnvironment e){
    sharedData=null;
  }
  @Override public Optional<RegionObserver> getRegionObserver(){
    return Optional.of(new RegionObserver(){
      @Override public void preGetOp(      final ObserverContext<RegionCoprocessorEnvironment> e,      final Get get,      final List<Cell> results) throws IOException {
        throw new RuntimeException();
      }
    }
);
  }
  Map<String,Object> getSharedData(){
    return sharedData;
  }
}
