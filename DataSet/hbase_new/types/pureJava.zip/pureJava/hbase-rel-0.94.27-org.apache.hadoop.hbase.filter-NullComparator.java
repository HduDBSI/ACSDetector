/** 
 * A binary comparator which lexicographically compares against the specified byte array using  {@link org.apache.hadoop.hbase.util.Bytes#compareTo(byte[],byte[])}.
 */
public class NullComparator extends WritableByteArrayComparable {
  /** 
 * Nullary constructor for Writable, do not use 
 */
  public NullComparator(){
    value=new byte[0];
  }
  @Override public int compareTo(  byte[] value){
    return value != null ? 1 : 0;
  }
  @Override public int compareTo(  byte[] value,  int offset,  int length){
    return compareTo(value);
  }
}
