public static class majorCompact_call extends org.apache.thrift.async.TAsyncMethodCall {
  private ByteBuffer tableNameOrRegionName;
  public majorCompact_call(  ByteBuffer tableNameOrRegionName,  org.apache.thrift.async.AsyncMethodCallback<majorCompact_call> resultHandler,  org.apache.thrift.async.TAsyncClient client,  org.apache.thrift.protocol.TProtocolFactory protocolFactory,  org.apache.thrift.transport.TNonblockingTransport transport) throws org.apache.thrift.TException {
    super(client,protocolFactory,transport,resultHandler,false);
    this.tableNameOrRegionName=tableNameOrRegionName;
  }
  public void write_args(  org.apache.thrift.protocol.TProtocol prot) throws org.apache.thrift.TException {
    prot.writeMessageBegin(new org.apache.thrift.protocol.TMessage("majorCompact",org.apache.thrift.protocol.TMessageType.CALL,0));
    majorCompact_args args=new majorCompact_args();
    args.setTableNameOrRegionName(tableNameOrRegionName);
    args.write(prot);
    prot.writeMessageEnd();
  }
  public void getResult() throws IOError, org.apache.thrift.TException {
    if (getState() != org.apache.thrift.async.TAsyncMethodCall.State.RESPONSE_READ) {
      throw new IllegalStateException("Method call not finished!");
    }
    org.apache.thrift.transport.TMemoryInputTransport memoryTransport=new org.apache.thrift.transport.TMemoryInputTransport(getFrameBuffer().array());
    org.apache.thrift.protocol.TProtocol prot=client.getProtocolFactory().getProtocol(memoryTransport);
    (new Client(prot)).recv_majorCompact();
  }
}
