/** 
 * Datastructure to hold RegionServer Thread and RegionServer instance
 */
public static class RegionServerThread extends Thread {
  private final HRegionServer regionServer;
  public RegionServerThread(  final HRegionServer r,  final int index){
    super(r,"RegionServer:" + index + ";"+ r.getServerName());
    this.regionServer=r;
  }
  /** 
 * @return the region server 
 */
  public HRegionServer getRegionServer(){
    return this.regionServer;
  }
  /** 
 * Block until the region server has come online, indicating it is ready to be used.
 */
  public void waitForServerOnline(){
    while (!this.regionServer.isOnline() && !this.regionServer.isStopped()) {
      try {
        Thread.sleep(1000);
      }
 catch (      InterruptedException e) {
      }
    }
  }
}
