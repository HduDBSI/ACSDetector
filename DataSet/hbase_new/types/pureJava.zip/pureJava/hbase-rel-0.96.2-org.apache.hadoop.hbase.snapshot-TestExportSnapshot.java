/** 
 * Test Export Snapshot Tool
 */
@Category(MediumTests.class) public class TestExportSnapshot {
  private final Log LOG=LogFactory.getLog(getClass());
  protected final static HBaseTestingUtility TEST_UTIL=new HBaseTestingUtility();
  private final static byte[] FAMILY=Bytes.toBytes("cf");
  private byte[] emptySnapshotName;
  private byte[] snapshotName;
  private TableName tableName;
  private HBaseAdmin admin;
  public static void setUpBaseConf(  Configuration conf){
    conf.setBoolean(SnapshotManager.HBASE_SNAPSHOT_ENABLED,true);
    conf.setInt("hbase.regionserver.msginterval",100);
    conf.setInt("hbase.client.pause",250);
    conf.setInt(HConstants.HBASE_CLIENT_RETRIES_NUMBER,6);
    conf.setBoolean("hbase.master.enabletable.roundrobin",true);
    conf.setInt("mapreduce.map.max.attempts",10);
    conf.setInt("mapred.map.max.attempts",10);
  }
  @BeforeClass public static void setUpBeforeClass() throws Exception {
    setUpBaseConf(TEST_UTIL.getConfiguration());
    TEST_UTIL.startMiniCluster(3);
    TEST_UTIL.startMiniMapReduceCluster();
  }
  @AfterClass public static void tearDownAfterClass() throws Exception {
    TEST_UTIL.shutdownMiniMapReduceCluster();
    TEST_UTIL.shutdownMiniCluster();
  }
  /** 
 * Create a table and take a snapshot of the table used by the export test.
 */
  @Before public void setUp() throws Exception {
    this.admin=TEST_UTIL.getHBaseAdmin();
    long tid=System.currentTimeMillis();
    tableName=TableName.valueOf("testtb-" + tid);
    snapshotName=Bytes.toBytes("snaptb0-" + tid);
    emptySnapshotName=Bytes.toBytes("emptySnaptb0-" + tid);
    SnapshotTestingUtils.createTable(TEST_UTIL,tableName,FAMILY);
    admin.snapshot(emptySnapshotName,tableName);
    HTable table=new HTable(TEST_UTIL.getConfiguration(),tableName);
    SnapshotTestingUtils.loadData(TEST_UTIL,tableName,1000,FAMILY);
    admin.snapshot(snapshotName,tableName);
  }
  @After public void tearDown() throws Exception {
    TEST_UTIL.deleteTable(tableName);
    SnapshotTestingUtils.deleteAllSnapshots(TEST_UTIL.getHBaseAdmin());
    SnapshotTestingUtils.deleteArchiveDirectory(TEST_UTIL);
  }
  /** 
 * Verfy the result of getBalanceSplits() method. The result are groups of files, used as input list for the "export" mappers. All the groups should have similar amount of data. The input list is a pair of file path and length. The getBalanceSplits() function sort it by length, and assign to each group a file, going back and forth through the groups.
 */
  @Test public void testBalanceSplit() throws Exception {
    List<Pair<Path,Long>> files=new ArrayList<Pair<Path,Long>>();
    for (long i=0; i <= 20; i++) {
      files.add(new Pair<Path,Long>(new Path("file-" + i),i));
    }
    List<List<Path>> splits=ExportSnapshot.getBalancedSplits(files,5);
    assertEquals(5,splits.size());
    assertEquals(Arrays.asList(new Path("file-20"),new Path("file-11"),new Path("file-10"),new Path("file-1"),new Path("file-0")),splits.get(0));
    assertEquals(Arrays.asList(new Path("file-19"),new Path("file-12"),new Path("file-9"),new Path("file-2")),splits.get(1));
    assertEquals(Arrays.asList(new Path("file-18"),new Path("file-13"),new Path("file-8"),new Path("file-3")),splits.get(2));
    assertEquals(Arrays.asList(new Path("file-17"),new Path("file-14"),new Path("file-7"),new Path("file-4")),splits.get(3));
    assertEquals(Arrays.asList(new Path("file-16"),new Path("file-15"),new Path("file-6"),new Path("file-5")),splits.get(4));
  }
  /** 
 * Verify if exported snapshot and copied files matches the original one.
 */
  @Test public void testExportFileSystemState() throws Exception {
    testExportFileSystemState(tableName,snapshotName,2);
  }
  @Test public void testEmptyExportFileSystemState() throws Exception {
    testExportFileSystemState(tableName,emptySnapshotName,1);
  }
  @Test public void testConsecutiveExports() throws Exception {
    Path copyDir=getLocalDestinationDir();
    testExportFileSystemState(tableName,snapshotName,2,copyDir,false);
    testExportFileSystemState(tableName,snapshotName,2,copyDir,true);
    removeExportDir(copyDir);
  }
  /** 
 * Mock a snapshot with files in the archive dir, two regions, and one reference file.
 */
  @Test public void testSnapshotWithRefsExportFileSystemState() throws Exception {
    Configuration conf=TEST_UTIL.getConfiguration();
    final TableName tableWithRefsName=TableName.valueOf("tableWithRefs");
    final String snapshotName="tableWithRefs";
    final String TEST_FAMILY=Bytes.toString(FAMILY);
    final String TEST_HFILE="abc";
    final SnapshotDescription sd=SnapshotDescription.newBuilder().setName(snapshotName).setTable(tableWithRefsName.getNameAsString()).build();
    FileSystem fs=TEST_UTIL.getHBaseCluster().getMaster().getMasterFileSystem().getFileSystem();
    Path rootDir=TEST_UTIL.getHBaseCluster().getMaster().getMasterFileSystem().getRootDir();
    Path archiveDir=new Path(rootDir,HConstants.HFILE_ARCHIVE_DIRECTORY);
    HRegionInfo hri=new HRegionInfo(tableWithRefsName);
    HRegionFileSystem r0fs=HRegionFileSystem.createRegionOnFileSystem(conf,fs,FSUtils.getTableDir(archiveDir,hri.getTable()),hri);
    Path storeFile=new Path(rootDir,TEST_HFILE);
    FSDataOutputStream out=fs.create(storeFile);
    out.write(Bytes.toBytes("Test Data"));
    out.close();
    r0fs.commitStoreFile(TEST_FAMILY,storeFile);
    hri=new HRegionInfo(tableWithRefsName);
    HRegionFileSystem r1fs=HRegionFileSystem.createRegionOnFileSystem(conf,fs,new Path(archiveDir,hri.getTable().getNameAsString()),hri);
    storeFile=new Path(rootDir,TEST_HFILE + '.' + r0fs.getRegionInfo().getEncodedName());
    out=fs.create(storeFile);
    out.write(Bytes.toBytes("Test Data"));
    out.close();
    r1fs.commitStoreFile(TEST_FAMILY,storeFile);
    Path tableDir=FSUtils.getTableDir(archiveDir,tableWithRefsName);
    Path snapshotDir=SnapshotDescriptionUtils.getCompletedSnapshotDir(snapshotName,rootDir);
    FileUtil.copy(fs,tableDir,fs,snapshotDir,false,conf);
    SnapshotDescriptionUtils.writeSnapshotInfo(sd,snapshotDir,fs);
    testExportFileSystemState(tableWithRefsName,Bytes.toBytes(snapshotName),2);
  }
  private void testExportFileSystemState(  final TableName tableName,  final byte[] snapshotName,  int filesExpected) throws Exception {
    Path copyDir=getHdfsDestinationDir();
    testExportFileSystemState(tableName,snapshotName,filesExpected,copyDir,false);
    removeExportDir(copyDir);
  }
  /** 
 * Test ExportSnapshot
 */
  private void testExportFileSystemState(  final TableName tableName,  final byte[] snapshotName,  int filesExpected,  Path copyDir,  boolean overwrite) throws Exception {
    URI hdfsUri=FileSystem.get(TEST_UTIL.getConfiguration()).getUri();
    FileSystem fs=FileSystem.get(copyDir.toUri(),new Configuration());
    copyDir=copyDir.makeQualified(fs);
    List<String> opts=new ArrayList<String>();
    opts.add("-snapshot");
    opts.add(Bytes.toString(snapshotName));
    opts.add("-copy-to");
    opts.add(copyDir.toString());
    if (overwrite)     opts.add("-overwrite");
    int res=ExportSnapshot.innerMain(TEST_UTIL.getConfiguration(),opts.toArray(new String[opts.size()]));
    assertEquals(0,res);
    FileStatus[] rootFiles=fs.listStatus(copyDir);
    assertEquals(filesExpected,rootFiles.length);
    for (    FileStatus fileStatus : rootFiles) {
      String name=fileStatus.getPath().getName();
      assertTrue(fileStatus.isDir());
      assertTrue(name.equals(HConstants.SNAPSHOT_DIR_NAME) || name.equals(HConstants.HFILE_ARCHIVE_DIRECTORY));
    }
    final FileSystem hdfs=FileSystem.get(hdfsUri,TEST_UTIL.getConfiguration());
    final Path snapshotDir=new Path(HConstants.SNAPSHOT_DIR_NAME,Bytes.toString(snapshotName));
    verifySnapshot(hdfs,new Path(TEST_UTIL.getDefaultRootDirPath(),snapshotDir),fs,new Path(copyDir,snapshotDir));
    verifyArchive(fs,copyDir,tableName,Bytes.toString(snapshotName));
    FSUtils.logFileSystemState(hdfs,snapshotDir,LOG);
  }
  /** 
 * Check that ExportSnapshot will return a failure if something fails.
 */
  @Test public void testExportFailure() throws Exception {
    assertEquals(1,runExportAndInjectFailures(snapshotName,false));
  }
  /** 
 * Check that ExportSnapshot will succede if something fails but the retry succede.
 */
  @Test public void testExportRetry() throws Exception {
    assertEquals(0,runExportAndInjectFailures(snapshotName,true));
  }
  private int runExportAndInjectFailures(  final byte[] snapshotName,  boolean retry) throws Exception {
    Path copyDir=getLocalDestinationDir();
    URI hdfsUri=FileSystem.get(TEST_UTIL.getConfiguration()).getUri();
    FileSystem fs=FileSystem.get(copyDir.toUri(),new Configuration());
    copyDir=copyDir.makeQualified(fs);
    Configuration conf=new Configuration(TEST_UTIL.getConfiguration());
    conf.setBoolean(ExportSnapshot.CONF_TEST_FAILURE,true);
    conf.setBoolean(ExportSnapshot.CONF_TEST_RETRY,retry);
    int res=ExportSnapshot.innerMain(conf,new String[]{"-snapshot",Bytes.toString(snapshotName),"-copy-to",copyDir.toString()});
    return res;
  }
  private void verifySnapshot(  final FileSystem fs1,  final Path root1,  final FileSystem fs2,  final Path root2) throws IOException {
    Set<String> s=new HashSet<String>();
    assertEquals(listFiles(fs1,root1,root1),listFiles(fs2,root2,root2));
  }
  private void verifyArchive(  final FileSystem fs,  final Path rootDir,  final TableName tableName,  final String snapshotName) throws IOException {
    final Path exportedSnapshot=new Path(rootDir,new Path(HConstants.SNAPSHOT_DIR_NAME,snapshotName));
    final Path exportedArchive=new Path(rootDir,HConstants.HFILE_ARCHIVE_DIRECTORY);
    LOG.debug(listFiles(fs,exportedArchive,exportedArchive));
    SnapshotReferenceUtil.visitReferencedFiles(fs,exportedSnapshot,new SnapshotReferenceUtil.FileVisitor(){
      public void storeFile(      final String region,      final String family,      final String hfile) throws IOException {
        verifyNonEmptyFile(new Path(exportedArchive,new Path(FSUtils.getTableDir(new Path("./"),tableName),new Path(region,new Path(family,hfile)))));
      }
      public void recoveredEdits(      final String region,      final String logfile) throws IOException {
        verifyNonEmptyFile(new Path(exportedSnapshot,new Path(tableName.getNameAsString(),new Path(region,logfile))));
      }
      public void logFile(      final String server,      final String logfile) throws IOException {
        verifyNonEmptyFile(new Path(exportedSnapshot,new Path(server,logfile)));
      }
      private void verifyNonEmptyFile(      final Path path) throws IOException {
        assertTrue(path + " should exists",fs.exists(path));
        assertTrue(path + " should not be empty",fs.getFileStatus(path).getLen() > 0);
      }
    }
);
  }
  private Set<String> listFiles(  final FileSystem fs,  final Path root,  final Path dir) throws IOException {
    Set<String> files=new HashSet<String>();
    int rootPrefix=root.toString().length();
    FileStatus[] list=FSUtils.listStatus(fs,dir);
    if (list != null) {
      for (      FileStatus fstat : list) {
        LOG.debug(fstat.getPath());
        if (fstat.isDir()) {
          files.addAll(listFiles(fs,root,fstat.getPath()));
        }
 else {
          files.add(fstat.getPath().toString().substring(rootPrefix));
        }
      }
    }
    return files;
  }
  private Path getHdfsDestinationDir(){
    Path rootDir=TEST_UTIL.getHBaseCluster().getMaster().getMasterFileSystem().getRootDir();
    Path path=new Path(new Path(rootDir,"export-test"),"export-" + System.currentTimeMillis());
    LOG.info("HDFS export destination path: " + path);
    return path;
  }
  private Path getLocalDestinationDir(){
    Path path=TEST_UTIL.getDataTestDir("local-export-" + System.currentTimeMillis());
    LOG.info("Local export destination path: " + path);
    return path;
  }
  private void removeExportDir(  final Path path) throws IOException {
    FileSystem fs=FileSystem.get(path.toUri(),new Configuration());
    FSUtils.logFileSystemState(fs,path,LOG);
    fs.delete(path,true);
  }
}
