/** 
 * Checks the last and first key seen against the scanner boundaries.
 */
public static class ScanReducer extends Reducer<ImmutableBytesWritable,ImmutableBytesWritable,NullWritable,NullWritable> {
  private String first=null;
  private String last=null;
  protected void reduce(  ImmutableBytesWritable key,  Iterable<ImmutableBytesWritable> values,  Context context) throws IOException, InterruptedException {
    int count=0;
    for (    ImmutableBytesWritable value : values) {
      String val=Bytes.toStringBinary(value.get());
      LOG.info("reduce: key[" + count + "] -> "+ Bytes.toStringBinary(key.get())+ ", value -> "+ val);
      if (first == null)       first=val;
      last=val;
      count++;
    }
  }
  protected void cleanup(  Context context) throws IOException, InterruptedException {
    Configuration c=context.getConfiguration();
    String startRow=c.get(KEY_STARTROW);
    String lastRow=c.get(KEY_LASTROW);
    LOG.info("cleanup: first -> \"" + first + "\", start row -> \""+ startRow+ "\"");
    LOG.info("cleanup: last -> \"" + last + "\", last row -> \""+ lastRow+ "\"");
    if (startRow != null && startRow.length() > 0) {
      assertEquals(startRow,first);
    }
    if (lastRow != null && lastRow.length() > 0) {
      assertEquals(lastRow,last);
    }
  }
}
