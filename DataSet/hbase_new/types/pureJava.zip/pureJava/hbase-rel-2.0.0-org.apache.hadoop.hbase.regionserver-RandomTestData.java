static class RandomTestData {
  private long[] keys=new long[NUM_KEYS];
  private long min=Long.MAX_VALUE;
  private long max=0;
  public RandomTestData(){
    if (ThreadLocalRandom.current().nextInt(NUM_OF_THREADS) % 2 == 0) {
      for (int i=0; i < NUM_KEYS; i++) {
        keys[i]=i + ThreadLocalRandom.current().nextLong(NUM_OF_THREADS);
        if (keys[i] < min)         min=keys[i];
        if (keys[i] > max)         max=keys[i];
      }
    }
 else {
      for (int i=NUM_KEYS - 1; i >= 0; i--) {
        keys[i]=i + ThreadLocalRandom.current().nextLong(NUM_OF_THREADS);
        if (keys[i] < min)         min=keys[i];
        if (keys[i] > max)         max=keys[i];
      }
    }
  }
  public long getMax(){
    return this.max;
  }
  public long getMin(){
    return this.min;
  }
}
