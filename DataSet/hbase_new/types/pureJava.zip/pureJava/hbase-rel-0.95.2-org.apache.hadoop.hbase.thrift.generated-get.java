public static class get<I extends Iface> extends org.apache.thrift.ProcessFunction<I,get_args> {
  public get(){
    super("get");
  }
  public get_args getEmptyArgsInstance(){
    return new get_args();
  }
  protected boolean isOneway(){
    return false;
  }
  public get_result getResult(  I iface,  get_args args) throws org.apache.thrift.TException {
    get_result result=new get_result();
    try {
      result.success=iface.get(args.tableName,args.row,args.column,args.attributes);
    }
 catch (    IOError io) {
      result.io=io;
    }
    return result;
  }
}
