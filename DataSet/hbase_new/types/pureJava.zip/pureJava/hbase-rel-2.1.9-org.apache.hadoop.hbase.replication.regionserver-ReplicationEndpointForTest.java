public static class ReplicationEndpointForTest extends HBaseInterClusterReplicationEndpoint {
  protected static AtomicInteger batchCount=new AtomicInteger(0);
  protected static int entriesCount;
  private static final Object latch=new Object();
  private static AtomicBoolean useLatch=new AtomicBoolean(false);
  public static void resume(){
    useLatch.set(false);
synchronized (latch) {
      latch.notifyAll();
    }
  }
  public static void pause(){
    useLatch.set(true);
  }
  public static void await() throws InterruptedException {
    if (useLatch.get()) {
      LOG.info("Waiting on latch");
synchronized (latch) {
        latch.wait();
      }
      LOG.info("Waited on latch, now proceeding");
    }
  }
  public static int getBatchCount(){
    return batchCount.get();
  }
  public static void setBatchCount(  int i){
    LOG.info("SetBatchCount=" + i + ", old="+ getBatchCount());
    batchCount.set(i);
  }
  public static int getEntriesCount(){
    return entriesCount;
  }
  public static void setEntriesCount(  int i){
    LOG.info("SetEntriesCount=" + i);
    entriesCount=i;
  }
  @Override public boolean replicate(  ReplicateContext replicateContext){
    try {
      await();
    }
 catch (    InterruptedException e) {
      LOG.warn("Interrupted waiting for latch",e);
    }
    return super.replicate(replicateContext);
  }
  @Override protected Callable<Integer> createReplicator(  List<Entry> entries,  int ordinal){
    return () -> {
      int batchIndex=replicateEntries(entries,ordinal);
      entriesCount+=entries.size();
      int count=batchCount.incrementAndGet();
      LOG.info("Completed replicating batch " + System.identityHashCode(entries) + " count="+ count);
      return batchIndex;
    }
;
  }
}
