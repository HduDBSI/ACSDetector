/** 
 * Hadoop 2 implementation of BaseSource (using metrics2 framework).  It handles registration to DefaultMetricsSystem and creation of the metrics registry. All MetricsSource's in hbase-hadoop2-compat should derive from this class.
 */
@InterfaceAudience.Private public class BaseSourceImpl implements BaseSource, MetricsSource {
  private static enum DefaultMetricsSystemInitializer {  INSTANCE;   private boolean inited=false;
  private JvmMetrics jvmMetricsSource;
  synchronized void init(  String name){
    if (inited)     return;
    inited=true;
    DefaultMetricsSystem.initialize(HBASE_METRICS_SYSTEM_NAME);
    jvmMetricsSource=JvmMetrics.initSingleton(name,"");
  }
}
  protected final DynamicMetricsRegistry metricsRegistry;
  protected final String metricsName;
  protected final String metricsDescription;
  protected final String metricsContext;
  protected final String metricsJmxContext;
  public BaseSourceImpl(  String metricsName,  String metricsDescription,  String metricsContext,  String metricsJmxContext){
    this.metricsName=metricsName;
    this.metricsDescription=metricsDescription;
    this.metricsContext=metricsContext;
    this.metricsJmxContext=metricsJmxContext;
    metricsRegistry=new DynamicMetricsRegistry(metricsName).setContext(metricsContext);
    DefaultMetricsSystemInitializer.INSTANCE.init(metricsName);
    DefaultMetricsSystem.instance().register(metricsJmxContext,metricsDescription,this);
    init();
  }
  public void init(){
    this.metricsRegistry.clearMetrics();
  }
  /** 
 * Set a single gauge to a value.
 * @param gaugeName gauge name
 * @param value     the new value of the gauge.
 */
  public void setGauge(  String gaugeName,  long value){
    MutableGaugeLong gaugeInt=metricsRegistry.getLongGauge(gaugeName,value);
    gaugeInt.set(value);
  }
  /** 
 * Add some amount to a gauge.
 * @param gaugeName The name of the gauge to increment.
 * @param delta     The amount to increment the gauge by.
 */
  public void incGauge(  String gaugeName,  long delta){
    MutableGaugeLong gaugeInt=metricsRegistry.getLongGauge(gaugeName,0l);
    gaugeInt.incr(delta);
  }
  /** 
 * Decrease the value of a named gauge.
 * @param gaugeName The name of the gauge.
 * @param delta     the ammount to subtract from a gauge value.
 */
  public void decGauge(  String gaugeName,  long delta){
    MutableGaugeLong gaugeInt=metricsRegistry.getLongGauge(gaugeName,0l);
    gaugeInt.decr(delta);
  }
  /** 
 * Increment a named counter by some value.
 * @param key   the name of the counter
 * @param delta the ammount to increment
 */
  public void incCounters(  String key,  long delta){
    MutableCounterLong counter=metricsRegistry.getLongCounter(key,0l);
    counter.incr(delta);
  }
  @Override public void updateHistogram(  String name,  long value){
    MutableHistogram histo=metricsRegistry.getHistogram(name);
    histo.add(value);
  }
  @Override public void updateQuantile(  String name,  long value){
    MetricMutableQuantiles histo=metricsRegistry.getQuantile(name);
    histo.add(value);
  }
  /** 
 * Remove a named gauge.
 * @param key
 */
  public void removeMetric(  String key){
    metricsRegistry.removeMetric(key);
    JmxCacheBuster.clearJmxCache();
  }
  @Override public void getMetrics(  MetricsCollector metricsCollector,  boolean all){
    metricsRegistry.snapshot(metricsCollector.addRecord(metricsRegistry.info()),all);
  }
  public DynamicMetricsRegistry getMetricsRegistry(){
    return metricsRegistry;
  }
  public String getMetricsContext(){
    return metricsContext;
  }
  public String getMetricsDescription(){
    return metricsDescription;
  }
  public String getMetricsJmxContext(){
    return metricsJmxContext;
  }
  public String getMetricsName(){
    return metricsName;
  }
}
