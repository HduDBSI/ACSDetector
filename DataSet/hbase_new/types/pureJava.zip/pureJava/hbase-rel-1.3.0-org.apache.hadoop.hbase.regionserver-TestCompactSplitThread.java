@Category(MediumTests.class) public class TestCompactSplitThread {
  private static final Log LOG=LogFactory.getLog(TestCompactSplitThread.class);
  private static final HBaseTestingUtility TEST_UTIL=new HBaseTestingUtility();
  private final TableName tableName=TableName.valueOf(getClass().getSimpleName());
  private final byte[] family=Bytes.toBytes("f");
  private static final int NUM_RS=1;
  private static final int blockingStoreFiles=3;
  private static Path rootDir;
  private static FileSystem fs;
  /** 
 * Setup the config for the cluster
 */
  @BeforeClass public static void setupCluster() throws Exception {
    setupConf(TEST_UTIL.getConfiguration());
    TEST_UTIL.startMiniCluster(NUM_RS);
    fs=TEST_UTIL.getDFSCluster().getFileSystem();
    rootDir=TEST_UTIL.getMiniHBaseCluster().getMaster().getMasterFileSystem().getRootDir();
  }
  private static void setupConf(  Configuration conf){
    conf.setInt("hbase.regionsever.info.port",-1);
    conf.setInt("hbase.hstore.compaction.min",2);
    conf.setInt("hbase.hstore.compactionThreshold",5);
    conf.setInt("hbase.hregion.memstore.flush.size",25000);
    conf.setInt("hbase.hstore.blockingStoreFiles",blockingStoreFiles);
    conf.setInt(CompactSplitThread.LARGE_COMPACTION_THREADS,3);
    conf.setInt(CompactSplitThread.SMALL_COMPACTION_THREADS,4);
    conf.setInt(CompactSplitThread.SPLIT_THREADS,5);
    conf.setInt(CompactSplitThread.MERGE_THREADS,6);
  }
  @After public void tearDown() throws Exception {
    TEST_UTIL.deleteTable(tableName);
  }
  @AfterClass public static void cleanupTest() throws Exception {
    try {
      TEST_UTIL.shutdownMiniCluster();
    }
 catch (    Exception e) {
    }
  }
  @Test public void testThreadPoolSizeTuning() throws Exception {
    Configuration conf=TEST_UTIL.getConfiguration();
    Connection conn=ConnectionFactory.createConnection(conf);
    try {
      HTableDescriptor htd=new HTableDescriptor(tableName);
      htd.addFamily(new HColumnDescriptor(family));
      htd.setCompactionEnabled(false);
      TEST_UTIL.getHBaseAdmin().createTable(htd);
      TEST_UTIL.waitTableAvailable(tableName);
      HRegionServer regionServer=TEST_UTIL.getRSForFirstRegionInTable(tableName);
      assertEquals(3,regionServer.compactSplitThread.getLargeCompactionThreadNum());
      assertEquals(4,regionServer.compactSplitThread.getSmallCompactionThreadNum());
      assertEquals(5,regionServer.compactSplitThread.getSplitThreadNum());
      assertEquals(6,regionServer.compactSplitThread.getMergeThreadNum());
      conf.setInt(CompactSplitThread.LARGE_COMPACTION_THREADS,4);
      conf.setInt(CompactSplitThread.SMALL_COMPACTION_THREADS,5);
      conf.setInt(CompactSplitThread.SPLIT_THREADS,6);
      conf.setInt(CompactSplitThread.MERGE_THREADS,7);
      try {
        regionServer.compactSplitThread.onConfigurationChange(conf);
      }
 catch (      IllegalArgumentException iae) {
        Assert.fail("Update bigger configuration failed!");
      }
      assertEquals(4,regionServer.compactSplitThread.getLargeCompactionThreadNum());
      assertEquals(5,regionServer.compactSplitThread.getSmallCompactionThreadNum());
      assertEquals(6,regionServer.compactSplitThread.getSplitThreadNum());
      assertEquals(7,regionServer.compactSplitThread.getMergeThreadNum());
      conf.setInt(CompactSplitThread.LARGE_COMPACTION_THREADS,2);
      conf.setInt(CompactSplitThread.SMALL_COMPACTION_THREADS,3);
      conf.setInt(CompactSplitThread.SPLIT_THREADS,4);
      conf.setInt(CompactSplitThread.MERGE_THREADS,5);
      try {
        regionServer.compactSplitThread.onConfigurationChange(conf);
      }
 catch (      IllegalArgumentException iae) {
        Assert.fail("Update smaller configuration failed!");
      }
      assertEquals(2,regionServer.compactSplitThread.getLargeCompactionThreadNum());
      assertEquals(3,regionServer.compactSplitThread.getSmallCompactionThreadNum());
      assertEquals(4,regionServer.compactSplitThread.getSplitThreadNum());
      assertEquals(5,regionServer.compactSplitThread.getMergeThreadNum());
    }
  finally {
      conn.close();
    }
  }
  @Test(timeout=60000) public void testFlushWithTableCompactionDisabled() throws Exception {
    Admin admin=TEST_UTIL.getHBaseAdmin();
    HTableDescriptor htd=new HTableDescriptor(tableName);
    htd.setCompactionEnabled(false);
    TEST_UTIL.createTable(htd,new byte[][]{family},null);
    for (int i=0; i < blockingStoreFiles + 1; i++) {
      TEST_UTIL.loadTable(TEST_UTIL.getConnection().getTable(tableName),family);
      TEST_UTIL.flush(tableName);
    }
    Path tableDir=FSUtils.getTableDir(rootDir,tableName);
    Collection<String> hfiles=SnapshotTestingUtils.listHFileNames(fs,tableDir);
    assert (hfiles.size() > blockingStoreFiles + 1);
  }
}
