public static class CoprocessorImpl implements RegionCoprocessor, RegionObserver {
  private boolean startCalled;
  private boolean stopCalled;
  private boolean preOpenCalled;
  private boolean postOpenCalled;
  private boolean preCloseCalled;
  private boolean postCloseCalled;
  private boolean preCompactCalled;
  private boolean postCompactCalled;
  private boolean preFlushCalled;
  private boolean postFlushCalled;
  private ConcurrentMap<String,Object> sharedData;
  @Override public void start(  CoprocessorEnvironment e){
    sharedData=((RegionCoprocessorEnvironment)e).getSharedData();
    sharedData.putIfAbsent("test1",new Object());
    startCalled=true;
  }
  @Override public void stop(  CoprocessorEnvironment e){
    sharedData=null;
    stopCalled=true;
  }
  @Override public Optional<RegionObserver> getRegionObserver(){
    return Optional.of(this);
  }
  @Override public void preOpen(  ObserverContext<RegionCoprocessorEnvironment> e){
    preOpenCalled=true;
  }
  @Override public void postOpen(  ObserverContext<RegionCoprocessorEnvironment> e){
    postOpenCalled=true;
  }
  @Override public void preClose(  ObserverContext<RegionCoprocessorEnvironment> e,  boolean abortRequested){
    preCloseCalled=true;
  }
  @Override public void postClose(  ObserverContext<RegionCoprocessorEnvironment> e,  boolean abortRequested){
    postCloseCalled=true;
  }
  @Override public InternalScanner preCompact(  ObserverContext<RegionCoprocessorEnvironment> e,  Store store,  InternalScanner scanner,  ScanType scanType,  CompactionLifeCycleTracker tracker,  CompactionRequest request){
    preCompactCalled=true;
    return scanner;
  }
  @Override public void postCompact(  ObserverContext<RegionCoprocessorEnvironment> e,  Store store,  StoreFile resultFile,  CompactionLifeCycleTracker tracker,  CompactionRequest request){
    postCompactCalled=true;
  }
  @Override public void preFlush(  ObserverContext<RegionCoprocessorEnvironment> e,  FlushLifeCycleTracker tracker){
    preFlushCalled=true;
  }
  @Override public void postFlush(  ObserverContext<RegionCoprocessorEnvironment> e,  FlushLifeCycleTracker tracker){
    postFlushCalled=true;
  }
  @Override public RegionScanner postScannerOpen(  final ObserverContext<RegionCoprocessorEnvironment> e,  final Scan scan,  final RegionScanner s) throws IOException {
    return new CustomScanner(s);
  }
  boolean wasStarted(){
    return startCalled;
  }
  boolean wasStopped(){
    return stopCalled;
  }
  boolean wasOpened(){
    return (preOpenCalled && postOpenCalled);
  }
  boolean wasClosed(){
    return (preCloseCalled && postCloseCalled);
  }
  boolean wasFlushed(){
    return (preFlushCalled && postFlushCalled);
  }
  boolean wasCompacted(){
    return (preCompactCalled && postCompactCalled);
  }
  Map<String,Object> getSharedData(){
    return sharedData;
  }
}
