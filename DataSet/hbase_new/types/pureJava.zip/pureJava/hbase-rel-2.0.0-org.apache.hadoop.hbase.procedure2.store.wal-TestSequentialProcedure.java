public static class TestSequentialProcedure extends SequentialProcedure<Void> {
  private static long seqid=0;
  public TestSequentialProcedure(){
    setProcId(++seqid);
  }
  @Override protected Procedure[] execute(  Void env){
    return null;
  }
  @Override protected void rollback(  Void env){
  }
  @Override protected boolean abort(  Void env){
    return false;
  }
  @Override protected void serializeStateData(  ProcedureStateSerializer serializer) throws IOException {
    long procId=getProcId();
    if (procId % 2 == 0) {
      Int64Value.Builder builder=Int64Value.newBuilder().setValue(procId);
      serializer.serialize(builder.build());
    }
  }
  @Override protected void deserializeStateData(  ProcedureStateSerializer serializer) throws IOException {
    long procId=getProcId();
    if (procId % 2 == 0) {
      Int64Value value=serializer.deserialize(Int64Value.class);
      assertEquals(procId,value.getValue());
    }
  }
}
