/** 
 * Stores the hostname and weight for that hostname. This is used when determining the physical locations of the blocks making up a region. To make a prioritized list of the hosts holding the most data of a region, this class is used to count the total weight for each host.  The weight is currently just the size of the file.
 */
private static class HostAndWeight {
  private final String host;
  private long weight;
  public HostAndWeight(  String host,  long weight){
    this.host=host;
    this.weight=weight;
  }
  public void addWeight(  long weight){
    this.weight+=weight;
  }
  public String getHost(){
    return host;
  }
  public long getWeight(){
    return weight;
  }
private static class HostComparator implements Comparator<HostAndWeight> {
    @Override public int compare(    HostAndWeight l,    HostAndWeight r){
      return l.getHost().compareTo(r.getHost());
    }
  }
private static class WeightComparator implements Comparator<HostAndWeight> {
    @Override public int compare(    HostAndWeight l,    HostAndWeight r){
      if (l.getWeight() == r.getWeight()) {
        return l.getHost().compareTo(r.getHost());
      }
      return l.getWeight() < r.getWeight() ? -1 : 1;
    }
  }
}
