/** 
 * This filter is used for selecting only those keys with columns that matches a particular prefix. For example, if prefix is 'an', it will pass keys with columns like 'and', 'anti' but not keys with columns like 'ball', 'act'.
 */
public class ColumnPrefixFilter extends FilterBase {
  protected byte[] prefix=null;
  public ColumnPrefixFilter(){
    super();
  }
  public ColumnPrefixFilter(  final byte[] prefix){
    this.prefix=prefix;
  }
  public byte[] getPrefix(){
    return prefix;
  }
  @Override public ReturnCode filterKeyValue(  KeyValue kv){
    if (this.prefix == null || kv.getBuffer() == null) {
      return ReturnCode.INCLUDE;
    }
 else {
      return filterColumn(kv.getBuffer(),kv.getQualifierOffset(),kv.getQualifierLength());
    }
  }
  public ReturnCode filterColumn(  byte[] buffer,  int qualifierOffset,  int qualifierLength){
    if (qualifierLength < prefix.length) {
      int cmp=Bytes.compareTo(buffer,qualifierOffset,qualifierLength,this.prefix,0,qualifierLength);
      if (cmp <= 0) {
        return ReturnCode.SEEK_NEXT_USING_HINT;
      }
 else {
        return ReturnCode.NEXT_ROW;
      }
    }
 else {
      int cmp=Bytes.compareTo(buffer,qualifierOffset,this.prefix.length,this.prefix,0,this.prefix.length);
      if (cmp < 0) {
        return ReturnCode.SEEK_NEXT_USING_HINT;
      }
 else       if (cmp > 0) {
        return ReturnCode.NEXT_ROW;
      }
 else {
        return ReturnCode.INCLUDE;
      }
    }
  }
  public static Filter createFilterFromArguments(  ArrayList<byte[]> filterArguments){
    Preconditions.checkArgument(filterArguments.size() == 1,"Expected 1 but got: %s",filterArguments.size());
    byte[] columnPrefix=ParseFilter.removeQuotesFromByteArray(filterArguments.get(0));
    return new ColumnPrefixFilter(columnPrefix);
  }
  public void write(  DataOutput out) throws IOException {
    Bytes.writeByteArray(out,this.prefix);
  }
  public void readFields(  DataInput in) throws IOException {
    this.prefix=Bytes.readByteArray(in);
  }
  public KeyValue getNextKeyHint(  KeyValue kv){
    return KeyValue.createFirstOnRow(kv.getBuffer(),kv.getRowOffset(),kv.getRowLength(),kv.getBuffer(),kv.getFamilyOffset(),kv.getFamilyLength(),prefix,0,prefix.length);
  }
  @Override public String toString(){
    return this.getClass().getSimpleName() + " " + Bytes.toStringBinary(this.prefix);
  }
}
