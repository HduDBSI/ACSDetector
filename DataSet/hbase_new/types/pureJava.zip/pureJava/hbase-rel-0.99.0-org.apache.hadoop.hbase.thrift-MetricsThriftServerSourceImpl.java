/** 
 * Hadoop 2 version of MetricsThriftServerSource {@link org.apache.hadoop.hbase.thrift.MetricsThriftServerSource}Implements BaseSource through BaseSourceImpl, following the pattern
 */
@InterfaceAudience.Private public class MetricsThriftServerSourceImpl extends BaseSourceImpl implements MetricsThriftServerSource {
  private MutableHistogram batchGetStat;
  private MutableHistogram batchMutateStat;
  private MutableHistogram queueTimeStat;
  private MutableHistogram thriftCallStat;
  private MutableHistogram thriftSlowCallStat;
  private MutableGaugeLong callQueueLenGauge;
  public MetricsThriftServerSourceImpl(  String metricsName,  String metricsDescription,  String metricsContext,  String metricsJmxContext){
    super(metricsName,metricsDescription,metricsContext,metricsJmxContext);
  }
  @Override public void init(){
    super.init();
    batchGetStat=getMetricsRegistry().newHistogram(BATCH_GET_KEY);
    batchMutateStat=getMetricsRegistry().newHistogram(BATCH_MUTATE_KEY);
    queueTimeStat=getMetricsRegistry().newHistogram(TIME_IN_QUEUE_KEY);
    thriftCallStat=getMetricsRegistry().newHistogram(THRIFT_CALL_KEY);
    thriftSlowCallStat=getMetricsRegistry().newHistogram(SLOW_THRIFT_CALL_KEY);
    callQueueLenGauge=getMetricsRegistry().getLongGauge(CALL_QUEUE_LEN_KEY,0);
  }
  @Override public void incTimeInQueue(  long time){
    queueTimeStat.add(time);
  }
  @Override public void setCallQueueLen(  int len){
    callQueueLenGauge.set(len);
  }
  @Override public void incNumRowKeysInBatchGet(  int diff){
    batchGetStat.add(diff);
  }
  @Override public void incNumRowKeysInBatchMutate(  int diff){
    batchMutateStat.add(diff);
  }
  @Override public void incMethodTime(  String name,  long time){
    MutableHistogram s=getMetricsRegistry().getHistogram(name);
    s.add(time);
  }
  @Override public void incCall(  long time){
    thriftCallStat.add(time);
  }
  @Override public void incSlowCall(  long time){
    thriftSlowCallStat.add(time);
  }
}
