public class DemoClient {
  private static String host="localhost";
  private static int port=9090;
  private static boolean secure=false;
  public static void main(  String[] args) throws Exception {
    System.out.println("Thrift2 Demo");
    System.out.println("Usage: DemoClient [host=localhost] [port=9090] [secure=false]");
    System.out.println("This demo assumes you have a table called \"example\" with a column family called \"family1\"");
    if (args.length >= 1) {
      host=args[0];
    }
    if (args.length >= 2) {
      port=Integer.parseInt(args[1]);
    }
    if (args.length >= 3) {
      secure=Boolean.parseBoolean(args[2]);
    }
    final DemoClient client=new DemoClient();
    Subject.doAs(getSubject(),new PrivilegedExceptionAction<Void>(){
      @Override public Void run() throws Exception {
        client.run();
        return null;
      }
    }
);
  }
  public void run() throws Exception {
    int timeout=10000;
    boolean framed=false;
    TTransport transport=new TSocket(host,port,timeout);
    if (framed) {
      transport=new TFramedTransport(transport);
    }
 else     if (secure) {
      Map<String,String> saslProperties=new HashMap<String,String>();
      saslProperties.put(Sasl.QOP,"auth-conf,auth-int,auth");
      transport=new TSaslClientTransport("GSSAPI",null,"hbase",host,saslProperties,null,transport);
    }
    TProtocol protocol=new TBinaryProtocol(transport);
    THBaseService.Iface client=new THBaseService.Client(protocol);
    transport.open();
    ByteBuffer table=ByteBuffer.wrap("example".getBytes());
    TPut put=new TPut();
    put.setRow("row1".getBytes());
    TColumnValue columnValue=new TColumnValue();
    columnValue.setFamily("family1".getBytes());
    columnValue.setQualifier("qualifier1".getBytes());
    columnValue.setValue("value1".getBytes());
    List<TColumnValue> columnValues=new ArrayList<TColumnValue>();
    columnValues.add(columnValue);
    put.setColumnValues(columnValues);
    client.put(table,put);
    TGet get=new TGet();
    get.setRow("row1".getBytes());
    TResult result=client.get(table,get);
    System.out.print("row = " + new String(result.getRow()));
    for (    TColumnValue resultColumnValue : result.getColumnValues()) {
      System.out.print("family = " + new String(resultColumnValue.getFamily()));
      System.out.print("qualifier = " + new String(resultColumnValue.getFamily()));
      System.out.print("value = " + new String(resultColumnValue.getValue()));
      System.out.print("timestamp = " + resultColumnValue.getTimestamp());
    }
    transport.close();
  }
  static Subject getSubject() throws Exception {
    if (!secure)     return new Subject();
    LoginContext context=new LoginContext("",new Subject(),null,new Configuration(){
      @Override public AppConfigurationEntry[] getAppConfigurationEntry(      String name){
        Map<String,String> options=new HashMap<String,String>();
        options.put("useKeyTab","false");
        options.put("storeKey","false");
        options.put("doNotPrompt","true");
        options.put("useTicketCache","true");
        options.put("renewTGT","true");
        options.put("refreshKrb5Config","true");
        options.put("isInitiator","true");
        String ticketCache=System.getenv("KRB5CCNAME");
        if (ticketCache != null) {
          options.put("ticketCache",ticketCache);
        }
        options.put("debug","true");
        return new AppConfigurationEntry[]{new AppConfigurationEntry("com.sun.security.auth.module.Krb5LoginModule",AppConfigurationEntry.LoginModuleControlFlag.REQUIRED,options)};
      }
    }
);
    context.login();
    return context.getSubject();
  }
}
