/** 
 * A  {@link org.apache.hadoop.hbase.replication.ReplicationEndpoint}implementation for replicating to another HBase cluster. For the slave cluster it selects a random number of peers using a replication ratio. For example, if replication ration = 0.1 and slave cluster has 100 region servers, 10 will be selected. <p> A stream is considered down when we cannot contact a region server on the peer cluster for more than 55 seconds by default. </p>
 */
@InterfaceAudience.Private public class HBaseInterClusterReplicationEndpoint extends HBaseReplicationEndpoint {
  private static final Logger LOG=LoggerFactory.getLogger(HBaseInterClusterReplicationEndpoint.class);
  private static final long DEFAULT_MAX_TERMINATION_WAIT_MULTIPLIER=2;
  private ClusterConnection conn;
  private Configuration localConf;
  private Configuration conf;
  private long sleepForRetries;
  private int maxRetriesMultiplier;
  private int socketTimeoutMultiplier;
  private long maxTerminationWait;
  private int replicationRpcLimit;
  private MetricsSource metrics;
  private ReplicationSinkManager replicationSinkMgr;
  private boolean peersSelected=false;
  private String replicationClusterId="";
  private ThreadPoolExecutor exec;
  private int maxThreads;
  private Path baseNamespaceDir;
  private Path hfileArchiveDir;
  private boolean replicationBulkLoadDataEnabled;
  private Abortable abortable;
  private boolean dropOnDeletedTables;
  private boolean isSerial=false;
  @Override public void init(  Context context) throws IOException {
    super.init(context);
    this.conf=HBaseConfiguration.create(ctx.getConfiguration());
    this.localConf=HBaseConfiguration.create(ctx.getLocalConfiguration());
    decorateConf();
    this.maxRetriesMultiplier=this.conf.getInt("replication.source.maxretriesmultiplier",300);
    this.socketTimeoutMultiplier=this.conf.getInt("replication.source.socketTimeoutMultiplier",maxRetriesMultiplier);
    long maxTerminationWaitMultiplier=this.conf.getLong("replication.source.maxterminationmultiplier",DEFAULT_MAX_TERMINATION_WAIT_MULTIPLIER);
    this.maxTerminationWait=maxTerminationWaitMultiplier * this.conf.getLong(HConstants.HBASE_RPC_TIMEOUT_KEY,HConstants.DEFAULT_HBASE_RPC_TIMEOUT);
    this.conn=(ClusterConnection)ConnectionFactory.createConnection(this.conf);
    this.sleepForRetries=this.conf.getLong("replication.source.sleepforretries",1000);
    this.metrics=context.getMetrics();
    this.replicationSinkMgr=new ReplicationSinkManager(conn,ctx.getPeerId(),this,this.conf);
    this.maxThreads=this.conf.getInt(HConstants.REPLICATION_SOURCE_MAXTHREADS_KEY,HConstants.REPLICATION_SOURCE_MAXTHREADS_DEFAULT);
    this.exec=Threads.getBoundedCachedThreadPool(maxThreads,60,TimeUnit.SECONDS,new ThreadFactoryBuilder().setDaemon(true).setNameFormat("SinkThread-%d").build());
    this.abortable=ctx.getAbortable();
    this.replicationRpcLimit=(int)(0.95 * conf.getLong(RpcServer.MAX_REQUEST_SIZE,RpcServer.DEFAULT_MAX_REQUEST_SIZE));
    this.dropOnDeletedTables=this.conf.getBoolean(HConstants.REPLICATION_DROP_ON_DELETED_TABLE_KEY,false);
    this.replicationBulkLoadDataEnabled=conf.getBoolean(HConstants.REPLICATION_BULKLOAD_ENABLE_KEY,HConstants.REPLICATION_BULKLOAD_ENABLE_DEFAULT);
    if (this.replicationBulkLoadDataEnabled) {
      replicationClusterId=this.conf.get(HConstants.REPLICATION_CLUSTER_ID);
    }
    Path rootDir=FSUtils.getRootDir(conf);
    Path baseNSDir=new Path(HConstants.BASE_NAMESPACE_DIR);
    baseNamespaceDir=new Path(rootDir,baseNSDir);
    hfileArchiveDir=new Path(rootDir,new Path(HConstants.HFILE_ARCHIVE_DIRECTORY,baseNSDir));
    isSerial=context.getPeerConfig().isSerial();
  }
  private void decorateConf(){
    String replicationCodec=this.conf.get(HConstants.REPLICATION_CODEC_CONF_KEY);
    if (StringUtils.isNotEmpty(replicationCodec)) {
      this.conf.set(HConstants.RPC_CODEC_CONF_KEY,replicationCodec);
    }
  }
  private void connectToPeers(){
    getRegionServers();
    int sleepMultiplier=1;
    while (this.isRunning() && replicationSinkMgr.getNumSinks() == 0) {
      replicationSinkMgr.chooseSinks();
      if (this.isRunning() && replicationSinkMgr.getNumSinks() == 0) {
        if (sleepForRetries("Waiting for peers",sleepMultiplier)) {
          sleepMultiplier++;
        }
      }
    }
  }
  /** 
 * Do the sleeping logic
 * @param msg Why we sleep
 * @param sleepMultiplier by how many times the default sleeping time is augmented
 * @return True if <code>sleepMultiplier</code> is &lt; <code>maxRetriesMultiplier</code>
 */
  protected boolean sleepForRetries(  String msg,  int sleepMultiplier){
    try {
      if (LOG.isTraceEnabled()) {
        LOG.trace("{} {}, sleeping {} times {}",logPeerId(),msg,sleepForRetries,sleepMultiplier);
      }
      Thread.sleep(this.sleepForRetries * sleepMultiplier);
    }
 catch (    InterruptedException e) {
      if (LOG.isDebugEnabled()) {
        LOG.debug("{} Interrupted while sleeping between retries",logPeerId());
      }
    }
    return sleepMultiplier < maxRetriesMultiplier;
  }
  private int getEstimatedEntrySize(  Entry e){
    long size=e.getKey().estimatedSerializedSizeOf() + e.getEdit().estimatedSerializedSizeOf();
    return (int)size;
  }
  private List<List<Entry>> createParallelBatches(  final List<Entry> entries){
    int numSinks=Math.max(replicationSinkMgr.getNumSinks(),1);
    int n=Math.min(Math.min(this.maxThreads,entries.size() / 100 + 1),numSinks);
    List<List<Entry>> entryLists=Stream.generate(ArrayList<Entry>::new).limit(n).collect(Collectors.toList());
    int[] sizes=new int[n];
    for (    Entry e : entries) {
      int index=Math.abs(Bytes.hashCode(e.getKey().getEncodedRegionName()) % n);
      int entrySize=getEstimatedEntrySize(e);
      if (sizes[index] > 0 && sizes[index] + entrySize > replicationRpcLimit) {
        entryLists.add(entryLists.get(index));
        entryLists.set(index,new ArrayList<>());
        sizes[index]=0;
      }
      entryLists.get(index).add(e);
      sizes[index]+=entrySize;
    }
    return entryLists;
  }
  private List<List<Entry>> createSerialBatches(  final List<Entry> entries){
    Map<byte[],List<Entry>> regionEntries=new TreeMap<>(Bytes.BYTES_COMPARATOR);
    for (    Entry e : entries) {
      regionEntries.computeIfAbsent(e.getKey().getEncodedRegionName(),key -> new ArrayList<>()).add(e);
    }
    return new ArrayList<>(regionEntries.values());
  }
  /** 
 * Divide the entries into multiple batches, so that we can replicate each batch in a thread pool concurrently. Note that, for serial replication, we need to make sure that entries from the same region to be replicated serially, so entries from the same region consist of a batch, and we will divide a batch into several batches by replicationRpcLimit in method serialReplicateRegionEntries()
 */
  private List<List<Entry>> createBatches(  final List<Entry> entries){
    if (isSerial) {
      return createSerialBatches(entries);
    }
 else {
      return createParallelBatches(entries);
    }
  }
  private TableName parseTable(  String msg){
    Pattern p=Pattern.compile("TableNotFoundException: '([\\S]*)'");
    Matcher m=p.matcher(msg);
    if (m.find()) {
      String table=m.group(1);
      try {
        TableName.valueOf(TableName.isLegalFullyQualifiedTableName(Bytes.toBytes(table)));
        return TableName.valueOf(table);
      }
 catch (      IllegalArgumentException ignore) {
      }
    }
    return null;
  }
  private List<List<Entry>> filterBatches(  final List<List<Entry>> oldEntryList,  TableName table){
    return oldEntryList.stream().map(entries -> entries.stream().filter(e -> !e.getKey().getTableName().equals(table)).collect(Collectors.toList())).collect(Collectors.toList());
  }
  private void reconnectToPeerCluster(){
    ClusterConnection connection=null;
    try {
      connection=(ClusterConnection)ConnectionFactory.createConnection(this.conf);
    }
 catch (    IOException ioe) {
      LOG.warn("{} Failed to create connection for peer cluster",logPeerId(),ioe);
    }
    if (connection != null) {
      this.conn=connection;
    }
  }
  private long parallelReplicate(  CompletionService<Integer> pool,  ReplicateContext replicateContext,  List<List<Entry>> batches) throws IOException {
    int futures=0;
    for (int i=0; i < batches.size(); i++) {
      List<Entry> entries=batches.get(i);
      if (!entries.isEmpty()) {
        if (LOG.isTraceEnabled()) {
          LOG.trace("{} Submitting {} entries of total size {}",logPeerId(),entries.size(),replicateContext.getSize());
        }
        pool.submit(createReplicator(entries,i));
        futures++;
      }
    }
    IOException iox=null;
    long lastWriteTime=0;
    for (int i=0; i < futures; i++) {
      try {
        Future<Integer> f=pool.take();
        int index=f.get();
        List<Entry> batch=batches.get(index);
        batches.set(index,Collections.emptyList());
        long writeTime=batch.get(batch.size() - 1).getKey().getWriteTime();
        if (writeTime > lastWriteTime) {
          lastWriteTime=writeTime;
        }
      }
 catch (      InterruptedException ie) {
        iox=new IOException(ie);
      }
catch (      ExecutionException ee) {
        iox=(IOException)ee.getCause();
      }
    }
    if (iox != null) {
      throw iox;
    }
    return lastWriteTime;
  }
  /** 
 * Do the shipping logic
 */
  @Override public boolean replicate(  ReplicateContext replicateContext){
    CompletionService<Integer> pool=new ExecutorCompletionService<>(this.exec);
    String walGroupId=replicateContext.getWalGroupId();
    int sleepMultiplier=1;
    if (!peersSelected && this.isRunning()) {
      connectToPeers();
      peersSelected=true;
    }
    int numSinks=replicationSinkMgr.getNumSinks();
    if (numSinks == 0) {
      LOG.warn("{} No replication sinks found, returning without replicating. " + "The source should retry with the same set of edits.",logPeerId());
      return false;
    }
    List<List<Entry>> batches=createBatches(replicateContext.getEntries());
    while (this.isRunning() && !exec.isShutdown()) {
      if (!isPeerEnabled()) {
        if (sleepForRetries("Replication is disabled",sleepMultiplier)) {
          sleepMultiplier++;
        }
        continue;
      }
      if (this.conn == null || this.conn.isClosed()) {
        reconnectToPeerCluster();
      }
      try {
        long lastWriteTime;
        lastWriteTime=parallelReplicate(pool,replicateContext,batches);
        if (lastWriteTime > 0) {
          this.metrics.setAgeOfLastShippedOp(lastWriteTime,walGroupId);
        }
        return true;
      }
 catch (      IOException ioe) {
        this.metrics.refreshAgeOfLastShippedOp(walGroupId);
        if (ioe instanceof RemoteException) {
          ioe=((RemoteException)ioe).unwrapRemoteException();
          LOG.warn("{} Can't replicate because of an error on the remote cluster: ",logPeerId(),ioe);
          if (ioe instanceof TableNotFoundException) {
            if (dropOnDeletedTables) {
              TableName table=parseTable(ioe.getMessage());
              if (table != null) {
                try (Connection localConn=ConnectionFactory.createConnection(ctx.getLocalConfiguration())){
                  if (!localConn.getAdmin().tableExists(table)) {
                    LOG.info("{} Missing table detected at sink, local table also does not " + "exist, filtering edits for '{}'",logPeerId(),table);
                    batches=filterBatches(batches,table);
                    continue;
                  }
                }
 catch (                IOException iox) {
                  LOG.warn("{} Exception checking for local table: ",logPeerId(),iox);
                }
              }
            }
          }
 else {
            LOG.warn("{} Peer encountered RemoteException, rechecking all sinks: ",logPeerId(),ioe);
            replicationSinkMgr.chooseSinks();
          }
        }
 else {
          if (ioe instanceof SocketTimeoutException) {
            sleepForRetries("Encountered a SocketTimeoutException. Since the " + "call to the remote cluster timed out, which is usually " + "caused by a machine failure or a massive slowdown",this.socketTimeoutMultiplier);
          }
 else           if (ioe instanceof ConnectException || ioe instanceof UnknownHostException) {
            LOG.warn("{} Peer is unavailable, rechecking all sinks: ",logPeerId(),ioe);
            replicationSinkMgr.chooseSinks();
          }
 else {
            LOG.warn("{} Can't replicate because of a local or network error: ",logPeerId(),ioe);
          }
        }
        if (sleepForRetries("Since we are unable to replicate",sleepMultiplier)) {
          sleepMultiplier++;
        }
      }
    }
    return false;
  }
  protected boolean isPeerEnabled(){
    return ctx.getReplicationPeer().isPeerEnabled();
  }
  @Override protected void doStop(){
    disconnect();
    if (this.conn != null) {
      try {
        this.conn.close();
        this.conn=null;
      }
 catch (      IOException e) {
        LOG.warn("{} Failed to close the connection",logPeerId());
      }
    }
    exec.shutdown();
    try {
      exec.awaitTermination(maxTerminationWait,TimeUnit.MILLISECONDS);
    }
 catch (    InterruptedException e) {
    }
    if (!exec.isTerminated()) {
      String errMsg="HBaseInterClusterReplicationEndpoint termination failed. The " + "ThreadPoolExecutor failed to finish all tasks within " + maxTerminationWait + "ms. "+ "Aborting to prevent Replication from deadlocking. See HBASE-16081.";
      abortable.abort(errMsg,new IOException(errMsg));
    }
    notifyStopped();
  }
  @VisibleForTesting protected int replicateEntries(  List<Entry> entries,  int batchIndex) throws IOException {
    SinkPeer sinkPeer=null;
    try {
      int entriesHashCode=System.identityHashCode(entries);
      if (LOG.isTraceEnabled()) {
        long size=entries.stream().mapToLong(this::getEstimatedEntrySize).sum();
        LOG.trace("{} Replicating batch {} of {} entries with total size {} bytes to {}",logPeerId(),entriesHashCode,entries.size(),size,replicationClusterId);
      }
      sinkPeer=replicationSinkMgr.getReplicationSink();
      BlockingInterface rrs=sinkPeer.getRegionServer();
      try {
        ReplicationProtbufUtil.replicateWALEntry(rrs,entries.toArray(new Entry[entries.size()]),replicationClusterId,baseNamespaceDir,hfileArchiveDir);
        if (LOG.isTraceEnabled()) {
          LOG.trace("{} Completed replicating batch {}",logPeerId(),entriesHashCode);
        }
      }
 catch (      IOException e) {
        if (LOG.isTraceEnabled()) {
          LOG.trace("{} Failed replicating batch {}",logPeerId(),entriesHashCode,e);
        }
        throw e;
      }
      replicationSinkMgr.reportSinkSuccess(sinkPeer);
    }
 catch (    IOException ioe) {
      if (sinkPeer != null) {
        replicationSinkMgr.reportBadSink(sinkPeer);
      }
      throw ioe;
    }
    return batchIndex;
  }
  private int serialReplicateRegionEntries(  List<Entry> entries,  int batchIndex) throws IOException {
    int batchSize=0, index=0;
    List<Entry> batch=new ArrayList<>();
    for (    Entry entry : entries) {
      int entrySize=getEstimatedEntrySize(entry);
      if (batchSize > 0 && batchSize + entrySize > replicationRpcLimit) {
        replicateEntries(batch,index++);
        batch.clear();
        batchSize=0;
      }
      batch.add(entry);
      batchSize+=entrySize;
    }
    if (batchSize > 0) {
      replicateEntries(batch,index);
    }
    return batchIndex;
  }
  @VisibleForTesting protected Callable<Integer> createReplicator(  List<Entry> entries,  int batchIndex){
    return isSerial ? () -> serialReplicateRegionEntries(entries,batchIndex) : () -> replicateEntries(entries,batchIndex);
  }
  private String logPeerId(){
    return "[Source for peer " + this.ctx.getPeerId() + "]:";
  }
}
