public static class CustomFilter extends FilterBase {
  private String key=null;
  public CustomFilter(){
  }
  public CustomFilter(  String key){
    this.key=key;
  }
  public String getKey(){
    return key;
  }
  public void write(  DataOutput out) throws IOException {
    Text.writeString(out,this.key);
  }
  public void readFields(  DataInput in) throws IOException {
    this.key=Text.readString(in);
  }
}
