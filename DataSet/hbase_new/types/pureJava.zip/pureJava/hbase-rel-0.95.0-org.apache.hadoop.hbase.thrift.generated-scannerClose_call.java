public static class scannerClose_call extends org.apache.thrift.async.TAsyncMethodCall {
  private int id;
  public scannerClose_call(  int id,  org.apache.thrift.async.AsyncMethodCallback<scannerClose_call> resultHandler,  org.apache.thrift.async.TAsyncClient client,  org.apache.thrift.protocol.TProtocolFactory protocolFactory,  org.apache.thrift.transport.TNonblockingTransport transport) throws org.apache.thrift.TException {
    super(client,protocolFactory,transport,resultHandler,false);
    this.id=id;
  }
  public void write_args(  org.apache.thrift.protocol.TProtocol prot) throws org.apache.thrift.TException {
    prot.writeMessageBegin(new org.apache.thrift.protocol.TMessage("scannerClose",org.apache.thrift.protocol.TMessageType.CALL,0));
    scannerClose_args args=new scannerClose_args();
    args.setId(id);
    args.write(prot);
    prot.writeMessageEnd();
  }
  public void getResult() throws IOError, IllegalArgument, org.apache.thrift.TException {
    if (getState() != org.apache.thrift.async.TAsyncMethodCall.State.RESPONSE_READ) {
      throw new IllegalStateException("Method call not finished!");
    }
    org.apache.thrift.transport.TMemoryInputTransport memoryTransport=new org.apache.thrift.transport.TMemoryInputTransport(getFrameBuffer().array());
    org.apache.thrift.protocol.TProtocol prot=client.getProtocolFactory().getProtocol(memoryTransport);
    (new Client(prot)).recv_scannerClose();
  }
}
