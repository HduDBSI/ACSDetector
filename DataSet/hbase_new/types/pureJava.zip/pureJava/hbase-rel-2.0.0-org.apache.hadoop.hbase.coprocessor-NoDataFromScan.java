/** 
 * Don't return any data from a scan by creating a custom  {@link StoreScanner}.
 */
public static class NoDataFromScan implements RegionCoprocessor, RegionObserver {
  @Override public Optional<RegionObserver> getRegionObserver(){
    return Optional.of(this);
  }
  @Override public void preGetOp(  ObserverContext<RegionCoprocessorEnvironment> c,  Get get,  List<Cell> result) throws IOException {
    c.bypass();
  }
  @Override public void preScannerOpen(  ObserverContext<RegionCoprocessorEnvironment> c,  Scan scan) throws IOException {
    scan.setFilter(new NoDataFilter());
  }
}
