public class HbckTestingUtil {
  public static HBaseFsck doFsck(  Configuration conf,  boolean fix) throws Exception {
    HBaseFsck fsck=new HBaseFsck(conf);
    fsck.connect();
    fsck.displayFullReport();
    fsck.setTimeLag(0);
    fsck.setFixErrors(fix);
    fsck.doWork();
    return fsck;
  }
  public static void assertNoErrors(  HBaseFsck fsck) throws Exception {
    List<ERROR_CODE> errs=fsck.getErrors().getErrorList();
    assertEquals(0,errs.size());
  }
  public static void assertErrors(  HBaseFsck fsck,  ERROR_CODE[] expectedErrors){
    List<ERROR_CODE> errs=fsck.getErrors().getErrorList();
    assertEquals(Arrays.asList(expectedErrors),errs);
  }
}
