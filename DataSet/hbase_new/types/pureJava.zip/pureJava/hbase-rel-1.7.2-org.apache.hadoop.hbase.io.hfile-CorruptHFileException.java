/** 
 * This exception is thrown when attempts to read an HFile fail due to corruption or truncation issues.
 */
@InterfaceAudience.Private public class CorruptHFileException extends DoNotRetryIOException {
  private static final long serialVersionUID=1L;
  public CorruptHFileException(  String m,  Throwable t){
    super(m,t);
  }
  public CorruptHFileException(  String m){
    super(m);
  }
}
