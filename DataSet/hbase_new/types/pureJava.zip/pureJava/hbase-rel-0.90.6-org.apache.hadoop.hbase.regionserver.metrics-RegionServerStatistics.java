/** 
 * Exports metrics recorded by  {@link RegionServerMetrics} as an MBeanfor JMX monitoring.
 */
public class RegionServerStatistics extends MetricsMBeanBase {
  private final ObjectName mbeanName;
  public RegionServerStatistics(  MetricsRegistry registry,  String rsName){
    super(registry,"RegionServerStatistics");
    mbeanName=MBeanUtil.registerMBean("RegionServer","RegionServerStatistics",this);
  }
  public void shutdown(){
    if (mbeanName != null)     MBeanUtil.unregisterMBean(mbeanName);
  }
}
