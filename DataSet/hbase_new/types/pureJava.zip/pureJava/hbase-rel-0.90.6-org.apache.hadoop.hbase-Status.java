/** 
 * Implementations can have their status set.
 */
static interface Status {
  /** 
 * Sets status
 * @param msg status message
 * @throws IOException
 */
  void setStatus(  final String msg) throws IOException ;
}
