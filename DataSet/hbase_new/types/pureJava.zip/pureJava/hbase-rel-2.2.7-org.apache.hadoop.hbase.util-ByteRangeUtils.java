/** 
 * Utility methods for working with  {@link ByteRange}.
 */
@InterfaceAudience.Public public class ByteRangeUtils {
  public static int numEqualPrefixBytes(  ByteRange left,  ByteRange right,  int rightInnerOffset){
    int maxCompares=Math.min(left.getLength(),right.getLength() - rightInnerOffset);
    final byte[] lbytes=left.getBytes();
    final byte[] rbytes=right.getBytes();
    final int loffset=left.getOffset();
    final int roffset=right.getOffset();
    for (int i=0; i < maxCompares; ++i) {
      if (lbytes[loffset + i] != rbytes[roffset + rightInnerOffset + i]) {
        return i;
      }
    }
    return maxCompares;
  }
  public static ArrayList<byte[]> copyToNewArrays(  Collection<ByteRange> ranges){
    if (ranges == null) {
      return new ArrayList<>(0);
    }
    ArrayList<byte[]> arrays=Lists.newArrayListWithCapacity(ranges.size());
    for (    ByteRange range : ranges) {
      arrays.add(range.deepCopyToNewArray());
    }
    return arrays;
  }
  public static ArrayList<ByteRange> fromArrays(  Collection<byte[]> arrays){
    if (arrays == null) {
      return new ArrayList<>(0);
    }
    ArrayList<ByteRange> ranges=Lists.newArrayListWithCapacity(arrays.size());
    for (    byte[] array : arrays) {
      ranges.add(new SimpleMutableByteRange(array));
    }
    return ranges;
  }
  public static void write(  OutputStream os,  ByteRange byteRange) throws IOException {
    os.write(byteRange.getBytes(),byteRange.getOffset(),byteRange.getLength());
  }
  public static void write(  OutputStream os,  ByteRange byteRange,  int byteRangeInnerOffset) throws IOException {
    os.write(byteRange.getBytes(),byteRange.getOffset() + byteRangeInnerOffset,byteRange.getLength() - byteRangeInnerOffset);
  }
}
