/** 
 * Callable that handles the <code>multi</code> method call going against a single regionserver; i.e. A  {@link RegionServerCallable} for the multi call (It is not a{@link RegionServerCallable} that goes against multiple regions.
 * @param < R >
 */
class MultiServerCallable<R> extends RegionServerCallable<MultiResponse> {
  private final MultiAction<R> multi;
  MultiServerCallable(  final HConnection connection,  final TableName tableName,  final HRegionLocation location,  final MultiAction<R> multi){
    super(connection,tableName,null);
    this.multi=multi;
    setLocation(location);
  }
  MultiAction<R> getMulti(){
    return this.multi;
  }
  @Override public MultiResponse call() throws IOException {
    MultiResponse response=new MultiResponse();
    for (    Map.Entry<byte[],List<Action<R>>> e : this.multi.actions.entrySet()) {
      byte[] regionName=e.getKey();
      int rowMutations=0;
      List<Action<R>> actions=e.getValue();
      for (      Action<R> action : actions) {
        Row row=action.getAction();
        if (row instanceof RowMutations) {
          try {
            RowMutations rms=(RowMutations)row;
            List<CellScannable> cells=new ArrayList<CellScannable>(rms.getMutations().size());
            MultiRequest multiRequest=RequestConverter.buildNoDataMultiRequest(regionName,rms,cells);
            getStub().multi(new PayloadCarryingRpcController(cells),multiRequest);
            response.add(regionName,action.getOriginalIndex(),Result.EMPTY_RESULT);
          }
 catch (          ServiceException se) {
            response.add(regionName,action.getOriginalIndex(),ProtobufUtil.getRemoteException(se));
          }
          rowMutations++;
        }
      }
      if (actions.size() > rowMutations) {
        Exception ex=null;
        List<Object> results=null;
        List<CellScannable> cells=new ArrayList<CellScannable>(actions.size() - rowMutations);
        try {
          MultiRequest multiRequest=RequestConverter.buildNoDataMultiRequest(regionName,actions,cells);
          PayloadCarryingRpcController controller=new PayloadCarryingRpcController(cells);
          ClientProtos.MultiResponse responseProto=getStub().multi(controller,multiRequest);
          results=ResponseConverter.getResults(responseProto,controller.cellScanner());
        }
 catch (        ServiceException se) {
          ex=ProtobufUtil.getRemoteException(se);
        }
        for (int i=0, n=actions.size(); i < n; i++) {
          int originalIndex=actions.get(i).getOriginalIndex();
          response.add(regionName,originalIndex,results == null ? ex : results.get(i));
        }
      }
    }
    return response;
  }
  @Override public void prepare(  boolean reload) throws IOException {
    setStub(getConnection().getClient(getLocation().getServerName()));
  }
}
