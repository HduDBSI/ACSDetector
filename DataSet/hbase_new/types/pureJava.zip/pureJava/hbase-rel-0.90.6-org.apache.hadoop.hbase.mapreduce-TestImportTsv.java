public class TestImportTsv {
  @Test public void testTsvParserSpecParsing(){
    TsvParser parser;
    parser=new TsvParser("HBASE_ROW_KEY","\t");
    assertNull(parser.getFamily(0));
    assertNull(parser.getQualifier(0));
    assertEquals(0,parser.getRowKeyColumnIndex());
    parser=new TsvParser("HBASE_ROW_KEY,col1:scol1","\t");
    assertNull(parser.getFamily(0));
    assertNull(parser.getQualifier(0));
    assertBytesEquals(Bytes.toBytes("col1"),parser.getFamily(1));
    assertBytesEquals(Bytes.toBytes("scol1"),parser.getQualifier(1));
    assertEquals(0,parser.getRowKeyColumnIndex());
    parser=new TsvParser("HBASE_ROW_KEY,col1:scol1,col1:scol2","\t");
    assertNull(parser.getFamily(0));
    assertNull(parser.getQualifier(0));
    assertBytesEquals(Bytes.toBytes("col1"),parser.getFamily(1));
    assertBytesEquals(Bytes.toBytes("scol1"),parser.getQualifier(1));
    assertBytesEquals(Bytes.toBytes("col1"),parser.getFamily(2));
    assertBytesEquals(Bytes.toBytes("scol2"),parser.getQualifier(2));
    assertEquals(0,parser.getRowKeyColumnIndex());
  }
  @Test public void testTsvParser() throws BadTsvLineException {
    TsvParser parser=new TsvParser("col_a,col_b:qual,HBASE_ROW_KEY,col_d","\t");
    assertBytesEquals(Bytes.toBytes("col_a"),parser.getFamily(0));
    assertBytesEquals(HConstants.EMPTY_BYTE_ARRAY,parser.getQualifier(0));
    assertBytesEquals(Bytes.toBytes("col_b"),parser.getFamily(1));
    assertBytesEquals(Bytes.toBytes("qual"),parser.getQualifier(1));
    assertNull(parser.getFamily(2));
    assertNull(parser.getQualifier(2));
    assertEquals(2,parser.getRowKeyColumnIndex());
    byte[] line=Bytes.toBytes("val_a\tval_b\tval_c\tval_d");
    ParsedLine parsed=parser.parse(line,line.length);
    checkParsing(parsed,Splitter.on("\t").split(Bytes.toString(line)));
  }
  private void checkParsing(  ParsedLine parsed,  Iterable<String> expected){
    ArrayList<String> parsedCols=new ArrayList<String>();
    for (int i=0; i < parsed.getColumnCount(); i++) {
      parsedCols.add(Bytes.toString(parsed.getLineBytes(),parsed.getColumnOffset(i),parsed.getColumnLength(i)));
    }
    if (!Iterables.elementsEqual(parsedCols,expected)) {
      fail("Expected: " + Joiner.on(",").join(expected) + "\n"+ "Got:"+ Joiner.on(",").join(parsedCols));
    }
  }
  private void assertBytesEquals(  byte[] a,  byte[] b){
    assertEquals(Bytes.toStringBinary(a),Bytes.toStringBinary(b));
  }
  /** 
 * Test cases that throw BadTsvLineException
 */
  @Test(expected=BadTsvLineException.class) public void testTsvParserBadTsvLineExcessiveColumns() throws BadTsvLineException {
    TsvParser parser=new TsvParser("HBASE_ROW_KEY,col_a","\t");
    byte[] line=Bytes.toBytes("val_a\tval_b\tval_c");
    ParsedLine parsed=parser.parse(line,line.length);
  }
  @Test(expected=BadTsvLineException.class) public void testTsvParserBadTsvLineZeroColumn() throws BadTsvLineException {
    TsvParser parser=new TsvParser("HBASE_ROW_KEY,col_a","\t");
    byte[] line=Bytes.toBytes("");
    ParsedLine parsed=parser.parse(line,line.length);
  }
  @Test(expected=BadTsvLineException.class) public void testTsvParserBadTsvLineOnlyKey() throws BadTsvLineException {
    TsvParser parser=new TsvParser("HBASE_ROW_KEY,col_a","\t");
    byte[] line=Bytes.toBytes("key_only");
    ParsedLine parsed=parser.parse(line,line.length);
  }
  @Test(expected=BadTsvLineException.class) public void testTsvParserBadTsvLineNoRowKey() throws BadTsvLineException {
    TsvParser parser=new TsvParser("col_a,HBASE_ROW_KEY","\t");
    byte[] line=Bytes.toBytes("only_cola_data_and_no_row_key");
    ParsedLine parsed=parser.parse(line,line.length);
  }
  @Test public void testMROnTable() throws Exception {
    String TABLE_NAME="TestTable";
    String FAMILY="FAM";
    String INPUT_FILE="InputFile.esv";
    String[] args=new String[]{"-D" + ImportTsv.COLUMNS_CONF_KEY + "=HBASE_ROW_KEY,FAM:A,FAM:B","-D" + ImportTsv.SEPARATOR_CONF_KEY + "=\u001b",TABLE_NAME,INPUT_FILE};
    HBaseTestingUtility htu1=new HBaseTestingUtility();
    MiniHBaseCluster cluster=htu1.startMiniCluster();
    GenericOptionsParser opts=new GenericOptionsParser(cluster.getConfiguration(),args);
    Configuration conf=opts.getConfiguration();
    args=opts.getRemainingArgs();
    try {
      FileSystem fs=FileSystem.get(conf);
      FSDataOutputStream op=fs.create(new Path(INPUT_FILE),true);
      String line="KEY\u001bVALUE1\u001bVALUE2\n";
      op.write(line.getBytes(HConstants.UTF8_ENCODING));
      op.close();
      final byte[] FAM=Bytes.toBytes(FAMILY);
      final byte[] TAB=Bytes.toBytes(TABLE_NAME);
      final byte[] QA=Bytes.toBytes("A");
      final byte[] QB=Bytes.toBytes("B");
      HTableDescriptor desc=new HTableDescriptor(TAB);
      desc.addFamily(new HColumnDescriptor(FAM));
      new HBaseAdmin(conf).createTable(desc);
      Job job=ImportTsv.createSubmittableJob(conf,args);
      job.waitForCompletion(false);
      assertTrue(job.isSuccessful());
      HTable table=new HTable(new Configuration(conf),TAB);
      boolean verified=false;
      long pause=conf.getLong("hbase.client.pause",5 * 1000);
      int numRetries=conf.getInt("hbase.client.retries.number",5);
      for (int i=0; i < numRetries; i++) {
        try {
          Scan scan=new Scan();
          scan.addFamily(FAM);
          ResultScanner resScanner=table.getScanner(scan);
          for (          Result res : resScanner) {
            assertTrue(res.size() == 2);
            List<KeyValue> kvs=res.list();
            assertEquals(toU8Str(kvs.get(0).getRow()),toU8Str(Bytes.toBytes("KEY")));
            assertEquals(toU8Str(kvs.get(1).getRow()),toU8Str(Bytes.toBytes("KEY")));
            assertEquals(toU8Str(kvs.get(0).getValue()),toU8Str(Bytes.toBytes("VALUE1")));
            assertEquals(toU8Str(kvs.get(1).getValue()),toU8Str(Bytes.toBytes("VALUE2")));
          }
          verified=true;
          break;
        }
 catch (        NullPointerException e) {
        }
        try {
          Thread.sleep(pause);
        }
 catch (        InterruptedException e) {
        }
      }
      assertTrue(verified);
    }
  finally {
      cluster.shutdown();
    }
  }
  public static String toU8Str(  byte[] bytes) throws UnsupportedEncodingException {
    return new String(bytes,HConstants.UTF8_ENCODING);
  }
}
