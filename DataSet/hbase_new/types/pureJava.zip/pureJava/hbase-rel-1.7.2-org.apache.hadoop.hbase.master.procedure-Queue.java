private static abstract class Queue<TKey extends Comparable<TKey>> implements QueueInterface {
  private Queue<TKey> avlRight=null;
  private Queue<TKey> avlLeft=null;
  private int avlHeight=1;
  private Queue<TKey> iterNext=null;
  private Queue<TKey> iterPrev=null;
  private boolean suspended=false;
  private long exclusiveLockProcIdOwner=Long.MIN_VALUE;
  private int sharedLock=0;
  private final TKey key;
  private final int priority;
  public Queue(  TKey key){
    this(key,1);
  }
  public Queue(  TKey key,  int priority){
    this.key=key;
    this.priority=priority;
  }
  protected TKey getKey(){
    return key;
  }
  protected int getPriority(){
    return priority;
  }
  /** 
 * True if the queue is not in the run-queue and it is owned by an event.
 */
  @Override public boolean isSuspended(){
    return suspended;
  }
  protected boolean setSuspended(  boolean isSuspended){
    if (this.suspended == isSuspended)     return false;
    this.suspended=isSuspended;
    return true;
  }
  public synchronized boolean isLocked(){
    return hasExclusiveLock() || sharedLock > 0;
  }
  public synchronized boolean hasExclusiveLock(){
    return this.exclusiveLockProcIdOwner != Long.MIN_VALUE;
  }
  public synchronized boolean trySharedLock(){
    if (hasExclusiveLock())     return false;
    sharedLock++;
    return true;
  }
  public synchronized void releaseSharedLock(){
    sharedLock--;
  }
  protected synchronized boolean isSingleSharedLock(){
    return sharedLock == 1;
  }
  public synchronized boolean tryExclusiveLock(  long procIdOwner){
    assert procIdOwner != Long.MIN_VALUE;
    if (isLocked())     return false;
    exclusiveLockProcIdOwner=procIdOwner;
    return true;
  }
  public synchronized void releaseExclusiveLock(){
    exclusiveLockProcIdOwner=Long.MIN_VALUE;
  }
  @Override public synchronized boolean isAvailable(){
    return !hasExclusiveLock() && !isEmpty();
  }
  public int compareKey(  TKey cmpKey){
    return key.compareTo(cmpKey);
  }
  public int compareTo(  Queue<TKey> other){
    return compareKey(other.key);
  }
  @Override public String toString(){
    return String.format("%s(%s)",getClass().getSimpleName(),key);
  }
}
