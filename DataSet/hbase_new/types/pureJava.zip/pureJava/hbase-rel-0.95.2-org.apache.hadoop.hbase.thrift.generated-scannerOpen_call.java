public static class scannerOpen_call extends org.apache.thrift.async.TAsyncMethodCall {
  private ByteBuffer tableName;
  private ByteBuffer startRow;
  private List<ByteBuffer> columns;
  private Map<ByteBuffer,ByteBuffer> attributes;
  public scannerOpen_call(  ByteBuffer tableName,  ByteBuffer startRow,  List<ByteBuffer> columns,  Map<ByteBuffer,ByteBuffer> attributes,  org.apache.thrift.async.AsyncMethodCallback<scannerOpen_call> resultHandler,  org.apache.thrift.async.TAsyncClient client,  org.apache.thrift.protocol.TProtocolFactory protocolFactory,  org.apache.thrift.transport.TNonblockingTransport transport) throws org.apache.thrift.TException {
    super(client,protocolFactory,transport,resultHandler,false);
    this.tableName=tableName;
    this.startRow=startRow;
    this.columns=columns;
    this.attributes=attributes;
  }
  public void write_args(  org.apache.thrift.protocol.TProtocol prot) throws org.apache.thrift.TException {
    prot.writeMessageBegin(new org.apache.thrift.protocol.TMessage("scannerOpen",org.apache.thrift.protocol.TMessageType.CALL,0));
    scannerOpen_args args=new scannerOpen_args();
    args.setTableName(tableName);
    args.setStartRow(startRow);
    args.setColumns(columns);
    args.setAttributes(attributes);
    args.write(prot);
    prot.writeMessageEnd();
  }
  public int getResult() throws IOError, org.apache.thrift.TException {
    if (getState() != org.apache.thrift.async.TAsyncMethodCall.State.RESPONSE_READ) {
      throw new IllegalStateException("Method call not finished!");
    }
    org.apache.thrift.transport.TMemoryInputTransport memoryTransport=new org.apache.thrift.transport.TMemoryInputTransport(getFrameBuffer().array());
    org.apache.thrift.protocol.TProtocol prot=client.getProtocolFactory().getProtocol(memoryTransport);
    return (new Client(prot)).recv_scannerOpen();
  }
}
