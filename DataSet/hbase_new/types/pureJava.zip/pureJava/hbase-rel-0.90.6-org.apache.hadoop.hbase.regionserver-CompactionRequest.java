/** 
 * This class represents a compaction request and holds the region, priority, and time submitted.
 */
private class CompactionRequest implements Comparable<CompactionRequest> {
  private final HRegion r;
  private final int p;
  private final Long timeInNanos;
  public CompactionRequest(  HRegion r,  int p){
    this(r,p,null);
  }
  public CompactionRequest(  HRegion r,  int p,  Long time){
    if (r == null) {
      throw new NullPointerException("HRegion cannot be null");
    }
    if (time == null) {
      time=System.nanoTime();
    }
    this.r=r;
    this.p=p;
    this.timeInNanos=time;
  }
  /** 
 * This function will define where in the priority queue the request will end up.  Those with the highest priorities will be first.  When the priorities are the same it will It will first compare priority then date to maintain a FIFO functionality. <p>Note: The date is only accurate to the millisecond which means it is possible that two requests were inserted into the queue within a millisecond.  When that is the case this function will break the tie arbitrarily.
 */
  @Override public int compareTo(  CompactionRequest request){
    if (this.equals(request)) {
      return 0;
    }
    int compareVal;
    compareVal=p - request.p;
    if (compareVal != 0) {
      return compareVal;
    }
    compareVal=timeInNanos.compareTo(request.timeInNanos);
    if (compareVal != 0) {
      return compareVal;
    }
    return -1;
  }
  /** 
 * Gets the HRegion for the request 
 */
  HRegion getHRegion(){
    return r;
  }
  /** 
 * Gets the priority for the request 
 */
  int getPriority(){
    return p;
  }
  public String toString(){
    return "regionName=" + r.getRegionNameAsString() + ", priority="+ p+ ", time="+ timeInNanos;
  }
}
