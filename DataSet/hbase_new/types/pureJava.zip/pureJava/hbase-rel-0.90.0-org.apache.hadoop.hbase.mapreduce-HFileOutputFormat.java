/** 
 * Writes HFiles. Passed KeyValues must arrive in order. Currently, can only write files to a single column family at a time.  Multiple column families requires coordinating keys cross family. Writes current time as the sequence id for the file. Sets the major compacted attribute on created hfiles.
 * @see KeyValueSortReducer
 */
public class HFileOutputFormat extends FileOutputFormat<ImmutableBytesWritable,KeyValue> {
  static Log LOG=LogFactory.getLog(HFileOutputFormat.class);
  public RecordWriter<ImmutableBytesWritable,KeyValue> getRecordWriter(  final TaskAttemptContext context) throws IOException, InterruptedException {
    final Path outputPath=FileOutputFormat.getOutputPath(context);
    final Path outputdir=new FileOutputCommitter(outputPath,context).getWorkPath();
    Configuration conf=context.getConfiguration();
    final FileSystem fs=outputdir.getFileSystem(conf);
    final long maxsize=conf.getLong("hbase.hregion.max.filesize",268435456);
    final int blocksize=conf.getInt("hbase.mapreduce.hfileoutputformat.blocksize",65536);
    final String compression=conf.get("hfile.compression",Compression.Algorithm.NONE.getName());
    return new RecordWriter<ImmutableBytesWritable,KeyValue>(){
      private final Map<byte[],WriterLength> writers=new TreeMap<byte[],WriterLength>(Bytes.BYTES_COMPARATOR);
      private byte[] previousRow=HConstants.EMPTY_BYTE_ARRAY;
      private final byte[] now=Bytes.toBytes(System.currentTimeMillis());
      public void write(      ImmutableBytesWritable row,      KeyValue kv) throws IOException {
        long length=kv.getLength();
        byte[] family=kv.getFamily();
        WriterLength wl=this.writers.get(family);
        if (wl == null || ((length + wl.written) >= maxsize) && Bytes.compareTo(this.previousRow,0,this.previousRow.length,kv.getBuffer(),kv.getRowOffset(),kv.getRowLength()) != 0) {
          Path basedir=new Path(outputdir,Bytes.toString(family));
          if (wl == null) {
            wl=new WriterLength();
            this.writers.put(family,wl);
            if (this.writers.size() > 1)             throw new IOException("One family only");
            if (!fs.exists(basedir))             fs.mkdirs(basedir);
          }
          wl.writer=getNewWriter(wl.writer,basedir);
          LOG.info("Writer=" + wl.writer.getPath() + ((wl.written == 0) ? "" : ", wrote=" + wl.written));
          wl.written=0;
        }
        kv.updateLatestStamp(this.now);
        wl.writer.append(kv);
        wl.written+=length;
        this.previousRow=kv.getRow();
      }
      private HFile.Writer getNewWriter(      final HFile.Writer writer,      final Path familydir) throws IOException {
        close(writer);
        return new HFile.Writer(fs,StoreFile.getUniqueFile(fs,familydir),blocksize,compression,KeyValue.KEY_COMPARATOR);
      }
      private void close(      final HFile.Writer w) throws IOException {
        if (w != null) {
          w.appendFileInfo(StoreFile.BULKLOAD_TIME_KEY,Bytes.toBytes(System.currentTimeMillis()));
          w.appendFileInfo(StoreFile.BULKLOAD_TASK_KEY,Bytes.toBytes(context.getTaskAttemptID().toString()));
          w.appendFileInfo(StoreFile.MAJOR_COMPACTION_KEY,Bytes.toBytes(true));
          w.close();
        }
      }
      public void close(      TaskAttemptContext c) throws IOException, InterruptedException {
        for (        Map.Entry<byte[],WriterLength> e : this.writers.entrySet()) {
          close(e.getValue().writer);
        }
      }
    }
;
  }
static class WriterLength {
    long written=0;
    HFile.Writer writer=null;
  }
  /** 
 * Return the start keys of all of the regions in this table, as a list of ImmutableBytesWritable.
 */
  private static List<ImmutableBytesWritable> getRegionStartKeys(  HTable table) throws IOException {
    byte[][] byteKeys=table.getStartKeys();
    ArrayList<ImmutableBytesWritable> ret=new ArrayList<ImmutableBytesWritable>(byteKeys.length);
    for (    byte[] byteKey : byteKeys) {
      ret.add(new ImmutableBytesWritable(byteKey));
    }
    return ret;
  }
  /** 
 * Write out a SequenceFile that can be read by TotalOrderPartitioner that contains the split points in startKeys.
 * @param partitionsPath output path for SequenceFile
 * @param startKeys the region start keys
 */
  private static void writePartitions(  Configuration conf,  Path partitionsPath,  List<ImmutableBytesWritable> startKeys) throws IOException {
    if (startKeys.isEmpty()) {
      throw new IllegalArgumentException("No regions passed");
    }
    TreeSet<ImmutableBytesWritable> sorted=new TreeSet<ImmutableBytesWritable>(startKeys);
    ImmutableBytesWritable first=sorted.first();
    if (!first.equals(HConstants.EMPTY_BYTE_ARRAY)) {
      throw new IllegalArgumentException("First region of table should have empty start key. Instead has: " + Bytes.toStringBinary(first.get()));
    }
    sorted.remove(first);
    FileSystem fs=partitionsPath.getFileSystem(conf);
    SequenceFile.Writer writer=SequenceFile.createWriter(fs,conf,partitionsPath,ImmutableBytesWritable.class,NullWritable.class);
    try {
      for (      ImmutableBytesWritable startKey : sorted) {
        writer.append(startKey,NullWritable.get());
      }
    }
  finally {
      writer.close();
    }
  }
  /** 
 * Configure a MapReduce Job to perform an incremental load into the given table. This <ul> <li>Inspects the table to configure a total order partitioner</li> <li>Uploads the partitions file to the cluster and adds it to the DistributedCache</li> <li>Sets the number of reduce tasks to match the current number of regions</li> <li>Sets the output key/value class to match HFileOutputFormat's requirements</li> <li>Sets the reducer up to perform the appropriate sorting (either KeyValueSortReducer or PutSortReducer)</li> </ul>  The user should be sure to set the map output value class to either KeyValue or Put before running this function.
 */
  public static void configureIncrementalLoad(  Job job,  HTable table) throws IOException {
    Configuration conf=job.getConfiguration();
    job.setPartitionerClass(TotalOrderPartitioner.class);
    job.setOutputKeyClass(ImmutableBytesWritable.class);
    job.setOutputValueClass(KeyValue.class);
    job.setOutputFormatClass(HFileOutputFormat.class);
    if (KeyValue.class.equals(job.getMapOutputValueClass())) {
      job.setReducerClass(KeyValueSortReducer.class);
    }
 else     if (Put.class.equals(job.getMapOutputValueClass())) {
      job.setReducerClass(PutSortReducer.class);
    }
 else {
      LOG.warn("Unknown map output value type:" + job.getMapOutputValueClass());
    }
    LOG.info("Looking up current regions for table " + table);
    List<ImmutableBytesWritable> startKeys=getRegionStartKeys(table);
    LOG.info("Configuring " + startKeys.size() + " reduce partitions "+ "to match current region count");
    job.setNumReduceTasks(startKeys.size());
    Path partitionsPath=new Path(job.getWorkingDirectory(),"partitions_" + System.currentTimeMillis());
    LOG.info("Writing partition information to " + partitionsPath);
    FileSystem fs=partitionsPath.getFileSystem(conf);
    writePartitions(conf,partitionsPath,startKeys);
    partitionsPath.makeQualified(fs);
    URI cacheUri;
    try {
      cacheUri=new URI(partitionsPath.toString() + "#" + TotalOrderPartitioner.DEFAULT_PATH);
    }
 catch (    URISyntaxException e) {
      throw new IOException(e);
    }
    DistributedCache.addCacheFile(cacheUri,conf);
    DistributedCache.createSymlink(conf);
    LOG.info("Incremental table output configured.");
  }
}
