/** 
 * Describes a command.
 */
static class CmdDescriptor {
  private Class<? extends Test> cmdClass;
  private String name;
  private String description;
  CmdDescriptor(  Class<? extends Test> cmdClass,  String name,  String description){
    this.cmdClass=cmdClass;
    this.name=name;
    this.description=description;
  }
  public Class<? extends Test> getCmdClass(){
    return cmdClass;
  }
  public String getName(){
    return name;
  }
  public String getDescription(){
    return description;
  }
}
