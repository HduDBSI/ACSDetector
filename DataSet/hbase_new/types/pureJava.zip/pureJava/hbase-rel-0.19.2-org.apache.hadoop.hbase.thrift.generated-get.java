private class get implements ProcessFunction {
  public void process(  int seqid,  TProtocol iprot,  TProtocol oprot) throws TException {
    get_args args=new get_args();
    args.read(iprot);
    iprot.readMessageEnd();
    get_result result=new get_result();
    try {
      result.success=iface_.get(args.tableName,args.row,args.column);
      result.__isset.success=true;
    }
 catch (    IOError io) {
      result.io=io;
      result.__isset.io=true;
    }
catch (    NotFound nf) {
      result.nf=nf;
      result.__isset.nf=true;
    }
    oprot.writeMessageBegin(new TMessage("get",TMessageType.REPLY,seqid));
    result.write(oprot);
    oprot.writeMessageEnd();
    oprot.getTransport().flush();
  }
}
