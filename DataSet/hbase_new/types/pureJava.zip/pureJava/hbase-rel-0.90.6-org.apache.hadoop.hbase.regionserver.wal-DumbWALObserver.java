static class DumbWALObserver implements WALObserver {
  int increments=0;
  @Override public void visitLogEntryBeforeWrite(  HRegionInfo info,  HLogKey logKey,  WALEdit logEdit){
    increments++;
  }
  @Override public void logRolled(  Path newFile){
  }
  @Override public void logRollRequested(){
  }
  @Override public void logCloseRequested(){
  }
}
