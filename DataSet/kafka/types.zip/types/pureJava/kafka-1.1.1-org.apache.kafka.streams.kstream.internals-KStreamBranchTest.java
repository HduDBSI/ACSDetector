public class KStreamBranchTest {
  private String topicName="topic";
  @Rule public final KStreamTestDriver driver=new KStreamTestDriver();
  @SuppressWarnings("unchecked") @Test public void testKStreamBranch(){
    final StreamsBuilder builder=new StreamsBuilder();
    Predicate<Integer,String> isEven=new Predicate<Integer,String>(){
      @Override public boolean test(      Integer key,      String value){
        return (key % 2) == 0;
      }
    }
;
    Predicate<Integer,String> isMultipleOfThree=new Predicate<Integer,String>(){
      @Override public boolean test(      Integer key,      String value){
        return (key % 3) == 0;
      }
    }
;
    Predicate<Integer,String> isOdd=new Predicate<Integer,String>(){
      @Override public boolean test(      Integer key,      String value){
        return (key % 2) != 0;
      }
    }
;
    final int[] expectedKeys=new int[]{1,2,3,4,5,6};
    KStream<Integer,String> stream;
    KStream<Integer,String>[] branches;
    MockProcessorSupplier<Integer,String>[] processors;
    stream=builder.stream(topicName,Consumed.with(Serdes.Integer(),Serdes.String()));
    branches=stream.branch(isEven,isMultipleOfThree,isOdd);
    assertEquals(3,branches.length);
    processors=(MockProcessorSupplier<Integer,String>[])Array.newInstance(MockProcessorSupplier.class,branches.length);
    for (int i=0; i < branches.length; i++) {
      processors[i]=new MockProcessorSupplier<>();
      branches[i].process(processors[i]);
    }
    driver.setUp(builder);
    for (    int expectedKey : expectedKeys) {
      driver.process(topicName,expectedKey,"V" + expectedKey);
    }
    assertEquals(3,processors[0].processed.size());
    assertEquals(1,processors[1].processed.size());
    assertEquals(2,processors[2].processed.size());
  }
  @Test public void testTypeVariance(){
    Predicate<Number,Object> positive=new Predicate<Number,Object>(){
      @Override public boolean test(      Number key,      Object value){
        return key.doubleValue() > 0;
      }
    }
;
    Predicate<Number,Object> negative=new Predicate<Number,Object>(){
      @Override public boolean test(      Number key,      Object value){
        return key.doubleValue() < 0;
      }
    }
;
    @SuppressWarnings("unchecked") final KStream<Integer,String>[] branches=new StreamsBuilder().<Integer,String>stream("empty").branch(positive,negative);
  }
}
