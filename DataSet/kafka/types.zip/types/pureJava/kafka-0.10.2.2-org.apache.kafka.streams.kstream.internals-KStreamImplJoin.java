private class KStreamImplJoin {
  private final boolean leftOuter;
  private final boolean rightOuter;
  KStreamImplJoin(  final boolean leftOuter,  final boolean rightOuter){
    this.leftOuter=leftOuter;
    this.rightOuter=rightOuter;
  }
  public <K1,R,V1,V2>KStream<K1,R> join(  KStream<K1,V1> lhs,  KStream<K1,V2> other,  ValueJoiner<? super V1,? super V2,? extends R> joiner,  JoinWindows windows,  Serde<K1> keySerde,  Serde<V1> lhsValueSerde,  Serde<V2> otherValueSerde){
    String thisWindowStreamName=topology.newName(WINDOWED_NAME);
    String otherWindowStreamName=topology.newName(WINDOWED_NAME);
    String joinThisName=rightOuter ? topology.newName(OUTERTHIS_NAME) : topology.newName(JOINTHIS_NAME);
    String joinOtherName=leftOuter ? topology.newName(OUTEROTHER_NAME) : topology.newName(JOINOTHER_NAME);
    String joinMergeName=topology.newName(MERGE_NAME);
    StateStoreSupplier thisWindow=createWindowedStateStore(windows,keySerde,lhsValueSerde,joinThisName + "-store");
    StateStoreSupplier otherWindow=createWindowedStateStore(windows,keySerde,otherValueSerde,joinOtherName + "-store");
    KStreamJoinWindow<K1,V1> thisWindowedStream=new KStreamJoinWindow<>(thisWindow.name(),windows.beforeMs + windows.afterMs + 1,windows.maintainMs());
    KStreamJoinWindow<K1,V2> otherWindowedStream=new KStreamJoinWindow<>(otherWindow.name(),windows.beforeMs + windows.afterMs + 1,windows.maintainMs());
    final KStreamKStreamJoin<K1,R,? super V1,? super V2> joinThis=new KStreamKStreamJoin<>(otherWindow.name(),windows.beforeMs,windows.afterMs,joiner,leftOuter);
    final KStreamKStreamJoin<K1,R,? super V2,? super V1> joinOther=new KStreamKStreamJoin<>(thisWindow.name(),windows.afterMs,windows.beforeMs,reverseJoiner(joiner),rightOuter);
    KStreamPassThrough<K1,R> joinMerge=new KStreamPassThrough<>();
    topology.addProcessor(thisWindowStreamName,thisWindowedStream,((AbstractStream)lhs).name);
    topology.addProcessor(otherWindowStreamName,otherWindowedStream,((AbstractStream)other).name);
    topology.addProcessor(joinThisName,joinThis,thisWindowStreamName);
    topology.addProcessor(joinOtherName,joinOther,otherWindowStreamName);
    topology.addProcessor(joinMergeName,joinMerge,joinThisName,joinOtherName);
    topology.addStateStore(thisWindow,thisWindowStreamName,joinOtherName);
    topology.addStateStore(otherWindow,otherWindowStreamName,joinThisName);
    Set<String> allSourceNodes=new HashSet<>(((AbstractStream<K>)lhs).sourceNodes);
    allSourceNodes.addAll(((KStreamImpl<K1,V2>)other).sourceNodes);
    return new KStreamImpl<>(topology,joinMergeName,allSourceNodes,false);
  }
}
