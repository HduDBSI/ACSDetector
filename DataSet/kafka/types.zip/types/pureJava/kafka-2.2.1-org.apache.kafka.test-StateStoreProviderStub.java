public class StateStoreProviderStub implements StateStoreProvider {
  private final Map<String,StateStore> stores=new HashMap<>();
  private final boolean throwException;
  public StateStoreProviderStub(  final boolean throwException){
    this.throwException=throwException;
  }
  @SuppressWarnings("unchecked") @Override public <T>List<T> stores(  final String storeName,  final QueryableStoreType<T> queryableStoreType){
    if (throwException) {
      throw new InvalidStateStoreException("store is unavailable");
    }
    if (stores.containsKey(storeName) && queryableStoreType.accepts(stores.get(storeName))) {
      return (List<T>)Collections.singletonList(stores.get(storeName));
    }
    return Collections.emptyList();
  }
  public void addStore(  final String storeName,  final StateStore store){
    stores.put(storeName,store);
  }
}
