static class MemoryLRUCacheBytesIterator implements PeekingKeyValueIterator<Bytes,LRUCacheEntry> {
  private final Iterator<Bytes> keys;
  private final NamedCache cache;
  private KeyValue<Bytes,LRUCacheEntry> nextEntry;
  MemoryLRUCacheBytesIterator(  final Iterator<Bytes> keys,  final NamedCache cache){
    this.keys=keys;
    this.cache=cache;
  }
  public Bytes peekNextKey(){
    if (!hasNext()) {
      throw new NoSuchElementException();
    }
    return nextEntry.key;
  }
  public KeyValue<Bytes,LRUCacheEntry> peekNext(){
    if (!hasNext()) {
      throw new NoSuchElementException();
    }
    return nextEntry;
  }
  @Override public boolean hasNext(){
    if (nextEntry != null) {
      return true;
    }
    while (keys.hasNext() && nextEntry == null) {
      internalNext();
    }
    return nextEntry != null;
  }
  @Override public KeyValue<Bytes,LRUCacheEntry> next(){
    if (!hasNext()) {
      throw new NoSuchElementException();
    }
    final KeyValue<Bytes,LRUCacheEntry> result=nextEntry;
    nextEntry=null;
    return result;
  }
  private void internalNext(){
    Bytes cacheKey=keys.next();
    final LRUCacheEntry entry=cache.get(cacheKey);
    if (entry == null) {
      return;
    }
    nextEntry=new KeyValue<>(cacheKey,entry);
  }
  @Override public void remove(){
    throw new UnsupportedOperationException("remove not supported by MemoryLRUCacheBytesIterator");
  }
  @Override public void close(){
  }
}
