public class NoOpConsumerRebalanceListener implements ConsumerRebalanceListener {
  @Override public void onPartitionsAssigned(  Collection<TopicPartition> partitions){
  }
  @Override public void onPartitionsRevoked(  Collection<TopicPartition> partitions){
  }
}
