/** 
 * The state for a task which is being run by the agent.
 */
public class TaskRunning extends TaskState {
  /** 
 * The time on the agent when the task was started.
 */
  private final long startedMs;
  @JsonCreator public TaskRunning(  @JsonProperty("spec") TaskSpec spec,  @JsonProperty("startedMs") long startedMs,  @JsonProperty("status") JsonNode status){
    super(spec,status);
    this.startedMs=startedMs;
  }
  @JsonProperty public long startedMs(){
    return startedMs;
  }
  @Override public TaskStateType stateType(){
    return TaskStateType.RUNNING;
  }
}
