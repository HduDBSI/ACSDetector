/** 
 * <p> Command line utility that runs Kafka Connect in distributed mode. In this mode, the process joints a group of other workers and work is distributed among them. This is useful for running Connect as a service, where connectors can be submitted to the cluster to be automatically executed in a scalable, distributed fashion. This also allows you to easily scale out horizontally, elastically adding or removing capacity simply by starting or stopping worker instances. </p>
 */
public class ConnectDistributed {
  private static final Logger log=LoggerFactory.getLogger(ConnectDistributed.class);
  private final Time time=Time.SYSTEM;
  private final long initStart=time.hiResClockMs();
  public static void main(  String[] args){
    if (args.length < 1 || Arrays.asList(args).contains("--help")) {
      log.info("Usage: ConnectDistributed worker.properties");
      Exit.exit(1);
    }
    try {
      WorkerInfo initInfo=new WorkerInfo();
      initInfo.logAll();
      String workerPropsFile=args[0];
      Map<String,String> workerProps=!workerPropsFile.isEmpty() ? Utils.propsToStringMap(Utils.loadProps(workerPropsFile)) : Collections.emptyMap();
      ConnectDistributed connectDistributed=new ConnectDistributed();
      Connect connect=connectDistributed.startConnect(workerProps);
      connect.awaitStop();
    }
 catch (    Throwable t) {
      log.error("Stopping due to error",t);
      Exit.exit(2);
    }
  }
  public Connect startConnect(  Map<String,String> workerProps){
    log.info("Scanning for plugin classes. This might take a moment ...");
    Plugins plugins=new Plugins(workerProps);
    plugins.compareAndSwapWithDelegatingLoader();
    DistributedConfig config=new DistributedConfig(workerProps);
    String kafkaClusterId=ConnectUtils.lookupKafkaClusterId(config);
    log.debug("Kafka cluster ID: {}",kafkaClusterId);
    RestServer rest=new RestServer(config);
    HerderProvider provider=new HerderProvider();
    rest.start(provider,plugins);
    URI advertisedUrl=rest.advertisedUrl();
    String workerId=advertisedUrl.getHost() + ":" + advertisedUrl.getPort();
    KafkaOffsetBackingStore offsetBackingStore=new KafkaOffsetBackingStore();
    offsetBackingStore.configure(config);
    Worker worker=new Worker(workerId,time,plugins,config,offsetBackingStore);
    WorkerConfigTransformer configTransformer=worker.configTransformer();
    Converter internalValueConverter=worker.getInternalValueConverter();
    StatusBackingStore statusBackingStore=new KafkaStatusBackingStore(time,internalValueConverter);
    statusBackingStore.configure(config);
    ConfigBackingStore configBackingStore=new KafkaConfigBackingStore(internalValueConverter,config,configTransformer);
    DistributedHerder herder=new DistributedHerder(config,time,worker,kafkaClusterId,statusBackingStore,configBackingStore,advertisedUrl.toString());
    final Connect connect=new Connect(herder,rest);
    log.info("Kafka Connect distributed worker initialization took {}ms",time.hiResClockMs() - initStart);
    try {
      connect.start();
      provider.setHerder(herder);
    }
 catch (    Exception e) {
      log.error("Failed to start Connect",e);
      connect.stop();
      Exit.exit(3);
    }
    return connect;
  }
}
