public static class FLG {
  private static final int VERSION=1;
  private final int presetDictionary;
  private final int reserved1;
  private final int contentChecksum;
  private final int contentSize;
  private final int blockChecksum;
  private final int blockIndependence;
  private final int version;
  public FLG(){
    this(false);
  }
  public FLG(  boolean blockChecksum){
    this(0,0,0,0,blockChecksum ? 1 : 0,1,VERSION);
  }
  private FLG(  int presetDictionary,  int reserved1,  int contentChecksum,  int contentSize,  int blockChecksum,  int blockIndependence,  int version){
    this.presetDictionary=presetDictionary;
    this.reserved1=reserved1;
    this.contentChecksum=contentChecksum;
    this.contentSize=contentSize;
    this.blockChecksum=blockChecksum;
    this.blockIndependence=blockIndependence;
    this.version=version;
    validate();
  }
  public static FLG fromByte(  byte flg){
    int presetDictionary=(flg >>> 0) & 1;
    int reserved1=(flg >>> 1) & 1;
    int contentChecksum=(flg >>> 2) & 1;
    int contentSize=(flg >>> 3) & 1;
    int blockChecksum=(flg >>> 4) & 1;
    int blockIndependence=(flg >>> 5) & 1;
    int version=(flg >>> 6) & 3;
    return new FLG(presetDictionary,reserved1,contentChecksum,contentSize,blockChecksum,blockIndependence,version);
  }
  public byte toByte(){
    return (byte)(((presetDictionary & 1) << 0) | ((reserved1 & 1) << 1) | ((contentChecksum & 1) << 2)| ((contentSize & 1) << 3)| ((blockChecksum & 1) << 4)| ((blockIndependence & 1) << 5)| ((version & 3) << 6));
  }
  private void validate(){
    if (presetDictionary != 0) {
      throw new RuntimeException("Preset dictionary is unsupported");
    }
    if (reserved1 != 0) {
      throw new RuntimeException("Reserved1 field must be 0");
    }
    if (contentChecksum != 0) {
      throw new RuntimeException("Content checksum is unsupported");
    }
    if (contentSize != 0) {
      throw new RuntimeException("Content size is unsupported");
    }
    if (blockIndependence != 1) {
      throw new RuntimeException("Dependent block stream is unsupported");
    }
    if (version != VERSION) {
      throw new RuntimeException(String.format("Version %d is unsupported",version));
    }
  }
  public boolean isPresetDictionarySet(){
    return presetDictionary == 1;
  }
  public boolean isContentChecksumSet(){
    return contentChecksum == 1;
  }
  public boolean isContentSizeSet(){
    return contentSize == 1;
  }
  public boolean isBlockChecksumSet(){
    return blockChecksum == 1;
  }
  public boolean isBlockIndependenceSet(){
    return blockIndependence == 1;
  }
  public int getVersion(){
    return version;
  }
}
