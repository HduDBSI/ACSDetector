public static class TheRocksDbConfigSetter implements RocksDBConfigSetter {
  static boolean called=false;
  @Override public void setConfig(  final String storeName,  final Options options,  final Map<String,Object> configs){
    called=true;
  }
}
