/** 
 * Single process, in-memory "herder". Useful for a standalone Kafka Connect process.
 */
public class StandaloneHerder extends AbstractHerder {
  private static final Logger log=LoggerFactory.getLogger(StandaloneHerder.class);
  private ClusterConfigState configState;
  public StandaloneHerder(  Worker worker){
    this(worker,worker.workerId(),new MemoryStatusBackingStore(),new MemoryConfigBackingStore());
  }
  StandaloneHerder(  Worker worker,  String workerId,  StatusBackingStore statusBackingStore,  MemoryConfigBackingStore configBackingStore){
    super(worker,workerId,statusBackingStore,configBackingStore);
    this.configState=ClusterConfigState.EMPTY;
    configBackingStore.setUpdateListener(new ConfigUpdateListener());
  }
  public synchronized void start(){
    log.info("Herder starting");
    startServices();
    log.info("Herder started");
  }
  public synchronized void stop(){
    log.info("Herder stopping");
    for (    String connName : configState.connectors()) {
      removeConnectorTasks(connName);
      try {
        worker.stopConnector(connName);
      }
 catch (      ConnectException e) {
        log.error("Error shutting down connector {}: ",connName,e);
      }
    }
    stopServices();
    log.info("Herder stopped");
  }
  @Override public int generation(){
    return 0;
  }
  @Override public synchronized void connectors(  Callback<Collection<String>> callback){
    callback.onCompletion(null,configState.connectors());
  }
  @Override public synchronized void connectorInfo(  String connName,  Callback<ConnectorInfo> callback){
    ConnectorInfo connectorInfo=createConnectorInfo(connName);
    if (connectorInfo == null) {
      callback.onCompletion(new NotFoundException("Connector " + connName + " not found"),null);
      return;
    }
    callback.onCompletion(null,connectorInfo);
  }
  private ConnectorInfo createConnectorInfo(  String connector){
    if (!configState.contains(connector))     return null;
    Map<String,String> config=configState.connectorConfig(connector);
    return new ConnectorInfo(connector,config,configState.tasks(connector));
  }
  @Override public void connectorConfig(  String connName,  final Callback<Map<String,String>> callback){
    connectorInfo(connName,new Callback<ConnectorInfo>(){
      @Override public void onCompletion(      Throwable error,      ConnectorInfo result){
        if (error != null) {
          callback.onCompletion(error,null);
          return;
        }
        callback.onCompletion(null,result.config());
      }
    }
);
  }
  @Override public synchronized void putConnectorConfig(  String connName,  final Map<String,String> config,  boolean allowReplace,  final Callback<Created<ConnectorInfo>> callback){
    try {
      boolean created=false;
      if (configState.contains(connName)) {
        if (!allowReplace) {
          callback.onCompletion(new AlreadyExistsException("Connector " + connName + " already exists"),null);
          return;
        }
        if (config == null)         removeConnectorTasks(connName);
        worker.stopConnector(connName);
        if (config == null) {
          configBackingStore.removeConnectorConfig(connName);
          onDeletion(connName);
        }
      }
 else {
        if (config == null) {
          callback.onCompletion(new NotFoundException("Connector " + connName + " not found",null),null);
          return;
        }
        created=true;
      }
      if (config != null) {
        startConnector(config);
        updateConnectorTasks(connName);
      }
      if (config != null)       callback.onCompletion(null,new Created<>(created,createConnectorInfo(connName)));
 else       callback.onCompletion(null,new Created<ConnectorInfo>(false,null));
    }
 catch (    ConnectException e) {
      callback.onCompletion(e,null);
    }
  }
  @Override public synchronized void requestTaskReconfiguration(  String connName){
    if (!worker.connectorNames().contains(connName)) {
      log.error("Task that requested reconfiguration does not exist: {}",connName);
      return;
    }
    updateConnectorTasks(connName);
  }
  @Override public synchronized void taskConfigs(  String connName,  Callback<List<TaskInfo>> callback){
    if (!configState.contains(connName)) {
      callback.onCompletion(new NotFoundException("Connector " + connName + " not found",null),null);
      return;
    }
    List<TaskInfo> result=new ArrayList<>();
    for (    ConnectorTaskId taskId : configState.tasks(connName))     result.add(new TaskInfo(taskId,configState.taskConfig(taskId)));
    callback.onCompletion(null,result);
  }
  @Override public void putTaskConfigs(  String connName,  List<Map<String,String>> configs,  Callback<Void> callback){
    throw new UnsupportedOperationException("Kafka Connect in standalone mode does not support externally setting task configurations.");
  }
  @Override public synchronized void restartTask(  ConnectorTaskId taskId,  Callback<Void> cb){
    if (!configState.contains(taskId.connector()))     cb.onCompletion(new NotFoundException("Connector " + taskId.connector() + " not found",null),null);
    Map<String,String> taskConfig=configState.taskConfig(taskId);
    if (taskConfig == null)     cb.onCompletion(new NotFoundException("Task " + taskId + " not found",null),null);
    TargetState targetState=configState.targetState(taskId.connector());
    try {
      worker.stopAndAwaitTask(taskId);
      worker.startTask(taskId,new TaskConfig(taskConfig),this,targetState);
      cb.onCompletion(null,null);
    }
 catch (    Exception e) {
      log.error("Failed to restart task {}",taskId,e);
      cb.onCompletion(e,null);
    }
  }
  @Override public synchronized void restartConnector(  String connName,  Callback<Void> cb){
    if (!configState.contains(connName))     cb.onCompletion(new NotFoundException("Connector " + connName + " not found",null),null);
    Map<String,String> config=configState.connectorConfig(connName);
    try {
      worker.stopConnector(connName);
      startConnector(config);
      cb.onCompletion(null,null);
    }
 catch (    Exception e) {
      log.error("Failed to restart connector {}",connName,e);
      cb.onCompletion(e,null);
    }
  }
  /** 
 * Start a connector in the worker and record its state.
 * @param connectorProps new connector configuration
 * @return the connector name
 */
  private String startConnector(  Map<String,String> connectorProps){
    ConnectorConfig connConfig=new ConnectorConfig(connectorProps);
    String connName=connConfig.getString(ConnectorConfig.NAME_CONFIG);
    configBackingStore.putConnectorConfig(connName,connectorProps);
    TargetState targetState=configState.targetState(connName);
    worker.startConnector(connConfig,new HerderConnectorContext(this,connName),this,targetState);
    return connName;
  }
  private List<Map<String,String>> recomputeTaskConfigs(  String connName){
    Map<String,String> config=configState.connectorConfig(connName);
    ConnectorConfig connConfig;
    if (worker.isSinkConnector(connName)) {
      connConfig=new SinkConnectorConfig(config);
      return worker.connectorTaskConfigs(connName,connConfig.getInt(ConnectorConfig.TASKS_MAX_CONFIG),connConfig.getList(SinkConnectorConfig.TOPICS_CONFIG));
    }
 else {
      connConfig=new SourceConnectorConfig(config);
      return worker.connectorTaskConfigs(connName,connConfig.getInt(ConnectorConfig.TASKS_MAX_CONFIG),null);
    }
  }
  private void createConnectorTasks(  String connName,  TargetState initialState){
    for (    ConnectorTaskId taskId : configState.tasks(connName)) {
      Map<String,String> taskConfigMap=configState.taskConfig(taskId);
      TaskConfig config=new TaskConfig(taskConfigMap);
      try {
        worker.startTask(taskId,config,this,initialState);
      }
 catch (      Throwable e) {
        log.error("Failed to add task {}: ",taskId,e);
      }
    }
  }
  private void removeConnectorTasks(  String connName){
    Collection<ConnectorTaskId> tasks=configState.tasks(connName);
    if (!tasks.isEmpty()) {
      worker.stopTasks(tasks);
      worker.awaitStopTasks(tasks);
      configBackingStore.removeTaskConfigs(connName);
    }
  }
  private void updateConnectorTasks(  String connName){
    if (!worker.isRunning(connName)) {
      log.info("Skipping reconfiguration of connector {} since it is not running",connName);
      return;
    }
    List<Map<String,String>> newTaskConfigs=recomputeTaskConfigs(connName);
    List<Map<String,String>> oldTaskConfigs=configState.allTaskConfigs(connName);
    if (!newTaskConfigs.equals(oldTaskConfigs)) {
      removeConnectorTasks(connName);
      configBackingStore.putTaskConfigs(connName,newTaskConfigs);
      createConnectorTasks(connName,configState.targetState(connName));
    }
  }
private class ConfigUpdateListener implements ConfigBackingStore.UpdateListener {
    @Override public void onConnectorConfigRemove(    String connector){
synchronized (StandaloneHerder.this) {
        configState=configBackingStore.snapshot();
      }
    }
    @Override public void onConnectorConfigUpdate(    String connector){
synchronized (StandaloneHerder.this) {
        configState=configBackingStore.snapshot();
      }
    }
    @Override public void onTaskConfigUpdate(    Collection<ConnectorTaskId> tasks){
synchronized (StandaloneHerder.this) {
        configState=configBackingStore.snapshot();
      }
    }
    @Override public void onConnectorTargetStateChange(    String connector){
synchronized (StandaloneHerder.this) {
        configState=configBackingStore.snapshot();
        TargetState targetState=configState.targetState(connector);
        worker.setTargetState(connector,targetState);
        if (targetState == TargetState.STARTED)         updateConnectorTasks(connector);
      }
    }
  }
}
