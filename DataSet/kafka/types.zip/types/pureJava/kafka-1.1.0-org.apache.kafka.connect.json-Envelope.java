static class Envelope {
  public JsonNode schema;
  public JsonNode payload;
  public Envelope(  JsonNode schema,  JsonNode payload){
    this.schema=schema;
    this.payload=payload;
  }
  public ObjectNode toJsonNode(){
    return envelope(schema,payload);
  }
}
