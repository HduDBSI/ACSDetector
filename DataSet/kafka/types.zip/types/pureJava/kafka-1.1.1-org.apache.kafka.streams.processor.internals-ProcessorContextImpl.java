public class ProcessorContextImpl extends AbstractProcessorContext implements RecordCollector.Supplier {
  private final StreamTask task;
  private final RecordCollector collector;
  ProcessorContextImpl(  final TaskId id,  final StreamTask task,  final StreamsConfig config,  final RecordCollector collector,  final ProcessorStateManager stateMgr,  final StreamsMetrics metrics,  final ThreadCache cache){
    super(id,config,metrics,stateMgr,cache);
    this.task=task;
    this.collector=collector;
  }
  public ProcessorStateManager getStateMgr(){
    return (ProcessorStateManager)stateManager;
  }
  @Override public RecordCollector recordCollector(){
    return this.collector;
  }
  /** 
 * @throws org.apache.kafka.streams.errors.TopologyBuilderException if an attempt is made to access this state store from an unknown node
 */
  @SuppressWarnings("deprecation") @Override public StateStore getStateStore(  final String name){
    if (currentNode() == null) {
      throw new org.apache.kafka.streams.errors.TopologyBuilderException("Accessing from an unknown node");
    }
    final StateStore global=stateManager.getGlobalStore(name);
    if (global != null) {
      return global;
    }
    if (!currentNode().stateStores.contains(name)) {
      throw new org.apache.kafka.streams.errors.TopologyBuilderException("Processor " + currentNode().name() + " has no access to StateStore "+ name);
    }
    return stateManager.getStore(name);
  }
  @SuppressWarnings("unchecked") @Override public <K,V>void forward(  final K key,  final V value,  final int childIndex){
    final ProcessorNode previousNode=currentNode();
    final ProcessorNode child=(ProcessorNode<K,V>)currentNode().children().get(childIndex);
    setCurrentNode(child);
    try {
      child.process(key,value);
    }
  finally {
      setCurrentNode(previousNode);
    }
  }
  @SuppressWarnings("unchecked") @Override public <K,V>void forward(  final K key,  final V value,  final String childName){
    for (    ProcessorNode child : (List<ProcessorNode<K,V>>)currentNode().children()) {
      if (child.name().equals(childName)) {
        ProcessorNode previousNode=currentNode();
        setCurrentNode(child);
        try {
          child.process(key,value);
          return;
        }
  finally {
          setCurrentNode(previousNode);
        }
      }
    }
  }
  @Override public void commit(){
    task.needCommit();
  }
  @Override public Cancellable schedule(  final long interval,  final PunctuationType type,  final Punctuator callback){
    return task.schedule(interval,type,callback);
  }
  @Override @Deprecated public void schedule(  final long interval){
    schedule(interval,PunctuationType.STREAM_TIME,new Punctuator(){
      @Override public void punctuate(      final long timestamp){
        currentNode().processor().punctuate(timestamp);
      }
    }
);
  }
}
