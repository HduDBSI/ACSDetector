public class InMemoryKeyValueStore<K,V> implements KeyValueStore<K,V> {
  private final String name;
  private final Serde<K> keySerde;
  private final Serde<V> valueSerde;
  private final NavigableMap<K,V> map;
  private volatile boolean open=false;
  private StateSerdes<K,V> serdes;
  public InMemoryKeyValueStore(  final String name,  final Serde<K> keySerde,  final Serde<V> valueSerde){
    this.name=name;
    this.keySerde=keySerde;
    this.valueSerde=valueSerde;
    this.map=new TreeMap<>();
  }
  public KeyValueStore<K,V> enableLogging(){
    return new InMemoryKeyValueLoggedStore<>(this,keySerde,valueSerde);
  }
  @Override public String name(){
    return this.name;
  }
  @Override @SuppressWarnings("unchecked") public void init(  final ProcessorContext context,  final StateStore root){
    this.serdes=new StateSerdes<>(ProcessorStateManager.storeChangelogTopic(context.applicationId(),name),keySerde == null ? (Serde<K>)context.keySerde() : keySerde,valueSerde == null ? (Serde<V>)context.valueSerde() : valueSerde);
    if (root != null) {
      context.register(root,false,new StateRestoreCallback(){
        @Override public void restore(        byte[] key,        byte[] value){
          if (value == null) {
            delete(serdes.keyFrom(key));
          }
 else {
            put(serdes.keyFrom(key),serdes.valueFrom(value));
          }
        }
      }
);
    }
    this.open=true;
  }
  @Override public boolean persistent(){
    return false;
  }
  @Override public boolean isOpen(){
    return this.open;
  }
  @Override public synchronized V get(  final K key){
    return this.map.get(key);
  }
  @Override public synchronized void put(  final K key,  final V value){
    if (value == null) {
      this.map.remove(key);
    }
 else {
      this.map.put(key,value);
    }
  }
  @Override public synchronized V putIfAbsent(  final K key,  final V value){
    V originalValue=get(key);
    if (originalValue == null) {
      put(key,value);
    }
    return originalValue;
  }
  @Override public synchronized void putAll(  final List<KeyValue<K,V>> entries){
    for (    KeyValue<K,V> entry : entries)     put(entry.key,entry.value);
  }
  @Override public synchronized V delete(  final K key){
    return this.map.remove(key);
  }
  @Override public synchronized KeyValueIterator<K,V> range(  final K from,  final K to){
    return new DelegatingPeekingKeyValueIterator<>(name,new InMemoryKeyValueIterator<>(this.map.subMap(from,true,to,true).entrySet().iterator()));
  }
  @Override public synchronized KeyValueIterator<K,V> all(){
    final TreeMap<K,V> copy=new TreeMap<>(this.map);
    return new DelegatingPeekingKeyValueIterator<>(name,new InMemoryKeyValueIterator<>(copy.entrySet().iterator()));
  }
  @Override public long approximateNumEntries(){
    return this.map.size();
  }
  @Override public void flush(){
  }
  @Override public void close(){
    this.map.clear();
    this.open=false;
  }
private static class InMemoryKeyValueIterator<K,V> implements KeyValueIterator<K,V> {
    private final Iterator<Map.Entry<K,V>> iter;
    private InMemoryKeyValueIterator(    final Iterator<Map.Entry<K,V>> iter){
      this.iter=iter;
    }
    @Override public boolean hasNext(){
      return iter.hasNext();
    }
    @Override public KeyValue<K,V> next(){
      Map.Entry<K,V> entry=iter.next();
      return new KeyValue<>(entry.getKey(),entry.getValue());
    }
    @Override public void remove(){
      iter.remove();
    }
    @Override public void close(){
    }
    @Override public K peekNextKey(){
      throw new UnsupportedOperationException("peekNextKey() not supported in " + getClass().getName());
    }
  }
}
