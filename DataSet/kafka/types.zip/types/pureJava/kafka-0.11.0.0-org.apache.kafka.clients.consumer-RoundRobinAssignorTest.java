public class RoundRobinAssignorTest {
  private RoundRobinAssignor assignor=new RoundRobinAssignor();
  @Test public void testOneConsumerNoTopic(){
    String consumerId="consumer";
    Map<String,Integer> partitionsPerTopic=new HashMap<>();
    Map<String,List<TopicPartition>> assignment=assignor.assign(partitionsPerTopic,Collections.singletonMap(consumerId,new Subscription(Collections.<String>emptyList())));
    assertEquals(Collections.singleton(consumerId),assignment.keySet());
    assertTrue(assignment.get(consumerId).isEmpty());
  }
  @Test public void testOneConsumerNonexistentTopic(){
    String topic="topic";
    String consumerId="consumer";
    Map<String,Integer> partitionsPerTopic=new HashMap<>();
    Map<String,List<TopicPartition>> assignment=assignor.assign(partitionsPerTopic,Collections.singletonMap(consumerId,new Subscription(topics(topic))));
    assertEquals(Collections.singleton(consumerId),assignment.keySet());
    assertTrue(assignment.get(consumerId).isEmpty());
  }
  @Test public void testOneConsumerOneTopic(){
    String topic="topic";
    String consumerId="consumer";
    Map<String,Integer> partitionsPerTopic=new HashMap<>();
    partitionsPerTopic.put(topic,3);
    Map<String,List<TopicPartition>> assignment=assignor.assign(partitionsPerTopic,Collections.singletonMap(consumerId,new Subscription(topics(topic))));
    assertEquals(partitions(tp(topic,0),tp(topic,1),tp(topic,2)),assignment.get(consumerId));
  }
  @Test public void testOnlyAssignsPartitionsFromSubscribedTopics(){
    String topic="topic";
    String otherTopic="other";
    String consumerId="consumer";
    Map<String,Integer> partitionsPerTopic=new HashMap<>();
    partitionsPerTopic.put(topic,3);
    partitionsPerTopic.put(otherTopic,3);
    Map<String,List<TopicPartition>> assignment=assignor.assign(partitionsPerTopic,Collections.singletonMap(consumerId,new Subscription(topics(topic))));
    assertEquals(partitions(tp(topic,0),tp(topic,1),tp(topic,2)),assignment.get(consumerId));
  }
  @Test public void testOneConsumerMultipleTopics(){
    String topic1="topic1";
    String topic2="topic2";
    String consumerId="consumer";
    Map<String,Integer> partitionsPerTopic=new HashMap<>();
    partitionsPerTopic.put(topic1,1);
    partitionsPerTopic.put(topic2,2);
    Map<String,List<TopicPartition>> assignment=assignor.assign(partitionsPerTopic,Collections.singletonMap(consumerId,new Subscription(topics(topic1,topic2))));
    assertEquals(partitions(tp(topic1,0),tp(topic2,0),tp(topic2,1)),assignment.get(consumerId));
  }
  @Test public void testTwoConsumersOneTopicOnePartition(){
    String topic="topic";
    String consumer1="consumer1";
    String consumer2="consumer2";
    Map<String,Integer> partitionsPerTopic=new HashMap<>();
    partitionsPerTopic.put(topic,1);
    Map<String,Subscription> consumers=new HashMap<>();
    consumers.put(consumer1,new Subscription(topics(topic)));
    consumers.put(consumer2,new Subscription(topics(topic)));
    Map<String,List<TopicPartition>> assignment=assignor.assign(partitionsPerTopic,consumers);
    assertEquals(partitions(tp(topic,0)),assignment.get(consumer1));
    assertEquals(Collections.<TopicPartition>emptyList(),assignment.get(consumer2));
  }
  @Test public void testTwoConsumersOneTopicTwoPartitions(){
    String topic="topic";
    String consumer1="consumer1";
    String consumer2="consumer2";
    Map<String,Integer> partitionsPerTopic=new HashMap<>();
    partitionsPerTopic.put(topic,2);
    Map<String,Subscription> consumers=new HashMap<>();
    consumers.put(consumer1,new Subscription(topics(topic)));
    consumers.put(consumer2,new Subscription(topics(topic)));
    Map<String,List<TopicPartition>> assignment=assignor.assign(partitionsPerTopic,consumers);
    assertEquals(partitions(tp(topic,0)),assignment.get(consumer1));
    assertEquals(partitions(tp(topic,1)),assignment.get(consumer2));
  }
  @Test public void testMultipleConsumersMixedTopics(){
    String topic1="topic1";
    String topic2="topic2";
    String consumer1="consumer1";
    String consumer2="consumer2";
    String consumer3="consumer3";
    Map<String,Integer> partitionsPerTopic=new HashMap<>();
    partitionsPerTopic.put(topic1,3);
    partitionsPerTopic.put(topic2,2);
    Map<String,Subscription> consumers=new HashMap<>();
    consumers.put(consumer1,new Subscription(topics(topic1)));
    consumers.put(consumer2,new Subscription(topics(topic1,topic2)));
    consumers.put(consumer3,new Subscription(topics(topic1)));
    Map<String,List<TopicPartition>> assignment=assignor.assign(partitionsPerTopic,consumers);
    assertEquals(partitions(tp(topic1,0)),assignment.get(consumer1));
    assertEquals(partitions(tp(topic1,1),tp(topic2,0),tp(topic2,1)),assignment.get(consumer2));
    assertEquals(partitions(tp(topic1,2)),assignment.get(consumer3));
  }
  @Test public void testTwoConsumersTwoTopicsSixPartitions(){
    String topic1="topic1";
    String topic2="topic2";
    String consumer1="consumer1";
    String consumer2="consumer2";
    Map<String,Integer> partitionsPerTopic=new HashMap<>();
    partitionsPerTopic.put(topic1,3);
    partitionsPerTopic.put(topic2,3);
    Map<String,Subscription> consumers=new HashMap<>();
    consumers.put(consumer1,new Subscription(topics(topic1,topic2)));
    consumers.put(consumer2,new Subscription(topics(topic1,topic2)));
    Map<String,List<TopicPartition>> assignment=assignor.assign(partitionsPerTopic,consumers);
    assertEquals(partitions(tp(topic1,0),tp(topic1,2),tp(topic2,1)),assignment.get(consumer1));
    assertEquals(partitions(tp(topic1,1),tp(topic2,0),tp(topic2,2)),assignment.get(consumer2));
  }
  private static List<String> topics(  String... topics){
    return Arrays.asList(topics);
  }
  private static List<TopicPartition> partitions(  TopicPartition... partitions){
    return Arrays.asList(partitions);
  }
  private static TopicPartition tp(  String topic,  int partition){
    return new TopicPartition(topic,partition);
  }
}
