public class StampedRecord extends Stamped<ConsumerRecord<Object,Object>> {
  public StampedRecord(  ConsumerRecord<Object,Object> record,  long timestamp){
    super(record,timestamp);
  }
  public String topic(){
    return value.topic();
  }
  public int partition(){
    return value.partition();
  }
  public Object key(){
    return value.key();
  }
  public Object value(){
    return value.value();
  }
  public long offset(){
    return value.offset();
  }
  @Override public String toString(){
    return value.toString() + ", timestamp = " + timestamp;
  }
}
