/** 
 * Merges two iterators. Assumes each of them is sorted by key
 */
class MergedSortedCacheSessionStoreIterator extends AbstractMergedSortedCacheStoreIterator<Windowed<Bytes>,Windowed<Bytes>,byte[],byte[]> {
  private final SegmentedCacheFunction cacheFunction;
  MergedSortedCacheSessionStoreIterator(  final PeekingKeyValueIterator<Bytes,LRUCacheEntry> cacheIterator,  final KeyValueIterator<Windowed<Bytes>,byte[]> storeIterator,  final SegmentedCacheFunction cacheFunction){
    super(cacheIterator,storeIterator);
    this.cacheFunction=cacheFunction;
  }
  @Override public KeyValue<Windowed<Bytes>,byte[]> deserializeStorePair(  final KeyValue<Windowed<Bytes>,byte[]> pair){
    return pair;
  }
  @Override Windowed<Bytes> deserializeCacheKey(  final Bytes cacheKey){
    final byte[] binaryKey=cacheFunction.key(cacheKey).get();
    final byte[] keyBytes=SessionKeySerde.extractKeyBytes(binaryKey);
    final Window window=SessionKeySerde.extractWindow(binaryKey);
    return new Windowed<>(Bytes.wrap(keyBytes),window);
  }
  @Override byte[] deserializeCacheValue(  final LRUCacheEntry cacheEntry){
    return cacheEntry.value;
  }
  @Override public Windowed<Bytes> deserializeStoreKey(  final Windowed<Bytes> key){
    return key;
  }
  @Override public int compare(  final Bytes cacheKey,  final Windowed<Bytes> storeKey){
    Bytes storeKeyBytes=SessionKeySerde.bytesToBinary(storeKey);
    return cacheFunction.compareSegmentedKeys(cacheKey,storeKeyBytes);
  }
}
