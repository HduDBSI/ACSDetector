public class MockInternalTopicManager extends InternalTopicManager {
  final public Map<String,Integer> readyTopics=new HashMap<>();
  final private MockConsumer<byte[],byte[]> restoreConsumer;
  public MockInternalTopicManager(  final StreamsConfig streamsConfig,  final MockConsumer<byte[],byte[]> restoreConsumer){
    super(KafkaAdminClient.create(streamsConfig.originals()),streamsConfig);
    this.restoreConsumer=restoreConsumer;
  }
  @Override public void makeReady(  final Map<String,InternalTopicConfig> topics){
    for (    final InternalTopicConfig topic : topics.values()) {
      final String topicName=topic.name();
      final int numberOfPartitions=topic.numberOfPartitions();
      readyTopics.put(topicName,numberOfPartitions);
      final List<PartitionInfo> partitions=new ArrayList<>();
      for (int i=0; i < numberOfPartitions; i++) {
        partitions.add(new PartitionInfo(topicName,i,null,null,null));
      }
      restoreConsumer.updatePartitions(topicName,partitions);
    }
  }
  @Override protected Map<String,Integer> getNumPartitions(  final Set<String> topics){
    final Map<String,Integer> partitions=new HashMap<>();
    for (    String topic : topics) {
      partitions.put(topic,restoreConsumer.partitionsFor(topic) == null ? null : restoreConsumer.partitionsFor(topic).size());
    }
    return partitions;
  }
}
