public static class StressTestThread extends Thread {
  private final int iterations;
  private final BufferPool pool;
  private final long maxBlockTimeMs=20_000;
  public final AtomicBoolean success=new AtomicBoolean(false);
  public StressTestThread(  BufferPool pool,  int iterations){
    this.iterations=iterations;
    this.pool=pool;
  }
  public void run(){
    try {
      for (int i=0; i < iterations; i++) {
        int size;
        if (TestUtils.RANDOM.nextBoolean())         size=pool.poolableSize();
 else         size=TestUtils.RANDOM.nextInt((int)pool.totalMemory());
        ByteBuffer buffer=pool.allocate(size,maxBlockTimeMs);
        pool.deallocate(buffer);
      }
      success.set(true);
    }
 catch (    Exception e) {
      e.printStackTrace();
    }
  }
}
