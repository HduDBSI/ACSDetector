public class FakeMetricsReporter implements MetricsReporter {
  @Override public void configure(  Map<String,?> configs){
  }
  @Override public void init(  List<KafkaMetric> metrics){
  }
  @Override public void metricChange(  KafkaMetric metric){
  }
  @Override public void metricRemoval(  KafkaMetric metric){
  }
  @Override public void close(){
  }
}
