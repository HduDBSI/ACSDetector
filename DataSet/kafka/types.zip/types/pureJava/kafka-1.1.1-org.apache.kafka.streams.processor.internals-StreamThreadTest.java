public class StreamThreadTest {
  private final String clientId="clientId";
  private final String applicationId="stream-thread-test";
  private final MockTime mockTime=new MockTime();
  private final Metrics metrics=new Metrics();
  private final MockClientSupplier clientSupplier=new MockClientSupplier();
  private UUID processId=UUID.randomUUID();
  private final InternalStreamsBuilder internalStreamsBuilder=new InternalStreamsBuilder(new InternalTopologyBuilder());
  private InternalTopologyBuilder internalTopologyBuilder;
  private final StreamsConfig config=new StreamsConfig(configProps(false));
  private final String stateDir=TestUtils.tempDirectory().getPath();
  private final StateDirectory stateDirectory=new StateDirectory(config,mockTime);
  private StreamsMetadataState streamsMetadataState;
  private final ConsumedInternal<Object,Object> consumed=new ConsumedInternal<>();
  @Before public void setUp(){
    processId=UUID.randomUUID();
    internalTopologyBuilder=InternalStreamsBuilderTest.internalTopologyBuilder(internalStreamsBuilder);
    internalTopologyBuilder.setApplicationId(applicationId);
    streamsMetadataState=new StreamsMetadataState(internalTopologyBuilder,StreamsMetadataState.UNKNOWN_HOST);
  }
  private final String topic1="topic1";
  private final String topic2="topic2";
  private final TopicPartition t1p1=new TopicPartition(topic1,1);
  private final TopicPartition t1p2=new TopicPartition(topic1,2);
  private final TopicPartition t2p1=new TopicPartition(topic2,1);
  private final TaskId task1=new TaskId(0,1);
  private final TaskId task2=new TaskId(0,2);
  private final TaskId task3=new TaskId(1,1);
  private Properties configProps(  final boolean enableEos){
    return new Properties(){
{
        setProperty(StreamsConfig.APPLICATION_ID_CONFIG,applicationId);
        setProperty(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG,"localhost:2171");
        setProperty(StreamsConfig.BUFFERED_RECORDS_PER_PARTITION_CONFIG,"3");
        setProperty(StreamsConfig.DEFAULT_TIMESTAMP_EXTRACTOR_CLASS_CONFIG,MockTimestampExtractor.class.getName());
        setProperty(StreamsConfig.STATE_DIR_CONFIG,TestUtils.tempDirectory().getAbsolutePath());
        if (enableEos) {
          setProperty(StreamsConfig.PROCESSING_GUARANTEE_CONFIG,StreamsConfig.EXACTLY_ONCE);
        }
      }
    }
;
  }
  @Test public void testPartitionAssignmentChangeForSingleGroup(){
    internalTopologyBuilder.addSource(null,"source1",null,null,null,topic1);
    final StreamThread thread=getStreamThread();
    final StateListenerStub stateListener=new StateListenerStub();
    thread.setStateListener(stateListener);
    assertEquals(thread.state(),StreamThread.State.CREATED);
    final ConsumerRebalanceListener rebalanceListener=thread.rebalanceListener;
    thread.setState(StreamThread.State.RUNNING);
    List<TopicPartition> revokedPartitions;
    List<TopicPartition> assignedPartitions;
    revokedPartitions=Collections.emptyList();
    rebalanceListener.onPartitionsRevoked(revokedPartitions);
    assertEquals(thread.state(),StreamThread.State.PARTITIONS_REVOKED);
    assignedPartitions=Collections.singletonList(t1p1);
    thread.taskManager().setAssignmentMetadata(Collections.<TaskId,Set<TopicPartition>>emptyMap(),Collections.<TaskId,Set<TopicPartition>>emptyMap());
    final MockConsumer<byte[],byte[]> mockConsumer=(MockConsumer<byte[],byte[]>)thread.consumer;
    mockConsumer.assign(assignedPartitions);
    mockConsumer.updateBeginningOffsets(Collections.singletonMap(t1p1,0L));
    rebalanceListener.onPartitionsAssigned(assignedPartitions);
    thread.runOnce(-1);
    assertEquals(thread.state(),StreamThread.State.RUNNING);
    Assert.assertEquals(4,stateListener.numChanges);
    Assert.assertEquals(StreamThread.State.PARTITIONS_ASSIGNED,stateListener.oldState);
    thread.shutdown();
    assertTrue(thread.state() == StreamThread.State.PENDING_SHUTDOWN);
  }
  @Test public void testStateChangeStartClose() throws InterruptedException {
    final StreamThread thread=createStreamThread(clientId,config,false);
    final StateListenerStub stateListener=new StateListenerStub();
    thread.setStateListener(stateListener);
    thread.start();
    TestUtils.waitForCondition(new TestCondition(){
      @Override public boolean conditionMet(){
        return thread.state() == StreamThread.State.RUNNING;
      }
    }
,10 * 1000,"Thread never started.");
    thread.shutdown();
    TestUtils.waitForCondition(new TestCondition(){
      @Override public boolean conditionMet(){
        return thread.state() == StreamThread.State.DEAD;
      }
    }
,10 * 1000,"Thread never shut down.");
    thread.shutdown();
    assertEquals(thread.state(),StreamThread.State.DEAD);
  }
  private Cluster createCluster(  final int numNodes){
    HashMap<Integer,Node> nodes=new HashMap<>();
    for (int i=0; i < numNodes; ++i) {
      nodes.put(i,new Node(i,"localhost",8121 + i));
    }
    return new Cluster("mockClusterId",nodes.values(),Collections.<PartitionInfo>emptySet(),Collections.<String>emptySet(),Collections.<String>emptySet(),nodes.get(0));
  }
  private StreamThread createStreamThread(  final String clientId,  final StreamsConfig config,  final boolean eosEnabled){
    if (eosEnabled) {
      clientSupplier.setApplicationIdForProducer(applicationId);
    }
    clientSupplier.setClusterForAdminClient(createCluster(1));
    return StreamThread.create(internalTopologyBuilder,config,clientSupplier,clientSupplier.getAdminClient(config.getAdminConfigs(clientId)),processId,clientId,metrics,mockTime,streamsMetadataState,0,stateDirectory,new MockStateRestoreListener());
  }
  @Test public void testMetrics(){
    final StreamThread thread=createStreamThread(clientId,config,false);
    final String defaultGroupName="stream-metrics";
    final String defaultPrefix="thread." + thread.getName();
    final Map<String,String> defaultTags=Collections.singletonMap("client-id",thread.getName());
    assertNotNull(metrics.getSensor(defaultPrefix + ".commit-latency"));
    assertNotNull(metrics.getSensor(defaultPrefix + ".poll-latency"));
    assertNotNull(metrics.getSensor(defaultPrefix + ".process-latency"));
    assertNotNull(metrics.getSensor(defaultPrefix + ".punctuate-latency"));
    assertNotNull(metrics.getSensor(defaultPrefix + ".task-created"));
    assertNotNull(metrics.getSensor(defaultPrefix + ".task-closed"));
    assertNotNull(metrics.getSensor(defaultPrefix + ".skipped-records"));
    assertNotNull(metrics.metrics().get(metrics.metricName("commit-latency-avg",defaultGroupName,"The average commit time in ms",defaultTags)));
    assertNotNull(metrics.metrics().get(metrics.metricName("commit-latency-max",defaultGroupName,"The maximum commit time in ms",defaultTags)));
    assertNotNull(metrics.metrics().get(metrics.metricName("commit-rate",defaultGroupName,"The average per-second number of commit calls",defaultTags)));
    assertNotNull(metrics.metrics().get(metrics.metricName("poll-latency-avg",defaultGroupName,"The average poll time in ms",defaultTags)));
    assertNotNull(metrics.metrics().get(metrics.metricName("poll-latency-max",defaultGroupName,"The maximum poll time in ms",defaultTags)));
    assertNotNull(metrics.metrics().get(metrics.metricName("poll-rate",defaultGroupName,"The average per-second number of record-poll calls",defaultTags)));
    assertNotNull(metrics.metrics().get(metrics.metricName("process-latency-avg",defaultGroupName,"The average process time in ms",defaultTags)));
    assertNotNull(metrics.metrics().get(metrics.metricName("process-latency-max",defaultGroupName,"The maximum process time in ms",defaultTags)));
    assertNotNull(metrics.metrics().get(metrics.metricName("process-rate",defaultGroupName,"The average per-second number of process calls",defaultTags)));
    assertNotNull(metrics.metrics().get(metrics.metricName("punctuate-latency-avg",defaultGroupName,"The average punctuate time in ms",defaultTags)));
    assertNotNull(metrics.metrics().get(metrics.metricName("punctuate-latency-max",defaultGroupName,"The maximum punctuate time in ms",defaultTags)));
    assertNotNull(metrics.metrics().get(metrics.metricName("punctuate-rate",defaultGroupName,"The average per-second number of punctuate calls",defaultTags)));
    assertNotNull(metrics.metrics().get(metrics.metricName("task-created-rate",defaultGroupName,"The average per-second number of newly created tasks",defaultTags)));
    assertNotNull(metrics.metrics().get(metrics.metricName("task-closed-rate",defaultGroupName,"The average per-second number of closed tasks",defaultTags)));
    assertNotNull(metrics.metrics().get(metrics.metricName("skipped-records-rate",defaultGroupName,"The average per-second number of skipped records.",defaultTags)));
  }
  @SuppressWarnings({"unchecked","ThrowableNotThrown"}) @Test public void shouldNotCommitBeforeTheCommitInterval(){
    final long commitInterval=1000L;
    final Properties props=configProps(false);
    props.setProperty(StreamsConfig.STATE_DIR_CONFIG,stateDir);
    props.setProperty(StreamsConfig.COMMIT_INTERVAL_MS_CONFIG,Long.toString(commitInterval));
    final StreamsConfig config=new StreamsConfig(props);
    final Consumer<byte[],byte[]> consumer=EasyMock.createNiceMock(Consumer.class);
    final TaskManager taskManager=mockTaskManagerCommit(consumer,1,1);
    StreamThread.StreamsMetricsThreadImpl streamsMetrics=new StreamThread.StreamsMetricsThreadImpl(metrics,"","",Collections.<String,String>emptyMap());
    final StreamThread thread=new StreamThread(mockTime,config,consumer,consumer,null,taskManager,streamsMetrics,internalTopologyBuilder,clientId,new LogContext(""));
    thread.maybeCommit(mockTime.milliseconds());
    mockTime.sleep(commitInterval - 10L);
    thread.maybeCommit(mockTime.milliseconds());
    EasyMock.verify(taskManager);
  }
  @SuppressWarnings({"unchecked","ThrowableNotThrown"}) @Test public void shouldNotCauseExceptionIfNothingCommited(){
    final long commitInterval=1000L;
    final Properties props=configProps(false);
    props.setProperty(StreamsConfig.STATE_DIR_CONFIG,stateDir);
    props.setProperty(StreamsConfig.COMMIT_INTERVAL_MS_CONFIG,Long.toString(commitInterval));
    final StreamsConfig config=new StreamsConfig(props);
    final Consumer<byte[],byte[]> consumer=EasyMock.createNiceMock(Consumer.class);
    final TaskManager taskManager=mockTaskManagerCommit(consumer,1,0);
    StreamThread.StreamsMetricsThreadImpl streamsMetrics=new StreamThread.StreamsMetricsThreadImpl(metrics,"","",Collections.<String,String>emptyMap());
    final StreamThread thread=new StreamThread(mockTime,config,consumer,consumer,null,taskManager,streamsMetrics,internalTopologyBuilder,clientId,new LogContext(""));
    thread.maybeCommit(mockTime.milliseconds());
    mockTime.sleep(commitInterval - 10L);
    thread.maybeCommit(mockTime.milliseconds());
    EasyMock.verify(taskManager);
  }
  @SuppressWarnings("unchecked") @Test public void shouldCommitAfterTheCommitInterval(){
    final long commitInterval=1000L;
    final Properties props=configProps(false);
    props.setProperty(StreamsConfig.STATE_DIR_CONFIG,stateDir);
    props.setProperty(StreamsConfig.COMMIT_INTERVAL_MS_CONFIG,Long.toString(commitInterval));
    final StreamsConfig config=new StreamsConfig(props);
    final Consumer<byte[],byte[]> consumer=EasyMock.createNiceMock(Consumer.class);
    final TaskManager taskManager=mockTaskManagerCommit(consumer,2,1);
    StreamThread.StreamsMetricsThreadImpl streamsMetrics=new StreamThread.StreamsMetricsThreadImpl(metrics,"","",Collections.<String,String>emptyMap());
    final StreamThread thread=new StreamThread(mockTime,config,consumer,consumer,null,taskManager,streamsMetrics,internalTopologyBuilder,clientId,new LogContext(""));
    thread.maybeCommit(mockTime.milliseconds());
    mockTime.sleep(commitInterval + 1);
    thread.maybeCommit(mockTime.milliseconds());
    EasyMock.verify(taskManager);
  }
  @SuppressWarnings({"ThrowableNotThrown","unchecked"}) private TaskManager mockTaskManagerCommit(  final Consumer<byte[],byte[]> consumer,  final int numberOfCommits,  final int commits){
    final TaskManager taskManager=EasyMock.createNiceMock(TaskManager.class);
    EasyMock.expect(taskManager.commitAll()).andReturn(commits).times(numberOfCommits);
    EasyMock.replay(taskManager,consumer);
    return taskManager;
  }
  @Test public void shouldInjectSharedProducerForAllTasksUsingClientSupplierOnCreateIfEosDisabled(){
    internalTopologyBuilder.addSource(null,"source1",null,null,null,topic1);
    final StreamThread thread=createStreamThread(clientId,config,false);
    thread.setState(StreamThread.State.RUNNING);
    thread.rebalanceListener.onPartitionsRevoked(Collections.<TopicPartition>emptyList());
    final Map<TaskId,Set<TopicPartition>> activeTasks=new HashMap<>();
    final List<TopicPartition> assignedPartitions=new ArrayList<>();
    assignedPartitions.add(t1p1);
    assignedPartitions.add(t1p2);
    activeTasks.put(task1,Collections.singleton(t1p1));
    activeTasks.put(task2,Collections.singleton(t1p2));
    thread.taskManager().setAssignmentMetadata(activeTasks,Collections.<TaskId,Set<TopicPartition>>emptyMap());
    final MockConsumer<byte[],byte[]> mockConsumer=(MockConsumer<byte[],byte[]>)thread.consumer;
    mockConsumer.assign(assignedPartitions);
    Map<TopicPartition,Long> beginOffsets=new HashMap<>();
    beginOffsets.put(t1p1,0L);
    beginOffsets.put(t1p2,0L);
    mockConsumer.updateBeginningOffsets(beginOffsets);
    thread.rebalanceListener.onPartitionsAssigned(new HashSet<>(assignedPartitions));
    assertEquals(1,clientSupplier.producers.size());
    final Producer globalProducer=clientSupplier.producers.get(0);
    for (    final Task task : thread.tasks().values()) {
      assertSame(globalProducer,((RecordCollectorImpl)((StreamTask)task).recordCollector()).producer());
    }
    assertSame(clientSupplier.consumer,thread.consumer);
    assertSame(clientSupplier.restoreConsumer,thread.restoreConsumer);
  }
  @Test public void shouldInjectProducerPerTaskUsingClientSupplierOnCreateIfEosEnable(){
    internalTopologyBuilder.addSource(null,"source1",null,null,null,topic1);
    final StreamThread thread=createStreamThread(clientId,new StreamsConfig(configProps(true)),true);
    thread.setState(StreamThread.State.RUNNING);
    thread.rebalanceListener.onPartitionsRevoked(Collections.<TopicPartition>emptyList());
    final Map<TaskId,Set<TopicPartition>> activeTasks=new HashMap<>();
    final List<TopicPartition> assignedPartitions=new ArrayList<>();
    assignedPartitions.add(t1p1);
    assignedPartitions.add(t1p2);
    activeTasks.put(task1,Collections.singleton(t1p1));
    activeTasks.put(task2,Collections.singleton(t1p2));
    thread.taskManager().setAssignmentMetadata(activeTasks,Collections.<TaskId,Set<TopicPartition>>emptyMap());
    final MockConsumer<byte[],byte[]> mockConsumer=(MockConsumer<byte[],byte[]>)thread.consumer;
    mockConsumer.assign(assignedPartitions);
    Map<TopicPartition,Long> beginOffsets=new HashMap<>();
    beginOffsets.put(t1p1,0L);
    beginOffsets.put(t1p2,0L);
    mockConsumer.updateBeginningOffsets(beginOffsets);
    thread.rebalanceListener.onPartitionsAssigned(new HashSet<>(assignedPartitions));
    thread.runOnce(-1);
    assertEquals(thread.tasks().size(),clientSupplier.producers.size());
    assertSame(clientSupplier.consumer,thread.consumer);
    assertSame(clientSupplier.restoreConsumer,thread.restoreConsumer);
  }
  @Test public void shouldCloseAllTaskProducersOnCloseIfEosEnabled(){
    internalTopologyBuilder.addSource(null,"source1",null,null,null,topic1);
    final StreamThread thread=createStreamThread(clientId,new StreamsConfig(configProps(true)),true);
    thread.setState(StreamThread.State.RUNNING);
    thread.rebalanceListener.onPartitionsRevoked(Collections.<TopicPartition>emptyList());
    final Map<TaskId,Set<TopicPartition>> activeTasks=new HashMap<>();
    final List<TopicPartition> assignedPartitions=new ArrayList<>();
    assignedPartitions.add(t1p1);
    assignedPartitions.add(t1p2);
    activeTasks.put(task1,Collections.singleton(t1p1));
    activeTasks.put(task2,Collections.singleton(t1p2));
    thread.taskManager().setAssignmentMetadata(activeTasks,Collections.<TaskId,Set<TopicPartition>>emptyMap());
    final MockConsumer<byte[],byte[]> mockConsumer=(MockConsumer<byte[],byte[]>)thread.consumer;
    mockConsumer.assign(assignedPartitions);
    Map<TopicPartition,Long> beginOffsets=new HashMap<>();
    beginOffsets.put(t1p1,0L);
    beginOffsets.put(t1p2,0L);
    mockConsumer.updateBeginningOffsets(beginOffsets);
    thread.rebalanceListener.onPartitionsAssigned(assignedPartitions);
    thread.shutdown();
    thread.run();
    for (    final Task task : thread.tasks().values()) {
      assertTrue(((MockProducer)((RecordCollectorImpl)((StreamTask)task).recordCollector()).producer()).closed());
    }
  }
  @SuppressWarnings("unchecked") @Test public void shouldShutdownTaskManagerOnClose(){
    final Consumer<byte[],byte[]> consumer=EasyMock.createNiceMock(Consumer.class);
    final TaskManager taskManager=EasyMock.createNiceMock(TaskManager.class);
    EasyMock.expect(taskManager.activeTasks()).andReturn(Collections.<TaskId,StreamTask>emptyMap());
    EasyMock.expect(taskManager.standbyTasks()).andReturn(Collections.<TaskId,StandbyTask>emptyMap());
    taskManager.shutdown(true);
    EasyMock.expectLastCall();
    EasyMock.replay(taskManager,consumer);
    final StreamThread.StreamsMetricsThreadImpl streamsMetrics=new StreamThread.StreamsMetricsThreadImpl(metrics,"","",Collections.<String,String>emptyMap());
    final StreamThread thread=new StreamThread(mockTime,config,consumer,consumer,null,taskManager,streamsMetrics,internalTopologyBuilder,clientId,new LogContext(""));
    thread.setStateListener(new StreamThread.StateListener(){
      @Override public void onChange(      final Thread t,      final ThreadStateTransitionValidator newState,      final ThreadStateTransitionValidator oldState){
        if (oldState == StreamThread.State.CREATED && newState == StreamThread.State.RUNNING) {
          thread.shutdown();
        }
      }
    }
);
    thread.run();
    EasyMock.verify(taskManager);
  }
  @SuppressWarnings("unchecked") @Test public void shouldShutdownTaskManagerOnCloseWithoutStart(){
    final Consumer<byte[],byte[]> consumer=EasyMock.createNiceMock(Consumer.class);
    final TaskManager taskManager=EasyMock.createNiceMock(TaskManager.class);
    taskManager.shutdown(true);
    EasyMock.expectLastCall();
    EasyMock.replay(taskManager,consumer);
    final StreamThread.StreamsMetricsThreadImpl streamsMetrics=new StreamThread.StreamsMetricsThreadImpl(metrics,"","",Collections.<String,String>emptyMap());
    final StreamThread thread=new StreamThread(mockTime,config,consumer,consumer,null,taskManager,streamsMetrics,internalTopologyBuilder,clientId,new LogContext(""));
    thread.shutdown();
    EasyMock.verify(taskManager);
  }
  @SuppressWarnings("unchecked") @Test public void shouldOnlyShutdownOnce(){
    final Consumer<byte[],byte[]> consumer=EasyMock.createNiceMock(Consumer.class);
    final TaskManager taskManager=EasyMock.createNiceMock(TaskManager.class);
    taskManager.shutdown(true);
    EasyMock.expectLastCall();
    EasyMock.replay(taskManager,consumer);
    final StreamThread.StreamsMetricsThreadImpl streamsMetrics=new StreamThread.StreamsMetricsThreadImpl(metrics,"","",Collections.<String,String>emptyMap());
    final StreamThread thread=new StreamThread(mockTime,config,consumer,consumer,null,taskManager,streamsMetrics,internalTopologyBuilder,clientId,new LogContext(""));
    thread.shutdown();
    thread.run();
    EasyMock.verify(taskManager);
  }
  @Test public void shouldNotNullPointerWhenStandbyTasksAssignedAndNoStateStoresForTopology(){
    internalTopologyBuilder.addSource(null,"name",null,null,null,"topic");
    internalTopologyBuilder.addSink("out","output",null,null,null);
    final StreamThread thread=createStreamThread(clientId,config,false);
    thread.setState(StreamThread.State.RUNNING);
    thread.rebalanceListener.onPartitionsRevoked(Collections.<TopicPartition>emptyList());
    final Map<TaskId,Set<TopicPartition>> standbyTasks=new HashMap<>();
    standbyTasks.put(task1,Collections.singleton(t1p1));
    thread.taskManager().setAssignmentMetadata(Collections.<TaskId,Set<TopicPartition>>emptyMap(),standbyTasks);
    thread.taskManager().createTasks(Collections.<TopicPartition>emptyList());
    thread.rebalanceListener.onPartitionsAssigned(Collections.<TopicPartition>emptyList());
  }
  @Test public void shouldCloseTaskAsZombieAndRemoveFromActiveTasksIfProducerWasFencedWhileProcessing() throws Exception {
    internalTopologyBuilder.addSource(null,"source",null,null,null,topic1);
    internalTopologyBuilder.addSink("sink","dummyTopic",null,null,null,"source");
    final StreamThread thread=createStreamThread(clientId,new StreamsConfig(configProps(true)),true);
    final MockConsumer<byte[],byte[]> consumer=clientSupplier.consumer;
    consumer.updatePartitions(topic1,Collections.singletonList(new PartitionInfo(topic1,1,null,null,null)));
    thread.setState(StreamThread.State.RUNNING);
    thread.rebalanceListener.onPartitionsRevoked(null);
    final Map<TaskId,Set<TopicPartition>> activeTasks=new HashMap<>();
    final List<TopicPartition> assignedPartitions=new ArrayList<>();
    assignedPartitions.add(t1p1);
    activeTasks.put(task1,Collections.singleton(t1p1));
    thread.taskManager().setAssignmentMetadata(activeTasks,Collections.<TaskId,Set<TopicPartition>>emptyMap());
    final MockConsumer<byte[],byte[]> mockConsumer=(MockConsumer<byte[],byte[]>)thread.consumer;
    mockConsumer.assign(assignedPartitions);
    mockConsumer.updateBeginningOffsets(Collections.singletonMap(t1p1,0L));
    thread.rebalanceListener.onPartitionsAssigned(assignedPartitions);
    thread.runOnce(-1);
    assertThat(thread.tasks().size(),equalTo(1));
    final MockProducer producer=clientSupplier.producers.get(0);
    consumer.updateBeginningOffsets(Collections.singletonMap(assignedPartitions.iterator().next(),0L));
    consumer.unsubscribe();
    consumer.assign(new HashSet<>(assignedPartitions));
    consumer.addRecord(new ConsumerRecord<>(topic1,1,0,new byte[0],new byte[0]));
    mockTime.sleep(config.getLong(StreamsConfig.COMMIT_INTERVAL_MS_CONFIG) + 1);
    thread.runOnce(-1);
    assertThat(producer.history().size(),equalTo(1));
    assertFalse(producer.transactionCommitted());
    mockTime.sleep(config.getLong(StreamsConfig.COMMIT_INTERVAL_MS_CONFIG) + 1L);
    TestUtils.waitForCondition(new TestCondition(){
      @Override public boolean conditionMet(){
        return producer.commitCount() == 2;
      }
    }
,"StreamsThread did not commit transaction.");
    producer.fenceProducer();
    mockTime.sleep(config.getLong(StreamsConfig.COMMIT_INTERVAL_MS_CONFIG) + 1L);
    consumer.addRecord(new ConsumerRecord<>(topic1,1,0,new byte[0],new byte[0]));
    try {
      thread.runOnce(-1);
      fail("Should have thrown TaskMigratedException");
    }
 catch (    final TaskMigratedException expected) {
    }
    TestUtils.waitForCondition(new TestCondition(){
      @Override public boolean conditionMet(){
        return thread.tasks().isEmpty();
      }
    }
,"StreamsThread did not remove fenced zombie task.");
    assertThat(producer.commitCount(),equalTo(2L));
  }
  @Test public void shouldCloseTaskAsZombieAndRemoveFromActiveTasksIfProducerGotFencedAtBeginTransactionWhenTaskIsResumed(){
    internalTopologyBuilder.addSource(null,"name",null,null,null,topic1);
    internalTopologyBuilder.addSink("out","output",null,null,null);
    final StreamThread thread=createStreamThread(clientId,new StreamsConfig(configProps(true)),true);
    thread.setState(StreamThread.State.RUNNING);
    thread.rebalanceListener.onPartitionsRevoked(null);
    final Map<TaskId,Set<TopicPartition>> activeTasks=new HashMap<>();
    final List<TopicPartition> assignedPartitions=new ArrayList<>();
    assignedPartitions.add(t1p1);
    activeTasks.put(task1,Collections.singleton(t1p1));
    thread.taskManager().setAssignmentMetadata(activeTasks,Collections.<TaskId,Set<TopicPartition>>emptyMap());
    final MockConsumer<byte[],byte[]> mockConsumer=(MockConsumer<byte[],byte[]>)thread.consumer;
    mockConsumer.assign(assignedPartitions);
    mockConsumer.updateBeginningOffsets(Collections.singletonMap(t1p1,0L));
    thread.rebalanceListener.onPartitionsAssigned(assignedPartitions);
    thread.runOnce(-1);
    assertThat(thread.tasks().size(),equalTo(1));
    thread.rebalanceListener.onPartitionsRevoked(null);
    clientSupplier.producers.get(0).fenceProducer();
    thread.rebalanceListener.onPartitionsAssigned(assignedPartitions);
    try {
      thread.runOnce(-1);
      fail("Should have thrown TaskMigratedException");
    }
 catch (    final TaskMigratedException expected) {
    }
    assertTrue(thread.tasks().isEmpty());
  }
private static class StateListenerStub implements StreamThread.StateListener {
    int numChanges=0;
    ThreadStateTransitionValidator oldState=null;
    ThreadStateTransitionValidator newState=null;
    @Override public void onChange(    final Thread thread,    final ThreadStateTransitionValidator newState,    final ThreadStateTransitionValidator oldState){
      ++numChanges;
      if (this.newState != null) {
        if (this.newState != oldState) {
          throw new RuntimeException("State mismatch " + oldState + " different from "+ this.newState);
        }
      }
      this.oldState=oldState;
      this.newState=newState;
    }
  }
  private StreamThread getStreamThread(){
    return createStreamThread(clientId,config,false);
  }
  @Test public void shouldReturnActiveTaskMetadataWhileRunningState(){
    internalTopologyBuilder.addSource(null,"source",null,null,null,topic1);
    final StreamThread thread=createStreamThread(clientId,config,false);
    thread.setState(StreamThread.State.RUNNING);
    thread.rebalanceListener.onPartitionsRevoked(null);
    final Map<TaskId,Set<TopicPartition>> activeTasks=new HashMap<>();
    final List<TopicPartition> assignedPartitions=new ArrayList<>();
    assignedPartitions.add(t1p1);
    activeTasks.put(task1,Collections.singleton(t1p1));
    thread.taskManager().setAssignmentMetadata(activeTasks,Collections.<TaskId,Set<TopicPartition>>emptyMap());
    final MockConsumer<byte[],byte[]> mockConsumer=(MockConsumer<byte[],byte[]>)thread.consumer;
    mockConsumer.assign(assignedPartitions);
    mockConsumer.updateBeginningOffsets(Collections.singletonMap(t1p1,0L));
    thread.rebalanceListener.onPartitionsAssigned(assignedPartitions);
    thread.runOnce(-1);
    ThreadMetadata threadMetadata=thread.threadMetadata();
    assertEquals(StreamThread.State.RUNNING.name(),threadMetadata.threadState());
    assertTrue(threadMetadata.activeTasks().contains(new TaskMetadata(task1.toString(),Utils.mkSet(t1p1))));
    assertTrue(threadMetadata.standbyTasks().isEmpty());
  }
  @Test public void shouldReturnStandbyTaskMetadataWhileRunningState(){
    internalStreamsBuilder.stream(Collections.singleton(topic1),consumed).groupByKey().count(Materialized.<Object,Long,KeyValueStore<Bytes,byte[]>>as("count-one"));
    final StreamThread thread=createStreamThread(clientId,config,false);
    final MockConsumer<byte[],byte[]> restoreConsumer=clientSupplier.restoreConsumer;
    restoreConsumer.updatePartitions("stream-thread-test-count-one-changelog",Collections.singletonList(new PartitionInfo("stream-thread-test-count-one-changelog",0,null,new Node[0],new Node[0])));
    final HashMap<TopicPartition,Long> offsets=new HashMap<>();
    offsets.put(new TopicPartition("stream-thread-test-count-one-changelog",1),0L);
    restoreConsumer.updateEndOffsets(offsets);
    restoreConsumer.updateBeginningOffsets(offsets);
    thread.setState(StreamThread.State.RUNNING);
    thread.rebalanceListener.onPartitionsRevoked(null);
    final Map<TaskId,Set<TopicPartition>> standbyTasks=new HashMap<>();
    standbyTasks.put(task1,Collections.singleton(t1p1));
    thread.taskManager().setAssignmentMetadata(Collections.<TaskId,Set<TopicPartition>>emptyMap(),standbyTasks);
    thread.rebalanceListener.onPartitionsAssigned(Collections.<TopicPartition>emptyList());
    thread.runOnce(-1);
    ThreadMetadata threadMetadata=thread.threadMetadata();
    assertEquals(StreamThread.State.RUNNING.name(),threadMetadata.threadState());
    assertTrue(threadMetadata.standbyTasks().contains(new TaskMetadata(task1.toString(),Utils.mkSet(t1p1))));
    assertTrue(threadMetadata.activeTasks().isEmpty());
  }
  @SuppressWarnings("unchecked") @Test public void shouldUpdateStandbyTask() throws IOException {
    final String storeName1="count-one";
    final String storeName2="table-two";
    final String changelogName1=applicationId + "-" + storeName1+ "-changelog";
    final String changelogName2=applicationId + "-" + storeName2+ "-changelog";
    final TopicPartition partition1=new TopicPartition(changelogName1,1);
    final TopicPartition partition2=new TopicPartition(changelogName2,1);
    internalStreamsBuilder.stream(Collections.singleton(topic1),consumed).groupByKey().count(Materialized.<Object,Long,KeyValueStore<Bytes,byte[]>>as(storeName1));
    final MaterializedInternal materialized=new MaterializedInternal(Materialized.<Object,Long,KeyValueStore<Bytes,byte[]>>as(storeName2),internalStreamsBuilder,"");
    internalStreamsBuilder.table(topic2,new ConsumedInternal(),materialized);
    final StreamThread thread=createStreamThread(clientId,config,false);
    final MockConsumer<byte[],byte[]> restoreConsumer=clientSupplier.restoreConsumer;
    restoreConsumer.updatePartitions(changelogName1,singletonList(new PartitionInfo(changelogName1,1,null,new Node[0],new Node[0])));
    restoreConsumer.assign(Utils.mkSet(partition1,partition2));
    restoreConsumer.updateEndOffsets(Collections.singletonMap(partition1,10L));
    restoreConsumer.updateBeginningOffsets(Collections.singletonMap(partition1,0L));
    restoreConsumer.updateEndOffsets(Collections.singletonMap(partition2,10L));
    restoreConsumer.updateBeginningOffsets(Collections.singletonMap(partition2,0L));
    OffsetCheckpoint checkpoint=new OffsetCheckpoint(new File(stateDirectory.directoryForTask(task3),CHECKPOINT_FILE_NAME));
    checkpoint.write(Collections.singletonMap(partition2,5L));
    for (long i=0L; i < 10L; i++) {
      restoreConsumer.addRecord(new ConsumerRecord<>(changelogName1,1,i,("K" + i).getBytes(),("V" + i).getBytes()));
      restoreConsumer.addRecord(new ConsumerRecord<>(changelogName2,1,i,("K" + i).getBytes(),("V" + i).getBytes()));
    }
    thread.setState(StreamThread.State.RUNNING);
    thread.rebalanceListener.onPartitionsRevoked(null);
    final Map<TaskId,Set<TopicPartition>> standbyTasks=new HashMap<>();
    standbyTasks.put(task1,Collections.singleton(t1p1));
    standbyTasks.put(task3,Collections.singleton(t2p1));
    thread.taskManager().setAssignmentMetadata(Collections.<TaskId,Set<TopicPartition>>emptyMap(),standbyTasks);
    thread.rebalanceListener.onPartitionsAssigned(Collections.<TopicPartition>emptyList());
    thread.runOnce(-1);
    final StandbyTask standbyTask1=thread.taskManager().standbyTask(partition1);
    final StandbyTask standbyTask2=thread.taskManager().standbyTask(partition2);
    final KeyValueStore<Object,Long> store1=(KeyValueStore<Object,Long>)standbyTask1.getStore(storeName1);
    final KeyValueStore<Object,Long> store2=(KeyValueStore<Object,Long>)standbyTask2.getStore(storeName2);
    assertEquals(10L,store1.approximateNumEntries());
    assertEquals(5L,store2.approximateNumEntries());
    assertEquals(0,thread.standbyRecords().size());
  }
  @Test public void shouldAlwaysUpdateTasksMetadataAfterChangingState(){
    final StreamThread thread=createStreamThread(clientId,config,false);
    ThreadMetadata metadata=thread.threadMetadata();
    assertEquals(StreamThread.State.CREATED.name(),metadata.threadState());
    thread.setState(StreamThread.State.RUNNING);
    metadata=thread.threadMetadata();
    assertEquals(StreamThread.State.RUNNING.name(),metadata.threadState());
  }
  @Test public void shouldAlwaysReturnEmptyTasksMetadataWhileRebalancingStateAndTasksNotRunning(){
    internalStreamsBuilder.stream(Collections.singleton(topic1),consumed).groupByKey().count(Materialized.<Object,Long,KeyValueStore<Bytes,byte[]>>as("count-one"));
    final StreamThread thread=createStreamThread(clientId,config,false);
    final MockConsumer<byte[],byte[]> restoreConsumer=clientSupplier.restoreConsumer;
    restoreConsumer.updatePartitions("stream-thread-test-count-one-changelog",Utils.mkList(new PartitionInfo("stream-thread-test-count-one-changelog",0,null,new Node[0],new Node[0]),new PartitionInfo("stream-thread-test-count-one-changelog",1,null,new Node[0],new Node[0])));
    final HashMap<TopicPartition,Long> offsets=new HashMap<>();
    offsets.put(new TopicPartition("stream-thread-test-count-one-changelog",0),0L);
    offsets.put(new TopicPartition("stream-thread-test-count-one-changelog",1),0L);
    restoreConsumer.updateEndOffsets(offsets);
    restoreConsumer.updateBeginningOffsets(offsets);
    clientSupplier.consumer.updateBeginningOffsets(Collections.singletonMap(t1p1,0L));
    thread.setState(StreamThread.State.RUNNING);
    final List<TopicPartition> assignedPartitions=new ArrayList<>();
    thread.rebalanceListener.onPartitionsRevoked(assignedPartitions);
    assertThreadMetadataHasEmptyTasksWithState(thread.threadMetadata(),StreamThread.State.PARTITIONS_REVOKED);
    final Map<TaskId,Set<TopicPartition>> activeTasks=new HashMap<>();
    final Map<TaskId,Set<TopicPartition>> standbyTasks=new HashMap<>();
    assignedPartitions.add(t1p1);
    activeTasks.put(task1,Collections.singleton(t1p1));
    standbyTasks.put(task2,Collections.singleton(t1p2));
    thread.taskManager().setAssignmentMetadata(activeTasks,standbyTasks);
    thread.rebalanceListener.onPartitionsAssigned(assignedPartitions);
    assertThreadMetadataHasEmptyTasksWithState(thread.threadMetadata(),StreamThread.State.PARTITIONS_ASSIGNED);
  }
  @Test public void shouldRecoverFromInvalidOffsetExceptionOnRestoreAndFinishRestore() throws Exception {
    internalStreamsBuilder.stream(Collections.singleton("topic"),consumed).groupByKey().count(Materialized.<Object,Long,KeyValueStore<Bytes,byte[]>>as("count"));
    final StreamThread thread=createStreamThread("cliendId",config,false);
    final MockConsumer<byte[],byte[]> mockConsumer=(MockConsumer<byte[],byte[]>)thread.consumer;
    final MockConsumer<byte[],byte[]> mockRestoreConsumer=(MockConsumer<byte[],byte[]>)thread.restoreConsumer;
    final TopicPartition topicPartition=new TopicPartition("topic",0);
    final Set<TopicPartition> topicPartitionSet=Collections.singleton(topicPartition);
    final Map<TaskId,Set<TopicPartition>> activeTasks=new HashMap<>();
    activeTasks.put(new TaskId(0,0),topicPartitionSet);
    thread.taskManager().setAssignmentMetadata(activeTasks,Collections.<TaskId,Set<TopicPartition>>emptyMap());
    mockConsumer.updatePartitions("topic",new ArrayList<PartitionInfo>(){
{
        add(new PartitionInfo("topic",0,null,new Node[0],new Node[0]));
      }
    }
);
    mockConsumer.updateBeginningOffsets(Collections.singletonMap(topicPartition,0L));
    mockRestoreConsumer.updatePartitions("stream-thread-test-count-changelog",new ArrayList<PartitionInfo>(){
{
        add(new PartitionInfo("stream-thread-test-count-changelog",0,null,new Node[0],new Node[0]));
      }
    }
);
    final TopicPartition changelogPartition=new TopicPartition("stream-thread-test-count-changelog",0);
    final Set<TopicPartition> changelogPartitionSet=Collections.singleton(changelogPartition);
    mockRestoreConsumer.updateBeginningOffsets(Collections.singletonMap(changelogPartition,0L));
    mockRestoreConsumer.updateEndOffsets(Collections.singletonMap(changelogPartition,2L));
    mockConsumer.schedulePollTask(new Runnable(){
      @Override public void run(){
        thread.setState(StreamThread.State.PARTITIONS_REVOKED);
        thread.rebalanceListener.onPartitionsAssigned(topicPartitionSet);
      }
    }
);
    try {
      thread.start();
      TestUtils.waitForCondition(new TestCondition(){
        @Override public boolean conditionMet(){
          return mockRestoreConsumer.assignment().size() == 1;
        }
      }
,"Never restore first record");
      mockRestoreConsumer.addRecord(new ConsumerRecord<>("stream-thread-test-count-changelog",0,0L,"K1".getBytes(),"V1".getBytes()));
      TestUtils.waitForCondition(new TestCondition(){
        @Override public boolean conditionMet(){
          return mockRestoreConsumer.position(changelogPartition) == 1L;
        }
      }
,"Never restore first record");
      mockRestoreConsumer.setException(new InvalidOffsetException("Try Again!"){
        @Override public Set<TopicPartition> partitions(){
          return changelogPartitionSet;
        }
      }
);
      mockRestoreConsumer.addRecord(new ConsumerRecord<>("stream-thread-test-count-changelog",0,0L,"K1".getBytes(),"V1".getBytes()));
      mockRestoreConsumer.addRecord(new ConsumerRecord<>("stream-thread-test-count-changelog",0,1L,"K2".getBytes(),"V2".getBytes()));
      TestUtils.waitForCondition(new TestCondition(){
        @Override public boolean conditionMet(){
          mockRestoreConsumer.assign(changelogPartitionSet);
          return mockRestoreConsumer.position(changelogPartition) == 2L;
        }
      }
,"Never finished restore");
    }
  finally {
      thread.shutdown();
      thread.join(10000);
    }
  }
  @Test public void shouldReportSkippedRecordsForInvalidTimestamps(){
    internalTopologyBuilder.addSource(null,"source1",null,null,null,topic1);
    final Properties config=configProps(false);
    config.setProperty(StreamsConfig.DEFAULT_TIMESTAMP_EXTRACTOR_CLASS_CONFIG,LogAndSkipOnInvalidTimestamp.class.getName());
    final StreamThread thread=createStreamThread(clientId,new StreamsConfig(config),false);
    thread.setState(StreamThread.State.RUNNING);
    thread.setState(StreamThread.State.PARTITIONS_REVOKED);
    final Set<TopicPartition> assignedPartitions=Collections.singleton(t1p1);
    thread.taskManager().setAssignmentMetadata(Collections.singletonMap(new TaskId(0,t1p1.partition()),assignedPartitions),Collections.<TaskId,Set<TopicPartition>>emptyMap());
    final MockConsumer<byte[],byte[]> mockConsumer=(MockConsumer<byte[],byte[]>)thread.consumer;
    mockConsumer.assign(Collections.singleton(t1p1));
    mockConsumer.updateBeginningOffsets(Collections.singletonMap(t1p1,0L));
    thread.rebalanceListener.onPartitionsAssigned(assignedPartitions);
    thread.runOnce(-1);
    final MetricName skippedTotalMetric=metrics.metricName("skipped-records-total","stream-metrics",Collections.singletonMap("client-id",thread.getName()));
    assertEquals(0.0,metrics.metric(skippedTotalMetric).metricValue());
    long offset=-1;
    mockConsumer.addRecord(new ConsumerRecord<>(t1p1.topic(),t1p1.partition(),++offset,-1,TimestampType.CREATE_TIME,-1,-1,-1,new byte[0],new byte[0]));
    mockConsumer.addRecord(new ConsumerRecord<>(t1p1.topic(),t1p1.partition(),++offset,-1,TimestampType.CREATE_TIME,-1,-1,-1,new byte[0],new byte[0]));
    thread.runOnce(-1);
    assertEquals(2.0,metrics.metric(skippedTotalMetric).metricValue());
    mockConsumer.addRecord(new ConsumerRecord<>(t1p1.topic(),t1p1.partition(),++offset,-1,TimestampType.CREATE_TIME,-1,-1,-1,new byte[0],new byte[0]));
    mockConsumer.addRecord(new ConsumerRecord<>(t1p1.topic(),t1p1.partition(),++offset,-1,TimestampType.CREATE_TIME,-1,-1,-1,new byte[0],new byte[0]));
    mockConsumer.addRecord(new ConsumerRecord<>(t1p1.topic(),t1p1.partition(),++offset,-1,TimestampType.CREATE_TIME,-1,-1,-1,new byte[0],new byte[0]));
    mockConsumer.addRecord(new ConsumerRecord<>(t1p1.topic(),t1p1.partition(),++offset,-1,TimestampType.CREATE_TIME,-1,-1,-1,new byte[0],new byte[0]));
    thread.runOnce(-1);
    assertEquals(6.0,metrics.metric(skippedTotalMetric).metricValue());
    mockConsumer.addRecord(new ConsumerRecord<>(t1p1.topic(),t1p1.partition(),++offset,1,TimestampType.CREATE_TIME,-1,-1,-1,new byte[0],new byte[0]));
    mockConsumer.addRecord(new ConsumerRecord<>(t1p1.topic(),t1p1.partition(),++offset,1,TimestampType.CREATE_TIME,-1,-1,-1,new byte[0],new byte[0]));
    thread.runOnce(-1);
    assertEquals(6.0,metrics.metric(skippedTotalMetric).metricValue());
  }
  private void assertThreadMetadataHasEmptyTasksWithState(  ThreadMetadata metadata,  StreamThread.State state){
    assertEquals(state.name(),metadata.threadState());
    assertTrue(metadata.activeTasks().isEmpty());
    assertTrue(metadata.standbyTasks().isEmpty());
  }
}
