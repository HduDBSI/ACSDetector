public interface PeekingKeyValueIterator<K,V> extends KeyValueIterator<K,V> {
  KeyValue<K,V> peekNext();
}
