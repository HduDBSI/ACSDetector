static class SecurityStore {
  private final String type;
  private final String path;
  private final Password password;
  private final Password keyPassword;
  private final Long fileLastModifiedMs;
  SecurityStore(  String type,  String path,  Password password,  Password keyPassword){
    Objects.requireNonNull(type,"type must not be null");
    this.type=type;
    this.path=path;
    this.password=password;
    this.keyPassword=keyPassword;
    fileLastModifiedMs=lastModifiedMs(path);
  }
  /** 
 * Loads this keystore
 * @return the keystore
 * @throws KafkaException if the file could not be read or if the keystore could not be loadedusing the specified configs (e.g. if the password or keystore type is invalid)
 */
  KeyStore load(){
    try (InputStream in=Files.newInputStream(Paths.get(path))){
      KeyStore ks=KeyStore.getInstance(type);
      char[] passwordChars=password != null ? password.value().toCharArray() : null;
      ks.load(in,passwordChars);
      return ks;
    }
 catch (    GeneralSecurityException|IOException e) {
      throw new KafkaException("Failed to load SSL keystore " + path + " of type "+ type,e);
    }
  }
  private Long lastModifiedMs(  String path){
    try {
      return Files.getLastModifiedTime(Paths.get(path)).toMillis();
    }
 catch (    IOException e) {
      log.error("Modification time of key store could not be obtained: " + path,e);
      return null;
    }
  }
  boolean modified(){
    Long modifiedMs=lastModifiedMs(path);
    return modifiedMs != null && !Objects.equals(modifiedMs,this.fileLastModifiedMs);
  }
  @Override public String toString(){
    return "SecurityStore(" + "path=" + path + ", modificationTime="+ (fileLastModifiedMs == null ? null : new Date(fileLastModifiedMs))+ ")";
  }
}
