public class WallclockTimestampExtractorTest {
  @Test public void extractSystemTimestamp(){
    final TimestampExtractor extractor=new WallclockTimestampExtractor();
    final long before=System.currentTimeMillis();
    final long timestamp=extractor.extract(new ConsumerRecord<>("anyTopic",0,0,null,null),42);
    final long after=System.currentTimeMillis();
    assertThat(timestamp,is(new InBetween(before,after)));
  }
private static class InBetween extends BaseMatcher<Long> {
    private final long before;
    private final long after;
    public InBetween(    long before,    long after){
      this.before=before;
      this.after=after;
    }
    @Override public boolean matches(    Object item){
      final long timestamp=(Long)item;
      return before <= timestamp && timestamp <= after;
    }
    @Override public void describeMismatch(    Object item,    Description mismatchDescription){
    }
    @Override public void describeTo(    Description description){
    }
  }
}
