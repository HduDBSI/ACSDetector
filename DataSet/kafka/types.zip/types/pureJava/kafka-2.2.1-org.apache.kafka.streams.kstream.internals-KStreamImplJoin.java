private class KStreamImplJoin {
  private final boolean leftOuter;
  private final boolean rightOuter;
  KStreamImplJoin(  final boolean leftOuter,  final boolean rightOuter){
    this.leftOuter=leftOuter;
    this.rightOuter=rightOuter;
  }
  public <K1,R,V1,V2>KStream<K1,R> join(  final KStream<K1,V1> lhs,  final KStream<K1,V2> other,  final ValueJoiner<? super V1,? super V2,? extends R> joiner,  final JoinWindows windows,  final Joined<K1,V1,V2> joined){
    final String thisWindowStreamName=builder.newProcessorName(WINDOWED_NAME);
    final String otherWindowStreamName=builder.newProcessorName(WINDOWED_NAME);
    final String joinThisName=rightOuter ? builder.newProcessorName(OUTERTHIS_NAME) : builder.newProcessorName(JOINTHIS_NAME);
    final String joinOtherName=leftOuter ? builder.newProcessorName(OUTEROTHER_NAME) : builder.newProcessorName(JOINOTHER_NAME);
    final String joinMergeName=builder.newProcessorName(MERGE_NAME);
    final StreamsGraphNode thisStreamsGraphNode=((AbstractStream)lhs).streamsGraphNode;
    final StreamsGraphNode otherStreamsGraphNode=((AbstractStream)other).streamsGraphNode;
    final StoreBuilder<WindowStore<K1,V1>> thisWindowStore=joinWindowStoreBuilder(joinThisName,windows,joined.keySerde(),joined.valueSerde());
    final StoreBuilder<WindowStore<K1,V2>> otherWindowStore=joinWindowStoreBuilder(joinOtherName,windows,joined.keySerde(),joined.otherValueSerde());
    final KStreamJoinWindow<K1,V1> thisWindowedStream=new KStreamJoinWindow<>(thisWindowStore.name());
    final ProcessorParameters<K1,V1> thisWindowStreamProcessorParams=new ProcessorParameters<>(thisWindowedStream,thisWindowStreamName);
    final ProcessorGraphNode<K1,V1> thisWindowedStreamsNode=new ProcessorGraphNode<>(thisWindowStreamName,thisWindowStreamProcessorParams);
    builder.addGraphNode(thisStreamsGraphNode,thisWindowedStreamsNode);
    final KStreamJoinWindow<K1,V2> otherWindowedStream=new KStreamJoinWindow<>(otherWindowStore.name());
    final ProcessorParameters<K1,V2> otherWindowStreamProcessorParams=new ProcessorParameters<>(otherWindowedStream,otherWindowStreamName);
    final ProcessorGraphNode<K1,V2> otherWindowedStreamsNode=new ProcessorGraphNode<>(otherWindowStreamName,otherWindowStreamProcessorParams);
    builder.addGraphNode(otherStreamsGraphNode,otherWindowedStreamsNode);
    final KStreamKStreamJoin<K1,R,V1,V2> joinThis=new KStreamKStreamJoin<>(otherWindowStore.name(),windows.beforeMs,windows.afterMs,joiner,leftOuter);
    final KStreamKStreamJoin<K1,R,V2,V1> joinOther=new KStreamKStreamJoin<>(thisWindowStore.name(),windows.afterMs,windows.beforeMs,reverseJoiner(joiner),rightOuter);
    final KStreamPassThrough<K1,R> joinMerge=new KStreamPassThrough<>();
    final StreamStreamJoinNode.StreamStreamJoinNodeBuilder<K1,V1,V2,R> joinBuilder=StreamStreamJoinNode.streamStreamJoinNodeBuilder();
    final ProcessorParameters<K1,V1> joinThisProcessorParams=new ProcessorParameters<>(joinThis,joinThisName);
    final ProcessorParameters<K1,V2> joinOtherProcessorParams=new ProcessorParameters<>(joinOther,joinOtherName);
    final ProcessorParameters<K1,R> joinMergeProcessorParams=new ProcessorParameters<>(joinMerge,joinMergeName);
    joinBuilder.withJoinMergeProcessorParameters(joinMergeProcessorParams).withJoinThisProcessorParameters(joinThisProcessorParams).withJoinOtherProcessorParameters(joinOtherProcessorParams).withThisWindowStoreBuilder(thisWindowStore).withOtherWindowStoreBuilder(otherWindowStore).withThisWindowedStreamProcessorParameters(thisWindowStreamProcessorParams).withOtherWindowedStreamProcessorParameters(otherWindowStreamProcessorParams).withValueJoiner(joiner).withNodeName(joinMergeName);
    final StreamsGraphNode joinGraphNode=joinBuilder.build();
    builder.addGraphNode(Arrays.asList(thisStreamsGraphNode,otherStreamsGraphNode),joinGraphNode);
    final Set<String> allSourceNodes=new HashSet<>(((KStreamImpl<K1,V1>)lhs).sourceNodes);
    allSourceNodes.addAll(((KStreamImpl<K1,V2>)other).sourceNodes);
    return new KStreamImpl<>(joinMergeName,joined.keySerde(),null,allSourceNodes,false,joinGraphNode,builder);
  }
}
