/** 
 * A byte buffer backed log input stream. This class avoids the need to copy records by returning slices from the underlying byte buffer.
 */
class ByteBufferLogInputStream implements LogInputStream<ByteBufferLogInputStream.ByteBufferLogEntry> {
  private final ByteBuffer buffer;
  private final int maxMessageSize;
  ByteBufferLogInputStream(  ByteBuffer buffer,  int maxMessageSize){
    this.buffer=buffer;
    this.maxMessageSize=maxMessageSize;
  }
  public ByteBufferLogEntry nextEntry() throws IOException {
    int remaining=buffer.remaining();
    if (remaining < LOG_OVERHEAD)     return null;
    int recordSize=buffer.getInt(buffer.position() + Records.SIZE_OFFSET);
    if (recordSize < Record.RECORD_OVERHEAD_V0)     throw new CorruptRecordException(String.format("Record size is less than the minimum record overhead (%d)",Record.RECORD_OVERHEAD_V0));
    if (recordSize > maxMessageSize)     throw new CorruptRecordException(String.format("Record size exceeds the largest allowable message size (%d).",maxMessageSize));
    int entrySize=recordSize + LOG_OVERHEAD;
    if (remaining < entrySize)     return null;
    ByteBuffer entrySlice=buffer.slice();
    entrySlice.limit(entrySize);
    buffer.position(buffer.position() + entrySize);
    return new ByteBufferLogEntry(entrySlice);
  }
public static class ByteBufferLogEntry extends LogEntry {
    private final ByteBuffer buffer;
    private final Record record;
    private ByteBufferLogEntry(    ByteBuffer buffer){
      this.buffer=buffer;
      buffer.position(LOG_OVERHEAD);
      this.record=new Record(buffer.slice());
      buffer.position(OFFSET_OFFSET);
    }
    @Override public long offset(){
      return buffer.getLong(OFFSET_OFFSET);
    }
    @Override public Record record(){
      return record;
    }
    public void setOffset(    long offset){
      buffer.putLong(OFFSET_OFFSET,offset);
    }
    public void setCreateTime(    long timestamp){
      if (record.magic() == Record.MAGIC_VALUE_V0)       throw new IllegalArgumentException("Cannot set timestamp for a record with magic = 0");
      long currentTimestamp=record.timestamp();
      if (record.timestampType() == TimestampType.CREATE_TIME && currentTimestamp == timestamp)       return;
      setTimestampAndUpdateCrc(TimestampType.CREATE_TIME,timestamp);
    }
    public void setLogAppendTime(    long timestamp){
      if (record.magic() == Record.MAGIC_VALUE_V0)       throw new IllegalArgumentException("Cannot set timestamp for a record with magic = 0");
      setTimestampAndUpdateCrc(TimestampType.LOG_APPEND_TIME,timestamp);
    }
    private void setTimestampAndUpdateCrc(    TimestampType timestampType,    long timestamp){
      byte attributes=record.attributes();
      buffer.put(LOG_OVERHEAD + Record.ATTRIBUTES_OFFSET,timestampType.updateAttributes(attributes));
      buffer.putLong(LOG_OVERHEAD + Record.TIMESTAMP_OFFSET,timestamp);
      long crc=record.computeChecksum();
      Utils.writeUnsignedInt(buffer,LOG_OVERHEAD + Record.CRC_OFFSET,crc);
    }
    public ByteBuffer buffer(){
      return buffer;
    }
  }
}
