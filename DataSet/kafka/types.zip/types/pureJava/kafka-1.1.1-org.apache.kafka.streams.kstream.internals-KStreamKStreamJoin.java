class KStreamKStreamJoin<K,R,V1,V2> implements ProcessorSupplier<K,V1> {
  private final String otherWindowName;
  private final long joinBeforeMs;
  private final long joinAfterMs;
  private final ValueJoiner<? super V1,? super V2,? extends R> joiner;
  private final boolean outer;
  KStreamKStreamJoin(  String otherWindowName,  long joinBeforeMs,  long joinAfterMs,  ValueJoiner<? super V1,? super V2,? extends R> joiner,  boolean outer){
    this.otherWindowName=otherWindowName;
    this.joinBeforeMs=joinBeforeMs;
    this.joinAfterMs=joinAfterMs;
    this.joiner=joiner;
    this.outer=outer;
  }
  @Override public Processor<K,V1> get(){
    return new KStreamKStreamJoinProcessor();
  }
private class KStreamKStreamJoinProcessor extends AbstractProcessor<K,V1> {
    private WindowStore<K,V2> otherWindow;
    @SuppressWarnings("unchecked") @Override public void init(    ProcessorContext context){
      super.init(context);
      otherWindow=(WindowStore<K,V2>)context.getStateStore(otherWindowName);
    }
    @Override public void process(    final K key,    final V1 value){
      if (key == null || value == null) {
        return;
      }
      boolean needOuterJoin=outer;
      final long timeFrom=Math.max(0L,context().timestamp() - joinBeforeMs);
      final long timeTo=Math.max(0L,context().timestamp() + joinAfterMs);
      try (WindowStoreIterator<V2> iter=otherWindow.fetch(key,timeFrom,timeTo)){
        while (iter.hasNext()) {
          needOuterJoin=false;
          context().forward(key,joiner.apply(value,iter.next().value));
        }
        if (needOuterJoin) {
          context().forward(key,joiner.apply(value,null));
        }
      }
     }
  }
}
