static class InternalTopicMetadata {
  public final InternalTopicConfig config;
  public int numPartitions;
  InternalTopicMetadata(  final InternalTopicConfig config){
    this.config=config;
    this.numPartitions=UNKNOWN;
  }
  @Override public String toString(){
    return "InternalTopicMetadata(" + "config=" + config + ", numPartitions="+ numPartitions+ ")";
  }
}
