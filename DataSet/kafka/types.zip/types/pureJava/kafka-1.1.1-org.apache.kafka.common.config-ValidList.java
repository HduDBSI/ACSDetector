public static class ValidList implements Validator {
  final ValidString validString;
  private ValidList(  List<String> validStrings){
    this.validString=new ValidString(validStrings);
  }
  public static ValidList in(  String... validStrings){
    return new ValidList(Arrays.asList(validStrings));
  }
  @Override public void ensureValid(  final String name,  final Object value){
    @SuppressWarnings("unchecked") List<String> values=(List<String>)value;
    for (    String string : values) {
      validString.ensureValid(name,string);
    }
  }
  public String toString(){
    return validString.toString();
  }
}
