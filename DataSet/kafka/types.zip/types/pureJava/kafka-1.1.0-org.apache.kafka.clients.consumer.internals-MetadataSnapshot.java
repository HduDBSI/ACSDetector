private static class MetadataSnapshot {
  private final Map<String,Integer> partitionsPerTopic;
  private MetadataSnapshot(  SubscriptionState subscription,  Cluster cluster){
    Map<String,Integer> partitionsPerTopic=new HashMap<>();
    for (    String topic : subscription.groupSubscription())     partitionsPerTopic.put(topic,cluster.partitionCountForTopic(topic));
    this.partitionsPerTopic=partitionsPerTopic;
  }
  @Override public boolean equals(  Object o){
    if (this == o)     return true;
    if (o == null || getClass() != o.getClass())     return false;
    MetadataSnapshot that=(MetadataSnapshot)o;
    return partitionsPerTopic != null ? partitionsPerTopic.equals(that.partitionsPerTopic) : that.partitionsPerTopic == null;
  }
  @Override public int hashCode(){
    return partitionsPerTopic != null ? partitionsPerTopic.hashCode() : 0;
  }
}
