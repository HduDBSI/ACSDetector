public abstract class AbstractTask {
  private static final Logger log=LoggerFactory.getLogger(AbstractTask.class);
  protected final TaskId id;
  protected final String applicationId;
  protected final ProcessorTopology topology;
  protected final Consumer consumer;
  protected final ProcessorStateManager stateMgr;
  protected final Set<TopicPartition> partitions;
  protected InternalProcessorContext processorContext;
  protected final ThreadCache cache;
  /** 
 * @throws ProcessorStateException if the state manager cannot be created
 */
  protected AbstractTask(  final TaskId id,  final String applicationId,  final Collection<TopicPartition> partitions,  final ProcessorTopology topology,  final Consumer<byte[],byte[]> consumer,  final Consumer<byte[],byte[]> restoreConsumer,  final boolean isStandby,  final StateDirectory stateDirectory,  final ThreadCache cache){
    this.id=id;
    this.applicationId=applicationId;
    this.partitions=new HashSet<>(partitions);
    this.topology=topology;
    this.consumer=consumer;
    this.cache=cache;
    try {
      stateMgr=new ProcessorStateManager(id,partitions,restoreConsumer,isStandby,stateDirectory,topology.storeToChangelogTopic());
    }
 catch (    IOException e) {
      throw new ProcessorStateException(String.format("task [%s] Error while creating the state manager",id),e);
    }
  }
  protected void initializeStateStores(){
    initializeOffsetLimits();
    for (    StateStore store : this.topology.stateStores()) {
      log.trace("task [{}] Initializing store {}",id(),store.name());
      store.init(this.processorContext,store);
    }
  }
  public final TaskId id(){
    return id;
  }
  public final String applicationId(){
    return applicationId;
  }
  public final Set<TopicPartition> partitions(){
    return this.partitions;
  }
  public final ProcessorTopology topology(){
    return topology;
  }
  public final ProcessorContext context(){
    return processorContext;
  }
  public final ThreadCache cache(){
    return cache;
  }
  public abstract void commit();
  public abstract void close();
  public abstract void initTopology();
  public abstract void closeTopology();
  public abstract void commitOffsets();
  /** 
 * @throws ProcessorStateException if there is an error while closing the state manager
 * @param writeCheckpoint boolean indicating if a checkpoint file should be written
 */
  void closeStateManager(  final boolean writeCheckpoint){
    log.trace("task [{}] Closing",id());
    try {
      stateMgr.close(writeCheckpoint ? activeTaskCheckpointableOffsets() : null);
    }
 catch (    IOException e) {
      throw new ProcessorStateException("Error while closing the state manager",e);
    }
  }
  protected Map<TopicPartition,Long> activeTaskCheckpointableOffsets(){
    return Collections.emptyMap();
  }
  protected void initializeOffsetLimits(){
    for (    TopicPartition partition : partitions) {
      try {
        OffsetAndMetadata metadata=consumer.committed(partition);
        stateMgr.putOffsetLimit(partition,metadata != null ? metadata.offset() : 0L);
      }
 catch (      AuthorizationException e) {
        throw new ProcessorStateException(String.format("task [%s] AuthorizationException when initializing offsets for %s",id,partition),e);
      }
catch (      WakeupException e) {
        throw e;
      }
catch (      KafkaException e) {
        throw new ProcessorStateException(String.format("task [%s] Failed to initialize offsets for %s",id,partition),e);
      }
    }
  }
  public StateStore getStore(  final String name){
    return stateMgr.getStore(name);
  }
  /** 
 * Produces a string representation containing useful information about a StreamTask. This is useful in debugging scenarios.
 * @return A string representation of the StreamTask instance.
 */
  @Override public String toString(){
    return toString("");
  }
  /** 
 * Produces a string representation containing useful information about a StreamTask starting with the given indent. This is useful in debugging scenarios.
 * @return A string representation of the StreamTask instance.
 */
  public String toString(  final String indent){
    final StringBuilder sb=new StringBuilder(indent + "StreamsTask taskId: " + this.id()+ "\n");
    if (topology != null) {
      sb.append(indent).append(topology.toString(indent + "\t"));
    }
    if (partitions != null && !partitions.isEmpty()) {
      sb.append(indent).append("Partitions [");
      for (      TopicPartition topicPartition : partitions) {
        sb.append(topicPartition.toString()).append(", ");
      }
      sb.setLength(sb.length() - 2);
      sb.append("]\n");
    }
    return sb.toString();
  }
  /** 
 * Flush all state stores owned by this task
 */
  public void flushState(){
    stateMgr.flush((InternalProcessorContext)this.context());
  }
}
