private static class ShutdownComplete extends ConsumerEvent {
  @Override public String name(){
    return "shutdown_complete";
  }
}
