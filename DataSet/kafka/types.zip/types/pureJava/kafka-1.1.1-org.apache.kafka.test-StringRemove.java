private static class StringRemove implements Reducer<String> {
  @Override public String apply(  String value1,  String value2){
    return value1 + "-" + value2;
  }
}
