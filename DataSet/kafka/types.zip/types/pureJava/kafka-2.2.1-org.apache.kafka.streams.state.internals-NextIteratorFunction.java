interface NextIteratorFunction<K,V,StoreType> {
  KeyValueIterator<K,V> apply(  final StoreType store);
}
