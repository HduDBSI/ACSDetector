public class RecordQueueTest {
  private final Serializer<Integer> intSerializer=new IntegerSerializer();
  private final Deserializer<Integer> intDeserializer=new IntegerDeserializer();
  private final TimestampExtractor timestampExtractor=new MockTimestampExtractor();
  private final String[] topics={"topic"};
  final MockProcessorContext context=new MockProcessorContext(StateSerdes.withBuiltinTypes("anyName",Bytes.class,Bytes.class),new RecordCollectorImpl(null,null,new LogContext("record-queue-test "),new DefaultProductionExceptionHandler()));
  private final MockSourceNode mockSourceNodeWithMetrics=new MockSourceNode<>(topics,intDeserializer,intDeserializer);
  private final RecordQueue queue=new RecordQueue(new TopicPartition(topics[0],1),mockSourceNodeWithMetrics,timestampExtractor,new LogAndFailExceptionHandler(),context,new LogContext());
  private final RecordQueue queueThatSkipsDeserializeErrors=new RecordQueue(new TopicPartition(topics[0],1),mockSourceNodeWithMetrics,timestampExtractor,new LogAndContinueExceptionHandler(),context,new LogContext());
  private final byte[] recordValue=intSerializer.serialize(null,10);
  private final byte[] recordKey=intSerializer.serialize(null,1);
  @Before public void before(){
    mockSourceNodeWithMetrics.init(context);
  }
  @After public void after(){
    mockSourceNodeWithMetrics.close();
  }
  @Test public void testTimeTracking(){
    assertTrue(queue.isEmpty());
    assertEquals(0,queue.size());
    assertEquals(TimestampTracker.NOT_KNOWN,queue.timestamp());
    List<ConsumerRecord<byte[],byte[]>> list1=Arrays.asList(new ConsumerRecord<>("topic",1,2,0L,TimestampType.CREATE_TIME,0L,0,0,recordKey,recordValue),new ConsumerRecord<>("topic",1,1,0L,TimestampType.CREATE_TIME,0L,0,0,recordKey,recordValue),new ConsumerRecord<>("topic",1,3,0L,TimestampType.CREATE_TIME,0L,0,0,recordKey,recordValue));
    queue.addRawRecords(list1);
    assertEquals(3,queue.size());
    assertEquals(1L,queue.timestamp());
    assertEquals(2,queue.timeTracker().size());
    assertEquals(2L,queue.poll().timestamp);
    assertEquals(2,queue.size());
    assertEquals(1L,queue.timestamp());
    assertEquals(2,queue.timeTracker().size());
    assertEquals(1L,queue.poll().timestamp);
    assertEquals(1,queue.size());
    assertEquals(3L,queue.timestamp());
    assertEquals(1,queue.timeTracker().size());
    List<ConsumerRecord<byte[],byte[]>> list2=Arrays.asList(new ConsumerRecord<>("topic",1,4,0L,TimestampType.CREATE_TIME,0L,0,0,recordKey,recordValue),new ConsumerRecord<>("topic",1,1,0L,TimestampType.CREATE_TIME,0L,0,0,recordKey,recordValue),new ConsumerRecord<>("topic",1,2,0L,TimestampType.CREATE_TIME,0L,0,0,recordKey,recordValue));
    queue.addRawRecords(list2);
    assertEquals(4,queue.size());
    assertEquals(3L,queue.timestamp());
    assertEquals(2,queue.timeTracker().size());
    assertEquals(3L,queue.poll().timestamp);
    assertEquals(3,queue.size());
    assertEquals(3L,queue.timestamp());
    assertEquals(2,queue.timeTracker().size());
    assertEquals(4L,queue.poll().timestamp);
    assertEquals(3L,queue.timestamp());
    assertEquals(2,queue.timeTracker().size());
    assertEquals(1L,queue.poll().timestamp);
    assertEquals(3L,queue.timestamp());
    assertEquals(1,queue.timeTracker().size());
    assertEquals(2L,queue.poll().timestamp);
    assertTrue(queue.isEmpty());
    assertEquals(0,queue.size());
    assertEquals(3L,queue.timestamp());
    assertEquals(0,queue.timeTracker().size());
    List<ConsumerRecord<byte[],byte[]>> list3=Arrays.asList(new ConsumerRecord<>("topic",1,4,0L,TimestampType.CREATE_TIME,0L,0,0,recordKey,recordValue),new ConsumerRecord<>("topic",1,5,0L,TimestampType.CREATE_TIME,0L,0,0,recordKey,recordValue),new ConsumerRecord<>("topic",1,6,0L,TimestampType.CREATE_TIME,0L,0,0,recordKey,recordValue));
    queue.addRawRecords(list3);
    assertEquals(3,queue.size());
    assertEquals(4L,queue.timestamp());
    assertEquals(4L,queue.poll().timestamp);
    assertEquals(2,queue.size());
    assertEquals(5L,queue.timestamp());
    assertEquals(2,queue.timeTracker().size());
    queue.clear();
    assertTrue(queue.isEmpty());
    assertEquals(0,queue.size());
    assertEquals(0,queue.timeTracker().size());
    assertEquals(TimestampTracker.NOT_KNOWN,queue.timestamp());
    queue.addRawRecords(list3);
    assertEquals(3,queue.size());
    assertEquals(4L,queue.timestamp());
  }
  @Test(expected=StreamsException.class) public void shouldThrowStreamsExceptionWhenKeyDeserializationFails(){
    final byte[] key=Serdes.Long().serializer().serialize("foo",1L);
    final List<ConsumerRecord<byte[],byte[]>> records=Collections.singletonList(new ConsumerRecord<>("topic",1,1,0L,TimestampType.CREATE_TIME,0L,0,0,key,recordValue));
    queue.addRawRecords(records);
  }
  @Test(expected=StreamsException.class) public void shouldThrowStreamsExceptionWhenValueDeserializationFails(){
    final byte[] value=Serdes.Long().serializer().serialize("foo",1L);
    final List<ConsumerRecord<byte[],byte[]>> records=Collections.singletonList(new ConsumerRecord<>("topic",1,1,0L,TimestampType.CREATE_TIME,0L,0,0,recordKey,value));
    queue.addRawRecords(records);
  }
  @Test public void shouldNotThrowStreamsExceptionWhenKeyDeserializationFailsWithSkipHandler() throws Exception {
    final byte[] key=Serdes.Long().serializer().serialize("foo",1L);
    final List<ConsumerRecord<byte[],byte[]>> records=Collections.singletonList(new ConsumerRecord<>("topic",1,1,0L,TimestampType.CREATE_TIME,0L,0,0,key,recordValue));
    final StateSerdes anyStateSerde=StateSerdes.withBuiltinTypes("anyName",Bytes.class,Bytes.class);
    queueThatSkipsDeserializeErrors.addRawRecords(records);
    assertEquals(0,queueThatSkipsDeserializeErrors.size());
  }
  @Test public void shouldNotThrowStreamsExceptionWhenValueDeserializationFailsWithSkipHandler() throws Exception {
    final byte[] value=Serdes.Long().serializer().serialize("foo",1L);
    final List<ConsumerRecord<byte[],byte[]>> records=Collections.singletonList(new ConsumerRecord<>("topic",1,1,0L,TimestampType.CREATE_TIME,0L,0,0,recordKey,value));
    queueThatSkipsDeserializeErrors.addRawRecords(records);
    assertEquals(0,queueThatSkipsDeserializeErrors.size());
  }
  @Test(expected=StreamsException.class) public void shouldThrowOnNegativeTimestamp(){
    final List<ConsumerRecord<byte[],byte[]>> records=Collections.singletonList(new ConsumerRecord<>("topic",1,1,-1L,TimestampType.CREATE_TIME,0L,0,0,recordKey,recordValue));
    final RecordQueue queue=new RecordQueue(new TopicPartition(topics[0],1),new MockSourceNode<>(topics,intDeserializer,intDeserializer),new FailOnInvalidTimestamp(),new LogAndContinueExceptionHandler(),null,new LogContext());
    queue.addRawRecords(records);
  }
  @Test public void shouldDropOnNegativeTimestamp(){
    final List<ConsumerRecord<byte[],byte[]>> records=Collections.singletonList(new ConsumerRecord<>("topic",1,1,-1L,TimestampType.CREATE_TIME,0L,0,0,recordKey,recordValue));
    final RecordQueue queue=new RecordQueue(new TopicPartition(topics[0],1),new MockSourceNode<>(topics,intDeserializer,intDeserializer),new LogAndSkipOnInvalidTimestamp(),new LogAndContinueExceptionHandler(),null,new LogContext());
    queue.addRawRecords(records);
    assertEquals(0,queue.size());
  }
}
