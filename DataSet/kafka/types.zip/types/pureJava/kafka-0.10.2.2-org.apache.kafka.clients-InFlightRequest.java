static class InFlightRequest {
  final RequestHeader header;
  final String destination;
  final RequestCompletionHandler callback;
  final boolean expectResponse;
  final boolean isInternalRequest;
  final Send send;
  final long sendTimeMs;
  final long createdTimeMs;
  public InFlightRequest(  RequestHeader header,  long createdTimeMs,  String destination,  RequestCompletionHandler callback,  boolean expectResponse,  boolean isInternalRequest,  Send send,  long sendTimeMs){
    this.header=header;
    this.destination=destination;
    this.callback=callback;
    this.expectResponse=expectResponse;
    this.isInternalRequest=isInternalRequest;
    this.send=send;
    this.sendTimeMs=sendTimeMs;
    this.createdTimeMs=createdTimeMs;
  }
  public ClientResponse completed(  AbstractResponse response,  long timeMs){
    return new ClientResponse(header,callback,destination,createdTimeMs,timeMs,false,null,response);
  }
  public ClientResponse disconnected(  long timeMs){
    return new ClientResponse(header,callback,destination,createdTimeMs,timeMs,true,null,null);
  }
}
