private static class OffsetsForTime {
  Map<TopicPartition,OffsetAndTimestamp> result;
  @Override public String toString(){
    return result.toString();
  }
}
