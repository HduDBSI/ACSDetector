/** 
 * Marks keys retrieved via `get` as used. This is needed because `Configurable.configure` takes a `Map` instead of an `AbstractConfig` and we can't change that without breaking public API like `Partitioner`.
 */
private class RecordingMap<V> extends HashMap<String,V> {
  private final String prefix;
  private final boolean withIgnoreFallback;
  RecordingMap(){
    this("",false);
  }
  RecordingMap(  String prefix,  boolean withIgnoreFallback){
    this.prefix=prefix;
    this.withIgnoreFallback=withIgnoreFallback;
  }
  RecordingMap(  Map<String,? extends V> m){
    this(m,"",false);
  }
  RecordingMap(  Map<String,? extends V> m,  String prefix,  boolean withIgnoreFallback){
    super(m);
    this.prefix=prefix;
    this.withIgnoreFallback=withIgnoreFallback;
  }
  @Override public V get(  Object key){
    if (key instanceof String) {
      String stringKey=(String)key;
      String keyWithPrefix;
      if (prefix.isEmpty()) {
        keyWithPrefix=stringKey;
      }
 else {
        keyWithPrefix=prefix + stringKey;
      }
      ignore(keyWithPrefix);
      if (withIgnoreFallback)       ignore(stringKey);
    }
    return super.get(key);
  }
}
