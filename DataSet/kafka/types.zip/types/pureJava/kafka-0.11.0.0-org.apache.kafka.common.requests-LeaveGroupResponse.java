public class LeaveGroupResponse extends AbstractResponse {
  private static final String ERROR_CODE_KEY_NAME="error_code";
  /** 
 * Possible error code: GROUP_LOAD_IN_PROGRESS (14) CONSUMER_COORDINATOR_NOT_AVAILABLE (15) NOT_COORDINATOR_FOR_CONSUMER (16) UNKNOWN_CONSUMER_ID (25) GROUP_AUTHORIZATION_FAILED (30)
 */
  private final Errors error;
  private final int throttleTimeMs;
  public LeaveGroupResponse(  Errors error){
    this(DEFAULT_THROTTLE_TIME,error);
  }
  public LeaveGroupResponse(  int throttleTimeMs,  Errors error){
    this.throttleTimeMs=throttleTimeMs;
    this.error=error;
  }
  public LeaveGroupResponse(  Struct struct){
    this.throttleTimeMs=struct.hasField(THROTTLE_TIME_KEY_NAME) ? struct.getInt(THROTTLE_TIME_KEY_NAME) : DEFAULT_THROTTLE_TIME;
    error=Errors.forCode(struct.getShort(ERROR_CODE_KEY_NAME));
  }
  public int throttleTimeMs(){
    return throttleTimeMs;
  }
  public Errors error(){
    return error;
  }
  @Override public Struct toStruct(  short version){
    Struct struct=new Struct(ApiKeys.LEAVE_GROUP.responseSchema(version));
    if (struct.hasField(THROTTLE_TIME_KEY_NAME))     struct.set(THROTTLE_TIME_KEY_NAME,throttleTimeMs);
    struct.set(ERROR_CODE_KEY_NAME,error.code());
    return struct;
  }
  public static LeaveGroupResponse parse(  ByteBuffer buffer,  short versionId){
    return new LeaveGroupResponse(ApiKeys.LEAVE_GROUP.parseResponse(versionId,buffer));
  }
}
