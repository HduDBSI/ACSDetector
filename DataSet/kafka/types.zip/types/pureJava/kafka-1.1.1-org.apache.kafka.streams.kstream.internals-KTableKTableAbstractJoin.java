abstract class KTableKTableAbstractJoin<K,R,V1,V2> implements KTableProcessorSupplier<K,V1,R> {
  private final KTableImpl<K,?,V1> table1;
  private final KTableImpl<K,?,V2> table2;
  final KTableValueGetterSupplier<K,V1> valueGetterSupplier1;
  final KTableValueGetterSupplier<K,V2> valueGetterSupplier2;
  final ValueJoiner<? super V1,? super V2,? extends R> joiner;
  boolean sendOldValues=false;
  KTableKTableAbstractJoin(  KTableImpl<K,?,V1> table1,  KTableImpl<K,?,V2> table2,  ValueJoiner<? super V1,? super V2,? extends R> joiner){
    this.table1=table1;
    this.table2=table2;
    this.valueGetterSupplier1=table1.valueGetterSupplier();
    this.valueGetterSupplier2=table2.valueGetterSupplier();
    this.joiner=joiner;
  }
  @Override public final void enableSendingOldValues(){
    table1.enableSendingOldValues();
    table2.enableSendingOldValues();
    sendOldValues=true;
  }
}
