/** 
 * The client has attempted to perform an operation on an invalid topic. For example the topic name is too long, contains invalid characters etc. This exception is not retriable because the operation won't suddenly become valid.
 * @see UnknownTopicOrPartitionException
 */
public class InvalidTopicException extends ApiException {
  private static final long serialVersionUID=1L;
  public InvalidTopicException(){
    super();
  }
  public InvalidTopicException(  String message,  Throwable cause){
    super(message,cause);
  }
  public InvalidTopicException(  String message){
    super(message);
  }
  public InvalidTopicException(  Throwable cause){
    super(cause);
  }
}
