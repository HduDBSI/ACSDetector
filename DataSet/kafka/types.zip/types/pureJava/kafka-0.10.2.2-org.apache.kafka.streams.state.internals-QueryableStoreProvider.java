/** 
 * A wrapper over all of the  {@link StateStoreProvider}s in a Topology
 */
public class QueryableStoreProvider {
  private final List<StateStoreProvider> storeProviders;
  private final GlobalStateStoreProvider globalStoreProvider;
  public QueryableStoreProvider(  final List<StateStoreProvider> storeProviders,  final GlobalStateStoreProvider globalStateStoreProvider){
    this.storeProviders=new ArrayList<>(storeProviders);
    this.globalStoreProvider=globalStateStoreProvider;
  }
  /** 
 * Get a composite object wrapping the instances of the  {@link StateStore} with the providedstoreName and  {@link QueryableStoreType}
 * @param storeName          name of the store
 * @param queryableStoreType accept stores passing {@link QueryableStoreType#accepts(StateStore)}
 * @param < T >                The expected type of the returned store
 * @return A composite object that wraps the store instances.
 */
  public <T>T getStore(  final String storeName,  final QueryableStoreType<T> queryableStoreType){
    final List<T> globalStore=globalStoreProvider.stores(storeName,queryableStoreType);
    if (!globalStore.isEmpty()) {
      return queryableStoreType.create(new WrappingStoreProvider(Collections.<StateStoreProvider>singletonList(globalStoreProvider)),storeName);
    }
    final List<T> allStores=new ArrayList<>();
    for (    StateStoreProvider storeProvider : storeProviders) {
      allStores.addAll(storeProvider.stores(storeName,queryableStoreType));
    }
    if (allStores.isEmpty()) {
      throw new InvalidStateStoreException("the state store, " + storeName + ", may have migrated to another instance.");
    }
    return queryableStoreType.create(new WrappingStoreProvider(storeProviders),storeName);
  }
}
