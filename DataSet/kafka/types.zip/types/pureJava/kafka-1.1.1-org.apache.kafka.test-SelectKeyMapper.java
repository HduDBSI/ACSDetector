private static class SelectKeyMapper<K,V> implements KeyValueMapper<K,V,K> {
  @Override public K apply(  K key,  V value){
    return key;
  }
}
