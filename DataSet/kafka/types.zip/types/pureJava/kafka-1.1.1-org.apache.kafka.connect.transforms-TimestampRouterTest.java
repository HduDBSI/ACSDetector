public class TimestampRouterTest {
  private final TimestampRouter<SourceRecord> xform=new TimestampRouter<>();
  @After public void teardown(){
    xform.close();
  }
  @Test public void defaultConfiguration(){
    xform.configure(Collections.<String,Object>emptyMap());
    final SourceRecord record=new SourceRecord(null,null,"test",0,null,null,null,null,1483425001864L);
    assertEquals("test-20170103",xform.apply(record).topic());
  }
}
