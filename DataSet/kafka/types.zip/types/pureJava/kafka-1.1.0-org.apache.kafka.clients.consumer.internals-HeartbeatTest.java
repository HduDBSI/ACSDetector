public class HeartbeatTest {
  private long timeout=300L;
  private long interval=100L;
  private long maxPollInterval=900L;
  private long retryBackoff=10L;
  private MockTime time=new MockTime();
  private Heartbeat heartbeat=new Heartbeat(timeout,interval,maxPollInterval,retryBackoff);
  @Test public void testShouldHeartbeat(){
    heartbeat.sentHeartbeat(time.milliseconds());
    time.sleep((long)((float)interval * 1.1));
    assertTrue(heartbeat.shouldHeartbeat(time.milliseconds()));
  }
  @Test public void testShouldNotHeartbeat(){
    heartbeat.sentHeartbeat(time.milliseconds());
    time.sleep(interval / 2);
    assertFalse(heartbeat.shouldHeartbeat(time.milliseconds()));
  }
  @Test public void testTimeToNextHeartbeat(){
    heartbeat.sentHeartbeat(0);
    assertEquals(100,heartbeat.timeToNextHeartbeat(0));
    assertEquals(0,heartbeat.timeToNextHeartbeat(100));
    assertEquals(0,heartbeat.timeToNextHeartbeat(200));
  }
  @Test public void testSessionTimeoutExpired(){
    heartbeat.sentHeartbeat(time.milliseconds());
    time.sleep(305);
    assertTrue(heartbeat.sessionTimeoutExpired(time.milliseconds()));
  }
  @Test public void testResetSession(){
    heartbeat.sentHeartbeat(time.milliseconds());
    time.sleep(305);
    heartbeat.resetTimeouts(time.milliseconds());
    assertFalse(heartbeat.sessionTimeoutExpired(time.milliseconds()));
  }
}
