/** 
 * Indicates a processor state operation (e.g. put, get) has failed.
 * @see org.apache.kafka.streams.processor.StateStore
 */
public class ProcessorStateException extends StreamsException {
  private final static long serialVersionUID=1L;
  public ProcessorStateException(  final String message){
    super(message);
  }
  public ProcessorStateException(  final String message,  final Throwable throwable){
    super(message,throwable);
  }
  public ProcessorStateException(  final Throwable throwable){
    super(throwable);
  }
}
