public static class KStreamTransformValuesProcessor<K,V,R> implements Processor<K,V> {
  private final InternalValueTransformerWithKey<K,V,R> valueTransformer;
  private ProcessorContext context;
  public KStreamTransformValuesProcessor(  final InternalValueTransformerWithKey<K,V,R> valueTransformer){
    this.valueTransformer=valueTransformer;
  }
  @Override public void init(  final ProcessorContext context){
    valueTransformer.init(new ProcessorContext(){
      @Override public String applicationId(){
        return context.applicationId();
      }
      @Override public TaskId taskId(){
        return context.taskId();
      }
      @Override public Serde<?> keySerde(){
        return context.keySerde();
      }
      @Override public Serde<?> valueSerde(){
        return context.valueSerde();
      }
      @Override public File stateDir(){
        return context.stateDir();
      }
      @Override public StreamsMetrics metrics(){
        return context.metrics();
      }
      @Override public void register(      final StateStore store,      final boolean deprecatedAndIgnoredLoggingEnabled,      final StateRestoreCallback stateRestoreCallback){
        context.register(store,deprecatedAndIgnoredLoggingEnabled,stateRestoreCallback);
      }
      @Override public StateStore getStateStore(      final String name){
        return context.getStateStore(name);
      }
      @Override public Cancellable schedule(      final long interval,      final PunctuationType type,      final Punctuator callback){
        return context.schedule(interval,type,callback);
      }
      @SuppressWarnings("deprecation") @Override public void schedule(      final long interval){
        context.schedule(interval);
      }
      @Override public <K,V>void forward(      final K key,      final V value){
        throw new StreamsException("ProcessorContext#forward() must not be called within TransformValues.");
      }
      @Override public <K,V>void forward(      final K key,      final V value,      final int childIndex){
        throw new StreamsException("ProcessorContext#forward() must not be called within TransformValues.");
      }
      @Override public <K,V>void forward(      final K key,      final V value,      final String childName){
        throw new StreamsException("ProcessorContext#forward() must not be called within TransformValues.");
      }
      @Override public void commit(){
        context.commit();
      }
      @Override public String topic(){
        return context.topic();
      }
      @Override public int partition(){
        return context.partition();
      }
      @Override public long offset(){
        return context.offset();
      }
      @Override public long timestamp(){
        return context.timestamp();
      }
      @Override public Map<String,Object> appConfigs(){
        return context.appConfigs();
      }
      @Override public Map<String,Object> appConfigsWithPrefix(      String prefix){
        return context.appConfigsWithPrefix(prefix);
      }
    }
);
    this.context=context;
  }
  @Override public void process(  K key,  V value){
    context.forward(key,valueTransformer.transform(key,value));
  }
  @SuppressWarnings("deprecation") @Override public void punctuate(  long timestamp){
    if (valueTransformer.punctuate(timestamp) != null) {
      throw new StreamsException("ValueTransformer#punctuate must return null.");
    }
  }
  @Override public void close(){
    valueTransformer.close();
  }
}
