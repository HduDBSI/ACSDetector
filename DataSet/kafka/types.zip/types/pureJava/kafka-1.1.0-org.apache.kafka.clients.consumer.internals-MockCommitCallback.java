private static class MockCommitCallback implements OffsetCommitCallback {
  public int invoked=0;
  public Exception exception=null;
  @Override public void onComplete(  Map<TopicPartition,OffsetAndMetadata> offsets,  Exception exception){
    invoked++;
    this.exception=exception;
  }
}
