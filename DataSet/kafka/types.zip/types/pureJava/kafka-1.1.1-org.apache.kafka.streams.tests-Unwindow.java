public static final class Unwindow<K,V> implements KeyValueMapper<Windowed<K>,V,K> {
  @Override public K apply(  final Windowed<K> winKey,  final V value){
    return winKey.key();
  }
}
