public class ChannelBuilders {
  private ChannelBuilders(){
  }
  /** 
 * @param securityProtocol the securityProtocol
 * @param mode the mode, it must be non-null if `securityProtocol` is not `PLAINTEXT`;it is ignored otherwise
 * @param loginType the loginType, it must be non-null if `securityProtocol` is SASL_*; it is ignored otherwise
 * @param configs client/server configs
 * @return the configured `ChannelBuilder`
 * @throws IllegalArgumentException if `mode` invariants described above is not maintained
 */
  public static ChannelBuilder create(  SecurityProtocol securityProtocol,  Mode mode,  LoginType loginType,  Map<String,?> configs){
    ChannelBuilder channelBuilder;
switch (securityProtocol) {
case SSL:
      requireNonNullMode(mode,securityProtocol);
    channelBuilder=new SslChannelBuilder(mode);
  break;
case SASL_SSL:
case SASL_PLAINTEXT:
requireNonNullMode(mode,securityProtocol);
if (loginType == null) throw new IllegalArgumentException("`loginType` must be non-null if `securityProtocol` is `" + securityProtocol + "`");
channelBuilder=new SaslChannelBuilder(mode,loginType,securityProtocol);
break;
case PLAINTEXT:
case TRACE:
channelBuilder=new PlaintextChannelBuilder();
break;
default :
throw new IllegalArgumentException("Unexpected securityProtocol " + securityProtocol);
}
channelBuilder.configure(configs);
return channelBuilder;
}
/** 
 * Returns a configured `PrincipalBuilder`.
 */
static PrincipalBuilder createPrincipalBuilder(Map<String,?> configs){
Class<?> principalBuilderClass=(Class<?>)configs.get(SslConfigs.PRINCIPAL_BUILDER_CLASS_CONFIG);
PrincipalBuilder principalBuilder;
if (principalBuilderClass == null) principalBuilder=new DefaultPrincipalBuilder();
 else principalBuilder=(PrincipalBuilder)Utils.newInstance(principalBuilderClass);
principalBuilder.configure(configs);
return principalBuilder;
}
private static void requireNonNullMode(Mode mode,SecurityProtocol securityProtocol){
if (mode == null) throw new IllegalArgumentException("`mode` must be non-null if `securityProtocol` is `" + securityProtocol + "`");
}
}
