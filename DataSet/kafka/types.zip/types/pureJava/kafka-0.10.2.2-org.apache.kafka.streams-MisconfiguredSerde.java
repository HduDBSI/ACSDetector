static class MisconfiguredSerde implements Serde {
  @Override public void configure(  final Map configs,  final boolean isKey){
    throw new RuntimeException("boom");
  }
  @Override public void close(){
  }
  @Override public Serializer serializer(){
    return null;
  }
  @Override public Deserializer deserializer(){
    return null;
  }
}
