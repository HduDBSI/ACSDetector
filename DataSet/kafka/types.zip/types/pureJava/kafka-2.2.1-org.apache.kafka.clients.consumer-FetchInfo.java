private static class FetchInfo {
  long offset;
  int count;
  FetchInfo(  long offset,  int count){
    this.offset=offset;
    this.count=count;
  }
}
