private static final class KStreamPassThroughProcessor<K,V> extends AbstractProcessor<K,V> {
  @Override public void process(  K key,  V value){
    context().forward(key,value);
  }
}
