/** 
 * Thrown when a request breaks basic wire protocol rules. This most likely occurs because of a request being malformed by the client library or the message was sent to an incompatible broker.
 */
public class InvalidRequestException extends ApiException {
  private static final long serialVersionUID=1L;
  public InvalidRequestException(  String message){
    super(message);
  }
  public InvalidRequestException(  String message,  Throwable cause){
    super(message,cause);
  }
}
