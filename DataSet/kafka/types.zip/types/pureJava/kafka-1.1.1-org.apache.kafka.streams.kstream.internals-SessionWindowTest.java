public class SessionWindowTest {
  private long start=50;
  private long end=100;
  private final SessionWindow window=new SessionWindow(start,end);
  private final TimeWindow timeWindow=new TimeWindow(start,end);
  @Test public void shouldNotOverlapIfOtherWindowIsBeforeThisWindow(){
    assertFalse(window.overlap(new SessionWindow(0,25)));
    assertFalse(window.overlap(new SessionWindow(0,start - 1)));
    assertFalse(window.overlap(new SessionWindow(start - 1,start - 1)));
  }
  @Test public void shouldOverlapIfOtherWindowEndIsWithinThisWindow(){
    assertTrue(window.overlap(new SessionWindow(0,start)));
    assertTrue(window.overlap(new SessionWindow(0,start + 1)));
    assertTrue(window.overlap(new SessionWindow(0,75)));
    assertTrue(window.overlap(new SessionWindow(0,end - 1)));
    assertTrue(window.overlap(new SessionWindow(0,end)));
    assertTrue(window.overlap(new SessionWindow(start - 1,start)));
    assertTrue(window.overlap(new SessionWindow(start - 1,start + 1)));
    assertTrue(window.overlap(new SessionWindow(start - 1,75)));
    assertTrue(window.overlap(new SessionWindow(start - 1,end - 1)));
    assertTrue(window.overlap(new SessionWindow(start - 1,end)));
  }
  @Test public void shouldOverlapIfOtherWindowContainsThisWindow(){
    assertTrue(window.overlap(new SessionWindow(0,end)));
    assertTrue(window.overlap(new SessionWindow(0,end + 1)));
    assertTrue(window.overlap(new SessionWindow(0,150)));
    assertTrue(window.overlap(new SessionWindow(start - 1,end)));
    assertTrue(window.overlap(new SessionWindow(start - 1,end + 1)));
    assertTrue(window.overlap(new SessionWindow(start - 1,150)));
    assertTrue(window.overlap(new SessionWindow(start,end)));
    assertTrue(window.overlap(new SessionWindow(start,end + 1)));
    assertTrue(window.overlap(new SessionWindow(start,150)));
  }
  @Test public void shouldOverlapIfOtherWindowIsWithinThisWindow(){
    assertTrue(window.overlap(new SessionWindow(start,start)));
    assertTrue(window.overlap(new SessionWindow(start,75)));
    assertTrue(window.overlap(new SessionWindow(start,end)));
    assertTrue(window.overlap(new SessionWindow(75,end)));
    assertTrue(window.overlap(new SessionWindow(end,end)));
  }
  @Test public void shouldOverlapIfOtherWindowStartIsWithinThisWindow(){
    assertTrue(window.overlap(new SessionWindow(start,end + 1)));
    assertTrue(window.overlap(new SessionWindow(start,150)));
    assertTrue(window.overlap(new SessionWindow(75,end + 1)));
    assertTrue(window.overlap(new SessionWindow(75,150)));
    assertTrue(window.overlap(new SessionWindow(end,end + 1)));
    assertTrue(window.overlap(new SessionWindow(end,150)));
  }
  @Test public void shouldNotOverlapIsOtherWindowIsAfterThisWindow(){
    assertFalse(window.overlap(new SessionWindow(end + 1,end + 1)));
    assertFalse(window.overlap(new SessionWindow(end + 1,150)));
    assertFalse(window.overlap(new SessionWindow(125,150)));
  }
  @Test(expected=IllegalArgumentException.class) public void cannotCompareSessionWindowWithDifferentWindowType(){
    window.overlap(timeWindow);
  }
}
