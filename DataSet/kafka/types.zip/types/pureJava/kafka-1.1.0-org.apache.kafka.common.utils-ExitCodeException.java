/** 
 * This is an IOException with exit code added.
 */
@SuppressWarnings("serial") public static class ExitCodeException extends IOException {
  int exitCode;
  public ExitCodeException(  int exitCode,  String message){
    super(message);
    this.exitCode=exitCode;
  }
  public int getExitCode(){
    return exitCode;
  }
}
