/** 
 * {@code KafkaClientSupplier} can be used to provide custom Kafka clients to a {@link KafkaStreams} instance.
 * @see KafkaStreams#KafkaStreams(Topology,java.util.Properties,KafkaClientSupplier)
 */
public interface KafkaClientSupplier {
  /** 
 * Create an  {@link AdminClient} which is used for internal topic management.
 * @param config Supplied by the {@link java.util.Properties} given to the {@link KafkaStreams}
 * @return an instance of {@link AdminClient}
 */
  AdminClient getAdminClient(  final Map<String,Object> config);
  /** 
 * Create a  {@link Producer} which is used to write records to sink topics.
 * @param config {@link StreamsConfig#getProducerConfigs(String) producer config} which is supplied by the{@link java.util.Properties} given to the {@link KafkaStreams} instance
 * @return an instance of Kafka producer
 */
  Producer<byte[],byte[]> getProducer(  final Map<String,Object> config);
  /** 
 * Create a  {@link Consumer} which is used to read records of source topics.
 * @param config {@link StreamsConfig#getMainConsumerConfigs(String,String) consumer config} which issupplied by the  {@link java.util.Properties} given to the {@link KafkaStreams} instance
 * @return an instance of Kafka consumer
 */
  Consumer<byte[],byte[]> getConsumer(  final Map<String,Object> config);
  /** 
 * Create a  {@link Consumer} which is used to read records to restore {@link StateStore}s.
 * @param config {@link StreamsConfig#getRestoreConsumerConfigs(String) restore consumer config} which is suppliedby the  {@link java.util.Properties} given to the {@link KafkaStreams}
 * @return an instance of Kafka consumer
 */
  Consumer<byte[],byte[]> getRestoreConsumer(  final Map<String,Object> config);
  /** 
 * Create a  {@link Consumer} which is used to consume records for {@link GlobalKTable}.
 * @param config {@link StreamsConfig#getGlobalConsumerConfigs(String) global consumer config} which is suppliedby the  {@link java.util.Properties} given to the {@link KafkaStreams}
 * @return an instance of Kafka consumer
 */
  Consumer<byte[],byte[]> getGlobalConsumer(  final Map<String,Object> config);
}
