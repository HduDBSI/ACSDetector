/** 
 * The implementation class of  {@link KGroupedTable}.
 * @param < K > the key type
 * @param < V > the value type
 */
public class KGroupedTableImpl<K,V> extends AbstractStream<K> implements KGroupedTable<K,V> {
  private static final String AGGREGATE_NAME="KTABLE-AGGREGATE-";
  private static final String REDUCE_NAME="KTABLE-REDUCE-";
  protected final Serde<K> keySerde;
  protected final Serde<V> valSerde;
  private boolean isQueryable;
  private final Initializer<Long> countInitializer=new Initializer<Long>(){
    @Override public Long apply(){
      return 0L;
    }
  }
;
  private final Aggregator<K,V,Long> countAdder=new Aggregator<K,V,Long>(){
    @Override public Long apply(    K aggKey,    V value,    Long aggregate){
      return aggregate + 1L;
    }
  }
;
  private Aggregator<K,V,Long> countSubtractor=new Aggregator<K,V,Long>(){
    @Override public Long apply(    K aggKey,    V value,    Long aggregate){
      return aggregate - 1L;
    }
  }
;
  KGroupedTableImpl(  final InternalStreamsBuilder builder,  final String name,  final String sourceName,  final Serde<K> keySerde,  final Serde<V> valSerde){
    super(builder,name,Collections.singleton(sourceName));
    this.keySerde=keySerde;
    this.valSerde=valSerde;
    this.isQueryable=true;
  }
  private void determineIsQueryable(  final String queryableStoreName){
    if (queryableStoreName == null) {
      isQueryable=false;
    }
  }
  @SuppressWarnings("deprecation") @Override public <T>KTable<K,T> aggregate(  final Initializer<T> initializer,  final Aggregator<? super K,? super V,T> adder,  final Aggregator<? super K,? super V,T> subtractor,  final Serde<T> aggValueSerde,  final String queryableStoreName){
    determineIsQueryable(queryableStoreName);
    return aggregate(initializer,adder,subtractor,keyValueStore(keySerde,aggValueSerde,getOrCreateName(queryableStoreName,AGGREGATE_NAME)));
  }
  @SuppressWarnings("deprecation") @Override public <T>KTable<K,T> aggregate(  final Initializer<T> initializer,  final Aggregator<? super K,? super V,T> adder,  final Aggregator<? super K,? super V,T> subtractor,  final Serde<T> aggValueSerde){
    return aggregate(initializer,adder,subtractor,aggValueSerde,null);
  }
  @SuppressWarnings("deprecation") @Override public <T>KTable<K,T> aggregate(  final Initializer<T> initializer,  final Aggregator<? super K,? super V,T> adder,  final Aggregator<? super K,? super V,T> subtractor,  final String queryableStoreName){
    determineIsQueryable(queryableStoreName);
    return aggregate(initializer,adder,subtractor,null,getOrCreateName(queryableStoreName,AGGREGATE_NAME));
  }
  @Override public <T>KTable<K,T> aggregate(  final Initializer<T> initializer,  final Aggregator<? super K,? super V,T> adder,  final Aggregator<? super K,? super V,T> subtractor){
    return aggregate(initializer,adder,subtractor,(String)null);
  }
  @SuppressWarnings("deprecation") @Override public <T>KTable<K,T> aggregate(  final Initializer<T> initializer,  final Aggregator<? super K,? super V,T> adder,  final Aggregator<? super K,? super V,T> subtractor,  final org.apache.kafka.streams.processor.StateStoreSupplier<KeyValueStore> storeSupplier){
    Objects.requireNonNull(initializer,"initializer can't be null");
    Objects.requireNonNull(adder,"adder can't be null");
    Objects.requireNonNull(subtractor,"subtractor can't be null");
    Objects.requireNonNull(storeSupplier,"storeSupplier can't be null");
    ProcessorSupplier<K,Change<V>> aggregateSupplier=new KTableAggregate<>(storeSupplier.name(),initializer,adder,subtractor);
    return doAggregate(aggregateSupplier,AGGREGATE_NAME,storeSupplier);
  }
  @SuppressWarnings("deprecation") private <T>KTable<K,T> doAggregate(  final ProcessorSupplier<K,Change<V>> aggregateSupplier,  final String functionName,  final org.apache.kafka.streams.processor.StateStoreSupplier<KeyValueStore> storeSupplier){
    final String sinkName=builder.newProcessorName(KStreamImpl.SINK_NAME);
    final String sourceName=builder.newProcessorName(KStreamImpl.SOURCE_NAME);
    final String funcName=builder.newProcessorName(functionName);
    buildAggregate(aggregateSupplier,storeSupplier.name() + KStreamImpl.REPARTITION_TOPIC_SUFFIX,funcName,sourceName,sinkName);
    builder.internalTopologyBuilder.addStateStore(storeSupplier,funcName);
    return new KTableImpl<>(builder,funcName,aggregateSupplier,Collections.singleton(sourceName),storeSupplier.name(),isQueryable);
  }
  private void buildAggregate(  final ProcessorSupplier<K,Change<V>> aggregateSupplier,  final String topic,  final String funcName,  final String sourceName,  final String sinkName){
    final Serializer<? extends K> keySerializer=keySerde == null ? null : keySerde.serializer();
    final Deserializer<? extends K> keyDeserializer=keySerde == null ? null : keySerde.deserializer();
    final Serializer<? extends V> valueSerializer=valSerde == null ? null : valSerde.serializer();
    final Deserializer<? extends V> valueDeserializer=valSerde == null ? null : valSerde.deserializer();
    final ChangedSerializer<? extends V> changedValueSerializer=new ChangedSerializer<>(valueSerializer);
    final ChangedDeserializer<? extends V> changedValueDeserializer=new ChangedDeserializer<>(valueDeserializer);
    builder.internalTopologyBuilder.addInternalTopic(topic);
    builder.internalTopologyBuilder.addSink(sinkName,topic,keySerializer,changedValueSerializer,null,this.name);
    builder.internalTopologyBuilder.addSource(null,sourceName,new FailOnInvalidTimestamp(),keyDeserializer,changedValueDeserializer,topic);
    builder.internalTopologyBuilder.addProcessor(funcName,aggregateSupplier,sourceName);
  }
  private <T>KTable<K,T> doAggregate(  final ProcessorSupplier<K,Change<V>> aggregateSupplier,  final String functionName,  final MaterializedInternal<K,T,KeyValueStore<Bytes,byte[]>> materialized){
    final String sinkName=builder.newProcessorName(KStreamImpl.SINK_NAME);
    final String sourceName=builder.newProcessorName(KStreamImpl.SOURCE_NAME);
    final String funcName=builder.newProcessorName(functionName);
    buildAggregate(aggregateSupplier,materialized.storeName() + KStreamImpl.REPARTITION_TOPIC_SUFFIX,funcName,sourceName,sinkName);
    builder.internalTopologyBuilder.addStateStore(new KeyValueStoreMaterializer<>(materialized).materialize(),funcName);
    return new KTableImpl<>(builder,funcName,aggregateSupplier,Collections.singleton(sourceName),materialized.storeName(),isQueryable);
  }
  @SuppressWarnings("deprecation") @Override public KTable<K,V> reduce(  final Reducer<V> adder,  final Reducer<V> subtractor,  final String queryableStoreName){
    determineIsQueryable(queryableStoreName);
    return reduce(adder,subtractor,keyValueStore(keySerde,valSerde,getOrCreateName(queryableStoreName,REDUCE_NAME)));
  }
  @Override public KTable<K,V> reduce(  final Reducer<V> adder,  final Reducer<V> subtractor,  final Materialized<K,V,KeyValueStore<Bytes,byte[]>> materialized){
    Objects.requireNonNull(adder,"adder can't be null");
    Objects.requireNonNull(subtractor,"subtractor can't be null");
    Objects.requireNonNull(materialized,"materialized can't be null");
    final MaterializedInternal<K,V,KeyValueStore<Bytes,byte[]>> materializedInternal=new MaterializedInternal<>(materialized,builder,REDUCE_NAME);
    final ProcessorSupplier<K,Change<V>> aggregateSupplier=new KTableReduce<>(materializedInternal.storeName(),adder,subtractor);
    return doAggregate(aggregateSupplier,REDUCE_NAME,materializedInternal);
  }
  @Override public KTable<K,V> reduce(  final Reducer<V> adder,  final Reducer<V> subtractor){
    return reduce(adder,subtractor,(String)null);
  }
  @SuppressWarnings("deprecation") @Override public KTable<K,V> reduce(  final Reducer<V> adder,  final Reducer<V> subtractor,  final org.apache.kafka.streams.processor.StateStoreSupplier<KeyValueStore> storeSupplier){
    Objects.requireNonNull(adder,"adder can't be null");
    Objects.requireNonNull(subtractor,"subtractor can't be null");
    Objects.requireNonNull(storeSupplier,"storeSupplier can't be null");
    ProcessorSupplier<K,Change<V>> aggregateSupplier=new KTableReduce<>(storeSupplier.name(),adder,subtractor);
    return doAggregate(aggregateSupplier,REDUCE_NAME,storeSupplier);
  }
  @SuppressWarnings("deprecation") @Override public KTable<K,Long> count(  final String queryableStoreName){
    determineIsQueryable(queryableStoreName);
    return count(keyValueStore(keySerde,Serdes.Long(),getOrCreateName(queryableStoreName,AGGREGATE_NAME)));
  }
  @Override public KTable<K,Long> count(  final Materialized<K,Long,KeyValueStore<Bytes,byte[]>> materialized){
    return aggregate(countInitializer,countAdder,countSubtractor,materialized);
  }
  @SuppressWarnings("unchecked") @Override public <VR>KTable<K,VR> aggregate(  final Initializer<VR> initializer,  final Aggregator<? super K,? super V,VR> adder,  final Aggregator<? super K,? super V,VR> subtractor,  final Materialized<K,VR,KeyValueStore<Bytes,byte[]>> materialized){
    Objects.requireNonNull(initializer,"initializer can't be null");
    Objects.requireNonNull(adder,"adder can't be null");
    Objects.requireNonNull(subtractor,"subtractor can't be null");
    Objects.requireNonNull(materialized,"materialized can't be null");
    final MaterializedInternal<K,VR,KeyValueStore<Bytes,byte[]>> materializedInternal=new MaterializedInternal<>(materialized,builder,AGGREGATE_NAME);
    if (materializedInternal.keySerde() == null) {
      materializedInternal.withKeySerde(keySerde);
    }
    final ProcessorSupplier<K,Change<V>> aggregateSupplier=new KTableAggregate<>(materializedInternal.storeName(),initializer,adder,subtractor);
    return doAggregate(aggregateSupplier,AGGREGATE_NAME,materializedInternal);
  }
  @Override public KTable<K,Long> count(){
    return count((String)null);
  }
  @SuppressWarnings("deprecation") @Override public KTable<K,Long> count(  final org.apache.kafka.streams.processor.StateStoreSupplier<KeyValueStore> storeSupplier){
    return this.aggregate(countInitializer,countAdder,countSubtractor,storeSupplier);
  }
}
