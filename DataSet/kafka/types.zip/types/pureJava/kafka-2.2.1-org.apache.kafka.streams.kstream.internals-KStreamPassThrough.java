class KStreamPassThrough<K,V> implements ProcessorSupplier<K,V> {
  @Override public Processor<K,V> get(){
    return new KStreamPassThroughProcessor<>();
  }
private static final class KStreamPassThroughProcessor<K,V> extends AbstractProcessor<K,V> {
    @Override public void process(    final K key,    final V value){
      context().forward(key,value);
    }
  }
}
