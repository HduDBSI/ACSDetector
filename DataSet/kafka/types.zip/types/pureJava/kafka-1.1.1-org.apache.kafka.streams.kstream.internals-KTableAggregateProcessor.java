private class KTableAggregateProcessor extends AbstractProcessor<K,Change<V>> {
  private KeyValueStore<K,T> store;
  private TupleForwarder<K,T> tupleForwarder;
  @SuppressWarnings("unchecked") @Override public void init(  final ProcessorContext context){
    super.init(context);
    store=(KeyValueStore<K,T>)context.getStateStore(storeName);
    tupleForwarder=new TupleForwarder<>(store,context,new ForwardingCacheFlushListener<K,V>(context,sendOldValues),sendOldValues);
  }
  /** 
 * @throws StreamsException if key is null
 */
  @Override public void process(  K key,  Change<V> value){
    if (key == null)     throw new StreamsException("Record key for KTable aggregate operator with state " + storeName + " should not be null.");
    T oldAgg=store.get(key);
    if (oldAgg == null)     oldAgg=initializer.apply();
    T newAgg=oldAgg;
    if (value.oldValue != null) {
      newAgg=remove.apply(key,value.oldValue,newAgg);
    }
    if (value.newValue != null) {
      newAgg=add.apply(key,value.newValue,newAgg);
    }
    store.put(key,newAgg);
    tupleForwarder.maybeForward(key,newAgg,oldAgg);
  }
}
