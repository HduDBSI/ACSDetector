interface NextIteratorFunction<K,V> {
  KeyValueIterator<K,V> apply(  final ReadOnlyKeyValueStore<K,V> store);
}
