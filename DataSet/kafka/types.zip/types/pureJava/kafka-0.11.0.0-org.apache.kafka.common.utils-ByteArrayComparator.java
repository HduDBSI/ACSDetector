public interface ByteArrayComparator extends Comparator<byte[]>, Serializable {
  int compare(  final byte[] buffer1,  int offset1,  int length1,  final byte[] buffer2,  int offset2,  int length2);
}
