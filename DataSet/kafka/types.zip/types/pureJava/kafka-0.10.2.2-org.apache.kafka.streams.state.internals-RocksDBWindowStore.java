class RocksDBWindowStore<K,V> implements WindowStore<K,V> {
  private final SegmentedBytesStore bytesStore;
  private final boolean retainDuplicates;
  private final Serde<K> keySerde;
  private final Serde<V> valueSerde;
  private ProcessorContext context;
  private int seqnum=0;
  private StateSerdes<K,V> serdes;
  static RocksDBWindowStore<Bytes,byte[]> bytesStore(  final SegmentedBytesStore inner,  final boolean retainDuplicates){
    return new RocksDBWindowStore<>(inner,Serdes.Bytes(),Serdes.ByteArray(),retainDuplicates);
  }
  RocksDBWindowStore(  final SegmentedBytesStore bytesStore,  final Serde<K> keySerde,  final Serde<V> valueSerde,  final boolean retainDuplicates){
    this.keySerde=keySerde;
    this.valueSerde=valueSerde;
    this.retainDuplicates=retainDuplicates;
    this.bytesStore=bytesStore;
  }
  @Override public String name(){
    return bytesStore.name();
  }
  @Override @SuppressWarnings("unchecked") public void init(  final ProcessorContext context,  final StateStore root){
    this.context=context;
    this.serdes=new StateSerdes<>(ProcessorStateManager.storeChangelogTopic(context.applicationId(),bytesStore.name()),keySerde == null ? (Serde<K>)context.keySerde() : keySerde,valueSerde == null ? (Serde<V>)context.valueSerde() : valueSerde);
    bytesStore.init(context,root);
  }
  @Override public boolean persistent(){
    return true;
  }
  @Override public boolean isOpen(){
    return bytesStore.isOpen();
  }
  @Override public void flush(){
    bytesStore.flush();
  }
  @Override public void close(){
    bytesStore.close();
  }
  @Override public void put(  K key,  V value){
    put(key,value,context.timestamp());
  }
  @Override public void put(  K key,  V value,  long timestamp){
    if (retainDuplicates) {
      seqnum=(seqnum + 1) & 0x7FFFFFFF;
    }
    bytesStore.put(Bytes.wrap(WindowStoreUtils.toBinaryKey(key,timestamp,seqnum,serdes)),serdes.rawValue(value));
  }
  @SuppressWarnings("unchecked") @Override public WindowStoreIterator<V> fetch(  K key,  long timeFrom,  long timeTo){
    final KeyValueIterator<Bytes,byte[]> bytesIterator=bytesStore.fetch(Bytes.wrap(serdes.rawKey(key)),timeFrom,timeTo);
    return new TheWindowStoreIterator<>(bytesIterator,serdes);
  }
private static class TheWindowStoreIterator<V> implements WindowStoreIterator<V> {
    private final KeyValueIterator<Bytes,byte[]> actual;
    private final StateSerdes<?,V> serdes;
    TheWindowStoreIterator(    final KeyValueIterator<Bytes,byte[]> actual,    final StateSerdes<?,V> serdes){
      this.actual=actual;
      this.serdes=serdes;
    }
    @Override public boolean hasNext(){
      return actual.hasNext();
    }
    /** 
 * @throws NoSuchElementException if no next element exists
 */
    @Override public KeyValue<Long,V> next(){
      if (!actual.hasNext()) {
        throw new NoSuchElementException();
      }
      final KeyValue<Bytes,byte[]> next=actual.next();
      final long timestamp=WindowStoreUtils.timestampFromBinaryKey(next.key.get());
      final V value=serdes.valueFrom(next.value);
      return KeyValue.pair(timestamp,value);
    }
    @Override public void remove(){
      throw new UnsupportedOperationException();
    }
    @Override public void close(){
      actual.close();
    }
    @Override public Long peekNextKey(){
      if (!actual.hasNext()) {
        throw new NoSuchElementException();
      }
      return WindowStoreUtils.timestampFromBinaryKey(actual.peekNextKey().get());
    }
  }
}
