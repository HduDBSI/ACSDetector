static class StateConsumer {
  private final Consumer<byte[],byte[]> consumer;
  private final GlobalStateMaintainer stateMaintainer;
  private final Time time;
  private final long pollMs;
  private final long flushInterval;
  private long lastFlush;
  StateConsumer(  final Consumer<byte[],byte[]> consumer,  final GlobalStateMaintainer stateMaintainer,  final Time time,  final long pollMs,  final long flushInterval){
    this.consumer=consumer;
    this.stateMaintainer=stateMaintainer;
    this.time=time;
    this.pollMs=pollMs;
    this.flushInterval=flushInterval;
  }
  void initialize(){
    final Map<TopicPartition,Long> partitionOffsets=stateMaintainer.initialize();
    consumer.assign(partitionOffsets.keySet());
    for (    Map.Entry<TopicPartition,Long> entry : partitionOffsets.entrySet()) {
      consumer.seek(entry.getKey(),entry.getValue());
    }
    lastFlush=time.milliseconds();
  }
  void pollAndUpdate(){
    final ConsumerRecords<byte[],byte[]> received=consumer.poll(pollMs);
    for (    ConsumerRecord<byte[],byte[]> record : received) {
      stateMaintainer.update(record);
    }
    final long now=time.milliseconds();
    if (flushInterval >= 0 && now >= lastFlush + flushInterval) {
      stateMaintainer.flushState();
      lastFlush=now;
    }
  }
  public void close() throws IOException {
    try {
      consumer.close();
    }
 catch (    Exception e) {
      log.error("Failed to cleanly close GlobalStreamThread consumer",e);
    }
    stateMaintainer.close();
  }
}
