public class MockPartitioner implements Partitioner {
  public static final AtomicInteger INIT_COUNT=new AtomicInteger(0);
  public static final AtomicInteger CLOSE_COUNT=new AtomicInteger(0);
  public MockPartitioner(){
    INIT_COUNT.incrementAndGet();
  }
  @Override public void configure(  Map<String,?> configs){
  }
  @Override public int partition(  String topic,  Object key,  byte[] keyBytes,  Object value,  byte[] valueBytes,  Cluster cluster){
    return 0;
  }
  @Override public void close(){
    CLOSE_COUNT.incrementAndGet();
  }
  public static void resetCounters(){
    INIT_COUNT.set(0);
    CLOSE_COUNT.set(0);
  }
}
