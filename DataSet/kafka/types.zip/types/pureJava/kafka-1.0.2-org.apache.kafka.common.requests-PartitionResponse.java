public static final class PartitionResponse {
  public Errors error;
  public long baseOffset;
  public long logAppendTime;
  public long logStartOffset;
  public PartitionResponse(  Errors error){
    this(error,INVALID_OFFSET,RecordBatch.NO_TIMESTAMP,INVALID_OFFSET);
  }
  public PartitionResponse(  Errors error,  long baseOffset,  long logAppendTime,  long logStartOffset){
    this.error=error;
    this.baseOffset=baseOffset;
    this.logAppendTime=logAppendTime;
    this.logStartOffset=logStartOffset;
  }
  @Override public String toString(){
    StringBuilder b=new StringBuilder();
    b.append('{');
    b.append("error: ");
    b.append(error);
    b.append(",offset: ");
    b.append(baseOffset);
    b.append(",logAppendTime: ");
    b.append(logAppendTime);
    b.append(", logStartOffset: ");
    b.append(logStartOffset);
    b.append('}');
    return b.toString();
  }
}
