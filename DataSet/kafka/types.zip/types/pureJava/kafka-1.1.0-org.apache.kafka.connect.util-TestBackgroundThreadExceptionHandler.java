/** 
 * An UncaughtExceptionHandler that can be registered with one or more threads which tracks the first exception so the main thread can check for uncaught exceptions.
 */
public class TestBackgroundThreadExceptionHandler implements Thread.UncaughtExceptionHandler {
  private Throwable firstException=null;
  @Override public void uncaughtException(  Thread t,  Throwable e){
    if (this.firstException == null)     this.firstException=e;
  }
  public void verifyNoExceptions(){
    if (this.firstException != null)     throw new AssertionError(this.firstException);
  }
}
