private static class EmptyUrlType implements UrlType {
  private final List<String> endings;
  private EmptyUrlType(  final List<String> endings){
    this.endings=endings;
  }
  @Override public boolean matches(  URL url){
    final String protocol=url.getProtocol();
    final String externalForm=url.toExternalForm();
    if (!protocol.equals(FILE_PROTOCOL)) {
      return false;
    }
    for (    String ending : endings) {
      if (externalForm.endsWith(ending)) {
        return true;
      }
    }
    return false;
  }
  @Override public Dir createDir(  final URL url) throws Exception {
    return emptyVfsDir(url);
  }
  private static Dir emptyVfsDir(  final URL url){
    return new Dir(){
      @Override public String getPath(){
        return url.toExternalForm();
      }
      @Override public Iterable<File> getFiles(){
        return Collections.emptyList();
      }
      @Override public void close(){
      }
    }
;
  }
}
