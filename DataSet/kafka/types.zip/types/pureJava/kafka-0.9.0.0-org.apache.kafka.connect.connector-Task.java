/** 
 * <p> Tasks contain the code that actually copies data to/from another system. They receive a configuration from their parent Connector, assigning them a fraction of a Kafka Connect job's work. The Kafka Connect framework then pushes/pulls data from the Task. The Task must also be able to respond to reconfiguration requests. </p> <p> Task only contains the minimal shared functionality between {@link org.apache.kafka.connect.source.SourceTask} and{@link org.apache.kafka.connect.sink.SinkTask}. </p>
 */
@InterfaceStability.Unstable public interface Task {
  /** 
 * Get the version of this task. Usually this should be the same as the corresponding  {@link Connector} class's version.
 * @return the version, formatted as a String
 */
  String version();
  /** 
 * Start the Task
 * @param props initial configuration
 */
  void start(  Map<String,String> props);
  /** 
 * Stop this task.
 */
  void stop();
}
