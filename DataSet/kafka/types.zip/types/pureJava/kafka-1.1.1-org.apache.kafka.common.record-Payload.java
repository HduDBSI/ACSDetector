static class Payload {
  String name;
  byte[] payload;
  Payload(  String name,  byte[] payload){
    this.name=name;
    this.payload=payload;
  }
  @Override public String toString(){
    return "Payload{" + "size=" + payload.length + ", name='"+ name+ '\''+ '}';
  }
}
