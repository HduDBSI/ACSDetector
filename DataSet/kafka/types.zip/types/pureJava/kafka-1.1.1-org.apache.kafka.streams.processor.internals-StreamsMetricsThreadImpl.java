/** 
 * This class extends  {@link StreamsMetricsImpl(Metrics, String, String, Map)} andoverrides one of its functions for efficiency
 */
static class StreamsMetricsThreadImpl extends StreamsMetricsImpl {
  final Sensor commitTimeSensor;
  final Sensor pollTimeSensor;
  final Sensor processTimeSensor;
  final Sensor punctuateTimeSensor;
  final Sensor taskCreatedSensor;
  final Sensor tasksClosedSensor;
  final Sensor skippedRecordsSensor;
  StreamsMetricsThreadImpl(  final Metrics metrics,  final String groupName,  final String prefix,  final Map<String,String> tags){
    super(metrics,groupName,tags);
    commitTimeSensor=metrics.sensor(prefix + ".commit-latency",Sensor.RecordingLevel.INFO);
    commitTimeSensor.add(metrics.metricName("commit-latency-avg",this.groupName,"The average commit time in ms",this.tags),new Avg());
    commitTimeSensor.add(metrics.metricName("commit-latency-max",this.groupName,"The maximum commit time in ms",this.tags),new Max());
    commitTimeSensor.add(metrics.metricName("commit-rate",this.groupName,"The average per-second number of commit calls",this.tags),new Rate(TimeUnit.SECONDS,new Count()));
    commitTimeSensor.add(metrics.metricName("commit-total",this.groupName,"The total number of commit calls",this.tags),new Count());
    pollTimeSensor=metrics.sensor(prefix + ".poll-latency",Sensor.RecordingLevel.INFO);
    pollTimeSensor.add(metrics.metricName("poll-latency-avg",this.groupName,"The average poll time in ms",this.tags),new Avg());
    pollTimeSensor.add(metrics.metricName("poll-latency-max",this.groupName,"The maximum poll time in ms",this.tags),new Max());
    pollTimeSensor.add(metrics.metricName("poll-rate",this.groupName,"The average per-second number of record-poll calls",this.tags),new Rate(TimeUnit.SECONDS,new Count()));
    pollTimeSensor.add(metrics.metricName("poll-total",this.groupName,"The total number of record-poll calls",this.tags),new Count());
    processTimeSensor=metrics.sensor(prefix + ".process-latency",Sensor.RecordingLevel.INFO);
    processTimeSensor.add(metrics.metricName("process-latency-avg",this.groupName,"The average process time in ms",this.tags),new Avg());
    processTimeSensor.add(metrics.metricName("process-latency-max",this.groupName,"The maximum process time in ms",this.tags),new Max());
    processTimeSensor.add(metrics.metricName("process-rate",this.groupName,"The average per-second number of process calls",this.tags),new Rate(TimeUnit.SECONDS,new Count()));
    processTimeSensor.add(metrics.metricName("process-total",this.groupName,"The total number of process calls",this.tags),new Count());
    punctuateTimeSensor=metrics.sensor(prefix + ".punctuate-latency",Sensor.RecordingLevel.INFO);
    punctuateTimeSensor.add(metrics.metricName("punctuate-latency-avg",this.groupName,"The average punctuate time in ms",this.tags),new Avg());
    punctuateTimeSensor.add(metrics.metricName("punctuate-latency-max",this.groupName,"The maximum punctuate time in ms",this.tags),new Max());
    punctuateTimeSensor.add(metrics.metricName("punctuate-rate",this.groupName,"The average per-second number of punctuate calls",this.tags),new Rate(TimeUnit.SECONDS,new Count()));
    punctuateTimeSensor.add(metrics.metricName("punctuate-total",this.groupName,"The total number of punctuate calls",this.tags),new Count());
    taskCreatedSensor=metrics.sensor(prefix + ".task-created",Sensor.RecordingLevel.INFO);
    taskCreatedSensor.add(metrics.metricName("task-created-rate","stream-metrics","The average per-second number of newly created tasks",this.tags),new Rate(TimeUnit.SECONDS,new Count()));
    taskCreatedSensor.add(metrics.metricName("task-created-total","stream-metrics","The total number of newly created tasks",this.tags),new Total());
    tasksClosedSensor=metrics.sensor(prefix + ".task-closed",Sensor.RecordingLevel.INFO);
    tasksClosedSensor.add(metrics.metricName("task-closed-rate",this.groupName,"The average per-second number of closed tasks",this.tags),new Rate(TimeUnit.SECONDS,new Count()));
    tasksClosedSensor.add(metrics.metricName("task-closed-total",this.groupName,"The total number of closed tasks",this.tags),new Total());
    skippedRecordsSensor=metrics.sensor(prefix + ".skipped-records");
    skippedRecordsSensor.add(metrics.metricName("skipped-records-rate",this.groupName,"The average per-second number of skipped records",this.tags),new Rate(TimeUnit.SECONDS,new Sum()));
    skippedRecordsSensor.add(metrics.metricName("skipped-records-total",this.groupName,"The total number of skipped records",this.tags),new Total());
  }
  void removeAllSensors(){
    removeSensor(commitTimeSensor);
    removeSensor(pollTimeSensor);
    removeSensor(processTimeSensor);
    removeSensor(punctuateTimeSensor);
    removeSensor(taskCreatedSensor);
    removeSensor(tasksClosedSensor);
    removeSensor(skippedRecordsSensor);
  }
}
