public static class TimestampAndOffset {
  public final long timestamp;
  public final long offset;
  public TimestampAndOffset(  long timestamp,  long offset){
    this.timestamp=timestamp;
    this.offset=offset;
  }
  @Override public boolean equals(  Object o){
    if (this == o)     return true;
    if (o == null || getClass() != o.getClass())     return false;
    TimestampAndOffset that=(TimestampAndOffset)o;
    if (timestamp != that.timestamp)     return false;
    return offset == that.offset;
  }
  @Override public int hashCode(){
    int result=(int)(timestamp ^ (timestamp >>> 32));
    result=31 * result + (int)(offset ^ (offset >>> 32));
    return result;
  }
  @Override public String toString(){
    return "TimestampAndOffset(" + "timestamp=" + timestamp + ", offset="+ offset+ ')';
  }
}
