private class ShutdownHook extends Thread {
  @Override public void run(){
    try {
      startLatch.await();
      Connect.this.stop();
    }
 catch (    InterruptedException e) {
      log.error("Interrupted in shutdown hook while waiting for Kafka Connect startup to finish");
    }
  }
}
