public class TransformationChain<R extends ConnectRecord<R>> {
  private final List<Transformation<R>> transformations;
  public TransformationChain(  List<Transformation<R>> transformations){
    this.transformations=transformations;
  }
  public R apply(  R record){
    if (transformations.isEmpty())     return record;
    for (    Transformation<R> transformation : transformations) {
      record=transformation.apply(record);
      if (record == null)       break;
    }
    return record;
  }
  public void close(){
    for (    Transformation<R> transformation : transformations) {
      transformation.close();
    }
  }
  @Override public boolean equals(  Object o){
    if (this == o)     return true;
    if (o == null || getClass() != o.getClass())     return false;
    TransformationChain that=(TransformationChain)o;
    return Objects.equals(transformations,that.transformations);
  }
  @Override public int hashCode(){
    return Objects.hash(transformations);
  }
  public static <R extends ConnectRecord<R>>TransformationChain<R> noOp(){
    return new TransformationChain<R>(Collections.<Transformation<R>>emptyList());
  }
}
