class KStreamWindowReduce<K,V,W extends Window> extends KStreamWindowAggregate<K,V,V,W> {
  KStreamWindowReduce(  final Windows<W> windows,  final String storeName,  final Reducer<V> reducer){
    super(windows,storeName,() -> null,(key,newValue,oldValue) -> oldValue == null ? newValue : reducer.apply(oldValue,newValue));
  }
}
