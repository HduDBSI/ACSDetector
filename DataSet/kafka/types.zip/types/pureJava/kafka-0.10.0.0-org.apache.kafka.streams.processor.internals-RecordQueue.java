/** 
 * RecordQueue is a FIFO queue of  {@link StampedRecord} (ConsumerRecord + timestamp). It also keeps track of thepartition timestamp defined as the minimum timestamp of records in its queue; in addition, its partition timestamp is monotonically increasing such that once it is advanced, it will not be decremented.
 */
public class RecordQueue {
  private final SourceNode source;
  private final TopicPartition partition;
  private final ArrayDeque<StampedRecord> fifoQueue;
  private final TimestampTracker<ConsumerRecord<Object,Object>> timeTracker;
  private long partitionTime=TimestampTracker.NOT_KNOWN;
  public RecordQueue(  TopicPartition partition,  SourceNode source){
    this.partition=partition;
    this.source=source;
    this.fifoQueue=new ArrayDeque<>();
    this.timeTracker=new MinTimestampTracker<>();
  }
  /** 
 * Returns the corresponding source node in the topology
 * @return SourceNode
 */
  public SourceNode source(){
    return source;
  }
  /** 
 * Returns the partition with which this queue is associated
 * @return TopicPartition
 */
  public TopicPartition partition(){
    return partition;
  }
  /** 
 * Add a batch of  {@link ConsumerRecord} into the queue
 * @param rawRecords the raw records
 * @param timestampExtractor TimestampExtractor
 * @return the size of this queue
 */
  public int addRawRecords(  Iterable<ConsumerRecord<byte[],byte[]>> rawRecords,  TimestampExtractor timestampExtractor){
    for (    ConsumerRecord<byte[],byte[]> rawRecord : rawRecords) {
      Object key=source.deserializeKey(rawRecord.topic(),rawRecord.key());
      Object value=source.deserializeValue(rawRecord.topic(),rawRecord.value());
      ConsumerRecord<Object,Object> record=new ConsumerRecord<>(rawRecord.topic(),rawRecord.partition(),rawRecord.offset(),rawRecord.timestamp(),TimestampType.CREATE_TIME,rawRecord.checksum(),rawRecord.serializedKeySize(),rawRecord.serializedValueSize(),key,value);
      long timestamp=timestampExtractor.extract(record);
      StampedRecord stampedRecord=new StampedRecord(record,timestamp);
      fifoQueue.addLast(stampedRecord);
      timeTracker.addElement(stampedRecord);
    }
    long timestamp=timeTracker.get();
    if (timestamp > partitionTime)     partitionTime=timestamp;
    return size();
  }
  /** 
 * Get the next  {@link StampedRecord} from the queue
 * @return StampedRecord
 */
  public StampedRecord poll(){
    StampedRecord elem=fifoQueue.pollFirst();
    if (elem == null)     return null;
    timeTracker.removeElement(elem);
    long timestamp=timeTracker.get();
    if (timestamp > partitionTime)     partitionTime=timestamp;
    return elem;
  }
  /** 
 * Returns the number of records in the queue
 * @return the number of records
 */
  public int size(){
    return fifoQueue.size();
  }
  /** 
 * Tests if the queue is empty
 * @return true if the queue is empty, otherwise false
 */
  public boolean isEmpty(){
    return fifoQueue.isEmpty();
  }
  /** 
 * Returns the tracked partition timestamp
 * @return timestamp
 */
  public long timestamp(){
    return partitionTime;
  }
}
