/** 
 * The windowed key interface used in  {@link KTable}, used for representing a windowed table result from windowed stream aggregations, i.e.  {@link KStream#aggregateByKey(Initializer,Aggregator,Windows,org.apache.kafka.common.serialization.Serde,org.apache.kafka.common.serialization.Serde)}
 * @param < K > Type of the key
 */
public class Windowed<K> {
  private K key;
  private Window window;
  public Windowed(  K key,  Window window){
    this.key=key;
    this.window=window;
  }
  /** 
 * Return the key of the window.
 * @return the key of the window
 */
  public K key(){
    return key;
  }
  /** 
 * Return the window containing the values associated with this key.
 * @return  the window containing the values
 */
  public Window window(){
    return window;
  }
  @Override public String toString(){
    return "[" + key + "@"+ window.start()+ "]";
  }
  @Override public boolean equals(  Object obj){
    if (obj == this)     return true;
    if (!(obj instanceof Windowed))     return false;
    Windowed<?> that=(Windowed)obj;
    return this.window.equals(that.window) && this.key.equals(that.key);
  }
  @Override public int hashCode(){
    long n=((long)window.hashCode() << 32) | key.hashCode();
    return (int)(n % 0xFFFFFFFFL);
  }
}
