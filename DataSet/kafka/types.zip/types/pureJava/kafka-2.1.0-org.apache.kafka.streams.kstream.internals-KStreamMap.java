class KStreamMap<K,V,K1,V1> implements ProcessorSupplier<K,V> {
  private final KeyValueMapper<? super K,? super V,? extends KeyValue<? extends K1,? extends V1>> mapper;
  public KStreamMap(  final KeyValueMapper<? super K,? super V,? extends KeyValue<? extends K1,? extends V1>> mapper){
    this.mapper=mapper;
  }
  @Override public Processor<K,V> get(){
    return new KStreamMapProcessor();
  }
private class KStreamMapProcessor extends AbstractProcessor<K,V> {
    @Override public void process(    final K key,    final V value){
      final KeyValue<? extends K1,? extends V1> newPair=mapper.apply(key,value);
      context().forward(newPair.key,newPair.value);
    }
  }
}
