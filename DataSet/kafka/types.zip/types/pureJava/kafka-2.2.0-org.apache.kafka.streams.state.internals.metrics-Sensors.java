public final class Sensors {
  private Sensors(){
  }
  public static Sensor createTaskAndStoreLatencyAndThroughputSensors(  final Sensor.RecordingLevel level,  final String operation,  final StreamsMetricsImpl metrics,  final String metricsGroup,  final String taskName,  final String storeName,  final Map<String,String> taskTags,  final Map<String,String> storeTags){
    final Sensor taskSensor=metrics.taskLevelSensor(taskName,operation,level);
    addAvgMaxLatency(taskSensor,metricsGroup,taskTags,operation);
    addInvocationRateAndCount(taskSensor,metricsGroup,taskTags,operation);
    final Sensor sensor=metrics.storeLevelSensor(taskName,storeName,operation,level,taskSensor);
    addAvgMaxLatency(sensor,metricsGroup,storeTags,operation);
    addInvocationRateAndCount(sensor,metricsGroup,storeTags,operation);
    return sensor;
  }
  public static Sensor createBufferSizeSensor(  final StateStore store,  final InternalProcessorContext context){
    return getBufferSizeOrCountSensor(store,context,"size");
  }
  public static Sensor createBufferCountSensor(  final StateStore store,  final InternalProcessorContext context){
    return getBufferSizeOrCountSensor(store,context,"count");
  }
  private static Sensor getBufferSizeOrCountSensor(  final StateStore store,  final InternalProcessorContext context,  final String property){
    final StreamsMetricsImpl metrics=context.metrics();
    final String sensorName="suppression-buffer-" + property;
    final Sensor sensor=metrics.storeLevelSensor(context.taskId().toString(),store.name(),sensorName,Sensor.RecordingLevel.DEBUG);
    final String metricsGroup="stream-buffer-metrics";
    final Map<String,String> tags=metrics.tagMap("task-id",context.taskId().toString(),"buffer-id",store.name());
    sensor.add(new MetricName(sensorName + "-current",metricsGroup,"The current " + property + " of buffered records.",tags),new Value());
    sensor.add(new MetricName(sensorName + "-avg",metricsGroup,"The average " + property + " of buffered records.",tags),new Avg());
    sensor.add(new MetricName(sensorName + "-max",metricsGroup,"The max " + property + " of buffered records.",tags),new Max());
    return sensor;
  }
}
