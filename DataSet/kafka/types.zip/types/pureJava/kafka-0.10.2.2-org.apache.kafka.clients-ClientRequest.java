/** 
 * A request being sent to the server. This holds both the network send as well as the client-level metadata.
 */
public final class ClientRequest {
  private final String destination;
  private final AbstractRequest.Builder<?> requestBuilder;
  private final int correlationId;
  private final String clientId;
  private final long createdTimeMs;
  private final boolean expectResponse;
  private final RequestCompletionHandler callback;
  /** 
 * @param destination The brokerId to send the request to
 * @param requestBuilder The builder for the request to make
 * @param correlationId The correlation id for this client request
 * @param clientId The client ID to use for the header
 * @param createdTimeMs The unix timestamp in milliseconds for the time at which this request was created.
 * @param expectResponse Should we expect a response message or is this request complete once it is sent?
 * @param callback A callback to execute when the response has been received (or null if no callback is necessary)
 */
  public ClientRequest(  String destination,  AbstractRequest.Builder<?> requestBuilder,  int correlationId,  String clientId,  long createdTimeMs,  boolean expectResponse,  RequestCompletionHandler callback){
    this.destination=destination;
    this.requestBuilder=requestBuilder;
    this.correlationId=correlationId;
    this.clientId=clientId;
    this.createdTimeMs=createdTimeMs;
    this.expectResponse=expectResponse;
    this.callback=callback;
  }
  @Override public String toString(){
    return "ClientRequest(expectResponse=" + expectResponse + ", callback="+ callback+ ", destination="+ destination+ ", correlationId="+ correlationId+ ", clientId="+ clientId+ ", createdTimeMs="+ createdTimeMs+ ", requestBuilder="+ requestBuilder+ ")";
  }
  public boolean expectResponse(){
    return expectResponse;
  }
  public ApiKeys apiKey(){
    return requestBuilder.apiKey();
  }
  public RequestHeader makeHeader(){
    return new RequestHeader(requestBuilder.apiKey().id,requestBuilder.version(),clientId,correlationId);
  }
  public AbstractRequest.Builder<?> requestBuilder(){
    return requestBuilder;
  }
  public String destination(){
    return destination;
  }
  public RequestCompletionHandler callback(){
    return callback;
  }
  public long createdTimeMs(){
    return createdTimeMs;
  }
  public int correlationId(){
    return correlationId;
  }
}
