public final class TransportLayers {
  private TransportLayers(){
  }
  public static boolean hasPendingWrites(  GatheringByteChannel channel){
    if (channel instanceof TransportLayer)     return ((TransportLayer)channel).hasPendingWrites();
    return false;
  }
}
