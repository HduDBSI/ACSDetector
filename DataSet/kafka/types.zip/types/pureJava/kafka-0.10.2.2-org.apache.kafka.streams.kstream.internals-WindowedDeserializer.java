/** 
 * The inner deserializer class can be specified by setting the property key.deserializer.inner.class, value.deserializer.inner.class or deserializer.inner.class, if the no-arg constructor is called and hence it is not passed during initialization. Note that the first two take precedence over the last.
 */
public class WindowedDeserializer<T> implements Deserializer<Windowed<T>> {
  private static final int TIMESTAMP_SIZE=8;
  private Deserializer<T> inner;
  public WindowedDeserializer(){
  }
  public WindowedDeserializer(  Deserializer<T> inner){
    this.inner=inner;
  }
  @Override public void configure(  Map<String,?> configs,  boolean isKey){
    if (inner == null) {
      String propertyName=isKey ? "key.deserializer.inner.class" : "value.deserializer.inner.class";
      Object innerDeserializerClass=configs.get(propertyName);
      propertyName=(innerDeserializerClass == null) ? "deserializer.inner.class" : propertyName;
      String value=null;
      try {
        value=(String)configs.get(propertyName);
        inner=Deserializer.class.cast(Utils.newInstance(value,Deserializer.class));
        inner.configure(configs,isKey);
      }
 catch (      ClassNotFoundException e) {
        throw new ConfigException(propertyName,value,"Class " + value + " could not be found.");
      }
    }
  }
  @Override public Windowed<T> deserialize(  String topic,  byte[] data){
    byte[] bytes=new byte[data.length - TIMESTAMP_SIZE];
    System.arraycopy(data,0,bytes,0,bytes.length);
    long start=ByteBuffer.wrap(data).getLong(data.length - TIMESTAMP_SIZE);
    return new Windowed<T>(inner.deserialize(topic,bytes),new UnlimitedWindow(start));
  }
  @Override public void close(){
    inner.close();
  }
  public Deserializer<T> innerDeserializer(){
    return inner;
  }
}
