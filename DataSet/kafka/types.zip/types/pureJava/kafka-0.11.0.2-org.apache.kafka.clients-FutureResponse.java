private static class FutureResponse {
  private final Node node;
  private final RequestMatcher requestMatcher;
  private final AbstractResponse responseBody;
  private final boolean disconnected;
  private final boolean isUnsupportedRequest;
  public FutureResponse(  Node node,  RequestMatcher requestMatcher,  AbstractResponse responseBody,  boolean disconnected,  boolean isUnsupportedRequest){
    this.node=node;
    this.requestMatcher=requestMatcher;
    this.responseBody=responseBody;
    this.disconnected=disconnected;
    this.isUnsupportedRequest=isUnsupportedRequest;
  }
}
