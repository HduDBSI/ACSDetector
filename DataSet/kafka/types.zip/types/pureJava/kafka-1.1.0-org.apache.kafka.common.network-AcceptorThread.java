private class AcceptorThread extends Thread {
  public AcceptorThread() throws IOException {
    setName("acceptor");
  }
  public void run(){
    try {
      java.nio.channels.Selector acceptSelector=java.nio.channels.Selector.open();
      serverSocketChannel.register(acceptSelector,SelectionKey.OP_ACCEPT);
      while (serverSocketChannel.isOpen()) {
        if (acceptSelector.select(1000) > 0) {
          Iterator<SelectionKey> it=acceptSelector.selectedKeys().iterator();
          while (it.hasNext()) {
            SelectionKey key=it.next();
            if (key.isAcceptable()) {
              SocketChannel socketChannel=((ServerSocketChannel)key.channel()).accept();
              socketChannel.configureBlocking(false);
              newChannels.add(socketChannel);
              selector.wakeup();
            }
            it.remove();
          }
        }
      }
    }
 catch (    IOException e) {
    }
  }
}
