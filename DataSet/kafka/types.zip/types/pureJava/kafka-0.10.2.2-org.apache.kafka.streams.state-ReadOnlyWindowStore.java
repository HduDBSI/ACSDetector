/** 
 * A window store that only supports read operations Implementations should be thread-safe as concurrent reads and writes are expected.
 * @param < K > Type of keys
 * @param < V > Type of values
 */
@InterfaceStability.Unstable public interface ReadOnlyWindowStore<K,V> {
  /** 
 * Get all the key-value pairs with the given key and the time range from all the existing windows. <p> The time range is inclusive and applies to the starting timestamp of the window. For example, if we have the following windows: <p> <pre> +-------------------------------+ |  key  | start time | end time | +-------+------------+----------+ |   A   |     10     |    20    | +-------+------------+----------+ |   A   |     15     |    25    | +-------+------------+----------+ |   A   |     20     |    30    | +-------+------------+----------+ |   A   |     25     |    35    | +-------------------------------- </pre> And we call  {@code store.fetch("A", 10, 20)} then the results will contain the firstthree windows from the table above, i.e., all those where 10 <= start time <= 20. <p> For each key, the iterator guarantees ordering of windows, starting from the oldest/earliest available window to the newest/latest window.
 * @return an iterator over key-value pairs {@code <timestamp, value>}
 * @throws InvalidStateStoreException if the store is not initialized
 */
  WindowStoreIterator<V> fetch(  K key,  long timeFrom,  long timeTo);
}
