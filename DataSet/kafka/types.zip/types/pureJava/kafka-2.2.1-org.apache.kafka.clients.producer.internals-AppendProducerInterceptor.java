private class AppendProducerInterceptor implements ProducerInterceptor<Integer,String> {
  private String appendStr="";
  private boolean throwExceptionOnSend=false;
  private boolean throwExceptionOnAck=false;
  public AppendProducerInterceptor(  String appendStr){
    this.appendStr=appendStr;
  }
  @Override public void configure(  Map<String,?> configs){
  }
  @Override public ProducerRecord<Integer,String> onSend(  ProducerRecord<Integer,String> record){
    onSendCount++;
    if (throwExceptionOnSend)     throw new KafkaException("Injected exception in AppendProducerInterceptor.onSend");
    return new ProducerRecord<>(record.topic(),record.partition(),record.key(),record.value().concat(appendStr));
  }
  @Override public void onAcknowledgement(  RecordMetadata metadata,  Exception exception){
    onAckCount++;
    if (exception != null) {
      onErrorAckCount++;
      if (metadata != null && metadata.topic().length() >= 0) {
        onErrorAckWithTopicSetCount++;
        if (metadata.partition() >= 0)         onErrorAckWithTopicPartitionSetCount++;
      }
    }
    if (throwExceptionOnAck)     throw new KafkaException("Injected exception in AppendProducerInterceptor.onAcknowledgement");
  }
  @Override public void close(){
  }
  public void injectOnSendError(  boolean on){
    throwExceptionOnSend=on;
  }
  public void injectOnAcknowledgementError(  boolean on){
    throwExceptionOnAck=on;
  }
}
