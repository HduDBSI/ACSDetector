private static class TestCloseable implements Closeable {
  private final int id;
  private final IOException closeException;
  private boolean closed;
  TestCloseable(  int id,  boolean exceptionOnClose){
    this.id=id;
    this.closeException=exceptionOnClose ? new IOException("Test close exception " + id) : null;
  }
  @Override public void close() throws IOException {
    closed=true;
    if (closeException != null)     throw closeException;
  }
  static TestCloseable[] createCloseables(  boolean... exceptionOnClose){
    TestCloseable[] closeables=new TestCloseable[exceptionOnClose.length];
    for (int i=0; i < closeables.length; i++)     closeables[i]=new TestCloseable(i,exceptionOnClose[i]);
    return closeables;
  }
  static void checkClosed(  TestCloseable... closeables){
    for (    TestCloseable closeable : closeables)     assertTrue("Close not invoked for " + closeable.id,closeable.closed);
  }
  static void checkException(  IOException e,  TestCloseable... closeablesWithException){
    assertEquals(closeablesWithException[0].closeException,e);
    Throwable[] suppressed=e.getSuppressed();
    assertEquals(closeablesWithException.length - 1,suppressed.length);
    for (int i=1; i < closeablesWithException.length; i++)     assertEquals(closeablesWithException[i].closeException,suppressed[i - 1]);
  }
}
