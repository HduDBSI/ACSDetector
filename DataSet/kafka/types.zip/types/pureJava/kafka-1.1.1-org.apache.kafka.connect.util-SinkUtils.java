public final class SinkUtils {
  private SinkUtils(){
  }
  public static String consumerGroupId(  String connector){
    return "connect-" + connector;
  }
}
