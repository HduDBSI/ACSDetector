public class RecordCollector {
  /** 
 * A supplier of a  {@link RecordCollector} instance.
 */
public interface Supplier {
    /** 
 * Get the record collector.
 * @return the record collector
 */
    RecordCollector recordCollector();
  }
  private static final Logger log=LoggerFactory.getLogger(RecordCollector.class);
  private final Producer<byte[],byte[]> producer;
  private final Map<TopicPartition,Long> offsets;
  private final Callback callback=new Callback(){
    @Override public void onCompletion(    RecordMetadata metadata,    Exception exception){
      if (exception == null) {
        TopicPartition tp=new TopicPartition(metadata.topic(),metadata.partition());
        offsets.put(tp,metadata.offset());
      }
 else {
        log.error("Error sending record: " + metadata,exception);
      }
    }
  }
;
  public RecordCollector(  Producer<byte[],byte[]> producer){
    this.producer=producer;
    this.offsets=new HashMap<>();
  }
  public <K,V>void send(  ProducerRecord<K,V> record,  Serializer<K> keySerializer,  Serializer<V> valueSerializer){
    send(record,keySerializer,valueSerializer,null);
  }
  public <K,V>void send(  ProducerRecord<K,V> record,  Serializer<K> keySerializer,  Serializer<V> valueSerializer,  StreamPartitioner<K,V> partitioner){
    byte[] keyBytes=keySerializer.serialize(record.topic(),record.key());
    byte[] valBytes=valueSerializer.serialize(record.topic(),record.value());
    Integer partition=record.partition();
    if (partition == null && partitioner != null) {
      List<PartitionInfo> partitions=this.producer.partitionsFor(record.topic());
      if (partitions != null)       partition=partitioner.partition(record.key(),record.value(),partitions.size());
    }
    this.producer.send(new ProducerRecord<>(record.topic(),partition,keyBytes,valBytes),callback);
  }
  public void flush(){
    this.producer.flush();
  }
  /** 
 * Closes this RecordCollector
 */
  public void close(){
    producer.close();
  }
  /** 
 * The last ack'd offset from the producer
 * @return the map from TopicPartition to offset
 */
  Map<TopicPartition,Long> offsets(){
    return this.offsets;
  }
}
