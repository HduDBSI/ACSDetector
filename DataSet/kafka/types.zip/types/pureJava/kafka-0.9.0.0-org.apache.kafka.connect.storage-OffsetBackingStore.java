/** 
 * <p> OffsetBackingStore is an interface for storage backends that store key-value data. The backing store doesn't need to handle serialization or deserialization. It only needs to support reading/writing bytes. Since it is expected these operations will require network operations, only bulk operations are supported. </p> <p> Since OffsetBackingStore is a shared resource that may be used by many OffsetStorage instances that are associated with individual tasks, the caller must be sure keys include information about the connector so that the shared namespace does not result in conflicting keys. </p>
 */
public interface OffsetBackingStore extends Configurable {
  /** 
 * Start this offset store.
 */
  public void start();
  /** 
 * Stop the backing store. Implementations should attempt to shutdown gracefully, but not block indefinitely.
 */
  public void stop();
  /** 
 * Get the values for the specified keys
 * @param keys list of keys to look up
 * @param callback callback to invoke on completion
 * @return future for the resulting map from key to value
 */
  public Future<Map<ByteBuffer,ByteBuffer>> get(  Collection<ByteBuffer> keys,  Callback<Map<ByteBuffer,ByteBuffer>> callback);
  /** 
 * Set the specified keys and values.
 * @param values map from key to value
 * @param callback callback to invoke on completion
 * @return void future for the operation
 */
  public Future<Void> set(  Map<ByteBuffer,ByteBuffer> values,  Callback<Void> callback);
}
