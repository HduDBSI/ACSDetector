class RestrictedClassLoader extends ClassLoader {
  public RestrictedClassLoader(){
    super(null);
  }
  @Override protected Class<?> findClass(  String name) throws ClassNotFoundException {
    if (name.equals(ClassTestConfig.DEFAULT_CLASS.getName()) || name.equals(ClassTestConfig.RESTRICTED_CLASS.getName()))     return null;
 else     return ClassTestConfig.class.getClassLoader().loadClass(name);
  }
}
