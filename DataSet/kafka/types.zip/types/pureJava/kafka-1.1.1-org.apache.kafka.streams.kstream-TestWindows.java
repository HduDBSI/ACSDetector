private class TestWindows extends Windows {
  @Override public Map windowsFor(  long timestamp){
    return null;
  }
  @Override public long size(){
    return 0;
  }
}
