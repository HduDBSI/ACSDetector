public class ByteArraySerializer implements Serializer<byte[]> {
  @Override public void configure(  Map<String,?> configs,  boolean isKey){
  }
  @Override public byte[] serialize(  String topic,  byte[] data){
    return data;
  }
  @Override public void close(){
  }
}
