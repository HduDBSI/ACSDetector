/** 
 * An abstract implementation of  {@link Processor} that manages the {@link ProcessorContext} instance and provides default no-opimplementation of  {@link #close()}.
 * @param < K > the type of keys
 * @param < V > the type of values
 */
public abstract class AbstractProcessor<K,V> implements Processor<K,V> {
  private ProcessorContext context;
  protected AbstractProcessor(){
  }
  @Override public void init(  final ProcessorContext context){
    this.context=context;
  }
  /** 
 * Close this processor and clean up any resources. <p> This method does nothing by default; if desired, subclasses should override it with custom functionality. </p>
 */
  @Override public void close(){
  }
  /** 
 * Get the processor's context set during  {@link #init(ProcessorContext) initialization}.
 * @return the processor context; null only when called prior to {@link #init(ProcessorContext) initialization}.
 */
  protected final ProcessorContext context(){
    return context;
  }
}
