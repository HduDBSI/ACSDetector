@RunWith(PowerMockRunner.class) @PrepareForTest({AbstractHerder.class}) public class AbstractHerderTest {
  private final String workerId="workerId";
  private final String kafkaClusterId="I4ZmrWqfT2e-upky_4fdPA";
  private final int generation=5;
  private final String connector="connector";
  @MockStrict private Worker worker;
  @MockStrict private Plugins plugins;
  @MockStrict private ClassLoader classLoader;
  @MockStrict private ConfigBackingStore configStore;
  @MockStrict private StatusBackingStore statusStore;
  @Test public void connectorStatus(){
    ConnectorTaskId taskId=new ConnectorTaskId(connector,0);
    AbstractHerder herder=partialMockBuilder(AbstractHerder.class).withConstructor(Worker.class,String.class,String.class,StatusBackingStore.class,ConfigBackingStore.class).withArgs(worker,workerId,kafkaClusterId,statusStore,configStore).addMockedMethod("generation").createMock();
    EasyMock.expect(herder.generation()).andStubReturn(generation);
    EasyMock.expect(herder.config(connector)).andReturn(null);
    EasyMock.expect(statusStore.get(connector)).andReturn(new ConnectorStatus(connector,AbstractStatus.State.RUNNING,workerId,generation));
    EasyMock.expect(statusStore.getAll(connector)).andReturn(Collections.singletonList(new TaskStatus(taskId,AbstractStatus.State.UNASSIGNED,workerId,generation)));
    EasyMock.expect(worker.getPlugins()).andStubReturn(plugins);
    replayAll();
    ConnectorStateInfo state=herder.connectorStatus(connector);
    assertEquals(connector,state.name());
    assertEquals("RUNNING",state.connector().state());
    assertEquals(1,state.tasks().size());
    assertEquals(workerId,state.connector().workerId());
    ConnectorStateInfo.TaskState taskState=state.tasks().get(0);
    assertEquals(0,taskState.id());
    assertEquals("UNASSIGNED",taskState.state());
    assertEquals(workerId,taskState.workerId());
    PowerMock.verifyAll();
  }
  @Test public void taskStatus(){
    ConnectorTaskId taskId=new ConnectorTaskId("connector",0);
    String workerId="workerId";
    AbstractHerder herder=partialMockBuilder(AbstractHerder.class).withConstructor(Worker.class,String.class,String.class,StatusBackingStore.class,ConfigBackingStore.class).withArgs(worker,workerId,kafkaClusterId,statusStore,configStore).addMockedMethod("generation").createMock();
    EasyMock.expect(herder.generation()).andStubReturn(5);
    final Capture<TaskStatus> statusCapture=EasyMock.newCapture();
    statusStore.putSafe(EasyMock.capture(statusCapture));
    EasyMock.expectLastCall();
    EasyMock.expect(statusStore.get(taskId)).andAnswer(new IAnswer<TaskStatus>(){
      @Override public TaskStatus answer() throws Throwable {
        return statusCapture.getValue();
      }
    }
);
    replayAll();
    herder.onFailure(taskId,new RuntimeException());
    ConnectorStateInfo.TaskState taskState=herder.taskStatus(taskId);
    assertEquals(workerId,taskState.workerId());
    assertEquals("FAILED",taskState.state());
    assertEquals(0,taskState.id());
    assertNotNull(taskState.trace());
    verifyAll();
  }
  @Test(expected=BadRequestException.class) public void testConfigValidationEmptyConfig(){
    AbstractHerder herder=createConfigValidationHerder(TestSourceConnector.class);
    replayAll();
    herder.validateConnectorConfig(new HashMap<String,String>());
    verifyAll();
  }
  @Test() public void testConfigValidationMissingName(){
    AbstractHerder herder=createConfigValidationHerder(TestSourceConnector.class);
    replayAll();
    Map<String,String> config=Collections.singletonMap(ConnectorConfig.CONNECTOR_CLASS_CONFIG,TestSourceConnector.class.getName());
    ConfigInfos result=herder.validateConnectorConfig(config);
    assertEquals(TestSourceConnector.class.getName(),result.name());
    assertEquals(Arrays.asList(ConnectorConfig.COMMON_GROUP,ConnectorConfig.TRANSFORMS_GROUP),result.groups());
    assertEquals(2,result.errorCount());
    assertEquals(9,result.values().size());
    assertEquals(ConnectorConfig.NAME_CONFIG,result.values().get(0).configValue().name());
    assertEquals(1,result.values().get(0).configValue().errors().size());
    assertEquals("required",result.values().get(7).configValue().name());
    assertEquals(1,result.values().get(7).configValue().errors().size());
    verifyAll();
  }
  @Test(expected=ConfigException.class) public void testConfigValidationInvalidTopics(){
    AbstractHerder herder=createConfigValidationHerder(TestSinkConnector.class);
    replayAll();
    Map<String,String> config=new HashMap();
    config.put(ConnectorConfig.CONNECTOR_CLASS_CONFIG,TestSinkConnector.class.getName());
    config.put(SinkConnectorConfig.TOPICS_CONFIG,"topic1,topic2");
    config.put(SinkConnectorConfig.TOPICS_REGEX_CONFIG,"topic.*");
    herder.validateConnectorConfig(config);
    verifyAll();
  }
  @Test() public void testConfigValidationTransformsExtendResults(){
    AbstractHerder herder=createConfigValidationHerder(TestSourceConnector.class);
    Set<PluginDesc<Transformation>> transformations=new HashSet<>();
    transformations.add(new PluginDesc<Transformation>(SampleTransformation.class,"1.0",classLoader));
    EasyMock.expect(plugins.transformations()).andReturn(transformations).times(2);
    replayAll();
    Map<String,String> config=new HashMap<>();
    config.put(ConnectorConfig.CONNECTOR_CLASS_CONFIG,TestSourceConnector.class.getName());
    config.put(ConnectorConfig.NAME_CONFIG,"connector-name");
    config.put(ConnectorConfig.TRANSFORMS_CONFIG,"xformA,xformB");
    config.put(ConnectorConfig.TRANSFORMS_CONFIG + ".xformA.type",SampleTransformation.class.getName());
    config.put("required","value");
    ConfigInfos result=herder.validateConnectorConfig(config);
    assertEquals(herder.connectorTypeForClass(config.get(ConnectorConfig.CONNECTOR_CLASS_CONFIG)),ConnectorType.SOURCE);
    assertEquals(TestSourceConnector.class.getName(),result.name());
    List<String> expectedGroups=Arrays.asList(ConnectorConfig.COMMON_GROUP,ConnectorConfig.TRANSFORMS_GROUP,"Transforms: xformA","Transforms: xformB");
    assertEquals(expectedGroups,result.groups());
    assertEquals(2,result.errorCount());
    assertEquals(12,result.values().size());
    assertEquals("transforms.xformA.type",result.values().get(7).configValue().name());
    assertTrue(result.values().get(7).configValue().errors().isEmpty());
    assertEquals("transforms.xformA.subconfig",result.values().get(8).configValue().name());
    assertEquals("transforms.xformB.type",result.values().get(9).configValue().name());
    assertFalse(result.values().get(9).configValue().errors().isEmpty());
    verifyAll();
  }
  private AbstractHerder createConfigValidationHerder(  Class<? extends Connector> connectorClass){
    ConfigBackingStore configStore=strictMock(ConfigBackingStore.class);
    StatusBackingStore statusStore=strictMock(StatusBackingStore.class);
    AbstractHerder herder=partialMockBuilder(AbstractHerder.class).withConstructor(Worker.class,String.class,String.class,StatusBackingStore.class,ConfigBackingStore.class).withArgs(worker,workerId,kafkaClusterId,statusStore,configStore).addMockedMethod("generation").createMock();
    EasyMock.expect(herder.generation()).andStubReturn(generation);
    EasyMock.expect(worker.getPlugins()).andStubReturn(plugins);
    final Connector connector;
    try {
      connector=connectorClass.newInstance();
    }
 catch (    InstantiationException|IllegalAccessException e) {
      throw new RuntimeException("Couldn't create connector",e);
    }
    EasyMock.expect(plugins.newConnector(connectorClass.getName())).andReturn(connector);
    EasyMock.expect(plugins.compareAndSwapLoaders(connector)).andReturn(classLoader);
    return herder;
  }
public static class SampleTransformation<R extends ConnectRecord<R>> implements Transformation<R> {
    @Override public void configure(    Map<String,?> configs){
    }
    @Override public R apply(    R record){
      return record;
    }
    @Override public ConfigDef config(){
      return new ConfigDef().define("subconfig",ConfigDef.Type.STRING,"default",ConfigDef.Importance.LOW,"docs");
    }
    @Override public void close(){
    }
  }
}
