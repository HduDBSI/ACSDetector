/** 
 * Test consumer interceptor that filters records in onConsume() intercept
 */
private class FilterConsumerInterceptor<K,V> implements ConsumerInterceptor<K,V> {
  private int filterPartition;
  private boolean throwExceptionOnConsume=false;
  private boolean throwExceptionOnCommit=false;
  FilterConsumerInterceptor(  int filterPartition){
    this.filterPartition=filterPartition;
  }
  @Override public void configure(  Map<String,?> configs){
  }
  @Override public ConsumerRecords<K,V> onConsume(  ConsumerRecords<K,V> records){
    onConsumeCount++;
    if (throwExceptionOnConsume)     throw new KafkaException("Injected exception in FilterConsumerInterceptor.onConsume.");
    Map<TopicPartition,List<ConsumerRecord<K,V>>> recordMap=new HashMap<>();
    for (    TopicPartition tp : records.partitions()) {
      if (tp.partition() != filterPartition)       recordMap.put(tp,records.records(tp));
    }
    return new ConsumerRecords<K,V>(recordMap);
  }
  @Override public void onCommit(  Map<TopicPartition,OffsetAndMetadata> offsets){
    onCommitCount++;
    if (throwExceptionOnCommit)     throw new KafkaException("Injected exception in FilterConsumerInterceptor.onCommit.");
  }
  @Override public void close(){
  }
  public void injectOnConsumeError(  boolean on){
    throwExceptionOnConsume=on;
  }
  public void injectOnCommitError(  boolean on){
    throwExceptionOnCommit=on;
  }
}
