private class OffsetCommitResponseHandler extends CoordinatorResponseHandler<OffsetCommitResponse,Void> {
  private final Map<TopicPartition,OffsetAndMetadata> offsets;
  private OffsetCommitResponseHandler(  Map<TopicPartition,OffsetAndMetadata> offsets){
    this.offsets=offsets;
  }
  @Override public void handle(  OffsetCommitResponse commitResponse,  RequestFuture<Void> future){
    sensors.commitLatency.record(response.requestLatencyMs());
    Set<String> unauthorizedTopics=new HashSet<>();
    for (    Map.Entry<TopicPartition,Errors> entry : commitResponse.responseData().entrySet()) {
      TopicPartition tp=entry.getKey();
      OffsetAndMetadata offsetAndMetadata=this.offsets.get(tp);
      long offset=offsetAndMetadata.offset();
      Errors error=entry.getValue();
      if (error == Errors.NONE) {
        log.debug("Committed offset {} for partition {}",offset,tp);
      }
 else {
        log.error("Offset commit failed on partition {} at offset {}: {}",tp,offset,error.message());
        if (error == Errors.GROUP_AUTHORIZATION_FAILED) {
          future.raise(new GroupAuthorizationException(groupId));
          return;
        }
 else         if (error == Errors.TOPIC_AUTHORIZATION_FAILED) {
          unauthorizedTopics.add(tp.topic());
        }
 else         if (error == Errors.OFFSET_METADATA_TOO_LARGE || error == Errors.INVALID_COMMIT_OFFSET_SIZE) {
          future.raise(error);
          return;
        }
 else         if (error == Errors.COORDINATOR_LOAD_IN_PROGRESS) {
          future.raise(error);
          return;
        }
 else         if (error == Errors.COORDINATOR_NOT_AVAILABLE || error == Errors.NOT_COORDINATOR || error == Errors.REQUEST_TIMED_OUT) {
          markCoordinatorUnknown();
          future.raise(error);
          return;
        }
 else         if (error == Errors.UNKNOWN_MEMBER_ID || error == Errors.ILLEGAL_GENERATION || error == Errors.REBALANCE_IN_PROGRESS) {
          resetGeneration();
          future.raise(new CommitFailedException());
          return;
        }
 else         if (error == Errors.UNKNOWN_TOPIC_OR_PARTITION) {
          future.raise(new KafkaException("Topic or Partition " + tp + " does not exist"));
          return;
        }
 else {
          future.raise(new KafkaException("Unexpected error in commit: " + error.message()));
          return;
        }
      }
    }
    if (!unauthorizedTopics.isEmpty()) {
      log.error("Not authorized to commit to topics {}",unauthorizedTopics);
      future.raise(new TopicAuthorizationException(unauthorizedTopics));
    }
 else {
      future.complete(null);
    }
  }
}
