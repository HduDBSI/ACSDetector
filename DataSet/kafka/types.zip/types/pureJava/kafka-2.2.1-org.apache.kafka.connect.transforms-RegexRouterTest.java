public class RegexRouterTest {
  private static String apply(  String regex,  String replacement,  String topic){
    final Map<String,String> props=new HashMap<>();
    props.put("regex",regex);
    props.put("replacement",replacement);
    final RegexRouter<SinkRecord> router=new RegexRouter<>();
    router.configure(props);
    String sinkTopic=router.apply(new SinkRecord(topic,0,null,null,null,null,0)).topic();
    router.close();
    return sinkTopic;
  }
  @Test public void staticReplacement(){
    assertEquals("bar",apply("foo","bar","foo"));
  }
  @Test public void doesntMatch(){
    assertEquals("orig",apply("foo","bar","orig"));
  }
  @Test public void identity(){
    assertEquals("orig",apply("(.*)","$1","orig"));
  }
  @Test public void addPrefix(){
    assertEquals("prefix-orig",apply("(.*)","prefix-$1","orig"));
  }
  @Test public void addSuffix(){
    assertEquals("orig-suffix",apply("(.*)","$1-suffix","orig"));
  }
  @Test public void slice(){
    assertEquals("index",apply("(.*)-(\\d\\d\\d\\d\\d\\d\\d\\d)","$1","index-20160117"));
  }
}
