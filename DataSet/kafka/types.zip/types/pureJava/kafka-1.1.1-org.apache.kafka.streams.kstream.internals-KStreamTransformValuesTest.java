public class KStreamTransformValuesTest {
  private String topicName="topic";
  final private Serde<Integer> intSerde=Serdes.Integer();
  @Rule public final KStreamTestDriver driver=new KStreamTestDriver();
  @Test public void testTransform(){
    StreamsBuilder builder=new StreamsBuilder();
    ValueTransformerSupplier<Number,Integer> valueTransformerSupplier=new ValueTransformerSupplier<Number,Integer>(){
      public ValueTransformer<Number,Integer> get(){
        return new ValueTransformer<Number,Integer>(){
          private int total=0;
          @Override public void init(          ProcessorContext context){
          }
          @Override public Integer transform(          Number value){
            total+=value.intValue();
            return total;
          }
          @Override public Integer punctuate(          long timestamp){
            return null;
          }
          @Override public void close(){
          }
        }
;
      }
    }
;
    final int[] expectedKeys={1,10,100,1000};
    KStream<Integer,Integer> stream;
    MockProcessorSupplier<Integer,Integer> processor=new MockProcessorSupplier<>();
    stream=builder.stream(topicName,Consumed.with(intSerde,intSerde));
    stream.transformValues(valueTransformerSupplier).process(processor);
    driver.setUp(builder);
    for (    int expectedKey : expectedKeys) {
      driver.process(topicName,expectedKey,expectedKey * 10);
    }
    String[] expected={"1:10","10:110","100:1110","1000:11110"};
    assertArrayEquals(expected,processor.processed.toArray());
  }
  @Test public void testTransformWithKey(){
    StreamsBuilder builder=new StreamsBuilder();
    ValueTransformerWithKeySupplier<Integer,Number,Integer> valueTransformerSupplier=new ValueTransformerWithKeySupplier<Integer,Number,Integer>(){
      public ValueTransformerWithKey<Integer,Number,Integer> get(){
        return new ValueTransformerWithKey<Integer,Number,Integer>(){
          private int total=0;
          @Override public void init(          final ProcessorContext context){
          }
          @Override public Integer transform(          final Integer readOnlyKey,          final Number value){
            total+=value.intValue() + readOnlyKey;
            return total;
          }
          @Override public void close(){
          }
        }
;
      }
    }
;
    final int[] expectedKeys={1,10,100,1000};
    KStream<Integer,Integer> stream;
    MockProcessorSupplier<Integer,Integer> processor=new MockProcessorSupplier<>();
    stream=builder.stream(topicName,Consumed.with(intSerde,intSerde));
    stream.transformValues(valueTransformerSupplier).process(processor);
    driver.setUp(builder);
    for (    int expectedKey : expectedKeys) {
      driver.process(topicName,expectedKey,expectedKey * 10);
    }
    String[] expected={"1:11","10:121","100:1221","1000:12221"};
    assertArrayEquals(expected,processor.processed.toArray());
  }
  @Test public void shouldNotAllowValueTransformerToCallInternalProcessorContextMethods(){
    final BadValueTransformer badValueTransformer=new BadValueTransformer();
    final KStreamTransformValues<Integer,Integer,Integer> transformValue=new KStreamTransformValues<>(new InternalValueTransformerWithKeySupplier<Integer,Integer,Integer>(){
      @Override public InternalValueTransformerWithKey<Integer,Integer,Integer> get(){
        return new InternalValueTransformerWithKey<Integer,Integer,Integer>(){
          @Override public Integer punctuate(          long timestamp){
            throw new StreamsException("ValueTransformerWithKey#punctuate should not be called.");
          }
          @Override public void init(          final ProcessorContext context){
            badValueTransformer.init(context);
          }
          @Override public Integer transform(          final Integer readOnlyKey,          final Integer value){
            return badValueTransformer.transform(readOnlyKey,value);
          }
          @Override public void close(){
            badValueTransformer.close();
          }
        }
;
      }
    }
);
    final Processor transformValueProcessor=transformValue.get();
    transformValueProcessor.init(null);
    try {
      transformValueProcessor.process(null,0);
      fail("should not allow call to context.forward() within ValueTransformer");
    }
 catch (    final StreamsException e) {
    }
    try {
      transformValueProcessor.process(null,1);
      fail("should not allow call to context.forward() within ValueTransformer");
    }
 catch (    final StreamsException e) {
    }
    try {
      transformValueProcessor.process(null,2);
      fail("should not allow call to context.forward() within ValueTransformer");
    }
 catch (    final StreamsException e) {
    }
    try {
      transformValueProcessor.punctuate(0);
      fail("should not allow ValueTransformer#puntuate() to return not-null value");
    }
 catch (    final StreamsException e) {
    }
  }
private static final class BadValueTransformer implements ValueTransformerWithKey<Integer,Integer,Integer> {
    private ProcessorContext context;
    @Override public void init(    final ProcessorContext context){
      this.context=context;
    }
    @Override public Integer transform(    final Integer key,    final Integer value){
      if (value == 0) {
        context.forward(null,null);
      }
      if (value == 1) {
        context.forward(null,null,null);
      }
      if (value == 2) {
        context.forward(null,null,0);
      }
      throw new RuntimeException("Should never happen in this test");
    }
    @Override public void close(){
    }
  }
}
