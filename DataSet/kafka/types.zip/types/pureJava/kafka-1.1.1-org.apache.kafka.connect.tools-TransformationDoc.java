public class TransformationDoc {
private static final class DocInfo {
    final String transformationName;
    final String overview;
    final ConfigDef configDef;
    private DocInfo(    String transformationName,    String overview,    ConfigDef configDef){
      this.transformationName=transformationName;
      this.overview=overview;
      this.configDef=configDef;
    }
  }
  private static final List<DocInfo> TRANSFORMATIONS=Arrays.asList(new DocInfo(InsertField.class.getName(),InsertField.OVERVIEW_DOC,InsertField.CONFIG_DEF),new DocInfo(ReplaceField.class.getName(),ReplaceField.OVERVIEW_DOC,ReplaceField.CONFIG_DEF),new DocInfo(MaskField.class.getName(),MaskField.OVERVIEW_DOC,MaskField.CONFIG_DEF),new DocInfo(ValueToKey.class.getName(),ValueToKey.OVERVIEW_DOC,ValueToKey.CONFIG_DEF),new DocInfo(HoistField.class.getName(),HoistField.OVERVIEW_DOC,HoistField.CONFIG_DEF),new DocInfo(ExtractField.class.getName(),ExtractField.OVERVIEW_DOC,ExtractField.CONFIG_DEF),new DocInfo(SetSchemaMetadata.class.getName(),SetSchemaMetadata.OVERVIEW_DOC,SetSchemaMetadata.CONFIG_DEF),new DocInfo(TimestampRouter.class.getName(),TimestampRouter.OVERVIEW_DOC,TimestampRouter.CONFIG_DEF),new DocInfo(RegexRouter.class.getName(),RegexRouter.OVERVIEW_DOC,RegexRouter.CONFIG_DEF),new DocInfo(Flatten.class.getName(),Flatten.OVERVIEW_DOC,Flatten.CONFIG_DEF),new DocInfo(Cast.class.getName(),Cast.OVERVIEW_DOC,Cast.CONFIG_DEF),new DocInfo(TimestampConverter.class.getName(),TimestampConverter.OVERVIEW_DOC,TimestampConverter.CONFIG_DEF));
  private static void printTransformationHtml(  PrintStream out,  DocInfo docInfo){
    out.println("<div id=\"" + docInfo.transformationName + "\">");
    out.print("<h5>");
    out.print(docInfo.transformationName);
    out.println("</h5>");
    out.println(docInfo.overview);
    out.println("<p/>");
    out.println(docInfo.configDef.toHtmlTable());
    out.println("</div>");
  }
  private static void printHtml(  PrintStream out) throws NoSuchFieldException, IllegalAccessException, InstantiationException {
    for (    final DocInfo docInfo : TRANSFORMATIONS) {
      printTransformationHtml(out,docInfo);
    }
  }
  public static void main(  String... args) throws Exception {
    printHtml(System.out);
  }
}
