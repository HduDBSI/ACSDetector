/** 
 * A set of composite sends, sent one after another
 */
public class MultiSend implements Send {
  private static final Logger log=LoggerFactory.getLogger(MultiSend.class);
  private final String dest;
  private final Queue<Send> sendQueue;
  private final long size;
  private long totalWritten=0;
  private Send current;
  /** 
 * Construct a MultiSend for the given destination from a queue of Send objects. The queue will be consumed as the MultiSend progresses (on completion, it will be empty).
 */
  public MultiSend(  String dest,  Queue<Send> sends){
    this.dest=dest;
    this.sendQueue=sends;
    long size=0;
    for (    Send send : sends)     size+=send.size();
    this.size=size;
    this.current=sendQueue.poll();
  }
  @Override public long size(){
    return size;
  }
  @Override public String destination(){
    return dest;
  }
  @Override public boolean completed(){
    return current == null;
  }
  int numResidentSends(){
    int count=0;
    if (current != null)     count+=1;
    count+=sendQueue.size();
    return count;
  }
  @Override public long writeTo(  GatheringByteChannel channel) throws IOException {
    if (completed())     throw new KafkaException("This operation cannot be invoked on a complete request.");
    int totalWrittenPerCall=0;
    boolean sendComplete;
    do {
      long written=current.writeTo(channel);
      totalWrittenPerCall+=written;
      sendComplete=current.completed();
      if (sendComplete)       current=sendQueue.poll();
    }
 while (!completed() && sendComplete);
    totalWritten+=totalWrittenPerCall;
    if (completed() && totalWritten != size)     log.error("mismatch in sending bytes over socket; expected: " + size + " actual: "+ totalWritten);
    log.trace("Bytes written as part of multi-send call: {}, total bytes written so far: {}, expected bytes to write: {}",totalWrittenPerCall,totalWritten,size);
    return totalWrittenPerCall;
  }
}
