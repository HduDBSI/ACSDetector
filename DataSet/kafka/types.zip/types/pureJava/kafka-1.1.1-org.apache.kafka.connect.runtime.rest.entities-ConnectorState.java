public static class ConnectorState extends AbstractState {
  public ConnectorState(  String state,  String worker,  String msg){
    super(state,worker,msg);
  }
}
