public class KStreamFlatMapValuesTest {
  private String topicName="topic";
  @Rule public final KStreamTestDriver driver=new KStreamTestDriver();
  @Test public void testFlatMapValues(){
    StreamsBuilder builder=new StreamsBuilder();
    ValueMapper<Number,Iterable<String>> mapper=new ValueMapper<Number,Iterable<String>>(){
      @Override public Iterable<String> apply(      Number value){
        ArrayList<String> result=new ArrayList<String>();
        result.add("v" + value);
        result.add("V" + value);
        return result;
      }
    }
;
    final int[] expectedKeys={0,1,2,3};
    final KStream<Integer,Integer> stream=builder.stream(topicName,Consumed.with(Serdes.Integer(),Serdes.Integer()));
    final MockProcessorSupplier<Integer,String> processor=new MockProcessorSupplier<>();
    stream.flatMapValues(mapper).process(processor);
    driver.setUp(builder);
    for (    final int expectedKey : expectedKeys) {
      driver.process(topicName,expectedKey,expectedKey);
    }
    String[] expected={"0:v0","0:V0","1:v1","1:V1","2:v2","2:V2","3:v3","3:V3"};
    assertArrayEquals(expected,processor.processed.toArray());
  }
  @Test public void testFlatMapValuesWithKeys(){
    StreamsBuilder builder=new StreamsBuilder();
    ValueMapperWithKey<Integer,Number,Iterable<String>> mapper=new ValueMapperWithKey<Integer,Number,Iterable<String>>(){
      @Override public Iterable<String> apply(      final Integer readOnlyKey,      final Number value){
        ArrayList<String> result=new ArrayList<>();
        result.add("v" + value);
        result.add("k" + readOnlyKey);
        return result;
      }
    }
;
    final int[] expectedKeys={0,1,2,3};
    final KStream<Integer,Integer> stream=builder.stream(topicName,Consumed.with(Serdes.Integer(),Serdes.Integer()));
    final MockProcessorSupplier<Integer,String> processor=new MockProcessorSupplier<>();
    stream.flatMapValues(mapper).process(processor);
    driver.setUp(builder);
    for (    final int expectedKey : expectedKeys) {
      driver.process(topicName,expectedKey,expectedKey);
    }
    String[] expected={"0:v0","0:k0","1:v1","1:k1","2:v2","2:k2","3:v3","3:k3"};
    assertArrayEquals(expected,processor.processed.toArray());
  }
}
