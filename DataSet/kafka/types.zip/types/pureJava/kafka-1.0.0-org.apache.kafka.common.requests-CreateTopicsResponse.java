public class CreateTopicsResponse extends AbstractResponse {
  private static final String TOPIC_ERRORS_KEY_NAME="topic_errors";
  private static final Schema TOPIC_ERROR_CODE=new Schema(TOPIC_NAME,ERROR_CODE);
  private static final Schema TOPIC_ERROR=new Schema(TOPIC_NAME,ERROR_CODE,ERROR_MESSAGE);
  private static final Schema CREATE_TOPICS_RESPONSE_V0=new Schema(new Field(TOPIC_ERRORS_KEY_NAME,new ArrayOf(TOPIC_ERROR_CODE),"An array of per topic error codes."));
  private static final Schema CREATE_TOPICS_RESPONSE_V1=new Schema(new Field(TOPIC_ERRORS_KEY_NAME,new ArrayOf(TOPIC_ERROR),"An array of per topic errors."));
  private static final Schema CREATE_TOPICS_RESPONSE_V2=new Schema(THROTTLE_TIME_MS,new Field(TOPIC_ERRORS_KEY_NAME,new ArrayOf(TOPIC_ERROR),"An array of per topic errors."));
  public static Schema[] schemaVersions(){
    return new Schema[]{CREATE_TOPICS_RESPONSE_V0,CREATE_TOPICS_RESPONSE_V1,CREATE_TOPICS_RESPONSE_V2};
  }
  /** 
 * Possible error codes: REQUEST_TIMED_OUT(7) INVALID_TOPIC_EXCEPTION(17) CLUSTER_AUTHORIZATION_FAILED(31) TOPIC_ALREADY_EXISTS(36) INVALID_PARTITIONS(37) INVALID_REPLICATION_FACTOR(38) INVALID_REPLICA_ASSIGNMENT(39) INVALID_CONFIG(40) NOT_CONTROLLER(41) INVALID_REQUEST(42)
 */
  private final Map<String,ApiError> errors;
  private final int throttleTimeMs;
  public CreateTopicsResponse(  Map<String,ApiError> errors){
    this(DEFAULT_THROTTLE_TIME,errors);
  }
  public CreateTopicsResponse(  int throttleTimeMs,  Map<String,ApiError> errors){
    this.throttleTimeMs=throttleTimeMs;
    this.errors=errors;
  }
  public CreateTopicsResponse(  Struct struct){
    Object[] topicErrorStructs=struct.getArray(TOPIC_ERRORS_KEY_NAME);
    Map<String,ApiError> errors=new HashMap<>();
    for (    Object topicErrorStructObj : topicErrorStructs) {
      Struct topicErrorStruct=(Struct)topicErrorStructObj;
      String topic=topicErrorStruct.get(TOPIC_NAME);
      errors.put(topic,new ApiError(topicErrorStruct));
    }
    this.throttleTimeMs=struct.getOrElse(THROTTLE_TIME_MS,DEFAULT_THROTTLE_TIME);
    this.errors=errors;
  }
  @Override protected Struct toStruct(  short version){
    Struct struct=new Struct(ApiKeys.CREATE_TOPICS.responseSchema(version));
    struct.setIfExists(THROTTLE_TIME_MS,throttleTimeMs);
    List<Struct> topicErrorsStructs=new ArrayList<>(errors.size());
    for (    Map.Entry<String,ApiError> topicError : errors.entrySet()) {
      Struct topicErrorsStruct=struct.instance(TOPIC_ERRORS_KEY_NAME);
      topicErrorsStruct.set(TOPIC_NAME,topicError.getKey());
      topicError.getValue().write(topicErrorsStruct);
      topicErrorsStructs.add(topicErrorsStruct);
    }
    struct.set(TOPIC_ERRORS_KEY_NAME,topicErrorsStructs.toArray());
    return struct;
  }
  public int throttleTimeMs(){
    return throttleTimeMs;
  }
  public Map<String,ApiError> errors(){
    return errors;
  }
  @Override public Map<Errors,Integer> errorCounts(){
    return apiErrorCounts(errors);
  }
  public static CreateTopicsResponse parse(  ByteBuffer buffer,  short version){
    return new CreateTopicsResponse(ApiKeys.CREATE_TOPICS.responseSchema(version).read(buffer));
  }
}
