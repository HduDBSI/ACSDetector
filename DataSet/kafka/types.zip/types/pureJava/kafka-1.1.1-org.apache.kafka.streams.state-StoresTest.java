public class StoresTest {
  @Test(expected=NullPointerException.class) public void shouldThrowIfPersistentKeyValueStoreStoreNameIsNull(){
    Stores.persistentKeyValueStore(null);
  }
  @Test(expected=NullPointerException.class) public void shouldThrowIfIMemoryKeyValueStoreStoreNameIsNull(){
    Stores.inMemoryKeyValueStore(null);
  }
  @Test(expected=NullPointerException.class) public void shouldThrowIfILruMapStoreNameIsNull(){
    Stores.lruMap(null,0);
  }
  @Test(expected=IllegalArgumentException.class) public void shouldThrowIfILruMapStoreCapacityIsNegative(){
    Stores.lruMap("anyName",-1);
  }
  @Test(expected=NullPointerException.class) public void shouldThrowIfIPersistentWindowStoreStoreNameIsNull(){
    Stores.persistentWindowStore(null,0,1,0,false);
  }
  @Test(expected=IllegalArgumentException.class) public void shouldThrowIfIPersistentWindowStoreRetentionPeriodIsNegative(){
    Stores.persistentWindowStore("anyName",-1,1,0,false);
  }
  @Test(expected=IllegalArgumentException.class) public void shouldThrowIfIPersistentWindowStoreIfNumberOfSegmentsSmallerThanOne(){
    Stores.persistentWindowStore("anyName",0,0,0,false);
  }
  @Test(expected=IllegalArgumentException.class) public void shouldThrowIfIPersistentWindowStoreIfWindowSizeIsNegative(){
    Stores.persistentWindowStore("anyName",0,1,-1,false);
  }
  @Test(expected=NullPointerException.class) public void shouldThrowIfIPersistentSessionStoreStoreNameIsNull(){
    Stores.persistentSessionStore(null,0);
  }
  @Test(expected=IllegalArgumentException.class) public void shouldThrowIfIPersistentSessionStoreRetentionPeriodIsNegative(){
    Stores.persistentSessionStore("anyName",-1);
  }
  @Test(expected=NullPointerException.class) public void shouldThrowIfSupplierIsNullForWindowStoreBuilder(){
    Stores.windowStoreBuilder(null,Serdes.ByteArray(),Serdes.ByteArray());
  }
  @Test(expected=NullPointerException.class) public void shouldThrowIfSupplierIsNullForKeyValueStoreBuilder(){
    Stores.keyValueStoreBuilder(null,Serdes.ByteArray(),Serdes.ByteArray());
  }
  @Test(expected=NullPointerException.class) public void shouldThrowIfSupplierIsNullForSessionStoreBuilder(){
    Stores.sessionStoreBuilder(null,Serdes.ByteArray(),Serdes.ByteArray());
  }
  @SuppressWarnings("deprecation") @Test public void shouldCreateInMemoryStoreSupplierWithLoggedConfig(){
    final StateStoreSupplier supplier=Stores.create("store").withKeys(Serdes.String()).withValues(Serdes.String()).inMemory().enableLogging(Collections.singletonMap("retention.ms","1000")).build();
    final Map<String,String> config=supplier.logConfig();
    assertTrue(supplier.loggingEnabled());
    assertEquals("1000",config.get("retention.ms"));
  }
  @SuppressWarnings("deprecation") @Test public void shouldCreateInMemoryStoreSupplierNotLogged(){
    final StateStoreSupplier supplier=Stores.create("store").withKeys(Serdes.String()).withValues(Serdes.String()).inMemory().disableLogging().build();
    assertFalse(supplier.loggingEnabled());
  }
  @SuppressWarnings("deprecation") @Test public void shouldCreatePersistenStoreSupplierWithLoggedConfig(){
    final StateStoreSupplier supplier=Stores.create("store").withKeys(Serdes.String()).withValues(Serdes.String()).persistent().enableLogging(Collections.singletonMap("retention.ms","1000")).build();
    final Map<String,String> config=supplier.logConfig();
    assertTrue(supplier.loggingEnabled());
    assertEquals("1000",config.get("retention.ms"));
  }
  @SuppressWarnings("deprecation") @Test public void shouldCreatePersistenStoreSupplierNotLogged(){
    final StateStoreSupplier supplier=Stores.create("store").withKeys(Serdes.String()).withValues(Serdes.String()).persistent().disableLogging().build();
    assertFalse(supplier.loggingEnabled());
  }
  @Test public void shouldThrowIllegalArgumentExceptionWhenTryingToConstructWindowStoreWithLessThanTwoSegments(){
    final Stores.PersistentKeyValueFactory<String,String> storeFactory=Stores.create("store").withKeys(Serdes.String()).withValues(Serdes.String()).persistent();
    try {
      storeFactory.windowed(1,1,1,false);
      fail("Should have thrown illegal argument exception as number of segments is less than 2");
    }
 catch (    final IllegalArgumentException e) {
    }
  }
  @Test public void shouldCreateInMemoryKeyValueStore(){
    assertThat(Stores.inMemoryKeyValueStore("memory").get(),instanceOf(InMemoryKeyValueStore.class));
  }
  @Test public void shouldCreateMemoryNavigableCache(){
    assertThat(Stores.lruMap("map",10).get(),instanceOf(MemoryNavigableLRUCache.class));
  }
  @Test public void shouldCreateRocksDbStore(){
    assertThat(Stores.persistentKeyValueStore("store").get(),instanceOf(RocksDBStore.class));
  }
  @Test public void shouldCreateRocksDbWindowStore(){
    assertThat(Stores.persistentWindowStore("store",1,3,1,false).get(),instanceOf(RocksDBWindowStore.class));
  }
  @Test public void shouldCreateRocksDbSessionStore(){
    assertThat(Stores.persistentSessionStore("store",1).get(),instanceOf(RocksDBSessionStore.class));
  }
  @Test public void shouldBuildWindowStore(){
    final WindowStore<String,String> store=Stores.windowStoreBuilder(Stores.persistentWindowStore("store",3,2,3,true),Serdes.String(),Serdes.String()).build();
    assertThat(store,not(nullValue()));
  }
  @Test public void shouldBuildKeyValueStore(){
    final KeyValueStore<String,String> store=Stores.keyValueStoreBuilder(Stores.persistentKeyValueStore("name"),Serdes.String(),Serdes.String()).build();
    assertThat(store,not(nullValue()));
  }
  @Test public void shouldBuildSessionStore(){
    final SessionStore<String,String> store=Stores.sessionStoreBuilder(Stores.persistentSessionStore("name",10),Serdes.String(),Serdes.String()).build();
    assertThat(store,not(nullValue()));
  }
}
