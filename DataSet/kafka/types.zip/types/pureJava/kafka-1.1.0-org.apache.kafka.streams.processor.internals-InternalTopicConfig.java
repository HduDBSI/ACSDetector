/** 
 * InternalTopicConfig captures the properties required for configuring the internal topics we create for change-logs and repartitioning etc.
 */
public abstract class InternalTopicConfig {
  final String name;
  final Map<String,String> topicConfigs;
  private int numberOfPartitions=-1;
  InternalTopicConfig(  final String name,  final Map<String,String> topicConfigs){
    Objects.requireNonNull(name,"name can't be null");
    Topic.validate(name);
    this.name=name;
    this.topicConfigs=topicConfigs;
  }
  /** 
 * Get the configured properties for this topic. If rententionMs is set then we add additionalRetentionMs to work out the desired retention when cleanup.policy=compact,delete
 * @param additionalRetentionMs - added to retention to allow for clock drift etc
 * @return Properties to be used when creating the topic
 */
  abstract public Map<String,String> getProperties(  final Map<String,String> defaultProperties,  final long additionalRetentionMs);
  public String name(){
    return name;
  }
  public int numberOfPartitions(){
    if (numberOfPartitions == -1) {
      throw new IllegalStateException("Number of partitions not specified.");
    }
    return numberOfPartitions;
  }
  void setNumberOfPartitions(  final int numberOfPartitions){
    if (numberOfPartitions < 1) {
      throw new IllegalArgumentException("Number of partitions must be at least 1.");
    }
    this.numberOfPartitions=numberOfPartitions;
  }
  @Override public String toString(){
    return "InternalTopicConfig(" + "name=" + name + ", topicConfigs="+ topicConfigs+ ")";
  }
}
