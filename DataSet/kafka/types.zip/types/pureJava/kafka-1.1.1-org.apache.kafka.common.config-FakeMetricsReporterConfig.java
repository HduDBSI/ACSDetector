public static class FakeMetricsReporterConfig extends AbstractConfig {
  public static final String EXTRA_CONFIG="metric.extra_config";
  private static final String EXTRA_CONFIG_DOC="An extraneous configuration string.";
  private static final ConfigDef CONFIG=new ConfigDef().define(EXTRA_CONFIG,ConfigDef.Type.STRING,"",ConfigDef.Importance.LOW,EXTRA_CONFIG_DOC);
  public FakeMetricsReporterConfig(  Map<?,?> props){
    super(CONFIG,props);
  }
}
