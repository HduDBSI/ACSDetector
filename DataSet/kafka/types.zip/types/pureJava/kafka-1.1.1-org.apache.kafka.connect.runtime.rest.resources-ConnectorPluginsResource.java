@Path("/connector-plugins") @Produces(MediaType.APPLICATION_JSON) @Consumes(MediaType.APPLICATION_JSON) public class ConnectorPluginsResource {
  private static final String ALIAS_SUFFIX="Connector";
  private final Herder herder;
  private final List<ConnectorPluginInfo> connectorPlugins;
  private static final List<Class<? extends Connector>> CONNECTOR_EXCLUDES=Arrays.asList(VerifiableSourceConnector.class,VerifiableSinkConnector.class,MockConnector.class,MockSourceConnector.class,MockSinkConnector.class,SchemaSourceConnector.class);
  public ConnectorPluginsResource(  Herder herder){
    this.herder=herder;
    this.connectorPlugins=new ArrayList<>();
  }
  @PUT @Path("/{connectorType}/config/validate") public ConfigInfos validateConfigs(  final @PathParam("connectorType") String connType,  final Map<String,String> connectorConfig) throws Throwable {
    String includedConnType=connectorConfig.get(ConnectorConfig.CONNECTOR_CLASS_CONFIG);
    if (includedConnType != null && !normalizedPluginName(includedConnType).endsWith(normalizedPluginName(connType))) {
      throw new BadRequestException("Included connector type " + includedConnType + " does not match request type "+ connType);
    }
    return herder.validateConnectorConfig(connectorConfig);
  }
  @GET @Path("/") public List<ConnectorPluginInfo> listConnectorPlugins(){
    return getConnectorPlugins();
  }
  private synchronized List<ConnectorPluginInfo> getConnectorPlugins(){
    if (connectorPlugins.isEmpty()) {
      for (      PluginDesc<Connector> plugin : herder.plugins().connectors()) {
        if (!CONNECTOR_EXCLUDES.contains(plugin.pluginClass())) {
          connectorPlugins.add(new ConnectorPluginInfo(plugin));
        }
      }
    }
    return Collections.unmodifiableList(connectorPlugins);
  }
  private String normalizedPluginName(  String pluginName){
    return pluginName.endsWith(ALIAS_SUFFIX) && pluginName.length() > ALIAS_SUFFIX.length() ? pluginName.substring(0,pluginName.length() - ALIAS_SUFFIX.length()) : pluginName;
  }
}
