public class KafkaConsumerTest {
  private final String topic="test";
  private final TopicPartition tp0=new TopicPartition(topic,0);
  private final TopicPartition tp1=new TopicPartition(topic,1);
  private final String topic2="test2";
  private final TopicPartition t2p0=new TopicPartition(topic2,0);
  private final String topic3="test3";
  private final TopicPartition t3p0=new TopicPartition(topic3,0);
  private final int sessionTimeoutMs=10000;
  private final int heartbeatIntervalMs=1000;
  private final int autoCommitIntervalMs=500;
  @Rule public ExpectedException expectedException=ExpectedException.none();
  @Test public void testConstructorClose() throws Exception {
    Properties props=new Properties();
    props.setProperty(ConsumerConfig.CLIENT_ID_CONFIG,"testConstructorClose");
    props.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,"invalid-23-8409-adsfsdj");
    props.setProperty(ConsumerConfig.METRIC_REPORTER_CLASSES_CONFIG,MockMetricsReporter.class.getName());
    final int oldInitCount=MockMetricsReporter.INIT_COUNT.get();
    final int oldCloseCount=MockMetricsReporter.CLOSE_COUNT.get();
    try {
      new KafkaConsumer<>(props,new ByteArrayDeserializer(),new ByteArrayDeserializer());
      Assert.fail("should have caught an exception and returned");
    }
 catch (    KafkaException e) {
      assertEquals(oldInitCount + 1,MockMetricsReporter.INIT_COUNT.get());
      assertEquals(oldCloseCount + 1,MockMetricsReporter.CLOSE_COUNT.get());
      assertEquals("Failed to construct kafka consumer",e.getMessage());
    }
  }
  @Test public void testOsDefaultSocketBufferSizes() throws Exception {
    Map<String,Object> config=new HashMap<>();
    config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,"localhost:9999");
    config.put(ConsumerConfig.SEND_BUFFER_CONFIG,Selectable.USE_DEFAULT_BUFFER_SIZE);
    config.put(ConsumerConfig.RECEIVE_BUFFER_CONFIG,Selectable.USE_DEFAULT_BUFFER_SIZE);
    KafkaConsumer<byte[],byte[]> consumer=new KafkaConsumer<>(config,new ByteArrayDeserializer(),new ByteArrayDeserializer());
    consumer.close();
  }
  @Test(expected=KafkaException.class) public void testInvalidSocketSendBufferSize() throws Exception {
    Map<String,Object> config=new HashMap<>();
    config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,"localhost:9999");
    config.put(ConsumerConfig.SEND_BUFFER_CONFIG,-2);
    new KafkaConsumer<>(config,new ByteArrayDeserializer(),new ByteArrayDeserializer());
  }
  @Test(expected=KafkaException.class) public void testInvalidSocketReceiveBufferSize() throws Exception {
    Map<String,Object> config=new HashMap<>();
    config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,"localhost:9999");
    config.put(ConsumerConfig.RECEIVE_BUFFER_CONFIG,-2);
    new KafkaConsumer<>(config,new ByteArrayDeserializer(),new ByteArrayDeserializer());
  }
  @Test public void testSubscription(){
    KafkaConsumer<byte[],byte[]> consumer=newConsumer();
    consumer.subscribe(singletonList(topic));
    assertEquals(singleton(topic),consumer.subscription());
    assertTrue(consumer.assignment().isEmpty());
    consumer.subscribe(Collections.<String>emptyList());
    assertTrue(consumer.subscription().isEmpty());
    assertTrue(consumer.assignment().isEmpty());
    consumer.assign(singletonList(tp0));
    assertTrue(consumer.subscription().isEmpty());
    assertEquals(singleton(tp0),consumer.assignment());
    consumer.unsubscribe();
    assertTrue(consumer.subscription().isEmpty());
    assertTrue(consumer.assignment().isEmpty());
    consumer.close();
  }
  @Test(expected=IllegalArgumentException.class) public void testSubscriptionOnNullTopicCollection(){
    try (KafkaConsumer<byte[],byte[]> consumer=newConsumer()){
      consumer.subscribe((List<String>)null);
    }
   }
  @Test(expected=IllegalArgumentException.class) public void testSubscriptionOnNullTopic(){
    try (KafkaConsumer<byte[],byte[]> consumer=newConsumer()){
      consumer.subscribe(singletonList((String)null));
    }
   }
  @Test(expected=IllegalArgumentException.class) public void testSubscriptionOnEmptyTopic(){
    try (KafkaConsumer<byte[],byte[]> consumer=newConsumer()){
      String emptyTopic="  ";
      consumer.subscribe(singletonList(emptyTopic));
    }
   }
  @Test(expected=IllegalArgumentException.class) public void testSubscriptionOnNullPattern(){
    try (KafkaConsumer<byte[],byte[]> consumer=newConsumer()){
      consumer.subscribe((Pattern)null);
    }
   }
  @Test(expected=IllegalStateException.class) public void testSubscriptionWithEmptyPartitionAssignment(){
    Properties props=new Properties();
    props.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,"localhost:9999");
    props.setProperty(ConsumerConfig.PARTITION_ASSIGNMENT_STRATEGY_CONFIG,"");
    try (KafkaConsumer<byte[],byte[]> consumer=newConsumer(props)){
      consumer.subscribe(singletonList(topic));
    }
   }
  @Test(expected=IllegalArgumentException.class) public void testSeekNegative(){
    try (KafkaConsumer<byte[],byte[]> consumer=newConsumer()){
      consumer.assign(singleton(new TopicPartition("nonExistTopic",0)));
      consumer.seek(new TopicPartition("nonExistTopic",0),-1);
    }
   }
  @Test(expected=IllegalArgumentException.class) public void testAssignOnNullTopicPartition(){
    try (KafkaConsumer<byte[],byte[]> consumer=newConsumer()){
      consumer.assign(null);
    }
   }
  @Test public void testAssignOnEmptyTopicPartition(){
    try (KafkaConsumer<byte[],byte[]> consumer=newConsumer()){
      consumer.assign(Collections.<TopicPartition>emptyList());
      assertTrue(consumer.subscription().isEmpty());
      assertTrue(consumer.assignment().isEmpty());
    }
   }
  @Test(expected=IllegalArgumentException.class) public void testAssignOnNullTopicInPartition(){
    try (KafkaConsumer<byte[],byte[]> consumer=newConsumer()){
      consumer.assign(singleton(new TopicPartition(null,0)));
    }
   }
  @Test(expected=IllegalArgumentException.class) public void testAssignOnEmptyTopicInPartition(){
    try (KafkaConsumer<byte[],byte[]> consumer=newConsumer()){
      consumer.assign(singleton(new TopicPartition("  ",0)));
    }
   }
  @Test public void testInterceptorConstructorClose() throws Exception {
    try {
      Properties props=new Properties();
      props.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,"localhost:9999");
      props.setProperty(ConsumerConfig.INTERCEPTOR_CLASSES_CONFIG,MockConsumerInterceptor.class.getName());
      KafkaConsumer<String,String> consumer=new KafkaConsumer<>(props,new StringDeserializer(),new StringDeserializer());
      assertEquals(1,MockConsumerInterceptor.INIT_COUNT.get());
      assertEquals(0,MockConsumerInterceptor.CLOSE_COUNT.get());
      consumer.close();
      assertEquals(1,MockConsumerInterceptor.INIT_COUNT.get());
      assertEquals(1,MockConsumerInterceptor.CLOSE_COUNT.get());
      Assert.assertNull(MockConsumerInterceptor.CLUSTER_META.get());
    }
  finally {
      MockConsumerInterceptor.resetCounters();
    }
  }
  @Test public void testPause(){
    KafkaConsumer<byte[],byte[]> consumer=newConsumer();
    consumer.assign(singletonList(tp0));
    assertEquals(singleton(tp0),consumer.assignment());
    assertTrue(consumer.paused().isEmpty());
    consumer.pause(singleton(tp0));
    assertEquals(singleton(tp0),consumer.paused());
    consumer.resume(singleton(tp0));
    assertTrue(consumer.paused().isEmpty());
    consumer.unsubscribe();
    assertTrue(consumer.paused().isEmpty());
    consumer.close();
  }
  private KafkaConsumer<byte[],byte[]> newConsumer(){
    Properties props=new Properties();
    props.setProperty(ConsumerConfig.CLIENT_ID_CONFIG,"my.consumer");
    props.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,"localhost:9999");
    props.setProperty(ConsumerConfig.METRIC_REPORTER_CLASSES_CONFIG,MockMetricsReporter.class.getName());
    return newConsumer(props);
  }
  private KafkaConsumer<byte[],byte[]> newConsumer(  Properties props){
    return new KafkaConsumer<>(props,new ByteArrayDeserializer(),new ByteArrayDeserializer());
  }
  @Test public void verifyHeartbeatSent() throws Exception {
    Time time=new MockTime();
    Cluster cluster=TestUtils.singletonCluster(topic,1);
    Node node=cluster.nodes().get(0);
    Metadata metadata=createMetadata();
    metadata.update(cluster,Collections.<String>emptySet(),time.milliseconds());
    MockClient client=new MockClient(time,metadata);
    client.setNode(node);
    PartitionAssignor assignor=new RoundRobinAssignor();
    KafkaConsumer<String,String> consumer=newConsumer(time,client,metadata,assignor,true);
    consumer.subscribe(singleton(topic),getConsumerRebalanceListener(consumer));
    Node coordinator=prepareRebalance(client,node,assignor,singletonList(tp0),null);
    client.prepareResponseFrom(fetchResponse(tp0,0,0),node);
    consumer.poll(0);
    assertEquals(singleton(tp0),consumer.assignment());
    AtomicBoolean heartbeatReceived=prepareHeartbeatResponse(client,coordinator);
    time.sleep(heartbeatIntervalMs);
    Thread.sleep(heartbeatIntervalMs);
    consumer.poll(0);
    assertTrue(heartbeatReceived.get());
    consumer.close(0,TimeUnit.MILLISECONDS);
  }
  @Test public void verifyHeartbeatSentWhenFetchedDataReady() throws Exception {
    Time time=new MockTime();
    Cluster cluster=TestUtils.singletonCluster(topic,1);
    Node node=cluster.nodes().get(0);
    Metadata metadata=createMetadata();
    metadata.update(cluster,Collections.<String>emptySet(),time.milliseconds());
    MockClient client=new MockClient(time,metadata);
    client.setNode(node);
    PartitionAssignor assignor=new RoundRobinAssignor();
    KafkaConsumer<String,String> consumer=newConsumer(time,client,metadata,assignor,true);
    consumer.subscribe(singleton(topic),getConsumerRebalanceListener(consumer));
    Node coordinator=prepareRebalance(client,node,assignor,singletonList(tp0),null);
    consumer.poll(0);
    client.respondFrom(fetchResponse(tp0,0,5),node);
    client.poll(0,time.milliseconds());
    client.prepareResponseFrom(fetchResponse(tp0,5,0),node);
    AtomicBoolean heartbeatReceived=prepareHeartbeatResponse(client,coordinator);
    time.sleep(heartbeatIntervalMs);
    Thread.sleep(heartbeatIntervalMs);
    consumer.poll(0);
    assertTrue(heartbeatReceived.get());
    consumer.close(0,TimeUnit.MILLISECONDS);
  }
  @Test public void verifyNoCoordinatorLookupForManualAssignmentWithSeek(){
    Time time=new MockTime();
    Cluster cluster=TestUtils.singletonCluster(topic,1);
    Node node=cluster.nodes().get(0);
    Metadata metadata=createMetadata();
    metadata.update(cluster,Collections.<String>emptySet(),time.milliseconds());
    MockClient client=new MockClient(time,metadata);
    client.setNode(node);
    PartitionAssignor assignor=new RoundRobinAssignor();
    KafkaConsumer<String,String> consumer=newConsumer(time,client,metadata,assignor,true);
    consumer.assign(singleton(tp0));
    consumer.seekToBeginning(singleton(tp0));
    client.prepareResponse(listOffsetsResponse(Collections.singletonMap(tp0,50L)));
    client.prepareResponse(fetchResponse(tp0,50L,5));
    ConsumerRecords<String,String> records=consumer.poll(5);
    assertEquals(5,records.count());
    assertEquals(55L,consumer.position(tp0));
    consumer.close(0,TimeUnit.MILLISECONDS);
  }
  @Test public void testFetchProgressWithMissingPartitionPosition(){
    Time time=new MockTime();
    Cluster cluster=TestUtils.singletonCluster(topic,2);
    Node node=cluster.nodes().get(0);
    Metadata metadata=createMetadata();
    metadata.update(cluster,Collections.<String>emptySet(),time.milliseconds());
    MockClient client=new MockClient(time,metadata);
    client.setNode(node);
    KafkaConsumer<String,String> consumer=newConsumerNoAutoCommit(time,client,metadata);
    consumer.assign(Arrays.asList(tp0,tp1));
    consumer.seekToEnd(singleton(tp0));
    consumer.seekToBeginning(singleton(tp1));
    client.prepareResponse(new MockClient.RequestMatcher(){
      @Override public boolean matches(      AbstractRequest body){
        ListOffsetRequest request=(ListOffsetRequest)body;
        Map<TopicPartition,Long> expectedTimestamps=new HashMap<>();
        expectedTimestamps.put(tp0,ListOffsetRequest.LATEST_TIMESTAMP);
        expectedTimestamps.put(tp1,ListOffsetRequest.EARLIEST_TIMESTAMP);
        return expectedTimestamps.equals(request.partitionTimestamps());
      }
    }
,listOffsetsResponse(Collections.singletonMap(tp0,50L),Collections.singletonMap(tp1,Errors.NOT_LEADER_FOR_PARTITION)));
    client.prepareResponse(new MockClient.RequestMatcher(){
      @Override public boolean matches(      AbstractRequest body){
        FetchRequest request=(FetchRequest)body;
        return request.fetchData().keySet().equals(singleton(tp0)) && request.fetchData().get(tp0).fetchOffset == 50L;
      }
    }
,fetchResponse(tp0,50L,5));
    ConsumerRecords<String,String> records=consumer.poll(5);
    assertEquals(5,records.count());
    assertEquals(singleton(tp0),records.partitions());
  }
  @Test(expected=NoOffsetForPartitionException.class) public void testMissingOffsetNoResetPolicy(){
    Time time=new MockTime();
    Cluster cluster=TestUtils.singletonCluster(topic,1);
    Node node=cluster.nodes().get(0);
    Metadata metadata=createMetadata();
    metadata.update(cluster,Collections.<String>emptySet(),time.milliseconds());
    MockClient client=new MockClient(time,metadata);
    client.setNode(node);
    PartitionAssignor assignor=new RoundRobinAssignor();
    KafkaConsumer<String,String> consumer=newConsumer(time,client,metadata,assignor,OffsetResetStrategy.NONE,true);
    consumer.assign(singletonList(tp0));
    client.prepareResponseFrom(new FindCoordinatorResponse(Errors.NONE,node),node);
    Node coordinator=new Node(Integer.MAX_VALUE - node.id(),node.host(),node.port());
    client.prepareResponseFrom(offsetResponse(Collections.singletonMap(tp0,-1L),Errors.NONE),coordinator);
    consumer.poll(0);
  }
  @Test public void testResetToCommittedOffset(){
    Time time=new MockTime();
    Cluster cluster=TestUtils.singletonCluster(topic,1);
    Node node=cluster.nodes().get(0);
    Metadata metadata=createMetadata();
    metadata.update(cluster,Collections.<String>emptySet(),time.milliseconds());
    MockClient client=new MockClient(time,metadata);
    client.setNode(node);
    PartitionAssignor assignor=new RoundRobinAssignor();
    KafkaConsumer<String,String> consumer=newConsumer(time,client,metadata,assignor,OffsetResetStrategy.NONE,true);
    consumer.assign(singletonList(tp0));
    client.prepareResponseFrom(new FindCoordinatorResponse(Errors.NONE,node),node);
    Node coordinator=new Node(Integer.MAX_VALUE - node.id(),node.host(),node.port());
    client.prepareResponseFrom(offsetResponse(Collections.singletonMap(tp0,539L),Errors.NONE),coordinator);
    consumer.poll(0);
    assertEquals(539L,consumer.position(tp0));
  }
  @Test public void testResetUsingAutoResetPolicy(){
    Time time=new MockTime();
    Cluster cluster=TestUtils.singletonCluster(topic,1);
    Node node=cluster.nodes().get(0);
    Metadata metadata=createMetadata();
    metadata.update(cluster,Collections.<String>emptySet(),time.milliseconds());
    MockClient client=new MockClient(time,metadata);
    client.setNode(node);
    PartitionAssignor assignor=new RoundRobinAssignor();
    KafkaConsumer<String,String> consumer=newConsumer(time,client,metadata,assignor,OffsetResetStrategy.LATEST,true);
    consumer.assign(singletonList(tp0));
    client.prepareResponseFrom(new FindCoordinatorResponse(Errors.NONE,node),node);
    Node coordinator=new Node(Integer.MAX_VALUE - node.id(),node.host(),node.port());
    client.prepareResponseFrom(offsetResponse(Collections.singletonMap(tp0,-1L),Errors.NONE),coordinator);
    client.prepareResponse(listOffsetsResponse(Collections.singletonMap(tp0,50L)));
    consumer.poll(0);
    assertEquals(50L,consumer.position(tp0));
  }
  @Test public void testCommitsFetchedDuringAssign(){
    long offset1=10000;
    long offset2=20000;
    Time time=new MockTime();
    Cluster cluster=TestUtils.singletonCluster(topic,2);
    Node node=cluster.nodes().get(0);
    Metadata metadata=createMetadata();
    metadata.update(cluster,Collections.<String>emptySet(),time.milliseconds());
    MockClient client=new MockClient(time,metadata);
    client.setNode(node);
    PartitionAssignor assignor=new RoundRobinAssignor();
    KafkaConsumer<String,String> consumer=newConsumer(time,client,metadata,assignor,true);
    consumer.assign(singletonList(tp0));
    client.prepareResponseFrom(new FindCoordinatorResponse(Errors.NONE,node),node);
    Node coordinator=new Node(Integer.MAX_VALUE - node.id(),node.host(),node.port());
    client.prepareResponseFrom(offsetResponse(Collections.singletonMap(tp0,offset1),Errors.NONE),coordinator);
    assertEquals(offset1,consumer.committed(tp0).offset());
    consumer.assign(Arrays.asList(tp0,tp1));
    Map<TopicPartition,Long> offsets=new HashMap<>();
    offsets.put(tp0,offset1);
    client.prepareResponseFrom(offsetResponse(offsets,Errors.NONE),coordinator);
    assertEquals(offset1,consumer.committed(tp0).offset());
    offsets.remove(tp0);
    offsets.put(tp1,offset2);
    client.prepareResponseFrom(offsetResponse(offsets,Errors.NONE),coordinator);
    assertEquals(offset2,consumer.committed(tp1).offset());
    consumer.close(0,TimeUnit.MILLISECONDS);
  }
  @Test public void testAutoCommitSentBeforePositionUpdate(){
    Time time=new MockTime();
    Cluster cluster=TestUtils.singletonCluster(topic,1);
    Node node=cluster.nodes().get(0);
    Metadata metadata=createMetadata();
    metadata.update(cluster,Collections.<String>emptySet(),time.milliseconds());
    MockClient client=new MockClient(time,metadata);
    client.setNode(node);
    PartitionAssignor assignor=new RoundRobinAssignor();
    KafkaConsumer<String,String> consumer=newConsumer(time,client,metadata,assignor,true);
    consumer.subscribe(singleton(topic),getConsumerRebalanceListener(consumer));
    Node coordinator=prepareRebalance(client,node,assignor,singletonList(tp0),null);
    consumer.poll(0);
    client.respondFrom(fetchResponse(tp0,0,5),node);
    client.poll(0,time.milliseconds());
    time.sleep(autoCommitIntervalMs);
    client.prepareResponseFrom(fetchResponse(tp0,5,0),node);
    AtomicBoolean commitReceived=prepareOffsetCommitResponse(client,coordinator,tp0,0);
    consumer.poll(0);
    assertTrue(commitReceived.get());
    consumer.close(0,TimeUnit.MILLISECONDS);
  }
  @Test public void testRegexSubscription(){
    String unmatchedTopic="unmatched";
    Time time=new MockTime();
    Map<String,Integer> topicMetadata=new HashMap<>();
    topicMetadata.put(topic,1);
    topicMetadata.put(unmatchedTopic,1);
    Cluster cluster=TestUtils.clusterWith(1,topicMetadata);
    Metadata metadata=createMetadata();
    Node node=cluster.nodes().get(0);
    MockClient client=new MockClient(time,metadata);
    client.setNode(node);
    PartitionAssignor assignor=new RoundRobinAssignor();
    KafkaConsumer<String,String> consumer=newConsumer(time,client,metadata,assignor,true);
    prepareRebalance(client,node,singleton(topic),assignor,singletonList(tp0),null);
    consumer.subscribe(Pattern.compile(topic),getConsumerRebalanceListener(consumer));
    client.prepareMetadataUpdate(cluster,Collections.<String>emptySet());
    consumer.poll(0);
    assertEquals(singleton(topic),consumer.subscription());
    assertEquals(singleton(tp0),consumer.assignment());
    consumer.close(0,TimeUnit.MILLISECONDS);
  }
  @Test public void testChangingRegexSubscription(){
    PartitionAssignor assignor=new RoundRobinAssignor();
    String otherTopic="other";
    TopicPartition otherTopicPartition=new TopicPartition(otherTopic,0);
    Time time=new MockTime();
    Map<String,Integer> topicMetadata=new HashMap<>();
    topicMetadata.put(topic,1);
    topicMetadata.put(otherTopic,1);
    Cluster cluster=TestUtils.clusterWith(1,topicMetadata);
    Metadata metadata=createMetadata();
    Node node=cluster.nodes().get(0);
    MockClient client=new MockClient(time,metadata);
    client.setNode(node);
    client.cluster(cluster);
    metadata.update(cluster,Collections.<String>emptySet(),time.milliseconds());
    KafkaConsumer<String,String> consumer=newConsumer(time,client,metadata,assignor,false);
    Node coordinator=prepareRebalance(client,node,singleton(topic),assignor,singletonList(tp0),null);
    consumer.subscribe(Pattern.compile(topic),getConsumerRebalanceListener(consumer));
    consumer.poll(0);
    assertEquals(singleton(topic),consumer.subscription());
    consumer.subscribe(Pattern.compile(otherTopic),getConsumerRebalanceListener(consumer));
    prepareRebalance(client,node,singleton(otherTopic),assignor,singletonList(otherTopicPartition),coordinator);
    consumer.poll(0);
    assertEquals(singleton(otherTopic),consumer.subscription());
    consumer.close(0,TimeUnit.MILLISECONDS);
  }
  @Test public void testWakeupWithFetchDataAvailable() throws Exception {
    final Time time=new MockTime();
    Cluster cluster=TestUtils.singletonCluster(topic,1);
    Node node=cluster.nodes().get(0);
    Metadata metadata=createMetadata();
    metadata.update(cluster,Collections.<String>emptySet(),time.milliseconds());
    MockClient client=new MockClient(time,metadata);
    client.setNode(node);
    PartitionAssignor assignor=new RoundRobinAssignor();
    KafkaConsumer<String,String> consumer=newConsumer(time,client,metadata,assignor,true);
    consumer.subscribe(singleton(topic),getConsumerRebalanceListener(consumer));
    prepareRebalance(client,node,assignor,singletonList(tp0),null);
    consumer.poll(0);
    client.respondFrom(fetchResponse(tp0,0,5),node);
    client.poll(0,time.milliseconds());
    consumer.wakeup();
    try {
      consumer.poll(0);
      fail();
    }
 catch (    WakeupException e) {
    }
    assertEquals(0,consumer.position(tp0));
    ConsumerRecords<String,String> records=consumer.poll(0);
    assertEquals(5,records.count());
    final ScheduledExecutorService exec=Executors.newSingleThreadScheduledExecutor();
    exec.scheduleAtFixedRate(new Runnable(){
      @Override public void run(){
        time.sleep(sessionTimeoutMs);
      }
    }
,0L,10L,TimeUnit.MILLISECONDS);
    consumer.close();
    exec.shutdownNow();
    exec.awaitTermination(5L,TimeUnit.SECONDS);
  }
  @Test public void testPollThrowsInterruptExceptionIfInterrupted() throws Exception {
    final Time time=new MockTime();
    Cluster cluster=TestUtils.singletonCluster(topic,1);
    final Node node=cluster.nodes().get(0);
    Metadata metadata=createMetadata();
    metadata.update(cluster,Collections.<String>emptySet(),time.milliseconds());
    final MockClient client=new MockClient(time,metadata);
    client.setNode(node);
    final PartitionAssignor assignor=new RoundRobinAssignor();
    KafkaConsumer<String,String> consumer=newConsumer(time,client,metadata,assignor,false);
    consumer.subscribe(singleton(topic),getConsumerRebalanceListener(consumer));
    prepareRebalance(client,node,assignor,singletonList(tp0),null);
    consumer.poll(0);
    try {
      Thread.currentThread().interrupt();
      expectedException.expect(InterruptException.class);
      consumer.poll(0);
    }
  finally {
      Thread.interrupted();
    }
    consumer.close(0,TimeUnit.MILLISECONDS);
  }
  @Test public void fetchResponseWithUnexpectedPartitionIsIgnored(){
    Time time=new MockTime();
    Cluster cluster=TestUtils.singletonCluster(singletonMap(topic,1));
    Node node=cluster.nodes().get(0);
    Metadata metadata=createMetadata();
    metadata.update(cluster,Collections.<String>emptySet(),time.milliseconds());
    MockClient client=new MockClient(time,metadata);
    client.setNode(node);
    PartitionAssignor assignor=new RangeAssignor();
    KafkaConsumer<String,String> consumer=newConsumer(time,client,metadata,assignor,true);
    consumer.subscribe(singletonList(topic),getConsumerRebalanceListener(consumer));
    prepareRebalance(client,node,assignor,singletonList(tp0),null);
    Map<TopicPartition,FetchInfo> fetches1=new HashMap<>();
    fetches1.put(tp0,new FetchInfo(0,1));
    fetches1.put(t2p0,new FetchInfo(0,10));
    client.prepareResponseFrom(fetchResponse(fetches1),node);
    ConsumerRecords<String,String> records=consumer.poll(0);
    assertEquals(0,records.count());
    consumer.close(0,TimeUnit.MILLISECONDS);
  }
  /** 
 * Verify that when a consumer changes its topic subscription its assigned partitions do not immediately change, and the latest consumed offsets of its to-be-revoked partitions are properly committed (when auto-commit is enabled). Upon unsubscribing from subscribed topics the consumer subscription and assignment are both updated right away but its consumed offsets are not auto committed.
 */
  @Test public void testSubscriptionChangesWithAutoCommitEnabled(){
    Time time=new MockTime();
    Map<String,Integer> tpCounts=new HashMap<>();
    tpCounts.put(topic,1);
    tpCounts.put(topic2,1);
    tpCounts.put(topic3,1);
    Cluster cluster=TestUtils.singletonCluster(tpCounts);
    Node node=cluster.nodes().get(0);
    Metadata metadata=createMetadata();
    metadata.update(cluster,Collections.<String>emptySet(),time.milliseconds());
    MockClient client=new MockClient(time,metadata);
    client.setNode(node);
    PartitionAssignor assignor=new RangeAssignor();
    KafkaConsumer<String,String> consumer=newConsumer(time,client,metadata,assignor,true);
    consumer.subscribe(Arrays.asList(topic,topic2),getConsumerRebalanceListener(consumer));
    assertTrue(consumer.subscription().size() == 2);
    assertTrue(consumer.subscription().contains(topic) && consumer.subscription().contains(topic2));
    assertTrue(consumer.assignment().isEmpty());
    Node coordinator=prepareRebalance(client,node,assignor,Arrays.asList(tp0,t2p0),null);
    consumer.poll(0);
    assertTrue(consumer.subscription().size() == 2);
    assertTrue(consumer.subscription().contains(topic) && consumer.subscription().contains(topic2));
    assertTrue(consumer.assignment().size() == 2);
    assertTrue(consumer.assignment().contains(tp0) && consumer.assignment().contains(t2p0));
    Map<TopicPartition,FetchInfo> fetches1=new HashMap<>();
    fetches1.put(tp0,new FetchInfo(0,1));
    fetches1.put(t2p0,new FetchInfo(0,10));
    client.respondFrom(fetchResponse(fetches1),node);
    client.poll(0,time.milliseconds());
    ConsumerRecords<String,String> records=consumer.poll(0);
    fetches1.put(tp0,new FetchInfo(1,0));
    fetches1.put(t2p0,new FetchInfo(10,0));
    client.respondFrom(fetchResponse(fetches1),node);
    client.poll(0,time.milliseconds());
    assertEquals(11,records.count());
    assertEquals(1L,consumer.position(tp0));
    assertEquals(10L,consumer.position(t2p0));
    consumer.subscribe(Arrays.asList(topic,topic3),getConsumerRebalanceListener(consumer));
    assertTrue(consumer.subscription().size() == 2);
    assertTrue(consumer.subscription().contains(topic) && consumer.subscription().contains(topic3));
    assertTrue(consumer.assignment().size() == 2);
    assertTrue(consumer.assignment().contains(tp0) && consumer.assignment().contains(t2p0));
    Map<TopicPartition,Long> partitionOffsets1=new HashMap<>();
    partitionOffsets1.put(tp0,1L);
    partitionOffsets1.put(t2p0,10L);
    AtomicBoolean commitReceived=prepareOffsetCommitResponse(client,coordinator,partitionOffsets1);
    prepareRebalance(client,node,assignor,Arrays.asList(tp0,t3p0),coordinator);
    Map<TopicPartition,FetchInfo> fetches2=new HashMap<>();
    fetches2.put(tp0,new FetchInfo(1,1));
    fetches2.put(t3p0,new FetchInfo(0,100));
    client.prepareResponse(fetchResponse(fetches2));
    records=consumer.poll(0);
    assertEquals(101,records.count());
    assertEquals(2L,consumer.position(tp0));
    assertEquals(100L,consumer.position(t3p0));
    assertTrue(commitReceived.get());
    assertTrue(consumer.subscription().size() == 2);
    assertTrue(consumer.subscription().contains(topic) && consumer.subscription().contains(topic3));
    assertTrue(consumer.assignment().size() == 2);
    assertTrue(consumer.assignment().contains(tp0) && consumer.assignment().contains(t3p0));
    consumer.unsubscribe();
    assertTrue(consumer.subscription().isEmpty());
    assertTrue(consumer.assignment().isEmpty());
    client.requests().clear();
    consumer.close();
  }
  /** 
 * Verify that when a consumer changes its topic subscription its assigned partitions do not immediately change, and the consumed offsets of its to-be-revoked partitions are not committed (when auto-commit is disabled). Upon unsubscribing from subscribed topics, the assigned partitions immediately change but if auto-commit is disabled the consumer offsets are not committed.
 */
  @Test public void testSubscriptionChangesWithAutoCommitDisabled(){
    Time time=new MockTime();
    Map<String,Integer> tpCounts=new HashMap<>();
    tpCounts.put(topic,1);
    tpCounts.put(topic2,1);
    Cluster cluster=TestUtils.singletonCluster(tpCounts);
    Node node=cluster.nodes().get(0);
    Metadata metadata=createMetadata();
    metadata.update(cluster,Collections.<String>emptySet(),time.milliseconds());
    MockClient client=new MockClient(time,metadata);
    client.setNode(node);
    PartitionAssignor assignor=new RangeAssignor();
    KafkaConsumer<String,String> consumer=newConsumer(time,client,metadata,assignor,false);
    consumer.subscribe(singleton(topic),getConsumerRebalanceListener(consumer));
    assertTrue(consumer.subscription().equals(singleton(topic)));
    assertTrue(consumer.assignment().isEmpty());
    prepareRebalance(client,node,assignor,singletonList(tp0),null);
    consumer.poll(0);
    assertTrue(consumer.subscription().equals(singleton(topic)));
    assertTrue(consumer.assignment().equals(singleton(tp0)));
    consumer.poll(0);
    consumer.subscribe(singleton(topic2),getConsumerRebalanceListener(consumer));
    assertTrue(consumer.subscription().equals(singleton(topic2)));
    assertTrue(consumer.assignment().equals(singleton(tp0)));
    for (    ClientRequest req : client.requests())     assertTrue(req.requestBuilder().apiKey() != ApiKeys.OFFSET_COMMIT);
    consumer.unsubscribe();
    assertTrue(consumer.subscription().isEmpty());
    assertTrue(consumer.assignment().isEmpty());
    for (    ClientRequest req : client.requests())     assertTrue(req.requestBuilder().apiKey() != ApiKeys.OFFSET_COMMIT);
    client.requests().clear();
    consumer.close();
  }
  @Test public void testManualAssignmentChangeWithAutoCommitEnabled(){
    Time time=new MockTime();
    Map<String,Integer> tpCounts=new HashMap<>();
    tpCounts.put(topic,1);
    tpCounts.put(topic2,1);
    Cluster cluster=TestUtils.singletonCluster(tpCounts);
    Node node=cluster.nodes().get(0);
    Metadata metadata=createMetadata();
    metadata.update(cluster,Collections.<String>emptySet(),time.milliseconds());
    MockClient client=new MockClient(time,metadata);
    client.setNode(node);
    PartitionAssignor assignor=new RangeAssignor();
    KafkaConsumer<String,String> consumer=newConsumer(time,client,metadata,assignor,true);
    client.prepareResponseFrom(new FindCoordinatorResponse(Errors.NONE,node),node);
    Node coordinator=new Node(Integer.MAX_VALUE - node.id(),node.host(),node.port());
    consumer.assign(singleton(tp0));
    consumer.seekToBeginning(singleton(tp0));
    client.prepareResponseFrom(offsetResponse(Collections.singletonMap(tp0,0L),Errors.NONE),coordinator);
    assertEquals(0,consumer.committed(tp0).offset());
    assertTrue(consumer.assignment().equals(singleton(tp0)));
    client.prepareResponse(listOffsetsResponse(Collections.singletonMap(tp0,10L)));
    client.prepareResponse(fetchResponse(tp0,10L,1));
    ConsumerRecords<String,String> records=consumer.poll(5);
    assertEquals(1,records.count());
    assertEquals(11L,consumer.position(tp0));
    AtomicBoolean commitReceived=prepareOffsetCommitResponse(client,coordinator,tp0,11);
    consumer.assign(singleton(t2p0));
    assertTrue(consumer.assignment().equals(singleton(t2p0)));
    assertTrue(commitReceived.get());
    client.requests().clear();
    consumer.close();
  }
  @Test public void testManualAssignmentChangeWithAutoCommitDisabled(){
    Time time=new MockTime();
    Map<String,Integer> tpCounts=new HashMap<>();
    tpCounts.put(topic,1);
    tpCounts.put(topic2,1);
    Cluster cluster=TestUtils.singletonCluster(tpCounts);
    Node node=cluster.nodes().get(0);
    Metadata metadata=createMetadata();
    metadata.update(cluster,Collections.<String>emptySet(),time.milliseconds());
    MockClient client=new MockClient(time,metadata);
    client.setNode(node);
    PartitionAssignor assignor=new RangeAssignor();
    KafkaConsumer<String,String> consumer=newConsumer(time,client,metadata,assignor,false);
    client.prepareResponseFrom(new FindCoordinatorResponse(Errors.NONE,node),node);
    Node coordinator=new Node(Integer.MAX_VALUE - node.id(),node.host(),node.port());
    consumer.assign(singleton(tp0));
    consumer.seekToBeginning(singleton(tp0));
    client.prepareResponseFrom(offsetResponse(Collections.singletonMap(tp0,0L),Errors.NONE),coordinator);
    assertEquals(0,consumer.committed(tp0).offset());
    assertTrue(consumer.assignment().equals(singleton(tp0)));
    client.prepareResponse(listOffsetsResponse(Collections.singletonMap(tp0,10L)));
    client.prepareResponse(fetchResponse(tp0,10L,1));
    ConsumerRecords<String,String> records=consumer.poll(5);
    assertEquals(1,records.count());
    assertEquals(11L,consumer.position(tp0));
    consumer.assign(singleton(t2p0));
    assertTrue(consumer.assignment().equals(singleton(t2p0)));
    for (    ClientRequest req : client.requests())     assertTrue(req.requestBuilder().apiKey() != ApiKeys.OFFSET_COMMIT);
    client.requests().clear();
    consumer.close();
  }
  @Test public void testOffsetOfPausedPartitions(){
    Time time=new MockTime();
    Cluster cluster=TestUtils.singletonCluster(topic,2);
    Node node=cluster.nodes().get(0);
    Metadata metadata=createMetadata();
    metadata.update(cluster,Collections.<String>emptySet(),time.milliseconds());
    MockClient client=new MockClient(time,metadata);
    client.setNode(node);
    PartitionAssignor assignor=new RangeAssignor();
    KafkaConsumer<String,String> consumer=newConsumer(time,client,metadata,assignor,true);
    client.prepareResponseFrom(new FindCoordinatorResponse(Errors.NONE,node),node);
    Node coordinator=new Node(Integer.MAX_VALUE - node.id(),node.host(),node.port());
    Set<TopicPartition> partitions=Utils.mkSet(tp0,tp1);
    consumer.assign(partitions);
    assertTrue(consumer.assignment().equals(partitions));
    consumer.pause(partitions);
    consumer.seekToEnd(partitions);
    Map<TopicPartition,Long> offsets=new HashMap<>();
    offsets.put(tp0,0L);
    offsets.put(tp1,0L);
    client.prepareResponseFrom(offsetResponse(offsets,Errors.NONE),coordinator);
    assertEquals(0,consumer.committed(tp0).offset());
    offsets.remove(tp0);
    offsets.put(tp1,0L);
    client.prepareResponseFrom(offsetResponse(offsets,Errors.NONE),coordinator);
    assertEquals(0,consumer.committed(tp1).offset());
    final Map<TopicPartition,Long> offsetResponse=new HashMap<>();
    offsetResponse.put(tp0,3L);
    offsetResponse.put(tp1,3L);
    client.prepareResponse(listOffsetsResponse(offsetResponse));
    assertEquals(3L,consumer.position(tp0));
    assertEquals(3L,consumer.position(tp1));
    client.requests().clear();
    consumer.unsubscribe();
    consumer.close();
  }
  @Test(expected=IllegalStateException.class) public void testPollWithNoSubscription(){
    try (KafkaConsumer<byte[],byte[]> consumer=newConsumer()){
      consumer.poll(0);
    }
   }
  @Test(expected=IllegalStateException.class) public void testPollWithEmptySubscription(){
    try (KafkaConsumer<byte[],byte[]> consumer=newConsumer()){
      consumer.subscribe(Collections.<String>emptyList());
      consumer.poll(0);
    }
   }
  @Test(expected=IllegalStateException.class) public void testPollWithEmptyUserAssignment(){
    try (KafkaConsumer<byte[],byte[]> consumer=newConsumer()){
      consumer.assign(Collections.<TopicPartition>emptySet());
      consumer.poll(0);
    }
   }
  @Test public void testGracefulClose() throws Exception {
    Map<TopicPartition,Errors> response=new HashMap<>();
    response.put(tp0,Errors.NONE);
    OffsetCommitResponse commitResponse=offsetCommitResponse(response);
    LeaveGroupResponse leaveGroupResponse=new LeaveGroupResponse(Errors.NONE);
    consumerCloseTest(5000,Arrays.asList(commitResponse,leaveGroupResponse),0,false);
  }
  @Test public void testCloseTimeout() throws Exception {
    consumerCloseTest(5000,Collections.<AbstractResponse>emptyList(),5000,false);
  }
  @Test public void testLeaveGroupTimeout() throws Exception {
    Map<TopicPartition,Errors> response=new HashMap<>();
    response.put(tp0,Errors.NONE);
    OffsetCommitResponse commitResponse=offsetCommitResponse(response);
    consumerCloseTest(5000,singletonList(commitResponse),5000,false);
  }
  @Test public void testCloseNoWait() throws Exception {
    consumerCloseTest(0,Collections.<AbstractResponse>emptyList(),0,false);
  }
  @Test public void testCloseInterrupt() throws Exception {
    consumerCloseTest(Long.MAX_VALUE,Collections.<AbstractResponse>emptyList(),0,true);
  }
  @Test public void closeShouldBeIdempotent(){
    KafkaConsumer<byte[],byte[]> consumer=newConsumer();
    consumer.close();
    consumer.close();
    consumer.close();
  }
  @Test public void testMetricConfigRecordingLevel(){
    Properties props=new Properties();
    props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,"localhost:9000");
    try (KafkaConsumer consumer=new KafkaConsumer<>(props,new ByteArrayDeserializer(),new ByteArrayDeserializer())){
      assertEquals(Sensor.RecordingLevel.INFO,consumer.metrics.config().recordLevel());
    }
     props.put(ConsumerConfig.METRICS_RECORDING_LEVEL_CONFIG,"DEBUG");
    try (KafkaConsumer consumer=new KafkaConsumer<>(props,new ByteArrayDeserializer(),new ByteArrayDeserializer())){
      assertEquals(Sensor.RecordingLevel.DEBUG,consumer.metrics.config().recordLevel());
    }
   }
  @Test public void shouldAttemptToRejoinGroupAfterSyncGroupFailed() throws Exception {
    Time time=new MockTime();
    Cluster cluster=TestUtils.singletonCluster(topic,1);
    Node node=cluster.nodes().get(0);
    Metadata metadata=new Metadata(0,Long.MAX_VALUE,false);
    metadata.update(cluster,Collections.<String>emptySet(),time.milliseconds());
    MockClient client=new MockClient(time,metadata);
    client.setNode(node);
    PartitionAssignor assignor=new RoundRobinAssignor();
    KafkaConsumer<String,String> consumer=newConsumer(time,client,metadata,assignor,false);
    consumer.subscribe(singleton(topic),getConsumerRebalanceListener(consumer));
    client.prepareResponseFrom(new FindCoordinatorResponse(Errors.NONE,node),node);
    Node coordinator=new Node(Integer.MAX_VALUE - node.id(),node.host(),node.port());
    client.prepareResponseFrom(joinGroupFollowerResponse(assignor,1,"memberId","leaderId",Errors.NONE),coordinator);
    client.prepareResponseFrom(syncGroupResponse(singletonList(tp0),Errors.NONE),coordinator);
    client.prepareResponseFrom(fetchResponse(tp0,0,1),node);
    client.prepareResponseFrom(fetchResponse(tp0,1,0),node);
    consumer.poll(0);
    client.prepareResponseFrom(new MockClient.RequestMatcher(){
      @Override public boolean matches(      AbstractRequest body){
        return true;
      }
    }
,new HeartbeatResponse(Errors.REBALANCE_IN_PROGRESS),coordinator);
    final ByteBuffer byteBuffer=ConsumerProtocol.serializeSubscription(new PartitionAssignor.Subscription(singletonList(topic)));
    final JoinGroupResponse leaderResponse=new JoinGroupResponse(Errors.NONE,1,assignor.name(),"memberId","memberId",Collections.singletonMap("memberId",byteBuffer));
    client.prepareResponseFrom(leaderResponse,coordinator);
    client.prepareResponseFrom(syncGroupResponse(singletonList(tp0),Errors.NONE),coordinator,true);
    client.prepareResponseFrom(new FindCoordinatorResponse(Errors.NONE,node),node);
    client.prepareResponseFrom(joinGroupFollowerResponse(assignor,1,"memberId","leaderId",Errors.NONE),coordinator);
    client.prepareResponseFrom(syncGroupResponse(singletonList(tp0),Errors.NONE),coordinator);
    client.prepareResponseFrom(new MockClient.RequestMatcher(){
      @Override public boolean matches(      final AbstractRequest body){
        return body instanceof FetchRequest && ((FetchRequest)body).fetchData().containsKey(tp0);
      }
    }
,fetchResponse(tp0,1,1),node);
    time.sleep(heartbeatIntervalMs);
    Thread.sleep(heartbeatIntervalMs);
    final ConsumerRecords<String,String> records=consumer.poll(0);
    assertFalse(records.isEmpty());
    consumer.close(0,TimeUnit.MILLISECONDS);
  }
  private void consumerCloseTest(  final long closeTimeoutMs,  List<? extends AbstractResponse> responses,  long waitMs,  boolean interrupt) throws Exception {
    Time time=new MockTime();
    Cluster cluster=TestUtils.singletonCluster(topic,1);
    Node node=cluster.nodes().get(0);
    Metadata metadata=createMetadata();
    metadata.update(cluster,Collections.<String>emptySet(),time.milliseconds());
    MockClient client=new MockClient(time,metadata);
    client.setNode(node);
    PartitionAssignor assignor=new RoundRobinAssignor();
    final KafkaConsumer<String,String> consumer=newConsumer(time,client,metadata,assignor,false);
    consumer.subscribe(singleton(topic),getConsumerRebalanceListener(consumer));
    Node coordinator=prepareRebalance(client,node,assignor,singletonList(tp0),null);
    client.prepareMetadataUpdate(cluster,Collections.<String>emptySet());
    client.prepareResponseFrom(fetchResponse(tp0,0,1),node);
    client.prepareResponseFrom(fetchResponse(tp0,1,0),node);
    consumer.poll(0);
    ExecutorService executor=Executors.newSingleThreadExecutor();
    final AtomicReference<Exception> closeException=new AtomicReference<>();
    try {
      Future<?> future=executor.submit(new Runnable(){
        @Override public void run(){
          consumer.commitAsync();
          try {
            consumer.close(closeTimeoutMs,TimeUnit.MILLISECONDS);
          }
 catch (          Exception e) {
            closeException.set(e);
          }
        }
      }
);
      try {
        future.get(100,TimeUnit.MILLISECONDS);
        if (closeTimeoutMs != 0)         fail("Close completed without waiting for commit or leave response");
      }
 catch (      TimeoutException e) {
      }
      client.waitForRequests(2,1000);
      for (int i=0; i < responses.size(); i++) {
        client.waitForRequests(1,1000);
        client.respondFrom(responses.get(i),coordinator);
        if (i != responses.size() - 1) {
          try {
            future.get(100,TimeUnit.MILLISECONDS);
            fail("Close completed without waiting for response");
          }
 catch (          TimeoutException e) {
          }
        }
      }
      if (waitMs > 0)       time.sleep(waitMs);
      if (interrupt) {
        assertTrue("Close terminated prematurely",future.cancel(true));
        TestUtils.waitForCondition(new TestCondition(){
          @Override public boolean conditionMet(){
            return closeException.get() != null;
          }
        }
,"InterruptException did not occur within timeout.");
        assertTrue("Expected exception not thrown " + closeException,closeException.get() instanceof InterruptException);
      }
 else {
        future.get(500,TimeUnit.MILLISECONDS);
        assertNull("Unexpected exception during close",closeException.get());
      }
    }
  finally {
      executor.shutdownNow();
    }
  }
  private ConsumerRebalanceListener getConsumerRebalanceListener(  final KafkaConsumer<String,String> consumer){
    return new ConsumerRebalanceListener(){
      @Override public void onPartitionsRevoked(      Collection<TopicPartition> partitions){
      }
      @Override public void onPartitionsAssigned(      Collection<TopicPartition> partitions){
        for (        TopicPartition partition : partitions)         consumer.seek(partition,0);
      }
    }
;
  }
  private Metadata createMetadata(){
    return new Metadata(0,Long.MAX_VALUE,true);
  }
  private Node prepareRebalance(  MockClient client,  Node node,  final Set<String> subscribedTopics,  PartitionAssignor assignor,  List<TopicPartition> partitions,  Node coordinator){
    if (coordinator == null) {
      client.prepareResponseFrom(new FindCoordinatorResponse(Errors.NONE,node),node);
      coordinator=new Node(Integer.MAX_VALUE - node.id(),node.host(),node.port());
    }
    client.prepareResponseFrom(new MockClient.RequestMatcher(){
      @Override public boolean matches(      AbstractRequest body){
        JoinGroupRequest joinGroupRequest=(JoinGroupRequest)body;
        PartitionAssignor.Subscription subscription=ConsumerProtocol.deserializeSubscription(joinGroupRequest.groupProtocols().get(0).metadata());
        return subscribedTopics.equals(new HashSet<>(subscription.topics()));
      }
    }
,joinGroupFollowerResponse(assignor,1,"memberId","leaderId",Errors.NONE),coordinator);
    client.prepareResponseFrom(syncGroupResponse(partitions,Errors.NONE),coordinator);
    return coordinator;
  }
  private Node prepareRebalance(  MockClient client,  Node node,  PartitionAssignor assignor,  List<TopicPartition> partitions,  Node coordinator){
    if (coordinator == null) {
      client.prepareResponseFrom(new FindCoordinatorResponse(Errors.NONE,node),node);
      coordinator=new Node(Integer.MAX_VALUE - node.id(),node.host(),node.port());
    }
    client.prepareResponseFrom(joinGroupFollowerResponse(assignor,1,"memberId","leaderId",Errors.NONE),coordinator);
    client.prepareResponseFrom(syncGroupResponse(partitions,Errors.NONE),coordinator);
    return coordinator;
  }
  private AtomicBoolean prepareHeartbeatResponse(  MockClient client,  Node coordinator){
    final AtomicBoolean heartbeatReceived=new AtomicBoolean(false);
    client.prepareResponseFrom(new MockClient.RequestMatcher(){
      @Override public boolean matches(      AbstractRequest body){
        heartbeatReceived.set(true);
        return true;
      }
    }
,new HeartbeatResponse(Errors.NONE),coordinator);
    return heartbeatReceived;
  }
  private AtomicBoolean prepareOffsetCommitResponse(  MockClient client,  Node coordinator,  final Map<TopicPartition,Long> partitionOffsets){
    final AtomicBoolean commitReceived=new AtomicBoolean(true);
    Map<TopicPartition,Errors> response=new HashMap<>();
    for (    TopicPartition partition : partitionOffsets.keySet())     response.put(partition,Errors.NONE);
    client.prepareResponseFrom(new MockClient.RequestMatcher(){
      @Override public boolean matches(      AbstractRequest body){
        OffsetCommitRequest commitRequest=(OffsetCommitRequest)body;
        for (        Map.Entry<TopicPartition,Long> partitionOffset : partitionOffsets.entrySet()) {
          OffsetCommitRequest.PartitionData partitionData=commitRequest.offsetData().get(partitionOffset.getKey());
          if (partitionData.offset != partitionOffset.getValue()) {
            commitReceived.set(false);
            return false;
          }
        }
        return true;
      }
    }
,offsetCommitResponse(response),coordinator);
    return commitReceived;
  }
  private AtomicBoolean prepareOffsetCommitResponse(  MockClient client,  Node coordinator,  final TopicPartition partition,  final long offset){
    return prepareOffsetCommitResponse(client,coordinator,Collections.singletonMap(partition,offset));
  }
  private OffsetCommitResponse offsetCommitResponse(  Map<TopicPartition,Errors> responseData){
    return new OffsetCommitResponse(responseData);
  }
  private JoinGroupResponse joinGroupFollowerResponse(  PartitionAssignor assignor,  int generationId,  String memberId,  String leaderId,  Errors error){
    return new JoinGroupResponse(error,generationId,assignor.name(),memberId,leaderId,Collections.<String,ByteBuffer>emptyMap());
  }
  private SyncGroupResponse syncGroupResponse(  List<TopicPartition> partitions,  Errors error){
    ByteBuffer buf=ConsumerProtocol.serializeAssignment(new PartitionAssignor.Assignment(partitions));
    return new SyncGroupResponse(error,buf);
  }
  private OffsetFetchResponse offsetResponse(  Map<TopicPartition,Long> offsets,  Errors error){
    Map<TopicPartition,OffsetFetchResponse.PartitionData> partitionData=new HashMap<>();
    for (    Map.Entry<TopicPartition,Long> entry : offsets.entrySet()) {
      partitionData.put(entry.getKey(),new OffsetFetchResponse.PartitionData(entry.getValue(),"",error));
    }
    return new OffsetFetchResponse(Errors.NONE,partitionData);
  }
  private ListOffsetResponse listOffsetsResponse(  Map<TopicPartition,Long> offsets){
    return listOffsetsResponse(offsets,Collections.<TopicPartition,Errors>emptyMap());
  }
  private ListOffsetResponse listOffsetsResponse(  Map<TopicPartition,Long> partitionOffsets,  Map<TopicPartition,Errors> partitionErrors){
    Map<TopicPartition,ListOffsetResponse.PartitionData> partitionData=new HashMap<>();
    for (    Map.Entry<TopicPartition,Long> partitionOffset : partitionOffsets.entrySet()) {
      partitionData.put(partitionOffset.getKey(),new ListOffsetResponse.PartitionData(Errors.NONE,ListOffsetResponse.UNKNOWN_TIMESTAMP,partitionOffset.getValue()));
    }
    for (    Map.Entry<TopicPartition,Errors> partitionError : partitionErrors.entrySet()) {
      partitionData.put(partitionError.getKey(),new ListOffsetResponse.PartitionData(partitionError.getValue(),ListOffsetResponse.UNKNOWN_TIMESTAMP,ListOffsetResponse.UNKNOWN_OFFSET));
    }
    return new ListOffsetResponse(partitionData);
  }
  private FetchResponse fetchResponse(  Map<TopicPartition,FetchInfo> fetches){
    LinkedHashMap<TopicPartition,PartitionData> tpResponses=new LinkedHashMap<>();
    for (    Map.Entry<TopicPartition,FetchInfo> fetchEntry : fetches.entrySet()) {
      TopicPartition partition=fetchEntry.getKey();
      long fetchOffset=fetchEntry.getValue().offset;
      int fetchCount=fetchEntry.getValue().count;
      final MemoryRecords records;
      if (fetchCount == 0) {
        records=MemoryRecords.EMPTY;
      }
 else {
        MemoryRecordsBuilder builder=MemoryRecords.builder(ByteBuffer.allocate(1024),CompressionType.NONE,TimestampType.CREATE_TIME,fetchOffset);
        for (int i=0; i < fetchCount; i++)         builder.append(0L,("key-" + i).getBytes(),("value-" + i).getBytes());
        records=builder.build();
      }
      tpResponses.put(partition,new FetchResponse.PartitionData(Errors.NONE,0,FetchResponse.INVALID_LAST_STABLE_OFFSET,0L,null,records));
    }
    return new FetchResponse(Errors.NONE,tpResponses,0,INVALID_SESSION_ID);
  }
  private FetchResponse fetchResponse(  TopicPartition partition,  long fetchOffset,  int count){
    FetchInfo fetchInfo=new FetchInfo(fetchOffset,count);
    return fetchResponse(Collections.singletonMap(partition,fetchInfo));
  }
  private KafkaConsumer<String,String> newConsumer(  Time time,  KafkaClient client,  Metadata metadata,  PartitionAssignor assignor,  boolean autoCommitEnabled){
    return newConsumer(time,client,metadata,assignor,OffsetResetStrategy.EARLIEST,autoCommitEnabled);
  }
  private KafkaConsumer<String,String> newConsumerNoAutoCommit(  Time time,  KafkaClient client,  Metadata metadata){
    return newConsumer(time,client,metadata,new RangeAssignor(),OffsetResetStrategy.EARLIEST,false);
  }
  private KafkaConsumer<String,String> newConsumer(  Time time,  KafkaClient client,  Metadata metadata,  PartitionAssignor assignor,  OffsetResetStrategy resetStrategy,  boolean autoCommitEnabled){
    String clientId="mock-consumer";
    String groupId="mock-group";
    String metricGroupPrefix="consumer";
    long retryBackoffMs=100;
    long requestTimeoutMs=30000;
    boolean excludeInternalTopics=true;
    int minBytes=1;
    int maxBytes=Integer.MAX_VALUE;
    int maxWaitMs=500;
    int fetchSize=1024 * 1024;
    int maxPollRecords=Integer.MAX_VALUE;
    boolean checkCrcs=true;
    int rebalanceTimeoutMs=60000;
    Deserializer<String> keyDeserializer=new StringDeserializer();
    Deserializer<String> valueDeserializer=new StringDeserializer();
    List<PartitionAssignor> assignors=singletonList(assignor);
    ConsumerInterceptors<String,String> interceptors=new ConsumerInterceptors<>(Collections.<ConsumerInterceptor<String,String>>emptyList());
    Metrics metrics=new Metrics();
    ConsumerMetrics metricsRegistry=new ConsumerMetrics(metricGroupPrefix);
    SubscriptionState subscriptions=new SubscriptionState(resetStrategy);
    LogContext loggerFactory=new LogContext();
    ConsumerNetworkClient consumerClient=new ConsumerNetworkClient(loggerFactory,client,metadata,time,retryBackoffMs,requestTimeoutMs,heartbeatIntervalMs);
    ConsumerCoordinator consumerCoordinator=new ConsumerCoordinator(loggerFactory,consumerClient,groupId,rebalanceTimeoutMs,sessionTimeoutMs,heartbeatIntervalMs,assignors,metadata,subscriptions,metrics,metricGroupPrefix,time,retryBackoffMs,autoCommitEnabled,autoCommitIntervalMs,interceptors,excludeInternalTopics,true);
    Fetcher<String,String> fetcher=new Fetcher<>(loggerFactory,consumerClient,minBytes,maxBytes,maxWaitMs,fetchSize,maxPollRecords,checkCrcs,keyDeserializer,valueDeserializer,metadata,subscriptions,metrics,metricsRegistry.fetcherMetrics,time,retryBackoffMs,requestTimeoutMs,IsolationLevel.READ_UNCOMMITTED);
    return new KafkaConsumer<>(loggerFactory,clientId,consumerCoordinator,keyDeserializer,valueDeserializer,fetcher,interceptors,time,consumerClient,metrics,subscriptions,metadata,retryBackoffMs,requestTimeoutMs,assignors);
  }
private static class FetchInfo {
    long offset;
    int count;
    FetchInfo(    long offset,    int count){
      this.offset=offset;
      this.count=count;
    }
  }
}
