static class CopartitionedTopicsValidator {
  private final String logPrefix;
  private final Logger log;
  CopartitionedTopicsValidator(  final String logPrefix){
    this.logPrefix=logPrefix;
    final LogContext logContext=new LogContext(logPrefix);
    log=logContext.logger(getClass());
  }
  void validate(  final Set<String> copartitionGroup,  final Map<String,InternalTopicMetadata> allRepartitionTopicsNumPartitions,  final Cluster metadata){
    int numPartitions=UNKNOWN;
    for (    final String topic : copartitionGroup) {
      if (!allRepartitionTopicsNumPartitions.containsKey(topic)) {
        final Integer partitions=metadata.partitionCountForTopic(topic);
        if (partitions == null) {
          final String str=String.format("%sTopic not found: %s",logPrefix,topic);
          log.error(str);
          throw new IllegalStateException(str);
        }
        if (numPartitions == UNKNOWN) {
          numPartitions=partitions;
        }
 else         if (numPartitions != partitions) {
          final String[] topics=copartitionGroup.toArray(new String[copartitionGroup.size()]);
          Arrays.sort(topics);
          throw new org.apache.kafka.streams.errors.TopologyException(String.format("%sTopics not co-partitioned: [%s]",logPrefix,Utils.join(Arrays.asList(topics),",")));
        }
      }
    }
    if (numPartitions == UNKNOWN) {
      for (      final Map.Entry<String,InternalTopicMetadata> entry : allRepartitionTopicsNumPartitions.entrySet()) {
        if (copartitionGroup.contains(entry.getKey())) {
          final int partitions=entry.getValue().numPartitions;
          if (partitions > numPartitions) {
            numPartitions=partitions;
          }
        }
      }
    }
    for (    final Map.Entry<String,InternalTopicMetadata> entry : allRepartitionTopicsNumPartitions.entrySet()) {
      if (copartitionGroup.contains(entry.getKey())) {
        entry.getValue().numPartitions=numPartitions;
      }
    }
  }
}
