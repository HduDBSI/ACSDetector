interface KeySchema {
  /** 
 * Initialized the schema with a topic.
 * @param topic a topic name
 */
  void init(  final String topic);
  /** 
 * Given a record-key and a time, construct a Segmented key that represents the upper range of keys to search when performing range queries.
 * @see SessionKeySchema#upperRange
 * @see WindowStoreKeySchema#upperRange
 * @param key
 * @param to
 * @return      The key that represents the upper range to search for in the store
 */
  Bytes upperRange(  final Bytes key,  final long to);
  /** 
 * Given a record-key and a time, construct a Segmented key that represents the lower range of keys to search when performing range queries.
 * @see SessionKeySchema#lowerRange
 * @see WindowStoreKeySchema#lowerRange
 * @param key
 * @param from
 * @return      The key that represents the lower range to search for in the store
 */
  Bytes lowerRange(  final Bytes key,  final long from);
  /** 
 * Extract the timestamp of the segment from the key. The key is a composite of the record-key, any timestamps, plus any additional information.
 * @see SessionKeySchema#lowerRange
 * @see WindowStoreKeySchema#lowerRange
 * @param key
 * @return
 */
  long segmentTimestamp(  final Bytes key);
  /** 
 * Create an implementation of  {@link HasNextCondition} that knows whento stop iterating over the Segments. Used during  {@link SegmentedBytesStore#fetch(Bytes,long,long)} operations
 * @param binaryKey     the record-key
 * @param from          starting time range
 * @param to            ending time range
 * @return
 */
  HasNextCondition hasNextCondition(  final Bytes binaryKey,  long from,  long to);
  /** 
 * Used during  {@link SegmentedBytesStore#fetch(Bytes,long,long)} operations to determinewhich segments should be scanned.
 * @param segments
 * @param from
 * @param to
 * @return  List of segments to search
 */
  List<Segment> segmentsToSearch(  Segments segments,  long from,  long to);
}
