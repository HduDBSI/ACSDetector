private static class OffsetCommitCompletion {
  private final OffsetCommitCallback callback;
  private final Map<TopicPartition,OffsetAndMetadata> offsets;
  private final Exception exception;
  private OffsetCommitCompletion(  OffsetCommitCallback callback,  Map<TopicPartition,OffsetAndMetadata> offsets,  Exception exception){
    this.callback=callback;
    this.offsets=offsets;
    this.exception=exception;
  }
  public void invoke(){
    if (callback != null)     callback.onComplete(offsets,exception);
  }
}
