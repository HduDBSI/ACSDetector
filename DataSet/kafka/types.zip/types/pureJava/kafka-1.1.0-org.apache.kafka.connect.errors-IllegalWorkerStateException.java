/** 
 * Indicates that a method has been invoked illegally or at an invalid time by a connector or task.
 */
public class IllegalWorkerStateException extends ConnectException {
  public IllegalWorkerStateException(  String s){
    super(s);
  }
  public IllegalWorkerStateException(  String s,  Throwable throwable){
    super(s,throwable);
  }
  public IllegalWorkerStateException(  Throwable throwable){
    super(throwable);
  }
}
