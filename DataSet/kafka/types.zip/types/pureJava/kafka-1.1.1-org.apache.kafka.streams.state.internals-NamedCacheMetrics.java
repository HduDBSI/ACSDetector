class NamedCacheMetrics {
  final StreamsMetricsImpl metrics;
  final String groupName;
  final Map<String,String> metricTags;
  final Map<String,String> allMetricTags;
  final Sensor hitRatioSensor;
  public NamedCacheMetrics(  StreamsMetrics metrics){
    final String scope="record-cache";
    final String opName="hitRatio";
    final String tagKey=scope + "-id";
    final String tagValue=ThreadCache.underlyingStoreNamefromCacheName(name);
    this.groupName="stream-" + scope + "-metrics";
    this.metrics=(StreamsMetricsImpl)metrics;
    this.allMetricTags=((StreamsMetricsImpl)metrics).tagMap(tagKey,"all","task-id",ThreadCache.taskIDfromCacheName(name));
    this.metricTags=((StreamsMetricsImpl)metrics).tagMap(tagKey,tagValue,"task-id",ThreadCache.taskIDfromCacheName(name));
    Sensor parent=this.metrics.registry().sensor(opName,Sensor.RecordingLevel.DEBUG);
    ((StreamsMetricsImpl)metrics).maybeAddMetric(parent,this.metrics.registry().metricName(opName + "-avg",groupName,"The average cache hit ratio.",allMetricTags),new Avg());
    ((StreamsMetricsImpl)metrics).maybeAddMetric(parent,this.metrics.registry().metricName(opName + "-min",groupName,"The minimum cache hit ratio.",allMetricTags),new Min());
    ((StreamsMetricsImpl)metrics).maybeAddMetric(parent,this.metrics.registry().metricName(opName + "-max",groupName,"The maximum cache hit ratio.",allMetricTags),new Max());
    hitRatioSensor=this.metrics.registry().sensor(opName,Sensor.RecordingLevel.DEBUG,parent);
    ((StreamsMetricsImpl)metrics).maybeAddMetric(hitRatioSensor,this.metrics.registry().metricName(opName + "-avg",groupName,"The average cache hit ratio.",metricTags),new Avg());
    ((StreamsMetricsImpl)metrics).maybeAddMetric(hitRatioSensor,this.metrics.registry().metricName(opName + "-min",groupName,"The minimum cache hit ratio.",metricTags),new Min());
    ((StreamsMetricsImpl)metrics).maybeAddMetric(hitRatioSensor,this.metrics.registry().metricName(opName + "-max",groupName,"The maximum cache hit ratio.",metricTags),new Max());
  }
  public void removeAllSensors(){
    metrics.removeSensor(hitRatioSensor);
  }
}
