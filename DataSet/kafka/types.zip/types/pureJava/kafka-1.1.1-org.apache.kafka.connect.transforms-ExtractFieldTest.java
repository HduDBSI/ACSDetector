public class ExtractFieldTest {
  private final ExtractField<SinkRecord> xform=new ExtractField.Key<>();
  @After public void teardown(){
    xform.close();
  }
  @Test public void schemaless(){
    xform.configure(Collections.singletonMap("field","magic"));
    final SinkRecord record=new SinkRecord("test",0,null,Collections.singletonMap("magic",42),null,null,0);
    final SinkRecord transformedRecord=xform.apply(record);
    assertNull(transformedRecord.keySchema());
    assertEquals(42,transformedRecord.key());
  }
  @Test public void testNullSchemaless(){
    xform.configure(Collections.singletonMap("field","magic"));
    final Map<String,Object> key=null;
    final SinkRecord record=new SinkRecord("test",0,null,key,null,null,0);
    final SinkRecord transformedRecord=xform.apply(record);
    assertNull(transformedRecord.keySchema());
    assertNull(transformedRecord.key());
  }
  @Test public void withSchema(){
    xform.configure(Collections.singletonMap("field","magic"));
    final Schema keySchema=SchemaBuilder.struct().field("magic",Schema.INT32_SCHEMA).build();
    final Struct key=new Struct(keySchema).put("magic",42);
    final SinkRecord record=new SinkRecord("test",0,keySchema,key,null,null,0);
    final SinkRecord transformedRecord=xform.apply(record);
    assertEquals(Schema.INT32_SCHEMA,transformedRecord.keySchema());
    assertEquals(42,transformedRecord.key());
  }
  @Test public void testNullWithSchema(){
    xform.configure(Collections.singletonMap("field","magic"));
    final Schema keySchema=SchemaBuilder.struct().field("magic",Schema.INT32_SCHEMA).optional().build();
    final Struct key=null;
    final SinkRecord record=new SinkRecord("test",0,keySchema,key,null,null,0);
    final SinkRecord transformedRecord=xform.apply(record);
    assertEquals(Schema.INT32_SCHEMA,transformedRecord.keySchema());
    assertNull(transformedRecord.key());
  }
}
