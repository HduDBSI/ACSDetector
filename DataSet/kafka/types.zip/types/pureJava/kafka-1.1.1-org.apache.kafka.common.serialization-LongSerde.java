static public final class LongSerde extends WrapperSerde<Long> {
  public LongSerde(){
    super(new LongSerializer(),new LongDeserializer());
  }
}
