/** 
 * Used for testing the assignment of a subset of a topology group, not the entire topology
 */
public class SingleGroupPartitionGrouperStub implements PartitionGrouper {
  private PartitionGrouper defaultPartitionGrouper=new DefaultPartitionGrouper();
  @Override public Map<TaskId,Set<TopicPartition>> partitionGroups(  final Map<Integer,Set<String>> topicGroups,  final Cluster metadata){
    final Map<Integer,Set<String>> includedTopicGroups=new HashMap<>();
    for (    final Map.Entry<Integer,Set<String>> entry : topicGroups.entrySet()) {
      includedTopicGroups.put(entry.getKey(),entry.getValue());
      break;
    }
    final Map<TaskId,Set<TopicPartition>> result=defaultPartitionGrouper.partitionGroups(includedTopicGroups,metadata);
    return result;
  }
}
