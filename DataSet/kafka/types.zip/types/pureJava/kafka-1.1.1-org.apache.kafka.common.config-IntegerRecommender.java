private static class IntegerRecommender implements ConfigDef.Recommender {
  private boolean hasParent;
  public IntegerRecommender(  boolean hasParent){
    this.hasParent=hasParent;
  }
  @Override public List<Object> validValues(  String name,  Map<String,Object> parsedConfig){
    List<Object> values=new LinkedList<>();
    if (!hasParent) {
      values.addAll(Arrays.asList(1,2,3));
    }
 else {
      values.addAll(Arrays.asList(4,5));
    }
    return values;
  }
  @Override public boolean visible(  String name,  Map<String,Object> parsedConfig){
    return true;
  }
}
