static class TheSourceNode extends SourceNode {
  private final boolean keyThrowsException;
  private final boolean valueThrowsException;
  private final Object key;
  private final Object value;
  TheSourceNode(  final boolean keyThrowsException,  final boolean valueThrowsException){
    this(keyThrowsException,valueThrowsException,null,null);
  }
  @SuppressWarnings("unchecked") TheSourceNode(  final boolean keyThrowsException,  final boolean valueThrowsException,  final Object key,  final Object value){
    super("",Collections.EMPTY_LIST,null,null);
    this.keyThrowsException=keyThrowsException;
    this.valueThrowsException=valueThrowsException;
    this.key=key;
    this.value=value;
  }
  @Override public Object deserializeKey(  final String topic,  final Headers headers,  final byte[] data){
    if (keyThrowsException) {
      throw new RuntimeException();
    }
    return key;
  }
  @Override public Object deserializeValue(  final String topic,  final Headers headers,  final byte[] data){
    if (valueThrowsException) {
      throw new RuntimeException();
    }
    return value;
  }
}
