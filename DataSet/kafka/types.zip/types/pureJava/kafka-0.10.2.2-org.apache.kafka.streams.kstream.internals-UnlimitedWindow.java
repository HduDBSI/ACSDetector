/** 
 * {@link UnlimitedWindow} is an "infinite" large window with a fixed (inclusive) start time.All windows of the same  {@link org.apache.kafka.streams.kstream.UnlimitedWindows window specification} will have thesame start time. To make the window size "infinite" end time is set to  {@link Long#MAX_VALUE}. <p> For time semantics, see  {@link org.apache.kafka.streams.processor.TimestampExtractor TimestampExtractor}.
 * @see TimeWindow
 * @see SessionWindow
 * @see org.apache.kafka.streams.kstream.UnlimitedWindows
 * @see org.apache.kafka.streams.processor.TimestampExtractor
 */
@InterfaceStability.Unstable public class UnlimitedWindow extends Window {
  /** 
 * Create a new window for the given start time (inclusive).
 * @param startMs the start timestamp of the window (inclusive)
 * @throws IllegalArgumentException if {@code start} is negative
 */
  public UnlimitedWindow(  final long startMs){
    super(startMs,Long.MAX_VALUE);
  }
  /** 
 * Returns  {@code true} if the given window is of the same type, because all unlimited windows overlap with eachother due to their infinite size.
 * @param other another window
 * @return {@code true}
 * @throws IllegalArgumentException if the {@code other} window has a different type than {@link this} window
 */
  @Override public boolean overlap(  final Window other){
    if (getClass() != other.getClass()) {
      throw new IllegalArgumentException("Cannot compare windows of different type. Other window has type " + other.getClass() + ".");
    }
    return true;
  }
}
