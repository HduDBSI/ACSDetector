/** 
 * ConnectorContext allows Connectors to proactively interact with the Kafka Connect runtime.
 */
@InterfaceStability.Unstable public interface ConnectorContext {
  /** 
 * Requests that the runtime reconfigure the Tasks for this source. This should be used to indicate to the runtime that something about the input/output has changed (e.g. partitions added/removed) and the running Tasks will need to be modified.
 */
  void requestTaskReconfiguration();
}
