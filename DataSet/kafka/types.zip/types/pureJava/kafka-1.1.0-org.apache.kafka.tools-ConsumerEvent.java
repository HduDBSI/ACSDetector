@JsonPropertyOrder({"timestamp","name"}) private static abstract class ConsumerEvent {
  private final long timestamp=System.currentTimeMillis();
  @JsonProperty public abstract String name();
  @JsonProperty public long timestamp(){
    return timestamp;
  }
}
