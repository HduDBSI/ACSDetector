public class AssignmentInfoTest {
  @Test public void testEncodeDecode(){
    List<TaskId> activeTasks=Arrays.asList(new TaskId(0,0),new TaskId(0,0),new TaskId(0,1),new TaskId(1,0));
    Map<TaskId,Set<TopicPartition>> standbyTasks=new HashMap<>();
    standbyTasks.put(new TaskId(1,1),Utils.mkSet(new TopicPartition("t1",1),new TopicPartition("t2",1)));
    standbyTasks.put(new TaskId(2,0),Utils.mkSet(new TopicPartition("t3",0),new TopicPartition("t3",0)));
    AssignmentInfo info=new AssignmentInfo(activeTasks,standbyTasks,new HashMap<HostInfo,Set<TopicPartition>>());
    AssignmentInfo decoded=AssignmentInfo.decode(info.encode());
    assertEquals(info,decoded);
  }
  @Test public void shouldDecodePreviousVersion() throws IOException {
    List<TaskId> activeTasks=Arrays.asList(new TaskId(0,0),new TaskId(0,0),new TaskId(0,1),new TaskId(1,0));
    Map<TaskId,Set<TopicPartition>> standbyTasks=new HashMap<>();
    standbyTasks.put(new TaskId(1,1),Utils.mkSet(new TopicPartition("t1",1),new TopicPartition("t2",1)));
    standbyTasks.put(new TaskId(2,0),Utils.mkSet(new TopicPartition("t3",0),new TopicPartition("t3",0)));
    final AssignmentInfo oldVersion=new AssignmentInfo(1,activeTasks,standbyTasks,null);
    final AssignmentInfo decoded=AssignmentInfo.decode(encodeV1(oldVersion));
    assertEquals(oldVersion.activeTasks,decoded.activeTasks);
    assertEquals(oldVersion.standbyTasks,decoded.standbyTasks);
    assertEquals(0,decoded.partitionsByHost.size());
    assertEquals(1,decoded.version);
  }
  /** 
 * This is a clone of what the V1 encoding did. The encode method has changed for V2 so it is impossible to test compatibility without having this
 */
  private ByteBuffer encodeV1(  AssignmentInfo oldVersion) throws IOException {
    ByteArrayOutputStream baos=new ByteArrayOutputStream();
    DataOutputStream out=new DataOutputStream(baos);
    out.writeInt(oldVersion.version);
    out.writeInt(oldVersion.activeTasks.size());
    for (    TaskId id : oldVersion.activeTasks) {
      id.writeTo(out);
    }
    out.writeInt(oldVersion.standbyTasks.size());
    for (    Map.Entry<TaskId,Set<TopicPartition>> entry : oldVersion.standbyTasks.entrySet()) {
      TaskId id=entry.getKey();
      id.writeTo(out);
      Set<TopicPartition> partitions=entry.getValue();
      out.writeInt(partitions.size());
      for (      TopicPartition partition : partitions) {
        out.writeUTF(partition.topic());
        out.writeInt(partition.partition());
      }
    }
    out.flush();
    out.close();
    return ByteBuffer.wrap(baos.toByteArray());
  }
}
