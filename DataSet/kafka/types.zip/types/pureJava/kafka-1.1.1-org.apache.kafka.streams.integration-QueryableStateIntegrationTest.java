@Category({IntegrationTest.class}) public class QueryableStateIntegrationTest {
  private static final int NUM_BROKERS=1;
  @ClassRule public static final EmbeddedKafkaCluster CLUSTER=new EmbeddedKafkaCluster(NUM_BROKERS);
  private static final int STREAM_THREE_PARTITIONS=4;
  private final MockTime mockTime=CLUSTER.time;
  private String streamOne="stream-one";
  private String streamTwo="stream-two";
  private String streamThree="stream-three";
  private String streamConcurrent="stream-concurrent";
  private String outputTopic="output";
  private String outputTopicConcurrent="output-concurrent";
  private String outputTopicConcurrentWindowed="output-concurrent-windowed";
  private String outputTopicThree="output-three";
  private static final long WINDOW_SIZE=TimeUnit.MILLISECONDS.convert(2,TimeUnit.DAYS);
  private static final int STREAM_TWO_PARTITIONS=2;
  private static final int NUM_REPLICAS=NUM_BROKERS;
  private Properties streamsConfiguration;
  private List<String> inputValues;
  private int numberOfWordsPerIteration=0;
  private Set<String> inputValuesKeys;
  private KafkaStreams kafkaStreams;
  private Comparator<KeyValue<String,String>> stringComparator;
  private Comparator<KeyValue<String,Long>> stringLongComparator;
  private static int testNo=0;
  private void createTopics() throws InterruptedException {
    streamOne=streamOne + "-" + testNo;
    streamConcurrent=streamConcurrent + "-" + testNo;
    streamThree=streamThree + "-" + testNo;
    outputTopic=outputTopic + "-" + testNo;
    outputTopicConcurrent=outputTopicConcurrent + "-" + testNo;
    outputTopicConcurrentWindowed=outputTopicConcurrentWindowed + "-" + testNo;
    outputTopicThree=outputTopicThree + "-" + testNo;
    streamTwo=streamTwo + "-" + testNo;
    CLUSTER.createTopics(streamOne,streamConcurrent);
    CLUSTER.createTopic(streamTwo,STREAM_TWO_PARTITIONS,NUM_REPLICAS);
    CLUSTER.createTopic(streamThree,STREAM_THREE_PARTITIONS,1);
    CLUSTER.createTopics(outputTopic,outputTopicConcurrent,outputTopicConcurrentWindowed,outputTopicThree);
  }
  @Before public void before() throws Exception {
    testNo++;
    createTopics();
    streamsConfiguration=new Properties();
    final String applicationId="queryable-state-" + testNo;
    streamsConfiguration.put(StreamsConfig.APPLICATION_ID_CONFIG,applicationId);
    streamsConfiguration.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG,CLUSTER.bootstrapServers());
    streamsConfiguration.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,"earliest");
    streamsConfiguration.put(StreamsConfig.STATE_DIR_CONFIG,TestUtils.tempDirectory("qs-test").getPath());
    streamsConfiguration.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG,Serdes.String().getClass());
    streamsConfiguration.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG,Serdes.String().getClass());
    streamsConfiguration.put(StreamsConfig.COMMIT_INTERVAL_MS_CONFIG,100);
    streamsConfiguration.put(IntegrationTestUtils.INTERNAL_LEAVE_GROUP_ON_CLOSE,true);
    stringComparator=new Comparator<KeyValue<String,String>>(){
      @Override public int compare(      final KeyValue<String,String> o1,      final KeyValue<String,String> o2){
        return o1.key.compareTo(o2.key);
      }
    }
;
    stringLongComparator=new Comparator<KeyValue<String,Long>>(){
      @Override public int compare(      final KeyValue<String,Long> o1,      final KeyValue<String,Long> o2){
        return o1.key.compareTo(o2.key);
      }
    }
;
    inputValues=Arrays.asList("hello world","all streams lead to kafka","streams","kafka streams","the cat in the hat","green eggs and ham","that sam i am","up the creek without a paddle","run forest run","a tank full of gas","eat sleep rave repeat","one jolly sailor","king of the world");
    inputValuesKeys=new HashSet<>();
    for (    final String sentence : inputValues) {
      final String[] words=sentence.split("\\W+");
      numberOfWordsPerIteration+=words.length;
      Collections.addAll(inputValuesKeys,words);
    }
  }
  @After public void shutdown() throws IOException {
    if (kafkaStreams != null) {
      kafkaStreams.close(30,TimeUnit.SECONDS);
    }
    IntegrationTestUtils.purgeLocalStreamsState(streamsConfiguration);
  }
  /** 
 * Creates a typical word count topology
 */
  private KafkaStreams createCountStream(  final String inputTopic,  final String outputTopic,  final String windowOutputTopic,  final String storeName,  final String windowStoreName,  final Properties streamsConfiguration){
    final StreamsBuilder builder=new StreamsBuilder();
    final Serde<String> stringSerde=Serdes.String();
    final KStream<String,String> textLines=builder.stream(inputTopic,Consumed.with(stringSerde,stringSerde));
    final KGroupedStream<String,String> groupedByWord=textLines.flatMapValues(new ValueMapper<String,Iterable<String>>(){
      @Override public Iterable<String> apply(      final String value){
        return Arrays.asList(value.toLowerCase(Locale.getDefault()).split("\\W+"));
      }
    }
).groupBy(MockMapper.<String,String>selectValueMapper());
    groupedByWord.count(Materialized.<String,Long,KeyValueStore<Bytes,byte[]>>as(storeName + "-" + inputTopic)).toStream().to(outputTopic,Produced.with(Serdes.String(),Serdes.Long()));
    groupedByWord.windowedBy(TimeWindows.of(WINDOW_SIZE)).count(Materialized.<String,Long,WindowStore<Bytes,byte[]>>as(windowStoreName + "-" + inputTopic)).toStream(new KeyValueMapper<Windowed<String>,Long,String>(){
      @Override public String apply(      final Windowed<String> key,      final Long value){
        return key.key();
      }
    }
).to(windowOutputTopic,Produced.with(Serdes.String(),Serdes.Long()));
    return new KafkaStreams(builder.build(),streamsConfiguration);
  }
private class StreamRunnable implements Runnable {
    private final KafkaStreams myStream;
    private boolean closed=false;
    private final KafkaStreamsTest.StateListenerStub stateListener=new KafkaStreamsTest.StateListenerStub();
    StreamRunnable(    final String inputTopic,    final String outputTopic,    final String outputTopicWindowed,    final String storeName,    final String windowStoreName,    final int queryPort){
      final Properties props=(Properties)streamsConfiguration.clone();
      props.put(StreamsConfig.APPLICATION_SERVER_CONFIG,"localhost:" + queryPort);
      myStream=createCountStream(inputTopic,outputTopic,outputTopicWindowed,storeName,windowStoreName,props);
      myStream.setStateListener(stateListener);
    }
    @Override public void run(){
      myStream.start();
    }
    public void close(){
      if (!closed) {
        myStream.close();
        closed=true;
      }
    }
    public boolean isClosed(){
      return closed;
    }
    public final KafkaStreams getStream(){
      return myStream;
    }
    final KafkaStreamsTest.StateListenerStub getStateListener(){
      return stateListener;
    }
  }
  private void verifyAllKVKeys(  final StreamRunnable[] streamRunnables,  final KafkaStreams streams,  final KafkaStreamsTest.StateListenerStub stateListenerStub,  final Set<String> keys,  final String storeName) throws InterruptedException {
    for (    final String key : keys) {
      TestUtils.waitForCondition(new TestCondition(){
        @Override public boolean conditionMet(){
          try {
            final StreamsMetadata metadata=streams.metadataForKey(storeName,key,new StringSerializer());
            if (metadata == null || metadata.equals(StreamsMetadata.NOT_AVAILABLE)) {
              return false;
            }
            final int index=metadata.hostInfo().port();
            final KafkaStreams streamsWithKey=streamRunnables[index].getStream();
            final ReadOnlyKeyValueStore<String,Long> store=streamsWithKey.store(storeName,QueryableStoreTypes.<String,Long>keyValueStore());
            return store != null && store.get(key) != null;
          }
 catch (          final IllegalStateException e) {
            return false;
          }
catch (          final InvalidStateStoreException e) {
            assertTrue(stateListenerStub.mapStates.get(KafkaStreams.State.REBALANCING) >= 1);
            return false;
          }
        }
      }
,120000,"waiting for metadata, store and value to be non null");
    }
  }
  private void verifyAllWindowedKeys(  final StreamRunnable[] streamRunnables,  final KafkaStreams streams,  final KafkaStreamsTest.StateListenerStub stateListenerStub,  final Set<String> keys,  final String storeName,  final Long from,  final Long to) throws InterruptedException {
    for (    final String key : keys) {
      TestUtils.waitForCondition(new TestCondition(){
        @Override public boolean conditionMet(){
          try {
            final StreamsMetadata metadata=streams.metadataForKey(storeName,key,new StringSerializer());
            if (metadata == null || metadata.equals(StreamsMetadata.NOT_AVAILABLE)) {
              return false;
            }
            final int index=metadata.hostInfo().port();
            final KafkaStreams streamsWithKey=streamRunnables[index].getStream();
            final ReadOnlyWindowStore<String,Long> store=streamsWithKey.store(storeName,QueryableStoreTypes.<String,Long>windowStore());
            return store != null && store.fetch(key,from,to) != null;
          }
 catch (          final IllegalStateException e) {
            return false;
          }
catch (          final InvalidStateStoreException e) {
            assertTrue(stateListenerStub.mapStates.get(KafkaStreams.State.REBALANCING) >= 1);
            return false;
          }
        }
      }
,120000,"waiting for metadata, store and value to be non null");
    }
  }
  @Test public void queryOnRebalance() throws InterruptedException {
    final int numThreads=STREAM_TWO_PARTITIONS;
    final StreamRunnable[] streamRunnables=new StreamRunnable[numThreads];
    final Thread[] streamThreads=new Thread[numThreads];
    final ProducerRunnable producerRunnable=new ProducerRunnable(streamThree,inputValues,1);
    producerRunnable.run();
    final String storeName="word-count-store";
    final String windowStoreName="windowed-word-count-store";
    for (int i=0; i < numThreads; i++) {
      streamRunnables[i]=new StreamRunnable(streamThree,outputTopicThree,outputTopicConcurrentWindowed,storeName,windowStoreName,i);
      streamThreads[i]=new Thread(streamRunnables[i]);
      streamThreads[i].start();
    }
    try {
      waitUntilAtLeastNumRecordProcessed(outputTopicThree,1);
      for (int i=0; i < numThreads; i++) {
        verifyAllKVKeys(streamRunnables,streamRunnables[i].getStream(),streamRunnables[i].getStateListener(),inputValuesKeys,storeName + "-" + streamThree);
        verifyAllWindowedKeys(streamRunnables,streamRunnables[i].getStream(),streamRunnables[i].getStateListener(),inputValuesKeys,windowStoreName + "-" + streamThree,0L,WINDOW_SIZE);
        assertEquals(streamRunnables[i].getStream().state(),KafkaStreams.State.RUNNING);
      }
      for (int i=1; i < numThreads; i++) {
        streamRunnables[i].close();
        streamThreads[i].interrupt();
        streamThreads[i].join();
      }
      verifyAllKVKeys(streamRunnables,streamRunnables[0].getStream(),streamRunnables[0].getStateListener(),inputValuesKeys,storeName + "-" + streamThree);
      verifyAllWindowedKeys(streamRunnables,streamRunnables[0].getStream(),streamRunnables[0].getStateListener(),inputValuesKeys,windowStoreName + "-" + streamThree,0L,WINDOW_SIZE);
      assertEquals(streamRunnables[0].getStream().state(),KafkaStreams.State.RUNNING);
    }
  finally {
      for (int i=0; i < numThreads; i++) {
        if (!streamRunnables[i].isClosed()) {
          streamRunnables[i].close();
          streamThreads[i].interrupt();
          streamThreads[i].join();
        }
      }
    }
  }
  @Test public void concurrentAccesses() throws InterruptedException {
    final int numIterations=500000;
    final String storeName="word-count-store";
    final String windowStoreName="windowed-word-count-store";
    final ProducerRunnable producerRunnable=new ProducerRunnable(streamConcurrent,inputValues,numIterations);
    final Thread producerThread=new Thread(producerRunnable);
    kafkaStreams=createCountStream(streamConcurrent,outputTopicConcurrent,outputTopicConcurrentWindowed,storeName,windowStoreName,streamsConfiguration);
    kafkaStreams.start();
    producerThread.start();
    try {
      waitUntilAtLeastNumRecordProcessed(outputTopicConcurrent,numberOfWordsPerIteration);
      waitUntilAtLeastNumRecordProcessed(outputTopicConcurrentWindowed,numberOfWordsPerIteration);
      final ReadOnlyKeyValueStore<String,Long> keyValueStore=kafkaStreams.store(storeName + "-" + streamConcurrent,QueryableStoreTypes.<String,Long>keyValueStore());
      final ReadOnlyWindowStore<String,Long> windowStore=kafkaStreams.store(windowStoreName + "-" + streamConcurrent,QueryableStoreTypes.<String,Long>windowStore());
      final Map<String,Long> expectedWindowState=new HashMap<>();
      final Map<String,Long> expectedCount=new HashMap<>();
      while (producerRunnable.getCurrIteration() < numIterations) {
        verifyGreaterOrEqual(inputValuesKeys.toArray(new String[inputValuesKeys.size()]),expectedWindowState,expectedCount,windowStore,keyValueStore,true);
      }
    }
  finally {
      producerRunnable.shutdown();
      producerThread.interrupt();
      producerThread.join();
    }
  }
  @Test public void shouldBeAbleToQueryStateWithZeroSizedCache() throws Exception {
    verifyCanQueryState(0);
  }
  @Test public void shouldBeAbleToQueryStateWithNonZeroSizedCache() throws Exception {
    verifyCanQueryState(10 * 1024 * 1024);
  }
  @Test public void shouldBeAbleToQueryFilterState() throws Exception {
    streamsConfiguration.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG,Serdes.String().getClass());
    streamsConfiguration.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG,Serdes.Long().getClass());
    final StreamsBuilder builder=new StreamsBuilder();
    final String[] keys={"hello","goodbye","welcome","go","kafka"};
    final Set<KeyValue<String,Long>> batch1=new HashSet<>(Arrays.asList(new KeyValue<>(keys[0],1L),new KeyValue<>(keys[1],1L),new KeyValue<>(keys[2],3L),new KeyValue<>(keys[3],5L),new KeyValue<>(keys[4],2L)));
    final Set<KeyValue<String,Long>> expectedBatch1=new HashSet<>(Collections.singleton(new KeyValue<>(keys[4],2L)));
    IntegrationTestUtils.produceKeyValuesSynchronously(streamOne,batch1,TestUtils.producerConfig(CLUSTER.bootstrapServers(),StringSerializer.class,LongSerializer.class,new Properties()),mockTime);
    final Predicate<String,Long> filterPredicate=new Predicate<String,Long>(){
      @Override public boolean test(      final String key,      final Long value){
        return key.contains("kafka");
      }
    }
;
    final KTable<String,Long> t1=builder.table(streamOne);
    final KTable<String,Long> t2=t1.filter(filterPredicate,Materialized.<String,Long,KeyValueStore<Bytes,byte[]>>as("queryFilter"));
    t1.filterNot(filterPredicate,Materialized.<String,Long,KeyValueStore<Bytes,byte[]>>as("queryFilterNot"));
    t2.toStream().to(outputTopic);
    kafkaStreams=new KafkaStreams(builder.build(),streamsConfiguration);
    kafkaStreams.start();
    waitUntilAtLeastNumRecordProcessed(outputTopic,2);
    final ReadOnlyKeyValueStore<String,Long> myFilterStore=kafkaStreams.store("queryFilter",QueryableStoreTypes.<String,Long>keyValueStore());
    final ReadOnlyKeyValueStore<String,Long> myFilterNotStore=kafkaStreams.store("queryFilterNot",QueryableStoreTypes.<String,Long>keyValueStore());
    for (    final KeyValue<String,Long> expectedEntry : expectedBatch1) {
      assertEquals(myFilterStore.get(expectedEntry.key),expectedEntry.value);
    }
    for (    final KeyValue<String,Long> batchEntry : batch1) {
      if (!expectedBatch1.contains(batchEntry)) {
        assertNull(myFilterStore.get(batchEntry.key));
      }
    }
    for (    final KeyValue<String,Long> expectedEntry : expectedBatch1) {
      assertNull(myFilterNotStore.get(expectedEntry.key));
    }
    for (    final KeyValue<String,Long> batchEntry : batch1) {
      if (!expectedBatch1.contains(batchEntry)) {
        assertEquals(myFilterNotStore.get(batchEntry.key),batchEntry.value);
      }
    }
  }
  @Test public void shouldBeAbleToQueryMapValuesState() throws Exception {
    streamsConfiguration.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG,Serdes.String().getClass());
    streamsConfiguration.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG,Serdes.String().getClass());
    final StreamsBuilder builder=new StreamsBuilder();
    final String[] keys={"hello","goodbye","welcome","go","kafka"};
    final Set<KeyValue<String,String>> batch1=new HashSet<>(Arrays.asList(new KeyValue<>(keys[0],"1"),new KeyValue<>(keys[1],"1"),new KeyValue<>(keys[2],"3"),new KeyValue<>(keys[3],"5"),new KeyValue<>(keys[4],"2")));
    IntegrationTestUtils.produceKeyValuesSynchronously(streamOne,batch1,TestUtils.producerConfig(CLUSTER.bootstrapServers(),StringSerializer.class,StringSerializer.class,new Properties()),mockTime);
    final KTable<String,String> t1=builder.table(streamOne);
    final KTable<String,Long> t2=t1.mapValues(new ValueMapper<String,Long>(){
      @Override public Long apply(      final String value){
        return Long.valueOf(value);
      }
    }
,Materialized.<String,Long,KeyValueStore<Bytes,byte[]>>as("queryMapValues").withValueSerde(Serdes.Long()));
    t2.toStream().to(outputTopic,Produced.with(Serdes.String(),Serdes.Long()));
    kafkaStreams=new KafkaStreams(builder.build(),streamsConfiguration);
    kafkaStreams.start();
    waitUntilAtLeastNumRecordProcessed(outputTopic,1);
    final ReadOnlyKeyValueStore<String,Long> myMapStore=kafkaStreams.store("queryMapValues",QueryableStoreTypes.<String,Long>keyValueStore());
    for (    final KeyValue<String,String> batchEntry : batch1) {
      assertEquals(myMapStore.get(batchEntry.key),Long.valueOf(batchEntry.value));
    }
  }
  @Test public void shouldBeAbleToQueryMapValuesAfterFilterState() throws Exception {
    streamsConfiguration.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG,Serdes.String().getClass());
    streamsConfiguration.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG,Serdes.String().getClass());
    final StreamsBuilder builder=new StreamsBuilder();
    final String[] keys={"hello","goodbye","welcome","go","kafka"};
    final Set<KeyValue<String,String>> batch1=new HashSet<>(Arrays.asList(new KeyValue<>(keys[0],"1"),new KeyValue<>(keys[1],"1"),new KeyValue<>(keys[2],"3"),new KeyValue<>(keys[3],"5"),new KeyValue<>(keys[4],"2")));
    final Set<KeyValue<String,Long>> expectedBatch1=new HashSet<>(Collections.singleton(new KeyValue<>(keys[4],2L)));
    IntegrationTestUtils.produceKeyValuesSynchronously(streamOne,batch1,TestUtils.producerConfig(CLUSTER.bootstrapServers(),StringSerializer.class,StringSerializer.class,new Properties()),mockTime);
    final Predicate<String,String> filterPredicate=new Predicate<String,String>(){
      @Override public boolean test(      final String key,      final String value){
        return key.contains("kafka");
      }
    }
;
    final KTable<String,String> t1=builder.table(streamOne);
    final KTable<String,String> t2=t1.filter(filterPredicate,Materialized.<String,String,KeyValueStore<Bytes,byte[]>>as("queryFilter"));
    final KTable<String,Long> t3=t2.mapValues(new ValueMapper<String,Long>(){
      @Override public Long apply(      final String value){
        return Long.valueOf(value);
      }
    }
,Materialized.<String,Long,KeyValueStore<Bytes,byte[]>>as("queryMapValues").withValueSerde(Serdes.Long()));
    t3.toStream().to(outputTopic,Produced.with(Serdes.String(),Serdes.Long()));
    kafkaStreams=new KafkaStreams(builder.build(),streamsConfiguration);
    kafkaStreams.start();
    waitUntilAtLeastNumRecordProcessed(outputTopic,1);
    final ReadOnlyKeyValueStore<String,Long> myMapStore=kafkaStreams.store("queryMapValues",QueryableStoreTypes.<String,Long>keyValueStore());
    for (    final KeyValue<String,Long> expectedEntry : expectedBatch1) {
      assertEquals(myMapStore.get(expectedEntry.key),expectedEntry.value);
    }
    for (    final KeyValue<String,String> batchEntry : batch1) {
      final KeyValue<String,Long> batchEntryMapValue=new KeyValue<>(batchEntry.key,Long.valueOf(batchEntry.value));
      if (!expectedBatch1.contains(batchEntryMapValue)) {
        assertNull(myMapStore.get(batchEntry.key));
      }
    }
  }
  private void verifyCanQueryState(  final int cacheSizeBytes) throws Exception {
    streamsConfiguration.put(StreamsConfig.CACHE_MAX_BYTES_BUFFERING_CONFIG,cacheSizeBytes);
    final StreamsBuilder builder=new StreamsBuilder();
    final String[] keys={"hello","goodbye","welcome","go","kafka"};
    final Set<KeyValue<String,String>> batch1=new TreeSet<>(stringComparator);
    batch1.addAll(Arrays.asList(new KeyValue<>(keys[0],"hello"),new KeyValue<>(keys[1],"goodbye"),new KeyValue<>(keys[2],"welcome"),new KeyValue<>(keys[3],"go"),new KeyValue<>(keys[4],"kafka")));
    final Set<KeyValue<String,Long>> expectedCount=new TreeSet<>(stringLongComparator);
    for (    final String key : keys) {
      expectedCount.add(new KeyValue<>(key,1L));
    }
    IntegrationTestUtils.produceKeyValuesSynchronously(streamOne,batch1,TestUtils.producerConfig(CLUSTER.bootstrapServers(),StringSerializer.class,StringSerializer.class,new Properties()),mockTime);
    final KStream<String,String> s1=builder.stream(streamOne);
    final String storeName="my-count";
    s1.groupByKey().count(Materialized.<String,Long,KeyValueStore<Bytes,byte[]>>as(storeName)).toStream().to(outputTopic,Produced.with(Serdes.String(),Serdes.Long()));
    final String windowStoreName="windowed-count";
    s1.groupByKey().windowedBy(TimeWindows.of(WINDOW_SIZE)).count(Materialized.<String,Long,WindowStore<Bytes,byte[]>>as(windowStoreName));
    kafkaStreams=new KafkaStreams(builder.build(),streamsConfiguration);
    kafkaStreams.start();
    waitUntilAtLeastNumRecordProcessed(outputTopic,1);
    final ReadOnlyKeyValueStore<String,Long> myCount=kafkaStreams.store(storeName,QueryableStoreTypes.<String,Long>keyValueStore());
    final ReadOnlyWindowStore<String,Long> windowStore=kafkaStreams.store(windowStoreName,QueryableStoreTypes.<String,Long>windowStore());
    verifyCanGetByKey(keys,expectedCount,expectedCount,windowStore,myCount);
    verifyRangeAndAll(expectedCount,myCount);
  }
  @Test public void shouldNotMakeStoreAvailableUntilAllStoresAvailable() throws Exception {
    final StreamsBuilder builder=new StreamsBuilder();
    final KStream<String,String> stream=builder.stream(streamThree);
    final String storeName="count-by-key";
    stream.groupByKey().count(Materialized.<String,Long,KeyValueStore<Bytes,byte[]>>as(storeName));
    kafkaStreams=new KafkaStreams(builder.build(),streamsConfiguration);
    kafkaStreams.start();
    final KeyValue<String,String> hello=KeyValue.pair("hello","hello");
    IntegrationTestUtils.produceKeyValuesSynchronously(streamThree,Arrays.asList(hello,hello,hello,hello,hello,hello,hello,hello),TestUtils.producerConfig(CLUSTER.bootstrapServers(),StringSerializer.class,StringSerializer.class,new Properties()),mockTime);
    final int maxWaitMs=30000;
    TestUtils.waitForCondition(new WaitForStore(storeName),maxWaitMs,"waiting for store " + storeName);
    final ReadOnlyKeyValueStore<String,Long> store=kafkaStreams.store(storeName,QueryableStoreTypes.<String,Long>keyValueStore());
    TestUtils.waitForCondition(new TestCondition(){
      @Override public boolean conditionMet(){
        return new Long(8).equals(store.get("hello"));
      }
    }
,maxWaitMs,"wait for count to be 8");
    kafkaStreams.close();
    kafkaStreams=new KafkaStreams(builder.build(),streamsConfiguration);
    kafkaStreams.start();
    TestUtils.waitForCondition(new TestCondition(){
      @Override public boolean conditionMet(){
        try {
          assertEquals(Long.valueOf(8L),kafkaStreams.store(storeName,QueryableStoreTypes.<String,Long>keyValueStore()).get("hello"));
          return true;
        }
 catch (        final InvalidStateStoreException ise) {
          return false;
        }
      }
    }
,maxWaitMs,"waiting for store " + storeName);
  }
private class WaitForStore implements TestCondition {
    private final String storeName;
    WaitForStore(    final String storeName){
      this.storeName=storeName;
    }
    @Override public boolean conditionMet(){
      try {
        kafkaStreams.store(storeName,QueryableStoreTypes.<String,Long>keyValueStore());
        return true;
      }
 catch (      final InvalidStateStoreException ise) {
        return false;
      }
    }
  }
  @Test public void shouldAllowToQueryAfterThreadDied() throws Exception {
    final AtomicBoolean beforeFailure=new AtomicBoolean(true);
    final AtomicBoolean failed=new AtomicBoolean(false);
    final String storeName="store";
    final StreamsBuilder builder=new StreamsBuilder();
    final KStream<String,String> input=builder.stream(streamOne);
    input.groupByKey().reduce(new Reducer<String>(){
      @Override public String apply(      final String value1,      final String value2){
        if (value1.length() > 1) {
          if (beforeFailure.compareAndSet(true,false)) {
            throw new RuntimeException("Injected test exception");
          }
        }
        return value1 + value2;
      }
    }
,Materialized.<String,String,KeyValueStore<Bytes,byte[]>>as(storeName)).toStream().to(outputTopic);
    streamsConfiguration.put(StreamsConfig.NUM_STREAM_THREADS_CONFIG,2);
    kafkaStreams=new KafkaStreams(builder.build(),streamsConfiguration);
    kafkaStreams.setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler(){
      @Override public void uncaughtException(      final Thread t,      final Throwable e){
        failed.set(true);
      }
    }
);
    kafkaStreams.start();
    IntegrationTestUtils.produceKeyValuesSynchronously(streamOne,Arrays.asList(KeyValue.pair("a","1"),KeyValue.pair("a","2"),KeyValue.pair("b","3"),KeyValue.pair("b","4")),TestUtils.producerConfig(CLUSTER.bootstrapServers(),StringSerializer.class,StringSerializer.class,new Properties()),mockTime);
    final int maxWaitMs=30000;
    TestUtils.waitForCondition(new WaitForStore(storeName),maxWaitMs,"waiting for store " + storeName);
    final ReadOnlyKeyValueStore<String,String> store=kafkaStreams.store(storeName,QueryableStoreTypes.<String,String>keyValueStore());
    TestUtils.waitForCondition(new TestCondition(){
      @Override public boolean conditionMet(){
        return "12".equals(store.get("a")) && "34".equals(store.get("b"));
      }
    }
,maxWaitMs,"wait for agg to be <a,12> and <b,34>");
    IntegrationTestUtils.produceKeyValuesSynchronously(streamOne,Collections.singleton(KeyValue.pair("a","5")),TestUtils.producerConfig(CLUSTER.bootstrapServers(),StringSerializer.class,StringSerializer.class,new Properties()),mockTime);
    TestUtils.waitForCondition(new TestCondition(){
      @Override public boolean conditionMet(){
        return failed.get();
      }
    }
,30000,"wait for thread to fail");
    TestUtils.waitForCondition(new WaitForStore(storeName),maxWaitMs,"waiting for store " + storeName);
    final ReadOnlyKeyValueStore<String,String> store2=kafkaStreams.store(storeName,QueryableStoreTypes.<String,String>keyValueStore());
    try {
      TestUtils.waitForCondition(new TestCondition(){
        @Override public boolean conditionMet(){
          return ("125".equals(store2.get("a")) || "1225".equals(store2.get("a")) || "12125".equals(store2.get("a"))) && ("34".equals(store2.get("b")) || "344".equals(store2.get("b")) || "3434".equals(store2.get("b")));
        }
      }
,maxWaitMs,"wait for agg to be <a,125>||<a,1225>||<a,12125> and <b,34>||<b,344>||<b,3434>");
    }
 catch (    final Throwable t) {
      throw new RuntimeException("Store content is a: " + store2.get("a") + "; b: "+ store2.get("b"),t);
    }
  }
  private void verifyRangeAndAll(  final Set<KeyValue<String,Long>> expectedCount,  final ReadOnlyKeyValueStore<String,Long> myCount){
    final Set<KeyValue<String,Long>> countRangeResults=new TreeSet<>(stringLongComparator);
    final Set<KeyValue<String,Long>> countAllResults=new TreeSet<>(stringLongComparator);
    final Set<KeyValue<String,Long>> expectedRangeResults=new TreeSet<>(stringLongComparator);
    expectedRangeResults.addAll(Arrays.asList(new KeyValue<>("hello",1L),new KeyValue<>("go",1L),new KeyValue<>("goodbye",1L),new KeyValue<>("kafka",1L)));
    try (final KeyValueIterator<String,Long> range=myCount.range("go","kafka")){
      while (range.hasNext()) {
        countRangeResults.add(range.next());
      }
    }
     try (final KeyValueIterator<String,Long> all=myCount.all()){
      while (all.hasNext()) {
        countAllResults.add(all.next());
      }
    }
     assertThat(countRangeResults,equalTo(expectedRangeResults));
    assertThat(countAllResults,equalTo(expectedCount));
  }
  private void verifyCanGetByKey(  final String[] keys,  final Set<KeyValue<String,Long>> expectedWindowState,  final Set<KeyValue<String,Long>> expectedCount,  final ReadOnlyWindowStore<String,Long> windowStore,  final ReadOnlyKeyValueStore<String,Long> myCount) throws InterruptedException {
    final Set<KeyValue<String,Long>> windowState=new TreeSet<>(stringLongComparator);
    final Set<KeyValue<String,Long>> countState=new TreeSet<>(stringLongComparator);
    final long timeout=System.currentTimeMillis() + 30000;
    while ((windowState.size() < keys.length || countState.size() < keys.length) && System.currentTimeMillis() < timeout) {
      Thread.sleep(10);
      for (      final String key : keys) {
        windowState.addAll(fetch(windowStore,key));
        final Long value=myCount.get(key);
        if (value != null) {
          countState.add(new KeyValue<>(key,value));
        }
      }
    }
    assertThat(windowState,equalTo(expectedWindowState));
    assertThat(countState,equalTo(expectedCount));
  }
  /** 
 * Verify that the new count is greater than or equal to the previous count. Note: this method changes the values in expectedWindowState and expectedCount
 * @param keys                  All the keys we ever expect to find
 * @param expectedWindowedCount Expected windowed count
 * @param expectedCount         Expected count
 * @param windowStore           Window Store
 * @param keyValueStore         Key-value store
 * @param failIfKeyNotFound     if true, tests fails if an expected key is not found in store. If false,the method merely inserts the new found key into the list of expected keys.
 */
  private void verifyGreaterOrEqual(  final String[] keys,  final Map<String,Long> expectedWindowedCount,  final Map<String,Long> expectedCount,  final ReadOnlyWindowStore<String,Long> windowStore,  final ReadOnlyKeyValueStore<String,Long> keyValueStore,  final boolean failIfKeyNotFound){
    final Map<String,Long> windowState=new HashMap<>();
    final Map<String,Long> countState=new HashMap<>();
    for (    final String key : keys) {
      final Map<String,Long> map=fetchMap(windowStore,key);
      if (map.equals(Collections.<String,Long>emptyMap()) && failIfKeyNotFound) {
        fail("Key in windowed-store not found " + key);
      }
      windowState.putAll(map);
      final Long value=keyValueStore.get(key);
      if (value != null) {
        countState.put(key,value);
      }
 else       if (failIfKeyNotFound) {
        fail("Key in key-value-store not found " + key);
      }
    }
    for (    final Map.Entry<String,Long> actualWindowStateEntry : windowState.entrySet()) {
      if (expectedWindowedCount.containsKey(actualWindowStateEntry.getKey())) {
        final Long expectedValue=expectedWindowedCount.get(actualWindowStateEntry.getKey());
        assertTrue(actualWindowStateEntry.getValue() >= expectedValue);
      }
      expectedWindowedCount.put(actualWindowStateEntry.getKey(),actualWindowStateEntry.getValue());
    }
    for (    final Map.Entry<String,Long> actualCountStateEntry : countState.entrySet()) {
      if (expectedCount.containsKey(actualCountStateEntry.getKey())) {
        final Long expectedValue=expectedCount.get(actualCountStateEntry.getKey());
        assertTrue(actualCountStateEntry.getValue() >= expectedValue);
      }
      expectedCount.put(actualCountStateEntry.getKey(),actualCountStateEntry.getValue());
    }
  }
  private void waitUntilAtLeastNumRecordProcessed(  final String topic,  final int numRecs) throws InterruptedException {
    final Properties config=new Properties();
    config.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,CLUSTER.bootstrapServers());
    config.setProperty(ConsumerConfig.GROUP_ID_CONFIG,"queryable-state-consumer");
    config.setProperty(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,"earliest");
    config.setProperty(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class.getName());
    config.setProperty(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,LongDeserializer.class.getName());
    IntegrationTestUtils.waitUntilMinValuesRecordsReceived(config,topic,numRecs,120 * 1000);
  }
  private Set<KeyValue<String,Long>> fetch(  final ReadOnlyWindowStore<String,Long> store,  final String key){
    final WindowStoreIterator<Long> fetch=store.fetch(key,0,System.currentTimeMillis());
    if (fetch.hasNext()) {
      final KeyValue<Long,Long> next=fetch.next();
      return Collections.singleton(KeyValue.pair(key,next.value));
    }
    return Collections.emptySet();
  }
  private Map<String,Long> fetchMap(  final ReadOnlyWindowStore<String,Long> store,  final String key){
    final WindowStoreIterator<Long> fetch=store.fetch(key,0,System.currentTimeMillis());
    if (fetch.hasNext()) {
      final KeyValue<Long,Long> next=fetch.next();
      return Collections.singletonMap(key,next.value);
    }
    return Collections.emptyMap();
  }
  /** 
 * A class that periodically produces records in a separate thread
 */
private class ProducerRunnable implements Runnable {
    private final String topic;
    private final List<String> inputValues;
    private final int numIterations;
    private int currIteration=0;
    boolean shutdown=false;
    ProducerRunnable(    final String topic,    final List<String> inputValues,    final int numIterations){
      this.topic=topic;
      this.inputValues=inputValues;
      this.numIterations=numIterations;
    }
    private synchronized void incrementIteration(){
      currIteration++;
    }
    synchronized int getCurrIteration(){
      return currIteration;
    }
    synchronized void shutdown(){
      shutdown=true;
    }
    @Override public void run(){
      final Properties producerConfig=new Properties();
      producerConfig.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,CLUSTER.bootstrapServers());
      producerConfig.put(ProducerConfig.ACKS_CONFIG,"all");
      producerConfig.put(ProducerConfig.RETRIES_CONFIG,10);
      producerConfig.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,StringSerializer.class);
      producerConfig.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,StringSerializer.class);
      try (final KafkaProducer<String,String> producer=new KafkaProducer<>(producerConfig,new StringSerializer(),new StringSerializer())){
        while (getCurrIteration() < numIterations && !shutdown) {
          for (          final String value : inputValues) {
            producer.send(new ProducerRecord<String,String>(topic,value));
          }
          incrementIteration();
        }
      }
     }
  }
}
