/** 
 * A callback called when producer request is complete. It in turn calls user-supplied callback (if given) and notifies producer interceptors about the request completion.
 */
private static class InterceptorCallback<K,V> implements Callback {
  private final Callback userCallback;
  private final ProducerInterceptors<K,V> interceptors;
  private final TopicPartition tp;
  private InterceptorCallback(  Callback userCallback,  ProducerInterceptors<K,V> interceptors,  TopicPartition tp){
    this.userCallback=userCallback;
    this.interceptors=interceptors;
    this.tp=tp;
  }
  public void onCompletion(  RecordMetadata metadata,  Exception exception){
    metadata=metadata != null ? metadata : new RecordMetadata(tp,-1,-1,RecordBatch.NO_TIMESTAMP,Long.valueOf(-1L),-1,-1);
    this.interceptors.onAcknowledgement(metadata,exception);
    if (this.userCallback != null)     this.userCallback.onCompletion(metadata,exception);
  }
}
