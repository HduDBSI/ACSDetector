public interface BinScheme {
  public int bins();
  public int toBin(  double value);
  public double fromBin(  int bin);
}
