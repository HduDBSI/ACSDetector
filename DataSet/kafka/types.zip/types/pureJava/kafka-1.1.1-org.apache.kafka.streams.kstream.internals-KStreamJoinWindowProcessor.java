private class KStreamJoinWindowProcessor extends AbstractProcessor<K,V> {
  private WindowStore<K,V> window;
  @SuppressWarnings("unchecked") @Override public void init(  ProcessorContext context){
    super.init(context);
    window=(WindowStore<K,V>)context.getStateStore(windowName);
  }
  @Override public void process(  K key,  V value){
    if (key != null) {
      context().forward(key,value);
      window.put(key,value);
    }
  }
}
