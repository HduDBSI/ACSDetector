public class MemoryStatusBackingStore implements StatusBackingStore {
  private final Table<String,Integer,TaskStatus> tasks;
  private final Map<String,ConnectorStatus> connectors;
  public MemoryStatusBackingStore(){
    this.tasks=new Table<>();
    this.connectors=new HashMap<>();
  }
  @Override public void configure(  WorkerConfig config){
  }
  @Override public void start(){
  }
  @Override public void stop(){
  }
  @Override public synchronized void put(  ConnectorStatus status){
    if (status.state() == ConnectorStatus.State.DESTROYED)     connectors.remove(status.id());
 else     connectors.put(status.id(),status);
  }
  @Override public synchronized void putSafe(  ConnectorStatus status){
    put(status);
  }
  @Override public synchronized void put(  TaskStatus status){
    if (status.state() == TaskStatus.State.DESTROYED)     tasks.remove(status.id().connector(),status.id().task());
 else     tasks.put(status.id().connector(),status.id().task(),status);
  }
  @Override public synchronized void putSafe(  TaskStatus status){
    put(status);
  }
  @Override public synchronized TaskStatus get(  ConnectorTaskId id){
    return tasks.get(id.connector(),id.task());
  }
  @Override public synchronized ConnectorStatus get(  String connector){
    return connectors.get(connector);
  }
  @Override public synchronized Collection<TaskStatus> getAll(  String connector){
    return new HashSet<>(tasks.row(connector).values());
  }
  @Override public synchronized Set<String> connectors(){
    return new HashSet<>(connectors.keySet());
  }
  @Override public void flush(){
  }
}
