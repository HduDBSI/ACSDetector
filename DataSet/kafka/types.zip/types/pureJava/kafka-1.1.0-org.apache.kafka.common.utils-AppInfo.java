public static class AppInfo implements AppInfoMBean {
  public AppInfo(){
    log.info("Kafka version : " + AppInfoParser.getVersion());
    log.info("Kafka commitId : " + AppInfoParser.getCommitId());
  }
  @Override public String getVersion(){
    return AppInfoParser.getVersion();
  }
  @Override public String getCommitId(){
    return AppInfoParser.getCommitId();
  }
}
