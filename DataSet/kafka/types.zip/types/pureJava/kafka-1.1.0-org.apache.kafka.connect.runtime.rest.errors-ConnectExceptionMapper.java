public class ConnectExceptionMapper implements ExceptionMapper<Exception> {
  private static final Logger log=LoggerFactory.getLogger(ConnectExceptionMapper.class);
  @Context private UriInfo uriInfo;
  @Override public Response toResponse(  Exception exception){
    log.debug("Uncaught exception in REST call to /{}",uriInfo.getPath(),exception);
    if (exception instanceof ConnectRestException) {
      ConnectRestException restException=(ConnectRestException)exception;
      return Response.status(restException.statusCode()).entity(new ErrorMessage(restException.errorCode(),restException.getMessage())).build();
    }
    if (exception instanceof NotFoundException) {
      return Response.status(Response.Status.NOT_FOUND).entity(new ErrorMessage(Response.Status.NOT_FOUND.getStatusCode(),exception.getMessage())).build();
    }
    if (exception instanceof AlreadyExistsException) {
      return Response.status(Response.Status.CONFLICT).entity(new ErrorMessage(Response.Status.CONFLICT.getStatusCode(),exception.getMessage())).build();
    }
    if (!log.isDebugEnabled()) {
      log.error("Uncaught exception in REST call to /{}",uriInfo.getPath(),exception);
    }
    final int statusCode;
    if (exception instanceof WebApplicationException) {
      Response.StatusType statusInfo=((WebApplicationException)exception).getResponse().getStatusInfo();
      statusCode=statusInfo.getStatusCode();
    }
 else {
      statusCode=Response.Status.INTERNAL_SERVER_ERROR.getStatusCode();
    }
    return Response.status(statusCode).entity(new ErrorMessage(statusCode,exception.getMessage())).build();
  }
}
