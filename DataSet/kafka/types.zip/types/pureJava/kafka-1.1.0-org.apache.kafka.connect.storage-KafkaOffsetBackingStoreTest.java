@RunWith(PowerMockRunner.class) @PrepareForTest(KafkaOffsetBackingStore.class) @PowerMockIgnore("javax.management.*") @SuppressWarnings("unchecked") public class KafkaOffsetBackingStoreTest {
  private static final String TOPIC="connect-offsets";
  private static final short TOPIC_PARTITIONS=2;
  private static final short TOPIC_REPLICATION_FACTOR=5;
  private static final Map<String,String> DEFAULT_PROPS=new HashMap<>();
  private static final DistributedConfig DEFAULT_DISTRIBUTED_CONFIG;
static {
    DEFAULT_PROPS.put(CommonClientConfigs.BOOTSTRAP_SERVERS_CONFIG,"broker1:9092,broker2:9093");
    DEFAULT_PROPS.put(DistributedConfig.OFFSET_STORAGE_TOPIC_CONFIG,TOPIC);
    DEFAULT_PROPS.put(DistributedConfig.OFFSET_STORAGE_REPLICATION_FACTOR_CONFIG,Short.toString(TOPIC_REPLICATION_FACTOR));
    DEFAULT_PROPS.put(DistributedConfig.OFFSET_STORAGE_PARTITIONS_CONFIG,Integer.toString(TOPIC_PARTITIONS));
    DEFAULT_PROPS.put(DistributedConfig.CONFIG_TOPIC_CONFIG,"connect-configs");
    DEFAULT_PROPS.put(DistributedConfig.CONFIG_STORAGE_REPLICATION_FACTOR_CONFIG,Short.toString(TOPIC_REPLICATION_FACTOR));
    DEFAULT_PROPS.put(DistributedConfig.GROUP_ID_CONFIG,"connect");
    DEFAULT_PROPS.put(DistributedConfig.STATUS_STORAGE_TOPIC_CONFIG,"status-topic");
    DEFAULT_PROPS.put(DistributedConfig.KEY_CONVERTER_CLASS_CONFIG,"org.apache.kafka.connect.json.JsonConverter");
    DEFAULT_PROPS.put(DistributedConfig.VALUE_CONVERTER_CLASS_CONFIG,"org.apache.kafka.connect.json.JsonConverter");
    DEFAULT_PROPS.put(DistributedConfig.INTERNAL_KEY_CONVERTER_CLASS_CONFIG,"org.apache.kafka.connect.json.JsonConverter");
    DEFAULT_PROPS.put(DistributedConfig.INTERNAL_VALUE_CONVERTER_CLASS_CONFIG,"org.apache.kafka.connect.json.JsonConverter");
    DEFAULT_DISTRIBUTED_CONFIG=new DistributedConfig(DEFAULT_PROPS);
  }
  private static final Map<ByteBuffer,ByteBuffer> FIRST_SET=new HashMap<>();
static {
    FIRST_SET.put(buffer("key"),buffer("value"));
    FIRST_SET.put(null,null);
  }
  private static final ByteBuffer TP0_KEY=buffer("TP0KEY");
  private static final ByteBuffer TP1_KEY=buffer("TP1KEY");
  private static final ByteBuffer TP2_KEY=buffer("TP2KEY");
  private static final ByteBuffer TP0_VALUE=buffer("VAL0");
  private static final ByteBuffer TP1_VALUE=buffer("VAL1");
  private static final ByteBuffer TP2_VALUE=buffer("VAL2");
  private static final ByteBuffer TP0_VALUE_NEW=buffer("VAL0_NEW");
  private static final ByteBuffer TP1_VALUE_NEW=buffer("VAL1_NEW");
  @Mock KafkaBasedLog<byte[],byte[]> storeLog;
  private KafkaOffsetBackingStore store;
  private Capture<String> capturedTopic=EasyMock.newCapture();
  private Capture<Map<String,Object>> capturedProducerProps=EasyMock.newCapture();
  private Capture<Map<String,Object>> capturedConsumerProps=EasyMock.newCapture();
  private Capture<Map<String,Object>> capturedAdminProps=EasyMock.newCapture();
  private Capture<NewTopic> capturedNewTopic=EasyMock.newCapture();
  private Capture<Callback<ConsumerRecord<byte[],byte[]>>> capturedConsumedCallback=EasyMock.newCapture();
  @Before public void setUp() throws Exception {
    store=PowerMock.createPartialMockAndInvokeDefaultConstructor(KafkaOffsetBackingStore.class,new String[]{"createKafkaBasedLog"});
  }
  @Test public void testStartStop() throws Exception {
    expectConfigure();
    expectStart(Collections.EMPTY_LIST);
    expectStop();
    PowerMock.replayAll();
    store.configure(DEFAULT_DISTRIBUTED_CONFIG);
    assertEquals(TOPIC,capturedTopic.getValue());
    assertEquals("org.apache.kafka.common.serialization.ByteArraySerializer",capturedProducerProps.getValue().get(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG));
    assertEquals("org.apache.kafka.common.serialization.ByteArraySerializer",capturedProducerProps.getValue().get(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG));
    assertEquals("org.apache.kafka.common.serialization.ByteArrayDeserializer",capturedConsumerProps.getValue().get(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG));
    assertEquals("org.apache.kafka.common.serialization.ByteArrayDeserializer",capturedConsumerProps.getValue().get(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG));
    assertEquals(TOPIC,capturedNewTopic.getValue().name());
    assertEquals(TOPIC_PARTITIONS,capturedNewTopic.getValue().numPartitions());
    assertEquals(TOPIC_REPLICATION_FACTOR,capturedNewTopic.getValue().replicationFactor());
    store.start();
    store.stop();
    PowerMock.verifyAll();
  }
  @Test public void testReloadOnStart() throws Exception {
    expectConfigure();
    expectStart(Arrays.asList(new ConsumerRecord<>(TOPIC,0,0,0L,TimestampType.CREATE_TIME,0L,0,0,TP0_KEY.array(),TP0_VALUE.array()),new ConsumerRecord<>(TOPIC,1,0,0L,TimestampType.CREATE_TIME,0L,0,0,TP1_KEY.array(),TP1_VALUE.array()),new ConsumerRecord<>(TOPIC,0,1,0L,TimestampType.CREATE_TIME,0L,0,0,TP0_KEY.array(),TP0_VALUE_NEW.array()),new ConsumerRecord<>(TOPIC,1,1,0L,TimestampType.CREATE_TIME,0L,0,0,TP1_KEY.array(),TP1_VALUE_NEW.array())));
    expectStop();
    PowerMock.replayAll();
    store.configure(DEFAULT_DISTRIBUTED_CONFIG);
    store.start();
    HashMap<ByteBuffer,ByteBuffer> data=Whitebox.getInternalState(store,"data");
    assertEquals(TP0_VALUE_NEW,data.get(TP0_KEY));
    assertEquals(TP1_VALUE_NEW,data.get(TP1_KEY));
    store.stop();
    PowerMock.verifyAll();
  }
  @Test public void testGetSet() throws Exception {
    expectConfigure();
    expectStart(Collections.EMPTY_LIST);
    expectStop();
    final Capture<Callback<Void>> firstGetReadToEndCallback=EasyMock.newCapture();
    storeLog.readToEnd(EasyMock.capture(firstGetReadToEndCallback));
    PowerMock.expectLastCall().andAnswer(new IAnswer<Object>(){
      @Override public Object answer() throws Throwable {
        firstGetReadToEndCallback.getValue().onCompletion(null,null);
        return null;
      }
    }
);
    Capture<org.apache.kafka.clients.producer.Callback> callback0=EasyMock.newCapture();
    storeLog.send(EasyMock.aryEq(TP0_KEY.array()),EasyMock.aryEq(TP0_VALUE.array()),EasyMock.capture(callback0));
    PowerMock.expectLastCall();
    Capture<org.apache.kafka.clients.producer.Callback> callback1=EasyMock.newCapture();
    storeLog.send(EasyMock.aryEq(TP1_KEY.array()),EasyMock.aryEq(TP1_VALUE.array()),EasyMock.capture(callback1));
    PowerMock.expectLastCall();
    final Capture<Callback<Void>> secondGetReadToEndCallback=EasyMock.newCapture();
    storeLog.readToEnd(EasyMock.capture(secondGetReadToEndCallback));
    PowerMock.expectLastCall().andAnswer(new IAnswer<Object>(){
      @Override public Object answer() throws Throwable {
        capturedConsumedCallback.getValue().onCompletion(null,new ConsumerRecord<>(TOPIC,0,0,0L,TimestampType.CREATE_TIME,0L,0,0,TP0_KEY.array(),TP0_VALUE.array()));
        capturedConsumedCallback.getValue().onCompletion(null,new ConsumerRecord<>(TOPIC,1,0,0L,TimestampType.CREATE_TIME,0L,0,0,TP1_KEY.array(),TP1_VALUE.array()));
        secondGetReadToEndCallback.getValue().onCompletion(null,null);
        return null;
      }
    }
);
    final Capture<Callback<Void>> thirdGetReadToEndCallback=EasyMock.newCapture();
    storeLog.readToEnd(EasyMock.capture(thirdGetReadToEndCallback));
    PowerMock.expectLastCall().andAnswer(new IAnswer<Object>(){
      @Override public Object answer() throws Throwable {
        capturedConsumedCallback.getValue().onCompletion(null,new ConsumerRecord<>(TOPIC,0,1,0L,TimestampType.CREATE_TIME,0L,0,0,TP0_KEY.array(),TP0_VALUE_NEW.array()));
        capturedConsumedCallback.getValue().onCompletion(null,new ConsumerRecord<>(TOPIC,1,1,0L,TimestampType.CREATE_TIME,0L,0,0,TP1_KEY.array(),TP1_VALUE_NEW.array()));
        thirdGetReadToEndCallback.getValue().onCompletion(null,null);
        return null;
      }
    }
);
    PowerMock.replayAll();
    store.configure(DEFAULT_DISTRIBUTED_CONFIG);
    store.start();
    final AtomicBoolean getInvokedAndPassed=new AtomicBoolean(false);
    store.get(Arrays.asList(TP0_KEY,TP1_KEY),new Callback<Map<ByteBuffer,ByteBuffer>>(){
      @Override public void onCompletion(      Throwable error,      Map<ByteBuffer,ByteBuffer> result){
        assertEquals(null,result.get(TP0_KEY));
        assertEquals(null,result.get(TP1_KEY));
        getInvokedAndPassed.set(true);
      }
    }
).get(10000,TimeUnit.MILLISECONDS);
    assertTrue(getInvokedAndPassed.get());
    Map<ByteBuffer,ByteBuffer> toSet=new HashMap<>();
    toSet.put(TP0_KEY,TP0_VALUE);
    toSet.put(TP1_KEY,TP1_VALUE);
    final AtomicBoolean invoked=new AtomicBoolean(false);
    Future<Void> setFuture=store.set(toSet,new Callback<Void>(){
      @Override public void onCompletion(      Throwable error,      Void result){
        invoked.set(true);
      }
    }
);
    assertFalse(setFuture.isDone());
    callback1.getValue().onCompletion(null,null);
    assertFalse(invoked.get());
    callback0.getValue().onCompletion(null,null);
    setFuture.get(10000,TimeUnit.MILLISECONDS);
    assertTrue(invoked.get());
    final AtomicBoolean secondGetInvokedAndPassed=new AtomicBoolean(false);
    store.get(Arrays.asList(TP0_KEY,TP1_KEY),new Callback<Map<ByteBuffer,ByteBuffer>>(){
      @Override public void onCompletion(      Throwable error,      Map<ByteBuffer,ByteBuffer> result){
        assertEquals(TP0_VALUE,result.get(TP0_KEY));
        assertEquals(TP1_VALUE,result.get(TP1_KEY));
        secondGetInvokedAndPassed.set(true);
      }
    }
).get(10000,TimeUnit.MILLISECONDS);
    assertTrue(secondGetInvokedAndPassed.get());
    final AtomicBoolean thirdGetInvokedAndPassed=new AtomicBoolean(false);
    store.get(Arrays.asList(TP0_KEY,TP1_KEY),new Callback<Map<ByteBuffer,ByteBuffer>>(){
      @Override public void onCompletion(      Throwable error,      Map<ByteBuffer,ByteBuffer> result){
        assertEquals(TP0_VALUE_NEW,result.get(TP0_KEY));
        assertEquals(TP1_VALUE_NEW,result.get(TP1_KEY));
        thirdGetInvokedAndPassed.set(true);
      }
    }
).get(10000,TimeUnit.MILLISECONDS);
    assertTrue(thirdGetInvokedAndPassed.get());
    store.stop();
    PowerMock.verifyAll();
  }
  @Test public void testGetSetNull() throws Exception {
    expectConfigure();
    expectStart(Collections.EMPTY_LIST);
    Capture<org.apache.kafka.clients.producer.Callback> callback0=EasyMock.newCapture();
    storeLog.send(EasyMock.isNull(byte[].class),EasyMock.aryEq(TP0_VALUE.array()),EasyMock.capture(callback0));
    PowerMock.expectLastCall();
    Capture<org.apache.kafka.clients.producer.Callback> callback1=EasyMock.newCapture();
    storeLog.send(EasyMock.aryEq(TP1_KEY.array()),EasyMock.isNull(byte[].class),EasyMock.capture(callback1));
    PowerMock.expectLastCall();
    final Capture<Callback<Void>> secondGetReadToEndCallback=EasyMock.newCapture();
    storeLog.readToEnd(EasyMock.capture(secondGetReadToEndCallback));
    PowerMock.expectLastCall().andAnswer(new IAnswer<Object>(){
      @Override public Object answer() throws Throwable {
        capturedConsumedCallback.getValue().onCompletion(null,new ConsumerRecord<>(TOPIC,0,0,0L,TimestampType.CREATE_TIME,0L,0,0,(byte[])null,TP0_VALUE.array()));
        capturedConsumedCallback.getValue().onCompletion(null,new ConsumerRecord<>(TOPIC,1,0,0L,TimestampType.CREATE_TIME,0L,0,0,TP1_KEY.array(),(byte[])null));
        secondGetReadToEndCallback.getValue().onCompletion(null,null);
        return null;
      }
    }
);
    expectStop();
    PowerMock.replayAll();
    store.configure(DEFAULT_DISTRIBUTED_CONFIG);
    store.start();
    Map<ByteBuffer,ByteBuffer> toSet=new HashMap<>();
    toSet.put(null,TP0_VALUE);
    toSet.put(TP1_KEY,null);
    final AtomicBoolean invoked=new AtomicBoolean(false);
    Future<Void> setFuture=store.set(toSet,new Callback<Void>(){
      @Override public void onCompletion(      Throwable error,      Void result){
        invoked.set(true);
      }
    }
);
    assertFalse(setFuture.isDone());
    callback1.getValue().onCompletion(null,null);
    assertFalse(invoked.get());
    callback0.getValue().onCompletion(null,null);
    setFuture.get(10000,TimeUnit.MILLISECONDS);
    assertTrue(invoked.get());
    final AtomicBoolean secondGetInvokedAndPassed=new AtomicBoolean(false);
    store.get(Arrays.asList(null,TP1_KEY),new Callback<Map<ByteBuffer,ByteBuffer>>(){
      @Override public void onCompletion(      Throwable error,      Map<ByteBuffer,ByteBuffer> result){
        assertEquals(TP0_VALUE,result.get(null));
        assertNull(result.get(TP1_KEY));
        secondGetInvokedAndPassed.set(true);
      }
    }
).get(10000,TimeUnit.MILLISECONDS);
    assertTrue(secondGetInvokedAndPassed.get());
    store.stop();
    PowerMock.verifyAll();
  }
  @Test public void testSetFailure() throws Exception {
    expectConfigure();
    expectStart(Collections.EMPTY_LIST);
    expectStop();
    Capture<org.apache.kafka.clients.producer.Callback> callback0=EasyMock.newCapture();
    storeLog.send(EasyMock.aryEq(TP0_KEY.array()),EasyMock.aryEq(TP0_VALUE.array()),EasyMock.capture(callback0));
    PowerMock.expectLastCall();
    Capture<org.apache.kafka.clients.producer.Callback> callback1=EasyMock.newCapture();
    storeLog.send(EasyMock.aryEq(TP1_KEY.array()),EasyMock.aryEq(TP1_VALUE.array()),EasyMock.capture(callback1));
    PowerMock.expectLastCall();
    Capture<org.apache.kafka.clients.producer.Callback> callback2=EasyMock.newCapture();
    storeLog.send(EasyMock.aryEq(TP2_KEY.array()),EasyMock.aryEq(TP2_VALUE.array()),EasyMock.capture(callback2));
    PowerMock.expectLastCall();
    PowerMock.replayAll();
    store.configure(DEFAULT_DISTRIBUTED_CONFIG);
    store.start();
    Map<ByteBuffer,ByteBuffer> toSet=new HashMap<>();
    toSet.put(TP0_KEY,TP0_VALUE);
    toSet.put(TP1_KEY,TP1_VALUE);
    toSet.put(TP2_KEY,TP2_VALUE);
    final AtomicBoolean invoked=new AtomicBoolean(false);
    final AtomicBoolean invokedFailure=new AtomicBoolean(false);
    Future<Void> setFuture=store.set(toSet,new Callback<Void>(){
      @Override public void onCompletion(      Throwable error,      Void result){
        invoked.set(true);
        if (error != null)         invokedFailure.set(true);
      }
    }
);
    assertFalse(setFuture.isDone());
    callback1.getValue().onCompletion(null,null);
    assertFalse(invoked.get());
    callback2.getValue().onCompletion(null,new KafkaException("bogus error"));
    assertTrue(invoked.get());
    assertTrue(invokedFailure.get());
    callback0.getValue().onCompletion(null,null);
    try {
      setFuture.get(10000,TimeUnit.MILLISECONDS);
      fail("Should have seen KafkaException thrown when waiting on KafkaOffsetBackingStore.set() future");
    }
 catch (    ExecutionException e) {
      assertNotNull(e.getCause());
      assertTrue(e.getCause() instanceof KafkaException);
    }
    store.stop();
    PowerMock.verifyAll();
  }
  private void expectConfigure() throws Exception {
    PowerMock.expectPrivate(store,"createKafkaBasedLog",EasyMock.capture(capturedTopic),EasyMock.capture(capturedProducerProps),EasyMock.capture(capturedConsumerProps),EasyMock.capture(capturedConsumedCallback),EasyMock.capture(capturedNewTopic),EasyMock.capture(capturedAdminProps)).andReturn(storeLog);
  }
  private void expectStart(  final List<ConsumerRecord<byte[],byte[]>> preexistingRecords) throws Exception {
    storeLog.start();
    PowerMock.expectLastCall().andAnswer(new IAnswer<Object>(){
      @Override public Object answer() throws Throwable {
        for (        ConsumerRecord<byte[],byte[]> rec : preexistingRecords)         capturedConsumedCallback.getValue().onCompletion(null,rec);
        return null;
      }
    }
);
  }
  private void expectStop(){
    storeLog.stop();
    PowerMock.expectLastCall();
  }
  private static ByteBuffer buffer(  String v){
    return ByteBuffer.wrap(v.getBytes());
  }
}
