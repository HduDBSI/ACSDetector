/** 
 * A processor that stores each key-value pair in an in-memory key-value store registered with the context. When {@link #punctuate(long)} is called, it outputs the total number of entries in the store.
 */
protected static class StatefulProcessor extends AbstractProcessor<String,String> {
  private KeyValueStore<String,String> store;
  private final String storeName;
  public StatefulProcessor(  String storeName){
    this.storeName=storeName;
  }
  @Override @SuppressWarnings("unchecked") public void init(  ProcessorContext context){
    super.init(context);
    store=(KeyValueStore<String,String>)context.getStateStore(storeName);
  }
  @Override public void process(  String key,  String value){
    store.put(key,value);
  }
  @Override public void punctuate(  long streamTime){
    int count=0;
    try (KeyValueIterator<String,String> iter=store.all()){
      while (iter.hasNext()) {
        iter.next();
        ++count;
      }
    }
     context().forward(Long.toString(streamTime),count);
  }
  @Override public void close(){
    store.close();
  }
}
