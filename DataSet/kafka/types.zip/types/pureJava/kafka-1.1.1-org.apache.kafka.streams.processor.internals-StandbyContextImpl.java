class StandbyContextImpl extends AbstractProcessorContext implements RecordCollector.Supplier {
  private static final RecordCollector NO_OP_COLLECTOR=new RecordCollector(){
    @Override public <K,V>void send(    final String topic,    final K key,    final V value,    final Integer partition,    final Long timestamp,    final Serializer<K> keySerializer,    final Serializer<V> valueSerializer){
    }
    @Override public <K,V>void send(    final String topic,    final K key,    final V value,    final Long timestamp,    final Serializer<K> keySerializer,    final Serializer<V> valueSerializer,    final StreamPartitioner<? super K,? super V> partitioner){
    }
    @Override public void flush(){
    }
    @Override public void close(){
    }
    @Override public Map<TopicPartition,Long> offsets(){
      return Collections.emptyMap();
    }
  }
;
  StandbyContextImpl(  final TaskId id,  final StreamsConfig config,  final ProcessorStateManager stateMgr,  final StreamsMetrics metrics){
    super(id,config,metrics,stateMgr,new ThreadCache(new LogContext(String.format("stream-thread [%s] ",Thread.currentThread().getName())),0,metrics));
  }
  StateManager getStateMgr(){
    return stateManager;
  }
  @Override public RecordCollector recordCollector(){
    return NO_OP_COLLECTOR;
  }
  /** 
 * @throws UnsupportedOperationException on every invocation
 */
  @Override public StateStore getStateStore(  final String name){
    throw new UnsupportedOperationException("this should not happen: getStateStore() not supported in standby tasks.");
  }
  /** 
 * @throws UnsupportedOperationException on every invocation
 */
  @Override public String topic(){
    throw new UnsupportedOperationException("this should not happen: topic() not supported in standby tasks.");
  }
  /** 
 * @throws UnsupportedOperationException on every invocation
 */
  @Override public int partition(){
    throw new UnsupportedOperationException("this should not happen: partition() not supported in standby tasks.");
  }
  /** 
 * @throws UnsupportedOperationException on every invocation
 */
  @Override public long offset(){
    throw new UnsupportedOperationException("this should not happen: offset() not supported in standby tasks.");
  }
  /** 
 * @throws UnsupportedOperationException on every invocation
 */
  @Override public long timestamp(){
    throw new UnsupportedOperationException("this should not happen: timestamp() not supported in standby tasks.");
  }
  /** 
 * @throws UnsupportedOperationException on every invocation
 */
  @Override public <K,V>void forward(  final K key,  final V value){
    throw new UnsupportedOperationException("this should not happen: forward() not supported in standby tasks.");
  }
  /** 
 * @throws UnsupportedOperationException on every invocation
 */
  @Override public <K,V>void forward(  final K key,  final V value,  final int childIndex){
    throw new UnsupportedOperationException("this should not happen: forward() not supported in standby tasks.");
  }
  /** 
 * @throws UnsupportedOperationException on every invocation
 */
  @Override public <K,V>void forward(  final K key,  final V value,  final String childName){
    throw new UnsupportedOperationException("this should not happen: forward() not supported in standby tasks.");
  }
  /** 
 * @throws UnsupportedOperationException on every invocation
 */
  @Override public void commit(){
    throw new UnsupportedOperationException("this should not happen: commit() not supported in standby tasks.");
  }
  /** 
 * @throws UnsupportedOperationException on every invocation
 */
  @Override public Cancellable schedule(  long interval,  PunctuationType type,  Punctuator callback){
    throw new UnsupportedOperationException("this should not happen: schedule() not supported in standby tasks.");
  }
  /** 
 * @throws UnsupportedOperationException on every invocation
 */
  @Override @Deprecated public void schedule(  final long interval){
    throw new UnsupportedOperationException("this should not happen: schedule() not supported in standby tasks.");
  }
  /** 
 * @throws UnsupportedOperationException on every invocation
 */
  @Override public RecordContext recordContext(){
    throw new UnsupportedOperationException("this should not happen: recordContext not supported in standby tasks.");
  }
  /** 
 * @throws UnsupportedOperationException on every invocation
 */
  @Override public void setRecordContext(  final RecordContext recordContext){
    throw new UnsupportedOperationException("this should not happen: setRecordContext not supported in standby tasks.");
  }
  @Override public void setCurrentNode(  final ProcessorNode currentNode){
  }
  /** 
 * @throws UnsupportedOperationException on every invocation
 */
  @Override public ProcessorNode currentNode(){
    throw new UnsupportedOperationException("this should not happen: currentNode not supported in standby tasks.");
  }
}
