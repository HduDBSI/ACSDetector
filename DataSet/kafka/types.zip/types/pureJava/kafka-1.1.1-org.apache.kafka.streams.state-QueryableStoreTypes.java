/** 
 * Provides access to the  {@link QueryableStoreType}s provided with KafkaStreams. These can be used with  {@link org.apache.kafka.streams.KafkaStreams#store(String,QueryableStoreType)}To access and query the  {@link StateStore}s that are part of a Topology
 */
public class QueryableStoreTypes {
  /** 
 * A  {@link QueryableStoreType} that accepts {@link ReadOnlyKeyValueStore}
 * @param < K >   key type of the store
 * @param < V >   value type of the store
 * @return  {@link QueryableStoreTypes.KeyValueStoreType}
 */
  public static <K,V>QueryableStoreType<ReadOnlyKeyValueStore<K,V>> keyValueStore(){
    return new KeyValueStoreType<>();
  }
  /** 
 * A  {@link QueryableStoreType} that accepts {@link ReadOnlyWindowStore}
 * @param < K >   key type of the store
 * @param < V >   value type of the store
 * @return  {@link QueryableStoreTypes.WindowStoreType}
 */
  public static <K,V>QueryableStoreType<ReadOnlyWindowStore<K,V>> windowStore(){
    return new WindowStoreType<>();
  }
  /** 
 * A  {@link QueryableStoreType} that accepts {@link ReadOnlySessionStore}
 * @param < K >   key type of the store
 * @param < V >   value type of the store
 * @return  {@link QueryableStoreTypes.SessionStoreType}
 */
  public static <K,V>QueryableStoreType<ReadOnlySessionStore<K,V>> sessionStore(){
    return new SessionStoreType<>();
  }
private static abstract class QueryableStoreTypeMatcher<T> implements QueryableStoreType<T> {
    private final Class matchTo;
    QueryableStoreTypeMatcher(    Class matchTo){
      this.matchTo=matchTo;
    }
    @SuppressWarnings("unchecked") @Override public boolean accepts(    final StateStore stateStore){
      return matchTo.isAssignableFrom(stateStore.getClass());
    }
  }
private static class KeyValueStoreType<K,V> extends QueryableStoreTypeMatcher<ReadOnlyKeyValueStore<K,V>> {
    KeyValueStoreType(){
      super(ReadOnlyKeyValueStore.class);
    }
    @Override public ReadOnlyKeyValueStore<K,V> create(    final StateStoreProvider storeProvider,    final String storeName){
      return new CompositeReadOnlyKeyValueStore<>(storeProvider,this,storeName);
    }
  }
private static class WindowStoreType<K,V> extends QueryableStoreTypeMatcher<ReadOnlyWindowStore<K,V>> {
    WindowStoreType(){
      super(ReadOnlyWindowStore.class);
    }
    @Override public ReadOnlyWindowStore<K,V> create(    final StateStoreProvider storeProvider,    final String storeName){
      return new CompositeReadOnlyWindowStore<>(storeProvider,this,storeName);
    }
  }
private static class SessionStoreType<K,V> extends QueryableStoreTypeMatcher<ReadOnlySessionStore<K,V>> {
    SessionStoreType(){
      super(ReadOnlySessionStore.class);
    }
    @Override public ReadOnlySessionStore<K,V> create(    final StateStoreProvider storeProvider,    final String storeName){
      return new CompositeReadOnlySessionStore<>(storeProvider,this,storeName);
    }
  }
}
