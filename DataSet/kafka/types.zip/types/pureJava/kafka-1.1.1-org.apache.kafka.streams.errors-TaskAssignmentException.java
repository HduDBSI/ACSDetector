/** 
 * Indicates a run time error incurred while trying to assign {@link org.apache.kafka.streams.processor.internals.StreamTask stream tasks} to{@link org.apache.kafka.streams.processor.internals.StreamThread threads}.
 */
public class TaskAssignmentException extends StreamsException {
  private final static long serialVersionUID=1L;
  public TaskAssignmentException(  final String message){
    super(message);
  }
  public TaskAssignmentException(  final String message,  final Throwable throwable){
    super(message,throwable);
  }
  public TaskAssignmentException(  final Throwable throwable){
    super(throwable);
  }
}
