public class LeaderAndIsrResponse extends AbstractResponse {
  private static final String PARTITIONS_KEY_NAME="partitions";
  private static final Schema LEADER_AND_ISR_RESPONSE_PARTITION_V0=new Schema(TOPIC_NAME,PARTITION_ID,ERROR_CODE);
  private static final Schema LEADER_AND_ISR_RESPONSE_V0=new Schema(ERROR_CODE,new Field(PARTITIONS_KEY_NAME,new ArrayOf(LEADER_AND_ISR_RESPONSE_PARTITION_V0)));
  private static final Schema LEADER_AND_ISR_RESPONSE_V1=LEADER_AND_ISR_RESPONSE_V0;
  public static Schema[] schemaVersions(){
    return new Schema[]{LEADER_AND_ISR_RESPONSE_V0,LEADER_AND_ISR_RESPONSE_V1};
  }
  /** 
 * Possible error code: STALE_CONTROLLER_EPOCH (11)
 */
  private final Errors error;
  private final Map<TopicPartition,Errors> responses;
  public LeaderAndIsrResponse(  Errors error,  Map<TopicPartition,Errors> responses){
    this.responses=responses;
    this.error=error;
  }
  public LeaderAndIsrResponse(  Struct struct){
    responses=new HashMap<>();
    for (    Object responseDataObj : struct.getArray(PARTITIONS_KEY_NAME)) {
      Struct responseData=(Struct)responseDataObj;
      String topic=responseData.get(TOPIC_NAME);
      int partition=responseData.get(PARTITION_ID);
      Errors error=Errors.forCode(responseData.get(ERROR_CODE));
      responses.put(new TopicPartition(topic,partition),error);
    }
    error=Errors.forCode(struct.get(ERROR_CODE));
  }
  public Map<TopicPartition,Errors> responses(){
    return responses;
  }
  public Errors error(){
    return error;
  }
  @Override public Map<Errors,Integer> errorCounts(){
    if (error != Errors.NONE)     return Collections.singletonMap(error,responses.size());
    return errorCounts(responses);
  }
  public static LeaderAndIsrResponse parse(  ByteBuffer buffer,  short version){
    return new LeaderAndIsrResponse(ApiKeys.LEADER_AND_ISR.parseResponse(version,buffer));
  }
  @Override protected Struct toStruct(  short version){
    Struct struct=new Struct(ApiKeys.LEADER_AND_ISR.responseSchema(version));
    List<Struct> responseDatas=new ArrayList<>(responses.size());
    for (    Map.Entry<TopicPartition,Errors> response : responses.entrySet()) {
      Struct partitionData=struct.instance(PARTITIONS_KEY_NAME);
      TopicPartition partition=response.getKey();
      partitionData.set(TOPIC_NAME,partition.topic());
      partitionData.set(PARTITION_ID,partition.partition());
      partitionData.set(ERROR_CODE,response.getValue().code());
      responseDatas.add(partitionData);
    }
    struct.set(PARTITIONS_KEY_NAME,responseDatas.toArray());
    struct.set(ERROR_CODE,error.code());
    return struct;
  }
}
