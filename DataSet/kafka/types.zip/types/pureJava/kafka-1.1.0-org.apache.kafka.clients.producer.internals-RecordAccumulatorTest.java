public class RecordAccumulatorTest {
  private String topic="test";
  private int partition1=0;
  private int partition2=1;
  private int partition3=2;
  private Node node1=new Node(0,"localhost",1111);
  private Node node2=new Node(1,"localhost",1112);
  private TopicPartition tp1=new TopicPartition(topic,partition1);
  private TopicPartition tp2=new TopicPartition(topic,partition2);
  private TopicPartition tp3=new TopicPartition(topic,partition3);
  private PartitionInfo part1=new PartitionInfo(topic,partition1,node1,null,null);
  private PartitionInfo part2=new PartitionInfo(topic,partition2,node1,null,null);
  private PartitionInfo part3=new PartitionInfo(topic,partition3,node2,null,null);
  private MockTime time=new MockTime();
  private byte[] key="key".getBytes();
  private byte[] value="value".getBytes();
  private int msgSize=DefaultRecord.sizeInBytes(0,0,key.length,value.length,Record.EMPTY_HEADERS);
  private Cluster cluster=new Cluster(null,Arrays.asList(node1,node2),Arrays.asList(part1,part2,part3),Collections.<String>emptySet(),Collections.<String>emptySet());
  private Metrics metrics=new Metrics(time);
  private final long maxBlockTimeMs=1000;
  private final LogContext logContext=new LogContext();
  @After public void teardown(){
    this.metrics.close();
  }
  @Test public void testFull() throws Exception {
    long now=time.milliseconds();
    int batchSize=1025;
    RecordAccumulator accum=createTestRecordAccumulator(batchSize + DefaultRecordBatch.RECORD_BATCH_OVERHEAD,10L * batchSize,CompressionType.NONE,10L);
    int appends=expectedNumAppends(batchSize);
    for (int i=0; i < appends; i++) {
      accum.append(tp1,0L,key,value,Record.EMPTY_HEADERS,null,maxBlockTimeMs);
      Deque<ProducerBatch> partitionBatches=accum.batches().get(tp1);
      assertEquals(1,partitionBatches.size());
      ProducerBatch batch=partitionBatches.peekFirst();
      assertTrue(batch.isWritable());
      assertEquals("No partitions should be ready.",0,accum.ready(cluster,now).readyNodes.size());
    }
    accum.append(tp1,0L,key,value,Record.EMPTY_HEADERS,null,maxBlockTimeMs);
    Deque<ProducerBatch> partitionBatches=accum.batches().get(tp1);
    assertEquals(2,partitionBatches.size());
    Iterator<ProducerBatch> partitionBatchesIterator=partitionBatches.iterator();
    assertTrue(partitionBatchesIterator.next().isWritable());
    assertEquals("Our partition's leader should be ready",Collections.singleton(node1),accum.ready(cluster,time.milliseconds()).readyNodes);
    List<ProducerBatch> batches=accum.drain(cluster,Collections.singleton(node1),Integer.MAX_VALUE,0).get(node1.id());
    assertEquals(1,batches.size());
    ProducerBatch batch=batches.get(0);
    Iterator<Record> iter=batch.records().records().iterator();
    for (int i=0; i < appends; i++) {
      Record record=iter.next();
      assertEquals("Keys should match",ByteBuffer.wrap(key),record.key());
      assertEquals("Values should match",ByteBuffer.wrap(value),record.value());
    }
    assertFalse("No more records",iter.hasNext());
  }
  @Test public void testAppendLargeCompressed() throws Exception {
    testAppendLarge(CompressionType.GZIP);
  }
  @Test public void testAppendLargeNonCompressed() throws Exception {
    testAppendLarge(CompressionType.NONE);
  }
  private void testAppendLarge(  CompressionType compressionType) throws Exception {
    int batchSize=512;
    byte[] value=new byte[2 * batchSize];
    RecordAccumulator accum=createTestRecordAccumulator(batchSize + DefaultRecordBatch.RECORD_BATCH_OVERHEAD,10 * 1024,compressionType,0L);
    accum.append(tp1,0L,key,value,Record.EMPTY_HEADERS,null,maxBlockTimeMs);
    assertEquals("Our partition's leader should be ready",Collections.singleton(node1),accum.ready(cluster,time.milliseconds()).readyNodes);
    Deque<ProducerBatch> batches=accum.batches().get(tp1);
    assertEquals(1,batches.size());
    ProducerBatch producerBatch=batches.peek();
    List<MutableRecordBatch> recordBatches=TestUtils.toList(producerBatch.records().batches());
    assertEquals(1,recordBatches.size());
    MutableRecordBatch recordBatch=recordBatches.get(0);
    assertEquals(0L,recordBatch.baseOffset());
    List<Record> records=TestUtils.toList(recordBatch);
    assertEquals(1,records.size());
    Record record=records.get(0);
    assertEquals(0L,record.offset());
    assertEquals(ByteBuffer.wrap(key),record.key());
    assertEquals(ByteBuffer.wrap(value),record.value());
    assertEquals(0L,record.timestamp());
  }
  @Test public void testAppendLargeOldMessageFormatCompressed() throws Exception {
    testAppendLargeOldMessageFormat(CompressionType.GZIP);
  }
  @Test public void testAppendLargeOldMessageFormatNonCompressed() throws Exception {
    testAppendLargeOldMessageFormat(CompressionType.NONE);
  }
  private void testAppendLargeOldMessageFormat(  CompressionType compressionType) throws Exception {
    int batchSize=512;
    byte[] value=new byte[2 * batchSize];
    ApiVersions apiVersions=new ApiVersions();
    apiVersions.update(node1.idString(),NodeApiVersions.create(Collections.singleton(new ApiVersionsResponse.ApiVersion(ApiKeys.PRODUCE.id,(short)0,(short)2))));
    RecordAccumulator accum=createTestRecordAccumulator(batchSize + DefaultRecordBatch.RECORD_BATCH_OVERHEAD,10 * 1024,compressionType,0L);
    accum.append(tp1,0L,key,value,Record.EMPTY_HEADERS,null,maxBlockTimeMs);
    assertEquals("Our partition's leader should be ready",Collections.singleton(node1),accum.ready(cluster,time.milliseconds()).readyNodes);
    Deque<ProducerBatch> batches=accum.batches().get(tp1);
    assertEquals(1,batches.size());
    ProducerBatch producerBatch=batches.peek();
    List<MutableRecordBatch> recordBatches=TestUtils.toList(producerBatch.records().batches());
    assertEquals(1,recordBatches.size());
    MutableRecordBatch recordBatch=recordBatches.get(0);
    assertEquals(0L,recordBatch.baseOffset());
    List<Record> records=TestUtils.toList(recordBatch);
    assertEquals(1,records.size());
    Record record=records.get(0);
    assertEquals(0L,record.offset());
    assertEquals(ByteBuffer.wrap(key),record.key());
    assertEquals(ByteBuffer.wrap(value),record.value());
    assertEquals(0L,record.timestamp());
  }
  @Test public void testLinger() throws Exception {
    long lingerMs=10L;
    RecordAccumulator accum=createTestRecordAccumulator(1024 + DefaultRecordBatch.RECORD_BATCH_OVERHEAD,10 * 1024,CompressionType.NONE,lingerMs);
    accum.append(tp1,0L,key,value,Record.EMPTY_HEADERS,null,maxBlockTimeMs);
    assertEquals("No partitions should be ready",0,accum.ready(cluster,time.milliseconds()).readyNodes.size());
    time.sleep(10);
    assertEquals("Our partition's leader should be ready",Collections.singleton(node1),accum.ready(cluster,time.milliseconds()).readyNodes);
    List<ProducerBatch> batches=accum.drain(cluster,Collections.singleton(node1),Integer.MAX_VALUE,0).get(node1.id());
    assertEquals(1,batches.size());
    ProducerBatch batch=batches.get(0);
    Iterator<Record> iter=batch.records().records().iterator();
    Record record=iter.next();
    assertEquals("Keys should match",ByteBuffer.wrap(key),record.key());
    assertEquals("Values should match",ByteBuffer.wrap(value),record.value());
    assertFalse("No more records",iter.hasNext());
  }
  @Test public void testPartialDrain() throws Exception {
    RecordAccumulator accum=createTestRecordAccumulator(1024 + DefaultRecordBatch.RECORD_BATCH_OVERHEAD,10 * 1024,CompressionType.NONE,10L);
    int appends=1024 / msgSize + 1;
    List<TopicPartition> partitions=asList(tp1,tp2);
    for (    TopicPartition tp : partitions) {
      for (int i=0; i < appends; i++)       accum.append(tp,0L,key,value,Record.EMPTY_HEADERS,null,maxBlockTimeMs);
    }
    assertEquals("Partition's leader should be ready",Collections.singleton(node1),accum.ready(cluster,time.milliseconds()).readyNodes);
    List<ProducerBatch> batches=accum.drain(cluster,Collections.singleton(node1),1024,0).get(node1.id());
    assertEquals("But due to size bound only one partition should have been retrieved",1,batches.size());
  }
  @SuppressWarnings("unused") @Test public void testStressfulSituation() throws Exception {
    final int numThreads=5;
    final int msgs=10000;
    final int numParts=2;
    final RecordAccumulator accum=createTestRecordAccumulator(1024 + DefaultRecordBatch.RECORD_BATCH_OVERHEAD,10 * 1024,CompressionType.NONE,0L);
    List<Thread> threads=new ArrayList<>();
    for (int i=0; i < numThreads; i++) {
      threads.add(new Thread(){
        public void run(){
          for (int i=0; i < msgs; i++) {
            try {
              accum.append(new TopicPartition(topic,i % numParts),0L,key,value,Record.EMPTY_HEADERS,null,maxBlockTimeMs);
            }
 catch (            Exception e) {
              e.printStackTrace();
            }
          }
        }
      }
);
    }
    for (    Thread t : threads)     t.start();
    int read=0;
    long now=time.milliseconds();
    while (read < numThreads * msgs) {
      Set<Node> nodes=accum.ready(cluster,now).readyNodes;
      List<ProducerBatch> batches=accum.drain(cluster,nodes,5 * 1024,0).get(node1.id());
      if (batches != null) {
        for (        ProducerBatch batch : batches) {
          for (          Record record : batch.records().records())           read++;
          accum.deallocate(batch);
        }
      }
    }
    for (    Thread t : threads)     t.join();
  }
  @Test public void testNextReadyCheckDelay() throws Exception {
    long lingerMs=10L;
    int batchSize=1025;
    RecordAccumulator accum=createTestRecordAccumulator(batchSize + DefaultRecordBatch.RECORD_BATCH_OVERHEAD,10 * batchSize,CompressionType.NONE,lingerMs);
    int appends=expectedNumAppends(batchSize);
    for (int i=0; i < appends; i++)     accum.append(tp1,0L,key,value,Record.EMPTY_HEADERS,null,maxBlockTimeMs);
    RecordAccumulator.ReadyCheckResult result=accum.ready(cluster,time.milliseconds());
    assertEquals("No nodes should be ready.",0,result.readyNodes.size());
    assertEquals("Next check time should be the linger time",lingerMs,result.nextReadyCheckDelayMs);
    time.sleep(lingerMs / 2);
    for (int i=0; i < appends; i++)     accum.append(tp3,0L,key,value,Record.EMPTY_HEADERS,null,maxBlockTimeMs);
    result=accum.ready(cluster,time.milliseconds());
    assertEquals("No nodes should be ready.",0,result.readyNodes.size());
    assertEquals("Next check time should be defined by node1, half remaining linger time",lingerMs / 2,result.nextReadyCheckDelayMs);
    for (int i=0; i < appends + 1; i++)     accum.append(tp2,0L,key,value,Record.EMPTY_HEADERS,null,maxBlockTimeMs);
    result=accum.ready(cluster,time.milliseconds());
    assertEquals("Node1 should be ready",Collections.singleton(node1),result.readyNodes);
    assertTrue("Next check time should be defined by node2, at most linger time",result.nextReadyCheckDelayMs <= lingerMs);
  }
  @Test public void testRetryBackoff() throws Exception {
    long lingerMs=Long.MAX_VALUE / 4;
    long retryBackoffMs=Long.MAX_VALUE / 2;
    final RecordAccumulator accum=new RecordAccumulator(logContext,1024 + DefaultRecordBatch.RECORD_BATCH_OVERHEAD,10 * 1024,CompressionType.NONE,lingerMs,retryBackoffMs,metrics,time,new ApiVersions(),null);
    long now=time.milliseconds();
    accum.append(tp1,0L,key,value,Record.EMPTY_HEADERS,null,maxBlockTimeMs);
    RecordAccumulator.ReadyCheckResult result=accum.ready(cluster,now + lingerMs + 1);
    assertEquals("Node1 should be ready",Collections.singleton(node1),result.readyNodes);
    Map<Integer,List<ProducerBatch>> batches=accum.drain(cluster,result.readyNodes,Integer.MAX_VALUE,now + lingerMs + 1);
    assertEquals("Node1 should be the only ready node.",1,batches.size());
    assertEquals("Partition 0 should only have one batch drained.",1,batches.get(0).size());
    now=time.milliseconds();
    accum.reenqueue(batches.get(0).get(0),now);
    accum.append(tp2,0L,key,value,Record.EMPTY_HEADERS,null,maxBlockTimeMs);
    result=accum.ready(cluster,now + lingerMs + 1);
    assertEquals("Node1 should be ready",Collections.singleton(node1),result.readyNodes);
    batches=accum.drain(cluster,result.readyNodes,Integer.MAX_VALUE,now + lingerMs + 1);
    assertEquals("Node1 should be the only ready node.",1,batches.size());
    assertEquals("Node1 should only have one batch drained.",1,batches.get(0).size());
    assertEquals("Node1 should only have one batch for partition 1.",tp2,batches.get(0).get(0).topicPartition);
    result=accum.ready(cluster,now + retryBackoffMs + 1);
    assertEquals("Node1 should be ready",Collections.singleton(node1),result.readyNodes);
    batches=accum.drain(cluster,result.readyNodes,Integer.MAX_VALUE,now + retryBackoffMs + 1);
    assertEquals("Node1 should be the only ready node.",1,batches.size());
    assertEquals("Node1 should only have one batch drained.",1,batches.get(0).size());
    assertEquals("Node1 should only have one batch for partition 0.",tp1,batches.get(0).get(0).topicPartition);
  }
  @Test public void testFlush() throws Exception {
    long lingerMs=Long.MAX_VALUE;
    final RecordAccumulator accum=createTestRecordAccumulator(4 * 1024 + DefaultRecordBatch.RECORD_BATCH_OVERHEAD,64 * 1024,CompressionType.NONE,lingerMs);
    for (int i=0; i < 100; i++) {
      accum.append(new TopicPartition(topic,i % 3),0L,key,value,Record.EMPTY_HEADERS,null,maxBlockTimeMs);
      assertTrue(accum.hasIncomplete());
    }
    RecordAccumulator.ReadyCheckResult result=accum.ready(cluster,time.milliseconds());
    assertEquals("No nodes should be ready.",0,result.readyNodes.size());
    accum.beginFlush();
    result=accum.ready(cluster,time.milliseconds());
    Map<Integer,List<ProducerBatch>> results=accum.drain(cluster,result.readyNodes,Integer.MAX_VALUE,time.milliseconds());
    assertTrue(accum.hasIncomplete());
    for (    List<ProducerBatch> batches : results.values())     for (    ProducerBatch batch : batches)     accum.deallocate(batch);
    accum.awaitFlushCompletion();
    assertFalse(accum.hasUndrained());
    assertFalse(accum.hasIncomplete());
  }
  private void delayedInterrupt(  final Thread thread,  final long delayMs){
    Thread t=new Thread(){
      public void run(){
        Time.SYSTEM.sleep(delayMs);
        thread.interrupt();
      }
    }
;
    t.start();
  }
  @Test public void testAwaitFlushComplete() throws Exception {
    RecordAccumulator accum=createTestRecordAccumulator(4 * 1024 + DefaultRecordBatch.RECORD_BATCH_OVERHEAD,64 * 1024,CompressionType.NONE,Long.MAX_VALUE);
    accum.append(new TopicPartition(topic,0),0L,key,value,Record.EMPTY_HEADERS,null,maxBlockTimeMs);
    accum.beginFlush();
    assertTrue(accum.flushInProgress());
    delayedInterrupt(Thread.currentThread(),1000L);
    try {
      accum.awaitFlushCompletion();
      fail("awaitFlushCompletion should throw InterruptException");
    }
 catch (    InterruptedException e) {
      assertFalse("flushInProgress count should be decremented even if thread is interrupted",accum.flushInProgress());
    }
  }
  @Test public void testAbortIncompleteBatches() throws Exception {
    long lingerMs=Long.MAX_VALUE;
    int numRecords=100;
    final AtomicInteger numExceptionReceivedInCallback=new AtomicInteger(0);
    final RecordAccumulator accum=createTestRecordAccumulator(128 + DefaultRecordBatch.RECORD_BATCH_OVERHEAD,64 * 1024,CompressionType.NONE,lingerMs);
class TestCallback implements Callback {
      @Override public void onCompletion(      RecordMetadata metadata,      Exception exception){
        assertTrue(exception.getMessage().equals("Producer is closed forcefully."));
        numExceptionReceivedInCallback.incrementAndGet();
      }
    }
    for (int i=0; i < numRecords; i++)     accum.append(new TopicPartition(topic,i % 3),0L,key,value,null,new TestCallback(),maxBlockTimeMs);
    RecordAccumulator.ReadyCheckResult result=accum.ready(cluster,time.milliseconds());
    assertFalse(result.readyNodes.isEmpty());
    Map<Integer,List<ProducerBatch>> drained=accum.drain(cluster,result.readyNodes,Integer.MAX_VALUE,time.milliseconds());
    assertTrue(accum.hasUndrained());
    assertTrue(accum.hasIncomplete());
    int numDrainedRecords=0;
    for (    Map.Entry<Integer,List<ProducerBatch>> drainedEntry : drained.entrySet()) {
      for (      ProducerBatch batch : drainedEntry.getValue()) {
        assertTrue(batch.isClosed());
        assertFalse(batch.produceFuture.completed());
        numDrainedRecords+=batch.recordCount;
      }
    }
    assertTrue(numDrainedRecords > 0 && numDrainedRecords < numRecords);
    accum.abortIncompleteBatches();
    assertEquals(numRecords,numExceptionReceivedInCallback.get());
    assertFalse(accum.hasUndrained());
    assertFalse(accum.hasIncomplete());
  }
  @Test public void testAbortUnsentBatches() throws Exception {
    long lingerMs=Long.MAX_VALUE;
    int numRecords=100;
    final AtomicInteger numExceptionReceivedInCallback=new AtomicInteger(0);
    final RecordAccumulator accum=createTestRecordAccumulator(128 + DefaultRecordBatch.RECORD_BATCH_OVERHEAD,64 * 1024,CompressionType.NONE,lingerMs);
    final KafkaException cause=new KafkaException();
class TestCallback implements Callback {
      @Override public void onCompletion(      RecordMetadata metadata,      Exception exception){
        assertEquals(cause,exception);
        numExceptionReceivedInCallback.incrementAndGet();
      }
    }
    for (int i=0; i < numRecords; i++)     accum.append(new TopicPartition(topic,i % 3),0L,key,value,null,new TestCallback(),maxBlockTimeMs);
    RecordAccumulator.ReadyCheckResult result=accum.ready(cluster,time.milliseconds());
    assertFalse(result.readyNodes.isEmpty());
    Map<Integer,List<ProducerBatch>> drained=accum.drain(cluster,result.readyNodes,Integer.MAX_VALUE,time.milliseconds());
    assertTrue(accum.hasUndrained());
    assertTrue(accum.hasIncomplete());
    accum.abortUndrainedBatches(cause);
    int numDrainedRecords=0;
    for (    Map.Entry<Integer,List<ProducerBatch>> drainedEntry : drained.entrySet()) {
      for (      ProducerBatch batch : drainedEntry.getValue()) {
        assertTrue(batch.isClosed());
        assertFalse(batch.produceFuture.completed());
        numDrainedRecords+=batch.recordCount;
      }
    }
    assertTrue(numDrainedRecords > 0);
    assertTrue(numExceptionReceivedInCallback.get() > 0);
    assertEquals(numRecords,numExceptionReceivedInCallback.get() + numDrainedRecords);
    assertFalse(accum.hasUndrained());
    assertTrue(accum.hasIncomplete());
  }
  @Test public void testExpiredBatches() throws InterruptedException {
    long retryBackoffMs=100L;
    long lingerMs=3000L;
    int requestTimeout=60;
    int batchSize=1025;
    RecordAccumulator accum=createTestRecordAccumulator(batchSize + DefaultRecordBatch.RECORD_BATCH_OVERHEAD,10 * batchSize,CompressionType.NONE,lingerMs);
    int appends=expectedNumAppends(batchSize);
    for (int i=0; i < appends; i++) {
      accum.append(tp1,0L,key,value,Record.EMPTY_HEADERS,null,maxBlockTimeMs);
      assertEquals("No partitions should be ready.",0,accum.ready(cluster,time.milliseconds()).readyNodes.size());
    }
    accum.append(tp1,0L,key,value,Record.EMPTY_HEADERS,null,0);
    Set<Node> readyNodes=accum.ready(cluster,time.milliseconds()).readyNodes;
    assertEquals("Our partition's leader should be ready",Collections.singleton(node1),readyNodes);
    time.sleep(requestTimeout + 1);
    accum.mutePartition(tp1);
    List<ProducerBatch> expiredBatches=accum.expiredBatches(requestTimeout,time.milliseconds());
    assertEquals("The batch should not be expired when the partition is muted",0,expiredBatches.size());
    accum.unmutePartition(tp1);
    expiredBatches=accum.expiredBatches(requestTimeout,time.milliseconds());
    assertEquals("The batch should be expired",1,expiredBatches.size());
    assertEquals("No partitions should be ready.",0,accum.ready(cluster,time.milliseconds()).readyNodes.size());
    time.sleep(lingerMs);
    assertEquals("Our partition's leader should be ready",Collections.singleton(node1),readyNodes);
    time.sleep(requestTimeout + 1);
    accum.mutePartition(tp1);
    expiredBatches=accum.expiredBatches(requestTimeout,time.milliseconds());
    assertEquals("The batch should not be expired when metadata is still available and partition is muted",0,expiredBatches.size());
    accum.unmutePartition(tp1);
    expiredBatches=accum.expiredBatches(requestTimeout,time.milliseconds());
    assertEquals("The batch should be expired when the partition is not muted",1,expiredBatches.size());
    assertEquals("No partitions should be ready.",0,accum.ready(cluster,time.milliseconds()).readyNodes.size());
    accum.append(tp1,0L,key,value,Record.EMPTY_HEADERS,null,0);
    time.sleep(lingerMs);
    readyNodes=accum.ready(cluster,time.milliseconds()).readyNodes;
    assertEquals("Our partition's leader should be ready",Collections.singleton(node1),readyNodes);
    Map<Integer,List<ProducerBatch>> drained=accum.drain(cluster,readyNodes,Integer.MAX_VALUE,time.milliseconds());
    assertEquals("There should be only one batch.",drained.get(node1.id()).size(),1);
    time.sleep(1000L);
    accum.reenqueue(drained.get(node1.id()).get(0),time.milliseconds());
    time.sleep(requestTimeout + retryBackoffMs);
    expiredBatches=accum.expiredBatches(requestTimeout,time.milliseconds());
    assertEquals("The batch should not be expired.",0,expiredBatches.size());
    time.sleep(1L);
    accum.mutePartition(tp1);
    expiredBatches=accum.expiredBatches(requestTimeout,time.milliseconds());
    assertEquals("The batch should not be expired when the partition is muted",0,expiredBatches.size());
    accum.unmutePartition(tp1);
    expiredBatches=accum.expiredBatches(requestTimeout,time.milliseconds());
    assertEquals("The batch should be expired when the partition is not muted.",1,expiredBatches.size());
  }
  @Test public void testMutedPartitions() throws InterruptedException {
    long now=time.milliseconds();
    int batchSize=1025;
    RecordAccumulator accum=createTestRecordAccumulator(batchSize + DefaultRecordBatch.RECORD_BATCH_OVERHEAD,10 * batchSize,CompressionType.NONE,10);
    int appends=expectedNumAppends(batchSize);
    for (int i=0; i < appends; i++) {
      accum.append(tp1,0L,key,value,Record.EMPTY_HEADERS,null,maxBlockTimeMs);
      assertEquals("No partitions should be ready.",0,accum.ready(cluster,now).readyNodes.size());
    }
    time.sleep(2000);
    accum.mutePartition(tp1);
    RecordAccumulator.ReadyCheckResult result=accum.ready(cluster,time.milliseconds());
    assertEquals("No node should be ready",0,result.readyNodes.size());
    accum.unmutePartition(tp1);
    result=accum.ready(cluster,time.milliseconds());
    assertTrue("The batch should be ready",result.readyNodes.size() > 0);
    accum.mutePartition(tp1);
    Map<Integer,List<ProducerBatch>> drained=accum.drain(cluster,result.readyNodes,Integer.MAX_VALUE,time.milliseconds());
    assertEquals("No batch should have been drained",0,drained.get(node1.id()).size());
    accum.unmutePartition(tp1);
    drained=accum.drain(cluster,result.readyNodes,Integer.MAX_VALUE,time.milliseconds());
    assertTrue("The batch should have been drained.",drained.get(node1.id()).size() > 0);
  }
  @Test(expected=UnsupportedVersionException.class) public void testIdempotenceWithOldMagic() throws InterruptedException {
    ApiVersions apiVersions=new ApiVersions();
    int batchSize=1025;
    apiVersions.update("foobar",NodeApiVersions.create(Arrays.asList(new ApiVersionsResponse.ApiVersion(ApiKeys.PRODUCE.id,(short)0,(short)2))));
    RecordAccumulator accum=new RecordAccumulator(logContext,batchSize + DefaultRecordBatch.RECORD_BATCH_OVERHEAD,10 * batchSize,CompressionType.NONE,10,100L,metrics,time,apiVersions,new TransactionManager());
    accum.append(tp1,0L,key,value,Record.EMPTY_HEADERS,null,0);
  }
  @Test public void testSplitAndReenqueue() throws ExecutionException, InterruptedException {
    long now=time.milliseconds();
    RecordAccumulator accum=createTestRecordAccumulator(1024,10 * 1024,CompressionType.GZIP,10);
    ByteBuffer buffer=ByteBuffer.allocate(4096);
    MemoryRecordsBuilder builder=MemoryRecords.builder(buffer,CompressionType.NONE,TimestampType.CREATE_TIME,0L);
    ProducerBatch batch=new ProducerBatch(tp1,builder,now,true);
    byte[] value=new byte[1024];
    final AtomicInteger acked=new AtomicInteger(0);
    Callback cb=new Callback(){
      @Override public void onCompletion(      RecordMetadata metadata,      Exception exception){
        acked.incrementAndGet();
      }
    }
;
    Future<RecordMetadata> future1=batch.tryAppend(now,null,value,Record.EMPTY_HEADERS,cb,now);
    Future<RecordMetadata> future2=batch.tryAppend(now,null,value,Record.EMPTY_HEADERS,cb,now);
    assertNotNull(future1);
    assertNotNull(future2);
    batch.close();
    accum.reenqueue(batch,now);
    time.sleep(101L);
    RecordAccumulator.ReadyCheckResult result=accum.ready(cluster,time.milliseconds());
    assertTrue("The batch should be ready",result.readyNodes.size() > 0);
    Map<Integer,List<ProducerBatch>> drained=accum.drain(cluster,result.readyNodes,Integer.MAX_VALUE,time.milliseconds());
    assertEquals("Only node1 should be drained",1,drained.size());
    assertEquals("Only one batch should be drained",1,drained.get(node1.id()).size());
    accum.splitAndReenqueue(drained.get(node1.id()).get(0));
    time.sleep(101L);
    drained=accum.drain(cluster,result.readyNodes,Integer.MAX_VALUE,time.milliseconds());
    assertFalse(drained.isEmpty());
    assertFalse(drained.get(node1.id()).isEmpty());
    drained.get(node1.id()).get(0).done(acked.get(),100L,null);
    assertEquals("The first message should have been acked.",1,acked.get());
    assertTrue(future1.isDone());
    assertEquals(0,future1.get().offset());
    drained=accum.drain(cluster,result.readyNodes,Integer.MAX_VALUE,time.milliseconds());
    assertFalse(drained.isEmpty());
    assertFalse(drained.get(node1.id()).isEmpty());
    drained.get(node1.id()).get(0).done(acked.get(),100L,null);
    assertEquals("Both message should have been acked.",2,acked.get());
    assertTrue(future2.isDone());
    assertEquals(1,future2.get().offset());
  }
  @Test public void testSplitBatchOffAccumulator() throws InterruptedException {
    long seed=System.currentTimeMillis();
    final int batchSize=1024;
    final int bufferCapacity=3 * 1024;
    CompressionRatioEstimator.setEstimation(tp1.topic(),CompressionType.GZIP,0.1f);
    RecordAccumulator accum=createTestRecordAccumulator(batchSize,bufferCapacity,CompressionType.GZIP,0L);
    int numSplitBatches=prepareSplitBatches(accum,seed,100,20);
    assertTrue("There should be some split batches",numSplitBatches > 0);
    RecordAccumulator.ReadyCheckResult result=accum.ready(cluster,time.milliseconds());
    for (int i=0; i < numSplitBatches; i++) {
      Map<Integer,List<ProducerBatch>> drained=accum.drain(cluster,result.readyNodes,Integer.MAX_VALUE,time.milliseconds());
      assertFalse(drained.isEmpty());
      assertFalse(drained.get(node1.id()).isEmpty());
    }
    assertTrue("All the batches should have been drained.",accum.ready(cluster,time.milliseconds()).readyNodes.isEmpty());
    assertEquals("The split batches should be allocated off the accumulator",bufferCapacity,accum.bufferPoolAvailableMemory());
  }
  @Test public void testSplitFrequency() throws InterruptedException {
    long seed=System.currentTimeMillis();
    Random random=new Random();
    random.setSeed(seed);
    final int batchSize=1024;
    final int numMessages=1000;
    RecordAccumulator accum=createTestRecordAccumulator(batchSize,3 * 1024,CompressionType.GZIP,10);
    for (int goodCompRatioPercentage=1; goodCompRatioPercentage < 100; goodCompRatioPercentage++) {
      int numSplit=0;
      int numBatches=0;
      CompressionRatioEstimator.resetEstimation(topic);
      for (int i=0; i < numMessages; i++) {
        int dice=random.nextInt(100);
        byte[] value=(dice < goodCompRatioPercentage) ? bytesWithGoodCompression(random) : bytesWithPoorCompression(random,100);
        accum.append(tp1,0L,null,value,Record.EMPTY_HEADERS,null,0);
        BatchDrainedResult result=completeOrSplitBatches(accum,batchSize);
        numSplit+=result.numSplit;
        numBatches+=result.numBatches;
      }
      time.sleep(10);
      BatchDrainedResult result=completeOrSplitBatches(accum,batchSize);
      numSplit+=result.numSplit;
      numBatches+=result.numBatches;
      assertTrue(String.format("Total num batches = %d, split batches = %d, more than 10%% of the batch splits. " + "Random seed is " + seed,numBatches,numSplit),(double)numSplit / numBatches < 0.1f);
    }
  }
  private int prepareSplitBatches(  RecordAccumulator accum,  long seed,  int recordSize,  int numRecords) throws InterruptedException {
    Random random=new Random();
    random.setSeed(seed);
    CompressionRatioEstimator.setEstimation(tp1.topic(),CompressionType.GZIP,0.1f);
    for (int i=0; i < numRecords; i++) {
      accum.append(tp1,0L,null,bytesWithPoorCompression(random,recordSize),Record.EMPTY_HEADERS,null,0);
    }
    RecordAccumulator.ReadyCheckResult result=accum.ready(cluster,time.milliseconds());
    assertFalse(result.readyNodes.isEmpty());
    Map<Integer,List<ProducerBatch>> batches=accum.drain(cluster,result.readyNodes,Integer.MAX_VALUE,time.milliseconds());
    assertEquals(1,batches.size());
    assertEquals(1,batches.values().iterator().next().size());
    ProducerBatch batch=batches.values().iterator().next().get(0);
    int numSplitBatches=accum.splitAndReenqueue(batch);
    accum.deallocate(batch);
    return numSplitBatches;
  }
  private BatchDrainedResult completeOrSplitBatches(  RecordAccumulator accum,  int batchSize){
    int numSplit=0;
    int numBatches=0;
    boolean batchDrained;
    do {
      batchDrained=false;
      RecordAccumulator.ReadyCheckResult result=accum.ready(cluster,time.milliseconds());
      Map<Integer,List<ProducerBatch>> batches=accum.drain(cluster,result.readyNodes,Integer.MAX_VALUE,time.milliseconds());
      for (      List<ProducerBatch> batchList : batches.values()) {
        for (        ProducerBatch batch : batchList) {
          batchDrained=true;
          numBatches++;
          if (batch.estimatedSizeInBytes() > batchSize + DefaultRecordBatch.RECORD_BATCH_OVERHEAD) {
            accum.splitAndReenqueue(batch);
            numSplit++;
          }
 else {
            batch.done(0L,0L,null);
          }
          accum.deallocate(batch);
        }
      }
    }
 while (batchDrained);
    return new BatchDrainedResult(numSplit,numBatches);
  }
  /** 
 * Generates the compression ratio at about 0.6
 */
  private byte[] bytesWithGoodCompression(  Random random){
    byte[] value=new byte[100];
    ByteBuffer buffer=ByteBuffer.wrap(value);
    while (buffer.remaining() > 0)     buffer.putInt(random.nextInt(1000));
    return value;
  }
  /** 
 * Generates the compression ratio at about 0.9
 */
  private byte[] bytesWithPoorCompression(  Random random,  int size){
    byte[] value=new byte[size];
    random.nextBytes(value);
    return value;
  }
private class BatchDrainedResult {
    final int numSplit;
    final int numBatches;
    BatchDrainedResult(    int numSplit,    int numBatches){
      this.numBatches=numBatches;
      this.numSplit=numSplit;
    }
  }
  /** 
 * Return the offset delta.
 */
  private int expectedNumAppends(  int batchSize){
    int size=0;
    int offsetDelta=0;
    while (true) {
      int recordSize=DefaultRecord.sizeInBytes(offsetDelta,0,key.length,value.length,Record.EMPTY_HEADERS);
      if (size + recordSize > batchSize)       return offsetDelta;
      offsetDelta+=1;
      size+=recordSize;
    }
  }
  /** 
 * Return a test RecordAccumulator instance
 */
  private RecordAccumulator createTestRecordAccumulator(  int batchSize,  long totalSize,  CompressionType type,  long lingerMs){
    return new RecordAccumulator(logContext,batchSize,totalSize,type,lingerMs,100L,metrics,time,new ApiVersions(),null);
  }
}
