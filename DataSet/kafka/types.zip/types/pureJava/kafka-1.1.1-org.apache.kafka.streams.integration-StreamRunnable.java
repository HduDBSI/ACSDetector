private class StreamRunnable implements Runnable {
  private final KafkaStreams myStream;
  private boolean closed=false;
  private final KafkaStreamsTest.StateListenerStub stateListener=new KafkaStreamsTest.StateListenerStub();
  StreamRunnable(  final String inputTopic,  final String outputTopic,  final String outputTopicWindowed,  final String storeName,  final String windowStoreName,  final int queryPort){
    final Properties props=(Properties)streamsConfiguration.clone();
    props.put(StreamsConfig.APPLICATION_SERVER_CONFIG,"localhost:" + queryPort);
    myStream=createCountStream(inputTopic,outputTopic,outputTopicWindowed,storeName,windowStoreName,props);
    myStream.setStateListener(stateListener);
  }
  @Override public void run(){
    myStream.start();
  }
  public void close(){
    if (!closed) {
      myStream.close();
      closed=true;
    }
  }
  public boolean isClosed(){
    return closed;
  }
  public final KafkaStreams getStream(){
    return myStream;
  }
  final KafkaStreamsTest.StateListenerStub getStateListener(){
    return stateListener;
  }
}
