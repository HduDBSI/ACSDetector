private class KTableKTableJoinMergeProcessor extends AbstractProcessor<K,Change<V>> {
  private KeyValueStore<K,V> store;
  private TupleForwarder<K,V> tupleForwarder;
  @SuppressWarnings("unchecked") @Override public void init(  final ProcessorContext context){
    super.init(context);
    if (queryableName != null) {
      store=(KeyValueStore<K,V>)context.getStateStore(queryableName);
      tupleForwarder=new TupleForwarder<>(store,context,new ForwardingCacheFlushListener<K,V>(context,sendOldValues),sendOldValues);
    }
  }
  @Override public void process(  K key,  Change<V> value){
    if (queryableName != null) {
      store.put(key,value.newValue);
      tupleForwarder.maybeForward(key,value.newValue,value.oldValue);
    }
 else {
      context().forward(key,value);
    }
  }
}
