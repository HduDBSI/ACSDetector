/** 
 * Note that the use of array-typed keys is discouraged because they result in incorrect caching behavior. If you intend to work on byte arrays as key, for example, you may want to wrap them with the  {@code Bytes} class,i.e. use  {@code RocksDBStore<Bytes, ...>} rather than {@code RocksDBStore<byte[], ...>}.
 * @param < K >
 * @param < V >
 */
class StoreChangeLogger<K,V> {
  protected final StateSerdes<K,V> serialization;
  private final String topic;
  private final int partition;
  private final ProcessorContext context;
  private final RecordCollector collector;
  StoreChangeLogger(  String storeName,  ProcessorContext context,  StateSerdes<K,V> serialization){
    this(storeName,context,context.taskId().partition,serialization);
  }
  private StoreChangeLogger(  String storeName,  ProcessorContext context,  int partition,  StateSerdes<K,V> serialization){
    this.topic=ProcessorStateManager.storeChangelogTopic(context.applicationId(),storeName);
    this.context=context;
    this.partition=partition;
    this.serialization=serialization;
    this.collector=((RecordCollector.Supplier)context).recordCollector();
  }
  void logChange(  final K key,  final V value){
    if (collector != null) {
      final Serializer<K> keySerializer=serialization.keySerializer();
      final Serializer<V> valueSerializer=serialization.valueSerializer();
      collector.send(this.topic,key,value,this.partition,context.timestamp(),keySerializer,valueSerializer);
    }
  }
}
