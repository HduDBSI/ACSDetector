static class TestWindow extends Window {
  TestWindow(  final long startMs,  final long endMs){
    super(startMs,endMs);
  }
  @Override public boolean overlap(  final Window other){
    return false;
  }
}
