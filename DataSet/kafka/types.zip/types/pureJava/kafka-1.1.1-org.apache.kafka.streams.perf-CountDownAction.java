private class CountDownAction<V> implements ForeachAction<Integer,V> {
  private CountDownLatch latch;
  CountDownAction(  final CountDownLatch latch){
    this.latch=latch;
  }
  @Override public void apply(  Integer key,  V value){
    processedRecords.getAndIncrement();
    if (value instanceof byte[]) {
      processedBytes+=((byte[])value).length + Integer.SIZE;
    }
 else     if (value instanceof Long) {
      processedBytes+=Long.SIZE + Integer.SIZE;
    }
 else {
      System.err.println("Unknown value type in CountDownAction");
    }
    if (processedRecords.get() == numRecords) {
      this.latch.countDown();
    }
  }
}
