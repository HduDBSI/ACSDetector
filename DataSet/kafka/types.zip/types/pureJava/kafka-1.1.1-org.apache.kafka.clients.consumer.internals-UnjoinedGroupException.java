private static class UnjoinedGroupException extends RetriableException {
}
