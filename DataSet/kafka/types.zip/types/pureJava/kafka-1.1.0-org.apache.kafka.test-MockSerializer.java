public class MockSerializer implements ClusterResourceListener, Serializer<byte[]> {
  public static final AtomicInteger INIT_COUNT=new AtomicInteger(0);
  public static final AtomicInteger CLOSE_COUNT=new AtomicInteger(0);
  public static final AtomicReference<ClusterResource> CLUSTER_META=new AtomicReference<>();
  public static final ClusterResource NO_CLUSTER_ID=new ClusterResource("no_cluster_id");
  public static final AtomicReference<ClusterResource> CLUSTER_ID_BEFORE_SERIALIZE=new AtomicReference<>(NO_CLUSTER_ID);
  public MockSerializer(){
    INIT_COUNT.incrementAndGet();
  }
  @Override public void configure(  Map<String,?> configs,  boolean isKey){
  }
  @Override public byte[] serialize(  String topic,  byte[] data){
    CLUSTER_ID_BEFORE_SERIALIZE.compareAndSet(NO_CLUSTER_ID,CLUSTER_META.get());
    return data;
  }
  @Override public void close(){
    CLOSE_COUNT.incrementAndGet();
  }
  @Override public void onUpdate(  ClusterResource clusterResource){
    CLUSTER_META.set(clusterResource);
  }
}
