public interface EldestEntryRemovalListener<K,V> {
  void apply(  K key,  V value);
}
