public class TaskAssignorTest {
  private static Map<Integer,ClientState<Integer>> copyStates(  Map<Integer,ClientState<Integer>> states){
    Map<Integer,ClientState<Integer>> copy=new HashMap<>();
    for (    Map.Entry<Integer,ClientState<Integer>> entry : states.entrySet()) {
      copy.put(entry.getKey(),entry.getValue().copy());
    }
    return copy;
  }
  @Test public void testAssignWithoutStandby(){
    HashMap<Integer,ClientState<Integer>> statesWithNoPrevTasks=new HashMap<>();
    for (int i=0; i < 6; i++) {
      statesWithNoPrevTasks.put(i,new ClientState<Integer>(1d));
    }
    Set<Integer> tasks;
    int numActiveTasks;
    int numAssignedTasks;
    Map<Integer,ClientState<Integer>> states;
    states=copyStates(statesWithNoPrevTasks);
    tasks=mkSet(0,1,2,3,4,5);
    TaskAssignor.assign(states,tasks,0);
    numActiveTasks=0;
    numAssignedTasks=0;
    for (    ClientState<Integer> assignment : states.values()) {
      numActiveTasks+=assignment.activeTasks.size();
      numAssignedTasks+=assignment.assignedTasks.size();
      assertEquals(1,assignment.activeTasks.size());
      assertEquals(1,assignment.assignedTasks.size());
    }
    assertEquals(tasks.size(),numActiveTasks);
    assertEquals(tasks.size(),numAssignedTasks);
    tasks=mkSet(0,1,2,3,4,5,6,7);
    states=copyStates(statesWithNoPrevTasks);
    TaskAssignor.assign(states,tasks,0);
    numActiveTasks=0;
    numAssignedTasks=0;
    for (    ClientState<Integer> assignment : states.values()) {
      numActiveTasks+=assignment.activeTasks.size();
      numAssignedTasks+=assignment.assignedTasks.size();
      assertTrue(1 <= assignment.activeTasks.size());
      assertTrue(2 >= assignment.activeTasks.size());
      assertTrue(1 <= assignment.assignedTasks.size());
      assertTrue(2 >= assignment.assignedTasks.size());
    }
    assertEquals(tasks.size(),numActiveTasks);
    assertEquals(tasks.size(),numAssignedTasks);
    tasks=mkSet(0,1,2,3);
    states=copyStates(statesWithNoPrevTasks);
    TaskAssignor.assign(states,tasks,0);
    numActiveTasks=0;
    numAssignedTasks=0;
    for (    ClientState<Integer> assignment : states.values()) {
      numActiveTasks+=assignment.activeTasks.size();
      numAssignedTasks+=assignment.assignedTasks.size();
      assertTrue(0 <= assignment.activeTasks.size());
      assertTrue(1 >= assignment.activeTasks.size());
      assertTrue(0 <= assignment.assignedTasks.size());
      assertTrue(1 >= assignment.assignedTasks.size());
    }
    assertEquals(tasks.size(),numActiveTasks);
    assertEquals(tasks.size(),numAssignedTasks);
  }
  @Test public void testAssignWithStandby(){
    HashMap<Integer,ClientState<Integer>> statesWithNoPrevTasks=new HashMap<>();
    for (int i=0; i < 6; i++) {
      statesWithNoPrevTasks.put(i,new ClientState<Integer>(1d));
    }
    Set<Integer> tasks;
    Map<Integer,ClientState<Integer>> states;
    int numActiveTasks;
    int numAssignedTasks;
    tasks=mkSet(0,1,2,3,4,5);
    numActiveTasks=0;
    numAssignedTasks=0;
    states=copyStates(statesWithNoPrevTasks);
    TaskAssignor.assign(states,tasks,1);
    for (    ClientState<Integer> assignment : states.values()) {
      numActiveTasks+=assignment.activeTasks.size();
      numAssignedTasks+=assignment.assignedTasks.size();
      assertEquals(1,assignment.activeTasks.size());
      assertEquals(2,assignment.assignedTasks.size());
    }
    assertEquals(tasks.size(),numActiveTasks);
    assertEquals(tasks.size() * 2,numAssignedTasks);
    tasks=mkSet(0,1,2,3,4,5,6,7);
    states=copyStates(statesWithNoPrevTasks);
    TaskAssignor.assign(states,tasks,1);
    numActiveTasks=0;
    numAssignedTasks=0;
    for (    ClientState<Integer> assignment : states.values()) {
      numActiveTasks+=assignment.activeTasks.size();
      numAssignedTasks+=assignment.assignedTasks.size();
      assertTrue(1 <= assignment.activeTasks.size());
      assertTrue(2 >= assignment.activeTasks.size());
      assertTrue(2 <= assignment.assignedTasks.size());
      assertTrue(3 >= assignment.assignedTasks.size());
    }
    assertEquals(tasks.size(),numActiveTasks);
    assertEquals(tasks.size() * 2,numAssignedTasks);
    tasks=mkSet(0,1,2,3);
    states=copyStates(statesWithNoPrevTasks);
    TaskAssignor.assign(states,tasks,1);
    numActiveTasks=0;
    numAssignedTasks=0;
    for (    ClientState<Integer> assignment : states.values()) {
      numActiveTasks+=assignment.activeTasks.size();
      numAssignedTasks+=assignment.assignedTasks.size();
      assertTrue(0 <= assignment.activeTasks.size());
      assertTrue(1 >= assignment.activeTasks.size());
      assertTrue(1 <= assignment.assignedTasks.size());
      assertTrue(2 >= assignment.assignedTasks.size());
    }
    assertEquals(tasks.size(),numActiveTasks);
    assertEquals(tasks.size() * 2,numAssignedTasks);
    tasks=mkSet(0,1);
    states=copyStates(statesWithNoPrevTasks);
    TaskAssignor.assign(states,tasks,1);
    numActiveTasks=0;
    numAssignedTasks=0;
    for (    ClientState<Integer> assignment : states.values()) {
      numActiveTasks+=assignment.activeTasks.size();
      numAssignedTasks+=assignment.assignedTasks.size();
      assertTrue(0 <= assignment.activeTasks.size());
      assertTrue(1 >= assignment.activeTasks.size());
      assertTrue(0 <= assignment.assignedTasks.size());
      assertTrue(1 >= assignment.assignedTasks.size());
    }
    assertEquals(tasks.size(),numActiveTasks);
    assertEquals(tasks.size() * 2,numAssignedTasks);
    states=copyStates(statesWithNoPrevTasks);
    TaskAssignor.assign(states,tasks,2);
    numActiveTasks=0;
    numAssignedTasks=0;
    for (    ClientState<Integer> assignment : states.values()) {
      numActiveTasks+=assignment.activeTasks.size();
      numAssignedTasks+=assignment.assignedTasks.size();
      assertTrue(0 <= assignment.activeTasks.size());
      assertTrue(1 >= assignment.activeTasks.size());
      assertTrue(1 == assignment.assignedTasks.size());
    }
    assertEquals(tasks.size(),numActiveTasks);
    assertEquals(tasks.size() * 3,numAssignedTasks);
    states=copyStates(statesWithNoPrevTasks);
    TaskAssignor.assign(states,tasks,3);
    numActiveTasks=0;
    numAssignedTasks=0;
    for (    ClientState<Integer> assignment : states.values()) {
      numActiveTasks+=assignment.activeTasks.size();
      numAssignedTasks+=assignment.assignedTasks.size();
      assertTrue(0 <= assignment.activeTasks.size());
      assertTrue(1 >= assignment.activeTasks.size());
      assertTrue(1 <= assignment.assignedTasks.size());
      assertTrue(2 >= assignment.assignedTasks.size());
    }
    assertEquals(tasks.size(),numActiveTasks);
    assertEquals(tasks.size() * 4,numAssignedTasks);
  }
  @Test public void testStickiness(){
    List<Integer> tasks;
    Map<Integer,ClientState<Integer>> statesWithPrevTasks;
    Map<Integer,ClientState<Integer>> assignments;
    int i;
    Map<Integer,ClientState<Integer>> states;
    tasks=mkList(0,1,2,3,4,5);
    Collections.shuffle(tasks);
    statesWithPrevTasks=new HashMap<>();
    i=0;
    for (    int task : tasks) {
      ClientState<Integer> state=new ClientState<>(1d);
      state.prevActiveTasks.add(task);
      state.prevAssignedTasks.add(task);
      statesWithPrevTasks.put(i++,state);
    }
    states=copyStates(statesWithPrevTasks);
    TaskAssignor.assign(states,mkSet(0,1,2,3,4,5),0);
    for (    int client : states.keySet()) {
      Set<Integer> oldActive=statesWithPrevTasks.get(client).prevActiveTasks;
      Set<Integer> oldAssigned=statesWithPrevTasks.get(client).prevAssignedTasks;
      Set<Integer> newActive=states.get(client).activeTasks;
      Set<Integer> newAssigned=states.get(client).assignedTasks;
      assertEquals(oldActive,newActive);
      assertEquals(oldAssigned,newAssigned);
    }
    tasks=mkList(0,1,2,3,-1,-1);
    Collections.shuffle(tasks);
    statesWithPrevTasks=new HashMap<>();
    i=0;
    for (    int task : tasks) {
      ClientState<Integer> state=new ClientState<>(1d);
      if (task >= 0) {
        state.prevActiveTasks.add(task);
        state.prevAssignedTasks.add(task);
      }
      statesWithPrevTasks.put(i++,state);
    }
    states=copyStates(statesWithPrevTasks);
    TaskAssignor.assign(states,mkSet(0,1,2,3),0);
    for (    int client : states.keySet()) {
      Set<Integer> oldActive=statesWithPrevTasks.get(client).prevActiveTasks;
      Set<Integer> oldAssigned=statesWithPrevTasks.get(client).prevAssignedTasks;
      Set<Integer> newActive=states.get(client).activeTasks;
      Set<Integer> newAssigned=states.get(client).assignedTasks;
      assertEquals(oldActive,newActive);
      assertEquals(oldAssigned,newAssigned);
    }
    List<Set<Integer>> taskSets=mkList(mkSet(0,1),mkSet(2,3),mkSet(4,5),mkSet(6,7),mkSet(8,9),mkSet(10,11));
    Collections.shuffle(taskSets);
    statesWithPrevTasks=new HashMap<>();
    i=0;
    for (    Set<Integer> taskSet : taskSets) {
      ClientState<Integer> state=new ClientState<>(1d);
      state.prevActiveTasks.addAll(taskSet);
      state.prevAssignedTasks.addAll(taskSet);
      statesWithPrevTasks.put(i++,state);
    }
    states=copyStates(statesWithPrevTasks);
    TaskAssignor.assign(states,mkSet(0,1,2,3,4,5,6,7,8,9,10,11),0);
    for (    int client : states.keySet()) {
      Set<Integer> oldActive=statesWithPrevTasks.get(client).prevActiveTasks;
      Set<Integer> oldAssigned=statesWithPrevTasks.get(client).prevAssignedTasks;
      Set<Integer> newActive=states.get(client).activeTasks;
      Set<Integer> newAssigned=states.get(client).assignedTasks;
      Set<Integer> intersection=new HashSet<>();
      intersection.addAll(oldActive);
      intersection.retainAll(newActive);
      assertTrue(intersection.size() > 0);
      intersection.clear();
      intersection.addAll(oldAssigned);
      intersection.retainAll(newAssigned);
      assertTrue(intersection.size() > 0);
    }
  }
}
