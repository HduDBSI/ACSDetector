public class DecimalTest {
  private static final int TEST_SCALE=2;
  private static final BigDecimal TEST_DECIMAL=new BigDecimal(new BigInteger("156"),TEST_SCALE);
  private static final BigDecimal TEST_DECIMAL_NEGATIVE=new BigDecimal(new BigInteger("-156"),TEST_SCALE);
  private static final byte[] TEST_BYTES=new byte[]{0,-100};
  private static final byte[] TEST_BYTES_NEGATIVE=new byte[]{-1,100};
  @Test public void testBuilder(){
    Schema plain=Decimal.builder(2).build();
    assertEquals(Decimal.LOGICAL_NAME,plain.name());
    assertEquals(Collections.singletonMap(Decimal.SCALE_FIELD,"2"),plain.parameters());
    assertEquals(1,(Object)plain.version());
  }
  @Test public void testFromLogical(){
    Schema schema=Decimal.schema(TEST_SCALE);
    byte[] encoded=Decimal.fromLogical(schema,TEST_DECIMAL);
    assertArrayEquals(TEST_BYTES,encoded);
    encoded=Decimal.fromLogical(schema,TEST_DECIMAL_NEGATIVE);
    assertArrayEquals(TEST_BYTES_NEGATIVE,encoded);
  }
  @Test public void testToLogical(){
    Schema schema=Decimal.schema(2);
    BigDecimal converted=Decimal.toLogical(schema,TEST_BYTES);
    assertEquals(TEST_DECIMAL,converted);
    converted=Decimal.toLogical(schema,TEST_BYTES_NEGATIVE);
    assertEquals(TEST_DECIMAL_NEGATIVE,converted);
  }
}
