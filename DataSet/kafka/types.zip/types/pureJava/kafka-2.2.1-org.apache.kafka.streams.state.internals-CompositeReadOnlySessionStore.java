/** 
 * Wrapper over the underlying  {@link ReadOnlySessionStore}s found in a  {@link org.apache.kafka.streams.processor.internals.ProcessorTopology}
 */
public class CompositeReadOnlySessionStore<K,V> implements ReadOnlySessionStore<K,V> {
  private final StateStoreProvider storeProvider;
  private final QueryableStoreType<ReadOnlySessionStore<K,V>> queryableStoreType;
  private final String storeName;
  public CompositeReadOnlySessionStore(  final StateStoreProvider storeProvider,  final QueryableStoreType<ReadOnlySessionStore<K,V>> queryableStoreType,  final String storeName){
    this.storeProvider=storeProvider;
    this.queryableStoreType=queryableStoreType;
    this.storeName=storeName;
  }
  @Override public KeyValueIterator<Windowed<K>,V> fetch(  final K key){
    Objects.requireNonNull(key,"key can't be null");
    final List<ReadOnlySessionStore<K,V>> stores=storeProvider.stores(storeName,queryableStoreType);
    for (    final ReadOnlySessionStore<K,V> store : stores) {
      try {
        final KeyValueIterator<Windowed<K>,V> result=store.fetch(key);
        if (!result.hasNext()) {
          result.close();
        }
 else {
          return result;
        }
      }
 catch (      final InvalidStateStoreException ise) {
        throw new InvalidStateStoreException("State store  [" + storeName + "] is not available anymore"+ " and may have been migrated to another instance; "+ "please re-discover its location from the state metadata. "+ "Original error message: "+ ise.toString());
      }
    }
    return KeyValueIterators.emptyIterator();
  }
  @Override public KeyValueIterator<Windowed<K>,V> fetch(  final K from,  final K to){
    Objects.requireNonNull(from,"from can't be null");
    Objects.requireNonNull(to,"to can't be null");
    final NextIteratorFunction<Windowed<K>,V,ReadOnlySessionStore<K,V>> nextIteratorFunction=store -> store.fetch(from,to);
    return new DelegatingPeekingKeyValueIterator<>(storeName,new CompositeKeyValueIterator<>(storeProvider.stores(storeName,queryableStoreType).iterator(),nextIteratorFunction));
  }
}
