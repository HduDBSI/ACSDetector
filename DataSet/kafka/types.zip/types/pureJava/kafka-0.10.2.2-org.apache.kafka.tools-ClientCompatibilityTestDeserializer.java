public static class ClientCompatibilityTestDeserializer implements Deserializer<byte[]>, ClusterResourceListener {
  private final boolean expectClusterId;
  ClientCompatibilityTestDeserializer(  boolean expectClusterId){
    this.expectClusterId=expectClusterId;
  }
  @Override public void configure(  Map<String,?> configs,  boolean isKey){
  }
  @Override public byte[] deserialize(  String topic,  byte[] data){
    return data;
  }
  @Override public void close(){
  }
  @Override public void onUpdate(  ClusterResource clusterResource){
    if (expectClusterId) {
      if (clusterResource.clusterId() == null) {
        throw new RuntimeException("Expected cluster id to be supported, but it was null.");
      }
    }
 else {
      if (clusterResource.clusterId() != null) {
        throw new RuntimeException("Expected cluster id to be null, but it was supported.");
      }
    }
  }
}
