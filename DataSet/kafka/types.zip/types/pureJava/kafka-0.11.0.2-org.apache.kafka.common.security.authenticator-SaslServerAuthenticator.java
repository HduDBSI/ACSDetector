public class SaslServerAuthenticator implements Authenticator {
  static final int MAX_RECEIVE_SIZE=524288;
  private static final Logger LOG=LoggerFactory.getLogger(SaslServerAuthenticator.class);
  public enum SaslState {  GSSAPI_OR_HANDSHAKE_REQUEST,   HANDSHAKE_REQUEST,   AUTHENTICATE,   COMPLETE,   FAILED}
  private final String node;
  private final JaasContext jaasContext;
  private final Subject subject;
  private final KerberosShortNamer kerberosNamer;
  private final String host;
  private final CredentialCache credentialCache;
  private SaslState saslState=SaslState.GSSAPI_OR_HANDSHAKE_REQUEST;
  private SaslState pendingSaslState=null;
  private SaslServer saslServer;
  private String saslMechanism;
  private AuthCallbackHandler callbackHandler;
  private TransportLayer transportLayer;
  private Set<String> enabledMechanisms;
  private Map<String,?> configs;
  private NetworkReceive netInBuffer;
  private Send netOutBuffer;
  public SaslServerAuthenticator(  String node,  JaasContext jaasContext,  final Subject subject,  KerberosShortNamer kerberosNameParser,  String host,  CredentialCache credentialCache) throws IOException {
    if (subject == null)     throw new IllegalArgumentException("subject cannot be null");
    this.node=node;
    this.jaasContext=jaasContext;
    this.subject=subject;
    this.kerberosNamer=kerberosNameParser;
    this.host=host;
    this.credentialCache=credentialCache;
  }
  public void configure(  TransportLayer transportLayer,  PrincipalBuilder principalBuilder,  Map<String,?> configs){
    this.transportLayer=transportLayer;
    this.configs=configs;
    List<String> enabledMechanisms=(List<String>)this.configs.get(SaslConfigs.SASL_ENABLED_MECHANISMS);
    if (enabledMechanisms == null || enabledMechanisms.isEmpty())     throw new IllegalArgumentException("No SASL mechanisms are enabled");
    this.enabledMechanisms=new HashSet<>(enabledMechanisms);
  }
  private void createSaslServer(  String mechanism) throws IOException {
    this.saslMechanism=mechanism;
    if (!ScramMechanism.isScram(mechanism))     callbackHandler=new SaslServerCallbackHandler(jaasContext,kerberosNamer);
 else     callbackHandler=new ScramServerCallbackHandler(credentialCache.cache(mechanism,ScramCredential.class));
    callbackHandler.configure(configs,Mode.SERVER,subject,saslMechanism);
    if (mechanism.equals(SaslConfigs.GSSAPI_MECHANISM)) {
      saslServer=createSaslKerberosServer(callbackHandler,configs,subject);
    }
 else {
      try {
        saslServer=Subject.doAs(subject,new PrivilegedExceptionAction<SaslServer>(){
          public SaslServer run() throws SaslException {
            return Sasl.createSaslServer(saslMechanism,"kafka",host,configs,callbackHandler);
          }
        }
);
      }
 catch (      PrivilegedActionException e) {
        throw new SaslException("Kafka Server failed to create a SaslServer to interact with a client during session authentication",e.getCause());
      }
    }
  }
  private SaslServer createSaslKerberosServer(  final AuthCallbackHandler saslServerCallbackHandler,  final Map<String,?> configs,  Subject subject) throws IOException {
    final String servicePrincipal=SaslClientAuthenticator.firstPrincipal(subject);
    KerberosName kerberosName;
    try {
      kerberosName=KerberosName.parse(servicePrincipal);
    }
 catch (    IllegalArgumentException e) {
      throw new KafkaException("Principal has name with unexpected format " + servicePrincipal);
    }
    final String servicePrincipalName=kerberosName.serviceName();
    final String serviceHostname=kerberosName.hostName();
    LOG.debug("Creating SaslServer for {} with mechanism {}",kerberosName,saslMechanism);
    boolean usingNativeJgss=Boolean.getBoolean("sun.security.jgss.native");
    if (usingNativeJgss) {
      try {
        GSSManager manager=GSSManager.getInstance();
        Oid krb5Mechanism=new Oid("1.2.840.113554.1.2.2");
        GSSName gssName=manager.createName(servicePrincipalName + "@" + serviceHostname,GSSName.NT_HOSTBASED_SERVICE);
        GSSCredential cred=manager.createCredential(gssName,GSSContext.INDEFINITE_LIFETIME,krb5Mechanism,GSSCredential.ACCEPT_ONLY);
        subject.getPrivateCredentials().add(cred);
      }
 catch (      GSSException ex) {
        LOG.warn("Cannot add private credential to subject; clients authentication may fail",ex);
      }
    }
    try {
      return Subject.doAs(subject,new PrivilegedExceptionAction<SaslServer>(){
        public SaslServer run() throws SaslException {
          return Sasl.createSaslServer(saslMechanism,servicePrincipalName,serviceHostname,configs,saslServerCallbackHandler);
        }
      }
);
    }
 catch (    PrivilegedActionException e) {
      throw new SaslException("Kafka Server failed to create a SaslServer to interact with a client during session authentication",e.getCause());
    }
  }
  /** 
 * Evaluates client responses via `SaslServer.evaluateResponse` and returns the issued challenge to the client until authentication succeeds or fails. The messages are sent and received as size delimited bytes that consists of a 4 byte network-ordered size N followed by N bytes representing the opaque payload.
 */
  public void authenticate() throws IOException {
    if (netOutBuffer != null && !flushNetOutBufferAndUpdateInterestOps())     return;
    if (saslServer != null && saslServer.isComplete()) {
      setSaslState(SaslState.COMPLETE);
      return;
    }
    if (netInBuffer == null)     netInBuffer=new NetworkReceive(MAX_RECEIVE_SIZE,node);
    netInBuffer.readFrom(transportLayer);
    if (netInBuffer.complete()) {
      netInBuffer.payload().rewind();
      byte[] clientToken=new byte[netInBuffer.payload().remaining()];
      netInBuffer.payload().get(clientToken,0,clientToken.length);
      netInBuffer=null;
      try {
switch (saslState) {
case HANDSHAKE_REQUEST:
          handleKafkaRequest(clientToken);
        break;
case GSSAPI_OR_HANDSHAKE_REQUEST:
      if (handleKafkaRequest(clientToken))       break;
case AUTHENTICATE:
    byte[] response=saslServer.evaluateResponse(clientToken);
  if (response != null) {
    netOutBuffer=new NetworkSend(node,ByteBuffer.wrap(response));
    flushNetOutBufferAndUpdateInterestOps();
  }
if (saslServer.isComplete()) setSaslState(SaslState.COMPLETE);
break;
default :
break;
}
}
 catch (Exception e) {
setSaslState(SaslState.FAILED);
throw new IOException(e);
}
}
}
public Principal principal(){
return new KafkaPrincipal(KafkaPrincipal.USER_TYPE,saslServer.getAuthorizationID());
}
public boolean complete(){
return saslState == SaslState.COMPLETE;
}
public void close() throws IOException {
if (saslServer != null) saslServer.dispose();
if (callbackHandler != null) callbackHandler.close();
}
private void setSaslState(SaslState saslState){
if (netOutBuffer != null && !netOutBuffer.completed()) pendingSaslState=saslState;
 else {
this.pendingSaslState=null;
this.saslState=saslState;
LOG.debug("Set SASL server state to {}",saslState);
}
}
private boolean flushNetOutBufferAndUpdateInterestOps() throws IOException {
boolean flushedCompletely=flushNetOutBuffer();
if (flushedCompletely) {
transportLayer.removeInterestOps(SelectionKey.OP_WRITE);
if (pendingSaslState != null) setSaslState(pendingSaslState);
}
 else transportLayer.addInterestOps(SelectionKey.OP_WRITE);
return flushedCompletely;
}
private boolean flushNetOutBuffer() throws IOException {
if (!netOutBuffer.completed()) netOutBuffer.writeTo(transportLayer);
return netOutBuffer.completed();
}
private boolean handleKafkaRequest(byte[] requestBytes) throws IOException, AuthenticationException {
boolean isKafkaRequest=false;
String clientMechanism=null;
try {
ByteBuffer requestBuffer=ByteBuffer.wrap(requestBytes);
RequestHeader requestHeader=RequestHeader.parse(requestBuffer);
ApiKeys apiKey=ApiKeys.forId(requestHeader.apiKey());
setSaslState(SaslState.HANDSHAKE_REQUEST);
isKafkaRequest=true;
if (!Protocol.apiVersionSupported(requestHeader.apiKey(),requestHeader.apiVersion())) {
if (apiKey == ApiKeys.API_VERSIONS) sendKafkaResponse(ApiVersionsResponse.unsupportedVersionSend(node,requestHeader));
 else throw new UnsupportedVersionException("Version " + requestHeader.apiVersion() + " is not supported for apiKey "+ apiKey);
}
 else {
LOG.debug("Handle Kafka request {}",apiKey);
switch (apiKey) {
case API_VERSIONS:
handleApiVersionsRequest(requestHeader);
break;
case SASL_HANDSHAKE:
short version=requestHeader.apiVersion();
Struct struct=ApiKeys.SASL_HANDSHAKE.parseRequest(version,requestBuffer);
SaslHandshakeRequest saslHandshakeRequest=new SaslHandshakeRequest(struct,version);
clientMechanism=handleHandshakeRequest(requestHeader,saslHandshakeRequest);
break;
default :
throw new IllegalSaslStateException("Unexpected Kafka request of type " + apiKey + " during SASL handshake.");
}
}
}
 catch (SchemaException|IllegalArgumentException e) {
if (saslState == SaslState.GSSAPI_OR_HANDSHAKE_REQUEST) {
if (LOG.isDebugEnabled()) {
StringBuilder tokenBuilder=new StringBuilder();
for (byte b : requestBytes) {
tokenBuilder.append(String.format("%02x",b));
if (tokenBuilder.length() >= 20) break;
}
LOG.debug("Received client packet of length {} starting with bytes 0x{}, process as GSSAPI packet",requestBytes.length,tokenBuilder);
}
if (enabledMechanisms.contains(SaslConfigs.GSSAPI_MECHANISM)) {
LOG.debug("First client packet is not a SASL mechanism request, using default mechanism GSSAPI");
clientMechanism=SaslConfigs.GSSAPI_MECHANISM;
}
 else throw new UnsupportedSaslMechanismException("Exception handling first SASL packet from client, GSSAPI is not supported by server",e);
}
 else throw e;
}
if (clientMechanism != null) {
createSaslServer(clientMechanism);
setSaslState(SaslState.AUTHENTICATE);
}
return isKafkaRequest;
}
private String handleHandshakeRequest(RequestHeader requestHeader,SaslHandshakeRequest handshakeRequest) throws IOException, UnsupportedSaslMechanismException {
String clientMechanism=handshakeRequest.mechanism();
if (enabledMechanisms.contains(clientMechanism)) {
LOG.debug("Using SASL mechanism '{}' provided by client",clientMechanism);
sendKafkaResponse(requestHeader,new SaslHandshakeResponse(Errors.NONE,enabledMechanisms));
return clientMechanism;
}
 else {
LOG.debug("SASL mechanism '{}' requested by client is not supported",clientMechanism);
sendKafkaResponse(requestHeader,new SaslHandshakeResponse(Errors.UNSUPPORTED_SASL_MECHANISM,enabledMechanisms));
throw new UnsupportedSaslMechanismException("Unsupported SASL mechanism " + clientMechanism);
}
}
private void handleApiVersionsRequest(RequestHeader requestHeader) throws IOException, UnsupportedSaslMechanismException {
sendKafkaResponse(requestHeader,ApiVersionsResponse.API_VERSIONS_RESPONSE);
}
private void sendKafkaResponse(RequestHeader requestHeader,AbstractResponse response) throws IOException {
sendKafkaResponse(response.toSend(node,requestHeader));
}
private void sendKafkaResponse(Send send) throws IOException {
netOutBuffer=send;
flushNetOutBufferAndUpdateInterestOps();
}
}
