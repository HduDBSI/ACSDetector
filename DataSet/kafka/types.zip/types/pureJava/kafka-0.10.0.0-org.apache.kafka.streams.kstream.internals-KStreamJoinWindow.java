class KStreamJoinWindow<K,V> implements ProcessorSupplier<K,V> {
  private final String windowName;
  /** 
 * @throws TopologyBuilderException if retention period of the join window is less than expected
 */
  KStreamJoinWindow(  String windowName,  long windowSizeMs,  long retentionPeriodMs){
    this.windowName=windowName;
    if (windowSizeMs > retentionPeriodMs)     throw new TopologyBuilderException("The retention period of the join window " + windowName + " must be no smaller than its window size.");
  }
  @Override public Processor<K,V> get(){
    return new KStreamJoinWindowProcessor();
  }
private class KStreamJoinWindowProcessor extends AbstractProcessor<K,V> {
    private WindowStore<K,V> window;
    @SuppressWarnings("unchecked") @Override public void init(    ProcessorContext context){
      super.init(context);
      window=(WindowStore<K,V>)context.getStateStore(windowName);
    }
    @Override public void process(    K key,    V value){
      if (key != null) {
        context().forward(key,value);
        window.put(key,value);
      }
    }
  }
}
