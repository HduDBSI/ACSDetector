private static final class DataLogInputStream implements LogInputStream<AbstractLegacyRecordBatch> {
  private final InputStream stream;
  protected final int maxMessageSize;
  private final ByteBuffer offsetAndSizeBuffer;
  DataLogInputStream(  InputStream stream,  int maxMessageSize){
    this.stream=stream;
    this.maxMessageSize=maxMessageSize;
    this.offsetAndSizeBuffer=ByteBuffer.allocate(Records.LOG_OVERHEAD);
  }
  public AbstractLegacyRecordBatch nextBatch() throws IOException {
    offsetAndSizeBuffer.clear();
    Utils.readFully(stream,offsetAndSizeBuffer);
    if (offsetAndSizeBuffer.hasRemaining())     return null;
    long offset=offsetAndSizeBuffer.getLong(Records.OFFSET_OFFSET);
    int size=offsetAndSizeBuffer.getInt(Records.SIZE_OFFSET);
    if (size < LegacyRecord.RECORD_OVERHEAD_V0)     throw new CorruptRecordException(String.format("Record size is less than the minimum record overhead (%d)",LegacyRecord.RECORD_OVERHEAD_V0));
    if (size > maxMessageSize)     throw new CorruptRecordException(String.format("Record size exceeds the largest allowable message size (%d).",maxMessageSize));
    ByteBuffer batchBuffer=ByteBuffer.allocate(size);
    Utils.readFully(stream,batchBuffer);
    if (batchBuffer.hasRemaining())     return null;
    batchBuffer.flip();
    return new BasicLegacyRecordBatch(offset,new LegacyRecord(batchBuffer));
  }
}
