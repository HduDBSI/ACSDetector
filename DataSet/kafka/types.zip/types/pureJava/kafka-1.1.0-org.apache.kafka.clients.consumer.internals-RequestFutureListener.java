/** 
 * Listener interface to hook into RequestFuture completion.
 */
public interface RequestFutureListener<T> {
  void onSuccess(  T value);
  void onFailure(  RuntimeException e);
}
