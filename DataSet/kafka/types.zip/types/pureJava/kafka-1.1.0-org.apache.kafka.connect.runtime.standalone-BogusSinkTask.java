private abstract class BogusSinkTask extends SourceTask {
}
