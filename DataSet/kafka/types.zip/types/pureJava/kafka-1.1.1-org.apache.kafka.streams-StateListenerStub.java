public static class StateListenerStub implements KafkaStreams.StateListener {
  int numChanges=0;
  KafkaStreams.State oldState;
  KafkaStreams.State newState;
  public Map<KafkaStreams.State,Long> mapStates=new HashMap<>();
  @Override public void onChange(  final KafkaStreams.State newState,  final KafkaStreams.State oldState){
    final long prevCount=mapStates.containsKey(newState) ? mapStates.get(newState) : 0;
    numChanges++;
    this.oldState=oldState;
    this.newState=newState;
    mapStates.put(newState,prevCount + 1);
  }
}
