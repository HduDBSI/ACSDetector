private class KStreamBranchProcessor extends AbstractProcessor<K,V> {
  @Override public void process(  K key,  V value){
    for (int i=0; i < predicates.length; i++) {
      if (predicates[i].test(key,value)) {
        context().forward(key,value,i);
        break;
      }
    }
  }
}
