private static class FetchMetrics {
  private int fetchBytes;
  private int fetchRecords;
  protected void increment(  int bytes,  int records){
    this.fetchBytes+=bytes;
    this.fetchRecords+=records;
  }
}
