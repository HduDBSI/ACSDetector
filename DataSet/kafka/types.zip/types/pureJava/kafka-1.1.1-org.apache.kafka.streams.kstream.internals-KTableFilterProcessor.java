private class KTableFilterProcessor extends AbstractProcessor<K,Change<V>> {
  private KeyValueStore<K,V> store;
  private TupleForwarder<K,V> tupleForwarder;
  @SuppressWarnings("unchecked") @Override public void init(  ProcessorContext context){
    super.init(context);
    if (queryableName != null) {
      store=(KeyValueStore<K,V>)context.getStateStore(queryableName);
      tupleForwarder=new TupleForwarder<>(store,context,new ForwardingCacheFlushListener<K,V>(context,sendOldValues),sendOldValues);
    }
  }
  @Override public void process(  K key,  Change<V> change){
    V newValue=computeValue(key,change.newValue);
    V oldValue=sendOldValues ? computeValue(key,change.oldValue) : null;
    if (sendOldValues && oldValue == null && newValue == null)     return;
    if (queryableName != null) {
      store.put(key,newValue);
      tupleForwarder.maybeForward(key,newValue,oldValue);
    }
 else {
      context().forward(key,new Change<>(newValue,oldValue));
    }
  }
}
