public static class GroupMember {
  private final String memberId;
  private final String clientId;
  private final String clientHost;
  private final ByteBuffer memberMetadata;
  private final ByteBuffer memberAssignment;
  public GroupMember(  String memberId,  String clientId,  String clientHost,  ByteBuffer memberMetadata,  ByteBuffer memberAssignment){
    this.memberId=memberId;
    this.clientId=clientId;
    this.clientHost=clientHost;
    this.memberMetadata=memberMetadata;
    this.memberAssignment=memberAssignment;
  }
  public String memberId(){
    return memberId;
  }
  public String clientId(){
    return clientId;
  }
  public String clientHost(){
    return clientHost;
  }
  public ByteBuffer memberMetadata(){
    return memberMetadata;
  }
  public ByteBuffer memberAssignment(){
    return memberAssignment;
  }
}
