public class Table<R,C,V> {
  private Map<R,Map<C,V>> table=new HashMap<>();
  public V put(  R row,  C column,  V value){
    Map<C,V> columns=table.get(row);
    if (columns == null) {
      columns=new HashMap<>();
      table.put(row,columns);
    }
    return columns.put(column,value);
  }
  public V get(  R row,  C column){
    Map<C,V> columns=table.get(row);
    if (columns == null)     return null;
    return columns.get(column);
  }
  public Map<C,V> remove(  R row){
    return table.remove(row);
  }
  public V remove(  R row,  C column){
    Map<C,V> columns=table.get(row);
    if (columns == null)     return null;
    V value=columns.remove(column);
    if (columns.isEmpty())     table.remove(row);
    return value;
  }
  public Map<C,V> row(  R row){
    Map<C,V> columns=table.get(row);
    if (columns == null)     return Collections.emptyMap();
    return Collections.unmodifiableMap(columns);
  }
}
