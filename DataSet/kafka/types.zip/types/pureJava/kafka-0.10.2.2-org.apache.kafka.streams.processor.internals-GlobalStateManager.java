public interface GlobalStateManager extends StateManager {
  Set<String> initialize(  InternalProcessorContext processorContext);
}
