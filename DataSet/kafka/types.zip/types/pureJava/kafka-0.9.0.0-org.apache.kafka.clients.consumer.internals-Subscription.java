class Subscription {
  private final List<String> topics;
  private final ByteBuffer userData;
  public Subscription(  List<String> topics,  ByteBuffer userData){
    this.topics=topics;
    this.userData=userData;
  }
  public Subscription(  List<String> topics){
    this(topics,ByteBuffer.wrap(new byte[0]));
  }
  public List<String> topics(){
    return topics;
  }
  public ByteBuffer userData(){
    return userData;
  }
}
