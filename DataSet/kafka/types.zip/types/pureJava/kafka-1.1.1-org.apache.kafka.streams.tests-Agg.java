public static class Agg {
  KeyValueMapper<String,Long,KeyValue<String,Long>> selector(){
    return new KeyValueMapper<String,Long,KeyValue<String,Long>>(){
      @Override public KeyValue<String,Long> apply(      final String key,      final Long value){
        return new KeyValue<>(value == null ? null : Long.toString(value),1L);
      }
    }
;
  }
  public Initializer<Long> init(){
    return new Initializer<Long>(){
      @Override public Long apply(){
        return 0L;
      }
    }
;
  }
  Aggregator<String,Long,Long> adder(){
    return new Aggregator<String,Long,Long>(){
      @Override public Long apply(      final String aggKey,      final Long value,      final Long aggregate){
        return aggregate + value;
      }
    }
;
  }
  Aggregator<String,Long,Long> remover(){
    return new Aggregator<String,Long,Long>(){
      @Override public Long apply(      final String aggKey,      final Long value,      final Long aggregate){
        return aggregate - value;
      }
    }
;
  }
}
