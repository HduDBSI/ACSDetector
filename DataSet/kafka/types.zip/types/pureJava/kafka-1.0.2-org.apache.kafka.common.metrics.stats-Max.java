/** 
 * A  {@link SampledStat} that gives the max over its samples.
 */
public final class Max extends SampledStat {
  public Max(){
    super(Double.NEGATIVE_INFINITY);
  }
  @Override protected void update(  Sample sample,  MetricConfig config,  double value,  long now){
    sample.value=Math.max(sample.value,value);
  }
  @Override public double combine(  List<Sample> samples,  MetricConfig config,  long now){
    double max=Double.NEGATIVE_INFINITY;
    for (    Sample sample : samples)     max=Math.max(max,sample.value);
    return max;
  }
}
