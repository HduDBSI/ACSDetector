@Path("/") @Produces(MediaType.APPLICATION_JSON) public class RootResource {
  private final Herder herder;
  public RootResource(  Herder herder){
    this.herder=herder;
  }
  @GET @Path("/") public ServerInfo serverInfo(){
    return new ServerInfo(herder.kafkaClusterId());
  }
}
