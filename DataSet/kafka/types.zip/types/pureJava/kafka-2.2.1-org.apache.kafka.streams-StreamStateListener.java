/** 
 * Class that handles stream thread transitions
 */
final class StreamStateListener implements StreamThread.StateListener {
  private final Map<Long,StreamThread.State> threadState;
  private GlobalStreamThread.State globalThreadState;
  private final Object threadStatesLock;
  StreamStateListener(  final Map<Long,StreamThread.State> threadState,  final GlobalStreamThread.State globalThreadState){
    this.threadState=threadState;
    this.globalThreadState=globalThreadState;
    this.threadStatesLock=new Object();
  }
  /** 
 * If all threads are dead set to ERROR
 */
  private void maybeSetError(){
    for (    final StreamThread.State state : threadState.values()) {
      if (state != StreamThread.State.DEAD) {
        return;
      }
    }
    if (setState(State.ERROR)) {
      log.error("All stream threads have died. The instance will be in error state and should be closed.");
    }
  }
  /** 
 * If all threads are up, including the global thread, set to RUNNING
 */
  private void maybeSetRunning(){
    for (    final StreamThread.State state : threadState.values()) {
      if (state != StreamThread.State.RUNNING && state != StreamThread.State.DEAD) {
        return;
      }
    }
    if (globalThreadState != null && globalThreadState != GlobalStreamThread.State.RUNNING) {
      return;
    }
    setState(State.RUNNING);
  }
  @Override public synchronized void onChange(  final Thread thread,  final ThreadStateTransitionValidator abstractNewState,  final ThreadStateTransitionValidator abstractOldState){
synchronized (threadStatesLock) {
      if (thread instanceof StreamThread) {
        final StreamThread.State newState=(StreamThread.State)abstractNewState;
        threadState.put(thread.getId(),newState);
        if (newState == StreamThread.State.PARTITIONS_REVOKED) {
          setState(State.REBALANCING);
        }
 else         if (newState == StreamThread.State.RUNNING) {
          maybeSetRunning();
        }
 else         if (newState == StreamThread.State.DEAD) {
          maybeSetError();
        }
      }
 else       if (thread instanceof GlobalStreamThread) {
        final GlobalStreamThread.State newState=(GlobalStreamThread.State)abstractNewState;
        globalThreadState=newState;
        if (newState == GlobalStreamThread.State.DEAD) {
          if (setState(State.ERROR)) {
            log.error("Global thread has died. The instance will be in error state and should be closed.");
          }
        }
      }
    }
  }
}
