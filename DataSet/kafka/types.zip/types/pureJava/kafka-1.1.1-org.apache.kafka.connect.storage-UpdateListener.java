interface UpdateListener {
  /** 
 * Invoked when a connector configuration has been removed
 * @param connector name of the connector
 */
  void onConnectorConfigRemove(  String connector);
  /** 
 * Invoked when a connector configuration has been updated.
 * @param connector name of the connector
 */
  void onConnectorConfigUpdate(  String connector);
  /** 
 * Invoked when task configs are updated.
 * @param tasks all the tasks whose configs have been updated
 */
  void onTaskConfigUpdate(  Collection<ConnectorTaskId> tasks);
  /** 
 * Invoked when the user has set a new target state (e.g. paused)
 * @param connector name of the connector
 */
  void onConnectorTargetStateChange(  String connector);
}
