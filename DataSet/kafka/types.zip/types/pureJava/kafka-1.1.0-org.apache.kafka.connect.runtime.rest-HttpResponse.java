public static class HttpResponse<T> {
  private int status;
  private Map<String,String> headers;
  private T body;
  public HttpResponse(  int status,  Map<String,String> headers,  T body){
    this.status=status;
    this.headers=headers;
    this.body=body;
  }
  public int status(){
    return status;
  }
  public Map<String,String> headers(){
    return headers;
  }
  public T body(){
    return body;
  }
}
