public class ConnectRestException extends ConnectException {
  private final int statusCode;
  private final int errorCode;
  public ConnectRestException(  int statusCode,  int errorCode,  String message,  Throwable t){
    super(message,t);
    this.statusCode=statusCode;
    this.errorCode=errorCode;
  }
  public ConnectRestException(  Response.Status status,  int errorCode,  String message,  Throwable t){
    this(status.getStatusCode(),errorCode,message,t);
  }
  public ConnectRestException(  int statusCode,  int errorCode,  String message){
    this(statusCode,errorCode,message,null);
  }
  public ConnectRestException(  Response.Status status,  int errorCode,  String message){
    this(status,errorCode,message,null);
  }
  public ConnectRestException(  int statusCode,  String message,  Throwable t){
    this(statusCode,statusCode,message,t);
  }
  public ConnectRestException(  Response.Status status,  String message,  Throwable t){
    this(status,status.getStatusCode(),message,t);
  }
  public ConnectRestException(  int statusCode,  String message){
    this(statusCode,statusCode,message,null);
  }
  public ConnectRestException(  Response.Status status,  String message){
    this(status.getStatusCode(),status.getStatusCode(),message,null);
  }
  public int statusCode(){
    return statusCode;
  }
  public int errorCode(){
    return errorCode;
  }
}
