/** 
 * Merges two iterators. Assumes each of them is sorted by key
 */
class MergedSortedCacheWindowStoreIterator extends AbstractMergedSortedCacheStoreIterator<Long,Long,byte[],byte[]> implements WindowStoreIterator<byte[]> {
  MergedSortedCacheWindowStoreIterator(  final PeekingKeyValueIterator<Bytes,LRUCacheEntry> cacheIterator,  final KeyValueIterator<Long,byte[]> storeIterator){
    super(cacheIterator,storeIterator);
  }
  @Override public KeyValue<Long,byte[]> deserializeStorePair(  final KeyValue<Long,byte[]> pair){
    return pair;
  }
  @Override Long deserializeCacheKey(  final Bytes cacheKey){
    byte[] binaryKey=bytesFromCacheKey(cacheKey);
    return WindowStoreUtils.timestampFromBinaryKey(binaryKey);
  }
  @Override byte[] deserializeCacheValue(  final LRUCacheEntry cacheEntry){
    return cacheEntry.value;
  }
  @Override public Long deserializeStoreKey(  final Long key){
    return key;
  }
  @Override public int compare(  final Bytes cacheKey,  final Long storeKey){
    byte[] binaryKey=bytesFromCacheKey(cacheKey);
    final Long cacheTimestamp=WindowStoreUtils.timestampFromBinaryKey(binaryKey);
    return cacheTimestamp.compareTo(storeKey);
  }
}
