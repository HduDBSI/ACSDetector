/** 
 * A compound stat is a stat where a single measurement and associated data structure feeds many metrics. This is the example for a histogram which has many associated percentiles.
 */
public interface CompoundStat extends Stat {
  public List<NamedMeasurable> stats();
public static class NamedMeasurable {
    private final MetricName name;
    private final Measurable stat;
    public NamedMeasurable(    MetricName name,    Measurable stat){
      super();
      this.name=name;
      this.stat=stat;
    }
    public MetricName name(){
      return name;
    }
    public Measurable stat(){
      return stat;
    }
  }
}
