private class SyncGroupResponseHandler extends CoordinatorResponseHandler<SyncGroupResponse,ByteBuffer> {
  @Override public void handle(  SyncGroupResponse syncResponse,  RequestFuture<ByteBuffer> future){
    Errors error=syncResponse.error();
    if (error == Errors.NONE) {
      sensors.syncLatency.record(response.requestLatencyMs());
      future.complete(syncResponse.memberAssignment());
    }
 else {
      requestRejoin();
      if (error == Errors.GROUP_AUTHORIZATION_FAILED) {
        future.raise(new GroupAuthorizationException(groupId));
      }
 else       if (error == Errors.REBALANCE_IN_PROGRESS) {
        log.debug("SyncGroup failed because the group began another rebalance");
        future.raise(error);
      }
 else       if (error == Errors.UNKNOWN_MEMBER_ID || error == Errors.ILLEGAL_GENERATION) {
        log.debug("SyncGroup failed: {}",error.message());
        resetGeneration();
        future.raise(error);
      }
 else       if (error == Errors.COORDINATOR_NOT_AVAILABLE || error == Errors.NOT_COORDINATOR) {
        log.debug("SyncGroup failed: {}",error.message());
        markCoordinatorUnknown();
        future.raise(error);
      }
 else {
        future.raise(new KafkaException("Unexpected error from SyncGroup: " + error.message()));
      }
    }
  }
}
