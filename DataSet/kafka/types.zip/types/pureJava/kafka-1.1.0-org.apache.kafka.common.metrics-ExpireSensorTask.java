/** 
 * This iterates over every Sensor and triggers a removeSensor if it has expired Package private for testing
 */
class ExpireSensorTask implements Runnable {
  public void run(){
    for (    Map.Entry<String,Sensor> sensorEntry : sensors.entrySet()) {
synchronized (sensorEntry.getValue()) {
        if (sensorEntry.getValue().hasExpired()) {
          log.debug("Removing expired sensor {}",sensorEntry.getKey());
          removeSensor(sensorEntry.getKey());
        }
      }
    }
  }
}
