public final static class RecordAppendResult {
  public final FutureRecordMetadata future;
  public final boolean batchIsFull;
  public final boolean newBatchCreated;
  public RecordAppendResult(  FutureRecordMetadata future,  boolean batchIsFull,  boolean newBatchCreated){
    this.future=future;
    this.batchIsFull=batchIsFull;
    this.newBatchCreated=newBatchCreated;
  }
}
