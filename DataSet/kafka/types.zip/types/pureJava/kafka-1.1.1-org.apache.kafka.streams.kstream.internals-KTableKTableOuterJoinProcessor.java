private class KTableKTableOuterJoinProcessor extends AbstractProcessor<K,Change<V1>> {
  private final KTableValueGetter<K,V2> valueGetter;
  KTableKTableOuterJoinProcessor(  KTableValueGetter<K,V2> valueGetter){
    this.valueGetter=valueGetter;
  }
  @Override public void init(  ProcessorContext context){
    super.init(context);
    valueGetter.init(context);
  }
  @Override public void process(  final K key,  final Change<V1> change){
    if (key == null) {
      return;
    }
    R newValue=null;
    R oldValue=null;
    final V2 value2=valueGetter.get(key);
    if (value2 == null && change.newValue == null && change.oldValue == null) {
      return;
    }
    if (value2 != null || change.newValue != null) {
      newValue=joiner.apply(change.newValue,value2);
    }
    if (sendOldValues && (value2 != null || change.oldValue != null)) {
      oldValue=joiner.apply(change.oldValue,value2);
    }
    context().forward(key,new Change<>(newValue,oldValue));
  }
}
