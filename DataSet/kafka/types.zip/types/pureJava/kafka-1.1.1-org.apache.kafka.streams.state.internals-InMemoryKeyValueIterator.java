private static class InMemoryKeyValueIterator<K,V> implements KeyValueIterator<K,V> {
  private final Iterator<Map.Entry<K,V>> iter;
  private InMemoryKeyValueIterator(  final Iterator<Map.Entry<K,V>> iter){
    this.iter=iter;
  }
  @Override public boolean hasNext(){
    return iter.hasNext();
  }
  @Override public KeyValue<K,V> next(){
    Map.Entry<K,V> entry=iter.next();
    return new KeyValue<>(entry.getKey(),entry.getValue());
  }
  @Override public void remove(){
    iter.remove();
  }
  @Override public void close(){
  }
  @Override public K peekNextKey(){
    throw new UnsupportedOperationException("peekNextKey() not supported in " + getClass().getName());
  }
}
