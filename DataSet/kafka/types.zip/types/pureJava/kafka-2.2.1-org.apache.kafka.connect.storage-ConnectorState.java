private static class ConnectorState {
  private TargetState targetState;
  private Map<String,String> connConfig;
  private Map<ConnectorTaskId,Map<String,String>> taskConfigs;
  public ConnectorState(  Map<String,String> connConfig){
    this.targetState=TargetState.STARTED;
    this.connConfig=connConfig;
    this.taskConfigs=new HashMap<>();
  }
}
