private class KStreamWindowAggregateValueGetter implements KTableValueGetter<Windowed<K>,T> {
  private WindowStore<K,T> windowStore;
  @SuppressWarnings("unchecked") @Override public void init(  ProcessorContext context){
    windowStore=(WindowStore<K,T>)context.getStateStore(storeName);
  }
  @SuppressWarnings("unchecked") @Override public T get(  Windowed<K> windowedKey){
    K key=windowedKey.key();
    W window=(W)windowedKey.window();
    try (WindowStoreIterator<T> iter=windowStore.fetch(key,window.start(),window.start())){
      return iter.hasNext() ? iter.next().value : null;
    }
   }
}
