/** 
 * ConnectorContext for use with a Herder
 */
public class HerderConnectorContext implements ConnectorContext {
  private final AbstractHerder herder;
  private final String connectorName;
  public HerderConnectorContext(  AbstractHerder herder,  String connectorName){
    this.herder=herder;
    this.connectorName=connectorName;
  }
  @Override public void requestTaskReconfiguration(){
    herder.requestTaskReconfiguration(connectorName);
  }
  @Override public void raiseError(  Exception e){
    herder.onFailure(connectorName,e);
  }
}
