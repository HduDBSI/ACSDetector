public class MockValueJoiner {
  public final static ValueJoiner<Object,Object,String> TOSTRING_JOINER=instance("+");
  public static <V1,V2>ValueJoiner<V1,V2,String> instance(  final String separator){
    return new ValueJoiner<V1,V2,String>(){
      @Override public String apply(      V1 value1,      V2 value2){
        return value1 + separator + value2;
      }
    }
;
  }
}
