public class KTableSource<K,V> implements ProcessorSupplier<K,V> {
  private static final Logger LOG=LoggerFactory.getLogger(KTableSource.class);
  private final String storeName;
  private String queryableName;
  private boolean sendOldValues;
  public KTableSource(  final String storeName,  final String queryableName){
    Objects.requireNonNull(storeName,"storeName can't be null");
    this.storeName=storeName;
    this.queryableName=queryableName;
    this.sendOldValues=false;
  }
  public String queryableName(){
    return queryableName;
  }
  @Override public Processor<K,V> get(){
    return new KTableSourceProcessor();
  }
  public void enableSendingOldValues(){
    this.sendOldValues=true;
    this.queryableName=storeName;
  }
  public void materialize(){
    this.queryableName=storeName;
  }
private class KTableSourceProcessor extends AbstractProcessor<K,V> {
    private KeyValueStore<K,V> store;
    private TupleForwarder<K,V> tupleForwarder;
    private StreamsMetricsImpl metrics;
    @SuppressWarnings("unchecked") @Override public void init(    final ProcessorContext context){
      super.init(context);
      metrics=(StreamsMetricsImpl)context.metrics();
      if (queryableName != null) {
        store=(KeyValueStore<K,V>)context.getStateStore(queryableName);
        tupleForwarder=new TupleForwarder<>(store,context,new ForwardingCacheFlushListener<K,V>(context),sendOldValues);
      }
    }
    @Override public void process(    final K key,    final V value){
      if (key == null) {
        LOG.warn("Skipping record due to null key. topic=[{}] partition=[{}] offset=[{}]",context().topic(),context().partition(),context().offset());
        metrics.skippedRecordsSensor().record();
        return;
      }
      if (queryableName != null) {
        final V oldValue=sendOldValues ? store.get(key) : null;
        store.put(key,value);
        tupleForwarder.maybeForward(key,value,oldValue);
      }
 else {
        context().forward(key,new Change<>(value,null));
      }
    }
  }
}
