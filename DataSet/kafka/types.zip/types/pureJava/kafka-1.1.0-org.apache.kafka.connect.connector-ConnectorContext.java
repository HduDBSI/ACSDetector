/** 
 * ConnectorContext allows Connectors to proactively interact with the Kafka Connect runtime.
 */
public interface ConnectorContext {
  /** 
 * Requests that the runtime reconfigure the Tasks for this source. This should be used to indicate to the runtime that something about the input/output has changed (e.g. partitions added/removed) and the running Tasks will need to be modified.
 */
  void requestTaskReconfiguration();
  /** 
 * Raise an unrecoverable exception to the Connect framework. This will cause the status of the connector to transition to FAILED.
 * @param e Exception to be raised.
 */
  void raiseError(  Exception e);
}
