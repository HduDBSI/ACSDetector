public static class RecordInfo {
  RecordQueue queue;
  public ProcessorNode node(){
    return queue.source();
  }
  public TopicPartition partition(){
    return queue.partition();
  }
  RecordQueue queue(){
    return queue;
  }
}
