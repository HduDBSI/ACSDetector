private static class TestCallbackHandler implements RequestCompletionHandler {
  public boolean executed=false;
  public ClientResponse response;
  public void onComplete(  ClientResponse response){
    this.executed=true;
    this.response=response;
  }
}
