class FilteredCacheIterator implements PeekingKeyValueIterator<Bytes,LRUCacheEntry> {
  private final PeekingKeyValueIterator<Bytes,LRUCacheEntry> cacheIterator;
  private final HasNextCondition hasNextCondition;
  private final PeekingKeyValueIterator<Bytes,LRUCacheEntry> wrappedIterator;
  FilteredCacheIterator(  final PeekingKeyValueIterator<Bytes,LRUCacheEntry> cacheIterator,  final HasNextCondition hasNextCondition,  final CacheFunction cacheFunction){
    this.cacheIterator=cacheIterator;
    this.hasNextCondition=hasNextCondition;
    this.wrappedIterator=new PeekingKeyValueIterator<Bytes,LRUCacheEntry>(){
      @Override public KeyValue<Bytes,LRUCacheEntry> peekNext(){
        return cachedPair(cacheIterator.peekNext());
      }
      @Override public void close(){
        cacheIterator.close();
      }
      @Override public Bytes peekNextKey(){
        return cacheFunction.key(cacheIterator.peekNextKey());
      }
      @Override public boolean hasNext(){
        return cacheIterator.hasNext();
      }
      @Override public KeyValue<Bytes,LRUCacheEntry> next(){
        return cachedPair(cacheIterator.next());
      }
      private KeyValue<Bytes,LRUCacheEntry> cachedPair(      KeyValue<Bytes,LRUCacheEntry> next){
        return KeyValue.pair(cacheFunction.key(next.key),next.value);
      }
      @Override public void remove(){
        cacheIterator.remove();
      }
    }
;
  }
  @Override public void close(){
  }
  @Override public Bytes peekNextKey(){
    if (!hasNext()) {
      throw new NoSuchElementException();
    }
    return cacheIterator.peekNextKey();
  }
  @Override public boolean hasNext(){
    return hasNextCondition.hasNext(wrappedIterator);
  }
  @Override public KeyValue<Bytes,LRUCacheEntry> next(){
    if (!hasNext()) {
      throw new NoSuchElementException();
    }
    return cacheIterator.next();
  }
  @Override public void remove(){
    throw new UnsupportedOperationException();
  }
  @Override public KeyValue<Bytes,LRUCacheEntry> peekNext(){
    if (!hasNext()) {
      throw new NoSuchElementException();
    }
    return cacheIterator.peekNext();
  }
}
