public class ProducerRecordTest {
  @Test public void testEqualsAndHashCode(){
    ProducerRecord<String,Integer> producerRecord=new ProducerRecord<>("test",1,"key",1);
    assertEquals(producerRecord,producerRecord);
    assertEquals(producerRecord.hashCode(),producerRecord.hashCode());
    ProducerRecord<String,Integer> equalRecord=new ProducerRecord<>("test",1,"key",1);
    assertEquals(producerRecord,equalRecord);
    assertEquals(producerRecord.hashCode(),equalRecord.hashCode());
    ProducerRecord<String,Integer> topicMisMatch=new ProducerRecord<>("test-1",1,"key",1);
    assertFalse(producerRecord.equals(topicMisMatch));
    ProducerRecord<String,Integer> partitionMismatch=new ProducerRecord<>("test",2,"key",1);
    assertFalse(producerRecord.equals(partitionMismatch));
    ProducerRecord<String,Integer> keyMisMatch=new ProducerRecord<>("test",1,"key-1",1);
    assertFalse(producerRecord.equals(keyMisMatch));
    ProducerRecord<String,Integer> valueMisMatch=new ProducerRecord<>("test",1,"key",2);
    assertFalse(producerRecord.equals(valueMisMatch));
    ProducerRecord<String,Integer> nullFieldsRecord=new ProducerRecord<>("topic",null,null,null,null,null);
    assertEquals(nullFieldsRecord,nullFieldsRecord);
    assertEquals(nullFieldsRecord.hashCode(),nullFieldsRecord.hashCode());
  }
  @Test public void testInvalidRecords(){
    try {
      new ProducerRecord<>(null,0,"key",1);
      fail("Expected IllegalArgumentException to be raised because topic is null");
    }
 catch (    IllegalArgumentException e) {
    }
    try {
      new ProducerRecord<>("test",0,-1L,"key",1);
      fail("Expected IllegalArgumentException to be raised because of negative timestamp");
    }
 catch (    IllegalArgumentException e) {
    }
    try {
      new ProducerRecord<>("test",-1,"key",1);
      fail("Expected IllegalArgumentException to be raised because of negative partition");
    }
 catch (    IllegalArgumentException e) {
    }
  }
}
