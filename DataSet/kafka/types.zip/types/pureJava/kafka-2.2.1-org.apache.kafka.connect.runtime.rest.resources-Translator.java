private interface Translator<T,U> {
  T translate(  RestClient.HttpResponse<U> response);
}
