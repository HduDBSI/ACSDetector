private class KTableKTableLeftJoinValueGetter implements KTableValueGetter<K,R> {
  private final KTableValueGetter<K,V1> valueGetter1;
  private final KTableValueGetter<K,V2> valueGetter2;
  KTableKTableLeftJoinValueGetter(  KTableValueGetter<K,V1> valueGetter1,  KTableValueGetter<K,V2> valueGetter2){
    this.valueGetter1=valueGetter1;
    this.valueGetter2=valueGetter2;
  }
  @Override public void init(  ProcessorContext context){
    valueGetter1.init(context);
    valueGetter2.init(context);
  }
  @Override public R get(  K key){
    V1 value1=valueGetter1.get(key);
    if (value1 != null) {
      V2 value2=valueGetter2.get(key);
      return joiner.apply(value1,value2);
    }
 else {
      return null;
    }
  }
}
