private static class Completion {
  private final long offset;
  private final RecordMetadata metadata;
  private final ProduceRequestResult result;
  private final Callback callback;
  public Completion(  long offset,  RecordMetadata metadata,  ProduceRequestResult result,  Callback callback){
    this.metadata=metadata;
    this.offset=offset;
    this.result=result;
    this.callback=callback;
  }
  public void complete(  RuntimeException e){
    result.set(e == null ? offset : -1L,RecordBatch.NO_TIMESTAMP,e);
    if (callback != null) {
      if (e == null)       callback.onCompletion(metadata,null);
 else       callback.onCompletion(null,e);
    }
    result.done();
  }
}
