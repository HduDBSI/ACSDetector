private static class TopicPartitionState {
  private Long position;
  private Long highWatermark;
  private Long logStartOffset;
  private Long lastStableOffset;
  private boolean paused;
  private OffsetResetStrategy resetStrategy;
  private Long nextAllowedRetryTimeMs;
  TopicPartitionState(){
    this.paused=false;
    this.position=null;
    this.highWatermark=null;
    this.logStartOffset=null;
    this.lastStableOffset=null;
    this.resetStrategy=null;
    this.nextAllowedRetryTimeMs=null;
  }
  private void reset(  OffsetResetStrategy strategy){
    this.resetStrategy=strategy;
    this.position=null;
    this.nextAllowedRetryTimeMs=null;
  }
  private boolean isResetAllowed(  long nowMs){
    return nextAllowedRetryTimeMs == null || nowMs >= nextAllowedRetryTimeMs;
  }
  private boolean awaitingReset(){
    return resetStrategy != null;
  }
  private void setResetPending(  long nextAllowedRetryTimeMs){
    this.nextAllowedRetryTimeMs=nextAllowedRetryTimeMs;
  }
  private void resetFailed(  long nextAllowedRetryTimeMs){
    this.nextAllowedRetryTimeMs=nextAllowedRetryTimeMs;
  }
  private boolean hasValidPosition(){
    return position != null;
  }
  private boolean isMissingPosition(){
    return !hasValidPosition() && !awaitingReset();
  }
  private boolean isPaused(){
    return paused;
  }
  private void seek(  long offset){
    this.position=offset;
    this.resetStrategy=null;
    this.nextAllowedRetryTimeMs=null;
  }
  private void position(  long offset){
    if (!hasValidPosition())     throw new IllegalStateException("Cannot set a new position without a valid current position");
    this.position=offset;
  }
  private void pause(){
    this.paused=true;
  }
  private void resume(){
    this.paused=false;
  }
  private boolean isFetchable(){
    return !paused && hasValidPosition();
  }
}
