private class GroupCoordinatorMetrics {
  public final String metricGrpName;
  public final Sensor heartbeatLatency;
  public final Sensor joinLatency;
  public final Sensor syncLatency;
  public GroupCoordinatorMetrics(  Metrics metrics,  String metricGrpPrefix){
    this.metricGrpName=metricGrpPrefix + "-coordinator-metrics";
    this.heartbeatLatency=metrics.sensor("heartbeat-latency");
    this.heartbeatLatency.add(metrics.metricName("heartbeat-response-time-max",this.metricGrpName,"The max time taken to receive a response to a heartbeat request"),new Max());
    this.heartbeatLatency.add(createMeter(metrics,metricGrpName,"heartbeat","heartbeats"));
    this.joinLatency=metrics.sensor("join-latency");
    this.joinLatency.add(metrics.metricName("join-time-avg",this.metricGrpName,"The average time taken for a group rejoin"),new Avg());
    this.joinLatency.add(metrics.metricName("join-time-max",this.metricGrpName,"The max time taken for a group rejoin"),new Max());
    this.joinLatency.add(createMeter(metrics,metricGrpName,"join","group joins"));
    this.syncLatency=metrics.sensor("sync-latency");
    this.syncLatency.add(metrics.metricName("sync-time-avg",this.metricGrpName,"The average time taken for a group sync"),new Avg());
    this.syncLatency.add(metrics.metricName("sync-time-max",this.metricGrpName,"The max time taken for a group sync"),new Max());
    this.syncLatency.add(createMeter(metrics,metricGrpName,"sync","group syncs"));
    Measurable lastHeartbeat=new Measurable(){
      public double measure(      MetricConfig config,      long now){
        return TimeUnit.SECONDS.convert(now - heartbeat.lastHeartbeatSend(),TimeUnit.MILLISECONDS);
      }
    }
;
    metrics.addMetric(metrics.metricName("last-heartbeat-seconds-ago",this.metricGrpName,"The number of seconds since the last controller heartbeat was sent"),lastHeartbeat);
  }
}
