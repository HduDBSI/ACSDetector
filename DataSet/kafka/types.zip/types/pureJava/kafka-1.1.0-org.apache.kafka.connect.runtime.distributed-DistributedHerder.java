/** 
 * <p> Distributed "herder" that coordinates with other workers to spread work across multiple processes. </p> <p> Under the hood, this is implemented as a group managed by Kafka's group membership facilities (i.e. the generalized group/consumer coordinator). Each instance of DistributedHerder joins the group and indicates what it's current configuration state is (where it is in the configuration log). The group coordinator selects one member to take this information and assign each instance a subset of the active connectors & tasks to execute. This assignment is currently performed in a simple round-robin fashion, but this is not guaranteed -- the herder may also choose to, e.g., use a sticky assignment to avoid the usual start/stop costs associated with connectors and tasks. Once an assignment is received, the DistributedHerder simply runs its assigned connectors and tasks in a Worker. </p> <p> In addition to distributing work, the DistributedHerder uses the leader determined during the work assignment to select a leader for this generation of the group who is responsible for other tasks that can only be performed by a single node at a time. Most importantly, this includes writing updated configurations for connectors and tasks, (and therefore, also for creating, destroy, and scaling up/down connectors). </p> <p> The DistributedHerder uses a single thread for most of its processing. This includes processing config changes, handling task rebalances and serving requests from the HTTP layer. The latter are pushed into a queue until the thread has time to handle them. A consequence of this is that requests can get blocked behind a worker rebalance. When the herder knows that a rebalance is expected, it typically returns an error immediately to the request, but this is not always possible (in particular when another worker has requested the rebalance). Similar to handling HTTP requests, config changes which are observed asynchronously by polling the config log are batched for handling in the work thread. </p>
 */
public class DistributedHerder extends AbstractHerder implements Runnable {
  private static final Logger log=LoggerFactory.getLogger(DistributedHerder.class);
  private static final long RECONFIGURE_CONNECTOR_TASKS_BACKOFF_MS=250;
  private static final int START_STOP_THREAD_POOL_SIZE=8;
  private final AtomicLong requestSeqNum=new AtomicLong();
  private final Time time;
  private final HerderMetrics herderMetrics;
  private final String workerGroupId;
  private final int workerSyncTimeoutMs;
  private final long workerTasksShutdownTimeoutMs;
  private final int workerUnsyncBackoffMs;
  private final ExecutorService herderExecutor;
  private final ExecutorService forwardRequestExecutor;
  private final ExecutorService startAndStopExecutor;
  private final WorkerGroupMember member;
  private final AtomicBoolean stopping;
  private boolean rebalanceResolved;
  private ConnectProtocol.Assignment assignment;
  private boolean canReadConfigs;
  private ClusterConfigState configState;
  final NavigableSet<HerderRequest> requests=new ConcurrentSkipListSet<>();
  private Set<String> connectorConfigUpdates=new HashSet<>();
  private Set<String> connectorTargetStateChanges=new HashSet<>();
  private boolean needsReconfigRebalance;
  private volatile int generation;
  private final DistributedConfig config;
  public DistributedHerder(  DistributedConfig config,  Time time,  Worker worker,  String kafkaClusterId,  StatusBackingStore statusBackingStore,  ConfigBackingStore configBackingStore,  String restUrl){
    this(config,worker,worker.workerId(),kafkaClusterId,statusBackingStore,configBackingStore,null,restUrl,worker.metrics(),time);
    configBackingStore.setUpdateListener(new ConfigUpdateListener());
  }
  DistributedHerder(  DistributedConfig config,  Worker worker,  String workerId,  String kafkaClusterId,  StatusBackingStore statusBackingStore,  ConfigBackingStore configBackingStore,  WorkerGroupMember member,  String restUrl,  ConnectMetrics metrics,  Time time){
    super(worker,workerId,kafkaClusterId,statusBackingStore,configBackingStore);
    this.time=time;
    this.herderMetrics=new HerderMetrics(metrics);
    this.workerGroupId=config.getString(DistributedConfig.GROUP_ID_CONFIG);
    this.workerSyncTimeoutMs=config.getInt(DistributedConfig.WORKER_SYNC_TIMEOUT_MS_CONFIG);
    this.workerTasksShutdownTimeoutMs=config.getLong(DistributedConfig.TASK_SHUTDOWN_GRACEFUL_TIMEOUT_MS_CONFIG);
    this.workerUnsyncBackoffMs=config.getInt(DistributedConfig.WORKER_UNSYNC_BACKOFF_MS_CONFIG);
    this.member=member != null ? member : new WorkerGroupMember(config,restUrl,this.configBackingStore,new RebalanceListener(),time);
    this.herderExecutor=new ThreadPoolExecutor(1,1,0L,TimeUnit.MILLISECONDS,new LinkedBlockingDeque<Runnable>(1),new ThreadFactory(){
      @Override public Thread newThread(      Runnable herder){
        return new Thread(herder,"DistributedHerder");
      }
    }
);
    this.forwardRequestExecutor=Executors.newSingleThreadExecutor();
    this.startAndStopExecutor=Executors.newFixedThreadPool(START_STOP_THREAD_POOL_SIZE);
    this.config=config;
    stopping=new AtomicBoolean(false);
    configState=ClusterConfigState.EMPTY;
    rebalanceResolved=true;
    needsReconfigRebalance=false;
    canReadConfigs=true;
  }
  @Override public void start(){
    this.herderExecutor.submit(this);
  }
  @Override public void run(){
    try {
      log.info("Herder starting");
      startServices();
      log.info("Herder started");
      while (!stopping.get()) {
        tick();
      }
      halt();
      log.info("Herder stopped");
      herderMetrics.close();
    }
 catch (    Throwable t) {
      log.error("Uncaught exception in herder work thread, exiting: ",t);
      Exit.exit(1);
    }
  }
  public void tick(){
    try {
      if (!canReadConfigs && !readConfigToEnd(workerSyncTimeoutMs))       return;
      member.ensureActive();
      if (!handleRebalanceCompleted())       return;
    }
 catch (    WakeupException e) {
      return;
    }
    final long now=time.milliseconds();
    long nextRequestTimeoutMs=Long.MAX_VALUE;
    while (true) {
      final HerderRequest next=peekWithoutException();
      if (next == null) {
        break;
      }
 else       if (now >= next.at) {
        requests.pollFirst();
      }
 else {
        nextRequestTimeoutMs=next.at - now;
        break;
      }
      try {
        next.action().call();
        next.callback().onCompletion(null,null);
      }
 catch (      Throwable t) {
        next.callback().onCompletion(t,null);
      }
    }
    Set<String> connectorConfigUpdatesCopy=null;
    Set<String> connectorTargetStateChangesCopy=null;
synchronized (this) {
      if (needsReconfigRebalance || !connectorConfigUpdates.isEmpty() || !connectorTargetStateChanges.isEmpty()) {
        configState=configBackingStore.snapshot();
        if (needsReconfigRebalance) {
          member.requestRejoin();
          connectorConfigUpdates.clear();
          connectorTargetStateChanges.clear();
          needsReconfigRebalance=false;
          return;
        }
 else {
          if (!connectorConfigUpdates.isEmpty()) {
            connectorConfigUpdatesCopy=connectorConfigUpdates;
            connectorConfigUpdates=new HashSet<>();
          }
          if (!connectorTargetStateChanges.isEmpty()) {
            connectorTargetStateChangesCopy=connectorTargetStateChanges;
            connectorTargetStateChanges=new HashSet<>();
          }
        }
      }
    }
    if (connectorConfigUpdatesCopy != null)     processConnectorConfigUpdates(connectorConfigUpdatesCopy);
    if (connectorTargetStateChangesCopy != null)     processTargetStateChanges(connectorTargetStateChangesCopy);
    try {
      member.poll(nextRequestTimeoutMs);
      handleRebalanceCompleted();
    }
 catch (    WakeupException e) {
    }
  }
  private void processConnectorConfigUpdates(  Set<String> connectorConfigUpdates){
    Set<String> localConnectors=assignment == null ? Collections.<String>emptySet() : new HashSet<>(assignment.connectors());
    for (    String connectorName : connectorConfigUpdates) {
      if (!localConnectors.contains(connectorName))       continue;
      boolean remains=configState.contains(connectorName);
      log.info("Handling connector-only config update by {} connector {}",remains ? "restarting" : "stopping",connectorName);
      worker.stopConnector(connectorName);
      if (remains)       startConnector(connectorName);
    }
  }
  private void processTargetStateChanges(  Set<String> connectorTargetStateChanges){
    for (    String connector : connectorTargetStateChanges) {
      TargetState targetState=configState.targetState(connector);
      if (!configState.connectors().contains(connector)) {
        log.debug("Received target state change for unknown connector: {}",connector);
        continue;
      }
      worker.setTargetState(connector,targetState);
      if (targetState == TargetState.STARTED)       reconfigureConnectorTasksWithRetry(connector);
    }
  }
  public void halt(){
synchronized (this) {
      log.info("Stopping connectors and tasks that are still assigned to this worker.");
      List<Callable<Void>> callables=new ArrayList<>();
      for (      String connectorName : new ArrayList<>(worker.connectorNames())) {
        callables.add(getConnectorStoppingCallable(connectorName));
      }
      for (      ConnectorTaskId taskId : new ArrayList<>(worker.taskIds())) {
        callables.add(getTaskStoppingCallable(taskId));
      }
      startAndStop(callables);
      member.stop();
      HerderRequest request=requests.pollFirst();
      while (request != null) {
        request.callback().onCompletion(new ConnectException("Worker is shutting down"),null);
        request=requests.pollFirst();
      }
      stopServices();
    }
  }
  @Override public void stop(){
    log.info("Herder stopping");
    stopping.set(true);
    member.wakeup();
    herderExecutor.shutdown();
    try {
      if (!herderExecutor.awaitTermination(workerTasksShutdownTimeoutMs,TimeUnit.MILLISECONDS))       herderExecutor.shutdownNow();
      forwardRequestExecutor.shutdown();
      startAndStopExecutor.shutdown();
      if (!forwardRequestExecutor.awaitTermination(10000L,TimeUnit.MILLISECONDS))       forwardRequestExecutor.shutdownNow();
      if (!startAndStopExecutor.awaitTermination(1000L,TimeUnit.MILLISECONDS))       startAndStopExecutor.shutdownNow();
    }
 catch (    InterruptedException e) {
    }
    log.info("Herder stopped");
  }
  @Override public void connectors(  final Callback<Collection<String>> callback){
    log.trace("Submitting connector listing request");
    addRequest(new Callable<Void>(){
      @Override public Void call() throws Exception {
        if (checkRebalanceNeeded(callback))         return null;
        callback.onCompletion(null,configState.connectors());
        return null;
      }
    }
,forwardErrorCallback(callback));
  }
  @Override public void connectorInfo(  final String connName,  final Callback<ConnectorInfo> callback){
    log.trace("Submitting connector info request {}",connName);
    addRequest(new Callable<Void>(){
      @Override public Void call() throws Exception {
        if (checkRebalanceNeeded(callback))         return null;
        if (!configState.contains(connName)) {
          callback.onCompletion(new NotFoundException("Connector " + connName + " not found"),null);
        }
 else {
          Map<String,String> config=configState.connectorConfig(connName);
          callback.onCompletion(null,new ConnectorInfo(connName,config,configState.tasks(connName),connectorTypeForClass(config.get(ConnectorConfig.CONNECTOR_CLASS_CONFIG))));
        }
        return null;
      }
    }
,forwardErrorCallback(callback));
  }
  @Override protected Map<String,String> config(  String connName){
    return configState.connectorConfig(connName);
  }
  @Override public void connectorConfig(  String connName,  final Callback<Map<String,String>> callback){
    log.trace("Submitting connector config read request {}",connName);
    connectorInfo(connName,new Callback<ConnectorInfo>(){
      @Override public void onCompletion(      Throwable error,      ConnectorInfo result){
        if (error != null)         callback.onCompletion(error,null);
 else         callback.onCompletion(null,result.config());
      }
    }
);
  }
  @Override public void deleteConnectorConfig(  final String connName,  final Callback<Created<ConnectorInfo>> callback){
    addRequest(new Callable<Void>(){
      @Override public Void call() throws Exception {
        log.trace("Handling connector config request {}",connName);
        if (!isLeader()) {
          callback.onCompletion(new NotLeaderException("Only the leader can set connector configs.",leaderUrl()),null);
          return null;
        }
        if (!configState.contains(connName)) {
          callback.onCompletion(new NotFoundException("Connector " + connName + " not found"),null);
        }
 else {
          log.trace("Removing connector config {} {}",connName,configState.connectors());
          configBackingStore.removeConnectorConfig(connName);
          callback.onCompletion(null,new Created<ConnectorInfo>(false,null));
        }
        return null;
      }
    }
,forwardErrorCallback(callback));
  }
  @Override protected Map<String,ConfigValue> validateBasicConnectorConfig(  Connector connector,  ConfigDef configDef,  Map<String,String> config){
    Map<String,ConfigValue> validatedConfig=super.validateBasicConnectorConfig(connector,configDef,config);
    if (connector instanceof SinkConnector) {
      ConfigValue validatedName=validatedConfig.get(ConnectorConfig.NAME_CONFIG);
      String name=(String)validatedName.value();
      if (workerGroupId.equals(SinkUtils.consumerGroupId(name))) {
        validatedName.addErrorMessage("Consumer group for sink connector named " + name + " conflicts with Connect worker group "+ workerGroupId);
      }
    }
    return validatedConfig;
  }
  @Override public void putConnectorConfig(  final String connName,  final Map<String,String> config,  final boolean allowReplace,  final Callback<Created<ConnectorInfo>> callback){
    log.trace("Submitting connector config write request {}",connName);
    addRequest(new Callable<Void>(){
      @Override public Void call() throws Exception {
        if (maybeAddConfigErrors(validateConnectorConfig(config),callback)) {
          return null;
        }
        log.trace("Handling connector config request {}",connName);
        if (!isLeader()) {
          callback.onCompletion(new NotLeaderException("Only the leader can set connector configs.",leaderUrl()),null);
          return null;
        }
        boolean exists=configState.contains(connName);
        if (!allowReplace && exists) {
          callback.onCompletion(new AlreadyExistsException("Connector " + connName + " already exists"),null);
          return null;
        }
        log.trace("Submitting connector config {} {} {}",connName,allowReplace,configState.connectors());
        configBackingStore.putConnectorConfig(connName,config);
        Map<String,String> map=configState.connectorConfig(connName);
        ConnectorInfo info=new ConnectorInfo(connName,config,configState.tasks(connName),map == null ? null : connectorTypeForClass(map.get(ConnectorConfig.CONNECTOR_CLASS_CONFIG)));
        callback.onCompletion(null,new Created<>(!exists,info));
        return null;
      }
    }
,forwardErrorCallback(callback));
  }
  @Override public void requestTaskReconfiguration(  final String connName){
    log.trace("Submitting connector task reconfiguration request {}",connName);
    addRequest(new Callable<Void>(){
      @Override public Void call() throws Exception {
        reconfigureConnectorTasksWithRetry(connName);
        return null;
      }
    }
,new Callback<Void>(){
      @Override public void onCompletion(      Throwable error,      Void result){
        if (error != null) {
          log.error("Unexpected error during task reconfiguration: ",error);
          log.error("Task reconfiguration for {} failed unexpectedly, this connector will not be properly reconfigured unless manually triggered.",connName);
        }
      }
    }
);
  }
  @Override public void taskConfigs(  final String connName,  final Callback<List<TaskInfo>> callback){
    log.trace("Submitting get task configuration request {}",connName);
    addRequest(new Callable<Void>(){
      @Override public Void call() throws Exception {
        if (checkRebalanceNeeded(callback))         return null;
        if (!configState.contains(connName)) {
          callback.onCompletion(new NotFoundException("Connector " + connName + " not found"),null);
        }
 else {
          List<TaskInfo> result=new ArrayList<>();
          for (int i=0; i < configState.taskCount(connName); i++) {
            ConnectorTaskId id=new ConnectorTaskId(connName,i);
            result.add(new TaskInfo(id,configState.taskConfig(id)));
          }
          callback.onCompletion(null,result);
        }
        return null;
      }
    }
,forwardErrorCallback(callback));
  }
  @Override public void putTaskConfigs(  final String connName,  final List<Map<String,String>> configs,  final Callback<Void> callback){
    log.trace("Submitting put task configuration request {}",connName);
    addRequest(new Callable<Void>(){
      @Override public Void call() throws Exception {
        if (!isLeader())         callback.onCompletion(new NotLeaderException("Only the leader may write task configurations.",leaderUrl()),null);
 else         if (!configState.contains(connName))         callback.onCompletion(new NotFoundException("Connector " + connName + " not found"),null);
 else {
          configBackingStore.putTaskConfigs(connName,configs);
          callback.onCompletion(null,null);
        }
        return null;
      }
    }
,forwardErrorCallback(callback));
  }
  @Override public void restartConnector(  final String connName,  final Callback<Void> callback){
    addRequest(new Callable<Void>(){
      @Override public Void call() throws Exception {
        if (checkRebalanceNeeded(callback))         return null;
        if (!configState.connectors().contains(connName)) {
          callback.onCompletion(new NotFoundException("Unknown connector: " + connName),null);
          return null;
        }
        if (assignment.connectors().contains(connName)) {
          try {
            worker.stopConnector(connName);
            if (startConnector(connName))             callback.onCompletion(null,null);
 else             callback.onCompletion(new ConnectException("Failed to start connector: " + connName),null);
          }
 catch (          Throwable t) {
            callback.onCompletion(t,null);
          }
        }
 else         if (isLeader()) {
          callback.onCompletion(new NotAssignedException("Cannot restart connector since it is not assigned to this member",member.ownerUrl(connName)),null);
        }
 else {
          callback.onCompletion(new NotLeaderException("Cannot restart connector since it is not assigned to this member",leaderUrl()),null);
        }
        return null;
      }
    }
,forwardErrorCallback(callback));
  }
  @Override public void restartTask(  final ConnectorTaskId id,  final Callback<Void> callback){
    addRequest(new Callable<Void>(){
      @Override public Void call() throws Exception {
        if (checkRebalanceNeeded(callback))         return null;
        if (!configState.connectors().contains(id.connector())) {
          callback.onCompletion(new NotFoundException("Unknown connector: " + id.connector()),null);
          return null;
        }
        if (configState.taskConfig(id) == null) {
          callback.onCompletion(new NotFoundException("Unknown task: " + id),null);
          return null;
        }
        if (assignment.tasks().contains(id)) {
          try {
            worker.stopAndAwaitTask(id);
            if (startTask(id))             callback.onCompletion(null,null);
 else             callback.onCompletion(new ConnectException("Failed to start task: " + id),null);
          }
 catch (          Throwable t) {
            callback.onCompletion(t,null);
          }
        }
 else         if (isLeader()) {
          callback.onCompletion(new NotAssignedException("Cannot restart task since it is not assigned to this member",member.ownerUrl(id)),null);
        }
 else {
          callback.onCompletion(new NotLeaderException("Cannot restart task since it is not assigned to this member",leaderUrl()),null);
        }
        return null;
      }
    }
,forwardErrorCallback(callback));
  }
  @Override public int generation(){
    return generation;
  }
  private boolean isLeader(){
    return assignment != null && member.memberId().equals(assignment.leader());
  }
  /** 
 * Get the URL for the leader's REST interface, or null if we do not have the leader's URL yet.
 */
  private String leaderUrl(){
    if (assignment == null)     return null;
    return assignment.leaderUrl();
  }
  /** 
 * Handle post-assignment operations, either trying to resolve issues that kept assignment from completing, getting this node into sync and its work started. Since
 * @return false if we couldn't finish
 */
  private boolean handleRebalanceCompleted(){
    if (this.rebalanceResolved)     return true;
    boolean needsReadToEnd=false;
    boolean needsRejoin=false;
    if (assignment.failed()) {
      needsRejoin=true;
      if (isLeader()) {
        log.warn("Join group completed, but assignment failed and we are the leader. Reading to end of config and retrying.");
        needsReadToEnd=true;
      }
 else       if (configState.offset() < assignment.offset()) {
        log.warn("Join group completed, but assignment failed and we lagging. Reading to end of config and retrying.");
        needsReadToEnd=true;
      }
 else {
        log.warn("Join group completed, but assignment failed. We were up to date, so just retrying.");
      }
    }
 else {
      if (configState.offset() < assignment.offset()) {
        log.warn("Catching up to assignment's config offset.");
        needsReadToEnd=true;
      }
    }
    if (needsReadToEnd) {
      if (!readConfigToEnd(workerSyncTimeoutMs)) {
        canReadConfigs=false;
        needsRejoin=true;
      }
    }
    if (needsRejoin) {
      member.requestRejoin();
      return false;
    }
    if (configState.offset() != assignment.offset()) {
      log.info("Current config state offset {} does not match group assignment {}. Forcing rebalance.",configState.offset(),assignment.offset());
      member.requestRejoin();
      return false;
    }
    startWork();
    herderMetrics.rebalanceSucceeded(time.milliseconds());
    rebalanceResolved=true;
    return true;
  }
  /** 
 * Try to read to the end of the config log within the given timeout
 * @param timeoutMs maximum time to wait to sync to the end of the log
 * @return true if successful, false if timed out
 */
  private boolean readConfigToEnd(  long timeoutMs){
    log.info("Current config state offset {} is behind group assignment {}, reading to end of config log",configState.offset(),assignment.offset());
    try {
      configBackingStore.refresh(timeoutMs,TimeUnit.MILLISECONDS);
      configState=configBackingStore.snapshot();
      log.info("Finished reading to end of log and updated config snapshot, new config log offset: {}",configState.offset());
      return true;
    }
 catch (    TimeoutException e) {
      log.warn("Didn't reach end of config log quickly enough",e);
      member.maybeLeaveGroup();
      backoff(workerUnsyncBackoffMs);
      return false;
    }
  }
  private void backoff(  long ms){
    Utils.sleep(ms);
  }
  private void startAndStop(  Collection<Callable<Void>> callables){
    try {
      startAndStopExecutor.invokeAll(callables);
    }
 catch (    InterruptedException e) {
    }
  }
  private void startWork(){
    log.info("Starting connectors and tasks using config offset {}",assignment.offset());
    List<Callable<Void>> callables=new ArrayList<>();
    for (    String connectorName : assignment.connectors()) {
      callables.add(getConnectorStartingCallable(connectorName));
    }
    for (    ConnectorTaskId taskId : assignment.tasks()) {
      callables.add(getTaskStartingCallable(taskId));
    }
    startAndStop(callables);
    log.info("Finished starting connectors and tasks");
  }
  private boolean startTask(  ConnectorTaskId taskId){
    log.info("Starting task {}",taskId);
    return worker.startTask(taskId,configState.connectorConfig(taskId.connector()),configState.taskConfig(taskId),this,configState.targetState(taskId.connector()));
  }
  private Callable<Void> getTaskStartingCallable(  final ConnectorTaskId taskId){
    return new Callable<Void>(){
      @Override public Void call() throws Exception {
        try {
          startTask(taskId);
        }
 catch (        Throwable t) {
          log.error("Couldn't instantiate task {} because it has an invalid task configuration. This task will not execute until reconfigured.",taskId,t);
          onFailure(taskId,t);
        }
        return null;
      }
    }
;
  }
  private Callable<Void> getTaskStoppingCallable(  final ConnectorTaskId taskId){
    return new Callable<Void>(){
      @Override public Void call() throws Exception {
        worker.stopAndAwaitTask(taskId);
        return null;
      }
    }
;
  }
  private boolean startConnector(  String connectorName){
    log.info("Starting connector {}",connectorName);
    final Map<String,String> configProps=configState.connectorConfig(connectorName);
    final ConnectorContext ctx=new HerderConnectorContext(this,connectorName);
    final TargetState initialState=configState.targetState(connectorName);
    boolean started=worker.startConnector(connectorName,configProps,ctx,this,initialState);
    if (started && initialState == TargetState.STARTED)     reconfigureConnectorTasksWithRetry(connectorName);
    return started;
  }
  private Callable<Void> getConnectorStartingCallable(  final String connectorName){
    return new Callable<Void>(){
      @Override public Void call() throws Exception {
        try {
          startConnector(connectorName);
        }
 catch (        Throwable t) {
          log.error("Couldn't instantiate connector " + connectorName + " because it has an invalid connector "+ "configuration. This connector will not execute until reconfigured.",t);
          onFailure(connectorName,t);
        }
        return null;
      }
    }
;
  }
  private Callable<Void> getConnectorStoppingCallable(  final String connectorName){
    return new Callable<Void>(){
      @Override public Void call() throws Exception {
        try {
          worker.stopConnector(connectorName);
        }
 catch (        Throwable t) {
          log.error("Failed to shut down connector " + connectorName,t);
        }
        return null;
      }
    }
;
  }
  private void reconfigureConnectorTasksWithRetry(  final String connName){
    reconfigureConnector(connName,new Callback<Void>(){
      @Override public void onCompletion(      Throwable error,      Void result){
        if (error != null) {
          log.error("Failed to reconfigure connector's tasks, retrying after backoff:",error);
          addRequest(RECONFIGURE_CONNECTOR_TASKS_BACKOFF_MS,new Callable<Void>(){
            @Override public Void call() throws Exception {
              reconfigureConnectorTasksWithRetry(connName);
              return null;
            }
          }
,new Callback<Void>(){
            @Override public void onCompletion(            Throwable error,            Void result){
              log.error("Unexpected error during connector task reconfiguration: ",error);
              log.error("Task reconfiguration for {} failed unexpectedly, this connector will not be properly reconfigured unless manually triggered.",connName);
            }
          }
);
        }
      }
    }
);
  }
  private void reconfigureConnector(  final String connName,  final Callback<Void> cb){
    try {
      if (!worker.isRunning(connName)) {
        log.info("Skipping reconfiguration of connector {} since it is not running",connName);
        return;
      }
      Map<String,String> configs=configState.connectorConfig(connName);
      ConnectorConfig connConfig;
      if (worker.isSinkConnector(connName)) {
        connConfig=new SinkConnectorConfig(plugins(),configs);
      }
 else {
        connConfig=new SourceConnectorConfig(plugins(),configs);
      }
      final List<Map<String,String>> taskProps=worker.connectorTaskConfigs(connName,connConfig);
      boolean changed=false;
      int currentNumTasks=configState.taskCount(connName);
      if (taskProps.size() != currentNumTasks) {
        log.debug("Change in connector task count from {} to {}, writing updated task configurations",currentNumTasks,taskProps.size());
        changed=true;
      }
 else {
        int index=0;
        for (        Map<String,String> taskConfig : taskProps) {
          if (!taskConfig.equals(configState.taskConfig(new ConnectorTaskId(connName,index)))) {
            log.debug("Change in task configurations, writing updated task configurations");
            changed=true;
            break;
          }
          index++;
        }
      }
      if (changed) {
        if (isLeader()) {
          configBackingStore.putTaskConfigs(connName,taskProps);
          cb.onCompletion(null,null);
        }
 else {
          forwardRequestExecutor.submit(new Runnable(){
            @Override public void run(){
              try {
                String reconfigUrl=RestServer.urlJoin(leaderUrl(),"/connectors/" + connName + "/tasks");
                RestClient.httpRequest(reconfigUrl,"POST",taskProps,null,config);
                cb.onCompletion(null,null);
              }
 catch (              ConnectException e) {
                log.error("Request to leader to reconfigure connector tasks failed",e);
                cb.onCompletion(e,null);
              }
            }
          }
);
        }
      }
    }
 catch (    Throwable t) {
      cb.onCompletion(t,null);
    }
  }
  private boolean checkRebalanceNeeded(  Callback<?> callback){
    if (needsReconfigRebalance) {
      callback.onCompletion(new RebalanceNeededException("Request cannot be completed because a rebalance is expected"),null);
      return true;
    }
    return false;
  }
  HerderRequest addRequest(  Callable<Void> action,  Callback<Void> callback){
    return addRequest(0,action,callback);
  }
  HerderRequest addRequest(  long delayMs,  Callable<Void> action,  Callback<Void> callback){
    HerderRequest req=new HerderRequest(time.milliseconds() + delayMs,requestSeqNum.incrementAndGet(),action,callback);
    requests.add(req);
    if (peekWithoutException() == req)     member.wakeup();
    return req;
  }
  private HerderRequest peekWithoutException(){
    try {
      return requests.isEmpty() ? null : requests.first();
    }
 catch (    NoSuchElementException e) {
    }
    return null;
  }
public class ConfigUpdateListener implements ConfigBackingStore.UpdateListener {
    @Override public void onConnectorConfigRemove(    String connector){
      log.info("Connector {} config removed",connector);
synchronized (DistributedHerder.this) {
        if (configState.contains(connector))         needsReconfigRebalance=true;
        connectorConfigUpdates.add(connector);
      }
      member.wakeup();
    }
    @Override public void onConnectorConfigUpdate(    String connector){
      log.info("Connector {} config updated",connector);
synchronized (DistributedHerder.this) {
        if (!configState.contains(connector))         needsReconfigRebalance=true;
        connectorConfigUpdates.add(connector);
      }
      member.wakeup();
    }
    @Override public void onTaskConfigUpdate(    Collection<ConnectorTaskId> tasks){
      log.info("Tasks {} configs updated",tasks);
synchronized (DistributedHerder.this) {
        needsReconfigRebalance=true;
      }
      member.wakeup();
    }
    @Override public void onConnectorTargetStateChange(    String connector){
      log.info("Connector {} target state change",connector);
synchronized (DistributedHerder.this) {
        connectorTargetStateChanges.add(connector);
      }
      member.wakeup();
    }
  }
static class HerderRequest implements Comparable<HerderRequest> {
    private final long at;
    private final long seq;
    private final Callable<Void> action;
    private final Callback<Void> callback;
    public HerderRequest(    long at,    long seq,    Callable<Void> action,    Callback<Void> callback){
      this.at=at;
      this.seq=seq;
      this.action=action;
      this.callback=callback;
    }
    public Callable<Void> action(){
      return action;
    }
    public Callback<Void> callback(){
      return callback;
    }
    @Override public int compareTo(    HerderRequest o){
      final int cmp=Long.compare(at,o.at);
      return cmp == 0 ? Long.compare(seq,o.seq) : cmp;
    }
    @Override public boolean equals(    Object o){
      if (this == o)       return true;
      if (!(o instanceof HerderRequest))       return false;
      HerderRequest other=(HerderRequest)o;
      return compareTo(other) == 0;
    }
    @Override public int hashCode(){
      return Objects.hash(at,seq);
    }
  }
  private static final Callback<Void> forwardErrorCallback(  final Callback<?> callback){
    return new Callback<Void>(){
      @Override public void onCompletion(      Throwable error,      Void result){
        if (error != null)         callback.onCompletion(error,null);
      }
    }
;
  }
  private void updateDeletedConnectorStatus(){
    ClusterConfigState snapshot=configBackingStore.snapshot();
    Set<String> connectors=snapshot.connectors();
    for (    String connector : statusBackingStore.connectors()) {
      if (!connectors.contains(connector)) {
        log.debug("Cleaning status information for connector {}",connector);
        onDeletion(connector);
      }
    }
  }
  protected HerderMetrics herderMetrics(){
    return herderMetrics;
  }
public class RebalanceListener implements WorkerRebalanceListener {
    @Override public void onAssigned(    ConnectProtocol.Assignment assignment,    int generation){
      log.info("Joined group and got assignment: {}",assignment);
synchronized (DistributedHerder.this) {
        DistributedHerder.this.assignment=assignment;
        DistributedHerder.this.generation=generation;
        rebalanceResolved=false;
        herderMetrics.rebalanceStarted(time.milliseconds());
      }
      if (isLeader())       updateDeletedConnectorStatus();
      member.wakeup();
    }
    @Override public void onRevoked(    String leader,    Collection<String> connectors,    Collection<ConnectorTaskId> tasks){
      log.info("Rebalance started");
      if (rebalanceResolved) {
        List<Callable<Void>> callables=new ArrayList<>();
        for (        final String connectorName : connectors) {
          callables.add(getConnectorStoppingCallable(connectorName));
        }
        for (        final ConnectorTaskId taskId : tasks) {
          callables.add(getTaskStoppingCallable(taskId));
        }
        startAndStop(callables);
        statusBackingStore.flush();
        log.info("Finished stopping tasks in preparation for rebalance");
      }
 else {
        log.info("Wasn't unable to resume work after last rebalance, can skip stopping connectors and tasks");
      }
    }
  }
class HerderMetrics {
    private final MetricGroup metricGroup;
    private final Sensor rebalanceCompletedCounts;
    private final Sensor rebalanceTime;
    private volatile long lastRebalanceCompletedAtMillis=Long.MIN_VALUE;
    private volatile boolean rebalancing=false;
    private volatile long rebalanceStartedAtMillis=0L;
    public HerderMetrics(    ConnectMetrics connectMetrics){
      ConnectMetricsRegistry registry=connectMetrics.registry();
      metricGroup=connectMetrics.group(registry.workerRebalanceGroupName());
      metricGroup.addValueMetric(registry.leaderName,new LiteralSupplier<String>(){
        @Override public String metricValue(        long now){
          return leaderUrl();
        }
      }
);
      metricGroup.addValueMetric(registry.epoch,new LiteralSupplier<Double>(){
        @Override public Double metricValue(        long now){
          return (double)generation;
        }
      }
);
      metricGroup.addValueMetric(registry.rebalanceMode,new LiteralSupplier<Double>(){
        @Override public Double metricValue(        long now){
          return rebalancing ? 1.0d : 0.0d;
        }
      }
);
      rebalanceCompletedCounts=metricGroup.sensor("completed-rebalance-count");
      rebalanceCompletedCounts.add(metricGroup.metricName(registry.rebalanceCompletedTotal),new Total());
      rebalanceTime=metricGroup.sensor("rebalance-time");
      rebalanceTime.add(metricGroup.metricName(registry.rebalanceTimeMax),new Max());
      rebalanceTime.add(metricGroup.metricName(registry.rebalanceTimeAvg),new Avg());
      metricGroup.addValueMetric(registry.rebalanceTimeSinceLast,new LiteralSupplier<Double>(){
        @Override public Double metricValue(        long now){
          return lastRebalanceCompletedAtMillis == Long.MIN_VALUE ? Double.POSITIVE_INFINITY : (double)(now - lastRebalanceCompletedAtMillis);
        }
      }
);
    }
    void close(){
      metricGroup.close();
    }
    void rebalanceStarted(    long now){
      rebalanceStartedAtMillis=now;
      rebalancing=true;
    }
    void rebalanceSucceeded(    long now){
      long duration=Math.max(0L,now - rebalanceStartedAtMillis);
      rebalancing=false;
      rebalanceCompletedCounts.record(1.0);
      rebalanceTime.record(duration);
      lastRebalanceCompletedAtMillis=now;
    }
    protected MetricGroup metricGroup(){
      return metricGroup;
    }
  }
}
