/** 
 * MinTimestampTracker implements  {@link TimestampTracker} that maintains the mintimestamp of the maintained stamped elements.
 */
public class MinTimestampTracker<E> implements TimestampTracker<E> {
  private final LinkedList<Stamped<E>> descendingSubsequence=new LinkedList<>();
  private long lastKnownTime=NOT_KNOWN;
  /** 
 * @throws NullPointerException if the element is null
 */
  public void addElement(  final Stamped<E> elem){
    if (elem == null)     throw new NullPointerException();
    Stamped<E> minElem=descendingSubsequence.peekLast();
    while (minElem != null && minElem.timestamp >= elem.timestamp) {
      descendingSubsequence.removeLast();
      minElem=descendingSubsequence.peekLast();
    }
    descendingSubsequence.offerLast(elem);
  }
  public void removeElement(  final Stamped<E> elem){
    if (elem == null) {
      return;
    }
    if (descendingSubsequence.peekFirst() == elem) {
      descendingSubsequence.removeFirst();
    }
    if (descendingSubsequence.isEmpty()) {
      lastKnownTime=elem.timestamp;
    }
  }
  public int size(){
    return descendingSubsequence.size();
  }
  public long get(){
    Stamped<E> stamped=descendingSubsequence.peekFirst();
    if (stamped == null)     return lastKnownTime;
 else     return stamped.timestamp;
  }
}
