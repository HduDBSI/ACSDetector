public class ConsumerRecordTest {
  @Test @SuppressWarnings("deprecation") public void testOldConstructor(){
    String topic="topic";
    int partition=0;
    long offset=23;
    String key="key";
    String value="value";
    ConsumerRecord<String,String> record=new ConsumerRecord<>(topic,partition,offset,key,value);
    assertEquals(topic,record.topic());
    assertEquals(partition,record.partition());
    assertEquals(offset,record.offset());
    assertEquals(key,record.key());
    assertEquals(value,record.value());
    assertEquals(TimestampType.NO_TIMESTAMP_TYPE,record.timestampType());
    assertEquals(ConsumerRecord.NO_TIMESTAMP,record.timestamp());
    assertEquals(ConsumerRecord.NULL_CHECKSUM,record.checksum());
    assertEquals(ConsumerRecord.NULL_SIZE,record.serializedKeySize());
    assertEquals(ConsumerRecord.NULL_SIZE,record.serializedValueSize());
    assertEquals(new RecordHeaders(),record.headers());
  }
  @Test @SuppressWarnings("deprecation") public void testNullChecksumInConstructor(){
    String key="key";
    String value="value";
    long timestamp=242341324L;
    ConsumerRecord<String,String> record=new ConsumerRecord<>("topic",0,23L,timestamp,TimestampType.CREATE_TIME,null,key.length(),value.length(),key,value,new RecordHeaders());
    assertEquals(DefaultRecord.computePartialChecksum(timestamp,key.length(),value.length()),record.checksum());
  }
}
