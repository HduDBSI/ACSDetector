/** 
 * KTable repartition map functions are not exposed to public APIs, but only used for keyed aggregations. Given the input, it can output at most two records (one mapped from old value and one mapped from new value).
 */
public class KTableRepartitionMap<K,V,K1,V1> implements KTableProcessorSupplier<K,V,KeyValue<K1,V1>> {
  private final KTableImpl<K,?,V> parent;
  private final KeyValueMapper<? super K,? super V,KeyValue<K1,V1>> mapper;
  KTableRepartitionMap(  final KTableImpl<K,?,V> parent,  final KeyValueMapper<? super K,? super V,KeyValue<K1,V1>> mapper){
    this.parent=parent;
    this.mapper=mapper;
  }
  @Override public Processor<K,Change<V>> get(){
    return new KTableMapProcessor();
  }
  @Override public KTableValueGetterSupplier<K,KeyValue<K1,V1>> view(){
    final KTableValueGetterSupplier<K,V> parentValueGetterSupplier=parent.valueGetterSupplier();
    return new KTableValueGetterSupplier<K,KeyValue<K1,V1>>(){
      public KTableValueGetter<K,KeyValue<K1,V1>> get(){
        return new KTableMapValueGetter(parentValueGetterSupplier.get());
      }
      @Override public String[] storeNames(){
        throw new StreamsException("Underlying state store not accessible due to repartitioning.");
      }
    }
;
  }
  /** 
 * @throws IllegalStateException since this method should never be called
 */
  @Override public void enableSendingOldValues(){
    throw new IllegalStateException("KTableRepartitionMap should always require sending old values.");
  }
private class KTableMapProcessor extends AbstractProcessor<K,Change<V>> {
    /** 
 * @throws StreamsException if key is null
 */
    @Override public void process(    K key,    Change<V> change){
      if (key == null)       throw new StreamsException("Record key for the grouping KTable should not be null.");
      KeyValue<? extends K1,? extends V1> newPair=change.newValue == null ? null : mapper.apply(key,change.newValue);
      KeyValue<? extends K1,? extends V1> oldPair=change.oldValue == null ? null : mapper.apply(key,change.oldValue);
      if (oldPair != null && oldPair.key != null && oldPair.value != null) {
        context().forward(oldPair.key,new Change<>(null,oldPair.value));
      }
      if (newPair != null && newPair.key != null && newPair.value != null) {
        context().forward(newPair.key,new Change<>(newPair.value,null));
      }
    }
  }
private class KTableMapValueGetter implements KTableValueGetter<K,KeyValue<K1,V1>> {
    private final KTableValueGetter<K,V> parentGetter;
    KTableMapValueGetter(    final KTableValueGetter<K,V> parentGetter){
      this.parentGetter=parentGetter;
    }
    @Override public void init(    final ProcessorContext context){
      parentGetter.init(context);
    }
    @Override public KeyValue<K1,V1> get(    final K key){
      return mapper.apply(key,parentGetter.get(key));
    }
  }
}
