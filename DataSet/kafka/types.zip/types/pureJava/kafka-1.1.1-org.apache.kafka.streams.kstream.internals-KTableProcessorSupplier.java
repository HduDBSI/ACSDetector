public interface KTableProcessorSupplier<K,V,T> extends ProcessorSupplier<K,Change<V>> {
  KTableValueGetterSupplier<K,T> view();
  void enableSendingOldValues();
}
