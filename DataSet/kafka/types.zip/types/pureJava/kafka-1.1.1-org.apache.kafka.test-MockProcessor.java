public class MockProcessor extends AbstractProcessor<K,V> {
  PunctuationType punctuationType;
  public MockProcessor(  PunctuationType punctuationType){
    this.punctuationType=punctuationType;
  }
  @Override public void init(  ProcessorContext context){
    super.init(context);
    if (scheduleInterval > 0L) {
      scheduleCancellable=context.schedule(scheduleInterval,punctuationType,new Punctuator(){
        @Override public void punctuate(        long timestamp){
          if (punctuationType == PunctuationType.STREAM_TIME) {
            assertEquals(timestamp,context().timestamp());
          }
          assertEquals(-1,context().partition());
          assertEquals(-1L,context().offset());
          (punctuationType == PunctuationType.STREAM_TIME ? punctuatedStreamTime : punctuatedSystemTime).add(timestamp);
        }
      }
);
    }
  }
  @Override public void process(  K key,  V value){
    processedKeys.add(key);
    processedValues.add(value);
    processed.add((key == null ? "null" : key) + ":" + (value == null ? "null" : value));
  }
}
