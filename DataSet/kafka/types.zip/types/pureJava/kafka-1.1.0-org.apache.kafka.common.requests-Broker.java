public static final class Broker {
  public final int id;
  public final List<EndPoint> endPoints;
  public final String rack;
  public Broker(  int id,  List<EndPoint> endPoints,  String rack){
    this.id=id;
    this.endPoints=endPoints;
    this.rack=rack;
  }
  @Override public String toString(){
    StringBuilder bld=new StringBuilder();
    bld.append("(id=").append(id);
    bld.append(", endPoints=").append(Utils.join(endPoints,","));
    bld.append(", rack=").append(rack);
    bld.append(")");
    return bld.toString();
  }
}
