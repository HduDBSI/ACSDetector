private static class MyProcessorSupplier implements ProcessorSupplier<String,String> {
  @Override public Processor<String,String> get(){
    return new Processor<String,String>(){
      private ProcessorContext context;
      private KeyValueStore<String,Integer> kvStore;
      @Override @SuppressWarnings("unchecked") public void init(      final ProcessorContext context){
        this.context=context;
        this.context.schedule(1000,PunctuationType.STREAM_TIME,new Punctuator(){
          @Override public void punctuate(          long timestamp){
            try (KeyValueIterator<String,Integer> iter=kvStore.all()){
              System.out.println("----------- " + timestamp + " ----------- ");
              while (iter.hasNext()) {
                KeyValue<String,Integer> entry=iter.next();
                System.out.println("[" + entry.key + ", "+ entry.value+ "]");
                context.forward(entry.key,entry.value.toString());
              }
            }
           }
        }
);
        this.kvStore=(KeyValueStore<String,Integer>)context.getStateStore("Counts");
      }
      @Override public void process(      String dummy,      String line){
        String[] words=line.toLowerCase(Locale.getDefault()).split(" ");
        for (        String word : words) {
          Integer oldValue=this.kvStore.get(word);
          if (oldValue == null) {
            this.kvStore.put(word,1);
          }
 else {
            this.kvStore.put(word,oldValue + 1);
          }
        }
        context.commit();
      }
      @Override @Deprecated public void punctuate(      long timestamp){
      }
      @Override public void close(){
      }
    }
;
  }
}
