/** 
 * Abstract assignor implementation which does some common grunt work (in particular collecting partition counts which are always needed in assignors).
 */
public abstract class AbstractPartitionAssignor implements PartitionAssignor {
  private static final Logger log=LoggerFactory.getLogger(AbstractPartitionAssignor.class);
  /** 
 * Perform the group assignment given the partition counts and member subscriptions
 * @param partitionsPerTopic The number of partitions for each subscribed topic. Topics not in metadata will be excludedfrom this map.
 * @param subscriptions Map from the memberId to their respective topic subscription
 * @return Map from each member to the list of partitions assigned to them.
 */
  public abstract Map<String,List<TopicPartition>> assign(  Map<String,Integer> partitionsPerTopic,  Map<String,List<String>> subscriptions);
  @Override public Subscription subscription(  Set<String> topics){
    return new Subscription(new ArrayList<>(topics));
  }
  @Override public Map<String,Assignment> assign(  Cluster metadata,  Map<String,Subscription> subscriptions){
    Set<String> allSubscribedTopics=new HashSet<>();
    Map<String,List<String>> topicSubscriptions=new HashMap<>();
    for (    Map.Entry<String,Subscription> subscriptionEntry : subscriptions.entrySet()) {
      List<String> topics=subscriptionEntry.getValue().topics();
      allSubscribedTopics.addAll(topics);
      topicSubscriptions.put(subscriptionEntry.getKey(),topics);
    }
    Map<String,Integer> partitionsPerTopic=new HashMap<>();
    for (    String topic : allSubscribedTopics) {
      Integer numPartitions=metadata.partitionCountForTopic(topic);
      if (numPartitions != null && numPartitions > 0)       partitionsPerTopic.put(topic,numPartitions);
 else       log.debug("Skipping assignment for topic {} since no metadata is available",topic);
    }
    Map<String,List<TopicPartition>> rawAssignments=assign(partitionsPerTopic,topicSubscriptions);
    Map<String,Assignment> assignments=new HashMap<>();
    for (    Map.Entry<String,List<TopicPartition>> assignmentEntry : rawAssignments.entrySet())     assignments.put(assignmentEntry.getKey(),new Assignment(assignmentEntry.getValue()));
    return assignments;
  }
  @Override public void onAssignment(  Assignment assignment){
  }
  protected static <K,V>void put(  Map<K,List<V>> map,  K key,  V value){
    List<V> list=map.get(key);
    if (list == null) {
      list=new ArrayList<>();
      map.put(key,list);
    }
    list.add(value);
  }
  protected static List<TopicPartition> partitions(  String topic,  int numPartitions){
    List<TopicPartition> partitions=new ArrayList<>(numPartitions);
    for (int i=0; i < numPartitions; i++)     partitions.add(new TopicPartition(topic,i));
    return partitions;
  }
}
