/** 
 * The state of our connection to a node
 */
final class NodeConnectionState {
  ConnectionState state;
  long lastConnectAttemptMs;
  public NodeConnectionState(  ConnectionState state,  long lastConnectAttempt){
    this.state=state;
    this.lastConnectAttemptMs=lastConnectAttempt;
  }
  public String toString(){
    return "NodeState(" + state + ", "+ lastConnectAttemptMs+ ")";
  }
}
