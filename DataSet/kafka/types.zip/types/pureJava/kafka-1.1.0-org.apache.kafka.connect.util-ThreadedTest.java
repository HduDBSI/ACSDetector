/** 
 * Base class for tests that use threads. It sets up uncaught exception handlers for all known thread classes and checks for errors at the end of the test so that failures in background threads will cause the test to fail.
 */
public class ThreadedTest {
  protected TestBackgroundThreadExceptionHandler backgroundThreadExceptionHandler;
  @Before public void setup(){
    backgroundThreadExceptionHandler=new TestBackgroundThreadExceptionHandler();
    ShutdownableThread.funcaughtExceptionHandler=backgroundThreadExceptionHandler;
  }
  @After public void teardown(){
    backgroundThreadExceptionHandler.verifyNoExceptions();
    ShutdownableThread.funcaughtExceptionHandler=null;
  }
}
