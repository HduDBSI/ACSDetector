private interface LogicalTypeConverter {
  Object convert(  Schema schema,  Object value);
}
