private static class SetCallbackFuture implements org.apache.kafka.clients.producer.Callback, Future<Void> {
  private int numLeft;
  private boolean completed=false;
  private Throwable exception=null;
  private final Callback<Void> callback;
  public SetCallbackFuture(  int numRecords,  Callback<Void> callback){
    numLeft=numRecords;
    this.callback=callback;
  }
  @Override public synchronized void onCompletion(  RecordMetadata metadata,  Exception exception){
    if (exception != null) {
      if (!completed) {
        this.exception=exception;
        callback.onCompletion(exception,null);
        completed=true;
        this.notify();
      }
      return;
    }
    numLeft-=1;
    if (numLeft == 0) {
      callback.onCompletion(null,null);
      completed=true;
      this.notify();
    }
  }
  @Override public synchronized boolean cancel(  boolean mayInterruptIfRunning){
    return false;
  }
  @Override public synchronized boolean isCancelled(){
    return false;
  }
  @Override public synchronized boolean isDone(){
    return completed;
  }
  @Override public synchronized Void get() throws InterruptedException, ExecutionException {
    while (!completed) {
      this.wait();
    }
    if (exception != null)     throw new ExecutionException(exception);
    return null;
  }
  @Override public synchronized Void get(  long timeout,  TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
    long started=System.currentTimeMillis();
    long limit=started + unit.toMillis(timeout);
    while (!completed) {
      long leftMs=limit - System.currentTimeMillis();
      if (leftMs < 0)       throw new TimeoutException("KafkaOffsetBackingStore Future timed out.");
      this.wait(leftMs);
    }
    if (exception != null)     throw new ExecutionException(exception);
    return null;
  }
}
