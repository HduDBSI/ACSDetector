private static class TestProcessor extends AbstractProcessor<String,String> {
  public final ArrayList<Long> punctuatedAt=new ArrayList<>();
  @Override public void init(  ProcessorContext context){
  }
  @Override public void process(  String key,  String value){
  }
  @Override public void punctuate(  long streamTime){
    punctuatedAt.add(streamTime);
  }
  @Override public void close(){
  }
}
