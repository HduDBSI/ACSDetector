/** 
 * Since we parse the message data for each partition from each fetch response lazily, fetch-level metrics need to be aggregated as the messages from each partition are parsed. This class is used to facilitate this incremental aggregation.
 */
private static class FetchResponseMetricAggregator {
  private final FetchManagerMetrics sensors;
  private final Set<TopicPartition> unrecordedPartitions;
  private final FetchMetrics fetchMetrics=new FetchMetrics();
  private final Map<String,FetchMetrics> topicFetchMetrics=new HashMap<>();
  private FetchResponseMetricAggregator(  FetchManagerMetrics sensors,  Set<TopicPartition> partitions){
    this.sensors=sensors;
    this.unrecordedPartitions=partitions;
  }
  /** 
 * After each partition is parsed, we update the current metric totals with the total bytes and number of records parsed. After all partitions have reported, we write the metric.
 */
  public void record(  TopicPartition partition,  int bytes,  int records){
    this.unrecordedPartitions.remove(partition);
    this.fetchMetrics.increment(bytes,records);
    String topic=partition.topic();
    FetchMetrics topicFetchMetric=this.topicFetchMetrics.get(topic);
    if (topicFetchMetric == null) {
      topicFetchMetric=new FetchMetrics();
      this.topicFetchMetrics.put(topic,topicFetchMetric);
    }
    topicFetchMetric.increment(bytes,records);
    if (this.unrecordedPartitions.isEmpty()) {
      this.sensors.bytesFetched.record(this.fetchMetrics.fetchBytes);
      this.sensors.recordsFetched.record(this.fetchMetrics.fetchRecords);
      for (      Map.Entry<String,FetchMetrics> entry : this.topicFetchMetrics.entrySet()) {
        FetchMetrics metric=entry.getValue();
        this.sensors.recordTopicFetchMetrics(entry.getKey(),metric.fetchBytes,metric.fetchRecords);
      }
    }
  }
private static class FetchMetrics {
    private int fetchBytes;
    private int fetchRecords;
    protected void increment(    int bytes,    int records){
      this.fetchBytes+=bytes;
      this.fetchRecords+=records;
    }
  }
}
