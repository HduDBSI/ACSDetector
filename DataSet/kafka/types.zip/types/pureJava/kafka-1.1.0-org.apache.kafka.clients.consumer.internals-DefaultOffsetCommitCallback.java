private class DefaultOffsetCommitCallback implements OffsetCommitCallback {
  @Override public void onComplete(  Map<TopicPartition,OffsetAndMetadata> offsets,  Exception exception){
    if (exception != null)     log.error("Offset commit with offsets {} failed",offsets,exception);
  }
}
