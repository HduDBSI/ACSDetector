/** 
 * Exception thrown if a create topics request does not satisfy the configured policy for a topic.
 */
public class PolicyViolationException extends ApiException {
  public PolicyViolationException(  String message){
    super(message);
  }
  public PolicyViolationException(  String message,  Throwable cause){
    super(message,cause);
  }
}
