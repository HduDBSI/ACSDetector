/** 
 * The result of the  {@link KafkaAdminClient#describeConfigs(Collection)} call.The API of this class is evolving, see  {@link AdminClient} for details.
 */
@InterfaceStability.Evolving public class DescribeConfigsResult {
  private final Map<ConfigResource,KafkaFuture<Config>> futures;
  DescribeConfigsResult(  Map<ConfigResource,KafkaFuture<Config>> futures){
    this.futures=futures;
  }
  /** 
 * Return a map from resources to futures which can be used to check the status of the configuration for each resource.
 */
  public Map<ConfigResource,KafkaFuture<Config>> values(){
    return futures;
  }
  /** 
 * Return a future which succeeds only if all the config descriptions succeed.
 */
  public KafkaFuture<Map<ConfigResource,Config>> all(){
    return KafkaFuture.allOf(futures.values().toArray(new KafkaFuture[0])).thenApply(new KafkaFuture.Function<Void,Map<ConfigResource,Config>>(){
      @Override public Map<ConfigResource,Config> apply(      Void v){
        Map<ConfigResource,Config> configs=new HashMap<>(futures.size());
        for (        Map.Entry<ConfigResource,KafkaFuture<Config>> entry : futures.entrySet()) {
          try {
            configs.put(entry.getKey(),entry.getValue().get());
          }
 catch (          InterruptedException|ExecutionException e) {
            throw new RuntimeException(e);
          }
        }
        return configs;
      }
    }
);
  }
}
