private static class DeepRecordsIterator extends AbstractIterator<Record> implements CloseableIterator<Record> {
  private final ArrayDeque<AbstractLegacyRecordBatch> innerEntries;
  private final long absoluteBaseOffset;
  private final byte wrapperMagic;
  private DeepRecordsIterator(  AbstractLegacyRecordBatch wrapperEntry,  boolean ensureMatchingMagic,  int maxMessageSize,  BufferSupplier bufferSupplier){
    LegacyRecord wrapperRecord=wrapperEntry.outerRecord();
    this.wrapperMagic=wrapperRecord.magic();
    if (wrapperMagic != RecordBatch.MAGIC_VALUE_V0 && wrapperMagic != RecordBatch.MAGIC_VALUE_V1)     throw new InvalidRecordException("Invalid wrapper magic found in legacy deep record iterator " + wrapperMagic);
    CompressionType compressionType=wrapperRecord.compressionType();
    ByteBuffer wrapperValue=wrapperRecord.value();
    if (wrapperValue == null)     throw new InvalidRecordException("Found invalid compressed record set with null value (magic = " + wrapperMagic + ")");
    InputStream stream=compressionType.wrapForInput(wrapperValue,wrapperRecord.magic(),bufferSupplier);
    LogInputStream<AbstractLegacyRecordBatch> logStream=new DataLogInputStream(stream,maxMessageSize);
    long lastOffsetFromWrapper=wrapperEntry.lastOffset();
    long timestampFromWrapper=wrapperRecord.timestamp();
    this.innerEntries=new ArrayDeque<>();
    try {
      while (true) {
        AbstractLegacyRecordBatch innerEntry=logStream.nextBatch();
        if (innerEntry == null)         break;
        LegacyRecord record=innerEntry.outerRecord();
        byte magic=record.magic();
        if (ensureMatchingMagic && magic != wrapperMagic)         throw new InvalidRecordException("Compressed message magic " + magic + " does not match wrapper magic "+ wrapperMagic);
        if (magic == RecordBatch.MAGIC_VALUE_V1) {
          LegacyRecord recordWithTimestamp=new LegacyRecord(record.buffer(),timestampFromWrapper,wrapperRecord.timestampType());
          innerEntry=new BasicLegacyRecordBatch(innerEntry.lastOffset(),recordWithTimestamp);
        }
        innerEntries.addLast(innerEntry);
      }
      if (innerEntries.isEmpty())       throw new InvalidRecordException("Found invalid compressed record set with no inner records");
      if (wrapperMagic == RecordBatch.MAGIC_VALUE_V1) {
        if (lastOffsetFromWrapper == 0) {
          this.absoluteBaseOffset=0;
        }
 else {
          long lastInnerOffset=innerEntries.getLast().offset();
          if (lastOffsetFromWrapper < lastInnerOffset)           throw new InvalidRecordException("Found invalid wrapper offset in compressed v1 message set, " + "wrapper offset '" + lastOffsetFromWrapper + "' is less than the last inner message "+ "offset '"+ lastInnerOffset+ "' and it is not zero.");
          this.absoluteBaseOffset=lastOffsetFromWrapper - lastInnerOffset;
        }
      }
 else {
        this.absoluteBaseOffset=-1;
      }
    }
 catch (    IOException e) {
      throw new KafkaException(e);
    }
 finally {
      Utils.closeQuietly(stream,"records iterator stream");
    }
  }
  @Override protected Record makeNext(){
    if (innerEntries.isEmpty())     return allDone();
    AbstractLegacyRecordBatch entry=innerEntries.remove();
    if (wrapperMagic == RecordBatch.MAGIC_VALUE_V1) {
      long absoluteOffset=absoluteBaseOffset + entry.offset();
      entry=new BasicLegacyRecordBatch(absoluteOffset,entry.outerRecord());
    }
    if (entry.isCompressed())     throw new InvalidRecordException("Inner messages must not be compressed");
    return entry;
  }
  @Override public void close(){
  }
}
