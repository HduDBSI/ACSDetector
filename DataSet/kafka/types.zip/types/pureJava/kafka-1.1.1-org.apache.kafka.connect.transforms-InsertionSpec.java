private static final class InsertionSpec {
  final String name;
  final boolean optional;
  private InsertionSpec(  String name,  boolean optional){
    this.name=name;
    this.optional=optional;
  }
  public static InsertionSpec parse(  String spec){
    if (spec == null)     return null;
    if (spec.endsWith("?")) {
      return new InsertionSpec(spec.substring(0,spec.length() - 1),true);
    }
    if (spec.endsWith("!")) {
      return new InsertionSpec(spec.substring(0,spec.length() - 1),false);
    }
    return new InsertionSpec(spec,true);
  }
}
