/** 
 * JAAS configuration parser that constructs a JAAS configuration object with a single login context from the the Kafka configuration option  {@link SaslConfigs#SASL_JAAS_CONFIG}. <p/> JAAS configuration file format is described <a href="http://docs.oracle.com/javase/8/docs/technotes/guides/security/jgss/tutorials/LoginConfigFile.html">here</a>. The format of the property value is: <pre> {@code <loginModuleClass> <controlFlag> (<optionName>=<optionValue>)*;}</pre>
 */
class JaasConfig extends Configuration {
  private final String loginContextName;
  private final List<AppConfigurationEntry> configEntries;
  public JaasConfig(  LoginType loginType,  String jaasConfigParams){
    StreamTokenizer tokenizer=new StreamTokenizer(new StringReader(jaasConfigParams));
    tokenizer.slashSlashComments(true);
    tokenizer.slashStarComments(true);
    tokenizer.wordChars('-','-');
    tokenizer.wordChars('_','_');
    tokenizer.wordChars('$','$');
    try {
      configEntries=new ArrayList<>();
      while (tokenizer.nextToken() != StreamTokenizer.TT_EOF) {
        configEntries.add(parseAppConfigurationEntry(tokenizer));
      }
      if (configEntries.isEmpty())       throw new IllegalArgumentException("Login module not specified in JAAS config");
      this.loginContextName=loginType.contextName();
    }
 catch (    IOException e) {
      throw new KafkaException("Unexpected exception while parsing JAAS config");
    }
  }
  @Override public AppConfigurationEntry[] getAppConfigurationEntry(  String name){
    if (this.loginContextName.equals(name))     return configEntries.toArray(new AppConfigurationEntry[0]);
 else     return null;
  }
  private LoginModuleControlFlag loginModuleControlFlag(  String flag){
    LoginModuleControlFlag controlFlag;
switch (flag.toUpperCase(Locale.ROOT)) {
case "REQUIRED":
      controlFlag=LoginModuleControlFlag.REQUIRED;
    break;
case "REQUISITE":
  controlFlag=LoginModuleControlFlag.REQUISITE;
break;
case "SUFFICIENT":
controlFlag=LoginModuleControlFlag.SUFFICIENT;
break;
case "OPTIONAL":
controlFlag=LoginModuleControlFlag.OPTIONAL;
break;
default :
throw new IllegalArgumentException("Invalid login module control flag '" + flag + "' in JAAS config");
}
return controlFlag;
}
private AppConfigurationEntry parseAppConfigurationEntry(StreamTokenizer tokenizer) throws IOException {
String loginModule=tokenizer.sval;
if (tokenizer.nextToken() == StreamTokenizer.TT_EOF) throw new IllegalArgumentException("Login module control flag not specified in JAAS config");
LoginModuleControlFlag controlFlag=loginModuleControlFlag(tokenizer.sval);
Map<String,String> options=new HashMap<>();
while (tokenizer.nextToken() != StreamTokenizer.TT_EOF && tokenizer.ttype != ';') {
String key=tokenizer.sval;
if (tokenizer.nextToken() != '=' || tokenizer.nextToken() == StreamTokenizer.TT_EOF || tokenizer.sval == null) throw new IllegalArgumentException("Value not specified for key '" + key + "' in JAAS config");
String value=tokenizer.sval;
options.put(key,value);
}
if (tokenizer.ttype != ';') throw new IllegalArgumentException("JAAS config entry not terminated by semi-colon");
return new AppConfigurationEntry(loginModule,controlFlag,options);
}
}
