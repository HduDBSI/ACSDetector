/** 
 * Listen to state change events
 */
public interface StateListener {
  /** 
 * Called when state changes
 * @param thread       thread changing state
 * @param newState     current state
 * @param oldState     previous state
 */
  void onChange(  final Thread thread,  final ThreadStateTransitionValidator newState,  final ThreadStateTransitionValidator oldState);
}
