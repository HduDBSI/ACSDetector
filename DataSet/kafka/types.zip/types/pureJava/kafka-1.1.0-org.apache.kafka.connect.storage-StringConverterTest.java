public class StringConverterTest {
  private static final String TOPIC="topic";
  private static final String SAMPLE_STRING="a string";
  private StringConverter converter=new StringConverter();
  @Test public void testStringToBytes() throws UnsupportedEncodingException {
    assertArrayEquals(SAMPLE_STRING.getBytes("UTF8"),converter.fromConnectData(TOPIC,Schema.STRING_SCHEMA,SAMPLE_STRING));
  }
  @Test public void testNonStringToBytes() throws UnsupportedEncodingException {
    assertArrayEquals("true".getBytes("UTF8"),converter.fromConnectData(TOPIC,Schema.BOOLEAN_SCHEMA,true));
  }
  @Test public void testNullToBytes(){
    assertEquals(null,converter.fromConnectData(TOPIC,Schema.OPTIONAL_STRING_SCHEMA,null));
  }
  @Test public void testToBytesIgnoresSchema() throws UnsupportedEncodingException {
    assertArrayEquals("true".getBytes("UTF8"),converter.fromConnectData(TOPIC,null,true));
  }
  @Test public void testToBytesNonUtf8Encoding() throws UnsupportedEncodingException {
    converter.configure(Collections.singletonMap("converter.encoding","UTF-16"),true);
    assertArrayEquals(SAMPLE_STRING.getBytes("UTF-16"),converter.fromConnectData(TOPIC,Schema.STRING_SCHEMA,SAMPLE_STRING));
  }
  @Test public void testBytesToString(){
    SchemaAndValue data=converter.toConnectData(TOPIC,SAMPLE_STRING.getBytes());
    assertEquals(Schema.OPTIONAL_STRING_SCHEMA,data.schema());
    assertEquals(SAMPLE_STRING,data.value());
  }
  @Test public void testBytesNullToString(){
    SchemaAndValue data=converter.toConnectData(TOPIC,null);
    assertEquals(Schema.OPTIONAL_STRING_SCHEMA,data.schema());
    assertEquals(null,data.value());
  }
  @Test public void testBytesToStringNonUtf8Encoding() throws UnsupportedEncodingException {
    converter.configure(Collections.singletonMap("converter.encoding","UTF-16"),true);
    SchemaAndValue data=converter.toConnectData(TOPIC,SAMPLE_STRING.getBytes("UTF-16"));
    assertEquals(Schema.OPTIONAL_STRING_SCHEMA,data.schema());
    assertEquals(SAMPLE_STRING,data.value());
  }
  @Test public void testStringHeaderValueToBytes() throws UnsupportedEncodingException {
    assertArrayEquals(SAMPLE_STRING.getBytes("UTF8"),converter.fromConnectHeader(TOPIC,"hdr",Schema.STRING_SCHEMA,SAMPLE_STRING));
  }
  @Test public void testNonStringHeaderValueToBytes() throws UnsupportedEncodingException {
    assertArrayEquals("true".getBytes("UTF8"),converter.fromConnectHeader(TOPIC,"hdr",Schema.BOOLEAN_SCHEMA,true));
  }
  @Test public void testNullHeaderValueToBytes(){
    assertEquals(null,converter.fromConnectHeader(TOPIC,"hdr",Schema.OPTIONAL_STRING_SCHEMA,null));
  }
}
