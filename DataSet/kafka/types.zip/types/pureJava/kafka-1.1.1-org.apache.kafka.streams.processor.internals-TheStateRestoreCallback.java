private static class TheStateRestoreCallback implements StateRestoreCallback {
  private final List<KeyValue<byte[],byte[]>> restored=new ArrayList<>();
  @Override public void restore(  final byte[] key,  final byte[] value){
    restored.add(KeyValue.pair(key,value));
  }
}
