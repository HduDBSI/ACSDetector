class ExtendedTimeoutException extends TimeoutException {
}
