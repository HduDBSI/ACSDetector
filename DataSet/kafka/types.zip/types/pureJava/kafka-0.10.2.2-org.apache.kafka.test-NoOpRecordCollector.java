public class NoOpRecordCollector implements RecordCollector {
  @Override public <K,V>void send(  final String topic,  K key,  V value,  Integer partition,  Long timestamp,  Serializer<K> keySerializer,  Serializer<V> valueSerializer){
  }
  @Override public <K,V>void send(  final String topic,  K key,  V value,  Integer partition,  Long timestamp,  Serializer<K> keySerializer,  Serializer<V> valueSerializer,  StreamPartitioner<? super K,? super V> partitioner){
  }
  @Override public void flush(){
  }
  @Override public void close(){
  }
  @Override public Map<TopicPartition,Long> offsets(){
    return Collections.emptyMap();
  }
}
