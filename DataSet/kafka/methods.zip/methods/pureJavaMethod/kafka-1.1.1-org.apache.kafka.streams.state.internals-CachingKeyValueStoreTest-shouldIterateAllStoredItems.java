@Test public void shouldIterateAllStoredItems() throws IOException {
  int items=addItemsToCache();
  final KeyValueIterator<Bytes,byte[]> all=store.all();
  final List<Bytes> results=new ArrayList<>();
  while (all.hasNext()) {
    results.add(all.next().key);
  }
  assertEquals(items,results.size());
}
