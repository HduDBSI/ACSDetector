@Test public void shouldNotFlushOffsetsWhenFlushIntervalHasNotLapsed(){
  stateConsumer.initialize();
  consumer.addRecord(new ConsumerRecord<>("topic-one",1,20L,new byte[0],new byte[0]));
  time.sleep(FLUSH_INTERVAL / 2);
  stateConsumer.pollAndUpdate();
  assertFalse(stateMaintainer.flushed);
}
