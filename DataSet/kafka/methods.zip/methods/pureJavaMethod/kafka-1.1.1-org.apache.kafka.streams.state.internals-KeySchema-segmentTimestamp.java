/** 
 * Extract the timestamp of the segment from the key. The key is a composite of the record-key, any timestamps, plus any additional information.
 * @see SessionKeySchema#lowerRange
 * @see WindowKeySchema#lowerRange
 * @param key
 * @return
 */
long segmentTimestamp(final Bytes key);
