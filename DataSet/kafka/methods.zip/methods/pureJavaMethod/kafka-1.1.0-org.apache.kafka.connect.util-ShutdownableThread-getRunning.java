/** 
 * Returns true if the thread hasn't exited yet and none of the shutdown methods have been invoked
 */
public boolean getRunning(){
  return isRunning.get();
}
