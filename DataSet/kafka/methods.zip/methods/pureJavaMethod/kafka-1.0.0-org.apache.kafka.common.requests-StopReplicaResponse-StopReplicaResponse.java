public StopReplicaResponse(Struct struct){
  responses=new HashMap<>();
  for (  Object responseDataObj : struct.getArray(PARTITIONS_KEY_NAME)) {
    Struct responseData=(Struct)responseDataObj;
    String topic=responseData.get(TOPIC_NAME);
    int partition=responseData.get(PARTITION_ID);
    Errors error=Errors.forCode(responseData.get(ERROR_CODE));
    responses.put(new TopicPartition(topic,partition),error);
  }
  error=Errors.forCode(struct.get(ERROR_CODE));
}
