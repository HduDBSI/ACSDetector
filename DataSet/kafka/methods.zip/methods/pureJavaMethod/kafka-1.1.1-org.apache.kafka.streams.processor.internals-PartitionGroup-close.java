public void close(){
  partitionQueues.clear();
}
