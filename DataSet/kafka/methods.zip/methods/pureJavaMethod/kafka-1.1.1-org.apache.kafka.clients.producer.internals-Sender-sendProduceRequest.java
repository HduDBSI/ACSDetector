/** 
 * Create a produce request from the given record batches
 */
private void sendProduceRequest(long now,int destination,short acks,int timeout,List<ProducerBatch> batches){
  if (batches.isEmpty())   return;
  Map<TopicPartition,MemoryRecords> produceRecordsByPartition=new HashMap<>(batches.size());
  final Map<TopicPartition,ProducerBatch> recordsByPartition=new HashMap<>(batches.size());
  byte minUsedMagic=apiVersions.maxUsableProduceMagic();
  for (  ProducerBatch batch : batches) {
    if (batch.magic() < minUsedMagic)     minUsedMagic=batch.magic();
  }
  for (  ProducerBatch batch : batches) {
    TopicPartition tp=batch.topicPartition;
    MemoryRecords records=batch.records();
    if (!records.hasMatchingMagic(minUsedMagic))     records=batch.records().downConvert(minUsedMagic,0,time).records();
    produceRecordsByPartition.put(tp,records);
    recordsByPartition.put(tp,batch);
  }
  String transactionalId=null;
  if (transactionManager != null && transactionManager.isTransactional()) {
    transactionalId=transactionManager.transactionalId();
  }
  ProduceRequest.Builder requestBuilder=ProduceRequest.Builder.forMagic(minUsedMagic,acks,timeout,produceRecordsByPartition,transactionalId);
  RequestCompletionHandler callback=new RequestCompletionHandler(){
    public void onComplete(    ClientResponse response){
      handleProduceResponse(response,recordsByPartition,time.milliseconds());
    }
  }
;
  String nodeId=Integer.toString(destination);
  ClientRequest clientRequest=client.newClientRequest(nodeId,requestBuilder,now,acks != 0,callback);
  client.send(clientRequest,now);
  log.trace("Sent produce request to {}: {}",nodeId,requestBuilder);
}
