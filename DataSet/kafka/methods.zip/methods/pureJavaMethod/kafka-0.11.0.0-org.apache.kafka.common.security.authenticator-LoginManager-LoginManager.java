private LoginManager(JaasContext jaasContext,boolean hasKerberos,Map<String,?> configs,Password jaasConfigValue) throws IOException, LoginException {
  this.cacheKey=jaasConfigValue != null ? jaasConfigValue : jaasContext.name();
  login=hasKerberos ? new KerberosLogin() : new DefaultLogin();
  login.configure(configs,jaasContext);
  login.login();
}
