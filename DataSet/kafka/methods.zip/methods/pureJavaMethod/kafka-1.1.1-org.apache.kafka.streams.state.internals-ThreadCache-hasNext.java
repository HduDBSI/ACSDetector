@Override public boolean hasNext(){
  if (nextEntry != null) {
    return true;
  }
  while (keys.hasNext() && nextEntry == null) {
    internalNext();
  }
  return nextEntry != null;
}
