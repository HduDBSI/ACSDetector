public RebalanceNeededException(String s){
  super(s);
}
