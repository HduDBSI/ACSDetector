/** 
 * Set the  {@link StreamThread.StateListener} to be notified when state changes. Note this API is internal toKafka Streams and is not intended to be used by an external application.
 */
public void setStateListener(final StreamThread.StateListener listener){
  stateListener=listener;
}
