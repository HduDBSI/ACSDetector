private void readToLogEnd(){
  log.trace("Reading to end of offset log");
  Set<TopicPartition> assignment=consumer.assignment();
  Map<TopicPartition,Long> endOffsets=consumer.endOffsets(assignment);
  log.trace("Reading to end of log offsets {}",endOffsets);
  while (!endOffsets.isEmpty()) {
    Iterator<Map.Entry<TopicPartition,Long>> it=endOffsets.entrySet().iterator();
    while (it.hasNext()) {
      Map.Entry<TopicPartition,Long> entry=it.next();
      if (consumer.position(entry.getKey()) >= entry.getValue())       it.remove();
 else {
        poll(Integer.MAX_VALUE);
        break;
      }
    }
  }
}
