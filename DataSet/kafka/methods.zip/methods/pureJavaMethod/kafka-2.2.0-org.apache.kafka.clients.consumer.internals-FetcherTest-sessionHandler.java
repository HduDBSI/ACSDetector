@Override protected FetchSessionHandler sessionHandler(int id){
  final FetchSessionHandler handler=super.sessionHandler(id);
  if (handler == null)   return null;
 else {
    return new FetchSessionHandler(new LogContext(),id){
      @Override public Builder newBuilder(){
        verifySessionPartitions();
        return handler.newBuilder();
      }
      @Override public boolean handleResponse(      FetchResponse response){
        verifySessionPartitions();
        return handler.handleResponse(response);
      }
      @Override public void handleError(      Throwable t){
        verifySessionPartitions();
        handler.handleError(t);
      }
      private void verifySessionPartitions(){
        try {
          Field field=FetchSessionHandler.class.getDeclaredField("sessionPartitions");
          field.setAccessible(true);
          LinkedHashMap<?,?> sessionPartitions=(LinkedHashMap<?,?>)field.get(handler);
          for (          Map.Entry<?,?> entry : sessionPartitions.entrySet()) {
            Thread.yield();
          }
        }
 catch (        Exception e) {
          throw new RuntimeException(e);
        }
      }
    }
;
  }
}
