@Override public <KR>KGroupedStream<KR,V> groupBy(final KeyValueMapper<? super K,? super V,KR> selector,final Grouped<KR,V> grouped){
  Objects.requireNonNull(selector,"selector can't be null");
  Objects.requireNonNull(grouped,"grouped can't be null");
  final GroupedInternal<KR,V> groupedInternal=new GroupedInternal<>(grouped);
  final ProcessorGraphNode<K,V> selectKeyMapNode=internalSelectKey(selector);
  selectKeyMapNode.keyChangingOperation(true);
  builder.addGraphNode(this.streamsGraphNode,selectKeyMapNode);
  return new KGroupedStreamImpl<>(selectKeyMapNode.nodeName(),sourceNodes,groupedInternal,true,selectKeyMapNode,builder);
}
