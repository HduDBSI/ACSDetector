private void verifySessionPartitions(){
  try {
    Field field=FetchSessionHandler.class.getDeclaredField("sessionPartitions");
    field.setAccessible(true);
    LinkedHashMap<?,?> sessionPartitions=(LinkedHashMap<?,?>)field.get(handler);
    for (    Map.Entry<?,?> entry : sessionPartitions.entrySet()) {
      Thread.yield();
    }
  }
 catch (  Exception e) {
    throw new RuntimeException(e);
  }
}
