@Override public boolean equals(final Object obj){
  if (this == obj)   return true;
  if (!(obj instanceof KeyValue)) {
    return false;
  }
  final KeyValue other=(KeyValue)obj;
  return (key == null ? other.key == null : key.equals(other.key)) && (value == null ? other.value == null : value.equals(other.value));
}
