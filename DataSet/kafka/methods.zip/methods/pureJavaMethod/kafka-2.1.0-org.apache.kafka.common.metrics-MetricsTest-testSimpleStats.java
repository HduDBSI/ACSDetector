@Test public void testSimpleStats() throws Exception {
  verifyStats(m -> (double)m.metricValue());
}
