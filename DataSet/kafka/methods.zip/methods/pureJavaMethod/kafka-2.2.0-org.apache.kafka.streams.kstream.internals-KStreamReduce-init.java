@SuppressWarnings("unchecked") @Override public void init(final ProcessorContext context){
  store=(KeyValueStore<K,V>)context.getStateStore(storeName);
}
