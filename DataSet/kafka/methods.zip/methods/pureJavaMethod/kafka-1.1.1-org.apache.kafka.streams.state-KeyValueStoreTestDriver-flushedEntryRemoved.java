/** 
 * Determine whether the store  {@link KeyValueStore#flush() flushed} the removal of the given key.
 * @param key the key
 * @return {@code true} if the entry with the given key was removed when flushed, or {@code false} if the entry was notremoved when last flushed
 */
public boolean flushedEntryRemoved(final K key){
  return flushedRemovals.contains(key);
}
