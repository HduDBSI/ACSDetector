/** 
 * Recursively delete the given file/directory and any subfiles (if any exist)
 * @param file The root file at which to begin deleting
 */
public static void delete(final File file) throws IOException {
  if (file == null)   return;
  Files.walkFileTree(file.toPath(),new SimpleFileVisitor<Path>(){
    @Override public FileVisitResult visitFileFailed(    Path path,    IOException exc) throws IOException {
      if (exc instanceof NoSuchFileException && path.toFile().equals(file))       return FileVisitResult.TERMINATE;
      throw exc;
    }
    @Override public FileVisitResult visitFile(    Path path,    BasicFileAttributes attrs) throws IOException {
      Files.delete(path);
      return FileVisitResult.CONTINUE;
    }
    @Override public FileVisitResult postVisitDirectory(    Path path,    IOException exc) throws IOException {
      Files.delete(path);
      return FileVisitResult.CONTINUE;
    }
  }
);
}
