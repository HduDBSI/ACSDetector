@After public void cleanUp() throws IOException {
  Utils.delete(stateDir);
}
