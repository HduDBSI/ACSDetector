public static void waitForChannelReady(Selector selector,String node) throws IOException {
  int secondsLeft=30;
  while (!selector.isChannelReady(node) && secondsLeft-- > 0) {
    selector.poll(1000L);
  }
  assertTrue(selector.isChannelReady(node));
}
