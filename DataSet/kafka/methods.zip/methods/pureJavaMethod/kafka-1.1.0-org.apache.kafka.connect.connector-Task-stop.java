/** 
 * Stop this task.
 */
void stop();
