@Test public void testMissingFieldWithDefaultValue(){
  Schema schema=SchemaBuilder.struct().field("field",DEFAULT_FIELD_SCHEMA).build();
  Struct struct=new Struct(schema);
  assertEquals((byte)0,struct.get("field"));
}
