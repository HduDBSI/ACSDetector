/** 
 * Parse a value according to its expected type.
 * @param name  The config name
 * @param value The config value
 * @param type  The expected type
 * @return The parsed object
 */
public static Object parseType(String name,Object value,Type type){
  try {
    if (value == null)     return null;
    String trimmed=null;
    if (value instanceof String)     trimmed=((String)value).trim();
switch (type) {
case BOOLEAN:
      if (value instanceof String) {
        if (trimmed.equalsIgnoreCase("true"))         return true;
 else         if (trimmed.equalsIgnoreCase("false"))         return false;
 else         throw new ConfigException(name,value,"Expected value to be either true or false");
      }
 else       if (value instanceof Boolean)       return value;
 else       throw new ConfigException(name,value,"Expected value to be either true or false");
case PASSWORD:
    if (value instanceof Password)     return value;
 else     if (value instanceof String)     return new Password(trimmed);
 else     throw new ConfigException(name,value,"Expected value to be a string, but it was a " + value.getClass().getName());
case STRING:
  if (value instanceof String)   return trimmed;
 else   throw new ConfigException(name,value,"Expected value to be a string, but it was a " + value.getClass().getName());
case INT:
if (value instanceof Integer) {
  return value;
}
 else if (value instanceof String) {
  return Integer.parseInt(trimmed);
}
 else {
  throw new ConfigException(name,value,"Expected value to be a 32-bit integer, but it was a " + value.getClass().getName());
}
case SHORT:
if (value instanceof Short) {
return value;
}
 else if (value instanceof String) {
return Short.parseShort(trimmed);
}
 else {
throw new ConfigException(name,value,"Expected value to be a 16-bit integer (short), but it was a " + value.getClass().getName());
}
case LONG:
if (value instanceof Integer) return ((Integer)value).longValue();
if (value instanceof Long) return value;
 else if (value instanceof String) return Long.parseLong(trimmed);
 else throw new ConfigException(name,value,"Expected value to be a 64-bit integer (long), but it was a " + value.getClass().getName());
case DOUBLE:
if (value instanceof Number) return ((Number)value).doubleValue();
 else if (value instanceof String) return Double.parseDouble(trimmed);
 else throw new ConfigException(name,value,"Expected value to be a double, but it was a " + value.getClass().getName());
case LIST:
if (value instanceof List) return value;
 else if (value instanceof String) if (trimmed.isEmpty()) return Collections.emptyList();
 else return Arrays.asList(trimmed.split("\\s*,\\s*",-1));
 else throw new ConfigException(name,value,"Expected a comma separated list.");
case CLASS:
if (value instanceof Class) return value;
 else if (value instanceof String) return Class.forName(trimmed,true,Utils.getContextOrKafkaClassLoader());
 else throw new ConfigException(name,value,"Expected a Class instance or class name.");
default :
throw new IllegalStateException("Unknown type.");
}
}
 catch (NumberFormatException e) {
throw new ConfigException(name,value,"Not a number of type " + type);
}
catch (ClassNotFoundException e) {
throw new ConfigException(name,value,"Class " + value + " could not be found.");
}
}
