/** 
 * The hashcode is cached except for the case where it is computed as 0, in which case we compute the hashcode on every call.
 * @return the hashcode
 */
@Override public int hashCode(){
  if (hashCode == 0) {
    hashCode=Arrays.hashCode(bytes);
  }
  return hashCode;
}
