@Override public int hashCode(){
  int result=topicPartition.hashCode();
  result=31 * result + value.hashCode();
  return result;
}
