@Test public void shouldSupportRangeAcrossMultipleKVStores(){
  final KeyValueStore<String,String> cache=newStoreInstance();
  stubProviderTwo.addStore(storeName,cache);
  stubOneUnderlying.put("a","a");
  stubOneUnderlying.put("b","b");
  stubOneUnderlying.put("z","z");
  cache.put("c","c");
  cache.put("d","d");
  cache.put("x","x");
  final List<KeyValue<String,String>> results=toList(theStore.range("a","e"));
  assertTrue(results.contains(new KeyValue<>("a","a")));
  assertTrue(results.contains(new KeyValue<>("b","b")));
  assertTrue(results.contains(new KeyValue<>("c","c")));
  assertTrue(results.contains(new KeyValue<>("d","d")));
  assertEquals(4,results.size());
}
