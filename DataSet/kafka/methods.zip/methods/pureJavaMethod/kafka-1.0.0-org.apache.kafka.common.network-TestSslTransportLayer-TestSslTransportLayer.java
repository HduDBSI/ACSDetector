public TestSslTransportLayer(String channelId,SelectionKey key,SSLEngine sslEngine) throws IOException {
  super(channelId,key,sslEngine,false);
  this.netReadBufSize=new ResizeableBufferSize(netReadBufSizeOverride);
  this.netWriteBufSize=new ResizeableBufferSize(netWriteBufSizeOverride);
  this.appBufSize=new ResizeableBufferSize(appBufSizeOverride);
  numReadsRemaining=new AtomicLong(readFailureIndex);
  numFlushesRemaining=new AtomicLong(flushFailureIndex);
  numDelayedFlushesRemaining=new AtomicInteger(flushDelayCount);
}
