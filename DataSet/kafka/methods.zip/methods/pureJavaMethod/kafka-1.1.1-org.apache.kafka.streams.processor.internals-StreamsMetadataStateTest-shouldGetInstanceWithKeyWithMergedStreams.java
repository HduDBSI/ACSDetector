@Test public void shouldGetInstanceWithKeyWithMergedStreams(){
  final TopicPartition topic2P2=new TopicPartition("topic-two",2);
  hostToPartitions.put(hostTwo,Utils.mkSet(topic2P0,topic1P1,topic2P2));
  discovery.onChange(hostToPartitions,cluster.withPartitions(Collections.singletonMap(topic2P2,new PartitionInfo("topic-two",2,null,null,null))));
  final StreamsMetadata expected=new StreamsMetadata(hostTwo,Utils.mkSet("global-table","table-two","table-one","merged-table"),Utils.mkSet(topic2P0,topic1P1,topic2P2));
  final StreamsMetadata actual=discovery.getMetadataWithKey("merged-table","123",new StreamPartitioner<String,Object>(){
    @Override public Integer partition(    final String key,    final Object value,    final int numPartitions){
      return 2;
    }
  }
);
  assertEquals(expected,actual);
}
