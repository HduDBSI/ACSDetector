public static java.util.Date toLogical(Schema schema,long value){
  if (!(LOGICAL_NAME.equals(schema.name())))   throw new DataException("Requested conversion of Timestamp object but the schema does not match.");
  return new java.util.Date(value);
}
