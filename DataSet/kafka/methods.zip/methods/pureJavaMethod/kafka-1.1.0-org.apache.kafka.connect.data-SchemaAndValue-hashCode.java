@Override public int hashCode(){
  return Objects.hash(schema,value);
}
