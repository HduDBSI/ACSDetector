public void run(){
  try {
    for (int i=0; i < iterations; i++) {
      int size;
      if (TestUtils.RANDOM.nextBoolean())       size=pool.poolableSize();
 else       size=TestUtils.RANDOM.nextInt((int)pool.totalMemory());
      ByteBuffer buffer=pool.allocate(size,maxBlockTimeMs);
      pool.deallocate(buffer);
    }
    success.set(true);
  }
 catch (  Exception e) {
    e.printStackTrace();
  }
}
