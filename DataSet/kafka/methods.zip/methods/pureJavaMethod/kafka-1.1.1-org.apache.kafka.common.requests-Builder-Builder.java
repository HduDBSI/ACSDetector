public Builder(Set<String> groups){
  super(ApiKeys.DELETE_GROUPS);
  this.groups=groups;
}
