@Test(expected=ProcessorStateException.class) public void shouldThrowProcessorStateExceptionOnInitializeOffsetsWhenAuthorizationException(){
  final Consumer consumer=mockConsumer(new AuthorizationException("blah"));
  final AbstractTask task=createTask(consumer,Collections.<StateStore,String>emptyMap());
  task.updateOffsetLimits();
}
