@Test public void shouldThrowIllegalArgumentExceptionIfCallbackIsNull(){
  stateManager.initialize();
  try {
    stateManager.register(store1,null);
    fail("should have thrown due to null callback");
  }
 catch (  IllegalArgumentException e) {
  }
}
