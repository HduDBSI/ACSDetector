@Override public void onPartitionsAssigned(Collection<TopicPartition> partitions){
  lastCommittedOffsets=new HashMap<>();
  currentOffsets=new HashMap<>();
  for (  TopicPartition tp : partitions) {
    long pos=consumer.position(tp);
    lastCommittedOffsets.put(tp,new OffsetAndMetadata(pos));
    currentOffsets.put(tp,new OffsetAndMetadata(pos));
    log.debug("{} assigned topic partition {} with offset {}",id,tp,pos);
  }
  pausedForRedelivery=false;
  context.pausedPartitions().retainAll(partitions);
  if (shouldPause())   pauseAll();
 else   if (!context.pausedPartitions().isEmpty())   consumer.pause(context.pausedPartitions());
  if (rebalanceException == null) {
    try {
      openPartitions(partitions);
    }
 catch (    RuntimeException e) {
      rebalanceException=e;
    }
  }
}
