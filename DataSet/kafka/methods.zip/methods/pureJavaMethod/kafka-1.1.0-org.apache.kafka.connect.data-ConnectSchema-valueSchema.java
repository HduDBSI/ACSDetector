@Override public Schema valueSchema(){
  if (type != Type.MAP && type != Type.ARRAY)   throw new DataException("Cannot look up value schema on non-array and non-map type");
  return valueSchema;
}
