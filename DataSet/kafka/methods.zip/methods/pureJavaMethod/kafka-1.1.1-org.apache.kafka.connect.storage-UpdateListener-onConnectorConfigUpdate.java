/** 
 * Invoked when a connector configuration has been updated.
 * @param connector name of the connector
 */
void onConnectorConfigUpdate(String connector);
