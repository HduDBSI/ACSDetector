private void deliverMessages(){
  try {
    log.trace("{} Delivering batch of {} messages to task",this,messageBatch.size());
    task.put(new ArrayList<>(messageBatch));
    currentOffsets.putAll(origOffsets);
    messageBatch.clear();
    if (pausedForRedelivery) {
      if (!shouldPause())       resumeAll();
      pausedForRedelivery=false;
    }
  }
 catch (  RetriableException e) {
    log.error("RetriableException from SinkTask {}:",id,e);
    pausedForRedelivery=true;
    pauseAll();
  }
catch (  Throwable t) {
    log.error("Task {} threw an uncaught and unrecoverable exception",id,t);
    log.error("Task is being killed and will not recover until manually restarted");
    throw new ConnectException("Exiting WorkerSinkTask due to unrecoverable exception.");
  }
}
