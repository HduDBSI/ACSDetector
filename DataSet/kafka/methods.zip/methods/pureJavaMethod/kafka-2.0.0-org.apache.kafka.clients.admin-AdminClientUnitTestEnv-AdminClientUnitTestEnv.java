public AdminClientUnitTestEnv(MockClient mockClient,Time time,Cluster cluster,Map<String,Object> config){
  this.time=time;
  this.cluster=cluster;
  AdminClientConfig adminClientConfig=new AdminClientConfig(config);
  this.mockClient=mockClient;
  this.adminClient=KafkaAdminClient.createInternal(adminClientConfig,mockClient,time);
}
