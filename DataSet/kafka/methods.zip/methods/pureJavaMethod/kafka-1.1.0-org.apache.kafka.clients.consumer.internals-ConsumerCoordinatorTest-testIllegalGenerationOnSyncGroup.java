@Test public void testIllegalGenerationOnSyncGroup(){
  final String consumerId="consumer";
  subscriptions.subscribe(singleton(topic1),rebalanceListener);
  client.prepareResponse(groupCoordinatorResponse(node,Errors.NONE));
  coordinator.ensureCoordinatorReady();
  client.prepareResponse(joinGroupFollowerResponse(1,consumerId,"leader",Errors.NONE));
  client.prepareResponse(syncGroupResponse(Collections.<TopicPartition>emptyList(),Errors.ILLEGAL_GENERATION));
  client.prepareResponse(new MockClient.RequestMatcher(){
    @Override public boolean matches(    AbstractRequest body){
      JoinGroupRequest joinRequest=(JoinGroupRequest)body;
      return joinRequest.memberId().equals(JoinGroupRequest.UNKNOWN_MEMBER_ID);
    }
  }
,joinGroupFollowerResponse(2,consumerId,"leader",Errors.NONE));
  client.prepareResponse(syncGroupResponse(singletonList(t1p),Errors.NONE));
  coordinator.joinGroupIfNeeded();
  assertFalse(coordinator.needRejoin());
  assertEquals(singleton(t1p),subscriptions.assignedPartitions());
}
