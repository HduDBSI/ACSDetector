@Test public void testToLogical(){
  assertEquals(EPOCH.getTime(),Time.toLogical(Time.SCHEMA,0));
  assertEquals(EPOCH_PLUS_TEN_THOUSAND_MILLIS.getTime(),Time.toLogical(Time.SCHEMA,10000));
}
