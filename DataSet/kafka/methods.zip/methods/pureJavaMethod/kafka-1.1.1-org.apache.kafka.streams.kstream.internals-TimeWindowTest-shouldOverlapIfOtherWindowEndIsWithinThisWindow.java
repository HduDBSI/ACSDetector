@Test public void shouldOverlapIfOtherWindowEndIsWithinThisWindow(){
  assertTrue(window.overlap(new TimeWindow(0,start + 1)));
  assertTrue(window.overlap(new TimeWindow(0,75)));
  assertTrue(window.overlap(new TimeWindow(0,end - 1)));
  assertTrue(window.overlap(new TimeWindow(start - 1,start + 1)));
  assertTrue(window.overlap(new TimeWindow(start - 1,75)));
  assertTrue(window.overlap(new TimeWindow(start - 1,end - 1)));
}
