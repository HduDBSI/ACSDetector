private void drain(){
  if (!isFetched) {
    maybeCloseRecordStream();
    cachedRecordException=null;
    this.isFetched=true;
    this.completedFetch.metricAggregator.record(partition,bytesRead,recordsRead);
    if (bytesRead > 0)     subscriptions.movePartitionToEnd(partition);
  }
}
