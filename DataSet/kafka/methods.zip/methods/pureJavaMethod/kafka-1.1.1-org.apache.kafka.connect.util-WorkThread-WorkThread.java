public WorkThread(){
  super("KafkaBasedLog Work Thread - " + topic);
}
