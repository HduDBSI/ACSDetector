@SuppressWarnings("unchecked") @Override public void init(final ProcessorContext context){
  super.init(context);
  if (queryableName != null) {
    store=(KeyValueStore<K,V>)context.getStateStore(queryableName);
    tupleForwarder=new TupleForwarder<>(store,context,new ForwardingCacheFlushListener<K,V>(context),sendOldValues);
  }
}
