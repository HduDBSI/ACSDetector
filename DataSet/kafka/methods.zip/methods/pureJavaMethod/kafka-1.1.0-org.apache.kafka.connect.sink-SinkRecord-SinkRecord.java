public SinkRecord(String topic,int partition,Schema keySchema,Object key,Schema valueSchema,Object value,long kafkaOffset,Long timestamp,TimestampType timestampType,Iterable<Header> headers){
  super(topic,partition,keySchema,key,valueSchema,value,timestamp,headers);
  this.kafkaOffset=kafkaOffset;
  this.timestampType=timestampType;
}
