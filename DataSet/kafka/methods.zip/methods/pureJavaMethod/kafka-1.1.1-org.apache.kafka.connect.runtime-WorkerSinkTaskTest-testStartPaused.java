@Test public void testStartPaused() throws Exception {
  createTask(TargetState.PAUSED);
  expectInitializeTask();
  expectPollInitialAssignment();
  Set<TopicPartition> partitions=new HashSet<>(asList(TOPIC_PARTITION,TOPIC_PARTITION2));
  EasyMock.expect(consumer.assignment()).andReturn(partitions);
  consumer.pause(partitions);
  PowerMock.expectLastCall();
  PowerMock.replayAll();
  workerTask.initialize(TASK_CONFIG);
  workerTask.initializeAndStart();
  workerTask.iteration();
  time.sleep(10000L);
  assertSinkMetricValue("partition-count",2);
  assertTaskMetricValue("status","paused");
  assertTaskMetricValue("running-ratio",0.0);
  assertTaskMetricValue("pause-ratio",1.0);
  assertTaskMetricValue("offset-commit-max-time-ms",Double.NEGATIVE_INFINITY);
  PowerMock.verifyAll();
}
