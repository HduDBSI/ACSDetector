@POST @Path("/{connector}/tasks") public void putTaskConfigs(final @PathParam("connector") String connector,final @QueryParam("forward") Boolean forward,final List<Map<String,String>> taskConfigs) throws Throwable {
  FutureCallback<Void> cb=new FutureCallback<>();
  herder.putTaskConfigs(connector,taskConfigs,cb);
  completeOrForwardRequest(cb,"/connectors/" + connector + "/tasks","POST",taskConfigs,forward);
}
