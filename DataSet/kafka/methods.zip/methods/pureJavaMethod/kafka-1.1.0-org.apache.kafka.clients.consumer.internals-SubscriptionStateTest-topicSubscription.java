@Test public void topicSubscription(){
  state.subscribe(singleton(topic),rebalanceListener);
  assertEquals(1,state.subscription().size());
  assertTrue(state.assignedPartitions().isEmpty());
  assertTrue(state.partitionsAutoAssigned());
  state.assignFromSubscribed(singleton(tp0));
  state.seek(tp0,1);
  assertEquals(1L,state.position(tp0).longValue());
  state.assignFromSubscribed(singleton(tp1));
  assertTrue(state.isAssigned(tp1));
  assertFalse(state.isAssigned(tp0));
  assertFalse(state.isFetchable(tp1));
  assertEquals(singleton(tp1),state.assignedPartitions());
}
