@Before public void setup(){
  os=new ByteArrayOutputStream();
  printStream=new PrintStream(os);
  task=new FileStreamSinkTask(printStream);
}
