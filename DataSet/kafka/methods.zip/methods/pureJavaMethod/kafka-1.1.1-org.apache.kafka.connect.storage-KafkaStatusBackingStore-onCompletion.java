@Override public void onCompletion(RecordMetadata metadata,Exception exception){
  if (exception != null) {
    if (exception instanceof RetriableException) {
synchronized (KafkaStatusBackingStore.this) {
        if (entry.isDeleted() || status.generation() != generation || (safeWrite && !entry.canWriteSafely(status,sequence)))         return;
      }
      kafkaLog.send(key,value,this);
    }
 else {
      log.error("Failed to write status update",exception);
    }
  }
}
