@SuppressWarnings("unchecked") @Override public void init(ProcessorContext context){
  store=(KeyValueStore<K,V>)context.getStateStore(storeName);
}
