@Override protected Record makeNext(){
  if (innerEntries.isEmpty())   return allDone();
  AbstractLegacyRecordBatch entry=innerEntries.remove();
  if (wrapperMagic == RecordBatch.MAGIC_VALUE_V1) {
    long absoluteOffset=absoluteBaseOffset + entry.offset();
    entry=new BasicLegacyRecordBatch(absoluteOffset,entry.outerRecord());
  }
  if (entry.isCompressed())   throw new InvalidRecordException("Inner messages must not be compressed");
  return entry;
}
