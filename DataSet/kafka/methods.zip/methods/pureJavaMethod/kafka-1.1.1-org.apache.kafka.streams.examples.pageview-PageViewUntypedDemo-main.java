public static void main(String[] args) throws Exception {
  Properties props=new Properties();
  props.put(StreamsConfig.APPLICATION_ID_CONFIG,"streams-pageview-untyped");
  props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG,"localhost:9092");
  props.put(StreamsConfig.DEFAULT_TIMESTAMP_EXTRACTOR_CLASS_CONFIG,JsonTimestampExtractor.class);
  props.put(StreamsConfig.CACHE_MAX_BYTES_BUFFERING_CONFIG,0);
  props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,"earliest");
  StreamsBuilder builder=new StreamsBuilder();
  final Serializer<JsonNode> jsonSerializer=new JsonSerializer();
  final Deserializer<JsonNode> jsonDeserializer=new JsonDeserializer();
  final Serde<JsonNode> jsonSerde=Serdes.serdeFrom(jsonSerializer,jsonDeserializer);
  final Consumed<String,JsonNode> consumed=Consumed.with(Serdes.String(),jsonSerde);
  KStream<String,JsonNode> views=builder.stream("streams-pageview-input",consumed);
  KTable<String,JsonNode> users=builder.table("streams-userprofile-input",consumed);
  KTable<String,String> userRegions=users.mapValues(new ValueMapper<JsonNode,String>(){
    @Override public String apply(    JsonNode record){
      return record.get("region").textValue();
    }
  }
);
  KStream<JsonNode,JsonNode> regionCount=views.leftJoin(userRegions,new ValueJoiner<JsonNode,String,JsonNode>(){
    @Override public JsonNode apply(    JsonNode view,    String region){
      ObjectNode jNode=JsonNodeFactory.instance.objectNode();
      return jNode.put("user",view.get("user").textValue()).put("page",view.get("page").textValue()).put("region",region == null ? "UNKNOWN" : region);
    }
  }
).map(new KeyValueMapper<String,JsonNode,KeyValue<String,JsonNode>>(){
    @Override public KeyValue<String,JsonNode> apply(    String user,    JsonNode viewRegion){
      return new KeyValue<>(viewRegion.get("region").textValue(),viewRegion);
    }
  }
).groupByKey(Serialized.with(Serdes.String(),jsonSerde)).windowedBy(TimeWindows.of(7 * 24 * 60* 60* 1000L).advanceBy(1000)).count().toStream().map(new KeyValueMapper<Windowed<String>,Long,KeyValue<JsonNode,JsonNode>>(){
    @Override public KeyValue<JsonNode,JsonNode> apply(    Windowed<String> key,    Long value){
      ObjectNode keyNode=JsonNodeFactory.instance.objectNode();
      keyNode.put("window-start",key.window().start()).put("region",key.key());
      ObjectNode valueNode=JsonNodeFactory.instance.objectNode();
      valueNode.put("count",value);
      return new KeyValue<>((JsonNode)keyNode,(JsonNode)valueNode);
    }
  }
);
  regionCount.to("streams-pageviewstats-untyped-output",Produced.with(jsonSerde,jsonSerde));
  KafkaStreams streams=new KafkaStreams(builder.build(),props);
  streams.start();
  Thread.sleep(5000L);
  streams.close();
}
