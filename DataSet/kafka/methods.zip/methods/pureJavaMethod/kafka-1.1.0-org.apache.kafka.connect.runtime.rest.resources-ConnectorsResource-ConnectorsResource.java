public ConnectorsResource(Herder herder,WorkerConfig config){
  this.herder=herder;
  this.config=config;
}
