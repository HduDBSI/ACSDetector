@Override public synchronized boolean hasNext(){
  if (!open) {
    throw new InvalidStateStoreException(String.format("Store %s has closed",storeName));
  }
  if (next != null) {
    return true;
  }
  if (!underlying.hasNext()) {
    return false;
  }
  next=underlying.next();
  return true;
}
