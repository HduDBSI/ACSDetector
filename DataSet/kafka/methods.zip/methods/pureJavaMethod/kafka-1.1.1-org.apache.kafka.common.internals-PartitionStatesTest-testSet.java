@Test public void testSet(){
  PartitionStates<String> states=new PartitionStates<>();
  LinkedHashMap<TopicPartition,String> map=createMap();
  states.set(map);
  LinkedHashMap<TopicPartition,String> expected=new LinkedHashMap<>();
  expected.put(new TopicPartition("foo",2),"foo 2");
  expected.put(new TopicPartition("foo",0),"foo 0");
  expected.put(new TopicPartition("blah",2),"blah 2");
  expected.put(new TopicPartition("blah",1),"blah 1");
  expected.put(new TopicPartition("baz",2),"baz 2");
  expected.put(new TopicPartition("baz",3),"baz 3");
  checkState(states,expected);
  states.set(new LinkedHashMap<TopicPartition,String>());
  checkState(states,new LinkedHashMap<TopicPartition,String>());
}
