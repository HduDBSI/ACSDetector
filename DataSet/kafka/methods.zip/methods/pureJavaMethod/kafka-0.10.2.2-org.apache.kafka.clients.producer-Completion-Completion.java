public Completion(long offset,RecordMetadata metadata,ProduceRequestResult result,Callback callback){
  this.metadata=metadata;
  this.offset=offset;
  this.result=result;
  this.callback=callback;
}
