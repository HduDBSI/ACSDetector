public MemoryLRUCacheBytesIterator all(final String namespace){
  final NamedCache cache=getCache(namespace);
  if (cache == null) {
    return new MemoryLRUCacheBytesIterator(Collections.<Bytes>emptyIterator(),new NamedCache(namespace,this.metrics));
  }
  return new MemoryLRUCacheBytesIterator(cache.allKeys(),cache);
}
