private void validateEnvelopeNullSchema(JsonNode env){
  assertNotNull(env);
  assertTrue(env.isObject());
  assertEquals(2,env.size());
  assertTrue(env.has(JsonSchema.ENVELOPE_SCHEMA_FIELD_NAME));
  assertTrue(env.get(JsonSchema.ENVELOPE_SCHEMA_FIELD_NAME).isNull());
  assertTrue(env.has(JsonSchema.ENVELOPE_PAYLOAD_FIELD_NAME));
}
