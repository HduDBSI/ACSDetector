@Test public void shouldCloseProducerOnCloseWhenEosEnabled(){
  task=createStatelessTask(true);
  task.close(true,false);
  task=null;
  assertTrue(producer.closed());
}
