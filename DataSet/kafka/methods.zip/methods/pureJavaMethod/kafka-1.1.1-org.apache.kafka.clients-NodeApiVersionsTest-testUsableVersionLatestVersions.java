@Test public void testUsableVersionLatestVersions(){
  List<ApiVersion> versionList=new LinkedList<>();
  for (  ApiVersion apiVersion : ApiVersionsResponse.defaultApiVersionsResponse().apiVersions()) {
    versionList.add(apiVersion);
  }
  versionList.add(new ApiVersion((short)100,(short)0,(short)1));
  NodeApiVersions versions=new NodeApiVersions(versionList);
  for (  ApiKeys apiKey : ApiKeys.values()) {
    assertEquals(apiKey.latestVersion(),versions.latestUsableVersion(apiKey));
  }
}
