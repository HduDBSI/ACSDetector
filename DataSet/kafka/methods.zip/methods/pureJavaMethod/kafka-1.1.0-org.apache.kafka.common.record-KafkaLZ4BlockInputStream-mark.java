@Override public void mark(int readlimit){
  throw new RuntimeException("mark not supported");
}
