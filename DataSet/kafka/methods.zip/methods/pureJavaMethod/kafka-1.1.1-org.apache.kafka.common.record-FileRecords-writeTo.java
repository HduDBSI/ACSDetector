@Override public long writeTo(GatheringByteChannel destChannel,long offset,int length) throws IOException {
  long newSize=Math.min(channel.size(),end) - start;
  int oldSize=sizeInBytes();
  if (newSize < oldSize)   throw new KafkaException(String.format("Size of FileRecords %s has been truncated during write: old size %d, new size %d",file.getAbsolutePath(),oldSize,newSize));
  long position=start + offset;
  int count=Math.min(length,oldSize);
  final long bytesTransferred;
  if (destChannel instanceof TransportLayer) {
    TransportLayer tl=(TransportLayer)destChannel;
    bytesTransferred=tl.transferFrom(channel,position,count);
  }
 else {
    bytesTransferred=channel.transferTo(position,count,destChannel);
  }
  return bytesTransferred;
}
