@Test public void testFetchNonContinuousRecords(){
  MemoryRecordsBuilder builder=MemoryRecords.builder(ByteBuffer.allocate(1024),CompressionType.NONE,TimestampType.CREATE_TIME,0L);
  builder.appendWithOffset(15L,0L,"key".getBytes(),"value-1".getBytes());
  builder.appendWithOffset(20L,0L,"key".getBytes(),"value-2".getBytes());
  builder.appendWithOffset(30L,0L,"key".getBytes(),"value-3".getBytes());
  MemoryRecords records=builder.build();
  List<ConsumerRecord<byte[],byte[]>> consumerRecords;
  subscriptions.assignFromUser(singleton(tp0));
  subscriptions.seek(tp0,0);
  assertEquals(1,fetcher.sendFetches());
  client.prepareResponse(fullFetchResponse(tp0,records,Errors.NONE,100L,0));
  consumerClient.poll(0);
  consumerRecords=fetcher.fetchedRecords().get(tp0);
  assertEquals(3,consumerRecords.size());
  assertEquals(31L,subscriptions.position(tp0).longValue());
  assertEquals(15L,consumerRecords.get(0).offset());
  assertEquals(20L,consumerRecords.get(1).offset());
  assertEquals(30L,consumerRecords.get(2).offset());
}
