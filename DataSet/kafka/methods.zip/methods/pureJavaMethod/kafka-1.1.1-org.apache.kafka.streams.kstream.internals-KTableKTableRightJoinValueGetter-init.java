@Override public void init(ProcessorContext context){
  valueGetter1.init(context);
  valueGetter2.init(context);
}
