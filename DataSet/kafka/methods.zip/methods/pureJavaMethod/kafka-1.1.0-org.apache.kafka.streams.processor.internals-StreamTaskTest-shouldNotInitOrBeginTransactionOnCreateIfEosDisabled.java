@Test public void shouldNotInitOrBeginTransactionOnCreateIfEosDisabled(){
  task=createStatelessTask(false);
  assertFalse(producer.transactionInitialized());
  assertFalse(producer.transactionInFlight());
}
