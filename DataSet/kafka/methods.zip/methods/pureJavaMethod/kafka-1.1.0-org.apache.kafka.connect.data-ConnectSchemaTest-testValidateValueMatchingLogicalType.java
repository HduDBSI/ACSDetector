@Test public void testValidateValueMatchingLogicalType(){
  ConnectSchema.validateValue(Decimal.schema(2),new BigDecimal(new BigInteger("156"),2));
  ConnectSchema.validateValue(Date.SCHEMA,new java.util.Date(0));
  ConnectSchema.validateValue(Time.SCHEMA,new java.util.Date(0));
  ConnectSchema.validateValue(Timestamp.SCHEMA,new java.util.Date(0));
}
