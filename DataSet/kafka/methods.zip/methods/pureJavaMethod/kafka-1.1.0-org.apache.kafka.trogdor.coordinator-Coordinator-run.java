@Override public void run(){
  log.warn("Running coordinator shutdown hook.");
  try {
    coordinator.beginShutdown(false);
    coordinator.waitForShutdown();
  }
 catch (  Exception e) {
    log.error("Got exception while running coordinator shutdown hook.",e);
  }
}
