/** 
 * @throws UnsupportedOperationException if this method adds a child to a sink node
 */
@Override public void addChild(final ProcessorNode<?,?> child){
  throw new UnsupportedOperationException("sink node does not allow addChild");
}
