@Override public R get(K key){
  V1 value1=valueGetter1.get(key);
  if (value1 != null) {
    V2 value2=valueGetter2.get(key);
    return joiner.apply(value1,value2);
  }
 else {
    return null;
  }
}
