@Test public void testUniteMany(){
  QuickUnion<Long> qu=new QuickUnion<>();
  long[] ids={1L,2L,3L,4L,5L};
  for (  long id : ids) {
    qu.add(id);
  }
  assertEquals(5,roots(qu,ids).size());
  qu.unite(1L,2L,3L,4L);
  assertEquals(2,roots(qu,ids).size());
  assertEquals(qu.root(1L),qu.root(2L));
  assertEquals(qu.root(2L),qu.root(3L));
  assertEquals(qu.root(3L),qu.root(4L));
  assertNotEquals(qu.root(1L),qu.root(5L));
}
