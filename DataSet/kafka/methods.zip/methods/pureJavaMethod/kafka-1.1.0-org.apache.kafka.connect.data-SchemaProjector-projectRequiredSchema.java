private static Object projectRequiredSchema(Schema source,Object record,Schema target) throws SchemaProjectorException {
switch (target.type()) {
case INT8:
case INT16:
case INT32:
case INT64:
case FLOAT32:
case FLOAT64:
case BOOLEAN:
case BYTES:
case STRING:
    return projectPrimitive(source,record,target);
case STRUCT:
  return projectStruct(source,(Struct)record,target);
case ARRAY:
return projectArray(source,record,target);
case MAP:
return projectMap(source,record,target);
}
return null;
}
