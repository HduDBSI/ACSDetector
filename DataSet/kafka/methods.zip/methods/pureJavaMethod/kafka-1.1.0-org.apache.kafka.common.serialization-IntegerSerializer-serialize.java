public byte[] serialize(String topic,Integer data){
  if (data == null)   return null;
  return new byte[]{(byte)(data >>> 24),(byte)(data >>> 16),(byte)(data >>> 8),data.byteValue()};
}
