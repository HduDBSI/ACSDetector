public TopicDetails(Map<Integer,List<Integer>> replicasAssignments){
  this(replicasAssignments,Collections.<String,String>emptyMap());
}
