@Override public String toString(){
  StringBuilder bld=new StringBuilder();
  bld.append("(type=OffsetCommitRequest").append(", groupId=").append(groupId).append(", memberId=").append(memberId).append(", generationId=").append(generationId).append(", retentionTime=").append(retentionTime).append(", offsetData=").append(offsetData).append(")");
  return bld.toString();
}
