/** 
 * Registers and possibly restores the specified storage engine.
 * @param store the storage engine
 * @param stateRestoreCallback the restoration callback logic for log-backed state stores upon restart
 * @throws IllegalStateException If store gets registered after initialized is already finished
 * @throws StreamsException if the store's change log does not contain the partition
 */
void register(final StateStore store,final StateRestoreCallback stateRestoreCallback);
