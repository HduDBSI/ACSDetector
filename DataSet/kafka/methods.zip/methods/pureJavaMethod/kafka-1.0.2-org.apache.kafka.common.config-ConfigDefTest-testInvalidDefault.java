@Test(expected=ConfigException.class) public void testInvalidDefault(){
  new ConfigDef().define("a",Type.INT,"hello",Importance.HIGH,"docs");
}
