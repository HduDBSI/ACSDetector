private boolean containsAbortMarker(RecordBatch batch){
  if (!batch.isControlBatch())   return false;
  Iterator<Record> batchIterator=batch.iterator();
  if (!batchIterator.hasNext())   return false;
  Record firstRecord=batchIterator.next();
  return ControlRecordType.ABORT == ControlRecordType.parse(firstRecord.key());
}
