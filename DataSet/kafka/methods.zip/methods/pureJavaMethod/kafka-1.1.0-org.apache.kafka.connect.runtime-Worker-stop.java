/** 
 * Stop worker.
 */
public void stop(){
  log.info("Worker stopping");
  long started=time.milliseconds();
  long limit=started + config.getLong(WorkerConfig.TASK_SHUTDOWN_GRACEFUL_TIMEOUT_MS_CONFIG);
  if (!connectors.isEmpty()) {
    log.warn("Shutting down connectors {} uncleanly; herder should have shut down connectors before the Worker is stopped",connectors.keySet());
    stopConnectors();
  }
  if (!tasks.isEmpty()) {
    log.warn("Shutting down tasks {} uncleanly; herder should have shut down tasks before the Worker is stopped",tasks.keySet());
    stopAndAwaitTasks();
  }
  long timeoutMs=limit - time.milliseconds();
  sourceTaskOffsetCommitter.close(timeoutMs);
  offsetBackingStore.stop();
  metrics.stop();
  log.info("Worker stopped");
  workerMetricsGroup.close();
}
