@Test public void shouldCreateSingleSessionWhenWithinGap(){
  context.setTime(0);
  processor.process("john","first");
  context.setTime(500);
  processor.process("john","second");
  final KeyValueIterator<Windowed<String>,Long> values=sessionStore.findSessions("john",0,2000);
  assertTrue(values.hasNext());
  assertEquals(Long.valueOf(2),values.next().value);
}
