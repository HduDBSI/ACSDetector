@Override public void onAcknowledgement(RecordMetadata metadata,Exception exception){
  onAckCount++;
  if (exception != null) {
    onErrorAckCount++;
    if (metadata != null && metadata.topic().length() >= 0) {
      onErrorAckWithTopicSetCount++;
      if (metadata.partition() >= 0)       onErrorAckWithTopicPartitionSetCount++;
    }
  }
  if (throwExceptionOnAck)   throw new KafkaException("Injected exception in AppendProducerInterceptor.onAcknowledgement");
}
