public RecordBatchTooLargeException(Throwable cause){
  super(cause);
}
