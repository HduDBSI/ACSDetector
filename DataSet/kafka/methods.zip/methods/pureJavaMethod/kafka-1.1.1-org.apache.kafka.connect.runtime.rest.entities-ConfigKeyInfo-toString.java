@Override public String toString(){
  StringBuffer sb=new StringBuffer();
  sb.append("[").append(name).append(",").append(type).append(",").append(required).append(",").append(defaultValue).append(",").append(importance).append(",").append(documentation).append(",").append(group).append(",").append(orderInGroup).append(",").append(width).append(",").append(displayName).append(",").append(dependents).append("]");
  return sb.toString();
}
