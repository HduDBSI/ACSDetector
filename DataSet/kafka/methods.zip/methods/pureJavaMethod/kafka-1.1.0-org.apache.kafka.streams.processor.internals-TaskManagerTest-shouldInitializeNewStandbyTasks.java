@Test public void shouldInitializeNewStandbyTasks(){
  active.updateRestored(EasyMock.<Collection<TopicPartition>>anyObject());
  EasyMock.expectLastCall();
  replay();
  taskManager.updateNewAndRestoringTasks();
  verify(standby);
}
