public KafkaMetric(Object lock,MetricName metricName,MetricValueProvider<?> valueProvider,MetricConfig config,Time time){
  this.metricName=metricName;
  this.lock=lock;
  if (!(valueProvider instanceof Measurable) && !(valueProvider instanceof Gauge))   throw new IllegalArgumentException("Unsupported metric value provider of class " + valueProvider.getClass());
  this.metricValueProvider=valueProvider;
  this.config=config;
  this.time=time;
}
