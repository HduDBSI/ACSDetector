/** 
 * Test if the record with the given key and value satisfies the predicate.
 * @param key   the key of the record
 * @param value the value of the record
 * @return {@code true} if the {@link KeyValue} pair satisfies the predicate&mdash;{@code false} otherwise
 */
boolean test(final K key,final V value);
