public static Cluster singletonCluster(final String topic,final int partitions){
  return clusterWith(1,topic,partitions);
}
