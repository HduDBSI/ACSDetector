public DoubleSerde(){
  super(new DoubleSerializer(),new DoubleDeserializer());
}
