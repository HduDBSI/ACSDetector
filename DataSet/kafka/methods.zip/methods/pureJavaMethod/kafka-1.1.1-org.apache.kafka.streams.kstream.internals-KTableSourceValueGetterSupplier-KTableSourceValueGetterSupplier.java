public KTableSourceValueGetterSupplier(String storeName){
  this.storeName=storeName;
}
