@Override public int hashCode(){
  if (hash != 0)   return hash;
  final int prime=31;
  int result=1;
  result=prime * result + partition;
  result=prime * result + ((topic == null) ? 0 : topic.hashCode());
  this.hash=result;
  return result;
}
