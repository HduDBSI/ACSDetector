@Test public void testRateWindowing() throws Exception {
  MetricConfig cfg=new MetricConfig().samples(3);
  Sensor s=metrics.sensor("test.sensor",cfg);
  MetricName rateMetricName=metrics.metricName("test.rate","grp1");
  MetricName totalMetricName=metrics.metricName("test.total","grp1");
  s.add(new Meter(TimeUnit.SECONDS,rateMetricName,totalMetricName));
  KafkaMetric totalMetric=metrics.metrics().get(metrics.metricName("test.total","grp1"));
  int sum=0;
  int count=cfg.samples() - 1;
  for (int i=0; i < count; i++) {
    s.record(100);
    sum+=100;
    time.sleep(cfg.timeWindowMs());
    assertEquals(sum,totalMetric.value(),EPS);
  }
  time.sleep(cfg.timeWindowMs() / 2);
  double elapsedSecs=(cfg.timeWindowMs() * (cfg.samples() - 1) + cfg.timeWindowMs() / 2) / 1000.0;
  KafkaMetric rateMetric=metrics.metrics().get(metrics.metricName("test.rate","grp1"));
  assertEquals("Rate(0...2) = 2.666",sum / elapsedSecs,rateMetric.value(),EPS);
  assertEquals("Elapsed Time = 75 seconds",elapsedSecs,((Rate)rateMetric.measurable()).windowSize(cfg,time.milliseconds()) / 1000,EPS);
  assertEquals(sum,totalMetric.value(),EPS);
}
