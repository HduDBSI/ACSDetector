synchronized Iterator<Bytes> keyRange(final Bytes from,final Bytes to){
  return keySetIterator(cache.navigableKeySet().subSet(from,true,to,true));
}
