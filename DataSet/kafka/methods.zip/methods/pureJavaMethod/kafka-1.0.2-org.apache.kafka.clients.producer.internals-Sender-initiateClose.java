/** 
 * Start closing the sender (won't actually complete until all data is sent out)
 */
public void initiateClose(){
  this.accumulator.close();
  this.running=false;
  this.wakeup();
}
