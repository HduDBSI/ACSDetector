@Override public void apply(final List<ThreadCache.DirtyEntry> entries){
  for (  ThreadCache.DirtyEntry entry : entries) {
    final byte[] binaryWindowKey=cacheFunction.key(entry.key()).get();
    final long timestamp=WindowKeySchema.extractStoreTimestamp(binaryWindowKey);
    final Windowed<K> windowedKey=WindowKeySchema.fromStoreKey(binaryWindowKey,windowSize,serdes);
    final Bytes key=Bytes.wrap(WindowKeySchema.extractStoreKeyBytes(binaryWindowKey));
    maybeForward(entry,key,windowedKey,(InternalProcessorContext)context);
    underlying.put(key,entry.newValue(),timestamp);
  }
}
