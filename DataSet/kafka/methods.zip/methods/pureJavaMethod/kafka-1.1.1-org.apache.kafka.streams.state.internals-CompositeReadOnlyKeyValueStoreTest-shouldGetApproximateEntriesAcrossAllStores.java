@Test public void shouldGetApproximateEntriesAcrossAllStores(){
  final KeyValueStore<String,String> cache=newStoreInstance();
  stubProviderTwo.addStore(storeName,cache);
  stubOneUnderlying.put("a","a");
  stubOneUnderlying.put("b","b");
  stubOneUnderlying.put("z","z");
  cache.put("c","c");
  cache.put("d","d");
  cache.put("x","x");
  assertEquals(6,theStore.approximateNumEntries());
}
