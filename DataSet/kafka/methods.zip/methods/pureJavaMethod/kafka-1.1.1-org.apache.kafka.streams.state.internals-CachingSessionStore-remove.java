@Override public void remove(final Windowed<Bytes> sessionKey){
  validateStoreOpen();
  put(sessionKey,null);
}
