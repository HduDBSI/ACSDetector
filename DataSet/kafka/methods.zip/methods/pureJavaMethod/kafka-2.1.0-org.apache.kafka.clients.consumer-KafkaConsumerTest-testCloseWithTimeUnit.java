@Test @SuppressWarnings("deprecation") public void testCloseWithTimeUnit(){
  KafkaConsumer consumer=mock(KafkaConsumer.class);
  doCallRealMethod().when(consumer).close(anyLong(),any());
  consumer.close(1,TimeUnit.SECONDS);
  verify(consumer).close(Duration.ofSeconds(1));
}
