/** 
 * Aborts the ongoing transaction. Any unflushed produce messages will be aborted when this call is made. This call will throw an exception immediately if any prior  {@link #send(ProducerRecord)} calls failed with a{@link ProducerFencedException} or an instance of {@link org.apache.kafka.common.errors.AuthorizationException}.
 * @throws IllegalStateException if no transactional.id has been configured or no transaction has been started
 * @throws ProducerFencedException fatal error indicating another producer with the same transactional.id is active
 * @throws org.apache.kafka.common.errors.UnsupportedVersionException fatal error indicating the brokerdoes not support transactions (i.e. if its version is lower than 0.11.0.0)
 * @throws org.apache.kafka.common.errors.AuthorizationException fatal error indicating that the configuredtransactional.id is not authorized
 * @throws KafkaException if the producer has encountered a previous fatal error or for any other unexpected error
 */
public void abortTransaction() throws ProducerFencedException {
  throwIfNoTransactionManager();
  TransactionalRequestResult result=transactionManager.beginAbort();
  sender.wakeup();
  result.await();
}
