@Override public ConsumerRecords<K,V> onConsume(ConsumerRecords<K,V> records){
  onConsumeCount++;
  if (throwExceptionOnConsume)   throw new KafkaException("Injected exception in FilterConsumerInterceptor.onConsume.");
  Map<TopicPartition,List<ConsumerRecord<K,V>>> recordMap=new HashMap<>();
  for (  TopicPartition tp : records.partitions()) {
    if (tp.partition() != filterPartition)     recordMap.put(tp,records.records(tp));
  }
  return new ConsumerRecords<K,V>(recordMap);
}
