@Override public int hashCode(){
  return Objects.hash(name,type,required,defaultValue,importance,documentation,group,orderInGroup,width,displayName,dependents);
}
