/** 
 * See  {@link KafkaProducer#metrics()}
 */
Map<MetricName,? extends Metric> metrics();
