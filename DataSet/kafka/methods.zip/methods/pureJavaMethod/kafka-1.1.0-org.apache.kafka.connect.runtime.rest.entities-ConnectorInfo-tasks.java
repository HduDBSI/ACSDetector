@JsonProperty public List<ConnectorTaskId> tasks(){
  return tasks;
}
