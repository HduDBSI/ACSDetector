/** 
 * Create a REST server for this herder using the specified configs.
 */
public RestServer(WorkerConfig config){
  this.config=config;
  List<String> listeners=parseListeners();
  jettyServer=new Server();
  createConnectors(listeners);
}
