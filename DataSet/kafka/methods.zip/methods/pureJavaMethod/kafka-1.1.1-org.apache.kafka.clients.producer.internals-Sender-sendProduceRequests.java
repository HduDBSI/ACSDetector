/** 
 * Transfer the record batches into a list of produce requests on a per-node basis
 */
private void sendProduceRequests(Map<Integer,List<ProducerBatch>> collated,long now){
  for (  Map.Entry<Integer,List<ProducerBatch>> entry : collated.entrySet())   sendProduceRequest(now,entry.getKey(),acks,requestTimeout,entry.getValue());
}
