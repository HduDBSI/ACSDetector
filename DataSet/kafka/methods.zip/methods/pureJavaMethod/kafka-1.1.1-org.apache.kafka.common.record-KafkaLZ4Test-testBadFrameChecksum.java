@Test public void testBadFrameChecksum() throws Exception {
  if (!ignoreFlagDescriptorChecksum) {
    thrown.expect(IOException.class);
    thrown.expectMessage(KafkaLZ4BlockInputStream.DESCRIPTOR_HASH_MISMATCH);
  }
  byte[] compressed=compressedBytes();
  compressed[6]=(byte)0xFF;
  makeInputStream(ByteBuffer.wrap(compressed));
}
