private boolean isInputTopic(final String topic){
  return options.valuesOf(inputTopicsOption).contains(topic);
}
