/** 
 * Get the record collector.
 * @return the record collector
 */
RecordCollector recordCollector();
