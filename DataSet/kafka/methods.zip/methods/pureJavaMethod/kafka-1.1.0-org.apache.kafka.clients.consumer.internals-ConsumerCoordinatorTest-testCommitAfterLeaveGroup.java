@Test public void testCommitAfterLeaveGroup(){
  subscriptions.subscribe(singleton(topic1),rebalanceListener);
  joinAsFollowerAndReceiveAssignment("consumer",coordinator,singletonList(t1p));
  client.prepareResponse(new LeaveGroupResponse(Errors.NONE));
  subscriptions.unsubscribe();
  coordinator.maybeLeaveGroup();
  subscriptions.assignFromUser(singleton(t1p));
  client.prepareResponse(new MockClient.RequestMatcher(){
    @Override public boolean matches(    AbstractRequest body){
      OffsetCommitRequest commitRequest=(OffsetCommitRequest)body;
      return commitRequest.memberId().equals(OffsetCommitRequest.DEFAULT_MEMBER_ID) && commitRequest.generationId() == OffsetCommitRequest.DEFAULT_GENERATION_ID;
    }
  }
,offsetCommitResponse(singletonMap(t1p,Errors.NONE)));
  AtomicBoolean success=new AtomicBoolean(false);
  coordinator.commitOffsetsAsync(singletonMap(t1p,new OffsetAndMetadata(100L)),callback(success));
  coordinator.invokeCompletedOffsetCommitCallbacks();
  assertTrue(success.get());
}
