public CopyOnWriteMap(Map<K,V> map){
  this.map=Collections.unmodifiableMap(map);
}
