private Map<TopicPartition,Long> readOffsetsCheckpoint() throws IOException {
  final OffsetCheckpoint offsetCheckpoint=new OffsetCheckpoint(new File(stateManager.baseDir(),ProcessorStateManager.CHECKPOINT_FILE_NAME));
  return offsetCheckpoint.read();
}
