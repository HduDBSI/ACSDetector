@Test public void shouldCheckpointOffsetsOnCommit() throws IOException {
  task=createStatefulTask(false,true);
  task.initializeStateStores();
  task.initializeTopology();
  task.commit();
  final OffsetCheckpoint checkpoint=new OffsetCheckpoint(new File(stateDirectory.directoryForTask(taskId00),ProcessorStateManager.CHECKPOINT_FILE_NAME));
  assertThat(checkpoint.read(),equalTo(Collections.singletonMap(changelogPartition,offset)));
}
