@Test public void testCacheSchemaToJsonConversion(){
  Cache<Schema,ObjectNode> cache=Whitebox.getInternalState(converter,"fromConnectSchemaCache");
  assertEquals(0,cache.size());
  converter.fromConnectData(TOPIC,SchemaBuilder.bool().build(),true);
  assertEquals(1,cache.size());
  converter.fromConnectData(TOPIC,SchemaBuilder.bool().build(),true);
  assertEquals(1,cache.size());
  converter.fromConnectData(TOPIC,SchemaBuilder.bool().optional().build(),true);
  assertEquals(2,cache.size());
}
