private void initializeConsumer(final long numRecords,final long startOffset,final TopicPartition topicPartition){
  final HashMap<TopicPartition,Long> startOffsets=new HashMap<>();
  startOffsets.put(topicPartition,1L);
  final HashMap<TopicPartition,Long> endOffsets=new HashMap<>();
  endOffsets.put(topicPartition,startOffset + numRecords - 1);
  consumer.updatePartitions(topicPartition.topic(),Collections.singletonList(new PartitionInfo(topicPartition.topic(),topicPartition.partition(),null,null,null)));
  consumer.assign(Collections.singletonList(topicPartition));
  consumer.updateEndOffsets(endOffsets);
  consumer.updateBeginningOffsets(startOffsets);
  for (int i=0; i < numRecords; i++) {
    consumer.addRecord(new ConsumerRecord<>(topicPartition.topic(),topicPartition.partition(),startOffset + i,"key".getBytes(),"value".getBytes()));
  }
}
