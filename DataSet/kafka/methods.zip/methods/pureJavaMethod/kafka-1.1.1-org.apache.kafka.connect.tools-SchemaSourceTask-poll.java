@Override public List<SourceRecord> poll() throws InterruptedException {
  if (count < maxNumMsgs) {
    long sendStartMs=System.currentTimeMillis();
    if (throttler.shouldThrottle(seqno - startingSeqno,sendStartMs)) {
      throttler.throttle();
    }
    Map<String,Long> ccOffset=Collections.singletonMap(SEQNO_FIELD,seqno);
    int partitionVal=(int)(seqno % partitionCount);
    final Struct data;
    final SourceRecord srcRecord;
    if (!multipleSchema || count % 2 == 0) {
      data=new Struct(valueSchema).put("boolean",true).put("int",12).put("long",12L).put("float",12.2f).put("double",12.2).put("partitioning",partitionVal).put("id",id).put("seqno",seqno);
      srcRecord=new SourceRecord(partition,ccOffset,topic,id,Schema.STRING_SCHEMA,"key",valueSchema,data);
    }
 else {
      data=new Struct(valueSchema2).put("boolean",true).put("int",12).put("long",12L).put("float",12.2f).put("double",12.2).put("partitioning",partitionVal).put("string","def").put("id",id).put("seqno",seqno);
      srcRecord=new SourceRecord(partition,ccOffset,topic,id,Schema.STRING_SCHEMA,"key",valueSchema2,data);
    }
    System.out.println("{\"task\": " + id + ", \"seqno\": "+ seqno+ "}");
    List<SourceRecord> result=Collections.singletonList(srcRecord);
    seqno++;
    count++;
    return result;
  }
 else {
    throttler.throttle();
    return new ArrayList<>();
  }
}
