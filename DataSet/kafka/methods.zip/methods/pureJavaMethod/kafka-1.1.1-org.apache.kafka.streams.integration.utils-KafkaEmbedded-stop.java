/** 
 * Stop the broker.
 */
public void stop(){
  log.debug("Shutting down embedded Kafka broker at {} (with ZK ensemble at {}) ...",brokerList(),zookeeperConnect());
  kafka.shutdown();
  kafka.awaitShutdown();
  log.debug("Removing logs.dir at {} ...",logDir);
  final List<String> logDirs=Collections.singletonList(logDir.getAbsolutePath());
  CoreUtils.delete(scala.collection.JavaConversions.asScalaBuffer(logDirs).seq());
  tmpFolder.delete();
  log.debug("Shutdown of embedded Kafka broker at {} completed (with ZK ensemble at {}) ...",brokerList(),zookeeperConnect());
}
