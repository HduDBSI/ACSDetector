@Override public List<Object> validValues(String name,Map<String,Object> parsedConfig){
  return Arrays.<Object>asList(1,2,3);
}
