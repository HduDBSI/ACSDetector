@Test public void testResetSession(){
  heartbeat.sentHeartbeat(time.milliseconds());
  time.sleep(305);
  heartbeat.resetTimeouts(time.milliseconds());
  assertFalse(heartbeat.sessionTimeoutExpired(time.milliseconds()));
}
