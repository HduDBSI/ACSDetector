@Test public void testSchedule() throws Exception {
  Capture<Runnable> taskWrapper=EasyMock.newCapture();
  EasyMock.expect(executor.scheduleWithFixedDelay(EasyMock.capture(taskWrapper),eq(DEFAULT_OFFSET_COMMIT_INTERVAL_MS),eq(DEFAULT_OFFSET_COMMIT_INTERVAL_MS),eq(TimeUnit.MILLISECONDS))).andReturn(commitFuture);
  EasyMock.expect(committers.put(taskId,commitFuture)).andReturn(null);
  PowerMock.replayAll();
  committer.schedule(taskId,task);
  assertTrue(taskWrapper.hasCaptured());
  assertNotNull(taskWrapper.getValue());
  PowerMock.verifyAll();
}
