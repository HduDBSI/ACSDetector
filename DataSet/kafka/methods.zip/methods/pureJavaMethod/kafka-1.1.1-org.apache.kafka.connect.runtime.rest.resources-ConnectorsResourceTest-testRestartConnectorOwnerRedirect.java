@Test public void testRestartConnectorOwnerRedirect() throws Throwable {
  final Capture<Callback<Void>> cb=Capture.newInstance();
  herder.restartConnector(EasyMock.eq(CONNECTOR_NAME),EasyMock.capture(cb));
  String ownerUrl="http://owner:8083";
  expectAndCallbackException(cb,new NotAssignedException("not owner test",ownerUrl));
  EasyMock.expect(RestClient.httpRequest(EasyMock.eq("http://owner:8083/connectors/" + CONNECTOR_NAME + "/restart?forward=false"),EasyMock.eq("POST"),EasyMock.isNull(),EasyMock.<TypeReference>anyObject(),EasyMock.anyObject(WorkerConfig.class))).andReturn(new RestClient.HttpResponse<>(202,new HashMap<String,String>(),null));
  PowerMock.replayAll();
  connectorsResource.restartConnector(CONNECTOR_NAME,true);
  PowerMock.verifyAll();
}
