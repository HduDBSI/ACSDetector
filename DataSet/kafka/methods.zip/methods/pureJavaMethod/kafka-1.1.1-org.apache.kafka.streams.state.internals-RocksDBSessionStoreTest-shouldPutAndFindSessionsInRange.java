@Test public void shouldPutAndFindSessionsInRange(){
  final String key="a";
  final Windowed<String> a1=new Windowed<>(key,new SessionWindow(10,10L));
  final Windowed<String> a2=new Windowed<>(key,new SessionWindow(500L,1000L));
  sessionStore.put(a1,1L);
  sessionStore.put(a2,2L);
  sessionStore.put(new Windowed<>(key,new SessionWindow(1500L,2000L)),1L);
  sessionStore.put(new Windowed<>(key,new SessionWindow(2500L,3000L)),2L);
  final List<KeyValue<Windowed<String>,Long>> expected=Arrays.asList(KeyValue.pair(a1,1L),KeyValue.pair(a2,2L));
  final KeyValueIterator<Windowed<String>,Long> values=sessionStore.findSessions(key,0,1000L);
  assertEquals(expected,toList(values));
}
