@Test public void testRestoreConnectorDeletion() throws Exception {
  expectConfigure();
  List<ConsumerRecord<String,byte[]>> existingRecords=Arrays.asList(new ConsumerRecord<>(TOPIC,0,0,0L,TimestampType.CREATE_TIME,0L,0,0,CONNECTOR_CONFIG_KEYS.get(0),CONFIGS_SERIALIZED.get(0)),new ConsumerRecord<>(TOPIC,0,1,0L,TimestampType.CREATE_TIME,0L,0,0,TASK_CONFIG_KEYS.get(0),CONFIGS_SERIALIZED.get(1)),new ConsumerRecord<>(TOPIC,0,2,0L,TimestampType.CREATE_TIME,0L,0,0,TASK_CONFIG_KEYS.get(1),CONFIGS_SERIALIZED.get(2)),new ConsumerRecord<>(TOPIC,0,3,0L,TimestampType.CREATE_TIME,0L,0,0,CONNECTOR_CONFIG_KEYS.get(0),CONFIGS_SERIALIZED.get(3)),new ConsumerRecord<>(TOPIC,0,4,0L,TimestampType.CREATE_TIME,0L,0,0,TARGET_STATE_KEYS.get(0),CONFIGS_SERIALIZED.get(4)),new ConsumerRecord<>(TOPIC,0,5,0L,TimestampType.CREATE_TIME,0L,0,0,COMMIT_TASKS_CONFIG_KEYS.get(0),CONFIGS_SERIALIZED.get(5)));
  LinkedHashMap<byte[],Struct> deserialized=new LinkedHashMap<>();
  deserialized.put(CONFIGS_SERIALIZED.get(0),CONNECTOR_CONFIG_STRUCTS.get(0));
  deserialized.put(CONFIGS_SERIALIZED.get(1),TASK_CONFIG_STRUCTS.get(0));
  deserialized.put(CONFIGS_SERIALIZED.get(2),TASK_CONFIG_STRUCTS.get(0));
  deserialized.put(CONFIGS_SERIALIZED.get(3),null);
  deserialized.put(CONFIGS_SERIALIZED.get(4),null);
  deserialized.put(CONFIGS_SERIALIZED.get(5),TASKS_COMMIT_STRUCT_TWO_TASK_CONNECTOR);
  logOffset=6;
  expectStart(existingRecords,deserialized);
  expectStop();
  PowerMock.replayAll();
  configStorage.setupAndCreateKafkaBasedLog(TOPIC,DEFAULT_DISTRIBUTED_CONFIG);
  configStorage.start();
  ClusterConfigState configState=configStorage.snapshot();
  assertEquals(6,configState.offset());
  assertTrue(configState.connectors().isEmpty());
  configStorage.stop();
  PowerMock.verifyAll();
}
