@Test public void shouldDelete(){
  final ThreadCache cache=new ThreadCache(logContext,10000L,new MockStreamsMetrics(new Metrics()));
  final Bytes key=Bytes.wrap(new byte[]{0});
  cache.put(namespace,key,dirtyEntry(key.get()));
  assertEquals(key.get(),cache.delete(namespace,key).value);
  assertNull(cache.get(namespace,key));
}
