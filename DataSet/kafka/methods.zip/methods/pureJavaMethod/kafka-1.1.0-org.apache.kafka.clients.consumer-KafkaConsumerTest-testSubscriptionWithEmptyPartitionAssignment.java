@Test(expected=IllegalStateException.class) public void testSubscriptionWithEmptyPartitionAssignment(){
  Properties props=new Properties();
  props.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,"localhost:9999");
  props.setProperty(ConsumerConfig.PARTITION_ASSIGNMENT_STRATEGY_CONFIG,"");
  try (KafkaConsumer<byte[],byte[]> consumer=newConsumer(props)){
    consumer.subscribe(singletonList(topic));
  }
 }
