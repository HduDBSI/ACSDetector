@Test(expected=IllegalArgumentException.class) public void windowSizeMustNotBeNegative(){
  TimeWindows.of(-1);
}
