@Override public byte[] serialize(String topic,String data){
  try {
    if (data == null)     return null;
 else     return data.getBytes(encoding);
  }
 catch (  UnsupportedEncodingException e) {
    throw new SerializationException("Error when serializing string to byte[] due to unsupported encoding " + encoding);
  }
}
