/** 
 * Add a listener which will be notified when the future completes
 * @param listener non-null listener to add
 */
public void addListener(RequestFutureListener<T> listener){
  this.listeners.add(listener);
  if (failed())   fireFailure();
 else   if (succeeded())   fireSuccess();
}
