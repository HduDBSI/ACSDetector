public void onCompletion(RecordMetadata metadata,Exception exception){
  metadata=metadata != null ? metadata : new RecordMetadata(tp,-1,-1,RecordBatch.NO_TIMESTAMP,Long.valueOf(-1L),-1,-1);
  this.interceptors.onAcknowledgement(metadata,exception);
  if (this.userCallback != null)   this.userCallback.onCompletion(metadata,exception);
}
