void apply(final List<DirtyEntry> dirty);
