@Test public void testSendingOldValues() throws Exception {
  final KStreamBuilder builder=new KStreamBuilder();
  final int[] expectedKeys=new int[]{0,1,2,3};
  final KTable<Integer,String> table1;
  final KTable<Integer,String> table2;
  final KTable<Integer,String> joined;
  final MockProcessorSupplier<Integer,String> proc;
  table1=builder.table(intSerde,stringSerde,topic1,storeName1);
  table2=builder.table(intSerde,stringSerde,topic2,storeName2);
  joined=table1.join(table2,MockValueJoiner.TOSTRING_JOINER);
  proc=new MockProcessorSupplier<>();
  builder.addProcessor("proc",proc,((KTableImpl<?,?,?>)joined).name);
  doTestSendingOldValues(builder,expectedKeys,table1,table2,proc,joined,true);
}
