@Test public void testGetSet() throws Exception {
  expectConfigure();
  expectStart(Collections.EMPTY_LIST);
  expectStop();
  final Capture<Callback<Void>> firstGetReadToEndCallback=EasyMock.newCapture();
  storeLog.readToEnd(EasyMock.capture(firstGetReadToEndCallback));
  PowerMock.expectLastCall().andAnswer(new IAnswer<Object>(){
    @Override public Object answer() throws Throwable {
      firstGetReadToEndCallback.getValue().onCompletion(null,null);
      return null;
    }
  }
);
  Capture<org.apache.kafka.clients.producer.Callback> callback0=EasyMock.newCapture();
  storeLog.send(EasyMock.aryEq(TP0_KEY.array()),EasyMock.aryEq(TP0_VALUE.array()),EasyMock.capture(callback0));
  PowerMock.expectLastCall();
  Capture<org.apache.kafka.clients.producer.Callback> callback1=EasyMock.newCapture();
  storeLog.send(EasyMock.aryEq(TP1_KEY.array()),EasyMock.aryEq(TP1_VALUE.array()),EasyMock.capture(callback1));
  PowerMock.expectLastCall();
  final Capture<Callback<Void>> secondGetReadToEndCallback=EasyMock.newCapture();
  storeLog.readToEnd(EasyMock.capture(secondGetReadToEndCallback));
  PowerMock.expectLastCall().andAnswer(new IAnswer<Object>(){
    @Override public Object answer() throws Throwable {
      capturedConsumedCallback.getValue().onCompletion(null,new ConsumerRecord<>(TOPIC,0,0,0L,TimestampType.CREATE_TIME,0L,0,0,TP0_KEY.array(),TP0_VALUE.array()));
      capturedConsumedCallback.getValue().onCompletion(null,new ConsumerRecord<>(TOPIC,1,0,0L,TimestampType.CREATE_TIME,0L,0,0,TP1_KEY.array(),TP1_VALUE.array()));
      secondGetReadToEndCallback.getValue().onCompletion(null,null);
      return null;
    }
  }
);
  final Capture<Callback<Void>> thirdGetReadToEndCallback=EasyMock.newCapture();
  storeLog.readToEnd(EasyMock.capture(thirdGetReadToEndCallback));
  PowerMock.expectLastCall().andAnswer(new IAnswer<Object>(){
    @Override public Object answer() throws Throwable {
      capturedConsumedCallback.getValue().onCompletion(null,new ConsumerRecord<>(TOPIC,0,1,0L,TimestampType.CREATE_TIME,0L,0,0,TP0_KEY.array(),TP0_VALUE_NEW.array()));
      capturedConsumedCallback.getValue().onCompletion(null,new ConsumerRecord<>(TOPIC,1,1,0L,TimestampType.CREATE_TIME,0L,0,0,TP1_KEY.array(),TP1_VALUE_NEW.array()));
      thirdGetReadToEndCallback.getValue().onCompletion(null,null);
      return null;
    }
  }
);
  PowerMock.replayAll();
  store.configure(DEFAULT_DISTRIBUTED_CONFIG);
  store.start();
  final AtomicBoolean getInvokedAndPassed=new AtomicBoolean(false);
  store.get(Arrays.asList(TP0_KEY,TP1_KEY),new Callback<Map<ByteBuffer,ByteBuffer>>(){
    @Override public void onCompletion(    Throwable error,    Map<ByteBuffer,ByteBuffer> result){
      assertEquals(null,result.get(TP0_KEY));
      assertEquals(null,result.get(TP1_KEY));
      getInvokedAndPassed.set(true);
    }
  }
).get(10000,TimeUnit.MILLISECONDS);
  assertTrue(getInvokedAndPassed.get());
  Map<ByteBuffer,ByteBuffer> toSet=new HashMap<>();
  toSet.put(TP0_KEY,TP0_VALUE);
  toSet.put(TP1_KEY,TP1_VALUE);
  final AtomicBoolean invoked=new AtomicBoolean(false);
  Future<Void> setFuture=store.set(toSet,new Callback<Void>(){
    @Override public void onCompletion(    Throwable error,    Void result){
      invoked.set(true);
    }
  }
);
  assertFalse(setFuture.isDone());
  callback1.getValue().onCompletion(null,null);
  assertFalse(invoked.get());
  callback0.getValue().onCompletion(null,null);
  setFuture.get(10000,TimeUnit.MILLISECONDS);
  assertTrue(invoked.get());
  final AtomicBoolean secondGetInvokedAndPassed=new AtomicBoolean(false);
  store.get(Arrays.asList(TP0_KEY,TP1_KEY),new Callback<Map<ByteBuffer,ByteBuffer>>(){
    @Override public void onCompletion(    Throwable error,    Map<ByteBuffer,ByteBuffer> result){
      assertEquals(TP0_VALUE,result.get(TP0_KEY));
      assertEquals(TP1_VALUE,result.get(TP1_KEY));
      secondGetInvokedAndPassed.set(true);
    }
  }
).get(10000,TimeUnit.MILLISECONDS);
  assertTrue(secondGetInvokedAndPassed.get());
  final AtomicBoolean thirdGetInvokedAndPassed=new AtomicBoolean(false);
  store.get(Arrays.asList(TP0_KEY,TP1_KEY),new Callback<Map<ByteBuffer,ByteBuffer>>(){
    @Override public void onCompletion(    Throwable error,    Map<ByteBuffer,ByteBuffer> result){
      assertEquals(TP0_VALUE_NEW,result.get(TP0_KEY));
      assertEquals(TP1_VALUE_NEW,result.get(TP1_KEY));
      thirdGetInvokedAndPassed.set(true);
    }
  }
).get(10000,TimeUnit.MILLISECONDS);
  assertTrue(thirdGetInvokedAndPassed.get());
  store.stop();
  PowerMock.verifyAll();
}
