/** 
 * Test that waiting on a request that never completes times out
 */
@Test public void testTimeout() throws Exception {
  ProduceRequestResult request=new ProduceRequestResult(topicPartition);
  FutureRecordMetadata future=new FutureRecordMetadata(request,relOffset,RecordBatch.NO_TIMESTAMP,0L,0,0);
  assertFalse("Request is not completed",future.isDone());
  try {
    future.get(5,TimeUnit.MILLISECONDS);
    fail("Should have thrown exception.");
  }
 catch (  TimeoutException e) {
  }
  request.set(baseOffset,RecordBatch.NO_TIMESTAMP,null);
  request.done();
  assertTrue(future.isDone());
  assertEquals(baseOffset + relOffset,future.get().offset());
}
