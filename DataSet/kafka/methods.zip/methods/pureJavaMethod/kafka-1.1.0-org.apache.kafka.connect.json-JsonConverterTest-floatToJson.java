@Test public void floatToJson(){
  JsonNode converted=parse(converter.fromConnectData(TOPIC,Schema.FLOAT32_SCHEMA,12.34f));
  validateEnvelope(converted);
  assertEquals(parse("{ \"type\": \"float\", \"optional\": false }"),converted.get(JsonSchema.ENVELOPE_SCHEMA_FIELD_NAME));
  assertEquals(12.34f,converted.get(JsonSchema.ENVELOPE_PAYLOAD_FIELD_NAME).floatValue(),0.001);
}
