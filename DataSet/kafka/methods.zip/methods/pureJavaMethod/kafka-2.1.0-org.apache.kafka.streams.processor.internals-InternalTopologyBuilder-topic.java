@Override public String topic(){
  if (topicNameExtractor instanceof StaticTopicNameExtractor) {
    return ((StaticTopicNameExtractor)topicNameExtractor).topicName;
  }
 else {
    return null;
  }
}
