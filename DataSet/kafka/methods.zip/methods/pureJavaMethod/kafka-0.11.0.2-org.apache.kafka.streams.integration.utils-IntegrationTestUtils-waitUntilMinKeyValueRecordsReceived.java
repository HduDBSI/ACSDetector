/** 
 * Wait until enough data (key-value records) has been consumed.
 * @param consumerConfig     Kafka Consumer configuration
 * @param topic              Topic to consume from
 * @param expectedNumRecords Minimum number of expected records
 * @param waitTime           Upper bound in waiting time in milliseconds
 * @return All the records consumed, or null if no records are consumed
 * @throws InterruptedException
 * @throws AssertionError       if the given wait time elapses
 */
public static <K,V>List<KeyValue<K,V>> waitUntilMinKeyValueRecordsReceived(final Properties consumerConfig,final String topic,final int expectedNumRecords,final long waitTime) throws InterruptedException {
  final List<KeyValue<K,V>> accumData=new ArrayList<>();
  try (final Consumer<K,V> consumer=createConsumer(consumerConfig)){
    final TestCondition valuesRead=new TestCondition(){
      @Override public boolean conditionMet(){
        final List<KeyValue<K,V>> readData=readKeyValues(topic,consumer,waitTime,expectedNumRecords);
        accumData.addAll(readData);
        return accumData.size() >= expectedNumRecords;
      }
    }
;
    final String conditionDetails="Did not receive all " + expectedNumRecords + " records from topic "+ topic;
    TestUtils.waitForCondition(valuesRead,waitTime,conditionDetails);
  }
   return accumData;
}
