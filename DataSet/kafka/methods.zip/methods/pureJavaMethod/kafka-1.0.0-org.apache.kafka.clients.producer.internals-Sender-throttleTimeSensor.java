public static Sensor throttleTimeSensor(SenderMetricsRegistry metrics){
  Sensor produceThrottleTimeSensor=metrics.sensor("produce-throttle-time");
  produceThrottleTimeSensor.add(metrics.produceThrottleTimeAvg,new Avg());
  produceThrottleTimeSensor.add(metrics.produceThrottleTimeMax,new Max());
  return produceThrottleTimeSensor;
}
