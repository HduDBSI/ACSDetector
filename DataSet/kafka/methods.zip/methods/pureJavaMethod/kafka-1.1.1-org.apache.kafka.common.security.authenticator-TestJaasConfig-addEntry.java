public void addEntry(String name,String loginModule,Map<String,Object> options){
  AppConfigurationEntry entry=new AppConfigurationEntry(loginModule,LoginModuleControlFlag.REQUIRED,options);
  AppConfigurationEntry[] existing=entryMap.get(name);
  AppConfigurationEntry[] newEntries=existing == null ? new AppConfigurationEntry[1] : Arrays.copyOf(existing,existing.length + 1);
  newEntries[newEntries.length - 1]=entry;
  entryMap.put(name,newEntries);
}
