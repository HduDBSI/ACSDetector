/** 
 * @param valueSchema the schema for elements of the array
 * @return a new {@link Schema.Type#ARRAY} SchemaBuilder
 */
public static SchemaBuilder array(Schema valueSchema){
  if (null == valueSchema)   throw new SchemaBuilderException("valueSchema cannot be null.");
  SchemaBuilder builder=new SchemaBuilder(Type.ARRAY);
  builder.valueSchema=valueSchema;
  return builder;
}
