@Test public void retentionTimeMustNoBeSmallerThanWindowSize(){
  final TimeWindows windowSpec=TimeWindows.of(ANY_SIZE);
  try {
    windowSpec.until(ANY_SIZE - 1);
    fail("should not accept retention time smaller than window size");
  }
 catch (  final IllegalArgumentException e) {
  }
}
