@Override public void close() throws IOException {
  if (principalBuilder instanceof Closeable)   Utils.closeQuietly((Closeable)principalBuilder,"principal builder");
}
