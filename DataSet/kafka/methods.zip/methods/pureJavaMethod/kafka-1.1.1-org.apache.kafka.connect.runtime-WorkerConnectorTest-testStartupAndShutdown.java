@Test public void testStartupAndShutdown(){
  connector.version();
  expectLastCall().andReturn(VERSION);
  connector.initialize(EasyMock.notNull(ConnectorContext.class));
  expectLastCall();
  connector.start(CONFIG);
  expectLastCall();
  listener.onStartup(CONNECTOR);
  expectLastCall();
  connector.stop();
  expectLastCall();
  listener.onShutdown(CONNECTOR);
  expectLastCall();
  replayAll();
  WorkerConnector workerConnector=new WorkerConnector(CONNECTOR,connector,ctx,metrics,listener);
  workerConnector.initialize(connectorConfig);
  assertInitializedMetric(workerConnector);
  workerConnector.transitionTo(TargetState.STARTED);
  assertRunningMetric(workerConnector);
  workerConnector.shutdown();
  assertStoppedMetric(workerConnector);
  verifyAll();
}
