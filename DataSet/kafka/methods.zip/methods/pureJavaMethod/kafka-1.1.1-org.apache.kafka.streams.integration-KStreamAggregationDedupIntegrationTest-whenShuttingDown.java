@After public void whenShuttingDown() throws IOException {
  if (kafkaStreams != null) {
    kafkaStreams.close();
  }
  IntegrationTestUtils.purgeLocalStreamsState(streamsConfiguration);
}
