@Override public int hashCode(){
  int result=id != null ? id.hashCode() : 0;
  result=31 * result + (state != null ? state.hashCode() : 0);
  result=31 * result + (trace != null ? trace.hashCode() : 0);
  result=31 * result + (workerId != null ? workerId.hashCode() : 0);
  result=31 * result + generation;
  return result;
}
