@Override public SinkRecord newRecord(String topic,Integer kafkaPartition,Schema keySchema,Object key,Schema valueSchema,Object value,Long timestamp,Iterable<Header> headers){
  return new SinkRecord(topic,kafkaPartition,keySchema,key,valueSchema,value,kafkaOffset(),timestamp,timestampType,headers);
}
