private LeaveGroupResponse createLeaveGroupResponse(){
  return new LeaveGroupResponse(Errors.NONE);
}
