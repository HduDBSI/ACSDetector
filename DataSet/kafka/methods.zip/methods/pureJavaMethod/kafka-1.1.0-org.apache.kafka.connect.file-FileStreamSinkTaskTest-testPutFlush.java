@Test public void testPutFlush(){
  HashMap<TopicPartition,OffsetAndMetadata> offsets=new HashMap<>();
  final String newLine=System.getProperty("line.separator");
  task.put(Arrays.asList(new SinkRecord("topic1",0,null,null,Schema.STRING_SCHEMA,"line1",1)));
  offsets.put(new TopicPartition("topic1",0),new OffsetAndMetadata(1L));
  task.flush(offsets);
  assertEquals("line1" + newLine,os.toString());
  task.put(Arrays.asList(new SinkRecord("topic1",0,null,null,Schema.STRING_SCHEMA,"line2",2),new SinkRecord("topic2",0,null,null,Schema.STRING_SCHEMA,"line3",1)));
  offsets.put(new TopicPartition("topic1",0),new OffsetAndMetadata(2L));
  offsets.put(new TopicPartition("topic2",0),new OffsetAndMetadata(1L));
  task.flush(offsets);
  assertEquals("line1" + newLine + "line2"+ newLine+ "line3"+ newLine,os.toString());
}
