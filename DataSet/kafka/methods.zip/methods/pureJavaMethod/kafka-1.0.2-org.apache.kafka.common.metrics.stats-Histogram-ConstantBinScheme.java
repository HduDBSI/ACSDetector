/** 
 * Create a bin scheme with the specified number of bins that all have the same width.
 * @param bins the number of bins; must be at least 2
 * @param min the minimum value to be counted in the bins
 * @param max the maximum value to be counted in the bins
 */
public ConstantBinScheme(int bins,double min,double max){
  if (bins < 2)   throw new IllegalArgumentException("Must have at least 2 bins.");
  this.min=min;
  this.max=max;
  this.bins=bins;
  this.bucketWidth=(max - min) / bins;
  this.maxBinNumber=bins - 1;
}
