/** 
 * Execute the shell command. 
 */
public void execute() throws IOException {
  this.run();
}
