public void remove(TopicPartition topicPartition){
  map.remove(topicPartition);
}
