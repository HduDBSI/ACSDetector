private static boolean verifyDif(Map<String,Integer> map,Map<String,Set<Integer>> allData,final boolean print){
  if (map.isEmpty()) {
    if (print) {
      System.out.println("dif is empty");
    }
    return false;
  }
 else {
    if (print) {
      System.out.println("verifying dif");
    }
    if (map.size() != allData.size()) {
      if (print) {
        System.out.println("fail: resultCount=" + map.size() + " expectedCount="+ allData.size());
      }
      return false;
    }
    for (    Map.Entry<String,Integer> entry : map.entrySet()) {
      int min=getMin(entry.getKey());
      int max=getMax(entry.getKey());
      int expected=max - min;
      if (entry.getValue() == null || expected != entry.getValue()) {
        if (print) {
          System.out.println("fail: key=" + entry.getKey() + " dif="+ entry.getValue()+ " expected="+ expected);
        }
        return false;
      }
    }
  }
  return true;
}
