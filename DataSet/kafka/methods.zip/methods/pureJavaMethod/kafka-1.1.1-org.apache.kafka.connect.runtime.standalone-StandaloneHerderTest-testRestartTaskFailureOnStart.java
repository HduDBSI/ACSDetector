@Test public void testRestartTaskFailureOnStart() throws Exception {
  ConnectorTaskId taskId=new ConnectorTaskId(CONNECTOR_NAME,0);
  expectAdd(SourceSink.SOURCE);
  Map<String,String> connectorConfig=connectorConfig(SourceSink.SOURCE);
  Connector connectorMock=PowerMock.createMock(SourceConnector.class);
  expectConfigValidation(connectorMock,true,connectorConfig);
  worker.stopAndAwaitTask(taskId);
  EasyMock.expectLastCall();
  worker.startTask(taskId,connectorConfig,taskConfig(SourceSink.SOURCE),herder,TargetState.STARTED);
  EasyMock.expectLastCall().andReturn(false);
  PowerMock.replayAll();
  herder.putConnectorConfig(CONNECTOR_NAME,connectorConfig,false,createCallback);
  FutureCallback<Void> cb=new FutureCallback<>();
  herder.restartTask(taskId,cb);
  try {
    cb.get(1000L,TimeUnit.MILLISECONDS);
    fail("Expected restart callback to raise an exception");
  }
 catch (  ExecutionException exception) {
    assertEquals(ConnectException.class,exception.getCause().getClass());
  }
  PowerMock.verifyAll();
}
