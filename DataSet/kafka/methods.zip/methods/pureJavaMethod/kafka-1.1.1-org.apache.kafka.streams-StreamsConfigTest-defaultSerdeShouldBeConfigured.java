@Test public void defaultSerdeShouldBeConfigured(){
  final Map<String,Object> serializerConfigs=new HashMap<>();
  serializerConfigs.put("key.serializer.encoding","UTF8");
  serializerConfigs.put("value.serializer.encoding","UTF-16");
  final Serializer<String> serializer=Serdes.String().serializer();
  final String str="my string for testing";
  final String topic="my topic";
  serializer.configure(serializerConfigs,true);
  assertEquals("Should get the original string after serialization and deserialization with the configured encoding",str,streamsConfig.defaultKeySerde().deserializer().deserialize(topic,serializer.serialize(topic,str)));
  serializer.configure(serializerConfigs,false);
  assertEquals("Should get the original string after serialization and deserialization with the configured encoding",str,streamsConfig.defaultValueSerde().deserializer().deserialize(topic,serializer.serialize(topic,str)));
}
