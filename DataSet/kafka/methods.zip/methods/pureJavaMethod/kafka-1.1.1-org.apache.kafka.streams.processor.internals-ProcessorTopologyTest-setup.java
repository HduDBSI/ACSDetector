@Before public void setup(){
  File localState=TestUtils.tempDirectory();
  Properties props=new Properties();
  props.setProperty(StreamsConfig.APPLICATION_ID_CONFIG,"processor-topology-test");
  props.setProperty(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG,"localhost:9091");
  props.setProperty(StreamsConfig.STATE_DIR_CONFIG,localState.getAbsolutePath());
  props.setProperty(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG,Serdes.String().getClass().getName());
  props.setProperty(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG,Serdes.String().getClass().getName());
  props.setProperty(StreamsConfig.DEFAULT_TIMESTAMP_EXTRACTOR_CLASS_CONFIG,CustomTimestampExtractor.class.getName());
  this.config=new StreamsConfig(props);
}
