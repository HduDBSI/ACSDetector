/** 
 * Get the list of sent records since the last call to  {@link #clear()}
 */
public synchronized List<ProducerRecord<K,V>> history(){
  return new ArrayList<>(this.sent);
}
