public boolean matches(URL url){
  final String protocol=url.getProtocol();
  final String externalForm=url.toExternalForm();
  if (!protocol.equals(FILE_PROTOCOL)) {
    return false;
  }
  for (  String ending : endings) {
    if (externalForm.endsWith(ending)) {
      return true;
    }
  }
  return false;
}
