/** 
 * Return the number of partitions to create or null if replicaAssignments is not null.
 */
public Integer numPartitions(){
  return numPartitions;
}
