@Test public void testInt16Builder(){
  Schema schema=SchemaBuilder.int16().build();
  assertTypeAndDefault(schema,Schema.Type.INT16,false,null);
  assertNoMetadata(schema);
  schema=SchemaBuilder.int16().name(NAME).optional().defaultValue((short)12).version(VERSION).doc(DOC).build();
  assertTypeAndDefault(schema,Schema.Type.INT16,true,(short)12);
  assertMetadata(schema,NAME,VERSION,DOC,NO_PARAMS);
}
