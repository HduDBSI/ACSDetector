private PartitionRecords(TopicPartition partition,CompletedFetch completedFetch,Iterator<? extends RecordBatch> batches){
  this.partition=partition;
  this.completedFetch=completedFetch;
  this.batches=batches;
  this.nextFetchOffset=completedFetch.fetchedOffset;
  this.abortedProducerIds=new HashSet<>();
  this.abortedTransactions=abortedTransactions(completedFetch.partitionData);
}
