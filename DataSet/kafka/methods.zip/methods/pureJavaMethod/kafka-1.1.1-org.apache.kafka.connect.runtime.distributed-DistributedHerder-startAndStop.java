private void startAndStop(Collection<Callable<Void>> callables){
  try {
    startAndStopExecutor.invokeAll(callables);
  }
 catch (  InterruptedException e) {
  }
}
