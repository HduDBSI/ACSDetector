public void close() throws IOException {
  try {
    globalConsumer.close();
  }
 catch (  final RuntimeException e) {
    log.error("Failed to close consumer due to the following error:",e);
  }
  stateMaintainer.close();
}
