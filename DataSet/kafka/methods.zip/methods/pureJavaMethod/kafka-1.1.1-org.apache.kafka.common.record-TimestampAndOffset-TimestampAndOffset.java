public TimestampAndOffset(long timestamp,long offset){
  this.timestamp=timestamp;
  this.offset=offset;
}
