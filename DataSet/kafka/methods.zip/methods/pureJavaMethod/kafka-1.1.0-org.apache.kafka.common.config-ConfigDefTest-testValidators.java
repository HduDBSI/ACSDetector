private void testValidators(Type type,Validator validator,Object defaultVal,Object[] okValues,Object[] badValues){
  ConfigDef def=new ConfigDef().define("name",type,defaultVal,validator,Importance.HIGH,"docs");
  for (  Object value : okValues) {
    Map<String,Object> m=new HashMap<String,Object>();
    m.put("name",value);
    def.parse(m);
  }
  for (  Object value : badValues) {
    Map<String,Object> m=new HashMap<String,Object>();
    m.put("name",value);
    try {
      def.parse(m);
      fail("Expected a config exception due to invalid value " + value);
    }
 catch (    ConfigException e) {
    }
  }
}
