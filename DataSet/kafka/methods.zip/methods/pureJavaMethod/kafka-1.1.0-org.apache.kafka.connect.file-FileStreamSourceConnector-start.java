@Override public void start(Map<String,String> props){
  AbstractConfig parsedConfig=new AbstractConfig(CONFIG_DEF,props);
  filename=parsedConfig.getString(FILE_CONFIG);
  List<String> topics=parsedConfig.getList(TOPIC_CONFIG);
  if (topics.size() != 1) {
    throw new ConfigException("'topic' in FileStreamSourceConnector configuration requires definition of a single topic");
  }
  topic=topics.get(0);
  batchSize=parsedConfig.getInt(TASK_BATCH_SIZE_CONFIG);
}
