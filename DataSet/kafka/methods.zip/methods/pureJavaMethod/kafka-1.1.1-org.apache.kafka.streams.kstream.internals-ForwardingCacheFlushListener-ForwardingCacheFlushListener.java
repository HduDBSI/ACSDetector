ForwardingCacheFlushListener(final ProcessorContext context,final boolean sendOldValues){
  this.context=(InternalProcessorContext)context;
  myNode=this.context.currentNode();
  this.sendOldValues=sendOldValues;
}
