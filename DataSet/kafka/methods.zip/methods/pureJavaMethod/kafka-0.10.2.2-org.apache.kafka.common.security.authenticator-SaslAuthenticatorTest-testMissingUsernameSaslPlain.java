/** 
 * Tests that SASL/PLAIN clients without valid username fail authentication.
 */
@Test public void testMissingUsernameSaslPlain() throws Exception {
  String node="0";
  TestJaasConfig jaasConfig=configureMechanisms("PLAIN",Arrays.asList("PLAIN"));
  jaasConfig.setPlainClientOptions(null,"mypassword");
  SecurityProtocol securityProtocol=SecurityProtocol.SASL_SSL;
  server=NetworkTestUtils.createEchoServer(securityProtocol,saslServerConfigs);
  createSelector(securityProtocol,saslClientConfigs);
  InetSocketAddress addr=new InetSocketAddress("127.0.0.1",server.port());
  try {
    selector.connect(node,addr,BUFFER_SIZE,BUFFER_SIZE);
    fail("SASL/PLAIN channel created without username");
  }
 catch (  IOException e) {
    assertTrue("Channels not closed",selector.channels().isEmpty());
    for (    SelectionKey key : selector.keys())     assertFalse("Key not cancelled",key.isValid());
  }
}
