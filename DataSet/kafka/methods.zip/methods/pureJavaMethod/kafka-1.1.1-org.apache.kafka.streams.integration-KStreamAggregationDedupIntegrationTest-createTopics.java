private void createTopics() throws InterruptedException {
  streamOneInput="stream-one-" + testNo;
  outputTopic="output-" + testNo;
  CLUSTER.createTopic(streamOneInput,3,1);
  CLUSTER.createTopic(outputTopic);
}
