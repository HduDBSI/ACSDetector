@Override public boolean equals(Object o){
  if (o instanceof SubscriptionInfo) {
    SubscriptionInfo other=(SubscriptionInfo)o;
    return this.version == other.version && this.processId.equals(other.processId) && this.prevTasks.equals(other.prevTasks) && this.standbyTasks.equals(other.standbyTasks) && this.userEndPoint != null ? this.userEndPoint.equals(other.userEndPoint) : other.userEndPoint == null;
  }
 else {
    return false;
  }
}
