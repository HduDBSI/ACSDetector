@Override public void onCompletion(Throwable error,ConsumerRecord<String,byte[]> record){
  if (error != null) {
    log.error("Unexpected in consumer callback for KafkaConfigBackingStore: ",error);
    return;
  }
  final SchemaAndValue value;
  try {
    value=converter.toConnectData(topic,record.value());
  }
 catch (  DataException e) {
    log.error("Failed to convert config data to Kafka Connect format: ",e);
    return;
  }
  offset=record.offset() + 1;
  if (record.key().startsWith(TARGET_STATE_PREFIX)) {
    String connectorName=record.key().substring(TARGET_STATE_PREFIX.length());
    boolean removed=false;
synchronized (lock) {
      if (value.value() == null) {
        log.debug("Removed target state for connector {} due to null value in topic.",connectorName);
        connectorTargetStates.remove(connectorName);
        removed=true;
        if (connectorConfigs.containsKey(connectorName))         connectorTargetStates.put(connectorName,TargetState.STARTED);
      }
 else {
        if (!(value.value() instanceof Map)) {
          log.error("Found target state ({}) in wrong format: {}",record.key(),value.value().getClass());
          return;
        }
        Object targetState=((Map<String,Object>)value.value()).get("state");
        if (!(targetState instanceof String)) {
          log.error("Invalid data for target state for connector ({}): 'state' field should be a Map but is {}",connectorName,targetState == null ? null : targetState.getClass());
          return;
        }
        try {
          TargetState state=TargetState.valueOf((String)targetState);
          log.debug("Setting target state for connector {} to {}",connectorName,targetState);
          connectorTargetStates.put(connectorName,state);
        }
 catch (        IllegalArgumentException e) {
          log.error("Invalid target state for connector ({}): {}",connectorName,targetState);
          return;
        }
      }
    }
    if (started && !removed)     updateListener.onConnectorTargetStateChange(connectorName);
  }
 else   if (record.key().startsWith(CONNECTOR_PREFIX)) {
    String connectorName=record.key().substring(CONNECTOR_PREFIX.length());
    boolean removed=false;
synchronized (lock) {
      if (value.value() == null) {
        log.info("Removed connector " + connectorName + " due to null configuration. This is usually intentional and does not indicate an issue.");
        connectorConfigs.remove(connectorName);
        removed=true;
      }
 else {
        if (!(value.value() instanceof Map)) {
          log.error("Found connector configuration (" + record.key() + ") in wrong format: "+ value.value().getClass());
          return;
        }
        Object newConnectorConfig=((Map<String,Object>)value.value()).get("properties");
        if (!(newConnectorConfig instanceof Map)) {
          log.error("Invalid data for connector config ({}): properties field should be a Map but is {}",connectorName,newConnectorConfig == null ? null : newConnectorConfig.getClass());
          return;
        }
        log.debug("Updating configuration for connector " + connectorName + " configuration: "+ newConnectorConfig);
        connectorConfigs.put(connectorName,(Map<String,String>)newConnectorConfig);
        if (!connectorTargetStates.containsKey(connectorName))         connectorTargetStates.put(connectorName,TargetState.STARTED);
      }
    }
    if (started) {
      if (removed)       updateListener.onConnectorConfigRemove(connectorName);
 else       updateListener.onConnectorConfigUpdate(connectorName);
    }
  }
 else   if (record.key().startsWith(TASK_PREFIX)) {
synchronized (lock) {
      ConnectorTaskId taskId=parseTaskId(record.key());
      if (taskId == null) {
        log.error("Ignoring task configuration because " + record.key() + " couldn't be parsed as a task config key");
        return;
      }
      if (!(value.value() instanceof Map)) {
        log.error("Ignoring task configuration for task " + taskId + " because it is in the wrong format: "+ value.value());
        return;
      }
      Object newTaskConfig=((Map<String,Object>)value.value()).get("properties");
      if (!(newTaskConfig instanceof Map)) {
        log.error("Invalid data for task config (" + taskId + "): properties filed should be a Map but is "+ newTaskConfig.getClass());
        return;
      }
      Map<ConnectorTaskId,Map<String,String>> deferred=deferredTaskUpdates.get(taskId.connector());
      if (deferred == null) {
        deferred=new HashMap<>();
        deferredTaskUpdates.put(taskId.connector(),deferred);
      }
      log.debug("Storing new config for task " + taskId + " this will wait for a commit message before the new config will take effect. New config: "+ newTaskConfig);
      deferred.put(taskId,(Map<String,String>)newTaskConfig);
    }
  }
 else   if (record.key().startsWith(COMMIT_TASKS_PREFIX)) {
    String connectorName=record.key().substring(COMMIT_TASKS_PREFIX.length());
    List<ConnectorTaskId> updatedTasks=new ArrayList<>();
synchronized (lock) {
      if (!(value.value() instanceof Map)) {
        log.error("Ignoring connector tasks configuration commit for connector " + connectorName + " because it is in the wrong format: "+ value.value());
        return;
      }
      Map<ConnectorTaskId,Map<String,String>> deferred=deferredTaskUpdates.get(connectorName);
      int newTaskCount=intValue(((Map<String,Object>)value.value()).get("tasks"));
      Set<Integer> taskIdSet=taskIds(connectorName,deferred);
      if (!completeTaskIdSet(taskIdSet,newTaskCount)) {
        log.debug("We have an incomplete set of task configs for connector " + connectorName + " probably due to compaction. So we are not doing anything with the new configuration.");
        inconsistent.add(connectorName);
      }
 else {
        if (deferred != null) {
          taskConfigs.putAll(deferred);
          updatedTasks.addAll(taskConfigs.keySet());
        }
        inconsistent.remove(connectorName);
      }
      if (deferred != null)       deferred.clear();
      connectorTaskCounts.put(connectorName,newTaskCount);
    }
    if (started)     updateListener.onTaskConfigUpdate(updatedTasks);
  }
 else {
    log.error("Discarding config update record with invalid key: " + record.key());
  }
}
