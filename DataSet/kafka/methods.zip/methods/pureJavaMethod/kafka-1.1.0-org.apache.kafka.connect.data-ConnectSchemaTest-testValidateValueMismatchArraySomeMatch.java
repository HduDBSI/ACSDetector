@Test(expected=DataException.class) public void testValidateValueMismatchArraySomeMatch(){
  ConnectSchema.validateValue(SchemaBuilder.array(Schema.INT32_SCHEMA).build(),Arrays.asList(1,2,"c"));
}
