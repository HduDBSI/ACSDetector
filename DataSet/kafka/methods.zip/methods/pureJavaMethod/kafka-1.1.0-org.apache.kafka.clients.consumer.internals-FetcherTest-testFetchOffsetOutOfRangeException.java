@Test public void testFetchOffsetOutOfRangeException(){
  subscriptionsNoAutoReset.assignFromUser(singleton(tp0));
  subscriptionsNoAutoReset.seek(tp0,0);
  fetcherNoAutoReset.sendFetches();
  client.prepareResponse(fullFetchResponse(tp0,this.records,Errors.OFFSET_OUT_OF_RANGE,100L,0));
  consumerClient.poll(0);
  assertFalse(subscriptionsNoAutoReset.isOffsetResetNeeded(tp0));
  for (int i=0; i < 2; i++) {
    try {
      fetcherNoAutoReset.fetchedRecords();
      fail("Should have thrown OffsetOutOfRangeException");
    }
 catch (    OffsetOutOfRangeException e) {
      assertTrue(e.offsetOutOfRangePartitions().containsKey(tp0));
      assertEquals(e.offsetOutOfRangePartitions().size(),1);
    }
  }
}
