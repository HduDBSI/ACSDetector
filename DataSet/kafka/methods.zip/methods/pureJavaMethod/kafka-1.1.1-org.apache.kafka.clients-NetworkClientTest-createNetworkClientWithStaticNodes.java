private NetworkClient createNetworkClientWithStaticNodes(){
  return new NetworkClient(selector,new ManualMetadataUpdater(Arrays.asList(node)),"mock-static",Integer.MAX_VALUE,0,0,64 * 1024,64 * 1024,requestTimeoutMs,time,true,new ApiVersions(),new LogContext());
}
