private <T>KTable<K,T> doAggregate(final KStreamAggProcessorSupplier<K,?,V,T> aggregateSupplier,final String functionName,final MaterializedInternal<K,T,KeyValueStore<Bytes,byte[]>> materializedInternal){
  final StoreBuilder<KeyValueStore<K,T>> storeBuilder=new KeyValueStoreMaterializer<>(materializedInternal).materialize();
  return aggregateBuilder.build(aggregateSupplier,functionName,storeBuilder,materializedInternal.isQueryable());
}
