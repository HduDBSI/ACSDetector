public TaskInfo(ConnectorTaskId id,Map<String,String> config){
  this.id=id;
  this.config=config;
}
