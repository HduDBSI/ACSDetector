@Test public void testInconsistentConfigs() throws Exception {
}
