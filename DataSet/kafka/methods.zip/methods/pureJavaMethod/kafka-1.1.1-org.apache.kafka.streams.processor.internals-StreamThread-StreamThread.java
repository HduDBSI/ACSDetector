public StreamThread(final Time time,final StreamsConfig config,final Consumer<byte[],byte[]> restoreConsumer,final Consumer<byte[],byte[]> consumer,final String originalReset,final TaskManager taskManager,final StreamsMetricsThreadImpl streamsMetrics,final InternalTopologyBuilder builder,final String threadClientId,final LogContext logContext){
  super(threadClientId);
  this.stateLock=new Object();
  this.standbyRecords=new HashMap<>();
  this.time=time;
  this.builder=builder;
  this.streamsMetrics=streamsMetrics;
  this.logPrefix=logContext.logPrefix();
  this.log=logContext.logger(StreamThread.class);
  this.rebalanceListener=new RebalanceListener(time,taskManager,this,this.log);
  this.taskManager=taskManager;
  this.restoreConsumer=restoreConsumer;
  this.consumer=consumer;
  this.originalReset=originalReset;
  this.pollTimeMs=config.getLong(StreamsConfig.POLL_MS_CONFIG);
  this.commitTimeMs=config.getLong(StreamsConfig.COMMIT_INTERVAL_MS_CONFIG);
  updateThreadMetadata(Collections.<TaskId,StreamTask>emptyMap(),Collections.<TaskId,StandbyTask>emptyMap());
}
