public KafkaPrincipal(String principalType,String name){
  this.principalType=requireNonNull(principalType,"Principal type cannot be null");
  this.name=requireNonNull(name,"Principal name cannot be null");
}
