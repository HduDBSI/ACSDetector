@SuppressWarnings("unchecked") @Override public void init(final ProcessorContext context){
  store=(KeyValueStore<K,T>)context.getStateStore(storeName);
}
