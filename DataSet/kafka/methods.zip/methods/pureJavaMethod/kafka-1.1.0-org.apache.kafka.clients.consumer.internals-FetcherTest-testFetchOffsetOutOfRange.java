@Test public void testFetchOffsetOutOfRange(){
  subscriptions.assignFromUser(singleton(tp0));
  subscriptions.seek(tp0,0);
  assertEquals(1,fetcher.sendFetches());
  client.prepareResponse(fullFetchResponse(tp0,this.records,Errors.OFFSET_OUT_OF_RANGE,100L,0));
  consumerClient.poll(0);
  assertEquals(0,fetcher.fetchedRecords().size());
  assertTrue(subscriptions.isOffsetResetNeeded(tp0));
  assertEquals(null,subscriptions.position(tp0));
}
