@Test public void shouldSupportRange(){
  stubOneUnderlying.put("a","a");
  stubOneUnderlying.put("b","b");
  stubOneUnderlying.put("c","c");
  final List<KeyValue<String,String>> results=toList(theStore.range("a","b"));
  assertTrue(results.contains(new KeyValue<>("a","a")));
  assertTrue(results.contains(new KeyValue<>("b","b")));
  assertEquals(2,results.size());
}
