private StreamTask createStreamsTask(final String applicationId,final StreamsConfig streamsConfig,final MockClientSupplier clientSupplier,final ProcessorTopology topology,final TaskId taskId){
  return new StreamTask(taskId,Collections.singletonList(new TopicPartition(topicName,taskId.partition)),topology,clientSupplier.consumer,new StoreChangelogReader(clientSupplier.restoreConsumer,new MockStateRestoreListener(),new LogContext("test-stream-task ")),streamsConfig,new MockStreamsMetrics(new Metrics()),stateDirectory,null,new MockTime(),clientSupplier.getProducer(new HashMap<String,Object>())){
    @Override protected void updateOffsetLimits(){
    }
  }
;
}
