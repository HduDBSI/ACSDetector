public boolean hasDefault(){
  return !NO_DEFAULT_VALUE.equals(this.defaultValue);
}
