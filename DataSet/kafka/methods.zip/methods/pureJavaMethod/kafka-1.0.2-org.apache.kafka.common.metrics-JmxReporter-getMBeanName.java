/** 
 * @param metricName
 * @return standard JMX MBean name in the following format domainName:type=metricType,key1=val1,key2=val2
 */
static String getMBeanName(String prefix,MetricName metricName){
  StringBuilder mBeanName=new StringBuilder();
  mBeanName.append(prefix);
  mBeanName.append(":type=");
  mBeanName.append(metricName.group());
  for (  Map.Entry<String,String> entry : metricName.tags().entrySet()) {
    if (entry.getKey().length() <= 0 || entry.getValue().length() <= 0)     continue;
    mBeanName.append(",");
    mBeanName.append(entry.getKey());
    mBeanName.append("=");
    mBeanName.append(Sanitizer.jmxSanitize(entry.getValue()));
  }
  return mBeanName.toString();
}
