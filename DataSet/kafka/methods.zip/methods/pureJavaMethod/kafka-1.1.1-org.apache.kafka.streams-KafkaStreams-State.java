State(final Integer... validTransitions){
  this.validTransitions.addAll(Arrays.asList(validTransitions));
}
