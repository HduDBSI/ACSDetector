public static ConfigInfos generateResult(String connType,Map<String,ConfigKey> configKeys,List<ConfigValue> configValues,List<String> groups){
  int errorCount=0;
  List<ConfigInfo> configInfoList=new LinkedList<>();
  Map<String,ConfigValue> configValueMap=new HashMap<>();
  for (  ConfigValue configValue : configValues) {
    String configName=configValue.name();
    configValueMap.put(configName,configValue);
    if (!configKeys.containsKey(configName)) {
      configValue.addErrorMessage("Configuration is not defined: " + configName);
      configInfoList.add(new ConfigInfo(null,convertConfigValue(configValue,null)));
    }
  }
  for (  Map.Entry<String,ConfigKey> entry : configKeys.entrySet()) {
    String configName=entry.getKey();
    ConfigKeyInfo configKeyInfo=convertConfigKey(entry.getValue());
    Type type=entry.getValue().type;
    ConfigValueInfo configValueInfo=null;
    if (configValueMap.containsKey(configName)) {
      ConfigValue configValue=configValueMap.get(configName);
      configValueInfo=convertConfigValue(configValue,type);
      errorCount+=configValue.errorMessages().size();
    }
    configInfoList.add(new ConfigInfo(configKeyInfo,configValueInfo));
  }
  return new ConfigInfos(connType,errorCount,groups,configInfoList);
}
