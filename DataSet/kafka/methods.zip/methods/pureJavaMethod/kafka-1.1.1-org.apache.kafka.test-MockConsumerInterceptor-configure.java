@Override public void configure(Map<String,?> configs){
  Object clientIdValue=configs.get(ConsumerConfig.CLIENT_ID_CONFIG);
  if (clientIdValue == null)   throw new ConfigException("Mock consumer interceptor expects configuration " + ProducerConfig.CLIENT_ID_CONFIG);
}
