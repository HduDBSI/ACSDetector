@Test public void shouldRemove(){
  bytesStore.put(serializeKey(new Windowed<>("a",new SessionWindow(0,1000))),serializeValue(30L));
  bytesStore.put(serializeKey(new Windowed<>("a",new SessionWindow(1500,2500))),serializeValue(50L));
  bytesStore.remove(serializeKey(new Windowed<>("a",new SessionWindow(0,1000))));
  final KeyValueIterator<Bytes,byte[]> value=bytesStore.fetch(Bytes.wrap("a".getBytes()),0,1000L);
  assertFalse(value.hasNext());
}
