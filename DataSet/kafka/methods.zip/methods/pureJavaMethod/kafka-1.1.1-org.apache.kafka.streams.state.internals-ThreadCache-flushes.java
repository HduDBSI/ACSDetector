public long flushes(){
  return numFlushes;
}
