@Override public String toString(){
  StringBuilder bld=new StringBuilder();
  bld.append("(type=FetchRequest").append(", replicaId=").append(replicaId).append(", maxWait=").append(maxWait).append(", minBytes=").append(minBytes).append(", maxBytes=").append(maxBytes).append(", fetchData=").append(fetchData).append(", isolationLevel=").append(isolationLevel).append(", toForget=").append(Utils.join(toForget,", ")).append(", metadata=").append(metadata).append(")");
  return bld.toString();
}
