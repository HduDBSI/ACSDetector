@Test public void nullSchemaAndMapToJson(){
  Map<String,Object> input=new HashMap<>();
  input.put("key1",12);
  input.put("key2","string");
  input.put("key3",true);
  JsonNode converted=parse(converter.fromConnectData(TOPIC,null,input));
  validateEnvelopeNullSchema(converted);
  assertTrue(converted.get(JsonSchema.ENVELOPE_SCHEMA_FIELD_NAME).isNull());
  assertEquals(JsonNodeFactory.instance.objectNode().put("key1",12).put("key2","string").put("key3",true),converted.get(JsonSchema.ENVELOPE_PAYLOAD_FIELD_NAME));
}
