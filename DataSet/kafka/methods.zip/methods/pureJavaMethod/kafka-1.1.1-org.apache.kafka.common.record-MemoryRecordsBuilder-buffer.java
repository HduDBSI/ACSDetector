public ByteBuffer buffer(){
  return bufferStream.buffer();
}
