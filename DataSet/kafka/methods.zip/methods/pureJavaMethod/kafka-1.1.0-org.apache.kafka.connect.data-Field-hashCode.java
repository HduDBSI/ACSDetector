@Override public int hashCode(){
  return Objects.hash(name,index,schema);
}
