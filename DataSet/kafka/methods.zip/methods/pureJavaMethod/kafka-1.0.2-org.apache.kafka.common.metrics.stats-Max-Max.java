public Max(){
  super(Double.NEGATIVE_INFINITY);
}
