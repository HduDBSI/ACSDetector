@Test public void testFlushFailureReplacesOffsets() throws Exception {
  @SuppressWarnings("unchecked") final Callback<Void> callback=PowerMock.createMock(Callback.class);
  expectStore(OFFSET_KEY,OFFSET_KEY_SERIALIZED,OFFSET_VALUE,OFFSET_VALUE_SERIALIZED,callback,true,null);
  expectStore(OFFSET_KEY,OFFSET_KEY_SERIALIZED,OFFSET_VALUE,OFFSET_VALUE_SERIALIZED,callback,false,null);
  PowerMock.replayAll();
  writer.offset(OFFSET_KEY,OFFSET_VALUE);
  assertTrue(writer.beginFlush());
  writer.doFlush(callback).get(1000,TimeUnit.MILLISECONDS);
  assertTrue(writer.beginFlush());
  writer.doFlush(callback).get(1000,TimeUnit.MILLISECONDS);
  assertFalse(writer.beginFlush());
  PowerMock.verifyAll();
}
