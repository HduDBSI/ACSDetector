/** 
 * Process the record with the given key and value.
 * @param key the key for the record
 * @param value the value for the record
 */
void process(K key,V value);
