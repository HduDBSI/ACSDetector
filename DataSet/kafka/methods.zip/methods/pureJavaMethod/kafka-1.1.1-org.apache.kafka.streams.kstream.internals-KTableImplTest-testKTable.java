@Test public void testKTable(){
  final StreamsBuilder builder=new StreamsBuilder();
  String topic1="topic1";
  String topic2="topic2";
  String storeName2="storeName2";
  KTable<String,String> table1=builder.table(topic1,consumed);
  MockProcessorSupplier<String,String> proc1=new MockProcessorSupplier<>();
  table1.toStream().process(proc1);
  KTable<String,Integer> table2=table1.mapValues(new ValueMapper<String,Integer>(){
    @Override public Integer apply(    String value){
      return new Integer(value);
    }
  }
);
  MockProcessorSupplier<String,Integer> proc2=new MockProcessorSupplier<>();
  table2.toStream().process(proc2);
  KTable<String,Integer> table3=table2.filter(new Predicate<String,Integer>(){
    @Override public boolean test(    String key,    Integer value){
      return (value % 2) == 0;
    }
  }
);
  MockProcessorSupplier<String,Integer> proc3=new MockProcessorSupplier<>();
  table3.toStream().process(proc3);
  KTable<String,String> table4=table1.through(stringSerde,stringSerde,topic2,storeName2);
  MockProcessorSupplier<String,String> proc4=new MockProcessorSupplier<>();
  table4.toStream().process(proc4);
  driver.setUp(builder,stateDir);
  driver.process(topic1,"A","01");
  driver.flushState();
  driver.process(topic1,"B","02");
  driver.flushState();
  driver.process(topic1,"C","03");
  driver.flushState();
  driver.process(topic1,"D","04");
  driver.flushState();
  driver.flushState();
  assertEquals(Utils.mkList("A:01","B:02","C:03","D:04"),proc1.processed);
  assertEquals(Utils.mkList("A:1","B:2","C:3","D:4"),proc2.processed);
  assertEquals(Utils.mkList("A:null","B:2","C:null","D:4"),proc3.processed);
  assertEquals(Utils.mkList("A:01","B:02","C:03","D:04"),proc4.processed);
}
