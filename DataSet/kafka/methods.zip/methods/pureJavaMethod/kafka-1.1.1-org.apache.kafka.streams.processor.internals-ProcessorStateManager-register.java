@Override public void register(final StateStore store,final StateRestoreCallback stateRestoreCallback){
  final String storeName=store.name();
  log.debug("Registering state store {} to its state manager",storeName);
  if (CHECKPOINT_FILE_NAME.equals(storeName)) {
    throw new IllegalArgumentException(String.format("%sIllegal store name: %s",logPrefix,CHECKPOINT_FILE_NAME));
  }
  if (stores.containsKey(storeName)) {
    throw new IllegalArgumentException(String.format("%sStore %s has already been registered.",logPrefix,storeName));
  }
  final String topic=storeToChangelogTopic.get(storeName);
  if (topic == null) {
    stores.put(storeName,store);
    return;
  }
  final TopicPartition storePartition=new TopicPartition(topic,getPartition(topic));
  if (isStandby) {
    log.trace("Preparing standby replica of persistent state store {} with changelog topic {}",storeName,topic);
    restoreCallbacks.put(topic,stateRestoreCallback);
  }
 else {
    log.trace("Restoring state store {} from changelog topic {}",storeName,topic);
    final StateRestorer restorer=new StateRestorer(storePartition,new CompositeRestoreListener(stateRestoreCallback),checkpointableOffsets.get(storePartition),offsetLimit(storePartition),store.persistent(),storeName);
    changelogReader.register(restorer);
  }
  changelogPartitions.add(storePartition);
  stores.put(storeName,store);
}
