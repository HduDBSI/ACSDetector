@Override public void register(final StateStore store,final StateRestoreCallback stateRestoreCallback){
  if (initialized) {
    throw new IllegalStateException("Can only create state stores during initialization.");
  }
  Objects.requireNonNull(store,"store must not be null");
  stateManager.register(store,stateRestoreCallback);
}
