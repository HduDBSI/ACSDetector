/** 
 * Join records of this stream with  {@link GlobalKTable}'s records using non-windowed inner equi join. The join is a primary key table lookup join with join attribute {@code keyValueMapper.map(stream.keyValue) == table.key}. "Table lookup join" means, that results are only computed if  {@code KStream} records are processed.This is done by performing a lookup for matching records in the <em>current</em> internal  {@link GlobalKTable}state. In contrast, processing  {@link GlobalKTable} input records will only update the internal {@link GlobalKTable}state and will not produce any result records. <p> For each  {@code KStream} record that finds a corresponding record in {@link GlobalKTable} the provided{@link ValueJoiner} will be called to compute a value (with arbitrary type) for the result record.The key of the result record is the same as the key of this  {@code KStream}. If a  {@code KStream} input record key or value is {@code null} the record will not be included in the joinoperation and thus no output record will be added to the resulting  {@code KStream}. If  {@code keyValueMapper} returns {@code null} implying no match exists, no output record will be added to theresulting  {@code KStream}.
 * @param globalKTable   the {@link GlobalKTable} to be joined with this stream
 * @param keyValueMapper instance of {@link KeyValueMapper} used to map from the (key, value) of this streamto the key of the  {@link GlobalKTable}
 * @param joiner         a {@link ValueJoiner} that computes the join result for a pair of matching records
 * @param < GK >           the key type of {@link GlobalKTable}
 * @param < GV >           the value type of the {@link GlobalKTable}
 * @param < RV >           the value type of the resulting {@code KStream}
 * @return a {@code KStream} that contains join-records for each key and values computed by the given{@link ValueJoiner}, one output for each input  {@code KStream} record
 * @see #leftJoin(GlobalKTable,KeyValueMapper,ValueJoiner)
 */
<GK,GV,RV>KStream<K,RV> join(final GlobalKTable<GK,GV> globalKTable,final KeyValueMapper<? super K,? super V,? extends GK> keyValueMapper,final ValueJoiner<? super V,? super GV,? extends RV> joiner);
