@Test public void testRestartTask() throws Exception {
  EasyMock.expect(worker.connectorTaskConfigs(CONN1,conn1SinkConfig)).andStubReturn(TASK_CONFIGS);
  EasyMock.expect(member.memberId()).andStubReturn("leader");
  expectRebalance(1,Collections.<String>emptyList(),singletonList(TASK0));
  expectPostRebalanceCatchup(SNAPSHOT);
  member.poll(EasyMock.anyInt());
  PowerMock.expectLastCall();
  worker.startTask(EasyMock.eq(TASK0),EasyMock.<Map<String,String>>anyObject(),EasyMock.<Map<String,String>>anyObject(),EasyMock.eq(herder),EasyMock.eq(TargetState.STARTED));
  PowerMock.expectLastCall().andReturn(true);
  member.wakeup();
  PowerMock.expectLastCall();
  member.ensureActive();
  PowerMock.expectLastCall();
  member.poll(EasyMock.anyInt());
  PowerMock.expectLastCall();
  worker.stopAndAwaitTask(TASK0);
  PowerMock.expectLastCall();
  worker.startTask(EasyMock.eq(TASK0),EasyMock.<Map<String,String>>anyObject(),EasyMock.<Map<String,String>>anyObject(),EasyMock.eq(herder),EasyMock.eq(TargetState.STARTED));
  PowerMock.expectLastCall().andReturn(true);
  PowerMock.replayAll();
  herder.tick();
  FutureCallback<Void> callback=new FutureCallback<>();
  herder.restartTask(TASK0,callback);
  herder.tick();
  callback.get(1000L,TimeUnit.MILLISECONDS);
  PowerMock.verifyAll();
}
