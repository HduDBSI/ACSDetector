/** 
 * @param amountSoFar bytes produced so far if you want to throttle data throughput, ormessages produced so far if you want to throttle message throughput.
 * @param sendStartMs timestamp of the most recently sent message
 * @return
 */
public boolean shouldThrottle(long amountSoFar,long sendStartMs){
  if (this.targetThroughput < 0) {
    return false;
  }
  float elapsedSec=(sendStartMs - startMs) / 1000.f;
  return elapsedSec > 0 && (amountSoFar / elapsedSec) > this.targetThroughput;
}
