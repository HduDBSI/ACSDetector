@Test(expected=ApiException.class) public void testJoinGroupInvalidGroupId(){
  final String consumerId="leader";
  subscriptions.subscribe(singleton(topic1),rebalanceListener);
  metadata.setTopics(singletonList(topic1));
  metadata.update(cluster,Collections.<String>emptySet(),time.milliseconds());
  client.prepareResponse(groupCoordinatorResponse(node,Errors.NONE));
  coordinator.ensureCoordinatorReady();
  client.prepareResponse(joinGroupLeaderResponse(0,consumerId,Collections.<String,List<String>>emptyMap(),Errors.INVALID_GROUP_ID));
  coordinator.poll(time.milliseconds(),Long.MAX_VALUE);
}
