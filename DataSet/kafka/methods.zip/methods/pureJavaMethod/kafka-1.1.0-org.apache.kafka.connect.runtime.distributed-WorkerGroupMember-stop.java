private void stop(boolean swallowException){
  log.trace("Stopping the Connect group member.");
  AtomicReference<Throwable> firstException=new AtomicReference<>();
  this.stopped=true;
  ClientUtils.closeQuietly(coordinator,"coordinator",firstException);
  ClientUtils.closeQuietly(metrics,"consumer metrics",firstException);
  ClientUtils.closeQuietly(client,"consumer network client",firstException);
  AppInfoParser.unregisterAppInfo(JMX_PREFIX,clientId,metrics);
  if (firstException.get() != null && !swallowException)   throw new KafkaException("Failed to stop the Connect group member",firstException.get());
 else   log.debug("The Connect group member has stopped.");
}
