public abstract T convert(U result);
