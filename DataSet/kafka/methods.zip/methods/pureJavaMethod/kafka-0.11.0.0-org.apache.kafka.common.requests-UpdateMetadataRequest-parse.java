public static UpdateMetadataRequest parse(ByteBuffer buffer,short version){
  return new UpdateMetadataRequest(ApiKeys.UPDATE_METADATA_KEY.parseRequest(version,buffer),version);
}
