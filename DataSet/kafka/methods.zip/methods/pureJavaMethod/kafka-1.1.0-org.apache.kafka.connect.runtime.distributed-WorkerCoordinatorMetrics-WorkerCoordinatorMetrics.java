public WorkerCoordinatorMetrics(Metrics metrics,String metricGrpPrefix){
  this.metricGrpName=metricGrpPrefix + "-coordinator-metrics";
  Measurable numConnectors=new Measurable(){
    public double measure(    MetricConfig config,    long now){
      return assignmentSnapshot.connectors().size();
    }
  }
;
  Measurable numTasks=new Measurable(){
    public double measure(    MetricConfig config,    long now){
      return assignmentSnapshot.tasks().size();
    }
  }
;
  metrics.addMetric(metrics.metricName("assigned-connectors",this.metricGrpName,"The number of connector instances currently assigned to this consumer"),numConnectors);
  metrics.addMetric(metrics.metricName("assigned-tasks",this.metricGrpName,"The number of tasks currently assigned to this consumer"),numTasks);
}
