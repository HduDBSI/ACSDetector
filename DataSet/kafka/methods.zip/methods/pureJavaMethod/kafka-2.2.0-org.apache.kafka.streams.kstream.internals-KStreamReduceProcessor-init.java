@SuppressWarnings("unchecked") @Override public void init(final ProcessorContext context){
  super.init(context);
  metrics=(StreamsMetricsImpl)context.metrics();
  store=(KeyValueStore<K,V>)context.getStateStore(storeName);
  tupleForwarder=new TupleForwarder<>(store,context,new ForwardingCacheFlushListener<K,V>(context),sendOldValues);
}
