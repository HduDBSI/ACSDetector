@Test public void testJsonSchemaMetadataTranslation(){
  JsonNode converted=parse(converter.fromConnectData(TOPIC,Schema.BOOLEAN_SCHEMA,true));
  validateEnvelope(converted);
  assertEquals(parse("{ \"type\": \"boolean\", \"optional\": false }"),converted.get(JsonSchema.ENVELOPE_SCHEMA_FIELD_NAME));
  assertEquals(true,converted.get(JsonSchema.ENVELOPE_PAYLOAD_FIELD_NAME).booleanValue());
  converted=parse(converter.fromConnectData(TOPIC,Schema.OPTIONAL_BOOLEAN_SCHEMA,null));
  validateEnvelope(converted);
  assertEquals(parse("{ \"type\": \"boolean\", \"optional\": true }"),converted.get(JsonSchema.ENVELOPE_SCHEMA_FIELD_NAME));
  assertTrue(converted.get(JsonSchema.ENVELOPE_PAYLOAD_FIELD_NAME).isNull());
  converted=parse(converter.fromConnectData(TOPIC,SchemaBuilder.bool().defaultValue(true).build(),true));
  validateEnvelope(converted);
  assertEquals(parse("{ \"type\": \"boolean\", \"optional\": false, \"default\": true }"),converted.get(JsonSchema.ENVELOPE_SCHEMA_FIELD_NAME));
  assertEquals(true,converted.get(JsonSchema.ENVELOPE_PAYLOAD_FIELD_NAME).booleanValue());
  converted=parse(converter.fromConnectData(TOPIC,SchemaBuilder.bool().required().name("bool").version(3).doc("the documentation").parameter("foo","bar").build(),true));
  validateEnvelope(converted);
  assertEquals(parse("{ \"type\": \"boolean\", \"optional\": false, \"name\": \"bool\", \"version\": 3, \"doc\": \"the documentation\", \"parameters\": { \"foo\": \"bar\" }}"),converted.get(JsonSchema.ENVELOPE_SCHEMA_FIELD_NAME));
  assertEquals(true,converted.get(JsonSchema.ENVELOPE_PAYLOAD_FIELD_NAME).booleanValue());
}
