public static void main(String[] args) throws Exception {
  Properties props=new Properties();
  props.put(StreamsConfig.APPLICATION_ID_CONFIG,"streams-pageview-typed");
  props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG,"localhost:9092");
  props.put(StreamsConfig.DEFAULT_TIMESTAMP_EXTRACTOR_CLASS_CONFIG,JsonTimestampExtractor.class);
  props.put(StreamsConfig.CACHE_MAX_BYTES_BUFFERING_CONFIG,0);
  props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,"earliest");
  StreamsBuilder builder=new StreamsBuilder();
  Map<String,Object> serdeProps=new HashMap<>();
  final Serializer<PageView> pageViewSerializer=new JsonPOJOSerializer<>();
  serdeProps.put("JsonPOJOClass",PageView.class);
  pageViewSerializer.configure(serdeProps,false);
  final Deserializer<PageView> pageViewDeserializer=new JsonPOJODeserializer<>();
  serdeProps.put("JsonPOJOClass",PageView.class);
  pageViewDeserializer.configure(serdeProps,false);
  final Serde<PageView> pageViewSerde=Serdes.serdeFrom(pageViewSerializer,pageViewDeserializer);
  final Serializer<UserProfile> userProfileSerializer=new JsonPOJOSerializer<>();
  serdeProps.put("JsonPOJOClass",UserProfile.class);
  userProfileSerializer.configure(serdeProps,false);
  final Deserializer<UserProfile> userProfileDeserializer=new JsonPOJODeserializer<>();
  serdeProps.put("JsonPOJOClass",UserProfile.class);
  userProfileDeserializer.configure(serdeProps,false);
  final Serde<UserProfile> userProfileSerde=Serdes.serdeFrom(userProfileSerializer,userProfileDeserializer);
  final Serializer<WindowedPageViewByRegion> wPageViewByRegionSerializer=new JsonPOJOSerializer<>();
  serdeProps.put("JsonPOJOClass",WindowedPageViewByRegion.class);
  wPageViewByRegionSerializer.configure(serdeProps,false);
  final Deserializer<WindowedPageViewByRegion> wPageViewByRegionDeserializer=new JsonPOJODeserializer<>();
  serdeProps.put("JsonPOJOClass",WindowedPageViewByRegion.class);
  wPageViewByRegionDeserializer.configure(serdeProps,false);
  final Serde<WindowedPageViewByRegion> wPageViewByRegionSerde=Serdes.serdeFrom(wPageViewByRegionSerializer,wPageViewByRegionDeserializer);
  final Serializer<RegionCount> regionCountSerializer=new JsonPOJOSerializer<>();
  serdeProps.put("JsonPOJOClass",RegionCount.class);
  regionCountSerializer.configure(serdeProps,false);
  final Deserializer<RegionCount> regionCountDeserializer=new JsonPOJODeserializer<>();
  serdeProps.put("JsonPOJOClass",RegionCount.class);
  regionCountDeserializer.configure(serdeProps,false);
  final Serde<RegionCount> regionCountSerde=Serdes.serdeFrom(regionCountSerializer,regionCountDeserializer);
  final Serializer<PageViewByRegion> pageViewByRegionSerializer=new JsonPOJOSerializer<>();
  serdeProps.put("JsonPOJOClass",PageViewByRegion.class);
  pageViewByRegionSerializer.configure(serdeProps,false);
  final Deserializer<PageViewByRegion> pageViewByRegionDeserializer=new JsonPOJODeserializer<>();
  serdeProps.put("JsonPOJOClass",PageViewByRegion.class);
  pageViewByRegionDeserializer.configure(serdeProps,false);
  final Serde<PageViewByRegion> pageViewByRegionSerde=Serdes.serdeFrom(pageViewByRegionSerializer,pageViewByRegionDeserializer);
  KStream<String,PageView> views=builder.stream("streams-pageview-input",Consumed.with(Serdes.String(),pageViewSerde));
  KTable<String,UserProfile> users=builder.table("streams-userprofile-input",Consumed.with(Serdes.String(),userProfileSerde));
  KStream<WindowedPageViewByRegion,RegionCount> regionCount=views.leftJoin(users,new ValueJoiner<PageView,UserProfile,PageViewByRegion>(){
    @Override public PageViewByRegion apply(    PageView view,    UserProfile profile){
      PageViewByRegion viewByRegion=new PageViewByRegion();
      viewByRegion.user=view.user;
      viewByRegion.page=view.page;
      if (profile != null) {
        viewByRegion.region=profile.region;
      }
 else {
        viewByRegion.region="UNKNOWN";
      }
      return viewByRegion;
    }
  }
).map(new KeyValueMapper<String,PageViewByRegion,KeyValue<String,PageViewByRegion>>(){
    @Override public KeyValue<String,PageViewByRegion> apply(    String user,    PageViewByRegion viewRegion){
      return new KeyValue<>(viewRegion.region,viewRegion);
    }
  }
).groupByKey(Serialized.with(Serdes.String(),pageViewByRegionSerde)).windowedBy(TimeWindows.of(TimeUnit.DAYS.toMillis(7)).advanceBy(TimeUnit.SECONDS.toMillis(1))).count().toStream().map(new KeyValueMapper<Windowed<String>,Long,KeyValue<WindowedPageViewByRegion,RegionCount>>(){
    @Override public KeyValue<WindowedPageViewByRegion,RegionCount> apply(    Windowed<String> key,    Long value){
      WindowedPageViewByRegion wViewByRegion=new WindowedPageViewByRegion();
      wViewByRegion.windowStart=key.window().start();
      wViewByRegion.region=key.key();
      RegionCount rCount=new RegionCount();
      rCount.region=key.key();
      rCount.count=value;
      return new KeyValue<>(wViewByRegion,rCount);
    }
  }
);
  regionCount.to("streams-pageviewstats-typed-output",Produced.with(wPageViewByRegionSerde,regionCountSerde));
  KafkaStreams streams=new KafkaStreams(builder.build(),props);
  streams.start();
  Thread.sleep(5000L);
  streams.close();
}
