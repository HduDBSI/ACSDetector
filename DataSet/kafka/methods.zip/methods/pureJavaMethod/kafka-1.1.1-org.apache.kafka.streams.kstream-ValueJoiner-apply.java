/** 
 * Return a joined value consisting of  {@code value1} and {@code value2}.
 * @param value1 the first value for joining
 * @param value2 the second value for joining
 * @return the joined value
 */
VR apply(final V1 value1,final V2 value2);
