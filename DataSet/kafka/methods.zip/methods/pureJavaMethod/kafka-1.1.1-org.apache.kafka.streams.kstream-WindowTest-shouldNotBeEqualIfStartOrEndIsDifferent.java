@Test public void shouldNotBeEqualIfStartOrEndIsDifferent(){
  assertNotEquals(window,new TestWindow(0,window.endMs));
  assertNotEquals(window,new TestWindow(7,window.endMs));
  assertNotEquals(window,new TestWindow(window.startMs,7));
  assertNotEquals(window,new TestWindow(window.startMs,15));
  assertNotEquals(window,new TestWindow(7,8));
  assertNotEquals(window,new TestWindow(0,15));
}
