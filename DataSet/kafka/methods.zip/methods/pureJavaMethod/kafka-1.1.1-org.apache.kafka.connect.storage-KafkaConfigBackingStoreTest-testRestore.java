@Test public void testRestore() throws Exception {
  expectConfigure();
  List<ConsumerRecord<String,byte[]>> existingRecords=Arrays.asList(new ConsumerRecord<>(TOPIC,0,0,0L,TimestampType.CREATE_TIME,0L,0,0,CONNECTOR_CONFIG_KEYS.get(0),CONFIGS_SERIALIZED.get(0)),new ConsumerRecord<>(TOPIC,0,1,0L,TimestampType.CREATE_TIME,0L,0,0,TASK_CONFIG_KEYS.get(0),CONFIGS_SERIALIZED.get(1)),new ConsumerRecord<>(TOPIC,0,2,0L,TimestampType.CREATE_TIME,0L,0,0,TASK_CONFIG_KEYS.get(1),CONFIGS_SERIALIZED.get(2)),new ConsumerRecord<>(TOPIC,0,3,0L,TimestampType.CREATE_TIME,0L,0,0,CONNECTOR_CONFIG_KEYS.get(0),CONFIGS_SERIALIZED.get(3)),new ConsumerRecord<>(TOPIC,0,4,0L,TimestampType.CREATE_TIME,0L,0,0,COMMIT_TASKS_CONFIG_KEYS.get(0),CONFIGS_SERIALIZED.get(4)),new ConsumerRecord<>(TOPIC,0,5,0L,TimestampType.CREATE_TIME,0L,0,0,CONNECTOR_CONFIG_KEYS.get(0),CONFIGS_SERIALIZED.get(5)),new ConsumerRecord<>(TOPIC,0,6,0L,TimestampType.CREATE_TIME,0L,0,0,TASK_CONFIG_KEYS.get(0),CONFIGS_SERIALIZED.get(6)));
  LinkedHashMap<byte[],Struct> deserialized=new LinkedHashMap<>();
  deserialized.put(CONFIGS_SERIALIZED.get(0),CONNECTOR_CONFIG_STRUCTS.get(0));
  deserialized.put(CONFIGS_SERIALIZED.get(1),TASK_CONFIG_STRUCTS.get(0));
  deserialized.put(CONFIGS_SERIALIZED.get(2),TASK_CONFIG_STRUCTS.get(0));
  deserialized.put(CONFIGS_SERIALIZED.get(3),CONNECTOR_CONFIG_STRUCTS.get(1));
  deserialized.put(CONFIGS_SERIALIZED.get(4),TASKS_COMMIT_STRUCT_TWO_TASK_CONNECTOR);
  deserialized.put(CONFIGS_SERIALIZED.get(5),CONNECTOR_CONFIG_STRUCTS.get(2));
  deserialized.put(CONFIGS_SERIALIZED.get(6),TASK_CONFIG_STRUCTS.get(1));
  logOffset=7;
  expectStart(existingRecords,deserialized);
  expectStop();
  PowerMock.replayAll();
  configStorage.setupAndCreateKafkaBasedLog(TOPIC,DEFAULT_DISTRIBUTED_CONFIG);
  configStorage.start();
  ClusterConfigState configState=configStorage.snapshot();
  assertEquals(7,configState.offset());
  assertEquals(Arrays.asList(CONNECTOR_IDS.get(0)),new ArrayList<>(configState.connectors()));
  assertEquals(TargetState.STARTED,configState.targetState(CONNECTOR_IDS.get(0)));
  assertEquals(SAMPLE_CONFIGS.get(2),configState.connectorConfig(CONNECTOR_IDS.get(0)));
  assertEquals(Arrays.asList(TASK_IDS.get(0),TASK_IDS.get(1)),configState.tasks(CONNECTOR_IDS.get(0)));
  assertEquals(SAMPLE_CONFIGS.get(0),configState.taskConfig(TASK_IDS.get(0)));
  assertEquals(SAMPLE_CONFIGS.get(0),configState.taskConfig(TASK_IDS.get(1)));
  assertEquals(Collections.EMPTY_SET,configState.inconsistentConnectors());
  configStorage.stop();
  PowerMock.verifyAll();
}
