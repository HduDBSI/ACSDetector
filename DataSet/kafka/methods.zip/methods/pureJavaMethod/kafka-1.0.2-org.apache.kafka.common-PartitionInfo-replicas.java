/** 
 * The complete set of replicas for this partition regardless of whether they are alive or up-to-date
 */
public Node[] replicas(){
  return replicas;
}
