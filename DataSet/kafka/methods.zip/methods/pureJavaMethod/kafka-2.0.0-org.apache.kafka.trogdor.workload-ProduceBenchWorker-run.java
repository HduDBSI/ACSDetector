@Override public void run(){
  try {
    update();
  }
 catch (  Exception e) {
    WorkerUtils.abort(log,"StatusUpdater",e,doneFuture);
  }
}
