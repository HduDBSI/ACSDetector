@Test public void testOneConsumerNonexistentTopic(){
  String topic="topic";
  String consumerId="consumer";
  Map<String,Integer> partitionsPerTopic=new HashMap<>();
  Map<String,List<TopicPartition>> assignment=assignor.assign(partitionsPerTopic,Collections.singletonMap(consumerId,new Subscription(topics(topic))));
  assertEquals(Collections.singleton(consumerId),assignment.keySet());
  assertTrue(assignment.get(consumerId).isEmpty());
}
