@Test public void testAbs(){
  assertEquals(0,Utils.abs(Integer.MIN_VALUE));
  assertEquals(10,Utils.abs(-10));
  assertEquals(10,Utils.abs(10));
  assertEquals(0,Utils.abs(0));
  assertEquals(1,Utils.abs(-1));
}
