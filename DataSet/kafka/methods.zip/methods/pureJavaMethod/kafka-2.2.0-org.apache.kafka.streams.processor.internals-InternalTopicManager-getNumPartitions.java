/** 
 * Try to get the number of partitions for the given topics; return the number of partitions for topics that already exists. Topics that were not able to get its description will simply not be returned
 */
protected Map<String,Integer> getNumPartitions(final Set<String> topics){
  log.debug("Trying to check if topics {} have been created with expected number of partitions.",topics);
  final DescribeTopicsResult describeTopicsResult=adminClient.describeTopics(topics);
  final Map<String,KafkaFuture<TopicDescription>> futures=describeTopicsResult.values();
  final Map<String,Integer> existedTopicPartition=new HashMap<>();
  for (  final Map.Entry<String,KafkaFuture<TopicDescription>> topicFuture : futures.entrySet()) {
    final String topicName=topicFuture.getKey();
    try {
      final TopicDescription topicDescription=topicFuture.getValue().get();
      existedTopicPartition.put(topicFuture.getKey(),topicDescription.partitions().size());
    }
 catch (    final InterruptedException fatalException) {
      Thread.currentThread().interrupt();
      log.error(INTERRUPTED_ERROR_MESSAGE,fatalException);
      throw new IllegalStateException(INTERRUPTED_ERROR_MESSAGE,fatalException);
    }
catch (    final ExecutionException couldNotDescribeTopicException) {
      final Throwable cause=couldNotDescribeTopicException.getCause();
      if (cause instanceof UnknownTopicOrPartitionException || cause instanceof LeaderNotAvailableException) {
        log.debug("Topic {} is unknown or not found, hence not existed yet.",topicName);
      }
 else {
        log.error("Unexpected error during topic description for {}.\n" + "Error message was: {}",topicName,cause.toString());
        throw new StreamsException(String.format("Could not create topic %s.",topicName),cause);
      }
    }
  }
  return existedTopicPartition;
}
