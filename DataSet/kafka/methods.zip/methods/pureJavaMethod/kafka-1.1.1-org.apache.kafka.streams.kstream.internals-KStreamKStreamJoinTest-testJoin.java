@Test public void testJoin(){
  StreamsBuilder builder=new StreamsBuilder();
  final int[] expectedKeys=new int[]{0,1,2,3};
  KStream<Integer,String> stream1;
  KStream<Integer,String> stream2;
  KStream<Integer,String> joined;
  MockProcessorSupplier<Integer,String> processor;
  processor=new MockProcessorSupplier<>();
  stream1=builder.stream(topic1,consumed);
  stream2=builder.stream(topic2,consumed);
  joined=stream1.join(stream2,MockValueJoiner.TOSTRING_JOINER,JoinWindows.of(100),Joined.with(intSerde,stringSerde,stringSerde));
  joined.process(processor);
  Collection<Set<String>> copartitionGroups=StreamsBuilderTest.getCopartitionedGroups(builder);
  assertEquals(1,copartitionGroups.size());
  assertEquals(new HashSet<>(Arrays.asList(topic1,topic2)),copartitionGroups.iterator().next());
  driver.setUp(builder,stateDir);
  driver.setTime(0L);
  for (int i=0; i < 2; i++) {
    driver.process(topic1,expectedKeys[i],"X" + expectedKeys[i]);
  }
  processor.checkAndClearProcessResult();
  for (int i=0; i < 2; i++) {
    driver.process(topic2,expectedKeys[i],"Y" + expectedKeys[i]);
  }
  processor.checkAndClearProcessResult("0:X0+Y0","1:X1+Y1");
  for (  int expectedKey : expectedKeys) {
    driver.process(topic1,expectedKey,"X" + expectedKey);
  }
  processor.checkAndClearProcessResult("0:X0+Y0","1:X1+Y1");
  for (  int expectedKey : expectedKeys) {
    driver.process(topic2,expectedKey,"YY" + expectedKey);
  }
  processor.checkAndClearProcessResult("0:X0+YY0","0:X0+YY0","1:X1+YY1","1:X1+YY1","2:X2+YY2","3:X3+YY3");
  for (  int expectedKey : expectedKeys) {
    driver.process(topic1,expectedKey,"XX" + expectedKey);
  }
  processor.checkAndClearProcessResult("0:XX0+Y0","0:XX0+YY0","1:XX1+Y1","1:XX1+YY1","2:XX2+YY2","3:XX3+YY3");
  for (int i=0; i < 2; i++) {
    driver.process(topic2,expectedKeys[i],"YYY" + expectedKeys[i]);
  }
  processor.checkAndClearProcessResult("0:X0+YYY0","0:X0+YYY0","0:XX0+YYY0","1:X1+YYY1","1:X1+YYY1","1:XX1+YYY1");
}
