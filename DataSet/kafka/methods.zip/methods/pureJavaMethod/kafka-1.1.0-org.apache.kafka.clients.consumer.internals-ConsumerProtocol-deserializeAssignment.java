public static PartitionAssignor.Assignment deserializeAssignment(ByteBuffer buffer){
  Struct header=CONSUMER_PROTOCOL_HEADER_SCHEMA.read(buffer);
  Short version=header.getShort(VERSION_KEY_NAME);
  checkVersionCompatibility(version);
  Struct struct=ASSIGNMENT_V0.read(buffer);
  ByteBuffer userData=struct.getBytes(USER_DATA_KEY_NAME);
  List<TopicPartition> partitions=new ArrayList<>();
  for (  Object structObj : struct.getArray(TOPIC_PARTITIONS_KEY_NAME)) {
    Struct assignment=(Struct)structObj;
    String topic=assignment.getString(TOPIC_KEY_NAME);
    for (    Object partitionObj : assignment.getArray(PARTITIONS_KEY_NAME)) {
      Integer partition=(Integer)partitionObj;
      partitions.add(new TopicPartition(topic,partition));
    }
  }
  return new PartitionAssignor.Assignment(partitions,userData);
}
