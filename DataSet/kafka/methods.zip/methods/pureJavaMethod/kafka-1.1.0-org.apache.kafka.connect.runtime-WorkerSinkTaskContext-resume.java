@Override public void resume(TopicPartition... partitions){
  if (consumer == null) {
    throw new IllegalWorkerStateException("SinkTaskContext may not be used to resume consumption until the task is initialized");
  }
  try {
    pausedPartitions.removeAll(Arrays.asList(partitions));
    if (sinkTask.shouldPause()) {
      log.debug("{} Connector is paused, so not resuming consumer's partitions {}",this,partitions);
    }
 else {
      consumer.resume(Arrays.asList(partitions));
      log.debug("{} Resuming partitions: {}",this,partitions);
    }
  }
 catch (  IllegalStateException e) {
    throw new IllegalWorkerStateException("SinkTasks may not resume partitions that are not currently assigned to them.",e);
  }
}
