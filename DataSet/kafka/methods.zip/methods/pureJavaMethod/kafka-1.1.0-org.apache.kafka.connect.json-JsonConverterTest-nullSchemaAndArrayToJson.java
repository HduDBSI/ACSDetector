@Test public void nullSchemaAndArrayToJson(){
  JsonNode converted=parse(converter.fromConnectData(TOPIC,null,Arrays.asList(1,"string",true)));
  validateEnvelopeNullSchema(converted);
  assertTrue(converted.get(JsonSchema.ENVELOPE_SCHEMA_FIELD_NAME).isNull());
  assertEquals(JsonNodeFactory.instance.arrayNode().add(1).add("string").add(true),converted.get(JsonSchema.ENVELOPE_PAYLOAD_FIELD_NAME));
}
