private static Set<TopicPartition> readTopicPartitions(DataInputStream in) throws IOException {
  int numPartitions=in.readInt();
  Set<TopicPartition> partitions=new HashSet<>(numPartitions);
  for (int j=0; j < numPartitions; j++) {
    partitions.add(new TopicPartition(in.readUTF(),in.readInt()));
  }
  return partitions;
}
