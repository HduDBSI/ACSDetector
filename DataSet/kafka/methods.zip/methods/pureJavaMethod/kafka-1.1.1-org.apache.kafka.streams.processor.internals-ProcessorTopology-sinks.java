public Set<SinkNode> sinks(){
  return new HashSet<>(sinksByTopic.values());
}
