public abstract void handle(R response,RequestFuture<T> future);
