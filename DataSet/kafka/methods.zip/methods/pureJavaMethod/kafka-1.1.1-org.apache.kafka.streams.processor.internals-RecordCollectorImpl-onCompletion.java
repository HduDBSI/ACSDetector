@Override public void onCompletion(final RecordMetadata metadata,final Exception exception){
  if (exception == null) {
    if (sendException != null) {
      return;
    }
    final TopicPartition tp=new TopicPartition(metadata.topic(),metadata.partition());
    offsets.put(tp,metadata.offset());
  }
 else {
    if (sendException == null) {
      if (exception instanceof ProducerFencedException) {
        log.warn(LOG_MESSAGE,key,value,timestamp,topic,exception.getMessage());
        sendException=new ProducerFencedException(String.format(EXCEPTION_MESSAGE,logPrefix,"producer got fenced",key,value,timestamp,topic,exception.getMessage()));
      }
 else {
        if (productionExceptionIsFatal(exception)) {
          recordSendError(key,value,timestamp,topic,exception);
        }
 else         if (productionExceptionHandler.handle(serializedRecord,exception) == ProductionExceptionHandlerResponse.FAIL) {
          recordSendError(key,value,timestamp,topic,exception);
        }
 else {
          log.debug(HANDLER_CONTINUED_MESSAGE,key,value,timestamp,topic,exception);
        }
      }
    }
  }
}
