@Override public double combine(List<Sample> samples,MetricConfig config,long now){
  double max=Double.NEGATIVE_INFINITY;
  for (  Sample sample : samples)   max=Math.max(max,sample.value);
  return max;
}
