/** 
 * Get the schema for this Struct.
 * @return the Struct's schema
 */
public Schema schema(){
  return schema;
}
