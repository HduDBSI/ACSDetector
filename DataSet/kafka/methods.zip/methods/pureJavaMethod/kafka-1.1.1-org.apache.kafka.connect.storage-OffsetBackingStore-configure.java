/** 
 * Configure class with the given key-value pairs
 * @param config can be DistributedConfig or StandaloneConfig
 */
void configure(WorkerConfig config);
