@Test public void shouldThrowOnCleanupWhileRunning() throws InterruptedException {
  globalStreams.start();
  TestUtils.waitForCondition(() -> globalStreams.state() == KafkaStreams.State.RUNNING,"Streams never started.");
  try {
    globalStreams.cleanUp();
    fail("Should have thrown IllegalStateException");
  }
 catch (  final IllegalStateException expected) {
    assertEquals("Cannot clean up while running.",expected.getMessage());
  }
}
