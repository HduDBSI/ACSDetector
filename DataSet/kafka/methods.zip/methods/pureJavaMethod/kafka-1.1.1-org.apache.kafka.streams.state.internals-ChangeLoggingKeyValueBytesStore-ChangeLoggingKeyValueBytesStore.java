ChangeLoggingKeyValueBytesStore(final KeyValueStore<Bytes,byte[]> inner){
  super(inner);
  this.inner=inner;
}
