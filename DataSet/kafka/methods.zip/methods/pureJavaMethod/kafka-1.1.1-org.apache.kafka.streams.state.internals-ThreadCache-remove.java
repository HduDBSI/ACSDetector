@Override public void remove(){
  throw new UnsupportedOperationException("remove not supported by MemoryLRUCacheBytesIterator");
}
