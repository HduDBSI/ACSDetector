public static ListOffsetRequest parse(ByteBuffer buffer,short version){
  return new ListOffsetRequest(ApiKeys.LIST_OFFSETS.parseRequest(version,buffer),version);
}
