@Test public void testValidateConfigWithAlias() throws Throwable {
  herder.validateConnectorConfig(EasyMock.eq(props));
  PowerMock.expectLastCall().andAnswer(new IAnswer<ConfigInfos>(){
    @Override public ConfigInfos answer(){
      ConfigDef connectorConfigDef=ConnectorConfig.configDef();
      List<ConfigValue> connectorConfigValues=connectorConfigDef.validate(props);
      Connector connector=new ConnectorPluginsResourceTestConnector();
      Config config=connector.validate(props);
      ConfigDef configDef=connector.config();
      Map<String,ConfigDef.ConfigKey> configKeys=configDef.configKeys();
      List<ConfigValue> configValues=config.configValues();
      Map<String,ConfigDef.ConfigKey> resultConfigKeys=new HashMap<>(configKeys);
      resultConfigKeys.putAll(connectorConfigDef.configKeys());
      configValues.addAll(connectorConfigValues);
      return AbstractHerder.generateResult(ConnectorPluginsResourceTestConnector.class.getName(),resultConfigKeys,configValues,Collections.singletonList("Test"));
    }
  }
);
  PowerMock.replayAll();
  ConfigInfos configInfos=connectorPluginsResource.validateConfigs("ConnectorPluginsResourceTest",props);
  assertEquals(CONFIG_INFOS.name(),configInfos.name());
  assertEquals(0,configInfos.errorCount());
  assertEquals(CONFIG_INFOS.groups(),configInfos.groups());
  assertEquals(new HashSet<>(CONFIG_INFOS.values()),new HashSet<>(configInfos.values()));
  PowerMock.verifyAll();
}
