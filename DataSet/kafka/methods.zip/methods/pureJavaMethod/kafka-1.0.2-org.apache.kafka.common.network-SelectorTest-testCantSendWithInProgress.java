/** 
 * Sending a request with one already in flight should result in an exception
 */
@Test public void testCantSendWithInProgress() throws Exception {
  String node="0";
  blockingConnect(node);
  selector.send(createSend(node,"test1"));
  try {
    selector.send(createSend(node,"test2"));
    fail("IllegalStateException not thrown when sending a request with one in flight");
  }
 catch (  IllegalStateException e) {
  }
  selector.poll(0);
  assertTrue("Channel not closed",selector.disconnected().containsKey(node));
  assertEquals(ChannelState.FAILED_SEND,selector.disconnected().get(node));
}
