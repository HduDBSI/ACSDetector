@Test public void testAssignOnEmptyTopicPartition(){
  try (KafkaConsumer<byte[],byte[]> consumer=newConsumer()){
    consumer.assign(Collections.<TopicPartition>emptyList());
    assertTrue(consumer.subscription().isEmpty());
    assertTrue(consumer.assignment().isEmpty());
  }
 }
