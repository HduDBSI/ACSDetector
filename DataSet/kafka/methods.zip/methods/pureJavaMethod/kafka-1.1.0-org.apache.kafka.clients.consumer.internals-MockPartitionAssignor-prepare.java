public void prepare(Map<String,List<TopicPartition>> result){
  this.result=result;
}
