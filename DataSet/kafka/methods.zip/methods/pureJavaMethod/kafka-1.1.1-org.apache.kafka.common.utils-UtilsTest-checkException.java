static void checkException(IOException e,TestCloseable... closeablesWithException){
  assertEquals(closeablesWithException[0].closeException,e);
  Throwable[] suppressed=e.getSuppressed();
  assertEquals(closeablesWithException.length - 1,suppressed.length);
  for (int i=1; i < closeablesWithException.length; i++)   assertEquals(closeablesWithException[i].closeException,suppressed[i - 1]);
}
