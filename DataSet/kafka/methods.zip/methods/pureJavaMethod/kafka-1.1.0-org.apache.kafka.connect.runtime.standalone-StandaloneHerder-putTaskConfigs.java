@Override public void putTaskConfigs(String connName,List<Map<String,String>> configs,Callback<Void> callback){
  throw new UnsupportedOperationException("Kafka Connect in standalone mode does not support externally setting task configurations.");
}
