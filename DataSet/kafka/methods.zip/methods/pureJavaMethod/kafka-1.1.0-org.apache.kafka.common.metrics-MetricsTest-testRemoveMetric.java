@Test public void testRemoveMetric(){
  int size=metrics.metrics().size();
  metrics.addMetric(metrics.metricName("test1","grp1"),new Count());
  metrics.addMetric(metrics.metricName("test2","grp1"),new Count());
  assertNotNull(metrics.removeMetric(metrics.metricName("test1","grp1")));
  assertNull(metrics.metrics().get(metrics.metricName("test1","grp1")));
  assertNotNull(metrics.metrics().get(metrics.metricName("test2","grp1")));
  assertNotNull(metrics.removeMetric(metrics.metricName("test2","grp1")));
  assertNull(metrics.metrics().get(metrics.metricName("test2","grp1")));
  assertEquals(size,metrics.metrics().size());
}
