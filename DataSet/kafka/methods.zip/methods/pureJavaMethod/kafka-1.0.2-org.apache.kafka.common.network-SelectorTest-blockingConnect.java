protected void blockingConnect(String node,InetSocketAddress serverAddr) throws IOException {
  selector.connect(node,serverAddr,BUFFER_SIZE,BUFFER_SIZE);
  while (!selector.connected().contains(node))   selector.poll(10000L);
  while (!selector.isChannelReady(node))   selector.poll(10000L);
}
