/** 
 * Get or create the directory for the global stores.
 * @return directory for the global stores
 * @throws ProcessorStateException if the global store directory does not exists and could not be created
 */
File globalStateDir(){
  final File dir=new File(stateDir,"global");
  if (!dir.exists() && !dir.mkdir()) {
    throw new ProcessorStateException(String.format("global state directory [%s] doesn't exist and couldn't be created",dir.getPath()));
  }
  return dir;
}
