@Before public void before(){
  stubProviderOne=new StateStoreProviderStub(false);
  stubProviderTwo=new StateStoreProviderStub(false);
  underlyingWindowStore=new ReadOnlyWindowStoreStub<>(WINDOW_SIZE);
  stubProviderOne.addStore(storeName,underlyingWindowStore);
  otherUnderlyingStore=new ReadOnlyWindowStoreStub<>(WINDOW_SIZE);
  stubProviderOne.addStore("other-window-store",otherUnderlyingStore);
  windowStore=new CompositeReadOnlyWindowStore<>(new WrappingStoreProvider(Arrays.<StateStoreProvider>asList(stubProviderOne,stubProviderTwo)),QueryableStoreTypes.<String,String>windowStore(),storeName);
}
