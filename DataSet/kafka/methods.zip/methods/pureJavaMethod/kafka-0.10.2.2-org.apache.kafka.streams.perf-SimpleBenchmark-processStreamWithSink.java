public void processStreamWithSink(String topic) throws Exception {
  if (maybeSetupPhase(topic,"simple-benchmark-process-stream-with-sink-load",true)) {
    return;
  }
  CountDownLatch latch=new CountDownLatch(1);
  final KafkaStreams streams=createKafkaStreamsWithSink(topic,latch);
  long latency=startStreamsThread(streams,latch);
  printResults("Streams Performance [records/latency/rec-sec/MB-sec source+sink]: ",latency);
}
