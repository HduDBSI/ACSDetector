/** 
 * Create a linear bin scheme with the specified number of bins and the maximum value to be counted in the bins.
 * @param numBins the number of bins; must be at least 2
 * @param max the maximum value to be counted in the bins
 */
public LinearBinScheme(int numBins,double max){
  if (numBins < 2)   throw new IllegalArgumentException("Must have at least 2 bins.");
  this.bins=numBins;
  this.max=max;
  double denom=numBins * (numBins - 1.0) / 2.0;
  this.scale=max / denom;
}
