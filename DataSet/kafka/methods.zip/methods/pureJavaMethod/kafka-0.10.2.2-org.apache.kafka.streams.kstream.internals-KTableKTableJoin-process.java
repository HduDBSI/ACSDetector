@Override public void process(final K key,final Change<V1> change){
  if (key == null) {
    return;
  }
  R newValue=null;
  R oldValue=null;
  final V2 value2=valueGetter.get(key);
  if (value2 == null) {
    return;
  }
  if (change.newValue != null) {
    newValue=joiner.apply(change.newValue,value2);
  }
  if (sendOldValues && change.oldValue != null) {
    oldValue=joiner.apply(change.oldValue,value2);
  }
  context().forward(key,new Change<>(newValue,oldValue));
}
