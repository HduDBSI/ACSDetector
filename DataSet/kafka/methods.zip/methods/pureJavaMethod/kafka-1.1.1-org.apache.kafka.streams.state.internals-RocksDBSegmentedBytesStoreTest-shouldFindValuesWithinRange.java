@Test public void shouldFindValuesWithinRange(){
  final String key="a";
  bytesStore.put(serializeKey(new Windowed<>(key,new SessionWindow(0L,0L))),serializeValue(50L));
  bytesStore.put(serializeKey(new Windowed<>(key,new SessionWindow(1000L,1000L))),serializeValue(10L));
  final KeyValueIterator<Bytes,byte[]> results=bytesStore.fetch(Bytes.wrap(key.getBytes()),1L,1999L);
  assertEquals(Collections.singletonList(KeyValue.pair(new Windowed<>(key,new SessionWindow(1000L,1000L)),10L)),toList(results));
}
