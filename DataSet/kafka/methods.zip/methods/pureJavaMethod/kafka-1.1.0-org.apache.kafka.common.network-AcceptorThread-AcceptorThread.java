public AcceptorThread() throws IOException {
  setName("acceptor");
}
