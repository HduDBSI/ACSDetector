@Test public void shouldSupportPrefixedPropertiesThatAreNotPartOfConsumerConfig(){
  final StreamsConfig streamsConfig=new StreamsConfig(props);
  props.put(consumerPrefix("interceptor.statsd.host"),"host");
  final Map<String,Object> consumerConfigs=streamsConfig.getConsumerConfigs("groupId","clientId");
  assertEquals("host",consumerConfigs.get("interceptor.statsd.host"));
}
