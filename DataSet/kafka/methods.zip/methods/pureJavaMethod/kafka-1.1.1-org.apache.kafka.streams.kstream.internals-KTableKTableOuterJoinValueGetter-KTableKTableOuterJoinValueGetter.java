KTableKTableOuterJoinValueGetter(KTableValueGetter<K,V1> valueGetter1,KTableValueGetter<K,V2> valueGetter2){
  this.valueGetter1=valueGetter1;
  this.valueGetter2=valueGetter2;
}
