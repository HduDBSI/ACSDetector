/** 
 * Tests that ApiVersionsRequest after Kafka SASL handshake request flow, but prior to actual SASL authentication, results in authentication failure. This is similar to  {@link #testUnauthenticatedApiVersionsRequest(SecurityProtocol,short)}where a non-SASL client is used to send requests that are processed by {@link SaslServerAuthenticator} of the server prior to client authentication.
 */
@Test public void testInvalidApiVersionsRequestSequence() throws Exception {
  SecurityProtocol securityProtocol=SecurityProtocol.SASL_PLAINTEXT;
  configureMechanisms("PLAIN",Arrays.asList("PLAIN"));
  server=createEchoServer(securityProtocol);
  String node1="invalid1";
  createClientConnection(SecurityProtocol.PLAINTEXT,node1);
  sendHandshakeRequestReceiveResponse(node1,(short)1);
  ApiVersionsRequest request=createApiVersionsRequestV0();
  RequestHeader versionsHeader=new RequestHeader(ApiKeys.API_VERSIONS,request.version(),"someclient",2);
  selector.send(request.toSend(node1,versionsHeader));
  NetworkTestUtils.waitForChannelClose(selector,node1,ChannelState.READY.state());
  selector.close();
  createAndCheckClientConnection(securityProtocol,"good1");
}
