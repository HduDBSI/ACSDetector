@Test public void testCloseNoWait() throws Exception {
  ConsumerCoordinator coordinator=prepareCoordinatorForCloseTest(true,true,true);
  time.sleep(autoCommitIntervalMs);
  closeVerifyTimeout(coordinator,0,0,0);
}
