@Override public void process(K key,V value){
  if (key == null)   return;
  T oldAgg=store.get(key);
  if (oldAgg == null)   oldAgg=initializer.apply();
  T newAgg=oldAgg;
  if (value != null) {
    newAgg=aggregator.apply(key,value,newAgg);
  }
  store.put(key,newAgg);
  tupleForwarder.maybeForward(key,newAgg,oldAgg);
}
