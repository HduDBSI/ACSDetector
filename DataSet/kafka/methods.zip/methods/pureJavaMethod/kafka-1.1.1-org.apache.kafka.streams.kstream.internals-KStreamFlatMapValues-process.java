@Override public void process(K key,V value){
  final Iterable<? extends V1> newValues=mapper.apply(key,value);
  for (  V1 v : newValues) {
    context().forward(key,v);
  }
}
