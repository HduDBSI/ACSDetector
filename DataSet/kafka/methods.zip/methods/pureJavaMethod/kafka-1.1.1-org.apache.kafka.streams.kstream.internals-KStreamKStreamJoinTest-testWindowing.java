@Test public void testWindowing(){
  long time=0L;
  StreamsBuilder builder=new StreamsBuilder();
  final int[] expectedKeys=new int[]{0,1,2,3};
  KStream<Integer,String> stream1;
  KStream<Integer,String> stream2;
  KStream<Integer,String> joined;
  MockProcessorSupplier<Integer,String> processor;
  processor=new MockProcessorSupplier<>();
  stream1=builder.stream(topic1,consumed);
  stream2=builder.stream(topic2,consumed);
  joined=stream1.join(stream2,MockValueJoiner.TOSTRING_JOINER,JoinWindows.of(100),Joined.with(intSerde,stringSerde,stringSerde));
  joined.process(processor);
  Collection<Set<String>> copartitionGroups=StreamsBuilderTest.getCopartitionedGroups(builder);
  assertEquals(1,copartitionGroups.size());
  assertEquals(new HashSet<>(Arrays.asList(topic1,topic2)),copartitionGroups.iterator().next());
  driver.setUp(builder,stateDir);
  setRecordContext(time,topic1);
  for (int i=0; i < 2; i++) {
    driver.process(topic1,expectedKeys[i],"X" + expectedKeys[i]);
  }
  processor.checkAndClearProcessResult();
  setRecordContext(time,topic2);
  for (int i=0; i < 2; i++) {
    driver.process(topic2,expectedKeys[i],"Y" + expectedKeys[i]);
  }
  processor.checkAndClearProcessResult("0:X0+Y0","1:X1+Y1");
  time=1000L;
  setRecordContext(time,topic1);
  for (int i=0; i < expectedKeys.length; i++) {
    setRecordContext(time + i,topic1);
    driver.process(topic1,expectedKeys[i],"X" + expectedKeys[i]);
  }
  processor.checkAndClearProcessResult();
  time=1000 + 100L;
  setRecordContext(time,topic2);
  for (  int expectedKey : expectedKeys) {
    driver.process(topic2,expectedKey,"YY" + expectedKey);
  }
  processor.checkAndClearProcessResult("0:X0+YY0","1:X1+YY1","2:X2+YY2","3:X3+YY3");
  setRecordContext(++time,topic2);
  for (  int expectedKey : expectedKeys) {
    driver.process(topic2,expectedKey,"YY" + expectedKey);
  }
  processor.checkAndClearProcessResult("1:X1+YY1","2:X2+YY2","3:X3+YY3");
  setRecordContext(++time,topic2);
  for (  int expectedKey : expectedKeys) {
    driver.process(topic2,expectedKey,"YY" + expectedKey);
  }
  processor.checkAndClearProcessResult("2:X2+YY2","3:X3+YY3");
  setRecordContext(++time,topic2);
  for (  int expectedKey : expectedKeys) {
    driver.process(topic2,expectedKey,"YY" + expectedKey);
  }
  processor.checkAndClearProcessResult("3:X3+YY3");
  setRecordContext(++time,topic2);
  for (  int expectedKey : expectedKeys) {
    driver.process(topic2,expectedKey,"YY" + expectedKey);
  }
  processor.checkAndClearProcessResult();
  time=1000L - 100L - 1L;
  setRecordContext(time,topic2);
  for (  int expectedKey : expectedKeys) {
    driver.process(topic2,expectedKey,"YY" + expectedKey);
  }
  processor.checkAndClearProcessResult();
  setRecordContext(++time,topic2);
  for (  int expectedKey : expectedKeys) {
    driver.process(topic2,expectedKey,"YY" + expectedKey);
  }
  processor.checkAndClearProcessResult("0:X0+YY0");
  setRecordContext(++time,topic2);
  for (  int expectedKey : expectedKeys) {
    driver.process(topic2,expectedKey,"YY" + expectedKey);
  }
  processor.checkAndClearProcessResult("0:X0+YY0","1:X1+YY1");
  setRecordContext(++time,topic2);
  for (  int expectedKey : expectedKeys) {
    driver.process(topic2,expectedKey,"YY" + expectedKey);
  }
  processor.checkAndClearProcessResult("0:X0+YY0","1:X1+YY1","2:X2+YY2");
  setRecordContext(++time,topic2);
  for (  int expectedKey : expectedKeys) {
    driver.process(topic2,expectedKey,"YY" + expectedKey);
  }
  processor.checkAndClearProcessResult("0:X0+YY0","1:X1+YY1","2:X2+YY2","3:X3+YY3");
  time=2000L;
  for (int i=0; i < expectedKeys.length; i++) {
    setRecordContext(time + i,topic2);
    driver.process(topic2,expectedKeys[i],"Y" + expectedKeys[i]);
  }
  processor.checkAndClearProcessResult();
  time=2000L + 100L;
  setRecordContext(time,topic1);
  for (  int expectedKey : expectedKeys) {
    driver.process(topic1,expectedKey,"XX" + expectedKey);
  }
  processor.checkAndClearProcessResult("0:XX0+Y0","1:XX1+Y1","2:XX2+Y2","3:XX3+Y3");
  setRecordContext(++time,topic1);
  for (  int expectedKey : expectedKeys) {
    driver.process(topic1,expectedKey,"XX" + expectedKey);
  }
  processor.checkAndClearProcessResult("1:XX1+Y1","2:XX2+Y2","3:XX3+Y3");
  setRecordContext(++time,topic1);
  for (  int expectedKey : expectedKeys) {
    driver.process(topic1,expectedKey,"XX" + expectedKey);
  }
  processor.checkAndClearProcessResult("2:XX2+Y2","3:XX3+Y3");
  setRecordContext(++time,topic1);
  for (  int expectedKey : expectedKeys) {
    driver.process(topic1,expectedKey,"XX" + expectedKey);
  }
  processor.checkAndClearProcessResult("3:XX3+Y3");
  setRecordContext(++time,topic1);
  for (  int expectedKey : expectedKeys) {
    driver.process(topic1,expectedKey,"XX" + expectedKey);
  }
  processor.checkAndClearProcessResult();
  time=2000L - 100L - 1L;
  setRecordContext(time,topic1);
  for (  int expectedKey : expectedKeys) {
    driver.process(topic1,expectedKey,"XX" + expectedKey);
  }
  processor.checkAndClearProcessResult();
  setRecordContext(++time,topic1);
  for (  int expectedKey : expectedKeys) {
    driver.process(topic1,expectedKey,"XX" + expectedKey);
  }
  processor.checkAndClearProcessResult("0:XX0+Y0");
  setRecordContext(++time,topic1);
  for (  int expectedKey : expectedKeys) {
    driver.process(topic1,expectedKey,"XX" + expectedKey);
  }
  processor.checkAndClearProcessResult("0:XX0+Y0","1:XX1+Y1");
  setRecordContext(++time,topic1);
  for (  int expectedKey : expectedKeys) {
    driver.process(topic1,expectedKey,"XX" + expectedKey);
  }
  processor.checkAndClearProcessResult("0:XX0+Y0","1:XX1+Y1","2:XX2+Y2");
  setRecordContext(++time,topic1);
  for (  int expectedKey : expectedKeys) {
    driver.process(topic1,expectedKey,"XX" + expectedKey);
  }
  processor.checkAndClearProcessResult("0:XX0+Y0","1:XX1+Y1","2:XX2+Y2","3:XX3+Y3");
}
