/** 
 * Tests that Kafka ApiVersionsRequests are handled by the SASL server authenticator prior to SASL handshake flow and that subsequent authentication succeeds when transport layer is PLAINTEXT/SSL. This test uses a non-SASL client that simulates SASL authentication after ApiVersionsRequest. <p> Test sequence (using <tt>securityProtocol=PLAINTEXT</tt> as an example): <ol> <li>Starts a SASL_PLAINTEXT test server that simply echoes back client requests after authentication.</li> <li>A (non-SASL) PLAINTEXT test client connects to the SASL server port. Client is now unauthenticated.<./li> <li>The unauthenticated non-SASL client sends an ApiVersionsRequest and validates the response. A valid response indicates that  {@link SaslServerAuthenticator} of the test server responded tothe ApiVersionsRequest even though the client is not yet authenticated.</li> <li>The unauthenticated non-SASL client sends a SaslHandshakeRequest and validates the response. A valid response indicates that  {@link SaslServerAuthenticator} of the test server responded to the SaslHandshakeRequestafter processing ApiVersionsRequest.</li> <li>The unauthenticated non-SASL client sends the SASL/PLAIN packet containing username/password to authenticate itself. The client is now authenticated by the server. At this point this test client is at the same state as a regular SASL_PLAINTEXT client that is <tt>ready</tt>.</li> <li>The authenticated client sends random data to the server and checks that the data is echoed back by the test server (ie, not Kafka request-response) to ensure that the client now behaves exactly as a regular SASL_PLAINTEXT client that has completed authentication.</li> </ol>
 */
private void testUnauthenticatedApiVersionsRequest(SecurityProtocol securityProtocol,short saslHandshakeVersion) throws Exception {
  configureMechanisms("PLAIN",Arrays.asList("PLAIN"));
  server=createEchoServer(securityProtocol);
  String node="1";
  SecurityProtocol clientProtocol;
switch (securityProtocol) {
case SASL_PLAINTEXT:
    clientProtocol=SecurityProtocol.PLAINTEXT;
  break;
case SASL_SSL:
clientProtocol=SecurityProtocol.SSL;
break;
default :
throw new IllegalArgumentException("Server protocol " + securityProtocol + " is not SASL");
}
createClientConnection(clientProtocol,node);
NetworkTestUtils.waitForChannelReady(selector,node);
ApiVersionsResponse versionsResponse=sendVersionRequestReceiveResponse(node);
assertEquals(ApiKeys.SASL_HANDSHAKE.oldestVersion(),versionsResponse.apiVersion(ApiKeys.SASL_HANDSHAKE.id).minVersion);
assertEquals(ApiKeys.SASL_HANDSHAKE.latestVersion(),versionsResponse.apiVersion(ApiKeys.SASL_HANDSHAKE.id).maxVersion);
assertEquals(ApiKeys.SASL_AUTHENTICATE.oldestVersion(),versionsResponse.apiVersion(ApiKeys.SASL_AUTHENTICATE.id).minVersion);
assertEquals(ApiKeys.SASL_AUTHENTICATE.latestVersion(),versionsResponse.apiVersion(ApiKeys.SASL_AUTHENTICATE.id).maxVersion);
SaslHandshakeResponse handshakeResponse=sendHandshakeRequestReceiveResponse(node,saslHandshakeVersion);
assertEquals(Collections.singletonList("PLAIN"),handshakeResponse.enabledMechanisms());
authenticateUsingSaslPlainAndCheckConnection(node,saslHandshakeVersion > 0);
}
