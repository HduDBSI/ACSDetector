@Test(expected=IllegalArgumentException.class) public void testForIdWithInvalidIdHigh(){
  ApiKeys.forId(10000);
}
