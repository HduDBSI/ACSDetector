@SuppressWarnings("unchecked") private void load(){
  try (SafeObjectInputStream is=new SafeObjectInputStream(new FileInputStream(file))){
    Object obj=is.readObject();
    if (!(obj instanceof HashMap))     throw new ConnectException("Expected HashMap but found " + obj.getClass());
    Map<byte[],byte[]> raw=(Map<byte[],byte[]>)obj;
    data=new HashMap<>();
    for (    Map.Entry<byte[],byte[]> mapEntry : raw.entrySet()) {
      ByteBuffer key=(mapEntry.getKey() != null) ? ByteBuffer.wrap(mapEntry.getKey()) : null;
      ByteBuffer value=(mapEntry.getValue() != null) ? ByteBuffer.wrap(mapEntry.getValue()) : null;
      data.put(key,value);
    }
  }
 catch (  FileNotFoundException|EOFException e) {
  }
catch (  IOException|ClassNotFoundException e) {
    throw new ConnectException(e);
  }
}
