public static Schema schema(int scale){
  return builder(scale).build();
}
