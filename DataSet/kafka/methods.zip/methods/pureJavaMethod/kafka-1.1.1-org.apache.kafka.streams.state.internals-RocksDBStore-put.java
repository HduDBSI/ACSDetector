@SuppressWarnings("unchecked") @Override public synchronized void put(final Bytes key,final byte[] value){
  Objects.requireNonNull(key,"key cannot be null");
  validateStoreOpen();
  putInternal(key.get(),value);
}
