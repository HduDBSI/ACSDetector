@Override public void run(){
  final Properties producerConfig=new Properties();
  producerConfig.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,CLUSTER.bootstrapServers());
  producerConfig.put(ProducerConfig.ACKS_CONFIG,"all");
  producerConfig.put(ProducerConfig.RETRIES_CONFIG,10);
  producerConfig.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,StringSerializer.class);
  producerConfig.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,StringSerializer.class);
  try (final KafkaProducer<String,String> producer=new KafkaProducer<>(producerConfig,new StringSerializer(),new StringSerializer())){
    while (getCurrIteration() < numIterations && !shutdown) {
      for (      final String value : inputValues) {
        producer.send(new ProducerRecord<String,String>(topic,value));
      }
      incrementIteration();
    }
  }
 }
