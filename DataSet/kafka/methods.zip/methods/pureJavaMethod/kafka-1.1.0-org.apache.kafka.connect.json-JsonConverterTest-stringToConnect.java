@Test public void stringToConnect(){
  assertEquals(new SchemaAndValue(Schema.STRING_SCHEMA,"foo-bar-baz"),converter.toConnectData(TOPIC,"{ \"schema\": { \"type\": \"string\" }, \"payload\": \"foo-bar-baz\" }".getBytes()));
}
