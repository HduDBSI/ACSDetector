@Test(expected=IllegalStateException.class) public void shouldNotGetTaskWithKeyAndSerializerWhenNotRunning(){
  streams.metadataForKey("store","key",Serdes.String().serializer());
}
