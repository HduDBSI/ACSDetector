public static FileRecords open(File file) throws IOException {
  return open(file,true);
}
