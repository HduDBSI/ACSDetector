public CommitData(String topic,int partition,long offset){
  super(topic,partition);
  this.offset=offset;
}
