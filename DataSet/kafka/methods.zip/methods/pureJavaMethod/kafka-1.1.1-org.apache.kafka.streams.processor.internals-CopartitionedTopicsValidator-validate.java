@SuppressWarnings("deprecation") void validate(final Set<String> copartitionGroup,final Map<String,InternalTopicMetadata> allRepartitionTopicsNumPartitions,final Cluster metadata){
  int numPartitions=UNKNOWN;
  for (  final String topic : copartitionGroup) {
    if (!allRepartitionTopicsNumPartitions.containsKey(topic)) {
      final Integer partitions=metadata.partitionCountForTopic(topic);
      if (partitions == null) {
        throw new org.apache.kafka.streams.errors.TopologyBuilderException(String.format("%sTopic not found: %s",logPrefix,topic));
      }
      if (numPartitions == UNKNOWN) {
        numPartitions=partitions;
      }
 else       if (numPartitions != partitions) {
        final String[] topics=copartitionGroup.toArray(new String[copartitionGroup.size()]);
        Arrays.sort(topics);
        throw new org.apache.kafka.streams.errors.TopologyBuilderException(String.format("%sTopics not co-partitioned: [%s]",logPrefix,Utils.join(Arrays.asList(topics),",")));
      }
    }
 else     if (allRepartitionTopicsNumPartitions.get(topic).numPartitions == NOT_AVAILABLE) {
      numPartitions=NOT_AVAILABLE;
      break;
    }
  }
  if (numPartitions == UNKNOWN) {
    for (    Map.Entry<String,InternalTopicMetadata> entry : allRepartitionTopicsNumPartitions.entrySet()) {
      if (copartitionGroup.contains(entry.getKey())) {
        final int partitions=entry.getValue().numPartitions;
        if (partitions > numPartitions) {
          numPartitions=partitions;
        }
      }
    }
  }
  for (  Map.Entry<String,InternalTopicMetadata> entry : allRepartitionTopicsNumPartitions.entrySet()) {
    if (copartitionGroup.contains(entry.getKey())) {
      entry.getValue().numPartitions=numPartitions;
    }
  }
}
