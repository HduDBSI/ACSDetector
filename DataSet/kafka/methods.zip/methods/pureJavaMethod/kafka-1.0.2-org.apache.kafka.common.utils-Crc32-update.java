@Override final public void update(int b){
  crc=(crc >>> 8) ^ T[T8_0_START + ((crc ^ b) & 0xff)];
}
