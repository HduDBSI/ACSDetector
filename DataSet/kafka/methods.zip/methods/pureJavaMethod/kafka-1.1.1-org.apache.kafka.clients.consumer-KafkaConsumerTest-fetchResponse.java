private FetchResponse fetchResponse(TopicPartition partition,long fetchOffset,int count){
  FetchInfo fetchInfo=new FetchInfo(fetchOffset,count);
  return fetchResponse(Collections.singletonMap(partition,fetchInfo));
}
