/** 
 * Check the status of the heartbeat thread (if it is active) and indicate the liveness of the client. This must be called periodically after joining with  {@link #ensureActiveGroup()}to ensure that the member stays in the group. If an interval of time longer than the provided rebalance timeout expires without calling this method, then the client will proactively leave the group.
 * @param now current time in milliseconds
 * @throws RuntimeException for unexpected errors raised from the heartbeat thread
 */
protected synchronized void pollHeartbeat(long now){
  if (heartbeatThread != null) {
    if (heartbeatThread.hasFailed()) {
      RuntimeException cause=heartbeatThread.failureCause();
      heartbeatThread=null;
      throw cause;
    }
    if (heartbeat.shouldHeartbeat(now)) {
      notify();
    }
    heartbeat.poll(now);
  }
}
