/** 
 * Return whether we have any completed fetches pending return to the user. This method is thread-safe.
 * @return true if there are completed fetches, false otherwise
 */
public boolean hasCompletedFetches(){
  return !completedFetches.isEmpty();
}
