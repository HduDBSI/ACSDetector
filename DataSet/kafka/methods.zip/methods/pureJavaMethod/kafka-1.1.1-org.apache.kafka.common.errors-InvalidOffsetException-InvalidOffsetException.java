public InvalidOffsetException(String message,Throwable cause){
  super(message,cause);
}
