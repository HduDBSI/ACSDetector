@Test(expected=NullPointerException.class) public void shouldThrowNullPointerOnAggregateWhenAdderIsNull(){
  groupedTable.aggregate(MockInitializer.STRING_INIT,null,MockAggregator.TOSTRING_REMOVER,Materialized.as("store"));
}
