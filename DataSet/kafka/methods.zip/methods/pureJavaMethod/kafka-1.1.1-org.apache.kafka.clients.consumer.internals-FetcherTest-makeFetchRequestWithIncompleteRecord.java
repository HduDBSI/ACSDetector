private void makeFetchRequestWithIncompleteRecord(){
  subscriptions.assignFromUser(singleton(tp0));
  subscriptions.seek(tp0,0);
  assertEquals(1,fetcher.sendFetches());
  assertFalse(fetcher.hasCompletedFetches());
  MemoryRecords partialRecord=MemoryRecords.readableRecords(ByteBuffer.wrap(new byte[]{0,0,0,0,0,0,0,0}));
  client.prepareResponse(fullFetchResponse(tp0,partialRecord,Errors.NONE,100L,0));
  consumerClient.poll(0);
  assertTrue(fetcher.hasCompletedFetches());
}
