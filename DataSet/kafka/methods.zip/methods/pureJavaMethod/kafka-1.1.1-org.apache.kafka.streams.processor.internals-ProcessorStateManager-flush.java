@Override public void flush(){
  ProcessorStateException firstException=null;
  if (!stores.isEmpty()) {
    log.debug("Flushing all stores registered in the state manager");
    for (    final StateStore store : stores.values()) {
      log.trace("Flushing store {}",store.name());
      try {
        store.flush();
      }
 catch (      final Exception e) {
        if (firstException == null) {
          firstException=new ProcessorStateException(String.format("%sFailed to flush state store %s",logPrefix,store.name()),e);
        }
        log.error("Failed to flush state store {}: ",store.name(),e);
      }
    }
  }
  if (firstException != null) {
    throw firstException;
  }
}
