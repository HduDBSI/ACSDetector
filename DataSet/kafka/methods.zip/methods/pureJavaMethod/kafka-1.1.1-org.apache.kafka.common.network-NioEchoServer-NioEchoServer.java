public NioEchoServer(ListenerName listenerName,SecurityProtocol securityProtocol,AbstractConfig config,String serverHost,ChannelBuilder channelBuilder,CredentialCache credentialCache) throws Exception {
  super("echoserver");
  setDaemon(true);
  serverSocketChannel=ServerSocketChannel.open();
  serverSocketChannel.configureBlocking(false);
  serverSocketChannel.socket().bind(new InetSocketAddress(serverHost,0));
  this.port=serverSocketChannel.socket().getLocalPort();
  this.socketChannels=Collections.synchronizedList(new ArrayList<SocketChannel>());
  this.newChannels=Collections.synchronizedList(new ArrayList<SocketChannel>());
  this.credentialCache=credentialCache;
  this.tokenCache=new DelegationTokenCache(ScramMechanism.mechanismNames());
  if (securityProtocol == SecurityProtocol.SASL_PLAINTEXT || securityProtocol == SecurityProtocol.SASL_SSL)   ScramCredentialUtils.createCache(credentialCache,ScramMechanism.mechanismNames());
  if (channelBuilder == null)   channelBuilder=ChannelBuilders.serverChannelBuilder(listenerName,false,securityProtocol,config,credentialCache,tokenCache);
  this.metrics=new Metrics();
  this.selector=new Selector(5000,metrics,new MockTime(),"MetricGroup",channelBuilder,new LogContext());
  acceptorThread=new AcceptorThread();
}
