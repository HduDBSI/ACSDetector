private static void populateSchemaFields(Schema schema,Set<BoundField> fields){
  for (  BoundField field : schema.fields()) {
    fields.add(field);
    if (field.def.type instanceof ArrayOf) {
      Type innerType=((ArrayOf)field.def.type).type();
      if (innerType instanceof Schema)       populateSchemaFields((Schema)innerType,fields);
    }
 else     if (field.def.type instanceof Schema)     populateSchemaFields((Schema)field.def.type,fields);
  }
}
