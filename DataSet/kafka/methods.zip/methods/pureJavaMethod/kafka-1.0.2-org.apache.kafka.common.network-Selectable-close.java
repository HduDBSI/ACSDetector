/** 
 * Close the connection identified by the given id
 */
public void close(String id);
