@Test public void cacheOverheadsSmallValues(){
  Runtime runtime=Runtime.getRuntime();
  double factor=0.05;
  double systemFactor=3;
  long desiredCacheSize=Math.min(100 * 1024 * 1024L,runtime.maxMemory());
  int keySizeBytes=8;
  int valueSizeBytes=100;
  checkOverheads(factor,systemFactor,desiredCacheSize,keySizeBytes,valueSizeBytes);
}
