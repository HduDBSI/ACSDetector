public static ValidString in(String... validStrings){
  return new ValidString(Arrays.asList(validStrings));
}
