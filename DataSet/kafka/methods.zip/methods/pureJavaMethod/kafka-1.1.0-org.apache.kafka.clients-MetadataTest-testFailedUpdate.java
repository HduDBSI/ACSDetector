@Test public void testFailedUpdate(){
  long time=100;
  metadata.update(Cluster.empty(),Collections.<String>emptySet(),time);
  assertEquals(100,metadata.timeToNextUpdate(1000));
  metadata.failedUpdate(1100,null);
  assertEquals(100,metadata.timeToNextUpdate(1100));
  assertEquals(100,metadata.lastSuccessfulUpdate());
  metadata.needMetadataForAllTopics(true);
  metadata.update(Cluster.empty(),Collections.<String>emptySet(),time);
  assertEquals(100,metadata.timeToNextUpdate(1000));
}
