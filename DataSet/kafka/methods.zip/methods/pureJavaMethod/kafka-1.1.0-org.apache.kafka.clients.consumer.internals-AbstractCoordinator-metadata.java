/** 
 * Get the current list of protocols and their associated metadata supported by the local member. The order of the protocols in the list indicates the preference of the protocol (the first entry is the most preferred). The coordinator takes this preference into account when selecting the generation protocol (generally more preferred protocols will be selected as long as all members support them and there is no disagreement on the preference).
 * @return Non-empty map of supported protocols and metadata
 */
protected abstract List<ProtocolMetadata> metadata();
