@Override public void onChange(final KafkaStreams.State newState,final KafkaStreams.State oldState){
  long prevCount=this.mapStates.containsKey(newState) ? this.mapStates.get(newState) : 0;
  this.numChanges++;
  this.oldState=oldState;
  this.newState=newState;
  this.mapStates.put(newState,prevCount + 1);
}
