@Test public void testSpecificPartition(){
  final RecordCollectorImpl collector=new RecordCollectorImpl(new MockProducer<>(cluster,true,new DefaultPartitioner(),byteArraySerializer,byteArraySerializer),"RecordCollectorTest-TestSpecificPartition",new LogContext("RecordCollectorTest-TestSpecificPartition "),new DefaultProductionExceptionHandler());
  collector.send("topic1","999","0",0,null,stringSerializer,stringSerializer);
  collector.send("topic1","999","0",0,null,stringSerializer,stringSerializer);
  collector.send("topic1","999","0",0,null,stringSerializer,stringSerializer);
  collector.send("topic1","999","0",1,null,stringSerializer,stringSerializer);
  collector.send("topic1","999","0",1,null,stringSerializer,stringSerializer);
  collector.send("topic1","999","0",2,null,stringSerializer,stringSerializer);
  final Map<TopicPartition,Long> offsets=collector.offsets();
  assertEquals((Long)2L,offsets.get(new TopicPartition("topic1",0)));
  assertEquals((Long)1L,offsets.get(new TopicPartition("topic1",1)));
  assertEquals((Long)0L,offsets.get(new TopicPartition("topic1",2)));
  collector.send("topic1","999","0",0,null,stringSerializer,stringSerializer);
  collector.send("topic1","999","0",1,null,stringSerializer,stringSerializer);
  collector.send("topic1","999","0",2,null,stringSerializer,stringSerializer);
  assertEquals((Long)3L,offsets.get(new TopicPartition("topic1",0)));
  assertEquals((Long)2L,offsets.get(new TopicPartition("topic1",1)));
  assertEquals((Long)1L,offsets.get(new TopicPartition("topic1",2)));
}
