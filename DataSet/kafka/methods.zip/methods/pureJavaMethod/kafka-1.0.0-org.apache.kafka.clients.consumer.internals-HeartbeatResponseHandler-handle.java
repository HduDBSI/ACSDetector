@Override public void handle(HeartbeatResponse heartbeatResponse,RequestFuture<Void> future){
  sensors.heartbeatLatency.record(response.requestLatencyMs());
  Errors error=heartbeatResponse.error();
  if (error == Errors.NONE) {
    log.debug("Received successful Heartbeat response");
    future.complete(null);
  }
 else   if (error == Errors.COORDINATOR_NOT_AVAILABLE || error == Errors.NOT_COORDINATOR) {
    log.debug("Attempt to heartbeat since coordinator {} is either not started or not valid.",coordinator());
    coordinatorDead();
    future.raise(error);
  }
 else   if (error == Errors.REBALANCE_IN_PROGRESS) {
    log.debug("Attempt to heartbeat failed since group is rebalancing");
    requestRejoin();
    future.raise(Errors.REBALANCE_IN_PROGRESS);
  }
 else   if (error == Errors.ILLEGAL_GENERATION) {
    log.debug("Attempt to heartbeat failed since generation {} is not current",generation.generationId);
    resetGeneration();
    future.raise(Errors.ILLEGAL_GENERATION);
  }
 else   if (error == Errors.UNKNOWN_MEMBER_ID) {
    log.debug("Attempt to heartbeat failed for since member id {} is not valid.",generation.memberId);
    resetGeneration();
    future.raise(Errors.UNKNOWN_MEMBER_ID);
  }
 else   if (error == Errors.GROUP_AUTHORIZATION_FAILED) {
    future.raise(new GroupAuthorizationException(groupId));
  }
 else {
    future.raise(new KafkaException("Unexpected error in heartbeat response: " + error.message()));
  }
}
