/** 
 * Implements any authentication mechanism. Use transportLayer to read or write tokens. For security protocols PLAINTEXT and SSL, this is a no-op since no further authentication needs to be done. For SASL_PLAINTEXT and SASL_SSL, this performs the SASL authentication.
 * @throws AuthenticationException if authentication fails due to invalid credentials orother security configuration errors
 * @throws IOException if read/write fails due to an I/O error
 */
void authenticate() throws AuthenticationException, IOException ;
