/** 
 * Test the new FileRecords with pre allocate as true
 */
@Test public void testPreallocateTrue() throws IOException {
  File temp=tempFile();
  FileRecords fileRecords=FileRecords.open(temp,false,512 * 1024 * 1024,true);
  long position=fileRecords.channel().position();
  int size=fileRecords.sizeInBytes();
  assertEquals(0,position);
  assertEquals(0,size);
  assertEquals(512 * 1024 * 1024,temp.length());
}
