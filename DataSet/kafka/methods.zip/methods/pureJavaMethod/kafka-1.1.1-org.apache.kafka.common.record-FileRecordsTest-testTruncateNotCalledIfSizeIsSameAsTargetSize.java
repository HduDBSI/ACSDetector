/** 
 * Test that truncateTo only calls truncate on the FileChannel if the size of the FileChannel is bigger than the target size. This is important because some JVMs change the mtime of the file, even if truncate should do nothing.
 */
@Test public void testTruncateNotCalledIfSizeIsSameAsTargetSize() throws IOException {
  FileChannel channelMock=EasyMock.createMock(FileChannel.class);
  EasyMock.expect(channelMock.size()).andReturn(42L).atLeastOnce();
  EasyMock.expect(channelMock.position(42L)).andReturn(null);
  EasyMock.replay(channelMock);
  FileRecords fileRecords=new FileRecords(tempFile(),channelMock,0,Integer.MAX_VALUE,false);
  fileRecords.truncateTo(42);
  EasyMock.verify(channelMock);
}
