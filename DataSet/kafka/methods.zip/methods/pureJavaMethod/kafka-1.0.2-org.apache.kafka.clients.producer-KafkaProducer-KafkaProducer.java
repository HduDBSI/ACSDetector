@SuppressWarnings("unchecked") private KafkaProducer(ProducerConfig config,Serializer<K> keySerializer,Serializer<V> valueSerializer){
  try {
    Map<String,Object> userProvidedConfigs=config.originals();
    this.producerConfig=config;
    this.time=Time.SYSTEM;
    String clientId=config.getString(ProducerConfig.CLIENT_ID_CONFIG);
    if (clientId.length() <= 0)     clientId="producer-" + PRODUCER_CLIENT_ID_SEQUENCE.getAndIncrement();
    this.clientId=clientId;
    String transactionalId=userProvidedConfigs.containsKey(ProducerConfig.TRANSACTIONAL_ID_CONFIG) ? (String)userProvidedConfigs.get(ProducerConfig.TRANSACTIONAL_ID_CONFIG) : null;
    LogContext logContext;
    if (transactionalId == null)     logContext=new LogContext(String.format("[Producer clientId=%s] ",clientId));
 else     logContext=new LogContext(String.format("[Producer clientId=%s, transactionalId=%s] ",clientId,transactionalId));
    log=logContext.logger(KafkaProducer.class);
    log.trace("Starting the Kafka producer");
    Map<String,String> metricTags=Collections.singletonMap("client-id",clientId);
    MetricConfig metricConfig=new MetricConfig().samples(config.getInt(ProducerConfig.METRICS_NUM_SAMPLES_CONFIG)).timeWindow(config.getLong(ProducerConfig.METRICS_SAMPLE_WINDOW_MS_CONFIG),TimeUnit.MILLISECONDS).recordLevel(Sensor.RecordingLevel.forName(config.getString(ProducerConfig.METRICS_RECORDING_LEVEL_CONFIG))).tags(metricTags);
    List<MetricsReporter> reporters=config.getConfiguredInstances(ProducerConfig.METRIC_REPORTER_CLASSES_CONFIG,MetricsReporter.class);
    reporters.add(new JmxReporter(JMX_PREFIX));
    this.metrics=new Metrics(metricConfig,reporters,time);
    ProducerMetrics metricsRegistry=new ProducerMetrics(this.metrics);
    this.partitioner=config.getConfiguredInstance(ProducerConfig.PARTITIONER_CLASS_CONFIG,Partitioner.class);
    long retryBackoffMs=config.getLong(ProducerConfig.RETRY_BACKOFF_MS_CONFIG);
    if (keySerializer == null) {
      this.keySerializer=ensureExtended(config.getConfiguredInstance(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,Serializer.class));
      this.keySerializer.configure(config.originals(),true);
    }
 else {
      config.ignore(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG);
      this.keySerializer=ensureExtended(keySerializer);
    }
    if (valueSerializer == null) {
      this.valueSerializer=ensureExtended(config.getConfiguredInstance(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,Serializer.class));
      this.valueSerializer.configure(config.originals(),false);
    }
 else {
      config.ignore(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG);
      this.valueSerializer=ensureExtended(valueSerializer);
    }
    userProvidedConfigs.put(ProducerConfig.CLIENT_ID_CONFIG,clientId);
    List<ProducerInterceptor<K,V>> interceptorList=(List)(new ProducerConfig(userProvidedConfigs,false)).getConfiguredInstances(ProducerConfig.INTERCEPTOR_CLASSES_CONFIG,ProducerInterceptor.class);
    this.interceptors=interceptorList.isEmpty() ? null : new ProducerInterceptors<>(interceptorList);
    ClusterResourceListeners clusterResourceListeners=configureClusterResourceListeners(keySerializer,valueSerializer,interceptorList,reporters);
    this.metadata=new Metadata(retryBackoffMs,config.getLong(ProducerConfig.METADATA_MAX_AGE_CONFIG),true,true,clusterResourceListeners);
    this.maxRequestSize=config.getInt(ProducerConfig.MAX_REQUEST_SIZE_CONFIG);
    this.totalMemorySize=config.getLong(ProducerConfig.BUFFER_MEMORY_CONFIG);
    this.compressionType=CompressionType.forName(config.getString(ProducerConfig.COMPRESSION_TYPE_CONFIG));
    this.maxBlockTimeMs=config.getLong(ProducerConfig.MAX_BLOCK_MS_CONFIG);
    this.requestTimeoutMs=config.getInt(ProducerConfig.REQUEST_TIMEOUT_MS_CONFIG);
    this.transactionManager=configureTransactionState(config,logContext,log);
    int retries=configureRetries(config,transactionManager != null,log);
    int maxInflightRequests=configureInflightRequests(config,transactionManager != null);
    short acks=configureAcks(config,transactionManager != null,log);
    this.apiVersions=new ApiVersions();
    this.accumulator=new RecordAccumulator(logContext,config.getInt(ProducerConfig.BATCH_SIZE_CONFIG),this.totalMemorySize,this.compressionType,config.getLong(ProducerConfig.LINGER_MS_CONFIG),retryBackoffMs,metrics,time,apiVersions,transactionManager);
    List<InetSocketAddress> addresses=ClientUtils.parseAndValidateAddresses(config.getList(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG));
    this.metadata.update(Cluster.bootstrap(addresses),Collections.<String>emptySet(),time.milliseconds());
    ChannelBuilder channelBuilder=ClientUtils.createChannelBuilder(config);
    Sensor throttleTimeSensor=Sender.throttleTimeSensor(metricsRegistry.senderMetrics);
    NetworkClient client=new NetworkClient(new Selector(config.getLong(ProducerConfig.CONNECTIONS_MAX_IDLE_MS_CONFIG),this.metrics,time,"producer",channelBuilder,logContext),this.metadata,clientId,maxInflightRequests,config.getLong(ProducerConfig.RECONNECT_BACKOFF_MS_CONFIG),config.getLong(ProducerConfig.RECONNECT_BACKOFF_MAX_MS_CONFIG),config.getInt(ProducerConfig.SEND_BUFFER_CONFIG),config.getInt(ProducerConfig.RECEIVE_BUFFER_CONFIG),this.requestTimeoutMs,time,true,apiVersions,throttleTimeSensor,logContext);
    this.sender=new Sender(logContext,client,this.metadata,this.accumulator,maxInflightRequests == 1,config.getInt(ProducerConfig.MAX_REQUEST_SIZE_CONFIG),acks,retries,metricsRegistry.senderMetrics,Time.SYSTEM,this.requestTimeoutMs,config.getLong(ProducerConfig.RETRY_BACKOFF_MS_CONFIG),this.transactionManager,apiVersions);
    String ioThreadName=NETWORK_THREAD_PREFIX + " | " + clientId;
    this.ioThread=new KafkaThread(ioThreadName,this.sender,true);
    this.ioThread.start();
    this.errors=this.metrics.sensor("errors");
    config.logUnused();
    AppInfoParser.registerAppInfo(JMX_PREFIX,clientId,metrics);
    log.debug("Kafka producer started");
  }
 catch (  Throwable t) {
    close(0,TimeUnit.MILLISECONDS,true);
    throw new KafkaException("Failed to construct kafka producer",t);
  }
}
