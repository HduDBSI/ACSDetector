private RequestFuture<ByteBuffer> onJoinLeader(JoinGroupResponse joinResponse){
  try {
    Map<String,ByteBuffer> groupAssignment=performAssignment(joinResponse.leaderId(),joinResponse.groupProtocol(),joinResponse.members());
    SyncGroupRequest.Builder requestBuilder=new SyncGroupRequest.Builder(groupId,generation.generationId,generation.memberId,groupAssignment);
    log.debug("Sending leader SyncGroup to coordinator {}: {}",this.coordinator,requestBuilder);
    return sendSyncGroupRequest(requestBuilder);
  }
 catch (  RuntimeException e) {
    return RequestFuture.failure(e);
  }
}
