@Test public void testUpdateFetchPositionOfPausedPartitionsWithAValidPosition(){
  subscriptions.assignFromUser(singleton(tp0));
  subscriptions.seek(tp0,10);
  subscriptions.pause(tp0);
  fetcher.resetOffsetsIfNeeded();
  assertFalse(subscriptions.isOffsetResetNeeded(tp0));
  assertFalse(subscriptions.isFetchable(tp0));
  assertTrue(subscriptions.hasValidPosition(tp0));
  assertEquals(10,subscriptions.position(tp0).longValue());
}
