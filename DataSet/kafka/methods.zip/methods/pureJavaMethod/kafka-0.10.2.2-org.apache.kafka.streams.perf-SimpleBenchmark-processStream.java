public void processStream(final String topic) throws Exception {
  if (maybeSetupPhase(topic,"simple-benchmark-process-stream-load",true)) {
    return;
  }
  CountDownLatch latch=new CountDownLatch(1);
  final KafkaStreams streams=createKafkaStreams(topic,latch);
  long latency=startStreamsThread(streams,latch);
  printResults("Streams Performance [records/latency/rec-sec/MB-sec source]: ",latency);
}
