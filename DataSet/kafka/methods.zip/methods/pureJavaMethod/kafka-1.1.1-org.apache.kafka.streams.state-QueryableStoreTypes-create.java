@Override public ReadOnlySessionStore<K,V> create(final StateStoreProvider storeProvider,final String storeName){
  return new CompositeReadOnlySessionStore<>(storeProvider,this,storeName);
}
