@Test public void testReadWrite() throws IOException {
  final File f=TestUtils.tempFile();
  final OffsetCheckpoint checkpoint=new OffsetCheckpoint(f);
  try {
    Map<TopicPartition,Long> offsets=new HashMap<>();
    offsets.put(new TopicPartition(topic,0),0L);
    offsets.put(new TopicPartition(topic,1),1L);
    offsets.put(new TopicPartition(topic,2),2L);
    checkpoint.write(offsets);
    assertEquals(offsets,checkpoint.read());
    checkpoint.delete();
    assertFalse(f.exists());
    offsets.put(new TopicPartition(topic,3),3L);
    checkpoint.write(offsets);
    assertEquals(offsets,checkpoint.read());
  }
  finally {
    checkpoint.delete();
  }
}
