@Test public void testReadNegativeBytesSize(){
  byte[] stringBytes="foo".getBytes();
  ByteBuffer invalidBuffer=ByteBuffer.allocate(4 + stringBytes.length);
  invalidBuffer.putInt(-20);
  invalidBuffer.put(stringBytes);
  invalidBuffer.rewind();
  try {
    Type.BYTES.read(invalidBuffer);
    fail("Bytes size not validated");
  }
 catch (  SchemaException e) {
  }
}
