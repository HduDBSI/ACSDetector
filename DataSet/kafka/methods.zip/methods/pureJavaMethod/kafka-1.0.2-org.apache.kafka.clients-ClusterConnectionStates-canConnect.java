/** 
 * Return true iff we can currently initiate a new connection. This will be the case if we are not connected and haven't been connected for at least the minimum reconnection backoff period.
 * @param id the connection id to check
 * @param now the current time in ms
 * @return true if we can initiate a new connection
 */
public boolean canConnect(String id,long now){
  NodeConnectionState state=nodeState.get(id);
  if (state == null)   return true;
 else   return state.state.isDisconnected() && now - state.lastConnectAttemptMs >= state.reconnectBackoffMs;
}
