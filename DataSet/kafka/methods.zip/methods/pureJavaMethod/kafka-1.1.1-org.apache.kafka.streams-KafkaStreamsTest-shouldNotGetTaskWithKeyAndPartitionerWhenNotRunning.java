@Test(expected=IllegalStateException.class) public void shouldNotGetTaskWithKeyAndPartitionerWhenNotRunning(){
  streams.metadataForKey("store","key",new StreamPartitioner<String,Object>(){
    @Override public Integer partition(    final String key,    final Object value,    final int numPartitions){
      return 0;
    }
  }
);
}
