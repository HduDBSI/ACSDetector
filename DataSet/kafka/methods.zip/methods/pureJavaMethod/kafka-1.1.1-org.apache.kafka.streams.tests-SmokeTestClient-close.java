public void close(){
  streams.close(5,TimeUnit.SECONDS);
  if (!uncaughtException) {
    System.out.println("SMOKE-TEST-CLIENT-CLOSED");
  }
  try {
    thread.join();
  }
 catch (  Exception ex) {
    System.out.println("SMOKE-TEST-CLIENT-EXCEPTION");
  }
}
