@Test public void shouldForwardOldValuesWhenEnabled(){
  cachingStore.setFlushListener(cacheListener,true);
  final Windowed<String> windowedKey=new Windowed<>("1",new TimeWindow(DEFAULT_TIMESTAMP,DEFAULT_TIMESTAMP + WINDOW_SIZE));
  cachingStore.put(bytesKey("1"),bytesValue("a"));
  cachingStore.flush();
  cachingStore.put(bytesKey("1"),bytesValue("b"));
  cachingStore.flush();
  assertEquals("b",cacheListener.forwarded.get(windowedKey).newValue);
  assertEquals("a",cacheListener.forwarded.get(windowedKey).oldValue);
}
