@Before public void setUp(){
  final Properties properties=new Properties();
  properties.put(IntegrationTestUtils.INTERNAL_LEAVE_GROUP_ON_CLOSE,true);
  streamsConfiguration=StreamsTestUtils.getStreamsConfig("regex-source-integration-test",CLUSTER.bootstrapServers(),STRING_SERDE_CLASSNAME,STRING_SERDE_CLASSNAME,properties);
}
