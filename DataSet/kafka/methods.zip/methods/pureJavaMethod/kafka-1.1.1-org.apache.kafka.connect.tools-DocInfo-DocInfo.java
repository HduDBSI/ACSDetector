private DocInfo(String transformationName,String overview,ConfigDef configDef){
  this.transformationName=transformationName;
  this.overview=overview;
  this.configDef=configDef;
}
