private Builder(short oldestAllowedVersion,short latestAllowedVersion,int replicaId,IsolationLevel isolationLevel){
  super(ApiKeys.LIST_OFFSETS,oldestAllowedVersion,latestAllowedVersion);
  this.replicaId=replicaId;
  this.isolationLevel=isolationLevel;
}
