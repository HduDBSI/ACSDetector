@Override public synchronized void putConnectorConfig(String connName,final Map<String,String> config,boolean allowReplace,final Callback<Created<ConnectorInfo>> callback){
  try {
    if (maybeAddConfigErrors(validateConnectorConfig(config),callback)) {
      return;
    }
    boolean created=false;
    if (configState.contains(connName)) {
      if (!allowReplace) {
        callback.onCompletion(new AlreadyExistsException("Connector " + connName + " already exists"),null);
        return;
      }
      worker.stopConnector(connName);
    }
 else {
      created=true;
    }
    if (!startConnector(config)) {
      callback.onCompletion(new ConnectException("Failed to start connector: " + connName),null);
      return;
    }
    updateConnectorTasks(connName);
    callback.onCompletion(null,new Created<>(created,createConnectorInfo(connName)));
  }
 catch (  ConnectException e) {
    callback.onCompletion(e,null);
  }
}
