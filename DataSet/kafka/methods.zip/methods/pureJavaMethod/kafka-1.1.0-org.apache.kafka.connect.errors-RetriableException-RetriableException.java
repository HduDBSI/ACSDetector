public RetriableException(Throwable throwable){
  super(throwable);
}
