private void testAppendLarge(CompressionType compressionType) throws Exception {
  int batchSize=512;
  byte[] value=new byte[2 * batchSize];
  RecordAccumulator accum=createTestRecordAccumulator(batchSize + DefaultRecordBatch.RECORD_BATCH_OVERHEAD,10 * 1024,compressionType,0L);
  accum.append(tp1,0L,key,value,Record.EMPTY_HEADERS,null,maxBlockTimeMs);
  assertEquals("Our partition's leader should be ready",Collections.singleton(node1),accum.ready(cluster,time.milliseconds()).readyNodes);
  Deque<ProducerBatch> batches=accum.batches().get(tp1);
  assertEquals(1,batches.size());
  ProducerBatch producerBatch=batches.peek();
  List<MutableRecordBatch> recordBatches=TestUtils.toList(producerBatch.records().batches());
  assertEquals(1,recordBatches.size());
  MutableRecordBatch recordBatch=recordBatches.get(0);
  assertEquals(0L,recordBatch.baseOffset());
  List<Record> records=TestUtils.toList(recordBatch);
  assertEquals(1,records.size());
  Record record=records.get(0);
  assertEquals(0L,record.offset());
  assertEquals(ByteBuffer.wrap(key),record.key());
  assertEquals(ByteBuffer.wrap(value),record.value());
  assertEquals(0L,record.timestamp());
}
