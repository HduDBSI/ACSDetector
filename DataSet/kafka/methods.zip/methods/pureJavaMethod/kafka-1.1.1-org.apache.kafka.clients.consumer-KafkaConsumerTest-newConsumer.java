private KafkaConsumer<String,String> newConsumer(Time time,KafkaClient client,Metadata metadata,PartitionAssignor assignor,OffsetResetStrategy resetStrategy,boolean autoCommitEnabled){
  String clientId="mock-consumer";
  String groupId="mock-group";
  String metricGroupPrefix="consumer";
  long retryBackoffMs=100;
  long requestTimeoutMs=30000;
  boolean excludeInternalTopics=true;
  int minBytes=1;
  int maxBytes=Integer.MAX_VALUE;
  int maxWaitMs=500;
  int fetchSize=1024 * 1024;
  int maxPollRecords=Integer.MAX_VALUE;
  boolean checkCrcs=true;
  int rebalanceTimeoutMs=60000;
  Deserializer<String> keyDeserializer=new StringDeserializer();
  Deserializer<String> valueDeserializer=new StringDeserializer();
  List<PartitionAssignor> assignors=singletonList(assignor);
  ConsumerInterceptors<String,String> interceptors=new ConsumerInterceptors<>(Collections.<ConsumerInterceptor<String,String>>emptyList());
  Metrics metrics=new Metrics();
  ConsumerMetrics metricsRegistry=new ConsumerMetrics(metricGroupPrefix);
  SubscriptionState subscriptions=new SubscriptionState(resetStrategy);
  LogContext loggerFactory=new LogContext();
  ConsumerNetworkClient consumerClient=new ConsumerNetworkClient(loggerFactory,client,metadata,time,retryBackoffMs,requestTimeoutMs,heartbeatIntervalMs);
  ConsumerCoordinator consumerCoordinator=new ConsumerCoordinator(loggerFactory,consumerClient,groupId,rebalanceTimeoutMs,sessionTimeoutMs,heartbeatIntervalMs,assignors,metadata,subscriptions,metrics,metricGroupPrefix,time,retryBackoffMs,autoCommitEnabled,autoCommitIntervalMs,interceptors,excludeInternalTopics,true);
  Fetcher<String,String> fetcher=new Fetcher<>(loggerFactory,consumerClient,minBytes,maxBytes,maxWaitMs,fetchSize,maxPollRecords,checkCrcs,keyDeserializer,valueDeserializer,metadata,subscriptions,metrics,metricsRegistry.fetcherMetrics,time,retryBackoffMs,requestTimeoutMs,IsolationLevel.READ_UNCOMMITTED);
  return new KafkaConsumer<>(loggerFactory,clientId,consumerCoordinator,keyDeserializer,valueDeserializer,fetcher,interceptors,time,consumerClient,metrics,subscriptions,metadata,retryBackoffMs,requestTimeoutMs,assignors);
}
