/** 
 * Unsubscribe from topics currently subscribed with  {@link #subscribe(List)}. This also clears any partitions directly assigned through  {@link #assign(List)}.
 */
public void unsubscribe(){
  acquire();
  try {
    log.debug("Unsubscribed all topics or patterns and assigned partitions");
    this.subscriptions.unsubscribe();
    this.coordinator.maybeLeaveGroup();
    this.metadata.needMetadataForAllTopics(false);
  }
  finally {
    release();
  }
}
