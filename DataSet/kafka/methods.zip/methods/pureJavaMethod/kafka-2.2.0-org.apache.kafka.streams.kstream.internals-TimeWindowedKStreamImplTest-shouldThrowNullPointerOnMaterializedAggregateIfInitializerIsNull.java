@Test(expected=NullPointerException.class) public void shouldThrowNullPointerOnMaterializedAggregateIfInitializerIsNull(){
  windowedStream.aggregate(null,MockAggregator.TOSTRING_ADDER,Materialized.as("store"));
}
