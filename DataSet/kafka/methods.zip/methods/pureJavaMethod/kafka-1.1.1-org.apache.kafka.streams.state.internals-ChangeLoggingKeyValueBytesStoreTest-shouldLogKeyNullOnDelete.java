@Test public void shouldLogKeyNullOnDelete(){
  store.put(hi,there);
  store.delete(hi);
  assertThat(sent.containsKey(hi),is(true));
  assertThat(sent.get(hi),nullValue());
}
