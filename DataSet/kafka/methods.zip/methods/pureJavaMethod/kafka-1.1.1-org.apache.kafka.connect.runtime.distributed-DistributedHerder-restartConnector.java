@Override public void restartConnector(final String connName,final Callback<Void> callback){
  addRequest(new Callable<Void>(){
    @Override public Void call() throws Exception {
      if (checkRebalanceNeeded(callback))       return null;
      if (!configState.connectors().contains(connName)) {
        callback.onCompletion(new NotFoundException("Unknown connector: " + connName),null);
        return null;
      }
      if (assignment.connectors().contains(connName)) {
        try {
          worker.stopConnector(connName);
          if (startConnector(connName))           callback.onCompletion(null,null);
 else           callback.onCompletion(new ConnectException("Failed to start connector: " + connName),null);
        }
 catch (        Throwable t) {
          callback.onCompletion(t,null);
        }
      }
 else       if (isLeader()) {
        callback.onCompletion(new NotAssignedException("Cannot restart connector since it is not assigned to this member",member.ownerUrl(connName)),null);
      }
 else {
        callback.onCompletion(new NotLeaderException("Cannot restart connector since it is not assigned to this member",leaderUrl()),null);
      }
      return null;
    }
  }
,forwardErrorCallback(callback));
}
