/** 
 * Set the  {@link CacheFlushListener} to be notified when entries are flushed from thecache to the underlying  {@link org.apache.kafka.streams.processor.StateStore}
 * @param listener
 * @param sendOldValues
 */
void setFlushListener(final CacheFlushListener<K,V> listener,final boolean sendOldValues);
