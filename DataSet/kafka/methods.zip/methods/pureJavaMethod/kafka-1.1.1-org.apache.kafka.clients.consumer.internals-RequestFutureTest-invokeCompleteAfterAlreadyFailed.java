@Test(expected=IllegalStateException.class) public void invokeCompleteAfterAlreadyFailed(){
  RequestFuture<Void> future=new RequestFuture<>();
  future.raise(new RuntimeException());
  future.complete(null);
}
