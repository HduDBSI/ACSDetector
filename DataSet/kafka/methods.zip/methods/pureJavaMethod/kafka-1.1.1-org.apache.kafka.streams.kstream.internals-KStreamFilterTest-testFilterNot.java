@Test public void testFilterNot(){
  StreamsBuilder builder=new StreamsBuilder();
  final int[] expectedKeys=new int[]{1,2,3,4,5,6,7};
  KStream<Integer,String> stream;
  MockProcessorSupplier<Integer,String> processor;
  processor=new MockProcessorSupplier<>();
  stream=builder.stream(topicName,Consumed.with(Serdes.Integer(),Serdes.String()));
  stream.filterNot(isMultipleOfThree).process(processor);
  driver.setUp(builder);
  for (  int expectedKey : expectedKeys) {
    driver.process(topicName,expectedKey,"V" + expectedKey);
  }
  assertEquals(5,processor.processed.size());
}
