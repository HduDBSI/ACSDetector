public static CreateTopicsRequest parse(ByteBuffer buffer,short version){
  return new CreateTopicsRequest(ApiKeys.CREATE_TOPICS.parseRequest(version,buffer),version);
}
