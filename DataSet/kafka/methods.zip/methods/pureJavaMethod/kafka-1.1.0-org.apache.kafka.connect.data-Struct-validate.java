/** 
 * Validates that this struct has filled in all the necessary data with valid values. For required fields without defaults, this validates that a value has been set and has matching types/schemas. If any validation fails, throws a DataException.
 */
public void validate(){
  for (  Field field : schema.fields()) {
    Schema fieldSchema=field.schema();
    Object value=values[field.index()];
    if (value == null && (fieldSchema.isOptional() || fieldSchema.defaultValue() != null))     continue;
    ConnectSchema.validateValue(field.name(),fieldSchema,value);
  }
}
