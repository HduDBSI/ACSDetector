/** 
 * Return  {@link ConfigDef} from {@code transformationCls}, which is expected to be a non-null  {@code Class<Transformation>}, by instantiating it and invoking  {@link Transformation#config()}.
 */
static ConfigDef getConfigDefFromTransformation(String key,Class<?> transformationCls){
  if (transformationCls == null || !Transformation.class.isAssignableFrom(transformationCls)) {
    throw new ConfigException(key,String.valueOf(transformationCls),"Not a Transformation");
  }
  try {
    return (transformationCls.asSubclass(Transformation.class).newInstance()).config();
  }
 catch (  Exception e) {
    throw new ConfigException(key,String.valueOf(transformationCls),"Error getting config definition from Transformation: " + e.getMessage());
  }
}
