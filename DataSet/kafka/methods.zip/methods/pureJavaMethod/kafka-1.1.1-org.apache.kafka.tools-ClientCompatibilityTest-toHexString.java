private static String toHexString(byte[] buf){
  StringBuilder bld=new StringBuilder();
  for (  byte b : buf) {
    bld.append(String.format("%02x",b));
  }
  return bld.toString();
}
