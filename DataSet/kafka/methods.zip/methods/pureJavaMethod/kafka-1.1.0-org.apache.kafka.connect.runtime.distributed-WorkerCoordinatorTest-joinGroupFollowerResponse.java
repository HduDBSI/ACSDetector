private JoinGroupResponse joinGroupFollowerResponse(int generationId,String memberId,String leaderId,Errors error){
  return new JoinGroupResponse(error,generationId,WorkerCoordinator.DEFAULT_SUBPROTOCOL,memberId,leaderId,Collections.<String,ByteBuffer>emptyMap());
}
