@Override public String toString(){
  StringBuilder builder=new StringBuilder();
  builder.append('[');
  Iterator<MutableRecordBatch> batchIterator=batches.iterator();
  while (batchIterator.hasNext()) {
    RecordBatch batch=batchIterator.next();
    try (CloseableIterator<Record> recordsIterator=batch.streamingIterator(BufferSupplier.create())){
      while (recordsIterator.hasNext()) {
        Record record=recordsIterator.next();
        appendRecordToStringBuilder(builder,record.toString());
        if (recordsIterator.hasNext())         builder.append(", ");
      }
    }
 catch (    KafkaException e) {
      appendRecordToStringBuilder(builder,"CORRUPTED");
    }
    if (batchIterator.hasNext())     builder.append(", ");
  }
  builder.append(']');
  return builder.toString();
}
