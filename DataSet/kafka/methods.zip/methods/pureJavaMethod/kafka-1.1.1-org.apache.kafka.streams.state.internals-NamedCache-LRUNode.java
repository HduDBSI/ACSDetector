LRUNode(final Bytes key,final LRUCacheEntry entry){
  this.key=key;
  this.entry=entry;
}
