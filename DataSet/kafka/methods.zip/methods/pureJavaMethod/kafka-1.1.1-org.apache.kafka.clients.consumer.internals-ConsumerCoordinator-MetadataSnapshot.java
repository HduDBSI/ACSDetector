private MetadataSnapshot(SubscriptionState subscription,Cluster cluster){
  Map<String,Integer> partitionsPerTopic=new HashMap<>();
  for (  String topic : subscription.groupSubscription())   partitionsPerTopic.put(topic,cluster.partitionCountForTopic(topic));
  this.partitionsPerTopic=partitionsPerTopic;
}
