public Percentiles(int sizeInBytes,double min,double max,BucketSizing bucketing,Percentile... percentiles){
  super(0.0);
  this.percentiles=percentiles;
  this.buckets=sizeInBytes / 4;
  if (bucketing == BucketSizing.CONSTANT) {
    this.binScheme=new ConstantBinScheme(buckets,min,max);
  }
 else   if (bucketing == BucketSizing.LINEAR) {
    if (min != 0.0d)     throw new IllegalArgumentException("Linear bucket sizing requires min to be 0.0.");
    this.binScheme=new LinearBinScheme(buckets,max);
  }
 else {
    throw new IllegalArgumentException("Unknown bucket type: " + bucketing);
  }
}
