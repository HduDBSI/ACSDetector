/** 
 * SSL exceptions are propagated as authentication failures so that clients can avoid retries and report the failure. If `flush` is true, exceptions are propagated after any pending outgoing bytes are flushed to ensure that the peer is notified of the failure.
 */
private void handshakeFailure(SSLException sslException,boolean flush) throws IOException {
  sslEngine.closeOutbound();
  try {
    sslEngine.closeInbound();
  }
 catch (  SSLException e) {
    log.debug("SSLEngine.closeInBound() raised an exception.",e);
  }
  state=State.HANDSHAKE_FAILED;
  handshakeException=new SslAuthenticationException("SSL handshake failed",sslException);
  if (!flush || flush(netWriteBuffer))   throw handshakeException;
}
