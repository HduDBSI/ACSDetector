private List<Map<String,String>> recomputeTaskConfigs(String connName){
  Map<String,String> config=configState.connectorConfig(connName);
  ConnectorConfig connConfig=worker.isSinkConnector(connName) ? new SinkConnectorConfig(plugins(),config) : new SourceConnectorConfig(plugins(),config);
  return worker.connectorTaskConfigs(connName,connConfig);
}
