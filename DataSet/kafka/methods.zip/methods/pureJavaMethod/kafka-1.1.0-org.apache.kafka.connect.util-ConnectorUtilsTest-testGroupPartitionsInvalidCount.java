@Test(expected=IllegalArgumentException.class) public void testGroupPartitionsInvalidCount(){
  ConnectorUtils.groupPartitions(FIVE_ELEMENTS,0);
}
