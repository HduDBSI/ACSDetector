/** 
 * Writes a sequence of bytes to this channel from the given buffers.
 * @param srcs The buffers from which bytes are to be retrieved
 * @return returns no.of bytes consumed by SSLEngine.wrap , possibly zero.
 * @throws IOException If some other I/O error occurs
 */
@Override public long write(ByteBuffer[] srcs) throws IOException {
  return write(srcs,0,srcs.length);
}
