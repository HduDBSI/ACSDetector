public SinkNode(final String name,final String topic,final Serializer<K> keySerializer,final Serializer<V> valSerializer,final StreamPartitioner<? super K,? super V> partitioner){
  super(name);
  this.topic=topic;
  this.keySerializer=keySerializer;
  this.valSerializer=valSerializer;
  this.partitioner=partitioner;
}
