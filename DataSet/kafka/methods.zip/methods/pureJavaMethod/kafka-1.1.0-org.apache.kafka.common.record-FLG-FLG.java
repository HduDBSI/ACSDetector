private FLG(int reserved,int contentChecksum,int contentSize,int blockChecksum,int blockIndependence,int version){
  this.reserved=reserved;
  this.contentChecksum=contentChecksum;
  this.contentSize=contentSize;
  this.blockChecksum=blockChecksum;
  this.blockIndependence=blockIndependence;
  this.version=version;
  validate();
}
