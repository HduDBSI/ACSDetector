@Test public void testFlush() throws Exception {
  long lingerMs=Long.MAX_VALUE;
  final RecordAccumulator accum=createTestRecordAccumulator(4 * 1024 + DefaultRecordBatch.RECORD_BATCH_OVERHEAD,64 * 1024,CompressionType.NONE,lingerMs);
  for (int i=0; i < 100; i++) {
    accum.append(new TopicPartition(topic,i % 3),0L,key,value,Record.EMPTY_HEADERS,null,maxBlockTimeMs);
    assertTrue(accum.hasIncomplete());
  }
  RecordAccumulator.ReadyCheckResult result=accum.ready(cluster,time.milliseconds());
  assertEquals("No nodes should be ready.",0,result.readyNodes.size());
  accum.beginFlush();
  result=accum.ready(cluster,time.milliseconds());
  Map<Integer,List<ProducerBatch>> results=accum.drain(cluster,result.readyNodes,Integer.MAX_VALUE,time.milliseconds());
  assertTrue(accum.hasIncomplete());
  for (  List<ProducerBatch> batches : results.values())   for (  ProducerBatch batch : batches)   accum.deallocate(batch);
  accum.awaitFlushCompletion();
  assertFalse(accum.hasUndrained());
  assertFalse(accum.hasIncomplete());
}
