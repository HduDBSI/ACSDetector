@Test public void shouldSupportAllAcrossMultipleStores(){
  final KeyValueStore<String,String> cache=newStoreInstance();
  stubProviderTwo.addStore(storeName,cache);
  stubOneUnderlying.put("a","a");
  stubOneUnderlying.put("b","b");
  stubOneUnderlying.put("z","z");
  cache.put("c","c");
  cache.put("d","d");
  cache.put("x","x");
  final List<KeyValue<String,String>> results=toList(theStore.all());
  assertTrue(results.contains(new KeyValue<>("a","a")));
  assertTrue(results.contains(new KeyValue<>("b","b")));
  assertTrue(results.contains(new KeyValue<>("c","c")));
  assertTrue(results.contains(new KeyValue<>("d","d")));
  assertTrue(results.contains(new KeyValue<>("x","x")));
  assertTrue(results.contains(new KeyValue<>("z","z")));
  assertEquals(6,results.size());
}
