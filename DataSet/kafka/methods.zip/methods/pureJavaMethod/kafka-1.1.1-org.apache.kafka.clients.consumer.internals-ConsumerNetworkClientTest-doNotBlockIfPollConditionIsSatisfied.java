@Test public void doNotBlockIfPollConditionIsSatisfied(){
  NetworkClient mockNetworkClient=EasyMock.mock(NetworkClient.class);
  ConsumerNetworkClient consumerClient=new ConsumerNetworkClient(new LogContext(),mockNetworkClient,metadata,time,100,1000,Integer.MAX_VALUE);
  EasyMock.expect(mockNetworkClient.poll(EasyMock.eq(0L),EasyMock.anyLong())).andReturn(Collections.<ClientResponse>emptyList());
  EasyMock.replay(mockNetworkClient);
  consumerClient.poll(Long.MAX_VALUE,time.milliseconds(),new ConsumerNetworkClient.PollCondition(){
    @Override public boolean shouldBlock(){
      return false;
    }
  }
);
  EasyMock.verify(mockNetworkClient);
}
