private HistogramSample(BinScheme scheme,long now){
  super(0.0,now);
  this.histogram=new Histogram(scheme);
}
