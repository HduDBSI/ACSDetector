@Test public void testMetadataChangeTriggersRebalance(){
  final String consumerId="consumer";
  metadata.setTopics(singletonList(topic1));
  metadata.update(cluster,Collections.<String>emptySet(),time.milliseconds());
  subscriptions.subscribe(singleton(topic1),rebalanceListener);
  client.prepareResponse(groupCoordinatorResponse(node,Errors.NONE));
  coordinator.ensureCoordinatorReady();
  Map<String,List<String>> memberSubscriptions=singletonMap(consumerId,singletonList(topic1));
  partitionAssignor.prepare(singletonMap(consumerId,singletonList(t1p)));
  client.prepareResponse(joinGroupLeaderResponse(1,consumerId,memberSubscriptions,Errors.NONE));
  client.prepareResponse(syncGroupResponse(singletonList(t1p),Errors.NONE));
  coordinator.poll(time.milliseconds(),Long.MAX_VALUE);
  assertFalse(coordinator.needRejoin());
  metadata.update(TestUtils.singletonCluster(topic1,2),Collections.<String>emptySet(),time.milliseconds());
  assertTrue(coordinator.needRejoin());
}
