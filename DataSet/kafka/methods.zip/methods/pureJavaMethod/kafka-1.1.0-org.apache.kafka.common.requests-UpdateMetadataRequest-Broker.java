public Broker(int id,List<EndPoint> endPoints,String rack){
  this.id=id;
  this.endPoints=endPoints;
  this.rack=rack;
}
