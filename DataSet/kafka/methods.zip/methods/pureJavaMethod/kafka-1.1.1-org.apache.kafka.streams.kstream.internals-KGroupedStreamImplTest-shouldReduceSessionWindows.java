@SuppressWarnings("deprecation") @Test public void shouldReduceSessionWindows(){
  final Map<Windowed<String>,String> results=new HashMap<>();
  KTable<Windowed<String>,String> table=groupedStream.reduce(new Reducer<String>(){
    @Override public String apply(    final String value1,    final String value2){
      return value1 + ":" + value2;
    }
  }
,SessionWindows.with(30),"session-store");
  table.toStream().foreach(new ForeachAction<Windowed<String>,String>(){
    @Override public void apply(    final Windowed<String> key,    final String value){
      results.put(key,value);
    }
  }
);
  doReduceSessionWindows(results);
  assertEquals(table.queryableStoreName(),"session-store");
}
