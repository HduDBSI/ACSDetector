/** 
 * Start worker.
 */
public void start(){
  log.info("Worker starting");
  offsetBackingStore.start();
  sourceTaskOffsetCommitter=new SourceTaskOffsetCommitter(config);
  log.info("Worker started");
}
