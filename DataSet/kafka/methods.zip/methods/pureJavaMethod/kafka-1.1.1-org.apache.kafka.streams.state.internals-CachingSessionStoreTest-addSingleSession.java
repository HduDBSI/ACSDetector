private void addSingleSession(final String sessionId,final List<KeyValue<Windowed<Bytes>,byte[]>> allSessions){
  final int timestamp=allSessions.size() * 10;
  final Windowed<Bytes> key=new Windowed<>(Bytes.wrap(sessionId.getBytes()),new SessionWindow(timestamp,timestamp));
  final byte[] value="1".getBytes();
  cachingStore.put(key,value);
  allSessions.add(KeyValue.pair(key,value));
}
