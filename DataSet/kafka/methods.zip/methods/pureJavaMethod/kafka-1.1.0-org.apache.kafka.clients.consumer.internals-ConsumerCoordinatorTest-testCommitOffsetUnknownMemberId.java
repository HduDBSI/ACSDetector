@Test(expected=CommitFailedException.class) public void testCommitOffsetUnknownMemberId(){
  client.prepareResponse(groupCoordinatorResponse(node,Errors.NONE));
  coordinator.ensureCoordinatorReady();
  prepareOffsetCommitRequest(singletonMap(t1p,100L),Errors.UNKNOWN_MEMBER_ID);
  coordinator.commitOffsetsSync(singletonMap(t1p,new OffsetAndMetadata(100L,"metadata")),Long.MAX_VALUE);
}
