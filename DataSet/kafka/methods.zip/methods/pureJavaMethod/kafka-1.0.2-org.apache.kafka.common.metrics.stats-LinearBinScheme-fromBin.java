public double fromBin(int b){
  if (b > this.bins - 1) {
    return Float.POSITIVE_INFINITY;
  }
 else   if (b < 0.0000d) {
    return Float.NEGATIVE_INFINITY;
  }
 else {
    return this.scale * (b * (b + 1.0)) / 2.0;
  }
}
