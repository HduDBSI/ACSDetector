@Override public void setRecordContext(final RecordContext recordContext){
  this.recordContext=recordContext;
}
