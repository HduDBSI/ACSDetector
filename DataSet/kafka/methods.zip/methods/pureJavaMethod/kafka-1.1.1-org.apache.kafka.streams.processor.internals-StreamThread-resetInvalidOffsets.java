private void resetInvalidOffsets(final InvalidOffsetException e){
  final Set<TopicPartition> partitions=e.partitions();
  final Set<String> loggedTopics=new HashSet<>();
  final Set<TopicPartition> seekToBeginning=new HashSet<>();
  final Set<TopicPartition> seekToEnd=new HashSet<>();
  for (  final TopicPartition partition : partitions) {
    if (builder.earliestResetTopicsPattern().matcher(partition.topic()).matches()) {
      addToResetList(partition,seekToBeginning,"Setting topic '{}' to consume from {} offset","earliest",loggedTopics);
    }
 else     if (builder.latestResetTopicsPattern().matcher(partition.topic()).matches()) {
      addToResetList(partition,seekToEnd,"Setting topic '{}' to consume from {} offset","latest",loggedTopics);
    }
 else {
      if (originalReset == null || (!originalReset.equals("earliest") && !originalReset.equals("latest"))) {
        final String errorMessage="No valid committed offset found for input topic %s (partition %s) and no valid reset policy configured." + " You need to set configuration parameter \"auto.offset.reset\" or specify a topic specific reset " + "policy via StreamsBuilder#stream(..., Consumed.with(Topology.AutoOffsetReset)) or StreamsBuilder#table(..., Consumed.with(Topology.AutoOffsetReset))";
        throw new StreamsException(String.format(errorMessage,partition.topic(),partition.partition()),e);
      }
      if (originalReset.equals("earliest")) {
        addToResetList(partition,seekToBeginning,"No custom setting defined for topic '{}' using original config '{}' for offset reset","earliest",loggedTopics);
      }
 else       if (originalReset.equals("latest")) {
        addToResetList(partition,seekToEnd,"No custom setting defined for topic '{}' using original config '{}' for offset reset","latest",loggedTopics);
      }
    }
  }
  if (!seekToBeginning.isEmpty()) {
    consumer.seekToBeginning(seekToBeginning);
  }
  if (!seekToEnd.isEmpty()) {
    consumer.seekToEnd(seekToEnd);
  }
}
