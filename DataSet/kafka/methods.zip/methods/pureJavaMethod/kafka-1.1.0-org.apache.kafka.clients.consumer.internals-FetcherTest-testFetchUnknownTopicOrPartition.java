@Test public void testFetchUnknownTopicOrPartition(){
  subscriptions.assignFromUser(singleton(tp0));
  subscriptions.seek(tp0,0);
  assertEquals(1,fetcher.sendFetches());
  client.prepareResponse(fullFetchResponse(tp0,this.records,Errors.UNKNOWN_TOPIC_OR_PARTITION,100L,0));
  consumerClient.poll(0);
  assertEquals(0,fetcher.fetchedRecords().size());
  assertEquals(0L,metadata.timeToNextUpdate(time.milliseconds()));
}
