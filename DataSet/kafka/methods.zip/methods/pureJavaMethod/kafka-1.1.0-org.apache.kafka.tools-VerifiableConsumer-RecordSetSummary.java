public RecordSetSummary(String topic,int partition,long count,long minOffset,long maxOffset){
  super(topic,partition);
  this.count=count;
  this.minOffset=minOffset;
  this.maxOffset=maxOffset;
}
