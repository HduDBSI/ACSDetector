public static JoinGroupRequest parse(ByteBuffer buffer,short version){
  return new JoinGroupRequest(ApiKeys.JOIN_GROUP.parseRequest(version,buffer),version);
}
