@SuppressWarnings("unchecked") @Override public void init(final ProcessorContext context){
  super.init(context);
  if (queryableName != null) {
    store=(KeyValueStore<K,V1>)context.getStateStore(queryableName);
    tupleForwarder=new TupleForwarder<>(store,context,new ForwardingCacheFlushListener<K,V1>(context),sendOldValues);
  }
}
