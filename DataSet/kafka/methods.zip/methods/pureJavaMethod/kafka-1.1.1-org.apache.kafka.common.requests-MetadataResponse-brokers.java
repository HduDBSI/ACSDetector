/** 
 * Get all brokers returned in metadata response
 * @return the brokers
 */
public Collection<Node> brokers(){
  return brokers;
}
