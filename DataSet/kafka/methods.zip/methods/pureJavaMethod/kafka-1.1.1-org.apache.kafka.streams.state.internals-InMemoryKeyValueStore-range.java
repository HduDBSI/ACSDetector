@Override public synchronized KeyValueIterator<K,V> range(final K from,final K to){
  return new DelegatingPeekingKeyValueIterator<>(name,new InMemoryKeyValueIterator<>(this.map.subMap(from,true,to,true).entrySet().iterator()));
}
