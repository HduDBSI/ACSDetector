@Override public void close(final Map<TopicPartition,Long> offsets) throws IOException {
  this.offsets.putAll(offsets);
  closed=true;
}
