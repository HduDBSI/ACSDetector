private void maybeEvict(final String namespace){
  int numEvicted=0;
  while (sizeBytes() > maxCacheSizeBytes) {
    final NamedCache cache=getOrCreateCache(namespace);
    if (cache.size() == 0) {
      return;
    }
    cache.evict();
    numEvicts++;
    numEvicted++;
  }
  if (log.isTraceEnabled()) {
    log.trace("Evicted {} entries from cache {}",numEvicted,namespace);
  }
}
