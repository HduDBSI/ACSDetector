public FindCoordinatorResponse(Struct struct){
  this.throttleTimeMs=struct.getOrElse(THROTTLE_TIME_MS,DEFAULT_THROTTLE_TIME);
  error=Errors.forCode(struct.get(ERROR_CODE));
  errorMessage=struct.getOrElse(ERROR_MESSAGE,null);
  Struct broker=(Struct)struct.get(COORDINATOR_KEY_NAME);
  int nodeId=broker.getInt(NODE_ID_KEY_NAME);
  String host=broker.getString(HOST_KEY_NAME);
  int port=broker.getInt(PORT_KEY_NAME);
  node=new Node(nodeId,host,port);
}
