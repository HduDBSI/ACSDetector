@Test public void testFetcherMetrics(){
  subscriptions.assignFromUser(singleton(tp0));
  subscriptions.seek(tp0,0);
  MetricName maxLagMetric=metrics.metricInstance(metricsRegistry.recordsLagMax);
  Map<String,String> tags=new HashMap<>();
  tags.put("topic",tp0.topic());
  tags.put("partition",String.valueOf(tp0.partition()));
  MetricName partitionLagMetric=metrics.metricName("records-lag",metricGroup,tags);
  Map<MetricName,KafkaMetric> allMetrics=metrics.metrics();
  KafkaMetric recordsFetchLagMax=allMetrics.get(maxLagMetric);
  assertEquals(Double.NEGATIVE_INFINITY,recordsFetchLagMax.value(),EPSILON);
  fetchRecords(tp0,MemoryRecords.EMPTY,Errors.NONE,100L,0);
  assertEquals(100,recordsFetchLagMax.value(),EPSILON);
  KafkaMetric partitionLag=allMetrics.get(partitionLagMetric);
  assertEquals(100,partitionLag.value(),EPSILON);
  MemoryRecordsBuilder builder=MemoryRecords.builder(ByteBuffer.allocate(1024),CompressionType.NONE,TimestampType.CREATE_TIME,0L);
  for (int v=0; v < 3; v++)   builder.appendWithOffset(v,RecordBatch.NO_TIMESTAMP,"key".getBytes(),("value-" + v).getBytes());
  fetchRecords(tp0,builder.build(),Errors.NONE,200L,0);
  assertEquals(197,recordsFetchLagMax.value(),EPSILON);
  assertEquals(197,partitionLag.value(),EPSILON);
  subscriptions.unsubscribe();
  assertFalse(allMetrics.containsKey(partitionLagMetric));
}
