public LRUCacheEntry delete(final String namespace,final Bytes key){
  final NamedCache cache=getCache(namespace);
  if (cache == null) {
    return null;
  }
  return cache.delete(key);
}
