@Override public Map<String,ChannelState> disconnected(){
  return this.disconnected;
}
