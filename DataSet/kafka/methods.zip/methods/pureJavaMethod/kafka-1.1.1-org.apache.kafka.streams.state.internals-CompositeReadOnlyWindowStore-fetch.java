@Override public KeyValueIterator<Windowed<K>,V> fetch(final K from,final K to,final long timeFrom,final long timeTo){
  Objects.requireNonNull(from,"from can't be null");
  Objects.requireNonNull(to,"to can't be null");
  final NextIteratorFunction<Windowed<K>,V,ReadOnlyWindowStore<K,V>> nextIteratorFunction=new NextIteratorFunction<Windowed<K>,V,ReadOnlyWindowStore<K,V>>(){
    @Override public KeyValueIterator<Windowed<K>,V> apply(    final ReadOnlyWindowStore<K,V> store){
      return store.fetch(from,to,timeFrom,timeTo);
    }
  }
;
  return new DelegatingPeekingKeyValueIterator<>(storeName,new CompositeKeyValueIterator<>(provider.stores(storeName,windowStoreType).iterator(),nextIteratorFunction));
}
