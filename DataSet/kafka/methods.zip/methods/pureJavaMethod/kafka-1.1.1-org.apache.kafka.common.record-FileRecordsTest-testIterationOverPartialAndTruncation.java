/** 
 * Test that adding invalid bytes to the end of the log doesn't break iteration
 */
@Test public void testIterationOverPartialAndTruncation() throws IOException {
  testPartialWrite(0,fileRecords);
  testPartialWrite(2,fileRecords);
  testPartialWrite(4,fileRecords);
  testPartialWrite(5,fileRecords);
  testPartialWrite(6,fileRecords);
}
