@Override public void onComplete(ClientResponse response){
  this.response=response;
  pendingCompletion.add(this);
}
