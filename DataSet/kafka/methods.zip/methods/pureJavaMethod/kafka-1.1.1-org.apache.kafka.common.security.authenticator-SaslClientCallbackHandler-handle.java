@Override public void handle(Callback[] callbacks) throws UnsupportedCallbackException {
  for (  Callback callback : callbacks) {
    if (callback instanceof NameCallback) {
      NameCallback nc=(NameCallback)callback;
      if (!isKerberos && subject != null && !subject.getPublicCredentials(String.class).isEmpty()) {
        nc.setName(subject.getPublicCredentials(String.class).iterator().next());
      }
 else       nc.setName(nc.getDefaultName());
    }
 else     if (callback instanceof PasswordCallback) {
      if (!isKerberos && subject != null && !subject.getPrivateCredentials(String.class).isEmpty()) {
        char[] password=subject.getPrivateCredentials(String.class).iterator().next().toCharArray();
        ((PasswordCallback)callback).setPassword(password);
      }
 else {
        String errorMessage="Could not login: the client is being asked for a password, but the Kafka" + " client code does not currently support obtaining a password from the user.";
        if (isKerberos) {
          errorMessage+=" Make sure -Djava.security.auth.login.config property passed to JVM and" + " the client is configured to use a ticket cache (using" + " the JAAS configuration setting 'useTicketCache=true)'. Make sure you are using"+ " FQDN of the Kafka broker you are trying to connect to.";
        }
        throw new UnsupportedCallbackException(callback,errorMessage);
      }
    }
 else     if (callback instanceof RealmCallback) {
      RealmCallback rc=(RealmCallback)callback;
      rc.setText(rc.getDefaultText());
    }
 else     if (callback instanceof AuthorizeCallback) {
      AuthorizeCallback ac=(AuthorizeCallback)callback;
      String authId=ac.getAuthenticationID();
      String authzId=ac.getAuthorizationID();
      ac.setAuthorized(authId.equals(authzId));
      if (ac.isAuthorized())       ac.setAuthorizedID(authzId);
    }
 else     if (callback instanceof ScramExtensionsCallback) {
      ScramExtensionsCallback sc=(ScramExtensionsCallback)callback;
      if (!isKerberos && subject != null && !subject.getPublicCredentials(Map.class).isEmpty()) {
        sc.extensions((Map<String,String>)subject.getPublicCredentials(Map.class).iterator().next());
      }
    }
 else {
      throw new UnsupportedCallbackException(callback,"Unrecognized SASL ClientCallback");
    }
  }
}
