@Test public void shouldKeepTrackOfSize(){
  final LRUCacheEntry value=new LRUCacheEntry(new byte[]{0});
  cache.put(Bytes.wrap(new byte[]{0}),value);
  cache.put(Bytes.wrap(new byte[]{1}),value);
  cache.put(Bytes.wrap(new byte[]{2}),value);
  final long size=cache.sizeInBytes();
  assertEquals((value.size() + 25) * 3,size);
}
