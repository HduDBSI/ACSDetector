public static ConfigDef configDef(){
  int orderInGroup=0;
  return new ConfigDef().define(NAME_CONFIG,Type.STRING,ConfigDef.NO_DEFAULT_VALUE,nonEmptyStringWithoutControlChars(),Importance.HIGH,NAME_DOC,COMMON_GROUP,++orderInGroup,Width.MEDIUM,NAME_DISPLAY).define(CONNECTOR_CLASS_CONFIG,Type.STRING,Importance.HIGH,CONNECTOR_CLASS_DOC,COMMON_GROUP,++orderInGroup,Width.LONG,CONNECTOR_CLASS_DISPLAY).define(TASKS_MAX_CONFIG,Type.INT,TASKS_MAX_DEFAULT,atLeast(TASKS_MIN_CONFIG),Importance.HIGH,TASKS_MAX_DOC,COMMON_GROUP,++orderInGroup,Width.SHORT,TASK_MAX_DISPLAY).define(KEY_CONVERTER_CLASS_CONFIG,Type.CLASS,null,Importance.LOW,KEY_CONVERTER_CLASS_DOC,COMMON_GROUP,++orderInGroup,Width.SHORT,KEY_CONVERTER_CLASS_DISPLAY).define(VALUE_CONVERTER_CLASS_CONFIG,Type.CLASS,null,Importance.LOW,VALUE_CONVERTER_CLASS_DOC,COMMON_GROUP,++orderInGroup,Width.SHORT,VALUE_CONVERTER_CLASS_DISPLAY).define(HEADER_CONVERTER_CLASS_CONFIG,Type.CLASS,HEADER_CONVERTER_CLASS_DEFAULT,Importance.LOW,HEADER_CONVERTER_CLASS_DOC,COMMON_GROUP,++orderInGroup,Width.SHORT,HEADER_CONVERTER_CLASS_DISPLAY).define(TRANSFORMS_CONFIG,Type.LIST,Collections.emptyList(),ConfigDef.CompositeValidator.of(new ConfigDef.NonNullValidator(),new ConfigDef.Validator(){
    @Override public void ensureValid(    String name,    Object value){
      final List<String> transformAliases=(List<String>)value;
      if (transformAliases.size() > new HashSet<>(transformAliases).size()) {
        throw new ConfigException(name,value,"Duplicate alias provided.");
      }
    }
  }
),Importance.LOW,TRANSFORMS_DOC,TRANSFORMS_GROUP,++orderInGroup,Width.LONG,TRANSFORMS_DISPLAY);
}
