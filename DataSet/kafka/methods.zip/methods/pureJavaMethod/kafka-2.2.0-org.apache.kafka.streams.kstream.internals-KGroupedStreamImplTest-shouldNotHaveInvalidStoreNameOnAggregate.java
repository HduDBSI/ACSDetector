@Test(expected=InvalidTopicException.class) public void shouldNotHaveInvalidStoreNameOnAggregate(){
  groupedStream.aggregate(MockInitializer.STRING_INIT,MockAggregator.TOSTRING_ADDER,Materialized.as(INVALID_STORE_NAME));
}
