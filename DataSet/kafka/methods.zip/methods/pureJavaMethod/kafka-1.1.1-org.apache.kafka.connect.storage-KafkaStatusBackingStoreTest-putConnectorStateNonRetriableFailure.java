@Test public void putConnectorStateNonRetriableFailure(){
  KafkaBasedLog<String,byte[]> kafkaBasedLog=mock(KafkaBasedLog.class);
  Converter converter=mock(Converter.class);
  KafkaStatusBackingStore store=new KafkaStatusBackingStore(new MockTime(),converter,STATUS_TOPIC,kafkaBasedLog);
  byte[] value=new byte[0];
  expect(converter.fromConnectData(eq(STATUS_TOPIC),anyObject(Schema.class),anyObject(Struct.class))).andStubReturn(value);
  final Capture<Callback> callbackCapture=newCapture();
  kafkaBasedLog.send(eq("status-connector-conn"),eq(value),capture(callbackCapture));
  expectLastCall().andAnswer(new IAnswer<Void>(){
    @Override public Void answer() throws Throwable {
      callbackCapture.getValue().onCompletion(null,new UnknownServerException());
      return null;
    }
  }
);
  replayAll();
  ConnectorStatus status=new ConnectorStatus(CONNECTOR,ConnectorStatus.State.RUNNING,WORKER_ID,0);
  store.put(status);
  assertEquals(null,store.get(CONNECTOR));
  verifyAll();
}
