private void expectConfigValidation(Connector connectorMock,boolean shouldCreateConnector,Map<String,String>... configs){
  EasyMock.expect(worker.getPlugins()).andReturn(plugins).times(3);
  EasyMock.expect(plugins.compareAndSwapLoaders(connectorMock)).andReturn(delegatingLoader);
  if (shouldCreateConnector) {
    EasyMock.expect(worker.getPlugins()).andReturn(plugins);
    EasyMock.expect(plugins.newConnector(EasyMock.anyString())).andReturn(connectorMock);
  }
  EasyMock.expect(connectorMock.config()).andStubReturn(new ConfigDef());
  for (  Map<String,String> config : configs)   EasyMock.expect(connectorMock.validate(config)).andReturn(new Config(Collections.<ConfigValue>emptyList()));
  EasyMock.expect(Plugins.compareAndSwapLoaders(delegatingLoader)).andReturn(pluginLoader);
}
