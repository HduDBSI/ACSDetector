public GroupMember(String memberId,String clientId,String clientHost,ByteBuffer memberMetadata,ByteBuffer memberAssignment){
  this.memberId=memberId;
  this.clientId=clientId;
  this.clientHost=clientHost;
  this.memberMetadata=memberMetadata;
  this.memberAssignment=memberAssignment;
}
