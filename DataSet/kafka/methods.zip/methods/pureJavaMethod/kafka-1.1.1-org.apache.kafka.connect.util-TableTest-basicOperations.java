@Test public void basicOperations(){
  Table<String,Integer,String> table=new Table<>();
  table.put("foo",5,"bar");
  table.put("foo",6,"baz");
  assertEquals("bar",table.get("foo",5));
  assertEquals("baz",table.get("foo",6));
  Map<Integer,String> row=table.row("foo");
  assertEquals("bar",row.get(5));
  assertEquals("baz",row.get(6));
  assertEquals("bar",table.remove("foo",5));
  assertNull(table.get("foo",5));
  assertEquals("baz",table.remove("foo",6));
  assertNull(table.get("foo",6));
  assertTrue(table.row("foo").isEmpty());
}
