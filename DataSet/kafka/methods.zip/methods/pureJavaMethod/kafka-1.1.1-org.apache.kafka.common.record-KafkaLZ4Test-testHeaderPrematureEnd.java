@Test public void testHeaderPrematureEnd() throws Exception {
  thrown.expect(IOException.class);
  thrown.expectMessage(KafkaLZ4BlockInputStream.PREMATURE_EOS);
  final ByteBuffer buffer=ByteBuffer.allocate(2);
  makeInputStream(buffer);
}
