/** 
 * Should be called before the start of each new transaction. Note that prior to the first invocation of this method, you must invoke  {@link #initTransactions()} exactly one time.
 * @throws IllegalStateException if no transactional.id has been configured or if {@link #initTransactions()}has not yet been invoked
 * @throws ProducerFencedException if another producer with the same transactional.id is active
 * @throws org.apache.kafka.common.errors.UnsupportedVersionException fatal error indicating the brokerdoes not support transactions (i.e. if its version is lower than 0.11.0.0)
 * @throws org.apache.kafka.common.errors.AuthorizationException fatal error indicating that the configuredtransactional.id is not authorized
 * @throws KafkaException if the producer has encountered a previous fatal error or for any other unexpected error
 */
public void beginTransaction() throws ProducerFencedException {
  throwIfNoTransactionManager();
  transactionManager.beginTransaction();
}
