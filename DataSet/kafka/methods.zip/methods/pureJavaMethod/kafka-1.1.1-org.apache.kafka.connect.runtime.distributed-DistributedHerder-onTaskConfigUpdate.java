@Override public void onTaskConfigUpdate(Collection<ConnectorTaskId> tasks){
  log.info("Tasks {} configs updated",tasks);
synchronized (DistributedHerder.this) {
    needsReconfigRebalance=true;
  }
  member.wakeup();
}
