@Test public void shouldGetNextFromStore(){
  final MergedSortedCacheSessionStoreIterator mergeIterator=createIterator(storeKvs,Collections.emptyIterator());
  assertThat(mergeIterator.next(),equalTo(KeyValue.pair(new Windowed<>(storeKey,storeWindow),storeKey.get())));
}
