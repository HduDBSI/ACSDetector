private RequestFuture<ByteBuffer> sendSyncGroupRequest(SyncGroupRequest.Builder requestBuilder){
  if (coordinatorUnknown())   return RequestFuture.coordinatorNotAvailable();
  return client.send(coordinator,requestBuilder).compose(new SyncGroupResponseHandler());
}
