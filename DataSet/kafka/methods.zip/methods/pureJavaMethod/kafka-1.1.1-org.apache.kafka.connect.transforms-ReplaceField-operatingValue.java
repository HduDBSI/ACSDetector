@Override protected Object operatingValue(R record){
  return record.value();
}
