synchronized boolean shouldInjectFailure(){
  numTries++;
  if (numTries == 1) {
    failuresInjected++;
    return true;
  }
  return false;
}
