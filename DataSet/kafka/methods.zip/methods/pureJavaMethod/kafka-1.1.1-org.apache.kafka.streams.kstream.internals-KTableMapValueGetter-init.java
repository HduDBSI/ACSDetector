@Override public void init(final ProcessorContext context){
  parentGetter.init(context);
}
