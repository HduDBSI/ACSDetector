@Override public void close(){
  if (threadProducer != null) {
    try {
      threadProducer.close();
    }
 catch (    final Throwable e) {
      log.error("Failed to close producer due to the following error:",e);
    }
  }
}
