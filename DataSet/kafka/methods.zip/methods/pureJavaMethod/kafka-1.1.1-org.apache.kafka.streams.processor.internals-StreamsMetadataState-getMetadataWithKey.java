/** 
 * Find the  {@link StreamsMetadata}s for a given storeName and key. Note: the key may not exist in the  {@link StateStore}, this method provides a way of finding which  {@link StreamsMetadata} it would exist on.
 * @param storeName   Name of the store
 * @param key         Key to use
 * @param partitioner partitioner to use to find correct partition for key
 * @param < K >         key type
 * @return The {@link StreamsMetadata} for the storeName and key or {@link StreamsMetadata#NOT_AVAILABLE}if streams is (re-)initializing
 */
public synchronized <K>StreamsMetadata getMetadataWithKey(final String storeName,final K key,final StreamPartitioner<? super K,?> partitioner){
  Objects.requireNonNull(storeName,"storeName can't be null");
  Objects.requireNonNull(key,"key can't be null");
  Objects.requireNonNull(partitioner,"partitioner can't be null");
  if (!isInitialized()) {
    return StreamsMetadata.NOT_AVAILABLE;
  }
  if (globalStores.contains(storeName)) {
    if (thisHost == UNKNOWN_HOST) {
      return allMetadata.get(0);
    }
    return myMetadata;
  }
  SourceTopicsInfo sourceTopicsInfo=getSourceTopicsInfo(storeName);
  if (sourceTopicsInfo == null) {
    return null;
  }
  return getStreamsMetadataForKey(storeName,key,partitioner,sourceTopicsInfo);
}
