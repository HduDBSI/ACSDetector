@Test public void testGetOffsetsForTimes(){
  assertTrue(fetcher.offsetsByTimes(new HashMap<TopicPartition,Long>(),100L).isEmpty());
  testGetOffsetsForTimesWithUnknownOffset();
  testGetOffsetsForTimesWithError(Errors.NONE,Errors.NONE,-1L,100L,null,100L);
  testGetOffsetsForTimesWithError(Errors.NONE,Errors.NONE,10L,100L,10L,100L);
  testGetOffsetsForTimesWithError(Errors.NOT_LEADER_FOR_PARTITION,Errors.INVALID_REQUEST,10L,100L,10L,100L);
  testGetOffsetsForTimesWithError(Errors.NONE,Errors.NOT_LEADER_FOR_PARTITION,10L,100L,10L,100L);
  testGetOffsetsForTimesWithError(Errors.NOT_LEADER_FOR_PARTITION,Errors.NONE,10L,100L,10L,100L);
  testGetOffsetsForTimesWithError(Errors.UNKNOWN_TOPIC_OR_PARTITION,Errors.NONE,10L,100L,10L,100L);
  testGetOffsetsForTimesWithError(Errors.UNSUPPORTED_FOR_MESSAGE_FORMAT,Errors.NONE,10L,100L,null,100L);
  testGetOffsetsForTimesWithError(Errors.BROKER_NOT_AVAILABLE,Errors.NONE,10L,100L,10L,100L);
}
