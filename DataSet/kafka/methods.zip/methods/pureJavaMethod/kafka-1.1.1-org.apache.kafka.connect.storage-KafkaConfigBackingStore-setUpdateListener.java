@Override public void setUpdateListener(UpdateListener listener){
  this.updateListener=listener;
}
