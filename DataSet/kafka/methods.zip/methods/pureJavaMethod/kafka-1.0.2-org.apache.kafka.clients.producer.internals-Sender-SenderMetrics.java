public SenderMetrics(SenderMetricsRegistry metrics){
  this.metrics=metrics;
  this.batchSizeSensor=metrics.sensor("batch-size");
  this.batchSizeSensor.add(metrics.batchSizeAvg,new Avg());
  this.batchSizeSensor.add(metrics.batchSizeMax,new Max());
  this.compressionRateSensor=metrics.sensor("compression-rate");
  this.compressionRateSensor.add(metrics.compressionRateAvg,new Avg());
  this.queueTimeSensor=metrics.sensor("queue-time");
  this.queueTimeSensor.add(metrics.recordQueueTimeAvg,new Avg());
  this.queueTimeSensor.add(metrics.recordQueueTimeMax,new Max());
  this.requestTimeSensor=metrics.sensor("request-time");
  this.requestTimeSensor.add(metrics.requestLatencyAvg,new Avg());
  this.requestTimeSensor.add(metrics.requestLatencyMax,new Max());
  this.recordsPerRequestSensor=metrics.sensor("records-per-request");
  this.recordsPerRequestSensor.add(new Meter(metrics.recordSendRate,metrics.recordSendTotal));
  this.recordsPerRequestSensor.add(metrics.recordsPerRequestAvg,new Avg());
  this.retrySensor=metrics.sensor("record-retries");
  this.retrySensor.add(new Meter(metrics.recordRetryRate,metrics.recordRetryTotal));
  this.errorSensor=metrics.sensor("errors");
  this.errorSensor.add(new Meter(metrics.recordErrorRate,metrics.recordErrorTotal));
  this.maxRecordSizeSensor=metrics.sensor("record-size");
  this.maxRecordSizeSensor.add(metrics.recordSizeMax,new Max());
  this.maxRecordSizeSensor.add(metrics.recordSizeAvg,new Avg());
  this.metrics.addMetric(metrics.requestsInFlight,new Measurable(){
    public double measure(    MetricConfig config,    long now){
      return client.inFlightRequestCount();
    }
  }
);
  metrics.addMetric(metrics.metadataAge,new Measurable(){
    public double measure(    MetricConfig config,    long now){
      return (now - metadata.lastSuccessfulUpdate()) / 1000.0;
    }
  }
);
  this.batchSplitSensor=metrics.sensor("batch-split-rate");
  this.batchSplitSensor.add(new Meter(metrics.batchSplitRate,metrics.batchSplitTotal));
}
