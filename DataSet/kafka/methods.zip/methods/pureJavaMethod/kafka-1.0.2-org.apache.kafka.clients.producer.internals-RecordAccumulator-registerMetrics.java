private void registerMetrics(Metrics metrics,String metricGrpName){
  MetricName metricName=metrics.metricName("waiting-threads",metricGrpName,"The number of user threads blocked waiting for buffer memory to enqueue their records");
  Measurable waitingThreads=new Measurable(){
    public double measure(    MetricConfig config,    long now){
      return free.queued();
    }
  }
;
  metrics.addMetric(metricName,waitingThreads);
  metricName=metrics.metricName("buffer-total-bytes",metricGrpName,"The maximum amount of buffer memory the client can use (whether or not it is currently used).");
  Measurable totalBytes=new Measurable(){
    public double measure(    MetricConfig config,    long now){
      return free.totalMemory();
    }
  }
;
  metrics.addMetric(metricName,totalBytes);
  metricName=metrics.metricName("buffer-available-bytes",metricGrpName,"The total amount of buffer memory that is not being used (either unallocated or in the free list).");
  Measurable availableBytes=new Measurable(){
    public double measure(    MetricConfig config,    long now){
      return free.availableMemory();
    }
  }
;
  metrics.addMetric(metricName,availableBytes);
  Sensor bufferExhaustedRecordSensor=metrics.sensor("buffer-exhausted-records");
  MetricName rateMetricName=metrics.metricName("buffer-exhausted-rate",metricGrpName,"The average per-second number of record sends that are dropped due to buffer exhaustion");
  MetricName totalMetricName=metrics.metricName("buffer-exhausted-total",metricGrpName,"The total number of record sends that are dropped due to buffer exhaustion");
  bufferExhaustedRecordSensor.add(new Meter(rateMetricName,totalMetricName));
}
