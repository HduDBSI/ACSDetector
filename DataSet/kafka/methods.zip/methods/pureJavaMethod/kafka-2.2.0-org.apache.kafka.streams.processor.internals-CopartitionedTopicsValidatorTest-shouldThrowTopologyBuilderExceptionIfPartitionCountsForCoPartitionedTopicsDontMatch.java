@Test(expected=TopologyException.class) public void shouldThrowTopologyBuilderExceptionIfPartitionCountsForCoPartitionedTopicsDontMatch(){
  partitions.remove(new TopicPartition("second",0));
  validator.validate(Utils.mkSet("first","second"),Collections.emptyMap(),cluster.withPartitions(partitions));
}
