private void position(long offset){
  if (!hasValidPosition())   throw new IllegalStateException("Cannot set a new position without a valid current position");
  this.position=offset;
}
