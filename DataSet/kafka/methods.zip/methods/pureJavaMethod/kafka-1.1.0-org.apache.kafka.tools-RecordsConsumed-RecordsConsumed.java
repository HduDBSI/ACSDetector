public RecordsConsumed(long count,List<RecordSetSummary> partitionSummaries){
  this.count=count;
  this.partitionSummaries=partitionSummaries;
}
