public T makeNext(){
  if (position < list.size())   return list.get(position++);
 else   return allDone();
}
