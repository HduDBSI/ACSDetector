@Override public Herder.Created<ConnectorInfo> translate(RestClient.HttpResponse<ConnectorInfo> response){
  boolean created=response.status() == 201;
  return new Herder.Created<>(created,response.body());
}
