/** 
 * Equivalent to calling  {@link #get(String)} and casting the result to a Map.
 */
@SuppressWarnings("unchecked") public <K,V>Map<K,V> getMap(String fieldName){
  return (Map<K,V>)getCheckType(fieldName,Schema.Type.MAP);
}
