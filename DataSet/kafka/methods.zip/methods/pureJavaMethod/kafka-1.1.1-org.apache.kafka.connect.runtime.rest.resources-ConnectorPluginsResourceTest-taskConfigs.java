@Override public List<Map<String,String>> taskConfigs(int maxTasks){
  return null;
}
