public Dir createDir(final URL url) throws Exception {
  return emptyVfsDir(url);
}
