public SetCallbackFuture(int numRecords,Callback<Void> callback){
  numLeft=numRecords;
  this.callback=callback;
}
