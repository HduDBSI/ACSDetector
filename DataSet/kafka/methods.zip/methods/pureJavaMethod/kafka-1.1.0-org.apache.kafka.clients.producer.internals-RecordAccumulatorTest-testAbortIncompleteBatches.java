@Test public void testAbortIncompleteBatches() throws Exception {
  long lingerMs=Long.MAX_VALUE;
  int numRecords=100;
  final AtomicInteger numExceptionReceivedInCallback=new AtomicInteger(0);
  final RecordAccumulator accum=createTestRecordAccumulator(128 + DefaultRecordBatch.RECORD_BATCH_OVERHEAD,64 * 1024,CompressionType.NONE,lingerMs);
class TestCallback implements Callback {
    @Override public void onCompletion(    RecordMetadata metadata,    Exception exception){
      assertTrue(exception.getMessage().equals("Producer is closed forcefully."));
      numExceptionReceivedInCallback.incrementAndGet();
    }
  }
  for (int i=0; i < numRecords; i++)   accum.append(new TopicPartition(topic,i % 3),0L,key,value,null,new TestCallback(),maxBlockTimeMs);
  RecordAccumulator.ReadyCheckResult result=accum.ready(cluster,time.milliseconds());
  assertFalse(result.readyNodes.isEmpty());
  Map<Integer,List<ProducerBatch>> drained=accum.drain(cluster,result.readyNodes,Integer.MAX_VALUE,time.milliseconds());
  assertTrue(accum.hasUndrained());
  assertTrue(accum.hasIncomplete());
  int numDrainedRecords=0;
  for (  Map.Entry<Integer,List<ProducerBatch>> drainedEntry : drained.entrySet()) {
    for (    ProducerBatch batch : drainedEntry.getValue()) {
      assertTrue(batch.isClosed());
      assertFalse(batch.produceFuture.completed());
      numDrainedRecords+=batch.recordCount;
    }
  }
  assertTrue(numDrainedRecords > 0 && numDrainedRecords < numRecords);
  accum.abortIncompleteBatches();
  assertEquals(numRecords,numExceptionReceivedInCallback.get());
  assertFalse(accum.hasUndrained());
  assertFalse(accum.hasIncomplete());
}
