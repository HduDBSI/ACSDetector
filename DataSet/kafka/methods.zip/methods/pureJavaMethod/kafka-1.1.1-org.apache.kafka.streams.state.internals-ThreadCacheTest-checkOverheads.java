private void checkOverheads(double entryFactor,double systemFactor,long desiredCacheSize,int keySizeBytes,int valueSizeBytes){
  Runtime runtime=Runtime.getRuntime();
  long numElements=desiredCacheSize / memoryCacheEntrySize(new byte[keySizeBytes],new byte[valueSizeBytes],"");
  System.gc();
  long prevRuntimeMemory=runtime.totalMemory() - runtime.freeMemory();
  ThreadCache cache=new ThreadCache(logContext,desiredCacheSize,new MockStreamsMetrics(new Metrics()));
  long size=cache.sizeBytes();
  assertEquals(size,0);
  for (int i=0; i < numElements; i++) {
    String keyStr="K" + i;
    Bytes key=Bytes.wrap(keyStr.getBytes());
    byte[] value=new byte[valueSizeBytes];
    cache.put(namespace,key,new LRUCacheEntry(value,true,1L,1L,1,""));
  }
  System.gc();
  double ceiling=desiredCacheSize + desiredCacheSize * entryFactor;
  long usedRuntimeMemory=runtime.totalMemory() - runtime.freeMemory() - prevRuntimeMemory;
  assertTrue((double)cache.sizeBytes() <= ceiling);
  assertTrue("Used memory size " + usedRuntimeMemory + " greater than expected "+ cache.sizeBytes() * systemFactor,cache.sizeBytes() * systemFactor >= usedRuntimeMemory);
}
