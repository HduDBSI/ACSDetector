private void removeConnectorTasks(String connName){
  Collection<ConnectorTaskId> tasks=configState.tasks(connName);
  if (!tasks.isEmpty()) {
    worker.stopAndAwaitTasks(tasks);
    configBackingStore.removeTaskConfigs(connName);
  }
}
