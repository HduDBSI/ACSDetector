/** 
 * Produces a string representation containing useful information about a StreamThread, starting with the given indent. This is useful in debugging scenarios.
 * @return A string representation of the StreamThread instance.
 */
public String toString(final String indent){
  return indent + "\tStreamsThread threadId: " + getName()+ "\n"+ taskManager.toString(indent);
}
