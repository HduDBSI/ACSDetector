public Class<C> credentialClass(){
  return credentialClass;
}
