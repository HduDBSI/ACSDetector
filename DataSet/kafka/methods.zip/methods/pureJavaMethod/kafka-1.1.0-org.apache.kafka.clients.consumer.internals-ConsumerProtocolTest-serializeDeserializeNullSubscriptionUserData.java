@Test public void serializeDeserializeNullSubscriptionUserData(){
  Subscription subscription=new Subscription(Arrays.asList("foo","bar"),null);
  ByteBuffer buffer=ConsumerProtocol.serializeSubscription(subscription);
  Subscription parsedSubscription=ConsumerProtocol.deserializeSubscription(buffer);
  assertEquals(subscription.topics(),parsedSubscription.topics());
  assertNull(subscription.userData());
}
