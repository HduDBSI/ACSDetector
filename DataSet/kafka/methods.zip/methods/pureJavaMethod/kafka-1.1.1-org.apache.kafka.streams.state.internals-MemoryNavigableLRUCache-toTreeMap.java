private synchronized TreeMap<K,V> toTreeMap(){
  return new TreeMap<>(this.map);
}
