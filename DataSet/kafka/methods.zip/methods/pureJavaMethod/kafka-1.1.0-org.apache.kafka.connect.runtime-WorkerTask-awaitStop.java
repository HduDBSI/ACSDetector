/** 
 * Wait for this task to finish stopping.
 * @param timeoutMs time in milliseconds to await stop
 * @return true if successful, false if the timeout was reached
 */
public boolean awaitStop(long timeoutMs){
  try {
    return shutdownLatch.await(timeoutMs,TimeUnit.MILLISECONDS);
  }
 catch (  InterruptedException e) {
    return false;
  }
}
