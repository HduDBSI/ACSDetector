public ReplicaNotAvailableException(Throwable cause){
  super(cause);
}
