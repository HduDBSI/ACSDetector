@SuppressWarnings("deprecation") @Override public KTable<Windowed<K>,V> reduce(final Reducer<V> reducer,final SessionWindows sessionWindows,final org.apache.kafka.streams.processor.StateStoreSupplier<SessionStore> storeSupplier){
  Objects.requireNonNull(reducer,"reducer can't be null");
  Objects.requireNonNull(sessionWindows,"sessionWindows can't be null");
  Objects.requireNonNull(storeSupplier,"storeSupplier can't be null");
  final Initializer<V> initializer=new Initializer<V>(){
    @Override public V apply(){
      return null;
    }
  }
;
  final Aggregator<K,V,V> aggregator=new Aggregator<K,V,V>(){
    @Override public V apply(    final K aggKey,    final V value,    final V aggregate){
      if (aggregate == null) {
        return value;
      }
      return reducer.apply(aggregate,value);
    }
  }
;
  final Merger<K,V> sessionMerger=new Merger<K,V>(){
    @Override public V apply(    final K aggKey,    final V aggOne,    final V aggTwo){
      return aggregator.apply(aggKey,aggTwo,aggOne);
    }
  }
;
  return aggregate(initializer,aggregator,sessionMerger,sessionWindows,valSerde,storeSupplier);
}
