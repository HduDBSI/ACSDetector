@Override public void execute(){
  try {
    task.initialize(new WorkerSourceTaskContext(offsetReader));
    task.start(taskConfig);
    log.info("{} Source task finished initialization and start",this);
synchronized (this) {
      if (startedShutdownBeforeStartCompleted) {
        task.stop();
        return;
      }
      finishedStart=true;
    }
    while (!isStopping()) {
      if (shouldPause()) {
        onPause();
        if (awaitUnpause()) {
          onResume();
        }
        continue;
      }
      if (toSend == null) {
        log.trace("{} Nothing to send to Kafka. Polling source for additional records",this);
        long start=time.milliseconds();
        toSend=task.poll();
        if (toSend != null) {
          recordPollReturned(toSend.size(),time.milliseconds() - start);
        }
      }
      if (toSend == null)       continue;
      log.debug("{} About to send " + toSend.size() + " records to Kafka",this);
      if (!sendRecords())       stopRequestedLatch.await(SEND_FAILED_BACKOFF_MS,TimeUnit.MILLISECONDS);
    }
  }
 catch (  InterruptedException e) {
  }
 finally {
    commitOffsets();
  }
}
