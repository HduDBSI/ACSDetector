public Set<TopicPartition> topicPartitions(){
  return topicPartitions;
}
