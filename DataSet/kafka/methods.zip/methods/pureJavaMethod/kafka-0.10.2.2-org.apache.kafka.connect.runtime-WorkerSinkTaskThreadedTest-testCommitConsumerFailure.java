@Test public void testCommitConsumerFailure() throws Exception {
  expectInitializeTask();
  expectPollInitialAssignment();
  Capture<Collection<SinkRecord>> capturedRecords=expectPolls(WorkerConfig.OFFSET_COMMIT_INTERVAL_MS_DEFAULT);
  expectOffsetCommit(1L,null,new Exception(),0,true);
  expectStopTask();
  PowerMock.replayAll();
  workerTask.initialize(TASK_CONFIG);
  workerTask.initializeAndStart();
  workerTask.iteration();
  workerTask.iteration();
  workerTask.iteration();
  assertEquals(1,workerTask.commitFailures());
  assertEquals(false,Whitebox.getInternalState(workerTask,"committing"));
  workerTask.stop();
  workerTask.close();
  PowerMock.verifyAll();
}
