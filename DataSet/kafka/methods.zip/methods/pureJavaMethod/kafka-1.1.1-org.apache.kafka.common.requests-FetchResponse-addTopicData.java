private static void addTopicData(String dest,Queue<Send> sends,Struct topicData){
  String topic=topicData.get(TOPIC_NAME);
  Object[] allPartitionData=topicData.getArray(PARTITIONS_KEY_NAME);
  ByteBuffer buffer=ByteBuffer.allocate(STRING.sizeOf(topic) + 4);
  STRING.write(buffer,topic);
  buffer.putInt(allPartitionData.length);
  buffer.rewind();
  sends.add(new ByteBufferSend(dest,buffer));
  for (  Object partitionData : allPartitionData)   addPartitionData(dest,sends,(Struct)partitionData);
}
