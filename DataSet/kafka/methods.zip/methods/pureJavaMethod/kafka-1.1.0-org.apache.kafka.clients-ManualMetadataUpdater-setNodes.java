public void setNodes(List<Node> nodes){
  this.nodes=nodes;
}
