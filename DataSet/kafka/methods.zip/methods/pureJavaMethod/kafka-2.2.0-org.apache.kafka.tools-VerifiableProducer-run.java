public void run(ThroughputThrottler throttler){
  printJson(new StartupComplete());
  long maxMessages=(this.maxMessages < 0) ? Long.MAX_VALUE : this.maxMessages;
  for (long i=0; i < maxMessages; i++) {
    if (this.stopProducing) {
      break;
    }
    long sendStartMs=System.currentTimeMillis();
    this.send(this.getKey(),this.getValue(i));
    if (throttler.shouldThrottle(i,sendStartMs)) {
      throttler.throttle();
    }
  }
}
