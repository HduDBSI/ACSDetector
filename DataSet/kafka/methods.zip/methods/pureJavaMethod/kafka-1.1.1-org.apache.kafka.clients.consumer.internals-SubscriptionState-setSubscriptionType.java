/** 
 * This method sets the subscription type if it is not already set (i.e. when it is NONE), or verifies that the subscription type is equal to the give type when it is set (i.e. when it is not NONE)
 * @param type The given subscription type
 */
private void setSubscriptionType(SubscriptionType type){
  if (this.subscriptionType == SubscriptionType.NONE)   this.subscriptionType=type;
 else   if (this.subscriptionType != type)   throw new IllegalStateException(SUBSCRIPTION_EXCEPTION_MESSAGE);
}
