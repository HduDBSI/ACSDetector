/** 
 * Get the request queue for the given node
 */
private Deque<NetworkClient.InFlightRequest> requestQueue(String node){
  Deque<NetworkClient.InFlightRequest> reqs=requests.get(node);
  if (reqs == null || reqs.isEmpty())   throw new IllegalStateException("There are no in-flight requests for node " + node);
  return reqs;
}
