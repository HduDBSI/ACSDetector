@Test public void testAggBasic(){
  final StreamsBuilder builder=new StreamsBuilder();
  final String topic1="topic1";
  final MockProcessorSupplier<String,String> proc=new MockProcessorSupplier<>();
  KTable<String,String> table1=builder.table(topic1,consumed);
  KTable<String,String> table2=table1.groupBy(MockMapper.<String,String>noOpKeyValueMapper(),stringSerialzied).aggregate(MockInitializer.STRING_INIT,MockAggregator.TOSTRING_ADDER,MockAggregator.TOSTRING_REMOVER,stringSerde,"topic1-Canonized");
  table2.toStream().process(proc);
  driver.setUp(builder,stateDir,Serdes.String(),Serdes.String());
  driver.process(topic1,"A","1");
  driver.flushState();
  driver.process(topic1,"B","2");
  driver.flushState();
  driver.process(topic1,"A","3");
  driver.flushState();
  driver.process(topic1,"B","4");
  driver.flushState();
  driver.process(topic1,"C","5");
  driver.flushState();
  driver.process(topic1,"D","6");
  driver.flushState();
  driver.process(topic1,"B","7");
  driver.flushState();
  driver.process(topic1,"C","8");
  driver.flushState();
  assertEquals(Utils.mkList("A:0+1","B:0+2","A:0+1-1+3","B:0+2-2+4","C:0+5","D:0+6","B:0+2-2+4-4+7","C:0+5-5+8"),proc.processed);
}
