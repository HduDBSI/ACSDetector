KeyValueStoreType(){
  super(ReadOnlyKeyValueStore.class);
}
