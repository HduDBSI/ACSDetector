@Test public void testSlowTaskStart() throws Exception {
  final CountDownLatch startupLatch=new CountDownLatch(1);
  final CountDownLatch finishStartupLatch=new CountDownLatch(1);
  createWorkerTask();
  sourceTask.initialize(EasyMock.anyObject(SourceTaskContext.class));
  EasyMock.expectLastCall();
  sourceTask.start(TASK_PROPS);
  EasyMock.expectLastCall().andAnswer(new IAnswer<Object>(){
    @Override public Object answer() throws Throwable {
      startupLatch.countDown();
      assertTrue(awaitLatch(finishStartupLatch));
      return null;
    }
  }
);
  statusListener.onStartup(taskId);
  EasyMock.expectLastCall();
  sourceTask.stop();
  EasyMock.expectLastCall();
  expectOffsetFlush(true);
  statusListener.onShutdown(taskId);
  EasyMock.expectLastCall();
  producer.close(EasyMock.anyLong(),EasyMock.anyObject(TimeUnit.class));
  EasyMock.expectLastCall();
  transformationChain.close();
  EasyMock.expectLastCall();
  PowerMock.replayAll();
  workerTask.initialize(TASK_CONFIG);
  Future<?> workerTaskFuture=executor.submit(workerTask);
  assertTrue(awaitLatch(startupLatch));
  workerTask.stop();
  finishStartupLatch.countDown();
  assertTrue(workerTask.awaitStop(1000));
  workerTaskFuture.get();
  PowerMock.verifyAll();
}
