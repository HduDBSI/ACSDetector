private void verifyCanGetByKey(final String[] keys,final Set<KeyValue<String,Long>> expectedWindowState,final Set<KeyValue<String,Long>> expectedCount,final ReadOnlyWindowStore<String,Long> windowStore,final ReadOnlyKeyValueStore<String,Long> myCount) throws InterruptedException {
  final Set<KeyValue<String,Long>> windowState=new TreeSet<>(stringLongComparator);
  final Set<KeyValue<String,Long>> countState=new TreeSet<>(stringLongComparator);
  final long timeout=System.currentTimeMillis() + 30000;
  while ((windowState.size() < keys.length || countState.size() < keys.length) && System.currentTimeMillis() < timeout) {
    Thread.sleep(10);
    for (    final String key : keys) {
      windowState.addAll(fetch(windowStore,key));
      final Long value=myCount.get(key);
      if (value != null) {
        countState.add(new KeyValue<>(key,value));
      }
    }
  }
  assertThat(windowState,equalTo(expectedWindowState));
  assertThat(countState,equalTo(expectedCount));
}
