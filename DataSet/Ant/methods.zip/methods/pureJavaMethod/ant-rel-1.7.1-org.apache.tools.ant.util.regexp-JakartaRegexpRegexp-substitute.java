/** 
 * Perform a substitution on the regular expression.
 * @param input The string to substitute on
 * @param argument The string which defines the substitution
 * @param options The list of options for the match and replace.
 * @return the result of the operation
 * @throws BuildException on error
 */
public String substitute(String input,String argument,int options) throws BuildException {
  Vector v=getGroups(input,options);
  StringBuffer result=new StringBuffer();
  for (int i=0; i < argument.length(); i++) {
    char c=argument.charAt(i);
    if (c == '\\') {
      if (++i < argument.length()) {
        c=argument.charAt(i);
        int value=Character.digit(c,DECIMAL);
        if (value > -1) {
          result.append((String)v.elementAt(value));
        }
 else {
          result.append(c);
        }
      }
 else {
        result.append('\\');
      }
    }
 else {
      result.append(c);
    }
  }
  argument=result.toString();
  RE reg=getCompiledPattern(options);
  int sOptions=getSubsOptions(options);
  return reg.subst(input,argument,sOptions);
}
