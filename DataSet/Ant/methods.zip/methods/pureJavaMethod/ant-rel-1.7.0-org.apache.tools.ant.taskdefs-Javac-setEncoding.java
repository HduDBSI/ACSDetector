/** 
 * Set the Java source file encoding name.
 * @param encoding the source file encoding
 */
public void setEncoding(String encoding){
  this.encoding=encoding;
}
