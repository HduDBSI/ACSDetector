/** 
 * Perform a single step in a recursive depth-first-search traversal of the target dependency tree. <p> The current target is first set to the &quot;visiting&quot; state, and pushed onto the &quot;visiting&quot; stack. <p> An exception is then thrown if any child of the current node is in the visiting state, as that implies a circular dependency. The exception contains details of the cycle, using elements of the &quot;visiting&quot; stack. <p> If any child has not already been &quot;visited&quot;, this method is called recursively on it. <p> The current target is then added to the ordered list of targets. Note that this is performed after the children have been visited in order to get the correct order. The current target is set to the &quot;visited&quot; state. <p> By the time this method returns, the ordered list contains the sequence of targets up to and including the current target.
 * @param root The current target to inspect.Must not be <code>null</code>.
 * @param targetTable A mapping from names to targets (String to Target).Must not be <code>null</code>.
 * @param state   A mapping from target names to states (String to String).The states in question are &quot;VISITING&quot; and &quot;VISITED&quot;. Must not be <code>null</code>.
 * @param visiting A stack of targets which are currently being visited.Must not be <code>null</code>.
 * @param ret     The list to add target names to. This will end upcontaining the complete list of dependencies in dependency order. Must not be <code>null</code>.
 * @exception BuildException if a non-existent target is specified or ifa circular dependency is detected.
 */
private void tsort(final String root,final Hashtable<String,Target> targetTable,final Hashtable<String,String> state,final Stack<String> visiting,final Vector<Target> ret) throws BuildException {
  state.put(root,VISITING);
  visiting.push(root);
  final Target target=targetTable.get(root);
  if (target == null) {
    final StringBuilder sb=new StringBuilder("Target \"");
    sb.append(root);
    sb.append("\" does not exist in the project \"");
    sb.append(name);
    sb.append("\". ");
    visiting.pop();
    if (!visiting.empty()) {
      final String parent=visiting.peek();
      sb.append("It is used from target \"");
      sb.append(parent);
      sb.append("\".");
    }
    throw new BuildException(new String(sb));
  }
  for (  final String cur : Collections.list(target.getDependencies())) {
    final String m=state.get(cur);
    if (m == null) {
      tsort(cur,targetTable,state,visiting,ret);
    }
 else     if (m == VISITING) {
      throw makeCircularException(cur,visiting);
    }
  }
  final String p=visiting.pop();
  if (root != p) {
    throw new BuildException("Unexpected internal error: expected to " + "pop " + root + " but got "+ p);
  }
  state.put(root,VISITED);
  ret.addElement(target);
}
