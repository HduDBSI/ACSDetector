/** 
 * Ensure we have a consistent and legal set of attributes, and set any internal flags necessary based on different combinations  of attributes.
 */
protected void validateAttributes() throws BuildException {
  if (file == null && filesets.size() == 0) {
    throw new BuildException("Specify at least one source - a file or a fileset.");
  }
  if (destFile != null && destDir != null) {
    throw new BuildException("Only one of destfile and destdir may be set.");
  }
  if (destFile == null && destDir == null) {
    throw new BuildException("One of destfile or destdir must be set.");
  }
  if (file != null && file.exists() && file.isDirectory()) {
    throw new BuildException("Use a fileset to copy directories.");
  }
  if (destFile != null && filesets.size() > 0) {
    throw new BuildException("Cannot concatenate multple files into a single file.");
  }
  if (destFile != null) {
    destDir=new File(destFile.getParent());
  }
}
