/** 
 * Runs the task.
 */
public void execute() throws BuildException {
  checkConfiguration();
  FTPClient ftp=null;
  try {
    log("Opening FTP connection to " + server,Project.MSG_VERBOSE);
    ftp=new FTPClient();
    ftp.connect(server,port);
    if (!FTPReply.isPositiveCompletion(ftp.getReplyCode())) {
      throw new BuildException("FTP connection failed: " + ftp.getReplyString());
    }
    log("connected",Project.MSG_VERBOSE);
    log("logging in to FTP server",Project.MSG_VERBOSE);
    if (!ftp.login(userid,password)) {
      throw new BuildException("Could not login to FTP server");
    }
    log("login succeeded",Project.MSG_VERBOSE);
    if (binary) {
      ftp.setFileType(com.oroinc.net.ftp.FTP.IMAGE_FILE_TYPE);
      if (!FTPReply.isPositiveCompletion(ftp.getReplyCode())) {
        throw new BuildException("could not set transfer type: " + ftp.getReplyString());
      }
    }
    if (passive) {
      log("entering passive mode",Project.MSG_VERBOSE);
      ftp.enterLocalPassiveMode();
      if (!FTPReply.isPositiveCompletion(ftp.getReplyCode())) {
        throw new BuildException("could not enter into passive mode: " + ftp.getReplyString());
      }
    }
    if (remotedir != null) {
      log("changing the remote directory",Project.MSG_VERBOSE);
      ftp.changeWorkingDirectory(remotedir);
      if (!FTPReply.isPositiveCompletion(ftp.getReplyCode())) {
        throw new BuildException("could not change remote directory: " + ftp.getReplyString());
      }
    }
    log(ACTION_STRS[action] + " files");
    transferFiles(ftp);
  }
 catch (  IOException ex) {
    throw new BuildException("error during FTP transfer: " + ex);
  }
 finally {
  }
}
