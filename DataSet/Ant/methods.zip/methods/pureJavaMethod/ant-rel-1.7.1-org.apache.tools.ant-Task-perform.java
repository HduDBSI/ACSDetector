/** 
 * Performs this task if it's still valid, or gets a replacement version and performs that otherwise. Performing a task consists of firing a task started event, configuring the task, executing it, and then firing task finished event. If a runtime exception is thrown, the task finished event is still fired, but with the exception as the cause.
 */
public final void perform(){
  if (!invalid) {
    getProject().fireTaskStarted(this);
    Throwable reason=null;
    try {
      maybeConfigure();
      DispatchUtils.execute(this);
    }
 catch (    BuildException ex) {
      if (ex.getLocation() == Location.UNKNOWN_LOCATION) {
        ex.setLocation(getLocation());
      }
      reason=ex;
      throw ex;
    }
catch (    Exception ex) {
      reason=ex;
      BuildException be=new BuildException(ex);
      be.setLocation(getLocation());
      throw be;
    }
catch (    Error ex) {
      reason=ex;
      throw ex;
    }
 finally {
      getProject().fireTaskFinished(this,reason);
    }
  }
 else {
    UnknownElement ue=getReplacement();
    Task task=ue.getTask();
    task.perform();
  }
}
