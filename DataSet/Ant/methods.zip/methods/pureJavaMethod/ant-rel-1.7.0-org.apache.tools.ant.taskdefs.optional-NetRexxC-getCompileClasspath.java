/** 
 * Builds the compilation classpath.  
 */
private String getCompileClasspath(){
  StringBuffer classpath=new StringBuffer();
  classpath.append(destDir.getAbsolutePath());
  if (this.classpath != null) {
    addExistingToClasspath(classpath,this.classpath);
  }
  return classpath.toString();
}
