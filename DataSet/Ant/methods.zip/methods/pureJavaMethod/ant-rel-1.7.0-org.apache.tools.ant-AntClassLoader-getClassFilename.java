/** 
 * Converts the class dot notation to a filesystem equivalent for searching purposes.
 * @param classname The class name in dot format (eg java.lang.Integer).Must not be <code>null</code>.
 * @return the classname in filesystem format (eg java/lang/Integer.class)
 */
private String getClassFilename(String classname){
  return classname.replace('.','/') + ".class";
}
