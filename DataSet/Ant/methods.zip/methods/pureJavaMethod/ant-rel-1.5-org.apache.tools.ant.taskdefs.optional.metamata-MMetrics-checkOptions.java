protected void checkOptions() throws BuildException {
  super.checkOptions();
  if (outFile == null) {
    throw new BuildException("Output XML file must be set via 'tofile' attribute.");
  }
  if (path == null && fileSets.size() == 0) {
    throw new BuildException("Must set either paths (path element) or files (fileset element)");
  }
  if (path != null && fileSets.size() > 0) {
    throw new BuildException("Cannot set paths (path element) and files (fileset element) at the same time");
  }
  tmpFile=createTmpFile();
}
