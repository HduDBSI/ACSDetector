/** 
 * equality method
 * @param obj an <code>Object</code> value
 * @return a <code>boolean</code> value
 */
public boolean equals(Object obj){
  if (obj == null) {
    return false;
  }
  if (obj.getClass() != getClass()) {
    return false;
  }
  Attribute other=(Attribute)obj;
  if (name == null) {
    if (other.name != null) {
      return false;
    }
  }
 else   if (!name.equals(other.name)) {
    return false;
  }
  if (defaultValue == null) {
    if (other.defaultValue != null) {
      return false;
    }
  }
 else   if (!defaultValue.equals(other.defaultValue)) {
    return false;
  }
  return true;
}
