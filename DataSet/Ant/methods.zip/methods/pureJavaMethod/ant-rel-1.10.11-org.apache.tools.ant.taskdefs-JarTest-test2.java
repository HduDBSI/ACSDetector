/** 
 * Expected failure due to nonexistent manifest file
 */
@Test(expected=BuildException.class) public void test2(){
  buildRule.executeTarget("test2");
}
