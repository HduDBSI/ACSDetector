/** 
 * Convert a class name from java source file dot notation to class file slash notation..
 * @param dotName the class name in dot notation (eg. java.lang.Object).
 * @return the class name in slash notation (eg. java/lang/Object).
 */
public static String convertDotName(String dotName){
  return dotName.replace('.','/');
}
