/** 
 * Using the EJB descriptor file name passed from the <code>ejbjar</code> task, this method returns the "basename" which will be used to name the completed JAR file.
 * @param descriptorFileName String representing the file name of an EJBdescriptor to be processed
 * @return                   The "basename" which will be used to name thecompleted JAR file
 */
protected String getJarBaseName(String descriptorFileName){
  String baseName="";
  if (EjbJar.NamingScheme.BASEJARNAME.equals(config.namingScheme.getValue())) {
    String canonicalDescriptor=descriptorFileName.replace('\\','/');
    int index=canonicalDescriptor.lastIndexOf('/');
    if (index != -1) {
      baseName=descriptorFileName.substring(0,index + 1);
    }
    baseName+=config.baseJarName;
  }
 else   if (EjbJar.NamingScheme.DESCRIPTOR.equals(config.namingScheme.getValue())) {
    int lastSeparatorIndex=descriptorFileName.lastIndexOf(File.separator);
    int endBaseName=-1;
    if (lastSeparatorIndex != -1) {
      endBaseName=descriptorFileName.indexOf(config.baseNameTerminator,lastSeparatorIndex);
    }
 else {
      endBaseName=descriptorFileName.indexOf(config.baseNameTerminator);
    }
    if (endBaseName != -1) {
      baseName=descriptorFileName.substring(0,endBaseName);
    }
 else {
      throw new BuildException("Unable to determine jar name from descriptor \"%s\"",descriptorFileName);
    }
  }
 else   if (EjbJar.NamingScheme.DIRECTORY.equals(config.namingScheme.getValue())) {
    File descriptorFile=new File(config.descriptorDir,descriptorFileName);
    String path=descriptorFile.getAbsolutePath();
    int lastSeparatorIndex=path.lastIndexOf(File.separator);
    if (lastSeparatorIndex == -1) {
      throw new BuildException("Unable to determine directory name holding descriptor");
    }
    String dirName=path.substring(0,lastSeparatorIndex);
    int dirSeparatorIndex=dirName.lastIndexOf(File.separator);
    if (dirSeparatorIndex != -1) {
      dirName=dirName.substring(dirSeparatorIndex + 1);
    }
    baseName=dirName;
  }
 else   if (EjbJar.NamingScheme.EJB_NAME.equals(config.namingScheme.getValue())) {
    baseName=handler.getEjbName();
  }
  return baseName;
}
