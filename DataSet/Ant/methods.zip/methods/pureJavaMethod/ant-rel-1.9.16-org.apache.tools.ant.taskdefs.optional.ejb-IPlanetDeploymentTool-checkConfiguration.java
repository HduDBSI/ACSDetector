/** 
 * Verifies that the user selections are valid.
 * @param descriptorFileName String representing the file name of an EJBdescriptor to be processed
 * @param saxParser          SAXParser which may be used to parse the XMLdescriptor
 * @throws BuildException If the user selections are invalid.
 */
@Override protected void checkConfiguration(String descriptorFileName,SAXParser saxParser) throws BuildException {
  int startOfName=descriptorFileName.lastIndexOf(File.separatorChar) + 1;
  String stdXml=descriptorFileName.substring(startOfName);
  if (stdXml.equals(EJB_DD) && (getConfig().baseJarName == null)) {
    String msg="No name specified for the completed JAR file.  The EJB" + " descriptor should be prepended with the JAR " + "name or it should be specified using the "+ "attribute \"basejarname\" in the \"ejbjar\" task.";
    throw new BuildException(msg,getLocation());
  }
  File iasDescriptor=new File(getConfig().descriptorDir,getIasDescriptorName());
  if ((!iasDescriptor.exists()) || (!iasDescriptor.isFile())) {
    String msg="The iAS-specific EJB descriptor (" + iasDescriptor + ") was not found.";
    throw new BuildException(msg,getLocation());
  }
  if ((iashome != null) && (!iashome.isDirectory())) {
    String msg="If \"iashome\" is specified, it must be a valid " + "directory (it was set to " + iashome + ").";
    throw new BuildException(msg,getLocation());
  }
}
