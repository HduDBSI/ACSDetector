/** 
 * read a constant pool entry from a class stream.
 * @param cpStream the DataInputStream which contains the constant poolentry to be read.
 * @exception IOException if there is a problem reading the entry fromthe stream.
 */
public void read(DataInputStream cpStream) throws IOException {
  classIndex=cpStream.readUnsignedShort();
  nameAndTypeIndex=cpStream.readUnsignedShort();
}
