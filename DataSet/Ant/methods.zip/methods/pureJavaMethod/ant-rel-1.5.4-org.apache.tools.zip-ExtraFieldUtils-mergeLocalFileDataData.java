/** 
 * Merges the local file data fields of the given ZipExtraFields.
 * @since 1.1
 */
public static byte[] mergeLocalFileDataData(ZipExtraField[] data){
  int sum=4 * data.length;
  for (int i=0; i < data.length; i++) {
    sum+=data[i].getLocalFileDataLength().getValue();
  }
  byte[] result=new byte[sum];
  int start=0;
  for (int i=0; i < data.length; i++) {
    System.arraycopy(data[i].getHeaderId().getBytes(),0,result,start,2);
    System.arraycopy(data[i].getLocalFileDataLength().getBytes(),0,result,start + 2,2);
    byte[] local=data[i].getLocalFileDataData();
    System.arraycopy(local,0,result,start + 4,local.length);
    start+=(local.length + 4);
  }
  return result;
}
