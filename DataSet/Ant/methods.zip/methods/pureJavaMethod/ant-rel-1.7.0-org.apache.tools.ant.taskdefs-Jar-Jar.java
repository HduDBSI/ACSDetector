/** 
 * constructor 
 */
public Jar(){
  super();
  archiveType="jar";
  emptyBehavior="create";
  setEncoding("UTF8");
  rootEntries=new Vector();
}
