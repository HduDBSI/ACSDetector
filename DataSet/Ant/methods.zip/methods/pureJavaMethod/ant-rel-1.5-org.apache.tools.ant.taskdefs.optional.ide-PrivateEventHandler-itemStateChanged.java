/** 
 * ItemListener method
 */
public void itemStateChanged(ItemEvent e){
  try {
    if (e.getSource() == VAJAntToolGUI.this.getTargetList()) {
      getBuildButton().setEnabled(true);
    }
    if (e.getSource() == VAJAntToolGUI.this.getMessageOutputLevelChoice()) {
      getBuildInfo().setOutputMessageLevel(getMessageOutputLevelChoice().getSelectedIndex());
    }
    if (e.getSource() == VAJAntToolGUI.this.getTargetList()) {
      getBuildInfo().setTarget(getTargetList().getSelectedItem());
    }
  }
 catch (  Throwable exc) {
    handleException(exc);
  }
}
