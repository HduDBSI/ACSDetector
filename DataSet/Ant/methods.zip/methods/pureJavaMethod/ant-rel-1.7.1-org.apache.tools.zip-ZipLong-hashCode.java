/** 
 * Override to make two instances with same value equal.
 * @return the value stored in the ZipLong
 * @since 1.1
 */
public int hashCode(){
  return (int)value;
}
