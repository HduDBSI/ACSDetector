/** 
 * If true, then fail if the command exits with a returncode other than zero.
 * @param fail if true fail the build when the command exits with anonzero returncode.
 */
public void setFailonerror(boolean fail){
  failOnError=fail;
  incompatibleWithSpawn|=fail;
}
