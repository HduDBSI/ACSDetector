/** 
 * Create a reference to a named ID in a particular project.
 * @param p the project this reference is associated with
 * @param id the name of this reference
 * @since Ant 1.6.3
 */
public Reference(Project p,String id){
  setRefId(id);
  setProject(p);
}
