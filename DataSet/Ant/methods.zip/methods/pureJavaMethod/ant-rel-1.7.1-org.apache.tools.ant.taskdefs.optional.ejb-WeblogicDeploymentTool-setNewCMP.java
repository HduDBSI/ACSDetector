/** 
 * If this is set to true, the new method for locating CMP descriptors will be used; optional, default false. <P> The old CMP scheme locates the weblogic CMP descriptor based on the naming convention where the weblogic CMP file is expected to be named with the bean name as the prefix. Under this scheme the name of the CMP descriptor does not match the name actually used in the main weblogic EJB descriptor. Also, descriptors which contain multiple CMP references could not be used.
 * @param newCMP a <code>boolean</code> value.
 */
public void setNewCMP(boolean newCMP){
  this.newCMP=newCMP;
}
