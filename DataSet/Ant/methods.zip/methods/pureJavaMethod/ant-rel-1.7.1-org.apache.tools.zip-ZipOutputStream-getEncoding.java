/** 
 * The encoding to use for filenames and the file comment.
 * @return null if using the platform's default character encoding.
 * @since 1.3
 */
public String getEncoding(){
  return encoding;
}
