/** 
 * Create a new Ant project.
 */
public Project(){
  inputHandler=new DefaultInputHandler();
}
