/** 
 * Set a multiline message.
 * @param msg the CDATA text to append to the output text
 */
public void addText(String msg){
  message+=getProject().replaceProperties(msg);
}
