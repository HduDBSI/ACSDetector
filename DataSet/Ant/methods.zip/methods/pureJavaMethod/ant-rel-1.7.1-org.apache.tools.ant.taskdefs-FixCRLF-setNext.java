public void setNext(int next){
  this.next=next;
}
