/** 
 * Set the directory where the cleartool executable is located.
 * @param dir the directory containing the cleartool executable
 */
public final void setClearToolDir(String dir){
  mClearToolDir=FileUtils.translatePath(dir);
}
