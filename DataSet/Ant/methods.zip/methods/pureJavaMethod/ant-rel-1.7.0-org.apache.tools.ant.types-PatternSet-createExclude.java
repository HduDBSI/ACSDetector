/** 
 * add a name entry on the exclude list
 * @return a nested exclude element to be configured.
 */
public NameEntry createExclude(){
  if (isReference()) {
    throw noChildrenAllowed();
  }
  return addPatternToList(excludeList);
}
