public void setOutput(java.io.OutputStream out){
}
