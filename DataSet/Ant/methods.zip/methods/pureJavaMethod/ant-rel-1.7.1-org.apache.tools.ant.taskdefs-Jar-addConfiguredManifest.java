/** 
 * Allows the manifest for the archive file to be provided inline in the build file rather than in an external file.
 * @param newManifest an embedded manifest element
 * @throws ManifestException on error
 */
public void addConfiguredManifest(Manifest newManifest) throws ManifestException {
  if (configuredManifest == null) {
    configuredManifest=newManifest;
  }
 else {
    configuredManifest.merge(newManifest);
  }
  savedConfiguredManifest=configuredManifest;
}
