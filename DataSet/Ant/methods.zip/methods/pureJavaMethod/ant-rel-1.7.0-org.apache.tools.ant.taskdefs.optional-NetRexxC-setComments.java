/** 
 * Set whether comments are passed through to the generated java source. Valid true values are "on" or "true". Anything else sets the flag to false. The default value is false
 * @param comments a <code>boolean</code> value.
 */
public void setComments(boolean comments){
  this.comments=comments;
}
