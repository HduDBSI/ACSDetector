/** 
 * Executes the task.
 */
public void execute() throws BuildException {
  if (srcDir == null) {
    throw new BuildException("srcdir attribute must be set!");
  }
  if (!srcDir.exists()) {
    throw new BuildException("srcdir does not exist!");
  }
  if (!srcDir.isDirectory()) {
    throw new BuildException("srcdir is not a directory!");
  }
  if (destDir != null) {
    if (!destDir.exists()) {
      throw new BuildException("destdir does not exist!");
    }
    if (!destDir.isDirectory()) {
      throw new BuildException("destdir is not a directory!");
    }
  }
  log("options:" + " cr=" + (addcr == -1 ? "add" : addcr == 0 ? "asis" : "remove") + " tab="+ (addtab == -1 ? "add" : addtab == 0 ? "asis" : "remove")+ " eof="+ (ctrlz == -1 ? "add" : ctrlz == 0 ? "asis" : "remove")+ " tablength="+ tablength,Project.MSG_VERBOSE);
  DirectoryScanner ds=super.getDirectoryScanner(srcDir);
  String[] files=ds.getIncludedFiles();
  for (int i=0; i < files.length; i++) {
    File srcFile=new File(srcDir,files[i]);
    int count=(int)srcFile.length();
    byte indata[]=new byte[count];
    try {
      FileInputStream inStream=new FileInputStream(srcFile);
      inStream.read(indata);
      inStream.close();
    }
 catch (    IOException e) {
      throw new BuildException(e);
    }
    int cr=0;
    int lf=0;
    int tab=0;
    for (int k=0; k < count; k++) {
      byte c=indata[k];
      if (c == '\r')       cr++;
      if (c == '\n')       lf++;
      if (c == '\t')       tab++;
    }
    boolean eof=((count > 0) && (indata[count - 1] == 0x1A));
    log(srcFile + ": size=" + count+ " cr="+ cr+ " lf="+ lf+ " tab="+ tab+ " eof="+ eof,Project.MSG_VERBOSE);
    int outsize=count;
    if (addcr != 0)     outsize-=cr;
    if (addcr == +1)     outsize+=lf;
    if (addtab == -1)     outsize+=tab * (tablength - 1);
    if (ctrlz == +1)     outsize+=1;
    byte outdata[]=new byte[outsize];
    int o=0;
    int line=o;
    int col=0;
    for (int k=0; k < count; k++) {
switch (indata[k]) {
case (byte)' ':
        if (addtab == 0)         outdata[o++]=(byte)' ';
      col++;
    break;
case (byte)'\t':
  if (addtab == 0) {
    outdata[o++]=(byte)'\t';
    col++;
  }
 else {
    col=(col | (tablength - 1)) + 1;
  }
break;
case (byte)'\r':
if (addcr == 0) {
outdata[o++]=(byte)'\r';
col++;
}
break;
case (byte)'\n':
if (addcr == +1) outdata[o++]=(byte)'\r';
outdata[o++]=(byte)'\n';
line=o;
col=0;
break;
default :
if (addtab > 0 && o + 1 < line + col) {
int diff=o - line;
while ((diff | (tablength - 1)) < col) {
outdata[o++]=(byte)'\t';
line-=(tablength - 1) - (diff & (tablength - 1));
diff=o - line;
}
;
}
;
while (o < line + col) outdata[o++]=(byte)' ';
outdata[o++]=indata[k];
col++;
}
}
if (ctrlz == +1) {
if (outdata[o - 1] != 0x1A) outdata[o++]=0x1A;
}
 else if (ctrlz == -1) {
if (o > 2 && outdata[o - 1] == 0x0A && outdata[o - 2] == 0x1A) o--;
if (o > 1 && outdata[o - 1] == 0x1A) o--;
}
try {
File destFile=srcFile;
if (destDir != null) destFile=new File(destDir,files[i]);
FileOutputStream outStream=new FileOutputStream(destFile);
outStream.write(outdata,0,o);
outStream.close();
}
 catch (IOException e) {
throw new BuildException(e);
}
}
}
