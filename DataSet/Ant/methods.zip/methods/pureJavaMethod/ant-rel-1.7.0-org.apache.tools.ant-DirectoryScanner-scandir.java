/** 
 * Scan the given directory for files and directories. Found files and directories are placed in their respective collections, based on the matching of includes, excludes, and the selectors.  When a directory is found, it is scanned recursively.
 * @param dir   The directory to scan. Must not be <code>null</code>.
 * @param vpath The path relative to the base directory (needed toprevent problems with an absolute path when using dir). Must not be <code>null</code>.
 * @param fast  Whether or not this call is part of a fast scan.
 * @see #filesIncluded
 * @see #filesNotIncluded
 * @see #filesExcluded
 * @see #dirsIncluded
 * @see #dirsNotIncluded
 * @see #dirsExcluded
 * @see #slowScan
 */
protected void scandir(File dir,String vpath,boolean fast){
  if (dir == null) {
    throw new BuildException("dir must not be null.");
  }
 else   if (!dir.exists()) {
    throw new BuildException(dir + " doesn't exist.");
  }
 else   if (!dir.isDirectory()) {
    throw new BuildException(dir + " is not a directory.");
  }
  if (fast && hasBeenScanned(vpath)) {
    return;
  }
  String[] newfiles=dir.list();
  if (newfiles == null) {
    throw new BuildException("IO error scanning directory '" + dir.getAbsolutePath() + "'");
  }
  if (!followSymlinks) {
    Vector noLinks=new Vector();
    for (int i=0; i < newfiles.length; i++) {
      try {
        if (FILE_UTILS.isSymbolicLink(dir,newfiles[i])) {
          String name=vpath + newfiles[i];
          File file=new File(dir,newfiles[i]);
          (file.isDirectory() ? dirsExcluded : filesExcluded).addElement(name);
        }
 else {
          noLinks.addElement(newfiles[i]);
        }
      }
 catch (      IOException ioe) {
        String msg="IOException caught while checking " + "for links, couldn't get canonical path!";
        System.err.println(msg);
        noLinks.addElement(newfiles[i]);
      }
    }
    newfiles=(String[])(noLinks.toArray(new String[noLinks.size()]));
  }
  for (int i=0; i < newfiles.length; i++) {
    String name=vpath + newfiles[i];
    File file=new File(dir,newfiles[i]);
    if (file.isDirectory()) {
      if (isIncluded(name)) {
        accountForIncludedDir(name,file,fast);
      }
 else {
        everythingIncluded=false;
        dirsNotIncluded.addElement(name);
        if (fast && couldHoldIncluded(name)) {
          scandir(file,name + File.separator,fast);
        }
      }
      if (!fast) {
        scandir(file,name + File.separator,fast);
      }
    }
 else     if (file.isFile()) {
      if (isIncluded(name)) {
        accountForIncludedFile(name,file);
      }
 else {
        everythingIncluded=false;
        filesNotIncluded.addElement(name);
      }
    }
  }
}
