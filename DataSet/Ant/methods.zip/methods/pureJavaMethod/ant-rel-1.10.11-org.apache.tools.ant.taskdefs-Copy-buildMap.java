/** 
 * Create a map of resources to copy.
 * @param fromResources  The source resources.
 * @param toDir   the destination directory.
 * @param mapper  a <code>FileNameMapper</code> value.
 * @return a map of source resource to array of destination files.
 * @since Ant 1.7
 */
protected Map<Resource,String[]> buildMap(final Resource[] fromResources,final File toDir,final FileNameMapper mapper){
  final Map<Resource,String[]> map=new HashMap<>();
  Resource[] toCopy;
  if (forceOverwrite) {
    final List<Resource> v=new ArrayList<>();
    for (    Resource rc : fromResources) {
      if (mapper.mapFileName(rc.getName()) != null) {
        v.add(rc);
      }
    }
    toCopy=v.toArray(new Resource[v.size()]);
  }
 else {
    toCopy=ResourceUtils.selectOutOfDateSources(this,fromResources,mapper,name -> new FileResource(toDir,name),granularity);
  }
  for (  Resource rc : toCopy) {
    final String[] mappedFiles=mapper.mapFileName(rc.getName());
    if (mappedFiles == null || mappedFiles.length == 0) {
      throw new BuildException("Can't copy a resource without a" + " name if the mapper doesn't" + " provide one.");
    }
    if (!enableMultipleMappings) {
      map.put(rc,new String[]{new File(toDir,mappedFiles[0]).getAbsolutePath()});
    }
 else {
      for (int k=0; k < mappedFiles.length; k++) {
        mappedFiles[k]=new File(toDir,mappedFiles[k]).getAbsolutePath();
      }
      map.put(rc,mappedFiles);
    }
  }
  return map;
}
