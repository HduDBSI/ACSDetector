@Test public void testNofork(){
  assumeFalse("ran Ant tests with -ea and this would fail spuriously",AssertionsTest.class.desiredAssertionStatus());
  buildRule.executeTarget("test-nofork");
  assertThat(buildRule.getLog(),containsString("Assertion statements are currently ignored in non-forked mode"));
}
