/** 
 * Load the sql file and then execute it
 * @throws BuildException on error.
 */
public void execute() throws BuildException {
  Vector savedTransaction=(Vector)transactions.clone();
  String savedSqlCommand=sqlCommand;
  sqlCommand=sqlCommand.trim();
  try {
    if (srcFile == null && sqlCommand.length() == 0 && resources.size() == 0) {
      if (transactions.size() == 0) {
        throw new BuildException("Source file or resource " + "collection, " + "transactions or sql statement "+ "must be set!",getLocation());
      }
    }
    if (srcFile != null && !srcFile.exists()) {
      throw new BuildException("Source file does not exist!",getLocation());
    }
    Iterator iter=resources.iterator();
    while (iter.hasNext()) {
      Resource r=(Resource)iter.next();
      Transaction t=createTransaction();
      t.setSrcResource(r);
    }
    Transaction t=createTransaction();
    t.setSrc(srcFile);
    t.addText(sqlCommand);
    conn=getConnection();
    if (!isValidRdbms(conn)) {
      return;
    }
    try {
      statement=conn.createStatement();
      statement.setEscapeProcessing(escapeProcessing);
      PrintStream out=System.out;
      try {
        if (output != null) {
          log("Opening PrintStream to output file " + output,Project.MSG_VERBOSE);
          out=new PrintStream(new BufferedOutputStream(new FileOutputStream(output.getAbsolutePath(),append)));
        }
        for (Enumeration e=transactions.elements(); e.hasMoreElements(); ) {
          ((Transaction)e.nextElement()).runTransaction(out);
          if (!isAutocommit()) {
            log("Committing transaction",Project.MSG_VERBOSE);
            conn.commit();
          }
        }
      }
  finally {
        if (out != null && out != System.out) {
          out.close();
        }
      }
    }
 catch (    IOException e) {
      closeQuietly();
      throw new BuildException(e,getLocation());
    }
catch (    SQLException e) {
      closeQuietly();
      throw new BuildException(e,getLocation());
    }
 finally {
      try {
        if (statement != null) {
          statement.close();
        }
        if (conn != null) {
          conn.close();
        }
      }
 catch (      SQLException ex) {
      }
    }
    log(goodSql + " of " + totalSql+ " SQL statements executed successfully");
  }
  finally {
    transactions=savedTransaction;
    sqlCommand=savedSqlCommand;
  }
}
