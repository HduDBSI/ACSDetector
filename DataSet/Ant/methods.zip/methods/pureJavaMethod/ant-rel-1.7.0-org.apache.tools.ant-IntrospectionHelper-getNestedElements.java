/** 
 * Returns an enumeration of the names of the nested elements supported by the introspected class.
 * @return an enumeration of the names of the nested elements supportedby the introspected class.
 * @see #getNestedElementMap
 */
public Enumeration getNestedElements(){
  return nestedTypes.keys();
}
