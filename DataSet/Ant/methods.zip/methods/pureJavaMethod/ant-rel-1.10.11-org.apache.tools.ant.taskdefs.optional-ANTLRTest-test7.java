/** 
 * Expected failure due to inability to determine generated class
 */
@Test(expected=BuildException.class) public void test7(){
  buildRule.executeTarget("test7");
}
