protected void zipFile(File file,ZipOutputStream zOut,String vPath) throws IOException {
  if (!vPath.equalsIgnoreCase("WEB-INF/web.xml")) {
    super.zipFile(file,zOut,vPath);
  }
 else {
    log("Warning: selected " + archiveType + " files include a WEB-INF/web.xml which will be ignored "+ "(please use webxml attribute to "+ archiveType+ " task)",Project.MSG_WARN);
  }
}
