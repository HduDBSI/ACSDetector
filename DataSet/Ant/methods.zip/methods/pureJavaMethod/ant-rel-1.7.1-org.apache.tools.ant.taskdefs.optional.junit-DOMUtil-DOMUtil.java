/** 
 * unused constructor 
 */
private DOMUtil(){
}
