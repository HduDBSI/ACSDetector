/** 
 * Install a handler for the error stream of the subprocess.
 * @param is input stream to read from the error stream from the subprocess
 * @throws IOException on error
 */
void setProcessErrorStream(InputStream is) throws IOException ;
