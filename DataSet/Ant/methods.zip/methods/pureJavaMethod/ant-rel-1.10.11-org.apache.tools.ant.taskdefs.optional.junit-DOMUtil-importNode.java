/** 
 * Simple tree walker that will clone recursively a node. This is to avoid using parser-specific API such as Sun's <code>changeNodeOwner</code> when we are dealing with DOM L1 implementations since <code>cloneNode(boolean)</code> will not change the owner document. <code>changeNodeOwner</code> is much faster and avoid the costly cloning process. <code>importNode</code> is in the DOM L2 interface.
 * @param parent  the node parent to which we should do the import to.
 * @param child   the node to clone recursively. Its clone will beappended to <code>parent</code>.
 * @return  the cloned node that is appended to <code>parent</code>
 */
public static Node importNode(Node parent,Node child){
  final Document doc=parent.getOwnerDocument();
  Node copy;
switch (child.getNodeType()) {
case Node.CDATA_SECTION_NODE:
    copy=doc.createCDATASection(((CDATASection)child).getData());
  break;
case Node.COMMENT_NODE:
copy=doc.createComment(((Comment)child).getData());
break;
case Node.DOCUMENT_FRAGMENT_NODE:
copy=doc.createDocumentFragment();
break;
case Node.ELEMENT_NODE:
final Element elem=doc.createElement(((Element)child).getTagName());
copy=elem;
final NamedNodeMap attributes=child.getAttributes();
if (attributes != null) {
final int size=attributes.getLength();
for (int i=0; i < size; i++) {
final Attr attr=(Attr)attributes.item(i);
elem.setAttribute(attr.getName(),attr.getValue());
}
}
break;
case Node.ENTITY_REFERENCE_NODE:
copy=doc.createEntityReference(child.getNodeName());
break;
case Node.PROCESSING_INSTRUCTION_NODE:
final ProcessingInstruction pi=(ProcessingInstruction)child;
copy=doc.createProcessingInstruction(pi.getTarget(),pi.getData());
break;
case Node.TEXT_NODE:
copy=doc.createTextNode(((Text)child).getData());
break;
default :
throw new IllegalStateException("Invalid node type: " + child.getNodeType());
}
try {
final NodeList children=child.getChildNodes();
if (children != null) {
final int size=children.getLength();
for (int i=0; i < size; i++) {
final Node newChild=children.item(i);
if (newChild != null) {
importNode(copy,newChild);
}
}
}
}
 catch (DOMException ignored) {
}
parent.appendChild(copy);
return copy;
}
