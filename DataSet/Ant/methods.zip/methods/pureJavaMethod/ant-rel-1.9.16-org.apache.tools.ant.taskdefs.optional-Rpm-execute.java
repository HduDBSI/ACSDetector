/** 
 * Execute the task
 * @throws BuildException is there is a problem in the task execution.
 */
public void execute() throws BuildException {
  Commandline toExecute=new Commandline();
  toExecute.setExecutable(rpmBuildCommand == null ? guessRpmBuildCommand() : rpmBuildCommand);
  if (topDir != null) {
    toExecute.createArgument().setValue("--define");
    toExecute.createArgument().setValue("_topdir " + topDir);
  }
  toExecute.createArgument().setLine(command);
  if (cleanBuildDir) {
    toExecute.createArgument().setValue("--clean");
  }
  if (removeSpec) {
    toExecute.createArgument().setValue("--rmspec");
  }
  if (removeSource) {
    toExecute.createArgument().setValue("--rmsource");
  }
  toExecute.createArgument().setValue("SPECS/" + specFile);
  ExecuteStreamHandler streamhandler=null;
  OutputStream outputstream=null;
  OutputStream errorstream=null;
  if (error == null && output == null) {
    if (!quiet) {
      streamhandler=new LogStreamHandler(this,Project.MSG_INFO,Project.MSG_WARN);
    }
 else {
      streamhandler=new LogStreamHandler(this,Project.MSG_DEBUG,Project.MSG_DEBUG);
    }
  }
 else {
    if (output != null) {
      FileOutputStream fos=null;
      try {
        fos=new FileOutputStream(output);
        BufferedOutputStream bos=new BufferedOutputStream(fos);
        outputstream=new PrintStream(bos);
      }
 catch (      IOException e) {
        FileUtils.close(fos);
        throw new BuildException(e,getLocation());
      }
    }
 else     if (!quiet) {
      outputstream=new LogOutputStream(this,Project.MSG_INFO);
    }
 else {
      outputstream=new LogOutputStream(this,Project.MSG_DEBUG);
    }
    if (error != null) {
      FileOutputStream fos=null;
      try {
        fos=new FileOutputStream(error);
        BufferedOutputStream bos=new BufferedOutputStream(fos);
        errorstream=new PrintStream(bos);
      }
 catch (      IOException e) {
        FileUtils.close(fos);
        throw new BuildException(e,getLocation());
      }
    }
 else     if (!quiet) {
      errorstream=new LogOutputStream(this,Project.MSG_WARN);
    }
 else {
      errorstream=new LogOutputStream(this,Project.MSG_DEBUG);
    }
    streamhandler=new PumpStreamHandler(outputstream,errorstream);
  }
  Execute exe=getExecute(toExecute,streamhandler);
  try {
    log("Building the RPM based on the " + specFile + " file");
    int returncode=exe.execute();
    if (Execute.isFailure(returncode)) {
      String msg="'" + toExecute.getExecutable() + "' failed with exit code "+ returncode;
      if (failOnError) {
        throw new BuildException(msg);
      }
      log(msg,Project.MSG_ERR);
    }
  }
 catch (  IOException e) {
    throw new BuildException(e,getLocation());
  }
 finally {
    FileUtils.close(outputstream);
    FileUtils.close(errorstream);
  }
}
