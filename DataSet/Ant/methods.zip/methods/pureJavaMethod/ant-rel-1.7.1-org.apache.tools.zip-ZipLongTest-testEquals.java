/** 
 * Test the contract of the equals method.
 */
public void testEquals(){
  ZipLong zl=new ZipLong(0x12345678);
  ZipLong zl2=new ZipLong(0x12345678);
  ZipLong zl3=new ZipLong(0x87654321);
  assertTrue("reflexive",zl.equals(zl));
  assertTrue("works",zl.equals(zl2));
  assertTrue("works, part two",!zl.equals(zl3));
  assertTrue("symmetric",zl2.equals(zl));
  assertTrue("null handling",!zl.equals(null));
  assertTrue("non ZipLong handling",!zl.equals(new Integer(0x1234)));
}
