/** 
 * Verifies that the EJB is valid--if it is invalid, an exception is thrown
 * @param buildDir The directory where the EJB remote interface, homeinterface, and implementation class must be found.
 * @throws EjbcException If the EJB is invalid.
 */
private void checkConfiguration(File buildDir) throws EjbcException {
  if (home == null) {
    throw new EjbcException("A home interface was not found " + "for the " + name + " EJB.");
  }
  if (remote == null) {
    throw new EjbcException("A remote interface was not found " + "for the " + name + " EJB.");
  }
  if (implementation == null) {
    throw new EjbcException("An EJB implementation class was not " + "found for the " + name + " EJB.");
  }
  if ((!beantype.equals(ENTITY_BEAN)) && (!beantype.equals(STATELESS_SESSION)) && (!beantype.equals(STATEFUL_SESSION))) {
    throw new EjbcException("The beantype found (" + beantype + ") "+ "isn't valid in the "+ name+ " EJB.");
  }
  if (cmp && (!beantype.equals(ENTITY_BEAN))) {
    System.out.println("CMP stubs and skeletons may not be generated" + " for a Session Bean -- the \"cmp\" attribute will be" + " ignoredfor the " + name + " EJB.");
  }
  if (hasession && (!beantype.equals(STATEFUL_SESSION))) {
    System.out.println("Highly available stubs and skeletons may " + "only be generated for a Stateful Session Bean -- the " + "\"hasession\" attribute will be ignored for the " + name + " EJB.");
  }
  if (!remote.getClassFile(buildDir).exists()) {
    throw new EjbcException("The remote interface " + remote.getQualifiedClassName() + " could not be "+ "found.");
  }
  if (!home.getClassFile(buildDir).exists()) {
    throw new EjbcException("The home interface " + home.getQualifiedClassName() + " could not be "+ "found.");
  }
  if (!implementation.getClassFile(buildDir).exists()) {
    throw new EjbcException("The EJB implementation class " + implementation.getQualifiedClassName() + " could "+ "not be found.");
  }
}
