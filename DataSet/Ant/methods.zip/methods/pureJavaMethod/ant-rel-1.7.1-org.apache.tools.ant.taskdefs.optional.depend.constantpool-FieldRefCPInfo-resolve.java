/** 
 * Resolve this constant pool entry with respect to its dependents in the constant pool.
 * @param constantPool the constant pool of which this entry is a memberand against which this entry is to be resolved.
 */
public void resolve(ConstantPool constantPool){
  ClassCPInfo fieldClass=(ClassCPInfo)constantPool.getEntry(classIndex);
  fieldClass.resolve(constantPool);
  fieldClassName=fieldClass.getClassName();
  NameAndTypeCPInfo nt=(NameAndTypeCPInfo)constantPool.getEntry(nameAndTypeIndex);
  nt.resolve(constantPool);
  fieldName=nt.getName();
  fieldType=nt.getType();
  super.resolve(constantPool);
}
