/** 
 * Checks whether <code>rpmbuild</code> is on the PATH and returns the absolute path to it - falls back to <code>rpm</code> otherwise.
 * @return the command used to build RPM's
 * @since 1.6
 */
protected String guessRpmBuildCommand(){
  Map env=Execute.getEnvironmentVariables();
  String path=(String)env.get(PATH1);
  if (path == null) {
    path=(String)env.get(PATH2);
    if (path == null) {
      path=(String)env.get(PATH3);
    }
  }
  if (path != null) {
    Path p=new Path(getProject(),path);
    String[] pElements=p.list();
    for (int i=0; i < pElements.length; i++) {
      File f=new File(pElements[i],"rpmbuild" + (Os.isFamily("dos") ? ".exe" : ""));
      if (f.canRead()) {
        return f.getAbsolutePath();
      }
    }
  }
  return "rpm";
}
