/** 
 * Gets the list of files to be compiled.
 * @return the list of files as an array
 */
public File[] getFileList(){
  return compileList;
}
