/** 
 * Process a line while in "GET_PREVIOUS_REVISION" state.
 * @param line the line to process
 */
private void processGetPreviousRevision(final String line){
  if (!line.startsWith("revision ")) {
    throw new IllegalStateException("Unexpected line from CVS: " + line);
  }
  previousRevision=line.substring("revision ".length());
  saveEntry();
  revision=previousRevision;
  status=GET_DATE;
}
