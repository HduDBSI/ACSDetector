/** 
 * Receive notification that character data has been found in a standard EJB 1.1 descriptor.  We're interested in retrieving the home interface, remote interface, implementation class, the type of bean, and if the bean uses CMP.
 * @param value String data found in the XML document.
 */
private void stdCharacters(String value){
  if ("\\ejb-jar\\display-name".equals(currentLoc)) {
    displayName=value;
    return;
  }
  String base="\\ejb-jar\\enterprise-beans\\" + ejbType;
  if ((base + "\\ejb-name").equals(currentLoc)) {
    currentEjb=ejbs.computeIfAbsent(value,EjbInfo::new);
  }
 else   if ((base + "\\home").equals(currentLoc)) {
    currentEjb.setHome(value);
  }
 else   if ((base + "\\remote").equals(currentLoc)) {
    currentEjb.setRemote(value);
  }
 else   if ((base + "\\ejb-class").equals(currentLoc)) {
    currentEjb.setImplementation(value);
  }
 else   if ((base + "\\prim-key-class").equals(currentLoc)) {
    currentEjb.setPrimaryKey(value);
  }
 else   if ((base + "\\session-type").equals(currentLoc)) {
    currentEjb.setBeantype(value);
  }
 else   if ((base + "\\persistence-type").equals(currentLoc)) {
    currentEjb.setCmp(value);
  }
}
