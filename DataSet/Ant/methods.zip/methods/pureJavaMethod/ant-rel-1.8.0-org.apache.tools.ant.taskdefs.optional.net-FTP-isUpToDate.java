/** 
 * Checks to see if the remote file is current as compared with the local file. Returns true if the target file is up to date.
 * @param ftp ftpclient
 * @param localFile local file
 * @param remoteFile remote file
 * @return true if the target file is up to date
 * @throws IOException  in unknown circumstances
 * @throws BuildException if the date of the remote files cannot be found and the action isGET_FILES
 */
protected boolean isUpToDate(FTPClient ftp,File localFile,String remoteFile) throws IOException, BuildException {
  log("checking date for " + remoteFile,Project.MSG_VERBOSE);
  FTPFile[] files=ftp.listFiles(remoteFile);
  if (files == null || files.length == 0) {
    if (action == SEND_FILES) {
      log("Could not date test remote file: " + remoteFile + "assuming out of date.",Project.MSG_VERBOSE);
      return false;
    }
 else {
      throw new BuildException("could not date test remote file: " + ftp.getReplyString());
    }
  }
  long remoteTimestamp=files[0].getTimestamp().getTime().getTime();
  long localTimestamp=localFile.lastModified();
  long adjustedRemoteTimestamp=remoteTimestamp + this.timeDiffMillis + this.granularityMillis;
  StringBuffer msg;
synchronized (TIMESTAMP_LOGGING_SDF) {
    msg=new StringBuffer("   [").append(TIMESTAMP_LOGGING_SDF.format(new Date(localTimestamp))).append("] local");
  }
  log(msg.toString(),Project.MSG_VERBOSE);
synchronized (TIMESTAMP_LOGGING_SDF) {
    msg=new StringBuffer("   [").append(TIMESTAMP_LOGGING_SDF.format(new Date(adjustedRemoteTimestamp))).append("] remote");
  }
  if (remoteTimestamp != adjustedRemoteTimestamp) {
synchronized (TIMESTAMP_LOGGING_SDF) {
      msg.append(" - (raw: ").append(TIMESTAMP_LOGGING_SDF.format(new Date(remoteTimestamp))).append(")");
    }
  }
  log(msg.toString(),Project.MSG_VERBOSE);
  if (this.action == SEND_FILES) {
    return adjustedRemoteTimestamp >= localTimestamp;
  }
 else {
    return localTimestamp >= adjustedRemoteTimestamp;
  }
}
