/** 
 * Does this String match the XML-NMTOKEN production?
 */
protected boolean isNmtoken(String s){
  for (int i=0; i < s.length(); i++) {
    char c=s.charAt(i);
    if (!Character.isLetterOrDigit(c) && c != '.' && c != '-' && c != '_' && c != ':') {
      return false;
    }
  }
  return true;
}
