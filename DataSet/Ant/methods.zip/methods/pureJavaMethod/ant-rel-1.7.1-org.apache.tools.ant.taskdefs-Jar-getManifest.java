private Manifest getManifest(Reader r){
  Manifest newManifest=null;
  try {
    newManifest=new Manifest(r);
  }
 catch (  ManifestException e) {
    log("Manifest is invalid: " + e.getMessage(),Project.MSG_ERR);
    throw new BuildException("Invalid Manifest: " + manifestFile,e,getLocation());
  }
catch (  IOException e) {
    throw new BuildException("Unable to read manifest file" + " (" + e.getMessage() + ")",e);
  }
  return newManifest;
}
