public void execute() throws BuildException {
  log("Building tar: " + tarFile.getAbsolutePath());
  if (baseDir == null) {
    throw new BuildException("basedir attribute must be set!",location);
  }
  if (!baseDir.exists()) {
    throw new BuildException("basedir does not exist!",location);
  }
  DirectoryScanner ds=super.getDirectoryScanner(baseDir);
  String[] files=ds.getIncludedFiles();
  TarOutputStream tOut=null;
  try {
    tOut=new TarOutputStream(new FileOutputStream(tarFile));
    tOut.setDebug(true);
    for (int i=0; i < files.length; i++) {
      File f=new File(baseDir,files[i]);
      String name=files[i].replace(File.separatorChar,'/');
      tarFile(f,tOut,name);
    }
  }
 catch (  IOException ioe) {
    String msg="Problem creating TAR: " + ioe.getMessage();
    throw new BuildException(msg,ioe,location);
  }
 finally {
    if (tOut != null) {
      try {
        tOut.close();
      }
 catch (      IOException e) {
      }
    }
  }
}
