@Test public void testTsaLocalhost(){
  try {
    buildRule.executeTarget("testTsaLocalhost");
    fail("Should have thrown exception - no TSA at localhost:0");
  }
 catch (  BuildException ex) {
    assertEquals("jarsigner returned: 1",ex.getMessage());
  }
}
