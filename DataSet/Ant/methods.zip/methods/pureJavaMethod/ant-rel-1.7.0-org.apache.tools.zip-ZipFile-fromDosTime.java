/** 
 * Convert a DOS date/time field to a Date object.
 * @param zipDosTime contains the stored DOS time.
 * @return a Date instance corresponding to the given time.
 */
protected static Date fromDosTime(ZipLong zipDosTime){
  long dosTime=zipDosTime.getValue();
  return new Date(dosToJavaTime(dosTime));
}
