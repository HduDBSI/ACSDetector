/** 
 * The output file for the "list" action. This attribute is ignored for any other actions.
 * @param listing file in which to store the listing.
 */
public void setListing(File listing){
  this.listing=listing;
}
