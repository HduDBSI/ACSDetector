/** 
 * &quot;Normalize&quot; the given absolute path. <p>This includes: <ul> <li>Uppercase the drive letter if there is one.</li> <li>Remove redundant slashes after the drive spec.</li> <li>Resolve all ./, .\, ../ and ..\ sequences.</li> <li>DOS style paths that start with a drive letter will have \ as the separator.</li> </ul> <p>Unlike  {@link File#getCanonicalPath()} this methodspecifically does not resolve symbolic links.</p> <p>If the path tries to go beyond the file system root (i.e. it contains more ".." segments than can be travelled up) the method will return the original path unchanged.</p>
 * @param path the path to be normalized.
 * @return the normalized version of the path.
 * @throws java.lang.NullPointerException if path is null.
 */
public File normalize(final String path){
  Stack s=new Stack();
  String[] dissect=dissect(path);
  s.push(dissect[0]);
  StringTokenizer tok=new StringTokenizer(dissect[1],File.separator);
  while (tok.hasMoreTokens()) {
    String thisToken=tok.nextToken();
    if (".".equals(thisToken)) {
      continue;
    }
    if ("..".equals(thisToken)) {
      if (s.size() < 2) {
        return new File(path);
      }
      s.pop();
    }
 else {
      s.push(thisToken);
    }
  }
  StringBuffer sb=new StringBuffer();
  final int size=s.size();
  for (int i=0; i < size; i++) {
    if (i > 1) {
      sb.append(File.separatorChar);
    }
    sb.append(s.elementAt(i));
  }
  return new File(sb.toString());
}
