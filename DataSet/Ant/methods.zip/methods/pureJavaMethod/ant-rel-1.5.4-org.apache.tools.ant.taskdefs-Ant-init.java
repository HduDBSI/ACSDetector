/** 
 * Creates a Project instance for the project to call.
 */
public void init(){
  newProject=new Project();
  newProject.setJavaVersionProperty();
  newProject.addTaskDefinition("property",(Class)getProject().getTaskDefinitions().get("property"));
}
