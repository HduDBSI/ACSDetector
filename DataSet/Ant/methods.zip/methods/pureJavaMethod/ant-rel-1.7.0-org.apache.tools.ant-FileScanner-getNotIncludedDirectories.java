/** 
 * Returns the names of the directories which matched none of the include patterns. The names are relative to the base directory.
 * @return the names of the directories which matched none of the includepatterns.
 */
String[] getNotIncludedDirectories();
