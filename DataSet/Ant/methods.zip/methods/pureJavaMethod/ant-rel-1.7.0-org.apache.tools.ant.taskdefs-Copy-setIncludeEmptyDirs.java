/** 
 * Set whether to copy empty directories.
 * @param includeEmpty if true copy empty directories. Default is true.
 */
public void setIncludeEmptyDirs(boolean includeEmpty){
  this.includeEmpty=includeEmpty;
}
