public int getState(){
  return OneLiner.this.getState();
}
