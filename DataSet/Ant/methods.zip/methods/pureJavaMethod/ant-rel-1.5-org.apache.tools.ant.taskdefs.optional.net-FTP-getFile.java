/** 
 * Retrieve a single file to the remote host. <code>filename</code> may contain a relative path specification. <p> The file will then be retreived using the entire relative path spec - no attempt is made to change directories. It is anticipated that this may eventually cause problems with some FTP servers, but it simplifies the coding.</p>
 */
protected void getFile(FTPClient ftp,String dir,String filename) throws IOException, BuildException {
  OutputStream outstream=null;
  try {
    File file=project.resolveFile(new File(dir,filename).getPath());
    if (newerOnly && isUpToDate(ftp,file,resolveFile(filename))) {
      return;
    }
    if (verbose) {
      log("transferring " + filename + " to "+ file.getAbsolutePath());
    }
    File pdir=fileUtils.getParentFile(file);
    if (!pdir.exists()) {
      pdir.mkdirs();
    }
    outstream=new BufferedOutputStream(new FileOutputStream(file));
    ftp.retrieveFile(resolveFile(filename),outstream);
    if (!FTPReply.isPositiveCompletion(ftp.getReplyCode())) {
      String s="could not get file: " + ftp.getReplyString();
      if (skipFailedTransfers == true) {
        log(s,Project.MSG_WARN);
        skipped++;
      }
 else {
        throw new BuildException(s);
      }
    }
 else {
      log("File " + file.getAbsolutePath() + " copied from "+ server,Project.MSG_VERBOSE);
      transferred++;
    }
  }
  finally {
    if (outstream != null) {
      try {
        outstream.close();
      }
 catch (      IOException ex) {
      }
    }
  }
}
