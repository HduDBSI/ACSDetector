/** 
 * Set the packetlist location attribute.
 * @param src a <code>File</code> value
 */
public void setPackagelistLoc(File src){
  packagelistLoc=src;
}
