/** 
 * The directory which holds the files whose permissions must be changed.
 * @param src the directory.
 */
public void setDir(File src){
  defaultSet.setDir(src);
}
