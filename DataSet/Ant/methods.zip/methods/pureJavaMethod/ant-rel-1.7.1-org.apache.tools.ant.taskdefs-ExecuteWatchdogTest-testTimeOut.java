public void testTimeOut() throws Exception {
  Process process=getProcess(TIME_OUT * 2);
  long now=System.currentTimeMillis();
  watchdog.start(process);
  int retCode=process.waitFor();
  long elapsed=System.currentTimeMillis() - now;
  assertTrue("process should have been killed",watchdog.killedProcess());
  assertTrue("elapse time of " + elapsed + " ms is less than timeout value of "+ TIME_OUT_TEST+ " ms",elapsed >= TIME_OUT_TEST);
  assertTrue("elapse time of " + elapsed + " ms is greater than run value of "+ (TIME_OUT * 2)+ " ms",elapsed < TIME_OUT * 2);
}
