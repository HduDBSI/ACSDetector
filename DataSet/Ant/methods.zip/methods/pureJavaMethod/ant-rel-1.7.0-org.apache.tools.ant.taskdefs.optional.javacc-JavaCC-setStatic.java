/** 
 * Sets the STATIC grammar option.
 * @param staticParser a <code>boolean</code> value.
 */
public void setStatic(boolean staticParser){
  optionalAttrs.put(STATIC,staticParser ? Boolean.TRUE : Boolean.FALSE);
}
