/** 
 * Merge the contents of the given manifest into this manifest
 * @param other the Manifest to be merged with this one.
 * @param overwriteMain whether to overwrite the main sectionof the current manifest
 * @param mergeClassPaths whether Class-Path attributes should bemerged.
 * @throws ManifestException if there is a problem merging themanifest according to the Manifest spec.
 * @since Ant 1.8.0
 */
public void merge(Manifest other,boolean overwriteMain,boolean mergeClassPaths) throws ManifestException {
  if (other != null) {
    if (overwriteMain) {
      mainSection=(Section)other.mainSection.clone();
    }
 else {
      mainSection.merge(other.mainSection,mergeClassPaths);
    }
    if (other.manifestVersion != null) {
      manifestVersion=other.manifestVersion;
    }
    for (    String sectionName : Collections.list(other.getSectionNames())) {
      Section ourSection=sections.get(sectionName);
      Section otherSection=other.sections.get(sectionName);
      if (ourSection == null) {
        if (otherSection != null) {
          addConfiguredSection((Section)otherSection.clone());
        }
      }
 else {
        ourSection.merge(otherSection,mergeClassPaths);
      }
    }
  }
}
