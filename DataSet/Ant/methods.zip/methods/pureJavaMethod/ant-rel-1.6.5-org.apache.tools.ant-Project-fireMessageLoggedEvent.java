/** 
 * Send a &quot;message logged&quot; event to the build listeners for this project.
 * @param event    The event to send. This should be built up with theappropriate task/target/project by the caller, so that this method can set the message and priority, then send the event. Must not be <code>null</code>.
 * @param message  The message to send. Should not be <code>null</code>.
 * @param priority The priority of the message.
 */
private void fireMessageLoggedEvent(BuildEvent event,String message,int priority){
  if (message.endsWith(StringUtils.LINE_SEP)) {
    int endIndex=message.length() - StringUtils.LINE_SEP.length();
    event.setMessage(message.substring(0,endIndex),priority);
  }
 else {
    event.setMessage(message,priority);
  }
synchronized (this) {
    if (loggingMessage) {
      return;
    }
    try {
      loggingMessage=true;
      Iterator iter=listeners.iterator();
      while (iter.hasNext()) {
        BuildListener listener=(BuildListener)iter.next();
        listener.messageLogged(event);
      }
    }
  finally {
      loggingMessage=false;
    }
  }
}
