/** 
 * Executes the Task.
 * @throws BuildException on error.
 */
public void execute() throws BuildException {
  validateAttributes();
  try {
    File dest=destDir != null ? destDir : srcDir;
    int writeCount=0;
    final FileNameMapper mapper;
    if (mapperElement == null) {
      mapper=new IdentityMapper();
    }
 else {
      mapper=mapperElement.getImplementation();
    }
    if (srcDir != null) {
      final DirectoryScanner ds=super.getDirectoryScanner(srcDir);
      final String[] files=ds.getIncludedFiles();
      writeCount+=processDir(srcDir,files,dest,mapper);
    }
    for (int i=0; i < filesets.size(); i++) {
      final FileSet fs=(FileSet)filesets.elementAt(i);
      final DirectoryScanner ds=fs.getDirectoryScanner(getProject());
      final String[] files=ds.getIncludedFiles();
      final File fromDir=fs.getDir(getProject());
      writeCount+=processDir(fromDir,files,dest,mapper);
    }
    if (writeCount > 0) {
      log("Processed " + writeCount + (writeCount == 1 ? " image." : " images."));
    }
  }
 catch (  Exception err) {
    err.printStackTrace();
    throw new BuildException(err.getMessage());
  }
}
