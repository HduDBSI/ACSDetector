/** 
 * Handle operations for type <code>date</code>.
 * @param oldValue the current value read from the property file or<code>null</code> if the <code>key</code> was not contained in the property file.
 */
private void executeDate(String oldValue) throws BuildException {
  Calendar currentValue=Calendar.getInstance();
  if (pattern == null) {
    pattern="yyyy/MM/dd HH:mm";
  }
  DateFormat fmt=new SimpleDateFormat(pattern);
  String currentStringValue=getCurrentValue(oldValue);
  if (currentStringValue == null) {
    currentStringValue=DEFAULT_DATE_VALUE;
  }
  if ("now".equals(currentStringValue)) {
    currentValue.setTime(new Date());
  }
 else {
    try {
      currentValue.setTime(fmt.parse(currentStringValue));
    }
 catch (    ParseException pe) {
    }
  }
  if (operation != Operation.EQUALS_OPER) {
    int offset=0;
    try {
      offset=Integer.parseInt(value);
      if (operation == Operation.DECREMENT_OPER) {
        offset=-1 * offset;
      }
    }
 catch (    NumberFormatException e) {
      throw new BuildException("Value not an integer on " + key);
    }
    currentValue.add(field,offset);
  }
  newValue=fmt.format(currentValue.getTime());
}
