/** 
 * Tests a permission that has been granted and revoked later. 
 */
@Test(expected=SecurityException.class) public void testGrantedAndRevoked(){
  System.setProperty("user.home",System.getProperty("user.home"));
}
