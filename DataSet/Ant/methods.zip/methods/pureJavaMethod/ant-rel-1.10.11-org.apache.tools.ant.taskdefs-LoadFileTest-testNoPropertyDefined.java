/** 
 * Fail due to output property not defined
 */
@Test(expected=BuildException.class) public void testNoPropertyDefined(){
  buildRule.executeTarget("testNoPropertyDefined");
}
