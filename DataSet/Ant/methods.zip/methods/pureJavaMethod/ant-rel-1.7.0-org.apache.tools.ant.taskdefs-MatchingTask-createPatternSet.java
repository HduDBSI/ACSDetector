/** 
 * add a set of patterns
 * @return PatternSet object to be configured
 */
public PatternSet createPatternSet(){
  return fileset.createPatternSet();
}
