/** 
 * Print a readable version of the constant pool entry.
 * @return the string representation of this constant pool entry.
 */
public String toString(){
  return "Double Constant Pool Entry: " + getValue();
}
