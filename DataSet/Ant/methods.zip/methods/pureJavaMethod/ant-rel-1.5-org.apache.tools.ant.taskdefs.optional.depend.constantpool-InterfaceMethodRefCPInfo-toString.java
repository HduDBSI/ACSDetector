/** 
 * Print a readable version of the constant pool entry.
 * @return the string representation of this constant pool entry.
 */
public String toString(){
  String value;
  if (isResolved()) {
    value="InterfaceMethod : Class = " + interfaceMethodClassName + ", name = "+ interfaceMethodName+ ", type = "+ interfaceMethodType;
  }
 else {
    value="InterfaceMethod : Class index = " + classIndex + ", name and type index = "+ nameAndTypeIndex;
  }
  return value;
}
