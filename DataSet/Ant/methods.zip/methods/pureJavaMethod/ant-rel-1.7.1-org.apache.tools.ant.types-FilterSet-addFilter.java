/** 
 * Add a new filter made from the given token and value.
 * @param token The token for the new filter.
 * @param value The value for the new filter.
 */
public synchronized void addFilter(String token,String value){
  if (isReference()) {
    throw noChildrenAllowed();
  }
  addFilter(new Filter(token,value));
}
