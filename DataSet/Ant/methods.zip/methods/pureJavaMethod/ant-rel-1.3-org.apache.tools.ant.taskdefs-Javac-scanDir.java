/** 
 * Scans the directory looking for source files to be compiled.   The results are returned in the class variable compileList
 */
protected void scanDir(File srcDir,File destDir,String files[]){
  GlobPatternMapper m=new GlobPatternMapper();
  m.setFrom("*.java");
  m.setTo("*.class");
  SourceFileScanner sfs=new SourceFileScanner(this);
  File[] newFiles=sfs.restrictAsFiles(files,srcDir,destDir,m);
  if (newFiles.length > 0) {
    File[] newCompileList=new File[compileList.length + newFiles.length];
    System.arraycopy(compileList,0,newCompileList,0,compileList.length);
    System.arraycopy(newFiles,0,newCompileList,compileList.length,newFiles.length);
    compileList=newCompileList;
  }
}
