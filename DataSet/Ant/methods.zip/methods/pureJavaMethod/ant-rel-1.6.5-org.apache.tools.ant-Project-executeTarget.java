/** 
 * Execute the specified target and any targets it depends on.
 * @param targetName The name of the target to execute.Must not be <code>null</code>.
 * @exception BuildException if the build failed.
 */
public void executeTarget(String targetName) throws BuildException {
  if (targetName == null) {
    String msg="No target specified";
    throw new BuildException(msg);
  }
  executeSortedTargets(topoSort(targetName,targets,false));
}
