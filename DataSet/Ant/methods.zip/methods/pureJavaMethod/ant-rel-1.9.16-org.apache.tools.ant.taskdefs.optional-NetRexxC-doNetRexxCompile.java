/** 
 * Performs a compile using the NetRexx 1.1.x compiler  
 */
private void doNetRexxCompile() throws BuildException {
  log("Using NetRexx compiler",Project.MSG_VERBOSE);
  String classpath=getCompileClasspath();
  StringBuffer compileOptions=new StringBuffer();
  String[] compileOptionsArray=getCompileOptionsAsArray();
  String[] fileListArray=new String[compileList.size()];
  Enumeration e=compileList.elements();
  int j=0;
  while (e.hasMoreElements()) {
    fileListArray[j]=(String)e.nextElement();
    j++;
  }
  String[] compileArgs=new String[compileOptionsArray.length + fileListArray.length];
  for (int i=0; i < compileOptionsArray.length; i++) {
    compileArgs[i]=compileOptionsArray[i];
  }
  for (int i=0; i < fileListArray.length; i++) {
    compileArgs[i + compileOptionsArray.length]=fileListArray[i];
  }
  compileOptions.append("Compilation args: ");
  for (int i=0; i < compileOptionsArray.length; i++) {
    compileOptions.append(compileOptionsArray[i]);
    compileOptions.append(" ");
  }
  log(compileOptions.toString(),Project.MSG_VERBOSE);
  String eol=System.getProperty("line.separator");
  StringBuffer niceSourceList=new StringBuffer("Files to be compiled:" + eol);
  final int size=compileList.size();
  for (int i=0; i < size; i++) {
    niceSourceList.append("    ");
    niceSourceList.append(compileList.elementAt(i).toString());
    niceSourceList.append(eol);
  }
  log(niceSourceList.toString(),Project.MSG_VERBOSE);
  String currentClassPath=System.getProperty("java.class.path");
  Properties currentProperties=System.getProperties();
  currentProperties.put("java.class.path",classpath);
  try {
    StringWriter out=new StringWriter();
    PrintWriter w=null;
    int rc=COM.ibm.netrexx.process.NetRexxC.main(new Rexx(compileArgs),w=new PrintWriter(out));
    String sdir=srcDir.getAbsolutePath();
    String ddir=destDir.getAbsolutePath();
    boolean doReplace=!(sdir.equals(ddir));
    int dlen=ddir.length();
    String l;
    BufferedReader in=new BufferedReader(new StringReader(out.toString()));
    log("replacing destdir '" + ddir + "' through sourcedir '"+ sdir+ "'",Project.MSG_VERBOSE);
    while ((l=in.readLine()) != null) {
      int idx;
      while (doReplace && ((idx=l.indexOf(ddir)) != -1)) {
        l=(new StringBuffer(l)).replace(idx,idx + dlen,sdir).toString();
      }
      if (suppressMethodArgumentNotUsed && l.contains(MSG_METHOD_ARGUMENT_NOT_USED)) {
        log(l,Project.MSG_VERBOSE);
      }
 else       if (suppressPrivatePropertyNotUsed && l.contains(MSG_PRIVATE_PROPERTY_NOT_USED)) {
        log(l,Project.MSG_VERBOSE);
      }
 else       if (suppressVariableNotUsed && l.contains(MSG_VARIABLE_NOT_USED)) {
        log(l,Project.MSG_VERBOSE);
      }
 else       if (suppressExceptionNotSignalled && l.contains(MSG_EXCEPTION_NOT_SIGNALLED)) {
        log(l,Project.MSG_VERBOSE);
      }
 else       if (suppressDeprecation && l.contains(MSG_DEPRECATION)) {
        log(l,Project.MSG_VERBOSE);
      }
 else       if (l.contains("Error:")) {
        log(l,Project.MSG_ERR);
      }
 else       if (l.contains("Warning:")) {
        log(l,Project.MSG_WARN);
      }
 else {
        log(l,Project.MSG_INFO);
      }
    }
    if (rc > 1) {
      throw new BuildException("Compile failed, messages should " + "have been provided.");
    }
    if (w.checkError()) {
      throw new IOException("Encountered an error");
    }
  }
 catch (  IOException ioe) {
    throw new BuildException("Unexpected IOException while " + "playing with Strings",ioe);
  }
 finally {
    currentProperties=System.getProperties();
    currentProperties.put("java.class.path",currentClassPath);
  }
}
