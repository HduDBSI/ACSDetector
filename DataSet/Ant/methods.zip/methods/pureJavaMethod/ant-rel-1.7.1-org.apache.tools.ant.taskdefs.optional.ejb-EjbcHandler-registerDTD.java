/** 
 * Registers a local DTD that will be used when parsing an EJB descriptor.  When the DTD's public identifier is found in an XML document, the parser will reference the local DTD rather than the remote DTD.  This enables XML documents to be processed even when the public DTD isn't available.
 * @param publicID The DTD's public identifier.
 * @param location The location of the local DTD copy -- the locationmay either be a resource found on the classpath or a local file.
 */
public void registerDTD(String publicID,String location){
  log("Registering: " + location);
  if ((publicID == null) || (location == null)) {
    return;
  }
  if (ClassLoader.getSystemResource(location) != null) {
    log("Found resource: " + location);
    resourceDtds.put(publicID,location);
  }
 else {
    File dtdFile=new File(location);
    if (dtdFile.exists() && dtdFile.isFile()) {
      log("Found file: " + location);
      fileDtds.put(publicID,location);
    }
  }
}
