/** 
 * Get comment file
 * @return String containing the path to the comment file
 */
public String getCommentFile(){
  return mCfile;
}
