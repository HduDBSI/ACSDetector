/** 
 * Process included file.
 * @param name  path of the file relative to the directory of the FileSet.
 * @param file  included File.
 */
private void accountForIncludedFile(String name,File file){
  processIncluded(name,file,filesIncluded,filesExcluded,filesDeselected);
}
