@Test public void testNSGetsReused() throws IOException {
  Document d=DOMUtils.newDocument();
  Element root=d.createElementNS("urn:foo","root");
  Element child=d.createElementNS("urn:foo","child");
  root.appendChild(child);
  StringWriter sw=new StringWriter();
  DOMElementWriter w=new DOMElementWriter(false,DOMElementWriter.XmlNamespacePolicy.ONLY_QUALIFY_ELEMENTS);
  w.write(root,sw,0,"  ");
  assertEquals(String.format("<root xmlns=\"urn:foo\">%n  <child />%n</root>%n"),sw.toString());
}
