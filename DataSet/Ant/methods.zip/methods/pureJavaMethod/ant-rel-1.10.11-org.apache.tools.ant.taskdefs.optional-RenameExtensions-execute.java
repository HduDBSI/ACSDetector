/** 
 * Executes the task.
 * @throws BuildException is there is a problem in the task execution.
 */
public void execute() throws BuildException {
  if (fromExtension == null || toExtension == null || srcDir == null) {
    throw new BuildException("srcDir, fromExtension and toExtension " + "attributes must be set!");
  }
  log("DEPRECATED - The renameext task is deprecated.  Use move instead.",Project.MSG_WARN);
  log("Replace this with:",Project.MSG_INFO);
  log("<move todir=\"" + srcDir + "\" overwrite=\""+ replace+ "\">",Project.MSG_INFO);
  log("  <fileset dir=\"" + srcDir + "\" />",Project.MSG_INFO);
  log("  <mapper type=\"glob\"",Project.MSG_INFO);
  log("          from=\"*" + fromExtension + "\"",Project.MSG_INFO);
  log("          to=\"*" + toExtension + "\" />",Project.MSG_INFO);
  log("</move>",Project.MSG_INFO);
  log("using the same patterns on <fileset> as you've used here",Project.MSG_INFO);
  Move move=new Move();
  move.bindToOwner(this);
  move.setOwningTarget(getOwningTarget());
  move.setTaskName(getTaskName());
  move.setLocation(getLocation());
  move.setTodir(srcDir);
  move.setOverwrite(replace);
  fileset.setDir(srcDir);
  move.addFileset(fileset);
  Mapper me=move.createMapper();
  me.setType(globType);
  me.setFrom("*" + fromExtension);
  me.setTo("*" + toExtension);
  move.execute();
}
