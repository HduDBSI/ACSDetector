/** 
 * If true, transitive dependencies are followed until the closure of the dependency set if reached. When not set, the depend task will only follow direct dependencies between classes.
 * @param closure indicate if dependency closure is required.
 */
public void setClosure(boolean closure){
  this.closure=closure;
}
