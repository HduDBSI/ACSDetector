/** 
 * Execute the task.
 * @throws BuildException if errors occur.
 */
public void execute() throws BuildException {
  if (sources == null) {
    throw new BuildException("At least one set of source resources must be specified");
  }
  if (targets == null) {
    throw new BuildException("At least one set of target files must be specified");
  }
  if (sources.size() > 0 && targets.size() > 0 && !uptodate(sources,targets)) {
    log("Deleting all target files.",Project.MSG_VERBOSE);
    if (verbose) {
      String[] t=targets.list();
      for (int i=0; i < t.length; i++) {
        log("Deleting " + t[i]);
      }
    }
    Delete delete=new Delete();
    delete.bindToOwner(this);
    delete.add(targets);
    delete.perform();
  }
}
