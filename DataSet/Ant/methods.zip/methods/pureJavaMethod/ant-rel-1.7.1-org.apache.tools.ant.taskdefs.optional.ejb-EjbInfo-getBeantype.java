public String getBeantype(){
  return beantype;
}
