/** 
 * Override to make two instances with same value equal.
 * @return the value stored in the ZipShort
 * @since 1.1
 */
public int hashCode(){
  return value;
}
