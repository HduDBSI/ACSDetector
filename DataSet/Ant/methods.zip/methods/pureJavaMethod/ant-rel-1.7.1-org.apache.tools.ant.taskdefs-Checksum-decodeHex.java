/** 
 * Converts an array of characters representing hexadecimal values into an array of bytes of those same values. The returned array will be half the length of the passed array, as it takes two characters to represent any given byte. An exception is thrown if the passed char array has an odd number of elements. NOTE: This code is copied from jakarta-commons codec.
 * @param data an array of characters representing hexadecimal values
 * @return the converted array of bytes
 * @throws BuildException on error
 */
public static byte[] decodeHex(char[] data) throws BuildException {
  int l=data.length;
  if ((l & 0x01) != 0) {
    throw new BuildException("odd number of characters.");
  }
  byte[] out=new byte[l >> 1];
  for (int i=0, j=0; j < l; i++) {
    int f=Character.digit(data[j++],WORD) << NIBBLE;
    f=f | Character.digit(data[j++],WORD);
    out[i]=(byte)(f & BYTE_MASK);
  }
  return out;
}
