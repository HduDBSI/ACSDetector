/** 
 * Handle operations for type <code>int</code>.
 * @param oldValue the current value read from the property file or<code>null</code> if the <code>key</code> was not contained in the property file.
 */
private void executeInteger(String oldValue) throws BuildException {
  int currentValue=DEFAULT_INT_VALUE;
  int newV=DEFAULT_INT_VALUE;
  DecimalFormat fmt=(pattern != null) ? new DecimalFormat(pattern) : new DecimalFormat();
  try {
    String curval=getCurrentValue(oldValue);
    if (curval != null) {
      currentValue=fmt.parse(curval).intValue();
    }
 else {
      currentValue=0;
    }
  }
 catch (  NumberFormatException nfe) {
  }
catch (  ParseException pe) {
  }
  if (operation == Operation.EQUALS_OPER) {
    newV=currentValue;
  }
 else {
    int operationValue=1;
    if (value != null) {
      try {
        operationValue=fmt.parse(value).intValue();
      }
 catch (      NumberFormatException nfe) {
      }
catch (      ParseException pe) {
      }
    }
    if (operation == Operation.INCREMENT_OPER) {
      newV=currentValue + operationValue;
    }
 else     if (operation == Operation.DECREMENT_OPER) {
      newV=currentValue - operationValue;
    }
  }
  this.newValue=fmt.format(newV);
}
