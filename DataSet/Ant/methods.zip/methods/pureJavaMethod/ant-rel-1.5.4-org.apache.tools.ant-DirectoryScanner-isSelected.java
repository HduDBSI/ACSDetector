/** 
 * Tests whether a name should be selected.
 * @param name the filename to check for selecting
 * @param file the java.io.File object for this filename
 * @return <code>false</code> when the selectors says that the fileshould not be selected, <code>true</code> otherwise.
 */
protected boolean isSelected(String name,File file){
  if (selectors != null) {
    for (int i=0; i < selectors.length; i++) {
      if ((selectors[i].isSelected(basedir,name,file)) == false) {
        return false;
      }
    }
  }
  return true;
}
