/** 
 * @return the current mode.
 */
public int getMode(){
  return getFileMode(this.getProject());
}
