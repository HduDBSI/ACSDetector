/** 
 * Convert string to index.
 * @param oper the string to convert.
 * @return the index.
 */
public static int toOperation(String oper){
  if ("+".equals(oper)) {
    return INCREMENT_OPER;
  }
 else   if ("-".equals(oper)) {
    return DECREMENT_OPER;
  }
  return EQUALS_OPER;
}
