/** 
 * Invoked by Ant after the task is prepared, when it is ready to execute this task.  Parses the XML deployment descriptor to acquire the list of files, then constructs the destination jar file (first deleting it if it already exists) from the list of classfiles encountered and the descriptor itself.  File will be of the expected format with classes under full package hierarchies and the descriptor in META-INF/ejb-jar.xml
 * @exception BuildException thrown whenever a problem isencountered that cannot be recovered from, to signal to ant that a major problem occurred within this task.
 */
public void execute() throws BuildException {
  if (srcDir == null) {
    throw new BuildException("The srcDir attribute must be specified");
  }
  if (deploymentTools.size() == 0) {
    GenericDeploymentTool genericTool=new GenericDeploymentTool();
    genericTool.setDestdir(destDir);
    genericTool.setTask(this);
    genericTool.setGenericJarSuffix(genericJarSuffix);
    deploymentTools.add(genericTool);
  }
  File scanDir=descriptorDir;
  if (scanDir == null) {
    scanDir=srcDir;
  }
  for (Iterator i=deploymentTools.iterator(); i.hasNext(); ) {
    EJBDeploymentTool tool=(EJBDeploymentTool)i.next();
    tool.configure(srcDir,scanDir,baseNameTerminator,baseJarName,flatDestDir);
    tool.validateConfigured();
  }
  try {
    SAXParserFactory saxParserFactory=SAXParserFactory.newInstance();
    saxParserFactory.setValidating(true);
    SAXParser saxParser=saxParserFactory.newSAXParser();
    DirectoryScanner ds=getDirectoryScanner(scanDir);
    ds.scan();
    String[] files=ds.getIncludedFiles();
    log(files.length + " deployment descriptors located.",Project.MSG_VERBOSE);
    for (int index=0; index < files.length; ++index) {
      for (Iterator i=deploymentTools.iterator(); i.hasNext(); ) {
        EJBDeploymentTool tool=(EJBDeploymentTool)i.next();
        tool.processDescriptor(files[index],saxParser);
      }
    }
  }
 catch (  SAXException se) {
    String msg="SAXException while creating parser." + "  Details: " + se.getMessage();
    throw new BuildException(msg,se);
  }
catch (  ParserConfigurationException pce) {
    String msg="ParserConfigurationException while creating parser. " + "Details: " + pce.getMessage();
    throw new BuildException(msg,pce);
  }
}
