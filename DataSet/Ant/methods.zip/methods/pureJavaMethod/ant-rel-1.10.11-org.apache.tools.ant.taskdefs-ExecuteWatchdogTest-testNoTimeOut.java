@Test public void testNoTimeOut() throws Exception {
  Process process=getProcess(TIME_OUT / 2);
  watchdog.start(process);
  int retCode=waitForEnd(process);
  assertFalse("process should not have been killed",watchdog.killedProcess());
  assertFalse(Execute.isFailure(retCode));
}
