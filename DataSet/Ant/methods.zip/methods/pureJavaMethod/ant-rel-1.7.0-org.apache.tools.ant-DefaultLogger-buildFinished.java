/** 
 * Prints whether the build succeeded or failed, any errors the occurred during the build, and how long the build took.
 * @param event An event with any relevant extra information.Must not be <code>null</code>.
 */
public void buildFinished(BuildEvent event){
  Throwable error=event.getException();
  StringBuffer message=new StringBuffer();
  if (error == null) {
    message.append(StringUtils.LINE_SEP);
    message.append(getBuildSuccessfulMessage());
  }
 else {
    message.append(StringUtils.LINE_SEP);
    message.append(getBuildFailedMessage());
    message.append(StringUtils.LINE_SEP);
    if (Project.MSG_VERBOSE <= msgOutputLevel || !(error instanceof BuildException)) {
      message.append(StringUtils.getStackTrace(error));
    }
 else {
      message.append(error.toString()).append(lSep);
    }
  }
  message.append(StringUtils.LINE_SEP);
  message.append("Total time: ");
  message.append(formatTime(System.currentTimeMillis() - startTime));
  String msg=message.toString();
  if (error == null) {
    printMessage(msg,out,Project.MSG_VERBOSE);
  }
 else {
    printMessage(msg,err,Project.MSG_ERR);
  }
  log(msg);
}
