/** 
 * Gets the CLASSPATH this rmic process will use.
 * @return the classpath
 */
public Path getClasspath(){
  return getCompileClasspath();
}
