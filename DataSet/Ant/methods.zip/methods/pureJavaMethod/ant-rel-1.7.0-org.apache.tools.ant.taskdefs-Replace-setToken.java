/** 
 * Set the string token to replace; required unless a nested <code>replacetoken</code> element or the <code>replacefilterfile</code> attribute is used.
 * @param token token <code>String</code>.
 */
public void setToken(String token){
  createReplaceToken().addText(token);
}
