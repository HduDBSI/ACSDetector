/** 
 * execute the task
 * @throws BuildException if <code>failonerror</code> is true and an error happens
 */
public void execute() throws BuildException {
  try {
    int fileProcessed=0;
    if (file == null && filesets.isEmpty()) {
      throw new BuildException("Specify at least one source - " + "a file or a fileset.");
    }
    if (file != null) {
      if (file.exists() && file.canRead() && file.isFile()) {
        doValidate(file);
        fileProcessed++;
      }
 else {
        String errorMsg="File " + file + " cannot be read";
        if (failOnError) {
          throw new BuildException(errorMsg);
        }
 else {
          log(errorMsg,Project.MSG_ERR);
        }
      }
    }
    for (    final FileSet fs : filesets) {
      DirectoryScanner ds=fs.getDirectoryScanner(getProject());
      for (      String fileName : ds.getIncludedFiles()) {
        File srcFile=new File(fs.getDir(getProject()),fileName);
        doValidate(srcFile);
        fileProcessed++;
      }
    }
    onSuccessfulValidation(fileProcessed);
  }
  finally {
    cleanup();
  }
}
