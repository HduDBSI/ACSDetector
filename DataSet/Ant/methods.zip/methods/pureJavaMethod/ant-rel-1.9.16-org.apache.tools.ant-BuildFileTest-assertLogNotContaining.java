/** 
 * Assert that the given substring is not in the log messages.
 * @param substring String
 */
public void assertLogNotContaining(String substring){
  String realLog=getLog();
  assertFalse("didn't expect log to contain \"" + substring + "\" log was \""+ realLog+ "\"",realLog.contains(substring));
}
