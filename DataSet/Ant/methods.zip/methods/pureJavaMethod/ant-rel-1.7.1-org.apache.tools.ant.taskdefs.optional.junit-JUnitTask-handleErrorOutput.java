/** 
 * Pass output sent to System.err to the TestRunner so it can collect it for the formatters.
 * @param output output coming from System.err
 * @since Ant 1.5
 */
public void handleErrorOutput(String output){
  if (runner != null) {
    runner.handleErrorOutput(output);
    if (showOutput) {
      super.handleErrorOutput(output);
    }
  }
 else {
    super.handleErrorOutput(output);
  }
}
