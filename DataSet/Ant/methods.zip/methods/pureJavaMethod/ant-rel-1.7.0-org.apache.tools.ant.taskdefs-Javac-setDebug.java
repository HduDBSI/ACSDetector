/** 
 * Indicates whether source should be compiled with debug information; defaults to off.
 * @param debug if true compile with debug information
 */
public void setDebug(boolean debug){
  this.debug=debug;
}
