@Test public void testPreservesExtraFields() throws IOException {
  testExtraField(new Zip(),true);
}
