/** 
 * Get graphical flag status
 * @return boolean containing status of graphical flag
 */
public boolean getGraphical(){
  return mGraphical;
}
