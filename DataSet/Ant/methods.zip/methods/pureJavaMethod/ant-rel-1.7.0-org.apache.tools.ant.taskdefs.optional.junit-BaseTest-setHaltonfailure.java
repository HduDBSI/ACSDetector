/** 
 * Set the haltonfailure attribute.
 * @param value a <code>boolean</code> value.
 */
public void setHaltonfailure(boolean value){
  haltOnFail=value;
}
