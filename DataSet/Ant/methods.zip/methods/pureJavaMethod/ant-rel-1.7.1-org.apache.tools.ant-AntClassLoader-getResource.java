/** 
 * Finds the resource with the given name. A resource is some data (images, audio, text, etc) that can be accessed by class code in a way that is independent of the location of the code.
 * @param name The name of the resource for which a stream is required.Must not be <code>null</code>.
 * @return a URL for reading the resource, or <code>null</code> if theresource could not be found or the caller doesn't have adequate privileges to get the resource.
 */
public URL getResource(String name){
  URL url=null;
  if (isParentFirst(name)) {
    url=(parent == null) ? super.getResource(name) : parent.getResource(name);
  }
  if (url != null) {
    log("Resource " + name + " loaded from parent loader",Project.MSG_DEBUG);
  }
 else {
    Enumeration e=pathComponents.elements();
    while (e.hasMoreElements() && url == null) {
      File pathComponent=(File)e.nextElement();
      url=getResourceURL(pathComponent,name);
      if (url != null) {
        log("Resource " + name + " loaded from ant loader",Project.MSG_DEBUG);
      }
    }
  }
  if (url == null && !isParentFirst(name)) {
    if (ignoreBase) {
      url=(getRootLoader() == null) ? null : getRootLoader().getResource(name);
    }
 else {
      url=(parent == null) ? super.getResource(name) : parent.getResource(name);
    }
    if (url != null) {
      log("Resource " + name + " loaded from parent loader",Project.MSG_DEBUG);
    }
  }
  if (url == null) {
    log("Couldn't load Resource " + name,Project.MSG_DEBUG);
  }
  return url;
}
