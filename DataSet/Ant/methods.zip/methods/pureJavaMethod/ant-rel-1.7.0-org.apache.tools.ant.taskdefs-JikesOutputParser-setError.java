private void setError(boolean err){
  error=err;
  if (error) {
    errorFlag=true;
  }
}
