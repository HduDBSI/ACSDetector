/** 
 * Main application method for the iPlanet Application Server ejbc utility. If the application is run with no commandline arguments, a usage statement is printed for the user.
 * @param args The commandline arguments passed to the application.
 */
public static void main(String[] args){
  File stdDescriptor;
  File iasDescriptor;
  File destDirectory=null;
  String classpath=null;
  SAXParser parser=null;
  boolean debug=false;
  boolean retainSource=false;
  IPlanetEjbc ejbc;
  if ((args.length < MIN_NUM_ARGS) || (args.length > MAX_NUM_ARGS)) {
    usage();
    return;
  }
  stdDescriptor=new File(args[args.length - 2]);
  iasDescriptor=new File(args[args.length - 1]);
  for (int i=0; i < args.length - 2; i++) {
    if (args[i].equals("-classpath")) {
      classpath=args[++i];
    }
 else     if (args[i].equals("-d")) {
      destDirectory=new File(args[++i]);
    }
 else     if (args[i].equals("-debug")) {
      debug=true;
    }
 else     if (args[i].equals("-keepsource")) {
      retainSource=true;
    }
 else {
      usage();
      return;
    }
  }
  if (classpath == null) {
    Properties props=System.getProperties();
    classpath=props.getProperty("java.class.path");
  }
  if (destDirectory == null) {
    Properties props=System.getProperties();
    destDirectory=new File(props.getProperty("user.dir"));
  }
  SAXParserFactory parserFactory=SAXParserFactory.newInstance();
  parserFactory.setValidating(true);
  try {
    parser=parserFactory.newSAXParser();
  }
 catch (  Exception e) {
    System.out.println("An exception was generated while trying to ");
    System.out.println("create a new SAXParser.");
    e.printStackTrace();
    return;
  }
  ejbc=new IPlanetEjbc(stdDescriptor,iasDescriptor,destDirectory,classpath,parser);
  ejbc.setDebugOutput(debug);
  ejbc.setRetainSource(retainSource);
  try {
    ejbc.execute();
  }
 catch (  IOException e) {
    System.out.println("An IOException has occurred while reading the " + "XML descriptors (" + e.getMessage() + ").");
    return;
  }
catch (  SAXException e) {
    System.out.println("A SAXException has occurred while reading the " + "XML descriptors (" + e.getMessage() + ").");
    return;
  }
catch (  IPlanetEjbc.EjbcException e) {
    System.out.println("An error has occurred while executing the ejbc " + "utility (" + e.getMessage() + ").");
    return;
  }
}
