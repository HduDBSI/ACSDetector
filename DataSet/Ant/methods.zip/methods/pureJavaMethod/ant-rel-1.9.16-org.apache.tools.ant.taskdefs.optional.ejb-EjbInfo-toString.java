/** 
 * Convenience method which creates a String representation of all the instance variables of an EjbInfo object.
 * @return A String representing the EjbInfo instance.
 */
public String toString(){
  String s="EJB name: " + name + "\n\r              home:      "+ home+ "\n\r              remote:    "+ remote+ "\n\r              impl:      "+ implementation+ "\n\r              primaryKey: "+ primaryKey+ "\n\r              beantype:  "+ beantype+ "\n\r              cmp:       "+ cmp+ "\n\r              iiop:      "+ iiop+ "\n\r              hasession: "+ hasession;
  for (  String cmpDescriptor : cmpDescriptors) {
    s+="\n\r              CMP Descriptor: " + cmpDescriptor;
  }
  return s;
}
