/** 
 * Adds an extra fields - replacing an already present extra field of the same type.
 * @param ze an extra field
 * @since 1.1
 */
public void addExtraField(ZipExtraField ze){
  if (extraFields == null) {
    extraFields=new Vector();
  }
  ZipShort type=ze.getHeaderId();
  boolean done=false;
  for (int i=0, fieldsSize=extraFields.size(); !done && i < fieldsSize; i++) {
    if (((ZipExtraField)extraFields.elementAt(i)).getHeaderId().equals(type)) {
      extraFields.setElementAt(ze,i);
      done=true;
    }
  }
  if (!done) {
    extraFields.addElement(ze);
  }
  setExtra();
}
