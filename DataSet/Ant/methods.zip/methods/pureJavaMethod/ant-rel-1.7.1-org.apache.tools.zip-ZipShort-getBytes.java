/** 
 * Get value as two bytes in big endian byte order.
 * @param value the Java int to convert to bytes
 * @return the converted int as a byte array in big endian byte order
 */
public static byte[] getBytes(int value){
  byte[] result=new byte[2];
  result[0]=(byte)(value & BYTE_MASK);
  result[1]=(byte)((value & BYTE_1_MASK) >> BYTE_1_SHIFT);
  return result;
}
