public void testGroups(){
  reg.setPattern("aaaa");
  Vector v=reg.getGroups("xaaaa");
  assertEquals("No parens -> no extra groups",1,v.size());
  assertEquals("Trivial match with no parens","aaaa",(String)v.elementAt(0));
  reg.setPattern("(aaaa)");
  v=reg.getGroups("xaaaa");
  assertEquals("Trivial match with single paren",2,v.size());
  assertEquals("Trivial match with single paren, full match","aaaa",(String)v.elementAt(0));
  assertEquals("Trivial match with single paren, matched paren","aaaa",(String)v.elementAt(0));
  reg.setPattern("(a+)b(b+)");
  v=reg.getGroups("xaabb");
  assertEquals(3,v.size());
  assertEquals("aabb",(String)v.elementAt(0));
  assertEquals("aa",(String)v.elementAt(1));
  assertEquals("b",(String)v.elementAt(2));
}
