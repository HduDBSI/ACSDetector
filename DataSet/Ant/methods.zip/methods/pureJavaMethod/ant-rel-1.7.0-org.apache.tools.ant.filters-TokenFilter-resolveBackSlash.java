/** 
 * xml does not do "c" like interpretation of strings. i.e. \n\r\t etc. this method processes \n, \r, \t, \f, \\ also subs \s -> " \n\r\t\f" a trailing '\' will be ignored
 * @param input raw string with possible embedded '\'s
 * @return converted string
 */
public static String resolveBackSlash(String input){
  return StringUtils.resolveBackSlash(input);
}
