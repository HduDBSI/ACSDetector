/** 
 * Method used to encapsulate the writing of the JAR file. Iterates over the filenames/java.io.Files in the Hashtable stored on the instance variable ejbFiles.
 * @param baseName the base name.
 * @param jarFile  the jar file to write to.
 * @param files    the files to write to the jar.
 * @param publicId the id to use.
 * @throws BuildException if there is an error.
 */
protected void writeJar(String baseName,File jarFile,Hashtable files,String publicId) throws BuildException {
  Vector homes=new Vector();
  Iterator it=files.keySet().iterator();
  while (it.hasNext()) {
    String clazz=(String)it.next();
    if (clazz.endsWith("Home.class")) {
      String home=toClass(clazz);
      homes.add(home);
      log(" Home " + home,Project.MSG_VERBOSE);
    }
  }
  buildBorlandStubs(homes.iterator());
  files.putAll(genfiles);
  super.writeJar(baseName,jarFile,files,publicId);
  if (verify) {
    verifyBorlandJar(jarFile);
  }
  if (generateclient) {
    generateClient(jarFile);
  }
}
