protected void nextLine() throws BuildException {
  int ch;
  int eolcount=0;
  eolStr.setLength(0);
  try {
    int linelen;
    reader.mark(INBUFLEN);
    line=reader.readLine();
    if (line == null) {
      linelen=0;
    }
 else {
      linelen=line.length();
    }
    reader.reset();
    reader.skip((long)linelen);
    reader.mark(INBUFLEN);
    ch=reader.read();
switch ((char)ch) {
case '\r':
      ++eolcount;
    eolStr.append('\r');
switch ((char)(ch=reader.read())) {
case '\r':
    if ((char)(ch=reader.read()) == '\n') {
      eolcount+=2;
      eolStr.append("\r\n");
    }
  break;
case '\n':
++eolcount;
eolStr.append('\n');
break;
}
break;
case '\n':
++eolcount;
eolStr.append('\n');
break;
}
reader.reset();
reader.skip((long)eolcount);
if (line != null && eolcount == 0) {
int i=linelen;
while (--i >= 0 && line.charAt(i) == CTRLZ) {
}
if (i < linelen - 1) {
eofStr.append(line.substring(i + 1));
line=i < 0 ? null : line.substring(0,i + 1);
}
}
}
 catch (IOException e) {
throw new BuildException(e);
}
}
