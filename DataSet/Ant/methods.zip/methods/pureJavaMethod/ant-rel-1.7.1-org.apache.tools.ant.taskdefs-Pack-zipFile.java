/** 
 * zip a file to an output stream
 * @param file the file to zip
 * @param zOut the output stream
 * @throws IOException on error
 */
protected void zipFile(File file,OutputStream zOut) throws IOException {
  zipResource(new FileResource(file),zOut);
}
