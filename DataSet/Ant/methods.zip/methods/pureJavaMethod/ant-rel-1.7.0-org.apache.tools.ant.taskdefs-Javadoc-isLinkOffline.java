/** 
 * Get the linkOffline attribute.
 * @return the linkOffline attribute.
 */
public boolean isLinkOffline(){
  return offline;
}
