/** 
 * Run the compilation.
 * @exception BuildException if the compilation has problems.
 */
public boolean execute() throws BuildException {
  attributes.log("Using classic compiler",Project.MSG_VERBOSE);
  Commandline cmd=setupJavacCommand(true);
  OutputStream logstr=new LogOutputStream(attributes,Project.MSG_WARN);
  try {
    Class c=Class.forName("sun.tools.javac.Main");
    Constructor cons=c.getConstructor(new Class[]{OutputStream.class,String.class});
    Object compiler=cons.newInstance(new Object[]{logstr,"javac"});
    Method compile=c.getMethod("compile",new Class[]{String[].class});
    Boolean ok=(Boolean)compile.invoke(compiler,new Object[]{cmd.getArguments()});
    return ok.booleanValue();
  }
 catch (  ClassNotFoundException ex) {
    throw new BuildException("Cannot use classic compiler, as it is " + "not available.  A common solution is " + "to set the environment variable"+ " JAVA_HOME to your jdk directory.",location);
  }
catch (  Exception ex) {
    if (ex instanceof BuildException) {
      throw (BuildException)ex;
    }
 else {
      throw new BuildException("Error starting classic compiler: ",ex,location);
    }
  }
 finally {
    try {
      logstr.close();
    }
 catch (    IOException e) {
      throw new BuildException(e);
    }
  }
}
