static String sanitizeAddress(String s){
  int paramDepth=0;
  int start=0;
  int end=0;
  int len=s.length();
  for (int i=0; i < len; i++) {
    char c=s.charAt(i);
    if (c == '(') {
      paramDepth++;
      if (start == 0) {
        end=i;
      }
    }
 else     if (c == ')') {
      paramDepth--;
      if (end == 0) {
        start=i + 1;
      }
    }
 else     if (paramDepth == 0 && c == '<') {
      start=i + 1;
    }
 else     if (paramDepth == 0 && c == '>') {
      end=i;
    }
  }
  if (end == 0) {
    end=len;
  }
  return s.substring(start,end);
}
