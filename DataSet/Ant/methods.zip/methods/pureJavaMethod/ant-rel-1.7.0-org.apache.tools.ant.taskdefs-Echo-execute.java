/** 
 * Does the work.
 * @exception BuildException if something goes wrong with the build
 */
public void execute() throws BuildException {
  if (file == null) {
    log(message,logLevel);
  }
 else {
    Writer out=null;
    try {
      String filename=file.getAbsolutePath();
      if (encoding == null || encoding.length() == 0) {
        out=new FileWriter(filename,append);
      }
 else {
        out=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(filename,append),encoding));
      }
      out.write(message,0,message.length());
    }
 catch (    IOException ioe) {
      throw new BuildException(ioe,getLocation());
    }
 finally {
      FileUtils.close(out);
    }
  }
}
