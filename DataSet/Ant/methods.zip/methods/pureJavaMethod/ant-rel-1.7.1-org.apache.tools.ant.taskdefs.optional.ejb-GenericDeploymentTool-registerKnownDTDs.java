/** 
 * Register the locations of all known DTDs. vendor-specific subclasses should override this method to define the vendor-specific locations of the EJB DTDs
 * @param handler no used in this class.
 */
protected void registerKnownDTDs(DescriptorHandler handler){
}
