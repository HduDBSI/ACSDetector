/** 
 * Resolve this constant pool entry with respect to its dependents in the constant pool.
 * @param constantPool the constant pool of which this entry is a memberand against which this entry is to be resolved.
 */
public void resolve(ConstantPool constantPool){
  name=((Utf8CPInfo)constantPool.getEntry(nameIndex)).getValue();
  type=((Utf8CPInfo)constantPool.getEntry(descriptorIndex)).getValue();
  super.resolve(constantPool);
}
