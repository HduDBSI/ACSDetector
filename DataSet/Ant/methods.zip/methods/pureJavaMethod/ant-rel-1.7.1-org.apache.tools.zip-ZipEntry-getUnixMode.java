/** 
 * Unix permission.
 * @return the unix permissions
 * @since Ant 1.6
 */
public int getUnixMode(){
  return (int)((getExternalAttributes() >> SHORT_SHIFT) & SHORT_MASK);
}
