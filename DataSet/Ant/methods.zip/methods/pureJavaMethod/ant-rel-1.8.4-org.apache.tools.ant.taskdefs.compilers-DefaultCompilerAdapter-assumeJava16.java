/** 
 * Shall we assume JDK 1.6 command line switches?
 * @return true if JDK 1.6
 * @since Ant 1.7
 */
protected boolean assumeJava16(){
  return assumeJavaXY("javac1.6",JavaEnvUtils.JAVA_1_6);
}
