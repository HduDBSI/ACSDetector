/** 
 * Stop pumping the streams.
 */
public void stop(){
  finish(inputThread);
  try {
    err.flush();
  }
 catch (  IOException e) {
  }
  try {
    out.flush();
  }
 catch (  IOException e) {
  }
  finish(outputThread);
  finish(errorThread);
}
