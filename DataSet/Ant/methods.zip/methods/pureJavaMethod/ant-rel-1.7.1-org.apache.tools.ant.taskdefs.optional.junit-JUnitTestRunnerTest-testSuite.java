public void testSuite(){
  TestRunner runner=createRunner(SuiteTestCase.class);
  runner.run();
  assertEquals(runner.getFormatter().getError(),JUnitTestRunner.SUCCESS,runner.getRetCode());
}
