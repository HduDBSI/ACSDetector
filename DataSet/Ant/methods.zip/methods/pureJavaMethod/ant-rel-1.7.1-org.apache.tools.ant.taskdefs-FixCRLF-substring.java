public String substring(int begin,int end){
  return line.substring(begin,end);
}
