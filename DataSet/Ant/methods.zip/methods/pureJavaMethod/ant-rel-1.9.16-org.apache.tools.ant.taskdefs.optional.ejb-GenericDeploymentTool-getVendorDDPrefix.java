/** 
 * Get the prefix for vendor deployment descriptors. This will contain the path and the start of the descriptor name, depending on the naming scheme
 * @param baseName the base name to use.
 * @param descriptorFileName the file name to use.
 * @return the prefix.
 */
public String getVendorDDPrefix(String baseName,String descriptorFileName){
  String ddPrefix=null;
  if (config.namingScheme.getValue().equals(EjbJar.NamingScheme.DESCRIPTOR)) {
    ddPrefix=baseName + config.baseNameTerminator;
  }
 else   if (config.namingScheme.getValue().equals(EjbJar.NamingScheme.BASEJARNAME) || config.namingScheme.getValue().equals(EjbJar.NamingScheme.EJB_NAME) || config.namingScheme.getValue().equals(EjbJar.NamingScheme.DIRECTORY)) {
    String canonicalDescriptor=descriptorFileName.replace('\\','/');
    int index=canonicalDescriptor.lastIndexOf('/');
    if (index == -1) {
      ddPrefix="";
    }
 else {
      ddPrefix=descriptorFileName.substring(0,index + 1);
    }
  }
  return ddPrefix;
}
