/** 
 * Expected failure due lacking a required argument
 */
@Test(expected=BuildException.class) public void test3(){
  buildRule.executeTarget("test3");
}
