/** 
 * Get the Entry's type tag.
 * @return The Tag value of this entry
 */
public int getTag(){
  return tag;
}
