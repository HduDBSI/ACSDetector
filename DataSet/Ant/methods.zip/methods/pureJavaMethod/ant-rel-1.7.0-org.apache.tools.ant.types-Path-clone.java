/** 
 * Clone this Path.
 * @return Path with shallowly cloned Resource children.
 */
public Object clone(){
  try {
    Path result=(Path)super.clone();
    result.union=union == null ? union : (Union)union.clone();
    return result;
  }
 catch (  CloneNotSupportedException e) {
    throw new BuildException(e);
  }
}
