/** 
 * Verifies that the user selections are valid.
 * @throws BuildException If the user selections are invalid.
 */
private void checkConfiguration() throws BuildException {
  if (ejbdescriptor == null) {
    String msg="The standard EJB descriptor must be specified using " + "the \"ejbdescriptor\" attribute.";
    throw new BuildException(msg,location);
  }
  if ((!ejbdescriptor.exists()) || (!ejbdescriptor.isFile())) {
    String msg="The standard EJB descriptor (" + ejbdescriptor + ") was not found or isn't a file.";
    throw new BuildException(msg,location);
  }
  if (iasdescriptor == null) {
    String msg="The iAS-speific XML descriptor must be specified using" + " the \"iasdescriptor\" attribute.";
    throw new BuildException(msg,location);
  }
  if ((!iasdescriptor.exists()) || (!iasdescriptor.isFile())) {
    String msg="The iAS-specific XML descriptor (" + iasdescriptor + ") was not found or isn't a file.";
    throw new BuildException(msg,location);
  }
  if (dest == null) {
    String msg="The destination directory must be specified using " + "the \"dest\" attribute.";
    throw new BuildException(msg,location);
  }
  if ((!dest.exists()) || (!dest.isDirectory())) {
    String msg="The destination directory (" + dest + ") was not "+ "found or isn't a directory.";
    throw new BuildException(msg,location);
  }
  if ((iashome != null) && (!iashome.isDirectory())) {
    String msg="If \"iashome\" is specified, it must be a valid " + "directory (it was set to " + iashome + ").";
    throw new BuildException(msg,getLocation());
  }
}
