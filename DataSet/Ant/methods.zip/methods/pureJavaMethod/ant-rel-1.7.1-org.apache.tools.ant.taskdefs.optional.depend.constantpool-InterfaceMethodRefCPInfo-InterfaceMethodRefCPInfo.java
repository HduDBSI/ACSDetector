/** 
 * Constructor. 
 */
public InterfaceMethodRefCPInfo(){
  super(CONSTANT_INTERFACEMETHODREF,1);
}
