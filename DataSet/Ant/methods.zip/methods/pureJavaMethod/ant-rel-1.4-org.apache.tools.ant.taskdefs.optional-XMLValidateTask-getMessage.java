private String getMessage(SAXParseException e){
  String sysID=e.getSystemId();
  if (sysID != null) {
    try {
      int line=e.getLineNumber();
      int col=e.getColumnNumber();
      return new URL(sysID).getFile() + (line == -1 ? "" : (":" + line + (col == -1 ? "" : (":" + col)))) + ": "+ e.getMessage();
    }
 catch (    MalformedURLException mfue) {
    }
  }
  return e.getMessage();
}
