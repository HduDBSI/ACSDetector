/** 
 * If true, specifies that old JDK1.0-style header files should be generated. (otherwise output file contain JNI-style native method function prototypes) (JDK1.2 only).
 * @param old if true use old 1.0 style header files.
 */
public void setOld(boolean old){
  this.old=old;
}
