/** 
 * @return <tt>null</tt> if there is a timeout value, otherwise thewatchdog instance.
 * @throws BuildException in case of error
 */
protected ExecuteWatchdog createWatchdog() throws BuildException {
  if (getTimeout() == null) {
    return null;
  }
  return new ExecuteWatchdog(getTimeout().longValue());
}
