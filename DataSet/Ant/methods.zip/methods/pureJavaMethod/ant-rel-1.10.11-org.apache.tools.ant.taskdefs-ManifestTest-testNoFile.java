/** 
 * file attribute for manifest task is required.
 */
@Test(expected=BuildException.class) public void testNoFile(){
  buildRule.executeTarget("testNoFile");
}
