/** 
 * Add default exclusions to the current exclusions set.
 */
public synchronized void addDefaultExcludes(){
  int excludesLength=excludes == null ? 0 : excludes.length;
  String[] newExcludes;
  newExcludes=new String[excludesLength + defaultExcludes.size()];
  if (excludesLength > 0) {
    System.arraycopy(excludes,0,newExcludes,0,excludesLength);
  }
  String[] defaultExcludesTemp=getDefaultExcludes();
  for (int i=0; i < defaultExcludesTemp.length; i++) {
    newExcludes[i + excludesLength]=defaultExcludesTemp[i].replace('/',File.separatorChar).replace('\\',File.separatorChar);
  }
  excludes=newExcludes;
}
