/** 
 * Return the value of a property, if it is set.
 * @param propertyName The name of the property.May be <code>null</code>, in which case the return value is also <code>null</code>.
 * @return the property value, or <code>null</code> for no matchor if a <code>null</code> name is provided.
 */
public String getProperty(String propertyName){
  PropertyHelper ph=PropertyHelper.getPropertyHelper(this);
  return (String)ph.getProperty(null,propertyName);
}
