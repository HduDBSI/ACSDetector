/** 
 * set the debug mode for java2iiop (default false)
 * @param debug the setting to use.
 */
public void setDebug(boolean debug){
  this.java2iiopdebug=debug;
}
