/** 
 * Writes a DOM tree to a stream.
 * @param element the Root DOM element of the tree
 * @param out where to send the output
 * @param indent number of
 * @param indentWith string that should be used to indent thecorresponding tag.
 * @throws IOException if an error happens while writing to the stream.
 */
public void write(Element element,Writer out,int indent,String indentWith) throws IOException {
  NodeList children=element.getChildNodes();
  boolean hasChildren=(children.getLength() > 0);
  boolean hasChildElements=false;
  openElement(element,out,indent,indentWith,hasChildren);
  if (hasChildren) {
    for (int i=0; i < children.getLength(); i++) {
      Node child=children.item(i);
switch (child.getNodeType()) {
case Node.ELEMENT_NODE:
        hasChildElements=true;
      if (i == 0) {
        out.write(lSep);
      }
    write((Element)child,out,indent + 1,indentWith);
  break;
case Node.TEXT_NODE:
out.write(encode(child.getNodeValue()));
break;
case Node.COMMENT_NODE:
out.write("<!--");
out.write(encode(child.getNodeValue()));
out.write("-->");
break;
case Node.CDATA_SECTION_NODE:
out.write("<![CDATA[");
encodedata(out,((Text)child).getData());
out.write("]]>");
break;
case Node.ENTITY_REFERENCE_NODE:
out.write('&');
out.write(child.getNodeName());
out.write(';');
break;
case Node.PROCESSING_INSTRUCTION_NODE:
out.write("<?");
out.write(child.getNodeName());
String data=child.getNodeValue();
if (data != null && data.length() > 0) {
out.write(' ');
out.write(data);
}
out.write("?>");
break;
default :
}
}
closeElement(element,out,indent,indentWith,hasChildElements);
}
}
