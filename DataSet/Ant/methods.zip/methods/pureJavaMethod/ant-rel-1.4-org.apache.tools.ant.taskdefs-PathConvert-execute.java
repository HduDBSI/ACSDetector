/** 
 * Do the execution.
 */
public void execute() throws BuildException {
  if (isReference()) {
    path=new Path(getProject()).createPath();
    Object obj=refid.getReferencedObject(getProject());
    if (obj instanceof Path) {
      path.setRefid(refid);
    }
 else     if (obj instanceof FileSet) {
      FileSet fs=(FileSet)obj;
      path.addFileset(fs);
    }
 else {
      throw new BuildException("'refid' does not refer to a path or fileset");
    }
  }
  validateSetup();
  String osname=System.getProperty("os.name").toLowerCase();
  onWindows=(osname.indexOf("windows") >= 0);
  char fromDirSep=onWindows ? '\\' : '/';
  char toDirSep=dirSep.charAt(0);
  StringBuffer rslt=new StringBuffer(100);
  String[] elems=path.list();
  for (int i=0; i < elems.length; i++) {
    String elem=elems[i];
    elem=mapElement(elem);
    elem=elem.replace(fromDirSep,toDirSep);
    if (i != 0)     rslt.append(pathSep);
    rslt.append(elem);
  }
  String value=rslt.toString();
  log("Set property " + property + " = "+ value,Project.MSG_VERBOSE);
  getProject().setProperty(property,value);
}
