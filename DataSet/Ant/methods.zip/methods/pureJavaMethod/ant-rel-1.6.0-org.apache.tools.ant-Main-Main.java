/** 
 * Sole constructor, which parses and deals with command line arguments.
 * @param args Command line arguments. Must not be <code>null</code>.
 * @exception BuildException if the specified build file doesn't existor is a directory.
 * @deprecated
 */
protected Main(String[] args) throws BuildException {
  processArgs(args);
}
