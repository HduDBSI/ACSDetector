/** 
 * Testing helper method; kept here for unification of changes.
 * @return a list of test classes depending on the java version.
 */
public static Vector<String> getJrePackageTestCases(){
  Vector<String> tests=new Vector<>();
  tests.addElement("java.lang.Object");
  tests.addElement("sun.reflect.SerializationConstructorAccessorImpl");
  tests.addElement("sun.net.www.http.HttpClient");
  tests.addElement("sun.audio.AudioPlayer");
  tests.addElement("javax.accessibility.Accessible");
  tests.addElement("sun.misc.BASE64Encoder");
  tests.addElement("com.sun.image.codec.jpeg.JPEGCodec");
  tests.addElement("org.omg.CORBA.Any");
  tests.addElement("com.sun.corba.se.internal.corba.AnyImpl");
  tests.addElement("com.sun.jndi.ldap.LdapURL");
  tests.addElement("com.sun.media.sound.Printer");
  tests.addElement("com.sun.naming.internal.VersionHelper");
  tests.addElement("com.sun.org.omg.CORBA.Initializer");
  tests.addElement("sunw.io.Serializable");
  tests.addElement("sunw.util.EventListener");
  tests.addElement("sun.audio.AudioPlayer");
  tests.addElement("org.ietf.jgss.Oid");
  tests.addElement("org.w3c.dom.Attr");
  tests.addElement("org.xml.sax.XMLReader");
  tests.addElement("com.sun.org.apache.xerces.internal.jaxp.datatype.DatatypeFactoryImpl");
  tests.addElement("jdk.net.Sockets");
  return tests;
}
