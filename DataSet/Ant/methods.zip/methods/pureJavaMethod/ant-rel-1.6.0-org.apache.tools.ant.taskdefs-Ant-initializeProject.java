/** 
 * Attaches the build listeners of the current project to the new project, configures a possible logfile, transfers task and data-type definitions, transfers properties (either all or just the ones specified as user properties to the current project, depending on inheritall), transfers the input handler.
 */
private void initializeProject(){
  newProject.setInputHandler(getProject().getInputHandler());
  Vector listeners=getProject().getBuildListeners();
  final int count=listeners.size();
  for (int i=0; i < count; i++) {
    newProject.addBuildListener((BuildListener)listeners.elementAt(i));
  }
  if (output != null) {
    File outfile=null;
    if (dir != null) {
      outfile=FileUtils.newFileUtils().resolveFile(dir,output);
    }
 else {
      outfile=getProject().resolveFile(output);
    }
    try {
      out=new PrintStream(new FileOutputStream(outfile));
      DefaultLogger logger=new DefaultLogger();
      logger.setMessageOutputLevel(Project.MSG_INFO);
      logger.setOutputPrintStream(out);
      logger.setErrorPrintStream(out);
      newProject.addBuildListener(logger);
    }
 catch (    IOException ex) {
      log("Ant: Can't set output to " + output);
    }
  }
  getProject().initSubProject(newProject);
  getProject().copyUserProperties(newProject);
  if (!inheritAll) {
    newProject.setSystemProperties();
  }
 else {
    addAlmostAll(getProject().getProperties());
  }
  Enumeration e=propertySets.elements();
  while (e.hasMoreElements()) {
    PropertySet ps=(PropertySet)e.nextElement();
    addAlmostAll(ps.getProperties());
  }
}
