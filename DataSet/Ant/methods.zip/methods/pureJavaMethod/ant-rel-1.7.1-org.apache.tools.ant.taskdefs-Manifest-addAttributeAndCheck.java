/** 
 * Add an attribute to the section
 * @param attribute the attribute to be added.
 * @return the value of the attribute if it is a nameattribute - null other wise
 * @exception ManifestException if the attribute alreadyexists in this section.
 */
public String addAttributeAndCheck(Attribute attribute) throws ManifestException {
  if (attribute.getName() == null || attribute.getValue() == null) {
    throw new BuildException("Attributes must have name and value");
  }
  if (attribute.getKey().equalsIgnoreCase(ATTRIBUTE_NAME)) {
    warnings.addElement("\"" + ATTRIBUTE_NAME + "\" attributes "+ "should not occur in the main section and must be the "+ "first element in all other sections: \""+ attribute.getName()+ ": "+ attribute.getValue()+ "\"");
    return attribute.getValue();
  }
  if (attribute.getKey().startsWith(ATTRIBUTE_FROM.toLowerCase())) {
    warnings.addElement(ERROR_FROM_FORBIDDEN + attribute.getName() + ": "+ attribute.getValue()+ "\"");
  }
 else {
    String attributeKey=attribute.getKey();
    if (attributeKey.equalsIgnoreCase(ATTRIBUTE_CLASSPATH)) {
      Attribute classpathAttribute=(Attribute)attributes.get(attributeKey);
      if (classpathAttribute == null) {
        storeAttribute(attribute);
      }
 else {
        warnings.addElement("Multiple Class-Path attributes " + "are supported but violate the Jar " + "specification and may not be correctly "+ "processed in all environments");
        Enumeration e=attribute.getValues();
        while (e.hasMoreElements()) {
          String value=(String)e.nextElement();
          classpathAttribute.addValue(value);
        }
      }
    }
 else     if (attributes.containsKey(attributeKey)) {
      throw new ManifestException("The attribute \"" + attribute.getName() + "\" may not occur more "+ "than once in the same section");
    }
 else {
      storeAttribute(attribute);
    }
  }
  return null;
}
