/** 
 * Receive notification that character data has been found in a standard EJB 1.1 descriptor.  We're interested in retrieving the home  interface, remote interface, implementation class, the type of bean, and if the bean uses CMP.
 * @param value String data found in the XML document.
 */
private void stdCharacters(String value){
  if (currentLoc.equals("\\ejb-jar\\display-name")) {
    displayName=value;
    return;
  }
  String base="\\ejb-jar\\enterprise-beans\\" + ejbType;
  if (currentLoc.equals(base + "\\ejb-name")) {
    currentEjb=(EjbInfo)ejbs.get(value);
    if (currentEjb == null) {
      currentEjb=new EjbInfo(value);
      ejbs.put(value,currentEjb);
    }
  }
 else   if (currentLoc.equals(base + "\\home")) {
    currentEjb.setHome(value);
  }
 else   if (currentLoc.equals(base + "\\remote")) {
    currentEjb.setRemote(value);
  }
 else   if (currentLoc.equals(base + "\\ejb-class")) {
    currentEjb.setImplementation(value);
  }
 else   if (currentLoc.equals(base + "\\session-type")) {
    currentEjb.setBeantype(value);
  }
 else   if (currentLoc.equals(base + "\\persistence-type")) {
    currentEjb.setCmp(value);
  }
}
