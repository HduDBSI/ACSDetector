/** 
 * Logs a message for a target if it is of an appropriate priority, also logging the name of the target if this is the first message which needs to be logged for the target.
 * @param event A BuildEvent containing message information.Must not be <code>null</code>.
 */
public void messageLogged(BuildEvent event){
  if (event.getPriority() > msgOutputLevel || null == event.getMessage() || "".equals(event.getMessage().trim())) {
    return;
  }
  if (null != targetName) {
    out.println(StringUtils.LINE_SEP + targetName + ":");
    targetName=null;
  }
  super.messageLogged(event);
}
