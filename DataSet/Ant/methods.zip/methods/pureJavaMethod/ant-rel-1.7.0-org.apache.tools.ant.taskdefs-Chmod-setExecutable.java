/** 
 * Set the executable. This is not allowed for Chmod.
 * @param e ignored.
 * @throws BuildException always.
 * @ant.attribute ignore="true"
 */
public void setExecutable(String e){
  throw new BuildException(getTaskType() + " doesn\'t support the executable attribute",getLocation());
}
