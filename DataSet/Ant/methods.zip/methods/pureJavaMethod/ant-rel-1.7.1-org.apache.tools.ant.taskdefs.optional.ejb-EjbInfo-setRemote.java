public void setRemote(Classname remote){
  this.remote=remote;
}
