public int incColumn(){
  return column++;
}
