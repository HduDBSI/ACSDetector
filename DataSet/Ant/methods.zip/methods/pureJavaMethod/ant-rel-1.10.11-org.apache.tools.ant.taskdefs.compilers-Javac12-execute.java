/** 
 * Run the compilation.
 * @return true if the compiler ran with a zero exit result (ok)
 * @exception BuildException if the compilation has problems.
 */
public boolean execute() throws BuildException {
  attributes.log("Using classic compiler",Project.MSG_VERBOSE);
  Commandline cmd=setupJavacCommand(true);
  try (OutputStream logstr=new LogOutputStream(attributes,Project.MSG_WARN)){
    Class<?> c=Class.forName(CLASSIC_COMPILER_CLASSNAME);
    Constructor<?> cons=c.getConstructor(OutputStream.class,String.class);
    Object compiler=cons.newInstance(logstr,"javac");
    Method compile=c.getMethod("compile",String[].class);
    return (Boolean)compile.invoke(compiler,new Object[]{cmd.getArguments()});
  }
 catch (  ClassNotFoundException ex) {
    throw new BuildException("Cannot use classic compiler, as it is " + "not available. \n" + " A common solution is "+ "to set the environment variable"+ " JAVA_HOME to your jdk directory.\n"+ "It is currently set to \"" + JavaEnvUtils.getJavaHome() + "\"",location);
  }
catch (  Exception ex) {
    if (ex instanceof BuildException) {
      throw (BuildException)ex;
    }
 else {
      throw new BuildException("Error starting classic compiler: ",ex,location);
    }
  }
}
