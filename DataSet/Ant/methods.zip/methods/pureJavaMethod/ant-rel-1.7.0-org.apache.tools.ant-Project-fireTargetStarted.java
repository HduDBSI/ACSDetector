/** 
 * Send a &quot;target started&quot; event to the build listeners for this project.
 * @param target The target which is starting to build.Must not be <code>null</code>.
 */
protected void fireTargetStarted(Target target){
  BuildEvent event=new BuildEvent(target);
  Iterator iter=listeners.iterator();
  while (iter.hasNext()) {
    BuildListener listener=(BuildListener)iter.next();
    listener.targetStarted(event);
  }
}
