/** 
 * sleep for a period of time
 * @param millis time to sleep
 */
public void doSleep(long millis){
  try {
    Thread.sleep(millis);
  }
 catch (  InterruptedException ie) {
  }
}
