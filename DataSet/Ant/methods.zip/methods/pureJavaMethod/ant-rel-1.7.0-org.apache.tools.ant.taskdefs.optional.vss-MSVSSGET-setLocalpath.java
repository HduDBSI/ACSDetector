/** 
 * Override the project working directory.
 * @param localPath   The path on disk.
 */
public void setLocalpath(Path localPath){
  super.setInternalLocalPath(localPath.toString());
}
