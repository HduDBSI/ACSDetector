/** 
 * Base directory to look in for files to CAB.
 * @param baseDir base directory for files to cab.
 */
public void setBasedir(File baseDir){
  this.baseDir=baseDir;
}
