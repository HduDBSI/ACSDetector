private IntrospectionHelper(final Class bean){
  attributeTypes=new Hashtable();
  attributeSetters=new Hashtable();
  nestedTypes=new Hashtable();
  nestedCreators=new Hashtable();
  this.bean=bean;
  Method[] methods=bean.getMethods();
  for (int i=0; i < methods.length; i++) {
    final Method m=methods[i];
    final String name=m.getName();
    Class returnType=m.getReturnType();
    Class[] args=m.getParameterTypes();
    if (org.apache.tools.ant.Task.class.isAssignableFrom(bean) && args.length == 1 && (("setLocation".equals(name) && org.apache.tools.ant.Location.class.equals(args[0])) || ("setDescription".equals(name) && java.lang.String.class.equals(args[0])) || ("setTaskType".equals(name) && java.lang.String.class.equals(args[0])))) {
      continue;
    }
    if ("addText".equals(name) && java.lang.Void.TYPE.equals(returnType) && args.length == 1 && java.lang.String.class.equals(args[0])) {
      addText=methods[i];
    }
 else     if (name.startsWith("set") && java.lang.Void.TYPE.equals(returnType) && args.length == 1 && !args[0].isArray()) {
      String propName=getPropertyName(name,"set");
      AttributeSetter as=createAttributeSetter(m,args[0]);
      if (as != null) {
        attributeTypes.put(propName,args[0]);
        attributeSetters.put(propName,as);
      }
    }
 else     if (name.startsWith("create") && !returnType.isArray() && !returnType.isPrimitive()&& args.length == 0) {
      String propName=getPropertyName(name,"create");
      nestedTypes.put(propName,returnType);
      nestedCreators.put(propName,new NestedCreator(){
        public Object create(        Object parent) throws InvocationTargetException, IllegalAccessException {
          return m.invoke(parent,new Object[]{});
        }
      }
);
    }
 else     if (name.startsWith("add") && java.lang.Void.TYPE.equals(returnType) && args.length == 1 && !args[0].isArray() && !args[0].isPrimitive()) {
      try {
        final Constructor c=args[0].getConstructor(new Class[]{});
        String propName=getPropertyName(name,"add");
        nestedTypes.put(propName,args[0]);
        nestedCreators.put(propName,new NestedCreator(){
          public Object create(          Object parent) throws InvocationTargetException, IllegalAccessException, InstantiationException {
            Object o=c.newInstance(new Object[]{});
            m.invoke(parent,new Object[]{o});
            return o;
          }
        }
);
      }
 catch (      NoSuchMethodException nse) {
      }
    }
  }
}
