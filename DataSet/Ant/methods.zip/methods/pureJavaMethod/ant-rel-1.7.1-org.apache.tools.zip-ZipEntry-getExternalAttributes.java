/** 
 * Retrieves the external file attributes.
 * @return the external file attributes
 * @since 1.1
 */
public long getExternalAttributes(){
  return externalAttributes;
}
