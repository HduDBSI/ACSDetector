public Timer(){
  start();
}
