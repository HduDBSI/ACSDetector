/** 
 * Set the source directory in which to find files to convert.
 * @param srcDir directory to find input file in.
 */
public void setSrc(File srcDir){
  this.srcDir=srcDir;
}
