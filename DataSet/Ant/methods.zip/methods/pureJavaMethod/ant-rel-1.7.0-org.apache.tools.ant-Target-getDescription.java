/** 
 * Returns the description of this target.
 * @return the description of this target, or <code>null</code> if nodescription is available.
 */
public String getDescription(){
  return description;
}
