/** 
 * Execute a testcase by forking a new JVM. The command will block until it finishes. To know if the process was destroyed or not, use the <tt>killedProcess()</tt> method of the watchdog class.
 * @param test       the testcase to execute.
 * @param watchdog   the watchdog in charge of cancelling the test if itexceeds a certain amount of time. Can be <tt>null</tt>, in this case the test could probably hang forever.
 */
private int executeAsForked(JUnitTest test,ExecuteWatchdog watchdog) throws BuildException {
  CommandlineJava cmd=(CommandlineJava)commandline.clone();
  cmd.setClassname("org.apache.tools.ant.taskdefs.optional.junit.JUnitTestRunner");
  cmd.createArgument().setValue(test.getName());
  cmd.createArgument().setValue("filtertrace=" + test.getFiltertrace());
  cmd.createArgument().setValue("haltOnError=" + test.getHaltonerror());
  cmd.createArgument().setValue("haltOnFailure=" + test.getHaltonfailure());
  if (includeAntRuntime) {
    log("Implicitly adding " + antRuntimeClasses + " to CLASSPATH",Project.MSG_VERBOSE);
    cmd.createClasspath(getProject()).createPath().append(antRuntimeClasses);
  }
  if (summary) {
    log("Running " + test.getName(),Project.MSG_INFO);
    cmd.createArgument().setValue("formatter=org.apache.tools.ant.taskdefs.optional.junit.SummaryJUnitResultFormatter");
  }
  cmd.createArgument().setValue("showoutput=" + String.valueOf(showOutput));
  StringBuffer formatterArg=new StringBuffer(128);
  final FormatterElement[] feArray=mergeFormatters(test);
  for (int i=0; i < feArray.length; i++) {
    FormatterElement fe=feArray[i];
    formatterArg.append("formatter=");
    formatterArg.append(fe.getClassname());
    File outFile=getOutput(fe,test);
    if (outFile != null) {
      formatterArg.append(",");
      formatterArg.append(outFile);
    }
    cmd.createArgument().setValue(formatterArg.toString());
    formatterArg.setLength(0);
  }
  File propsFile=FileUtils.newFileUtils().createTempFile("junit",".properties",project.getBaseDir());
  cmd.createArgument().setValue("propsfile=" + propsFile.getAbsolutePath());
  Hashtable p=project.getProperties();
  Properties props=new Properties();
}
