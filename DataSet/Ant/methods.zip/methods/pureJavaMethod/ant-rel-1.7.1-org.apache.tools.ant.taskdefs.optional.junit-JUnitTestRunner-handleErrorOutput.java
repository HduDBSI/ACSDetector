/** 
 * {@inheritDoc}. 
 */
public void handleErrorOutput(String output){
  if (systemError != null) {
    systemError.print(output);
  }
}
