/** 
 * A copy constructor.
 * @param filelist a <code>FileList</code> value
 */
protected FileList(FileList filelist){
  this.dir=filelist.dir;
  this.filenames=filelist.filenames;
  setProject(filelist.getProject());
}
