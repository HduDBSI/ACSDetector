/** 
 * Set the stylesheet file.
 * @param stylesheet a {@link org.apache.tools.ant.types.Resource} value
 * @throws Exception on error
 */
public void setStylesheet(Resource stylesheet) throws Exception {
  if (this.stylesheet != null) {
    transformer=null;
    if (!this.stylesheet.equals(stylesheet) || (stylesheet.getLastModified() != templatesModTime)) {
      templates=null;
    }
  }
  this.stylesheet=stylesheet;
}
