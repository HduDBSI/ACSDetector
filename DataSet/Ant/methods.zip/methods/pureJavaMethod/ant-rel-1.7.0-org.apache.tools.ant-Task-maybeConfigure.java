/** 
 * Configures this task - if it hasn't been done already. If the task has been invalidated, it is replaced with an UnknownElement task which uses the new definition in the project.
 * @exception BuildException if the task cannot be configured.
 */
public void maybeConfigure() throws BuildException {
  if (!invalid) {
    if (wrapper != null) {
      wrapper.maybeConfigure(getProject());
    }
  }
 else {
    getReplacement();
  }
}
