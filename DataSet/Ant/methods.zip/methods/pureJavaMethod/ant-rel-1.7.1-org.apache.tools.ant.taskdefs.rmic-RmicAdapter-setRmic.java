/** 
 * Sets the rmic attributes, which are stored in the Rmic task.
 * @param attributes the rmic attributes to use
 */
void setRmic(Rmic attributes);
