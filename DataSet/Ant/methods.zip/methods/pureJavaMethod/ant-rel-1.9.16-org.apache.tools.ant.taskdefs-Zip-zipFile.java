/** 
 * Method that gets called when adding from <code>java.io.File</code> instances. <p>This implementation delegates to the six-arg version.</p>
 * @param file the file to add to the archive
 * @param zOut the stream to write to
 * @param vPath the name this entry shall have in the archive
 * @param mode the Unix permissions to set.
 * @throws IOException on error
 * @since Ant 1.5.2
 */
protected void zipFile(final File file,final ZipOutputStream zOut,final String vPath,final int mode) throws IOException {
  if (file.equals(zipFile)) {
    throw new BuildException("A zip file cannot include itself",getLocation());
  }
  final BufferedInputStream bIn=new BufferedInputStream(new FileInputStream(file));
  try {
    zipFile(bIn,zOut,vPath,file.lastModified() + (roundUp ? ROUNDUP_MILLIS : 0),null,mode);
  }
  finally {
    bIn.close();
  }
}
