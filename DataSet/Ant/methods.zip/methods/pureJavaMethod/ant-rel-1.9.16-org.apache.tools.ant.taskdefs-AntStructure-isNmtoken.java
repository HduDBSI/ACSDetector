/** 
 * Does this String match the XML-NMTOKEN production?
 * @param s the string to test
 * @return true if the string matches the XML-NMTOKEN
 */
protected boolean isNmtoken(final String s){
  return DTDPrinter.isNmtoken(s);
}
