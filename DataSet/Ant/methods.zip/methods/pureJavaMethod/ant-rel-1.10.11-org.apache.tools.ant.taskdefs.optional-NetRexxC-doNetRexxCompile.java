/** 
 * Performs a compile using the NetRexx 1.1.x compiler  
 */
private void doNetRexxCompile() throws BuildException {
  log("Using NetRexx compiler",Project.MSG_VERBOSE);
  String classpath=getCompileClasspath();
  String[] compileOptionsArray=getCompileOptionsAsArray();
  log(Stream.of(compileOptionsArray).collect(Collectors.joining(" ","Compilation args: ","")),Project.MSG_VERBOSE);
  log("Files to be compiled:",Project.MSG_VERBOSE);
  log(compileList.stream().map(s -> String.format("    %s%n",s)).collect(Collectors.joining("")),Project.MSG_VERBOSE);
  String[] compileArgs=Stream.concat(Stream.of(compileOptionsArray),compileList.stream()).toArray(String[]::new);
  String currentClassPath=System.getProperty("java.class.path");
  Properties currentProperties=System.getProperties();
  currentProperties.put("java.class.path",classpath);
  try {
    StringWriter out=new StringWriter();
    PrintWriter w;
    int rc=COM.ibm.netrexx.process.NetRexxC.main(new Rexx(compileArgs),w=new PrintWriter(out));
    String sdir=srcDir.getAbsolutePath();
    String ddir=destDir.getAbsolutePath();
    boolean doReplace=!(sdir.equals(ddir));
    int dlen=ddir.length();
    BufferedReader in=new BufferedReader(new StringReader(out.toString()));
    log("replacing destdir '" + ddir + "' through sourcedir '"+ sdir+ "'",Project.MSG_VERBOSE);
    String l;
    while ((l=in.readLine()) != null) {
      int idx;
      while (doReplace && ((idx=l.indexOf(ddir)) != -1)) {
        l=new StringBuilder(l).replace(idx,idx + dlen,sdir).toString();
      }
      if (suppressMethodArgumentNotUsed && l.contains(MSG_METHOD_ARGUMENT_NOT_USED)) {
        log(l,Project.MSG_VERBOSE);
      }
 else       if (suppressPrivatePropertyNotUsed && l.contains(MSG_PRIVATE_PROPERTY_NOT_USED)) {
        log(l,Project.MSG_VERBOSE);
      }
 else       if (suppressVariableNotUsed && l.contains(MSG_VARIABLE_NOT_USED)) {
        log(l,Project.MSG_VERBOSE);
      }
 else       if (suppressExceptionNotSignalled && l.contains(MSG_EXCEPTION_NOT_SIGNALLED)) {
        log(l,Project.MSG_VERBOSE);
      }
 else       if (suppressDeprecation && l.contains(MSG_DEPRECATION)) {
        log(l,Project.MSG_VERBOSE);
      }
 else       if (l.contains("Error:")) {
        log(l,Project.MSG_ERR);
      }
 else       if (l.contains("Warning:")) {
        log(l,Project.MSG_WARN);
      }
 else {
        log(l,Project.MSG_INFO);
      }
    }
    if (rc > 1) {
      throw new BuildException("Compile failed, messages should have been provided.");
    }
    if (w.checkError()) {
      throw new IOException("Encountered an error");
    }
  }
 catch (  IOException ioe) {
    throw new BuildException("Unexpected IOException while playing with Strings",ioe);
  }
 finally {
    currentProperties=System.getProperties();
    currentProperties.put("java.class.path",currentClassPath);
  }
}
