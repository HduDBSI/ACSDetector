public void addError(Test test,Throwable t){
  error=t;
}
