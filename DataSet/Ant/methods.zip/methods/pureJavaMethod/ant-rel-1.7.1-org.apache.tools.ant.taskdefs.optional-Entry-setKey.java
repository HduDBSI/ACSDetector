/** 
 * Name of the property name/value pair
 * @param value the key.
 */
public void setKey(String value){
  this.key=value;
}
