/** 
 * Do the execution.
 * @throws BuildException if something is invalid.
 */
public void execute() throws BuildException {
  Union savedPath=path;
  String savedPathSep=pathSep;
  String savedDirSep=dirSep;
  try {
    if (isReference()) {
      Object o=refid.getReferencedObject(getProject());
      if (!(o instanceof ResourceCollection)) {
        throw new BuildException("refid '" + refid.getRefId() + "' does not refer to a resource collection.");
      }
      getPath().add((ResourceCollection)o);
    }
    validateSetup();
    String fromDirSep=onWindows ? "\\" : "/";
    StringBuffer rslt=new StringBuffer();
    String[] elems=path.list();
    if (mapper != null) {
      FileNameMapper impl=mapper.getImplementation();
      List ret=new ArrayList();
      for (int i=0; i < elems.length; ++i) {
        String[] mapped=impl.mapFileName(elems[i]);
        for (int m=0; mapped != null && m < mapped.length; ++m) {
          ret.add(mapped[m]);
        }
      }
      elems=(String[])ret.toArray(new String[ret.size()]);
    }
    for (int i=0; i < elems.length; i++) {
      String elem=mapElement(elems[i]);
      if (i != 0) {
        rslt.append(pathSep);
      }
      StringTokenizer stDirectory=new StringTokenizer(elem,fromDirSep,true);
      while (stDirectory.hasMoreTokens()) {
        String token=stDirectory.nextToken();
        rslt.append(fromDirSep.equals(token) ? dirSep : token);
      }
    }
    if (setonempty || rslt.length() > 0) {
      String value=rslt.toString();
      if (property == null) {
        log(value);
      }
 else {
        log("Set property " + property + " = "+ value,Project.MSG_VERBOSE);
        getProject().setNewProperty(property,value);
      }
    }
  }
  finally {
    path=savedPath;
    dirSep=savedDirSep;
    pathSep=savedPathSep;
  }
}
