/** 
 * Adds a reference to the project.
 * @param name The name of the reference. Must not be <code>null</code>.
 * @param value The value of the reference. Must not be <code>null</code>.
 */
public void addReference(String name,Object value){
synchronized (references) {
    Object old=references.get(name);
    if (old == value) {
      return;
    }
    if (old != null && !(old instanceof UnknownElement)) {
      log("Overriding previous definition of reference to " + name,MSG_WARN);
    }
    String valueAsString="";
    try {
      valueAsString=value.toString();
    }
 catch (    Throwable t) {
      log("Caught exception (" + t.getClass().getName() + ")"+ " while expanding "+ name+ ": "+ t.getMessage(),MSG_WARN);
    }
    log("Adding reference: " + name + " -> "+ valueAsString,MSG_DEBUG);
    references.put(name,value);
  }
}
