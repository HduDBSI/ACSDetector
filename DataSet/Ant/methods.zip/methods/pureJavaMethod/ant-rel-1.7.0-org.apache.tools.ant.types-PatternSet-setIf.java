/** 
 * Sets the if attribute. This attribute and the "unless" attribute are used to validate the name, based in the existence of the property.
 * @param cond A property name. If this property is notpresent, the name is invalid.
 */
public void setIf(String cond){
  ifCond=cond;
}
