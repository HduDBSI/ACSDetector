/** 
 * Print headers for result sets from the statements; optional, default true.
 * @param showheaders if true print headers of result sets.
 */
public void setShowheaders(boolean showheaders){
  this.showheaders=showheaders;
}
