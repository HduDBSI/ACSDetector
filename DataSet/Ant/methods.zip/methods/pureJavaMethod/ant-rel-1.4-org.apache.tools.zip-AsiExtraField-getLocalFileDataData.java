/** 
 * The actual data to put into local file data - without Header-ID or length specifier.
 * @since 1.1
 */
public byte[] getLocalFileDataData(){
  byte[] data=new byte[getLocalFileDataLength().getValue() - 4];
  System.arraycopy((new ZipShort(getMode())).getBytes(),0,data,0,2);
  byte[] linkArray=getLinkedFile().getBytes();
  System.arraycopy((new ZipLong(linkArray.length)).getBytes(),0,data,2,4);
  System.arraycopy((new ZipShort(getUserId())).getBytes(),0,data,6,2);
  System.arraycopy((new ZipShort(getGroupId())).getBytes(),0,data,8,2);
  System.arraycopy(linkArray,0,data,10,linkArray.length);
  crc.reset();
  crc.update(data);
  long checksum=crc.getValue();
  byte[] result=new byte[data.length + 4];
  System.arraycopy((new ZipLong(checksum)).getBytes(),0,result,0,4);
  System.arraycopy(data,0,result,4,data.length);
  return result;
}
