/** 
 * Constructs a new MailMessage to send an email. Use the given host and port as the mail server.
 * @param host the mail server to use
 * @param port the port to connect to
 * @exception IOException if there's any problem contacting the mail server
 */
public MailMessage(String host,int port) throws IOException {
  this.port=port;
  this.host=host;
  replyto=new Vector();
  to=new Vector();
  cc=new Vector();
  headersKeys=new Vector();
  headersValues=new Vector();
  connect();
  sendHelo();
}
