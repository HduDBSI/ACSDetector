/** 
 * Constructor.  
 */
public Utf8CPInfo(){
  super(CONSTANT_UTF8,1);
}
