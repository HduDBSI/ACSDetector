/** 
 * Constructs an instance which may be used to process EJB descriptors and generate EJB stubs and skeletons, if needed.
 * @param stdDescriptor File referencing a standard EJB descriptor.
 * @param iasDescriptor File referencing an iAS-specific EJB descriptor.
 * @param destDirectory File referencing the base directory where bothEJB "source" files are found and where stubs and skeletons will be written.
 * @param classpath     String representation of the classpath to be usedby the iAS ejbc utility.
 * @param parser        SAXParser to be used to process both of the EJBdescriptors.
 * @todo classpathElements is not needed here, its never used(at least IDEA tells me so! :)
 */
public IPlanetEjbc(File stdDescriptor,File iasDescriptor,File destDirectory,String classpath,SAXParser parser){
  this.stdDescriptor=stdDescriptor;
  this.iasDescriptor=iasDescriptor;
  this.destDirectory=destDirectory;
  this.classpath=classpath;
  this.parser=parser;
  List elements=new ArrayList();
  if (classpath != null) {
    StringTokenizer st=new StringTokenizer(classpath,File.pathSeparator);
    while (st.hasMoreTokens()) {
      elements.add(st.nextToken());
    }
    classpathElements=(String[])elements.toArray(new String[elements.size()]);
  }
}
