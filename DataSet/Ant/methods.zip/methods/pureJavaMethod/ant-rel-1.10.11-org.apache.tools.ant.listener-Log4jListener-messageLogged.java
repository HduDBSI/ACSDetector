/** 
 * @see BuildListener#messageLogged {@inheritDoc}.
 */
@Override public void messageLogged(final BuildEvent event){
  Object categoryObject=event.getTask();
  if (categoryObject == null) {
    categoryObject=event.getTarget();
    if (categoryObject == null) {
      categoryObject=event.getProject();
    }
  }
  final Logger log=Logger.getLogger(categoryObject.getClass().getName());
switch (event.getPriority()) {
case Project.MSG_ERR:
    log.error(event.getMessage());
  break;
case Project.MSG_WARN:
log.warn(event.getMessage());
break;
case Project.MSG_INFO:
log.info(event.getMessage());
break;
case Project.MSG_VERBOSE:
case Project.MSG_DEBUG:
log.debug(event.getMessage());
break;
default :
log.error(event.getMessage());
break;
}
}
