private String assumedJavaVersion(){
  if (JavaEnvUtils.isJavaVersion(JavaEnvUtils.JAVA_1_4)) {
    return JAVAC14;
  }
 else   if (JavaEnvUtils.isJavaVersion(JavaEnvUtils.JAVA_1_5)) {
    return JAVAC15;
  }
 else   if (JavaEnvUtils.isJavaVersion(JavaEnvUtils.JAVA_1_6)) {
    return JAVAC16;
  }
 else   if (JavaEnvUtils.isJavaVersion(JavaEnvUtils.JAVA_1_7)) {
    return JAVAC17;
  }
 else   if (JavaEnvUtils.isJavaVersion(JavaEnvUtils.JAVA_1_8)) {
    return JAVAC18;
  }
 else   if (JavaEnvUtils.isJavaVersion(JavaEnvUtils.JAVA_9)) {
    return JAVAC9;
  }
 else {
    return CLASSIC;
  }
}
