/** 
 * This is the operation to get the existing or recalculated properties.
 * @return the properties for this propertyset.
 */
public Properties getProperties(){
  if (isReference()) {
    return getRef().getProperties();
  }
  dieOnCircularReference();
  Hashtable props=getEffectiveProperties();
  Set names=getPropertyNames(props);
  FileNameMapper m=null;
  Mapper myMapper=getMapper();
  if (myMapper != null) {
    m=myMapper.getImplementation();
  }
  Properties properties=new Properties();
  for (Iterator iter=names.iterator(); iter.hasNext(); ) {
    String name=(String)iter.next();
    String value=(String)props.get(name);
    if (value != null) {
      if (m != null) {
        String[] newname=m.mapFileName(name);
        if (newname != null) {
          name=newname[0];
        }
      }
      properties.setProperty(name,value);
    }
  }
  return properties;
}
