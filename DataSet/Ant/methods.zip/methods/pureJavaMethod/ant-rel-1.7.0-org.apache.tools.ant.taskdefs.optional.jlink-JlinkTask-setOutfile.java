/** 
 * The output file for this run of jlink. Usually a jar or zip file.
 * @param outfile the output file
 */
public void setOutfile(File outfile){
  this.outfile=outfile;
}
