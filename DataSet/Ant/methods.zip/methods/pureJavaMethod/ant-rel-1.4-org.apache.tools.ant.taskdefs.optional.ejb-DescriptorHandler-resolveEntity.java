public InputSource resolveEntity(String publicId,String systemId) throws SAXException {
  this.publicId=publicId;
  File dtdFile=(File)fileDTDs.get(publicId);
  if (dtdFile != null) {
    try {
      owningTask.log("Resolved " + publicId + " to local file "+ dtdFile,Project.MSG_VERBOSE);
      return new InputSource(new FileInputStream(dtdFile));
    }
 catch (    FileNotFoundException ex) {
    }
  }
  String dtdResourceName=(String)resourceDTDs.get(publicId);
  if (dtdResourceName != null) {
    InputStream is=this.getClass().getResourceAsStream(dtdResourceName);
    if (is != null) {
      owningTask.log("Resolved " + publicId + " to local resource "+ dtdResourceName,Project.MSG_VERBOSE);
      return new InputSource(is);
    }
  }
  URL dtdUrl=(URL)urlDTDs.get(publicId);
  if (dtdUrl != null) {
    try {
      InputStream is=dtdUrl.openStream();
      owningTask.log("Resolved " + publicId + " to url "+ dtdUrl,Project.MSG_VERBOSE);
      return new InputSource(is);
    }
 catch (    IOException ioe) {
    }
  }
  owningTask.log("Could not resolve ( publicId: " + publicId + ", systemId: "+ systemId+ ") to a local entity",Project.MSG_INFO);
  return null;
}
