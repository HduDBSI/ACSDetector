/** 
 * Expected failure due to non-public execute() method
 */
@Test(expected=BuildException.class) public void test5(){
  buildRule.executeTarget("test5");
}
