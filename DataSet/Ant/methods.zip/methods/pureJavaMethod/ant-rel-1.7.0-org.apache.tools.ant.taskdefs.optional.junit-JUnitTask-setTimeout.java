/** 
 * Set the timeout value (in milliseconds). <p>If the test is running for more than this value, the test will be canceled. (works only when in 'fork' mode).</p>
 * @param value the maximum time (in milliseconds) allowed beforedeclaring the test as 'timed-out'
 * @see #setFork(boolean)
 * @since Ant 1.2
 */
public void setTimeout(Integer value){
  timeout=value;
}
