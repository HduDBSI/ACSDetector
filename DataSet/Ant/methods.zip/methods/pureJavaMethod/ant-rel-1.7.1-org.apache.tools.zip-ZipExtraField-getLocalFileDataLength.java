/** 
 * Length of the extra field in the local file data - without Header-ID or length specifier.
 * @return the length of the field in the local file data
 * @since 1.1
 */
ZipShort getLocalFileDataLength();
