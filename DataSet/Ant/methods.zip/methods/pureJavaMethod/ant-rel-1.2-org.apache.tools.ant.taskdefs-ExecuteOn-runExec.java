protected void runExec(Execute exe) throws BuildException {
  try {
    Vector v=new Vector();
    for (int i=0; i < filesets.size(); i++) {
      FileSet fs=(FileSet)filesets.elementAt(i);
      DirectoryScanner ds=fs.getDirectoryScanner(project);
      if (!"dir".equals(type)) {
        String[] s=ds.getIncludedFiles();
        for (int j=0; j < s.length; j++) {
          v.addElement(new File(fs.getDir(project),s[j]).getAbsolutePath());
        }
      }
      if (!"file".equals(type)) {
        String[] s=ds.getIncludedDirectories();
        for (int j=0; j < s.length; j++) {
          v.addElement(new File(fs.getDir(project),s[j]).getAbsolutePath());
        }
      }
    }
    String[] s=new String[v.size()];
    v.copyInto(s);
    int err=-1;
    String myos=System.getProperty("os.name");
    if (parallel) {
      cmdl.addArguments(s);
      exe.setCommandline(cmdl.getCommandline());
      err=exe.execute();
      if (err != 0) {
        if (failOnError) {
          throw new BuildException("Exec returned: " + err,location);
        }
 else {
          log("Result: " + err,Project.MSG_ERR);
        }
      }
    }
 else {
      String[] cmd=new String[cmdl.size() + 1];
      System.arraycopy(cmdl.getCommandline(),0,cmd,0,cmdl.size());
      for (int i=0; i < s.length; i++) {
        cmd[cmdl.size()]=s[i];
        exe.setCommandline(cmd);
        err=exe.execute();
        if (err != 0) {
          if (failOnError) {
            throw new BuildException("Exec returned: " + err,location);
          }
 else {
            log("Result: " + err,Project.MSG_ERR);
          }
        }
      }
    }
  }
 catch (  IOException e) {
    throw new BuildException("Execute failed: " + e,e,location);
  }
 finally {
    logFlush();
  }
}
