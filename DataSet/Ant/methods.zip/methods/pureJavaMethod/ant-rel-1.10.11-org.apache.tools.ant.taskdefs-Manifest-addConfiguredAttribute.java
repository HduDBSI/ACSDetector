/** 
 * Add an attribute to the manifest - it is added to the main section.
 * @param attribute the attribute to be added.
 * @exception ManifestException if the attribute is not valid.
 */
public void addConfiguredAttribute(Attribute attribute) throws ManifestException {
  if (attribute.getKey() == null || attribute.getValue() == null) {
    throw new BuildException("Attributes must have name and value");
  }
  if (ATTRIBUTE_MANIFEST_VERSION_LC.equals(attribute.getKey())) {
    manifestVersion=attribute.getValue();
  }
 else {
    mainSection.addConfiguredAttribute(attribute);
  }
}
