/** 
 * Set the destination directory. File will be unzipped into the destination directory.
 * @param d Path to the directory.
 */
public void setDest(File d){
  this.dest=d;
}
