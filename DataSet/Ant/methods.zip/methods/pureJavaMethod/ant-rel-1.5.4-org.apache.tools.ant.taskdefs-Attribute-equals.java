/** 
 * @see java.lang.Object#equals
 */
public boolean equals(Object rhs){
  if (rhs == null || rhs.getClass() != getClass()) {
    return false;
  }
  if (rhs == this) {
    return true;
  }
  Attribute rhsAttribute=(Attribute)rhs;
  String lhsKey=getKey();
  String rhsKey=rhsAttribute.getKey();
  if ((lhsKey == null && rhsKey != null) || (lhsKey != null && rhsKey == null) || !lhsKey.equals(rhsKey)) {
    return false;
  }
  return CollectionUtils.equals(values,rhsAttribute.values);
}
