/** 
 * Builds and returns the command string to execute ccm
 * @return String containing path to the executable
 */
protected final String getCcmCommand(){
  String toReturn=ccmDir;
  if (!toReturn.equals("") && !toReturn.endsWith("/")) {
    toReturn+="/";
  }
  toReturn+=CCM_EXE;
  return toReturn;
}
