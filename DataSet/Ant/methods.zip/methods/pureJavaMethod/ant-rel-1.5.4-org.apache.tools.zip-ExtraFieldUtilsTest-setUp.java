public void setUp(){
  a=new AsiExtraField();
  a.setMode(0755);
  a.setDirectory(true);
  dummy=new UnrecognizedExtraField();
  dummy.setHeaderId(new ZipShort(1));
  dummy.setLocalFileDataData(new byte[0]);
  dummy.setCentralDirectoryData(new byte[]{0});
  aLocal=a.getLocalFileDataData();
  byte[] dummyLocal=dummy.getLocalFileDataData();
  data=new byte[4 + aLocal.length + 4+ dummyLocal.length];
  System.arraycopy(a.getHeaderId().getBytes(),0,data,0,2);
  System.arraycopy(a.getLocalFileDataLength().getBytes(),0,data,2,2);
  System.arraycopy(aLocal,0,data,4,aLocal.length);
  System.arraycopy(dummy.getHeaderId().getBytes(),0,data,4 + aLocal.length,2);
  System.arraycopy(dummy.getLocalFileDataLength().getBytes(),0,data,4 + aLocal.length + 2,2);
  System.arraycopy(dummyLocal,0,data,4 + aLocal.length + 4,dummyLocal.length);
}
