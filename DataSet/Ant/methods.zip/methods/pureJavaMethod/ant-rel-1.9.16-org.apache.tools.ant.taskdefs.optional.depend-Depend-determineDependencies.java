/** 
 * Determine the dependencies between classes. Class dependencies are determined by examining the class references in a class file to other classes. This method sets up the following fields <ul> <li>affectedClassMap - the list of classes each class affects</li> <li>classFileInfoMap - information about each class</li> <li>classpathDependencies - the list of jars and classes from the classpath that each class depends upon.</li> </ul> If required, the dependencies are written to the cache.
 * @exception IOException if either the dependencies cache or the classfiles cannot be read or written
 */
private void determineDependencies() throws IOException {
  affectedClassMap=new Hashtable();
  classFileInfoMap=new Hashtable();
  boolean cacheDirty=false;
  Hashtable dependencyMap=new Hashtable();
  File cacheFile=null;
  boolean cacheFileExists=true;
  long cacheLastModified=Long.MAX_VALUE;
  if (cache != null) {
    cacheFile=new File(cache,CACHE_FILE_NAME);
    cacheFileExists=cacheFile.exists();
    cacheLastModified=cacheFile.lastModified();
    if (cacheFileExists) {
      dependencyMap=readCachedDependencies(cacheFile);
    }
  }
  Enumeration classfileEnum=getClassFiles(destPath).elements();
  while (classfileEnum.hasMoreElements()) {
    ClassFileInfo info=(ClassFileInfo)classfileEnum.nextElement();
    log("Adding class info for " + info.className,Project.MSG_DEBUG);
    classFileInfoMap.put(info.className,info);
    Vector dependencyList=null;
    if (cache != null) {
      if (cacheFileExists && cacheLastModified > info.absoluteFile.lastModified()) {
        dependencyList=(Vector)dependencyMap.get(info.className);
      }
    }
    if (dependencyList == null) {
      DependencyAnalyzer analyzer=new AntAnalyzer();
      analyzer.addRootClass(info.className);
      analyzer.addClassPath(destPath);
      analyzer.setClosure(false);
      dependencyList=new Vector();
      Enumeration depEnum=analyzer.getClassDependencies();
      while (depEnum.hasMoreElements()) {
        Object o=depEnum.nextElement();
        dependencyList.addElement(o);
        log("Class " + info.className + " depends on "+ o,Project.MSG_DEBUG);
      }
      cacheDirty=true;
      dependencyMap.put(info.className,dependencyList);
    }
    Enumeration depEnum=dependencyList.elements();
    while (depEnum.hasMoreElements()) {
      String dependentClass=(String)depEnum.nextElement();
      Hashtable affectedClasses=(Hashtable)affectedClassMap.get(dependentClass);
      if (affectedClasses == null) {
        affectedClasses=new Hashtable();
        affectedClassMap.put(dependentClass,affectedClasses);
      }
      affectedClasses.put(info.className,info);
      log(dependentClass + " affects " + info.className,Project.MSG_DEBUG);
    }
  }
  classpathDependencies=null;
  Path checkPath=getCheckClassPath();
  if (checkPath != null) {
    classpathDependencies=new Hashtable();
    AntClassLoader loader=null;
    try {
      loader=getProject().createClassLoader(checkPath);
      Hashtable classpathFileCache=new Hashtable();
      Object nullFileMarker=new Object();
      for (Enumeration e=dependencyMap.keys(); e.hasMoreElements(); ) {
        String className=(String)e.nextElement();
        log("Determining classpath dependencies for " + className,Project.MSG_DEBUG);
        Vector dependencyList=(Vector)dependencyMap.get(className);
        Hashtable dependencies=new Hashtable();
        classpathDependencies.put(className,dependencies);
        Enumeration e2=dependencyList.elements();
        while (e2.hasMoreElements()) {
          String dependency=(String)e2.nextElement();
          log("Looking for " + dependency,Project.MSG_DEBUG);
          Object classpathFileObject=classpathFileCache.get(dependency);
          if (classpathFileObject == null) {
            classpathFileObject=nullFileMarker;
            if (!dependency.startsWith("java.") && !dependency.startsWith("javax.")) {
              URL classURL=loader.getResource(dependency.replace('.','/') + ".class");
              log("URL is " + classURL,Project.MSG_DEBUG);
              if (classURL != null) {
                if (classURL.getProtocol().equals("jar")) {
                  String jarFilePath=classURL.getFile();
                  int classMarker=jarFilePath.indexOf('!');
                  jarFilePath=jarFilePath.substring(0,classMarker);
                  if (jarFilePath.startsWith("file:")) {
                    classpathFileObject=new File(FileUtils.getFileUtils().fromURI(jarFilePath));
                  }
 else {
                    throw new IOException("Bizarre nested path in jar: protocol: " + jarFilePath);
                  }
                }
 else                 if (classURL.getProtocol().equals("file")) {
                  classpathFileObject=new File(FileUtils.getFileUtils().fromURI(classURL.toExternalForm()));
                }
                log("Class " + className + " depends on "+ classpathFileObject+ " due to "+ dependency,Project.MSG_DEBUG);
              }
            }
 else {
              log("Ignoring base classlib dependency " + dependency,Project.MSG_DEBUG);
            }
            classpathFileCache.put(dependency,classpathFileObject);
          }
          if (classpathFileObject != nullFileMarker) {
            File jarFile=(File)classpathFileObject;
            log("Adding a classpath dependency on " + jarFile,Project.MSG_DEBUG);
            dependencies.put(jarFile,jarFile);
          }
        }
      }
    }
  finally {
      if (loader != null) {
        loader.cleanup();
      }
    }
  }
 else {
    log("No classpath to check",Project.MSG_DEBUG);
  }
  if (cache != null && cacheDirty) {
    writeCachedDependencies(dependencyMap);
  }
}
