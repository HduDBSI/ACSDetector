/** 
 * Is the given argument a character or entity reference?
 */
public boolean isReference(String ent){
  if (!(ent.charAt(0) == '&') || !ent.endsWith(";")) {
    return false;
  }
  if (ent.charAt(1) == '#') {
    if (ent.charAt(2) == 'x') {
      try {
        Integer.parseInt(ent.substring(3,ent.length() - 1),16);
        return true;
      }
 catch (      NumberFormatException nfe) {
        return false;
      }
    }
 else {
      try {
        Integer.parseInt(ent.substring(2,ent.length() - 1));
        return true;
      }
 catch (      NumberFormatException nfe) {
        return false;
      }
    }
  }
  String name=ent.substring(1,ent.length() - 1);
  for (int i=0; i < knownEntities.length; i++) {
    if (name.equals(knownEntities[i])) {
      return true;
    }
  }
  return false;
}
