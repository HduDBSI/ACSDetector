/** 
 * Entry point for standalone (forked) mode. <p> Parameters: testcaseclassname plus parameters in the format key=value, none of which is required. </p> <table border="1"> <caption>Test runner attributes</caption> <tr> <th>key</th><th>description</th><th>default value</th> </tr> <tr> <td>haltOnError</td><td>halt test on errors?</td><td>false</td> </tr> <tr> <td>haltOnFailure</td><td>halt test on failures?</td><td>false</td> </tr> <tr> <td>formatter</td><td>A JUnitResultFormatter given as classname,filename. If filename is omitted, System.out is assumed.</td><td>none</td> </tr> <tr> <td>showoutput</td><td>send output to System.err/.out as well as to the formatters?</td><td>false</td> </tr> <tr> <td>logtestlistenerevents</td><td>log TestListener events to System.out.</td><td>false</td> </tr> <tr> <td>methods</td><td>Comma-separated list of names of individual test methods to execute.</td><td>null</td> </tr> </table>
 * @param args the command line arguments.
 * @throws IOException on error.
 */
public static void main(final String[] args) throws IOException {
  String[] methods=null;
  boolean haltError=false;
  boolean haltFail=false;
  boolean stackfilter=true;
  final Properties props=new Properties();
  boolean showOut=false;
  boolean outputToFormat=true;
  boolean logFailedTests=true;
  boolean logTestListenerEvents=false;
  boolean skipNonTests=false;
  int antThreadID=0;
  if (args.length == 0) {
    System.err.println("required argument TestClassName missing");
    System.exit(ERRORS);
  }
  if (args[0].startsWith(Constants.TESTSFILE)) {
    multipleTests=true;
    args[0]=args[0].substring(Constants.TESTSFILE.length());
  }
  for (  String arg : args) {
    if (arg.startsWith(Constants.METHOD_NAMES)) {
      try {
        final String methodsList=arg.substring(Constants.METHOD_NAMES.length());
        methods=JUnitTest.parseTestMethodNamesList(methodsList);
      }
 catch (      final IllegalArgumentException ex) {
        System.err.println("Invalid specification of test method names: " + arg);
        System.exit(ERRORS);
      }
    }
 else     if (arg.startsWith(Constants.HALT_ON_ERROR)) {
      haltError=Project.toBoolean(arg.substring(Constants.HALT_ON_ERROR.length()));
    }
 else     if (arg.startsWith(Constants.HALT_ON_FAILURE)) {
      haltFail=Project.toBoolean(arg.substring(Constants.HALT_ON_FAILURE.length()));
    }
 else     if (arg.startsWith(Constants.FILTERTRACE)) {
      stackfilter=Project.toBoolean(arg.substring(Constants.FILTERTRACE.length()));
    }
 else     if (arg.startsWith(Constants.CRASHFILE)) {
      crashFile=arg.substring(Constants.CRASHFILE.length());
      registerTestCase(Constants.BEFORE_FIRST_TEST);
    }
 else     if (arg.startsWith(Constants.FORMATTER)) {
      try {
        createAndStoreFormatter(arg.substring(Constants.FORMATTER.length()));
      }
 catch (      final BuildException be) {
        System.err.println(be.getMessage());
        System.exit(ERRORS);
      }
    }
 else     if (arg.startsWith(Constants.PROPSFILE)) {
      final FileInputStream in=new FileInputStream(arg.substring(Constants.PROPSFILE.length()));
      props.load(in);
      in.close();
    }
 else     if (arg.startsWith(Constants.SHOWOUTPUT)) {
      showOut=Project.toBoolean(arg.substring(Constants.SHOWOUTPUT.length()));
    }
 else     if (arg.startsWith(Constants.LOGTESTLISTENEREVENTS)) {
      logTestListenerEvents=Project.toBoolean(arg.substring(Constants.LOGTESTLISTENEREVENTS.length()));
    }
 else     if (arg.startsWith(Constants.OUTPUT_TO_FORMATTERS)) {
      outputToFormat=Project.toBoolean(arg.substring(Constants.OUTPUT_TO_FORMATTERS.length()));
    }
 else     if (arg.startsWith(Constants.LOG_FAILED_TESTS)) {
      logFailedTests=Project.toBoolean(arg.substring(Constants.LOG_FAILED_TESTS.length()));
    }
 else     if (arg.startsWith(Constants.SKIP_NON_TESTS)) {
      skipNonTests=Project.toBoolean(arg.substring(Constants.SKIP_NON_TESTS.length()));
    }
 else     if (arg.startsWith(Constants.THREADID)) {
      antThreadID=Integer.parseInt(arg.substring(Constants.THREADID.length()));
    }
  }
  final Hashtable p=System.getProperties();
  for (final Enumeration e=p.keys(); e.hasMoreElements(); ) {
    final Object key=e.nextElement();
    props.put(key,p.get(key));
  }
  int returnCode=SUCCESS;
  if (multipleTests) {
    try {
      final BufferedReader reader=new BufferedReader(new FileReader(args[0]));
      String testCaseName;
      String[] testMethodNames;
      int code=0;
      boolean errorOccurred=false;
      boolean failureOccurred=false;
      String line=null;
      while ((line=reader.readLine()) != null) {
        final StringTokenizer st=new StringTokenizer(line,",");
        final String testListSpec=st.nextToken();
        final int colonIndex=testListSpec.indexOf(':');
        if (colonIndex == -1) {
          testCaseName=testListSpec;
          testMethodNames=null;
        }
 else {
          testCaseName=testListSpec.substring(0,colonIndex);
          testMethodNames=JUnitTest.parseTestMethodNamesList(testListSpec.substring(colonIndex + 1).replace('+',','));
        }
        final JUnitTest t=new JUnitTest(testCaseName);
        t.setTodir(new File(st.nextToken()));
        t.setOutfile(st.nextToken());
        t.setProperties(props);
        t.setSkipNonTests(skipNonTests);
        t.setThread(antThreadID);
        code=launch(t,testMethodNames,haltError,stackfilter,haltFail,showOut,outputToFormat,logTestListenerEvents);
        errorOccurred=(code == ERRORS);
        failureOccurred=(code != SUCCESS);
        if (errorOccurred || failureOccurred) {
          if ((errorOccurred && haltError) || (failureOccurred && haltFail)) {
            registerNonCrash();
            System.exit(code);
          }
 else {
            if (code > returnCode) {
              returnCode=code;
            }
            if (logFailedTests) {
              System.out.println("TEST " + t.getName() + " FAILED");
            }
          }
        }
      }
    }
 catch (    final IOException e) {
      e.printStackTrace();
    }
  }
 else {
    final JUnitTest t=new JUnitTest(args[0]);
    t.setThread(antThreadID);
    t.setProperties(props);
    t.setSkipNonTests(skipNonTests);
    returnCode=launch(t,methods,haltError,stackfilter,haltFail,showOut,outputToFormat,logTestListenerEvents);
  }
  registerNonCrash();
  System.exit(returnCode);
}
