/** 
 * Get the name of the project
 * @return the name of the project.
 */
public String getName(){
  return name;
}
