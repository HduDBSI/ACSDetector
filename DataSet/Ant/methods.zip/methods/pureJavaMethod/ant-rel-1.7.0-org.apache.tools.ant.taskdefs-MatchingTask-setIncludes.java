/** 
 * Sets the set of include patterns. Patterns may be separated by a comma or a space.
 * @param includes the string containing the include patterns
 */
public void setIncludes(String includes){
  fileset.setIncludes(includes);
}
