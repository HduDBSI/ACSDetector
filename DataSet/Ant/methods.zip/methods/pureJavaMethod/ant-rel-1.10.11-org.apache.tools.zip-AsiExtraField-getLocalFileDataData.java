/** 
 * The actual data to put into local file data - without Header-ID or length specifier.
 * @return get the data
 * @since 1.1
 */
public byte[] getLocalFileDataData(){
  byte[] data=new byte[getLocalFileDataLength().getValue() - WORD];
  System.arraycopy(ZipShort.getBytes(getMode()),0,data,0,2);
  byte[] linkArray=getLinkedFile().getBytes();
  System.arraycopy(ZipLong.getBytes(linkArray.length),0,data,2,WORD);
  System.arraycopy(ZipShort.getBytes(getUserId()),0,data,6,2);
  System.arraycopy(ZipShort.getBytes(getGroupId()),0,data,8,2);
  System.arraycopy(linkArray,0,data,10,linkArray.length);
  crc.reset();
  crc.update(data);
  long checksum=crc.getValue();
  byte[] result=new byte[data.length + WORD];
  System.arraycopy(ZipLong.getBytes(checksum),0,result,0,WORD);
  System.arraycopy(data,0,result,WORD,data.length);
  return result;
}
