/** 
 * @ant.attribute ignore="true"
 * @param proceed inverse of failoferror
 */
public void setProceed(boolean proceed){
  failOnError=!proceed;
}
