/** 
 * Convert a class name from class file slash notation to java source file dot notation.
 * @param name the class name in slash notation org/apache/ant
 * @return the class name in dot notation (eg. java.lang.Object).
 */
public static String convertSlashName(String name){
  return name.replace('\\','.').replace('/','.');
}
