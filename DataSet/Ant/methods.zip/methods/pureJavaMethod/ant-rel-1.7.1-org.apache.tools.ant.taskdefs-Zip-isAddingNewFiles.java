/** 
 * Indicates if the task is adding new files into the archive as opposed to copying back unchanged files from the backup copy
 * @return true if adding new files
 */
protected final boolean isAddingNewFiles(){
  return addingNewFiles;
}
