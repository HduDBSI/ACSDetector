/** 
 * Create a token to filter as the text of a nested element.
 * @return nested token <code>NestedString</code> to configure.
 */
public NestedString createReplaceToken(){
  if (token == null) {
    token=new NestedString();
  }
  return token;
}
