/** 
 * <b>Deprecated</b>. Defines the location of Sun's EJB DTD in the weblogic class hierarchy. Should not be needed, and the nested &lt;dtd&gt; element is recommended when it is.
 * @param inString the string to use as the DTD location.
 */
public void setEJBdtd(String inString){
  this.ejb11DTD=inString;
}
