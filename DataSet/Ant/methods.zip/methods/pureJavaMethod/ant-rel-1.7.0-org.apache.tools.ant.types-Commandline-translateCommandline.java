/** 
 * Crack a command line.
 * @param toProcess the command line to process.
 * @return the command line broken into strings.An empty or null toProcess parameter results in a zero sized array.
 */
public static String[] translateCommandline(String toProcess){
  if (toProcess == null || toProcess.length() == 0) {
    return new String[0];
  }
  final int normal=0;
  final int inQuote=1;
  final int inDoubleQuote=2;
  int state=normal;
  StringTokenizer tok=new StringTokenizer(toProcess,"\"\' ",true);
  Vector v=new Vector();
  StringBuffer current=new StringBuffer();
  boolean lastTokenHasBeenQuoted=false;
  while (tok.hasMoreTokens()) {
    String nextTok=tok.nextToken();
switch (state) {
case inQuote:
      if ("\'".equals(nextTok)) {
        lastTokenHasBeenQuoted=true;
        state=normal;
      }
 else {
        current.append(nextTok);
      }
    break;
case inDoubleQuote:
  if ("\"".equals(nextTok)) {
    lastTokenHasBeenQuoted=true;
    state=normal;
  }
 else {
    current.append(nextTok);
  }
break;
default :
if ("\'".equals(nextTok)) {
state=inQuote;
}
 else if ("\"".equals(nextTok)) {
state=inDoubleQuote;
}
 else if (" ".equals(nextTok)) {
if (lastTokenHasBeenQuoted || current.length() != 0) {
  v.addElement(current.toString());
  current=new StringBuffer();
}
}
 else {
current.append(nextTok);
}
lastTokenHasBeenQuoted=false;
break;
}
}
if (lastTokenHasBeenQuoted || current.length() != 0) {
v.addElement(current.toString());
}
if (state == inQuote || state == inDoubleQuote) {
throw new BuildException("unbalanced quotes in " + toProcess);
}
String[] args=new String[v.size()];
v.copyInto(args);
return args;
}
