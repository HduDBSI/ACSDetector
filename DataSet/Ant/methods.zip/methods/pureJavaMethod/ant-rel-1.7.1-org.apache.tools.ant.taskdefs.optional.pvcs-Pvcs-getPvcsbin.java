/** 
 * Get name of the PVCS bin directory
 * @return String
 */
public String getPvcsbin(){
  return pvcsbin;
}
