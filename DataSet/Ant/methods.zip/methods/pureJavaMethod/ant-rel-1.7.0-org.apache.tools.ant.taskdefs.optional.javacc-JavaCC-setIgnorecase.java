/** 
 * Sets the IGNORE_CASE grammar option.
 * @param ignoreCase a <code>boolean</code> value.
 */
public void setIgnorecase(boolean ignoreCase){
  optionalAttrs.put(IGNORE_CASE,ignoreCase ? Boolean.TRUE : Boolean.FALSE);
}
