/** 
 * Tells the NetRexx compiler to store the class files in the same directory as the source files. The alternative is the working directory Valid true values are "on" or "true". Anything else sets the flag to false. The default value is true.
 * @param sourcedir a <code>boolean</code> value.
 */
public void setSourcedir(boolean sourcedir){
  this.sourcedir=sourcedir;
}
