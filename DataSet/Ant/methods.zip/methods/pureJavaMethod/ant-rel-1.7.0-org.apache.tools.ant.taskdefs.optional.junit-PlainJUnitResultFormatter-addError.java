/** 
 * Interface TestListener. <p>An error occurred while running the test.
 * @param test the test.
 * @param t    the exception.
 */
public void addError(Test test,Throwable t){
  formatError("\tCaused an ERROR",test,t);
}
