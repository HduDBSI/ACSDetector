/** 
 * Create a temporary file to pass the properties to a new process. Will auto-delete on (graceful) exit. The file will be in the project basedir unless tmpDir declares something else.
 * @param prefix
 * @return created file
 */
private File createTempPropertiesFile(String prefix){
  File propsFile=FILE_UTILS.createTempFile(prefix,".properties",tmpDir != null ? tmpDir : getProject().getBaseDir(),true);
  return propsFile;
}
