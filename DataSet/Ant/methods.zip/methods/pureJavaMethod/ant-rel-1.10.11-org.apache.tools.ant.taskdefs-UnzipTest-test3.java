/** 
 * Expected failure due to required argument not specified
 */
@Test(expected=BuildException.class) public void test3(){
  buildRule.executeTarget("test3");
}
