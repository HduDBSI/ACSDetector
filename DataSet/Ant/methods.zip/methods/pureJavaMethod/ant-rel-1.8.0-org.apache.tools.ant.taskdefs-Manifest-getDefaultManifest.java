/** 
 * Construct a manifest from Ant's default manifest file.
 * @return the default manifest.
 * @exception BuildException if there is a problem loading thedefault manifest
 */
public static Manifest getDefaultManifest() throws BuildException {
  InputStream in=null;
  InputStreamReader insr=null;
  try {
    String defManifest="/org/apache/tools/ant/defaultManifest.mf";
    in=Manifest.class.getResourceAsStream(defManifest);
    if (in == null) {
      throw new BuildException("Could not find default manifest: " + defManifest);
    }
    try {
      insr=new InputStreamReader(in,"UTF-8");
      Manifest defaultManifest=new Manifest(insr);
      String version=System.getProperty("java.runtime.version");
      if (version == null) {
        version=System.getProperty("java.vm.version");
      }
      Attribute createdBy=new Attribute("Created-By",version + " (" + System.getProperty("java.vm.vendor")+ ")");
      defaultManifest.getMainSection().storeAttribute(createdBy);
      return defaultManifest;
    }
 catch (    UnsupportedEncodingException e) {
      insr=new InputStreamReader(in);
      return new Manifest(insr);
    }
  }
 catch (  ManifestException e) {
    throw new BuildException("Default manifest is invalid !!",e);
  }
catch (  IOException e) {
    throw new BuildException("Unable to read default manifest",e);
  }
 finally {
    FileUtils.close(insr);
    FileUtils.close(in);
  }
}
