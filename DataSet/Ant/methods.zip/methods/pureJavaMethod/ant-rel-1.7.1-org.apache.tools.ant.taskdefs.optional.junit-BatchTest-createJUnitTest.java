/** 
 * Create a <tt>JUnitTest</tt> that has the same property as this <tt>BatchTest</tt> instance.
 * @param classname the name of the class that should be run as a<tt>JUnitTest</tt>. It must be a fully qualified name.
 * @return the <tt>JUnitTest</tt> over the given classname.
 */
private JUnitTest createJUnitTest(String classname){
  JUnitTest test=new JUnitTest();
  test.setName(classname);
  test.setHaltonerror(this.haltOnError);
  test.setHaltonfailure(this.haltOnFail);
  test.setFiltertrace(this.filtertrace);
  test.setFork(this.fork);
  test.setIf(this.ifProperty);
  test.setUnless(this.unlessProperty);
  test.setTodir(this.destDir);
  test.setFailureProperty(failureProperty);
  test.setErrorProperty(errorProperty);
  Enumeration list=this.formatters.elements();
  while (list.hasMoreElements()) {
    test.addFormatter((FormatterElement)list.nextElement());
  }
  return test;
}
