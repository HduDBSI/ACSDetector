/** 
 * Receive notification that character data has been found in an iAS-specific descriptor.  We're interested in retrieving data indicating whether the bean must support RMI/IIOP access, whether the bean must provide highly available stubs and skeletons (in the case of stateful session beans), and if this bean uses additional CMP XML descriptors (in the case of entity beans with CMP).
 * @param value String data found in the XML document.
 */
private void iasCharacters(String value){
  String base="\\ias-ejb-jar\\enterprise-beans\\" + ejbType;
  if (currentLoc.equals(base + "\\ejb-name")) {
    currentEjb=(EjbInfo)ejbs.get(value);
    if (currentEjb == null) {
      currentEjb=new EjbInfo(value);
      ejbs.put(value,currentEjb);
    }
  }
 else   if (currentLoc.equals(base + "\\iiop")) {
    currentEjb.setIiop(value);
  }
 else   if (currentLoc.equals(base + "\\failover-required")) {
    currentEjb.setHasession(value);
  }
 else   if (currentLoc.equals(base + "\\persistence-manager" + "\\properties-file-location")) {
    currentEjb.addCmpDescriptor(value);
  }
}
