/** 
 * Charset for cross-platform viewing of generated documentation.
 * @param src the name of the charset
 */
public void setCharset(String src){
  this.addArgIfNotEmpty("-charset",src);
}
