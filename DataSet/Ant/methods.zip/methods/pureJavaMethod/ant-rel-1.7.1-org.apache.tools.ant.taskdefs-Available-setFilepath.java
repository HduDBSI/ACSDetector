/** 
 * Set the path to use when looking for a file.
 * @param filepath a Path instance containing the search path for files.
 */
public void setFilepath(Path filepath){
  createFilepath().append(filepath);
}
