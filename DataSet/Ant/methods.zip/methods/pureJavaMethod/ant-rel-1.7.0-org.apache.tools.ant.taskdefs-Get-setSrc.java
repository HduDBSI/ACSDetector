/** 
 * Set the URL to get.
 * @param u URL for the file.
 */
public void setSrc(URL u){
  this.source=u;
}
