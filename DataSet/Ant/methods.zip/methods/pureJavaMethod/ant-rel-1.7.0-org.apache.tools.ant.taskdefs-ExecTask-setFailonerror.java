/** 
 * Fail if the command exits with a non-zero return code.
 * @param fail if true fail the command on non-zero return code.
 */
public void setFailonerror(boolean fail){
  failOnError=fail;
  incompatibleWithSpawn|=fail;
}
