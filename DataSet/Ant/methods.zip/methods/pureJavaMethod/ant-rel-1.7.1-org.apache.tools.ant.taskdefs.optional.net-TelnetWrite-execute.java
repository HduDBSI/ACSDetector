/** 
 * Execute the write task.
 * @param telnet the task to use
 * @throws BuildException on error
 */
public void execute(AntTelnetClient telnet) throws BuildException {
  telnet.sendString(taskString,echoString);
}
