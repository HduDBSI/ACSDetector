/** 
 * @return true if a socket can be created
 * @exception BuildException if the attributes are not set
 */
public boolean eval() throws BuildException {
  if (server == null) {
    throw new BuildException("No server specified in socket " + "condition");
  }
  if (port == 0) {
    throw new BuildException("No port specified in socket condition");
  }
  log("Checking for listener at " + server + ":"+ port,Project.MSG_VERBOSE);
  java.net.Socket s=null;
  try {
    s=new java.net.Socket(server,port);
  }
 catch (  IOException e) {
    return false;
  }
 finally {
    FileUtils.close(s);
  }
  return true;
}
