/** 
 * return time to sleep
 * @return sleep time. if below 0 then there is an error
 */
private long getSleepTime(){
  return ((((long)hours * 60) + minutes) * 60 + seconds) * 1000 + milliseconds;
}
