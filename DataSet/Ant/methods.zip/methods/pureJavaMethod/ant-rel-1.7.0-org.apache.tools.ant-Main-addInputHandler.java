/** 
 * Creates the InputHandler and adds it to the project.
 * @param project the project instance.
 * @exception BuildException if a specified InputHandlerimplementation could not be loaded.
 */
private void addInputHandler(Project project) throws BuildException {
  InputHandler handler=null;
  if (inputHandlerClassname == null) {
    handler=new DefaultInputHandler();
  }
 else {
    handler=(InputHandler)ClasspathUtils.newInstance(inputHandlerClassname,Main.class.getClassLoader(),InputHandler.class);
    if (project != null) {
      project.setProjectReference(handler);
    }
  }
  project.setInputHandler(handler);
}
