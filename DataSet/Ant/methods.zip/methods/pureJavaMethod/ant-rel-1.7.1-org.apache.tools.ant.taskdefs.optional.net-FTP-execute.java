public void execute() throws IOException {
  doSiteCommand(lftp,FTP.this.siteCommand);
}
