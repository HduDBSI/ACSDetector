/** 
 * Set the classname of the ejbc compiler;  optional Normally ejbjar determines the appropriate class based on the DTD used for the EJB. The EJB 2.0 compiler featured in weblogic 6 has, however, been deprecated in version 7. When using with version 7 this attribute should be set to &quot;weblogic.ejbc&quot; to avoid the deprecation warning.
 * @param ejbcClass the name of the class to use.
 */
public void setEjbcClass(String ejbcClass){
  this.ejbcClass=ejbcClass;
}
