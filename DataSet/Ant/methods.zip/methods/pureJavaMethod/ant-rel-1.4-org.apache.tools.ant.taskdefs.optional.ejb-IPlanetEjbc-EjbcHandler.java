/** 
 * Constructs a new instance of the handler and registers local copies of the standard EJB 1.1 descriptor DTD as well as iAS's EJB descriptor DTD.
 */
public EjbcHandler(){
  final String PUBLICID_EJB11="-//Sun Microsystems, Inc.//DTD Enterprise JavaBeans 1.1//EN";
  final String PUBLICID_IPLANET_EJB_60="-//Sun Microsystems, Inc.//DTD iAS Enterprise JavaBeans 1.0//EN";
  final String DEFAULT_IAS60_EJB11_DTD_LOCATION="ejb-jar_1_1.dtd";
  final String DEFAULT_IAS60_DTD_LOCATION="IASEjb_jar_1_0.dtd";
  registerDTD(PUBLICID_EJB11,DEFAULT_IAS60_EJB11_DTD_LOCATION);
  registerDTD(PUBLICID_IPLANET_EJB_60,DEFAULT_IAS60_DTD_LOCATION);
}
