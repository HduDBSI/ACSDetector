/** 
 * Write the manifest out to a print writer.
 * @param writer the Writer to which the manifest is written
 * @param flatten whether to collapse multi-valued attributes(i.e. potentially Class-Path) Class-Path into a single attribute.
 * @throws IOException if the manifest cannot be written
 * @since Ant 1.8.0
 */
public void write(PrintWriter writer,boolean flatten) throws IOException {
  writer.print(ATTRIBUTE_MANIFEST_VERSION + ": " + manifestVersion+ EOL);
  String signatureVersion=mainSection.getAttributeValue(ATTRIBUTE_SIGNATURE_VERSION);
  if (signatureVersion != null) {
    writer.print(ATTRIBUTE_SIGNATURE_VERSION + ": " + signatureVersion+ EOL);
    mainSection.removeAttribute(ATTRIBUTE_SIGNATURE_VERSION);
  }
  mainSection.write(writer,flatten);
  if (signatureVersion != null) {
    try {
      Attribute svAttr=new Attribute(ATTRIBUTE_SIGNATURE_VERSION,signatureVersion);
      mainSection.addConfiguredAttribute(svAttr);
    }
 catch (    ManifestException e) {
    }
  }
  for (  String sectionName : sections.keySet()) {
    Section section=getSection(sectionName);
    section.write(writer,flatten);
  }
}
