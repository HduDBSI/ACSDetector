/** 
 * Handle output sent to System.err.
 * @param output string of stderr.
 * @since Ant 1.5
 */
protected void handleErrorOutput(String output){
  if (redirector.getErrorStream() != null) {
    redirector.handleErrorOutput(output);
  }
 else {
    super.handleErrorOutput(output);
  }
}
