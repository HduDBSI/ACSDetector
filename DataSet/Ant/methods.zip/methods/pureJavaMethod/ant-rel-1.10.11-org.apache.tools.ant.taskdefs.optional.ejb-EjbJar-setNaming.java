/** 
 * Set the naming scheme used to determine the name of the generated jars from the deployment descriptor
 * @param namingScheme the naming scheme to be used
 */
public void setNaming(NamingScheme namingScheme){
  config.namingScheme=namingScheme;
  if (!NamingScheme.BASEJARNAME.equals(config.namingScheme.getValue()) && config.baseJarName != null) {
    throw new BuildException("The basejarname attribute is not compatible with the %s naming scheme",config.namingScheme.getValue());
  }
}
