@Test public void testSimple(){
  buildRule.executeTarget("simple");
  Project p=buildRule.getProject();
  FileSet fileset=(FileSet)p.getReference("testfileset");
  File baseDir=fileset.getDir(p);
  String log=buildRule.getLog();
  assertTrue("Expecting attribute value printed",log.contains("Attribute attr1 = test"));
  assertTrue("Expecting nested element value printed",log.contains("Fileset basedir = " + baseDir.getAbsolutePath()));
}
