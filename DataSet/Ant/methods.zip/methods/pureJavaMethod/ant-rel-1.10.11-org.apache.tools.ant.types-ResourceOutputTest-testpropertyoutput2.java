/** 
 * Expected failure
 * @throws IOException if something goes wrong
 */
@Test(expected=ImmutableResourceException.class) public void testpropertyoutput2() throws IOException {
  project.setNewProperty("bar","bar");
  PropertyResource r=new PropertyResource(project,"bar");
  testoutput(r);
}
