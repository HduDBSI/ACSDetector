/** 
 * Based on this object's instance variables as well as the EJB to be processed, the correct flags and parameters are set for the ejbc  command-line utility.
 * @param ejb The EJB for which stubs and skeletons will be compiled.
 * @return    An array of Strings which are the command-line parameters forfor the ejbc utility.
 */
private String[] buildArgumentList(EjbInfo ejb){
  List arguments=new ArrayList();
  if (debugOutput) {
    arguments.add("-debug");
  }
  if (ejb.getBeantype().equals(STATELESS_SESSION)) {
    arguments.add("-sl");
  }
 else   if (ejb.getBeantype().equals(STATEFUL_SESSION)) {
    arguments.add("-sf");
  }
  if (ejb.getIiop()) {
    arguments.add("-iiop");
  }
  if (ejb.getCmp()) {
    arguments.add("-cmp");
  }
  if (retainSource) {
    arguments.add("-gs");
  }
  if (ejb.getHasession()) {
    arguments.add("-fo");
  }
  arguments.add("-classpath");
  arguments.add(classpath);
  arguments.add("-d");
  arguments.add(destDirectory.toString());
  arguments.add(ejb.getHome().getQualifiedClassName());
  arguments.add(ejb.getRemote().getQualifiedClassName());
  arguments.add(ejb.getImplementation().getQualifiedClassName());
  return (String[])arguments.toArray(new String[arguments.size()]);
}
