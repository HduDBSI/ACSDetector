/** 
 * Constructor.
 */
public LongCPInfo(){
  super(CONSTANT_Long,2);
}
