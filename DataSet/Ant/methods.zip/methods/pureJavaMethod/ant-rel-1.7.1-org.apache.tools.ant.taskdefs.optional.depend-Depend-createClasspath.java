/** 
 * Adds a classpath to be used for this dependency check.
 * @return A path object to be configured by Ant
 */
public Path createClasspath(){
  if (dependClasspath == null) {
    dependClasspath=new Path(getProject());
  }
  return dependClasspath.createPath();
}
