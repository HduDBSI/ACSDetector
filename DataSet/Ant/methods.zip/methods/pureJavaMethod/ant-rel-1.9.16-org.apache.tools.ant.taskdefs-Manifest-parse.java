/** 
 * Parse a line into name and value pairs
 * @param line the line to be parsed
 * @throws ManifestException if the line does not contain a colonseparating the name and value
 */
public void parse(String line) throws ManifestException {
  int index=line.indexOf(": ");
  if (index == -1) {
    throw new ManifestException("Manifest line \"" + line + "\" is not valid as it does not "+ "contain a name and a value separated by ': ' ");
  }
  name=line.substring(0,index);
  setValue(line.substring(index + 2));
}
