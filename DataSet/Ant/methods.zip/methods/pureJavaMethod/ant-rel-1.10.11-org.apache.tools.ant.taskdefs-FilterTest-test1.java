@Test(expected=BuildException.class) public void test1(){
  buildRule.executeTarget("test1");
}
