/** 
 * Read a class definition from a stream.
 * @param stream the stream from which the class is to be read.
 * @param classname the class name of the class in the stream.
 * @return the Class object read from the stream.
 * @throws IOException if there is a problem reading the class from thestream.
 */
private Class getClassFromStream(InputStream stream,String classname) throws IOException {
  ByteArrayOutputStream baos=new ByteArrayOutputStream();
  int bytesRead=-1;
  byte[] buffer=new byte[BUFFER_SIZE];
  while ((bytesRead=stream.read(buffer,0,BUFFER_SIZE)) != -1) {
    baos.write(buffer,0,bytesRead);
  }
  byte[] classData=baos.toByteArray();
  if (defineClassProtectionDomain != null) {
    try {
      Object domain=getProtectionDomain.invoke(Project.class,new Object[0]);
      Object[] args=new Object[]{classname,classData,new Integer(0),new Integer(classData.length),domain};
      return (Class)defineClassProtectionDomain.invoke(this,args);
    }
 catch (    InvocationTargetException ite) {
      Throwable t=ite.getTargetException();
      if (t instanceof ClassFormatError) {
        throw (ClassFormatError)t;
      }
 else       if (t instanceof NoClassDefFoundError) {
        throw (NoClassDefFoundError)t;
      }
 else {
        throw new IOException(t.toString());
      }
    }
catch (    Exception e) {
      throw new IOException(e.toString());
    }
  }
 else {
    return defineClass(classname,classData,0,classData.length);
  }
}
