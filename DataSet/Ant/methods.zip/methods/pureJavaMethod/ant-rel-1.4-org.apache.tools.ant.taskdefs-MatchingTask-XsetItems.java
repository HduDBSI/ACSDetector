/** 
 * Set this to be the items in the base directory that you want to be included. You can also specify "*" for the items (ie: items="*")  and it will include all the items in the base directory.
 * @param itemString the string containing the files to include.
 */
public void XsetItems(String itemString){
  log("The items attribute is deprecated. " + "Please use the includes attribute.",Project.MSG_WARN);
  if (itemString == null || itemString.equals("*") || itemString.equals(".")) {
    createInclude().setName("**");
  }
 else {
    StringTokenizer tok=new StringTokenizer(itemString,", ");
    while (tok.hasMoreTokens()) {
      String pattern=tok.nextToken().trim();
      if (pattern.length() > 0) {
        createInclude().setName(pattern + "/**");
      }
    }
  }
}
