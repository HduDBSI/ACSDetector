/** 
 * Get the class name of a class in an input stream.
 * @param input an <code>InputStream</code> value
 * @return the name of the class
 * @exception IOException if an error occurs
 */
public static String getClassName(InputStream input) throws IOException {
  DataInputStream data=new DataInputStream(input);
  int cookie=data.readInt();
  if (cookie != CLASS_MAGIC_NUMBER) {
    return null;
  }
  data.readInt();
  ConstantPool constants=new ConstantPool(data);
  Object[] values=constants.values;
  data.readUnsignedShort();
  int classIndex=data.readUnsignedShort();
  Integer stringIndex=(Integer)values[classIndex];
  String className=(String)values[stringIndex.intValue()];
  return className;
}
