/** 
 * Get the index of a given CONSTANT_METHODREF entry in the constant pool.
 * @param methodClassName the name of the class which contains themethod being referenced.
 * @param methodName the name of the method being referenced.
 * @param methodType the type descriptor of the metho dbeing referenced.
 * @return the index at which the given method ref entry occurs in theconstant pool or -1 if the value does not occur.
 */
public int getMethodRefEntry(String methodClassName,String methodName,String methodType){
  int index=-1;
  for (int i=0; i < entries.size() && index == -1; ++i) {
    Object element=entries.elementAt(i);
    if (element instanceof MethodRefCPInfo) {
      MethodRefCPInfo methodRefEntry=(MethodRefCPInfo)element;
      if (methodRefEntry.getMethodClassName().equals(methodClassName) && methodRefEntry.getMethodName().equals(methodName) && methodRefEntry.getMethodType().equals(methodType)) {
        index=i;
      }
    }
  }
  return index;
}
