/** 
 * Create an Execute instance with the correct working directory set.
 * @return an instance of the Execute class.
 * @throws BuildException under unknown circumstances.
 */
protected Execute prepareExec() throws BuildException {
  if (dir == null) {
    dir=getProject().getBaseDir();
  }
  if (redirectorElement != null) {
    redirectorElement.configure(redirector);
  }
  Execute exe=new Execute(createHandler(),createWatchdog());
  exe.setAntRun(getProject());
  exe.setWorkingDirectory(dir);
  exe.setVMLauncher(vmLauncher);
  exe.setSpawn(spawn);
  String[] environment=env.getVariables();
  if (environment != null) {
    for (int i=0; i < environment.length; i++) {
      log("Setting environment variable: " + environment[i],Project.MSG_VERBOSE);
    }
  }
  exe.setNewenvironment(newEnvironment);
  exe.setEnvironment(environment);
  return exe;
}
