/** 
 * Resolves file: URIs relative to the build file.
 * @param publicId The public identifier, or <code>null</code>if none is available. Ignored in this implementation.
 * @param systemId The system identifier provided in the XMLdocument. Will not be <code>null</code>.
 */
public InputSource resolveEntity(String publicId,String systemId){
  helperImpl.project.log("resolving systemId: " + systemId,Project.MSG_VERBOSE);
  if (systemId.startsWith("file:")) {
    String path=fu.fromURI(systemId);
    File file=new File(path);
    if (!file.isAbsolute()) {
      file=fu.resolveFile(helperImpl.buildFileParent,path);
    }
    try {
      InputSource inputSource=new InputSource(new FileInputStream(file));
      inputSource.setSystemId(fu.toURI(file.getAbsolutePath()));
      return inputSource;
    }
 catch (    FileNotFoundException fne) {
      helperImpl.project.log(file.getAbsolutePath() + " could not be found",Project.MSG_WARN);
    }
  }
  return null;
}
