/** 
 * Returns null if the source file name doesn't match the &quot;from&quot; pattern, an one-element array containing the translated file otherwise.
 * @param sourceFileName the source file name
 * @return a one-element array containing the translated file ornull if the to pattern did not match
 */
public String[] mapFileName(String sourceFileName){
  if (sourceFileName == null) {
    return null;
  }
  if (handleDirSep) {
    if (sourceFileName.contains("\\")) {
      sourceFileName=sourceFileName.replace('\\','/');
    }
  }
  if (reg == null || to == null || !reg.matches(sourceFileName,regexpOptions)) {
    return null;
  }
  return new String[]{replaceReferences(sourceFileName)};
}
