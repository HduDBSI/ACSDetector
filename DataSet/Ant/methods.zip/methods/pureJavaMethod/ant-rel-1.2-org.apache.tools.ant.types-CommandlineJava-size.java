public int size(){
  int size=vmCommand.size() + javaCommand.size();
  if (classpath != null && classpath.size() > 0) {
    size+=2;
  }
  return size;
}
