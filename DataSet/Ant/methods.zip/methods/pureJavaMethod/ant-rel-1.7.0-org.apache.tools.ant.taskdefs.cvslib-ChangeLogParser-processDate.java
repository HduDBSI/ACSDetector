/** 
 * Process a line while in "DATE" state.
 * @param line the line to process
 */
private void processDate(final String line){
  if (line.startsWith("date:")) {
    int endOfDateIndex=line.indexOf(';');
    date=line.substring("date: ".length(),endOfDateIndex);
    int startOfAuthorIndex=line.indexOf("author: ",endOfDateIndex + 1);
    int endOfAuthorIndex=line.indexOf(';',startOfAuthorIndex + 1);
    author=line.substring("author: ".length() + startOfAuthorIndex,endOfAuthorIndex);
    status=GET_COMMENT;
    comment="";
  }
}
