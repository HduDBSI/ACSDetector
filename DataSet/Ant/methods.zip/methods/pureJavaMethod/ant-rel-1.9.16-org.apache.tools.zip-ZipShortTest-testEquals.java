/** 
 * Test the contract of the equals method.
 */
@Test public void testEquals(){
  ZipShort zs=new ZipShort(0x1234);
  ZipShort zs2=new ZipShort(0x1234);
  ZipShort zs3=new ZipShort(0x5678);
  assertTrue("reflexive",zs.equals(zs));
  assertTrue("works",zs.equals(zs2));
  assertTrue("works, part two",!zs.equals(zs3));
  assertTrue("symmetric",zs2.equals(zs));
  assertTrue("null handling",!zs.equals(null));
  assertTrue("non ZipShort handling",!zs.equals(Integer.valueOf(0x1234)));
}
