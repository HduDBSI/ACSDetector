/** 
 * Read a manifest file from the given reader
 * @param r is the reader from which the Manifest is read
 * @throws ManifestException if the manifest is not valid accordingto the JAR spec
 * @throws IOException if the manifest cannot be read from the reader.
 */
public Manifest(Reader r) throws ManifestException, IOException {
  BufferedReader reader=new BufferedReader(r);
  String nextSectionName=mainSection.read(reader);
  String readManifestVersion=mainSection.getAttributeValue(ATTRIBUTE_MANIFEST_VERSION);
  if (readManifestVersion != null) {
    manifestVersion=readManifestVersion;
    mainSection.removeAttribute(ATTRIBUTE_MANIFEST_VERSION);
  }
  String line=null;
  while ((line=reader.readLine()) != null) {
    if (line.length() == 0) {
      continue;
    }
    Section section=new Section();
    if (nextSectionName == null) {
      Attribute sectionName=new Attribute(line);
      if (!sectionName.getName().equalsIgnoreCase(ATTRIBUTE_NAME)) {
        throw new ManifestException("Manifest sections should " + "start with a \"" + ATTRIBUTE_NAME + "\" attribute and not \""+ sectionName.getName()+ "\"");
      }
      nextSectionName=sectionName.getValue();
    }
 else {
      Attribute firstAttribute=new Attribute(line);
      section.addAttributeAndCheck(firstAttribute);
    }
    section.setName(nextSectionName);
    nextSectionName=section.read(reader);
    addConfiguredSection(section);
  }
}
