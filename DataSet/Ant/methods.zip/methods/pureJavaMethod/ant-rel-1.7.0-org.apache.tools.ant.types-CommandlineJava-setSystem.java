/** 
 * Cache the system properties and set the system properties to the new values.
 * @throws BuildException if Security prevented this operation.
 */
public void setSystem() throws BuildException {
  try {
    sys=System.getProperties();
    Properties p=new Properties();
    for (Enumeration e=sys.propertyNames(); e.hasMoreElements(); ) {
      String name=(String)e.nextElement();
      p.put(name,sys.getProperty(name));
    }
    p.putAll(mergePropertySets());
    for (Enumeration e=variables.elements(); e.hasMoreElements(); ) {
      Environment.Variable v=(Environment.Variable)e.nextElement();
      v.validate();
      p.put(v.getKey(),v.getValue());
    }
    System.setProperties(p);
  }
 catch (  SecurityException e) {
    throw new BuildException("Cannot modify system properties",e);
  }
}
