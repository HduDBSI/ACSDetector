/** 
 * Returns a Vector of matched groups found in the argument. <p>Group 0 will be the full match, the rest are the parenthesized subexpressions</p>.
 * @param input the string to match against
 * @param options the regex options to use
 * @return the vector of groups
 * @throws BuildException on error
 */
public Vector getGroups(String input,int options) throws BuildException {
  Pattern p=getCompiledPattern(options);
  Matcher matcher=p.matcher(input);
  if (!matcher.find()) {
    return null;
  }
  Vector v=new Vector();
  int cnt=matcher.groupCount();
  for (int i=0; i <= cnt; i++) {
    String match=matcher.group(i);
    if (match == null) {
      match="";
    }
    v.addElement(match);
  }
  return v;
}
