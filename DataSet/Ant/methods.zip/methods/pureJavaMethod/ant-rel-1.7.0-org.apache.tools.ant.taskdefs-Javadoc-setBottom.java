/** 
 * Set the text to be placed at the bottom of each output file.
 * @param bottom the bottom text.
 */
public void setBottom(String bottom){
  Html h=new Html();
  h.addText(bottom);
  addBottom(h);
}
