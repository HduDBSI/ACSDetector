private void processFile(String file) throws BuildException {
  File srcFile=new File(srcDir,file);
  long lastModified=srcFile.lastModified();
  File destD=destDir == null ? srcDir : destDir;
  if (fcv == null) {
    FilterChain fc=new FilterChain();
    fc.add(filter);
    fcv=new Vector<>(1);
    fcv.add(fc);
  }
  File tmpFile=FILE_UTILS.createTempFile(getProject(),"fixcrlf","",null,true,true);
  try {
    FILE_UTILS.copyFile(srcFile,tmpFile,null,fcv,true,false,encoding,outputEncoding == null ? encoding : outputEncoding,getProject());
    File destFile=new File(destD,file);
    boolean destIsWrong=true;
    if (destFile.exists()) {
      log("destFile " + destFile + " exists",Project.MSG_DEBUG);
      destIsWrong=!FILE_UTILS.contentEquals(destFile,tmpFile);
      log(destFile + (destIsWrong ? " is being written" : " is not written, as the contents are identical"),Project.MSG_DEBUG);
    }
    if (destIsWrong) {
      FILE_UTILS.rename(tmpFile,destFile);
      if (preserveLastModified) {
        log("preserved lastModified for " + destFile,Project.MSG_DEBUG);
        FILE_UTILS.setFileLastModified(destFile,lastModified);
      }
    }
  }
 catch (  IOException e) {
    throw new BuildException("error running fixcrlf on file " + srcFile,e);
  }
 finally {
    if (tmpFile != null && tmpFile.exists()) {
      FILE_UTILS.tryHardToDelete(tmpFile);
    }
  }
}
