/** 
 * Test the contract of the equals method.
 */
@Test public void testEquals(){
  ZipLong zl=new ZipLong(0x12345678);
  ZipLong zl2=new ZipLong(0x12345678);
  ZipLong zl3=new ZipLong(0x87654321);
  assertEquals("reflexive",zl,zl);
  assertEquals("works",zl,zl2);
  assertNotEquals("works, part two",zl,zl3);
  assertEquals("symmetric",zl2,zl);
  assertNotEquals("null handling",null,zl);
  assertNotEquals("non ZipLong handling",0x1234,zl);
}
