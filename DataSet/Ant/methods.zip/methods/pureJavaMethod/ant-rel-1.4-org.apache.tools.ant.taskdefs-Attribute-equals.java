public boolean equals(Object rhs){
  if (!(rhs instanceof Attribute)) {
    return false;
  }
  Attribute rhsAttribute=(Attribute)rhs;
  return (name != null && rhsAttribute.name != null && name.toLowerCase().equals(rhsAttribute.name.toLowerCase()) && value != null && value.equals(rhsAttribute.value));
}
