/** 
 * Executes the task.
 * @exception BuildException if there is an execution problem.
 * @todo validate that if either in or out is defined, then both are
 */
@Override public void execute() throws BuildException {
  if ("style".equals(getTaskType())) {
    log("Warning: the task name <style> is deprecated. Use <xslt> instead.",Project.MSG_WARN);
  }
  final File savedBaseDir=baseDir;
  DirectoryScanner scanner;
  String[] list;
  String[] dirs;
  final String baseMessage="specify the stylesheet either as a filename in style attribute " + "or as a nested resource";
  if (xslResource == null && xslFile == null) {
    handleError(baseMessage);
    return;
  }
  if (xslResource != null && xslFile != null) {
    handleError(baseMessage + " but not as both");
    return;
  }
  if (inFile != null && !inFile.exists()) {
    handleError("input file " + inFile + " does not exist");
    return;
  }
  try {
    setupLoader();
    if (sysProperties.size() > 0) {
      sysProperties.setSystem();
    }
    Resource styleResource;
    if (baseDir == null) {
      baseDir=getProject().getBaseDir();
    }
    liaison=getLiaison();
    if (liaison instanceof XSLTLoggerAware) {
      ((XSLTLoggerAware)liaison).setLogger(this);
    }
    log("Using " + liaison.getClass().toString(),Project.MSG_VERBOSE);
    if (xslFile != null) {
      File stylesheet=getProject().resolveFile(xslFile);
      if (!stylesheet.exists()) {
        final File alternative=FILE_UTILS.resolveFile(baseDir,xslFile);
        if (alternative.exists()) {
          log("DEPRECATED - the 'style' attribute should be " + "relative to the project's");
          log("             basedir, not the tasks's basedir.");
          stylesheet=alternative;
        }
      }
      final FileResource fr=new FileResource();
      fr.setProject(getProject());
      fr.setFile(stylesheet);
      styleResource=fr;
    }
 else {
      styleResource=xslResource;
    }
    if (!styleResource.isExists()) {
      handleError("stylesheet " + styleResource + " doesn't exist.");
      return;
    }
    if (inFile != null && outFile != null) {
      process(inFile,outFile,styleResource);
      return;
    }
    checkDest();
    if (useImplicitFileset) {
      scanner=getDirectoryScanner(baseDir);
      log("Transforming into " + destDir,Project.MSG_INFO);
      list=scanner.getIncludedFiles();
      for (int i=0; i < list.length; ++i) {
        process(baseDir,list[i],destDir,styleResource);
      }
      if (performDirectoryScan) {
        dirs=scanner.getIncludedDirectories();
        for (int j=0; j < dirs.length; ++j) {
          list=new File(baseDir,dirs[j]).list();
          for (int i=0; i < list.length; ++i) {
            process(baseDir,dirs[j] + File.separator + list[i],destDir,styleResource);
          }
        }
      }
    }
 else {
      if (resources.size() == 0) {
        if (failOnNoResources) {
          handleError("no resources specified");
        }
        return;
      }
    }
    processResources(styleResource);
  }
  finally {
    if (loader != null) {
      loader.resetThreadContextLoader();
      loader.cleanup();
      loader=null;
    }
    if (sysProperties.size() > 0) {
      sysProperties.restoreSystem();
    }
    liaison=null;
    stylesheetLoaded=false;
    baseDir=savedBaseDir;
  }
}
