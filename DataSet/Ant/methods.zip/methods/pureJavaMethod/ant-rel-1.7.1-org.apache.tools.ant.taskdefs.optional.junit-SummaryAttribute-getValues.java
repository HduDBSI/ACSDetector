/** 
 * list the possible values
 * @return  array of allowed values
 */
public String[] getValues(){
  return new String[]{"true","yes","false","no","on","off","withOutAndErr"};
}
