private void determineOutOfDateClasses(){
  outOfDateClasses=new HashMap<>();
  directories(srcPath).forEach(srcDir -> {
    DirectoryScanner ds=this.getDirectoryScanner(srcDir);
    scanDir(srcDir,ds.getIncludedFiles());
  }
);
  if (classpathDependencies == null) {
    return;
  }
  for (  Map.Entry<String,Set<File>> e : classpathDependencies.entrySet()) {
    String className=e.getKey();
    if (outOfDateClasses.containsKey(className)) {
      continue;
    }
    ClassFileInfo info=classFileInfoMap.get(className);
    if (info != null) {
      for (      File classpathFile : e.getValue()) {
        if (classpathFile.lastModified() > info.absoluteFile.lastModified()) {
          log("Class " + className + " is out of date with respect to "+ classpathFile,Project.MSG_DEBUG);
          outOfDateClasses.put(className,className);
          break;
        }
      }
    }
  }
}
