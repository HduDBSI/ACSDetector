/** 
 * Interpret the filename as a file relative to the given file unless the filename already represents an absolute filename.
 * @param file the "reference" file for relative paths. Thisinstance must be an absolute file and must not contain &quot;./&quot; or &quot;../&quot; sequences (same for \ instead of /).  If it is null, this call is equivalent to <code>new java.io.File(filename)</code>.
 * @param filename a file name.
 * @return an absolute file that doesn't contain &quot;./&quot; or&quot;../&quot; sequences and uses the correct separator for the current platform.
 */
public File resolveFile(File file,String filename){
  filename=filename.replace('/',File.separatorChar).replace('\\',File.separatorChar);
  if (isAbsolutePath(filename)) {
    return normalize(filename);
  }
  if (file == null) {
    return new File(filename);
  }
  File helpFile=new File(file.getAbsolutePath());
  StringTokenizer tok=new StringTokenizer(filename,File.separator);
  while (tok.hasMoreTokens()) {
    String part=tok.nextToken();
    if (part.equals("..")) {
      helpFile=helpFile.getParentFile();
      if (helpFile == null) {
        String msg="The file or path you specified (" + filename + ") is invalid relative to "+ file.getPath();
        throw new BuildException(msg);
      }
    }
 else     if (part.equals(".")) {
    }
 else {
      helpFile=new File(helpFile,part);
    }
  }
  return new File(helpFile.getAbsolutePath());
}
