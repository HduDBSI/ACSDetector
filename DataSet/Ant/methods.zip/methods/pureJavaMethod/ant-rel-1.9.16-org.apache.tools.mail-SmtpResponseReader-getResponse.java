/** 
 * Read until the server indicates that the response is complete.
 * @return Response code (3 digits) + Blank + Text from allresponse line concatenated (with blanks replacing the \r\n sequences).
 * @throws IOException on error.
 */
public String getResponse() throws IOException {
  result.setLength(0);
  String line=reader.readLine();
  if (line != null && line.length() >= 3) {
    result.append(line.substring(0,3));
    result.append(" ");
  }
  while (line != null) {
    append(line);
    if (!hasMoreLines(line)) {
      break;
    }
    line=reader.readLine();
  }
  return result.toString().trim();
}
