/** 
 * The unit of the offset to be applied to the current time. Valid Values are <ul> <li>millisecond</li> <li>second</li> <li>minute</li> <li>hour</li> <li>day</li> <li>week</li> <li>month</li> <li>year</li> </ul> The default unit is day.
 * @param unit
 */
public void setUnit(Unit unit){
  field=unit.getCalendarField();
}
