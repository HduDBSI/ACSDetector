public int length(){
  return line.length();
}
