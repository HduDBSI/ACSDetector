/** 
 * Fired when a task has finished. This event will still be throw if an error occurred during the build.
 * @param event ignored.
 * @see BuildEvent#getException()
 */
public void taskFinished(BuildEvent event){
}
