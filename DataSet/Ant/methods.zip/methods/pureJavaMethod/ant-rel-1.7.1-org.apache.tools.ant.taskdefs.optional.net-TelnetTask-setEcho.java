/** 
 * Whether or not the message should be echoed to the log. Defaults to <code>true</code>.
 * @param b a <code>boolean</code> value
 */
public void setEcho(boolean b){
  echoString=b;
}
