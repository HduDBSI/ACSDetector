/** 
 * Forces initialization of a class in a JDK 1.1 compatible, albeit hacky way.
 * @param theClass The class to initialize.Must not be <code>null</code>.
 * @deprecated since 1.6.x.Use Class.forName with initialize=true instead.
 */
public static void initializeClass(Class theClass){
  final Constructor[] cons=theClass.getDeclaredConstructors();
  if (cons != null) {
    if (cons.length > 0 && cons[0] != null) {
      final String[] strs=new String[NUMBER_OF_STRINGS];
      try {
        cons[0].newInstance((Object[])strs);
      }
 catch (      Exception e) {
      }
    }
  }
}
