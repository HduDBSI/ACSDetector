/** 
 * Close the streams belonging to the given Process.
 * @param process   the <code>Process</code>.
 */
public static void closeStreams(Process process){
  FileUtils.close(process.getInputStream());
  FileUtils.close(process.getOutputStream());
  FileUtils.close(process.getErrorStream());
}
