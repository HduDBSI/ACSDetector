/** 
 * If true, verbose output when signing.
 * @param verbose verbose or not
 */
public void setVerbose(final boolean verbose){
  this.verbose=verbose;
}
