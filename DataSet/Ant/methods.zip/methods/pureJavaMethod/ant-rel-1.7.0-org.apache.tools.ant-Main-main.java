/** 
 * Command line entry point. This method kicks off the building of a project object and executes a build using either a given target or the default target.
 * @param args Command line arguments. Must not be <code>null</code>.
 */
public static void main(String[] args){
  start(args,null,null);
}
