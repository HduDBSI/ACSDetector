/** 
 * Returns the target that fired this event.
 * @return the project that fired this event, or <code>null</code>if this event is a project level event.
 */
public Target getTarget(){
  return target;
}
