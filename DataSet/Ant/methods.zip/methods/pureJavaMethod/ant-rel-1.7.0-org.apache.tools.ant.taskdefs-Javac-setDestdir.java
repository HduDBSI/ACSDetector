/** 
 * Set the destination directory into which the Java source files should be compiled.
 * @param destDir the destination director
 */
public void setDestdir(File destDir){
  this.destDir=destDir;
}
