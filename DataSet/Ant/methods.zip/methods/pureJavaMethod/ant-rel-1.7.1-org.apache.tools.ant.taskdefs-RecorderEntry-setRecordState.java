/** 
 * Turns off or on this recorder.
 * @param state true for on, false for off, null for no change.
 */
public void setRecordState(Boolean state){
  if (state != null) {
    flush();
    record=state.booleanValue();
  }
}
