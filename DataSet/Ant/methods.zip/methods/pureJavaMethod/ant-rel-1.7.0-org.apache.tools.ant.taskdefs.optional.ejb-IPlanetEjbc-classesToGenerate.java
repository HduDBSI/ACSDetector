/** 
 * Builds an array of class names which represent the stubs and skeletons which need to be generated for a given EJB.  The class names are fully qualified.  Nine classes are generated for all EJBs while an additional six classes are generated for beans requiring RMI/IIOP access.
 * @return An array of Strings representing the fully-qualified classnames for the stubs and skeletons to be generated.
 */
private String[] classesToGenerate(){
  String[] classnames=(iiop) ? new String[NUM_CLASSES_WITH_IIOP] : new String[NUM_CLASSES_WITHOUT_IIOP];
  final String remotePkg=remote.getPackageName() + ".";
  final String remoteClass=remote.getClassName();
  final String homePkg=home.getPackageName() + ".";
  final String homeClass=home.getClassName();
  final String implPkg=implementation.getPackageName() + ".";
  final String implFullClass=implementation.getQualifiedWithUnderscores();
  int index=0;
  classnames[index++]=implPkg + "ejb_fac_" + implFullClass;
  classnames[index++]=implPkg + "ejb_home_" + implFullClass;
  classnames[index++]=implPkg + "ejb_skel_" + implFullClass;
  classnames[index++]=remotePkg + "ejb_kcp_skel_" + remoteClass;
  classnames[index++]=homePkg + "ejb_kcp_skel_" + homeClass;
  classnames[index++]=remotePkg + "ejb_kcp_stub_" + remoteClass;
  classnames[index++]=homePkg + "ejb_kcp_stub_" + homeClass;
  classnames[index++]=remotePkg + "ejb_stub_" + remoteClass;
  classnames[index++]=homePkg + "ejb_stub_" + homeClass;
  if (!iiop) {
    return classnames;
  }
  classnames[index++]="org.omg.stub." + remotePkg + "_"+ remoteClass+ "_Stub";
  classnames[index++]="org.omg.stub." + homePkg + "_"+ homeClass+ "_Stub";
  classnames[index++]="org.omg.stub." + remotePkg + "_ejb_RmiCorbaBridge_"+ remoteClass+ "_Tie";
  classnames[index++]="org.omg.stub." + homePkg + "_ejb_RmiCorbaBridge_"+ homeClass+ "_Tie";
  classnames[index++]=remotePkg + "ejb_RmiCorbaBridge_" + remoteClass;
  classnames[index++]=homePkg + "ejb_RmiCorbaBridge_" + homeClass;
  return classnames;
}
