/** 
 * Called when an endelement is seen. This may be overridden in derived classes. This updates the ejbfiles if the element is an interface or a bean class. This updates the ejbname if the element is an ejb name.
 */
protected void processElement(){
  if (inEJBRef || (parseState != STATE_IN_ENTITY && parseState != STATE_IN_SESSION && parseState != STATE_IN_MESSAGE)) {
    return;
  }
  if (currentElement.equals(HOME_INTERFACE) || currentElement.equals(REMOTE_INTERFACE) || currentElement.equals(LOCAL_INTERFACE)|| currentElement.equals(LOCAL_HOME_INTERFACE)|| currentElement.equals(BEAN_CLASS)|| currentElement.equals(PK_CLASS)) {
    File classFile=null;
    String className=currentText.trim();
    if (!className.startsWith("java.") && !className.startsWith("javax.")) {
      className=className.replace('.',File.separatorChar);
      className+=".class";
      classFile=new File(srcDir,className);
      ejbFiles.put(className,classFile);
    }
  }
  if (currentElement.equals(EJB_NAME)) {
    if (ejbName == null) {
      ejbName=currentText.trim();
    }
  }
}
