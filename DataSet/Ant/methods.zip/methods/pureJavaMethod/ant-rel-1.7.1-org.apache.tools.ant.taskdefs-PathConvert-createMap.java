/** 
 * Create a nested MAP element.
 * @return a Map to configure.
 */
public MapEntry createMap(){
  MapEntry entry=new MapEntry();
  prefixMap.addElement(entry);
  return entry;
}
