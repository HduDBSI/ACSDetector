/** 
 * Validate the filter's configuration.
 * @throws BuildException if any part is invalid.
 */
public void validate() throws BuildException {
  if (token == null) {
    String message="token is a mandatory for replacefilter.";
    throw new BuildException(message);
  }
  if ("".equals(token.getText())) {
    String message="The token must not be an empty " + "string.";
    throw new BuildException(message);
  }
  if ((value != null) && (property != null)) {
    String message="Either value or property " + "can be specified, but a replacefilter " + "element cannot have both.";
    throw new BuildException(message);
  }
  if ((property != null)) {
    if (propertyResource == null) {
      String message="The replacefilter's property attribute " + "can only be used with the replacetask's " + "propertyFile/Resource attribute.";
      throw new BuildException(message);
    }
    if (properties == null || properties.getProperty(property) == null) {
      String message="property \"" + property + "\" was not found in "+ propertyResource.getName();
      throw new BuildException(message);
    }
  }
  replaceValue=getReplaceValue();
}
