/** 
 * The numeric offset to the current time.
 * @param offset the offset to use.
 */
public void setOffset(int offset){
  this.offset=offset;
}
