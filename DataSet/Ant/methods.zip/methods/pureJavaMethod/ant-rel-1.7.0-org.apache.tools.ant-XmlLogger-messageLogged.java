/** 
 * Fired when a message is logged, this adds a message element to the most appropriate parent element (task, target or build) and records the priority and text of the message.
 * @param event An event with any relevant extra information.Will not be <code>null</code>.
 */
public void messageLogged(BuildEvent event){
  int priority=event.getPriority();
  if (priority > msgOutputLevel) {
    return;
  }
  Element messageElement=doc.createElement(MESSAGE_TAG);
  String name="debug";
switch (event.getPriority()) {
case Project.MSG_ERR:
    name="error";
  break;
case Project.MSG_WARN:
name="warn";
break;
case Project.MSG_INFO:
name="info";
break;
default :
name="debug";
break;
}
messageElement.setAttribute(PRIORITY_ATTR,name);
Throwable ex=event.getException();
if (Project.MSG_DEBUG <= msgOutputLevel && ex != null) {
Text errText=doc.createCDATASection(StringUtils.getStackTrace(ex));
Element stacktrace=doc.createElement(STACKTRACE_TAG);
stacktrace.appendChild(errText);
buildElement.element.appendChild(stacktrace);
}
Text messageText=doc.createCDATASection(event.getMessage());
messageElement.appendChild(messageText);
TimedElement parentElement=null;
Task task=event.getTask();
Target target=event.getTarget();
if (task != null) {
parentElement=getTaskElement(task);
}
if (parentElement == null && target != null) {
parentElement=(TimedElement)targets.get(target);
}
if (parentElement != null) {
parentElement.element.appendChild(messageElement);
}
 else {
buildElement.element.appendChild(messageElement);
}
}
