/** 
 * Set the exit value.
 * @param value exit value of the process.
 */
protected void setExitValue(int value){
  exitValue=value;
}
