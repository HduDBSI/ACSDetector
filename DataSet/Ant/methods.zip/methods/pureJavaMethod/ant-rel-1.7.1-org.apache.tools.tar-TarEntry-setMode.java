/** 
 * Set the mode for this entry
 * @param mode the mode for this entry
 */
public void setMode(int mode){
  this.mode=mode;
}
