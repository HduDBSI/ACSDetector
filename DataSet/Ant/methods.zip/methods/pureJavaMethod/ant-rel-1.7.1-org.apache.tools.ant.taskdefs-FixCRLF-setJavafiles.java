/** 
 * Set to true if modifying Java source files.
 * @param javafiles whether modifying Java files.
 */
public void setJavafiles(boolean javafiles){
  filter.setJavafiles(javafiles);
}
