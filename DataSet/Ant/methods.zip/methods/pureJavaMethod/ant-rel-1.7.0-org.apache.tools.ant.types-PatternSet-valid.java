private boolean valid(Project p){
  if (ifCond != null && p.getProperty(ifCond) == null) {
    return false;
  }
 else   if (unlessCond != null && p.getProperty(unlessCond) != null) {
    return false;
  }
  return true;
}
