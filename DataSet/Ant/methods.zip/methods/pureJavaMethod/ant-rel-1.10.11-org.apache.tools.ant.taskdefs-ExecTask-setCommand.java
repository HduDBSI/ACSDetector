/** 
 * Sets a command line.
 * @param cmdl command line.
 * @ant.attribute ignore="true"
 */
public void setCommand(Commandline cmdl){
  log("The command attribute is deprecated.\nPlease use the executable attribute and nested arg elements.",Project.MSG_WARN);
  this.cmdl=cmdl;
}
