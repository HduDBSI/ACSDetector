/** 
 * Creates the nested <code>&lt;pathelement&gt;</code> element.
 * @return the <code>PathElement</code> to be configured
 * @throws BuildException on error
 */
public PathElement createPathElement() throws BuildException {
  if (isReference()) {
    throw noChildrenAllowed();
  }
  PathElement pe=new PathElement();
  add(pe);
  return pe;
}
