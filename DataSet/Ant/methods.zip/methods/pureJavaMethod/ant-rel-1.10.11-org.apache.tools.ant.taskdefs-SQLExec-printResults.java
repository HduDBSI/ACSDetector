/** 
 * print any results in the result set.
 * @param rs the resultset to print information about
 * @param out the place to print results
 * @throws SQLException on SQL problems.
 * @since Ant 1.6.3
 */
protected void printResults(ResultSet rs,PrintStream out) throws SQLException {
  if (rs != null) {
    log("Processing new result set.",Project.MSG_VERBOSE);
    ResultSetMetaData md=rs.getMetaData();
    int columnCount=md.getColumnCount();
    if (columnCount > 0) {
      if (showheaders) {
        out.print(maybeQuote(md.getColumnName(1)));
        for (int col=2; col <= columnCount; col++) {
          out.print(csvColumnSep);
          out.print(maybeQuote(md.getColumnName(col)));
        }
        out.println();
      }
      while (rs.next()) {
        printValue(rs,1,out);
        for (int col=2; col <= columnCount; col++) {
          out.print(csvColumnSep);
          printValue(rs,col,out);
        }
        out.println();
        printWarnings(rs.getWarnings(),false);
      }
    }
  }
  out.println();
}
