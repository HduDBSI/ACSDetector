/** 
 * @return a hash code value for this object.
 */
public int hashCode(){
  return objectHashCode(name) + (optional ? 1 : 0) + (implicit ? 1 : 0);
}
