/** 
 * @return true if all the contained conditions evaluates to true
 * @exception BuildException if an error occurs
 */
public boolean eval() throws BuildException {
  Enumeration e=getConditions();
  while (e.hasMoreElements()) {
    Condition c=(Condition)e.nextElement();
    if (!c.eval()) {
      return false;
    }
  }
  return true;
}
