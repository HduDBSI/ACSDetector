/** 
 * Processes a line of input and determines if an error occurred.
 */
private void processLine(){
  String s=line.toString();
  task.log(s,msgOutputLevel);
  line=new StringBuffer();
}
