/** 
 * Close the reader.
 * @throws IOException if there is an error.
 */
public void close() throws IOException {
  if (reader != null) {
    reader.close();
  }
}
