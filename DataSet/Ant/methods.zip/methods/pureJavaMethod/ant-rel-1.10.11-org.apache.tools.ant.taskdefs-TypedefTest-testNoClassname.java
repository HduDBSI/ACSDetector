@Test(expected=BuildException.class) public void testNoClassname(){
  buildRule.executeTarget("noClassname");
}
