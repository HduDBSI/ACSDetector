/** 
 * Gets the classpath to be used for this compilation.
 * @return the class path
 */
public Path getClasspath(){
  return compileClasspath;
}
