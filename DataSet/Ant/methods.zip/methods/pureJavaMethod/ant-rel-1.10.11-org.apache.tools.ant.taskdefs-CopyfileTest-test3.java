@Test(expected=BuildException.class) public void test3(){
  buildRule.executeTarget("test3");
}
