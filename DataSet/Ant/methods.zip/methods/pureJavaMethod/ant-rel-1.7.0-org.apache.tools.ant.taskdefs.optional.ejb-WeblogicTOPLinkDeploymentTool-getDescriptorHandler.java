/** 
 * Get the descriptor handler.
 * @param srcDir the source file.
 * @return the descriptor handler.
 */
protected DescriptorHandler getDescriptorHandler(File srcDir){
  DescriptorHandler handler=super.getDescriptorHandler(srcDir);
  if (toplinkDTD != null) {
    handler.registerDTD("-//The Object People, Inc.//" + "DTD TOPLink for WebLogic CMP 2.5.1//EN",toplinkDTD);
  }
 else {
    handler.registerDTD("-//The Object People, Inc.//" + "DTD TOPLink for WebLogic CMP 2.5.1//EN",TL_DTD_LOC);
  }
  return handler;
}
