/** 
 * If true, keeps a copy of the file with a .keep extension.
 * @param keep the status to set the flag to
 */
public void setKeepCopy(boolean keep){
  mKeep=keep;
}
