/** 
 * Does the work.
 * @exception BuildException Thrown in unrecoverable error.
 */
public void execute() throws BuildException {
  int logLevel=Project.MSG_INFO;
  DownloadProgress progress=null;
  if (verbose) {
    progress=new VerboseProgress(System.out);
  }
  try {
    doGet(logLevel,progress);
  }
 catch (  IOException ioe) {
    log("Error getting " + source + " to "+ dest);
    if (!ignoreErrors) {
      throw new BuildException(ioe,getLocation());
    }
  }
}
