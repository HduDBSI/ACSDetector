private String getEntryName(File file,String prefix){
  String name=file.getName();
  if (!name.endsWith(".class")) {
    InputStream input=null;
    try {
      input=new FileInputStream(file);
      String className=ClassNameReader.getClassName(input);
      if (className != null) {
        return className.replace('.','/') + ".class";
      }
    }
 catch (    IOException ioe) {
    }
 finally {
      FileUtils.close(input);
    }
  }
  System.out.println("From " + file.getPath() + " and prefix "+ prefix+ ", creating entry "+ prefix+ name);
  return (prefix + name);
}
