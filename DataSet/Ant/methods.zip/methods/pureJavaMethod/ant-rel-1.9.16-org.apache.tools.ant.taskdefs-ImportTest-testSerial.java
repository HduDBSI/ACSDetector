@Test public void testSerial(){
  buildRule.configureProject("src/etc/testcases/taskdefs/import/subdir/serial.xml");
  assertContains("Unnamed2.xmlUnnamed1.xml",buildRule.getLog());
  assertContains("Expected string was not found in log","Skipped already imported file",buildRule.getFullLog());
}
