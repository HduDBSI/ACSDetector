public void setEight(int i){
  assertEquals(2,i);
}
