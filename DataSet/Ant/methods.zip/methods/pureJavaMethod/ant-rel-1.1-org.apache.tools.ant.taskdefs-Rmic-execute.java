public void execute() throws BuildException {
  File baseDir=project.resolveFile(base);
  if (baseDir == null) {
    throw new BuildException("base attribute must be set!",location);
  }
  if (!baseDir.exists()) {
    throw new BuildException("base does not exist!",location);
  }
  if (verify) {
    log("Verify has been turned on.",Project.MSG_INFO);
  }
  File sourceBaseFile=null;
  if (null != sourceBase) {
    sourceBaseFile=project.resolveFile(sourceBase);
  }
  String classpath=getCompileClasspath(baseDir);
  if (classname == null) {
    DirectoryScanner ds=this.getDirectoryScanner(baseDir);
    String[] files=ds.getIncludedFiles();
    scanDir(baseDir,files,verify);
  }
  sun.rmi.rmic.Main compiler=new sun.rmi.rmic.Main(System.out,"rmic");
  int argCount=5;
  int i=0;
  if (null != stubVersion)   argCount++;
  if (null != sourceBase)   argCount++;
  if (compileList.size() > 0)   argCount+=compileList.size() - 1;
  String[] args=new String[argCount];
  args[i++]="-d";
  args[i++]=baseDir.getAbsolutePath();
  args[i++]="-classpath";
  args[i++]=classpath;
  if (null != stubVersion) {
    if ("1.1".equals(stubVersion))     args[i++]="-v1.1";
 else     if ("1.2".equals(stubVersion))     args[i++]="-v1.2";
 else     args[i++]="-vcompat";
  }
  if (null != sourceBase)   args[i++]="-keepgenerated";
  if (classname != null) {
    if (shouldCompile(new File(baseDir,classname.replace('.',File.separatorChar) + ".class"))) {
      args[i++]=classname;
      compiler.compile(args);
    }
  }
 else {
    if (compileList.size() > 0) {
      log("RMI Compiling " + compileList.size() + " classes to "+ baseDir,Project.MSG_INFO);
      for (int j=0; j < compileList.size(); j++) {
        args[i++]=(String)compileList.elementAt(j);
      }
      compiler.compile(args);
    }
  }
  if (null != sourceBase) {
    if (classname != null) {
      moveGeneratedFile(baseDir,sourceBaseFile,classname);
    }
 else {
      for (int j=0; j < compileList.size(); j++) {
        moveGeneratedFile(baseDir,sourceBaseFile,(String)compileList.elementAt(j));
      }
    }
  }
}
