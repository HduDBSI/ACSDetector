/** 
 * scans a particular directory
 * @param dir directory to scan
 * @param vpath  relative path to the base directory of the remote filesetalways ended with a File.separator
 * @param fast seems to be always true in practice
 */
protected void scandir(String dir,String vpath,boolean fast){
  if (fast && hasBeenScanned(vpath)) {
    return;
  }
  try {
    if (!ftp.changeWorkingDirectory(dir)) {
      return;
    }
    String completePath=null;
    if (!vpath.equals("")) {
      completePath=rootPath + remoteFileSep + vpath.replace(File.separatorChar,remoteFileSep.charAt(0));
    }
 else {
      completePath=rootPath;
    }
    FTPFile[] newfiles=listFiles(completePath,false);
    if (newfiles == null) {
      ftp.changeToParentDirectory();
      return;
    }
    for (int i=0; i < newfiles.length; i++) {
      FTPFile file=newfiles[i];
      if (file != null && !file.getName().equals(".") && !file.getName().equals("..")) {
        if (isFunctioningAsDirectory(ftp,dir,file)) {
          String name=vpath + file.getName();
          boolean slowScanAllowed=true;
          if (!isFollowSymlinks() && file.isSymbolicLink()) {
            dirsExcluded.addElement(name);
            slowScanAllowed=false;
          }
 else           if (isIncluded(name)) {
            accountForIncludedDir(name,new AntFTPFile(ftp,file,completePath),fast);
          }
 else {
            dirsNotIncluded.addElement(name);
            if (fast && couldHoldIncluded(name)) {
              scandir(file.getName(),name + File.separator,fast);
            }
          }
          if (!fast && slowScanAllowed) {
            scandir(file.getName(),name + File.separator,fast);
          }
        }
 else {
          String name=vpath + file.getName();
          if (!isFollowSymlinks() && file.isSymbolicLink()) {
            filesExcluded.addElement(name);
          }
 else           if (isFunctioningAsFile(ftp,dir,file)) {
            accountForIncludedFile(name);
          }
        }
      }
    }
    ftp.changeToParentDirectory();
  }
 catch (  IOException e) {
    throw new BuildException("Error while communicating with FTP " + "server: ",e);
  }
}
