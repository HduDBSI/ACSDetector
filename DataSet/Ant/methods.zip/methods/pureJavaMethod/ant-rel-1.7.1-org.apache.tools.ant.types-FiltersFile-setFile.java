/** 
 * Sets the file from which filters will be read.
 * @param file the file from which filters will be read.
 */
public void setFile(File file){
  filtersFiles.add(file);
}
