/** 
 * Test merge methods
 */
public void testMerge(){
  byte[] local=ExtraFieldUtils.mergeLocalFileDataData(new ZipExtraField[]{a,dummy});
  assertEquals("local length",data.length,local.length);
  for (int i=0; i < local.length; i++) {
    assertEquals("local byte " + i,data[i],local[i]);
  }
  byte[] dummyCentral=dummy.getCentralDirectoryData();
  byte[] data2=new byte[4 + aLocal.length + 4+ dummyCentral.length];
  System.arraycopy(data,0,data2,0,4 + aLocal.length + 2);
  System.arraycopy(dummy.getCentralDirectoryLength().getBytes(),0,data2,4 + aLocal.length + 2,2);
  System.arraycopy(dummyCentral,0,data2,4 + aLocal.length + 4,dummyCentral.length);
  byte[] central=ExtraFieldUtils.mergeCentralDirectoryData(new ZipExtraField[]{a,dummy});
  assertEquals("central length",data2.length,central.length);
  for (int i=0; i < central.length; i++) {
    assertEquals("central byte " + i,data2[i],central[i]);
  }
}
