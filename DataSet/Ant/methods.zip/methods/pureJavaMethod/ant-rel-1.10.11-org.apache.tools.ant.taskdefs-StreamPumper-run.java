@Override public void run(){
  try {
    try {
      while (!endOfStream) {
        pumpStream();
        sleep(SLEEP_TIME);
      }
    }
 catch (    InterruptedException ie) {
    }
    din.close();
  }
 catch (  IOException ioe) {
  }
}
