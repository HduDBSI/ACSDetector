public void start(){
  start=System.currentTimeMillis();
}
