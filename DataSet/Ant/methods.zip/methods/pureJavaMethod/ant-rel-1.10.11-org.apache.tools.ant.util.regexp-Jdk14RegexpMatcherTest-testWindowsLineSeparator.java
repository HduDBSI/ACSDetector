/** 
 * Should trigger once fixed.  {@since JDK 1.4RC1}
 */
@Test public void testWindowsLineSeparator(){
  super.testWindowsLineSeparator();
}
