/** 
 * Setter used to store the location of the borland DTD. This can be a file on the system or a resource on the classpath.
 * @param inString the string to use as the DTD location.
 */
public void setBASdtd(String inString){
  this.borlandDTD=inString;
}
