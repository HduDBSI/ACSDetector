/** 
 * Generate a deep clone of the contained object.
 * @return a clone of the contained object
 */
public Object clone(){
  try {
    Commandline c=(Commandline)super.clone();
    c.arguments=(Vector)arguments.clone();
    return c;
  }
 catch (  CloneNotSupportedException e) {
    throw new BuildException(e);
  }
}
