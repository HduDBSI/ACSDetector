/** 
 * test for a file being signed, by looking for a signature in the META-INF directory with our alias.
 * @param file the file to be checked
 * @return true if the file is signed
 * @see IsSigned#isSigned(File,String)
 */
protected boolean isSigned(File file){
  try {
    return IsSigned.isSigned(file,alias);
  }
 catch (  IOException e) {
    log(e.toString(),Project.MSG_VERBOSE);
    return false;
  }
}
