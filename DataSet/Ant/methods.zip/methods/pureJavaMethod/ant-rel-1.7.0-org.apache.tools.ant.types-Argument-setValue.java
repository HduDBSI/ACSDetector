/** 
 * Set a single commandline argument.
 * @param value a single commandline argument.
 */
public void setValue(String value){
  parts=new String[]{value};
}
