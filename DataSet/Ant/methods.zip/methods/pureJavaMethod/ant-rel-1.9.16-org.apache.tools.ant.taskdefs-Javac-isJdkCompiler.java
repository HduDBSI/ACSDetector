/** 
 * Is the compiler implementation a jdk compiler
 * @param compilerImpl the name of the compiler implementation
 * @return true if compilerImpl is "modern", "classic","javac1.1", "javac1.2", "javac1.3", "javac1.4", "javac1.5", "javac1.6", "javac1.7", "javac1.8", "javac1.9", "javac9" or "javac10+".
 */
protected boolean isJdkCompiler(final String compilerImpl){
  return MODERN.equals(compilerImpl) || CLASSIC.equals(compilerImpl) || JAVAC10_PLUS.equals(compilerImpl)|| JAVAC9.equals(compilerImpl)|| JAVAC18.equals(compilerImpl)|| JAVAC17.equals(compilerImpl)|| JAVAC16.equals(compilerImpl)|| JAVAC15.equals(compilerImpl)|| JAVAC14.equals(compilerImpl)|| JAVAC13.equals(compilerImpl)|| JAVAC12.equals(compilerImpl)|| JAVAC11.equals(compilerImpl);
}
