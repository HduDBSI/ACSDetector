/** 
 * If true, updates an existing file, otherwise overwrite any existing one; optional defaults to false.
 * @param c if true, updates an existing zip file
 */
public void setUpdate(boolean c){
  doUpdate=c;
  savedDoUpdate=c;
}
