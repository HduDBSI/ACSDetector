/** 
 * Wrap the input stream with the internal filters necessary to perform the configuration settings.
 */
private void initInternalFilters(){
  in=(ctrlz == AddAsisRemove.REMOVE) ? new RemoveEofFilter(in) : in;
  if (eol != CrLf.ASIS) {
    in=new NormalizeEolFilter(in,calculateEolString(eol),getFixlast());
  }
  if (tabs != AddAsisRemove.ASIS) {
    if (getJavafiles()) {
      in=new MaskJavaTabLiteralsFilter(in);
    }
    in=(tabs == AddAsisRemove.ADD) ? new AddTabFilter(in,getTablength()) : new RemoveTabFilter(in,getTablength());
  }
  in=(ctrlz == AddAsisRemove.ADD) ? new AddEofFilter(in) : in;
  initialized=true;
}
