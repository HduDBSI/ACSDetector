/** 
 * demand creation of the package list. When you add a new package, add a new test below.
 */
private static void buildJrePackages(){
  jrePackages=new Vector<>();
  jrePackages.addElement("sun");
  jrePackages.addElement("java");
  jrePackages.addElement("javax");
  jrePackages.addElement("com.sun.java");
  jrePackages.addElement("com.sun.image");
  jrePackages.addElement("org.omg");
  jrePackages.addElement("com.sun.corba");
  jrePackages.addElement("com.sun.jndi");
  jrePackages.addElement("com.sun.media");
  jrePackages.addElement("com.sun.naming");
  jrePackages.addElement("com.sun.org.omg");
  jrePackages.addElement("com.sun.rmi");
  jrePackages.addElement("sunw.io");
  jrePackages.addElement("sunw.util");
  jrePackages.addElement("org.ietf.jgss");
  jrePackages.addElement("org.w3c.dom");
  jrePackages.addElement("org.xml.sax");
  jrePackages.addElement("com.sun.org.apache");
  jrePackages.addElement("jdk");
}
