/** 
 * Run the task.
 * @throws BuildException if there is an error.
 */
@Override public void execute() throws BuildException {
  if (!destinationDirectory.isDirectory()) {
    throw new BuildException("destination directory %s is not valid",destinationDirectory.getPath());
  }
  if (!sourceDirectory.isDirectory()) {
    throw new BuildException("src directory %s is not valid",sourceDirectory.getPath());
  }
  if (destinationPackage == null) {
    throw new BuildException("package attribute must be present.",getLocation());
  }
  pathToPackage=this.destinationPackage.replace('.',File.separatorChar);
  DirectoryScanner ds=super.getDirectoryScanner(sourceDirectory);
  if (compileClasspath == null) {
    compileClasspath=new Path(getProject());
  }
  compileClasspath=compileClasspath.concatSystemClasspath();
  Java helperTask=new Java(this);
  helperTask.setFork(true);
  helperTask.setClassname("weblogic.jspc");
  helperTask.setTaskName(getTaskName());
  String[] args=new String[12];
  int j=0;
  args[j++]="-d";
  args[j++]=destinationDirectory.getAbsolutePath().trim();
  args[j++]="-docroot";
  args[j++]=sourceDirectory.getAbsolutePath().trim();
  args[j++]="-keepgenerated";
  args[j++]="-compilerclass";
  args[j++]="sun.tools.javac.Main";
  args[j++]="-classpath";
  args[j++]=compileClasspath.toString();
  this.scanDir(ds.getIncludedFiles());
  log("Compiling " + filesToDo.size() + " JSP files");
  for (  String filename : filesToDo) {
    File jspFile=new File(filename);
    args[j]="-package";
    String parents=jspFile.getParent();
    if (parents == null || parents.isEmpty()) {
      args[j + 1]=destinationPackage;
    }
 else {
      parents=this.replaceString(parents,File.separator,"_.");
      args[j + 1]=destinationPackage + "." + "_"+ parents;
    }
    args[j + 2]=sourceDirectory + File.separator + filename;
    helperTask.clearArgs();
    for (int x=0; x < j + 3; x++) {
      helperTask.createArg().setValue(args[x]);
    }
    helperTask.setClasspath(compileClasspath);
    if (helperTask.executeJava() != 0) {
      log(filename + " failed to compile",Project.MSG_WARN);
    }
  }
}
