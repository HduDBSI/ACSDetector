/** 
 * Constructor.  
 */
public LongCPInfo(){
  super(CONSTANT_LONG,2);
}
