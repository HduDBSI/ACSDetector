/** 
 * Constructor for a FilterSetCollection.
 * @param filterSet a filterset to start the collection with
 */
public FilterSetCollection(FilterSet filterSet){
  addFilterSet(filterSet);
}
