private void playClip(Clip clip,long duration){
  clip.loop(Clip.LOOP_CONTINUOUSLY);
  try {
    Thread.sleep(duration);
  }
 catch (  InterruptedException e) {
  }
}
