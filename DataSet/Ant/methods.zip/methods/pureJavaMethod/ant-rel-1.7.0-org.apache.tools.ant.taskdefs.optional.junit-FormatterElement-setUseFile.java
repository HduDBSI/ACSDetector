/** 
 * Set whether the formatter should log to file.
 * @param useFile if true use a file, if false sendto standard out.
 */
public void setUseFile(boolean useFile){
  this.useFile=useFile;
}
