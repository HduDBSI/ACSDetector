/** 
 * Performs a compile using the sj compiler from Symantec.
 * @return true if the compilation succeeded
 * @throws BuildException on error
 */
public boolean execute() throws BuildException {
  attributes.log("Using symantec java compiler",Project.MSG_VERBOSE);
  Commandline cmd=setupJavacCommand();
  String exec=getJavac().getExecutable();
  cmd.setExecutable(exec == null ? "sj" : exec);
  int firstFileName=cmd.size() - compileList.length;
  return executeExternalCompile(cmd.getCommandline(),firstFileName) == 0;
}
