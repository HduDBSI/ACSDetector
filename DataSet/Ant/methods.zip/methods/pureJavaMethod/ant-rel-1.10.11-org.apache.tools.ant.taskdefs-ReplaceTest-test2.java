/** 
 * Fail: required argument not specified
 */
@Test(expected=BuildException.class) public void test2(){
  buildRule.executeTarget("test2");
}
