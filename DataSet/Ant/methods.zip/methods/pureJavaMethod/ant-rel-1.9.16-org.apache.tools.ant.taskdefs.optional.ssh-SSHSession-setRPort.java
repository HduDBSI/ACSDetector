public void setRPort(final int rport){
  final Integer portKey=new Integer(rport);
  if (remotePortsUsed.contains(portKey)) {
    throw new BuildException("Multiple remote tunnels defined to" + " use same remote port " + rport);
  }
  remotePortsUsed.add(portKey);
  this.rport=rport;
}
