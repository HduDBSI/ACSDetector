/** 
 * Fail due to missing required argument
 */
@Test(expected=BuildException.class) public void test2(){
  buildRule.executeTarget("test2");
}
