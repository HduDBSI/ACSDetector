/** 
 * a timeout value that overrides any task wide timeout.
 * @param i an <code>Integer</code> value
 */
public void setTimeout(Integer i){
  this.timeout=i;
}
