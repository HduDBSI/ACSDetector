/** 
 * resolve properties inside a properties hashtable
 * @param props properties object to resolve
 */
private void resolveAllProperties(Properties props) throws BuildException {
  for (Enumeration e=props.keys(); e.hasMoreElements(); ) {
    String name=(String)e.nextElement();
    Stack referencesSeen=new Stack();
    resolve(props,name,referencesSeen);
  }
}
