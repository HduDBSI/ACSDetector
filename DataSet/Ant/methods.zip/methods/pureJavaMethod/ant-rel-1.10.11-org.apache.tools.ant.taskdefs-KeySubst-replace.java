/** 
 * Does replacement on text using the hashtable of keys.
 * @param origString an input string
 * @param keys       mapping of keys to values
 * @return the string with the replacements in it.
 * @throws BuildException on error
 */
public static String replace(String origString,Hashtable<String,String> keys) throws BuildException {
  StringBuffer finalString=new StringBuffer();
  int index=0;
  int i=0;
  String key=null;
  while ((index=origString.indexOf("${",i)) > -1) {
    key=origString.substring(index + 2,origString.indexOf("}",index + 3));
    finalString.append(origString,i,index);
    if (keys.containsKey(key)) {
      finalString.append(keys.get(key));
    }
 else {
      finalString.append("${");
      finalString.append(key);
      finalString.append("}");
    }
    i=index + 3 + key.length();
  }
  finalString.append(origString.substring(i));
  return finalString.toString();
}
