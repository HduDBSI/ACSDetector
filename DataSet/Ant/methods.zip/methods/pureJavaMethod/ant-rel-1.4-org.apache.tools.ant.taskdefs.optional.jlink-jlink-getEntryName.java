private String getEntryName(File file,String prefix){
  String name=file.getName();
  if (!name.endsWith(".class")) {
    try {
      InputStream input=new FileInputStream(file);
      String className=ClassNameReader.getClassName(input);
      input.close();
      if (className != null) {
        return className.replace('.','/') + ".class";
      }
    }
 catch (    IOException ioe) {
    }
  }
  System.out.println("From " + file.getPath() + " and prefix "+ prefix+ ", creating entry "+ prefix+ name);
  return (prefix + name);
}
