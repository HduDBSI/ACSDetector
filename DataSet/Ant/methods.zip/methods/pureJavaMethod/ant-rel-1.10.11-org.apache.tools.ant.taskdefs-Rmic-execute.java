/** 
 * execute by creating an instance of an implementation class and getting to do the work
 * @throws BuildException if there's a problem with baseDir or RMIC
 */
@Override public void execute() throws BuildException {
  try {
    compileList.clear();
    File outputDir=getOutputDir();
    if (outputDir == null) {
      throw new BuildException(ERROR_BASE_NOT_SET,getLocation());
    }
    if (!outputDir.exists()) {
      throw new BuildException(ERROR_NO_BASE_EXISTS + outputDir,getLocation());
    }
    if (!outputDir.isDirectory()) {
      throw new BuildException(ERROR_NOT_A_DIR + outputDir,getLocation());
    }
    if (verify) {
      log("Verify has been turned on.",Project.MSG_VERBOSE);
    }
    RmicAdapter adapter=nestedAdapter != null ? nestedAdapter : RmicAdapterFactory.getRmic(getCompiler(),this,createCompilerClasspath());
    adapter.setRmic(this);
    Path classpath=adapter.getClasspath();
    loader=getProject().createClassLoader(classpath);
    if (classname == null) {
      DirectoryScanner ds=this.getDirectoryScanner(baseDir);
      scanDir(baseDir,ds.getIncludedFiles(),adapter.getMapper());
    }
 else {
      String path=classname.replace('.',File.separatorChar) + ".class";
      File f=new File(baseDir,path);
      if (f.isFile()) {
        scanDir(baseDir,new String[]{path},adapter.getMapper());
      }
 else {
        compileList.add(classname);
      }
    }
    int fileCount=compileList.size();
    if (fileCount > 0) {
      log("RMI Compiling " + fileCount + " class"+ (fileCount > 1 ? "es" : "")+ " to "+ outputDir,Project.MSG_INFO);
      if (listFiles) {
        compileList.forEach(this::log);
      }
      if (!adapter.execute()) {
        throw new BuildException(ERROR_RMIC_FAILED,getLocation());
      }
    }
    if (null != sourceBase && !outputDir.equals(sourceBase) && fileCount > 0) {
      if (idl) {
        log("Cannot determine sourcefiles in idl mode, ",Project.MSG_WARN);
        log("sourcebase attribute will be ignored.",Project.MSG_WARN);
      }
 else {
        compileList.forEach(f -> moveGeneratedFile(outputDir,sourceBase,f,adapter));
      }
    }
  }
  finally {
    cleanup();
  }
}
