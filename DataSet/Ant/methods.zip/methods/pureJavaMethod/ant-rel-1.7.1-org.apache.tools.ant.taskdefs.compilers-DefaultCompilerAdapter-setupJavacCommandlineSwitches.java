/** 
 * Does the command line argument processing common to classic and modern.  Doesn't add the files to compile.
 * @param cmd the command line
 * @param useDebugLevel if true set set the debug level with the -g switch
 * @return the command line
 */
protected Commandline setupJavacCommandlineSwitches(Commandline cmd,boolean useDebugLevel){
  Path classpath=getCompileClasspath();
  Path sourcepath=null;
  if (compileSourcepath != null) {
    sourcepath=compileSourcepath;
  }
 else {
    sourcepath=src;
  }
  String memoryParameterPrefix=assumeJava11() ? "-J-" : "-J-X";
  if (memoryInitialSize != null) {
    if (!attributes.isForkedJavac()) {
      attributes.log("Since fork is false, ignoring " + "memoryInitialSize setting.",Project.MSG_WARN);
    }
 else {
      cmd.createArgument().setValue(memoryParameterPrefix + "ms" + memoryInitialSize);
    }
  }
  if (memoryMaximumSize != null) {
    if (!attributes.isForkedJavac()) {
      attributes.log("Since fork is false, ignoring " + "memoryMaximumSize setting.",Project.MSG_WARN);
    }
 else {
      cmd.createArgument().setValue(memoryParameterPrefix + "mx" + memoryMaximumSize);
    }
  }
  if (attributes.getNowarn()) {
    cmd.createArgument().setValue("-nowarn");
  }
  if (deprecation) {
    cmd.createArgument().setValue("-deprecation");
  }
  if (destDir != null) {
    cmd.createArgument().setValue("-d");
    cmd.createArgument().setFile(destDir);
  }
  cmd.createArgument().setValue("-classpath");
  if (assumeJava11()) {
    Path cp=new Path(project);
    Path bp=getBootClassPath();
    if (bp.size() > 0) {
      cp.append(bp);
    }
    if (extdirs != null) {
      cp.addExtdirs(extdirs);
    }
    cp.append(classpath);
    cp.append(sourcepath);
    cmd.createArgument().setPath(cp);
  }
 else {
    cmd.createArgument().setPath(classpath);
    if (sourcepath.size() > 0) {
      cmd.createArgument().setValue("-sourcepath");
      cmd.createArgument().setPath(sourcepath);
    }
    if (target != null) {
      cmd.createArgument().setValue("-target");
      cmd.createArgument().setValue(target);
    }
    Path bp=getBootClassPath();
    if (bp.size() > 0) {
      cmd.createArgument().setValue("-bootclasspath");
      cmd.createArgument().setPath(bp);
    }
    if (extdirs != null && extdirs.size() > 0) {
      cmd.createArgument().setValue("-extdirs");
      cmd.createArgument().setPath(extdirs);
    }
  }
  if (encoding != null) {
    cmd.createArgument().setValue("-encoding");
    cmd.createArgument().setValue(encoding);
  }
  if (debug) {
    if (useDebugLevel && !assumeJava11()) {
      String debugLevel=attributes.getDebugLevel();
      if (debugLevel != null) {
        cmd.createArgument().setValue("-g:" + debugLevel);
      }
 else {
        cmd.createArgument().setValue("-g");
      }
    }
 else {
      cmd.createArgument().setValue("-g");
    }
  }
 else   if (getNoDebugArgument() != null) {
    cmd.createArgument().setValue(getNoDebugArgument());
  }
  if (optimize) {
    cmd.createArgument().setValue("-O");
  }
  if (depend) {
    if (assumeJava11()) {
      cmd.createArgument().setValue("-depend");
    }
 else     if (assumeJava12()) {
      cmd.createArgument().setValue("-Xdepend");
    }
 else {
      attributes.log("depend attribute is not supported by the " + "modern compiler",Project.MSG_WARN);
    }
  }
  if (verbose) {
    cmd.createArgument().setValue("-verbose");
  }
  addCurrentCompilerArgs(cmd);
  return cmd;
}
