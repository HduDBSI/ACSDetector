/** 
 * @return the value of the haltonerror attribute
 */
public boolean getHaltonerror(){
  return haltonerror;
}
