public void testManualStop() throws Exception {
  final Process process=getProcess(TIME_OUT * 2);
  watchdog.start(process);
  Thread thread=new Thread(){
    public void run(){
      try {
        process.waitFor();
      }
 catch (      InterruptedException e) {
        fail("process interrupted in thread");
      }
    }
  }
;
  thread.start();
  thread.join(TIME_OUT / 2);
  watchdog.stop();
  thread.join();
  assertEquals(0,process.exitValue());
  assert ("process should not have been killed"=!watchdog.killedProcess());
}
