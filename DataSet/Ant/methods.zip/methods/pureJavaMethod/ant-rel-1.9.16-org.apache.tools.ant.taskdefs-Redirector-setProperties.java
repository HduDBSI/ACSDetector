/** 
 * Notify the <code>Redirector</code> that it is now okay to set any output and/or error properties.
 */
public void setProperties(){
synchronized (outMutex) {
    FileUtils.close(baos);
  }
synchronized (errMutex) {
    FileUtils.close(errorBaos);
  }
}
