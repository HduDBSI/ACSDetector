/** 
 * Entry point for standalone (forked) mode. Parameters: testcaseclassname plus parameters in the format key=value, none of which is required. <table cols="4" border="1"> <tr><th>key</th><th>description</th><th>default value</th></tr> <tr><td>haltOnError</td><td>halt test on errors?</td><td>false</td></tr> <tr><td>haltOnFailure</td><td>halt test on failures?</td><td>false</td></tr> <tr><td>formatter</td><td>A JUnitResultFormatter given as classname,filename. If filename is ommitted, System.out is assumed.</td><td>none</td></tr> </table> 
 */
public static void main(String[] args) throws IOException {
  boolean exitAtEnd=true;
  boolean haltError=false;
  boolean haltFail=false;
  if (args.length == 0) {
    System.err.println("required argument TestClassName missing");
    System.exit(ERRORS);
  }
  for (int i=1; i < args.length; i++) {
    if (args[i].startsWith("haltOnError=")) {
      haltError=Project.toBoolean(args[i].substring(12));
    }
 else     if (args[i].startsWith("haltOnFailure=")) {
      haltFail=Project.toBoolean(args[i].substring(14));
    }
 else     if (args[i].startsWith("formatter=")) {
      try {
        createAndStoreFormatter(args[i].substring(10));
      }
 catch (      BuildException be) {
        System.err.println(be.getMessage());
        System.exit(ERRORS);
      }
    }
  }
  JUnitTest t=new JUnitTest(args[0]);
  JUnitTestRunner runner=new JUnitTestRunner(t,haltError,haltFail);
  transferFormatters(runner);
  runner.run();
  System.exit(runner.getRetCode());
}
