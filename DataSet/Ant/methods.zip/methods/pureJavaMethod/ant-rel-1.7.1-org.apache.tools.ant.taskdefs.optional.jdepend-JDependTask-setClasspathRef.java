/** 
 * Adds a reference to a classpath defined elsewhere.
 * @param r a classpath reference
 */
public void setClasspathRef(Reference r){
  createClasspath().setRefid(r);
}
