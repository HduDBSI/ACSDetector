protected void doFileOperations(){
  if (fileCopyMap.size() > 0) {
    log("Moving " + fileCopyMap.size() + " files to "+ destDir.getAbsolutePath());
    Enumeration e=fileCopyMap.keys();
    while (e.hasMoreElements()) {
      String fromFile=(String)e.nextElement();
      String toFile=(String)fileCopyMap.get(fromFile);
      try {
        log("Moving " + fromFile + " to "+ toFile,verbosity);
        project.copyFile(fromFile,toFile,filtering,forceOverwrite);
        File f=new File(fromFile);
        if (!f.delete()) {
          throw new BuildException("Unable to delete file " + f.getAbsolutePath());
        }
      }
 catch (      IOException ioe) {
        String msg="Failed to copy " + fromFile + " to "+ toFile+ " due to "+ ioe.getMessage();
        throw new BuildException(msg,ioe,location);
      }
    }
  }
  if (includeEmpty) {
    Enumeration e=dirCopyMap.elements();
    int count=0;
    while (e.hasMoreElements()) {
      File d=new File((String)e.nextElement());
      if (!d.exists()) {
        if (!d.mkdirs()) {
          log("Unable to create directory " + d.getAbsolutePath(),Project.MSG_ERR);
        }
 else {
          count++;
        }
      }
    }
    if (count > 0) {
      log("Moved " + count + " empty directories to "+ destDir.getAbsolutePath());
    }
  }
  if (filesets.size() > 0) {
    Enumeration e=filesets.elements();
    while (e.hasMoreElements()) {
      FileSet fs=(FileSet)e.nextElement();
      File dir=fs.getDir(project);
      if (okToDelete(dir)) {
        deleteDir(dir);
      }
    }
  }
}
