public void testGetCommandline(){
  CommandlineJava c=new CommandlineJava();
  c.createArgument().setValue("org.apache.tools.ant.CommandlineJavaTest");
  c.setClassname("junit.textui.TestRunner");
  c.createVmArgument().setValue("-Djava.compiler=NONE");
  String[] s=c.getCommandline();
  assertEquals("no classpath",4,s.length);
  assertEquals("no classpath","java",s[0]);
  assertEquals("no classpath","-Djava.compiler=NONE",s[1]);
  assertEquals("no classpath","junit.textui.TestRunner",s[2]);
  assertEquals("no classpath","org.apache.tools.ant.CommandlineJavaTest",s[3]);
  c.createClasspath(project).setLocation(new File("junit.jar"));
  c.createClasspath(project).setLocation(new File("ant.jar"));
  s=c.getCommandline();
  assertEquals("with classpath",6,s.length);
  assertEquals("with classpath","java",s[0]);
  assertEquals("with classpath","-Djava.compiler=NONE",s[1]);
  assertEquals("with classpath","-classpath",s[2]);
  assert ("junit.jar contained".s[3].indexOf("junit.jar" + java.io.File.pathSeparator) >= 0);
  assert ("ant.jar contained".s[3].endsWith("ant.jar"));
  assertEquals("with classpath","junit.textui.TestRunner",s[4]);
  assertEquals("with classpath","org.apache.tools.ant.CommandlineJavaTest",s[5]);
}
