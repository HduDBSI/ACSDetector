/** 
 * Set the naming scheme used to determine the name of the generated jars from the deployment descriptor
 * @param namingScheme the naming scheme to be used
 */
public void setNaming(NamingScheme namingScheme){
  config.namingScheme=namingScheme;
  if (!config.namingScheme.getValue().equals(NamingScheme.BASEJARNAME) && config.baseJarName != null) {
    throw new BuildException("The basejarname attribute is not compatible with the " + config.namingScheme.getValue() + " naming scheme");
  }
}
