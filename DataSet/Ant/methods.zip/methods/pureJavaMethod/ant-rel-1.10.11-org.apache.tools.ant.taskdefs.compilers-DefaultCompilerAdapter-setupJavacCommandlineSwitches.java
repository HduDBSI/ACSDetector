/** 
 * Does the command line argument processing common to classic and modern.  Doesn't add the files to compile.
 * @param cmd the command line
 * @param useDebugLevel if true set set the debug level with the -g switch
 * @return the command line
 */
protected Commandline setupJavacCommandlineSwitches(final Commandline cmd,final boolean useDebugLevel){
  final Path classpath=getCompileClasspath();
  Path sourcepath;
  if (compileSourcepath != null) {
    sourcepath=compileSourcepath;
  }
 else {
    sourcepath=src;
  }
  final String memoryParameterPrefix=assumeJava1_2Plus() ? "-J-X" : "-J-";
  if (memoryInitialSize != null) {
    if (!attributes.isForkedJavac()) {
      attributes.log("Since fork is false, ignoring memoryInitialSize setting.",Project.MSG_WARN);
    }
 else {
      cmd.createArgument().setValue(memoryParameterPrefix + "ms" + memoryInitialSize);
    }
  }
  if (memoryMaximumSize != null) {
    if (!attributes.isForkedJavac()) {
      attributes.log("Since fork is false, ignoring memoryMaximumSize setting.",Project.MSG_WARN);
    }
 else {
      cmd.createArgument().setValue(memoryParameterPrefix + "mx" + memoryMaximumSize);
    }
  }
  if (attributes.getNowarn()) {
    cmd.createArgument().setValue("-nowarn");
  }
  if (deprecation) {
    cmd.createArgument().setValue("-deprecation");
  }
  if (destDir != null) {
    cmd.createArgument().setValue("-d");
    cmd.createArgument().setFile(destDir);
  }
  cmd.createArgument().setValue("-classpath");
  if (!assumeJava1_2Plus()) {
    final Path cp=new Path(project);
    Optional.ofNullable(getBootClassPath()).ifPresent(cp::append);
    if (extdirs != null) {
      cp.addExtdirs(extdirs);
    }
    cp.append(classpath);
    cp.append(sourcepath);
    cmd.createArgument().setPath(cp);
  }
 else {
    cmd.createArgument().setPath(classpath);
    if (sourcepath.size() > 0) {
      cmd.createArgument().setValue("-sourcepath");
      cmd.createArgument().setPath(sourcepath);
    }
    if (release == null || !assumeJava9Plus()) {
      if (target != null) {
        cmd.createArgument().setValue("-target");
        cmd.createArgument().setValue(target);
      }
      final Path bp=getBootClassPath();
      if (!bp.isEmpty()) {
        cmd.createArgument().setValue("-bootclasspath");
        cmd.createArgument().setPath(bp);
      }
    }
    if (extdirs != null && !extdirs.isEmpty()) {
      cmd.createArgument().setValue("-extdirs");
      cmd.createArgument().setPath(extdirs);
    }
  }
  if (encoding != null) {
    cmd.createArgument().setValue("-encoding");
    cmd.createArgument().setValue(encoding);
  }
  if (debug) {
    if (useDebugLevel && assumeJava1_2Plus()) {
      final String debugLevel=attributes.getDebugLevel();
      if (debugLevel != null) {
        cmd.createArgument().setValue("-g:" + debugLevel);
      }
 else {
        cmd.createArgument().setValue("-g");
      }
    }
 else {
      cmd.createArgument().setValue("-g");
    }
  }
 else   if (getNoDebugArgument() != null) {
    cmd.createArgument().setValue(getNoDebugArgument());
  }
  if (optimize) {
    cmd.createArgument().setValue("-O");
  }
  if (depend) {
    if (assumeJava1_3Plus()) {
      attributes.log("depend attribute is not supported by the modern compiler",Project.MSG_WARN);
    }
 else     if (assumeJava1_2Plus()) {
      cmd.createArgument().setValue("-Xdepend");
    }
 else {
      cmd.createArgument().setValue("-depend");
    }
  }
  if (verbose) {
    cmd.createArgument().setValue("-verbose");
  }
  addCurrentCompilerArgs(cmd);
  return cmd;
}
