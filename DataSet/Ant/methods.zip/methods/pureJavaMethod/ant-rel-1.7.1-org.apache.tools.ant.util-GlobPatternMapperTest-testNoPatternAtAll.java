public void testNoPatternAtAll(){
  GlobPatternMapper m=new GlobPatternMapper();
  m.setFrom("foobar");
  m.setTo("baz");
  assertNull("Shouldn\'t match foobar",m.mapFileName("plonk"));
  String[] result=m.mapFileName("foobar");
  assertNotNull("Should match foobar",result);
  assertEquals("only one result for foobar",1,result.length);
  assertEquals("baz",result[0]);
}
