/** 
 * execute patch
 * @throws BuildException when it all goes a bit pear shaped
 */
@Override public void execute() throws BuildException {
  if (!havePatchfile) {
    throw new BuildException("patchfile argument is required",getLocation());
  }
  Commandline toExecute=(Commandline)cmd.clone();
  toExecute.setExecutable(PATCH);
  if (originalFile != null) {
    toExecute.createArgument().setFile(originalFile);
  }
  Execute exe=new Execute(new LogStreamHandler(this,Project.MSG_INFO,Project.MSG_WARN),null);
  exe.setCommandline(toExecute.getCommandline());
  if (directory == null) {
    exe.setWorkingDirectory(getProject().getBaseDir());
  }
 else {
    if (!directory.isDirectory()) {
      throw new BuildException(directory + " is not a directory.",getLocation());
    }
    exe.setWorkingDirectory(directory);
  }
  log(toExecute.describeCommand(),Project.MSG_VERBOSE);
  try {
    int returncode=exe.execute();
    if (Execute.isFailure(returncode)) {
      String msg="'" + PATCH + "' failed with exit code "+ returncode;
      if (failOnError) {
        throw new BuildException(msg);
      }
      log(msg,Project.MSG_ERR);
    }
  }
 catch (  IOException e) {
    throw new BuildException(e,getLocation());
  }
}
