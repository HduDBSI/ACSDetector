/** 
 * Iterate over the children of a given node and return the first node that has a specific name.
 * @param parent  the node to search child from. Can be <code>null</code>.
 * @param tagname the child name we are looking for. Cannot be <code>null</code>.
 * @return  the first child that matches the given name or <code>null</code> ifthe parent is <code>null</code> or if a child does not match the given name.
 */
public static Element getChildByTagName(Node parent,String tagname){
  if (parent == null) {
    return null;
  }
  NodeList childList=parent.getChildNodes();
  final int len=childList.getLength();
  for (int i=0; i < len; i++) {
    Node child=childList.item(i);
    if (child != null && child.getNodeType() == Node.ELEMENT_NODE && child.getNodeName().equals(tagname)) {
      return (Element)child;
    }
  }
  return null;
}
