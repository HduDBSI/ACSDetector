/** 
 * @see BuildListener#messageLogged
 */
public void messageLogged(BuildEvent event){
  if (initialized) {
    Object categoryObject=event.getTask();
    String categoryString=null;
    String categoryDetail=null;
    if (categoryObject == null) {
      categoryObject=event.getTarget();
      if (categoryObject == null) {
        categoryObject=event.getProject();
        categoryString="org.apache.tools.ant.Project";
        categoryDetail=event.getProject().getName();
      }
 else {
        categoryString="org.apache.tools.ant.Target";
        categoryDetail=event.getTarget().getName();
      }
    }
 else {
      if (event.getTarget() != null) {
        categoryString=categoryObject.getClass().getName();
        categoryDetail=event.getTarget().getName();
      }
 else {
        categoryString=categoryObject.getClass().getName();
      }
    }
    Log log=getLog(categoryString,categoryDetail);
    int priority=event.getPriority();
    String message=event.getMessage();
    realLog(log,message,priority,null);
  }
}
