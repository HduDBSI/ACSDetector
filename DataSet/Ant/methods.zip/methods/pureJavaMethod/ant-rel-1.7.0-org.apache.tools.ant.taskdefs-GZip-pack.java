/** 
 * perform the GZip compression operation.
 */
protected void pack(){
  GZIPOutputStream zOut=null;
  try {
    zOut=new GZIPOutputStream(new FileOutputStream(zipFile));
    zipResource(getSrcResource(),zOut);
  }
 catch (  IOException ioe) {
    String msg="Problem creating gzip " + ioe.getMessage();
    throw new BuildException(msg,ioe,getLocation());
  }
 finally {
    FileUtils.close(zOut);
  }
}
