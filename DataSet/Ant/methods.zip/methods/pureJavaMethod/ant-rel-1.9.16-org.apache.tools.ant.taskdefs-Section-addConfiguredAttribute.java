/** 
 * Add an attribute to the section.
 * @param attribute the attribute to be added to the section
 * @exception ManifestException if the attribute is not valid.
 */
public void addConfiguredAttribute(Attribute attribute) throws ManifestException {
  String check=addAttributeAndCheck(attribute);
  if (check != null) {
    throw new BuildException("Specify the section name using " + "the \"name\" attribute of the <section> element rather " + "than using a \"Name\" manifest attribute");
  }
}
