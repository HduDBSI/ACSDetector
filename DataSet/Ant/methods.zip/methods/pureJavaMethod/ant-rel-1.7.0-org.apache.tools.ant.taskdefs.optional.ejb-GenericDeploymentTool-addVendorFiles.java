/** 
 * Add any vendor specific files which should be included in the EJB Jar.
 * @param ejbFiles a hashtable entryname -> file.
 * @param ddPrefix a prefix to use.
 */
protected void addVendorFiles(Hashtable ejbFiles,String ddPrefix){
}
