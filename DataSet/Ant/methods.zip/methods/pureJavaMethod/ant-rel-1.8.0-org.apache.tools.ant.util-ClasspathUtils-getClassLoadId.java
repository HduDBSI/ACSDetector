/** 
 * Computes the loaderId based on the configuration of the component.
 * @return a loader identifier.
 */
public String getClassLoadId(){
  if (loaderId == null && classpathId != null) {
    return MagicNames.REFID_CLASSPATH_LOADER_PREFIX + classpathId;
  }
 else {
    return loaderId;
  }
}
