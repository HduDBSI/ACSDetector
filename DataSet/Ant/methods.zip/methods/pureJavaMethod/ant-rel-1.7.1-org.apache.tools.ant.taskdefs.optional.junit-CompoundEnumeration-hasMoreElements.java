/** 
 * Tests if this enumeration contains more elements.
 * @return  <code>true</code> if and only if this enumeration objectcontains at least one more element to provide; <code>false</code> otherwise.
 */
public boolean hasMoreElements(){
  while (index < enumArray.length) {
    if (enumArray[index] != null && enumArray[index].hasMoreElements()) {
      return true;
    }
    index++;
  }
  return false;
}
