/** 
 * The resource to expand; required.
 * @param src resource to expand
 */
public void setSrcResource(Resource src){
  if (!src.isExists()) {
    throw new BuildException("the archive %s doesn't exist",src.getName());
  }
  if (src.isDirectory()) {
    throw new BuildException("the archive %s can't be a directory",src.getName());
  }
  FileProvider fp=src.as(FileProvider.class);
  if (fp != null) {
    source=fp.getFile();
  }
 else   if (!supportsNonFileResources()) {
    throw new BuildException("The source %s is not a FileSystem Only FileSystem resources are supported.",src.getName());
  }
  srcResource=src;
}
