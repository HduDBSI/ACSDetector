public void messageLogged(BuildEvent event){
  Element messageElement=doc.createElement(MESSAGE_TAG);
  String name="debug";
switch (event.getPriority()) {
case Project.MSG_ERR:
    name="error";
  break;
case Project.MSG_WARN:
name="warn";
break;
case Project.MSG_INFO:
name="info";
break;
default :
name="debug";
break;
}
messageElement.setAttribute(PRIORITY_ATTR,name);
Text messageText=doc.createTextNode(event.getMessage());
messageElement.appendChild(messageText);
if (taskElement != null) {
taskElement.appendChild(messageElement);
}
 else if (targetElement != null) {
targetElement.appendChild(messageElement);
}
 else {
buildElement.appendChild(messageElement);
}
}
