/** 
 * Get the destination directory.
 * @return the destination directory into which EJB jars are to be written
 */
protected File getDestDir(){
  return destDir;
}
