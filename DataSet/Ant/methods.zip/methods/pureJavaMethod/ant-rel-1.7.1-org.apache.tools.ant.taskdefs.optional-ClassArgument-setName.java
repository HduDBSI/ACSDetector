/** 
 * Set the name attribute.
 * @param name the name attribute.
 */
public void setName(String name){
  this.name=name;
}
