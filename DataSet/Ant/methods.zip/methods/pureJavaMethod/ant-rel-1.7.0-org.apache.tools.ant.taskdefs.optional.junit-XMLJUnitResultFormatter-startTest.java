/** 
 * Interface TestListener. <p>A new Test is started.
 * @param t the test.
 */
public void startTest(Test t){
  testStarts.put(t,new Long(System.currentTimeMillis()));
}
