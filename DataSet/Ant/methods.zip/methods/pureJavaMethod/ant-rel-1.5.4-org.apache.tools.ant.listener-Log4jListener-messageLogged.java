/** 
 * @see BuildListener#messageLogged
 */
public void messageLogged(BuildEvent event){
  if (initialized) {
    Object categoryObject=event.getTask();
    if (categoryObject == null) {
      categoryObject=event.getTarget();
      if (categoryObject == null) {
        categoryObject=event.getProject();
      }
    }
    Category cat=Category.getInstance(categoryObject.getClass().getName());
switch (event.getPriority()) {
case Project.MSG_ERR:
      cat.error(event.getMessage());
    break;
case Project.MSG_WARN:
  cat.warn(event.getMessage());
break;
case Project.MSG_INFO:
cat.info(event.getMessage());
break;
case Project.MSG_VERBOSE:
cat.debug(event.getMessage());
break;
case Project.MSG_DEBUG:
cat.debug(event.getMessage());
break;
default :
cat.error(event.getMessage());
break;
}
}
}
