public void testLongLines() throws IOException {
  executeTarget("testLongLines");
}
