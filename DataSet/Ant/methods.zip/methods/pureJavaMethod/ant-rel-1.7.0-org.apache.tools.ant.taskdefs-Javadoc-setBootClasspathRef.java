/** 
 * Adds a reference to a CLASSPATH defined elsewhere.
 * @param r the reference to an instance defining the bootclasspath.
 */
public void setBootClasspathRef(Reference r){
  createBootclasspath().setRefid(r);
}
