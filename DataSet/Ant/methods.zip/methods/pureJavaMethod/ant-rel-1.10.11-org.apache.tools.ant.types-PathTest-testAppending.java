@Test public void testAppending(){
  p=new Path(project,"/a:/b");
  String[] l=p.list();
  assertEquals("2 after construction",2,l.length);
  p.setLocation(new File("/c"));
  l=p.list();
  assertEquals("3 after setLocation",3,l.length);
  p.setPath("\\d;\\e");
  l=p.list();
  assertEquals("5 after setPath",5,l.length);
  p.append(new Path(project,"\\f"));
  l=p.list();
  assertEquals("6 after append",6,l.length);
  p.createPath().setLocation(new File("/g"));
  l=p.list();
  assertEquals("7 after append",7,l.length);
}
