/** 
 * Decodes an Uri with % characters. The URI is escaped
 * @param uri String with the uri possibly containing % characters.
 * @return The decoded Uri
 * @throws UnsupportedEncodingException if UTF-8 is not available
 * @since Ant 1.7
 */
public static String decodeUri(String uri) throws UnsupportedEncodingException {
  if (uri.indexOf('%') == -1) {
    return uri;
  }
  ByteArrayOutputStream sb=new ByteArrayOutputStream(uri.length());
  CharacterIterator iter=new StringCharacterIterator(uri);
  for (char c=iter.first(); c != CharacterIterator.DONE; c=iter.next()) {
    if (c == '%') {
      char c1=iter.next();
      if (c1 != CharacterIterator.DONE) {
        int i1=Character.digit(c1,WORD);
        char c2=iter.next();
        if (c2 != CharacterIterator.DONE) {
          int i2=Character.digit(c2,WORD);
          sb.write((char)((i1 << NIBBLE) + i2));
        }
      }
    }
 else {
      sb.write(c);
    }
  }
  return sb.toString(URI_ENCODING);
}
