/** 
 * @see java.lang.Object#equals
 * @param rhs the object to check for equality.
 * @return true if the version, main and sections are the same.
 */
public boolean equals(Object rhs){
  if (rhs == null || rhs.getClass() != getClass()) {
    return false;
  }
  if (rhs == this) {
    return true;
  }
  Manifest rhsManifest=(Manifest)rhs;
  if (manifestVersion == null) {
    if (rhsManifest.manifestVersion != null) {
      return false;
    }
  }
 else   if (!manifestVersion.equals(rhsManifest.manifestVersion)) {
    return false;
  }
  if (!mainSection.equals(rhsManifest.mainSection)) {
    return false;
  }
  return sections.equals(rhsManifest.sections);
}
