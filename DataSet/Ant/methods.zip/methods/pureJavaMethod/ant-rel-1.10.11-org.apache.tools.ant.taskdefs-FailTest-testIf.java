@Test(expected=BuildException.class) public void testIf(){
  buildRule.executeTarget("testIf");
  buildRule.getProject().setProperty("foo","");
  buildRule.executeTarget("testIf");
}
