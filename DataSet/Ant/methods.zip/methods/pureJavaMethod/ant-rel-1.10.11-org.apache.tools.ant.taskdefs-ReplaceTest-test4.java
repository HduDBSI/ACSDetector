/** 
 * Fail: empty token not allowed
 */
@Test(expected=BuildException.class) public void test4(){
  buildRule.executeTarget("test4");
}
