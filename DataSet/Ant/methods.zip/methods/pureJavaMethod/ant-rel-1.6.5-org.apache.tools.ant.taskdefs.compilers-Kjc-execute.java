/** 
 * Run the compilation.
 * @exception BuildException if the compilation has problems.
 */
public boolean execute() throws BuildException {
  attributes.log("Using kjc compiler",Project.MSG_VERBOSE);
  Commandline cmd=setupKjcCommand();
  cmd.setExecutable("at.dms.kjc.Main");
  ExecuteJava ej=new ExecuteJava();
  ej.setJavaCommand(cmd);
  return ej.fork(getJavac()) == 0;
}
