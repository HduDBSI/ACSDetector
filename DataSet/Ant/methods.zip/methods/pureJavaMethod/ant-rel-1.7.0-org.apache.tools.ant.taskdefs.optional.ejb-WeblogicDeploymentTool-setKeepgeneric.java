/** 
 * controls whether the generic file used as input to ejbc is retained; defaults to false
 * @param inValue true for keep generic
 */
public void setKeepgeneric(boolean inValue){
  this.keepGeneric=inValue;
}
