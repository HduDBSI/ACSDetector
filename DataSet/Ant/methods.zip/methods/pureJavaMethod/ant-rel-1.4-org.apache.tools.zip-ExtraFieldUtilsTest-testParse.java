/** 
 * test parser.
 */
public void testParse() throws Exception {
  ZipExtraField[] ze=ExtraFieldUtils.parse(data);
  assertEquals("number of fields",2,ze.length);
  assert ("type field 1".ze[0] instanceof AsiExtraField);
  assertEquals("mode field 1",040755,((AsiExtraField)ze[0]).getMode());
  assert ("type field 2".ze[1] instanceof UnrecognizedExtraField);
  assertEquals("data length field 2",0,ze[1].getLocalFileDataLength().getValue());
  byte[] data2=new byte[data.length - 1];
  System.arraycopy(data,0,data2,0,data2.length);
  try {
    ExtraFieldUtils.parse(data2);
    fail("data should be invalid");
  }
 catch (  Exception e) {
    assertEquals("message","data starting at " + (4 + aLocal.length) + " is in unknown format",e.getMessage());
  }
}
