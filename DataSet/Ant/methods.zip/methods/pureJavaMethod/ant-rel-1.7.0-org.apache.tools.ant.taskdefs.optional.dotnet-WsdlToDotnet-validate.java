/** 
 * validate the schema
 */
public void validate(){
  if (file != null) {
    if (!file.exists()) {
      throw new BuildException(ERROR_FILE_NOT_FOUND + file.toString());
    }
    if (file.isDirectory()) {
      throw new BuildException(ERROR_FILE_IS_DIR + file.toString());
    }
  }
  if (file != null && url != null) {
    throw new BuildException(ERROR_BOTH_DECLARED);
  }
  if (file == null && url == null) {
    throw new BuildException(ERROR_NONE_DECLARED);
  }
}
