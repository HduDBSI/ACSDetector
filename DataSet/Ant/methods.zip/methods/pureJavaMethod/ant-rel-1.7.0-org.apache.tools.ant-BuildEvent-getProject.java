/** 
 * Returns the project that fired this event.
 * @return the project that fired this event
 */
public Project getProject(){
  return project;
}
