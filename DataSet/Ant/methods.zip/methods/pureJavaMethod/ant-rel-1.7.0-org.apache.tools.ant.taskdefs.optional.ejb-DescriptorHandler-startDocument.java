/** 
 * SAX parser call-back method that is used to initialize the values of some instance variables to ensure safe operation.
 * @throws SAXException on error
 */
public void startDocument() throws SAXException {
  this.ejbFiles=new Hashtable(DEFAULT_HASH_TABLE_SIZE,1);
  this.currentElement=null;
  inEJBRef=false;
}
