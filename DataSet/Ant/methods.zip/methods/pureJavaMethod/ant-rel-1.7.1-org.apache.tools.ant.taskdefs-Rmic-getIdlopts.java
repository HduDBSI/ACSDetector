/** 
 * Gets additional arguments for idl compile.
 * @return the idl options
 */
public String getIdlopts(){
  return idlOpts;
}
