public boolean equals(Object rhs){
  if (!(rhs instanceof Manifest)) {
    return false;
  }
  Manifest rhsManifest=(Manifest)rhs;
  if (!manifestVersion.equals(rhsManifest.manifestVersion)) {
    return false;
  }
  if (sections.size() != rhsManifest.sections.size()) {
    return false;
  }
  if (!mainSection.equals(rhsManifest.mainSection)) {
    return false;
  }
  for (Enumeration e=sections.elements(); e.hasMoreElements(); ) {
    Section section=(Section)e.nextElement();
    Section rhsSection=(Section)rhsManifest.sections.get(section.getName().toLowerCase());
    if (!section.equals(rhsSection)) {
      return false;
    }
  }
  return true;
}
