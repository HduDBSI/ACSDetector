/** 
 * Read a constant pool entry from a stream. This is a factory method which reads a constant pool entry form a stream and returns the appropriate subclass for the entry.
 * @param cpStream the stream from which the constant pool entry is tobe read.
 * @return the appropriate ConstantPoolEntry subclass representing theconstant pool entry from the stream.
 * @exception IOException if the constant pool entry cannot be readfrom the stream
 */
public static ConstantPoolEntry readEntry(DataInputStream cpStream) throws IOException {
  ConstantPoolEntry cpInfo=null;
  int cpTag=cpStream.readUnsignedByte();
switch (cpTag) {
case CONSTANT_UTF8:
    cpInfo=new Utf8CPInfo();
  break;
case CONSTANT_INTEGER:
cpInfo=new IntegerCPInfo();
break;
case CONSTANT_FLOAT:
cpInfo=new FloatCPInfo();
break;
case CONSTANT_LONG:
cpInfo=new LongCPInfo();
break;
case CONSTANT_DOUBLE:
cpInfo=new DoubleCPInfo();
break;
case CONSTANT_CLASS:
cpInfo=new ClassCPInfo();
break;
case CONSTANT_STRING:
cpInfo=new StringCPInfo();
break;
case CONSTANT_FIELDREF:
cpInfo=new FieldRefCPInfo();
break;
case CONSTANT_METHODREF:
cpInfo=new MethodRefCPInfo();
break;
case CONSTANT_INTERFACEMETHODREF:
cpInfo=new InterfaceMethodRefCPInfo();
break;
case CONSTANT_NAMEANDTYPE:
cpInfo=new NameAndTypeCPInfo();
break;
case CONSTANT_METHODHANDLE:
cpInfo=new MethodHandleCPInfo();
break;
case CONSTANT_METHODTYPE:
cpInfo=new MethodTypeCPInfo();
break;
case CONSTANT_INVOKEDYNAMIC:
cpInfo=new InvokeDynamicCPInfo();
break;
default :
throw new ClassFormatError("Invalid Constant Pool entry Type " + cpTag);
}
cpInfo.read(cpStream);
return cpInfo;
}
