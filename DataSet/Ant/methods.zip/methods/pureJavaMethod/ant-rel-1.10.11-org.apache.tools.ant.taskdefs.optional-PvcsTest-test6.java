/** 
 * Expected failure due to nonexistent directory structure
 */
@Test(expected=BuildException.class) public void test6(){
  buildRule.executeTarget("test6");
}
