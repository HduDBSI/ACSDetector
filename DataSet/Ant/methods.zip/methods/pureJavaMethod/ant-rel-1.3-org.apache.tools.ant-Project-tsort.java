private final void tsort(String root,Hashtable targets,Hashtable state,Stack visiting,Vector ret) throws BuildException {
  state.put(root,VISITING);
  visiting.push(root);
  Target target=(Target)(targets.get(root));
  if (target == null) {
    StringBuffer sb=new StringBuffer("Target `");
    sb.append(root);
    sb.append("' does not exist in this project. ");
    visiting.pop();
    if (!visiting.empty()) {
      String parent=(String)visiting.peek();
      sb.append("It is used from target `");
      sb.append(parent);
      sb.append("'.");
    }
    throw new BuildException(new String(sb));
  }
  for (Enumeration en=target.getDependencies(); en.hasMoreElements(); ) {
    String cur=(String)en.nextElement();
    String m=(String)state.get(cur);
    if (m == null) {
      tsort(cur,targets,state,visiting,ret);
    }
 else     if (m == VISITING) {
      throw makeCircularException(cur,visiting);
    }
  }
  String p=(String)visiting.pop();
  if (root != p) {
    throw new RuntimeException("Unexpected internal error: expected to pop " + root + " but got "+ p);
  }
  state.put(root,VISITED);
  ret.addElement(target);
}
