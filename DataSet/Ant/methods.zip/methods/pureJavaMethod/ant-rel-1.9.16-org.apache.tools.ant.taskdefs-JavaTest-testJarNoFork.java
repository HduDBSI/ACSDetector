@Test public void testJarNoFork(){
  try {
    buildRule.executeTarget("testJarNoFork");
    fail("Build exception should have been thrown - parameter validation");
  }
 catch (  BuildException ex) {
    assertContains("Cannot execute a jar in non-forked mode. Please set fork='true'. ",ex.getMessage());
  }
}
