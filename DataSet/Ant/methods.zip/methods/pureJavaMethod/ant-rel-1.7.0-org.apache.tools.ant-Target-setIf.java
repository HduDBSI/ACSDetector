/** 
 * Sets the "if" condition to test on execution. This is the name of a property to test for existence - if the property is not set, the task will not execute. The property goes through property substitution once before testing, so if property <code>foo</code> has value <code>bar</code>, setting the "if" condition to <code>${foo}_x</code> will mean that the task will only execute if property <code>bar_x</code> is set.
 * @param property The property condition to test on execution.May be <code>null</code>, in which case no "if" test is performed.
 */
public void setIf(String property){
  ifCondition=(property == null) ? "" : property;
}
