/** 
 * Writes the local file header entry
 * @param ze the entry to write
 * @throws IOException on error
 * @since 1.1
 */
protected void writeLocalFileHeader(ZipEntry ze) throws IOException {
  boolean encodable=zipEncoding.canEncode(ze.getName());
  ByteBuffer name=getName(ze);
  if (createUnicodeExtraFields != UnicodeExtraFieldPolicy.NEVER) {
    addUnicodeExtraFields(ze,encodable,name);
  }
  final byte[] localHeader=createLocalFileHeader(ze,name,encodable);
  final long localHeaderStart=written;
  offsets.put(ze,localHeaderStart);
  entry.localDataStart=localHeaderStart + LFH_CRC_OFFSET;
  writeCounted(localHeader);
  entry.dataStart=written;
}
