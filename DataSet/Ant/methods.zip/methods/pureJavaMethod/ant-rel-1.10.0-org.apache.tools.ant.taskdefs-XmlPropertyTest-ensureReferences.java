/** 
 * Ensure all references loaded by the project are valid.
 */
private static void ensureReferences(String msg,File inputFile,Hashtable references){
  Enumeration referenceKeyEnum=references.keys();
  while (referenceKeyEnum.hasMoreElements()) {
    String currentKey=referenceKeyEnum.nextElement().toString();
    Object currentValue=references.get(currentKey);
    if (currentValue instanceof Path) {
    }
 else     if (currentValue instanceof String) {
    }
 else {
      if (!currentKey.startsWith("ant.")) {
        fail(msg + "-" + inputFile.getName()+ " Key="+ currentKey+ " is not a recognized type.");
      }
    }
  }
}
