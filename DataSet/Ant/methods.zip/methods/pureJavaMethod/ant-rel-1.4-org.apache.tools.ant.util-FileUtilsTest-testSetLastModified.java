public void testSetLastModified() throws IOException {
  removeThis=new File("dummy");
  FileOutputStream fos=new FileOutputStream(removeThis);
  fos.write(new byte[0]);
  fos.close();
  long modTime=removeThis.lastModified();
  assertTrue(modTime != 0);
  try {
    Thread.currentThread().sleep(5000);
  }
 catch (  InterruptedException ie) {
    fail(ie.getMessage());
  }
  fu.setFileLastModified(removeThis,-1);
  long secondModTime=removeThis.lastModified();
  try {
    Class.forName("java.lang.ThreadLocal");
    assertTrue(secondModTime > modTime);
  }
 catch (  ClassNotFoundException e) {
    assertEquals(modTime,secondModTime);
  }
  fu.setFileLastModified(removeThis,123456);
  long thirdModTime=removeThis.lastModified();
  try {
    Class.forName("java.lang.ThreadLocal");
    assertTrue(thirdModTime != secondModTime);
  }
 catch (  ClassNotFoundException e) {
    assertEquals(modTime,thirdModTime);
  }
}
