/** 
 * Utility method that encapsulates the logic of adding a file entry to a .jar file.  Used by execute() to add entries to the jar file as it is constructed.
 * @param jStream A JarOutputStream into which to write thejar entry.
 * @param inputFile A File from which to read thecontents the file being added.
 * @param logicalFilename A String representing the name, includingall relevant path information, that should be stored for the entry being added.
 */
protected void addFileToJar(JarOutputStream jStream,File inputFile,String logicalFilename) throws BuildException {
  FileInputStream iStream=null;
  try {
    if (!addedfiles.contains(logicalFilename)) {
      iStream=new FileInputStream(inputFile);
      ZipEntry zipEntry=new ZipEntry(logicalFilename.replace('\\','/'));
      jStream.putNextEntry(zipEntry);
      byte[] byteBuffer=new byte[2 * 1024];
      int count=0;
      do {
        jStream.write(byteBuffer,0,count);
        count=iStream.read(byteBuffer,0,byteBuffer.length);
      }
 while (count != -1);
      addedfiles.add(logicalFilename);
    }
  }
 catch (  IOException ioe) {
    log("WARNING: IOException while adding entry " + logicalFilename + " to jarfile from "+ inputFile.getPath()+ " "+ ioe.getClass().getName()+ "-"+ ioe.getMessage(),Project.MSG_WARN);
  }
 finally {
    if (iStream != null) {
      try {
        iStream.close();
      }
 catch (      IOException closeException) {
      }
    }
  }
}
