/** 
 * Sets the cc address.  Also sets the "Cc" header.  This method may be called multiple times.
 * @param cc the cc address
 * @exception IOException if there's any problem reported by the mail server
 */
public void cc(String cc) throws IOException {
  sendRcpt(cc);
  this.cc.addElement(cc);
}
