/** 
 * Default constructor Causes the BCEL classes to load to ensure BCEL dependencies can be satisfied
 */
public FullAnalyzer(){
  try {
    new ClassParser("force");
  }
 catch (  Exception e) {
    if (!(e instanceof IOException)) {
      throw new BuildException(e);
    }
  }
}
