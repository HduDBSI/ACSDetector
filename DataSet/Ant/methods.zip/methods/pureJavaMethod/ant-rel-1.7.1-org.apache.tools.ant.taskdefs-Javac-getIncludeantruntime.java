/** 
 * Gets whether or not the ant classpath is to be included in the classpath.
 * @return whether or not the ant classpath is to be included in the classpath
 */
public boolean getIncludeantruntime(){
  return includeAntRuntime;
}
