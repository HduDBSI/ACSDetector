/** 
 * Executes the build.
 */
private void runBuild(ClassLoader coreLoader) throws BuildException {
  if (!readyToRun) {
    return;
  }
  if (msgOutputLevel >= Project.MSG_INFO) {
    System.out.println("Buildfile: " + buildFile);
  }
  final Project project=new Project();
  project.setCoreLoader(coreLoader);
  Throwable error=null;
  try {
    addBuildListeners(project);
    PrintStream err=System.err;
    PrintStream out=System.out;
    SecurityManager oldsm=System.getSecurityManager();
    try {
      System.setOut(new PrintStream(new DemuxOutputStream(project,false)));
      System.setErr(new PrintStream(new DemuxOutputStream(project,true)));
      project.fireBuildStarted();
      project.init();
      project.setUserProperty("ant.version",getAntVersion());
      Enumeration e=definedProps.keys();
      while (e.hasMoreElements()) {
        String arg=(String)e.nextElement();
        String value=(String)definedProps.get(arg);
        project.setUserProperty(arg,value);
      }
      project.setUserProperty("ant.file",buildFile.getAbsolutePath());
      String noParserMessage="No JAXP compliant XML parser found. Please visit http://xml.apache.org for a suitable parser";
      try {
        Class.forName("javax.xml.parsers.SAXParserFactory");
        ProjectHelper.configureProject(project,buildFile);
      }
 catch (      NoClassDefFoundError ncdfe) {
        throw new BuildException(noParserMessage,ncdfe);
      }
catch (      ClassNotFoundException cnfe) {
        throw new BuildException(noParserMessage,cnfe);
      }
catch (      NullPointerException npe) {
        throw new BuildException(noParserMessage,npe);
      }
      if (targets.size() == 0) {
        targets.addElement(project.getDefaultTarget());
      }
      if (!projectHelp) {
        project.executeTargets(targets);
      }
    }
  finally {
      System.setOut(out);
      System.setErr(err);
    }
    if (projectHelp) {
      printDescription(project);
      printTargets(project);
    }
  }
 catch (  RuntimeException exc) {
    error=exc;
    throw exc;
  }
catch (  Error err) {
    error=err;
    throw err;
  }
 finally {
    project.fireBuildFinished(error);
  }
}
