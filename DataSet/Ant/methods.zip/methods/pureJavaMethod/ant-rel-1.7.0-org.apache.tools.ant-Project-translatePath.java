/** 
 * Translate a path into its native (platform specific) format. <p> This method uses PathTokenizer to separate the input path into its components. This handles DOS style paths in a relatively sensible way. The file separators are then converted to their platform specific versions.
 * @param toProcess The path to be translated.May be <code>null</code>.
 * @return the native version of the specified path oran empty string if the path is <code>null</code> or empty.
 * @deprecated since 1.7Use FileUtils.translatePath instead.
 * @see PathTokenizer
 */
public static String translatePath(String toProcess){
  return FileUtils.translatePath(toProcess);
}
