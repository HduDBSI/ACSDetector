void sendData() throws IOException {
  int[] ok={OK_DATA};
  send("DATA",ok);
}
