/** 
 * Fulfill the ResourceCollection contract.
 * @return an Iterator of Resources.
 * @since Ant 1.7
 */
@Override public Iterator<Resource> iterator(){
  if (isReference()) {
    return getRef().iterator();
  }
  return new FileResourceIterator(getProject(),getDir(getProject()),getDirectoryScanner().getIncludedDirectories());
}
