protected void scandir(String dir,String vpath,boolean fast){
  try {
    if (!ftp.changeWorkingDirectory(dir)) {
      return;
    }
    FTPFile[] newfiles=ftp.listFiles();
    if (newfiles == null) {
      ftp.changeToParentDirectory();
      return;
    }
    for (int i=0; i < newfiles.length; i++) {
      FTPFile file=newfiles[i];
      if (!file.getName().equals(".") && !file.getName().equals("..")) {
        if (file.isDirectory()) {
          String name=vpath + file.getName();
          if (isIncluded(name)) {
            if (!isExcluded(name)) {
              dirsIncluded.addElement(name);
              if (fast) {
                scandir(file.getName(),name + File.separator,fast);
              }
            }
 else {
              dirsExcluded.addElement(name);
              if (fast && couldHoldIncluded(name)) {
                scandir(file.getName(),name + File.separator,fast);
              }
            }
          }
 else {
            dirsNotIncluded.addElement(name);
            if (fast && couldHoldIncluded(name)) {
              scandir(file.getName(),name + File.separator,fast);
            }
          }
          if (!fast) {
            scandir(file.getName(),name + File.separator,fast);
          }
        }
 else {
          if (file.isFile()) {
            String name=vpath + file.getName();
            if (isIncluded(name)) {
              if (!isExcluded(name)) {
                filesIncluded.addElement(name);
              }
 else {
                filesExcluded.addElement(name);
              }
            }
 else {
              filesNotIncluded.addElement(name);
            }
          }
        }
      }
    }
    ftp.changeToParentDirectory();
  }
 catch (  IOException e) {
    throw new BuildException("Error while communicating with FTP " + "server: ",e);
  }
}
