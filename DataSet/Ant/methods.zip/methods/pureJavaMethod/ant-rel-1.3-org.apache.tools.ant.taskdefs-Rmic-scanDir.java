/** 
 * Scans the directory looking for class files to be compiled. The result is returned in the class variable compileList.
 */
protected void scanDir(File baseDir,String files[]){
  SourceFileScanner sfs=new SourceFileScanner(this);
  String[] newFiles=sfs.restrict(files,baseDir,baseDir,new RmicFileNameMapper());
  for (int i=0; i < newFiles.length; i++) {
    String classname=newFiles[i].replace(File.separatorChar,'.');
    classname=classname.substring(0,classname.indexOf(".class"));
    compileList.addElement(classname);
  }
}
