/** 
 * Return all <tt>JUnitTest</tt> instances obtain by applying the fileset rules.
 * @return  an enumeration of all elements of this batchtest that area <tt>JUnitTest</tt> instance.
 */
public Enumeration elements(){
  JUnitTest[] tests=createAllJUnitTest();
  return Enumerations.fromArray(tests);
}
