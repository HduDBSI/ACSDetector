/** 
 * Used for nested xml command line definitions.
 */
public static class Argument extends ProjectComponent {
  private String[] parts;
  /** 
 * Set a single commandline argument.
 * @param value a single commandline argument.
 */
  public void setValue(  String value){
    parts=new String[]{value};
  }
  /** 
 * Set the line to split into several commandline arguments.
 * @param line line to split into several commandline arguments.
 */
  public void setLine(  String line){
    if (line == null) {
      return;
    }
    parts=translateCommandline(line);
  }
  /** 
 * Set a single commandline argument and treats it like a PATH--ensuring the right separator for the local platform is used.
 * @param value a single commandline argument.
 */
  public void setPath(  Path value){
    parts=new String[]{value.toString()};
  }
  /** 
 * Set a single commandline argument from a reference to a path--ensuring the right separator for the local platform is used.
 * @param value a single commandline argument.
 */
  public void setPathref(  Reference value){
    Path p=new Path(getProject());
    p.setRefid(value);
    parts=new String[]{p.toString()};
  }
  /** 
 * Set a single commandline argument to the absolute filename of the given file.
 * @param value a single commandline argument.
 */
  public void setFile(  File value){
    parts=new String[]{value.getAbsolutePath()};
  }
  /** 
 * Return the constituent parts of this Argument.
 * @return an array of strings.
 */
  public String[] getParts(){
    return parts;
  }
}
