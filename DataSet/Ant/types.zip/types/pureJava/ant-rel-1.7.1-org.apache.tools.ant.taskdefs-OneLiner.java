/** 
 * Deprecated, the functionality has been moved to filters.FixCrLfFilter.
 * @deprecated since 1.7.0.
 */
protected class OneLiner implements Enumeration {
  private static final int UNDEF=-1;
  private static final int NOTJAVA=0;
  private static final int LOOKING=1;
  private static final int INBUFLEN=8192;
  private static final int LINEBUFLEN=200;
  private static final char CTRLZ='\u001A';
  private int state=filter.getJavafiles() ? LOOKING : NOTJAVA;
  private StringBuffer eolStr=new StringBuffer(LINEBUFLEN);
  private StringBuffer eofStr=new StringBuffer();
  private BufferedReader reader;
  private StringBuffer line=new StringBuffer();
  private boolean reachedEof=false;
  private File srcFile;
  /** 
 * Constructor.
 * @param srcFile the file to read.
 * @throws BuildException if there is an error.
 */
  public OneLiner(  File srcFile) throws BuildException {
    this.srcFile=srcFile;
    try {
      reader=new BufferedReader(((encoding == null) ? new FileReader(srcFile) : new InputStreamReader(new FileInputStream(srcFile),encoding)),INBUFLEN);
      nextLine();
    }
 catch (    IOException e) {
      throw new BuildException(srcFile + ": " + e.getMessage(),e,getLocation());
    }
  }
  /** 
 * Move to the next line.
 * @throws BuildException if there is an error.
 */
  protected void nextLine() throws BuildException {
    int ch=-1;
    int eolcount=0;
    eolStr=new StringBuffer();
    line=new StringBuffer();
    try {
      ch=reader.read();
      while (ch != -1 && ch != '\r' && ch != '\n') {
        line.append((char)ch);
        ch=reader.read();
      }
      if (ch == -1 && line.length() == 0) {
        reachedEof=true;
        return;
      }
switch ((char)ch) {
case '\r':
        ++eolcount;
      eolStr.append('\r');
    reader.mark(2);
  ch=reader.read();
switch (ch) {
case '\r':
  ch=reader.read();
if ((char)(ch) == '\n') {
  eolcount+=2;
  eolStr.append("\r\n");
}
 else {
  reader.reset();
}
break;
case '\n':
++eolcount;
eolStr.append('\n');
break;
case -1:
break;
default :
reader.reset();
break;
}
break;
case '\n':
++eolcount;
eolStr.append('\n');
break;
default :
}
if (eolcount == 0) {
int i=line.length();
while (--i >= 0 && line.charAt(i) == CTRLZ) {
}
if (i < line.length() - 1) {
eofStr.append(line.toString().substring(i + 1));
if (i < 0) {
line.setLength(0);
reachedEof=true;
}
 else {
line.setLength(i + 1);
}
}
}
}
 catch (IOException e) {
throw new BuildException(srcFile + ": " + e.getMessage(),e,getLocation());
}
}
/** 
 * get the eof string.
 * @return the eof string.
 */
public String getEofStr(){
return eofStr.substring(0);
}
/** 
 * get the state.
 * @return the state.
 */
public int getState(){
return state;
}
/** 
 * Set the state.
 * @param state the value to use.
 */
public void setState(int state){
this.state=state;
}
/** 
 * @return true if there is more elements.
 */
public boolean hasMoreElements(){
return !reachedEof;
}
/** 
 * get the next element.
 * @return the next element.
 * @throws NoSuchElementException if there is no more.
 */
public Object nextElement() throws NoSuchElementException {
if (!hasMoreElements()) {
throw new NoSuchElementException("OneLiner");
}
BufferLine tmpLine=new BufferLine(line.toString(),eolStr.substring(0));
nextLine();
return tmpLine;
}
/** 
 * Close the reader.
 * @throws IOException if there is an error.
 */
public void close() throws IOException {
if (reader != null) {
reader.close();
}
}
class BufferLine {
private int next=0;
private int column=0;
private int lookahead=UNDEF;
private String line;
private String eolStr;
public BufferLine(String line,String eolStr) throws BuildException {
next=0;
column=0;
this.line=line;
this.eolStr=eolStr;
}
public int getNext(){
return next;
}
public void setNext(int next){
this.next=next;
}
public int getLookahead(){
return lookahead;
}
public void setLookahead(int lookahead){
this.lookahead=lookahead;
}
public char getChar(int i){
return line.charAt(i);
}
public char getNextChar(){
return getChar(next);
}
public char getNextCharInc(){
return getChar(next++);
}
public int getColumn(){
return column;
}
public void setColumn(int col){
column=col;
}
public int incColumn(){
return column++;
}
public int length(){
return line.length();
}
public int getEolLength(){
return eolStr.length();
}
public String getLineString(){
return line;
}
public String getEol(){
return eolStr;
}
public String substring(int begin){
return line.substring(begin);
}
public String substring(int begin,int end){
return line.substring(begin,end);
}
public void setState(int state){
OneLiner.this.setState(state);
}
public int getState(){
return OneLiner.this.getState();
}
}
}
