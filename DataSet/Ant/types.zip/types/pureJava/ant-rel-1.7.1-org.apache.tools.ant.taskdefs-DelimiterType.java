/** 
 * delimiters we support, "normal" and "row"
 */
public static class DelimiterType extends EnumeratedAttribute {
  /** 
 * The enumerated strings 
 */
  public static final String NORMAL="normal", ROW="row";
  /** 
 * @return the enumerated strings 
 */
  public String[] getValues(){
    return new String[]{NORMAL,ROW};
  }
}
