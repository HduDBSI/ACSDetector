public class GroupArgument {
  private String title;
  private String packages;
  public GroupArgument(){
  }
  public void setTitle(  String src){
    title=src;
  }
  public String getTitle(){
    return title;
  }
  public void setPackages(  String src){
    packages=src;
  }
  public String getPackages(){
    return packages;
  }
}
