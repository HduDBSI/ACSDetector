/** 
 * This class handles the abstraction of the telnet protocol. Currently it is a wrapper around <a href="www.oroinc.com">ORO</a>'s  NetComponents
 */
public class AntTelnetClient extends TelnetClient {
  /** 
 * Read from the telnet session until the string we are  waiting for is found 
 * @parm s The string to wait on 
 */
  public void waitForString(  String s){
    waitForString(s,null);
  }
  /** 
 * Read from the telnet session until the string we are  waiting for is found or the timeout has been reached
 * @parm s The string to wait on 
 * @parm timeout The maximum number of seconds to wait
 */
  public void waitForString(  String s,  Integer timeout){
    InputStream is=this.getInputStream();
    try {
      StringBuffer sb=new StringBuffer();
      if (timeout == null || timeout.intValue() == 0) {
        while (sb.toString().indexOf(s) == -1) {
          sb.append((char)is.read());
        }
      }
 else {
        Calendar endTime=Calendar.getInstance();
        endTime.add(Calendar.SECOND,timeout.intValue());
        while (sb.toString().indexOf(s) == -1) {
          while (Calendar.getInstance().before(endTime) && is.available() == 0) {
            Thread.sleep(250);
          }
          if (is.available() == 0)           throw new BuildException("Response Timed-Out",getLocation());
          sb.append((char)is.read());
        }
      }
      log(sb.toString(),Project.MSG_INFO);
    }
 catch (    BuildException be) {
      throw be;
    }
catch (    Exception e) {
      throw new BuildException(e,getLocation());
    }
  }
  /** 
 * Write this string to the telnet session.
 * @parm echoString  Logs string sent
 */
  public void sendString(  String s,  boolean echoString){
    OutputStream os=this.getOutputStream();
    try {
      os.write((s + "\n").getBytes());
      if (echoString)       log(s,Project.MSG_INFO);
      os.flush();
    }
 catch (    Exception e) {
      throw new BuildException(e,getLocation());
    }
  }
}
