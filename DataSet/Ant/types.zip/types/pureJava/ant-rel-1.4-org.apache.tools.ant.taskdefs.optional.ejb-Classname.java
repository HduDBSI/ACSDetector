/** 
 * Convenience class used to represent the fully qualified name of a Java  class.  It provides an easy way to retrieve components of the class name  in a format that is convenient for building iAS stubs and skeletons.
 * @author Greg Nelson <a href="mailto:greg@netscape.com">greg@netscape.com</a>
 */
private class Classname {
  private String qualifiedName;
  private String packageName;
  private String className;
  /** 
 * This constructor builds an object which represents the name of a Java  class.
 * @param qualifiedName String representing the fully qualified classname of the Java class.
 */
  public Classname(  String qualifiedName){
    if (qualifiedName == null) {
      return;
    }
    this.qualifiedName=qualifiedName;
    int index=qualifiedName.lastIndexOf('.');
    if (index == -1) {
      className=qualifiedName;
      packageName="";
    }
 else {
      packageName=qualifiedName.substring(0,index);
      className=qualifiedName.substring(index + 1);
    }
  }
  /** 
 * Gets the fully qualified name of the Java class.
 * @return String representing the fully qualified class name.
 */
  public String getQualifiedClassName(){
    return qualifiedName;
  }
  /** 
 * Gets the package name for the Java class.
 * @return String representing the package name for the class.
 */
  public String getPackageName(){
    return packageName;
  }
  /** 
 * Gets the Java class name without the package structure.
 * @return String representing the name for the class.
 */
  public String getClassName(){
    return className;
  }
  /** 
 * Gets the fully qualified name of the Java class with underscores  separating the components of the class name rather than periods.   This format is used in naming some of the stub and skeleton classes  for the iPlanet Application Server.  
 * @return String representing the fully qualified class name using underscores instead of periods.
 */
  public String getQualifiedWithUnderscores(){
    return qualifiedName.replace('.','_');
  }
  /** 
 * Returns a File which references the class relative to the specified directory.  Note that the class file may or may not exist.
 * @param directory A File referencing the base directory containingclass files.
 * @return File referencing this class.
 */
  public File getClassFile(  File directory){
    String pathToFile=qualifiedName.replace('.',File.separatorChar) + ".class";
    return new File(directory,pathToFile);
  }
  /** 
 * String representation of this class name.  It returns the fully qualified class name.
 * @return String representing the fully qualified class name.
 */
  public String toString(){
    return getQualifiedClassName();
  }
}
