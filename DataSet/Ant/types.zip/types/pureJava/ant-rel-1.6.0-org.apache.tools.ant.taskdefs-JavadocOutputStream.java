private class JavadocOutputStream extends LogOutputStream {
  JavadocOutputStream(  int level){
    super(Javadoc.this,level);
  }
  private String queuedLine=null;
  protected void processLine(  String line,  int messageLevel){
    if (messageLevel == Project.MSG_INFO && line.startsWith("Generating ")) {
      if (queuedLine != null) {
        super.processLine(queuedLine,Project.MSG_VERBOSE);
      }
      queuedLine=line;
    }
 else {
      if (queuedLine != null) {
        if (line.startsWith("Building ")) {
          super.processLine(queuedLine,Project.MSG_VERBOSE);
        }
 else {
          super.processLine(queuedLine,Project.MSG_INFO);
        }
        queuedLine=null;
      }
      super.processLine(line,messageLevel);
    }
  }
  protected void logFlush(){
    if (queuedLine != null) {
      super.processLine(queuedLine,Project.MSG_VERBOSE);
      queuedLine=null;
    }
  }
}
