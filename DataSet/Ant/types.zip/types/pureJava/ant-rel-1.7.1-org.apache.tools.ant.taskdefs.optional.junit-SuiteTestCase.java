public static class SuiteTestCase extends NoSuiteTestCase {
  public SuiteTestCase(  String name){
    super(name);
  }
  public static Test suite(){
    return new TestSuite(SuiteTestCase.class);
  }
}
