protected class ValidatorErrorHandler implements ErrorHandler {
  protected File currentFile=null;
  protected String lastErrorMessage=null;
  protected boolean failed=false;
  public void init(  File file){
    currentFile=file;
    failed=false;
  }
  public boolean getFailure(){
    return failed;
  }
  public void fatalError(  SAXParseException exception){
    failed=true;
    doLog(exception,Project.MSG_ERR);
  }
  public void error(  SAXParseException exception){
    failed=true;
    doLog(exception,Project.MSG_ERR);
  }
  public void warning(  SAXParseException exception){
    if (warn)     doLog(exception,Project.MSG_WARN);
  }
  private void doLog(  SAXParseException e,  int logLevel){
    log(getMessage(e),logLevel);
  }
  private String getMessage(  SAXParseException e){
    String sysID=e.getSystemId();
    if (sysID != null) {
      try {
        int line=e.getLineNumber();
        int col=e.getColumnNumber();
        return new URL(sysID).getFile() + (line == -1 ? "" : (":" + line + (col == -1 ? "" : (":" + col)))) + ": "+ e.getMessage();
      }
 catch (      MalformedURLException mfue) {
      }
    }
    return e.getMessage();
  }
}
