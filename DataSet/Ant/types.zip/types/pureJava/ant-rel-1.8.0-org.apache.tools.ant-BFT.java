private class BFT extends org.apache.tools.ant.BuildFileTest {
  BFT(  String name,  String buildfile){
    super(name);
    this.buildfile=buildfile;
    setUp();
  }
  boolean isConfigured=false;
  String buildfile="";
  public void setUp(){
    if (!isConfigured) {
      configureProject("src/etc/testcases/" + buildfile);
      isConfigured=true;
    }
  }
  public void tearDown(){
  }
  public void doTarget(  String target){
    if (!isConfigured)     setUp();
    executeTarget(target);
  }
  public org.apache.tools.ant.Project getProject(){
    return super.getProject();
  }
}
