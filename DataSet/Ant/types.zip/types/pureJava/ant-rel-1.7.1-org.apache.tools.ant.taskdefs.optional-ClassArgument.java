/** 
 * A class corresponding the the nested "class" element. It contains a "name" attribute.
 */
public class ClassArgument {
  private String name;
  /** 
 * Constructor for ClassArgument. 
 */
  public ClassArgument(){
  }
  /** 
 * Set the name attribute.
 * @param name the name attribute.
 */
  public void setName(  String name){
    this.name=name;
  }
  /** 
 * Get the name attribute.
 * @return the name attribute.
 */
  public String getName(){
    return name;
  }
}
