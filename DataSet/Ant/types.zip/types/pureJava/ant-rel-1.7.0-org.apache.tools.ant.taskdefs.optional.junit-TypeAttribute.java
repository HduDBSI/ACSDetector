/** 
 * <p> Enumerated attribute with the values "plain", "xml" and "brief". <p> Use to enumerate options for <code>type</code> attribute.
 */
public static class TypeAttribute extends EnumeratedAttribute {
  /** 
 * {@inheritDoc}. 
 */
  public String[] getValues(){
    return new String[]{"plain","xml","brief"};
  }
}
