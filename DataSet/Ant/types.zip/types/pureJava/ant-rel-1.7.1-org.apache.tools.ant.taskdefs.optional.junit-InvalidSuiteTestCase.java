public static class InvalidSuiteTestCase extends NoSuiteTestCase {
  public InvalidSuiteTestCase(  String name){
    super(name);
  }
  public static Test suite(){
    throw new NullPointerException("thrown on purpose");
  }
}
