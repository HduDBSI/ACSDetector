/** 
 * A list of possible values for the <code>setAction()</code> method. Possible values include: start and stop.
 */
public static class ActionChoices extends EnumeratedAttribute {
  private static final String[] values={"start","stop"};
  public String[] getValues(){
    return values;
  }
}
