private static final class TestRunner extends JUnitTestRunner {
  private ResultFormatter formatter=new ResultFormatter();
  TestRunner(  JUnitTest test,  String[] methods,  boolean haltonerror,  boolean filtertrace,  boolean haltonfailure){
    super(test,methods,haltonerror,filtertrace,haltonfailure,false,false,TestRunner.class.getClassLoader());
    addFormatter(formatter);
  }
  ResultFormatter getFormatter(){
    return formatter;
  }
}
