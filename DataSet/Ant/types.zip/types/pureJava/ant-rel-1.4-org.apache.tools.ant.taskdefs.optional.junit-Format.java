public static class Format extends EnumeratedAttribute {
  public String[] getValues(){
    return new String[]{FRAMES,NOFRAMES};
  }
}
