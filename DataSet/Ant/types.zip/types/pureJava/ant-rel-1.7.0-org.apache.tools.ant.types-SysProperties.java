/** 
 * Specialized Environment class for System properties.
 */
public static class SysProperties extends Environment implements Cloneable {
  /** 
 * the system properties. 
 */
  Properties sys=null;
  private Vector propertySets=new Vector();
  /** 
 * Get the properties as an array; this is an override of the superclass, as it evaluates all the properties.
 * @return the array of definitions; may be null.
 * @throws BuildException on error.
 */
  public String[] getVariables() throws BuildException {
    List definitions=new LinkedList();
    ListIterator list=definitions.listIterator();
    addDefinitionsToList(list);
    if (definitions.size() == 0) {
      return null;
    }
 else {
      return (String[])definitions.toArray(new String[definitions.size()]);
    }
  }
  /** 
 * Add all definitions (including property sets) to a list.
 * @param listIt list iterator supporting add method.
 */
  public void addDefinitionsToList(  ListIterator listIt){
    String[] props=super.getVariables();
    if (props != null) {
      for (int i=0; i < props.length; i++) {
        listIt.add("-D" + props[i]);
      }
    }
    Properties propertySetProperties=mergePropertySets();
    for (Enumeration e=propertySetProperties.keys(); e.hasMoreElements(); ) {
      String key=(String)e.nextElement();
      String value=propertySetProperties.getProperty(key);
      listIt.add("-D" + key + "="+ value);
    }
  }
  /** 
 * Get the size of the sysproperties instance. This merges all property sets, so is not an O(1) operation.
 * @return the size of the sysproperties instance.
 */
  public int size(){
    Properties p=mergePropertySets();
    return variables.size() + p.size();
  }
  /** 
 * Cache the system properties and set the system properties to the new values.
 * @throws BuildException if Security prevented this operation.
 */
  public void setSystem() throws BuildException {
    try {
      sys=System.getProperties();
      Properties p=new Properties();
      for (Enumeration e=sys.propertyNames(); e.hasMoreElements(); ) {
        String name=(String)e.nextElement();
        p.put(name,sys.getProperty(name));
      }
      p.putAll(mergePropertySets());
      for (Enumeration e=variables.elements(); e.hasMoreElements(); ) {
        Environment.Variable v=(Environment.Variable)e.nextElement();
        v.validate();
        p.put(v.getKey(),v.getValue());
      }
      System.setProperties(p);
    }
 catch (    SecurityException e) {
      throw new BuildException("Cannot modify system properties",e);
    }
  }
  /** 
 * Restore the system properties to the cached value.
 * @throws BuildException  if Security prevented this operation, orthere were no system properties to restore.
 */
  public void restoreSystem() throws BuildException {
    if (sys == null) {
      throw new BuildException("Unbalanced nesting of SysProperties");
    }
    try {
      System.setProperties(sys);
      sys=null;
    }
 catch (    SecurityException e) {
      throw new BuildException("Cannot modify system properties",e);
    }
  }
  /** 
 * Create a deep clone.
 * @return a cloned instance of SysProperties.
 * @exception CloneNotSupportedException for signature.
 */
  public Object clone() throws CloneNotSupportedException {
    try {
      SysProperties c=(SysProperties)super.clone();
      c.variables=(Vector)variables.clone();
      c.propertySets=(Vector)propertySets.clone();
      return c;
    }
 catch (    CloneNotSupportedException e) {
      return null;
    }
  }
  /** 
 * Add a propertyset to the total set.
 * @param ps the new property set.
 */
  public void addSyspropertyset(  PropertySet ps){
    propertySets.addElement(ps);
  }
  /** 
 * Add a propertyset to the total set.
 * @param ps the new property set.
 * @since Ant 1.6.3
 */
  public void addSysproperties(  SysProperties ps){
    variables.addAll(ps.variables);
    propertySets.addAll(ps.propertySets);
  }
  /** 
 * Merge all property sets into a single Properties object.
 * @return the merged object.
 */
  private Properties mergePropertySets(){
    Properties p=new Properties();
    for (Enumeration e=propertySets.elements(); e.hasMoreElements(); ) {
      PropertySet ps=(PropertySet)e.nextElement();
      p.putAll(ps.getProperties());
    }
    return p;
  }
}
