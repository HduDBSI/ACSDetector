/** 
 * Filter interface to be applied when iterating over a DOM tree. Just think of it like a <tt>FileFilter</tt> clone.
 */
public interface NodeFilter {
  /** 
 * @param node    the node to check for acceptance.
 * @return      <tt>true</tt> if the node is accepted by this filter,otherwise <tt>false</tt>
 */
  public boolean accept(  Node node);
}
