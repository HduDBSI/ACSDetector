public static class TestNormal extends EnumeratedAttribute {
  public String[] getValues(){
    return expected;
  }
}
