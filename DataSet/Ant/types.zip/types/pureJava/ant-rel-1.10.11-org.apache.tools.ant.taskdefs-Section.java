/** 
 * A manifest section - you can nest attribute elements into sections. A section consists of a set of attribute values, separated from other sections by a blank line.
 */
public static class Section {
  /** 
 * Warnings for this section 
 */
  private List<String> warnings=new Vector<>();
  /** 
 * The section's name if any. The main section in a manifest is unnamed.
 */
  private String name=null;
  /** 
 * The section's attributes.
 */
  private Map<String,Attribute> attributes=new LinkedHashMap<>();
  /** 
 * The name of the section; optional -default is the main section.
 * @param name the section's name
 */
  public void setName(  String name){
    this.name=name;
  }
  /** 
 * Get the Section's name.
 * @return the section's name.
 */
  public String getName(){
    return name;
  }
  /** 
 * Read a section through a reader.
 * @param reader the reader from which the section is read
 * @return the name of the next section if it has been read aspart of this section - This only happens if the Manifest is malformed.
 * @throws ManifestException if the section is not valid accordingto the JAR spec
 * @throws IOException if the section cannot be read from the reader.
 */
  public String read(  BufferedReader reader) throws ManifestException, IOException {
    Attribute attribute=null;
    while (true) {
      String line=reader.readLine();
      if (line == null || line.isEmpty()) {
        return null;
      }
      if (line.charAt(0) == ' ') {
        if (attribute == null) {
          if (name == null) {
            throw new ManifestException("Can't start an " + "attribute with a continuation line " + line);
          }
          name+=line.substring(1);
        }
 else {
          attribute.addContinuation(line);
        }
      }
 else {
        attribute=new Attribute(line);
        String nameReadAhead=addAttributeAndCheck(attribute);
        attribute=getAttribute(attribute.getKey());
        if (nameReadAhead != null) {
          return nameReadAhead;
        }
      }
    }
  }
  /** 
 * Merge in another section without merging Class-Path attributes.
 * @param section the section to be merged with this one.
 * @throws ManifestException if the sections cannot be merged.
 */
  public void merge(  Section section) throws ManifestException {
    merge(section,false);
  }
  /** 
 * Merge in another section
 * @param section the section to be merged with this one.
 * @param mergeClassPaths whether Class-Path attributes shouldbe merged.
 * @throws ManifestException if the sections cannot be merged.
 */
  public void merge(  Section section,  boolean mergeClassPaths) throws ManifestException {
    if (name == null && section.getName() != null || (name != null && section.getName() != null && !(name.toLowerCase(Locale.ENGLISH).equals(section.getName().toLowerCase(Locale.ENGLISH))))) {
      throw new ManifestException("Unable to merge sections with different names");
    }
    Attribute classpathAttribute=null;
    for (    String attributeName : Collections.list(section.getAttributeKeys())) {
      Attribute attribute=section.getAttribute(attributeName);
      if (ATTRIBUTE_CLASSPATH.equalsIgnoreCase(attributeName)) {
        if (classpathAttribute == null) {
          classpathAttribute=new Attribute();
          classpathAttribute.setName(ATTRIBUTE_CLASSPATH);
        }
        Collections.list(attribute.getValues()).forEach(classpathAttribute::addValue);
      }
 else {
        storeAttribute(attribute);
      }
    }
    if (classpathAttribute != null) {
      if (mergeClassPaths) {
        Attribute currentCp=getAttribute(ATTRIBUTE_CLASSPATH);
        if (currentCp != null) {
          Collections.list(currentCp.getValues()).forEach(classpathAttribute::addValue);
        }
      }
      storeAttribute(classpathAttribute);
    }
    warnings.addAll(section.warnings);
  }
  /** 
 * Write the section out to a print writer without flattening multi-values attributes (i.e. Class-Path).
 * @param writer the Writer to which the section is written
 * @throws IOException if the section cannot be written
 */
  public void write(  PrintWriter writer) throws IOException {
    write(writer,false);
  }
  /** 
 * Write the section out to a print writer.
 * @param writer the Writer to which the section is written
 * @param flatten whether to collapse multi-valued attributes(i.e. potentially Class-Path) Class-Path into a single attribute.
 * @throws IOException if the section cannot be written
 * @since Ant 1.8.0
 */
  public void write(  PrintWriter writer,  boolean flatten) throws IOException {
    if (name != null) {
      Attribute nameAttr=new Attribute(ATTRIBUTE_NAME,name);
      nameAttr.write(writer);
    }
    for (    String key : Collections.list(getAttributeKeys())) {
      getAttribute(key).write(writer,flatten);
    }
    writer.print(EOL);
  }
  /** 
 * Get a attribute of the section
 * @param attributeName the name of the attribute
 * @return a Manifest.Attribute instance if the attribute issingle-valued, otherwise a Vector of Manifest.Attribute instances.
 */
  public Attribute getAttribute(  String attributeName){
    return attributes.get(attributeName.toLowerCase(Locale.ENGLISH));
  }
  /** 
 * Get the attribute keys.
 * @return an Enumeration of Strings, each string being the lower casekey of an attribute of the section.
 */
  public Enumeration<String> getAttributeKeys(){
    return Collections.enumeration(attributes.keySet());
  }
  /** 
 * Get the value of the attribute with the name given.
 * @param attributeName the name of the attribute to be returned.
 * @return the attribute's value or null if the attribute does not existin the section
 */
  public String getAttributeValue(  String attributeName){
    Attribute attribute=getAttribute(attributeName.toLowerCase(Locale.ENGLISH));
    return attribute == null ? null : attribute.getValue();
  }
  /** 
 * Remove the given attribute from the section
 * @param attributeName the name of the attribute to be removed.
 */
  public void removeAttribute(  String attributeName){
    String key=attributeName.toLowerCase(Locale.ENGLISH);
    attributes.remove(key);
  }
  /** 
 * Add an attribute to the section.
 * @param attribute the attribute to be added to the section
 * @exception ManifestException if the attribute is not valid.
 */
  public void addConfiguredAttribute(  Attribute attribute) throws ManifestException {
    String check=addAttributeAndCheck(attribute);
    if (check != null) {
      throw new BuildException("Specify the section name using the \"name\" attribute of the <section> element rather than using a \"Name\" manifest attribute");
    }
  }
  /** 
 * Add an attribute to the section
 * @param attribute the attribute to be added.
 * @return the value of the attribute if it is a nameattribute - null other wise
 * @exception ManifestException if the attribute alreadyexists in this section.
 */
  public String addAttributeAndCheck(  Attribute attribute) throws ManifestException {
    if (attribute.getName() == null || attribute.getValue() == null) {
      throw new BuildException("Attributes must have name and value");
    }
    String attributeKey=attribute.getKey();
    if (attributeKey.equals(ATTRIBUTE_NAME_LC)) {
      warnings.add("\"" + ATTRIBUTE_NAME + "\" attributes should not occur in the main section and must be the first element in all other sections: \""+ attribute.getName()+ ": "+ attribute.getValue()+ "\"");
      return attribute.getValue();
    }
    if (attributeKey.startsWith(ATTRIBUTE_FROM_LC)) {
      warnings.add(ERROR_FROM_FORBIDDEN + attribute.getName() + ": "+ attribute.getValue()+ "\"");
    }
 else {
      if (attributeKey.equals(ATTRIBUTE_CLASSPATH_LC)) {
        Attribute classpathAttribute=attributes.get(attributeKey);
        if (classpathAttribute == null) {
          storeAttribute(attribute);
        }
 else {
          warnings.add("Multiple Class-Path attributes are supported but violate the Jar specification and may not be correctly processed in all environments");
          Collections.list(attribute.getValues()).forEach(classpathAttribute::addValue);
        }
      }
 else       if (attributes.containsKey(attributeKey)) {
        throw new ManifestException("The attribute \"" + attribute.getName() + "\" may not occur more than once in the same section");
      }
 else {
        storeAttribute(attribute);
      }
    }
    return null;
  }
  /** 
 * Clone this section
 * @return the cloned Section
 * @since Ant 1.5.2
 */
  @Override public Object clone(){
    Section cloned=new Section();
    cloned.setName(name);
    StreamUtils.enumerationAsStream(getAttributeKeys()).map(key -> new Attribute(getAttribute(key).getName(),getAttribute(key).getValue())).forEach(cloned::storeAttribute);
    return cloned;
  }
  /** 
 * Store an attribute and update the index.
 * @param attribute the attribute to be stored
 */
  private void storeAttribute(  Attribute attribute){
    if (attribute == null) {
      return;
    }
    attributes.put(attribute.getKey(),attribute);
  }
  /** 
 * Get the warnings for this section.
 * @return an Enumeration of warning strings.
 */
  public Enumeration<String> getWarnings(){
    return Collections.enumeration(warnings);
  }
  /** 
 * @see java.lang.Object#hashCode
 * @return a hash value based on the attributes.
 */
  @Override public int hashCode(){
    return attributes.hashCode();
  }
  /** 
 * @see java.lang.Object#equals
 * @param rhs the object to check for equality.
 * @return true if the attributes are the same.
 */
  @Override public boolean equals(  Object rhs){
    if (rhs == null || rhs.getClass() != getClass()) {
      return false;
    }
    if (rhs == this) {
      return true;
    }
    Section rhsSection=(Section)rhs;
    return attributes.equals(rhsSection.attributes);
  }
}
