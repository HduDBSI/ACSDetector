/** 
 * An EnumeratedAttribute class for handling different EJB jar naming schemes
 */
public static class NamingScheme extends EnumeratedAttribute {
  /** 
 * Naming scheme where generated jar is determined from the ejb-name in the deployment descripor
 */
  public static final String EJB_NAME="ejb-name";
  /** 
 * Naming scheme where the generated jar name is based on the name of the directory containing the deployment descriptor
 */
  public static final String DIRECTORY="directory";
  /** 
 * Naming scheme where the generated jar name is based on the name of the deployment descriptor file
 */
  public static final String DESCRIPTOR="descriptor";
  /** 
 * Naming scheme where the generated jar is named by the basejarname attribute
 */
  public static final String BASEJARNAME="basejarname";
  /** 
 * Gets the values of the NamingScheme
 * @return an array of the values of this attribute class.
 */
  public String[] getValues(){
    return new String[]{EJB_NAME,DIRECTORY,DESCRIPTOR,BASEJARNAME};
  }
}
