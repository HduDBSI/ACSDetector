/** 
 * This PrintStream subclass makes sure that <CRLF>. becomes <CRLF>.. per RFC 821.  It also ensures that new lines are always \r\n.
 */
class MailPrintStream extends PrintStream {
  private int lastChar;
  public MailPrintStream(  OutputStream out){
    super(out,true);
  }
  public void write(  int b){
    if (b == '\n' && lastChar != '\r') {
      rawWrite('\r');
      rawWrite(b);
    }
 else     if (b == '.' && lastChar == '\n') {
      rawWrite('.');
      rawWrite(b);
    }
 else {
      rawWrite(b);
    }
    lastChar=b;
  }
  public void write(  byte[] buf,  int off,  int len){
    for (int i=0; i < len; i++) {
      write(buf[off + i]);
    }
  }
  void rawWrite(  int b){
    super.write(b);
  }
  void rawPrint(  String s){
    int len=s.length();
    for (int i=0; i < len; i++) {
      rawWrite(s.charAt(i));
    }
  }
}
