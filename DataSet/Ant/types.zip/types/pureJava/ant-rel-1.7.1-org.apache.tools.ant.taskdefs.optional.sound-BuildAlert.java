/** 
 * A class to be extended by any BuildAlert's that require the output of sound.
 */
public class BuildAlert {
  private File source=null;
  private int loops=0;
  private Long duration=null;
  /** 
 * Sets the duration in milliseconds the file should be played; optional.
 * @param duration the duration in millisconds
 */
  public void setDuration(  Long duration){
    this.duration=duration;
  }
  /** 
 * Sets the location of the file to get the audio; required.
 * @param source the name of a sound-file directory or of the audio file
 */
  public void setSource(  File source){
    this.source=source;
  }
  /** 
 * Sets the number of times the source file should be played; optional.
 * @param loops the number of loops to play the source file
 */
  public void setLoops(  int loops){
    this.loops=loops;
  }
  /** 
 * Gets the location of the file to get the audio.
 * @return the file location
 */
  public File getSource(){
    File nofile=null;
    if (source.exists()) {
      if (source.isDirectory()) {
        String[] entries=source.list();
        Vector files=new Vector();
        for (int i=0; i < entries.length; i++) {
          File f=new File(source,entries[i]);
          if (f.isFile()) {
            files.addElement(f);
          }
        }
        if (files.size() < 1) {
          throw new BuildException("No files found in directory " + source);
        }
        int numfiles=files.size();
        Random rn=new Random();
        int x=rn.nextInt(numfiles);
        this.source=(File)files.elementAt(x);
      }
    }
 else {
      log(source + ": invalid path.",Project.MSG_WARN);
      this.source=nofile;
    }
    return this.source;
  }
  /** 
 * Sets the number of times the source file should be played.
 * @return the number of loops to play the source file
 */
  public int getLoops(){
    return this.loops;
  }
  /** 
 * Gets the duration in milliseconds the file should be played.
 * @return the duration in milliseconds
 */
  public Long getDuration(){
    return this.duration;
  }
}
