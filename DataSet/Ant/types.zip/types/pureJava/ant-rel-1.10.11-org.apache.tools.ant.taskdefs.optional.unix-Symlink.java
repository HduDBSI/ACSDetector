/** 
 * Creates, Deletes, Records and Restores Symlinks. <p>This task performs several related operations. In the most trivial and default usage, it creates a link specified in the link attribute to a resource specified in the resource attribute. The second usage of this task is to traverse a directory structure specified by a fileset, and write a properties file in each included directory describing the links found in that directory. The third usage is to traverse a directory structure specified by a fileset, looking for properties files (also specified as included in the fileset) and recreate the links that have been previously recorded for each directory. Finally, it can be used to remove a symlink without deleting the associated resource.</p> <p>Usage examples:</p> <p>Make a link named &quot;foo&quot; to a resource named &quot;bar.foo&quot; in subdir:</p> <pre> &lt;symlink link=&quot;${dir.top}/foo&quot; resource=&quot;${dir.top}/subdir/bar.foo&quot;/&gt; </pre> <p>Record all links in subdir and its descendants in files named &quot;dir.links&quot;:</p> <pre> &lt;symlink action=&quot;record&quot; linkfilename=&quot;dir.links&quot;&gt; &lt;fileset dir=&quot;${dir.top}&quot; includes=&quot;subdir&#47;**&quot; /&gt; &lt;/symlink&gt; </pre> <p>Recreate the links recorded in the previous example:</p> <pre> &lt;symlink action=&quot;recreate&quot;&gt; &lt;fileset dir=&quot;${dir.top}&quot; includes=&quot;subdir&#47;**&#47;dir.links&quot; /&gt; &lt;/symlink&gt; </pre> <p>Delete a link named &quot;foo&quot; to a resource named &quot;bar.foo&quot; in subdir:</p> <pre> &lt;symlink action=&quot;delete&quot; link=&quot;${dir.top}/foo&quot;/&gt; </pre> <p><strong>Note:</strong> Starting Ant version 1.10.2, this task relies on the symbolic link support introduced in Java 7 through the  {@link Files} APIs.
 */
public class Symlink extends DispatchTask {
  private String resource;
  private String link;
  private List<FileSet> fileSets=new ArrayList<>();
  private String linkFileName;
  private boolean overwrite;
  private boolean failonerror;
  private boolean executing=false;
  /** 
 * Initialize the task.
 * @throws BuildException on error.
 */
  @Override public void init() throws BuildException {
    super.init();
    setDefaults();
  }
  /** 
 * The standard method for executing any task.
 * @throws BuildException on error.
 */
  @Override public synchronized void execute() throws BuildException {
    if (executing) {
      throw new BuildException("Infinite recursion detected in Symlink.execute()");
    }
    try {
      executing=true;
      DispatchUtils.execute(this);
    }
  finally {
      executing=false;
    }
  }
  /** 
 * Create a symlink.
 * @throws BuildException on error.
 * @since Ant 1.7
 */
  public void single() throws BuildException {
    try {
      if (resource == null) {
        handleError("Must define the resource to symlink to!");
        return;
      }
      if (link == null) {
        handleError("Must define the link name for symlink!");
        return;
      }
      doLink(resource,link);
    }
  finally {
      setDefaults();
    }
  }
  /** 
 * Delete a symlink.
 * @throws BuildException on error.
 * @since Ant 1.7
 */
  public void delete() throws BuildException {
    try {
      if (link == null) {
        handleError("Must define the link name for symlink!");
        return;
      }
      final Path linkPath=Paths.get(link);
      if (!Files.isSymbolicLink(linkPath)) {
        log("Skipping deletion of " + linkPath + " since it's not a symlink",Project.MSG_VERBOSE);
        return;
      }
      log("Removing symlink: " + link);
      deleteSymLink(linkPath);
    }
 catch (    IOException ioe) {
      handleError(ioe.getMessage());
    }
 finally {
      setDefaults();
    }
  }
  /** 
 * Restore symlinks.
 * @throws BuildException on error.
 * @since Ant 1.7
 */
  public void recreate() throws BuildException {
    try {
      if (fileSets.isEmpty()) {
        handleError("File set identifying link file(s) required for action recreate");
        return;
      }
      final Properties links=loadLinks(fileSets);
      for (      final String link : links.stringPropertyNames()) {
        final String resource=links.getProperty(link);
        try {
          if (Files.isSymbolicLink(Paths.get(link)) && new File(link).getCanonicalPath().equals(new File(resource).getCanonicalPath())) {
            log("not recreating " + link + " as it points to the correct target already",Project.MSG_DEBUG);
            continue;
          }
        }
 catch (        IOException e) {
          final String errMessage="Failed to check if path " + link + " is a symbolic link, linking to "+ resource;
          if (failonerror) {
            throw new BuildException(errMessage,e);
          }
          log(errMessage,Project.MSG_INFO);
          continue;
        }
        this.doLink(resource,link);
      }
    }
  finally {
      setDefaults();
    }
  }
  /** 
 * Record symlinks.
 * @throws BuildException on error.
 * @since Ant 1.7
 */
  public void record() throws BuildException {
    try {
      if (fileSets.isEmpty()) {
        handleError("Fileset identifying links to record required");
        return;
      }
      if (linkFileName == null) {
        handleError("Name of file to record links in required");
        return;
      }
      Map<File,List<File>> byDir=new HashMap<>();
      findLinks(fileSets).forEach(link -> byDir.computeIfAbsent(link.getParentFile(),k -> new ArrayList<>()).add(link));
      byDir.forEach((dir,linksInDir) -> {
        Properties linksToStore=new Properties();
        for (        File link : linksInDir) {
          try {
            linksToStore.put(link.getName(),link.getCanonicalPath());
          }
 catch (          IOException ioe) {
            handleError("Couldn't get canonical name of parent link");
          }
        }
        writePropertyFile(linksToStore,dir);
      }
);
    }
  finally {
      setDefaults();
    }
  }
  /** 
 * Return all variables to their default state for the next invocation.
 * @since Ant 1.7
 */
  private void setDefaults(){
    resource=null;
    link=null;
    linkFileName=null;
    failonerror=true;
    overwrite=false;
    setAction("single");
    fileSets.clear();
  }
  /** 
 * Set overwrite mode. If set to false (default) the task will not overwrite existing links, and may stop the build if a link already exists depending on the setting of failonerror.
 * @param owrite If true overwrite existing links.
 */
  public void setOverwrite(  boolean owrite){
    this.overwrite=owrite;
  }
  /** 
 * Set failonerror mode. If set to true (default) the entire build fails upon error; otherwise the error is logged and the build will continue.
 * @param foe    If true throw BuildException on error, else log it.
 */
  public void setFailOnError(  boolean foe){
    this.failonerror=foe;
  }
  /** 
 * Set the action to be performed.  May be &quot;single&quot;, &quot;delete&quot;, &quot;recreate&quot; or &quot;record&quot;.
 * @param action    The action to perform.
 */
  @Override public void setAction(  String action){
    super.setAction(action);
  }
  /** 
 * Set the name of the link. Used when action = &quot;single&quot;.
 * @param link     The name for the link.
 */
  public void setLink(  String link){
    this.link=link;
  }
  /** 
 * Set the name of the resource to which a link should be created. Used when action = &quot;single&quot;.
 * @param src      The resource to be linked.
 */
  public void setResource(  String src){
    this.resource=src;
  }
  /** 
 * Set the name of the file to which links will be written. Used when action = &quot;record&quot;.
 * @param lf      The name of the file to write links to.
 */
  public void setLinkfilename(  String lf){
    this.linkFileName=lf;
  }
  /** 
 * Add a fileset to this task.
 * @param set      The fileset to add.
 */
  public void addFileset(  FileSet set){
    fileSets.add(set);
  }
  /** 
 * Delete a symlink (without deleting the associated resource). <p>This is a convenience method that simply invokes  {@link #deleteSymlink(File)}</p>
 * @param path A string containing the path of the symlink to delete.
 * @throws IOException If the deletion attempt fails
 * @deprecated use {@link Files#delete(Path)} instead
 */
  @Deprecated public static void deleteSymlink(  final String path) throws IOException {
    deleteSymlink(Paths.get(path).toFile());
  }
  /** 
 * Delete a symlink (without deleting the associated resource). <p>This is a utility method that removes a symlink without removing the resource that the symlink points to. If it is accidentally invoked on a real file, the real file will not be harmed and instead this method returns silently.</p> <p>Since Ant 1.10.2 this method relies on the  {@link Files#isSymbolicLink(Path)}and  {@link Files#delete(Path)} to check and delete the symlink</p>
 * @param linkfil A <code>File</code> object of the symlink to delete. Cannot be null.
 * @throws IOException If the attempt to delete runs into exception
 * @deprecated use {@link Files#delete(Path)} instead
 */
  @Deprecated public static void deleteSymlink(  final File linkfil) throws IOException {
    if (!Files.isSymbolicLink(linkfil.toPath())) {
      return;
    }
    deleteSymLink(linkfil.toPath());
  }
  /** 
 * Write a properties file. This method uses <code>Properties.store</code> and thus may throw exceptions that occur while writing the file.
 * @param properties     The properties object to be written.
 * @param dir            The directory for which we are writing the links.
 * @throws BuildException if the property file could not be written
 */
  private void writePropertyFile(  Properties properties,  File dir) throws BuildException {
    try (BufferedOutputStream bos=new BufferedOutputStream(Files.newOutputStream(new File(dir,linkFileName).toPath()))){
      properties.store(bos,"Symlinks from " + dir);
    }
 catch (    IOException ioe) {
      throw new BuildException(ioe,getLocation());
    }
  }
  /** 
 * Handle errors based on the setting of failonerror.
 * @param msg    The message to log, or include in the<code>BuildException</code>.
 * @throws BuildException with the message if failonerror=true
 */
  private void handleError(  String msg){
    if (failonerror) {
      throw new BuildException(msg);
    }
    log(msg);
  }
  /** 
 * Conduct the actual construction of a link.
 * @param resource The path of the resource we are linking to.
 * @param link The name of the link we wish to make.
 * @throws BuildException when things go wrong
 */
  private void doLink(  String resource,  String link) throws BuildException {
    final Path linkPath=Paths.get(link);
    final Path target=Paths.get(resource);
    final boolean alreadyExists=Files.exists(linkPath,LinkOption.NOFOLLOW_LINKS);
    if (!alreadyExists) {
      try {
        log("creating symlink " + linkPath + " -> "+ target,Project.MSG_DEBUG);
        Files.createSymbolicLink(linkPath,target);
      }
 catch (      IOException e) {
        if (failonerror) {
          throw new BuildException("Failed to create symlink " + link + " to target "+ resource,e);
        }
        log("Unable to create symlink " + link + " to target "+ resource,e,Project.MSG_INFO);
      }
      return;
    }
    if (!overwrite) {
      log("Skipping symlink creation, since file at " + link + " already exists and overwrite is set to false",Project.MSG_INFO);
      return;
    }
    final boolean existingFileDeleted=linkPath.toFile().delete();
    if (!existingFileDeleted) {
      handleError("Deletion of file at " + link + " failed, while trying to overwrite it with a symlink");
      return;
    }
    try {
      log("creating symlink " + linkPath + " -> "+ target+ " after removing original",Project.MSG_DEBUG);
      Files.createSymbolicLink(linkPath,target);
    }
 catch (    IOException e) {
      if (failonerror) {
        throw new BuildException("Failed to create symlink " + link + " to target "+ resource,e);
      }
      log("Unable to create symlink " + link + " to target "+ resource,e,Project.MSG_INFO);
    }
  }
  /** 
 * Find all the links in all supplied filesets. <p>This method is invoked when the action attribute is &quot;record&quot;. This means that filesets are interpreted as the directories in which links may be found.</p>
 * @param fileSets The filesets specified by the user.
 * @return A Set of <code>File</code> objects containing thelinks (with canonical parent directories).
 */
  private Set<File> findLinks(  List<FileSet> fileSets){
    final Set<File> result=new HashSet<>();
    for (    FileSet fs : fileSets) {
      DirectoryScanner ds=fs.getDirectoryScanner(getProject());
      File dir=fs.getDir(getProject());
      Stream.of(ds.getIncludedFiles(),ds.getIncludedDirectories()).flatMap(Stream::of).forEach(path -> {
        try {
          final File f=new File(dir,path);
          final File pf=f.getParentFile();
          final String name=f.getName();
          final File parentDirCanonicalizedFile=new File(pf.getCanonicalPath(),name);
          if (Files.isSymbolicLink(parentDirCanonicalizedFile.toPath())) {
            result.add(parentDirCanonicalizedFile);
          }
        }
 catch (        IOException e) {
          handleError("IOException: " + path + " omitted");
        }
      }
);
    }
    return result;
  }
  /** 
 * Load links from properties files included in one or more FileSets. <p>This method is only invoked when the action attribute is set to &quot;recreate&quot;. The filesets passed in are assumed to specify the names of the property files with the link information and the subdirectories in which to look for them.</p>
 * @param fileSets    The <code>FileSet</code>s for this task.
 * @return            The links to be made.
 */
  private Properties loadLinks(  List<FileSet> fileSets){
    Properties finalList=new Properties();
    for (    FileSet fs : fileSets) {
      DirectoryScanner ds=new DirectoryScanner();
      fs.setupDirectoryScanner(ds,getProject());
      ds.setFollowSymlinks(false);
      ds.scan();
      File dir=fs.getDir(getProject());
      for (      String name : ds.getIncludedFiles()) {
        File inc=new File(dir,name);
        File pf=inc.getParentFile();
        Properties links=new Properties();
        try (InputStream is=new BufferedInputStream(Files.newInputStream(inc.toPath()))){
          links.load(is);
          pf=pf.getCanonicalFile();
        }
 catch (        FileNotFoundException fnfe) {
          handleError("Unable to find " + name + "; skipping it.");
          continue;
        }
catch (        IOException ioe) {
          handleError("Unable to open " + name + " or its parent dir; skipping it.");
          continue;
        }
        try {
          links.store(new PrintStream(new LogOutputStream(this,Project.MSG_INFO)),"listing properties");
        }
 catch (        IOException ex) {
          log("failed to log unshortened properties");
          links.list(new PrintStream(new LogOutputStream(this,Project.MSG_INFO)));
        }
        for (        String key : links.stringPropertyNames()) {
          finalList.put(new File(pf,key).getAbsolutePath(),links.getProperty(key));
        }
      }
    }
    return finalList;
  }
  private static void deleteSymLink(  final Path path) throws IOException {
    final boolean deleted=path.toFile().delete();
    if (!deleted) {
      throw new IOException("Could not delete symlink at " + path);
    }
  }
}
