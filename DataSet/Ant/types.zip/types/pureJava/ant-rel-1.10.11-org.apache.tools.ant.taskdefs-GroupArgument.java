/** 
 * A class corresponding to the group nested element.
 */
public class GroupArgument {
  private Html title;
  private final List<PackageName> packages=new Vector<>();
  /** 
 * Set the title attribute using a string.
 * @param src a <code>String</code> value
 */
  public void setTitle(  final String src){
    final Html h=new Html();
    h.addText(src);
    addTitle(h);
  }
  /** 
 * Set the title attribute using a nested Html value.
 * @param text a <code>Html</code> value
 */
  public void addTitle(  final Html text){
    title=text;
  }
  /** 
 * Get the title.
 * @return the title
 */
  public String getTitle(){
    return title != null ? title.getText() : null;
  }
  /** 
 * Set the packages to Javadoc on.
 * @param src a comma separated list of packages
 */
  public void setPackages(  final String src){
    final StringTokenizer tok=new StringTokenizer(src,",");
    while (tok.hasMoreTokens()) {
      final String p=tok.nextToken();
      final PackageName pn=new PackageName();
      pn.setName(p);
      addPackage(pn);
    }
  }
  /** 
 * Add a package nested element.
 * @param pn a nested element specifying the package.
 */
  public void addPackage(  final PackageName pn){
    packages.add(pn);
  }
  /** 
 * Get the packages as a colon separated list.
 * @return the packages as a string
 */
  public String getPackages(){
    return packages.stream().map(Object::toString).collect(Collectors.joining(":"));
  }
}
