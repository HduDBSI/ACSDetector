/** 
 * Print summary enumeration values.
 */
public static class SummaryAttribute extends EnumeratedAttribute {
  public String[] getValues(){
    return new String[]{"true","yes","false","no","on","off","withOutAndErr"};
  }
  public boolean asBoolean(){
    return "true".equals(value) || "on".equals(value) || "yes".equals(value)|| "withOutAndErr".equals(value);
  }
}
