/** 
 * Individual filter component of filterset.
 */
public static class Filter {
  /** 
 * Token which will be replaced in the filter operation. 
 */
  String token;
  /** 
 * The value which will replace the token in the filtering operation. 
 */
  String value;
  /** 
 * Constructor for the Filter object.
 * @param token  The token which will be replaced when filtering.
 * @param value  The value which will replace the token when filtering.
 */
  public Filter(  String token,  String value){
    setToken(token);
    setValue(value);
  }
  /** 
 * No-argument conmstructor.
 */
  public Filter(){
  }
  /** 
 * Sets the Token attribute of the Filter object.
 * @param token  The new Token value.
 */
  public void setToken(  String token){
    this.token=token;
  }
  /** 
 * Sets the Value attribute of the Filter object.
 * @param value  The new Value value.
 */
  public void setValue(  String value){
    this.value=value;
  }
  /** 
 * Gets the Token attribute of the Filter object.
 * @return   The Token value.
 */
  public String getToken(){
    return token;
  }
  /** 
 * Gets the Value attribute of the Filter object.
 * @return   The Value value.
 */
  public String getValue(){
    return value;
  }
}
