/** 
 * Internal interface used to storing nested elements. Not documented  in detail for reasons of source code readability.
 */
private interface NestedStorer {
  void store(  Object parent,  Object child) throws InvocationTargetException, IllegalAccessException, InstantiationException ;
}
