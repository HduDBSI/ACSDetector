/** 
 * Load a file's contents as Ant properties.
 * @since Ant 1.5
 * @ant.task category="utility"
 */
public class LoadProperties extends Task {
  /** 
 * Source file
 */
  private File srcFile=null;
  /** 
 * Resource
 */
  private String resource=null;
  /** 
 * Classpath
 */
  private Path classpath=null;
  /** 
 * Holds filterchains
 */
  private final Vector filterChains=new Vector();
  /** 
 * Encoding to use for input; defaults to the platform's default encoding.
 */
  private String encoding=null;
  /** 
 * Set the file to load.
 * @param srcFile The new SrcFile value
 */
  public final void setSrcFile(  final File srcFile){
    this.srcFile=srcFile;
  }
  /** 
 * Set the resource name of a property file to load.
 * @param resource resource on classpath
 */
  public void setResource(  String resource){
    this.resource=resource;
  }
  /** 
 * Encoding to use for input, defaults to the platform's default encoding. <p> For a list of possible values see <a href="http://java.sun.com/products/jdk/1.2/docs/guide/internat/encoding.doc.html"> http://java.sun.com/products/jdk/1.2/docs/guide/internat/encoding.doc.html </a>.</p>
 * @param encoding The new Encoding value
 */
  public final void setEncoding(  final String encoding){
    this.encoding=encoding;
  }
  /** 
 * Set the classpath to use when looking up a resource.
 * @param classpath to add to any existing classpath
 */
  public void setClasspath(  Path classpath){
    if (this.classpath == null) {
      this.classpath=classpath;
    }
 else {
      this.classpath.append(classpath);
    }
  }
  /** 
 * Add a classpath to use when looking up a resource.
 * @return The classpath to be configured
 */
  public Path createClasspath(){
    if (this.classpath == null) {
      this.classpath=new Path(getProject());
    }
    return this.classpath.createPath();
  }
  /** 
 * Set the classpath to use when looking up a resource, given as reference to a &lt;path&gt; defined elsewhere
 * @param r The reference value
 */
  public void setClasspathRef(  Reference r){
    createClasspath().setRefid(r);
  }
  /** 
 * get the classpath used by this <CODE>LoadProperties</CODE>.
 * @return The classpath
 */
  public Path getClasspath(){
    return classpath;
  }
  /** 
 * load Ant properties from the source file or resource
 * @exception BuildException if something goes wrong with the build
 */
  public final void execute() throws BuildException {
    if (srcFile == null && resource == null) {
      throw new BuildException("One of \"srcfile\" or \"resource\" is required.");
    }
    BufferedInputStream bis=null;
    if (srcFile != null) {
      if (!srcFile.exists()) {
        throw new BuildException("Source file does not exist.");
      }
      if (!srcFile.isFile()) {
        throw new BuildException("Source file is not a file.");
      }
      try {
        bis=new BufferedInputStream(new FileInputStream(srcFile));
      }
 catch (      IOException eyeOhEx) {
        throw new BuildException(eyeOhEx);
      }
    }
 else {
      ClassLoader cL=(classpath != null) ? getProject().createClassLoader(classpath) : LoadProperties.class.getClassLoader();
      InputStream is=(cL == null) ? ClassLoader.getSystemResourceAsStream(resource) : cL.getResourceAsStream(resource);
      if (is != null) {
        bis=new BufferedInputStream(is);
      }
 else {
        log("Unable to find resource " + resource,Project.MSG_WARN);
        return;
      }
    }
    Reader instream=null;
    ByteArrayInputStream tis=null;
    try {
      if (encoding == null) {
        instream=new InputStreamReader(bis);
      }
 else {
        instream=new InputStreamReader(bis,encoding);
      }
      ChainReaderHelper crh=new ChainReaderHelper();
      crh.setPrimaryReader(instream);
      crh.setFilterChains(filterChains);
      crh.setProject(getProject());
      instream=crh.getAssembledReader();
      String text=crh.readFully(instream);
      if (text != null) {
        if (!text.endsWith("\n")) {
          text=text + "\n";
        }
        if (encoding == null) {
          tis=new ByteArrayInputStream(text.getBytes());
        }
 else {
          tis=new ByteArrayInputStream(text.getBytes(encoding));
        }
        final Properties props=new Properties();
        props.load(tis);
        Property propertyTask=(Property)getProject().createTask("property");
        propertyTask.setTaskName(getTaskName());
        propertyTask.addProperties(props);
      }
    }
 catch (    final IOException ioe) {
      final String message="Unable to load file: " + ioe.toString();
      throw new BuildException(message,ioe,getLocation());
    }
catch (    final BuildException be) {
      throw be;
    }
 finally {
      try {
        if (bis != null) {
          bis.close();
        }
      }
 catch (      IOException ioex) {
      }
      try {
        if (tis != null) {
          tis.close();
        }
      }
 catch (      IOException ioex) {
      }
    }
  }
  /** 
 * Adds a FilterChain.
 * @param filter the filter to add
 */
  public final void addFilterChain(  FilterChain filter){
    filterChains.addElement(filter);
  }
}
