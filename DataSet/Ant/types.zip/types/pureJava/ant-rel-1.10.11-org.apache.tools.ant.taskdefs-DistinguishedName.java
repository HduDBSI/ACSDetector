/** 
 * A class corresponding to the dname nested element.
 */
public static class DistinguishedName {
  private List<DnameParam> params=new Vector<>();
  /** 
 * Create a param nested element.
 * @return a DnameParam object to be configured.
 */
  public Object createParam(){
    DnameParam param=new DnameParam();
    params.add(param);
    return param;
  }
  /** 
 * Get the nested parameters.
 * @return an enumeration of the nested parameters.
 */
  public Enumeration<DnameParam> getParams(){
    return Collections.enumeration(params);
  }
  /** 
 * Generate a string rep of this distinguished name. The format is each of the parameters (name = value) separated by ','. This is used on the command line.
 * @return a string rep of this name
 */
  @Override public String toString(){
    return params.stream().map(p -> encode(p.getName()) + "=" + encode(p.getValue())).collect(Collectors.joining(", "));
  }
  /** 
 * Encode a name or value. The encoded result is the same as the input string except that each ',' is replaced by a '\,'.
 * @param string the value to be encoded
 * @return the encoded value.
 */
  public String encode(  final String string){
    return String.join("\\,",string.split(","));
  }
}
