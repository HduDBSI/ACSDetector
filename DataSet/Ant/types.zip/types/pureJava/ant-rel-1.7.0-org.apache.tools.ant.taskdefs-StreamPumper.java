class StreamPumper extends Thread {
  private BufferedReader din;
  private int messageLevel;
  private boolean endOfStream=false;
  private static final int SLEEP_TIME=5;
  public StreamPumper(  InputStream is,  int messageLevel){
    this.din=new BufferedReader(new InputStreamReader(is));
    this.messageLevel=messageLevel;
  }
  public void pumpStream() throws IOException {
    if (!endOfStream) {
      String line=din.readLine();
      if (line != null) {
        outputLog(line,messageLevel);
      }
 else {
        endOfStream=true;
      }
    }
  }
  public void run(){
    try {
      try {
        while (!endOfStream) {
          pumpStream();
          sleep(SLEEP_TIME);
        }
      }
 catch (      InterruptedException ie) {
      }
      din.close();
    }
 catch (    IOException ioe) {
    }
  }
}
