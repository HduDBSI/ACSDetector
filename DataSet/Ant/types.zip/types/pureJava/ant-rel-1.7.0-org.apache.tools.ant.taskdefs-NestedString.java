/** 
 * An inline string to use as the replacement text.
 */
public class NestedString {
  private StringBuffer buf=new StringBuffer();
  /** 
 * The text of the element.
 * @param val the string to add
 */
  public void addText(  String val){
    buf.append(val);
  }
  /** 
 * @return the text
 */
  public String getText(){
    return buf.toString();
  }
}
