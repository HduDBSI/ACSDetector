/** 
 * Contains the definition of a new transaction element. Transactions allow several files or blocks of statements to be executed using the same JDBC connection and commit operation in between.
 */
public class Transaction {
  private Resource tSrcResource=null;
  private String tSqlCommand="";
  /** 
 * Set the source file attribute.
 * @param src the source file
 */
  public void setSrc(  File src){
    if (src != null) {
      setSrcResource(new FileResource(src));
    }
  }
  /** 
 * Set the source resource attribute.
 * @param src the source file
 * @since Ant 1.7
 */
  public void setSrcResource(  Resource src){
    if (tSrcResource != null) {
      throw new BuildException("only one resource per transaction");
    }
    tSrcResource=src;
  }
  /** 
 * Set inline text
 * @param sql the inline text
 */
  public void addText(  String sql){
    if (sql != null) {
      if (getExpandProperties()) {
        sql=getProject().replaceProperties(sql);
      }
      this.tSqlCommand+=sql;
    }
  }
  /** 
 * Set the source resource.
 * @param a the source resource collection.
 * @since Ant 1.7
 */
  public void addConfigured(  ResourceCollection a){
    if (a.size() != 1) {
      throw new BuildException("only single argument resource " + "collections are supported.");
    }
    setSrcResource((Resource)a.iterator().next());
  }
  /** 
 */
  private void runTransaction(  PrintStream out) throws IOException, SQLException {
    if (tSqlCommand.length() != 0) {
      log("Executing commands",Project.MSG_INFO);
      runStatements(new StringReader(tSqlCommand),out);
    }
    if (tSrcResource != null) {
      log("Executing resource: " + tSrcResource.toString(),Project.MSG_INFO);
      InputStream is=null;
      Reader reader=null;
      try {
        is=tSrcResource.getInputStream();
        reader=(encoding == null) ? new InputStreamReader(is) : new InputStreamReader(is,encoding);
        runStatements(reader,out);
      }
  finally {
        FileUtils.close(is);
        FileUtils.close(reader);
      }
    }
  }
}
