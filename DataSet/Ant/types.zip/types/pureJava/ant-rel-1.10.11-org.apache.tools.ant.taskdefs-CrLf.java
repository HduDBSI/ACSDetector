/** 
 * Enumerated attribute with the values "asis", "cr", "lf", "crlf", "mac", "unix" and "dos.
 */
public static class CrLf extends EnumeratedAttribute {
  /** 
 * @see EnumeratedAttribute#getValues {@inheritDoc}.
 */
  @Override public String[] getValues(){
    return new String[]{"asis","cr","lf","crlf","mac","unix","dos"};
  }
}
