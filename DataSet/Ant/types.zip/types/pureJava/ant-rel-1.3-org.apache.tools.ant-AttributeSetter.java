private interface AttributeSetter {
  public void set(  Project p,  Object parent,  String value) throws InvocationTargetException, IllegalAccessException, BuildException ;
}
