/** 
 * This inner class represents an EJB that will be compiled using ejbc.
 */
private class EjbInfo {
  private String name;
  private Classname home;
  private Classname remote;
  private Classname implementation;
  private Classname primaryKey;
  private String beantype="entity";
  private boolean cmp=false;
  private boolean iiop=false;
  private boolean hasession=false;
  private List cmpDescriptors=new ArrayList();
  /** 
 * Construct a new EJBInfo object with the given name.
 * @param name The display name for the EJB.
 */
  public EjbInfo(  String name){
    this.name=name;
  }
  /** 
 * Returns the display name of the EJB.  If a display name has not been set, it returns the EJB implementation classname (if the implementation class is not set, it returns "[unnamed]").
 * @return The display name for the EJB.
 */
  public String getName(){
    if (name == null) {
      if (implementation == null) {
        return "[unnamed]";
      }
 else {
        return implementation.getClassName();
      }
    }
    return name;
  }
  public void setHome(  String home){
    setHome(new Classname(home));
  }
  public void setHome(  Classname home){
    this.home=home;
  }
  public Classname getHome(){
    return home;
  }
  public void setRemote(  String remote){
    setRemote(new Classname(remote));
  }
  public void setRemote(  Classname remote){
    this.remote=remote;
  }
  public Classname getRemote(){
    return remote;
  }
  public void setImplementation(  String implementation){
    setImplementation(new Classname(implementation));
  }
  public void setImplementation(  Classname implementation){
    this.implementation=implementation;
  }
  public Classname getImplementation(){
    return implementation;
  }
  public void setPrimaryKey(  String primaryKey){
    setPrimaryKey(new Classname(primaryKey));
  }
  public void setPrimaryKey(  Classname primaryKey){
    this.primaryKey=primaryKey;
  }
  public Classname getPrimaryKey(){
    return primaryKey;
  }
  public void setBeantype(  String beantype){
    this.beantype=beantype.toLowerCase();
  }
  public String getBeantype(){
    return beantype;
  }
  public void setCmp(  boolean cmp){
    this.cmp=cmp;
  }
  public void setCmp(  String cmp){
    setCmp(cmp.equals("Container"));
  }
  public boolean getCmp(){
    return cmp;
  }
  public void setIiop(  boolean iiop){
    this.iiop=iiop;
  }
  public void setIiop(  String iiop){
    setIiop(iiop.equals("true"));
  }
  public boolean getIiop(){
    return iiop;
  }
  public void setHasession(  boolean hasession){
    this.hasession=hasession;
  }
  public void setHasession(  String hasession){
    setHasession(hasession.equals("true"));
  }
  public boolean getHasession(){
    return hasession;
  }
  public void addCmpDescriptor(  String descriptor){
    cmpDescriptors.add(descriptor);
  }
  public List getCmpDescriptors(){
    return cmpDescriptors;
  }
  /** 
 * Verifies that the EJB is valid--if it is invalid, an exception is thrown
 * @param buildDir The directory where the EJB remote interface, homeinterface, and implementation class must be found.
 * @throws EjbcException If the EJB is invalid.
 */
  private void checkConfiguration(  File buildDir) throws EjbcException {
    if (home == null) {
      throw new EjbcException("A home interface was not found " + "for the " + name + " EJB.");
    }
    if (remote == null) {
      throw new EjbcException("A remote interface was not found " + "for the " + name + " EJB.");
    }
    if (implementation == null) {
      throw new EjbcException("An EJB implementation class was not " + "found for the " + name + " EJB.");
    }
    if ((!beantype.equals(ENTITY_BEAN)) && (!beantype.equals(STATELESS_SESSION)) && (!beantype.equals(STATEFUL_SESSION))) {
      throw new EjbcException("The beantype found (" + beantype + ") "+ "isn't valid in the "+ name+ " EJB.");
    }
    if (cmp && (!beantype.equals(ENTITY_BEAN))) {
      System.out.println("CMP stubs and skeletons may not be generated" + " for a Session Bean -- the \"cmp\" attribute will be" + " ignoredfor the " + name + " EJB.");
    }
    if (hasession && (!beantype.equals(STATEFUL_SESSION))) {
      System.out.println("Highly available stubs and skeletons may " + "only be generated for a Stateful Session Bean -- the " + "\"hasession\" attribute will be ignored for the " + name + " EJB.");
    }
    if (!remote.getClassFile(buildDir).exists()) {
      throw new EjbcException("The remote interface " + remote.getQualifiedClassName() + " could not be "+ "found.");
    }
    if (!home.getClassFile(buildDir).exists()) {
      throw new EjbcException("The home interface " + home.getQualifiedClassName() + " could not be "+ "found.");
    }
    if (!implementation.getClassFile(buildDir).exists()) {
      throw new EjbcException("The EJB implementation class " + implementation.getQualifiedClassName() + " could "+ "not be found.");
    }
  }
  /** 
 * Determines if the ejbc utility needs to be run or not.  If the stubs and skeletons can all be found in the destination directory AND all of their timestamps are more recent than the EJB source classes (home, remote, and implementation classes), the method returns <code>false</code>.  Otherwise, the method returns <code>true</code>.
 * @param destDir The directory where the EJB source classes, stubs andskeletons are located.
 * @return A boolean indicating whether or not the ejbc utility needs tobe run to bring the stubs and skeletons up to date.
 */
  public boolean mustBeRecompiled(  File destDir){
    long sourceModified=sourceClassesModified(destDir);
    long destModified=destClassesModified(destDir);
    return (destModified < sourceModified);
  }
  /** 
 * Examines each of the EJB source classes (home, remote, and implementation) and returns the modification timestamp for the "oldest" class.
 * @param classpath The classpath to be used to find the source EJBclasses.  If <code>null</code>, the system classpath is used.
 * @return The modification timestamp for the "oldest" EJB source class.
 * @throws BuildException If one of the EJB source classes cannot befound on the classpath.
 */
  private long sourceClassesModified(  File buildDir){
    long latestModified;
    long modified;
    File remoteFile;
    File homeFile;
    File implFile;
    File pkFile;
    remoteFile=remote.getClassFile(buildDir);
    modified=remoteFile.lastModified();
    if (modified == -1) {
      System.out.println("The class " + remote.getQualifiedClassName() + " couldn't "+ "be found on the classpath");
      return -1;
    }
    latestModified=modified;
    homeFile=home.getClassFile(buildDir);
    modified=homeFile.lastModified();
    if (modified == -1) {
      System.out.println("The class " + home.getQualifiedClassName() + " couldn't be "+ "found on the classpath");
      return -1;
    }
    latestModified=Math.max(latestModified,modified);
    if (primaryKey != null) {
      pkFile=primaryKey.getClassFile(buildDir);
      modified=pkFile.lastModified();
      if (modified == -1) {
        System.out.println("The class " + primaryKey.getQualifiedClassName() + "couldn't be "+ "found on the classpath");
        return -1;
      }
      latestModified=Math.max(latestModified,modified);
    }
 else {
      pkFile=null;
    }
    implFile=implementation.getClassFile(buildDir);
    modified=implFile.lastModified();
    if (modified == -1) {
      System.out.println("The class " + implementation.getQualifiedClassName() + " couldn't be found on the classpath");
      return -1;
    }
    String pathToFile=remote.getQualifiedClassName();
    pathToFile=pathToFile.replace('.',File.separatorChar) + ".class";
    ejbFiles.put(pathToFile,remoteFile);
    pathToFile=home.getQualifiedClassName();
    pathToFile=pathToFile.replace('.',File.separatorChar) + ".class";
    ejbFiles.put(pathToFile,homeFile);
    pathToFile=implementation.getQualifiedClassName();
    pathToFile=pathToFile.replace('.',File.separatorChar) + ".class";
    ejbFiles.put(pathToFile,implFile);
    if (pkFile != null) {
      pathToFile=primaryKey.getQualifiedClassName();
      pathToFile=pathToFile.replace('.',File.separatorChar) + ".class";
      ejbFiles.put(pathToFile,pkFile);
    }
    return latestModified;
  }
  /** 
 * Examines each of the EJB stubs and skeletons in the destination directory and returns the modification timestamp for the "oldest" class. If one of the stubs or skeletons cannot be found, <code>-1 </code> is returned.
 * @param dest The directory in which the EJB stubs and skeletons arestored.
 * @return The modification timestamp for the "oldest" EJB stub orskeleton.  If one of the classes cannot be found, <code>-1 </code> is returned.
 * @throws BuildException If the canonical path of the destinationdirectory cannot be found.
 */
  private long destClassesModified(  File destDir){
    String[] classnames=classesToGenerate();
    long destClassesModified=new Date().getTime();
    boolean allClassesFound=true;
    for (int i=0; i < classnames.length; i++) {
      String pathToClass=classnames[i].replace('.',File.separatorChar) + ".class";
      File classFile=new File(destDir,pathToClass);
      ejbFiles.put(pathToClass,classFile);
      allClassesFound=allClassesFound && classFile.exists();
      if (allClassesFound) {
        long fileMod=classFile.lastModified();
        destClassesModified=Math.min(destClassesModified,fileMod);
      }
    }
    return (allClassesFound) ? destClassesModified : -1;
  }
  /** 
 * Builds an array of class names which represent the stubs and skeletons which need to be generated for a given EJB.  The class names are fully qualified.  Nine classes are generated for all EJBs while an additional six classes are generated for beans requiring RMI/IIOP access.
 * @return An array of Strings representing the fully-qualified classnames for the stubs and skeletons to be generated.
 */
  private String[] classesToGenerate(){
    String[] classnames=(iiop) ? new String[NUM_CLASSES_WITH_IIOP] : new String[NUM_CLASSES_WITHOUT_IIOP];
    final String remotePkg=remote.getPackageName() + ".";
    final String remoteClass=remote.getClassName();
    final String homePkg=home.getPackageName() + ".";
    final String homeClass=home.getClassName();
    final String implPkg=implementation.getPackageName() + ".";
    final String implFullClass=implementation.getQualifiedWithUnderscores();
    int index=0;
    classnames[index++]=implPkg + "ejb_fac_" + implFullClass;
    classnames[index++]=implPkg + "ejb_home_" + implFullClass;
    classnames[index++]=implPkg + "ejb_skel_" + implFullClass;
    classnames[index++]=remotePkg + "ejb_kcp_skel_" + remoteClass;
    classnames[index++]=homePkg + "ejb_kcp_skel_" + homeClass;
    classnames[index++]=remotePkg + "ejb_kcp_stub_" + remoteClass;
    classnames[index++]=homePkg + "ejb_kcp_stub_" + homeClass;
    classnames[index++]=remotePkg + "ejb_stub_" + remoteClass;
    classnames[index++]=homePkg + "ejb_stub_" + homeClass;
    if (!iiop) {
      return classnames;
    }
    classnames[index++]="org.omg.stub." + remotePkg + "_"+ remoteClass+ "_Stub";
    classnames[index++]="org.omg.stub." + homePkg + "_"+ homeClass+ "_Stub";
    classnames[index++]="org.omg.stub." + remotePkg + "_ejb_RmiCorbaBridge_"+ remoteClass+ "_Tie";
    classnames[index++]="org.omg.stub." + homePkg + "_ejb_RmiCorbaBridge_"+ homeClass+ "_Tie";
    classnames[index++]=remotePkg + "ejb_RmiCorbaBridge_" + remoteClass;
    classnames[index++]=homePkg + "ejb_RmiCorbaBridge_" + homeClass;
    return classnames;
  }
  /** 
 * Convenience method which creates a String representation of all the instance variables of an EjbInfo object.
 * @return A String representing the EjbInfo instance.
 */
  public String toString(){
    String s="EJB name: " + name + "\n\r              home:      "+ home+ "\n\r              remote:    "+ remote+ "\n\r              impl:      "+ implementation+ "\n\r              primaryKey: "+ primaryKey+ "\n\r              beantype:  "+ beantype+ "\n\r              cmp:       "+ cmp+ "\n\r              iiop:      "+ iiop+ "\n\r              hasession: "+ hasession;
    Iterator i=cmpDescriptors.iterator();
    while (i.hasNext()) {
      s+="\n\r              CMP Descriptor: " + i.next();
    }
    return s;
  }
}
