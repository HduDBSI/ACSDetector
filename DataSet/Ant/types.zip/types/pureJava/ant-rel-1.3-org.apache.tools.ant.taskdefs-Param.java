public class Param {
  private String name=null;
  private String expression=null;
  public void setName(  String name){
    this.name=name;
  }
  public void setExpression(  String expression){
    this.expression=expression;
  }
  public String getName() throws BuildException {
    if (name == null)     throw new BuildException("Name attribute is missing.");
    return name;
  }
  public String getExpression() throws BuildException {
    if (expression == null)     throw new BuildException("Expression attribute is missing.");
    return expression;
  }
}
