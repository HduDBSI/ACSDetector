/** 
 * A class to be extended by any BuildAlert's that require the output of sound.
 */
public class BuildAlert {
  private File source=null;
  private int loops=0;
  private Long duration=null;
  /** 
 * Sets the duration in milliseconds the file should be played.
 */
  public void setDuration(  Long duration){
    this.duration=duration;
  }
  /** 
 * Sets the location of the file to get the audio.
 * @param source the name a sound-file directory or of the audio file
 */
  public void setSource(  File source){
    this.source=source;
  }
  /** 
 * Sets the number of times the source file should be played.
 * @param loops the number of loops to play the source file
 */
  public void setLoops(  int loops){
    this.loops=loops;
  }
  /** 
 * Gets the location of the file to get the audio.
 */
  public File getSource(){
    File nofile=null;
    if (source.exists()) {
      if (source.isDirectory()) {
        File[] files=source.listFiles();
        int numfiles=files.length;
        Random rn=new Random();
        int i=rn.nextInt(numfiles);
        this.source=files[i];
      }
    }
 else {
      log(source + ": invalid path.",Project.MSG_WARN);
      this.source=nofile;
    }
    return this.source;
  }
  /** 
 * Sets the number of times the source file should be played.
 * @return the number of loops to play the source file
 */
  public int getLoops(){
    return this.loops;
  }
  /** 
 * Gets the duration in milliseconds the file should be played.
 */
  public Long getDuration(){
    return this.duration;
  }
}
