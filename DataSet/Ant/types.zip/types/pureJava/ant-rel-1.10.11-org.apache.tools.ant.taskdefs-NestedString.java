/** 
 * An inline string to use as the replacement text.
 */
public class NestedString {
  private boolean expandProperties=false;
  private StringBuffer buf=new StringBuffer();
  /** 
 * Whether properties should be expanded in nested test. <p>If you use this class via its Java interface the text you add via  {@link #addText addText} has most likely beenexpanded already so you do <b>not</b> want to set this to true.</p>
 * @param b boolean
 * @since Ant 1.8.0
 */
  public void setExpandProperties(  boolean b){
    expandProperties=b;
  }
  /** 
 * The text of the element.
 * @param val the string to add
 */
  public void addText(  String val){
    buf.append(val);
  }
  /** 
 * @return the text
 */
  public String getText(){
    String s=buf.toString();
    return expandProperties ? getProject().replaceProperties(s) : s;
  }
}
