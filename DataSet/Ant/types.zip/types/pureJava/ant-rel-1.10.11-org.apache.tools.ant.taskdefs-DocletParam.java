/** 
 * Inner class used to manage doclet parameters.
 */
public class DocletParam {
  /** 
 * The parameter name 
 */
  private String name;
  /** 
 * The parameter value 
 */
  private String value;
  /** 
 * Set the name of the parameter.
 * @param name the name of the doclet parameter
 */
  public void setName(  final String name){
    this.name=name;
  }
  /** 
 * Get the parameter name.
 * @return the parameter's name.
 */
  public String getName(){
    return name;
  }
  /** 
 * Set the parameter value. Note that only string values are supported. No resolution of file paths is performed.
 * @param value the parameter value.
 */
  public void setValue(  final String value){
    this.value=value;
  }
  /** 
 * Get the parameter value.
 * @return the parameter value.
 */
  public String getValue(){
    return value;
  }
}
