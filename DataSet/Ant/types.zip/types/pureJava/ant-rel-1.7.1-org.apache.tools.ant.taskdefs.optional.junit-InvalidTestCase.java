public static class InvalidTestCase extends TestCase {
  public InvalidTestCase(  String name){
    super(name);
    throw new NullPointerException("thrown on purpose");
  }
}
