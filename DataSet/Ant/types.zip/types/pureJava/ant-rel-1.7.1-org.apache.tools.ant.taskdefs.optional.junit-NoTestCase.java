public static class NoTestCase {
}
