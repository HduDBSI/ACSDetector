/** 
 * This internal BuildLogger, to be honest, is just a BuildListener. It does nearly the same as the DefaultLogger, but uses the Loggin-Window for output.
 */
private class VAJBuildLogger implements BuildListener {
  private long startTime=System.currentTimeMillis();
  /** 
 * VAJBuildLogger constructor comment.
 */
  public VAJBuildLogger(){
    super();
  }
  /** 
 * Fired after the last target has finished. This event will still be thrown if an error occured during the build.
 * @see BuildEvent#getException()
 */
  public void buildFinished(  BuildEvent event){
    getStopButton().setEnabled(false);
    getBuildButton().setEnabled(true);
    getBuildButton().requestFocus();
    Throwable error=event.getException();
    if (error == null) {
      getMessageTextArea().append(lineSeparator + "BUILD SUCCESSFUL");
    }
 else {
      logException(error);
    }
    getMessageTextArea().append(lineSeparator + "Total time: " + DateUtils.formatElapsedTime(System.currentTimeMillis() - startTime));
  }
  /** 
 * Outputs an exception.
 */
  public void logException(  Throwable error){
    getMessageTextArea().append(lineSeparator + "BUILD FAILED" + lineSeparator);
    if (error instanceof BuildException) {
      getMessageTextArea().append(error.toString());
      Throwable nested=((BuildException)error).getException();
      if (nested != null) {
        nested.printStackTrace(System.err);
      }
    }
 else {
      error.printStackTrace(System.err);
    }
  }
  /** 
 * Fired before any targets are started.
 */
  public void buildStarted(  BuildEvent event){
    getStopButton().setEnabled(true);
    getBuildButton().setEnabled(false);
    getStopButton().requestFocus();
    startTime=System.currentTimeMillis();
    getMessageTextArea().append(lineSeparator);
  }
  /** 
 * Fired whenever a message is logged.
 * @see BuildEvent#getMessage()
 * @see BuildEvent#getPriority()
 */
  public void messageLogged(  BuildEvent event){
    if (event.getPriority() <= getBuildInfo().getOutputMessageLevel()) {
      String msg="";
      if (event.getTask() != null) {
        msg="[" + event.getTask().getTaskName() + "] ";
      }
      getMessageTextArea().append(lineSeparator + msg + event.getMessage());
    }
  }
  /** 
 * Fired when a target has finished. This event will still be thrown if an error occured during the build.
 * @see BuildEvent#getException()
 */
  public void targetFinished(  BuildEvent event){
  }
  /** 
 * Fired when a target is started.
 * @see BuildEvent#getTarget()
 */
  public void targetStarted(  BuildEvent event){
    if (getBuildInfo().getOutputMessageLevel() <= Project.MSG_INFO) {
      getMessageTextArea().append(lineSeparator + event.getTarget().getName() + ":");
    }
  }
  /** 
 * Fired when a task has finished. This event will still be throw if an error occured during the build.
 * @see BuildEvent#getException()
 */
  public void taskFinished(  BuildEvent event){
  }
  /** 
 * Fired when a task is started.
 * @see BuildEvent#getTask()
 */
  public void taskStarted(  BuildEvent event){
  }
}
