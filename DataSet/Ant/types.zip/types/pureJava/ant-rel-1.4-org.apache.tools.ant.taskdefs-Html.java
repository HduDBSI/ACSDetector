public static class Html {
  private StringBuffer text=new StringBuffer();
  public void addText(  String t){
    text.append(t);
  }
  public String getText(){
    return text.toString();
  }
}
