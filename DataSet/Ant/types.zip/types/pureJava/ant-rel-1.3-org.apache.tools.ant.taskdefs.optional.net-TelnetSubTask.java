/** 
 * This class is the parent of the Read and Write tasks. It handles the common attributes for both.
 */
public class TelnetSubTask {
  protected String taskString="";
  public void execute(  AntTelnetClient telnet) throws BuildException {
    throw new BuildException("Shouldn't be able instantiate a SubTask directly");
  }
  public void addText(  String s){
    setString(s);
  }
  public void setString(  String s){
    taskString+=s;
  }
}
