public class NestedString {
  private StringBuffer buf=new StringBuffer();
  public void addText(  String val){
    buf.append(val);
  }
  public String getText(){
    return buf.toString();
  }
}
