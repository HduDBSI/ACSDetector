/** 
 * A manifest section - you can nest attribute elements into sections. A section consists of a set of attribute values, separated from other sections by a blank line.
 */
public static class Section {
  /** 
 * Warnings for this section 
 */
  private Vector warnings=new Vector();
  /** 
 * The section's name if any. The main section in a manifest is unnamed.
 */
  private String name=null;
  /** 
 * The section's attributes.
 */
  private Hashtable attributes=new Hashtable();
  /** 
 * Index used to retain the attribute ordering 
 */
  private Vector attributeIndex=new Vector();
  /** 
 * The name of the section; optional -default is the main section.
 * @param name the section's name
 */
  public void setName(  String name){
    this.name=name;
  }
  /** 
 * Get the Section's name.
 * @return the section's name.
 */
  public String getName(){
    return name;
  }
  /** 
 * Read a section through a reader.
 * @param reader the reader from which the section is read
 * @return the name of the next section if it has been read aspart of this section - This only happens if the Manifest is malformed.
 * @throws ManifestException if the section is not valid accordingto the JAR spec
 * @throws IOException if the section cannot be read from the reader.
 */
  public String read(  BufferedReader reader) throws ManifestException, IOException {
    Attribute attribute=null;
    while (true) {
      String line=reader.readLine();
      if (line == null || line.length() == 0) {
        return null;
      }
      if (line.charAt(0) == ' ') {
        if (attribute == null) {
          if (name != null) {
            name+=line.substring(1);
          }
 else {
            throw new ManifestException("Can't start an " + "attribute with a continuation line " + line);
          }
        }
 else {
          attribute.addContinuation(line);
        }
      }
 else {
        attribute=new Attribute(line);
        String nameReadAhead=addAttributeAndCheck(attribute);
        attribute=getAttribute(attribute.getKey());
        if (nameReadAhead != null) {
          return nameReadAhead;
        }
      }
    }
  }
  /** 
 * Merge in another section
 * @param section the section to be merged with this one.
 * @throws ManifestException if the sections cannot be merged.
 */
  public void merge(  Section section) throws ManifestException {
    if (name == null && section.getName() != null || name != null && !(name.equalsIgnoreCase(section.getName()))) {
      throw new ManifestException("Unable to merge sections " + "with different names");
    }
    Enumeration e=section.getAttributeKeys();
    Attribute classpathAttribute=null;
    while (e.hasMoreElements()) {
      String attributeName=(String)e.nextElement();
      Attribute attribute=section.getAttribute(attributeName);
      if (attributeName.equalsIgnoreCase(ATTRIBUTE_CLASSPATH)) {
        if (classpathAttribute == null) {
          classpathAttribute=new Attribute();
          classpathAttribute.setName(ATTRIBUTE_CLASSPATH);
        }
        Enumeration cpe=attribute.getValues();
        while (cpe.hasMoreElements()) {
          String value=(String)cpe.nextElement();
          classpathAttribute.addValue(value);
        }
      }
 else {
        storeAttribute(attribute);
      }
    }
    if (classpathAttribute != null) {
      storeAttribute(classpathAttribute);
    }
    Enumeration warnEnum=section.warnings.elements();
    while (warnEnum.hasMoreElements()) {
      warnings.addElement(warnEnum.nextElement());
    }
  }
  /** 
 * Write the section out to a print writer.
 * @param writer the Writer to which the section is written
 * @throws IOException if the section cannot be written
 */
  public void write(  PrintWriter writer) throws IOException {
    if (name != null) {
      Attribute nameAttr=new Attribute(ATTRIBUTE_NAME,name);
      nameAttr.write(writer);
    }
    Enumeration e=getAttributeKeys();
    while (e.hasMoreElements()) {
      String key=(String)e.nextElement();
      Attribute attribute=getAttribute(key);
      attribute.write(writer);
    }
    writer.print(EOL);
  }
  /** 
 * Get a attribute of the section
 * @param attributeName the name of the attribute
 * @return a Manifest.Attribute instance if the attribute issingle-valued, otherwise a Vector of Manifest.Attribute instances.
 */
  public Attribute getAttribute(  String attributeName){
    return (Attribute)attributes.get(attributeName.toLowerCase());
  }
  /** 
 * Get the attribute keys.
 * @return an Enumeration of Strings, each string being the lower casekey of an attribute of the section.
 */
  public Enumeration getAttributeKeys(){
    return attributeIndex.elements();
  }
  /** 
 * Get the value of the attribute with the name given.
 * @param attributeName the name of the attribute to be returned.
 * @return the attribute's value or null if the attribute does not existin the section
 */
  public String getAttributeValue(  String attributeName){
    Attribute attribute=getAttribute(attributeName.toLowerCase());
    if (attribute == null) {
      return null;
    }
    return attribute.getValue();
  }
  /** 
 * Remove the given attribute from the section
 * @param attributeName the name of the attribute to be removed.
 */
  public void removeAttribute(  String attributeName){
    String key=attributeName.toLowerCase();
    attributes.remove(key);
    attributeIndex.removeElement(key);
  }
  /** 
 * Add an attribute to the section.
 * @param attribute the attribute to be added to the section
 * @exception ManifestException if the attribute is not valid.
 */
  public void addConfiguredAttribute(  Attribute attribute) throws ManifestException {
    String check=addAttributeAndCheck(attribute);
    if (check != null) {
      throw new BuildException("Specify the section name using " + "the \"name\" attribute of the <section> element rather " + "than using a \"Name\" manifest attribute");
    }
  }
  /** 
 * Add an attribute to the section
 * @param attribute the attribute to be added.
 * @return the value of the attribute if it is a nameattribute - null other wise
 * @exception ManifestException if the attribute alreadyexists in this section.
 */
  public String addAttributeAndCheck(  Attribute attribute) throws ManifestException {
    if (attribute.getName() == null || attribute.getValue() == null) {
      throw new BuildException("Attributes must have name and value");
    }
    if (attribute.getKey().equalsIgnoreCase(ATTRIBUTE_NAME)) {
      warnings.addElement("\"" + ATTRIBUTE_NAME + "\" attributes "+ "should not occur in the main section and must be the "+ "first element in all other sections: \""+ attribute.getName()+ ": "+ attribute.getValue()+ "\"");
      return attribute.getValue();
    }
    if (attribute.getKey().startsWith(ATTRIBUTE_FROM.toLowerCase())) {
      warnings.addElement(ERROR_FROM_FORBIDDEN + attribute.getName() + ": "+ attribute.getValue()+ "\"");
    }
 else {
      String attributeKey=attribute.getKey();
      if (attributeKey.equalsIgnoreCase(ATTRIBUTE_CLASSPATH)) {
        Attribute classpathAttribute=(Attribute)attributes.get(attributeKey);
        if (classpathAttribute == null) {
          storeAttribute(attribute);
        }
 else {
          warnings.addElement("Multiple Class-Path attributes " + "are supported but violate the Jar " + "specification and may not be correctly "+ "processed in all environments");
          Enumeration e=attribute.getValues();
          while (e.hasMoreElements()) {
            String value=(String)e.nextElement();
            classpathAttribute.addValue(value);
          }
        }
      }
 else       if (attributes.containsKey(attributeKey)) {
        throw new ManifestException("The attribute \"" + attribute.getName() + "\" may not occur more "+ "than once in the same section");
      }
 else {
        storeAttribute(attribute);
      }
    }
    return null;
  }
  /** 
 * Clone this section
 * @return the cloned Section
 * @since Ant 1.5.2
 */
  public Object clone(){
    Section cloned=new Section();
    cloned.setName(name);
    Enumeration e=getAttributeKeys();
    while (e.hasMoreElements()) {
      String key=(String)e.nextElement();
      Attribute attribute=getAttribute(key);
      cloned.storeAttribute(new Attribute(attribute.getName(),attribute.getValue()));
    }
    return cloned;
  }
  /** 
 * Store an attribute and update the index.
 * @param attribute the attribute to be stored
 */
  private void storeAttribute(  Attribute attribute){
    if (attribute == null) {
      return;
    }
    String attributeKey=attribute.getKey();
    attributes.put(attributeKey,attribute);
    if (!attributeIndex.contains(attributeKey)) {
      attributeIndex.addElement(attributeKey);
    }
  }
  /** 
 * Get the warnings for this section.
 * @return an Enumeration of warning strings.
 */
  public Enumeration getWarnings(){
    return warnings.elements();
  }
  /** 
 * @see java.lang.Object#hashCode
 * @return a hash value based on the attributes.
 */
  public int hashCode(){
    return attributes.hashCode();
  }
  /** 
 * @see java.lang.Object#equals
 * @param rhs the object to check for equality.
 * @return true if the attributes are the same.
 */
  public boolean equals(  Object rhs){
    if (rhs == null || rhs.getClass() != getClass()) {
      return false;
    }
    if (rhs == this) {
      return true;
    }
    Section rhsSection=(Section)rhs;
    return attributes.equals(rhsSection.attributes);
  }
}
