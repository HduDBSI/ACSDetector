/** 
 * Prompts on System.err, reads input from System.in
 * @since Ant 1.5
 */
public class DefaultInputHandler implements InputHandler {
  /** 
 * Empty no-arg constructor
 */
  public DefaultInputHandler(){
  }
  /** 
 * Prompts and requests input.  May loop until a valid input has been entered.
 * @param request the request to handle
 * @throws BuildException if not possible to read from console
 */
  public void handleInput(  InputRequest request) throws BuildException {
    String prompt=getPrompt(request);
    BufferedReader r=null;
    boolean success=false;
    try {
      r=new BufferedReader(new InputStreamReader(getInputStream()));
      do {
        System.err.println(prompt);
        System.err.flush();
        try {
          String input=r.readLine();
          if (input == null) {
            throw new BuildException("unexpected end of stream while reading input");
          }
          request.setInput(input);
        }
 catch (        IOException e) {
          throw new BuildException("Failed to read input from" + " Console.",e);
        }
      }
 while (!request.isInputValid());
      success=true;
    }
  finally {
      if (r != null) {
        try {
          r.close();
        }
 catch (        IOException e) {
          if (success) {
            throw new BuildException("Failed to close input.",e);
          }
        }
      }
    }
  }
  /** 
 * Constructs user prompt from a request. <p>This implementation adds (choice1,choice2,choice3,...) to the prompt for <code>MultipleChoiceInputRequest</code>s.</p>
 * @param request the request to construct the prompt for.Must not be <code>null</code>.
 * @return the prompt to ask the user
 */
  protected String getPrompt(  InputRequest request){
    String prompt=request.getPrompt();
    String def=request.getDefaultValue();
    if (request instanceof MultipleChoiceInputRequest) {
      StringBuilder sb=new StringBuilder(prompt).append(" (");
      boolean first=true;
      for (      String next : ((MultipleChoiceInputRequest)request).getChoices()) {
        if (!first) {
          sb.append(", ");
        }
        if (next.equals(def)) {
          sb.append('[');
        }
        sb.append(next);
        if (next.equals(def)) {
          sb.append(']');
        }
        first=false;
      }
      sb.append(")");
      return sb.toString();
    }
 else     if (def != null) {
      return prompt + " [" + def+ "]";
    }
 else {
      return prompt;
    }
  }
  /** 
 * Returns the input stream from which the user input should be read.
 * @return the input stream from which the user input should be read.
 */
  protected InputStream getInputStream(){
    return KeepAliveInputStream.wrapSystemIn();
  }
}
