/** 
 * Filter interface to be applied when iterating over a DOM tree. Just think of it like a <code>FileFilter</code> clone.
 */
public interface NodeFilter {
  /** 
 * @param node    the node to check for acceptance.
 * @return      <code>true</code> if the node is accepted by this filter,otherwise <code>false</code>
 */
  boolean accept(  Node node);
}
