private static class ReverseDirs implements ResourceCollection {
  static final Comparator REVERSE=new Comparator(){
    public int compare(    Object foo,    Object bar){
      return ((Comparable)foo).compareTo(bar) * -1;
    }
  }
;
  private Project project;
  private File basedir;
  private String[] dirs;
  ReverseDirs(  Project project,  File basedir,  String[] dirs){
    this.project=project;
    this.basedir=basedir;
    this.dirs=dirs;
    Arrays.sort(this.dirs,REVERSE);
  }
  public Iterator iterator(){
    return new FileResourceIterator(project,basedir,dirs);
  }
  public boolean isFilesystemOnly(){
    return true;
  }
  public int size(){
    return dirs.length;
  }
}
