/** 
 * An enumeration of all resources of a given name found within the classpath of this class loader. This enumeration is used by the ClassLoader.findResources method, which is in turn used by the ClassLoader.getResources method.
 * @see AntClassLoader#findResources(String)
 * @see java.lang.ClassLoader#getResources(String)
 */
private class ResourceEnumeration implements Enumeration {
  /** 
 * The name of the resource being searched for.
 */
  private String resourceName;
  /** 
 * The index of the next classpath element to search.
 */
  private int pathElementsIndex;
  /** 
 * The URL of the next resource to return in the enumeration. If this field is <code>null</code> then the enumeration has been completed, i.e., there are no more elements to return.
 */
  private URL nextResource;
  /** 
 * Constructs a new enumeration of resources of the given name found within this class loader's classpath.
 * @param name the name of the resource to search for.
 */
  ResourceEnumeration(  String name){
    this.resourceName=name;
    this.pathElementsIndex=0;
    findNextResource();
  }
  /** 
 * Indicates whether there are more elements in the enumeration to return.
 * @return <code>true</code> if there are more elements in theenumeration; <code>false</code> otherwise.
 */
  public boolean hasMoreElements(){
    return (this.nextResource != null);
  }
  /** 
 * Returns the next resource in the enumeration.
 * @return the next resource in the enumeration
 */
  public Object nextElement(){
    URL ret=this.nextResource;
    findNextResource();
    return ret;
  }
  /** 
 * Locates the next resource of the correct name in the classpath and sets <code>nextResource</code> to the URL of that resource. If no more resources can be found, <code>nextResource</code> is set to <code>null</code>.
 */
  private void findNextResource(){
    URL url=null;
    while ((pathElementsIndex < pathComponents.size()) && (url == null)) {
      try {
        File pathComponent=(File)pathComponents.elementAt(pathElementsIndex);
        url=getResourceURL(pathComponent,this.resourceName);
        pathElementsIndex++;
      }
 catch (      BuildException e) {
      }
    }
    this.nextResource=url;
  }
}
