/** 
 * Specialized Environment class for System properties
 */
public static class SysProperties extends Environment implements Cloneable {
  Properties sys=null;
  public String[] getVariables() throws BuildException {
    String props[]=super.getVariables();
    if (props == null)     return null;
    for (int i=0; i < props.length; i++) {
      props[i]="-D" + props[i];
    }
    return props;
  }
  public int size(){
    return variables.size();
  }
  public void setSystem() throws BuildException {
    try {
      Properties p=new Properties(sys=System.getProperties());
      for (Enumeration e=variables.elements(); e.hasMoreElements(); ) {
        Environment.Variable v=(Environment.Variable)e.nextElement();
        p.put(v.getKey(),v.getValue());
      }
      System.setProperties(p);
    }
 catch (    SecurityException e) {
      throw new BuildException("Cannot modify system properties",e);
    }
  }
  public void restoreSystem() throws BuildException {
    if (sys == null)     throw new BuildException("Unbalanced nesting of SysProperties");
    try {
      System.setProperties(sys);
      sys=null;
    }
 catch (    SecurityException e) {
      throw new BuildException("Cannot modify system properties",e);
    }
  }
  public Object clone(){
    try {
      SysProperties c=(SysProperties)super.clone();
      c.variables=(Vector)variables.clone();
      return c;
    }
 catch (    CloneNotSupportedException e) {
      return null;
    }
  }
}
