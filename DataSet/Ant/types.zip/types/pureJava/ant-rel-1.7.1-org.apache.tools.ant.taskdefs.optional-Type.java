/** 
 * Enumerated attribute with the values "int", "date" and "string".
 */
public static class Type extends EnumeratedAttribute {
  /** 
 * int 
 */
  public static final int INTEGER_TYPE=0;
  /** 
 * date 
 */
  public static final int DATE_TYPE=1;
  /** 
 * string 
 */
  public static final int STRING_TYPE=2;
  /** 
 * {@inheritDoc} 
 */
  public String[] getValues(){
    return new String[]{"int","date","string"};
  }
  /** 
 * Convert string to index.
 * @param type the string to convert.
 * @return the index.
 */
  public static int toType(  String type){
    if ("int".equals(type)) {
      return INTEGER_TYPE;
    }
 else     if ("date".equals(type)) {
      return DATE_TYPE;
    }
    return STRING_TYPE;
  }
}
