/** 
 * Helper class for ExecuteWatchdogTest and ExecuteJavaTest. <p>Used to be an inner class of ExecuteWatchdogTest.
 */
public class TimeProcess {
  public static void main(  String[] args) throws Exception {
    int time=Integer.parseInt(args[0]);
    if (time < 1) {
      throw new IllegalArgumentException("Invalid time: " + time);
    }
    Thread.sleep(time);
  }
}
