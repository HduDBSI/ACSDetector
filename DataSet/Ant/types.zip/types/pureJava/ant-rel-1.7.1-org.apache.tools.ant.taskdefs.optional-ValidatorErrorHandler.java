/** 
 * ValidatorErrorHandler role : <ul> <li> log SAX parse exceptions, <li> remember if an error occurred </ul>
 */
protected class ValidatorErrorHandler implements ErrorHandler {
  protected File currentFile=null;
  protected String lastErrorMessage=null;
  protected boolean failed=false;
  /** 
 * initialises the class
 * @param file file used
 */
  public void init(  File file){
    currentFile=file;
    failed=false;
  }
  /** 
 * did an error happen during last parsing ?
 * @return did an error happen during last parsing ?
 */
  public boolean getFailure(){
    return failed;
  }
  /** 
 * record a fatal error
 * @param exception the fatal error
 */
  public void fatalError(  SAXParseException exception){
    failed=true;
    doLog(exception,Project.MSG_ERR);
  }
  /** 
 * receive notification of a recoverable error
 * @param exception the error
 */
  public void error(  SAXParseException exception){
    failed=true;
    doLog(exception,Project.MSG_ERR);
  }
  /** 
 * receive notification of a warning
 * @param exception the warning
 */
  public void warning(  SAXParseException exception){
    if (warn) {
      doLog(exception,Project.MSG_WARN);
    }
  }
  private void doLog(  SAXParseException e,  int logLevel){
    log(getMessage(e),logLevel);
  }
  private String getMessage(  SAXParseException e){
    String sysID=e.getSystemId();
    if (sysID != null) {
      String name=sysID;
      if (sysID.startsWith("file:")) {
        try {
          name=FILE_UTILS.fromURI(sysID);
        }
 catch (        Exception ex) {
        }
      }
      int line=e.getLineNumber();
      int col=e.getColumnNumber();
      return name + (line == -1 ? "" : (":" + line + (col == -1 ? "" : (":" + col)))) + ": "+ e.getMessage();
    }
    return e.getMessage();
  }
}
