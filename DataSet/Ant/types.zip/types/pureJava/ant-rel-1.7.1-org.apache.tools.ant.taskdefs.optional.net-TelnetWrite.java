/** 
 * Sends text to the connected server
 */
public class TelnetWrite extends TelnetSubTask {
  private boolean echoString=true;
  /** 
 * Execute the write task.
 * @param telnet the task to use
 * @throws BuildException on error
 */
  public void execute(  AntTelnetClient telnet) throws BuildException {
    telnet.sendString(taskString,echoString);
  }
  /** 
 * Whether or not the message should be echoed to the log. Defaults to <code>true</code>.
 * @param b a <code>boolean</code> value
 */
  public void setEcho(  boolean b){
    echoString=b;
  }
}
