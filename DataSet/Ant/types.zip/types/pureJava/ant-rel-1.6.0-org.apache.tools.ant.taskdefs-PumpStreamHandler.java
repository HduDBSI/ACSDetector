/** 
 * Copies standard output and error of subprocesses to standard output and error of the parent process. TODO: standard input of the subprocess is not implemented.
 * @author thomas.haas@softwired-inc.com
 * @since Ant 1.2
 */
public class PumpStreamHandler implements ExecuteStreamHandler {
  private Thread outputThread;
  private Thread errorThread;
  private Thread inputThread;
  private OutputStream out;
  private OutputStream err;
  private InputStream input;
  public PumpStreamHandler(  OutputStream out,  OutputStream err,  InputStream input){
    this.out=out;
    this.err=err;
    this.input=input;
  }
  public PumpStreamHandler(  OutputStream out,  OutputStream err){
    this(out,err,null);
  }
  public PumpStreamHandler(  OutputStream outAndErr){
    this(outAndErr,outAndErr);
  }
  public PumpStreamHandler(){
    this(System.out,System.err);
  }
  public void setProcessOutputStream(  InputStream is){
    createProcessOutputPump(is,out);
  }
  public void setProcessErrorStream(  InputStream is){
    if (err != null) {
      createProcessErrorPump(is,err);
    }
  }
  public void setProcessInputStream(  OutputStream os){
    if (input != null) {
      inputThread=createPump(input,os,true);
    }
 else {
      try {
        os.close();
      }
 catch (      IOException e) {
      }
    }
  }
  public void start(){
    outputThread.start();
    errorThread.start();
    if (inputThread != null) {
      inputThread.start();
    }
  }
  public void stop(){
    try {
      outputThread.join();
    }
 catch (    InterruptedException e) {
    }
    try {
      errorThread.join();
    }
 catch (    InterruptedException e) {
    }
    if (inputThread != null) {
      try {
        inputThread.join();
      }
 catch (      InterruptedException e) {
      }
    }
    try {
      err.flush();
    }
 catch (    IOException e) {
    }
    try {
      out.flush();
    }
 catch (    IOException e) {
    }
  }
  protected OutputStream getErr(){
    return err;
  }
  protected OutputStream getOut(){
    return out;
  }
  protected void createProcessOutputPump(  InputStream is,  OutputStream os){
    outputThread=createPump(is,os);
  }
  protected void createProcessErrorPump(  InputStream is,  OutputStream os){
    errorThread=createPump(is,os);
  }
  /** 
 * Creates a stream pumper to copy the given input stream to the given output stream.
 */
  protected Thread createPump(  InputStream is,  OutputStream os){
    return createPump(is,os,false);
  }
  /** 
 * Creates a stream pumper to copy the given input stream to the given output stream.
 */
  protected Thread createPump(  InputStream is,  OutputStream os,  boolean closeWhenExhausted){
    final Thread result=new Thread(new StreamPumper(is,os,closeWhenExhausted));
    result.setDaemon(true);
    return result;
  }
}
