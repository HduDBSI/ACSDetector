/** 
 * Helper class, holds the nested &lt;map&gt; values. Elements will look like this: &lt;map from=&quot;d:&quot; to=&quot;/foo&quot;/&gt; When running on windows, the prefix comparison will be case insensitive.
 */
public class MapEntry {
  private String from=null;
  private String to=null;
  /** 
 * Set the &quot;from&quot; attribute of the map entry.
 * @param from the prefix string to search for; required.Note that this value is case-insensitive when the build is running on a Windows platform and case-sensitive when running on a Unix platform.
 */
  public void setFrom(  String from){
    this.from=from;
  }
  /** 
 * Set the replacement text to use when from is matched; required.
 * @param to new prefix.
 */
  public void setTo(  String to){
    this.to=to;
  }
  /** 
 * Apply this map entry to a given path element.
 * @param elem Path element to process.
 * @return String Updated path element after mapping.
 */
  public String apply(  String elem){
    if (from == null || to == null) {
      throw new BuildException("Both 'from' and 'to' must be set " + "in a map entry");
    }
    String cmpElem=onWindows ? elem.toLowerCase().replace('\\','/') : elem;
    String cmpFrom=onWindows ? from.toLowerCase().replace('\\','/') : from;
    return cmpElem.startsWith(cmpFrom) ? to + elem.substring(from.length()) : elem;
  }
}
