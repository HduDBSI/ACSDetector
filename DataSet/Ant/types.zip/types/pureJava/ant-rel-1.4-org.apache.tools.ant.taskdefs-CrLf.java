/** 
 * Enumerated attribute with the values "asis", "cr", "lf" and "crlf".
 */
public static class CrLf extends EnumeratedAttribute {
  public String[] getValues(){
    return new String[]{"asis","cr","lf","crlf"};
  }
}
