/** 
 * Deployment tool for Weblogic TOPLink.
 */
public class WeblogicTOPLinkDeploymentTool extends WeblogicDeploymentTool {
  private static final String TL_DTD_LOC="http://www.objectpeople.com/tlwl/dtd/toplink-cmp_2_5_1.dtd";
  private String toplinkDescriptor;
  private String toplinkDTD;
  /** 
 * Setter used to store the name of the toplink descriptor.
 * @param inString the string to use as the descriptor name.
 */
  public void setToplinkdescriptor(  String inString){
    this.toplinkDescriptor=inString;
  }
  /** 
 * Setter used to store the location of the toplink DTD file. This is expected to be an URL (file or otherwise). If running this on NT using a file URL, the safest thing would be to not use a drive spec in the URL and make sure the file resides on the drive that ANT is running from.  This will keep the setting in the build XML platform independent.
 * @param inString the string to use as the DTD location.
 */
  public void setToplinkdtd(  String inString){
    this.toplinkDTD=inString;
  }
  /** 
 * Get the descriptor handler.
 * @param srcDir the source file.
 * @return the descriptor handler.
 */
  protected DescriptorHandler getDescriptorHandler(  File srcDir){
    DescriptorHandler handler=super.getDescriptorHandler(srcDir);
    if (toplinkDTD != null) {
      handler.registerDTD("-//The Object People, Inc.//" + "DTD TOPLink for WebLogic CMP 2.5.1//EN",toplinkDTD);
    }
 else {
      handler.registerDTD("-//The Object People, Inc.//" + "DTD TOPLink for WebLogic CMP 2.5.1//EN",TL_DTD_LOC);
    }
    return handler;
  }
  /** 
 * Add any vendor specific files which should be included in the EJB Jar.
 * @param ejbFiles the hashtable to add files to.
 * @param ddPrefix the prefix to use.
 */
  protected void addVendorFiles(  Hashtable ejbFiles,  String ddPrefix){
    super.addVendorFiles(ejbFiles,ddPrefix);
    File toplinkDD=new File(getConfig().descriptorDir,ddPrefix + toplinkDescriptor);
    if (toplinkDD.exists()) {
      ejbFiles.put(META_DIR + toplinkDescriptor,toplinkDD);
    }
 else {
      log("Unable to locate toplink deployment descriptor. " + "It was expected to be in " + toplinkDD.getPath(),Project.MSG_WARN);
    }
  }
  /** 
 * Called to validate that the tool parameters have been configured.
 * @throws BuildException if there is an error.
 */
  public void validateConfigured() throws BuildException {
    super.validateConfigured();
    if (toplinkDescriptor == null) {
      throw new BuildException("The toplinkdescriptor attribute must " + "be specified");
    }
  }
}
