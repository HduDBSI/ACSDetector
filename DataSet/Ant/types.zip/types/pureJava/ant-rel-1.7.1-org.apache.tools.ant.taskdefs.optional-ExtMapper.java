private class ExtMapper implements FileNameMapper {
  public void setFrom(  String s){
  }
  public void setTo(  String s){
  }
  public String[] mapFileName(  String fileName){
    int lastDot=fileName.lastIndexOf('.');
    if (lastDot >= 0) {
      return new String[]{fileName.substring(0,lastDot) + extension};
    }
 else {
      return new String[]{fileName + extension};
    }
  }
}
