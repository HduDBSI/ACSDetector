/** 
 * Helper class, holds the nested <code>&lt;pathelement&gt;</code> values.
 */
public class PathElement implements ResourceCollection {
  private String[] parts;
  /** 
 * Set the location.
 * @param loc a <code>File</code> value
 */
  public void setLocation(  File loc){
    parts=new String[]{translateFile(loc.getAbsolutePath())};
  }
  /** 
 * Set the path.
 * @param path a <code>String</code> value
 */
  public void setPath(  String path){
    parts=Path.translatePath(getProject(),path);
  }
  /** 
 * Return the converted pathelements.
 * @return a <code>String[]</code> value
 */
  public String[] getParts(){
    return parts;
  }
  /** 
 * Create an iterator.
 * @return an iterator.
 */
  public Iterator iterator(){
    return new FileResourceIterator(null,parts);
  }
  /** 
 * Check if this resource is only for filesystems.
 * @return true.
 */
  public boolean isFilesystemOnly(){
    return true;
  }
  /** 
 * Get the number of resources.
 * @return the number of parts.
 */
  public int size(){
    return parts == null ? 0 : parts.length;
  }
}
