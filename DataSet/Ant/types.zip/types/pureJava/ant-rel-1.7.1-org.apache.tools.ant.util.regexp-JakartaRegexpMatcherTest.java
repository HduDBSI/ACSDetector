/** 
 * Tests for the jakarta-regexp implementation of the RegexpMatcher interface.
 */
public class JakartaRegexpMatcherTest extends RegexpMatcherTest {
  public RegexpMatcher getImplementation(){
    return new JakartaRegexpMatcher();
  }
  public JakartaRegexpMatcherTest(  String name){
    super(name);
  }
  public void testWindowsLineSeparator2() throws IOException {
    try {
      super.testWindowsLineSeparator2();
      fail("Should trigger when this bug is fixed. {@since 1.2}");
    }
 catch (    AssertionFailedError e) {
    }
  }
  /** 
 * Fails for the same reason as "default" mode in doEndTest2.
 */
  public void testUnixLineSeparator() throws IOException {
    try {
      super.testUnixLineSeparator();
      fail("Should trigger once this bug is fixed. {@since 1.2}");
    }
 catch (    AssertionFailedError e) {
    }
  }
  /** 
 * Fails for "default" mode.
 */
  protected void doEndTest2(  String text){
  }
}
