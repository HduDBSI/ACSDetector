private final static class TestRunner extends JUnitTestRunner {
  private ResultFormatter formatter=new ResultFormatter();
  TestRunner(  JUnitTest test,  boolean x,  boolean y){
    super(test,x,y,TestRunner.class.getClassLoader());
    addFormatter(formatter);
  }
  ResultFormatter getFormatter(){
    return formatter;
  }
}
