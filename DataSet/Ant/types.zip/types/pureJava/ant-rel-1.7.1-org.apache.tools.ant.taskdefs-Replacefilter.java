/** 
 * A filter to apply.
 */
public class Replacefilter {
  private String token;
  private String value;
  private String replaceValue;
  private String property;
  private StringBuffer inputBuffer;
  private StringBuffer outputBuffer=new StringBuffer();
  /** 
 * Validate the filter's configuration.
 * @throws BuildException if any part is invalid.
 */
  public void validate() throws BuildException {
    if (token == null) {
      String message="token is a mandatory attribute " + "of replacefilter.";
      throw new BuildException(message);
    }
    if ("".equals(token)) {
      String message="The token attribute must not be an empty " + "string.";
      throw new BuildException(message);
    }
    if ((value != null) && (property != null)) {
      String message="Either value or property " + "can be specified, but a replacefilter " + "element cannot have both.";
      throw new BuildException(message);
    }
    if ((property != null)) {
      if (propertyFile == null) {
        String message="The replacefilter's property attribute " + "can only be used with the replacetask's " + "propertyFile attribute.";
        throw new BuildException(message);
      }
      if (properties == null || properties.getProperty(property) == null) {
        String message="property \"" + property + "\" was not found in "+ propertyFile.getPath();
        throw new BuildException(message);
      }
    }
    replaceValue=getReplaceValue();
  }
  /** 
 * Get the replacement value for this filter token.
 * @return the replacement value
 */
  public String getReplaceValue(){
    if (property != null) {
      return properties.getProperty(property);
    }
 else     if (value != null) {
      return value;
    }
 else     if (Replace.this.value != null) {
      return Replace.this.value.getText();
    }
 else {
      return "";
    }
  }
  /** 
 * Set the token to replace.
 * @param token <code>String</code> token.
 */
  public void setToken(  String token){
    this.token=token;
  }
  /** 
 * Get the string to search for.
 * @return current <code>String</code> token.
 */
  public String getToken(){
    return token;
  }
  /** 
 * The replacement string; required if <code>property<code> is not set.
 * @param value <code>String</code> value to replace.
 */
  public void setValue(  String value){
    this.value=value;
  }
  /** 
 * Get replacement <code>String</code>.
 * @return replacement or null.
 */
  public String getValue(){
    return value;
  }
  /** 
 * Set the name of the property whose value is to serve as the replacement value; required if <code>value</code> is not set.
 * @param property property name.
 */
  public void setProperty(  String property){
    this.property=property;
  }
  /** 
 * Get the name of the property whose value is to serve as the replacement value.
 * @return property or null.
 */
  public String getProperty(){
    return property;
  }
  /** 
 * Retrieves the output buffer of this filter. The filter guarantees that data is only appended to the end of this StringBuffer.
 * @return The StringBuffer containing the output of this filter.
 */
  StringBuffer getOutputBuffer(){
    return outputBuffer;
  }
  /** 
 * Sets the input buffer for this filter. The filter expects from the component providing the input that data is only added by that component to the end of this StringBuffer. This StringBuffer will be modified by this filter, and expects that another component will only apped to this StringBuffer.
 * @param input The input for this filter.
 */
  void setInputBuffer(  StringBuffer input){
    inputBuffer=input;
  }
  /** 
 * Processes the buffer as far as possible. Takes into account that appended data may make it possible to replace the end of the already received data, when the token is split over the "old" and the "new" part.
 * @return true if some data has been made available in theoutput buffer.
 */
  boolean process(){
    if (inputBuffer.length() > token.length()) {
      int pos=replace();
      pos=Math.max((inputBuffer.length() - token.length()),pos);
      outputBuffer.append(inputBuffer.substring(0,pos));
      inputBuffer.delete(0,pos);
      return true;
    }
    return false;
  }
  /** 
 * Processes the buffer to the end. Does not take into account that appended data may make it possible to replace the end of the already received data.
 */
  void flush(){
    replace();
    outputBuffer.append(inputBuffer.toString());
    inputBuffer.delete(0,inputBuffer.length());
  }
  /** 
 * Performs the replace operation.
 * @return The position of the last character that was inserted asreplacement.
 */
  private int replace(){
    int found=inputBuffer.toString().indexOf(token);
    int pos=-1;
    while (found >= 0) {
      inputBuffer.replace(found,found + token.length(),replaceValue);
      pos=found + replaceValue.length();
      found=inputBuffer.toString().indexOf(token,pos);
      ++replaceCount;
    }
    return pos;
  }
}
