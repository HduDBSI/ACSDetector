private final static class ResultFormatter implements JUnitResultFormatter {
  private Throwable error;
  public void setSystemOutput(  String output){
  }
  public void setSystemError(  String output){
  }
  public void startTestSuite(  JUnitTest suite) throws BuildException {
  }
  public void endTestSuite(  JUnitTest suite) throws BuildException {
  }
  public void setOutput(  java.io.OutputStream out){
  }
  public void startTest(  Test t){
  }
  public void endTest(  Test test){
  }
  public void addFailure(  Test test,  Throwable t){
  }
  public void addFailure(  Test test,  AssertionFailedError t){
  }
  public void addError(  Test test,  Throwable t){
    error=t;
  }
  String getError(){
    if (error == null) {
      return "";
    }
    StringWriter sw=new StringWriter();
    error.printStackTrace(new PrintWriter(sw));
    return sw.toString();
  }
}
