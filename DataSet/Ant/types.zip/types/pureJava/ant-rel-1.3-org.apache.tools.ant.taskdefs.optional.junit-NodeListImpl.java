/** 
 * custom implementation of a nodelist 
 */
public static class NodeListImpl extends Vector implements NodeList {
  public int getLength(){
    return size();
  }
  public Node item(  int i){
    try {
      return (Node)elementAt(i);
    }
 catch (    ArrayIndexOutOfBoundsException e) {
      return null;
    }
  }
}
