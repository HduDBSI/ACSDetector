/** 
 * This nested element that allows a property to be set to the current date and time in a given format. The date/time patterns are as defined in the Java SimpleDateFormat class. The format element also allows offsets to be applied to the time to generate different time values.
 * @todo consider refactoring out into a re-usable element.
 */
public class CustomFormat {
  private TimeZone timeZone;
  private String propertyName;
  private String pattern;
  private String language;
  private String country;
  private String variant;
  private int offset=0;
  private int field=Calendar.DATE;
  /** 
 * The property to receive the date/time string in the given pattern
 * @param propertyName the name of the property.
 */
  public void setProperty(  String propertyName){
    this.propertyName=propertyName;
  }
  /** 
 * The date/time pattern to be used. The values are as defined by the Java SimpleDateFormat class.
 * @param pattern the pattern to use.
 * @see java.text.SimpleDateFormat
 */
  public void setPattern(  String pattern){
    this.pattern=pattern;
  }
  /** 
 * The locale used to create date/time string. The general form is "language, country, variant" but either variant or variant and country may be omitted. For more information please refer to documentation for the java.util.Locale  class.
 * @param locale the locale to use.
 * @see java.util.Locale
 */
  public void setLocale(  String locale){
    StringTokenizer st=new StringTokenizer(locale," \t\n\r\f,");
    try {
      language=st.nextToken();
      if (st.hasMoreElements()) {
        country=st.nextToken();
        if (st.hasMoreElements()) {
          variant=st.nextToken();
          if (st.hasMoreElements()) {
            throw new BuildException("bad locale format",getLocation());
          }
        }
      }
 else {
        country="";
      }
    }
 catch (    NoSuchElementException e) {
      throw new BuildException("bad locale format",e,getLocation());
    }
  }
  /** 
 * The timezone to use for displaying time. The values are as defined by the Java TimeZone class.
 * @param id the timezone value.
 * @see java.util.TimeZone
 */
  public void setTimezone(  String id){
    timeZone=TimeZone.getTimeZone(id);
  }
  /** 
 * The numeric offset to the current time.
 * @param offset the offset to use.
 */
  public void setOffset(  int offset){
    this.offset=offset;
  }
  /** 
 * Set the unit type (using String).
 * @param unit the unit to use.
 * @deprecated since 1.5.x.setUnit(String) is deprecated and is replaced with setUnit(Tstamp.Unit) to make Ant's Introspection mechanism do the work and also to encapsulate operations on the unit in its own class.
 */
  @Deprecated public void setUnit(  String unit){
    log("DEPRECATED - The setUnit(String) method has been deprecated. Use setUnit(Tstamp.Unit) instead.");
    Unit u=new Unit();
    u.setValue(unit);
    field=u.getCalendarField();
  }
  /** 
 * The unit of the offset to be applied to the current time. Valid Values are <ul> <li>millisecond</li> <li>second</li> <li>minute</li> <li>hour</li> <li>day</li> <li>week</li> <li>month</li> <li>year</li> </ul> The default unit is day.
 * @param unit the unit to use.
 */
  public void setUnit(  Unit unit){
    field=unit.getCalendarField();
  }
  /** 
 * validate parameter and execute the format.
 * @param project project to set property in.
 * @param date date to use as a starting point.
 * @param location line in file (for errors)
 */
  public void execute(  Project project,  Date date,  Location location){
    if (propertyName == null) {
      throw new BuildException("property attribute must be provided",location);
    }
    if (pattern == null) {
      throw new BuildException("pattern attribute must be provided",location);
    }
    SimpleDateFormat sdf;
    if (language == null) {
      sdf=new SimpleDateFormat(pattern);
    }
 else     if (variant == null) {
      sdf=new SimpleDateFormat(pattern,new Locale(language,country));
    }
 else {
      sdf=new SimpleDateFormat(pattern,new Locale(language,country,variant));
    }
    if (offset != 0) {
      Calendar calendar=Calendar.getInstance();
      calendar.setTime(date);
      calendar.add(field,offset);
      date=calendar.getTime();
    }
    if (timeZone != null) {
      sdf.setTimeZone(timeZone);
    }
    Tstamp.this.setProperty(propertyName,sdf.format(date));
  }
}
