/** 
 * A DistinguishedName parameter. This is a nested element in a dname nested element.
 */
public static class DnameParam {
  private String name;
  private String value;
  /** 
 * Set the name attribute.
 * @param name a <code>String</code> value
 */
  public void setName(  String name){
    this.name=name;
  }
  /** 
 * Get the name attribute.
 * @return the name.
 */
  public String getName(){
    return name;
  }
  /** 
 * Set the value attribute.
 * @param value a <code>String</code> value
 */
  public void setValue(  String value){
    this.value=value;
  }
  /** 
 * Get the value attribute.
 * @return the value.
 */
  public String getValue(){
    return value;
  }
  public boolean isComplete(){
    return name != null && value != null;
  }
}
