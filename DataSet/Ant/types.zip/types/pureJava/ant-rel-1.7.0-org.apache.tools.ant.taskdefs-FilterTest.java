/** 
 */
public class FilterTest extends BuildFileTest {
  public FilterTest(  String name){
    super(name);
  }
  public void setUp(){
    configureProject("src/etc/testcases/taskdefs/filter.xml");
  }
  public void tearDown(){
    executeTarget("cleanup");
  }
  public void test1(){
    expectBuildException("test1","required argument missing");
  }
  public void test2(){
    expectBuildException("test2","required argument missing");
  }
  public void test3(){
    expectBuildException("test3","required argument missing");
  }
  public void test4(){
    executeTarget("test4");
  }
  public void test5(){
    executeTarget("test5");
    assertEquals("2000",getFilteredFile("5","filtered.tmp"));
  }
  public void test6(){
    executeTarget("test6");
    assertEquals("2000",getFilteredFile("6","taskdefs.tmp/filter1.txt"));
  }
  public void test7(){
    executeTarget("test7");
    assertEquals("<%@ include file=\"root/some/include.jsp\"%>",getFilteredFile("7","filtered.tmp"));
  }
  public void test8(){
    executeTarget("test8");
    assertEquals("<%@ include file=\"root/some/include.jsp\"%>",getFilteredFile("8","taskdefs.tmp/filter2.txt"));
  }
  public void test9(){
    executeTarget("test9");
    assertEquals("included",getFilteredFile("9","taskdefs.tmp/filter3.txt"));
  }
  private String getFilteredFile(  String testNumber,  String filteredFile){
    String line=null;
    File f=new File(getProjectDir(),filteredFile);
    if (!f.exists()) {
      fail("filter test" + testNumber + " failed");
    }
 else {
      BufferedReader in=null;
      try {
        in=new BufferedReader(new FileReader(f));
      }
 catch (      FileNotFoundException fnfe) {
        fail("filter test" + testNumber + " failed, filtered file: "+ f.toString()+ " not found");
      }
      try {
        line=in.readLine();
        in.close();
      }
 catch (      IOException ioe) {
        fail("filter test" + testNumber + " failed.  IOException while reading filtered file: "+ ioe);
      }
    }
    f.delete();
    return line;
  }
}
