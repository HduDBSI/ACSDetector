/** 
 * Class as Argument to FileNameMapper.setType.
 */
public static class MapperType extends EnumeratedAttribute {
  private Properties implementations;
  public MapperType(){
    implementations=new Properties();
    implementations.put("identity","org.apache.tools.ant.util.IdentityMapper");
    implementations.put("flatten","org.apache.tools.ant.util.FlatFileNameMapper");
    implementations.put("glob","org.apache.tools.ant.util.GlobPatternMapper");
    implementations.put("merge","org.apache.tools.ant.util.MergingMapper");
    implementations.put("regexp","org.apache.tools.ant.util.RegexpPatternMapper");
  }
  public String[] getValues(){
    return new String[]{"identity","flatten","glob","merge","regexp"};
  }
  public String getImplementation(){
    return implementations.getProperty(getValue());
  }
}
