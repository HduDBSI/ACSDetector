/** 
 * This class is the parent of the Read and Write tasks. It handles the common attributes for both.
 */
public class TelnetSubTask {
  protected String taskString="";
  /** 
 * Execute the subtask.
 * @param telnet the client
 * @throws BuildException always as it is not allowed to instantiate this object
 */
  public void execute(  AntTelnetClient telnet) throws BuildException {
    throw new BuildException("Shouldn't be able instantiate a SubTask directly");
  }
  /** 
 * the message as nested text
 * @param s the nested text
 */
  public void addText(  String s){
    setString(getProject().replaceProperties(s));
  }
  /** 
 * the message as an attribute
 * @param s a <code>String</code> value
 */
  public void setString(  String s){
    taskString+=s;
  }
}
