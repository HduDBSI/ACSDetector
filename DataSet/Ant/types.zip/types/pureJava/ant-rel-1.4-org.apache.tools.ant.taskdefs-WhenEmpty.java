/** 
 * Possible behaviors when there are no matching files for the task. 
 */
public static class WhenEmpty extends EnumeratedAttribute {
  public String[] getValues(){
    return new String[]{"fail","skip","create"};
  }
}
