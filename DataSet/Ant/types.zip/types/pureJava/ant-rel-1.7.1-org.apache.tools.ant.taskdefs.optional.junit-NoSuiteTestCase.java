public static class NoSuiteTestCase extends TestCase {
  public NoSuiteTestCase(  String name){
    super(name);
  }
  public void testA(){
  }
}
