/** 
 * This is a condition that checks to see if a file passes an embedded selector.
 */
public class IsFileSelected extends AbstractSelectorContainer implements Condition {
  private static final FileUtils FILE_UTILS=FileUtils.getFileUtils();
  private File file;
  private File baseDir;
  /** 
 * The file to check.
 * @param file the file to check if if passes the embedded selector.
 */
  public void setFile(  File file){
    this.file=file;
  }
  /** 
 * The base directory to use.
 * @param baseDir the base directory to use, if null use the project'sbasedir.
 */
  public void setBaseDir(  File baseDir){
    this.baseDir=baseDir;
  }
  /** 
 * validate the parameters.
 */
  public void validate(){
    if (selectorCount() != 1) {
      throw new BuildException("Only one selector allowed");
    }
    super.validate();
  }
  /** 
 * Evaluate the selector with the file.
 * @return true if the file is selected by the embedded selector.
 */
  public boolean eval(){
    if (file == null) {
      throw new BuildException("file attribute not set");
    }
    validate();
    File myBaseDir=baseDir;
    if (myBaseDir == null) {
      myBaseDir=getProject().getBaseDir();
    }
    FileSelector f=getSelectors(getProject())[0];
    return f.isSelected(myBaseDir,FILE_UTILS.removeLeadingPath(myBaseDir,file),file);
  }
}
