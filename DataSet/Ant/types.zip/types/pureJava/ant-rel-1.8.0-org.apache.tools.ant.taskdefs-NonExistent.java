private static final class NonExistent extends Restrict {
  private NonExistent(  ResourceCollection rc){
    super.add(rc);
    super.add(NOT_EXISTS);
  }
}
