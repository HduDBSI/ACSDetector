private class PropertyOutputStream extends ByteArrayOutputStream {
  private String property;
  private boolean closed=false;
  PropertyOutputStream(  String property){
    super();
    this.property=property;
  }
  public void close() throws IOException {
    if (!closed && !(append && appendProperties)) {
      setPropertyFromBAOS(this,property);
      closed=true;
    }
  }
}
