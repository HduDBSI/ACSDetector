/** 
 * Enumerated attribute with the values "asis", "add" and "remove".
 */
public static class AddAsisRemove extends EnumeratedAttribute {
  public String[] getValues(){
    return new String[]{"add","asis","remove"};
  }
}
