/** 
 * This inner class is an XML document handler that can be used to parse EJB descriptors (both the standard EJB descriptor as well as the iAS-specific descriptor that stores additional values for iAS).  Once the descriptors have been processed, the list of EJBs found can be obtained by calling the <code>getEjbs()</code> method.
 * @see IPlanetEjbc.EjbInfo
 */
private class EjbcHandler extends HandlerBase {
  /** 
 * EJB 1.1 ID 
 */
  private static final String PUBLICID_EJB11="-//Sun Microsystems, Inc.//DTD Enterprise JavaBeans 1.1//EN";
  /** 
 * IPlanet ID 
 */
  private static final String PUBLICID_IPLANET_EJB_60="-//Sun Microsystems, Inc.//DTD iAS Enterprise JavaBeans 1.0//EN";
  /** 
 * EJB 1.1 location 
 */
  private static final String DEFAULT_IAS60_EJB11_DTD_LOCATION="ejb-jar_1_1.dtd";
  /** 
 * IAS60 location 
 */
  private static final String DEFAULT_IAS60_DTD_LOCATION="IASEjb_jar_1_0.dtd";
  private Map resourceDtds=new HashMap();
  private Map fileDtds=new HashMap();
  private Map ejbs=new HashMap();
  private EjbInfo currentEjb;
  private boolean iasDescriptor=false;
  private String currentLoc="";
  private String currentText;
  private String ejbType;
  /** 
 * Constructs a new instance of the handler and registers local copies of the standard EJB 1.1 descriptor DTD as well as iAS's EJB descriptor DTD.
 */
  public EjbcHandler(){
    registerDTD(PUBLICID_EJB11,DEFAULT_IAS60_EJB11_DTD_LOCATION);
    registerDTD(PUBLICID_IPLANET_EJB_60,DEFAULT_IAS60_DTD_LOCATION);
  }
  /** 
 * Returns the list of EJB objects found during the processing of the standard EJB 1.1 descriptor and iAS-specific EJB descriptor.
 * @return An array of EJBs which were found during the descriptorparsing.
 */
  public EjbInfo[] getEjbs(){
    return (EjbInfo[])ejbs.values().toArray(new EjbInfo[ejbs.size()]);
  }
  /** 
 * Returns the value of the display-name element found in the standard EJB 1.1 descriptor.
 * @return String display-name value.
 */
  public String getDisplayName(){
    return displayName;
  }
  /** 
 * Registers a local DTD that will be used when parsing an EJB descriptor.  When the DTD's public identifier is found in an XML document, the parser will reference the local DTD rather than the remote DTD.  This enables XML documents to be processed even when the public DTD isn't available.
 * @param publicID The DTD's public identifier.
 * @param location The location of the local DTD copy -- the locationmay either be a resource found on the classpath or a local file.
 */
  public void registerDTD(  String publicID,  String location){
    log("Registering: " + location);
    if ((publicID == null) || (location == null)) {
      return;
    }
    if (ClassLoader.getSystemResource(location) != null) {
      log("Found resource: " + location);
      resourceDtds.put(publicID,location);
    }
 else {
      File dtdFile=new File(location);
      if (dtdFile.exists() && dtdFile.isFile()) {
        log("Found file: " + location);
        fileDtds.put(publicID,location);
      }
    }
  }
  /** 
 * Resolves an external entity found during XML processing.  If a public ID is found that has been registered with the handler, an <code> InputSource</code> will be returned which refers to the local copy. If the public ID hasn't been registered or if an error occurs, the superclass implementation is used.
 * @param publicId The DTD's public identifier.
 * @param systemId The location of the DTD, as found in the XML document.
 */
  public InputSource resolveEntity(  String publicId,  String systemId) throws SAXException {
    InputStream inputStream=null;
    try {
      String location=(String)resourceDtds.get(publicId);
      if (location != null) {
        inputStream=ClassLoader.getSystemResource(location).openStream();
      }
 else {
        location=(String)fileDtds.get(publicId);
        if (location != null) {
          inputStream=new FileInputStream(location);
        }
      }
    }
 catch (    IOException e) {
      return super.resolveEntity(publicId,systemId);
    }
    if (inputStream == null) {
      return super.resolveEntity(publicId,systemId);
    }
 else {
      return new InputSource(inputStream);
    }
  }
  /** 
 * Receive notification that the start of an XML element has been found.
 * @param name String name of the element found.
 * @param atts AttributeList of the attributes included with the element(if any).
 * @throws SAXException If the parser cannot process the document.
 */
  public void startElement(  String name,  AttributeList atts) throws SAXException {
    currentLoc+="\\" + name;
    currentText="";
    if (currentLoc.equals("\\ejb-jar")) {
      iasDescriptor=false;
    }
 else     if (currentLoc.equals("\\ias-ejb-jar")) {
      iasDescriptor=true;
    }
    if ((name.equals("session")) || (name.equals("entity"))) {
      ejbType=name;
    }
  }
  /** 
 * Receive notification that character data has been found in the XML document
 * @param ch Array of characters which have been found in the document.
 * @param start Starting index of the data found in the document.
 * @param len The number of characters found in the document.
 * @throws SAXException If the parser cannot process the document.
 */
  public void characters(  char[] ch,  int start,  int len) throws SAXException {
    currentText+=new String(ch).substring(start,start + len);
  }
  /** 
 * Receive notification that the end of an XML element has been found.
 * @param name String name of the element.
 * @throws SAXException If the parser cannot process the document.
 */
  public void endElement(  String name) throws SAXException {
    if (iasDescriptor) {
      iasCharacters(currentText);
    }
 else {
      stdCharacters(currentText);
    }
    int nameLength=name.length() + 1;
    int locLength=currentLoc.length();
    currentLoc=currentLoc.substring(0,locLength - nameLength);
  }
  /** 
 * Receive notification that character data has been found in a standard EJB 1.1 descriptor.  We're interested in retrieving the home interface, remote interface, implementation class, the type of bean, and if the bean uses CMP.
 * @param value String data found in the XML document.
 */
  private void stdCharacters(  String value){
    if (currentLoc.equals("\\ejb-jar\\display-name")) {
      displayName=value;
      return;
    }
    String base="\\ejb-jar\\enterprise-beans\\" + ejbType;
    if (currentLoc.equals(base + "\\ejb-name")) {
      currentEjb=(EjbInfo)ejbs.get(value);
      if (currentEjb == null) {
        currentEjb=new EjbInfo(value);
        ejbs.put(value,currentEjb);
      }
    }
 else     if (currentLoc.equals(base + "\\home")) {
      currentEjb.setHome(value);
    }
 else     if (currentLoc.equals(base + "\\remote")) {
      currentEjb.setRemote(value);
    }
 else     if (currentLoc.equals(base + "\\ejb-class")) {
      currentEjb.setImplementation(value);
    }
 else     if (currentLoc.equals(base + "\\prim-key-class")) {
      currentEjb.setPrimaryKey(value);
    }
 else     if (currentLoc.equals(base + "\\session-type")) {
      currentEjb.setBeantype(value);
    }
 else     if (currentLoc.equals(base + "\\persistence-type")) {
      currentEjb.setCmp(value);
    }
  }
  /** 
 * Receive notification that character data has been found in an iAS-specific descriptor.  We're interested in retrieving data indicating whether the bean must support RMI/IIOP access, whether the bean must provide highly available stubs and skeletons (in the case of stateful session beans), and if this bean uses additional CMP XML descriptors (in the case of entity beans with CMP).
 * @param value String data found in the XML document.
 */
  private void iasCharacters(  String value){
    String base="\\ias-ejb-jar\\enterprise-beans\\" + ejbType;
    if (currentLoc.equals(base + "\\ejb-name")) {
      currentEjb=(EjbInfo)ejbs.get(value);
      if (currentEjb == null) {
        currentEjb=new EjbInfo(value);
        ejbs.put(value,currentEjb);
      }
    }
 else     if (currentLoc.equals(base + "\\iiop")) {
      currentEjb.setIiop(value);
    }
 else     if (currentLoc.equals(base + "\\failover-required")) {
      currentEjb.setHasession(value);
    }
 else     if (currentLoc.equals(base + "\\persistence-manager" + "\\properties-file-location")) {
      currentEjb.addCmpDescriptor(value);
    }
  }
}
