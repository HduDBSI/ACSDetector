/** 
 * inner class to hold a name on list.  "If" and "Unless" attributes may be used to invalidate the entry based on the existence of a property (typically set thru the use of the Available task) or value of an expression.
 */
public class NameEntry {
  private String name;
  private Object ifCond;
  private Object unlessCond;
  /** 
 * Sets the name pattern.
 * @param name The pattern string.
 */
  public void setName(  String name){
    this.name=name;
  }
  /** 
 * Sets the if attribute. This attribute and the "unless" attribute are used to validate the name, based on the existence of the property or the value of the evaluated property expression.
 * @param cond A property name or expression.  If theexpression evaluates to false or no property of its value is present, the name is invalid.
 * @since Ant 1.8.0
 */
  public void setIf(  Object cond){
    ifCond=cond;
  }
  /** 
 * Sets the if attribute. This attribute and the "unless" attribute are used to validate the name, based on the existence of the property or the value of the evaluated property expression.
 * @param cond A property name or expression.  If theexpression evaluates to false or no property of its value is present, the name is invalid.
 */
  public void setIf(  String cond){
    setIf((Object)cond);
  }
  /** 
 * Sets the unless attribute. This attribute and the "if" attribute are used to validate the name, based on the existence of the property or the value of the evaluated property expression.
 * @param cond A property name or expression.  If theexpression evaluates to true or a property of its value is present, the name is invalid.
 * @param cond A property name or expression.
 * @since Ant 1.8.0
 */
  public void setUnless(  Object cond){
    unlessCond=cond;
  }
  /** 
 * Sets the unless attribute. This attribute and the "if" attribute are used to validate the name, based on the existence of the property or the value of the evaluated property expression.
 * @param cond A property name or expression.  If theexpression evaluates to true or a property of its value is present, the name is invalid.
 */
  public void setUnless(  String cond){
    setUnless((Object)cond);
  }
  /** 
 * @return the name attribute.
 */
  public String getName(){
    return name;
  }
  /** 
 * This validates the name - checks the if and unless properties.
 * @param p the current project, used to check the presence orabsence of a property.
 * @return  the name attribute or null if the "if" or "unless"properties are not/are set.
 */
  public String evalName(  Project p){
    return valid(p) ? name : null;
  }
  private boolean valid(  Project p){
    PropertyHelper ph=PropertyHelper.getPropertyHelper(p);
    return ph.testIfCondition(ifCond) && ph.testUnlessCondition(unlessCond);
  }
  /** 
 * @return a printable form of this object.
 */
  public String toString(){
    StringBuffer buf=new StringBuffer();
    if (name == null) {
      buf.append("noname");
    }
 else {
      buf.append(name);
    }
    if ((ifCond != null) || (unlessCond != null)) {
      buf.append(":");
      String connector="";
      if (ifCond != null) {
        buf.append("if->");
        buf.append(ifCond);
        connector=";";
      }
      if (unlessCond != null) {
        buf.append(connector);
        buf.append("unless->");
        buf.append(unlessCond);
      }
    }
    return buf.toString();
  }
}
