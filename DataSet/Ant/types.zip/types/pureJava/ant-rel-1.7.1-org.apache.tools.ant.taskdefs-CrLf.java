/** 
 * Enumerated attribute with the values "asis", "cr", "lf" and "crlf".
 */
public static class CrLf extends EnumeratedAttribute {
  /** 
 * {@inheritDoc}. 
 */
  public String[] getValues(){
    return new String[]{"asis","cr","lf","crlf","mac","unix","dos"};
  }
}
