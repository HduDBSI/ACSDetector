/** 
 * Provides a quick and dirty way to determine the true name of a class given just an InputStream. Reads in just enough to perform this minimal task only.
 */
public class ClassNameReader extends Object {
  public static String getClassName(  InputStream input) throws IOException {
    DataInputStream data=new DataInputStream(input);
    int cookie=data.readInt();
    if (cookie != 0xCAFEBABE) {
      return null;
    }
    int version=data.readInt();
    ConstantPool constants=new ConstantPool(data);
    Object[] values=constants.values;
    int accessFlags=data.readUnsignedShort();
    int classIndex=data.readUnsignedShort();
    Integer stringIndex=(Integer)values[classIndex];
    String className=(String)values[stringIndex.intValue()];
    return className;
  }
}
