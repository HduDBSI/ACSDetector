/** 
 * Contains the definition of a new transaction element. Transactions allow several files or blocks of statements to be executed using the same JDBC connection and commit operation in between.
 */
public class Transaction {
  private Resource tSrcResource=null;
  private String tSqlCommand="";
  /** 
 * Set the source file attribute.
 * @param src the source file
 */
  public void setSrc(  File src){
    if (src != null) {
      setSrcResource(new FileResource(src));
    }
  }
  /** 
 * Set the source resource attribute.
 * @param src the source file
 * @since Ant 1.7
 */
  public void setSrcResource(  Resource src){
    if (tSrcResource != null) {
      throw new BuildException("only one resource per transaction");
    }
    tSrcResource=src;
  }
  /** 
 * Set inline text
 * @param sql the inline text
 */
  public void addText(  String sql){
    if (sql != null) {
      this.tSqlCommand+=sql;
    }
  }
  /** 
 * Set the source resource.
 * @param a the source resource collection.
 * @since Ant 1.7
 */
  public void addConfigured(  ResourceCollection a){
    if (a.size() != 1) {
      throw new BuildException("only single argument resource collections are supported.");
    }
    setSrcResource(a.iterator().next());
  }
  private void runTransaction(  PrintStream out) throws IOException, SQLException {
    if (!tSqlCommand.isEmpty()) {
      log("Executing commands",Project.MSG_INFO);
      runStatements(new StringReader(tSqlCommand),out);
    }
    if (tSrcResource != null) {
      log("Executing resource: " + tSrcResource.toString(),Project.MSG_INFO);
      Charset charset=encoding == null ? Charset.defaultCharset() : Charset.forName(encoding);
      try (Reader reader=new InputStreamReader(tSrcResource.getInputStream(),charset)){
        runStatements(reader,out);
      }
     }
  }
}
