/** 
 * @deprecated use BuildFileTest instead.
 */
public abstract class TaskdefsTest extends BuildFileTest {
  public TaskdefsTest(  String name){
    super(name);
  }
}
