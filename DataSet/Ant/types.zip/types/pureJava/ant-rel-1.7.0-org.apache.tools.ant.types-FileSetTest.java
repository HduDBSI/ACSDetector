/** 
 * JUnit 3 testcases for org.apache.tools.ant.types.FileSet. <p>This doesn't actually test much, mainly reference handling.
 */
public class FileSetTest extends AbstractFileSetTest {
  public FileSetTest(  String name){
    super(name);
  }
  protected AbstractFileSet getInstance(){
    return new FileSet();
  }
}
