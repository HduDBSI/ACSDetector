/** 
 * Print summary enumeration values.
 */
public static class SummaryAttribute extends EnumeratedAttribute {
  /** 
 * list the possible values
 * @return  array of allowed values
 */
  public String[] getValues(){
    return new String[]{"true","yes","false","no","on","off","withOutAndErr"};
  }
  /** 
 * gives the boolean equivalent of the authorized values
 * @return boolean equivalent of the value
 */
  public boolean asBoolean(){
    String v=getValue();
    return "true".equals(v) || "on".equals(v) || "yes".equals(v)|| "withOutAndErr".equals(v);
  }
}
