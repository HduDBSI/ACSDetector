/** 
 * Contains the definition of a new transaction element. Transactions allow several files or blocks of statements to be executed using the same JDBC connection and commit operation in between.
 */
public class Transaction {
  private File tSrcFile=null;
  private String tSqlCommand="";
  public void setSrc(  File src){
    this.tSrcFile=src;
  }
  public void addText(  String sql){
    this.tSqlCommand+=sql;
  }
  private void runTransaction() throws IOException, SQLException {
    if (tSqlCommand.length() != 0) {
      log("Executing commands",Project.MSG_INFO);
      runStatements(new StringReader(tSqlCommand));
    }
    if (tSrcFile != null) {
      log("Executing file: " + tSrcFile.getAbsolutePath(),Project.MSG_INFO);
      runStatements(new FileReader(tSrcFile));
    }
  }
}
