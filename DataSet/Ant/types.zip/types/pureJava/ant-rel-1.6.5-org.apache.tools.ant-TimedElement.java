/** 
 * Utility class representing the time an element started. 
 */
private static class TimedElement {
  /** 
 * Start time in milliseconds (as returned by <code>System.currentTimeMillis()</code>).
 */
  private long startTime;
  /** 
 * Element created at the start time. 
 */
  private Element element;
  public String toString(){
    return element.getTagName() + ":" + element.getAttribute("name");
  }
}
