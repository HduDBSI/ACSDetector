/** 
 * Thread class used to redirect output from an <code>InputStream</code> to the JRE standard output.  This class may be used to redirect output from an external process to the standard output.
 */
private static class RedirectOutput extends Thread {
  private InputStream stream;
  /** 
 * Constructs a new instance that will redirect output from the specified stream to the standard output.
 * @param stream InputStream which will be read and redirected to thestandard output.
 */
  public RedirectOutput(  InputStream stream){
    this.stream=stream;
  }
  /** 
 * Reads text from the input stream and redirects it to standard output using a separate thread.
 */
  public void run(){
    BufferedReader reader=new BufferedReader(new InputStreamReader(stream));
    String text;
    try {
      while ((text=reader.readLine()) != null) {
        System.out.println(text);
      }
    }
 catch (    IOException e) {
      e.printStackTrace();
    }
 finally {
      try {
        reader.close();
      }
 catch (      IOException e) {
      }
    }
  }
}
