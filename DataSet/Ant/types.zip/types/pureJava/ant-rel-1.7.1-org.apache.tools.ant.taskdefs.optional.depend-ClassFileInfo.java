/** 
 * A class (struct) user to manage information about a class
 */
private static class ClassFileInfo {
  /** 
 * The file where the class file is stored in the file system 
 */
  private File absoluteFile;
  /** 
 * The Java class name of this class 
 */
  private String className;
  /** 
 * The source File containing this class 
 */
  private File sourceFile;
  /** 
 * if user has been warned about this file not having a source file 
 */
  private boolean isUserWarned=false;
}
