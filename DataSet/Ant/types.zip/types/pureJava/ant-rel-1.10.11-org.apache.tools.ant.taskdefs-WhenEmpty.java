/** 
 * Possible behaviors when there are no matching files for the task: "fail", "skip", or "create".
 */
public static class WhenEmpty extends EnumeratedAttribute {
  /** 
 * The string values for the enumerated value
 * @return the values
 */
  @Override public String[] getValues(){
    return new String[]{"fail","skip","create"};
  }
}
