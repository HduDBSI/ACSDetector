/** 
 * This class is used to manage the source files to be processed.
 */
public static class SourceFile {
  /** 
 * The source file 
 */
  private File file;
  /** 
 * Default constructor
 */
  public SourceFile(){
  }
  /** 
 * Constructor specifying the source file directly
 * @param file the source file
 */
  public SourceFile(  final File file){
    this.file=file;
  }
  /** 
 * Set the source file.
 * @param file the source file.
 */
  public void setFile(  final File file){
    this.file=file;
  }
  /** 
 * Get the source file.
 * @return the source file.
 */
  public File getFile(){
    return file;
  }
}
