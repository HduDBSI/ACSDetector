/** 
 * A class corresponding to the dname nested element.
 */
public static class DistinguishedName {
  private Vector params=new Vector();
  /** 
 * Create a param nested element.
 * @return a DnameParam object to be configured.
 */
  public Object createParam(){
    DnameParam param=new DnameParam();
    params.addElement(param);
    return param;
  }
  /** 
 * Get the nested parameters.
 * @return an enumeration of the nested parameters.
 */
  public Enumeration getParams(){
    return params.elements();
  }
  /** 
 * Generate a string rep of this distinguished name. The format is each of the parameters (name = value) separated by ','. This is used on the command line.
 * @return a string rep of this name
 */
  public String toString(){
    final int size=params.size();
    final StringBuffer sb=new StringBuffer();
    boolean firstPass=true;
    for (int i=0; i < size; i++) {
      if (!firstPass) {
        sb.append(" ,");
      }
      firstPass=false;
      final DnameParam param=(DnameParam)params.elementAt(i);
      sb.append(encode(param.getName()));
      sb.append('=');
      sb.append(encode(param.getValue()));
    }
    return sb.toString();
  }
  /** 
 * Encode a name or value. The encoded result is the same as the input string except that each ',' is replaced by a '\,'.
 * @param string the value to be encoded
 * @return the encoded value.
 */
  public String encode(  final String string){
    int end=string.indexOf(',');
    if (-1 == end) {
      return string;
    }
    final StringBuffer sb=new StringBuffer();
    int start=0;
    while (-1 != end) {
      sb.append(string.substring(start,end));
      sb.append("\\,");
      start=end + 1;
      end=string.indexOf(',',start);
    }
    sb.append(string.substring(start));
    return sb.toString();
  }
}
