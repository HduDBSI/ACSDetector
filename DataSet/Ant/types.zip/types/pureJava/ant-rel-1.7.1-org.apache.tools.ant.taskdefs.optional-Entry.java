/** 
 * Instance of this class represents nested elements of a task propertyfile.
 */
public static class Entry {
  private static final int DEFAULT_INT_VALUE=0;
  private static final String DEFAULT_DATE_VALUE="now";
  private static final String DEFAULT_STRING_VALUE="";
  private String key=null;
  private int type=Type.STRING_TYPE;
  private int operation=Operation.EQUALS_OPER;
  private String value=null;
  private String defaultValue=null;
  private String newValue=null;
  private String pattern=null;
  private int field=Calendar.DATE;
  /** 
 * Name of the property name/value pair
 * @param value the key.
 */
  public void setKey(  String value){
    this.key=value;
  }
  /** 
 * Value to set (=), to add (+) or subtract (-)
 * @param value the value.
 */
  public void setValue(  String value){
    this.value=value;
  }
  /** 
 * operation to apply. &quot;+&quot; or &quot;=&quot; (default) for all datatypes; &quot;-&quot; for date and int only)\.
 * @param value the operation enumerated value.
 */
  public void setOperation(  Operation value){
    this.operation=Operation.toOperation(value.getValue());
  }
  /** 
 * Regard the value as : int, date or string (default)
 * @param value the type enumerated value.
 */
  public void setType(  Type value){
    this.type=Type.toType(value.getValue());
  }
  /** 
 * Initial value to set for a property if it is not already defined in the property file. For type date, an additional keyword is allowed: &quot;now&quot;
 * @param value the default value.
 */
  public void setDefault(  String value){
    this.defaultValue=value;
  }
  /** 
 * For int and date type only. If present, Values will be parsed and formatted accordingly.
 * @param value the pattern to use.
 */
  public void setPattern(  String value){
    this.pattern=value;
  }
  /** 
 * The unit of the value to be applied to date +/- operations. Valid Values are: <ul> <li>millisecond</li> <li>second</li> <li>minute</li> <li>hour</li> <li>day (default)</li> <li>week</li> <li>month</li> <li>year</li> </ul> This only applies to date types using a +/- operation.
 * @param unit the unit enumerated value.
 * @since Ant 1.5
 */
  public void setUnit(  PropertyFile.Unit unit){
    field=unit.getCalendarField();
  }
  /** 
 * Apply the nested element to the properties.
 * @param props the properties to apply the entry on.
 * @throws BuildException if there is an error.
 */
  protected void executeOn(  Properties props) throws BuildException {
    checkParameters();
    String oldValue=(String)props.get(key);
    try {
      if (type == Type.INTEGER_TYPE) {
        executeInteger(oldValue);
      }
 else       if (type == Type.DATE_TYPE) {
        executeDate(oldValue);
      }
 else       if (type == Type.STRING_TYPE) {
        executeString(oldValue);
      }
 else {
        throw new BuildException("Unknown operation type: " + type);
      }
    }
 catch (    NullPointerException npe) {
      npe.printStackTrace();
    }
    if (newValue == null) {
      newValue="";
    }
    props.put(key,newValue);
  }
  /** 
 * Handle operations for type <code>date</code>.
 * @param oldValue the current value read from the property file or<code>null</code> if the <code>key</code> was not contained in the property file.
 */
  private void executeDate(  String oldValue) throws BuildException {
    Calendar currentValue=Calendar.getInstance();
    if (pattern == null) {
      pattern="yyyy/MM/dd HH:mm";
    }
    DateFormat fmt=new SimpleDateFormat(pattern);
    String currentStringValue=getCurrentValue(oldValue);
    if (currentStringValue == null) {
      currentStringValue=DEFAULT_DATE_VALUE;
    }
    if ("now".equals(currentStringValue)) {
      currentValue.setTime(new Date());
    }
 else {
      try {
        currentValue.setTime(fmt.parse(currentStringValue));
      }
 catch (      ParseException pe) {
      }
    }
    if (operation != Operation.EQUALS_OPER) {
      int offset=0;
      try {
        offset=Integer.parseInt(value);
        if (operation == Operation.DECREMENT_OPER) {
          offset=-1 * offset;
        }
      }
 catch (      NumberFormatException e) {
        throw new BuildException("Value not an integer on " + key);
      }
      currentValue.add(field,offset);
    }
    newValue=fmt.format(currentValue.getTime());
  }
  /** 
 * Handle operations for type <code>int</code>.
 * @param oldValue the current value read from the property file or<code>null</code> if the <code>key</code> was not contained in the property file.
 */
  private void executeInteger(  String oldValue) throws BuildException {
    int currentValue=DEFAULT_INT_VALUE;
    int newV=DEFAULT_INT_VALUE;
    DecimalFormat fmt=(pattern != null) ? new DecimalFormat(pattern) : new DecimalFormat();
    try {
      String curval=getCurrentValue(oldValue);
      if (curval != null) {
        currentValue=fmt.parse(curval).intValue();
      }
 else {
        currentValue=0;
      }
    }
 catch (    NumberFormatException nfe) {
    }
catch (    ParseException pe) {
    }
    if (operation == Operation.EQUALS_OPER) {
      newV=currentValue;
    }
 else {
      int operationValue=1;
      if (value != null) {
        try {
          operationValue=fmt.parse(value).intValue();
        }
 catch (        NumberFormatException nfe) {
        }
catch (        ParseException pe) {
        }
      }
      if (operation == Operation.INCREMENT_OPER) {
        newV=currentValue + operationValue;
      }
 else       if (operation == Operation.DECREMENT_OPER) {
        newV=currentValue - operationValue;
      }
    }
    this.newValue=fmt.format(newV);
  }
  /** 
 * Handle operations for type <code>string</code>.
 * @param oldValue the current value read from the property file or<code>null</code> if the <code>key</code> was not contained in the property file.
 */
  private void executeString(  String oldValue) throws BuildException {
    String newV=DEFAULT_STRING_VALUE;
    String currentValue=getCurrentValue(oldValue);
    if (currentValue == null) {
      currentValue=DEFAULT_STRING_VALUE;
    }
    if (operation == Operation.EQUALS_OPER) {
      newV=currentValue;
    }
 else     if (operation == Operation.INCREMENT_OPER) {
      newV=currentValue + value;
    }
    this.newValue=newV;
  }
  /** 
 * Check if parameter combinations can be supported
 * @todo make sure the 'unit' attribute is only specified on datefields
 */
  private void checkParameters() throws BuildException {
    if (type == Type.STRING_TYPE && operation == Operation.DECREMENT_OPER) {
      throw new BuildException("- is not supported for string " + "properties (key:" + key + ")");
    }
    if (value == null && defaultValue == null) {
      throw new BuildException("\"value\" and/or \"default\" " + "attribute must be specified (key:" + key + ")");
    }
    if (key == null) {
      throw new BuildException("key is mandatory");
    }
    if (type == Type.STRING_TYPE && pattern != null) {
      throw new BuildException("pattern is not supported for string " + "properties (key:" + key + ")");
    }
  }
  private String getCurrentValue(  String oldValue){
    String ret=null;
    if (operation == Operation.EQUALS_OPER) {
      if (value != null && defaultValue == null) {
        ret=value;
      }
      if (value == null && defaultValue != null && oldValue != null) {
        ret=oldValue;
      }
      if (value == null && defaultValue != null && oldValue == null) {
        ret=defaultValue;
      }
      if (value != null && defaultValue != null && oldValue != null) {
        ret=value;
      }
      if (value != null && defaultValue != null && oldValue == null) {
        ret=defaultValue;
      }
    }
 else {
      ret=(oldValue == null) ? defaultValue : oldValue;
    }
    return ret;
  }
  /** 
 * Enumerated attribute with the values "+", "-", "="
 */
public static class Operation extends EnumeratedAttribute {
    /** 
 * + 
 */
    public static final int INCREMENT_OPER=0;
    /** 
 * - 
 */
    public static final int DECREMENT_OPER=1;
    /** 
 * = 
 */
    public static final int EQUALS_OPER=2;
    /** 
 * {@inheritDoc}. 
 */
    public String[] getValues(){
      return new String[]{"+","-","="};
    }
    /** 
 * Convert string to index.
 * @param oper the string to convert.
 * @return the index.
 */
    public static int toOperation(    String oper){
      if ("+".equals(oper)) {
        return INCREMENT_OPER;
      }
 else       if ("-".equals(oper)) {
        return DECREMENT_OPER;
      }
      return EQUALS_OPER;
    }
  }
  /** 
 * Enumerated attribute with the values "int", "date" and "string".
 */
public static class Type extends EnumeratedAttribute {
    /** 
 * int 
 */
    public static final int INTEGER_TYPE=0;
    /** 
 * date 
 */
    public static final int DATE_TYPE=1;
    /** 
 * string 
 */
    public static final int STRING_TYPE=2;
    /** 
 * {@inheritDoc} 
 */
    public String[] getValues(){
      return new String[]{"int","date","string"};
    }
    /** 
 * Convert string to index.
 * @param type the string to convert.
 * @return the index.
 */
    public static int toType(    String type){
      if ("int".equals(type)) {
        return INTEGER_TYPE;
      }
 else       if ("date".equals(type)) {
        return DATE_TYPE;
      }
      return STRING_TYPE;
    }
  }
}
