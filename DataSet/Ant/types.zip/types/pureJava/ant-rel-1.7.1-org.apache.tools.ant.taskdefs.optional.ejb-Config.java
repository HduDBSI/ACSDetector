/** 
 * A class which contains the configuration state of the ejbjar task. This state is passed to the deployment tools for configuration
 */
static class Config {
  /** 
 * Stores a handle to the directory under which to search for class files
 */
  public File srcDir;
  /** 
 * Stores a handle to the directory under which to search for deployment descriptors
 */
  public File descriptorDir;
  /** 
 * Instance variable that marks the end of the 'basename' 
 */
  public String baseNameTerminator="-";
  /** 
 * Stores a handle to the destination EJB Jar file 
 */
  public String baseJarName;
  /** 
 * Instance variable that determines whether to use a package structure of a flat directory as the destination for the jar files.
 */
  public boolean flatDestDir=false;
  /** 
 * The classpath to use when loading classes
 */
  public Path classpath;
  /** 
 * A Fileset of support classes
 */
  public List supportFileSets=new ArrayList();
  /** 
 * The list of configured DTD locations
 */
  public ArrayList dtdLocations=new ArrayList();
  /** 
 * The naming scheme used to determine the generated jar name from the descriptor information
 */
  public NamingScheme namingScheme;
  /** 
 * The Manifest file
 */
  public File manifest;
  /** 
 * The dependency analyzer to use to add additional classes to the jar
 */
  public String analyzer;
}
