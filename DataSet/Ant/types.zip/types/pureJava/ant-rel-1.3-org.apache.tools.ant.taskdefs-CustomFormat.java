public class CustomFormat {
  private String propertyName;
  private String pattern;
  private int offset=0;
  private int field=Calendar.DATE;
  public CustomFormat(){
  }
  public void setProperty(  String propertyName){
    this.propertyName=propertyName;
  }
  public void setPattern(  String pattern){
    this.pattern=pattern;
  }
  public void setOffset(  int offset){
    this.offset=offset;
  }
  public void setUnit(  String unit){
    if (unit.equalsIgnoreCase("millisecond")) {
      field=Calendar.MILLISECOND;
    }
 else     if (unit.equalsIgnoreCase("second")) {
      field=Calendar.SECOND;
    }
 else     if (unit.equalsIgnoreCase("minute")) {
      field=Calendar.MINUTE;
    }
 else     if (unit.equalsIgnoreCase("hour")) {
      field=Calendar.HOUR_OF_DAY;
    }
 else     if (unit.equalsIgnoreCase("day")) {
      field=Calendar.DATE;
    }
 else     if (unit.equalsIgnoreCase("week")) {
      field=Calendar.WEEK_OF_YEAR;
    }
 else     if (unit.equalsIgnoreCase("month")) {
      field=Calendar.MONTH;
    }
 else     if (unit.equalsIgnoreCase("year")) {
      field=Calendar.YEAR;
    }
 else {
      throw new BuildException(unit + " is not a unit supported by the tstamp task");
    }
  }
  public void execute(  Project project,  Date date,  Location location){
    if (propertyName == null) {
      throw new BuildException("property attribute must be provided",location);
    }
    if (pattern == null) {
      throw new BuildException("pattern attribute must be provided",location);
    }
    SimpleDateFormat sdf=new SimpleDateFormat(pattern);
    if (offset != 0) {
      Calendar calendar=Calendar.getInstance();
      calendar.setTime(date);
      calendar.add(field,offset);
      date=calendar.getTime();
    }
    project.setProperty(propertyName,sdf.format(date));
  }
}
