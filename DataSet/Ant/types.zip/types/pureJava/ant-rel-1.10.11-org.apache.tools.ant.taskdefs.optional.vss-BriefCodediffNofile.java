/** 
 * Extension of EnumeratedAttribute to hold the values for style.
 */
public static class BriefCodediffNofile extends EnumeratedAttribute {
  /** 
 * Gets the list of allowable values.
 * @return The values.
 */
  public String[] getValues(){
    return new String[]{STYLE_BRIEF,STYLE_CODEDIFF,STYLE_NOFILE,STYLE_DEFAULT};
  }
}
