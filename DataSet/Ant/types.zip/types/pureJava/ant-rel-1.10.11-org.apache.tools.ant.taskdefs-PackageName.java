/** 
 * Used to track info about the packages to be javadoc'd
 */
public static class PackageName {
  /** 
 * The package name 
 */
  private String name;
  /** 
 * Set the name of the package
 * @param name the package name.
 */
  public void setName(  final String name){
    this.name=name.trim();
  }
  /** 
 * Get the package name.
 * @return the package's name.
 */
  public String getName(){
    return name;
  }
  /** 
 * Return a string rep for this object.
 * @return the package name.
 */
  @Override public String toString(){
    return getName();
  }
}
