/** 
 * The class corresponding to the sequential nested element. This is a simple task container.
 */
public static class NestedSequential implements TaskContainer {
  private List<Task> nested=new ArrayList<Task>();
  /** 
 * Add a task or type to the container.
 * @param task an unknown element.
 */
  public void addTask(  Task task){
    nested.add(task);
  }
  /** 
 * @return the list of unknown elements
 */
  public List<Task> getNested(){
    return nested;
  }
  /** 
 * A compare function to compare this with another NestedSequential. It calls similar on the nested unknown elements.
 * @param other the nested sequential to compare with.
 * @return true if they are similar, false otherwise
 */
  public boolean similar(  NestedSequential other){
    final int size=nested.size();
    if (size != other.nested.size()) {
      return false;
    }
    for (int i=0; i < size; ++i) {
      UnknownElement me=(UnknownElement)nested.get(i);
      UnknownElement o=(UnknownElement)other.nested.get(i);
      if (!me.similar(o)) {
        return false;
      }
    }
    return true;
  }
}
