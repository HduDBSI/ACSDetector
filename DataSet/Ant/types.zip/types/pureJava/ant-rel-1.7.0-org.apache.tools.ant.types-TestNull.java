public static class TestNull extends EnumeratedAttribute {
  public String[] getValues(){
    return null;
  }
}
