/** 
 * Internal interface used to create nested elements. Not documented  in detail for reasons of source code readability.
 */
private interface NestedCreator {
  Object create(  Object parent) throws InvocationTargetException, IllegalAccessException, InstantiationException ;
}
