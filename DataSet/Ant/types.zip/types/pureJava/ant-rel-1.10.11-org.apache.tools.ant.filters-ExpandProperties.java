/** 
 * Expands Ant properties, if any, in the data. <p>Example:</p> <pre>&lt;expandproperties/&gt;</pre> Or: <pre>&lt;filterreader classname=&quot;org.apache.tools.ant.filters.ExpandProperties&quot;/&gt;</pre>
 */
public final class ExpandProperties extends BaseFilterReader implements ChainableReader {
  private static final int EOF=-1;
  private char[] buffer;
  private int index;
  private PropertySet propertySet;
  /** 
 * Constructor for "dummy" instances.
 * @see BaseFilterReader#BaseFilterReader()
 */
  public ExpandProperties(){
    super();
  }
  /** 
 * Creates a new filtered reader.
 * @param in A Reader object providing the underlying stream.Must not be <code>null</code>.
 */
  public ExpandProperties(  final Reader in){
    super(in);
  }
  /** 
 * Restrict the expanded properties using a PropertySet.
 * @param propertySet replacement lookup
 */
  public void add(  PropertySet propertySet){
    if (this.propertySet != null) {
      throw new BuildException("expandproperties filter accepts only one propertyset");
    }
    this.propertySet=propertySet;
  }
  /** 
 * Returns the next character in the filtered stream. The original stream is first read in fully, and the Ant properties are expanded. The results of this expansion are then queued so they can be read character-by-character.
 * @return the next character in the resulting stream, or -1if the end of the resulting stream has been reached
 * @exception IOException if the underlying stream throws an IOExceptionduring reading
 */
  public int read() throws IOException {
    if (index > EOF) {
      if (buffer == null) {
        String data=readFully();
        Project project=getProject();
        GetProperty getProperty;
        if (propertySet == null) {
          getProperty=PropertyHelper.getPropertyHelper(project);
        }
 else {
          getProperty=propertySet.getProperties()::getProperty;
        }
        Object expanded=new ParseProperties(project,PropertyHelper.getPropertyHelper(project).getExpanders(),getProperty).parseProperties(data);
        buffer=expanded == null ? new char[0] : expanded.toString().toCharArray();
      }
      if (index < buffer.length) {
        return buffer[index++];
      }
      index=EOF;
    }
    return EOF;
  }
  /** 
 * Creates a new ExpandProperties filter using the passed in Reader for instantiation.
 * @param rdr A Reader object providing the underlying stream.Must not be <code>null</code>.
 * @return a new filter based on this configuration, but filteringthe specified reader
 */
  public Reader chain(  final Reader rdr){
    ExpandProperties newFilter=new ExpandProperties(rdr);
    newFilter.setProject(getProject());
    newFilter.add(propertySet);
    return newFilter;
  }
}
