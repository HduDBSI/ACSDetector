/** 
 * A list of possible values for the <code>setAction()</code> method. Possible values include: start and stop.
 */
public static class ActionChoices extends EnumeratedAttribute {
  private static final String[] VALUES={"start","stop"};
  /** 
 * @see EnumeratedAttribute#getValues() {@inheritDoc}.
 */
  public String[] getValues(){
    return VALUES;
  }
}
