/** 
 * A class corresponding to the group nested element.
 */
public class GroupArgument {
  private Html title;
  private Vector packages=new Vector();
  /** 
 * Constructor for GroupArgument 
 */
  public GroupArgument(){
  }
  /** 
 * Set the title attribute using a string.
 * @param src a <code>String</code> value
 */
  public void setTitle(  String src){
    Html h=new Html();
    h.addText(src);
    addTitle(h);
  }
  /** 
 * Set the title attribute using a nested Html value.
 * @param text a <code>Html</code> value
 */
  public void addTitle(  Html text){
    title=text;
  }
  /** 
 * Get the title.
 * @return the title
 */
  public String getTitle(){
    return title != null ? title.getText() : null;
  }
  /** 
 * Set the packages to Javadoc on.
 * @param src a comma separated list of packages
 */
  public void setPackages(  String src){
    StringTokenizer tok=new StringTokenizer(src,",");
    while (tok.hasMoreTokens()) {
      String p=tok.nextToken();
      PackageName pn=new PackageName();
      pn.setName(p);
      addPackage(pn);
    }
  }
  /** 
 * Add a package nested element.
 * @param pn a nested element specifing the package.
 */
  public void addPackage(  PackageName pn){
    packages.addElement(pn);
  }
  /** 
 * Get the packages as a collon separated list.
 * @return the packages as a string
 */
  public String getPackages(){
    StringBuffer p=new StringBuffer();
    for (int i=0; i < packages.size(); i++) {
      if (i > 0) {
        p.append(":");
      }
      p.append(packages.elementAt(i).toString());
    }
    return p.toString();
  }
}
