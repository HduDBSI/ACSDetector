/** 
 * inner timer class
 */
private static class Timer {
  long start=0;
  long stop=0;
  public Timer(){
    start();
  }
  public void start(){
    start=System.currentTimeMillis();
  }
  public void stop(){
    stop=System.currentTimeMillis();
  }
  public long time(){
    return stop - start;
  }
}
