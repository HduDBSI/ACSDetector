/** 
 * EnumeratedAttribute implementation supporting the Javadoc scoping values.
 */
public static class AccessType extends EnumeratedAttribute {
  /** 
 * @return the allowed values for the access type.
 */
  public String[] getValues(){
    return new String[]{"protected","public","package","private"};
  }
}
