public static class Variable {
  private String key, value;
  public Variable(){
    super();
  }
  public void setKey(  String key){
    this.key=key;
  }
  public void setValue(  String value){
    this.value=value;
  }
  public String getKey(){
    return this.key;
  }
  public String getValue(){
    return this.value;
  }
  public void setPath(  Path path){
    this.value=path.toString();
  }
  public void setFile(  java.io.File file){
    this.value=file.getAbsolutePath();
  }
  public String getContent() throws BuildException {
    if (key == null || value == null) {
      throw new BuildException("key and value must be specified for environment variables.");
    }
    StringBuffer sb=new StringBuffer(key.trim());
    sb.append("=").append(value.trim());
    return sb.toString();
  }
}
