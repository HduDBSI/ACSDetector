/** 
 * Enumerated attribute with the values "+", "-", "="
 */
public static class Operation extends EnumeratedAttribute {
  /** 
 * + 
 */
  public static final int INCREMENT_OPER=0;
  /** 
 * - 
 */
  public static final int DECREMENT_OPER=1;
  /** 
 * = 
 */
  public static final int EQUALS_OPER=2;
  /** 
 * {@inheritDoc}. 
 */
  public String[] getValues(){
    return new String[]{"+","-","="};
  }
  /** 
 * Convert string to index.
 * @param oper the string to convert.
 * @return the index.
 */
  public static int toOperation(  String oper){
    if ("+".equals(oper)) {
      return INCREMENT_OPER;
    }
 else     if ("-".equals(oper)) {
      return DECREMENT_OPER;
    }
    return EQUALS_OPER;
  }
}
