/** 
 * internal class allowing to read the contents of a remote file system using the FTP protocol used in particular for ftp get operations differences with DirectoryScanner "" (the root of the fileset) is never included in the included directories followSymlinks defaults to false
 */
protected class FTPDirectoryScanner extends DirectoryScanner {
  protected FTPClient ftp=null;
  private String rootPath=null;
  /** 
 * since ant 1.6 this flag should be set to true on UNIX and can save scanning time
 */
  private boolean remoteSystemCaseSensitive=false;
  private boolean remoteSensitivityChecked=false;
  /** 
 * constructor
 * @param ftp  ftpclient object
 */
  public FTPDirectoryScanner(  FTPClient ftp){
    super();
    this.ftp=ftp;
    this.setFollowSymlinks(false);
  }
  /** 
 * scans the remote directory, storing internally the included files, directories, ...
 */
  public void scan(){
    if (includes == null) {
      includes=new String[1];
      includes[0]="**";
    }
    if (excludes == null) {
      excludes=new String[0];
    }
    filesIncluded=new Vector();
    filesNotIncluded=new Vector();
    filesExcluded=new Vector();
    dirsIncluded=new Vector();
    dirsNotIncluded=new Vector();
    dirsExcluded=new Vector();
    try {
      String cwd=ftp.printWorkingDirectory();
      forceRemoteSensitivityCheck();
      checkIncludePatterns();
      clearCaches();
      ftp.changeWorkingDirectory(cwd);
    }
 catch (    IOException e) {
      throw new BuildException("Unable to scan FTP server: ",e);
    }
  }
  /** 
 * this routine is actually checking all the include patterns in order to avoid scanning everything under base dir
 * @since ant1.6
 */
  private void checkIncludePatterns(){
    Hashtable newroots=new Hashtable();
    for (int icounter=0; icounter < includes.length; icounter++) {
      String newpattern=SelectorUtils.rtrimWildcardTokens(includes[icounter]);
      newroots.put(newpattern,includes[icounter]);
    }
    if (remotedir == null) {
      try {
        remotedir=ftp.printWorkingDirectory();
      }
 catch (      IOException e) {
        throw new BuildException("could not read current ftp directory",getLocation());
      }
    }
    AntFTPFile baseFTPFile=new AntFTPRootFile(ftp,remotedir);
    rootPath=baseFTPFile.getAbsolutePath();
    if (newroots.containsKey("")) {
      scandir(rootPath,"",true);
    }
 else {
      Enumeration enum2=newroots.keys();
      while (enum2.hasMoreElements()) {
        String currentelement=(String)enum2.nextElement();
        String originalpattern=(String)newroots.get(currentelement);
        AntFTPFile myfile=new AntFTPFile(baseFTPFile,currentelement);
        boolean isOK=true;
        boolean traversesSymlinks=false;
        String path=null;
        if (myfile.exists()) {
          forceRemoteSensitivityCheck();
          if (remoteSensitivityChecked && remoteSystemCaseSensitive && isFollowSymlinks()) {
            path=myfile.getFastRelativePath();
          }
 else {
            try {
              path=myfile.getRelativePath();
              traversesSymlinks=myfile.isTraverseSymlinks();
            }
 catch (            IOException be) {
              throw new BuildException(be,getLocation());
            }
catch (            BuildException be) {
              isOK=false;
            }
          }
        }
 else {
          isOK=false;
        }
        if (isOK) {
          currentelement=path.replace(remoteFileSep.charAt(0),File.separatorChar);
          if (!isFollowSymlinks() && traversesSymlinks) {
            continue;
          }
          if (myfile.isDirectory()) {
            if (isIncluded(currentelement) && currentelement.length() > 0) {
              accountForIncludedDir(currentelement,myfile,true);
            }
 else {
              if (currentelement.length() > 0) {
                if (currentelement.charAt(currentelement.length() - 1) != File.separatorChar) {
                  currentelement=currentelement + File.separatorChar;
                }
              }
              scandir(myfile.getAbsolutePath(),currentelement,true);
            }
          }
 else {
            if (isCaseSensitive && originalpattern.equals(currentelement)) {
              accountForIncludedFile(currentelement);
            }
 else             if (!isCaseSensitive && originalpattern.equalsIgnoreCase(currentelement)) {
              accountForIncludedFile(currentelement);
            }
          }
        }
      }
    }
  }
  /** 
 * scans a particular directory
 * @param dir directory to scan
 * @param vpath  relative path to the base directory of the remote filesetalways ended with a File.separator
 * @param fast seems to be always true in practice
 */
  protected void scandir(  String dir,  String vpath,  boolean fast){
    if (fast && hasBeenScanned(vpath)) {
      return;
    }
    try {
      if (!ftp.changeWorkingDirectory(dir)) {
        return;
      }
      String completePath=null;
      if (!vpath.equals("")) {
        completePath=rootPath + remoteFileSep + vpath.replace(File.separatorChar,remoteFileSep.charAt(0));
      }
 else {
        completePath=rootPath;
      }
      FTPFile[] newfiles=listFiles(completePath,false);
      if (newfiles == null) {
        ftp.changeToParentDirectory();
        return;
      }
      for (int i=0; i < newfiles.length; i++) {
        FTPFile file=newfiles[i];
        if (file != null && !file.getName().equals(".") && !file.getName().equals("..")) {
          if (isFunctioningAsDirectory(ftp,dir,file)) {
            String name=vpath + file.getName();
            boolean slowScanAllowed=true;
            if (!isFollowSymlinks() && file.isSymbolicLink()) {
              dirsExcluded.addElement(name);
              slowScanAllowed=false;
            }
 else             if (isIncluded(name)) {
              accountForIncludedDir(name,new AntFTPFile(ftp,file,completePath),fast);
            }
 else {
              dirsNotIncluded.addElement(name);
              if (fast && couldHoldIncluded(name)) {
                scandir(file.getName(),name + File.separator,fast);
              }
            }
            if (!fast && slowScanAllowed) {
              scandir(file.getName(),name + File.separator,fast);
            }
          }
 else {
            String name=vpath + file.getName();
            if (!isFollowSymlinks() && file.isSymbolicLink()) {
              filesExcluded.addElement(name);
            }
 else             if (isFunctioningAsFile(ftp,dir,file)) {
              accountForIncludedFile(name);
            }
          }
        }
      }
      ftp.changeToParentDirectory();
    }
 catch (    IOException e) {
      throw new BuildException("Error while communicating with FTP " + "server: ",e);
    }
  }
  /** 
 * process included file
 * @param name  path of the file relative to the directory of the fileset
 */
  private void accountForIncludedFile(  String name){
    if (!filesIncluded.contains(name) && !filesExcluded.contains(name)) {
      if (isIncluded(name)) {
        if (!isExcluded(name)) {
          filesIncluded.addElement(name);
        }
 else {
          filesExcluded.addElement(name);
        }
      }
 else {
        filesNotIncluded.addElement(name);
      }
    }
  }
  /** 
 * @param name path of the directory relative to the directory ofthe fileset
 * @param file directory as file
 * @param fast
 */
  private void accountForIncludedDir(  String name,  AntFTPFile file,  boolean fast){
    if (!dirsIncluded.contains(name) && !dirsExcluded.contains(name)) {
      if (!isExcluded(name)) {
        if (fast) {
          if (file.isSymbolicLink()) {
            try {
              file.getClient().changeWorkingDirectory(file.curpwd);
            }
 catch (            IOException ioe) {
              throw new BuildException("could not change directory to curpwd");
            }
            scandir(file.getLink(),name + File.separator,fast);
          }
 else {
            try {
              file.getClient().changeWorkingDirectory(file.curpwd);
            }
 catch (            IOException ioe) {
              throw new BuildException("could not change directory to curpwd");
            }
            scandir(file.getName(),name + File.separator,fast);
          }
        }
        dirsIncluded.addElement(name);
      }
 else {
        dirsExcluded.addElement(name);
        if (fast && couldHoldIncluded(name)) {
          try {
            file.getClient().changeWorkingDirectory(file.curpwd);
          }
 catch (          IOException ioe) {
            throw new BuildException("could not change directory to curpwd");
          }
          scandir(file.getName(),name + File.separator,fast);
        }
      }
    }
  }
  /** 
 * temporary table to speed up the various scanning methods below
 * @since Ant 1.6
 */
  private Map fileListMap=new HashMap();
  /** 
 * List of all scanned directories.
 * @since Ant 1.6
 */
  private Set scannedDirs=new HashSet();
  /** 
 * Has the directory with the given path relative to the base directory already been scanned? <p>Registers the given directory as scanned as a side effect.</p>
 * @since Ant 1.6
 */
  private boolean hasBeenScanned(  String vpath){
    return !scannedDirs.add(vpath);
  }
  /** 
 * Clear internal caches.
 * @since Ant 1.6
 */
  private void clearCaches(){
    fileListMap.clear();
    scannedDirs.clear();
  }
  /** 
 * list the files present in one directory.
 * @param directory full path on the remote side
 * @param changedir if true change to directory directory before listing
 * @return array of FTPFile
 */
  public FTPFile[] listFiles(  String directory,  boolean changedir){
    String currentPath=directory;
    if (changedir) {
      try {
        boolean result=ftp.changeWorkingDirectory(directory);
        if (!result) {
          return null;
        }
        currentPath=ftp.printWorkingDirectory();
      }
 catch (      IOException ioe) {
        throw new BuildException(ioe,getLocation());
      }
    }
    if (fileListMap.containsKey(currentPath)) {
      getProject().log("filelist map used in listing files",Project.MSG_DEBUG);
      return ((FTPFile[])fileListMap.get(currentPath));
    }
    FTPFile[] result=null;
    try {
      result=ftp.listFiles();
    }
 catch (    IOException ioe) {
      throw new BuildException(ioe,getLocation());
    }
    fileListMap.put(currentPath,result);
    if (!remoteSensitivityChecked) {
      checkRemoteSensitivity(result,directory);
    }
    return result;
  }
  private void forceRemoteSensitivityCheck(){
    if (!remoteSensitivityChecked) {
      try {
        checkRemoteSensitivity(ftp.listFiles(),ftp.printWorkingDirectory());
      }
 catch (      IOException ioe) {
        throw new BuildException(ioe,getLocation());
      }
    }
  }
  /** 
 * cd into one directory and list the files present in one directory.
 * @param directory full path on the remote side
 * @return array of FTPFile
 */
  public FTPFile[] listFiles(  String directory){
    return listFiles(directory,true);
  }
  private void checkRemoteSensitivity(  FTPFile[] array,  String directory){
    if (array == null) {
      return;
    }
    boolean candidateFound=false;
    String target=null;
    for (int icounter=0; icounter < array.length; icounter++) {
      if (array[icounter] != null && array[icounter].isDirectory()) {
        if (!array[icounter].getName().equals(".") && !array[icounter].getName().equals("..")) {
          candidateFound=true;
          target=fiddleName(array[icounter].getName());
          getProject().log("will try to cd to " + target + " where a directory called "+ array[icounter].getName()+ " exists",Project.MSG_DEBUG);
          for (int pcounter=0; pcounter < array.length; pcounter++) {
            if (array[pcounter] != null && pcounter != icounter && target.equals(array[pcounter].getName())) {
              candidateFound=false;
            }
          }
          if (candidateFound) {
            break;
          }
        }
      }
    }
    if (candidateFound) {
      try {
        getProject().log("testing case sensitivity, attempting to cd to " + target,Project.MSG_DEBUG);
        remoteSystemCaseSensitive=!ftp.changeWorkingDirectory(target);
      }
 catch (      IOException ioe) {
        remoteSystemCaseSensitive=true;
      }
 finally {
        try {
          ftp.changeWorkingDirectory(directory);
        }
 catch (        IOException ioe) {
          throw new BuildException(ioe,getLocation());
        }
      }
      getProject().log("remote system is case sensitive : " + remoteSystemCaseSensitive,Project.MSG_VERBOSE);
      remoteSensitivityChecked=true;
    }
  }
  private String fiddleName(  String origin){
    StringBuffer result=new StringBuffer();
    for (int icounter=0; icounter < origin.length(); icounter++) {
      if (Character.isLowerCase(origin.charAt(icounter))) {
        result.append(Character.toUpperCase(origin.charAt(icounter)));
      }
 else       if (Character.isUpperCase(origin.charAt(icounter))) {
        result.append(Character.toLowerCase(origin.charAt(icounter)));
      }
 else {
        result.append(origin.charAt(icounter));
      }
    }
    return result.toString();
  }
  /** 
 * an AntFTPFile is a representation of a remote file
 * @since Ant 1.6
 */
protected class AntFTPFile {
    /** 
 * ftp client
 */
    private FTPClient client;
    /** 
 * parent directory of the file
 */
    private String curpwd;
    /** 
 * the file itself
 */
    private FTPFile ftpFile;
    /** 
 */
    private AntFTPFile parent=null;
    private boolean relativePathCalculated=false;
    private boolean traversesSymlinks=false;
    private String relativePath="";
    /** 
 * constructor
 * @param client ftp client variable
 * @param ftpFile the file
 * @param curpwd absolute remote path where the file is found
 */
    public AntFTPFile(    FTPClient client,    FTPFile ftpFile,    String curpwd){
      this.client=client;
      this.ftpFile=ftpFile;
      this.curpwd=curpwd;
    }
    /** 
 * other constructor
 * @param parent the parent file
 * @param path  a relative path to the parent file
 */
    public AntFTPFile(    AntFTPFile parent,    String path){
      this.parent=parent;
      this.client=parent.client;
      Vector pathElements=SelectorUtils.tokenizePath(path);
      try {
        boolean result=this.client.changeWorkingDirectory(parent.getAbsolutePath());
        if (!result) {
          return;
        }
        this.curpwd=parent.getAbsolutePath();
      }
 catch (      IOException ioe) {
        throw new BuildException("could not change working dir to " + parent.curpwd);
      }
      for (int fcount=0; fcount < pathElements.size() - 1; fcount++) {
        String currentPathElement=(String)pathElements.elementAt(fcount);
        try {
          boolean result=this.client.changeWorkingDirectory(currentPathElement);
          if (!result && !isCaseSensitive() && (remoteSystemCaseSensitive || !remoteSensitivityChecked)) {
            currentPathElement=findPathElementCaseUnsensitive(this.curpwd,currentPathElement);
            if (currentPathElement == null) {
              return;
            }
          }
 else           if (!result) {
            return;
          }
          this.curpwd=this.curpwd + remoteFileSep + currentPathElement;
        }
 catch (        IOException ioe) {
          throw new BuildException("could not change working dir to " + (String)pathElements.elementAt(fcount) + " from "+ this.curpwd);
        }
      }
      String lastpathelement=(String)pathElements.elementAt(pathElements.size() - 1);
      FTPFile[] theFiles=listFiles(this.curpwd);
      this.ftpFile=getFile(theFiles,lastpathelement);
    }
    /** 
 * find a file in a directory in case unsensitive way
 * @param parentPath        where we are
 * @param soughtPathElement what is being sought
 * @return                  the first file found or null if not found
 */
    private String findPathElementCaseUnsensitive(    String parentPath,    String soughtPathElement){
      FTPFile[] theFiles=listFiles(parentPath,false);
      if (theFiles == null) {
        return null;
      }
      for (int icounter=0; icounter < theFiles.length; icounter++) {
        if (theFiles[icounter] != null && theFiles[icounter].getName().equalsIgnoreCase(soughtPathElement)) {
          return theFiles[icounter].getName();
        }
      }
      return null;
    }
    /** 
 * find out if the file exists
 * @return  true if the file exists
 */
    public boolean exists(){
      return (ftpFile != null);
    }
    /** 
 * if the file is a symbolic link, find out to what it is pointing
 * @return the target of the symbolic link
 */
    public String getLink(){
      return ftpFile.getLink();
    }
    /** 
 * get the name of the file
 * @return the name of the file
 */
    public String getName(){
      return ftpFile.getName();
    }
    /** 
 * find out the absolute path of the file
 * @return absolute path as string
 */
    public String getAbsolutePath(){
      return curpwd + remoteFileSep + ftpFile.getName();
    }
    /** 
 * find out the relative path assuming that the path used to construct this AntFTPFile was spelled properly with regards to case. This is OK on a case sensitive system such as UNIX
 * @return relative path
 */
    public String getFastRelativePath(){
      String absPath=getAbsolutePath();
      if (absPath.indexOf(rootPath + remoteFileSep) == 0) {
        return absPath.substring(rootPath.length() + remoteFileSep.length());
      }
      return null;
    }
    /** 
 * find out the relative path to the rootPath of the enclosing scanner. this relative path is spelled exactly like on disk, for instance if the AntFTPFile has been instantiated as ALPHA, but the file is really called alpha, this method will return alpha. If a symbolic link is encountered, it is followed, but the name of the link rather than the name of the target is returned. (ie does not behave like File.getCanonicalPath())
 * @return                relative path, separated by remoteFileSep
 * @throws IOException    if a change directory fails, ...
 * @throws BuildException if one of the components of the relative path cannotbe found.
 */
    public String getRelativePath() throws IOException, BuildException {
      if (!relativePathCalculated) {
        if (parent != null) {
          traversesSymlinks=parent.isTraverseSymlinks();
          relativePath=getRelativePath(parent.getAbsolutePath(),parent.getRelativePath());
        }
 else {
          relativePath=getRelativePath(rootPath,"");
          relativePathCalculated=true;
        }
      }
      return relativePath;
    }
    /** 
 * get thge relative path of this file
 * @param currentPath          base path
 * @param currentRelativePath  relative path of the base path with regards to remote dir
 * @return relative path
 */
    private String getRelativePath(    String currentPath,    String currentRelativePath){
      Vector pathElements=SelectorUtils.tokenizePath(getAbsolutePath(),remoteFileSep);
      Vector pathElements2=SelectorUtils.tokenizePath(currentPath,remoteFileSep);
      String relPath=currentRelativePath;
      for (int pcount=pathElements2.size(); pcount < pathElements.size(); pcount++) {
        String currentElement=(String)pathElements.elementAt(pcount);
        FTPFile[] theFiles=listFiles(currentPath);
        FTPFile theFile=null;
        if (theFiles != null) {
          theFile=getFile(theFiles,currentElement);
        }
        if (!relPath.equals("")) {
          relPath=relPath + remoteFileSep;
        }
        if (theFile == null) {
          relPath=relPath + currentElement;
          currentPath=currentPath + remoteFileSep + currentElement;
          log("Hidden file " + relPath + " assumed to not be a symlink.",Project.MSG_VERBOSE);
        }
 else {
          traversesSymlinks=traversesSymlinks || theFile.isSymbolicLink();
          relPath=relPath + theFile.getName();
          currentPath=currentPath + remoteFileSep + theFile.getName();
        }
      }
      return relPath;
    }
    /** 
 * find a file matching a string in an array of FTPFile. This method will find "alpha" when requested for "ALPHA" if and only if the caseSensitive attribute is set to false. When caseSensitive is set to true, only the exact match is returned.
 * @param theFiles  array of files
 * @param lastpathelement  the file name being sought
 * @return null if the file cannot be found, otherwise return the matching file.
 */
    public FTPFile getFile(    FTPFile[] theFiles,    String lastpathelement){
      if (theFiles == null) {
        return null;
      }
      for (int fcount=0; fcount < theFiles.length; fcount++) {
        if (theFiles[fcount] != null) {
          if (theFiles[fcount].getName().equals(lastpathelement)) {
            return theFiles[fcount];
          }
 else           if (!isCaseSensitive() && theFiles[fcount].getName().equalsIgnoreCase(lastpathelement)) {
            return theFiles[fcount];
          }
        }
      }
      return null;
    }
    /** 
 * tell if a file is a directory. note that it will return false for symbolic links pointing to directories.
 * @return <code>true</code> for directories
 */
    public boolean isDirectory(){
      return ftpFile.isDirectory();
    }
    /** 
 * tell if a file is a symbolic link
 * @return <code>true</code> for symbolic links
 */
    public boolean isSymbolicLink(){
      return ftpFile.isSymbolicLink();
    }
    /** 
 * return the attached FTP client object. Warning : this instance is really shared with the enclosing class.
 * @return  FTP client
 */
    protected FTPClient getClient(){
      return client;
    }
    /** 
 * sets the current path of an AntFTPFile
 * @param curpwd the current path one wants to set
 */
    protected void setCurpwd(    String curpwd){
      this.curpwd=curpwd;
    }
    /** 
 * returns the path of the directory containing the AntFTPFile. of the full path of the file itself in case of AntFTPRootFile
 * @return parent directory of the AntFTPFile
 */
    public String getCurpwd(){
      return curpwd;
    }
    /** 
 * find out if a symbolic link is encountered in the relative path of this file from rootPath.
 * @return <code>true</code> if a symbolic link is encountered in the relative path.
 * @throws IOException if one of the change directory or directory listing operationsfails
 * @throws BuildException if a path component in the relative path cannot be found.
 */
    public boolean isTraverseSymlinks() throws IOException, BuildException {
      if (!relativePathCalculated) {
        getRelativePath();
      }
      return traversesSymlinks;
    }
    /** 
 * Get a string rep of this object.
 * @return a string containing the pwd and the file.
 */
    public String toString(){
      return "AntFtpFile: " + curpwd + "%"+ ftpFile;
    }
  }
  /** 
 * special class to represent the remote directory itself
 * @since Ant 1.6
 */
protected class AntFTPRootFile extends AntFTPFile {
    private String remotedir;
    /** 
 * constructor
 * @param aclient FTP client
 * @param remotedir remote directory
 */
    public AntFTPRootFile(    FTPClient aclient,    String remotedir){
      super(aclient,null,remotedir);
      this.remotedir=remotedir;
      try {
        this.getClient().changeWorkingDirectory(this.remotedir);
        this.setCurpwd(this.getClient().printWorkingDirectory());
      }
 catch (      IOException ioe) {
        throw new BuildException(ioe,getLocation());
      }
    }
    /** 
 * find the absolute path
 * @return absolute path
 */
    public String getAbsolutePath(){
      return this.getCurpwd();
    }
    /** 
 * find out the relative path to root
 * @return empty string
 * @throws BuildException actually never
 * @throws IOException  actually never
 */
    public String getRelativePath() throws BuildException, IOException {
      return "";
    }
  }
}
