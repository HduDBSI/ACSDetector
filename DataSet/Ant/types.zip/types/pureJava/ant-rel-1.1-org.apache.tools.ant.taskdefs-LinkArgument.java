public class LinkArgument {
  private String href;
  private boolean offline=false;
  private String packagelistLoc;
  public LinkArgument(){
  }
  public void setHref(  String hr){
    href=hr;
  }
  public String getHref(){
    return href;
  }
  public void setPackagelistLoc(  String src){
    packagelistLoc=src;
  }
  public String getPackagelistLoc(){
    return packagelistLoc;
  }
  public void setOffline(  String offline){
    this.offline=Project.toBoolean(offline);
  }
  public boolean isLinkOffline(){
    return offline;
  }
}
