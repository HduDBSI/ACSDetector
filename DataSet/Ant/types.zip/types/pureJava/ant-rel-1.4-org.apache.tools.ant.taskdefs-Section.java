/** 
 * Class to represent an individual section in the  Manifest. A section consists of a set of attribute values, separated from other sections by a blank line.
 */
static public class Section {
  private Vector warnings=new Vector();
  /** 
 * The section's name if any. The main section in a manifest is unnamed.
 */
  private String name=null;
  /** 
 * The section's attributes.
 */
  private Hashtable attributes=new Hashtable();
  /** 
 * Set the Section's name
 * @param name the section's name
 */
  public void setName(  String name){
    this.name=name;
  }
  /** 
 * Get the Section's name
 * @return the section's name.
 */
  public String getName(){
    return name;
  }
  /** 
 * Read a section through a reader 
 * @param reader the reader from which the section is read
 * @return the name of the next section if it has been read as part of this section - This only happens if the Manifest is malformed.
 * @throws ManifestException if the section is not valid according to the JAR spec
 * @throws IOException if the section cannot be read from the reader.
 */
  public String read(  BufferedReader reader) throws ManifestException, IOException {
    Attribute attribute=null;
    while (true) {
      String line=reader.readLine();
      if (line == null || line.length() == 0) {
        return null;
      }
      if (line.charAt(0) == ' ') {
        if (attribute == null) {
          throw new ManifestException("Can't start an attribute with a continuation line " + line);
        }
        attribute.addContinuation(line);
      }
 else {
        attribute=new Attribute(line);
        String nameReadAhead=addAttributeAndCheck(attribute);
        if (nameReadAhead != null) {
          return nameReadAhead;
        }
      }
    }
  }
  /** 
 * Merge in another section
 * @param section the section to be merged with this one.
 * @throws ManifestException if the sections cannot be merged.
 */
  public void merge(  Section section) throws ManifestException {
    if (name == null && section.getName() != null || name != null && !(name.equalsIgnoreCase(section.getName()))) {
      throw new ManifestException("Unable to merge sections with different names");
    }
    for (Enumeration e=section.attributes.keys(); e.hasMoreElements(); ) {
      String attributeName=(String)e.nextElement();
      attributes.put(attributeName,section.attributes.get(attributeName));
    }
    for (Enumeration e=section.warnings.elements(); e.hasMoreElements(); ) {
      warnings.addElement(e.nextElement());
    }
  }
  /** 
 * Write the section out to a print writer.
 * @param writer the Writer to which the section is written
 * @throws IOException if the section cannot be written
 */
  public void write(  PrintWriter writer) throws IOException {
    if (name != null) {
      Attribute nameAttr=new Attribute(ATTRIBUTE_NAME,name);
      nameAttr.write(writer);
    }
    for (Enumeration e=attributes.elements(); e.hasMoreElements(); ) {
      Attribute attribute=(Attribute)e.nextElement();
      attribute.write(writer);
    }
    writer.println();
  }
  /** 
 * Get the value of the attribute with the name given.
 * @param attributeName the name of the attribute to be returned.
 * @return the attribute's value or null if the attribute does not existin the section
 */
  public String getAttributeValue(  String attributeName){
    Attribute attribute=(Attribute)attributes.get(attributeName.toLowerCase());
    if (attribute == null) {
      return null;
    }
    return attribute.getValue();
  }
  /** 
 * Remove tge given attribute from the section 
 * @param attributeName the name of the attribute to be removed.
 */
  public void removeAttribute(  String attributeName){
    attributes.remove(attributeName.toLowerCase());
  }
  public void addConfiguredAttribute(  Attribute attribute) throws ManifestException {
    String check=addAttributeAndCheck(attribute);
    if (check != null) {
      throw new BuildException("Use the \"name\" attribute of the <section> element rather than using " + "the \"Name\" attribute");
    }
  }
  /** 
 * Add an attribute to the section
 * @param attribute the attribute to be added.
 * @return the value of the attribute if it is a name attribute - null other wise
 * @throws ManifestException if the attribute already exists in this section.
 */
  public String addAttributeAndCheck(  Attribute attribute) throws ManifestException {
    if (attribute.getName() == null || attribute.getValue() == null) {
      throw new BuildException("Attributes must have name and value");
    }
    if (attribute.getName().equalsIgnoreCase(ATTRIBUTE_NAME)) {
      warnings.addElement("\"" + ATTRIBUTE_NAME + "\" attributes should not occur in the "+ "main section and must be the first element in all "+ "other sections: \""+ attribute.getName()+ ": "+ attribute.getValue()+ "\"");
      return attribute.getValue();
    }
    if (attribute.getName().toLowerCase().startsWith(ATTRIBUTE_FROM.toLowerCase())) {
      warnings.addElement("Manifest attributes should not start with \"" + ATTRIBUTE_FROM + "\" in \""+ attribute.getName()+ ": "+ attribute.getValue()+ "\"");
    }
 else     if (attributes.containsKey(attribute.getName().toLowerCase())) {
      throw new ManifestException("The attribute \"" + attribute.getName() + "\" may not "+ "occur more than once in the same section");
    }
 else {
      attributes.put(attribute.getName().toLowerCase(),attribute);
    }
    return null;
  }
  public Enumeration getWarnings(){
    return warnings.elements();
  }
  public boolean equals(  Object rhs){
    if (!(rhs instanceof Section)) {
      return false;
    }
    Section rhsSection=(Section)rhs;
    if (attributes.size() != rhsSection.attributes.size()) {
      return false;
    }
    for (Enumeration e=attributes.elements(); e.hasMoreElements(); ) {
      Attribute attribute=(Attribute)e.nextElement();
      Attribute rshAttribute=(Attribute)rhsSection.attributes.get(attribute.getName().toLowerCase());
      if (!attribute.equals(rshAttribute)) {
        return false;
      }
    }
    return true;
  }
}
