/** 
 * A Float CP Info
 */
public class FloatCPInfo extends ConstantCPInfo {
  /** 
 * Constructor.  
 */
  public FloatCPInfo(){
    super(CONSTANT_FLOAT,1);
  }
  /** 
 * read a constant pool entry from a class stream.
 * @param cpStream the DataInputStream which contains the constant poolentry to be read.
 * @exception IOException if there is a problem reading the entry fromthe stream.
 */
  public void read(  DataInputStream cpStream) throws IOException {
    setValue(new Float(cpStream.readFloat()));
  }
  /** 
 * Print a readable version of the constant pool entry.
 * @return the string representation of this constant pool entry.
 */
  public String toString(){
    return "Float Constant Pool Entry: " + getValue();
  }
}
