/** 
 * Enumerated attribute with the values "plain", "xml", "brief" and "failure". <p>Use to enumerate options for <code>type</code> attribute.</p>
 */
public static class TypeAttribute extends EnumeratedAttribute {
  /** 
 * {@inheritDoc}. 
 */
  @Override public String[] getValues(){
    return new String[]{"plain","xml","brief","failure"};
  }
}
