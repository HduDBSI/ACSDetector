public static class DistinguishedName {
  private String name;
  private String path;
  private Vector params=new Vector();
  public Object createParam(){
    DnameParam param=new DnameParam();
    params.addElement(param);
    return param;
  }
  public Enumeration getParams(){
    return params.elements();
  }
  public String toString(){
    final int size=params.size();
    final StringBuffer sb=new StringBuffer();
    boolean firstPass=true;
    for (int i=0; i < size; i++) {
      if (!firstPass) {
        sb.append(" ,");
      }
      firstPass=false;
      final DnameParam param=(DnameParam)params.elementAt(i);
      sb.append(encode(param.getName()));
      sb.append('=');
      sb.append(encode(param.getValue()));
    }
    return sb.toString();
  }
  public String encode(  final String string){
    int end=string.indexOf(',');
    if (-1 == end)     return string;
    final StringBuffer sb=new StringBuffer();
    int start=0;
    while (-1 != end) {
      sb.append(string.substring(start,end));
      sb.append("\\,");
      start=end + 1;
      end=string.indexOf(',',start);
    }
    sb.append(string.substring(start));
    return sb.toString();
  }
}
