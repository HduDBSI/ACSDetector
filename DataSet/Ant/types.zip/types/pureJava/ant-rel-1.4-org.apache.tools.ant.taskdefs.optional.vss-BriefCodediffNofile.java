public static class BriefCodediffNofile extends EnumeratedAttribute {
  public String[] getValues(){
    return new String[]{"brief","codediff","nofile","default"};
  }
}
