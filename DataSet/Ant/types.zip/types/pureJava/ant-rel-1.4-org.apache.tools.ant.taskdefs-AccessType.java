public static class AccessType extends EnumeratedAttribute {
  public String[] getValues(){
    return new String[]{"protected","public","package","private"};
  }
}
