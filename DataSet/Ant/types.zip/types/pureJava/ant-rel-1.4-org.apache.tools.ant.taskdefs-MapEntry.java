/** 
 * Helper class, holds the nested <map> values.  Elements will look like this: &lt;map from="d:" to="/foo"/> <p> When running on windows, the prefix comparison will be case insensitive.
 */
public class MapEntry {
  /** 
 * Set the "from" attribute of the map entry
 */
  public void setFrom(  String from){
    this.from=from;
  }
  /** 
 * Set the "to" attribute of the map entry
 */
  public void setTo(  String to){
    this.to=to;
  }
  /** 
 * Apply this map entry to a given path element
 * @param elem Path element to process
 * @return String Updated path element after mapping
 */
  public String apply(  String elem){
    if (from == null || to == null) {
      throw new BuildException("Both 'from' and 'to' must be set in a map entry");
    }
    String cmpElem=onWindows ? elem.toLowerCase() : elem;
    String cmpFrom=onWindows ? from.toLowerCase() : from;
    if (cmpElem.startsWith(cmpFrom)) {
      int len=from.length();
      if (len >= elem.length()) {
        elem=to;
      }
 else {
        elem=to + elem.substring(len);
      }
    }
    return elem;
  }
  private String from=null;
  private String to=null;
}
