/** 
 * A NameAndType CP Info
 */
public class NameAndTypeCPInfo extends ConstantPoolEntry {
  /** 
 * Constructor. 
 */
  public NameAndTypeCPInfo(){
    super(CONSTANT_NAMEANDTYPE,1);
  }
  /** 
 * read a constant pool entry from a class stream.
 * @param cpStream the DataInputStream which contains the constant poolentry to be read.
 * @exception IOException if there is a problem reading the entry fromthe stream.
 */
  public void read(  DataInputStream cpStream) throws IOException {
    nameIndex=cpStream.readUnsignedShort();
    descriptorIndex=cpStream.readUnsignedShort();
  }
  /** 
 * Print a readable version of the constant pool entry.
 * @return the string representation of this constant pool entry.
 */
  public String toString(){
    String value;
    if (isResolved()) {
      value="Name = " + name + ", type = "+ type;
    }
 else {
      value="Name index = " + nameIndex + ", descriptor index = "+ descriptorIndex;
    }
    return value;
  }
  /** 
 * Resolve this constant pool entry with respect to its dependents in the constant pool.
 * @param constantPool the constant pool of which this entry is a memberand against which this entry is to be resolved.
 */
  public void resolve(  ConstantPool constantPool){
    name=((Utf8CPInfo)constantPool.getEntry(nameIndex)).getValue();
    type=((Utf8CPInfo)constantPool.getEntry(descriptorIndex)).getValue();
    super.resolve(constantPool);
  }
  /** 
 * Get the name component of this entry
 * @return the name of this name and type entry
 */
  public String getName(){
    return name;
  }
  /** 
 * Get the type signature of this entry
 * @return the type signature of this entry
 */
  public String getType(){
    return type;
  }
  /** 
 * the name component of this entry 
 */
  private String name;
  /** 
 * the type component of this entry 
 */
  private String type;
  /** 
 * the index into the constant pool at which the name component's string value is stored
 */
  private int nameIndex;
  /** 
 * the index into the constant pool where the type descriptor string is stored.
 */
  private int descriptorIndex;
}
