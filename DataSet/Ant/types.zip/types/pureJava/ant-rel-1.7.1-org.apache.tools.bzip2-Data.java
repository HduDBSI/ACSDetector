private static final class Data extends Object {
  final boolean[] inUse=new boolean[256];
  final byte[] seqToUnseq=new byte[256];
  final byte[] selector=new byte[MAX_SELECTORS];
  final byte[] selectorMtf=new byte[MAX_SELECTORS];
  /** 
 * Freq table collected to save a pass over the data during decompression.
 */
  final int[] unzftab=new int[256];
  final int[][] limit=new int[N_GROUPS][MAX_ALPHA_SIZE];
  final int[][] base=new int[N_GROUPS][MAX_ALPHA_SIZE];
  final int[][] perm=new int[N_GROUPS][MAX_ALPHA_SIZE];
  final int[] minLens=new int[N_GROUPS];
  final int[] cftab=new int[257];
  final char[] getAndMoveToFrontDecode_yy=new char[256];
  final char[][] temp_charArray2d=new char[N_GROUPS][MAX_ALPHA_SIZE];
  final byte[] recvDecodingTables_pos=new byte[N_GROUPS];
  int[] tt;
  byte[] ll8;
  Data(  int blockSize100k){
    super();
    this.ll8=new byte[blockSize100k * BZip2Constants.baseBlockSize];
  }
  /** 
 * Initializes the  {@link #tt} array.This method is called when the required length of the array is known.  I don't initialize it at construction time to avoid unneccessary memory allocation when compressing small files.
 */
  final int[] initTT(  int length){
    int[] ttShadow=this.tt;
    if ((ttShadow == null) || (ttShadow.length < length)) {
      this.tt=ttShadow=new int[length];
    }
    return ttShadow;
  }
}
