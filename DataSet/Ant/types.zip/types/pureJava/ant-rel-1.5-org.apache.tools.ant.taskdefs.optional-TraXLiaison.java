/** 
 * Concrete liaison for XSLT processor implementing TraX. (ie JAXP 1.1)
 * @author <a href="mailto:rubys@us.ibm.com">Sam Ruby</a>
 * @author <a href="mailto:dims@yahoo.com">Davanum Srinivas</a>
 * @author <a href="mailto:sbailliez@apache.org">Stephane Bailliez</a>
 * @since Ant 1.3
 */
public class TraXLiaison implements XSLTLiaison, ErrorListener, XSLTLoggerAware {
  /** 
 * The trax TransformerFactory 
 */
  private TransformerFactory tfactory=null;
  /** 
 * stylesheet stream, close it asap 
 */
  private FileInputStream xslStream=null;
  /** 
 * Stylesheet template 
 */
  private Templates templates=null;
  /** 
 * transformer 
 */
  private Transformer transformer=null;
  private XSLTLogger logger;
  /** 
 * possible resolver for publicIds 
 */
  private EntityResolver entityResolver;
  /** 
 * possible resolver for URIs 
 */
  private URIResolver uriResolver;
  public TraXLiaison() throws Exception {
    tfactory=TransformerFactory.newInstance();
    tfactory.setErrorListener(this);
  }
  /** 
 * Set the output property for the current transformer. Note that the stylesheet must be set prior to calling this method.
 * @param name the output property name.
 * @param value the output property value.
 */
  public void setOutputProperty(  String name,  String value){
    if (transformer == null) {
      throw new IllegalStateException("stylesheet must be set prior to setting the output properties");
    }
    transformer.setOutputProperty(name,value);
  }
  public void setStylesheet(  File stylesheet) throws Exception {
    xslStream=new FileInputStream(stylesheet);
    StreamSource src=new StreamSource(xslStream);
    src.setSystemId(getSystemId(stylesheet));
    templates=tfactory.newTemplates(src);
    transformer=templates.newTransformer();
    transformer.setErrorListener(this);
  }
  public void transform(  File infile,  File outfile) throws Exception {
    FileInputStream fis=null;
    FileOutputStream fos=null;
    try {
      fis=new FileInputStream(infile);
      fos=new FileOutputStream(outfile);
      Source src=null;
      if (entityResolver != null) {
        if (tfactory.getFeature(SAXSource.FEATURE)) {
          SAXParserFactory spFactory=SAXParserFactory.newInstance();
          spFactory.setNamespaceAware(true);
          XMLReader reader=spFactory.newSAXParser().getXMLReader();
          reader.setEntityResolver(entityResolver);
          src=new SAXSource(reader,new InputSource(fis));
        }
 else {
          throw new IllegalStateException("xcatalog specified, but " + "parser doesn't support SAX");
        }
      }
 else {
        src=new StreamSource(fis);
      }
      src.setSystemId(getSystemId(infile));
      StreamResult res=new StreamResult(fos);
      res.setSystemId(getSystemId(outfile));
      if (uriResolver != null)       transformer.setURIResolver(uriResolver);
      transformer.transform(src,res);
    }
  finally {
      try {
        if (xslStream != null) {
          xslStream.close();
        }
      }
 catch (      IOException ignored) {
      }
      try {
        if (fis != null) {
          fis.close();
        }
      }
 catch (      IOException ignored) {
      }
      try {
        if (fos != null) {
          fos.close();
        }
      }
 catch (      IOException ignored) {
      }
    }
  }
  protected String getSystemId(  File file){
    String path=file.getAbsolutePath();
    path=path.replace('\\','/');
    if (File.separatorChar == '\\') {
      return FILE_PROTOCOL_PREFIX + "/" + path;
    }
    return FILE_PROTOCOL_PREFIX + path;
  }
  public void addParam(  String name,  String value){
    transformer.setParameter(name,value);
  }
  public void setLogger(  XSLTLogger l){
    logger=l;
  }
  public void error(  TransformerException e){
    logError(e,"Error");
  }
  public void fatalError(  TransformerException e){
    logError(e,"Fatal Error");
    throw new BuildException("Fatal error during transformation",e);
  }
  public void warning(  TransformerException e){
    logError(e,"Warning");
  }
  private void logError(  TransformerException e,  String type){
    if (logger == null) {
      return;
    }
    StringBuffer msg=new StringBuffer();
    if (e.getLocator() != null) {
      if (e.getLocator().getSystemId() != null) {
        String url=e.getLocator().getSystemId();
        if (url.startsWith("file:///")) {
          url=url.substring(8);
        }
        msg.append(url);
      }
 else {
        msg.append("Unknown file");
      }
      if (e.getLocator().getLineNumber() != -1) {
        msg.append(":" + e.getLocator().getLineNumber());
        if (e.getLocator().getColumnNumber() != -1) {
          msg.append(":" + e.getLocator().getColumnNumber());
        }
      }
    }
    msg.append(": " + type + "! ");
    msg.append(e.getMessage());
    if (e.getCause() != null) {
      msg.append(" Cause: " + e.getCause());
    }
    logger.log(msg.toString());
  }
  /** 
 * Set the class to resolve entities during the transformation
 */
  public void setEntityResolver(  EntityResolver aResolver){
    entityResolver=aResolver;
  }
  /** 
 * Set the class to resolve URIs during the transformation
 */
  public void setURIResolver(  URIResolver aResolver){
    uriResolver=aResolver;
  }
}
