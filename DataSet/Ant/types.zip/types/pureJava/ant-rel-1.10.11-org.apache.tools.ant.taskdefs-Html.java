/** 
 * An HTML element in the Javadoc. This class is used for those Javadoc elements which contain HTML such as footers, headers, etc.
 */
public static class Html {
  /** 
 * The text for the element 
 */
  private final StringBuffer text=new StringBuffer();
  /** 
 * Add text to the element.
 * @param t the text to be added.
 */
  public void addText(  final String t){
    text.append(t);
  }
  /** 
 * Get the current text for the element.
 * @return the current text.
 */
  public String getText(){
    return text.substring(0);
  }
}
