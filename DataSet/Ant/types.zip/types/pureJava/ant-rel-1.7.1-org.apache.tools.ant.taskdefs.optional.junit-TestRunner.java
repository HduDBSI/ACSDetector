private final static class TestRunner extends JUnitTestRunner {
  private ResultFormatter formatter=new ResultFormatter();
  TestRunner(  JUnitTest test,  boolean haltonerror,  boolean filtertrace,  boolean haltonfailure){
    super(test,haltonerror,filtertrace,haltonfailure,TestRunner.class.getClassLoader());
    addFormatter(formatter);
  }
  ResultFormatter getFormatter(){
    return formatter;
  }
}
