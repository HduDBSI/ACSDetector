public static class SourceFile {
  private File file;
  public void setFile(  File file){
    this.file=file;
  }
  public File getFile(){
    return file;
  }
}
