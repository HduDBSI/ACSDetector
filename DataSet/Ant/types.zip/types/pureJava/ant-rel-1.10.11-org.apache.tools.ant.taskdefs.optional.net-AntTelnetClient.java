/** 
 * This class handles the abstraction of the telnet protocol. Currently it is a wrapper around <a href="https://jakarta.apache.org/commons/net/index.html">Jakarta Commons Net</a>.
 */
public class AntTelnetClient extends TelnetClient {
  /** 
 * Read from the telnet session until the string we are waiting for is found
 * @param s The string to wait on
 */
  public void waitForString(  String s){
    waitForString(s,null);
  }
  /** 
 * Read from the telnet session until the string we are waiting for is found or the timeout has been reached
 * @param s The string to wait on
 * @param timeout The maximum number of seconds to wait
 */
  public void waitForString(  String s,  Integer timeout){
    InputStream is=this.getInputStream();
    try {
      StringBuilder sb=new StringBuilder();
      int windowStart=-s.length();
      if (timeout == null || timeout == 0) {
        while (windowStart < 0 || !sb.substring(windowStart).equals(s)) {
          sb.append((char)is.read());
          windowStart++;
        }
      }
 else {
        Calendar endTime=Calendar.getInstance();
        endTime.add(Calendar.SECOND,timeout);
        while (windowStart < 0 || !sb.substring(windowStart).equals(s)) {
          while (Calendar.getInstance().before(endTime) && is.available() == 0) {
            Thread.sleep(WAIT_INTERVAL);
          }
          if (is.available() == 0) {
            log("Read before running into timeout: " + sb.toString(),Project.MSG_DEBUG);
            throw new BuildException("Response timed-out waiting for \"" + s + '\"',getLocation());
          }
          sb.append((char)is.read());
          windowStart++;
        }
      }
      log(sb.toString(),Project.MSG_INFO);
    }
 catch (    BuildException be) {
      throw be;
    }
catch (    Exception e) {
      throw new BuildException(e,getLocation());
    }
  }
  /** 
 * Write this string to the telnet session.
 * @param s          the string to write
 * @param echoString if true log the string sent
 */
  public void sendString(  String s,  boolean echoString){
    OutputStream os=this.getOutputStream();
    try {
      os.write((s + "\n").getBytes());
      if (echoString) {
        log(s,Project.MSG_INFO);
      }
      os.flush();
    }
 catch (    Exception e) {
      throw new BuildException(e,getLocation());
    }
  }
}
