@Testcontainers class FlinkKafkaInternalProducerITCase extends TestLogger {
  private static final Logger LOG=LoggerFactory.getLogger(FlinkKafkaInternalProducerITCase.class);
  @Container private static final KafkaContainer KAFKA_CONTAINER=createKafkaContainer(KAFKA,LOG).withEmbeddedZookeeper();
  private static final String TRANSACTION_PREFIX="test-transaction-";
  @Test void testInitTransactionId(){
    final String topic="test-init-transactions";
    try (FlinkKafkaInternalProducer<String,String> reuse=new FlinkKafkaInternalProducer<>(getProperties(),"dummy")){
      int numTransactions=20;
      for (int i=1; i <= numTransactions; i++) {
        reuse.initTransactionId(TRANSACTION_PREFIX + i);
        reuse.beginTransaction();
        reuse.send(new ProducerRecord<>(topic,"test-value-" + i));
        if (i % 2 == 0) {
          reuse.commitTransaction();
        }
 else {
          reuse.flush();
          reuse.abortTransaction();
        }
        assertNumTransactions(i);
        assertThat(readRecords(topic).count(),equalTo(i / 2));
      }
    }
   }
  @ParameterizedTest @MethodSource("provideTransactionsFinalizer") void testResetInnerTransactionIfFinalizingTransactionFailed(  Consumer<FlinkKafkaInternalProducer<?,?>> transactionFinalizer){
    final String topic="reset-producer-internal-state";
    try (FlinkKafkaInternalProducer<String,String> fenced=new FlinkKafkaInternalProducer<>(getProperties(),"dummy")){
      fenced.initTransactions();
      fenced.beginTransaction();
      fenced.send(new ProducerRecord<>(topic,"test-value"));
      try (FlinkKafkaInternalProducer<String,String> producer=new FlinkKafkaInternalProducer<>(getProperties(),"dummy")){
        producer.initTransactions();
        producer.beginTransaction();
        producer.send(new ProducerRecord<>(topic,"test-value"));
        producer.commitTransaction();
      }
       assertThrows(ProducerFencedException.class,() -> transactionFinalizer.accept(fenced));
      fenced.setTransactionId("dummy2");
    }
   }
  private static Properties getProperties(){
    Properties properties=new Properties();
    properties.put(CommonClientConfigs.BOOTSTRAP_SERVERS_CONFIG,KAFKA_CONTAINER.getBootstrapServers());
    properties.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG,"true");
    properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,StringSerializer.class);
    properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,StringSerializer.class);
    properties.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class);
    properties.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class);
    return properties;
  }
  private static List<Consumer<FlinkKafkaInternalProducer<?,?>>> provideTransactionsFinalizer(){
    return Lists.newArrayList(FlinkKafkaInternalProducer::commitTransaction,FlinkKafkaInternalProducer::abortTransaction);
  }
  private void assertNumTransactions(  int numTransactions){
    List<KafkaTransactionLog.TransactionRecord> transactions=new KafkaTransactionLog(getProperties()).getTransactions(id -> id.startsWith(TRANSACTION_PREFIX));
    assertThat(transactions.stream().map(KafkaTransactionLog.TransactionRecord::getTransactionId).collect(Collectors.toSet()),hasSize(numTransactions));
  }
  private ConsumerRecords<String,String> readRecords(  String topic){
    Properties properties=getProperties();
    properties.put(ConsumerConfig.ISOLATION_LEVEL_CONFIG,"read_committed");
    KafkaConsumer<String,String> consumer=new KafkaConsumer<>(properties);
    consumer.assign(consumer.partitionsFor(topic).stream().map(partitionInfo -> new TopicPartition(topic,partitionInfo.partition())).collect(Collectors.toSet()));
    consumer.seekToBeginning(consumer.assignment());
    return consumer.poll(Duration.ofMillis(1000));
  }
}
