/** 
 * Simple code which handles all HTTP requests from the user, and passes them to the Router handler directly if they do not involve file upload requests. If a file is required to be uploaded, it handles the upload, and in the http request to the next handler, passes the name of the file to the next handler.
 */
@ChannelHandler.Sharable public class HttpRequestHandler extends SimpleChannelInboundHandler<HttpObject> {
  private static final Logger LOG=LoggerFactory.getLogger(HttpRequestHandler.class);
  private static final Charset ENCODING=ConfigConstants.DEFAULT_CHARSET;
  /** 
 * A decoder factory that always stores POST chunks on disk. 
 */
  private static final HttpDataFactory DATA_FACTORY=new DefaultHttpDataFactory(true);
  private final File tmpDir;
  private HttpRequest currentRequest;
  private HttpPostRequestDecoder currentDecoder;
  private String currentRequestPath;
  public HttpRequestHandler(  File tmpDir){
    this.tmpDir=tmpDir;
  }
  @Override public void channelUnregistered(  ChannelHandlerContext ctx) throws Exception {
    if (currentDecoder != null) {
      currentDecoder.cleanFiles();
    }
  }
  @Override public void channelRead0(  ChannelHandlerContext ctx,  HttpObject msg){
    try {
      if (msg instanceof HttpRequest) {
        currentRequest=(HttpRequest)msg;
        currentRequestPath=null;
        if (currentDecoder != null) {
          currentDecoder.destroy();
          currentDecoder=null;
        }
        if (currentRequest.getMethod() == HttpMethod.GET || currentRequest.getMethod() == HttpMethod.DELETE) {
          ctx.fireChannelRead(currentRequest);
        }
 else         if (currentRequest.getMethod() == HttpMethod.POST) {
          currentRequestPath=new QueryStringDecoder(currentRequest.getUri(),ENCODING).path();
          currentDecoder=new HttpPostRequestDecoder(DATA_FACTORY,currentRequest,ENCODING);
        }
 else {
          throw new IOException("Unsupported HTTP method: " + currentRequest.getMethod().name());
        }
      }
 else       if (currentDecoder != null && msg instanceof HttpContent) {
        HttpContent chunk=(HttpContent)msg;
        currentDecoder.offer(chunk);
        try {
          while (currentDecoder.hasNext()) {
            InterfaceHttpData data=currentDecoder.next();
            if (data.getHttpDataType() == HttpDataType.FileUpload && tmpDir != null) {
              DiskFileUpload file=(DiskFileUpload)data;
              if (file.isCompleted()) {
                String name=file.getFilename();
                File target=new File(tmpDir,UUID.randomUUID() + "_" + name);
                if (!tmpDir.exists()) {
                  logExternalUploadDirDeletion(tmpDir);
                  checkAndCreateUploadDir(tmpDir);
                }
                file.renameTo(target);
                QueryStringEncoder encoder=new QueryStringEncoder(currentRequestPath);
                encoder.addParam("filepath",target.getAbsolutePath());
                encoder.addParam("filename",name);
                currentRequest.setUri(encoder.toString());
              }
            }
          }
        }
 catch (        EndOfDataDecoderException ignored) {
        }
        if (chunk instanceof LastHttpContent) {
          HttpRequest request=currentRequest;
          currentRequest=null;
          currentRequestPath=null;
          currentDecoder.destroy();
          currentDecoder=null;
          ctx.fireChannelRead(request);
        }
      }
    }
 catch (    Throwable t) {
      currentRequest=null;
      currentRequestPath=null;
      if (currentDecoder != null) {
        currentDecoder.destroy();
        currentDecoder=null;
      }
      if (ctx.channel().isActive()) {
        byte[] bytes=ExceptionUtils.stringifyException(t).getBytes(ENCODING);
        DefaultFullHttpResponse response=new DefaultFullHttpResponse(HttpVersion.HTTP_1_1,HttpResponseStatus.INTERNAL_SERVER_ERROR,Unpooled.wrappedBuffer(bytes));
        response.headers().set(HttpHeaders.Names.CONTENT_TYPE,"text/plain");
        response.headers().set(HttpHeaders.Names.CONTENT_LENGTH,response.content().readableBytes());
        ctx.writeAndFlush(response);
      }
    }
  }
  public static void logExternalUploadDirDeletion(  File uploadDir){
    LOG.warn("Jar storage directory {} has been deleted externally. Previously uploaded jars are no longer available.",uploadDir.getAbsolutePath());
  }
  /** 
 * Checks whether the given directory exists and is writable. If it doesn't exist this method will attempt to create it.
 * @param uploadDir directory to check
 * @throws IOException if the directory does not exist and cannot be created, or if the directory isn't writable
 */
  public static synchronized void checkAndCreateUploadDir(  File uploadDir) throws IOException {
    if (uploadDir.exists() && uploadDir.canWrite()) {
      LOG.info("Using directory {} for web frontend JAR file uploads.",uploadDir);
    }
 else     if (uploadDir.mkdirs() && uploadDir.canWrite()) {
      LOG.info("Created directory {} for web frontend JAR file uploads.",uploadDir);
    }
 else {
      LOG.warn("Jar upload directory {} cannot be created or is not writable.",uploadDir.getAbsolutePath());
      throw new IOException(String.format("Jar upload directory %s cannot be created or is not writable.",uploadDir.getAbsolutePath()));
    }
  }
}
