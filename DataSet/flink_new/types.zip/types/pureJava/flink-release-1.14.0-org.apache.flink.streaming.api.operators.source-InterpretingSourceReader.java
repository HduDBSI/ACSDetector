private static final class InterpretingSourceReader implements SourceReader<Integer,MockSourceSplit> {
  private final Iterator<Consumer<ReaderOutput<Integer>>> actions;
  @SafeVarargs private InterpretingSourceReader(  Consumer<ReaderOutput<Integer>>... actions){
    this.actions=Arrays.asList(actions).iterator();
  }
  @Override public void start(){
  }
  @Override public InputStatus pollNext(  ReaderOutput<Integer> output){
    if (actions.hasNext()) {
      actions.next().accept(output);
      return InputStatus.MORE_AVAILABLE;
    }
 else {
      return InputStatus.END_OF_INPUT;
    }
  }
  @Override public List<MockSourceSplit> snapshotState(  long checkpointId){
    throw new UnsupportedOperationException();
  }
  @Override public CompletableFuture<Void> isAvailable(){
    return CompletableFuture.completedFuture(null);
  }
  @Override public void addSplits(  List<MockSourceSplit> splits){
  }
  @Override public void notifyNoMoreSplits(){
  }
  @Override public void close(){
  }
}
