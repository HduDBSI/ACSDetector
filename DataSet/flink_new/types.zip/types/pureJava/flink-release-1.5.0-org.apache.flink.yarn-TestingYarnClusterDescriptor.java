/** 
 * Yarn client which starts a  {@link TestingApplicationMaster}. Additionally the client adds the flink-yarn-tests-X-tests.jar and the flink-runtime-X-tests.jar to the set of files which are shipped to the yarn cluster. This is necessary to load the testing classes.
 */
public class TestingYarnClusterDescriptor extends LegacyYarnClusterDescriptor {
  public TestingYarnClusterDescriptor(  Configuration configuration,  YarnConfiguration yarnConfiguration,  String configurationDirectory,  YarnClient yarnClient,  boolean sharedYarnClient){
    super(configuration,yarnConfiguration,configurationDirectory,yarnClient,sharedYarnClient);
    List<File> filesToShip=new ArrayList<>();
    File testingJar=YarnTestBase.findFile("..",new TestJarFinder("flink-yarn-tests"));
    Preconditions.checkNotNull(testingJar,"Could not find the flink-yarn-tests tests jar. " + "Make sure to package the flink-yarn-tests module.");
    File testingRuntimeJar=YarnTestBase.findFile("..",new TestJarFinder("flink-runtime"));
    Preconditions.checkNotNull(testingRuntimeJar,"Could not find the flink-runtime tests " + "jar. Make sure to package the flink-runtime module.");
    File testingYarnJar=YarnTestBase.findFile("..",new TestJarFinder("flink-yarn"));
    Preconditions.checkNotNull(testingRuntimeJar,"Could not find the flink-yarn tests " + "jar. Make sure to package the flink-yarn module.");
    filesToShip.add(testingJar);
    filesToShip.add(testingRuntimeJar);
    filesToShip.add(testingYarnJar);
    addShipFiles(filesToShip);
  }
  @Override protected String getYarnSessionClusterEntrypoint(){
    return TestingApplicationMaster.class.getName();
  }
  @Override protected String getYarnJobClusterEntrypoint(){
    throw new UnsupportedOperationException("Does not support Yarn per-job clusters.");
  }
  @Override public YarnClusterClient deployJobCluster(  ClusterSpecification clusterSpecification,  JobGraph jobGraph,  boolean detached){
    throw new UnsupportedOperationException("Cannot deploy a per-job cluster yet.");
  }
static class TestJarFinder implements FilenameFilter {
    private final String jarName;
    TestJarFinder(    final String jarName){
      this.jarName=jarName;
    }
    @Override public boolean accept(    File dir,    String name){
      return name.startsWith(jarName) && name.endsWith("-tests.jar") && dir.getAbsolutePath().contains(dir.separator + jarName + dir.separator);
    }
  }
}
