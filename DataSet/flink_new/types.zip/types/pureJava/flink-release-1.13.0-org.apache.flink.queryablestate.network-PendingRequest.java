/** 
 * A pending request queued while the channel is connecting. 
 */
private final class PendingRequest extends CompletableFuture<RESP> {
  private final REQ request;
  private PendingRequest(  REQ request){
    this.request=request;
  }
}
