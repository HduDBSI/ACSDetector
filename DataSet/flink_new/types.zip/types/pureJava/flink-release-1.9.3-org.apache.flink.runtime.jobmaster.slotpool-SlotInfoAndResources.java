/** 
 * This class is a value type that combines a  {@link SlotInfo} with its remaining {@link ResourceProfile}.
 */
final class SlotInfoAndResources {
  @Nonnull private final SlotInfo slotInfo;
  @Nonnull private final ResourceProfile remainingResources;
  private final double taskExecutorUtilization;
  public SlotInfoAndResources(  @Nonnull SlotInfo slotInfo,  @Nonnull ResourceProfile remainingResources,  double taskExecutorUtilization){
    this.slotInfo=slotInfo;
    this.remainingResources=remainingResources;
    this.taskExecutorUtilization=taskExecutorUtilization;
  }
  @Nonnull public SlotInfo getSlotInfo(){
    return slotInfo;
  }
  @Nonnull public ResourceProfile getRemainingResources(){
    return remainingResources;
  }
  public double getTaskExecutorUtilization(){
    return taskExecutorUtilization;
  }
  public static SlotInfoAndResources fromSingleSlot(  @Nonnull SlotInfoWithUtilization slotInfoWithUtilization){
    return new SlotInfoAndResources(slotInfoWithUtilization,slotInfoWithUtilization.getResourceProfile(),slotInfoWithUtilization.getTaskExecutorUtilization());
  }
}
