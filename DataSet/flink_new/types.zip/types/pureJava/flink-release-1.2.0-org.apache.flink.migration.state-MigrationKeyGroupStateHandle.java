@Internal @Deprecated public class MigrationKeyGroupStateHandle extends KeyGroupsStateHandle implements Migration {
  private static final long serialVersionUID=-8554427169776881697L;
  /** 
 * @param groupRangeOffsets range of key-group ids that in the state of this handle
 * @param streamStateHandle handle to the actual state of the key-groups
 */
  public MigrationKeyGroupStateHandle(  KeyGroupRangeOffsets groupRangeOffsets,  StreamStateHandle streamStateHandle){
    super(groupRangeOffsets,streamStateHandle);
  }
}
