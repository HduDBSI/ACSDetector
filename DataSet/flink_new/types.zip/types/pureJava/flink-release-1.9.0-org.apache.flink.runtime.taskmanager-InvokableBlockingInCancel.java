/** 
 * {@link AbstractInvokable} which blocks in cancel.
 */
public static final class InvokableBlockingInCancel extends AbstractInvokable {
  public InvokableBlockingInCancel(  Environment environment){
    super(environment);
  }
  @Override public void invoke(){
    awaitLatch.trigger();
    try {
      triggerLatch.await();
synchronized (this) {
        wait();
      }
    }
 catch (    InterruptedException ignored) {
synchronized (this) {
        notifyAll();
      }
    }
  }
  @Override public void cancel() throws Exception {
synchronized (this) {
      triggerLatch.trigger();
      wait();
    }
  }
}
