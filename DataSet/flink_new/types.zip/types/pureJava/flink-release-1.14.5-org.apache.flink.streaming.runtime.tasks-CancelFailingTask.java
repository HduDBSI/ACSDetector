/** 
 * A task that locks for ever, fail in  {@link #cancelTask()}. It can be only shut down cleanly if  {@link StreamTask#getCancelables()} are closed properly.
 */
public static class CancelFailingTask extends StreamTask<String,AbstractStreamOperator<String>> {
  public CancelFailingTask(  Environment env) throws Exception {
    super(env);
  }
  @Override protected void init(){
  }
  @Override protected void processInput(  MailboxDefaultAction.Controller controller) throws Exception {
    final OneShotLatch latch=new OneShotLatch();
    final Object lock=new Object();
    LockHolder holder=new LockHolder(lock,latch);
    holder.start();
    try {
      getCancelables().registerCloseable(holder);
      latch.await();
      syncLatch.trigger();
synchronized (lock) {
      }
    }
  finally {
      holder.close();
    }
    controller.suspendDefaultAction();
    mailboxProcessor.suspend();
  }
  @Override protected void cleanUpInternal(){
  }
  @Override protected void cancelTask() throws Exception {
    throw new Exception("test exception");
  }
  /** 
 * A thread that holds a lock as long as it lives. 
 */
private static final class LockHolder extends Thread implements Closeable {
    private final OneShotLatch trigger;
    private final Object lock;
    private volatile boolean canceled;
    private LockHolder(    Object lock,    OneShotLatch trigger){
      this.lock=lock;
      this.trigger=trigger;
    }
    @Override public void run(){
synchronized (lock) {
        while (!canceled) {
          trigger.trigger();
          try {
            Thread.sleep(1000000000);
          }
 catch (          InterruptedException ignored) {
          }
        }
      }
    }
    public void cancel(){
      canceled=true;
    }
    @Override public void close(){
      canceled=true;
      interrupt();
    }
  }
}
