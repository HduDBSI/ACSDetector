/** 
 * A test base that includes utilities for taking a savepoint. 
 */
public abstract class SavepointTestBase extends AbstractTestBase {
  public <T>String takeSavepoint(  T[] data,  Function<SourceFunction<T>,StreamExecutionEnvironment> jobGraphFactory) throws Exception {
    return takeSavepoint(Arrays.asList(data),jobGraphFactory);
  }
  public <T>String takeSavepoint(  Collection<T> data,  Function<SourceFunction<T>,StreamExecutionEnvironment> jobGraphFactory) throws Exception {
    StreamExecutionEnvironment env=StreamExecutionEnvironment.getExecutionEnvironment();
    env.getConfig().disableClosureCleaner();
    WaitingSource<T> waitingSource=createSource(data);
    JobGraph jobGraph=jobGraphFactory.apply(waitingSource).getStreamGraph().getJobGraph();
    JobID jobId=jobGraph.getJobID();
    ClusterClient<?> client=miniClusterResource.getClusterClient();
    try {
      JobID jobID=client.submitJob(jobGraph).get();
      return CompletableFuture.runAsync(waitingSource::awaitSource).thenCompose(ignore -> triggerSavepoint(client,jobID)).get(5,TimeUnit.MINUTES);
    }
 catch (    Exception e) {
      throw new RuntimeException("Failed to take savepoint",e);
    }
 finally {
      client.cancel(jobId);
    }
  }
  private <T>WaitingSource<T> createSource(  Collection<T> data) throws Exception {
    T first=data.iterator().next();
    if (first == null) {
      throw new IllegalArgumentException("Collection must not contain null elements");
    }
    TypeInformation<T> typeInfo=TypeExtractor.getForObject(first);
    SourceFunction<T> inner=new FromElementsFunction<>(typeInfo.createSerializer(new ExecutionConfig()),data);
    return new WaitingSource<>(inner,typeInfo);
  }
  private CompletableFuture<String> triggerSavepoint(  ClusterClient<?> client,  JobID jobID) throws RuntimeException {
    try {
      String dirPath=getTempDirPath(new AbstractID().toHexString());
      return client.triggerSavepoint(jobID,dirPath);
    }
 catch (    IOException e) {
      throw new RuntimeException(e);
    }
  }
}
