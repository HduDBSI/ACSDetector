/** 
 * A simple task that does nothing and finishes after a short delay of 100 milliseconds.
 */
public class WaitingNoOpInvokable extends AbstractInvokable {
  private static final long waitingTime=100L;
  public WaitingNoOpInvokable(  Environment environment){
    super(environment);
  }
  @Override public void invoke() throws Exception {
    Thread.sleep(waitingTime);
  }
}
