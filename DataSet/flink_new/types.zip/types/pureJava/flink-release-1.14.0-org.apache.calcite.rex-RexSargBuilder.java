/** 
 * Equivalent to a  {@link RexLiteral} whose value is a {@link Sarg}, but mutable, so that the Sarg can be expanded as  {@link SargCollector} traverses a list of OR or AND terms.<p>The  {@link SargCollector#fix} method converts it to an immutable literal.
 */
static class RexSargBuilder extends RexNode {
  final RexNode ref;
  private final RexBuilder rexBuilder;
  private List<RelDataType> types=new ArrayList<>();
  final RangeSet<Comparable> rangeSet=TreeRangeSet.create();
  boolean containsNull;
  RexSargBuilder(  RexNode ref,  RexBuilder rexBuilder,  boolean negate){
    this.ref=Objects.requireNonNull(ref);
    this.rexBuilder=Objects.requireNonNull(rexBuilder);
    this.containsNull=false;
  }
  @Override public String toString(){
    return "SEARCH(" + ref + ", "+ rangeSet+ (containsNull ? " + null)" : ")");
  }
  /** 
 * Returns a rough estimate of whether it is worth converting to a Sarg. <p>Examples: <ul> <li> {@code x = 1},  {@code x <> 1},  {@code x > 1} have complexity 1<li> {@code x > 1 or x is null} has complexity 2<li> {@code x in (2, 4, 6) or x > 20} has complexity 4</ul>
 */
  int complexity(){
    int complexity=0;
    if (rangeSet.asRanges().size() == 2 && rangeSet.complement().asRanges().size() == 1 && RangeSets.isPoint(Iterables.getOnlyElement(rangeSet.complement().asRanges()))) {
      complexity++;
    }
 else {
      complexity+=rangeSet.asRanges().size();
    }
    if (containsNull) {
      ++complexity;
    }
    return complexity;
  }
  <C extends Comparable<C>>Sarg<C> build(  boolean negate){
    final RangeSet rangeSet=negate ? this.rangeSet.complement() : this.rangeSet;
    return Sarg.of(containsNull,rangeSet);
  }
  @Override public RelDataType getType(){
    if (this.types.isEmpty()) {
      return ref.getType();
    }
    final List<RelDataType> distinctTypes=Util.distinctList(this.types);
    return Objects.requireNonNull(rexBuilder.typeFactory.leastRestrictive(distinctTypes),() -> "Can't find leastRestrictive type among " + distinctTypes);
  }
  @Override public <R>R accept(  RexVisitor<R> visitor){
    throw new UnsupportedOperationException();
  }
  @Override public <R,P>R accept(  RexBiVisitor<R,P> visitor,  P arg){
    throw new UnsupportedOperationException();
  }
  @Override public boolean equals(  Object obj){
    throw new UnsupportedOperationException();
  }
  @Override public int hashCode(){
    throw new UnsupportedOperationException();
  }
  void addRange(  Range<Comparable> range,  RelDataType type){
    types.add(type);
    rangeSet.add(range);
  }
  void addSarg(  Sarg sarg,  boolean negate,  RelDataType type){
    types.add(type);
    rangeSet.addAll(negate ? sarg.rangeSet.complement() : sarg.rangeSet);
    containsNull|=sarg.containsNull;
  }
}
