/** 
 * The  {@link CheckpointBarrierTracker} keeps track of what checkpoint barriers have been received fromwhich input channels. Once it has observed all checkpoint barriers for a checkpoint ID, it notifies its listener of a completed checkpoint. <p>Unlike the  {@link CheckpointBarrierAligner}, the BarrierTracker does not block the input channels that have sent barriers, so it cannot be used to gain "exactly-once" processing guarantees. It can, however, be used to gain "at least once" processing guarantees. <p>NOTE: This implementation strictly assumes that newer checkpoints have higher checkpoint IDs.
 */
@Internal public class CheckpointBarrierTracker extends CheckpointBarrierHandler {
  private static final Logger LOG=LoggerFactory.getLogger(CheckpointBarrierTracker.class);
  /** 
 * The tracker tracks a maximum number of checkpoints, for which some, but not all barriers have yet arrived.
 */
  private static final int MAX_CHECKPOINTS_TO_TRACK=50;
  /** 
 * The number of channels. Once that many barriers have been received for a checkpoint, the checkpoint is considered complete.
 */
  private final int totalNumberOfInputChannels;
  /** 
 * All checkpoints for which some (but not all) barriers have been received, and that are not yet known to be subsumed by newer checkpoints.
 */
  private final ArrayDeque<CheckpointBarrierCount> pendingCheckpoints;
  /** 
 * The highest checkpoint ID encountered so far. 
 */
  private long latestPendingCheckpointID=-1;
  public CheckpointBarrierTracker(  int totalNumberOfInputChannels,  AbstractInvokable toNotifyOnCheckpoint){
    super(toNotifyOnCheckpoint);
    this.totalNumberOfInputChannels=totalNumberOfInputChannels;
    this.pendingCheckpoints=new ArrayDeque<>();
  }
  public void processBarrier(  CheckpointBarrier receivedBarrier,  InputChannelInfo channelInfo) throws IOException {
    final long barrierId=receivedBarrier.getId();
    if (totalNumberOfInputChannels == 1) {
      markAlignmentStartAndEnd(receivedBarrier.getTimestamp());
      notifyCheckpoint(receivedBarrier);
      return;
    }
    if (LOG.isDebugEnabled()) {
      LOG.debug("Received barrier for checkpoint {} from channel {}",barrierId,channelInfo);
    }
    CheckpointBarrierCount barrierCount=null;
    int pos=0;
    for (    CheckpointBarrierCount next : pendingCheckpoints) {
      if (next.checkpointId == barrierId) {
        barrierCount=next;
        break;
      }
      pos++;
    }
    if (barrierCount != null) {
      int numBarriersNew=barrierCount.incrementBarrierCount();
      if (numBarriersNew == totalNumberOfInputChannels) {
        for (int i=0; i <= pos; i++) {
          pendingCheckpoints.pollFirst();
        }
        if (!barrierCount.isAborted()) {
          if (LOG.isDebugEnabled()) {
            LOG.debug("Received all barriers for checkpoint {}",barrierId);
          }
          markAlignmentEnd();
          notifyCheckpoint(receivedBarrier);
        }
      }
    }
 else {
      if (barrierId > latestPendingCheckpointID) {
        markAlignmentStart(receivedBarrier.getTimestamp());
        latestPendingCheckpointID=barrierId;
        pendingCheckpoints.addLast(new CheckpointBarrierCount(barrierId));
        if (pendingCheckpoints.size() > MAX_CHECKPOINTS_TO_TRACK) {
          pendingCheckpoints.pollFirst();
        }
      }
    }
  }
  @Override public void processBarrierAnnouncement(  CheckpointBarrier announcedBarrier,  int sequenceNumber,  InputChannelInfo channelInfo) throws IOException {
  }
  @Override public void processCancellationBarrier(  CancelCheckpointMarker cancelBarrier) throws IOException {
    final long checkpointId=cancelBarrier.getCheckpointId();
    if (LOG.isDebugEnabled()) {
      LOG.debug("Received cancellation barrier for checkpoint {}",checkpointId);
    }
    if (totalNumberOfInputChannels == 1) {
      notifyAbortOnCancellationBarrier(checkpointId);
      return;
    }
    CheckpointBarrierCount cbc;
    while ((cbc=pendingCheckpoints.peekFirst()) != null && cbc.checkpointId() < checkpointId) {
      pendingCheckpoints.removeFirst();
      if (cbc.markAborted()) {
        notifyAbortOnCancellationBarrier(cbc.checkpointId());
      }
    }
    if (cbc != null && cbc.checkpointId() == checkpointId) {
      if (cbc.markAborted()) {
        notifyAbortOnCancellationBarrier(checkpointId);
      }
      if (cbc.incrementBarrierCount() == totalNumberOfInputChannels) {
        pendingCheckpoints.removeFirst();
      }
    }
 else     if (checkpointId > latestPendingCheckpointID) {
      notifyAbortOnCancellationBarrier(checkpointId);
      latestPendingCheckpointID=checkpointId;
      CheckpointBarrierCount abortedMarker=new CheckpointBarrierCount(checkpointId);
      abortedMarker.markAborted();
      pendingCheckpoints.addFirst(abortedMarker);
    }
 else {
    }
  }
  @Override public void processEndOfPartition() throws IOException {
    while (!pendingCheckpoints.isEmpty()) {
      CheckpointBarrierCount barrierCount=pendingCheckpoints.removeFirst();
      if (barrierCount.markAborted()) {
        notifyAbort(barrierCount.checkpointId(),new CheckpointException(CheckpointFailureReason.CHECKPOINT_DECLINED_INPUT_END_OF_STREAM));
      }
    }
  }
  public long getLatestCheckpointId(){
    return pendingCheckpoints.isEmpty() ? -1 : pendingCheckpoints.peekLast().checkpointId();
  }
  public boolean isCheckpointPending(){
    return !pendingCheckpoints.isEmpty();
  }
  /** 
 * Simple class for a checkpoint ID with a barrier counter.
 */
private static final class CheckpointBarrierCount {
    private final long checkpointId;
    private int barrierCount;
    private boolean aborted;
    CheckpointBarrierCount(    long checkpointId){
      this.checkpointId=checkpointId;
      this.barrierCount=1;
    }
    public long checkpointId(){
      return checkpointId;
    }
    public int incrementBarrierCount(){
      return ++barrierCount;
    }
    public boolean isAborted(){
      return aborted;
    }
    public boolean markAborted(){
      boolean firstAbort=!this.aborted;
      this.aborted=true;
      return firstAbort;
    }
    @Override public String toString(){
      return isAborted() ? String.format("checkpointID=%d - ABORTED",checkpointId) : String.format("checkpointID=%d, count=%d",checkpointId,barrierCount);
    }
  }
}
