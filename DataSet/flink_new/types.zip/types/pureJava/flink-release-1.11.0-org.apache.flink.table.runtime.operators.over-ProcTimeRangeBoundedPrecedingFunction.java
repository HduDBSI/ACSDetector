/** 
 * Process Function used for the aggregate in bounded proc-time OVER window. <p>E.g.: SELECT currtime, b, c, min(c) OVER (PARTITION BY b ORDER BY proctime RANGE BETWEEN INTERVAL '4' SECOND PRECEDING AND CURRENT ROW), max(c) OVER (PARTITION BY b ORDER BY proctime RANGE BETWEEN INTERVAL '4' SECOND PRECEDING AND CURRENT ROW) FROM T.
 */
public class ProcTimeRangeBoundedPrecedingFunction<K> extends KeyedProcessFunction<K,RowData,RowData> {
  private static final long serialVersionUID=1L;
  private static final Logger LOG=LoggerFactory.getLogger(ProcTimeRangeBoundedPrecedingFunction.class);
  private final GeneratedAggsHandleFunction genAggsHandler;
  private final LogicalType[] accTypes;
  private final LogicalType[] inputFieldTypes;
  private final long precedingTimeBoundary;
  private transient ValueState<RowData> accState;
  private transient MapState<Long,List<RowData>> inputState;
  private transient ValueState<Long> cleanupTsState;
  private transient AggsHandleFunction function;
  private transient JoinedRowData output;
  public ProcTimeRangeBoundedPrecedingFunction(  GeneratedAggsHandleFunction genAggsHandler,  LogicalType[] accTypes,  LogicalType[] inputFieldTypes,  long precedingTimeBoundary){
    this.genAggsHandler=genAggsHandler;
    this.accTypes=accTypes;
    this.inputFieldTypes=inputFieldTypes;
    this.precedingTimeBoundary=precedingTimeBoundary;
  }
  @Override public void open(  Configuration parameters) throws Exception {
    function=genAggsHandler.newInstance(getRuntimeContext().getUserCodeClassLoader());
    function.open(new PerKeyStateDataViewStore(getRuntimeContext()));
    output=new JoinedRowData();
    RowDataTypeInfo inputType=new RowDataTypeInfo(inputFieldTypes);
    ListTypeInfo<RowData> rowListTypeInfo=new ListTypeInfo<>(inputType);
    MapStateDescriptor<Long,List<RowData>> mapStateDescriptor=new MapStateDescriptor<>("inputState",BasicTypeInfo.LONG_TYPE_INFO,rowListTypeInfo);
    inputState=getRuntimeContext().getMapState(mapStateDescriptor);
    RowDataTypeInfo accTypeInfo=new RowDataTypeInfo(accTypes);
    ValueStateDescriptor<RowData> stateDescriptor=new ValueStateDescriptor<RowData>("accState",accTypeInfo);
    accState=getRuntimeContext().getState(stateDescriptor);
    ValueStateDescriptor<Long> cleanupTsStateDescriptor=new ValueStateDescriptor<>("cleanupTsState",Types.LONG);
    this.cleanupTsState=getRuntimeContext().getState(cleanupTsStateDescriptor);
  }
  @Override public void processElement(  RowData input,  KeyedProcessFunction<K,RowData,RowData>.Context ctx,  Collector<RowData> out) throws Exception {
    long currentTime=ctx.timerService().currentProcessingTime();
    List<RowData> rowList=inputState.get(currentTime);
    if (rowList == null) {
      rowList=new ArrayList<RowData>();
      ctx.timerService().registerProcessingTimeTimer(currentTime + 1);
      registerCleanupTimer(ctx,currentTime);
    }
    rowList.add(input);
    inputState.put(currentTime,rowList);
  }
  private void registerCleanupTimer(  KeyedProcessFunction<K,RowData,RowData>.Context ctx,  long timestamp) throws Exception {
    long minCleanupTimestamp=timestamp + precedingTimeBoundary + 1;
    long maxCleanupTimestamp=timestamp + (long)(precedingTimeBoundary * 1.5) + 1;
    Long curCleanupTimestamp=cleanupTsState.value();
    if (curCleanupTimestamp == null || curCleanupTimestamp < minCleanupTimestamp) {
      ctx.timerService().registerProcessingTimeTimer(maxCleanupTimestamp);
      cleanupTsState.update(maxCleanupTimestamp);
    }
  }
  @Override public void onTimer(  long timestamp,  KeyedProcessFunction<K,RowData,RowData>.OnTimerContext ctx,  Collector<RowData> out) throws Exception {
    Long cleanupTimestamp=cleanupTsState.value();
    if (cleanupTimestamp != null && cleanupTimestamp <= timestamp) {
      inputState.clear();
      accState.clear();
      cleanupTsState.clear();
      function.cleanup();
      return;
    }
    ((TimestampedCollector)out).eraseTimestamp();
    long currentTime=timestamp - 1;
    List<RowData> currentElements=inputState.get(currentTime);
    if (null == currentElements) {
      return;
    }
    RowData accumulators=accState.value();
    if (null == accumulators) {
      accumulators=function.createAccumulators();
    }
    function.setAccumulators(accumulators);
    long limit=currentTime - precedingTimeBoundary;
    Iterator<Long> iter=inputState.keys().iterator();
    List<Long> markToRemove=new ArrayList<Long>();
    while (iter.hasNext()) {
      Long elementKey=iter.next();
      if (elementKey < limit) {
        List<RowData> elementsRemove=inputState.get(elementKey);
        if (elementsRemove != null) {
          int iRemove=0;
          while (iRemove < elementsRemove.size()) {
            RowData retractRow=elementsRemove.get(iRemove);
            function.retract(retractRow);
            iRemove+=1;
          }
        }
 else {
          LOG.warn("The state is cleared because of state ttl. " + "This will result in incorrect result. " + "You can increase the state ttl to avoid this.");
        }
        markToRemove.add(elementKey);
      }
    }
    int i=0;
    while (i < markToRemove.size()) {
      inputState.remove(markToRemove.get(i));
      i+=1;
    }
    int iElemenets=0;
    while (iElemenets < currentElements.size()) {
      RowData input=currentElements.get(iElemenets);
      function.accumulate(input);
      iElemenets+=1;
    }
    iElemenets=0;
    RowData aggValue=function.getValue();
    while (iElemenets < currentElements.size()) {
      RowData input=currentElements.get(iElemenets);
      output.replace(input,aggValue);
      out.collect(output);
      iElemenets+=1;
    }
    accumulators=function.getAccumulators();
    accState.update(accumulators);
  }
  @Override public void close() throws Exception {
    if (null != function) {
      function.close();
    }
  }
}
