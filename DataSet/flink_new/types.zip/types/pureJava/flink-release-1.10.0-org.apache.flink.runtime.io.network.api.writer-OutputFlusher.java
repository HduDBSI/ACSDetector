/** 
 * A dedicated thread that periodically flushes the output buffers, to set upper latency bounds. <p>The thread is daemonic, because it is only a utility thread.
 */
private class OutputFlusher extends Thread {
  private final long timeout;
  private volatile boolean running=true;
  OutputFlusher(  String name,  long timeout){
    super(name);
    setDaemon(true);
    this.timeout=timeout;
  }
  public void terminate(){
    running=false;
    interrupt();
  }
  @Override public void run(){
    try {
      while (running) {
        try {
          Thread.sleep(timeout);
        }
 catch (        InterruptedException e) {
          if (running) {
            throw new Exception(e);
          }
        }
        flushAll();
      }
    }
 catch (    Throwable t) {
      notifyFlusherException(t);
    }
  }
}
