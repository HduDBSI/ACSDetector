/** 
 * Base of all types that represent checkpointed state. Specializations are for example  {@link StateHandle StateHandles} (directly resolve to state).<p>State objects define how to: <ul> <li><b>Discard State</b>: The  {@link #discardState()} method defines how state is permanentlydisposed/deleted. After that method call, state may not be recoverable any more.</li> </ul>
 */
public interface StateObject extends java.io.Serializable {
  /** 
 * Discards the state referred to by this handle, to free up resources in the persistent storage. This method is called when the handle will not be used any more.
 */
  void discardState() throws Exception ;
  /** 
 * Returns the size of the state in bytes. <p>If the the size is not known, return  {@code 0}.
 * @return Size of the state in bytes.
 */
  long getStateSize();
}
