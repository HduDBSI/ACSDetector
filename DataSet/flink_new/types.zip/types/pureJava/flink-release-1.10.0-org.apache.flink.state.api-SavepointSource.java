private static class SavepointSource implements SourceFunction<Integer> {
  private static volatile boolean finished;
  private volatile boolean running=true;
  private static final Integer[] elements={1,2,3};
  @Override public void run(  SourceContext<Integer> ctx){
synchronized (ctx.getCheckpointLock()) {
      for (      Integer element : elements) {
        ctx.collect(element);
      }
      finished=true;
    }
    while (running) {
      try {
        Thread.sleep(100);
      }
 catch (      InterruptedException e) {
      }
    }
  }
  @Override public void cancel(){
    running=false;
  }
  private static void initializeForTest(){
    finished=false;
  }
  private static boolean isFinished(){
    return finished;
  }
  private static List<Integer> getElements(){
    return Arrays.asList(elements);
  }
}
