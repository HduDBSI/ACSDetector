/** 
 * Interface for releasing memory buffers.
 */
public interface BufferPoolOwner {
  void releaseMemory(  int numBuffersToRecycle) throws IOException ;
}
