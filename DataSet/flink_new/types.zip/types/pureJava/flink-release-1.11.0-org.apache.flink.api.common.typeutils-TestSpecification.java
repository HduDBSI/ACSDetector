/** 
 * Specification of one test scenario. This mainly needs a  {@link PreUpgradeSetup} and {@link UpgradeVerifier}.
 */
public static class TestSpecification<PreviousElementT,UpgradedElementT> {
  private final String name;
  private final MigrationVersion migrationVersion;
  private final ClassLoaderSafePreUpgradeSetup<PreviousElementT> setup;
  private final ClassLoaderSafeUpgradeVerifier<UpgradedElementT> verifier;
  public TestSpecification(  String name,  MigrationVersion migrationVersion,  Class<? extends PreUpgradeSetup<PreviousElementT>> setupClass,  Class<? extends UpgradeVerifier<UpgradedElementT>> verifierClass) throws Exception {
    this.name=checkNotNull(name);
    this.migrationVersion=checkNotNull(migrationVersion);
    this.setup=new ClassLoaderSafePreUpgradeSetup<>(setupClass);
    this.verifier=new ClassLoaderSafeUpgradeVerifier<>(verifierClass);
  }
  @Override public String toString(){
    return name + " / " + migrationVersion;
  }
}
