/** 
 * Rule to remove single_value rel. For cases like <blockquote> AggRel single_value proj/filter/agg/ join on unique LHS key AggRel single group </blockquote>
 */
public static final class RemoveSingleAggregateRule extends RelRule<RemoveSingleAggregateRule.Config> {
  static Config config(  RelBuilderFactory f){
    return Config.EMPTY.withRelBuilderFactory(f).withOperandSupplier(b0 -> b0.operand(Aggregate.class).oneInput(b1 -> b1.operand(Project.class).oneInput(b2 -> b2.operand(Aggregate.class).anyInputs()))).as(Config.class);
  }
  /** 
 * Creates a RemoveSingleAggregateRule. 
 */
  protected RemoveSingleAggregateRule(  Config config){
    super(config);
  }
  @Override public void onMatch(  RelOptRuleCall call){
    Aggregate singleAggregate=call.rel(0);
    Project project=call.rel(1);
    Aggregate aggregate=call.rel(2);
    if ((!singleAggregate.getGroupSet().isEmpty()) || (singleAggregate.getAggCallList().size() != 1) || !(singleAggregate.getAggCallList().get(0).getAggregation() instanceof SqlSingleValueAggFunction)) {
      return;
    }
    List<RexNode> projExprs=project.getProjects();
    if (projExprs.size() != 1) {
      return;
    }
    if (!aggregate.getGroupSet().isEmpty()) {
      return;
    }
    final RelBuilder relBuilder=call.builder();
    final boolean nullable=singleAggregate.getAggCallList().get(0).getType().isNullable();
    final RelDataType type=relBuilder.getTypeFactory().createTypeWithNullability(projExprs.get(0).getType(),nullable);
    final RexNode cast=relBuilder.getRexBuilder().makeCast(type,projExprs.get(0));
    relBuilder.push(aggregate).project(cast);
    call.transformTo(relBuilder.build());
  }
  /** 
 * Rule configuration. 
 */
public interface Config extends RelRule.Config {
    @Override default RemoveSingleAggregateRule toRule(){
      return new RemoveSingleAggregateRule(this);
    }
  }
}
