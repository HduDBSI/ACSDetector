/** 
 * Termination mode for the  {@link JobCancellationHandler}.
 */
public class TerminationModeQueryParameter extends MessageQueryParameter<TerminationModeQueryParameter.TerminationMode> {
  private static final String key="mode";
  public TerminationModeQueryParameter(){
    super(key,MessageParameterRequisiteness.OPTIONAL);
  }
  @Override public TerminationMode convertStringToValue(  String value){
    return TerminationMode.valueOf(value.toUpperCase());
  }
  @Override public String convertValueToString(  TerminationMode value){
    return value.name().toLowerCase();
  }
  /** 
 * Supported termination modes.
 */
  public enum TerminationMode {  CANCEL,   STOP}
}
