/** 
 * A blob store doing nothing.
 */
public class VoidBlobStore implements BlobStoreService {
  @Override public void put(  File localFile,  BlobKey blobKey) throws IOException {
  }
  @Override public void put(  File localFile,  JobID jobId,  String key) throws IOException {
  }
  @Override public void get(  BlobKey blobKey,  File localFile) throws IOException {
  }
  @Override public void get(  JobID jobId,  String key,  File localFile) throws IOException {
  }
  @Override public void delete(  BlobKey blobKey){
  }
  @Override public void delete(  JobID jobId,  String key){
  }
  @Override public void deleteAll(  JobID jobId){
  }
  @Override public void closeAndCleanupAllData(){
  }
  @Override public void close() throws IOException {
  }
}
