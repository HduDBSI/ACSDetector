/** 
 * Tests for  {@link StateUtil}. 
 */
public class StateUtilTest {
  @Test public void testDiscardStateSize() throws Exception {
    assertEquals(1234,discardStateFuture(completedFuture(new TestStateObject(1234))));
    assertEquals(0,discardStateFuture(null));
    assertEquals(0,discardStateFuture(new CompletableFuture<>()));
    assertEquals(0,discardStateFuture(completedExceptionally(new RuntimeException())));
    assertEquals(0,discardStateFuture(emptyFuture(false,true)));
    assertEquals(0,discardStateFuture(emptyFuture(false,false)));
    assertEquals(0,discardStateFuture(emptyFuture(true,true)));
    assertEquals(0,discardStateFuture(emptyFuture(true,false)));
  }
  @Test public void unexpectedStateExceptionForSingleExpectedType(){
    Exception exception=StateUtil.unexpectedStateHandleException(KeyGroupsStateHandle.class,KeyGroupsStateHandle.class);
    assertThat(exception.getMessage(),containsString("Unexpected state handle type, expected one of: class org.apache.flink.runtime.state.KeyGroupsStateHandle, but found: class org.apache.flink.runtime.state.KeyGroupsStateHandle. This can mostly happen when a different StateBackend from the one that was used for taking a checkpoint/savepoint is used when restoring."));
  }
  @Test @SuppressWarnings("unchecked") public void unexpectedStateExceptionForMultipleExpectedTypes(){
    Exception exception=StateUtil.unexpectedStateHandleException(new Class[]{KeyGroupsStateHandle.class,KeyGroupsStateHandle.class},KeyGroupsStateHandle.class);
    assertThat(exception.getMessage(),containsString("Unexpected state handle type, expected one of: class org.apache.flink.runtime.state.KeyGroupsStateHandle, class org.apache.flink.runtime.state.KeyGroupsStateHandle, but found: class org.apache.flink.runtime.state.KeyGroupsStateHandle. This can mostly happen when a different StateBackend from the one that was used for taking a checkpoint/savepoint is used when restoring."));
  }
  private static <T>Future<T> emptyFuture(  boolean done,  boolean canBeCancelled){
    return new Future<T>(){
      @Override public boolean cancel(      boolean mayInterruptIfRunning){
        return canBeCancelled;
      }
      @Override public boolean isCancelled(){
        return false;
      }
      @Override public boolean isDone(){
        return done;
      }
      @Override public T get(){
        throw new UnsupportedOperationException();
      }
      @Override public T get(      long timeout,      TimeUnit unit){
        throw new UnsupportedOperationException();
      }
    }
;
  }
private static class TestStateObject implements StateObject {
    private static final long serialVersionUID=-8070326169926626355L;
    private final int size;
    private TestStateObject(    int size){
      this.size=size;
    }
    @Override public long getStateSize(){
      return size;
    }
    @Override public void discardState(){
    }
  }
}
