/** 
 * A descriptor to deploy a cluster (e.g. Yarn or Mesos) and return a Client for Cluster communication.
 * @param < T > Type of the cluster id
 */
public interface ClusterDescriptor<T> extends AutoCloseable {
  /** 
 * Returns a String containing details about the cluster (NodeManagers, available memory, ...).
 */
  String getClusterDescription();
  /** 
 * Retrieves an existing Flink Cluster.
 * @param clusterId The unique identifier of the running cluster
 * @return Client for the cluster
 * @throws ClusterRetrieveException if the cluster client could not be retrieved
 */
  ClusterClient<T> retrieve(  T clusterId) throws ClusterRetrieveException ;
  /** 
 * Triggers deployment of a cluster.
 * @param clusterSpecification Cluster specification defining the cluster to deploy
 * @return Client for the cluster
 * @throws ClusterDeploymentException if the cluster could not be deployed
 */
  ClusterClient<T> deploySessionCluster(  ClusterSpecification clusterSpecification) throws ClusterDeploymentException ;
  /** 
 * Deploys a per-job cluster with the given job on the cluster.
 * @param clusterSpecification Initial cluster specification with which the Flink cluster is launched
 * @param jobGraph JobGraph with which the job cluster is started
 * @param detached true if the cluster should be stopped after the job completion without serving the result,otherwise false
 * @return Cluster client to talk to the Flink cluster
 * @throws ClusterDeploymentException if the cluster could not be deployed
 */
  ClusterClient<T> deployJobCluster(  final ClusterSpecification clusterSpecification,  final JobGraph jobGraph,  final boolean detached) throws ClusterDeploymentException ;
  /** 
 * Terminates the cluster with the given cluster id.
 * @param clusterId identifying the cluster to shut down
 * @throws FlinkException if the cluster could not be terminated
 */
  void killCluster(  T clusterId) throws FlinkException ;
}
