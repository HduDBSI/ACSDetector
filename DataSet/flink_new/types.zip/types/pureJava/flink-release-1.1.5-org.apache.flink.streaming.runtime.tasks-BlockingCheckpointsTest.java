/** 
 * This test checks that task checkpoints that block and do not react to thread interrupts are
 */
public class BlockingCheckpointsTest {
  private static final OneShotLatch IN_CHECKPOINT_LATCH=new OneShotLatch();
  @Test public void testBlockingNonInterruptibleCheckpoint() throws Exception {
    Configuration taskConfig=new Configuration();
    StreamConfig cfg=new StreamConfig(taskConfig);
    cfg.setTimeCharacteristic(TimeCharacteristic.ProcessingTime);
    cfg.setStreamOperator(new TestOperator());
    cfg.setStateBackend(new LockingStreamStateBackend());
    Task task=createTask(taskConfig);
    task.startTaskThread();
    IN_CHECKPOINT_LATCH.await();
    task.cancelExecution();
    task.getExecutingThread().join();
    assertEquals(ExecutionState.CANCELED,task.getExecutionState());
    assertNull(task.getFailureCause());
  }
  private static Task createTask(  Configuration taskConfig) throws IOException {
    JobInformation jobInformation=new JobInformation(new JobID(),"test job name",new SerializedValue<>(new ExecutionConfig()),new Configuration(),Collections.<BlobKey>emptyList(),Collections.<URL>emptyList());
    TaskInformation taskInformation=new TaskInformation(new JobVertexID(),"test task name",1,TestStreamTask.class.getName(),taskConfig);
    return new Task(jobInformation,taskInformation,new ExecutionAttemptID(),0,0,Collections.<ResultPartitionDeploymentDescriptor>emptyList(),Collections.<InputGateDeploymentDescriptor>emptyList(),0,null,mock(MemoryManager.class),mock(IOManager.class),mock(NetworkEnvironment.class),mock(BroadcastVariableManager.class),mock(ActorGateway.class),mock(ActorGateway.class),new FiniteDuration(10,TimeUnit.SECONDS),new FallbackLibraryCacheManager(),new FileCache(new Configuration()),new TaskManagerRuntimeInfo("localhost",new Configuration(),EnvironmentInformation.getTemporaryFileDirectory()),new UnregisteredTaskMetricsGroup());
  }
private static class LockingStreamStateBackend extends AbstractStateBackend {
    private static final long serialVersionUID=1L;
    private final LockingOutputStream out=new LockingOutputStream();
    @Override public void disposeAllStateForCurrentJob(){
    }
    @Override public void close() throws IOException {
      out.close();
    }
    @Override public CheckpointStateOutputStream createCheckpointStateOutputStream(    long checkpointID,    long timestamp) throws Exception {
      return out;
    }
    @Override protected <N,T>ValueState<T> createValueState(    TypeSerializer<N> namespaceSerializer,    ValueStateDescriptor<T> stateDesc) throws Exception {
      throw new UnsupportedOperationException();
    }
    @Override protected <N,T>ListState<T> createListState(    TypeSerializer<N> namespaceSerializer,    ListStateDescriptor<T> stateDesc) throws Exception {
      throw new UnsupportedOperationException();
    }
    @Override protected <N,T>ReducingState<T> createReducingState(    TypeSerializer<N> namespaceSerializer,    ReducingStateDescriptor<T> stateDesc) throws Exception {
      throw new UnsupportedOperationException();
    }
    @Override protected <N,T,ACC>FoldingState<T,ACC> createFoldingState(    TypeSerializer<N> namespaceSerializer,    FoldingStateDescriptor<T,ACC> stateDesc) throws Exception {
      throw new UnsupportedOperationException();
    }
    @Override public <S extends Serializable>StateHandle<S> checkpointStateSerializable(    S state,    long checkpointID,    long timestamp) throws Exception {
      throw new UnsupportedOperationException();
    }
  }
private static final class LockingOutputStream extends CheckpointStateOutputStream implements Serializable {
    private static final long serialVersionUID=1L;
    private final SerializableObject lock=new SerializableObject();
    private volatile boolean closed;
    @Override public StreamStateHandle closeAndGetHandle() throws IOException {
      throw new UnsupportedOperationException();
    }
    @Override public void write(    int b) throws IOException {
synchronized (lock) {
        while (!closed) {
          try {
            lock.wait();
          }
 catch (          InterruptedException ignored) {
          }
        }
      }
    }
    @Override public void close() throws IOException {
synchronized (lock) {
        closed=true;
        lock.notifyAll();
      }
    }
  }
@SuppressWarnings("serial") private static final class TestOperator extends StreamFilter<Object> {
    private static final long serialVersionUID=1L;
    public TestOperator(){
      super(new FilterFunction<Object>(){
        @Override public boolean filter(        Object value){
          return false;
        }
      }
);
    }
    @Override public StreamTaskState snapshotOperatorState(    long checkpointId,    long timestamp) throws Exception {
      AbstractStateBackend stateBackend=getStateBackend();
      CheckpointStateOutputStream outStream=stateBackend.createCheckpointStateOutputStream(checkpointId,timestamp);
      IN_CHECKPOINT_LATCH.trigger();
      outStream.write(1);
      return null;
    }
  }
public static final class TestStreamTask extends OneInputStreamTask<Object,Object> {
    @Override public void init(){
    }
    @Override protected void run() throws Exception {
      triggerCheckpointOnBarrier(11L,System.currentTimeMillis());
    }
    @Override protected void cleanup(){
    }
    @Override protected void cancelTask(){
    }
  }
}
