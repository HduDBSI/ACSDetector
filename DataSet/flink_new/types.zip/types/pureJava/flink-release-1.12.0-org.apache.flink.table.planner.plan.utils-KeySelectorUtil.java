/** 
 * Utility for KeySelector.
 */
public class KeySelectorUtil {
  /** 
 * Create a RowDataKeySelector to extract keys from DataStream which type is  {@link InternalTypeInfo} of {@link RowData}.
 * @param keyFields key fields
 * @param rowType type of DataStream to extract keys
 * @return the RowDataKeySelector to extract keys from DataStream which type is {@link InternalTypeInfo} of {@link RowData}.
 */
  public static RowDataKeySelector getRowDataSelector(  int[] keyFields,  InternalTypeInfo<RowData> rowType){
    if (keyFields.length > 0) {
      LogicalType[] inputFieldTypes=rowType.toRowFieldTypes();
      LogicalType[] keyFieldTypes=new LogicalType[keyFields.length];
      for (int i=0; i < keyFields.length; ++i) {
        keyFieldTypes[i]=inputFieldTypes[keyFields[i]];
      }
      RowType returnType=RowType.of(keyFieldTypes);
      RowType inputType=rowType.toRowType();
      GeneratedProjection generatedProjection=ProjectionCodeGenerator.generateProjection(CodeGeneratorContext.apply(new TableConfig()),"KeyProjection",inputType,returnType,keyFields);
      InternalTypeInfo<RowData> keyRowType=InternalTypeInfo.of(returnType);
      return new BinaryRowDataKeySelector(keyRowType,generatedProjection);
    }
 else {
      return EmptyRowDataKeySelector.INSTANCE;
    }
  }
}
