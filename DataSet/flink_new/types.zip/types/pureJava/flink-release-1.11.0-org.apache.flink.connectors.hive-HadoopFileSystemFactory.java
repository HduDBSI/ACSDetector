/** 
 * Hive  {@link FileSystemFactory}, hive need use job conf to create file system.
 */
public class HadoopFileSystemFactory implements FileSystemFactory {
  private static final long serialVersionUID=1L;
  private JobConfWrapper jobConfWrapper;
  HadoopFileSystemFactory(  JobConf jobConf){
    this.jobConfWrapper=new JobConfWrapper(jobConf);
  }
  @Override public FileSystem create(  URI uri) throws IOException {
    return new HadoopFileSystem(new Path(uri).getFileSystem(jobConfWrapper.conf()));
  }
}
