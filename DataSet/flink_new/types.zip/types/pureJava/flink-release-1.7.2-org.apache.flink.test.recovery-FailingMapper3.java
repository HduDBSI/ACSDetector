private static class FailingMapper3<T> extends RichMapFunction<T,T> {
  private static volatile int failuresBeforeSuccess=3;
  @Override public T map(  T value) throws Exception {
    if (failuresBeforeSuccess > 0 && getRuntimeContext().getIndexOfThisSubtask() == 1) {
      failuresBeforeSuccess--;
      throw new Exception("Test Failure");
    }
    return value;
  }
}
