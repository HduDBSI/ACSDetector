private static class ProducerThread extends CheckedThread {
  private final Random rnd=new Random();
  private final Source[] sources;
  private final int numTotal;
  private final int maxChunk;
  private final int yieldAfter;
  ProducerThread(  Source[] sources,  int numTotal,  int maxChunk,  int yieldAfter){
    this.sources=sources;
    this.numTotal=numTotal;
    this.maxChunk=maxChunk;
    this.yieldAfter=yieldAfter;
  }
  @Override public void go() throws Exception {
    final Buffer buffer=InputChannelTestUtils.createMockBuffer(100);
    int nextYield=numTotal - yieldAfter;
    for (int i=numTotal; i > 0; ) {
      final int nextChannel=rnd.nextInt(sources.length);
      final int chunk=Math.min(i,rnd.nextInt(maxChunk) + 1);
      final Source next=sources[nextChannel];
      for (int k=chunk; k > 0; --k) {
        next.addBuffer(buffer);
      }
      i-=chunk;
      if (i <= nextYield) {
        nextYield-=yieldAfter;
        Thread.yield();
      }
    }
  }
}
