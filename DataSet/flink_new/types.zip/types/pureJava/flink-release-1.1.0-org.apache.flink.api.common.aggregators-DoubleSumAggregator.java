/** 
 * An  {@link Aggregator} that sums up {@link DoubleValue} values.
 */
@SuppressWarnings("serial") @PublicEvolving public class DoubleSumAggregator implements Aggregator<DoubleValue> {
  private DoubleValue wrapper=new DoubleValue();
  private double sum;
  @Override public DoubleValue getAggregate(){
    wrapper.setValue(sum);
    return wrapper;
  }
  @Override public void aggregate(  DoubleValue element){
    sum+=element.getValue();
  }
  /** 
 * Adds the given value to the current aggregate.
 * @param value The value to add to the aggregate.
 */
  public void aggregate(  double value){
    sum+=value;
  }
  @Override public void reset(){
    sum=0;
  }
}
