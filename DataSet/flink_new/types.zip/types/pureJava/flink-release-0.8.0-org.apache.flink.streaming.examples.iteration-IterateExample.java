/** 
 * Example illustrating iterations in Flink streaming. <p> The program sums up random numbers and counts additions it performs to reach a specific threshold in an iterative streaming fashion. </p> <p> This example shows how to use: <ul> <li>streaming iterations, <li>buffer timeout to enhance latency, <li>directed outputs. </ul>
 */
public class IterateExample {
  public static void main(  String[] args) throws Exception {
    if (!parseParameters(args)) {
      return;
    }
    List<Tuple2<Double,Integer>> input=new ArrayList<Tuple2<Double,Integer>>();
    for (int i=0; i < 1000; i++) {
      input.add(new Tuple2<Double,Integer>(0.,0));
    }
    StreamExecutionEnvironment env=StreamExecutionEnvironment.getExecutionEnvironment().setBufferTimeout(1);
    IterativeDataStream<Tuple2<Double,Integer>> it=env.fromCollection(input).shuffle().iterate(5000);
    SplitDataStream<Tuple2<Double,Integer>> step=it.map(new Step()).shuffle().split(new MySelector());
    it.closeWith(step.select("iterate"));
    DataStream<Tuple1<Integer>> numbers=step.select("output").project(1).types(Integer.class);
    if (fileOutput) {
      numbers.writeAsText(outputPath,1);
    }
 else {
      numbers.print();
    }
    env.execute("Streaming Iteration Example");
  }
  /** 
 * Iteration step function which takes an input (Double , Integer) and produces an output (Double + random, Integer + 1).
 */
public static class Step extends RichMapFunction<Tuple2<Double,Integer>,Tuple2<Double,Integer>> {
    private static final long serialVersionUID=1L;
    private transient Random rnd;
    public void open(    Configuration parameters){
      rnd=new Random();
    }
    @Override public Tuple2<Double,Integer> map(    Tuple2<Double,Integer> value) throws Exception {
      return new Tuple2<Double,Integer>(value.f0 + rnd.nextDouble(),value.f1 + 1);
    }
  }
  /** 
 * OutputSelector testing which tuple needs to be iterated again.
 */
public static class MySelector implements OutputSelector<Tuple2<Double,Integer>> {
    private static final long serialVersionUID=1L;
    @Override public Iterable<String> select(    Tuple2<Double,Integer> value){
      List<String> output=new ArrayList<String>();
      if (value.f0 > 100) {
        output.add("output");
      }
 else {
        output.add("iterate");
      }
      return output;
    }
  }
  private static boolean fileOutput=false;
  private static String outputPath;
  private static boolean parseParameters(  String[] args){
    if (args.length > 0) {
      fileOutput=true;
      if (args.length == 1) {
        outputPath=args[0];
      }
 else {
        System.err.println("Usage: IterateExample <result path>");
        return false;
      }
    }
 else {
      System.out.println("Executing IterateExample with generated data.");
      System.out.println("  Provide parameter to write to file.");
      System.out.println("  Usage: IterateExample <result path>");
    }
    return true;
  }
}
