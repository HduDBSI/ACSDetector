public static class MyMapper3<D,E> implements MapFunction<PojoTuple<E,D,D>,Tuple2<E,D>> {
  private static final long serialVersionUID=1L;
  @Override public Tuple2<E,D> map(  PojoTuple<E,D,D> value) throws Exception {
    return null;
  }
}
