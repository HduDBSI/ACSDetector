/** 
 * Aggregate Function used for the groupby (without window) table aggregate. 
 */
public class GroupTableAggFunction extends KeyedProcessFunction<RowData,RowData,RowData> {
  private static final long serialVersionUID=1L;
  /** 
 * The code generated function used to handle table aggregates. 
 */
  private final GeneratedTableAggsHandleFunction genAggsHandler;
  /** 
 * The accumulator types. 
 */
  private final LogicalType[] accTypes;
  /** 
 * Used to count the number of added and retracted input records. 
 */
  private final RecordCounter recordCounter;
  /** 
 * Whether this operator will generate UPDATE_BEFORE messages. 
 */
  private final boolean generateUpdateBefore;
  /** 
 * State idle retention time which unit is MILLISECONDS. 
 */
  private final long stateRetentionTime;
  private transient TableAggsHandleFunction function=null;
  private transient ValueState<RowData> accState=null;
  /** 
 * Creates a  {@link GroupTableAggFunction}.
 * @param genAggsHandler The code generated function used to handle table aggregates.
 * @param accTypes The accumulator types.
 * @param indexOfCountStar The index of COUNT(*) in the aggregates. -1 when the input doesn'tcontain COUNT(*), i.e. doesn't contain retraction messages. We make sure there is a COUNT(*) if input stream contains retraction.
 * @param generateUpdateBefore Whether this operator will generate UPDATE_BEFORE messages.
 * @param stateRetentionTime state idle retention time which unit is MILLISECONDS.
 */
  public GroupTableAggFunction(  GeneratedTableAggsHandleFunction genAggsHandler,  LogicalType[] accTypes,  int indexOfCountStar,  boolean generateUpdateBefore,  long stateRetentionTime){
    this.genAggsHandler=genAggsHandler;
    this.accTypes=accTypes;
    this.recordCounter=RecordCounter.of(indexOfCountStar);
    this.generateUpdateBefore=generateUpdateBefore;
    this.stateRetentionTime=stateRetentionTime;
  }
  @Override public void open(  Configuration parameters) throws Exception {
    super.open(parameters);
    StateTtlConfig ttlConfig=createTtlConfig(stateRetentionTime);
    function=genAggsHandler.newInstance(getRuntimeContext().getUserCodeClassLoader());
    function.open(new PerKeyStateDataViewStore(getRuntimeContext(),ttlConfig));
    InternalTypeInfo<RowData> accTypeInfo=InternalTypeInfo.ofFields(accTypes);
    ValueStateDescriptor<RowData> accDesc=new ValueStateDescriptor<>("accState",accTypeInfo);
    if (ttlConfig.isEnabled()) {
      accDesc.enableTimeToLive(ttlConfig);
    }
    accState=getRuntimeContext().getState(accDesc);
  }
  @Override public void processElement(  RowData input,  Context ctx,  Collector<RowData> out) throws Exception {
    RowData currentKey=ctx.getCurrentKey();
    boolean firstRow;
    RowData accumulators=accState.value();
    if (null == accumulators) {
      firstRow=true;
      accumulators=function.createAccumulators();
    }
 else {
      firstRow=false;
    }
    function.setAccumulators(accumulators);
    if (!firstRow && generateUpdateBefore) {
      function.emitValue(out,currentKey,true);
    }
    if (isAccumulateMsg(input)) {
      function.accumulate(input);
    }
 else {
      function.retract(input);
    }
    accumulators=function.getAccumulators();
    if (!recordCounter.recordCountIsZero(accumulators)) {
      function.emitValue(out,currentKey,false);
      accState.update(accumulators);
    }
 else {
      accState.clear();
      function.cleanup();
    }
  }
  @Override public void close() throws Exception {
    if (function != null) {
      function.close();
    }
  }
}
