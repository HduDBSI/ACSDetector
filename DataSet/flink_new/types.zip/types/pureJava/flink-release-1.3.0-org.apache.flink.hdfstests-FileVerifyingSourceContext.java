private static class FileVerifyingSourceContext extends DummySourceContext {
  private final ContinuousFileMonitoringFunction src;
  private final OneShotLatch latch;
  private final Set<String> seenFiles;
  private int elementsBeforeNotifying=-1;
  private int elementsBeforeCanceling=-1;
  FileVerifyingSourceContext(  OneShotLatch latch,  ContinuousFileMonitoringFunction src){
    this(latch,src,-1,-1);
  }
  FileVerifyingSourceContext(  OneShotLatch latch,  ContinuousFileMonitoringFunction src,  int elementsBeforeNotifying,  int elementsBeforeCanceling){
    this.latch=latch;
    this.seenFiles=new TreeSet<>();
    this.src=src;
    this.elementsBeforeNotifying=elementsBeforeNotifying;
    this.elementsBeforeCanceling=elementsBeforeCanceling;
  }
  Set<String> getSeenFiles(){
    return this.seenFiles;
  }
  @Override public void collect(  TimestampedFileInputSplit element){
    String seenFileName=element.getPath().getName();
    this.seenFiles.add(seenFileName);
    if (seenFiles.size() == elementsBeforeNotifying && !latch.isTriggered()) {
      latch.trigger();
    }
    if (seenFiles.size() == elementsBeforeCanceling) {
      src.cancel();
    }
  }
  @Override public void close(){
    if (!latch.isTriggered()) {
      latch.trigger();
    }
    src.cancel();
  }
}
