/** 
 * Utility class that turns an  {@link InputStream} into a {@link DataInputView}.
 */
@PublicEvolving public class DataInputViewStreamWrapper extends DataInputStream implements DataInputView {
  public DataInputViewStreamWrapper(  InputStream in){
    super(in);
  }
  @Override public void skipBytesToRead(  int numBytes) throws IOException {
    if (skipBytes(numBytes) != numBytes) {
      throw new EOFException("Could not skip " + numBytes + " bytes.");
    }
  }
}
