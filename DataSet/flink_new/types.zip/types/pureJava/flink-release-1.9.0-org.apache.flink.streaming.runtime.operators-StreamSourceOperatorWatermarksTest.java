/** 
 * Tests for  {@link StreamSource} operators.
 */
@SuppressWarnings("serial") public class StreamSourceOperatorWatermarksTest {
  @Test public void testEmitMaxWatermarkForFiniteSource() throws Exception {
    StreamSource<String,FiniteSource<String>> operator=new StreamSource<>(new FiniteSource<String>());
    final List<StreamElement> output=new ArrayList<>();
    setupSourceOperator(operator,TimeCharacteristic.EventTime,0);
    OperatorChain<?,?> operatorChain=createOperatorChain(operator);
    try {
      operator.run(new Object(),mock(StreamStatusMaintainer.class),new CollectorOutput<String>(output),operatorChain);
    }
  finally {
      operatorChain.releaseOutputs();
    }
    assertEquals(1,output.size());
    assertEquals(Watermark.MAX_WATERMARK,output.get(0));
  }
  @Test public void testNoMaxWatermarkOnImmediateCancel() throws Exception {
    final List<StreamElement> output=new ArrayList<>();
    final StreamSource<String,InfiniteSource<String>> operator=new StreamSource<>(new InfiniteSource<String>());
    setupSourceOperator(operator,TimeCharacteristic.EventTime,0);
    operator.cancel();
    OperatorChain<?,?> operatorChain=createOperatorChain(operator);
    try {
      operator.run(new Object(),mock(StreamStatusMaintainer.class),new CollectorOutput<String>(output),operatorChain);
    }
  finally {
      operatorChain.releaseOutputs();
    }
    assertTrue(output.isEmpty());
  }
  @Test public void testNoMaxWatermarkOnAsyncCancel() throws Exception {
    final List<StreamElement> output=new ArrayList<>();
    final StreamSource<String,InfiniteSource<String>> operator=new StreamSource<>(new InfiniteSource<String>());
    setupSourceOperator(operator,TimeCharacteristic.EventTime,0);
    new Thread("canceler"){
      @Override public void run(){
        try {
          Thread.sleep(200);
        }
 catch (        InterruptedException ignored) {
        }
        operator.cancel();
      }
    }
.start();
    OperatorChain<?,?> operatorChain=createOperatorChain(operator);
    try {
      operator.run(new Object(),mock(StreamStatusMaintainer.class),new CollectorOutput<String>(output),operatorChain);
    }
 catch (    InterruptedException ignored) {
    }
 finally {
      operatorChain.releaseOutputs();
    }
    assertTrue(output.isEmpty());
  }
  @Test public void testAutomaticWatermarkContext() throws Exception {
    final StreamSource<String,InfiniteSource<String>> operator=new StreamSource<>(new InfiniteSource<>());
    long watermarkInterval=10;
    TestProcessingTimeService processingTimeService=new TestProcessingTimeService();
    processingTimeService.setCurrentTime(0);
    setupSourceOperator(operator,TimeCharacteristic.IngestionTime,watermarkInterval,processingTimeService);
    final List<StreamElement> output=new ArrayList<>();
    StreamSourceContexts.getSourceContext(TimeCharacteristic.IngestionTime,operator.getContainingTask().getProcessingTimeService(),operator.getContainingTask().getCheckpointLock(),operator.getContainingTask().getStreamStatusMaintainer(),new CollectorOutput<String>(output),operator.getExecutionConfig().getAutoWatermarkInterval(),-1);
    for (long i=1; i < 100; i+=watermarkInterval) {
      processingTimeService.setCurrentTime(i);
    }
    assertTrue(output.size() == 9);
    long nextWatermark=0;
    for (    StreamElement el : output) {
      nextWatermark+=watermarkInterval;
      Watermark wm=(Watermark)el;
      assertTrue(wm.getTimestamp() == nextWatermark);
    }
  }
  @SuppressWarnings("unchecked") private static <T>void setupSourceOperator(  StreamSource<T,?> operator,  TimeCharacteristic timeChar,  long watermarkInterval) throws Exception {
    setupSourceOperator(operator,timeChar,watermarkInterval,new TestProcessingTimeService());
  }
  @SuppressWarnings("unchecked") private static <T>void setupSourceOperator(  StreamSource<T,?> operator,  TimeCharacteristic timeChar,  long watermarkInterval,  final ProcessingTimeService timeProvider) throws Exception {
    ExecutionConfig executionConfig=new ExecutionConfig();
    executionConfig.setAutoWatermarkInterval(watermarkInterval);
    StreamConfig cfg=new StreamConfig(new Configuration());
    cfg.setStateBackend(new MemoryStateBackend());
    cfg.setTimeCharacteristic(timeChar);
    cfg.setOperatorID(new OperatorID());
    Environment env=new DummyEnvironment("MockTwoInputTask",1,0);
    StreamStatusMaintainer streamStatusMaintainer=mock(StreamStatusMaintainer.class);
    when(streamStatusMaintainer.getStreamStatus()).thenReturn(StreamStatus.ACTIVE);
    MockStreamTask mockTask=new MockStreamTaskBuilder(env).setConfig(cfg).setExecutionConfig(executionConfig).setStreamStatusMaintainer(streamStatusMaintainer).setProcessingTimeService(timeProvider).build();
    operator.setup(mockTask,cfg,(Output<StreamRecord<T>>)mock(Output.class));
  }
  private static OperatorChain<?,?> createOperatorChain(  AbstractStreamOperator<?> operator){
    return new OperatorChain<>(operator.getContainingTask(),StreamTask.createRecordWriters(operator.getOperatorConfig(),new MockEnvironmentBuilder().build()));
  }
private static final class FiniteSource<T> implements SourceFunction<T> {
    @Override public void run(    SourceContext<T> ctx){
    }
    @Override public void cancel(){
    }
  }
private static final class InfiniteSource<T> implements SourceFunction<T> {
    private volatile boolean running=true;
    @Override public void run(    SourceContext<T> ctx) throws Exception {
      while (running) {
        Thread.sleep(20);
      }
    }
    @Override public void cancel(){
      running=false;
    }
  }
}
