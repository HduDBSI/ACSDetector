private static class InfiniteTestSource implements SourceFunction<Integer> {
  private static final long serialVersionUID=1L;
  private volatile boolean running=true;
  @Override public void run(  SourceContext<Integer> ctx) throws Exception {
    while (running) {
synchronized (ctx.getCheckpointLock()) {
        ctx.collect(1);
      }
      Thread.sleep(1);
    }
  }
  @Override public void cancel(){
    running=false;
  }
}
