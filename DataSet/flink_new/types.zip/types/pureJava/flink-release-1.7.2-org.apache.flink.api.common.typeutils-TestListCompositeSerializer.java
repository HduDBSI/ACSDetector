private static class TestListCompositeSerializer extends CompositeSerializer<List<Object>> {
  TestListCompositeSerializer(  boolean isImmutableTargetType,  TypeSerializer<?>... fieldSerializers){
    super(isImmutableTargetType,fieldSerializers);
  }
  TestListCompositeSerializer(  PrecomputedParameters precomputed,  TypeSerializer<?>... fieldSerializers){
    super(precomputed,fieldSerializers);
  }
  @Override public List<Object> createInstance(  @Nonnull Object... values){
    return Arrays.asList(values);
  }
  @Override protected void setField(  @Nonnull List<Object> value,  int index,  Object fieldValue){
    if (precomputed.immutable) {
      throw new UnsupportedOperationException("Type is immutable");
    }
 else {
      value.set(index,fieldValue);
    }
  }
  @Override protected Object getField(  @Nonnull List<Object> value,  int index){
    return value.get(index);
  }
  @Override protected CompositeSerializer<List<Object>> createSerializerInstance(  PrecomputedParameters precomputed,  TypeSerializer<?>... originalSerializers){
    return new TestListCompositeSerializer(precomputed,originalSerializers);
  }
}
