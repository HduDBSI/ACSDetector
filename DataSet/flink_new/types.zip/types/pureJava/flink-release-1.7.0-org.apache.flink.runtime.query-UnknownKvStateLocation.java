/** 
 * Thrown if there is no  {@link KvStateLocation} found for the requestedregistration name. <p>This indicates that the requested KvState instance is not registered under this name (yet).
 */
public class UnknownKvStateLocation extends Exception {
  private static final long serialVersionUID=1L;
  public UnknownKvStateLocation(  String registrationName){
    super("No KvStateLocation found for KvState instance with name '" + registrationName + "'.");
  }
}
