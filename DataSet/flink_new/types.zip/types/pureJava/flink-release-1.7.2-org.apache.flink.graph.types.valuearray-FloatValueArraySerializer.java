/** 
 * Specialized serializer for  {@code FloatValueArray}.
 */
public final class FloatValueArraySerializer extends TypeSerializerSingleton<FloatValueArray> {
  private static final long serialVersionUID=1L;
  @Override public boolean isImmutableType(){
    return false;
  }
  @Override public FloatValueArray createInstance(){
    return new FloatValueArray();
  }
  @Override public FloatValueArray copy(  FloatValueArray from){
    return copy(from,new FloatValueArray());
  }
  @Override public FloatValueArray copy(  FloatValueArray from,  FloatValueArray reuse){
    reuse.setValue(from);
    return reuse;
  }
  @Override public int getLength(){
    return -1;
  }
  @Override public void serialize(  FloatValueArray record,  DataOutputView target) throws IOException {
    record.write(target);
  }
  @Override public FloatValueArray deserialize(  DataInputView source) throws IOException {
    return deserialize(new FloatValueArray(),source);
  }
  @Override public FloatValueArray deserialize(  FloatValueArray reuse,  DataInputView source) throws IOException {
    reuse.read(source);
    return reuse;
  }
  @Override public void copy(  DataInputView source,  DataOutputView target) throws IOException {
    FloatValueArray.copyInternal(source,target);
  }
  @Override public boolean canEqual(  Object obj){
    return obj instanceof FloatValueArraySerializer;
  }
  @Override protected boolean isCompatibleSerializationFormatIdentifier(  String identifier){
    return super.isCompatibleSerializationFormatIdentifier(identifier) || identifier.equals(LongPrimitiveArraySerializer.class.getCanonicalName());
  }
}
