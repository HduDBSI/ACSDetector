/** 
 * Represent a kubernetes resource.
 */
public abstract class KubernetesResource<T> {
  private T internalResource;
  public KubernetesResource(  T internalResource){
    this.internalResource=internalResource;
  }
  public T getInternalResource(){
    return internalResource;
  }
  public void setInternalResource(  T resource){
    this.internalResource=resource;
  }
}
