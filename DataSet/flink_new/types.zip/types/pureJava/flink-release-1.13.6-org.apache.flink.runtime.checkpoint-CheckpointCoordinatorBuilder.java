/** 
 * A helper builder for  {@link CheckpointCoordinator} to deduplicate test codes. 
 */
public static class CheckpointCoordinatorBuilder {
  private CheckpointCoordinatorConfiguration checkpointCoordinatorConfiguration=new CheckpointCoordinatorConfigurationBuilder().setMaxConcurrentCheckpoints(Integer.MAX_VALUE).build();
  private ExecutionGraph executionGraph;
  private Collection<OperatorCoordinatorCheckpointContext> coordinatorsToCheckpoint=Collections.emptyList();
  private CheckpointIDCounter checkpointIDCounter=new StandaloneCheckpointIDCounter();
  private CompletedCheckpointStore completedCheckpointStore=new StandaloneCompletedCheckpointStore(1);
  private CheckpointStorage checkpointStorage=new MemoryStateBackend();
  private Executor ioExecutor=Executors.directExecutor();
  private CheckpointsCleaner checkpointsCleaner=new CheckpointsCleaner();
  private ScheduledExecutor timer=new ManuallyTriggeredScheduledExecutor();
  private SharedStateRegistryFactory sharedStateRegistryFactory=SharedStateRegistry.DEFAULT_FACTORY;
  private CheckpointFailureManager failureManager=new CheckpointFailureManager(0,NoOpFailJobCall.INSTANCE);
  private boolean allowCheckpointsAfterTasksFinished;
  public CheckpointCoordinatorBuilder setCheckpointCoordinatorConfiguration(  CheckpointCoordinatorConfiguration checkpointCoordinatorConfiguration){
    this.checkpointCoordinatorConfiguration=checkpointCoordinatorConfiguration;
    return this;
  }
  public CheckpointCoordinatorBuilder setExecutionGraph(  ExecutionGraph executionGraph){
    this.executionGraph=executionGraph;
    return this;
  }
  public CheckpointCoordinatorBuilder setCoordinatorsToCheckpoint(  Collection<OperatorCoordinatorCheckpointContext> coordinatorsToCheckpoint){
    this.coordinatorsToCheckpoint=coordinatorsToCheckpoint;
    return this;
  }
  public CheckpointCoordinatorBuilder setCheckpointsCleaner(  CheckpointsCleaner checkpointsCleaner){
    this.checkpointsCleaner=checkpointsCleaner;
    return this;
  }
  public CheckpointCoordinatorBuilder setCheckpointIDCounter(  CheckpointIDCounter checkpointIDCounter){
    this.checkpointIDCounter=checkpointIDCounter;
    return this;
  }
  public CheckpointCoordinatorBuilder setCheckpointFailureManager(  CheckpointFailureManager checkpointFailureManager){
    this.failureManager=checkpointFailureManager;
    return this;
  }
  public CheckpointCoordinatorBuilder setCompletedCheckpointStore(  CompletedCheckpointStore completedCheckpointStore){
    this.completedCheckpointStore=completedCheckpointStore;
    return this;
  }
  public CheckpointCoordinatorBuilder setIoExecutor(  Executor ioExecutor){
    this.ioExecutor=ioExecutor;
    return this;
  }
  public CheckpointCoordinatorBuilder setTimer(  ScheduledExecutor timer){
    this.timer=timer;
    return this;
  }
  public CheckpointCoordinatorBuilder setSharedStateRegistryFactory(  SharedStateRegistryFactory sharedStateRegistryFactory){
    this.sharedStateRegistryFactory=sharedStateRegistryFactory;
    return this;
  }
  public CheckpointCoordinatorBuilder setFailureManager(  CheckpointFailureManager failureManager){
    this.failureManager=failureManager;
    return this;
  }
  public CheckpointCoordinatorBuilder setCheckpointStorage(  CheckpointStorage stateBackEnd){
    this.checkpointStorage=stateBackEnd;
    return this;
  }
  public CheckpointCoordinatorBuilder setAllowCheckpointsAfterTasksFinished(  boolean allowCheckpointsAfterTasksFinished){
    this.allowCheckpointsAfterTasksFinished=allowCheckpointsAfterTasksFinished;
    return this;
  }
  public CheckpointCoordinator build() throws Exception {
    if (executionGraph == null) {
      executionGraph=new CheckpointExecutionGraphBuilder().addJobVertex(new JobVertexID()).build();
    }
    DefaultCheckpointPlanCalculator checkpointPlanCalculator=new DefaultCheckpointPlanCalculator(executionGraph.getJobID(),new ExecutionGraphCheckpointPlanCalculatorContext(executionGraph),executionGraph.getVerticesTopologically());
    checkpointPlanCalculator.setAllowCheckpointsAfterTasksFinished(allowCheckpointsAfterTasksFinished);
    return new CheckpointCoordinator(executionGraph.getJobID(),checkpointCoordinatorConfiguration,coordinatorsToCheckpoint,checkpointIDCounter,completedCheckpointStore,checkpointStorage,ioExecutor,checkpointsCleaner,timer,sharedStateRegistryFactory,failureManager,checkpointPlanCalculator,new ExecutionAttemptMappingProvider(executionGraph.getAllExecutionVertices()));
  }
}
