private static class TestingEvent implements OperatorEvent {
  private static final long serialVersionUID=-3289352911927668275L;
}
