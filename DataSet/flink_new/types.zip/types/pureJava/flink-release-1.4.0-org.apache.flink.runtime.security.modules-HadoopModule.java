/** 
 * Responsible for installing a Hadoop login user.
 */
public class HadoopModule implements SecurityModule {
  private static final Logger LOG=LoggerFactory.getLogger(HadoopModule.class);
  private final SecurityConfiguration securityConfig;
  private final Configuration hadoopConfiguration;
  public HadoopModule(  SecurityConfiguration securityConfiguration,  Configuration hadoopConfiguration){
    this.securityConfig=checkNotNull(securityConfiguration);
    this.hadoopConfiguration=checkNotNull(hadoopConfiguration);
  }
  @Override public void install() throws SecurityInstallException {
    UserGroupInformation.setConfiguration(hadoopConfiguration);
    UserGroupInformation loginUser;
    try {
      if (UserGroupInformation.isSecurityEnabled() && !StringUtils.isBlank(securityConfig.getKeytab()) && !StringUtils.isBlank(securityConfig.getPrincipal())) {
        String keytabPath=(new File(securityConfig.getKeytab())).getAbsolutePath();
        UserGroupInformation.loginUserFromKeytab(securityConfig.getPrincipal(),keytabPath);
        loginUser=UserGroupInformation.getLoginUser();
        String fileLocation=System.getenv(UserGroupInformation.HADOOP_TOKEN_FILE_LOCATION);
        if (fileLocation != null) {
          try {
            Method readTokenStorageFileMethod=Credentials.class.getMethod("readTokenStorageFile",File.class,org.apache.hadoop.conf.Configuration.class);
            Credentials cred=(Credentials)readTokenStorageFileMethod.invoke(null,new File(fileLocation),hadoopConfiguration);
            Method getAllTokensMethod=Credentials.class.getMethod("getAllTokens");
            Credentials credentials=new Credentials();
            final Text hdfsDelegationTokenKind=new Text("HDFS_DELEGATION_TOKEN");
            Collection<Token<? extends TokenIdentifier>> usrTok=(Collection<Token<? extends TokenIdentifier>>)getAllTokensMethod.invoke(cred);
            for (            Token<? extends TokenIdentifier> token : usrTok) {
              if (!token.getKind().equals(hdfsDelegationTokenKind)) {
                final Text id=new Text(token.getIdentifier());
                credentials.addToken(id,token);
              }
            }
            Method addCredentialsMethod=UserGroupInformation.class.getMethod("addCredentials",Credentials.class);
            addCredentialsMethod.invoke(loginUser,credentials);
          }
 catch (          NoSuchMethodException e) {
            LOG.warn("Could not find method implementations in the shaded jar. Exception: {}",e);
          }
catch (          InvocationTargetException e) {
            throw e.getTargetException();
          }
        }
      }
 else {
        try {
          Method loginUserFromSubjectMethod=UserGroupInformation.class.getMethod("loginUserFromSubject",Subject.class);
          loginUserFromSubjectMethod.invoke(null,(Subject)null);
        }
 catch (        NoSuchMethodException e) {
          LOG.warn("Could not find method implementations in the shaded jar. Exception: {}",e);
        }
catch (        InvocationTargetException e) {
          throw e.getTargetException();
        }
        loginUser=UserGroupInformation.getLoginUser();
      }
      if (UserGroupInformation.isSecurityEnabled()) {
        if (securityConfig.useTicketCache() && !loginUser.hasKerberosCredentials()) {
          if (!HadoopUtils.hasHDFSDelegationToken()) {
            LOG.warn("Hadoop security is enabled but current login user does not have Kerberos credentials");
          }
        }
      }
      LOG.info("Hadoop user set to {}",loginUser);
    }
 catch (    Throwable ex) {
      throw new SecurityInstallException("Unable to set the Hadoop login user",ex);
    }
  }
  @Override public void uninstall() throws SecurityInstallException {
    throw new UnsupportedOperationException();
  }
}
