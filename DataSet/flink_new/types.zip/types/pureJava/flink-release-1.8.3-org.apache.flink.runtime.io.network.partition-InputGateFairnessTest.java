/** 
 * Tests verifying fairness in input gates.
 */
public class InputGateFairnessTest {
  @Test public void testFairConsumptionLocalChannelsPreFilled() throws Exception {
    final int numberOfChannels=37;
    final int buffersPerChannel=27;
    final ResultPartition resultPartition=mock(ResultPartition.class);
    final BufferConsumer bufferConsumer=createFilledBufferConsumer(42);
    final PipelinedSubpartition[] sources=new PipelinedSubpartition[numberOfChannels];
    for (int i=0; i < numberOfChannels; i++) {
      PipelinedSubpartition partition=new PipelinedSubpartition(0,resultPartition);
      for (int p=0; p < buffersPerChannel; p++) {
        partition.add(bufferConsumer.copy());
      }
      partition.finish();
      sources[i]=partition;
    }
    ResultPartitionManager resultPartitionManager=createResultPartitionManager(sources);
    SingleInputGate gate=new FairnessVerifyingInputGate("Test Task Name",new JobID(),new IntermediateDataSetID(),0,numberOfChannels,mock(TaskActions.class),UnregisteredMetricGroups.createUnregisteredTaskMetricGroup().getIOMetricGroup(),true);
    for (int i=0; i < numberOfChannels; i++) {
      LocalInputChannel channel=new LocalInputChannel(gate,i,new ResultPartitionID(),resultPartitionManager,mock(TaskEventDispatcher.class),UnregisteredMetricGroups.createUnregisteredTaskMetricGroup().getIOMetricGroup());
      gate.setInputChannel(new IntermediateResultPartitionID(),channel);
    }
    for (int i=numberOfChannels * (buffersPerChannel + 1); i > 0; --i) {
      assertNotNull(gate.getNextBufferOrEvent());
      int min=Integer.MAX_VALUE;
      int max=0;
      for (      PipelinedSubpartition source : sources) {
        int size=source.getCurrentNumberOfBuffers();
        min=Math.min(min,size);
        max=Math.max(max,size);
      }
      assertTrue(max == min || max == (min + 1));
    }
    assertFalse(gate.getNextBufferOrEvent().isPresent());
  }
  @Test public void testFairConsumptionLocalChannels() throws Exception {
    final int numberOfChannels=37;
    final int buffersPerChannel=27;
    final ResultPartition resultPartition=mock(ResultPartition.class);
    try (BufferConsumer bufferConsumer=createFilledBufferConsumer(42)){
      final PipelinedSubpartition[] sources=new PipelinedSubpartition[numberOfChannels];
      for (int i=0; i < numberOfChannels; i++) {
        sources[i]=new PipelinedSubpartition(0,resultPartition);
      }
      ResultPartitionManager resultPartitionManager=createResultPartitionManager(sources);
      SingleInputGate gate=new FairnessVerifyingInputGate("Test Task Name",new JobID(),new IntermediateDataSetID(),0,numberOfChannels,mock(TaskActions.class),UnregisteredMetricGroups.createUnregisteredTaskMetricGroup().getIOMetricGroup(),true);
      for (int i=0; i < numberOfChannels; i++) {
        LocalInputChannel channel=new LocalInputChannel(gate,i,new ResultPartitionID(),resultPartitionManager,mock(TaskEventDispatcher.class),UnregisteredMetricGroups.createUnregisteredTaskMetricGroup().getIOMetricGroup());
        gate.setInputChannel(new IntermediateResultPartitionID(),channel);
      }
      sources[12].add(bufferConsumer.copy());
      for (int i=0; i < numberOfChannels * buffersPerChannel; i++) {
        assertNotNull(gate.getNextBufferOrEvent());
        int min=Integer.MAX_VALUE;
        int max=0;
        for (        PipelinedSubpartition source : sources) {
          int size=source.getCurrentNumberOfBuffers();
          min=Math.min(min,size);
          max=Math.max(max,size);
        }
        assertTrue(max == min || max == min + 1);
        if (i % (2 * numberOfChannels) == 0) {
          fillRandom(sources,3,bufferConsumer);
        }
      }
    }
   }
  @Test public void testFairConsumptionRemoteChannelsPreFilled() throws Exception {
    final int numberOfChannels=37;
    final int buffersPerChannel=27;
    final Buffer mockBuffer=TestBufferFactory.createBuffer(42);
    SingleInputGate gate=new FairnessVerifyingInputGate("Test Task Name",new JobID(),new IntermediateDataSetID(),0,numberOfChannels,mock(TaskActions.class),UnregisteredMetricGroups.createUnregisteredTaskMetricGroup().getIOMetricGroup(),true);
    final ConnectionManager connManager=createDummyConnectionManager();
    final RemoteInputChannel[] channels=new RemoteInputChannel[numberOfChannels];
    for (int i=0; i < numberOfChannels; i++) {
      RemoteInputChannel channel=new RemoteInputChannel(gate,i,new ResultPartitionID(),mock(ConnectionID.class),connManager,0,0,UnregisteredMetricGroups.createUnregisteredTaskMetricGroup().getIOMetricGroup());
      channels[i]=channel;
      for (int p=0; p < buffersPerChannel; p++) {
        channel.onBuffer(mockBuffer,p,-1);
      }
      channel.onBuffer(EventSerializer.toBuffer(EndOfPartitionEvent.INSTANCE),buffersPerChannel,-1);
      gate.setInputChannel(new IntermediateResultPartitionID(),channel);
    }
    for (int i=numberOfChannels * (buffersPerChannel + 1); i > 0; --i) {
      assertNotNull(gate.getNextBufferOrEvent());
      int min=Integer.MAX_VALUE;
      int max=0;
      for (      RemoteInputChannel channel : channels) {
        int size=channel.getNumberOfQueuedBuffers();
        min=Math.min(min,size);
        max=Math.max(max,size);
      }
      assertTrue(max == min || max == (min + 1));
    }
    assertFalse(gate.getNextBufferOrEvent().isPresent());
  }
  @Test public void testFairConsumptionRemoteChannels() throws Exception {
    final int numberOfChannels=37;
    final int buffersPerChannel=27;
    final Buffer mockBuffer=TestBufferFactory.createBuffer(42);
    SingleInputGate gate=new FairnessVerifyingInputGate("Test Task Name",new JobID(),new IntermediateDataSetID(),0,numberOfChannels,mock(TaskActions.class),UnregisteredMetricGroups.createUnregisteredTaskMetricGroup().getIOMetricGroup(),true);
    final ConnectionManager connManager=createDummyConnectionManager();
    final RemoteInputChannel[] channels=new RemoteInputChannel[numberOfChannels];
    final int[] channelSequenceNums=new int[numberOfChannels];
    for (int i=0; i < numberOfChannels; i++) {
      RemoteInputChannel channel=new RemoteInputChannel(gate,i,new ResultPartitionID(),mock(ConnectionID.class),connManager,0,0,UnregisteredMetricGroups.createUnregisteredTaskMetricGroup().getIOMetricGroup());
      channels[i]=channel;
      gate.setInputChannel(new IntermediateResultPartitionID(),channel);
    }
    channels[11].onBuffer(mockBuffer,0,-1);
    channelSequenceNums[11]++;
    for (int i=0; i < numberOfChannels * buffersPerChannel; i++) {
      assertNotNull(gate.getNextBufferOrEvent());
      int min=Integer.MAX_VALUE;
      int max=0;
      for (      RemoteInputChannel channel : channels) {
        int size=channel.getNumberOfQueuedBuffers();
        min=Math.min(min,size);
        max=Math.max(max,size);
      }
      assertTrue(max == min || max == (min + 1));
      if (i % (2 * numberOfChannels) == 0) {
        fillRandom(channels,channelSequenceNums,3,mockBuffer);
      }
    }
  }
  private void fillRandom(  PipelinedSubpartition[] partitions,  int numPerPartition,  BufferConsumer buffer) throws Exception {
    ArrayList<Integer> poss=new ArrayList<>(partitions.length * numPerPartition);
    for (int i=0; i < partitions.length; i++) {
      for (int k=0; k < numPerPartition; k++) {
        poss.add(i);
      }
    }
    Collections.shuffle(poss);
    for (    Integer i : poss) {
      partitions[i].add(buffer.copy());
    }
  }
  private void fillRandom(  RemoteInputChannel[] partitions,  int[] sequenceNumbers,  int numPerPartition,  Buffer buffer) throws Exception {
    ArrayList<Integer> poss=new ArrayList<>(partitions.length * numPerPartition);
    for (int i=0; i < partitions.length; i++) {
      for (int k=0; k < numPerPartition; k++) {
        poss.add(i);
      }
    }
    Collections.shuffle(poss);
    for (    int i : poss) {
      partitions[i].onBuffer(buffer,sequenceNumbers[i]++,-1);
    }
  }
private static class FairnessVerifyingInputGate extends SingleInputGate {
    private final ArrayDeque<InputChannel> channelsWithData;
    private final HashSet<InputChannel> uniquenessChecker;
    @SuppressWarnings("unchecked") public FairnessVerifyingInputGate(    String owningTaskName,    JobID jobId,    IntermediateDataSetID consumedResultId,    int consumedSubpartitionIndex,    int numberOfInputChannels,    TaskActions taskActions,    TaskIOMetricGroup metrics,    boolean isCreditBased){
      super(owningTaskName,jobId,consumedResultId,ResultPartitionType.PIPELINED,consumedSubpartitionIndex,numberOfInputChannels,taskActions,metrics,isCreditBased);
      try {
        Field f=SingleInputGate.class.getDeclaredField("inputChannelsWithData");
        f.setAccessible(true);
        channelsWithData=(ArrayDeque<InputChannel>)f.get(this);
      }
 catch (      Exception e) {
        throw new RuntimeException(e);
      }
      this.uniquenessChecker=new HashSet<>();
    }
    @Override public Optional<BufferOrEvent> getNextBufferOrEvent() throws IOException, InterruptedException {
synchronized (channelsWithData) {
        assertTrue("too many input channels",channelsWithData.size() <= getNumberOfInputChannels());
        ensureUnique(channelsWithData);
      }
      return super.getNextBufferOrEvent();
    }
    private void ensureUnique(    Collection<InputChannel> channels){
      HashSet<InputChannel> uniquenessChecker=this.uniquenessChecker;
      for (      InputChannel channel : channels) {
        if (!uniquenessChecker.add(channel)) {
          fail("Duplicate channel in input gate: " + channel);
        }
      }
      assertTrue("found duplicate input channels",uniquenessChecker.size() == channels.size());
      uniquenessChecker.clear();
    }
  }
}
