/** 
 * This strategy tries to reduce remote data exchanges. Execution vertices, which are connected and belong to the same SlotSharingGroup, tend to be put in the same ExecutionSlotSharingGroup. Co-location constraints will be respected.
 */
class LocalInputPreferredSlotSharingStrategy implements SlotSharingStrategy {
  private final Map<ExecutionVertexID,ExecutionSlotSharingGroup> executionSlotSharingGroupMap;
  LocalInputPreferredSlotSharingStrategy(  final SchedulingTopology topology,  final Set<SlotSharingGroup> logicalSlotSharingGroups,  final Set<CoLocationGroup> coLocationGroups){
    this.executionSlotSharingGroupMap=new ExecutionSlotSharingGroupBuilder(topology,logicalSlotSharingGroups,coLocationGroups).build();
  }
  @Override public ExecutionSlotSharingGroup getExecutionSlotSharingGroup(  final ExecutionVertexID executionVertexId){
    return executionSlotSharingGroupMap.get(executionVertexId);
  }
  @Override public Set<ExecutionSlotSharingGroup> getExecutionSlotSharingGroups(){
    return new HashSet<>(executionSlotSharingGroupMap.values());
  }
static class Factory implements SlotSharingStrategy.Factory {
    public LocalInputPreferredSlotSharingStrategy create(    final SchedulingTopology topology,    final Set<SlotSharingGroup> logicalSlotSharingGroups,    final Set<CoLocationGroup> coLocationGroups){
      return new LocalInputPreferredSlotSharingStrategy(topology,logicalSlotSharingGroups,coLocationGroups);
    }
  }
private static class ExecutionSlotSharingGroupBuilder {
    private final SchedulingTopology topology;
    private final Map<JobVertexID,SlotSharingGroup> slotSharingGroupMap;
    private final Map<JobVertexID,CoLocationGroup> coLocationGroupMap;
    private final Map<ExecutionVertexID,ExecutionSlotSharingGroup> executionSlotSharingGroupMap;
    final Map<CoLocationConstraint,ExecutionSlotSharingGroup> constraintToExecutionSlotSharingGroupMap;
    final Map<SlotSharingGroupId,List<ExecutionSlotSharingGroup>> executionSlotSharingGroups;
    private final Map<ExecutionSlotSharingGroup,Set<JobVertexID>> assignedJobVerticesForGroups;
    private ExecutionSlotSharingGroupBuilder(    final SchedulingTopology topology,    final Set<SlotSharingGroup> logicalSlotSharingGroups,    final Set<CoLocationGroup> coLocationGroups){
      this.topology=checkNotNull(topology);
      this.slotSharingGroupMap=new HashMap<>();
      for (      SlotSharingGroup slotSharingGroup : logicalSlotSharingGroups) {
        for (        JobVertexID jobVertexId : slotSharingGroup.getJobVertexIds()) {
          slotSharingGroupMap.put(jobVertexId,slotSharingGroup);
        }
      }
      this.coLocationGroupMap=new HashMap<>();
      for (      CoLocationGroup coLocationGroup : coLocationGroups) {
        for (        JobVertexID jobVertexId : coLocationGroup.getVertexIds()) {
          coLocationGroupMap.put(jobVertexId,coLocationGroup);
        }
      }
      executionSlotSharingGroupMap=new HashMap<>();
      constraintToExecutionSlotSharingGroupMap=new HashMap<>();
      executionSlotSharingGroups=new HashMap<>();
      assignedJobVerticesForGroups=new IdentityHashMap<>();
    }
    /** 
 * Build ExecutionSlotSharingGroups for all vertices in the topology. The ExecutionSlotSharingGroup of a vertex is determined in order below: <p>1. try finding an existing group of the corresponding co-location constraint. <p>2. try finding an available group of its producer vertex if the producer is in the same slot sharing group. <p>3. try finding any available group. <p>4. create a new group.
 */
    private Map<ExecutionVertexID,ExecutionSlotSharingGroup> build(){
      final LinkedHashMap<JobVertexID,List<SchedulingExecutionVertex>> allVertices=getExecutionVertices();
      for (      List<SchedulingExecutionVertex> executionVertices : allVertices.values()) {
        final List<SchedulingExecutionVertex> remaining=tryFindOptimalAvailableExecutionSlotSharingGroupFor(executionVertices);
        findAvailableOrCreateNewExecutionSlotSharingGroupFor(remaining);
        updateConstraintToExecutionSlotSharingGroupMap(executionVertices);
      }
      return executionSlotSharingGroupMap;
    }
    private LinkedHashMap<JobVertexID,List<SchedulingExecutionVertex>> getExecutionVertices(){
      final LinkedHashMap<JobVertexID,List<SchedulingExecutionVertex>> vertices=new LinkedHashMap<>();
      for (      SchedulingExecutionVertex executionVertex : topology.getVertices()) {
        final List<SchedulingExecutionVertex> executionVertexGroup=vertices.computeIfAbsent(executionVertex.getId().getJobVertexId(),k -> new ArrayList<>());
        executionVertexGroup.add(executionVertex);
      }
      return vertices;
    }
    private List<SchedulingExecutionVertex> tryFindOptimalAvailableExecutionSlotSharingGroupFor(    final List<SchedulingExecutionVertex> executionVertices){
      final List<SchedulingExecutionVertex> remaining=new ArrayList<>();
      for (      SchedulingExecutionVertex executionVertex : executionVertices) {
        ExecutionSlotSharingGroup group=tryFindAvailableCoLocatedExecutionSlotSharingGroupFor(executionVertex);
        if (group == null) {
          group=tryFindAvailableProducerExecutionSlotSharingGroupFor(executionVertex);
        }
        if (group == null) {
          remaining.add(executionVertex);
        }
 else {
          addVertexToExecutionSlotSharingGroup(executionVertex,group);
        }
      }
      return remaining;
    }
    private ExecutionSlotSharingGroup tryFindAvailableCoLocatedExecutionSlotSharingGroupFor(    final SchedulingExecutionVertex executionVertex){
      final ExecutionVertexID executionVertexId=executionVertex.getId();
      final CoLocationGroup coLocationGroup=coLocationGroupMap.get(executionVertexId.getJobVertexId());
      if (coLocationGroup != null) {
        final CoLocationConstraint constraint=coLocationGroup.getLocationConstraint(executionVertexId.getSubtaskIndex());
        return constraintToExecutionSlotSharingGroupMap.get(constraint);
      }
 else {
        return null;
      }
    }
    private ExecutionSlotSharingGroup tryFindAvailableProducerExecutionSlotSharingGroupFor(    final SchedulingExecutionVertex executionVertex){
      final ExecutionVertexID executionVertexId=executionVertex.getId();
      for (      SchedulingResultPartition partition : executionVertex.getConsumedResults()) {
        final ExecutionVertexID producerVertexId=partition.getProducer().getId();
        if (!inSameLogicalSlotSharingGroup(producerVertexId,executionVertexId)) {
          continue;
        }
        final ExecutionSlotSharingGroup producerGroup=executionSlotSharingGroupMap.get(producerVertexId);
        checkState(producerGroup != null);
        if (isGroupAvailableForVertex(producerGroup,executionVertexId)) {
          return producerGroup;
        }
      }
      return null;
    }
    private boolean inSameLogicalSlotSharingGroup(    final ExecutionVertexID executionVertexId1,    final ExecutionVertexID executionVertexId2){
      return Objects.equals(getSlotSharingGroup(executionVertexId1).getSlotSharingGroupId(),getSlotSharingGroup(executionVertexId2).getSlotSharingGroupId());
    }
    private SlotSharingGroup getSlotSharingGroup(    final ExecutionVertexID executionVertexId){
      return checkNotNull(slotSharingGroupMap.get(executionVertexId.getJobVertexId()));
    }
    private boolean isGroupAvailableForVertex(    final ExecutionSlotSharingGroup executionSlotSharingGroup,    final ExecutionVertexID executionVertexId){
      final Set<JobVertexID> assignedVertices=assignedJobVerticesForGroups.get(executionSlotSharingGroup);
      return assignedVertices == null || !assignedVertices.contains(executionVertexId.getJobVertexId());
    }
    private void addVertexToExecutionSlotSharingGroup(    final SchedulingExecutionVertex vertex,    final ExecutionSlotSharingGroup group){
      group.addVertex(vertex.getId());
      executionSlotSharingGroupMap.put(vertex.getId(),group);
      assignedJobVerticesForGroups.computeIfAbsent(group,k -> new HashSet<>()).add(vertex.getId().getJobVertexId());
    }
    private void findAvailableOrCreateNewExecutionSlotSharingGroupFor(    final List<SchedulingExecutionVertex> executionVertices){
      for (      SchedulingExecutionVertex executionVertex : executionVertices) {
        final SlotSharingGroup slotSharingGroup=getSlotSharingGroup(executionVertex.getId());
        final List<ExecutionSlotSharingGroup> groups=executionSlotSharingGroups.computeIfAbsent(slotSharingGroup.getSlotSharingGroupId(),k -> new ArrayList<>());
        ExecutionSlotSharingGroup group=null;
        for (        ExecutionSlotSharingGroup executionSlotSharingGroup : groups) {
          if (isGroupAvailableForVertex(executionSlotSharingGroup,executionVertex.getId())) {
            group=executionSlotSharingGroup;
            break;
          }
        }
        if (group == null) {
          group=new ExecutionSlotSharingGroup();
          group.setResourceProfile(slotSharingGroup.getResourceProfile());
          groups.add(group);
        }
        addVertexToExecutionSlotSharingGroup(executionVertex,group);
      }
    }
    private void updateConstraintToExecutionSlotSharingGroupMap(    final List<SchedulingExecutionVertex> executionVertices){
      for (      SchedulingExecutionVertex executionVertex : executionVertices) {
        final ExecutionVertexID executionVertexId=executionVertex.getId();
        final CoLocationGroup coLocationGroup=coLocationGroupMap.get(executionVertexId.getJobVertexId());
        if (coLocationGroup != null) {
          final CoLocationConstraint constraint=coLocationGroup.getLocationConstraint(executionVertexId.getSubtaskIndex());
          constraintToExecutionSlotSharingGroupMap.put(constraint,executionSlotSharingGroupMap.get(executionVertexId));
        }
      }
    }
  }
}
