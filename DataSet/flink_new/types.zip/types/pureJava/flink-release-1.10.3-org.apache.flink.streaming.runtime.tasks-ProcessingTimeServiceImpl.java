class ProcessingTimeServiceImpl implements ProcessingTimeService {
  private final TimerService timerService;
  private final Function<ProcessingTimeCallback,ProcessingTimeCallback> processingTimeCallbackWrapper;
  ProcessingTimeServiceImpl(  TimerService timerService,  Function<ProcessingTimeCallback,ProcessingTimeCallback> processingTimeCallbackWrapper){
    this.timerService=timerService;
    this.processingTimeCallbackWrapper=processingTimeCallbackWrapper;
  }
  @Override public long getCurrentProcessingTime(){
    return timerService.getCurrentProcessingTime();
  }
  @Override public ScheduledFuture<?> registerTimer(  long timestamp,  ProcessingTimeCallback target){
    return timerService.registerTimer(timestamp,processingTimeCallbackWrapper.apply(target));
  }
  @Override public ScheduledFuture<?> scheduleAtFixedRate(  ProcessingTimeCallback callback,  long initialDelay,  long period){
    return timerService.scheduleAtFixedRate(processingTimeCallbackWrapper.apply(callback),initialDelay,period);
  }
}
