public class StreamIterationTail<IN> extends OneInputStreamTask<IN,IN> {
  private static final Logger LOG=LoggerFactory.getLogger(StreamIterationTail.class);
  @Override public void init() throws Exception {
    super.init();
    final String iterationId=getConfiguration().getIterationId();
    if (iterationId == null || iterationId.length() == 0) {
      throw new Exception("Missing iteration ID in the task configuration");
    }
    final String brokerID=StreamIterationHead.createBrokerIdString(getEnvironment().getJobID(),iterationId,getEnvironment().getIndexInSubtaskGroup());
    final long iterationWaitTime=getConfiguration().getIterationWaitTime();
    LOG.info("Iteration tail {} trying to acquire feedback queue under {}",getName(),brokerID);
    @SuppressWarnings("unchecked") BlockingQueue<StreamRecord<IN>> dataChannel=(BlockingQueue<StreamRecord<IN>>)BlockingQueueBroker.INSTANCE.get(brokerID);
    LOG.info("Iteration tail {} acquired feedback queue {}",getName(),brokerID);
    this.headOperator=new RecordPusher<>(dataChannel,iterationWaitTime);
  }
private static class RecordPusher<IN> extends AbstractStreamOperator<IN> implements OneInputStreamOperator<IN,IN> {
    private static final long serialVersionUID=1L;
    @SuppressWarnings("NonSerializableFieldInSerializableClass") private final BlockingQueue<StreamRecord<IN>> dataChannel;
    private final long iterationWaitTime;
    private final boolean shouldWait;
    RecordPusher(    BlockingQueue<StreamRecord<IN>> dataChannel,    long iterationWaitTime){
      this.dataChannel=dataChannel;
      this.iterationWaitTime=iterationWaitTime;
      this.shouldWait=iterationWaitTime > 0;
    }
    @Override public void processElement(    StreamRecord<IN> record) throws Exception {
      if (shouldWait) {
        dataChannel.offer(record,iterationWaitTime,TimeUnit.MILLISECONDS);
      }
 else {
        dataChannel.put(record);
      }
    }
    @Override public void processWatermark(    Watermark mark){
    }
  }
}
