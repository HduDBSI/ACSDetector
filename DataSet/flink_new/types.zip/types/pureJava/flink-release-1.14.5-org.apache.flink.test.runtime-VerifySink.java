private static class VerifySink extends RichSinkFunction<String> {
  private final boolean deletePartitionFile;
  VerifySink(  boolean deletePartitionFile){
    this.deletePartitionFile=deletePartitionFile;
  }
  @Override public void open(  Configuration parameters) throws Exception {
    if (!deletePartitionFile || getRuntimeContext().getAttemptNumber() > 0) {
      return;
    }
synchronized (BlockingShuffleITCase.class) {
      deleteFiles(TEMP_FOLDER.getRoot());
    }
  }
  @Override public void invoke(  String value,  Context context) throws Exception {
    assertEquals(RECORD,value);
  }
  private static void deleteFiles(  File root) throws IOException {
    File[] files=root.listFiles();
    if (files == null || files.length == 0) {
      return;
    }
    for (    File file : files) {
      if (!file.isDirectory()) {
        Files.deleteIfExists(file.toPath());
      }
 else {
        deleteFiles(file);
      }
    }
  }
}
