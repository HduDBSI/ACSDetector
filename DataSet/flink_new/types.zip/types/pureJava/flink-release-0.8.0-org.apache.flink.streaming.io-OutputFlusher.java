private class OutputFlusher extends Thread {
  private boolean running=true;
  public void terminate(){
    running=false;
  }
  @Override public void run(){
    while (running && !outputGate.isClosed()) {
      try {
        flush();
        Thread.sleep(timeout);
      }
 catch (      Exception e) {
        throw new RuntimeException(e);
      }
    }
  }
}
