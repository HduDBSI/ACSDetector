/** 
 * Convert the  {@link SourceReaderContext} into a {@link DeserializationSchema.InitializationContext}, we would use a pulsar named metric group for this content.
 */
@Internal public class PulsarDeserializationSchemaInitializationContext implements DeserializationSchema.InitializationContext {
  private final SourceReaderContext readerContext;
  public PulsarDeserializationSchemaInitializationContext(  SourceReaderContext readerContext){
    this.readerContext=readerContext;
  }
  @Override public MetricGroup getMetricGroup(){
    return readerContext.metricGroup().addGroup("pulsarDeserializer");
  }
  @Override public UserCodeClassLoader getUserCodeClassLoader(){
    return readerContext.getUserCodeClassLoader();
  }
}
