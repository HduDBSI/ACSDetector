public class CreditBasedPartitionRequestClientHandlerTest {
  /** 
 * Tests a fix for FLINK-1627. <p> FLINK-1627 discovered a race condition, which could lead to an infinite loop when a receiver was cancelled during a certain time of decoding a message. The test reproduces the input, which lead to the infinite loop: when the handler gets a reference to the buffer provider of the receiving input channel, but the respective input channel is released (and the corresponding buffer provider destroyed), the handler did not notice this.
 * @see <a href="https://issues.apache.org/jira/browse/FLINK-1627">FLINK-1627</a>
 */
  @Test(timeout=60000) @SuppressWarnings("unchecked") public void testReleaseInputChannelDuringDecode() throws Exception {
    final BufferProvider bufferProvider=mock(BufferProvider.class);
    when(bufferProvider.requestBuffer()).thenReturn(null);
    when(bufferProvider.isDestroyed()).thenReturn(true);
    when(bufferProvider.addBufferListener(any(BufferListener.class))).thenReturn(false);
    final RemoteInputChannel inputChannel=mock(RemoteInputChannel.class);
    when(inputChannel.getInputChannelId()).thenReturn(new InputChannelID());
    when(inputChannel.getBufferProvider()).thenReturn(bufferProvider);
    final BufferResponse receivedBuffer=createBufferResponse(TestBufferFactory.createBuffer(TestBufferFactory.BUFFER_SIZE),0,inputChannel.getInputChannelId(),2);
    final CreditBasedPartitionRequestClientHandler client=new CreditBasedPartitionRequestClientHandler();
    client.addInputChannel(inputChannel);
    client.channelRead(mock(ChannelHandlerContext.class),receivedBuffer);
  }
  /** 
 * Tests a fix for FLINK-1761. <p>FLINK-1761 discovered an IndexOutOfBoundsException, when receiving buffers of size 0.
 */
  @Test public void testReceiveEmptyBuffer() throws Exception {
    final BufferProvider bufferProvider=mock(BufferProvider.class);
    when(bufferProvider.requestBuffer()).thenReturn(TestBufferFactory.createBuffer(0));
    final RemoteInputChannel inputChannel=mock(RemoteInputChannel.class);
    when(inputChannel.getInputChannelId()).thenReturn(new InputChannelID());
    when(inputChannel.getBufferProvider()).thenReturn(bufferProvider);
    final Buffer emptyBuffer=TestBufferFactory.createBuffer(0);
    final int backlog=2;
    final BufferResponse receivedBuffer=createBufferResponse(emptyBuffer,0,inputChannel.getInputChannelId(),backlog);
    final CreditBasedPartitionRequestClientHandler client=new CreditBasedPartitionRequestClientHandler();
    client.addInputChannel(inputChannel);
    client.channelRead(mock(ChannelHandlerContext.class),receivedBuffer);
    verify(inputChannel,never()).onError(any(Throwable.class));
    verify(inputChannel,times(1)).onEmptyBuffer(0,backlog);
  }
  /** 
 * Verifies that  {@link RemoteInputChannel#onBuffer(Buffer,int,int)} is called when a{@link BufferResponse} is received.
 */
  @Test public void testReceiveBuffer() throws Exception {
    final NetworkBufferPool networkBufferPool=new NetworkBufferPool(10,32,2);
    final SingleInputGate inputGate=createSingleInputGate(1);
    final RemoteInputChannel inputChannel=InputChannelBuilder.newBuilder().setMemorySegmentProvider(networkBufferPool).buildRemoteAndSetToGate(inputGate);
    try {
      final BufferPool bufferPool=networkBufferPool.createBufferPool(8,8);
      inputGate.setBufferPool(bufferPool);
      inputGate.assignExclusiveSegments();
      final CreditBasedPartitionRequestClientHandler handler=new CreditBasedPartitionRequestClientHandler();
      handler.addInputChannel(inputChannel);
      final int backlog=2;
      final BufferResponse bufferResponse=createBufferResponse(TestBufferFactory.createBuffer(32),0,inputChannel.getInputChannelId(),backlog);
      handler.channelRead(mock(ChannelHandlerContext.class),bufferResponse);
      assertEquals(1,inputChannel.getNumberOfQueuedBuffers());
      assertEquals(2,inputChannel.getSenderBacklog());
    }
  finally {
      releaseResource(inputGate,networkBufferPool);
    }
  }
  /** 
 * Verifies that  {@link BufferResponse} of compressed {@link Buffer} can be handled correctly.
 */
  @Test public void testReceiveCompressedBuffer() throws Exception {
    int bufferSize=1024;
    String compressionCodec="LZ4";
    BufferCompressor compressor=new BufferCompressor(bufferSize,compressionCodec);
    BufferDecompressor decompressor=new BufferDecompressor(bufferSize,compressionCodec);
    NetworkBufferPool networkBufferPool=new NetworkBufferPool(10,bufferSize,2);
    SingleInputGate inputGate=new SingleInputGateBuilder().setBufferDecompressor(decompressor).build();
    RemoteInputChannel inputChannel=createRemoteInputChannel(inputGate,null,networkBufferPool);
    try {
      BufferPool bufferPool=networkBufferPool.createBufferPool(8,8);
      inputGate.setBufferPool(bufferPool);
      inputGate.assignExclusiveSegments();
      CreditBasedPartitionRequestClientHandler handler=new CreditBasedPartitionRequestClientHandler();
      handler.addInputChannel(inputChannel);
      Buffer buffer=compressor.compressToOriginalBuffer(TestBufferFactory.createBuffer(bufferSize));
      BufferResponse bufferResponse=createBufferResponse(buffer,0,inputChannel.getInputChannelId(),2);
      assertTrue(bufferResponse.isCompressed);
      handler.channelRead(null,bufferResponse);
      Buffer receivedBuffer=inputChannel.getNextReceivedBuffer();
      assertNotNull(receivedBuffer);
      assertTrue(receivedBuffer.isCompressed());
      receivedBuffer.recycleBuffer();
    }
  finally {
      releaseResource(inputGate,networkBufferPool);
    }
  }
  /** 
 * Verifies that  {@link RemoteInputChannel#onError(Throwable)} is called when a{@link BufferResponse} is received but no available buffer in input channel.
 */
  @Test public void testThrowExceptionForNoAvailableBuffer() throws Exception {
    final SingleInputGate inputGate=createSingleInputGate(1);
    final RemoteInputChannel inputChannel=spy(InputChannelBuilder.newBuilder().buildRemoteAndSetToGate(inputGate));
    final CreditBasedPartitionRequestClientHandler handler=new CreditBasedPartitionRequestClientHandler();
    handler.addInputChannel(inputChannel);
    assertEquals("There should be no buffers available in the channel.",0,inputChannel.getNumberOfAvailableBuffers());
    final BufferResponse bufferResponse=createBufferResponse(TestBufferFactory.createBuffer(TestBufferFactory.BUFFER_SIZE),0,inputChannel.getInputChannelId(),2);
    handler.channelRead(mock(ChannelHandlerContext.class),bufferResponse);
    verify(inputChannel,times(1)).onError(any(IllegalStateException.class));
  }
  /** 
 * Verifies that  {@link RemoteInputChannel#onFailedPartitionRequest()} is called when a{@link PartitionNotFoundException} is received.
 */
  @Test public void testReceivePartitionNotFoundException() throws Exception {
    final BufferProvider bufferProvider=mock(BufferProvider.class);
    when(bufferProvider.requestBuffer()).thenReturn(TestBufferFactory.createBuffer(0));
    final RemoteInputChannel inputChannel=mock(RemoteInputChannel.class);
    when(inputChannel.getInputChannelId()).thenReturn(new InputChannelID());
    when(inputChannel.getBufferProvider()).thenReturn(bufferProvider);
    final ErrorResponse partitionNotFound=new ErrorResponse(new PartitionNotFoundException(new ResultPartitionID()),inputChannel.getInputChannelId());
    final CreditBasedPartitionRequestClientHandler client=new CreditBasedPartitionRequestClientHandler();
    client.addInputChannel(inputChannel);
    ChannelHandlerContext ctx=mock(ChannelHandlerContext.class);
    when(ctx.channel()).thenReturn(mock(Channel.class));
    client.channelActive(ctx);
    client.channelRead(ctx,partitionNotFound);
    verify(inputChannel,times(1)).onFailedPartitionRequest();
  }
  @Test public void testCancelBeforeActive() throws Exception {
    final RemoteInputChannel inputChannel=mock(RemoteInputChannel.class);
    when(inputChannel.getInputChannelId()).thenReturn(new InputChannelID());
    final CreditBasedPartitionRequestClientHandler client=new CreditBasedPartitionRequestClientHandler();
    client.addInputChannel(inputChannel);
    client.cancelRequestFor(null);
    client.cancelRequestFor(inputChannel.getInputChannelId());
  }
  /** 
 * Verifies that  {@link RemoteInputChannel} is enqueued in the pipeline for notifying credits,and verifies the behaviour of credit notification by triggering channel's writability changed.
 */
  @Test public void testNotifyCreditAvailable() throws Exception {
    final CreditBasedPartitionRequestClientHandler handler=new CreditBasedPartitionRequestClientHandler();
    final EmbeddedChannel channel=new EmbeddedChannel(handler);
    final PartitionRequestClient client=new NettyPartitionRequestClient(channel,handler,mock(ConnectionID.class),mock(PartitionRequestClientFactory.class));
    final NetworkBufferPool networkBufferPool=new NetworkBufferPool(10,32,2);
    final SingleInputGate inputGate=createSingleInputGate(1);
    final RemoteInputChannel inputChannel1=createRemoteInputChannel(inputGate,client,networkBufferPool);
    final RemoteInputChannel inputChannel2=createRemoteInputChannel(inputGate,client,networkBufferPool);
    try {
      final BufferPool bufferPool=networkBufferPool.createBufferPool(6,6);
      inputGate.setBufferPool(bufferPool);
      inputGate.assignExclusiveSegments();
      inputChannel1.requestSubpartition(0);
      inputChannel2.requestSubpartition(0);
      assertTrue(channel.isWritable());
      Object readFromOutbound=channel.readOutbound();
      assertThat(readFromOutbound,instanceOf(PartitionRequest.class));
      assertEquals(inputChannel1.getInputChannelId(),((PartitionRequest)readFromOutbound).receiverId);
      assertEquals(2,((PartitionRequest)readFromOutbound).credit);
      readFromOutbound=channel.readOutbound();
      assertThat(readFromOutbound,instanceOf(PartitionRequest.class));
      assertEquals(inputChannel2.getInputChannelId(),((PartitionRequest)readFromOutbound).receiverId);
      assertEquals(2,((PartitionRequest)readFromOutbound).credit);
      final BufferResponse bufferResponse1=createBufferResponse(TestBufferFactory.createBuffer(32),0,inputChannel1.getInputChannelId(),1);
      final BufferResponse bufferResponse2=createBufferResponse(TestBufferFactory.createBuffer(32),0,inputChannel2.getInputChannelId(),1);
      handler.channelRead(mock(ChannelHandlerContext.class),bufferResponse1);
      handler.channelRead(mock(ChannelHandlerContext.class),bufferResponse2);
      assertEquals(2,inputChannel1.getUnannouncedCredit());
      assertEquals(2,inputChannel2.getUnannouncedCredit());
      channel.runPendingTasks();
      readFromOutbound=channel.readOutbound();
      assertThat(readFromOutbound,instanceOf(AddCredit.class));
      assertEquals(inputChannel1.getInputChannelId(),((AddCredit)readFromOutbound).receiverId);
      assertEquals(2,((AddCredit)readFromOutbound).credit);
      readFromOutbound=channel.readOutbound();
      assertThat(readFromOutbound,instanceOf(AddCredit.class));
      assertEquals(inputChannel2.getInputChannelId(),((AddCredit)readFromOutbound).receiverId);
      assertEquals(2,((AddCredit)readFromOutbound).credit);
      assertNull(channel.readOutbound());
      ByteBuf channelBlockingBuffer=blockChannel(channel);
      final BufferResponse bufferResponse3=createBufferResponse(TestBufferFactory.createBuffer(32),1,inputChannel1.getInputChannelId(),1);
      handler.channelRead(mock(ChannelHandlerContext.class),bufferResponse3);
      assertEquals(1,inputChannel1.getUnannouncedCredit());
      assertEquals(0,inputChannel2.getUnannouncedCredit());
      channel.runPendingTasks();
      assertFalse(channel.isWritable());
      assertNull(channel.readOutbound());
      channel.flush();
      assertSame(channelBlockingBuffer,channel.readOutbound());
      assertTrue(channel.isWritable());
      readFromOutbound=channel.readOutbound();
      assertThat(readFromOutbound,instanceOf(AddCredit.class));
      assertEquals(1,((AddCredit)readFromOutbound).credit);
      assertEquals(0,inputChannel1.getUnannouncedCredit());
      assertEquals(0,inputChannel2.getUnannouncedCredit());
      assertNull(channel.readOutbound());
    }
  finally {
      releaseResource(inputGate,networkBufferPool);
    }
  }
  /** 
 * Verifies that  {@link RemoteInputChannel} is enqueued in the pipeline, but {@link AddCredit}message is not sent actually when this input channel is released.
 */
  @Test public void testNotifyCreditAvailableAfterReleased() throws Exception {
    final CreditBasedPartitionRequestClientHandler handler=new CreditBasedPartitionRequestClientHandler();
    final EmbeddedChannel channel=new EmbeddedChannel(handler);
    final PartitionRequestClient client=new NettyPartitionRequestClient(channel,handler,mock(ConnectionID.class),mock(PartitionRequestClientFactory.class));
    final NetworkBufferPool networkBufferPool=new NetworkBufferPool(10,32,2);
    final SingleInputGate inputGate=createSingleInputGate(1);
    final RemoteInputChannel inputChannel=createRemoteInputChannel(inputGate,client,networkBufferPool);
    try {
      final BufferPool bufferPool=networkBufferPool.createBufferPool(6,6);
      inputGate.setBufferPool(bufferPool);
      inputGate.assignExclusiveSegments();
      inputChannel.requestSubpartition(0);
      Object readFromOutbound=channel.readOutbound();
      assertThat(readFromOutbound,instanceOf(PartitionRequest.class));
      assertEquals(2,((PartitionRequest)readFromOutbound).credit);
      final BufferResponse bufferResponse=createBufferResponse(TestBufferFactory.createBuffer(32),0,inputChannel.getInputChannelId(),1);
      handler.channelRead(mock(ChannelHandlerContext.class),bufferResponse);
      assertEquals(2,inputChannel.getUnannouncedCredit());
      inputGate.close();
      readFromOutbound=channel.readOutbound();
      assertThat(readFromOutbound,instanceOf(CloseRequest.class));
      channel.runPendingTasks();
      assertNull(channel.readOutbound());
    }
  finally {
      releaseResource(inputGate,networkBufferPool);
    }
  }
  private static void releaseResource(  SingleInputGate inputGate,  NetworkBufferPool networkBufferPool) throws IOException {
    inputGate.close();
    networkBufferPool.destroyAllBufferPools();
    networkBufferPool.destroy();
  }
  /** 
 * Returns a deserialized buffer message as it would be received during runtime.
 */
  private static BufferResponse createBufferResponse(  Buffer buffer,  int sequenceNumber,  InputChannelID receivingChannelId,  int backlog) throws IOException {
    BufferResponse resp=new BufferResponse(buffer,sequenceNumber,receivingChannelId,backlog);
    ByteBuf serialized=resp.write(UnpooledByteBufAllocator.DEFAULT);
    serialized.readBytes(NettyMessage.FRAME_HEADER_LENGTH);
    BufferResponse deserialized=BufferResponse.readFrom(serialized);
    return deserialized;
  }
}
