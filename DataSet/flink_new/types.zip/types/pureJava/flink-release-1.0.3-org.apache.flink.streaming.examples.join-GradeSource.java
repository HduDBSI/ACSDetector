/** 
 * Continuously emit tuples with random names and integers (grades).
 */
public static class GradeSource implements SourceFunction<Tuple3<Long,String,Integer>> {
  private static final long serialVersionUID=1L;
  private Random rand;
  private Tuple3<Long,String,Integer> outTuple;
  private volatile boolean isRunning=true;
  private int counter;
  public GradeSource(){
    rand=new Random();
    outTuple=new Tuple3<>();
  }
  @Override public void run(  SourceContext<Tuple3<Long,String,Integer>> ctx) throws Exception {
    while (isRunning && counter < 100) {
      outTuple.f0=System.currentTimeMillis();
      outTuple.f1=names[rand.nextInt(names.length)];
      outTuple.f2=rand.nextInt(GRADE_COUNT) + 1;
      Thread.sleep(rand.nextInt(SLEEP_TIME) + 1);
      counter++;
      ctx.collect(outTuple);
    }
  }
  @Override public void cancel(){
    isRunning=false;
  }
}
