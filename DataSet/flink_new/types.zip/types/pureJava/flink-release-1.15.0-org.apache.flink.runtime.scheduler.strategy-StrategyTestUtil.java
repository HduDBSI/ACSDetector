/** 
 * Strategy test utilities. 
 */
public class StrategyTestUtil {
  static List<ExecutionVertexID> getExecutionVertexIdsFromDeployOptions(  final List<ExecutionVertexDeploymentOption> deploymentOptions){
    return deploymentOptions.stream().map(ExecutionVertexDeploymentOption::getExecutionVertexId).collect(Collectors.toList());
  }
  static void assertLatestScheduledVerticesAreEqualTo(  final List<List<TestingSchedulingExecutionVertex>> expected,  TestingSchedulerOperations testingSchedulerOperation){
    final List<List<ExecutionVertexDeploymentOption>> deploymentOptions=testingSchedulerOperation.getScheduledVertices();
    final int expectedScheduledBulks=expected.size();
    assertThat(expectedScheduledBulks,lessThanOrEqualTo(deploymentOptions.size()));
    for (int i=0; i < expectedScheduledBulks; i++) {
      assertEquals(idsFromVertices(expected.get(expectedScheduledBulks - i - 1)),idsFromDeploymentOptions(deploymentOptions.get(deploymentOptions.size() - i - 1)));
    }
  }
  static List<ExecutionVertexID> idsFromVertices(  final List<TestingSchedulingExecutionVertex> vertices){
    return vertices.stream().map(TestingSchedulingExecutionVertex::getId).collect(Collectors.toList());
  }
  static List<ExecutionVertexID> idsFromDeploymentOptions(  final List<ExecutionVertexDeploymentOption> deploymentOptions){
    return deploymentOptions.stream().map(ExecutionVertexDeploymentOption::getExecutionVertexId).collect(Collectors.toList());
  }
}
