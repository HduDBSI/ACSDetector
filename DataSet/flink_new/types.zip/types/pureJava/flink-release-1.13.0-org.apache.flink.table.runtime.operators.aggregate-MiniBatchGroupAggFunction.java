/** 
 * Aggregate Function used for the groupby (without window) aggregate in miniBatch mode. <p>This function buffers input row in heap HashMap, and aggregates them when minibatch invoked.
 */
public class MiniBatchGroupAggFunction extends MapBundleFunction<RowData,List<RowData>,RowData,RowData> {
  private static final long serialVersionUID=7455939331036508477L;
  /** 
 * The code generated function used to handle aggregates. 
 */
  private final GeneratedAggsHandleFunction genAggsHandler;
  /** 
 * The code generated equaliser used to equal RowData. 
 */
  private final GeneratedRecordEqualiser genRecordEqualiser;
  /** 
 * The accumulator types. 
 */
  private final LogicalType[] accTypes;
  /** 
 * The input row type. 
 */
  private final RowType inputType;
  /** 
 * Used to count the number of added and retracted input records. 
 */
  private final RecordCounter recordCounter;
  /** 
 * Whether this operator will generate UPDATE_BEFORE messages. 
 */
  private final boolean generateUpdateBefore;
  /** 
 * State idle retention time which unit is MILLISECONDS. 
 */
  private final long stateRetentionTime;
  /** 
 * Reused output row. 
 */
  private transient JoinedRowData resultRow=new JoinedRowData();
  private transient TypeSerializer<RowData> inputRowSerializer;
  private transient AggsHandleFunction function=null;
  private transient RecordEqualiser equaliser=null;
  private transient ValueState<RowData> accState=null;
  /** 
 * Creates a  {@link MiniBatchGroupAggFunction}.
 * @param genAggsHandler The code generated function used to handle aggregates.
 * @param genRecordEqualiser The code generated equaliser used to equal RowData.
 * @param accTypes The accumulator types.
 * @param inputType The input row type.
 * @param indexOfCountStar The index of COUNT(*) in the aggregates. -1 when the input doesn'tcontain COUNT(*), i.e. doesn't contain retraction messages. We make sure there is a COUNT(*) if input stream contains retraction.
 * @param generateUpdateBefore Whether this operator will generate UPDATE_BEFORE messages.
 * @param stateRetentionTime state idle retention time which unit is MILLISECONDS.
 */
  public MiniBatchGroupAggFunction(  GeneratedAggsHandleFunction genAggsHandler,  GeneratedRecordEqualiser genRecordEqualiser,  LogicalType[] accTypes,  RowType inputType,  int indexOfCountStar,  boolean generateUpdateBefore,  long stateRetentionTime){
    this.genAggsHandler=genAggsHandler;
    this.genRecordEqualiser=genRecordEqualiser;
    this.recordCounter=RecordCounter.of(indexOfCountStar);
    this.accTypes=accTypes;
    this.inputType=inputType;
    this.generateUpdateBefore=generateUpdateBefore;
    this.stateRetentionTime=stateRetentionTime;
  }
  @Override public void open(  ExecutionContext ctx) throws Exception {
    super.open(ctx);
    StateTtlConfig ttlConfig=createTtlConfig(stateRetentionTime);
    function=genAggsHandler.newInstance(ctx.getRuntimeContext().getUserCodeClassLoader());
    function.open(new PerKeyStateDataViewStore(ctx.getRuntimeContext(),ttlConfig));
    equaliser=genRecordEqualiser.newInstance(ctx.getRuntimeContext().getUserCodeClassLoader());
    InternalTypeInfo<RowData> accTypeInfo=InternalTypeInfo.ofFields(accTypes);
    ValueStateDescriptor<RowData> accDesc=new ValueStateDescriptor<>("accState",accTypeInfo);
    if (ttlConfig.isEnabled()) {
      accDesc.enableTimeToLive(ttlConfig);
    }
    accState=ctx.getRuntimeContext().getState(accDesc);
    inputRowSerializer=InternalSerializers.create(inputType);
    resultRow=new JoinedRowData();
  }
  @Override public List<RowData> addInput(  @Nullable List<RowData> value,  RowData input) throws Exception {
    List<RowData> bufferedRows=value;
    if (value == null) {
      bufferedRows=new ArrayList<>();
    }
    bufferedRows.add(inputRowSerializer.copy(input));
    return bufferedRows;
  }
  @Override public void finishBundle(  Map<RowData,List<RowData>> buffer,  Collector<RowData> out) throws Exception {
    for (    Map.Entry<RowData,List<RowData>> entry : buffer.entrySet()) {
      RowData currentKey=entry.getKey();
      List<RowData> inputRows=entry.getValue();
      boolean firstRow=false;
      ctx.setCurrentKey(currentKey);
      RowData acc=accState.value();
      if (acc == null) {
        Iterator<RowData> inputIter=inputRows.iterator();
        while (inputIter.hasNext()) {
          RowData current=inputIter.next();
          if (isRetractMsg(current)) {
            inputIter.remove();
          }
 else {
            break;
          }
        }
        if (inputRows.isEmpty()) {
          return;
        }
        acc=function.createAccumulators();
        firstRow=true;
      }
      function.setAccumulators(acc);
      RowData prevAggValue=function.getValue();
      for (      RowData input : inputRows) {
        if (isAccumulateMsg(input)) {
          function.accumulate(input);
        }
 else {
          function.retract(input);
        }
      }
      RowData newAggValue=function.getValue();
      acc=function.getAccumulators();
      if (!recordCounter.recordCountIsZero(acc)) {
        accState.update(acc);
        if (!firstRow) {
          if (!equaliser.equals(prevAggValue,newAggValue)) {
            if (generateUpdateBefore) {
              resultRow.replace(currentKey,prevAggValue).setRowKind(RowKind.UPDATE_BEFORE);
              out.collect(resultRow);
            }
            resultRow.replace(currentKey,newAggValue).setRowKind(RowKind.UPDATE_AFTER);
            out.collect(resultRow);
          }
        }
 else {
          resultRow.replace(currentKey,newAggValue).setRowKind(RowKind.INSERT);
          out.collect(resultRow);
        }
      }
 else {
        if (!firstRow) {
          resultRow.replace(currentKey,prevAggValue).setRowKind(RowKind.DELETE);
          out.collect(resultRow);
        }
        accState.clear();
        function.cleanup();
      }
    }
  }
  @Override public void close() throws Exception {
    if (function != null) {
      function.close();
    }
  }
}
