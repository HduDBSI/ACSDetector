/** 
 * A special classloader that filters "org.apache.hadoop.*" and "com.mapr.*" classes.
 */
private static final class MapRFreeClassLoader extends URLClassLoader {
  private final ClassLoader properParent;
  MapRFreeClassLoader(  ClassLoader parent){
    super(getClasspathURLs(),null);
    properParent=parent;
  }
  @Override public Class<?> loadClass(  String name) throws ClassNotFoundException {
    if (name.startsWith("com.mapr") || name.startsWith("org.apache.hadoop")) {
      throw new ClassNotFoundException(name);
    }
 else     if (name.equals(RunnableWithException.class.getName()) || name.startsWith("org.apache.log4j")) {
      return properParent.loadClass(name);
    }
 else {
      return super.loadClass(name);
    }
  }
  private static URL[] getClasspathURLs(){
    final String[] cp=System.getProperty("java.class.path").split(File.pathSeparator);
    return Arrays.stream(cp).filter(str -> !str.isEmpty()).map(MapRFreeClassLoader::parse).toArray(URL[]::new);
  }
  private static URL parse(  String fileName){
    try {
      return new File(fileName).toURI().toURL();
    }
 catch (    MalformedURLException e) {
      throw new RuntimeException(e);
    }
  }
}
