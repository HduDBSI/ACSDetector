/** 
 * Internal window function for wrapping a  {@link WindowFunction} that takes an {@code Iterable}when the window state also is an  {@code Iterable}.
 */
public final class InternalIterableWindowFunction<IN,OUT,KEY,W extends Window> extends InternalWindowFunction<Iterable<IN>,OUT,KEY,W> implements RichFunction {
  private static final long serialVersionUID=1L;
  protected final WindowFunction<IN,OUT,KEY,W> wrappedFunction;
  public InternalIterableWindowFunction(  WindowFunction<IN,OUT,KEY,W> wrappedFunction){
    this.wrappedFunction=wrappedFunction;
  }
  @Override public void apply(  KEY key,  W window,  Iterable<IN> input,  Collector<OUT> out) throws Exception {
    wrappedFunction.apply(key,window,input,out);
  }
  @Override public void open(  Configuration parameters) throws Exception {
    FunctionUtils.openFunction(this.wrappedFunction,parameters);
  }
  @Override public void close() throws Exception {
    FunctionUtils.closeFunction(this.wrappedFunction);
  }
  @Override public void setRuntimeContext(  RuntimeContext t){
    FunctionUtils.setFunctionRuntimeContext(this.wrappedFunction,t);
  }
  @Override public RuntimeContext getRuntimeContext(){
    throw new RuntimeException("This should never be called.");
  }
  @Override public IterationRuntimeContext getIterationRuntimeContext(){
    throw new RuntimeException("This should never be called.");
  }
  @SuppressWarnings("unchecked") @Override public void setOutputType(  TypeInformation<OUT> outTypeInfo,  ExecutionConfig executionConfig){
    if (OutputTypeConfigurable.class.isAssignableFrom(this.wrappedFunction.getClass())) {
      ((OutputTypeConfigurable<OUT>)this.wrappedFunction).setOutputType(outTypeInfo,executionConfig);
    }
  }
}
