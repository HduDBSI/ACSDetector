/** 
 * A class for statistically unique job vertex IDs.
 */
public class JobVertexID extends AbstractID {
}
