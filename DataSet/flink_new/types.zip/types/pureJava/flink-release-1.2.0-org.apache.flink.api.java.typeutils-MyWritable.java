public static class MyWritable implements Writable {
  @Override public void write(  DataOutput out) throws IOException {
  }
  @Override public void readFields(  DataInput in) throws IOException {
  }
}
