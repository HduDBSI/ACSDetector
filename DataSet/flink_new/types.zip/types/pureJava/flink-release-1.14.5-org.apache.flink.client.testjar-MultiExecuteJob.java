/** 
 * A testing job with configurable number of calls to  {@link ExecutionEnvironment#executeAsync()}.
 */
public class MultiExecuteJob {
  public static PackagedProgram getProgram(  int noOfJobs,  boolean attached) throws FlinkException {
    try {
      return PackagedProgram.newBuilder().setUserClassPaths(Collections.singletonList(new File(CliFrontendTestUtils.getTestJarPath()).toURI().toURL())).setEntryPointClassName(MultiExecuteJob.class.getName()).setArguments(String.valueOf(noOfJobs),Boolean.toString(attached)).build();
    }
 catch (    ProgramInvocationException|FileNotFoundException|MalformedURLException e) {
      throw new FlinkException("Could not load the provided entrypoint class.",e);
    }
  }
  public static void main(  String[] args) throws Exception {
    int noOfExecutes=Integer.parseInt(args[0]);
    boolean attached=args.length > 1 && Boolean.parseBoolean(args[1]);
    final ExecutionEnvironment env=ExecutionEnvironment.getExecutionEnvironment();
    for (int i=0; i < noOfExecutes; i++) {
      final List<Integer> input=new ArrayList<>();
      input.add(1);
      input.add(2);
      input.add(3);
      env.fromCollection(input).map(element -> element + 1).output(new DiscardingOutputFormat<>());
      if (attached) {
        env.execute();
      }
 else {
        env.executeAsync();
      }
    }
  }
}
