private static final class TestSplit extends GenericInputSplit {
}
