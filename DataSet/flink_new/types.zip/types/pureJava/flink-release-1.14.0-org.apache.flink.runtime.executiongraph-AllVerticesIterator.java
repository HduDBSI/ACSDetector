class AllVerticesIterator<EV extends AccessExecutionVertex,EJV extends AccessExecutionJobVertex> implements Iterator<EV> {
  private final Iterator<EJV> jobVertices;
  private EV[] currVertices;
  private int currPos;
  public AllVerticesIterator(  Iterator<EJV> jobVertices){
    this.jobVertices=jobVertices;
  }
  @Override public boolean hasNext(){
    while (true) {
      if (currVertices != null) {
        if (currPos < currVertices.length) {
          return true;
        }
 else {
          currVertices=null;
        }
      }
 else       if (jobVertices.hasNext()) {
        currVertices=(EV[])jobVertices.next().getTaskVertices();
        currPos=0;
      }
 else {
        return false;
      }
    }
  }
  @Override public EV next(){
    if (hasNext()) {
      return currVertices[currPos++];
    }
 else {
      throw new NoSuchElementException();
    }
  }
  @Override public void remove(){
    throw new UnsupportedOperationException();
  }
}
