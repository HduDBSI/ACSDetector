/** 
 * Converter for  {@link RowType} of {@link Row} external type. 
 */
@Internal public class RowRowConverter implements DataStructureConverter<RowData,Row> {
  private static final long serialVersionUID=1L;
  private final DataStructureConverter<Object,Object>[] fieldConverters;
  private final RowData.FieldGetter[] fieldGetters;
  private final LinkedHashMap<String,Integer> positionByName;
  private RowRowConverter(  DataStructureConverter<Object,Object>[] fieldConverters,  RowData.FieldGetter[] fieldGetters,  LinkedHashMap<String,Integer> positionByName){
    this.fieldConverters=fieldConverters;
    this.fieldGetters=fieldGetters;
    this.positionByName=positionByName;
  }
  @Override public void open(  ClassLoader classLoader){
    for (    DataStructureConverter<Object,Object> fieldConverter : fieldConverters) {
      fieldConverter.open(classLoader);
    }
  }
  @Override public RowData toInternal(  Row external){
    final int length=fieldConverters.length;
    final GenericRowData genericRow=new GenericRowData(external.getKind(),length);
    final Set<String> fieldNames=external.getFieldNames(false);
    if (fieldNames == null) {
      for (int pos=0; pos < length; pos++) {
        final Object value=external.getField(pos);
        genericRow.setField(pos,fieldConverters[pos].toInternalOrNull(value));
      }
    }
 else {
      for (      String fieldName : fieldNames) {
        final Integer targetPos=positionByName.get(fieldName);
        if (targetPos == null) {
          throw new IllegalArgumentException(String.format("Unknown field name '%s' for mapping to a row position. " + "Available names are: %s",fieldName,positionByName.keySet()));
        }
        final Object value=external.getField(fieldName);
        genericRow.setField(targetPos,fieldConverters[targetPos].toInternalOrNull(value));
      }
    }
    return genericRow;
  }
  @Override public Row toExternal(  RowData internal){
    final int length=fieldConverters.length;
    final Object[] fieldByPosition=new Object[length];
    for (int pos=0; pos < length; pos++) {
      final Object value=fieldGetters[pos].getFieldOrNull(internal);
      fieldByPosition[pos]=fieldConverters[pos].toExternalOrNull(value);
    }
    return RowUtils.createRowWithNamedPositions(internal.getRowKind(),fieldByPosition,positionByName);
  }
  @SuppressWarnings({"unchecked","Convert2MethodRef"}) public static RowRowConverter create(  DataType dataType){
    final List<DataType> fields=dataType.getChildren();
    final DataStructureConverter<Object,Object>[] fieldConverters=fields.stream().map(dt -> DataStructureConverters.getConverter(dt)).toArray(DataStructureConverter[]::new);
    final RowData.FieldGetter[] fieldGetters=IntStream.range(0,fields.size()).mapToObj(pos -> RowData.createFieldGetter(fields.get(pos).getLogicalType(),pos)).toArray(RowData.FieldGetter[]::new);
    final List<String> fieldNames=getFieldNames(dataType.getLogicalType());
    final LinkedHashMap<String,Integer> positionByName=new LinkedHashMap<>();
    for (int i=0; i < fieldNames.size(); i++) {
      positionByName.put(fieldNames.get(i),i);
    }
    return new RowRowConverter(fieldConverters,fieldGetters,positionByName);
  }
}
