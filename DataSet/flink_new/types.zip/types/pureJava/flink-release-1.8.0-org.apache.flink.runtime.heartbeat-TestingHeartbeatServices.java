/** 
 * A  {@link HeartbeatServices} that allows the injection of a {@link ScheduledExecutor}.
 */
public class TestingHeartbeatServices extends HeartbeatServices {
  private final ScheduledExecutor scheduledExecutorToUse;
  public TestingHeartbeatServices(  long heartbeatInterval,  long heartbeatTimeout,  ScheduledExecutor scheduledExecutorToUse){
    super(heartbeatInterval,heartbeatTimeout);
    this.scheduledExecutorToUse=Preconditions.checkNotNull(scheduledExecutorToUse);
  }
  public TestingHeartbeatServices(){
    this(1000L,10000L,TestingUtils.defaultScheduledExecutor());
  }
  @Override public <I,O>HeartbeatManager<I,O> createHeartbeatManagerSender(  ResourceID resourceId,  HeartbeatListener<I,O> heartbeatListener,  ScheduledExecutor scheduledExecutor,  Logger log){
    return new HeartbeatManagerSenderImpl<>(heartbeatInterval,heartbeatTimeout,resourceId,heartbeatListener,org.apache.flink.runtime.concurrent.Executors.directExecutor(),scheduledExecutorToUse,log);
  }
}
