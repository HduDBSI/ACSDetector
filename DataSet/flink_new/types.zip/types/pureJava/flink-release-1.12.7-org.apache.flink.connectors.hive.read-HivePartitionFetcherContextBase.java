/** 
 * Base class for table partition fetcher context.
 * @param < P > The type of partition.
 */
public abstract class HivePartitionFetcherContextBase<P> implements PartitionFetcher.Context<P> {
  private static final long serialVersionUID=1L;
  protected final ObjectPath tablePath;
  protected final HiveShim hiveShim;
  protected final JobConfWrapper confWrapper;
  protected final List<String> partitionKeys;
  protected final DataType[] fieldTypes;
  protected final String[] fieldNames;
  protected final Configuration configuration;
  protected final String defaultPartitionName;
  protected final ConsumeOrder consumeOrder;
  protected transient HiveMetastoreClientWrapper metaStoreClient;
  protected transient StorageDescriptor tableSd;
  protected transient Properties tableProps;
  protected transient Path tableLocation;
  private transient PartitionTimeExtractor extractor;
  private transient Table table;
  private transient Map<List<String>,Long> partValuesToCreateTime;
  public HivePartitionFetcherContextBase(  ObjectPath tablePath,  HiveShim hiveShim,  JobConfWrapper confWrapper,  List<String> partitionKeys,  DataType[] fieldTypes,  String[] fieldNames,  Configuration configuration,  String defaultPartitionName){
    this.tablePath=tablePath;
    this.hiveShim=hiveShim;
    this.confWrapper=confWrapper;
    this.partitionKeys=partitionKeys;
    this.fieldTypes=fieldTypes;
    this.fieldNames=fieldNames;
    this.configuration=configuration;
    this.defaultPartitionName=defaultPartitionName;
    String consumeOrderStr=configuration.get(STREAMING_SOURCE_PARTITION_ORDER);
    this.consumeOrder=ConsumeOrder.getConsumeOrder(consumeOrderStr);
  }
  @Override public void open() throws Exception {
    metaStoreClient=new HiveMetastoreClientWrapper(HiveConfUtils.create(confWrapper.conf()),hiveShim);
    table=metaStoreClient.getTable(tablePath.getDatabaseName(),tablePath.getObjectName());
    tableSd=table.getSd();
    tableProps=HiveReflectionUtils.getTableMetadata(hiveShim,table);
    String extractorKind=configuration.get(PARTITION_TIME_EXTRACTOR_KIND);
    String extractorClass=configuration.get(PARTITION_TIME_EXTRACTOR_CLASS);
    String extractorPattern=configuration.get(PARTITION_TIME_EXTRACTOR_TIMESTAMP_PATTERN);
    extractor=PartitionTimeExtractor.create(Thread.currentThread().getContextClassLoader(),extractorKind,extractorClass,extractorPattern);
    tableLocation=new Path(table.getSd().getLocation());
    partValuesToCreateTime=new HashMap<>();
  }
  @Override public List<ComparablePartitionValue> getComparablePartitionValueList() throws Exception {
    List<ComparablePartitionValue> partitionValueList=new ArrayList<>();
switch (consumeOrder) {
case PARTITION_NAME_ORDER:
      List<String> partitionNames=metaStoreClient.listPartitionNames(tablePath.getDatabaseName(),tablePath.getObjectName(),Short.MAX_VALUE);
    for (    String partitionName : partitionNames) {
      partitionValueList.add(getComparablePartitionByName(partitionName));
    }
  break;
case CREATE_TIME_ORDER:
partitionNames=metaStoreClient.listPartitionNames(tablePath.getDatabaseName(),tablePath.getObjectName(),Short.MAX_VALUE);
List<String> newNames=partitionNames.stream().filter(n -> !partValuesToCreateTime.containsKey(extractPartitionValues(n))).collect(Collectors.toList());
List<Partition> newPartitions=metaStoreClient.getPartitionsByNames(tablePath.getDatabaseName(),tablePath.getObjectName(),newNames);
for (Partition partition : newPartitions) {
partValuesToCreateTime.put(partition.getValues(),getPartitionCreateTime(partition));
}
for (List<String> partValues : partValuesToCreateTime.keySet()) {
partitionValueList.add(getComparablePartitionByTime(partValues,partValuesToCreateTime.get(partValues)));
}
break;
case PARTITION_TIME_ORDER:
partitionNames=metaStoreClient.listPartitionNames(tablePath.getDatabaseName(),tablePath.getObjectName(),Short.MAX_VALUE);
for (String partitionName : partitionNames) {
List<String> partValues=extractPartitionValues(partitionName);
Long partitionTime=toMills(extractor.extract(partitionKeys,partValues));
partitionValueList.add(getComparablePartitionByTime(partValues,partitionTime));
}
break;
default :
throw new UnsupportedOperationException("Unsupported consumer order: " + consumeOrder);
}
return partitionValueList;
}
private long getPartitionCreateTime(Partition partition) throws IOException {
Path partLocation=new Path(partition.getSd().getLocation());
FileSystem fs=partLocation.getFileSystem(confWrapper.conf());
FileStatus fileStatus=fs.getFileStatus(partLocation);
return TimestampData.fromTimestamp(new Timestamp(fileStatus.getModificationTime())).getMillisecond();
}
private static List<String> extractPartitionValues(String partitionName){
return PartitionPathUtils.extractPartitionValues(new org.apache.flink.core.fs.Path(partitionName));
}
private ComparablePartitionValue<List<String>,Long> getComparablePartitionByTime(List<String> partValues,Long time){
return new ComparablePartitionValue<List<String>,Long>(){
private static final long serialVersionUID=1L;
@Override public List<String> getPartitionValue(){
return partValues;
}
@Override public Long getComparator(){
return time;
}
}
;
}
private ComparablePartitionValue<List<String>,String> getComparablePartitionByName(String partitionName){
return new ComparablePartitionValue<List<String>,String>(){
private static final long serialVersionUID=1L;
@Override public List<String> getPartitionValue(){
return extractPartitionValues(partitionName);
}
@Override public String getComparator(){
return partitionName;
}
}
;
}
@Override public void close() throws Exception {
if (partValuesToCreateTime != null) {
partValuesToCreateTime.clear();
}
if (this.metaStoreClient != null) {
this.metaStoreClient.close();
}
}
}
