/** 
 * Interface for RocksDB restore. 
 */
public interface RocksDBRestoreOperation extends RestoreOperation<RocksDBRestoreResult>, AutoCloseable {
  /** 
 * Restores state that was previously snapshot-ed from the provided state handles. 
 */
  RocksDBRestoreResult restore() throws Exception ;
}
