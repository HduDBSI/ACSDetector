public static class Book {
  private long bookId;
  private String title;
  private long authorId;
  public Book(){
  }
  public Book(  long bookId,  String title,  long authorId){
    this.bookId=bookId;
    this.title=title;
    this.authorId=authorId;
  }
  @Override public boolean equals(  Object obj){
    if (obj.getClass() == Book.class) {
      Book other=(Book)obj;
      return other.bookId == this.bookId && other.authorId == this.authorId && this.title.equals(other.title);
    }
 else {
      return false;
    }
  }
}
