/** 
 * A  {@link MutableObjectIterator} that wraps a Nephele Reader producing records of a certain type.
 */
public final class ReaderIterator<T> implements MutableObjectIterator<T> {
  private final MutableReader<DeserializationDelegate<T>> reader;
  private final DeserializationDelegate<T> delegate;
  /** 
 * Creates a new iterator, wrapping the given reader.
 * @param reader The reader to wrap.
 */
  public ReaderIterator(  MutableReader<DeserializationDelegate<T>> reader,  TypeSerializer<T> serializer){
    this.reader=reader;
    this.delegate=new DeserializationDelegate<T>(serializer);
  }
  @Override public T next(  T target) throws IOException {
    this.delegate.setInstance(target);
    try {
      if (this.reader.next(this.delegate)) {
        return this.delegate.getInstance();
      }
 else {
        return null;
      }
    }
 catch (    InterruptedException e) {
      throw new IOException("Reader interrupted.",e);
    }
  }
}
