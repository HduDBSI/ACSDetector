public class TaskInputSplitProvider implements InputSplitProvider {
  private final ActorRef jobManager;
  private final JobID jobId;
  private final JobVertexID vertexId;
  private final ExecutionAttemptID executionID;
  private final ClassLoader usercodeClassLoader;
  private final Timeout timeout;
  public TaskInputSplitProvider(  ActorRef jobManager,  JobID jobId,  JobVertexID vertexId,  ExecutionAttemptID executionID,  ClassLoader userCodeClassLoader,  Timeout timeout){
    this.jobManager=jobManager;
    this.jobId=jobId;
    this.vertexId=vertexId;
    this.executionID=executionID;
    this.usercodeClassLoader=userCodeClassLoader;
    this.timeout=timeout;
  }
  @Override public InputSplit getNextInputSplit(){
    try {
      final Future<Object> response=Patterns.ask(jobManager,new JobManagerMessages.RequestNextInputSplit(jobId,vertexId,executionID),timeout);
      final Object result=Await.result(response,timeout.duration());
      if (!(result instanceof JobManagerMessages.NextInputSplit)) {
        throw new RuntimeException("RequestNextInputSplit requires a response of type " + "NextInputSplit. Instead response is of type " + result.getClass() + ".");
      }
 else {
        final JobManagerMessages.NextInputSplit nextInputSplit=(JobManagerMessages.NextInputSplit)result;
        byte[] serializedData=nextInputSplit.splitData();
        if (serializedData == null) {
          return null;
        }
 else {
          Object deserialized=InstantiationUtil.deserializeObject(serializedData,usercodeClassLoader);
          return (InputSplit)deserialized;
        }
      }
    }
 catch (    Exception e) {
      throw new RuntimeException("Requesting the next InputSplit failed.",e);
    }
  }
}
