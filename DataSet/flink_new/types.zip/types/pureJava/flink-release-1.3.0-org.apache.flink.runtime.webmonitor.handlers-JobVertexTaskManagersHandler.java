/** 
 * A request handler that provides the details of a job vertex, including id, name, and the runtime and metrics of all its subtasks aggregated by TaskManager.
 */
public class JobVertexTaskManagersHandler extends AbstractJobVertexRequestHandler {
  private static final String JOB_VERTEX_TASKMANAGERS_REST_PATH="/jobs/:jobid/vertices/:vertexid/taskmanagers";
  private final MetricFetcher fetcher;
  public JobVertexTaskManagersHandler(  ExecutionGraphHolder executionGraphHolder,  MetricFetcher fetcher){
    super(executionGraphHolder);
    this.fetcher=fetcher;
  }
  @Override public String[] getPaths(){
    return new String[]{JOB_VERTEX_TASKMANAGERS_REST_PATH};
  }
  @Override public String handleRequest(  AccessExecutionJobVertex jobVertex,  Map<String,String> params) throws Exception {
    return createVertexDetailsByTaskManagerJson(jobVertex,params.get("jobid"),fetcher);
  }
public static class JobVertexTaskManagersJsonArchivist implements JsonArchivist {
    @Override public Collection<ArchivedJson> archiveJsonWithPath(    AccessExecutionGraph graph) throws IOException {
      List<ArchivedJson> archive=new ArrayList<>();
      for (      AccessExecutionJobVertex task : graph.getAllVertices().values()) {
        String json=createVertexDetailsByTaskManagerJson(task,graph.getJobID().toString(),null);
        String path=JOB_VERTEX_TASKMANAGERS_REST_PATH.replace(":jobid",graph.getJobID().toString()).replace(":vertexid",task.getJobVertexId().toString());
        archive.add(new ArchivedJson(path,json));
      }
      return archive;
    }
  }
  public static String createVertexDetailsByTaskManagerJson(  AccessExecutionJobVertex jobVertex,  String jobID,  @Nullable MetricFetcher fetcher) throws IOException {
    StringWriter writer=new StringWriter();
    JsonGenerator gen=JsonFactory.jacksonFactory.createGenerator(writer);
    Map<String,List<AccessExecutionVertex>> taskManagerVertices=new HashMap<>();
    for (    AccessExecutionVertex vertex : jobVertex.getTaskVertices()) {
      TaskManagerLocation location=vertex.getCurrentAssignedResourceLocation();
      String taskManager=location == null ? "(unassigned)" : location.getHostname() + ":" + location.dataPort();
      List<AccessExecutionVertex> vertices=taskManagerVertices.get(taskManager);
      if (vertices == null) {
        vertices=new ArrayList<>();
        taskManagerVertices.put(taskManager,vertices);
      }
      vertices.add(vertex);
    }
    final long now=System.currentTimeMillis();
    gen.writeStartObject();
    gen.writeStringField("id",jobVertex.getJobVertexId().toString());
    gen.writeStringField("name",jobVertex.getName());
    gen.writeNumberField("now",now);
    gen.writeArrayFieldStart("taskmanagers");
    for (    Map.Entry<String,List<AccessExecutionVertex>> entry : taskManagerVertices.entrySet()) {
      String host=entry.getKey();
      List<AccessExecutionVertex> taskVertices=entry.getValue();
      int[] tasksPerState=new int[ExecutionState.values().length];
      long startTime=Long.MAX_VALUE;
      long endTime=0;
      boolean allFinished=true;
      MutableIOMetrics counts=new MutableIOMetrics();
      for (      AccessExecutionVertex vertex : taskVertices) {
        final ExecutionState state=vertex.getExecutionState();
        tasksPerState[state.ordinal()]++;
        long started=vertex.getStateTimestamp(ExecutionState.DEPLOYING);
        if (started > 0) {
          startTime=Math.min(startTime,started);
        }
        allFinished&=state.isTerminal();
        endTime=Math.max(endTime,vertex.getStateTimestamp(state));
        counts.addIOMetrics(vertex.getCurrentExecutionAttempt(),fetcher,jobID,jobVertex.getJobVertexId().toString());
      }
      long duration;
      if (startTime < Long.MAX_VALUE) {
        if (allFinished) {
          duration=endTime - startTime;
        }
 else {
          endTime=-1L;
          duration=now - startTime;
        }
      }
 else {
        startTime=-1L;
        endTime=-1L;
        duration=-1L;
      }
      ExecutionState jobVertexState=ExecutionJobVertex.getAggregateJobVertexState(tasksPerState,taskVertices.size());
      gen.writeStartObject();
      gen.writeStringField("host",host);
      gen.writeStringField("status",jobVertexState.name());
      gen.writeNumberField("start-time",startTime);
      gen.writeNumberField("end-time",endTime);
      gen.writeNumberField("duration",duration);
      counts.writeIOMetricsAsJson(gen);
      gen.writeObjectFieldStart("status-counts");
      for (      ExecutionState state : ExecutionState.values()) {
        gen.writeNumberField(state.name(),tasksPerState[state.ordinal()]);
      }
      gen.writeEndObject();
      gen.writeEndObject();
    }
    gen.writeEndArray();
    gen.writeEndObject();
    gen.close();
    return writer.toString();
  }
}
