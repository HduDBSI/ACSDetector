/** 
 * This class is a value type that combines a  {@link SlotInfo} with a {@link Locality} hint.
 */
final class SlotInfoAndLocality {
  @Nonnull private final SlotInfo slotInfo;
  @Nonnull private final Locality locality;
  private SlotInfoAndLocality(  @Nonnull SlotInfo slotInfo,  @Nonnull Locality locality){
    this.slotInfo=slotInfo;
    this.locality=locality;
  }
  @Nonnull public SlotInfo getSlotInfo(){
    return slotInfo;
  }
  @Nonnull public Locality getLocality(){
    return locality;
  }
  public static SlotInfoAndLocality of(  @Nonnull SlotInfo slotInfo,  @Nonnull Locality locality){
    return new SlotInfoAndLocality(slotInfo,locality);
  }
}
