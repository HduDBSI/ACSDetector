@RunWith(PowerMockRunner.class) @PrepareForTest(BlobLibraryCacheManager.class) public class JobMasterTest extends TestLogger {
  private final Time testingTimeout=Time.seconds(10L);
  @Test public void testHeartbeatTimeoutWithTaskManager() throws Exception {
    final TestingHighAvailabilityServices haServices=new TestingHighAvailabilityServices();
    final TestingLeaderRetrievalService rmLeaderRetrievalService=new TestingLeaderRetrievalService(null,null);
    haServices.setResourceManagerLeaderRetriever(rmLeaderRetrievalService);
    haServices.setCheckpointRecoveryFactory(mock(CheckpointRecoveryFactory.class));
    final TestingFatalErrorHandler testingFatalErrorHandler=new TestingFatalErrorHandler();
    final String jobManagerAddress="jm";
    final JobMasterId jobMasterId=JobMasterId.generate();
    final ResourceID jmResourceId=new ResourceID(jobManagerAddress);
    final String taskManagerAddress="tm";
    final ResourceID tmResourceId=new ResourceID(taskManagerAddress);
    final TaskManagerLocation taskManagerLocation=new TaskManagerLocation(tmResourceId,InetAddress.getLoopbackAddress(),1234);
    final TaskExecutorGateway taskExecutorGateway=mock(TaskExecutorGateway.class);
    final TestingRpcService rpc=new TestingRpcService();
    rpc.registerGateway(taskManagerAddress,taskExecutorGateway);
    final long heartbeatInterval=1L;
    final long heartbeatTimeout=5L;
    final ScheduledExecutor scheduledExecutor=mock(ScheduledExecutor.class);
    final HeartbeatServices heartbeatServices=new TestingHeartbeatServices(heartbeatInterval,heartbeatTimeout,scheduledExecutor);
    final JobGraph jobGraph=new JobGraph();
    Configuration configuration=new Configuration();
    try (BlobServer blobServer=new BlobServer(configuration,new VoidBlobStore())){
      blobServer.start();
      final JobMaster jobMaster=new JobMaster(rpc,jmResourceId,jobGraph,configuration,haServices,heartbeatServices,Executors.newScheduledThreadPool(1),blobServer,new BlobLibraryCacheManager(blobServer,FlinkUserCodeClassLoaders.ResolveOrder.CHILD_FIRST,new String[0]),mock(RestartStrategyFactory.class),testingTimeout,null,mock(OnCompletionActions.class),testingFatalErrorHandler,FlinkUserCodeClassLoaders.parentFirst(new URL[0],JobMasterTest.class.getClassLoader()));
      CompletableFuture<Acknowledge> startFuture=jobMaster.start(jobMasterId,testingTimeout);
      startFuture.get(testingTimeout.toMilliseconds(),TimeUnit.MILLISECONDS);
      final JobMasterGateway jobMasterGateway=jobMaster.getSelfGateway(JobMasterGateway.class);
      CompletableFuture<RegistrationResponse> registrationResponse=jobMasterGateway.registerTaskManager(taskManagerAddress,taskManagerLocation,testingTimeout);
      registrationResponse.get();
      ArgumentCaptor<Runnable> heartbeatRunnableCaptor=ArgumentCaptor.forClass(Runnable.class);
      verify(scheduledExecutor,times(1)).scheduleAtFixedRate(heartbeatRunnableCaptor.capture(),eq(0L),eq(heartbeatInterval),eq(TimeUnit.MILLISECONDS));
      Runnable heartbeatRunnable=heartbeatRunnableCaptor.getValue();
      ArgumentCaptor<Runnable> timeoutRunnableCaptor=ArgumentCaptor.forClass(Runnable.class);
      verify(scheduledExecutor,timeout(testingTimeout.toMilliseconds())).schedule(timeoutRunnableCaptor.capture(),eq(heartbeatTimeout),eq(TimeUnit.MILLISECONDS));
      Runnable timeoutRunnable=timeoutRunnableCaptor.getValue();
      heartbeatRunnable.run();
      verify(taskExecutorGateway,times(1)).heartbeatFromJobManager(eq(jmResourceId));
      timeoutRunnable.run();
      verify(taskExecutorGateway,timeout(testingTimeout.toMilliseconds())).disconnectJobManager(eq(jobGraph.getJobID()),any(TimeoutException.class));
      testingFatalErrorHandler.rethrowError();
    }
  finally {
      rpc.stopService();
    }
  }
  @Test public void testHeartbeatTimeoutWithResourceManager() throws Exception {
    final String resourceManagerAddress="rm";
    final String jobManagerAddress="jm";
    final ResourceManagerId resourceManagerId=ResourceManagerId.generate();
    final JobMasterId jobMasterId=JobMasterId.generate();
    final ResourceID rmResourceId=new ResourceID(resourceManagerAddress);
    final ResourceID jmResourceId=new ResourceID(jobManagerAddress);
    final JobGraph jobGraph=new JobGraph();
    final TestingHighAvailabilityServices haServices=new TestingHighAvailabilityServices();
    final TestingLeaderRetrievalService rmLeaderRetrievalService=new TestingLeaderRetrievalService(null,null);
    haServices.setResourceManagerLeaderRetriever(rmLeaderRetrievalService);
    haServices.setCheckpointRecoveryFactory(mock(CheckpointRecoveryFactory.class));
    final long heartbeatInterval=1L;
    final long heartbeatTimeout=5L;
    final ScheduledExecutor scheduledExecutor=mock(ScheduledExecutor.class);
    final HeartbeatServices heartbeatServices=new TestingHeartbeatServices(heartbeatInterval,heartbeatTimeout,scheduledExecutor);
    final ResourceManagerGateway resourceManagerGateway=mock(ResourceManagerGateway.class);
    when(resourceManagerGateway.registerJobManager(any(JobMasterId.class),any(ResourceID.class),anyString(),any(JobID.class),any(Time.class))).thenReturn(CompletableFuture.completedFuture(new JobMasterRegistrationSuccess(heartbeatInterval,resourceManagerId,rmResourceId)));
    final TestingRpcService rpc=new TestingRpcService();
    rpc.registerGateway(resourceManagerAddress,resourceManagerGateway);
    final TestingFatalErrorHandler testingFatalErrorHandler=new TestingFatalErrorHandler();
    Configuration configuration=new Configuration();
    try (BlobServer blobServer=new BlobServer(configuration,new VoidBlobStore())){
      blobServer.start();
      final JobMaster jobMaster=new JobMaster(rpc,jmResourceId,jobGraph,configuration,haServices,heartbeatServices,Executors.newScheduledThreadPool(1),blobServer,new BlobLibraryCacheManager(blobServer,FlinkUserCodeClassLoaders.ResolveOrder.CHILD_FIRST,new String[0]),mock(RestartStrategyFactory.class),testingTimeout,null,mock(OnCompletionActions.class),testingFatalErrorHandler,FlinkUserCodeClassLoaders.parentFirst(new URL[0],JobMasterTest.class.getClassLoader()));
      CompletableFuture<Acknowledge> startFuture=jobMaster.start(jobMasterId,testingTimeout);
      startFuture.get(testingTimeout.toMilliseconds(),TimeUnit.MILLISECONDS);
      rmLeaderRetrievalService.notifyListener(resourceManagerAddress,resourceManagerId.toUUID());
      verify(resourceManagerGateway,timeout(testingTimeout.toMilliseconds())).registerJobManager(eq(jobMasterId),eq(jmResourceId),anyString(),eq(jobGraph.getJobID()),any(Time.class));
      verify(resourceManagerGateway,timeout(heartbeatTimeout * 50L)).disconnectJobManager(eq(jobGraph.getJobID()),any(TimeoutException.class));
      testingFatalErrorHandler.rethrowError();
    }
  finally {
      rpc.stopService();
    }
  }
}
