/** 
 * Only used for test. The difference between the class and VarSumAggFunction is accumulator type.
 */
public static class VarSum2AggFunction extends AggregateFunction<Long,Long> {
  @Override public Long createAccumulator(){
    return 0L;
  }
  public void accumulate(  Long acc,  Integer... args){
    for (    Integer x : args) {
      if (x != null) {
        acc+=x.longValue();
      }
    }
  }
  @Override public Long getValue(  Long accumulator){
    return accumulator;
  }
  @Override public TypeInformation<Long> getResultType(){
    return Types.LONG;
  }
}
