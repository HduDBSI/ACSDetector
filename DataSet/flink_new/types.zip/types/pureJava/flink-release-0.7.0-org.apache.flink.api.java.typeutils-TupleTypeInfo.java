public final class TupleTypeInfo<T extends Tuple> extends TupleTypeInfoBase<T> {
  @SuppressWarnings("unchecked") public TupleTypeInfo(  TypeInformation<?>... types){
    this((Class<T>)CLASSES[types.length - 1],types);
  }
  public TupleTypeInfo(  Class<T> tupleType,  TypeInformation<?>... types){
    super(tupleType,types);
    if (types == null || types.length == 0 || types.length > Tuple.MAX_ARITY) {
      throw new IllegalArgumentException();
    }
  }
  @Override public TupleSerializer<T> createSerializer(){
    TypeSerializer<?>[] fieldSerializers=new TypeSerializer<?>[getArity()];
    for (int i=0; i < types.length; i++) {
      fieldSerializers[i]=types[i].createSerializer();
    }
    Class<T> tupleClass=getTypeClass();
    return new TupleSerializer<T>(tupleClass,fieldSerializers);
  }
  /** 
 * Comparator creation
 */
  private TypeComparator<?>[] fieldComparators;
  private int[] logicalKeyFields;
  private int comparatorHelperIndex=0;
  @Override protected void initializeNewComparator(  int localKeyCount){
    fieldComparators=new TypeComparator<?>[localKeyCount];
    logicalKeyFields=new int[localKeyCount];
    comparatorHelperIndex=0;
  }
  @Override protected void addCompareField(  int fieldId,  TypeComparator<?> comparator){
    fieldComparators[comparatorHelperIndex]=comparator;
    logicalKeyFields[comparatorHelperIndex]=fieldId;
    comparatorHelperIndex++;
  }
  @Override protected TypeComparator<T> getNewComparator(){
    @SuppressWarnings("rawtypes") final TypeComparator[] finalFieldComparators=Arrays.copyOf(fieldComparators,comparatorHelperIndex);
    final int[] finalLogicalKeyFields=Arrays.copyOf(logicalKeyFields,comparatorHelperIndex);
    int maxKey=0;
    for (    int key : finalLogicalKeyFields) {
      maxKey=Math.max(maxKey,key);
    }
    TypeSerializer<?>[] fieldSerializers=new TypeSerializer<?>[maxKey + 1];
    for (int i=0; i <= maxKey; i++) {
      fieldSerializers[i]=types[i].createSerializer();
    }
    if (finalFieldComparators.length == 0 || finalLogicalKeyFields.length == 0 || fieldSerializers.length == 0 || finalFieldComparators.length != finalLogicalKeyFields.length) {
      throw new IllegalArgumentException("Tuple comparator creation has a bug");
    }
    return new TupleComparator<T>(finalLogicalKeyFields,finalFieldComparators,fieldSerializers);
  }
  @Override public boolean equals(  Object obj){
    if (obj instanceof TupleTypeInfo) {
      @SuppressWarnings("unchecked") TupleTypeInfo<T> other=(TupleTypeInfo<T>)obj;
      return ((this.tupleType == null && other.tupleType == null) || this.tupleType.equals(other.tupleType)) && Arrays.deepEquals(this.types,other.types);
    }
 else {
      return false;
    }
  }
  @Override public int hashCode(){
    return this.types.hashCode() ^ Arrays.deepHashCode(this.types);
  }
  @Override public String toString(){
    return "Java " + super.toString();
  }
  public static <X extends Tuple>TupleTypeInfo<X> getBasicTupleTypeInfo(  Class<?>... basicTypes){
    if (basicTypes == null || basicTypes.length == 0) {
      throw new IllegalArgumentException();
    }
    TypeInformation<?>[] infos=new TypeInformation<?>[basicTypes.length];
    for (int i=0; i < infos.length; i++) {
      Class<?> type=basicTypes[i];
      if (type == null) {
        throw new IllegalArgumentException("Type at position " + i + " is null.");
      }
      TypeInformation<?> info=BasicTypeInfo.getInfoFor(type);
      if (info == null) {
        throw new IllegalArgumentException("Type at position " + i + " is not a basic type.");
      }
      infos[i]=info;
    }
    @SuppressWarnings("unchecked") TupleTypeInfo<X> tupleInfo=(TupleTypeInfo<X>)new TupleTypeInfo<Tuple>(infos);
    return tupleInfo;
  }
  private static final Class<?>[] CLASSES=new Class<?>[]{Tuple1.class,Tuple2.class,Tuple3.class,Tuple4.class,Tuple5.class,Tuple6.class,Tuple7.class,Tuple8.class,Tuple9.class,Tuple10.class,Tuple11.class,Tuple12.class,Tuple13.class,Tuple14.class,Tuple15.class,Tuple16.class,Tuple17.class,Tuple18.class,Tuple19.class,Tuple20.class,Tuple21.class,Tuple22.class,Tuple23.class,Tuple24.class,Tuple25.class};
}
