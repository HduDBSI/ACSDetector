private static final class PendingRequest {
  private final SlotRequestId slotRequestId;
  private final ResourceProfile resourceProfile;
  private final CompletableFuture<PhysicalSlot> slotFuture;
  private final boolean isBatchRequest;
  private long unfulfillableSince;
  private PendingRequest(  SlotRequestId slotRequestId,  ResourceProfile resourceProfile,  boolean isBatchRequest){
    this.slotRequestId=slotRequestId;
    this.resourceProfile=resourceProfile;
    this.isBatchRequest=isBatchRequest;
    this.slotFuture=new CompletableFuture<>();
    this.unfulfillableSince=Long.MAX_VALUE;
  }
  static PendingRequest createBatchRequest(  SlotRequestId slotRequestId,  ResourceProfile resourceProfile){
    return new PendingRequest(slotRequestId,resourceProfile,true);
  }
  static PendingRequest createNormalRequest(  SlotRequestId slotRequestId,  ResourceProfile resourceProfile){
    return new PendingRequest(slotRequestId,resourceProfile,false);
  }
  SlotRequestId getSlotRequestId(){
    return slotRequestId;
  }
  ResourceProfile getResourceProfile(){
    return resourceProfile;
  }
  CompletableFuture<PhysicalSlot> getSlotFuture(){
    return slotFuture;
  }
  void failRequest(  Exception cause){
    slotFuture.completeExceptionally(cause);
  }
  public boolean isBatchRequest(){
    return isBatchRequest;
  }
  public void markFulfillable(){
    this.unfulfillableSince=Long.MAX_VALUE;
  }
  public void markUnfulfillable(  long currentTimestamp){
    if (isFulfillable()) {
      this.unfulfillableSince=currentTimestamp;
    }
  }
  private boolean isFulfillable(){
    return this.unfulfillableSince == Long.MAX_VALUE;
  }
  public long getUnfulfillableSince(){
    return unfulfillableSince;
  }
  public boolean fulfill(  PhysicalSlot slot){
    return slotFuture.complete(slot);
  }
  @Override public String toString(){
    return "PendingRequest{" + "slotRequestId=" + slotRequestId + ", resourceProfile="+ resourceProfile+ ", isBatchRequest="+ isBatchRequest+ ", unfulfillableSince="+ unfulfillableSince+ '}';
  }
}
