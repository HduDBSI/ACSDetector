/** 
 * Strategy test utilities. 
 */
public class StrategyTestUtil {
  static List<ExecutionVertexID> getExecutionVertexIdsFromDeployOptions(  final List<ExecutionVertexDeploymentOption> deploymentOptions){
    return deploymentOptions.stream().map(ExecutionVertexDeploymentOption::getExecutionVertexId).collect(Collectors.toList());
  }
}
