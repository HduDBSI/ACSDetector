/** 
 * Runnable to complete the given future with a  {@link TimeoutException}.
 */
private static final class Timeout implements Runnable {
  private final CompletableFuture<?> future;
  private Timeout(  CompletableFuture<?> future){
    this.future=checkNotNull(future);
  }
  @Override public void run(){
    future.completeExceptionally(new TimeoutException());
  }
}
