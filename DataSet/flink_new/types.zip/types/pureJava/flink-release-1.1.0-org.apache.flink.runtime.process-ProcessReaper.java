/** 
 * Utility actors that monitors other actors and kills the JVM upon actor termination.
 */
public class ProcessReaper extends UntypedActor {
  private final Logger log;
  private final int exitCode;
  public ProcessReaper(  ActorRef watchTarget,  Logger log,  int exitCode){
    if (watchTarget == null || watchTarget.equals(ActorRef.noSender())) {
      throw new IllegalArgumentException("Target may not be null or 'noSender'");
    }
    this.log=log;
    this.exitCode=exitCode;
    getContext().watch(watchTarget);
  }
  @Override public void onReceive(  Object message){
    if (message instanceof Terminated) {
      try {
        Terminated term=(Terminated)message;
        String name=term.actor().path().toSerializationFormat();
        if (log != null) {
          log.error("Actor " + name + " terminated, stopping process...");
          try {
            Thread.sleep(100);
          }
 catch (          InterruptedException e) {
          }
        }
      }
  finally {
        System.exit(exitCode);
      }
    }
  }
}
