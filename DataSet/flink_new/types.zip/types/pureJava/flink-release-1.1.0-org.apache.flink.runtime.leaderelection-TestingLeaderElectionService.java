/** 
 * Test  {@link LeaderElectionService} implementation which directly forwards isLeader and notLeadercalls to the contender.
 */
public class TestingLeaderElectionService implements LeaderElectionService {
  private LeaderContender contender;
  private boolean hasLeadership=false;
  @Override public void start(  LeaderContender contender) throws Exception {
    this.contender=contender;
  }
  @Override public void stop() throws Exception {
  }
  @Override public void confirmLeaderSessionID(  UUID leaderSessionID){
  }
  @Override public boolean hasLeadership(){
    return hasLeadership;
  }
  public void isLeader(  UUID leaderSessionID){
    hasLeadership=true;
    contender.grantLeadership(leaderSessionID);
  }
  public void notLeader(){
    hasLeadership=false;
    contender.revokeLeadership();
  }
  public void reset(){
    contender=null;
    hasLeadership=false;
  }
}
