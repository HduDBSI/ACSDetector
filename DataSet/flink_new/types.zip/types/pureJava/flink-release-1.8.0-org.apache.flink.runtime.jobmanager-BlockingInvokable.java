/** 
 * Utility to block/unblock a task.
 */
public static class BlockingInvokable extends AbstractInvokable {
  private static final OneShotLatch LATCH=new OneShotLatch();
  public BlockingInvokable(  Environment environment){
    super(environment);
  }
  @Override public void invoke() throws Exception {
    LATCH.await();
  }
  public static void unblock(){
    LATCH.trigger();
  }
}
