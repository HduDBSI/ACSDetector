/** 
 * A  {@link KeyGroupedInternalPriorityQueue} that keeps state on the underlying delegated {@link KeyGroupedInternalPriorityQueue} as well as on the state change log.
 */
public class ChangelogKeyGroupedPriorityQueue<T> implements KeyGroupedInternalPriorityQueue<T> {
  private final KeyGroupedInternalPriorityQueue<T> delegatedPriorityQueue;
  public ChangelogKeyGroupedPriorityQueue(  KeyGroupedInternalPriorityQueue<T> delegatedPriorityQueue){
    this.delegatedPriorityQueue=delegatedPriorityQueue;
  }
  @Override public Set<T> getSubsetForKeyGroup(  int keyGroupId){
    return delegatedPriorityQueue.getSubsetForKeyGroup(keyGroupId);
  }
  @Nullable @Override public T poll(){
    return delegatedPriorityQueue.poll();
  }
  @Nullable @Override public T peek(){
    return delegatedPriorityQueue.peek();
  }
  @Override public boolean add(  T toAdd){
    return delegatedPriorityQueue.add(toAdd);
  }
  @Override public boolean remove(  T toRemove){
    return delegatedPriorityQueue.remove(toRemove);
  }
  @Override public boolean isEmpty(){
    return delegatedPriorityQueue.isEmpty();
  }
  @Override public int size(){
    return delegatedPriorityQueue.size();
  }
  @Override public void addAll(  @Nullable Collection<? extends T> toAdd){
    delegatedPriorityQueue.addAll(toAdd);
  }
  @Override public CloseableIterator<T> iterator(){
    return delegatedPriorityQueue.iterator();
  }
}
