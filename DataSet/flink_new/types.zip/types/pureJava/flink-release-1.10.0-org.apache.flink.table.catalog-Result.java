/** 
 * Result of a function lookup.
 */
class Result {
  private final FunctionIdentifier functionIdentifier;
  private final FunctionDefinition functionDefinition;
  public Result(  FunctionIdentifier functionIdentifier,  FunctionDefinition functionDefinition){
    this.functionIdentifier=functionIdentifier;
    this.functionDefinition=functionDefinition;
  }
  public FunctionIdentifier getFunctionIdentifier(){
    return functionIdentifier;
  }
  public FunctionDefinition getFunctionDefinition(){
    return functionDefinition;
  }
}
