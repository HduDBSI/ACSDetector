protected class StreamWindow implements Serializable {
  private static final long serialVersionUID=1L;
  protected int granularity;
  protected int batchPerSlide;
  protected long numberOfBatches;
  protected long minibatchCounter;
  protected CircularFifoList<IN1> circularList1;
  protected CircularFifoList<IN2> circularList2;
  public StreamWindow(){
    this.granularity=(int)MathUtils.gcd(windowSize,slideSize);
    this.batchPerSlide=(int)(slideSize / granularity);
    this.numberOfBatches=windowSize / granularity;
    this.circularList1=new CircularFifoList<IN1>();
    this.circularList2=new CircularFifoList<IN2>();
    this.minibatchCounter=0;
  }
  public void addToBuffer1(  IN1 nextValue) throws Exception {
    checkWindowEnd(timeStamp1.getTimestamp(nextValue));
    if (minibatchCounter >= 0) {
      circularList1.add(nextValue);
    }
  }
  public void addToBuffer2(  IN2 nextValue) throws Exception {
    checkWindowEnd(timeStamp2.getTimestamp(nextValue));
    if (minibatchCounter >= 0) {
      circularList2.add(nextValue);
    }
  }
  protected synchronized void checkWindowEnd(  long timeStamp){
    nextRecordTime=timeStamp;
    while (miniBatchEnd()) {
      circularList1.newSlide();
      circularList2.newSlide();
      minibatchCounter++;
      if (windowEnd()) {
        callUserFunctionAndLogException();
        circularList1.shiftWindow(batchPerSlide);
        circularList2.shiftWindow(batchPerSlide);
      }
    }
  }
  protected boolean miniBatchEnd(){
    if (nextRecordTime < startTime + granularity) {
      return false;
    }
 else {
      startTime+=granularity;
      return true;
    }
  }
  public boolean windowEnd(){
    if (minibatchCounter == numberOfBatches) {
      minibatchCounter-=batchPerSlide;
      return true;
    }
    return false;
  }
  public void reduceLastBatch(){
    if (!miniBatchEnd()) {
      callUserFunctionAndLogException();
    }
  }
  public Iterable<IN1> getIterable1(){
    return circularList1.getIterable();
  }
  public Iterable<IN2> getIterable2(){
    return circularList2.getIterable();
  }
  @Override public String toString(){
    return circularList1.toString();
  }
}
