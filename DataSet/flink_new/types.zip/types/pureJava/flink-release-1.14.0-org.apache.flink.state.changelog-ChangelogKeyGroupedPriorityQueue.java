/** 
 * A  {@link KeyGroupedInternalPriorityQueue} that keeps state on the underlying delegated {@link KeyGroupedInternalPriorityQueue} as well as on the state change log.
 */
public class ChangelogKeyGroupedPriorityQueue<T> implements KeyGroupedInternalPriorityQueue<T>, ChangelogState {
  private final KeyGroupedInternalPriorityQueue<T> delegatedPriorityQueue;
  private final PriorityQueueStateChangeLogger<T> logger;
  private final TypeSerializer<T> serializer;
  public ChangelogKeyGroupedPriorityQueue(  KeyGroupedInternalPriorityQueue<T> delegatedPriorityQueue,  PriorityQueueStateChangeLogger<T> logger,  TypeSerializer<T> serializer){
    this.delegatedPriorityQueue=checkNotNull(delegatedPriorityQueue);
    this.logger=checkNotNull(logger);
    this.serializer=serializer;
  }
  @Override public Set<T> getSubsetForKeyGroup(  int keyGroupId){
    return delegatedPriorityQueue.getSubsetForKeyGroup(keyGroupId);
  }
  @Nullable @Override public T poll(){
    T polled=delegatedPriorityQueue.poll();
    try {
      logger.stateElementPolled();
    }
 catch (    IOException e) {
      ExceptionUtils.rethrow(e);
    }
    return polled;
  }
  @Nullable @Override public T peek(){
    return delegatedPriorityQueue.peek();
  }
  @Override public boolean add(  T toAdd){
    boolean changed=delegatedPriorityQueue.add(toAdd);
    logAddition(singletonList(toAdd));
    return changed;
  }
  @Override public boolean remove(  T toRemove){
    boolean removed=delegatedPriorityQueue.remove(toRemove);
    try {
      logger.valueElementRemoved(out -> serializer.serialize(toRemove,out),null);
    }
 catch (    IOException e) {
      ExceptionUtils.rethrow(e);
    }
    return removed;
  }
  @Override public boolean isEmpty(){
    return delegatedPriorityQueue.isEmpty();
  }
  @Override public int size(){
    return delegatedPriorityQueue.size();
  }
  @Override public void addAll(  @Nullable Collection<? extends T> toAdd){
    delegatedPriorityQueue.addAll(toAdd);
    logAddition(toAdd);
  }
  private void logAddition(  Collection<? extends T> toAdd){
    try {
      logger.valueElementAdded(out -> {
        out.writeInt(toAdd.size());
        for (        T x : toAdd) {
          serializer.serialize(x,out);
        }
      }
,null);
    }
 catch (    IOException e) {
      ExceptionUtils.rethrow(e);
    }
  }
  @Override @Nonnull public CloseableIterator<T> iterator(){
    return StateChangeLoggingIterator.create(delegatedPriorityQueue.iterator(),logger,serializer::serialize,null);
  }
  @Override public StateChangeApplier getChangeApplier(  ChangelogApplierFactory factory){
    return factory.forPriorityQueue(delegatedPriorityQueue,serializer);
  }
}
