/** 
 * Integration test that verifies that a user program with a big(ger) payload is successfully submitted and run.
 */
public class BigUserProgramJobSubmitITCase extends TestLogger {
  private static final MiniCluster CLUSTER;
  private static final RestClusterClient<StandaloneClusterId> CLIENT;
static {
    try {
      MiniClusterConfiguration clusterConfiguration=new MiniClusterConfiguration.Builder().setNumTaskManagers(1).setNumSlotsPerTaskManager(1).build();
      CLUSTER=new MiniCluster(clusterConfiguration);
      CLUSTER.start();
      URI restAddress=CLUSTER.getRestAddress();
      final Configuration clientConfig=new Configuration();
      clientConfig.setString(JobManagerOptions.ADDRESS,restAddress.getHost());
      clientConfig.setInteger(RestOptions.PORT,restAddress.getPort());
      CLIENT=new RestClusterClient<>(clientConfig,StandaloneClusterId.getInstance());
    }
 catch (    Exception e) {
      throw new AssertionError("Could not setup cluster.",e);
    }
  }
  @AfterClass public static void teardown() throws Exception {
    CLIENT.shutdown();
    CLUSTER.close();
  }
  private final Random rnd=new Random();
  /** 
 * Use a map function that references a 100MB byte array.
 */
  @Test public void bigDataInMap() throws Exception {
    final byte[] data=new byte[16 * 1024 * 1024];
    rnd.nextBytes(data);
    data[1]=0;
    data[3]=0;
    data[5]=0;
    CollectingSink resultSink=new CollectingSink();
    StreamExecutionEnvironment env=StreamExecutionEnvironment.getExecutionEnvironment();
    env.setParallelism(1);
    DataStream<Integer> src=env.fromElements(1,3,5);
    src.map(new MapFunction<Integer,String>(){
      private static final long serialVersionUID=1L;
      @Override public String map(      Integer value) throws Exception {
        return "x " + value + " "+ data[value];
      }
    }
).addSink(resultSink);
    JobGraph jobGraph=StreamingJobGraphGenerator.createJobGraph(env.getStreamGraph());
    CLIENT.setDetached(false);
    CLIENT.submitJob(jobGraph,BigUserProgramJobSubmitITCase.class.getClassLoader());
    List<String> expected=Arrays.asList("x 1 0","x 3 0","x 5 0");
    List<String> result=CollectingSink.result;
    Collections.sort(expected);
    Collections.sort(result);
    assertEquals(expected,result);
  }
private static class CollectingSink implements SinkFunction<String> {
    private static final List<String> result=Collections.synchronizedList(new ArrayList<>(3));
    public void invoke(    String value,    Context context) throws Exception {
      result.add(value);
    }
  }
}
