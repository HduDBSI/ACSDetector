/** 
 * Exception indicating that we could not find a Flink job with the given job ID.
 */
public class FlinkJobNotFoundException extends FlinkException {
  private static final long serialVersionUID=2294698055059659025L;
  public FlinkJobNotFoundException(  JobID jobId){
    super("Could not find Flink job (" + jobId + ')');
  }
}
