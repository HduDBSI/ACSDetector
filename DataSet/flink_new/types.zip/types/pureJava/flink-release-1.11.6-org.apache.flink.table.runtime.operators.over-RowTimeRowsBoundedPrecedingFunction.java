/** 
 * Process Function for ROWS clause event-time bounded OVER window. <p>E.g.: SELECT rowtime, b, c, min(c) OVER (PARTITION BY b ORDER BY rowtime ROWS BETWEEN 2 PRECEDING AND CURRENT ROW), max(c) OVER (PARTITION BY b ORDER BY rowtime ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) FROM T.
 */
public class RowTimeRowsBoundedPrecedingFunction<K> extends KeyedProcessFunctionWithCleanupState<K,RowData,RowData> {
  private static final long serialVersionUID=1L;
  private static final Logger LOG=LoggerFactory.getLogger(RowTimeRowsBoundedPrecedingFunction.class);
  private final GeneratedAggsHandleFunction genAggsHandler;
  private final LogicalType[] accTypes;
  private final LogicalType[] inputFieldTypes;
  private final long precedingOffset;
  private final int rowTimeIdx;
  private transient JoinedRowData output;
  private transient ValueState<Long> lastTriggeringTsState;
  private transient ValueState<Long> counterState;
  private transient ValueState<RowData> accState;
  private transient MapState<Long,List<RowData>> inputState;
  private transient AggsHandleFunction function;
  public RowTimeRowsBoundedPrecedingFunction(  long minRetentionTime,  long maxRetentionTime,  GeneratedAggsHandleFunction genAggsHandler,  LogicalType[] accTypes,  LogicalType[] inputFieldTypes,  long precedingOffset,  int rowTimeIdx){
    super(minRetentionTime,maxRetentionTime);
    Preconditions.checkNotNull(precedingOffset);
    this.genAggsHandler=genAggsHandler;
    this.accTypes=accTypes;
    this.inputFieldTypes=inputFieldTypes;
    this.precedingOffset=precedingOffset;
    this.rowTimeIdx=rowTimeIdx;
  }
  @Override public void open(  Configuration parameters) throws Exception {
    function=genAggsHandler.newInstance(getRuntimeContext().getUserCodeClassLoader());
    function.open(new PerKeyStateDataViewStore(getRuntimeContext()));
    output=new JoinedRowData();
    ValueStateDescriptor<Long> lastTriggeringTsDescriptor=new ValueStateDescriptor<Long>("lastTriggeringTsState",Types.LONG);
    lastTriggeringTsState=getRuntimeContext().getState(lastTriggeringTsDescriptor);
    ValueStateDescriptor<Long> dataCountStateDescriptor=new ValueStateDescriptor<Long>("processedCountState",Types.LONG);
    counterState=getRuntimeContext().getState(dataCountStateDescriptor);
    RowDataTypeInfo accTypeInfo=new RowDataTypeInfo(accTypes);
    ValueStateDescriptor<RowData> accStateDesc=new ValueStateDescriptor<RowData>("accState",accTypeInfo);
    accState=getRuntimeContext().getState(accStateDesc);
    RowDataTypeInfo inputType=new RowDataTypeInfo(inputFieldTypes);
    ListTypeInfo<RowData> rowListTypeInfo=new ListTypeInfo<RowData>(inputType);
    MapStateDescriptor<Long,List<RowData>> inputStateDesc=new MapStateDescriptor<Long,List<RowData>>("inputState",Types.LONG,rowListTypeInfo);
    inputState=getRuntimeContext().getMapState(inputStateDesc);
    initCleanupTimeState("RowTimeBoundedRowsOverCleanupTime");
  }
  @Override public void processElement(  RowData input,  KeyedProcessFunction<K,RowData,RowData>.Context ctx,  Collector<RowData> out) throws Exception {
    registerProcessingCleanupTimer(ctx,ctx.timerService().currentProcessingTime());
    long triggeringTs=input.getLong(rowTimeIdx);
    Long lastTriggeringTs=lastTriggeringTsState.value();
    if (lastTriggeringTs == null) {
      lastTriggeringTs=0L;
    }
    if (triggeringTs > lastTriggeringTs) {
      List<RowData> data=inputState.get(triggeringTs);
      if (null != data) {
        data.add(input);
        inputState.put(triggeringTs,data);
      }
 else {
        data=new ArrayList<RowData>();
        data.add(input);
        inputState.put(triggeringTs,data);
        ctx.timerService().registerEventTimeTimer(triggeringTs);
      }
    }
  }
  @Override public void onTimer(  long timestamp,  KeyedProcessFunction<K,RowData,RowData>.OnTimerContext ctx,  Collector<RowData> out) throws Exception {
    if (isProcessingTimeTimer(ctx)) {
      if (stateCleaningEnabled) {
        Iterator<Long> keysIt=inputState.keys().iterator();
        Long lastProcessedTime=lastTriggeringTsState.value();
        if (lastProcessedTime == null) {
          lastProcessedTime=0L;
        }
        boolean noRecordsToProcess=true;
        while (keysIt.hasNext() && noRecordsToProcess) {
          if (keysIt.next() > lastProcessedTime) {
            noRecordsToProcess=false;
          }
        }
        if (noRecordsToProcess) {
          cleanupState(inputState,accState,counterState,lastTriggeringTsState);
          function.cleanup();
        }
 else {
          registerProcessingCleanupTimer(ctx,ctx.timerService().currentProcessingTime());
        }
      }
      return;
    }
    List<RowData> inputs=inputState.get(timestamp);
    if (null != inputs) {
      Long dataCount=counterState.value();
      if (dataCount == null) {
        dataCount=0L;
      }
      RowData accumulators=accState.value();
      if (accumulators == null) {
        accumulators=function.createAccumulators();
      }
      function.setAccumulators(accumulators);
      List<RowData> retractList=null;
      long retractTs=Long.MAX_VALUE;
      int retractCnt=0;
      int i=0;
      while (i < inputs.size()) {
        RowData input=inputs.get(i);
        RowData retractRow=null;
        if (dataCount >= precedingOffset) {
          if (null == retractList) {
            retractTs=Long.MAX_VALUE;
            for (            Long dataTs : inputState.keys()) {
              if (dataTs < retractTs) {
                retractTs=dataTs;
                retractList=inputState.get(dataTs);
              }
            }
          }
          if (retractList != null) {
            retractRow=retractList.get(retractCnt);
            retractCnt+=1;
            if (retractList.size() == retractCnt) {
              inputState.remove(retractTs);
              retractList=null;
              retractCnt=0;
            }
          }
        }
 else {
          dataCount+=1;
        }
        if (null != retractRow) {
          function.retract(retractRow);
        }
        function.accumulate(input);
        output.replace(input,function.getValue());
        out.collect(output);
        i+=1;
      }
      if (inputState.contains(retractTs)) {
        if (retractCnt > 0) {
          retractList.subList(0,retractCnt).clear();
          inputState.put(retractTs,retractList);
        }
      }
      counterState.update(dataCount);
      accumulators=function.getAccumulators();
      accState.update(accumulators);
    }
    lastTriggeringTsState.update(timestamp);
    registerProcessingCleanupTimer(ctx,ctx.timerService().currentProcessingTime());
  }
  @Override public void close() throws Exception {
    if (null != function) {
      function.close();
    }
  }
}
