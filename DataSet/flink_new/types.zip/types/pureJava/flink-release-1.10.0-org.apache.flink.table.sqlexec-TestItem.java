private static class TestItem {
  private final String testExpr;
  @Nullable private Object expectedType;
  @Nullable private String expectedError;
  private TestItem(  String testExpr){
    this.testExpr=testExpr;
  }
  static TestItem fromTestExpr(  String testExpr){
    return new TestItem(testExpr);
  }
  TestItem withExpectedType(  Object expectedType){
    this.expectedType=expectedType;
    return this;
  }
  TestItem withExpectedError(  String expectedError){
    this.expectedError=expectedError;
    return this;
  }
  @Override public String toString(){
    return this.testExpr;
  }
}
