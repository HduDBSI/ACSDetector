private static class RecordPusher<IN> extends AbstractStreamOperator<IN> implements OneInputStreamOperator<IN,IN> {
  private static final long serialVersionUID=1L;
  @Override public void processElement(  StreamRecord<IN> record) throws Exception {
    output.collect(record);
  }
  @Override public void processWatermark(  Watermark mark){
  }
  @Override public void processLatencyMarker(  LatencyMarker latencyMarker) throws Exception {
  }
}
