/** 
 * Test job that retrieves the net runtime from the  {@link JobExecutionResult}.
 */
public static final class TestGetRuntime {
  public static void main(  String[] args) throws Exception {
    final ExecutionEnvironment env=ExecutionEnvironment.getExecutionEnvironment();
    env.fromElements(1,2).output(new DiscardingOutputFormat<Integer>());
    env.execute().getNetRuntime();
  }
}
