/** 
 * A  {@link Format} for a {@link DynamicTableSink} for writing rows.
 * @param < I > runtime interface needed by the table sink
 */
@PublicEvolving public interface EncodingFormat<I> extends Format {
  /** 
 * Creates runtime encoder implementation that is configured to consume data of the given data type.
 */
  I createRuntimeEncoder(  DynamicTableSink.Context context,  DataType physicalDataType);
  /** 
 * Returns the map of metadata keys and their corresponding data types that can be consumed by this format for writing. By default, this method returns an empty map. <p>Metadata columns add additional columns to the table's schema. An encoding format is responsible to accept requested metadata columns at the end of consumed rows and persist them. <p>See  {@link SupportsWritingMetadata} for more information.<p>Note: This method is only used if the outer  {@link DynamicTableSink} implements {@link SupportsWritingMetadata}and calls this method in  {@link SupportsWritingMetadata#listWritableMetadata()}.
 */
  default Map<String,DataType> listWritableMetadata(){
    return Collections.emptyMap();
  }
  /** 
 * Provides a list of metadata keys that the consumed row will contain as appended metadata columns. By default, this method throws an exception if metadata keys are defined. <p>See  {@link SupportsWritingMetadata} for more information.<p>Note: This method is only used if the outer  {@link DynamicTableSink} implements {@link SupportsWritingMetadata}and calls this method in  {@link SupportsWritingMetadata#applyWritableMetadata(List,DataType)}.
 */
  @SuppressWarnings("unused") default void applyWritableMetadata(  List<String> metadataKeys){
    throw new UnsupportedOperationException("An encoding format must override this method to apply metadata keys.");
  }
}
