public class BlobRecoveryITCase {
  private File recoveryDir;
  @Before public void setUp() throws Exception {
    recoveryDir=new File(FileUtils.getTempDirectory(),"BlobRecoveryITCaseDir");
    if (!recoveryDir.exists() && !recoveryDir.mkdirs()) {
      throw new IllegalStateException("Failed to create temp directory for test");
    }
  }
  @After public void cleanUp() throws Exception {
    if (recoveryDir != null) {
      FileUtils.deleteDirectory(recoveryDir);
    }
  }
  /** 
 * Tests that with  {@link HighAvailabilityMode#ZOOKEEPER} distributed JARs are recoverable from anyparticipating BlobServer.
 */
  @Test public void testBlobServerRecovery() throws Exception {
    Configuration config=new Configuration();
    config.setString(HighAvailabilityOptions.HA_MODE,"ZOOKEEPER");
    config.setString(ConfigConstants.STATE_BACKEND,"FILESYSTEM");
    config.setString(HighAvailabilityOptions.HA_STORAGE_PATH,recoveryDir.getPath());
    testBlobServerRecovery(config);
  }
  public static void testBlobServerRecovery(  final Configuration config) throws IOException {
    String storagePath=config.getString(HighAvailabilityOptions.HA_STORAGE_PATH);
    Random rand=new Random();
    BlobServer[] server=new BlobServer[2];
    InetSocketAddress[] serverAddress=new InetSocketAddress[2];
    BlobClient client=null;
    try {
      for (int i=0; i < server.length; i++) {
        server[i]=new BlobServer(config);
        serverAddress[i]=new InetSocketAddress("localhost",server[i].getPort());
      }
      client=new BlobClient(serverAddress[0],config);
      byte[] expected=new byte[1024];
      rand.nextBytes(expected);
      BlobKey[] keys=new BlobKey[2];
      keys[0]=client.put(expected);
      keys[1]=client.put(expected,32,256);
      JobID[] jobId=new JobID[]{new JobID(),new JobID()};
      String[] testKey=new String[]{"test-key-1","test-key-2"};
      client.put(jobId[0],testKey[0],expected);
      client.put(jobId[1],testKey[1],expected,32,256);
      final Path blobServerPath=new Path(storagePath,"blob");
      FileSystem fs=blobServerPath.getFileSystem();
      assertTrue("Unknown storage dir: " + blobServerPath,fs.exists(blobServerPath));
      client.close();
      client=new BlobClient(serverAddress[1],config);
      try (InputStream is=client.get(keys[0])){
        byte[] actual=new byte[expected.length];
        BlobUtils.readFully(is,actual,0,expected.length,null);
        for (int i=0; i < expected.length; i++) {
          assertEquals(expected[i],actual[i]);
        }
      }
       try (InputStream is=client.get(keys[1])){
        byte[] actual=new byte[256];
        BlobUtils.readFully(is,actual,0,256,null);
        for (int i=32, j=0; i < 256; i++, j++) {
          assertEquals(expected[i],actual[j]);
        }
      }
       try (InputStream is=client.get(jobId[0],testKey[0])){
        byte[] actual=new byte[expected.length];
        BlobUtils.readFully(is,actual,0,expected.length,null);
        for (int i=0; i < expected.length; i++) {
          assertEquals(expected[i],actual[i]);
        }
      }
       try (InputStream is=client.get(jobId[1],testKey[1])){
        byte[] actual=new byte[256];
        BlobUtils.readFully(is,actual,0,256,null);
        for (int i=32, j=0; i < 256; i++, j++) {
          assertEquals(expected[i],actual[j]);
        }
      }
       client.delete(keys[0]);
      client.delete(keys[1]);
      client.delete(jobId[0],testKey[0]);
      client.delete(jobId[1],testKey[1]);
      if (fs.exists(blobServerPath)) {
        final org.apache.flink.core.fs.FileStatus[] recoveryFiles=fs.listStatus(blobServerPath);
        ArrayList<String> filenames=new ArrayList<String>(recoveryFiles.length);
        for (        org.apache.flink.core.fs.FileStatus file : recoveryFiles) {
          filenames.add(file.toString());
        }
        fail("Unclean state backend: " + filenames);
      }
    }
  finally {
      for (      BlobServer s : server) {
        if (s != null) {
          s.shutdown();
        }
      }
      if (client != null) {
        client.close();
      }
    }
  }
}
