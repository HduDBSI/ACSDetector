/** 
 * Base class for per-window  {@link KeyedStateStore KeyedStateStores}. Used to allow per-window state access for  {@link org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction}.
 */
public abstract class AbstractPerWindowStateStore extends DefaultKeyedStateStore {
  protected W window;
  public AbstractPerWindowStateStore(  KeyedStateBackend<?> keyedStateBackend,  ExecutionConfig executionConfig){
    super(keyedStateBackend,executionConfig);
  }
}
