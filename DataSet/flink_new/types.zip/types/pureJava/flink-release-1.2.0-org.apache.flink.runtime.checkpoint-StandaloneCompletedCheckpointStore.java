/** 
 * {@link CompletedCheckpointStore} for JobManagers running in {@link HighAvailabilityMode#NONE}.
 */
public class StandaloneCompletedCheckpointStore implements CompletedCheckpointStore {
  private static final Logger LOG=LoggerFactory.getLogger(StandaloneCompletedCheckpointStore.class);
  /** 
 * The maximum number of checkpoints to retain (at least 1). 
 */
  private final int maxNumberOfCheckpointsToRetain;
  /** 
 * The completed checkpoints. 
 */
  private final ArrayDeque<CompletedCheckpoint> checkpoints;
  /** 
 * Creates  {@link StandaloneCompletedCheckpointStore}.
 * @param maxNumberOfCheckpointsToRetain The maximum number of checkpoints to retain (atleast 1). Adding more checkpoints than this results in older checkpoints being discarded.
 */
  public StandaloneCompletedCheckpointStore(  int maxNumberOfCheckpointsToRetain){
    checkArgument(maxNumberOfCheckpointsToRetain >= 1,"Must retain at least one checkpoint.");
    this.maxNumberOfCheckpointsToRetain=maxNumberOfCheckpointsToRetain;
    this.checkpoints=new ArrayDeque<>(maxNumberOfCheckpointsToRetain + 1);
  }
  @Override public void recover() throws Exception {
  }
  @Override public void addCheckpoint(  CompletedCheckpoint checkpoint) throws Exception {
    checkpoints.add(checkpoint);
    if (checkpoints.size() > maxNumberOfCheckpointsToRetain) {
      checkpoints.remove().subsume();
    }
  }
  @Override public CompletedCheckpoint getLatestCheckpoint(){
    return checkpoints.isEmpty() ? null : checkpoints.getLast();
  }
  @Override public List<CompletedCheckpoint> getAllCheckpoints(){
    return new ArrayList<>(checkpoints);
  }
  @Override public int getNumberOfRetainedCheckpoints(){
    return checkpoints.size();
  }
  @Override public void shutdown(  JobStatus jobStatus) throws Exception {
    try {
      LOG.info("Shutting down");
      for (      CompletedCheckpoint checkpoint : checkpoints) {
        checkpoint.discard(jobStatus);
      }
    }
  finally {
      checkpoints.clear();
    }
  }
}
