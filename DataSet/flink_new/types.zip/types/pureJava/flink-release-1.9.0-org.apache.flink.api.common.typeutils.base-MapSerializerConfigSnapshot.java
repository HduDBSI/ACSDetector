/** 
 * Configuration snapshot for serializers of maps, containing the configuration snapshot of its key serializer and value serializer.
 * @deprecated this snapshot class should not be used by any serializer anymore.
 */
@Internal @Deprecated public final class MapSerializerConfigSnapshot<K,V> extends CompositeTypeSerializerConfigSnapshot<Map<K,V>> {
  private static final int VERSION=1;
  /** 
 * This empty nullary constructor is required for deserializing the configuration. 
 */
  public MapSerializerConfigSnapshot(){
  }
  public MapSerializerConfigSnapshot(  TypeSerializer<K> keySerializer,  TypeSerializer<V> valueSerializer){
    super(keySerializer,valueSerializer);
  }
  @Override public TypeSerializerSchemaCompatibility<Map<K,V>> resolveSchemaCompatibility(  TypeSerializer<Map<K,V>> newSerializer){
    if (newSerializer instanceof MapSerializer) {
      List<Tuple2<TypeSerializer<?>,TypeSerializerSnapshot<?>>> nestedSerializersAndConfigs=getNestedSerializersAndConfigs();
      return CompositeTypeSerializerUtil.delegateCompatibilityCheckToNewSnapshot(newSerializer,new MapSerializerSnapshot<>(),nestedSerializersAndConfigs.get(0).f1,nestedSerializersAndConfigs.get(1).f1);
    }
 else {
      return super.resolveSchemaCompatibility(newSerializer);
    }
  }
  @Override public int getVersion(){
    return VERSION;
  }
}
