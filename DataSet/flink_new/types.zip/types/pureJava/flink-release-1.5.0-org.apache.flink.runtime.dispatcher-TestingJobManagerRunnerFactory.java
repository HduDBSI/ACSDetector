private static final class TestingJobManagerRunnerFactory implements Dispatcher.JobManagerRunnerFactory {
  private final CompletableFuture<ArchivedExecutionGraph> resultFuture;
  private final CompletableFuture<Void> terminationFuture;
  private TestingJobManagerRunnerFactory(  CompletableFuture<ArchivedExecutionGraph> resultFuture,  CompletableFuture<Void> terminationFuture){
    this.resultFuture=resultFuture;
    this.terminationFuture=terminationFuture;
  }
  @Override public JobManagerRunner createJobManagerRunner(  ResourceID resourceId,  JobGraph jobGraph,  Configuration configuration,  RpcService rpcService,  HighAvailabilityServices highAvailabilityServices,  HeartbeatServices heartbeatServices,  BlobServer blobServer,  JobManagerSharedServices jobManagerServices,  JobManagerJobMetricGroupFactory jobManagerJobMetricGroupFactory,  FatalErrorHandler fatalErrorHandler){
    final JobManagerRunner jobManagerRunnerMock=mock(JobManagerRunner.class);
    when(jobManagerRunnerMock.getResultFuture()).thenReturn(resultFuture);
    when(jobManagerRunnerMock.closeAsync()).thenReturn(terminationFuture);
    return jobManagerRunnerMock;
  }
}
