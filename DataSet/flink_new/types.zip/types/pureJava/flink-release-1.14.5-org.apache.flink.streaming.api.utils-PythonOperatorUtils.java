/** 
 * Utilities used by Python operators. 
 */
@Internal public class PythonOperatorUtils {
  /** 
 * Set the current key for streaming operator. 
 */
  public static <K>void setCurrentKeyForStreaming(  KeyedStateBackend<K> stateBackend,  K currentKey){
    if (!inBatchExecutionMode(stateBackend)) {
      stateBackend.setCurrentKey(currentKey);
    }
  }
  /** 
 * Set the current key for the timer service. 
 */
  public static <K,N>void setCurrentKeyForTimerService(  InternalTimerService<N> internalTimerService,  K currentKey) throws Exception {
    if (internalTimerService instanceof BatchExecutionInternalTimeService) {
      ((BatchExecutionInternalTimeService<K,N>)internalTimerService).setCurrentKey(currentKey);
    }
  }
  public static <K>boolean inBatchExecutionMode(  KeyedStateBackend<K> stateBackend){
    return stateBackend instanceof BatchExecutionKeyedStateBackend;
  }
}
