/** 
 * Runtime converter that maps between  {@link JsonNode}s and Java objects.
 */
@FunctionalInterface private interface DeserializationRuntimeConverter extends Serializable {
  Object convert(  ObjectMapper mapper,  JsonNode jsonNode);
}
