/** 
 * The shutdown hook used to destroy the Python process. 
 */
public static class PythonProcessShutdownHook extends Thread {
  private Process process;
  private GatewayServer gatewayServer;
  private String tmpDir;
  public PythonProcessShutdownHook(  Process process,  GatewayServer gatewayServer,  String tmpDir){
    this.process=process;
    this.gatewayServer=gatewayServer;
    this.tmpDir=tmpDir;
  }
  @Override public void run(){
    if (tmpDir != null) {
      FileUtils.deleteDirectoryQuietly(new File(tmpDir));
    }
    try {
      shutdownPythonProcess(process,TIMEOUT_MILLIS);
    }
  finally {
      gatewayServer.shutdown();
    }
  }
}
