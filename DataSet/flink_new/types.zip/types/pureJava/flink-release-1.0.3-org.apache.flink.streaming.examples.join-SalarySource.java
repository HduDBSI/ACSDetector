/** 
 * Continuously emit tuples with random names and integers (salaries).
 */
public static class SalarySource extends RichSourceFunction<Tuple3<Long,String,Integer>> {
  private static final long serialVersionUID=1L;
  private transient Random rand;
  private transient Tuple3<Long,String,Integer> outTuple;
  private volatile boolean isRunning;
  private int counter;
  public void open(  Configuration parameters) throws Exception {
    super.open(parameters);
    rand=new Random();
    outTuple=new Tuple3<Long,String,Integer>();
    isRunning=true;
  }
  @Override public void run(  SourceContext<Tuple3<Long,String,Integer>> ctx) throws Exception {
    while (isRunning && counter < 100) {
      outTuple.f0=System.currentTimeMillis();
      outTuple.f1=names[rand.nextInt(names.length)];
      outTuple.f2=rand.nextInt(SALARY_MAX) + 1;
      Thread.sleep(rand.nextInt(SLEEP_TIME) + 1);
      counter++;
      ctx.collect(outTuple);
    }
  }
  @Override public void cancel(){
    isRunning=false;
  }
}
