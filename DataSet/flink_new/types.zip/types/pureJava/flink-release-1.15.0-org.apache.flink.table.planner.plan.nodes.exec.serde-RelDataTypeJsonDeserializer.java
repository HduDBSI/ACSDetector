/** 
 * JSON deserializer for  {@link RelDataType}.
 * @see RelDataTypeJsonSerializer for the reverse operation
 */
@Internal final class RelDataTypeJsonDeserializer extends StdDeserializer<RelDataType> {
  private static final long serialVersionUID=1L;
  RelDataTypeJsonDeserializer(){
    super(RelDataType.class);
  }
  @Override public RelDataType deserialize(  JsonParser jsonParser,  DeserializationContext ctx) throws IOException {
    final JsonNode logicalTypeNode=jsonParser.readValueAsTree();
    final SerdeContext serdeContext=SerdeContext.get(ctx);
    return deserialize(logicalTypeNode,serdeContext);
  }
  static RelDataType deserialize(  JsonNode logicalTypeNode,  SerdeContext serdeContext){
    final FlinkTypeFactory typeFactory=serdeContext.getTypeFactory();
    final LogicalType logicalType=LogicalTypeJsonDeserializer.deserialize(logicalTypeNode,serdeContext);
    return LogicalRelDataTypeConverter.toRelDataType(logicalType,typeFactory);
  }
}
