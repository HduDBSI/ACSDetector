/** 
 * {@link AbstractInvokable} which throws {@link CancelTaskException} on invoke.
 */
public static final class InvokableWithCancelTaskExceptionInInvoke extends AbstractInvokable {
  public InvokableWithCancelTaskExceptionInInvoke(  Environment environment){
    super(environment);
  }
  @Override public void invoke(){
    awaitLatch.trigger();
    try {
      triggerLatch.await();
    }
 catch (    Throwable ignored) {
    }
    throw new CancelTaskException();
  }
}
