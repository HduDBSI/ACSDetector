/** 
 * Factory to create  {@link CompletedCheckpointStore} and {@link CheckpointIDCounter}. 
 */
public class KubernetesCheckpointRecoveryFactory implements CheckpointRecoveryFactory {
  private final FlinkKubeClient kubeClient;
  private final Executor executor;
  private final Function<JobID,String> getConfigMapNameFunction;
  private final Configuration configuration;
  @Nullable private final String lockIdentity;
  private final String clusterId;
  /** 
 * Create a KubernetesCheckpointRecoveryFactory.
 * @param kubeClient Kubernetes client
 * @param configuration Flink configuration
 * @param executor IO executor to run blocking calls
 * @param function Function to get the ConfigMap name for checkpoint.
 * @param lockIdentity Lock identity of current HA service
 */
  private KubernetesCheckpointRecoveryFactory(  FlinkKubeClient kubeClient,  Configuration configuration,  Executor executor,  Function<JobID,String> function,  String clusterId,  @Nullable String lockIdentity){
    this.kubeClient=checkNotNull(kubeClient);
    this.configuration=checkNotNull(configuration);
    this.executor=checkNotNull(executor);
    this.getConfigMapNameFunction=checkNotNull(function);
    this.lockIdentity=lockIdentity;
    this.clusterId=clusterId;
  }
  @Override public CompletedCheckpointStore createRecoveredCompletedCheckpointStore(  JobID jobID,  int maxNumberOfCheckpointsToRetain,  SharedStateRegistryFactory sharedStateRegistryFactory,  Executor ioExecutor,  RestoreMode restoreMode) throws Exception {
    final String configMapName=getConfigMapNameFunction.apply(jobID);
    KubernetesUtils.createConfigMapIfItDoesNotExist(kubeClient,configMapName,clusterId);
    return KubernetesUtils.createCompletedCheckpointStore(configuration,kubeClient,executor,configMapName,lockIdentity,maxNumberOfCheckpointsToRetain,sharedStateRegistryFactory,ioExecutor,restoreMode);
  }
  @Override public CheckpointIDCounter createCheckpointIDCounter(  JobID jobID) throws Exception {
    final String configMapName=getConfigMapNameFunction.apply(jobID);
    KubernetesUtils.createConfigMapIfItDoesNotExist(kubeClient,configMapName,clusterId);
    return new KubernetesCheckpointIDCounter(kubeClient,configMapName,lockIdentity);
  }
  public static KubernetesCheckpointRecoveryFactory withLeadershipValidation(  FlinkKubeClient kubeClient,  Configuration configuration,  Executor executor,  String clusterId,  Function<JobID,String> function,  String lockIdentity){
    return new KubernetesCheckpointRecoveryFactory(kubeClient,configuration,executor,function,clusterId,lockIdentity);
  }
  public static KubernetesCheckpointRecoveryFactory withoutLeadershipValidation(  FlinkKubeClient kubeClient,  Configuration configuration,  Executor executor,  String clusterId,  Function<JobID,String> function){
    return new KubernetesCheckpointRecoveryFactory(kubeClient,configuration,executor,function,clusterId,null);
  }
}
