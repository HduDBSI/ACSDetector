/** 
 * The table function for SQL Client test. 
 */
public static class TableUDF extends TableFunction<Row> {
  public void eval(  String str,  Long extra){
    for (    String s : str.split(" ")) {
      Row r=new Row(2);
      r.setField(0,s);
      r.setField(1,s.length() + extra);
      collect(r);
    }
  }
  @Override public TypeInformation<Row> getResultType(){
    return Types.ROW(Types.STRING(),Types.LONG());
  }
}
