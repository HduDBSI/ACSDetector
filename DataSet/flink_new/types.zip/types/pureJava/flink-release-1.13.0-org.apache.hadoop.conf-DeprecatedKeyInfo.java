/** 
 * Class to keep the information about the keys which replace the deprecated ones. <p>This class stores the new keys which replace the deprecated keys and also gives a provision to have a custom message for each of the deprecated key that is being replaced. It also provides method to get the appropriate warning message which can be logged whenever the deprecated key is used.
 */
private static class DeprecatedKeyInfo {
  private final String[] newKeys;
  private final String customMessage;
  private final AtomicBoolean accessed=new AtomicBoolean(false);
  DeprecatedKeyInfo(  String[] newKeys,  String customMessage){
    this.newKeys=newKeys;
    this.customMessage=customMessage;
  }
  private final String getWarningMessage(  String key){
    return getWarningMessage(key,null);
  }
  /** 
 * Method to provide the warning message. It gives the custom message if non-null, and default message otherwise.
 * @param key the associated deprecated key.
 * @param source the property source.
 * @return message that is to be logged when a deprecated key is used.
 */
  private String getWarningMessage(  String key,  String source){
    String warningMessage;
    if (customMessage == null) {
      StringBuilder message=new StringBuilder(key);
      if (source != null) {
        message.append(" in " + source);
      }
      message.append(" is deprecated. Instead, use ");
      for (int i=0; i < newKeys.length; i++) {
        message.append(newKeys[i]);
        if (i != newKeys.length - 1) {
          message.append(", ");
        }
      }
      warningMessage=message.toString();
    }
 else {
      warningMessage=customMessage;
    }
    return warningMessage;
  }
  boolean getAndSetAccessed(){
    return accessed.getAndSet(true);
  }
  public void clearAccessed(){
    accessed.set(false);
  }
}
