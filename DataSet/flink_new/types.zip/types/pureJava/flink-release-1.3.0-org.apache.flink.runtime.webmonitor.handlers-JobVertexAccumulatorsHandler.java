public class JobVertexAccumulatorsHandler extends AbstractJobVertexRequestHandler {
  private static final String JOB_VERTEX_ACCUMULATORS_REST_PATH="/jobs/:jobid/vertices/:vertexid/accumulators";
  public JobVertexAccumulatorsHandler(  ExecutionGraphHolder executionGraphHolder){
    super(executionGraphHolder);
  }
  @Override public String[] getPaths(){
    return new String[]{JOB_VERTEX_ACCUMULATORS_REST_PATH};
  }
  @Override public String handleRequest(  AccessExecutionJobVertex jobVertex,  Map<String,String> params) throws Exception {
    return createVertexAccumulatorsJson(jobVertex);
  }
public static class JobVertexAccumulatorsJsonArchivist implements JsonArchivist {
    @Override public Collection<ArchivedJson> archiveJsonWithPath(    AccessExecutionGraph graph) throws IOException {
      List<ArchivedJson> archive=new ArrayList<>();
      for (      AccessExecutionJobVertex task : graph.getAllVertices().values()) {
        String json=createVertexAccumulatorsJson(task);
        String path=JOB_VERTEX_ACCUMULATORS_REST_PATH.replace(":jobid",graph.getJobID().toString()).replace(":vertexid",task.getJobVertexId().toString());
        archive.add(new ArchivedJson(path,json));
      }
      return archive;
    }
  }
  public static String createVertexAccumulatorsJson(  AccessExecutionJobVertex jobVertex) throws IOException {
    StringWriter writer=new StringWriter();
    JsonGenerator gen=JsonFactory.jacksonFactory.createGenerator(writer);
    StringifiedAccumulatorResult[] accs=jobVertex.getAggregatedUserAccumulatorsStringified();
    gen.writeStartObject();
    gen.writeStringField("id",jobVertex.getJobVertexId().toString());
    gen.writeArrayFieldStart("user-accumulators");
    for (    StringifiedAccumulatorResult acc : accs) {
      gen.writeStartObject();
      gen.writeStringField("name",acc.getName());
      gen.writeStringField("type",acc.getType());
      gen.writeStringField("value",acc.getValue());
      gen.writeEndObject();
    }
    gen.writeEndArray();
    gen.writeEndObject();
    gen.close();
    return writer.toString();
  }
}
