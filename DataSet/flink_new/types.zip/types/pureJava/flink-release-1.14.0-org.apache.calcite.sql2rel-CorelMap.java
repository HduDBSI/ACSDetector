/** 
 * A map of the locations of  {@link org.apache.calcite.rel.core.Correlate} in a tree of {@link RelNode}s. <p>It is used to drive the decorrelation process. Treat it as immutable; rebuild if you modify the tree. <p>There are three maps: <ol> <li> {@link #mapRefRelToCorRef} maps a {@link RelNode} to the correlated variables itreferences; <li> {@link #mapCorToCorRel} maps a correlated variable to the {@link Correlate} providingit; <li> {@link #mapFieldAccessToCorRef} maps a rex field access to the corVar it represents.Because typeFlattener does not clone or modify a correlated field access this map does not need to be updated. </ol>
 */
protected static class CorelMap {
  private final Multimap<RelNode,CorRef> mapRefRelToCorRef;
  private final SortedMap<CorrelationId,RelNode> mapCorToCorRel;
  private final Map<RexFieldAccess,CorRef> mapFieldAccessToCorRef;
  private CorelMap(  Multimap<RelNode,CorRef> mapRefRelToCorRef,  SortedMap<CorrelationId,RelNode> mapCorToCorRel,  Map<RexFieldAccess,CorRef> mapFieldAccessToCorRef){
    this.mapRefRelToCorRef=mapRefRelToCorRef;
    this.mapCorToCorRel=mapCorToCorRel;
    this.mapFieldAccessToCorRef=ImmutableMap.copyOf(mapFieldAccessToCorRef);
  }
  @Override public String toString(){
    return "mapRefRelToCorRef=" + mapRefRelToCorRef + "\nmapCorToCorRel="+ mapCorToCorRel+ "\nmapFieldAccessToCorRef="+ mapFieldAccessToCorRef+ "\n";
  }
  @Override public boolean equals(  Object obj){
    return obj == this || obj instanceof CorelMap && mapRefRelToCorRef.equals(((CorelMap)obj).mapRefRelToCorRef) && mapCorToCorRel.equals(((CorelMap)obj).mapCorToCorRel)&& mapFieldAccessToCorRef.equals(((CorelMap)obj).mapFieldAccessToCorRef);
  }
  @Override public int hashCode(){
    return Objects.hash(mapRefRelToCorRef,mapCorToCorRel,mapFieldAccessToCorRef);
  }
  /** 
 * Creates a CorelMap with given contents. 
 */
  public static CorelMap of(  SortedSetMultimap<RelNode,CorRef> mapRefRelToCorVar,  SortedMap<CorrelationId,RelNode> mapCorToCorRel,  Map<RexFieldAccess,CorRef> mapFieldAccessToCorVar){
    return new CorelMap(mapRefRelToCorVar,mapCorToCorRel,mapFieldAccessToCorVar);
  }
  public SortedMap<CorrelationId,RelNode> getMapCorToCorRel(){
    return mapCorToCorRel;
  }
  /** 
 * Returns whether there are any correlating variables in this statement.
 * @return whether there are any correlating variables
 */
  public boolean hasCorrelation(){
    return !mapCorToCorRel.isEmpty();
  }
}
