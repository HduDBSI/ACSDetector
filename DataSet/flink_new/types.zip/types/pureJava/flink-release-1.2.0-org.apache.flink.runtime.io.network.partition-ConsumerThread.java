private static class ConsumerThread extends CheckedThread {
  private final SingleInputGate gate;
  private final int numBuffers;
  ConsumerThread(  SingleInputGate gate,  int numBuffers){
    this.gate=gate;
    this.numBuffers=numBuffers;
  }
  @Override public void go() throws Exception {
    for (int i=numBuffers; i > 0; --i) {
      assertNotNull(gate.getNextBufferOrEvent());
    }
  }
}
