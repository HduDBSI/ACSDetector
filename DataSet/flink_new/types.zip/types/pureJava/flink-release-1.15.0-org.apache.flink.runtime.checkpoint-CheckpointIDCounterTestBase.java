/** 
 * Test base class with common tests for the  {@link CheckpointIDCounter} implementations. 
 */
@ExtendWith(TestLoggerExtension.class) abstract class CheckpointIDCounterTestBase {
  protected abstract CheckpointIDCounter createCheckpointIdCounter() throws Exception ;
  /** 
 * This test guards an assumption made in the notifications in the  {@link org.apache.flink.runtime.operators.coordination.OperatorCoordinator}. The coordinator is notified of a reset/restore and if no checkpoint yet exists (failure was before the first checkpoint), a negative ID is passed.
 */
  @Test public void testCounterIsNeverNegative() throws Exception {
    final CheckpointIDCounter counter=createCheckpointIdCounter();
    try {
      counter.start();
      assertThat(counter.get()).isGreaterThanOrEqualTo(0L);
    }
  finally {
      counter.shutdown(JobStatus.FINISHED).join();
    }
  }
  /** 
 * Tests serial increment and get calls. 
 */
  @Test public void testSerialIncrementAndGet() throws Exception {
    final CheckpointIDCounter counter=createCheckpointIdCounter();
    try {
      counter.start();
      assertThat(counter.getAndIncrement()).isEqualTo(1);
      assertThat(counter.get()).isEqualTo(2);
      assertThat(counter.getAndIncrement()).isEqualTo(2);
      assertThat(counter.get()).isEqualTo(3);
      assertThat(counter.getAndIncrement()).isEqualTo(3);
      assertThat(counter.get()).isEqualTo(4);
      assertThat(counter.getAndIncrement()).isEqualTo(4);
    }
  finally {
      counter.shutdown(JobStatus.FINISHED).join();
    }
  }
  /** 
 * Tests concurrent increment and get calls from multiple Threads and verifies that the numbers counts strictly increasing.
 */
  @Test public void testConcurrentGetAndIncrement() throws Exception {
    final int numThreads=8;
    final CountDownLatch startLatch=new CountDownLatch(1);
    final CheckpointIDCounter counter=createCheckpointIdCounter();
    counter.start();
    ExecutorService executor=null;
    try {
      executor=Executors.newFixedThreadPool(numThreads);
      List<Future<List<Long>>> resultFutures=new ArrayList<>(numThreads);
      for (int i=0; i < numThreads; i++) {
        resultFutures.add(executor.submit(new Incrementer(startLatch,counter)));
      }
      startLatch.countDown();
      final int expectedTotal=numThreads * Incrementer.NumIncrements;
      List<Long> all=new ArrayList<>(expectedTotal);
      for (      Future<List<Long>> result : resultFutures) {
        List<Long> counts=result.get();
        assertStrictlyMonotonous(counts);
        all.addAll(counts);
      }
      Collections.sort(all);
      assertThat(all.size()).isEqualTo(expectedTotal);
      assertStrictlyMonotonous(all);
      final long lastCheckpointId=all.get(all.size() - 1);
      assertThat(lastCheckpointId).isLessThan(counter.get());
      assertThat(lastCheckpointId).isLessThan(counter.getAndIncrement());
    }
  finally {
      if (executor != null) {
        executor.shutdown();
      }
      counter.shutdown(JobStatus.FINISHED).join();
    }
  }
  private static void assertStrictlyMonotonous(  List<Long> checkpointIds){
    long current=-1;
    for (    long checkpointId : checkpointIds) {
      assertThat(current).isLessThan(checkpointId);
      current=checkpointId;
    }
  }
  /** 
 * Tests a simple  {@link CheckpointIDCounter#setCount(long)} operation. 
 */
  @Test public void testSetCount() throws Exception {
    final CheckpointIDCounter counter=createCheckpointIdCounter();
    counter.start();
    counter.setCount(1337);
    assertThat(counter.get()).isEqualTo(1337);
    assertThat(counter.getAndIncrement()).isEqualTo(1337);
    assertThat(counter.get()).isEqualTo(1338);
    assertThat(counter.getAndIncrement()).isEqualTo(1338);
    counter.shutdown(JobStatus.FINISHED).join();
  }
  /** 
 * Task repeatedly incrementing the  {@link CheckpointIDCounter}. 
 */
private static class Incrementer implements Callable<List<Long>> {
    /** 
 * Total number of  {@link CheckpointIDCounter#getAndIncrement()} calls. 
 */
    private static final int NumIncrements=128;
    private final CountDownLatch startLatch;
    private final CheckpointIDCounter counter;
    public Incrementer(    CountDownLatch startLatch,    CheckpointIDCounter counter){
      this.startLatch=startLatch;
      this.counter=counter;
    }
    @Override public List<Long> call() throws Exception {
      final Random rand=new Random();
      final List<Long> counts=new ArrayList<>();
      this.startLatch.await();
      for (int i=0; i < NumIncrements; i++) {
        counts.add(counter.getAndIncrement());
        Thread.sleep(rand.nextInt(20));
      }
      return counts;
    }
  }
}
