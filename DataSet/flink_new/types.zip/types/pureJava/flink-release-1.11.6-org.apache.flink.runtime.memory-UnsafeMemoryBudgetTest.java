/** 
 * Test suite for  {@link UnsafeMemoryBudget}. 
 */
public class UnsafeMemoryBudgetTest extends TestLogger {
  static final int MAX_SLEEPS_VERIFY_EMPTY_FOR_TESTS=10;
  @Test public void testGetTotalMemory(){
    UnsafeMemoryBudget budget=createUnsafeMemoryBudget();
    assertThat(budget.getTotalMemorySize(),is(100L));
  }
  @Test public void testReserveMemory() throws MemoryReservationException {
    UnsafeMemoryBudget budget=createUnsafeMemoryBudget();
    budget.reserveMemory(50L);
    assertThat(budget.getAvailableMemorySize(),is(50L));
  }
  @Test(expected=MemoryReservationException.class) public void testReserveMemoryOverLimitFails() throws MemoryReservationException {
    UnsafeMemoryBudget budget=createUnsafeMemoryBudget();
    budget.reserveMemory(120L);
  }
  @Test public void testReleaseMemory() throws MemoryReservationException {
    UnsafeMemoryBudget budget=createUnsafeMemoryBudget();
    budget.reserveMemory(50L);
    budget.releaseMemory(30L);
    assertThat(budget.getAvailableMemorySize(),is(80L));
  }
  @Test(expected=IllegalStateException.class) public void testReleaseMemoryMoreThanReservedFails() throws MemoryReservationException {
    UnsafeMemoryBudget budget=createUnsafeMemoryBudget();
    budget.reserveMemory(50L);
    budget.releaseMemory(70L);
  }
  @Test(expected=MemoryReservationException.class) public void testReservationFailsIfOwnerNotGced() throws MemoryReservationException {
    UnsafeMemoryBudget budget=createUnsafeMemoryBudget();
    Object memoryOwner=new Object();
    budget.reserveMemory(50L);
    JavaGcCleanerWrapper.createCleaner(memoryOwner,() -> budget.releaseMemory(50L));
    budget.reserveMemory(60L);
    log.info(memoryOwner.toString());
  }
  @Test public void testReservationSuccessIfOwnerGced() throws MemoryReservationException {
    UnsafeMemoryBudget budget=createUnsafeMemoryBudget();
    budget.reserveMemory(50L);
    JavaGcCleanerWrapper.createCleaner(new Object(),() -> budget.releaseMemory(50L));
    budget.reserveMemory(60L);
    assertThat(budget.getAvailableMemorySize(),is(40L));
  }
  private static UnsafeMemoryBudget createUnsafeMemoryBudget(){
    return new UnsafeMemoryBudget(100L,MAX_SLEEPS_VERIFY_EMPTY_FOR_TESTS);
  }
}
