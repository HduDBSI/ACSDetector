/** 
 * Tests for  {@link JobVertexBackPressureHandler}. 
 */
public class JobVertexBackPressureHandlerTest {
  /** 
 * Job ID for which back pressure stats exist. 
 */
  private static final JobID TEST_JOB_ID_BACK_PRESSURE_STATS_AVAILABLE=new JobID();
  private static final JobVertexID TEST_JOB_VERTEX_ID=new JobVertexID();
  /** 
 * Job ID for which back pressure stats are not available. 
 */
  private static final JobID TEST_JOB_ID_BACK_PRESSURE_STATS_ABSENT=new JobID();
  private TestingRestfulGateway restfulGateway;
  private JobVertexBackPressureHandler jobVertexBackPressureHandler;
  private MetricStore metricStore;
  private static Collection<MetricDump> getMetricDumps(){
    Collection<MetricDump> dumps=new ArrayList<>();
    TaskQueryScopeInfo task0=new TaskQueryScopeInfo(TEST_JOB_ID_BACK_PRESSURE_STATS_AVAILABLE.toString(),TEST_JOB_VERTEX_ID.toString(),0);
    dumps.add(new GaugeDump(task0,MetricNames.TASK_BACK_PRESSURED_TIME,"1000"));
    dumps.add(new GaugeDump(task0,MetricNames.TASK_IDLE_TIME,"0"));
    dumps.add(new GaugeDump(task0,MetricNames.TASK_BUSY_TIME,"0"));
    TaskQueryScopeInfo task1=new TaskQueryScopeInfo(TEST_JOB_ID_BACK_PRESSURE_STATS_AVAILABLE.toString(),TEST_JOB_VERTEX_ID.toString(),1);
    dumps.add(new GaugeDump(task1,MetricNames.TASK_BACK_PRESSURED_TIME,"500"));
    dumps.add(new GaugeDump(task1,MetricNames.TASK_IDLE_TIME,"100"));
    dumps.add(new GaugeDump(task1,MetricNames.TASK_BUSY_TIME,"900"));
    TaskQueryScopeInfo task3=new TaskQueryScopeInfo(TEST_JOB_ID_BACK_PRESSURE_STATS_AVAILABLE.toString(),TEST_JOB_VERTEX_ID.toString(),3);
    dumps.add(new GaugeDump(task3,MetricNames.TASK_BACK_PRESSURED_TIME,"100"));
    dumps.add(new GaugeDump(task3,MetricNames.TASK_IDLE_TIME,"200"));
    dumps.add(new GaugeDump(task3,MetricNames.TASK_BUSY_TIME,"700"));
    return dumps;
  }
  @Before public void setUp(){
    metricStore=new MetricStore();
    for (    MetricDump metricDump : getMetricDumps()) {
      metricStore.add(metricDump);
    }
    jobVertexBackPressureHandler=new JobVertexBackPressureHandler(() -> CompletableFuture.completedFuture(restfulGateway),Time.seconds(10),Collections.emptyMap(),JobVertexBackPressureHeaders.getInstance(),new MetricFetcher(){
      private long updateCount=0;
      @Override public MetricStore getMetricStore(){
        return metricStore;
      }
      @Override public void update(){
        updateCount++;
      }
      @Override public long getLastUpdateTime(){
        return updateCount;
      }
    }
);
  }
  @Test public void testGetBackPressure() throws Exception {
    final Map<String,String> pathParameters=new HashMap<>();
    pathParameters.put(JobIDPathParameter.KEY,TEST_JOB_ID_BACK_PRESSURE_STATS_AVAILABLE.toString());
    pathParameters.put(JobVertexIdPathParameter.KEY,TEST_JOB_VERTEX_ID.toString());
    final HandlerRequest<EmptyRequestBody,JobVertexMessageParameters> request=new HandlerRequest<>(EmptyRequestBody.getInstance(),new JobVertexMessageParameters(),pathParameters,Collections.emptyMap());
    final CompletableFuture<JobVertexBackPressureInfo> jobVertexBackPressureInfoCompletableFuture=jobVertexBackPressureHandler.handleRequest(request,restfulGateway);
    final JobVertexBackPressureInfo jobVertexBackPressureInfo=jobVertexBackPressureInfoCompletableFuture.get();
    assertThat(jobVertexBackPressureInfo.getStatus(),equalTo(VertexBackPressureStatus.OK));
    assertThat(jobVertexBackPressureInfo.getBackpressureLevel(),equalTo(HIGH));
    assertThat(jobVertexBackPressureInfo.getSubtasks().stream().map(SubtaskBackPressureInfo::getBackPressuredRatio).collect(Collectors.toList()),contains(1.0,0.5,0.1));
    assertThat(jobVertexBackPressureInfo.getSubtasks().stream().map(SubtaskBackPressureInfo::getIdleRatio).collect(Collectors.toList()),contains(0.0,0.1,0.2));
    assertThat(jobVertexBackPressureInfo.getSubtasks().stream().map(SubtaskBackPressureInfo::getBusyRatio).collect(Collectors.toList()),contains(0.0,0.9,0.7));
    assertThat(jobVertexBackPressureInfo.getSubtasks().stream().map(SubtaskBackPressureInfo::getBackpressureLevel).collect(Collectors.toList()),contains(HIGH,LOW,OK));
    assertThat(jobVertexBackPressureInfo.getSubtasks().stream().map(SubtaskBackPressureInfo::getSubtask).collect(Collectors.toList()),contains(0,1,3));
  }
  @Test public void testAbsentBackPressure() throws Exception {
    final Map<String,String> pathParameters=new HashMap<>();
    pathParameters.put(JobIDPathParameter.KEY,TEST_JOB_ID_BACK_PRESSURE_STATS_ABSENT.toString());
    pathParameters.put(JobVertexIdPathParameter.KEY,new JobVertexID().toString());
    final HandlerRequest<EmptyRequestBody,JobVertexMessageParameters> request=new HandlerRequest<>(EmptyRequestBody.getInstance(),new JobVertexMessageParameters(),pathParameters,Collections.emptyMap());
    final CompletableFuture<JobVertexBackPressureInfo> jobVertexBackPressureInfoCompletableFuture=jobVertexBackPressureHandler.handleRequest(request,restfulGateway);
    final JobVertexBackPressureInfo jobVertexBackPressureInfo=jobVertexBackPressureInfoCompletableFuture.get();
    assertThat(jobVertexBackPressureInfo.getStatus(),equalTo(VertexBackPressureStatus.DEPRECATED));
  }
}
