/** 
 * Empty interface to encapsulate partitioners.
 * @param < T > Type of the Tuple
 */
public interface StreamPartitioner<T> extends ChannelSelector<SerializationDelegate<StreamRecord<T>>>, Serializable {
}
