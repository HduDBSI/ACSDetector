/** 
 * Get serializers according to the given typeInformation. 
 */
public static class TypeInfoToSerializerConverter {
  private static final Map<Class,TypeSerializer> typeInfoToSerialzerMap=new HashMap<>();
static {
    typeInfoToSerialzerMap.put(BasicTypeInfo.BOOLEAN_TYPE_INFO.getTypeClass(),BooleanSerializer.INSTANCE);
    typeInfoToSerialzerMap.put(BasicTypeInfo.INT_TYPE_INFO.getTypeClass(),IntSerializer.INSTANCE);
    typeInfoToSerialzerMap.put(BasicTypeInfo.STRING_TYPE_INFO.getTypeClass(),StringSerializer.INSTANCE);
    typeInfoToSerialzerMap.put(BasicTypeInfo.SHORT_TYPE_INFO.getTypeClass(),ShortSerializer.INSTANCE);
    typeInfoToSerialzerMap.put(BasicTypeInfo.LONG_TYPE_INFO.getTypeClass(),LongSerializer.INSTANCE);
    typeInfoToSerialzerMap.put(BasicTypeInfo.FLOAT_TYPE_INFO.getTypeClass(),FloatSerializer.INSTANCE);
    typeInfoToSerialzerMap.put(BasicTypeInfo.DOUBLE_TYPE_INFO.getTypeClass(),DoubleSerializer.INSTANCE);
    typeInfoToSerialzerMap.put(BasicTypeInfo.CHAR_TYPE_INFO.getTypeClass(),CharSerializer.INSTANCE);
    typeInfoToSerialzerMap.put(BasicTypeInfo.BIG_INT_TYPE_INFO.getTypeClass(),BigIntSerializer.INSTANCE);
    typeInfoToSerialzerMap.put(BasicTypeInfo.BIG_DEC_TYPE_INFO.getTypeClass(),BigDecSerializer.INSTANCE);
    typeInfoToSerialzerMap.put(BasicTypeInfo.BYTE_TYPE_INFO.getTypeClass(),ByteSerializer.INSTANCE);
    typeInfoToSerialzerMap.put(PrimitiveArrayTypeInfo.BOOLEAN_PRIMITIVE_ARRAY_TYPE_INFO.getTypeClass(),BooleanPrimitiveArraySerializer.INSTANCE);
    typeInfoToSerialzerMap.put(PrimitiveArrayTypeInfo.BYTE_PRIMITIVE_ARRAY_TYPE_INFO.getTypeClass(),BytePrimitiveArraySerializer.INSTANCE);
    typeInfoToSerialzerMap.put(PrimitiveArrayTypeInfo.CHAR_PRIMITIVE_ARRAY_TYPE_INFO.getTypeClass(),CharPrimitiveArraySerializer.INSTANCE);
    typeInfoToSerialzerMap.put(PrimitiveArrayTypeInfo.DOUBLE_PRIMITIVE_ARRAY_TYPE_INFO.getTypeClass(),DoublePrimitiveArraySerializer.INSTANCE);
    typeInfoToSerialzerMap.put(PrimitiveArrayTypeInfo.FLOAT_PRIMITIVE_ARRAY_TYPE_INFO.getTypeClass(),FloatPrimitiveArraySerializer.INSTANCE);
    typeInfoToSerialzerMap.put(PrimitiveArrayTypeInfo.LONG_PRIMITIVE_ARRAY_TYPE_INFO.getTypeClass(),LongPrimitiveArraySerializer.INSTANCE);
    typeInfoToSerialzerMap.put(PrimitiveArrayTypeInfo.SHORT_PRIMITIVE_ARRAY_TYPE_INFO.getTypeClass(),ShortPrimitiveArraySerializer.INSTANCE);
    typeInfoToSerialzerMap.put(PrimitiveArrayTypeInfo.INT_PRIMITIVE_ARRAY_TYPE_INFO.getTypeClass(),IntPrimitiveArraySerializer.INSTANCE);
    typeInfoToSerialzerMap.put(SqlTimeTypeInfo.DATE.getTypeClass(),DateSerializer.INSTANCE);
    typeInfoToSerialzerMap.put(SqlTimeTypeInfo.TIME.getTypeClass(),TimeSerializer.INSTANCE);
    typeInfoToSerialzerMap.put(SqlTimeTypeInfo.TIMESTAMP.getTypeClass(),new TimestampSerializer(3));
  }
  @SuppressWarnings("unchecked") public static TypeSerializer typeInfoSerializerConverter(  TypeInformation typeInformation){
    TypeSerializer typeSerializer=typeInfoToSerialzerMap.get(typeInformation.getTypeClass());
    if (typeSerializer != null) {
      return typeSerializer;
    }
 else {
      if (typeInformation instanceof PickledByteArrayTypeInfo) {
        return BytePrimitiveArraySerializer.INSTANCE;
      }
      if (typeInformation instanceof RowTypeInfo) {
        RowTypeInfo rowTypeInfo=(RowTypeInfo)typeInformation;
        TypeSerializer[] fieldTypeSerializers=Arrays.stream(rowTypeInfo.getFieldTypes()).map(f -> typeInfoSerializerConverter(f)).toArray(TypeSerializer[]::new);
        return new RowSerializer(fieldTypeSerializers);
      }
      if (typeInformation instanceof TupleTypeInfo) {
        TupleTypeInfo tupleTypeInfo=(TupleTypeInfo)typeInformation;
        TypeInformation[] typeInformations=new TypeInformation[tupleTypeInfo.getArity()];
        for (int idx=0; idx < tupleTypeInfo.getArity(); idx++) {
          typeInformations[idx]=tupleTypeInfo.getTypeAt(idx);
        }
        TypeSerializer[] fieldTypeSerialzers=Arrays.stream(typeInformations).map(f -> typeInfoSerializerConverter(f)).toArray(TypeSerializer[]::new);
        return new TupleSerializer(Tuple.getTupleClass(tupleTypeInfo.getArity()),fieldTypeSerialzers);
      }
      if (typeInformation instanceof BasicArrayTypeInfo) {
        BasicArrayTypeInfo basicArrayTypeInfo=(BasicArrayTypeInfo)typeInformation;
        Class<?> elementClass=basicArrayTypeInfo.getComponentTypeClass();
        TypeSerializer<?> elementTypeSerializer=typeInfoToSerialzerMap.get(elementClass);
        return new GenericArraySerializer(elementClass,elementTypeSerializer);
      }
    }
    throw new UnsupportedOperationException(String.format("Could not find type serializer for current type [%s].",typeInformation.toString()));
  }
}
