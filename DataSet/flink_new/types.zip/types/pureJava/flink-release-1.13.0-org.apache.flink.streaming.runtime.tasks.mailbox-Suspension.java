/** 
 * Represents the suspended state of a  {@link MailboxDefaultAction}, ready to resume. 
 */
@Internal interface Suspension {
  /** 
 * Resume execution of the default action. 
 */
  void resume();
}
