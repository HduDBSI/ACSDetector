/** 
 * The common pulsar source reader for both ordered & unordered message consuming.
 * @param < OUT > The output message type for flink.
 */
abstract class PulsarSourceReaderBase<OUT> extends SourceReaderBase<PulsarMessage<OUT>,OUT,PulsarPartitionSplit,PulsarPartitionSplitState> {
  protected final SourceConfiguration sourceConfiguration;
  protected final PulsarClient pulsarClient;
  protected final PulsarAdmin pulsarAdmin;
  protected PulsarSourceReaderBase(  FutureCompletingBlockingQueue<RecordsWithSplitIds<PulsarMessage<OUT>>> elementsQueue,  PulsarFetcherManagerBase<OUT> splitFetcherManager,  SourceReaderContext context,  SourceConfiguration sourceConfiguration,  PulsarClient pulsarClient,  PulsarAdmin pulsarAdmin){
    super(elementsQueue,splitFetcherManager,new PulsarRecordEmitter<>(),sourceConfiguration,context);
    this.sourceConfiguration=sourceConfiguration;
    this.pulsarClient=pulsarClient;
    this.pulsarAdmin=pulsarAdmin;
  }
  @Override protected PulsarPartitionSplitState initializedState(  PulsarPartitionSplit split){
    return new PulsarPartitionSplitState(split);
  }
  @Override protected PulsarPartitionSplit toSplitType(  String splitId,  PulsarPartitionSplitState splitState){
    return splitState.toPulsarPartitionSplit();
  }
  @Override public void close() throws Exception {
    super.close();
    pulsarClient.shutdown();
    pulsarAdmin.close();
  }
}
