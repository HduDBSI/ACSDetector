/** 
 * A  {@link CheckpointRecoveryFactory} that pre-defined checkpointing components. 
 */
public class TestingCheckpointRecoveryFactory implements CheckpointRecoveryFactory {
  private final CompletedCheckpointStore store;
  private final CheckpointIDCounter counter;
  public TestingCheckpointRecoveryFactory(  CompletedCheckpointStore store,  CheckpointIDCounter counter){
    this.store=store;
    this.counter=counter;
  }
  @Override public CompletedCheckpointStore createRecoveredCompletedCheckpointStore(  JobID jobId,  int maxNumberOfCheckpointsToRetain,  SharedStateRegistryFactory sharedStateRegistryFactory,  Executor ioExecutor,  RestoreMode restoreMode){
    return store;
  }
  @Override public CheckpointIDCounter createCheckpointIDCounter(  JobID jobId){
    return counter;
  }
}
