public static class MyMapper5<A> implements MapFunction<PojoWithParameterizedFields2<A>,A> {
  private static final long serialVersionUID=1L;
  @Override public A map(  PojoWithParameterizedFields2<A> value) throws Exception {
    return null;
  }
}
