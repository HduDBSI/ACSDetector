/** 
 * A  {@link SchemaCoder.SchemaCoderProvider} that uses a cached schema registry client underneath.
 */
@Internal class CachedSchemaCoderProvider implements SchemaCoder.SchemaCoderProvider {
  private static final long serialVersionUID=8610401613495438381L;
  private final String subject;
  private final String url;
  private final int identityMapCapacity;
  private final @Nullable Map<String,?> registryConfigs;
  CachedSchemaCoderProvider(  String url,  int identityMapCapacity){
    this(null,url,identityMapCapacity,null);
  }
  CachedSchemaCoderProvider(  @Nullable String subject,  String url,  int identityMapCapacity,  @Nullable Map<String,?> registryConfigs){
    this.subject=subject;
    this.url=Objects.requireNonNull(url);
    this.identityMapCapacity=identityMapCapacity;
    this.registryConfigs=registryConfigs;
  }
  @Override public SchemaCoder get(){
    return new ConfluentSchemaRegistryCoder(this.subject,new CachedSchemaRegistryClient(url,identityMapCapacity,registryConfigs));
  }
  @Override public boolean equals(  Object o){
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CachedSchemaCoderProvider that=(CachedSchemaCoderProvider)o;
    return identityMapCapacity == that.identityMapCapacity && Objects.equals(subject,that.subject) && url.equals(that.url) && Objects.equals(registryConfigs,that.registryConfigs);
  }
  @Override public int hashCode(){
    return Objects.hash(subject,url,identityMapCapacity,registryConfigs);
  }
}
