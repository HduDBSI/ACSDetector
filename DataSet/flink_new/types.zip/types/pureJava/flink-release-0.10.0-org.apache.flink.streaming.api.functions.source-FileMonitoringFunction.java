public class FileMonitoringFunction implements SourceFunction<Tuple3<String,Long,Long>> {
  private static final long serialVersionUID=1L;
  private static final Logger LOG=LoggerFactory.getLogger(FileMonitoringFunction.class);
  public enum WatchType {  ONLY_NEW_FILES,   REPROCESS_WITH_APPENDED,   PROCESS_ONLY_APPENDED}
  private String path;
  private long interval;
  private WatchType watchType;
  private Map<String,Long> offsetOfFiles;
  private Map<String,Long> modificationTimes;
  private volatile boolean isRunning=true;
  public FileMonitoringFunction(  String path,  long interval,  WatchType watchType){
    this.path=path;
    this.interval=interval;
    this.watchType=watchType;
    this.modificationTimes=new HashMap<String,Long>();
    this.offsetOfFiles=new HashMap<String,Long>();
  }
  @Override public void run(  SourceContext<Tuple3<String,Long,Long>> ctx) throws Exception {
    FileSystem fileSystem=FileSystem.get(new URI(path));
    while (isRunning) {
      List<String> files=listNewFiles(fileSystem);
      for (      String filePath : files) {
        if (watchType == WatchType.ONLY_NEW_FILES || watchType == WatchType.REPROCESS_WITH_APPENDED) {
          ctx.collect(new Tuple3<String,Long,Long>(filePath,0L,-1L));
          offsetOfFiles.put(filePath,-1L);
        }
 else         if (watchType == WatchType.PROCESS_ONLY_APPENDED) {
          long offset=0;
          long fileSize=fileSystem.getFileStatus(new Path(filePath)).getLen();
          if (offsetOfFiles.containsKey(filePath)) {
            offset=offsetOfFiles.get(filePath);
          }
          ctx.collect(new Tuple3<String,Long,Long>(filePath,offset,fileSize));
          offsetOfFiles.put(filePath,fileSize);
          LOG.info("File processed: {}, {}, {}",filePath,offset,fileSize);
        }
      }
      Thread.sleep(interval);
    }
  }
  private List<String> listNewFiles(  FileSystem fileSystem) throws IOException {
    List<String> files=new ArrayList<String>();
    FileStatus[] statuses=fileSystem.listStatus(new Path(path));
    if (statuses == null) {
      LOG.warn("Path does not exist: {}",path);
    }
 else {
      for (      FileStatus status : statuses) {
        Path filePath=status.getPath();
        String fileName=filePath.getName();
        long modificationTime=status.getModificationTime();
        if (!isFiltered(fileName,modificationTime)) {
          files.add(filePath.toString());
          modificationTimes.put(fileName,modificationTime);
        }
      }
    }
    return files;
  }
  private boolean isFiltered(  String fileName,  long modificationTime){
    if ((watchType == WatchType.ONLY_NEW_FILES && modificationTimes.containsKey(fileName)) || fileName.startsWith(".") || fileName.contains("_COPYING_")) {
      return true;
    }
 else {
      Long lastModification=modificationTimes.get(fileName);
      return lastModification != null && lastModification >= modificationTime;
    }
  }
  @Override public void cancel(){
    isRunning=false;
  }
}
