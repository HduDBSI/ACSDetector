/** 
 * Base class for checkpoint related exceptions.
 */
public class CheckpointException extends Exception {
  private static final long serialVersionUID=3257526119022486948L;
  private final CheckpointFailureReason checkpointFailureReason;
  public CheckpointException(  CheckpointFailureReason failureReason){
    super(failureReason.message());
    this.checkpointFailureReason=Preconditions.checkNotNull(failureReason);
  }
  public CheckpointException(  String message,  CheckpointFailureReason failureReason){
    super(message + " Failure reason: " + failureReason.message());
    this.checkpointFailureReason=Preconditions.checkNotNull(failureReason);
  }
  public CheckpointException(  CheckpointFailureReason failureReason,  Throwable cause){
    super(failureReason.message(),cause);
    this.checkpointFailureReason=Preconditions.checkNotNull(failureReason);
  }
  public CheckpointException(  String message,  CheckpointFailureReason failureReason,  Throwable cause){
    super(message + " Failure reason: " + failureReason.message(),cause);
    this.checkpointFailureReason=Preconditions.checkNotNull(failureReason);
  }
  public CheckpointFailureReason getCheckpointFailureReason(){
    return checkpointFailureReason;
  }
}
