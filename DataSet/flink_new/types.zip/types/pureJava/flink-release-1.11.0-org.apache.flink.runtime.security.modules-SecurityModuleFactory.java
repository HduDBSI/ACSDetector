/** 
 * A factory for a  {@link SecurityModule}. A factory can determine whether a  {@link SecurityModule}works in the given environment (for example, it can check whether Hadoop dependencies are available) and can then create (or not) a module based on that.
 */
@FunctionalInterface public interface SecurityModuleFactory {
  /** 
 * Creates and returns a  {@link SecurityModule}. This can return  {@code null} if the typeof  {@link SecurityModule} that this factory can create does not work in the currentenvironment.
 */
  SecurityModule createModule(  SecurityConfiguration securityConfig);
}
