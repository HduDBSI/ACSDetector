/** 
 * An action to be performed by  {@link RetryingExecutor}, potentially with multiple attempts, potentially concurrently. <p>NOTE: the action must be idempotent because of potential concurrent attempts.
 */
interface RetriableAction extends RunnableWithException {
}
