/** 
 * Sub-class of  {@link org.apache.calcite.rel.core.Snapshot} not targeted at any particular engineor calling convention. The class was copied over because of * CALCITE-4554.  <p>Line 80 ~ 91: Calcite only supports timestamp type as period type, but Flink supports both Timestamp and TimestampLtz. Should be removed once calcite support TimestampLtz as period type.
 */
public class LogicalSnapshot extends Snapshot {
  /** 
 * Creates a LogicalSnapshot. <p>Use  {@link #create} unless you know what you're doing.
 * @param cluster Cluster that this relational expression belongs to
 * @param traitSet The traits of this relational expression
 * @param input Input relational expression
 * @param period Timestamp expression which as the table was at the given time in the past
 */
  public LogicalSnapshot(  RelOptCluster cluster,  RelTraitSet traitSet,  RelNode input,  RexNode period){
    super(cluster,traitSet,input,period);
  }
  @Override public Snapshot copy(  RelTraitSet traitSet,  RelNode input,  RexNode period){
    return new LogicalSnapshot(getCluster(),traitSet,input,period);
  }
  /** 
 * Creates a LogicalSnapshot. 
 */
  public static LogicalSnapshot create(  RelNode input,  RexNode period){
    final RelOptCluster cluster=input.getCluster();
    final RelMetadataQuery mq=cluster.getMetadataQuery();
    final RelTraitSet traitSet=cluster.traitSet().replace(Convention.NONE).replaceIfs(RelCollationTraitDef.INSTANCE,() -> RelMdCollation.snapshot(mq,input)).replaceIf(RelDistributionTraitDef.INSTANCE,() -> RelMdDistribution.snapshot(mq,input));
    return new LogicalSnapshot(cluster,traitSet,input,period);
  }
  @Override public boolean isValid(  Litmus litmus,  Context context){
    SqlTypeName periodTypeName=getPeriod().getType().getSqlTypeName();
    if (!(periodTypeName == SqlTypeName.TIMESTAMP || periodTypeName == SqlTypeName.TIMESTAMP_WITH_LOCAL_TIME_ZONE)) {
      return litmus.fail("The system time period specification expects TIMESTAMP or TIMESTAMP" + " WITH LOCAL TIME ZONE type but is '" + periodTypeName + "'");
    }
    return litmus.succeed();
  }
}
