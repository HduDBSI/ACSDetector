/** 
 * A source that locks if cancellation attempts to cleanly shut down.
 */
public static class InterruptedSource implements SourceFunction<String> {
  private static final long serialVersionUID=8713065281092996042L;
  private static CompletableFuture<Void> isRunning=new CompletableFuture<>();
  public static void reset(){
    isRunning=new CompletableFuture<>();
  }
  public static void awaitRunning() throws ExecutionException, InterruptedException {
    isRunning.get();
  }
  @Override public void run(  SourceContext<String> ctx) throws Exception {
synchronized (ctx.getCheckpointLock()) {
      isRunning.complete(null);
      Thread.currentThread().interrupt();
      throw new InterruptedException();
    }
  }
  @Override public void cancel(){
  }
}
