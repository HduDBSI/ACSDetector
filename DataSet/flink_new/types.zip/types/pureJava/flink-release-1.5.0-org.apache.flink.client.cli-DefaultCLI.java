/** 
 * The default CLI which is used for interaction with standalone clusters.
 */
public class DefaultCLI extends AbstractCustomCommandLine<StandaloneClusterId> {
  public DefaultCLI(  Configuration configuration){
    super(configuration);
  }
  @Override public boolean isActive(  CommandLine commandLine){
    return true;
  }
  @Override public String getId(){
    return "default";
  }
  @Override public void addGeneralOptions(  Options baseOptions){
    super.addGeneralOptions(baseOptions);
  }
  @Override public StandaloneClusterDescriptor createClusterDescriptor(  CommandLine commandLine) throws FlinkException {
    final Configuration effectiveConfiguration=applyCommandLineOptionsToConfiguration(commandLine);
    return new StandaloneClusterDescriptor(effectiveConfiguration);
  }
  @Override @Nullable public StandaloneClusterId getClusterId(  CommandLine commandLine){
    return StandaloneClusterId.getInstance();
  }
  @Override public ClusterSpecification getClusterSpecification(  CommandLine commandLine){
    return new ClusterSpecification.ClusterSpecificationBuilder().createClusterSpecification();
  }
}
