protected static class MockInputGate implements InputGate {
  private int numChannels;
  private BufferPool[] bufferPools;
  private int[] currentSupersteps;
  BarrierGenerator[] barrierGens;
  int currentChannel=0;
  long c=0;
  public MockInputGate(  BufferPool[] bufferPools,  BarrierGenerator[] barrierGens){
    this.numChannels=bufferPools.length;
    this.currentSupersteps=new int[numChannels];
    this.bufferPools=bufferPools;
    this.barrierGens=barrierGens;
  }
  @Override public int getNumberOfInputChannels(){
    return numChannels;
  }
  @Override public boolean isFinished(){
    return false;
  }
  @Override public void requestPartitions() throws IOException, InterruptedException {
  }
  @Override public BufferOrEvent getNextBufferOrEvent() throws IOException, InterruptedException {
    currentChannel=(currentChannel + 1) % numChannels;
    if (barrierGens[currentChannel].isNextBarrier()) {
      return BarrierBufferTest.createSuperstep(++currentSupersteps[currentChannel],currentChannel);
    }
 else {
      Buffer buffer=bufferPools[currentChannel].requestBuffer();
      buffer.getMemorySegment().putLong(0,c++);
      return new BufferOrEvent(buffer,currentChannel);
    }
  }
  @Override public void sendTaskEvent(  TaskEvent event) throws IOException {
  }
  @Override public void registerListener(  EventListener<InputGate> listener){
  }
}
