/** 
 * A <code>LogicalTableScan</code> reads all the rows from a  {@link RelOptTable}. <p>This class is copied from Calcite because the  {@link #explainTerms} should consider hints.<p>If the table is a <code>net.sf.saffron.ext.JdbcTable</code>, then this is literally possible. But for other kinds of tables, there may be many ways to read the data from the table. For some kinds of table, it may not even be possible to read all of the rows unless some narrowing constraint is applied. <p>In the example of the <code>net.sf.saffron.ext.ReflectSchema</code> schema, <blockquote> <pre>select from fields</pre> </blockquote> <p>cannot be implemented, but <blockquote> <pre>select from fields as f where f.getClass().getName().equals("java.lang.String")</pre> </blockquote> <p>can. It is the optimizer's responsibility to find these ways, by applying transformation rules.
 */
public final class LogicalTableScan extends TableScan {
  /** 
 * Creates a LogicalTableScan. <p>Use  {@link #create} unless you know what you're doing.
 */
  public LogicalTableScan(  RelOptCluster cluster,  RelTraitSet traitSet,  List<RelHint> hints,  RelOptTable table){
    super(cluster,traitSet,hints,table);
  }
  @Deprecated public LogicalTableScan(  RelOptCluster cluster,  RelTraitSet traitSet,  RelOptTable table){
    this(cluster,traitSet,ImmutableList.of(),table);
  }
  @Deprecated public LogicalTableScan(  RelOptCluster cluster,  RelOptTable table){
    this(cluster,cluster.traitSetOf(Convention.NONE),ImmutableList.of(),table);
  }
  /** 
 * Creates a LogicalTableScan by parsing serialized output. 
 */
  public LogicalTableScan(  RelInput input){
    super(input);
  }
  @Override public RelNode copy(  RelTraitSet traitSet,  List<RelNode> inputs){
    assert traitSet.containsIfApplicable(Convention.NONE);
    assert inputs.isEmpty();
    return this;
  }
  @Override public RelWriter explainTerms(  RelWriter pw){
    return super.explainTerms(pw).itemIf("hints",getHints(),!getHints().isEmpty());
  }
  /** 
 * Creates a LogicalTableScan.
 * @param cluster Cluster
 * @param relOptTable Table
 * @param hints The hints
 */
  public static LogicalTableScan create(  RelOptCluster cluster,  final RelOptTable relOptTable,  List<RelHint> hints){
    final Table table=relOptTable.unwrap(Table.class);
    final RelTraitSet traitSet=cluster.traitSetOf(Convention.NONE).replaceIfs(RelCollationTraitDef.INSTANCE,() -> {
      if (table != null) {
        return table.getStatistic().getCollations();
      }
      return ImmutableList.of();
    }
);
    return new LogicalTableScan(cluster,traitSet,hints,relOptTable);
  }
  @Override public RelNode withHints(  List<RelHint> hintList){
    return new LogicalTableScan(getCluster(),traitSet,hintList,table);
  }
}
