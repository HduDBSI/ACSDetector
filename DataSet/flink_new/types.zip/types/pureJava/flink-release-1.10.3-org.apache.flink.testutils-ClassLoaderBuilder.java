public static class ClassLoaderBuilder {
  private final File root;
  private final Map<String,String> classes;
  private ClassLoaderBuilder(  File root){
    this.root=root;
    this.classes=new HashMap<>();
  }
  public ClassLoaderBuilder addClass(  String className,  String source){
    String oldValue=classes.putIfAbsent(className,source);
    if (oldValue != null) {
      throw new RuntimeException(String.format("Class with name %s already registered.",className));
    }
    return this;
  }
  public URLClassLoader build() throws IOException {
    for (    Map.Entry<String,String> classInfo : classes.entrySet()) {
      writeAndCompile(root,createFileName(classInfo.getKey()),classInfo.getValue());
    }
    return createClassLoader(root);
  }
  private String createFileName(  String className){
    return className + ".java";
  }
}
