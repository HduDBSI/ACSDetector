/** 
 * Retrieves and stores the current leader address.
 */
public class LeaderRetriever implements LeaderRetrievalListener {
  protected final Logger log=LoggerFactory.getLogger(getClass());
  private AtomicReference<CompletableFuture<Tuple2<String,UUID>>> atomicLeaderFuture;
  public LeaderRetriever(){
    atomicLeaderFuture=new AtomicReference<>(new CompletableFuture<>());
  }
  /** 
 * Returns the current leader information if available. Otherwise it returns an empty optional.
 * @return The current leader information if available. Otherwise it returns anempty optional.
 * @throws Exception if the leader future has been completed with an exception
 */
  public Optional<Tuple2<String,UUID>> getLeaderNow() throws Exception {
    CompletableFuture<Tuple2<String,UUID>> leaderFuture=this.atomicLeaderFuture.get();
    if (leaderFuture != null) {
      if (leaderFuture.isDone()) {
        return Optional.of(leaderFuture.get());
      }
 else {
        return Optional.empty();
      }
    }
 else {
      return Optional.empty();
    }
  }
  /** 
 * Returns the current JobManagerGateway future.
 */
  public CompletableFuture<Tuple2<String,UUID>> getLeaderFuture(){
    return atomicLeaderFuture.get();
  }
  @Override public void notifyLeaderAddress(  final String leaderAddress,  final UUID leaderSessionID){
    if (leaderAddress != null && !leaderAddress.equals("")) {
      try {
        final CompletableFuture<Tuple2<String,UUID>> newLeaderFuture=CompletableFuture.completedFuture(Tuple2.of(leaderAddress,leaderSessionID));
        final CompletableFuture<Tuple2<String,UUID>> oldLeaderFuture=atomicLeaderFuture.getAndSet(newLeaderFuture);
        if (!oldLeaderFuture.isDone()) {
          oldLeaderFuture.complete(Tuple2.of(leaderAddress,leaderSessionID));
        }
        notifyNewLeaderAddress(newLeaderFuture);
      }
 catch (      Exception e) {
        handleError(e);
      }
    }
  }
  @Override public void handleError(  Exception exception){
    log.error("Received error from LeaderRetrievalService.",exception);
    atomicLeaderFuture.get().completeExceptionally(exception);
  }
  protected void notifyNewLeaderAddress(  CompletableFuture<Tuple2<String,UUID>> newLeaderAddressFuture){
  }
}
