/** 
 * Descriptor for describing a function.
 */
@PublicEvolving public class FunctionDescriptor implements Descriptor {
  private String from;
  private ClassInstance classInstance;
  /** 
 * Creates a function from a class description.
 */
  public FunctionDescriptor fromClass(  ClassInstance classType){
    from=FunctionDescriptorValidator.FROM_VALUE_CLASS;
    this.classInstance=classType;
    return this;
  }
  /** 
 * Converts this descriptor into a set of properties.
 */
  @Override public Map<String,String> toProperties(){
    DescriptorProperties properties=new DescriptorProperties();
    if (from != null) {
      properties.putString(FunctionDescriptorValidator.FROM,from);
    }
    if (classInstance != null) {
      properties.putProperties(classInstance.toProperties());
    }
    return properties.asMap();
  }
}
