/** 
 * A type for (synthetic) operators that do not output data. For example, data sinks.
 */
public class Nothing {
  private Nothing(){
  }
}
