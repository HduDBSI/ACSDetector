@SuppressWarnings("serial") @RunWith(PowerMockRunner.class) @PrepareForTest(ResultPartitionWriter.class) public class CassandraConnectorTest extends WriteAheadSinkTestBase<Tuple3<String,Integer,Integer>,CassandraTupleWriteAheadSink<Tuple3<String,Integer,Integer>>> {
  private static final Logger LOG=LoggerFactory.getLogger(CassandraConnectorTest.class);
  private static File tmpDir;
  private static final boolean EMBEDDED=true;
  private static EmbeddedCassandraService cassandra;
  private static ClusterBuilder builder=new ClusterBuilder(){
    @Override protected Cluster buildCluster(    Cluster.Builder builder){
      return builder.addContactPoint("127.0.0.1").withQueryOptions(new QueryOptions().setConsistencyLevel(ConsistencyLevel.ONE).setSerialConsistencyLevel(ConsistencyLevel.LOCAL_SERIAL)).withoutJMXReporting().withoutMetrics().build();
    }
  }
;
  private static Cluster cluster;
  private static Session session;
  private static final String CREATE_KEYSPACE_QUERY="CREATE KEYSPACE flink WITH replication= {'class':'SimpleStrategy', 'replication_factor':1};";
  private static final String DROP_KEYSPACE_QUERY="DROP KEYSPACE flink;";
  private static final String CREATE_TABLE_QUERY="CREATE TABLE flink.test (id text PRIMARY KEY, counter int, batch_id int);";
  private static final String CLEAR_TABLE_QUERY="TRUNCATE flink.test;";
  private static final String INSERT_DATA_QUERY="INSERT INTO flink.test (id, counter, batch_id) VALUES (?, ?, ?)";
  private static final String SELECT_DATA_QUERY="SELECT * FROM flink.test;";
  private static final ArrayList<Tuple3<String,Integer,Integer>> collection=new ArrayList<>(20);
static {
    for (int i=0; i < 20; i++) {
      collection.add(new Tuple3<>(UUID.randomUUID().toString(),i,0));
    }
  }
private static class EmbeddedCassandraService {
    CassandraDaemon cassandraDaemon;
    public void start() throws IOException {
      this.cassandraDaemon=new CassandraDaemon();
      this.cassandraDaemon.init(null);
      this.cassandraDaemon.start();
    }
    public void stop(){
      this.cassandraDaemon.stop();
    }
  }
  @BeforeClass public static void startCassandra() throws IOException {
    try {
      String javaVersionString=System.getProperty("java.runtime.version").substring(0,3);
      float javaVersion=Float.parseFloat(javaVersionString);
      Assume.assumeTrue(javaVersion >= 1.8f);
    }
 catch (    AssumptionViolatedException e) {
      System.out.println("Skipping CassandraConnectorTest, because the JDK is < Java 8+");
      throw e;
    }
catch (    Exception e) {
      LOG.error("Cannot determine Java version",e);
      e.printStackTrace();
      fail("Cannot determine Java version");
    }
    tmpDir=CommonTestUtils.createTempDirectory();
    ClassLoader classLoader=CassandraConnectorTest.class.getClassLoader();
    File file=new File(classLoader.getResource("cassandra.yaml").getFile());
    File tmp=new File(tmpDir.getAbsolutePath() + File.separator + "cassandra.yaml");
    assertTrue(tmp.createNewFile());
    BufferedWriter b=new BufferedWriter(new FileWriter(tmp));
    Scanner scanner=new Scanner(file);
    while (scanner.hasNextLine()) {
      String line=scanner.nextLine();
      line=line.replace("$PATH","'" + tmp.getParentFile());
      b.write(line + "\n");
      b.flush();
    }
    scanner.close();
    System.setProperty("cassandra.config",tmp.getAbsoluteFile().toURI().toString());
    if (EMBEDDED) {
      cassandra=new EmbeddedCassandraService();
      cassandra.start();
    }
    try {
      Thread.sleep(1000 * 10);
    }
 catch (    InterruptedException e) {
    }
    cluster=builder.getCluster();
    session=cluster.connect();
    session.execute(CREATE_KEYSPACE_QUERY);
    session.execute(CREATE_TABLE_QUERY);
  }
  @Before public void checkIfIgnore(){
  }
  @After public void deleteSchema() throws Exception {
    session.executeAsync(CLEAR_TABLE_QUERY);
  }
  @AfterClass public static void closeCassandra(){
    if (session != null) {
      session.executeAsync(DROP_KEYSPACE_QUERY);
      session.close();
    }
    if (cluster != null) {
      cluster.close();
    }
    if (cassandra != null) {
      cassandra.stop();
    }
    if (tmpDir != null) {
      tmpDir.delete();
    }
  }
  @Override protected CassandraTupleWriteAheadSink<Tuple3<String,Integer,Integer>> createSink() throws Exception {
    return new CassandraTupleWriteAheadSink<>(INSERT_DATA_QUERY,TypeExtractor.getForObject(new Tuple3<>("",0,0)).createSerializer(new ExecutionConfig()),builder,new CassandraCommitter(builder));
  }
  @Override protected TupleTypeInfo<Tuple3<String,Integer,Integer>> createTypeInfo(){
    return TupleTypeInfo.getBasicTupleTypeInfo(String.class,Integer.class,Integer.class);
  }
  @Override protected Tuple3<String,Integer,Integer> generateValue(  int counter,  int checkpointID){
    return new Tuple3<>(UUID.randomUUID().toString(),counter,checkpointID);
  }
  @Override protected void verifyResultsIdealCircumstances(  OneInputStreamTaskTestHarness<Tuple3<String,Integer,Integer>,Tuple3<String,Integer,Integer>> harness,  OneInputStreamTask<Tuple3<String,Integer,Integer>,Tuple3<String,Integer,Integer>> task,  CassandraTupleWriteAheadSink<Tuple3<String,Integer,Integer>> sink){
    ResultSet result=session.execute(SELECT_DATA_QUERY);
    ArrayList<Integer> list=new ArrayList<>();
    for (int x=1; x <= 60; x++) {
      list.add(x);
    }
    for (    Row s : result) {
      list.remove(new Integer(s.getInt("counter")));
    }
    Assert.assertTrue("The following ID's were not found in the ResultSet: " + list.toString(),list.isEmpty());
  }
  @Override protected void verifyResultsDataPersistenceUponMissedNotify(  OneInputStreamTaskTestHarness<Tuple3<String,Integer,Integer>,Tuple3<String,Integer,Integer>> harness,  OneInputStreamTask<Tuple3<String,Integer,Integer>,Tuple3<String,Integer,Integer>> task,  CassandraTupleWriteAheadSink<Tuple3<String,Integer,Integer>> sink){
    ResultSet result=session.execute(SELECT_DATA_QUERY);
    ArrayList<Integer> list=new ArrayList<>();
    for (int x=1; x <= 60; x++) {
      list.add(x);
    }
    for (    Row s : result) {
      list.remove(new Integer(s.getInt("counter")));
    }
    Assert.assertTrue("The following ID's were not found in the ResultSet: " + list.toString(),list.isEmpty());
  }
  @Override protected void verifyResultsDataDiscardingUponRestore(  OneInputStreamTaskTestHarness<Tuple3<String,Integer,Integer>,Tuple3<String,Integer,Integer>> harness,  OneInputStreamTask<Tuple3<String,Integer,Integer>,Tuple3<String,Integer,Integer>> task,  CassandraTupleWriteAheadSink<Tuple3<String,Integer,Integer>> sink){
    ResultSet result=session.execute(SELECT_DATA_QUERY);
    ArrayList<Integer> list=new ArrayList<>();
    for (int x=1; x <= 20; x++) {
      list.add(x);
    }
    for (int x=41; x <= 60; x++) {
      list.add(x);
    }
    for (    Row s : result) {
      list.remove(new Integer(s.getInt("counter")));
    }
    Assert.assertTrue("The following ID's were not found in the ResultSet: " + list.toString(),list.isEmpty());
  }
  @Test public void testCassandraCommitter() throws Exception {
    CassandraCommitter cc1=new CassandraCommitter(builder);
    cc1.setJobId("job");
    cc1.setOperatorId("operator");
    cc1.setOperatorSubtaskId(0);
    CassandraCommitter cc2=new CassandraCommitter(builder);
    cc2.setJobId("job");
    cc2.setOperatorId("operator");
    cc2.setOperatorSubtaskId(1);
    CassandraCommitter cc3=new CassandraCommitter(builder);
    cc3.setJobId("job");
    cc3.setOperatorId("operator1");
    cc3.setOperatorSubtaskId(0);
    cc1.createResource();
    cc1.open();
    cc2.open();
    cc3.open();
    Assert.assertFalse(cc1.isCheckpointCommitted(1));
    Assert.assertFalse(cc2.isCheckpointCommitted(1));
    Assert.assertFalse(cc3.isCheckpointCommitted(1));
    cc1.commitCheckpoint(1);
    Assert.assertTrue(cc1.isCheckpointCommitted(1));
    Assert.assertFalse(cc2.isCheckpointCommitted(1));
    Assert.assertFalse(cc3.isCheckpointCommitted(1));
    Assert.assertFalse(cc1.isCheckpointCommitted(2));
    cc1.close();
    cc2.close();
    cc3.close();
    cc1=new CassandraCommitter(builder);
    cc1.setJobId("job");
    cc1.setOperatorId("operator");
    cc1.setOperatorSubtaskId(0);
    cc1.open();
    Assert.assertTrue(cc1.isCheckpointCommitted(1));
    Assert.assertFalse(cc1.isCheckpointCommitted(2));
    cc1.close();
  }
  @Test public void testCassandraTupleAtLeastOnceSink() throws Exception {
    StreamExecutionEnvironment env=StreamExecutionEnvironment.getExecutionEnvironment();
    env.setParallelism(1);
    DataStream<Tuple3<String,Integer,Integer>> source=env.fromCollection(collection);
    source.addSink(new CassandraTupleSink<Tuple3<String,Integer,Integer>>(INSERT_DATA_QUERY,builder));
    env.execute();
    ResultSet rs=session.execute(SELECT_DATA_QUERY);
    Assert.assertEquals(20,rs.all().size());
  }
  @Test public void testCassandraPojoAtLeastOnceSink() throws Exception {
    StreamExecutionEnvironment env=StreamExecutionEnvironment.getExecutionEnvironment();
    env.setParallelism(1);
    DataStreamSource<Pojo> source=env.addSource(new SourceFunction<Pojo>(){
      private boolean running=true;
      private volatile int cnt=0;
      @Override public void run(      SourceContext<Pojo> ctx) throws Exception {
        while (running) {
          ctx.collect(new Pojo(UUID.randomUUID().toString(),cnt,0));
          cnt++;
          if (cnt == 20) {
            cancel();
          }
        }
      }
      @Override public void cancel(){
        running=false;
      }
    }
);
    source.addSink(new CassandraPojoSink<>(Pojo.class,builder));
    env.execute();
    ResultSet rs=session.execute(SELECT_DATA_QUERY);
    Assert.assertEquals(20,rs.all().size());
  }
  @Test public void testCassandraBatchFormats() throws Exception {
    ExecutionEnvironment env=ExecutionEnvironment.getExecutionEnvironment();
    env.setParallelism(1);
    DataSet<Tuple3<String,Integer,Integer>> dataSet=env.fromCollection(collection);
    dataSet.output(new CassandraOutputFormat<Tuple3<String,Integer,Integer>>(INSERT_DATA_QUERY,builder));
    env.execute("Write data");
    DataSet<Tuple3<String,Integer,Integer>> inputDS=env.createInput(new CassandraInputFormat<Tuple3<String,Integer,Integer>>(SELECT_DATA_QUERY,builder),TypeInformation.of(new TypeHint<Tuple3<String,Integer,Integer>>(){
    }
));
    long count=inputDS.count();
    Assert.assertEquals(count,20L);
  }
}
