/** 
 * Builder for  {@link AdaptiveScheduler}. 
 */
public class AdaptiveSchedulerBuilder {
  private static final Time DEFAULT_TIMEOUT=Time.seconds(300);
  private final JobGraph jobGraph;
  private final ComponentMainThreadExecutor mainThreadExecutor;
  private Executor ioExecutor=TestingUtils.defaultExecutor();
  private Configuration jobMasterConfiguration=new Configuration();
  private ScheduledExecutorService futureExecutor=TestingUtils.defaultExecutor();
  private ClassLoader userCodeLoader=ClassLoader.getSystemClassLoader();
  private CheckpointsCleaner checkpointsCleaner=new CheckpointsCleaner();
  private CheckpointRecoveryFactory checkpointRecoveryFactory=new StandaloneCheckpointRecoveryFactory();
  private DeclarativeSlotPool declarativeSlotPool;
  private Time rpcTimeout=DEFAULT_TIMEOUT;
  private BlobWriter blobWriter=VoidBlobWriter.getInstance();
  private JobManagerJobMetricGroup jobManagerJobMetricGroup=UnregisteredMetricGroups.createUnregisteredJobManagerJobMetricGroup();
  private ShuffleMaster<?> shuffleMaster=ShuffleTestUtils.DEFAULT_SHUFFLE_MASTER;
  private JobMasterPartitionTracker partitionTracker=NoOpJobMasterPartitionTracker.INSTANCE;
  private RestartBackoffTimeStrategy restartBackoffTimeStrategy=NoRestartBackoffTimeStrategy.INSTANCE;
  private FatalErrorHandler fatalErrorHandler=error -> FatalExitExceptionHandler.INSTANCE.uncaughtException(Thread.currentThread(),error);
  private JobStatusListener jobStatusListener=(ignoredA,ignoredB,ignoredC,ignoredD) -> {
  }
;
  private long initializationTimestamp=System.currentTimeMillis();
  @Nullable private SlotAllocator slotAllocator;
  public AdaptiveSchedulerBuilder(  final JobGraph jobGraph,  ComponentMainThreadExecutor mainThreadExecutor){
    this.jobGraph=jobGraph;
    this.mainThreadExecutor=mainThreadExecutor;
    this.declarativeSlotPool=new DefaultDeclarativeSlotPool(jobGraph.getJobID(),new DefaultAllocatedSlotPool(),ignored -> {
    }
,DEFAULT_TIMEOUT,rpcTimeout);
  }
  public AdaptiveSchedulerBuilder setIoExecutor(  final Executor ioExecutor){
    this.ioExecutor=ioExecutor;
    return this;
  }
  public AdaptiveSchedulerBuilder setJobMasterConfiguration(  final Configuration jobMasterConfiguration){
    this.jobMasterConfiguration=jobMasterConfiguration;
    return this;
  }
  public AdaptiveSchedulerBuilder setFutureExecutor(  final ScheduledExecutorService futureExecutor){
    this.futureExecutor=futureExecutor;
    return this;
  }
  public AdaptiveSchedulerBuilder setUserCodeLoader(  final ClassLoader userCodeLoader){
    this.userCodeLoader=userCodeLoader;
    return this;
  }
  public AdaptiveSchedulerBuilder setCheckpointCleaner(  final CheckpointsCleaner checkpointsCleaner){
    this.checkpointsCleaner=checkpointsCleaner;
    return this;
  }
  public AdaptiveSchedulerBuilder setCheckpointRecoveryFactory(  final CheckpointRecoveryFactory checkpointRecoveryFactory){
    this.checkpointRecoveryFactory=checkpointRecoveryFactory;
    return this;
  }
  public AdaptiveSchedulerBuilder setRpcTimeout(  final Time rpcTimeout){
    this.rpcTimeout=rpcTimeout;
    return this;
  }
  public AdaptiveSchedulerBuilder setBlobWriter(  final BlobWriter blobWriter){
    this.blobWriter=blobWriter;
    return this;
  }
  public AdaptiveSchedulerBuilder setJobManagerJobMetricGroup(  final JobManagerJobMetricGroup jobManagerJobMetricGroup){
    this.jobManagerJobMetricGroup=jobManagerJobMetricGroup;
    return this;
  }
  public AdaptiveSchedulerBuilder setShuffleMaster(  final ShuffleMaster<?> shuffleMaster){
    this.shuffleMaster=shuffleMaster;
    return this;
  }
  public AdaptiveSchedulerBuilder setPartitionTracker(  final JobMasterPartitionTracker partitionTracker){
    this.partitionTracker=partitionTracker;
    return this;
  }
  public AdaptiveSchedulerBuilder setDeclarativeSlotPool(  DeclarativeSlotPool declarativeSlotPool){
    this.declarativeSlotPool=declarativeSlotPool;
    return this;
  }
  public AdaptiveSchedulerBuilder setRestartBackoffTimeStrategy(  final RestartBackoffTimeStrategy restartBackoffTimeStrategy){
    this.restartBackoffTimeStrategy=restartBackoffTimeStrategy;
    return this;
  }
  public AdaptiveSchedulerBuilder setFatalErrorHandler(  FatalErrorHandler fatalErrorHandler){
    this.fatalErrorHandler=fatalErrorHandler;
    return this;
  }
  public AdaptiveSchedulerBuilder setJobStatusListener(  JobStatusListener jobStatusListener){
    this.jobStatusListener=jobStatusListener;
    return this;
  }
  public AdaptiveSchedulerBuilder setInitializationTimestamp(  long initializationTimestamp){
    this.initializationTimestamp=initializationTimestamp;
    return this;
  }
  public AdaptiveSchedulerBuilder setSlotAllocator(  SlotAllocator slotAllocator){
    this.slotAllocator=slotAllocator;
    return this;
  }
  public AdaptiveScheduler build() throws Exception {
    final ExecutionGraphFactory executionGraphFactory=new DefaultExecutionGraphFactory(jobMasterConfiguration,userCodeLoader,new DefaultExecutionDeploymentTracker(),futureExecutor,ioExecutor,rpcTimeout,jobManagerJobMetricGroup,blobWriter,shuffleMaster,partitionTracker);
    return new AdaptiveScheduler(jobGraph,jobMasterConfiguration,declarativeSlotPool,slotAllocator == null ? AdaptiveSchedulerFactory.createSlotSharingSlotAllocator(declarativeSlotPool) : slotAllocator,ioExecutor,userCodeLoader,checkpointsCleaner,checkpointRecoveryFactory,jobMasterConfiguration.get(JobManagerOptions.RESOURCE_WAIT_TIMEOUT),jobMasterConfiguration.get(JobManagerOptions.RESOURCE_STABILIZATION_TIMEOUT),jobManagerJobMetricGroup,restartBackoffTimeStrategy,initializationTimestamp,mainThreadExecutor,fatalErrorHandler,jobStatusListener,executionGraphFactory);
  }
}
