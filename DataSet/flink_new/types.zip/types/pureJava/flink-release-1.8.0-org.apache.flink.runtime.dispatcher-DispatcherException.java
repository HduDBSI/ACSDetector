/** 
 * Base class for  {@link Dispatcher} related exceptions.
 */
public class DispatcherException extends FlinkException {
  private static final long serialVersionUID=3781733042984381286L;
  public DispatcherException(  String message){
    super(message);
  }
  public DispatcherException(  Throwable cause){
    super(cause);
  }
  public DispatcherException(  String message,  Throwable cause){
    super(message,cause);
  }
}
