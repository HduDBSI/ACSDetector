/** 
 * Flink Sink to save data into a Cassandra cluster using <a href="http://docs.datastax.com/en/drivers/java/2.1/com/datastax/driver/mapping/Mapper.html">Mapper</a>, which it uses annotations from <a href="http://docs.datastax.com/en/drivers/java/2.1/com/datastax/driver/mapping/annotations/package-summary.html"> com.datastax.driver.mapping.annotations</a>.
 * @param < IN > Type of the elements emitted by this sink
 */
public class CassandraPojoSink<IN> extends CassandraSinkBase<IN,ResultSet> {
  private static final long serialVersionUID=1L;
  protected final Class<IN> clazz;
  private final MapperOptions options;
  protected transient Mapper<IN> mapper;
  protected transient MappingManager mappingManager;
  /** 
 * The main constructor for creating CassandraPojoSink.
 * @param clazz Class instance
 */
  public CassandraPojoSink(  Class<IN> clazz,  ClusterBuilder builder){
    this(clazz,builder,null);
  }
  public CassandraPojoSink(  Class<IN> clazz,  ClusterBuilder builder,  @Nullable MapperOptions options){
    super(builder);
    this.clazz=clazz;
    this.options=options;
  }
  @Override public void open(  Configuration configuration){
    super.open(configuration);
    try {
      this.mappingManager=new MappingManager(session);
      this.mapper=mappingManager.mapper(clazz);
      if (options != null) {
        Mapper.Option[] optionsArray=options.getMapperOptions();
        if (optionsArray != null) {
          this.mapper.setDefaultSaveOptions(optionsArray);
        }
      }
    }
 catch (    Exception e) {
      throw new RuntimeException("Cannot create CassandraPojoSink with input: " + clazz.getSimpleName(),e);
    }
  }
  @Override public ListenableFuture<ResultSet> send(  IN value){
    return session.executeAsync(mapper.saveQuery(value));
  }
}
