private static class StreamTaskUnderTest extends NoOpStreamTask {
  private Queue<Event> eventQueue;
  private volatile boolean stopped;
  StreamTaskUnderTest(  final Environment env,  Queue<Event> eventQueue) throws Exception {
    super(env);
    this.eventQueue=checkNotNull(eventQueue);
  }
  @Override protected void init(){
    eventQueue.add(Event.TASK_INITIALIZED);
  }
  @Override protected void processInput(  MailboxDefaultAction.Controller controller) throws Exception {
    if (stopped || isCanceled()) {
      controller.suspendDefaultAction();
      mailboxProcessor.suspend();
    }
  }
  void stopTask(){
    stopped=true;
  }
}
