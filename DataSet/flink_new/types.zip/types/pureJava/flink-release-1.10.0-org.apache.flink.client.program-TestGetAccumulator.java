/** 
 * Test job that retrieves an accumulator from the  {@link JobExecutionResult}.
 */
public static final class TestGetAccumulator {
  public static void main(  String[] args) throws Exception {
    final ExecutionEnvironment env=ExecutionEnvironment.getExecutionEnvironment();
    env.fromElements(1,2).output(new DiscardingOutputFormat<Integer>());
    env.execute().getAccumulatorResult(ACCUMULATOR_NAME);
  }
}
