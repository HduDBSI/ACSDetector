public static class MyMapper4<A> implements MapFunction<PojoWithParameterizedFields1<A>,A> {
  private static final long serialVersionUID=1L;
  @Override public A map(  PojoWithParameterizedFields1<A> value) throws Exception {
    return null;
  }
}
