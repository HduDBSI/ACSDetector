/** 
 * Mapping of counter between Flink and Datadog.
 */
public class DCounter extends DMetric {
  private final Counter counter;
  private long lastReportCount=0;
  private long currentReportCount=0;
  public DCounter(  Counter c,  String metricName,  String host,  List<String> tags,  Clock clock){
    super(MetricType.count,metricName,host,tags,clock);
    counter=c;
  }
  /** 
 * Visibility of this method must not be changed since we deliberately not map it to json object in a Datadog-defined format. <p>Note: DataDog counters count the number of events during the reporting interval.
 * @return the number of events since the last retrieval
 */
  @Override public Number getMetricValue(){
    long currentCount=counter.getCount();
    long difference=currentCount - lastReportCount;
    currentReportCount=currentCount;
    return difference;
  }
  @Override public void ackReport(){
    lastReportCount=currentReportCount;
  }
}
