/** 
 * A factory for buffer pools.
 */
public interface BufferPoolFactory {
  /** 
 * Tries to create a buffer pool, which is guaranteed to provide at least the number of required buffers. <p>The buffer pool is of dynamic size with at least <tt>numRequiredBuffers</tt> buffers.
 * @param numRequiredBuffers minimum number of network buffers in this pool
 * @param maxUsedBuffers maximum number of network buffers this pool offers
 */
  BufferPool createBufferPool(  int numRequiredBuffers,  int maxUsedBuffers) throws IOException ;
  /** 
 * Tries to create a buffer pool with an optional owner, which is guaranteed to provide at least the number of required buffers. <p>The buffer pool is of dynamic size with at least <tt>numRequiredBuffers</tt> buffers.
 * @param numRequiredBuffers minimum number of network buffers in this pool
 * @param maxUsedBuffers maximum number of network buffers this pool offers
 * @param owner the optional owner of this buffer pool to release memory when needed
 */
  BufferPool createBufferPool(  int numRequiredBuffers,  int maxUsedBuffers,  Optional<BufferPoolOwner> owner) throws IOException ;
  /** 
 * Destroy callback for updating factory book keeping.
 */
  void destroyBufferPool(  BufferPool bufferPool) throws IOException ;
}
