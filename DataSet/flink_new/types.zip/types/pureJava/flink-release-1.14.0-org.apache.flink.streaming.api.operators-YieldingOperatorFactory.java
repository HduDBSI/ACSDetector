/** 
 * An operator that needs access to the  {@link MailboxExecutor} to yield to downstream operatorsneeds to be created through a factory implementing this interface.
 */
@Experimental public interface YieldingOperatorFactory<OUT> extends StreamOperatorFactory<OUT> {
  void setMailboxExecutor(  MailboxExecutor mailboxExecutor);
}
