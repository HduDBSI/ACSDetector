private static class CleanerFactory {
  private final String cleanerName;
  @Nullable private final Object cleaner;
  private final Method cleanableCreationMethod;
  private final Method cleanMethod;
  private CleanerFactory(  String cleanerName,  @Nullable Object cleaner,  Method cleanableCreationMethod,  Method cleanMethod){
    this.cleanerName=cleanerName;
    this.cleaner=cleaner;
    this.cleanableCreationMethod=cleanableCreationMethod;
    this.cleanMethod=cleanMethod;
  }
  private Runnable create(  Object owner,  Runnable cleanupOperation){
    Object cleanable;
    try {
      cleanable=cleanableCreationMethod.invoke(cleaner,owner,cleanupOperation);
    }
 catch (    IllegalAccessException|InvocationTargetException e) {
      throw new Error("Failed to create a " + cleanerName,e);
    }
    String ownerString=owner.toString();
    return () -> {
      try {
        cleanMethod.invoke(cleanable);
      }
 catch (      IllegalAccessException|InvocationTargetException e) {
        String message=String.format("FATAL UNEXPECTED - Failed to invoke a %s for %s",cleanerName,ownerString);
        LOG.error(message,e);
        throw new Error(message,e);
      }
    }
;
  }
}
