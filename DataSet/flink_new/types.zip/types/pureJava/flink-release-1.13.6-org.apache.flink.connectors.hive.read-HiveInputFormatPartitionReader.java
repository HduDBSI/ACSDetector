/** 
 * Partition reader that read records from InputFormat using given partitions. 
 */
public class HiveInputFormatPartitionReader implements PartitionReader<HiveTablePartition,RowData> {
  private static final long serialVersionUID=1L;
  private final JobConfWrapper jobConfWrapper;
  private final String hiveVersion;
  protected final ObjectPath tablePath;
  private final DataType[] fieldTypes;
  private final String[] fieldNames;
  private final List<String> partitionKeys;
  private final int[] selectedFields;
  private final boolean useMapRedReader;
  private transient HiveTableInputFormat hiveTableInputFormat;
  private transient HiveTableInputSplit[] inputSplits;
  private transient int readingSplitId;
  public HiveInputFormatPartitionReader(  JobConf jobConf,  String hiveVersion,  ObjectPath tablePath,  DataType[] fieldTypes,  String[] fieldNames,  List<String> partitionKeys,  int[] selectedFields,  boolean useMapRedReader){
    this.jobConfWrapper=new JobConfWrapper(jobConf);
    this.hiveVersion=hiveVersion;
    this.tablePath=tablePath;
    this.fieldTypes=fieldTypes;
    this.fieldNames=fieldNames;
    this.partitionKeys=partitionKeys;
    this.selectedFields=selectedFields;
    this.useMapRedReader=useMapRedReader;
  }
  @Override public void open(  List<HiveTablePartition> partitions) throws IOException {
    hiveTableInputFormat=new HiveTableInputFormat(this.jobConfWrapper.conf(),this.partitionKeys,this.fieldTypes,this.fieldNames,this.selectedFields,null,this.hiveVersion,this.useMapRedReader,partitions);
    inputSplits=hiveTableInputFormat.createInputSplits(1);
    readingSplitId=0;
    if (inputSplits.length > 0) {
      hiveTableInputFormat.open(inputSplits[readingSplitId]);
    }
  }
  @Override public RowData read(  RowData reuse) throws IOException {
    if (hasNext()) {
      return hiveTableInputFormat.nextRecord(reuse);
    }
    return null;
  }
  private boolean hasNext() throws IOException {
    if (inputSplits.length > 0) {
      if (hiveTableInputFormat.reachedEnd()) {
        if (readingSplitId < inputSplits.length - 1) {
          hiveTableInputFormat.close();
          readingSplitId++;
          hiveTableInputFormat.open(inputSplits[readingSplitId]);
          return hasNext();
        }
      }
 else {
        return true;
      }
    }
    return false;
  }
  @Override public void close() throws IOException {
    if (hiveTableInputFormat != null) {
      hiveTableInputFormat.close();
    }
  }
}
