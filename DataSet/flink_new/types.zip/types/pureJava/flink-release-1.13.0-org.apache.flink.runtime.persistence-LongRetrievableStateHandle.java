/** 
 * Testing  {@link RetrievableStateStorageHelper} implementation with {@link Long}. 
 */
public static class LongRetrievableStateHandle implements RetrievableStateHandle<Long> {
  private static final long serialVersionUID=-3555329254423838912L;
  private static AtomicInteger numberOfGlobalDiscardCalls=new AtomicInteger(0);
  private final Long state;
  private int numberOfDiscardCalls=0;
  public LongRetrievableStateHandle(  Long state){
    this.state=state;
  }
  @Override public Long retrieveState(){
    return state;
  }
  @Override public void discardState(){
    numberOfGlobalDiscardCalls.incrementAndGet();
    numberOfDiscardCalls++;
  }
  @Override public long getStateSize(){
    return 0;
  }
  public int getNumberOfDiscardCalls(){
    return numberOfDiscardCalls;
  }
  public static int getNumberOfGlobalDiscardCalls(){
    return numberOfGlobalDiscardCalls.get();
  }
  public static void clearNumberOfGlobalDiscardCalls(){
    numberOfGlobalDiscardCalls.set(0);
  }
}
