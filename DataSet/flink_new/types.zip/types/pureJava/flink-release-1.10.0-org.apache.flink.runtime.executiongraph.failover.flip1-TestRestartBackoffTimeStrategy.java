/** 
 * A RestartBackoffTimeStrategy implementation for tests.
 */
public class TestRestartBackoffTimeStrategy implements RestartBackoffTimeStrategy {
  private boolean canRestart;
  private long backoffTime;
  public TestRestartBackoffTimeStrategy(  boolean canRestart,  long backoffTime){
    this.canRestart=canRestart;
    this.backoffTime=backoffTime;
  }
  @Override public boolean canRestart(){
    return canRestart;
  }
  @Override public long getBackoffTime(){
    return backoffTime;
  }
  @Override public void notifyFailure(  Throwable cause){
  }
  public void setCanRestart(  final boolean canRestart){
    this.canRestart=canRestart;
  }
  public void setBackoffTime(  final long backoffTime){
    this.backoffTime=backoffTime;
  }
}
