/** 
 * Test  {@link CompletedCheckpointStore} implementation for testing the shutdown behavior. 
 */
public final class TestingCompletedCheckpointStore implements CompletedCheckpointStore {
  private final CompletableFuture<JobStatus> shutdownStatus;
  public TestingCompletedCheckpointStore(  CompletableFuture<JobStatus> shutdownStatus){
    this.shutdownStatus=shutdownStatus;
  }
  @Override public void addCheckpoint(  CompletedCheckpoint checkpoint,  CheckpointsCleaner checkpointsCleaner,  Runnable postCleanup){
    throw new UnsupportedOperationException("Not implemented.");
  }
  @Override public CompletedCheckpoint getLatestCheckpoint(){
    return null;
  }
  @Override public void shutdown(  JobStatus jobStatus,  CheckpointsCleaner checkpointsCleaner){
    shutdownStatus.complete(jobStatus);
  }
  @Override public List<CompletedCheckpoint> getAllCheckpoints(){
    return Collections.emptyList();
  }
  @Override public int getNumberOfRetainedCheckpoints(){
    throw new UnsupportedOperationException("Not implemented.");
  }
  @Override public int getMaxNumberOfRetainedCheckpoints(){
    throw new UnsupportedOperationException("Not implemented.");
  }
  @Override public boolean requiresExternalizedCheckpoints(){
    throw new UnsupportedOperationException("Not implemented.");
  }
}
