/** 
 * The resettable iterator is a specialization of the iterator, allowing to reset the iterator and re-retrieve elements. Whether the iterator is completely reset or only partially depends on the actual implementation.
 */
public interface ResettableMutableObjectIterator<E> extends MutableObjectIterator<E> {
  /** 
 * Resets the iterator.
 * @throws IOException May be thrown when the serialization into buffers or the spilling to secondarystorage fails.
 */
  public void reset() throws IOException ;
}
