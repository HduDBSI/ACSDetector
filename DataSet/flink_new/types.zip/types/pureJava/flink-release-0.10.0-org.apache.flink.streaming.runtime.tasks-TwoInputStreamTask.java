public class TwoInputStreamTask<IN1,IN2,OUT> extends StreamTask<OUT,TwoInputStreamOperator<IN1,IN2,OUT>> {
  private StreamTwoInputProcessor<IN1,IN2> inputProcessor;
  private volatile boolean running=true;
  @Override public void init() throws Exception {
    StreamConfig configuration=getConfiguration();
    ClassLoader userClassLoader=getUserCodeClassLoader();
    TypeSerializer<IN1> inputDeserializer1=configuration.getTypeSerializerIn1(userClassLoader);
    TypeSerializer<IN2> inputDeserializer2=configuration.getTypeSerializerIn2(userClassLoader);
    int numberOfInputs=configuration.getNumberOfInputs();
    ArrayList<InputGate> inputList1=new ArrayList<InputGate>();
    ArrayList<InputGate> inputList2=new ArrayList<InputGate>();
    List<StreamEdge> inEdges=configuration.getInPhysicalEdges(userClassLoader);
    for (int i=0; i < numberOfInputs; i++) {
      int inputType=inEdges.get(i).getTypeNumber();
      InputGate reader=getEnvironment().getInputGate(i);
switch (inputType) {
case 1:
        inputList1.add(reader);
      break;
case 2:
    inputList2.add(reader);
  break;
default :
throw new RuntimeException("Invalid input type number: " + inputType);
}
}
this.inputProcessor=new StreamTwoInputProcessor<IN1,IN2>(inputList1,inputList2,inputDeserializer1,inputDeserializer2,getCheckpointBarrierListener(),configuration.getCheckpointMode(),getEnvironment().getIOManager(),getExecutionConfig().areTimestampsEnabled());
AccumulatorRegistry registry=getEnvironment().getAccumulatorRegistry();
AccumulatorRegistry.Reporter reporter=registry.getReadWriteReporter();
this.inputProcessor.setReporter(reporter);
}
@Override protected void run() throws Exception {
final TwoInputStreamOperator<IN1,IN2,OUT> operator=this.headOperator;
final StreamTwoInputProcessor<IN1,IN2> inputProcessor=this.inputProcessor;
final Object lock=getCheckpointLock();
while (running && inputProcessor.processInput(operator,lock)) {
checkTimerException();
}
}
@Override protected void cleanup() throws Exception {
inputProcessor.cleanup();
}
@Override protected void cancelTask(){
running=false;
}
}
