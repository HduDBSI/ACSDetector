private static class MockSource implements SourceFunction<Tuple2<Long,Integer>>, ListCheckpointed<Serializable> {
  private static final long serialVersionUID=1;
  private int maxElements;
  private int checkpointDelay;
  private int readDelay;
  private volatile int count;
  private volatile long lastCheckpointId=-1;
  private Semaphore semaphore;
  private volatile boolean isRunning=true;
  public MockSource(  int maxElements,  int checkpointDelay,  int readDelay){
    this.maxElements=maxElements;
    this.checkpointDelay=checkpointDelay;
    this.readDelay=readDelay;
    this.count=0;
    semaphore=new Semaphore(1);
  }
  @Override public void run(  SourceContext<Tuple2<Long,Integer>> ctx){
    while (isRunning && count < maxElements) {
      try {
        Thread.sleep(readDelay);
      }
 catch (      InterruptedException e) {
        Thread.currentThread().interrupt();
      }
synchronized (ctx.getCheckpointLock()) {
        ctx.collect(new Tuple2<>(lastCheckpointId,count));
        count++;
      }
    }
  }
  @Override public void cancel(){
    isRunning=false;
  }
  @Override public List<Serializable> snapshotState(  long checkpointId,  long timestamp) throws Exception {
    if (!semaphore.tryAcquire()) {
      Assert.fail("Concurrent invocation of snapshotState.");
    }
    int startCount=count;
    lastCheckpointId=checkpointId;
    long sum=0;
    for (int i=0; i < checkpointDelay; i++) {
      sum+=new Random().nextLong();
    }
    if (startCount != count) {
      semaphore.release();
      Assert.fail("Count is different at start end end of snapshot.");
    }
    semaphore.release();
    return Collections.singletonList(sum);
  }
  @Override public void restoreState(  List<Serializable> state) throws Exception {
  }
}
