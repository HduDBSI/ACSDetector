/** 
 * Base class for all stream operator factories. It implements some common methods and the  {@link ProcessingTimeServiceAware} interface which enables stream operators to access {@link ProcessingTimeService}.
 */
@Experimental public abstract class AbstractStreamOperatorFactory<OUT> implements StreamOperatorFactory<OUT>, ProcessingTimeServiceAware {
  protected ChainingStrategy chainingStrategy=ChainingStrategy.DEFAULT_CHAINING_STRATEGY;
  protected transient ProcessingTimeService processingTimeService;
  @Override public void setChainingStrategy(  ChainingStrategy strategy){
    this.chainingStrategy=strategy;
  }
  @Override public ChainingStrategy getChainingStrategy(){
    return chainingStrategy;
  }
  @Override public void setProcessingTimeService(  ProcessingTimeService processingTimeService){
    this.processingTimeService=processingTimeService;
  }
}
