private static class NonReshardedStreamsKinesis implements KinesisProxyInterface {
  private Map<String,List<StreamShardHandle>> streamsWithListOfShards=new HashMap<>();
  public NonReshardedStreamsKinesis(  Map<String,Integer> streamsToShardCount){
    for (    Map.Entry<String,Integer> streamToShardCount : streamsToShardCount.entrySet()) {
      String streamName=streamToShardCount.getKey();
      int shardCount=streamToShardCount.getValue();
      if (shardCount == 0) {
      }
 else {
        List<StreamShardHandle> shardsOfStream=new ArrayList<>(shardCount);
        for (int i=0; i < shardCount; i++) {
          shardsOfStream.add(new StreamShardHandle(streamName,new Shard().withShardId(KinesisShardIdGenerator.generateFromShardOrder(i))));
        }
        streamsWithListOfShards.put(streamName,shardsOfStream);
      }
    }
  }
  @Override public GetShardListResult getShardList(  Map<String,String> streamNamesWithLastSeenShardIds){
    GetShardListResult result=new GetShardListResult();
    for (    Map.Entry<String,List<StreamShardHandle>> streamsWithShards : streamsWithListOfShards.entrySet()) {
      String streamName=streamsWithShards.getKey();
      for (      StreamShardHandle shard : streamsWithShards.getValue()) {
        if (streamNamesWithLastSeenShardIds.get(streamName) == null) {
          result.addRetrievedShardToStream(streamName,shard);
        }
 else {
          if (compareShardIds(shard.getShard().getShardId(),streamNamesWithLastSeenShardIds.get(streamName)) > 0) {
            result.addRetrievedShardToStream(streamName,shard);
          }
        }
      }
    }
    return result;
  }
  @Override public String getShardIterator(  StreamShardHandle shard,  String shardIteratorType,  Object startingMarker){
    return null;
  }
  @Override public GetRecordsResult getRecords(  String shardIterator,  int maxRecordsToGet){
    return null;
  }
  /** 
 * Utility function to compare two shard ids.
 * @param firstShardId first shard id to compare
 * @param secondShardId second shard id to compare
 * @return a value less than 0 if the first shard id is smaller than the second shard id,or a value larger than 0 the first shard is larger than the second shard id, or 0 if they are equal
 */
  private static int compareShardIds(  String firstShardId,  String secondShardId){
    if (!isValidShardId(firstShardId)) {
      throw new IllegalArgumentException("The first shard id has invalid format.");
    }
    if (!isValidShardId(secondShardId)) {
      throw new IllegalArgumentException("The second shard id has invalid format.");
    }
    return Long.compare(Long.parseLong(firstShardId.substring(8)),Long.parseLong(secondShardId.substring(8)));
  }
  /** 
 * Checks if a shard id has valid format. Kinesis stream shard ids have 12-digit numbers left-padded with 0's, prefixed with "shardId-", ex. "shardId-000000000015".
 * @param shardId the shard id to check
 * @return whether the shard id is valid
 */
  private static boolean isValidShardId(  String shardId){
    if (shardId == null) {
      return false;
    }
    return shardId.matches("^shardId-\\d{12}");
  }
}
