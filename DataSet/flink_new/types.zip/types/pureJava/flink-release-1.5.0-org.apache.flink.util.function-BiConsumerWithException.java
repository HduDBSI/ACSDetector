/** 
 * A checked extension of the  {@link BiConsumer} interface.
 * @param < T > type of the first argument
 * @param < U > type of the second argument
 * @param < E > type of the thrown exception
 */
@FunctionalInterface public interface BiConsumerWithException<T,U,E extends Throwable> extends BiConsumer<T,U> {
  /** 
 * Performs this operation on the given arguments.
 * @param t the first input argument
 * @param u the second input argument
 * @throws E in case of an error
 */
  void acceptWithException(  T t,  U u) throws E ;
  @Override default void accept(  T t,  U u){
    try {
      acceptWithException(t,u);
    }
 catch (    Throwable e) {
      ExceptionUtils.rethrow(e);
    }
  }
}
