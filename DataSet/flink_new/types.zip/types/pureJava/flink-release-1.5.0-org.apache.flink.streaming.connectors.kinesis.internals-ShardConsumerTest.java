/** 
 * Tests for the  {@link ShardConsumer}.
 */
public class ShardConsumerTest {
  @Test public void testMetricsReporting(){
    StreamShardHandle fakeToBeConsumedShard=getMockStreamShard("fakeStream",0);
    LinkedList<KinesisStreamShardState> subscribedShardsStateUnderTest=new LinkedList<>();
    subscribedShardsStateUnderTest.add(new KinesisStreamShardState(KinesisDataFetcher.convertToStreamShardMetadata(fakeToBeConsumedShard),fakeToBeConsumedShard,new SequenceNumber("fakeStartingState")));
    TestSourceContext<String> sourceContext=new TestSourceContext<>();
    TestableKinesisDataFetcher<String> fetcher=new TestableKinesisDataFetcher<>(Collections.singletonList("fakeStream"),sourceContext,new Properties(),new KinesisDeserializationSchemaWrapper<>(new SimpleStringSchema()),10,2,new AtomicReference<>(),subscribedShardsStateUnderTest,KinesisDataFetcher.createInitialSubscribedStreamsToLastDiscoveredShardsState(Collections.singletonList("fakeStream")),Mockito.mock(KinesisProxyInterface.class));
    ShardMetricsReporter shardMetricsReporter=new ShardMetricsReporter();
    long millisBehindLatest=500L;
    new ShardConsumer<>(fetcher,0,subscribedShardsStateUnderTest.get(0).getStreamShardHandle(),subscribedShardsStateUnderTest.get(0).getLastProcessedSequenceNum(),FakeKinesisBehavioursFactory.totalNumOfRecordsAfterNumOfGetRecordsCalls(1000,9,millisBehindLatest),shardMetricsReporter).run();
    assertEquals(millisBehindLatest,shardMetricsReporter.getMillisBehindLatest());
  }
  @Test public void testCorrectNumOfCollectedRecordsAndUpdatedState(){
    StreamShardHandle fakeToBeConsumedShard=getMockStreamShard("fakeStream",0);
    LinkedList<KinesisStreamShardState> subscribedShardsStateUnderTest=new LinkedList<>();
    subscribedShardsStateUnderTest.add(new KinesisStreamShardState(KinesisDataFetcher.convertToStreamShardMetadata(fakeToBeConsumedShard),fakeToBeConsumedShard,new SequenceNumber("fakeStartingState")));
    TestSourceContext<String> sourceContext=new TestSourceContext<>();
    TestableKinesisDataFetcher<String> fetcher=new TestableKinesisDataFetcher<>(Collections.singletonList("fakeStream"),sourceContext,new Properties(),new KinesisDeserializationSchemaWrapper<>(new SimpleStringSchema()),10,2,new AtomicReference<>(),subscribedShardsStateUnderTest,KinesisDataFetcher.createInitialSubscribedStreamsToLastDiscoveredShardsState(Collections.singletonList("fakeStream")),Mockito.mock(KinesisProxyInterface.class));
    new ShardConsumer<>(fetcher,0,subscribedShardsStateUnderTest.get(0).getStreamShardHandle(),subscribedShardsStateUnderTest.get(0).getLastProcessedSequenceNum(),FakeKinesisBehavioursFactory.totalNumOfRecordsAfterNumOfGetRecordsCalls(1000,9,500L),new ShardMetricsReporter()).run();
    assertEquals(1000,sourceContext.getCollectedOutputs().size());
    assertEquals(SentinelSequenceNumber.SENTINEL_SHARD_ENDING_SEQUENCE_NUM.get(),subscribedShardsStateUnderTest.get(0).getLastProcessedSequenceNum());
  }
  @Test public void testCorrectNumOfCollectedRecordsAndUpdatedStateWithUnexpectedExpiredIterator(){
    StreamShardHandle fakeToBeConsumedShard=getMockStreamShard("fakeStream",0);
    LinkedList<KinesisStreamShardState> subscribedShardsStateUnderTest=new LinkedList<>();
    subscribedShardsStateUnderTest.add(new KinesisStreamShardState(KinesisDataFetcher.convertToStreamShardMetadata(fakeToBeConsumedShard),fakeToBeConsumedShard,new SequenceNumber("fakeStartingState")));
    TestSourceContext<String> sourceContext=new TestSourceContext<>();
    TestableKinesisDataFetcher<String> fetcher=new TestableKinesisDataFetcher<>(Collections.singletonList("fakeStream"),sourceContext,new Properties(),new KinesisDeserializationSchemaWrapper<>(new SimpleStringSchema()),10,2,new AtomicReference<>(),subscribedShardsStateUnderTest,KinesisDataFetcher.createInitialSubscribedStreamsToLastDiscoveredShardsState(Collections.singletonList("fakeStream")),Mockito.mock(KinesisProxyInterface.class));
    new ShardConsumer<>(fetcher,0,subscribedShardsStateUnderTest.get(0).getStreamShardHandle(),subscribedShardsStateUnderTest.get(0).getLastProcessedSequenceNum(),FakeKinesisBehavioursFactory.totalNumOfRecordsAfterNumOfGetRecordsCallsWithUnexpectedExpiredIterator(1000,9,7,500L),new ShardMetricsReporter()).run();
    assertEquals(1000,sourceContext.getCollectedOutputs().size());
    assertEquals(SentinelSequenceNumber.SENTINEL_SHARD_ENDING_SEQUENCE_NUM.get(),subscribedShardsStateUnderTest.get(0).getLastProcessedSequenceNum());
  }
  private static StreamShardHandle getMockStreamShard(  String streamName,  int shardId){
    return new StreamShardHandle(streamName,new Shard().withShardId(KinesisShardIdGenerator.generateFromShardOrder(shardId)).withHashKeyRange(new HashKeyRange().withStartingHashKey("0").withEndingHashKey(new BigInteger(StringUtils.repeat("FF",16),16).toString())));
  }
}
