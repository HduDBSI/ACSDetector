/** 
 * Default implementation of a  {@link CatalogTable}. 
 */
@Internal public class DefaultCatalogTable implements CatalogTable {
  private final Schema schema;
  private final @Nullable String comment;
  private final List<String> partitionKeys;
  private final Map<String,String> options;
  protected DefaultCatalogTable(  Schema schema,  @Nullable String comment,  List<String> partitionKeys,  Map<String,String> options){
    this.schema=checkNotNull(schema,"Schema must not be null.");
    this.comment=comment;
    this.partitionKeys=checkNotNull(partitionKeys,"Partition keys must not be null.");
    this.options=checkNotNull(options,"Options must not be null.");
    checkArgument(options.entrySet().stream().allMatch(e -> e.getKey() != null && e.getValue() != null),"Options cannot have null keys or values.");
  }
  @Override public Schema getUnresolvedSchema(){
    return schema;
  }
  @Override public String getComment(){
    return comment != null ? comment : "";
  }
  @Override public boolean isPartitioned(){
    return !partitionKeys.isEmpty();
  }
  @Override public List<String> getPartitionKeys(){
    return partitionKeys;
  }
  @Override public Map<String,String> getOptions(){
    return options;
  }
  @Override public CatalogBaseTable copy(){
    return new DefaultCatalogTable(schema,comment,partitionKeys,options);
  }
  @Override public CatalogTable copy(  Map<String,String> options){
    return new DefaultCatalogTable(schema,comment,partitionKeys,options);
  }
  @Override public Optional<String> getDescription(){
    return Optional.of(getComment());
  }
  @Override public Optional<String> getDetailedDescription(){
    return Optional.empty();
  }
  @Override public Map<String,String> toProperties(){
    throw new UnsupportedOperationException("Only a resolved catalog table can be serialized into a map of string properties.");
  }
  @Override public boolean equals(  Object o){
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    DefaultCatalogTable that=(DefaultCatalogTable)o;
    return schema.equals(that.schema) && Objects.equals(comment,that.comment) && partitionKeys.equals(that.partitionKeys)&& options.equals(that.options);
  }
  @Override public int hashCode(){
    return Objects.hash(schema,comment,partitionKeys,options);
  }
}
