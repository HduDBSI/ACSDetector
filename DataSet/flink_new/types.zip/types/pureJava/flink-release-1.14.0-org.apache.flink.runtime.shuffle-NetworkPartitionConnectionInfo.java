/** 
 * Remote partition connection information with index to query partition. <p>Normal connection information with network address and port for connection in case of distributed execution.
 */
public static class NetworkPartitionConnectionInfo implements PartitionConnectionInfo {
  private static final long serialVersionUID=5992534320110743746L;
  private final ConnectionID connectionID;
  @VisibleForTesting public NetworkPartitionConnectionInfo(  ConnectionID connectionID){
    this.connectionID=connectionID;
  }
  @Override public ConnectionID getConnectionId(){
    return connectionID;
  }
  static NetworkPartitionConnectionInfo fromProducerDescriptor(  ProducerDescriptor producerDescriptor,  int connectionIndex){
    InetSocketAddress address=new InetSocketAddress(producerDescriptor.getAddress(),producerDescriptor.getDataPort());
    return new NetworkPartitionConnectionInfo(new ConnectionID(address,connectionIndex));
  }
}
