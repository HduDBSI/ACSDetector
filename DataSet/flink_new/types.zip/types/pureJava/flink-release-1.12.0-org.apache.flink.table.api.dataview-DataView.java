/** 
 * A  {@link DataView} is a collection type that can be used in the accumulator of an{@link ImperativeAggregateFunction}. <p>Depending on the context in which the function is used, a  {@link DataView} can be backed by aJava heap collection or a state backend.
 * @see ListView
 * @see MapView
 */
@PublicEvolving public interface DataView {
  /** 
 * Clears the  {@link DataView} and removes all data.
 */
  void clear();
}
