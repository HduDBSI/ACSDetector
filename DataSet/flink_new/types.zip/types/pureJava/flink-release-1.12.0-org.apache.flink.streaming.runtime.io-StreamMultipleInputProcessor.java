/** 
 * Input processor for  {@link MultipleInputStreamOperator}.
 */
@Internal public final class StreamMultipleInputProcessor implements StreamInputProcessor {
  private final MultipleInputSelectionHandler inputSelectionHandler;
  private final StreamOneInputProcessor<?>[] inputProcessors;
  /** 
 * Always try to read from the first input. 
 */
  private int lastReadInputIndex=1;
  private boolean isPrepared;
  public StreamMultipleInputProcessor(  MultipleInputSelectionHandler inputSelectionHandler,  StreamOneInputProcessor<?>[] inputProcessors){
    this.inputSelectionHandler=inputSelectionHandler;
    this.inputProcessors=inputProcessors;
  }
  @Override public CompletableFuture<?> getAvailableFuture(){
    if (inputSelectionHandler.isAnyInputAvailable() || inputSelectionHandler.areAllInputsFinished()) {
      return AVAILABLE;
    }
    final CompletableFuture<?> anyInputAvailable=new CompletableFuture<>();
    for (int i=0; i < inputProcessors.length; i++) {
      if (!inputSelectionHandler.isInputFinished(i) && inputSelectionHandler.isInputSelected(i)) {
        assertNoException(inputProcessors[i].getAvailableFuture().thenRun(() -> anyInputAvailable.complete(null)));
      }
    }
    return anyInputAvailable;
  }
  @Override public InputStatus processInput() throws Exception {
    int readingInputIndex;
    if (isPrepared) {
      readingInputIndex=selectNextReadingInputIndex();
    }
 else {
      readingInputIndex=selectFirstReadingInputIndex();
    }
    if (readingInputIndex == InputSelection.NONE_AVAILABLE) {
      return InputStatus.NOTHING_AVAILABLE;
    }
    lastReadInputIndex=readingInputIndex;
    InputStatus inputStatus=inputProcessors[readingInputIndex].processInput();
    inputSelectionHandler.nextSelection();
    return inputSelectionHandler.updateStatus(inputStatus,readingInputIndex);
  }
  private int selectFirstReadingInputIndex(){
    inputSelectionHandler.nextSelection();
    isPrepared=true;
    return selectNextReadingInputIndex();
  }
  @Override public void close() throws IOException {
    IOException ex=null;
    for (    StreamOneInputProcessor<?> input : inputProcessors) {
      try {
        input.close();
      }
 catch (      IOException e) {
        ex=ExceptionUtils.firstOrSuppressed(e,ex);
      }
    }
    if (ex != null) {
      throw ex;
    }
  }
  @Override public CompletableFuture<Void> prepareSnapshot(  ChannelStateWriter channelStateWriter,  long checkpointId) throws IOException {
    CompletableFuture<?>[] inputFutures=new CompletableFuture[inputProcessors.length];
    for (int index=0; index < inputFutures.length; index++) {
      inputFutures[index]=inputProcessors[index].prepareSnapshot(channelStateWriter,checkpointId);
    }
    return CompletableFuture.allOf(inputFutures);
  }
  private int selectNextReadingInputIndex(){
    if (!inputSelectionHandler.isAnyInputAvailable()) {
      fullCheckAndSetAvailable();
    }
    int readingInputIndex=inputSelectionHandler.selectNextInputIndex(lastReadInputIndex);
    if (readingInputIndex == InputSelection.NONE_AVAILABLE) {
      return InputSelection.NONE_AVAILABLE;
    }
    if (inputSelectionHandler.shouldSetAvailableForAnotherInput()) {
      fullCheckAndSetAvailable();
    }
    return readingInputIndex;
  }
  private void fullCheckAndSetAvailable(){
    for (int i=0; i < inputProcessors.length; i++) {
      StreamOneInputProcessor<?> inputProcessor=inputProcessors[i];
      if (inputProcessor.isApproximatelyAvailable() || inputProcessor.isAvailable()) {
        inputSelectionHandler.setAvailableInput(i);
      }
    }
  }
}
