/** 
 * Standard Exception to be thrown as part of exception handling tests. Recognized by type.
 */
@SuppressWarnings("serial") public class ExpectedTestException extends RuntimeException {
  public ExpectedTestException(){
    super("Expected Test Exception");
  }
}
