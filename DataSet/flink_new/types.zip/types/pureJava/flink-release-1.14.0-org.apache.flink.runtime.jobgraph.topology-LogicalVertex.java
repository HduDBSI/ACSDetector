/** 
 * Represents a vertex in  {@link LogicalTopology}, i.e.  {@link JobVertex}. 
 */
public interface LogicalVertex extends Vertex<JobVertexID,IntermediateDataSetID,LogicalVertex,LogicalResult> {
  /** 
 * Get the input  {@link LogicalEdge}s of the vertex.
 * @return the input {@link LogicalEdge}s
 */
  Iterable<? extends LogicalEdge> getInputs();
}
