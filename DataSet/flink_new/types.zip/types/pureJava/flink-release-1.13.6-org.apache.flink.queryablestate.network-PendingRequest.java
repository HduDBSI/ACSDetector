/** 
 * A pending request queued while the channel is connecting. 
 */
private static final class PendingRequest<REQ extends MessageBody,RESP extends MessageBody> extends CompletableFuture<RESP> {
  private final REQ request;
  private PendingRequest(  REQ request){
    this.request=request;
  }
  public REQ getRequest(){
    return request;
  }
}
