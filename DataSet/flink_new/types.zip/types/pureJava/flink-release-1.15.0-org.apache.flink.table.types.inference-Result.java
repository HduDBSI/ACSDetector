/** 
 * The result of a type inference run. It contains information about how arguments need to be adapted in order to comply with the function's signature. <p>This includes casts that need to be inserted, reordering of arguments (*), or insertion of default values (*) where (*) is future work.
 */
public static final class Result {
  private final List<DataType> expectedArgumentTypes;
  private final @Nullable DataType accumulatorDataType;
  private final DataType outputDataType;
  public Result(  List<DataType> expectedArgumentTypes,  @Nullable DataType accumulatorDataType,  DataType outputDataType){
    this.expectedArgumentTypes=expectedArgumentTypes;
    this.accumulatorDataType=accumulatorDataType;
    this.outputDataType=outputDataType;
  }
  public List<DataType> getExpectedArgumentTypes(){
    return expectedArgumentTypes;
  }
  public Optional<DataType> getAccumulatorDataType(){
    return Optional.ofNullable(accumulatorDataType);
  }
  public DataType getOutputDataType(){
    return outputDataType;
  }
}
