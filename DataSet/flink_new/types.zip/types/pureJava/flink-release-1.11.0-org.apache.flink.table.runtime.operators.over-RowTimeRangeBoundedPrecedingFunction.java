/** 
 * Process Function for RANGE clause event-time bounded OVER window. <p>E.g.: SELECT rowtime, b, c, min(c) OVER (PARTITION BY b ORDER BY rowtime RANGE BETWEEN INTERVAL '4' SECOND PRECEDING AND CURRENT ROW), max(c) OVER (PARTITION BY b ORDER BY rowtime RANGE BETWEEN INTERVAL '4' SECOND PRECEDING AND CURRENT ROW) FROM T.
 */
public class RowTimeRangeBoundedPrecedingFunction<K> extends KeyedProcessFunction<K,RowData,RowData> {
  private static final long serialVersionUID=1L;
  private static final Logger LOG=LoggerFactory.getLogger(RowTimeRangeBoundedPrecedingFunction.class);
  private final GeneratedAggsHandleFunction genAggsHandler;
  private final LogicalType[] accTypes;
  private final LogicalType[] inputFieldTypes;
  private final long precedingOffset;
  private final int rowTimeIdx;
  private transient JoinedRowData output;
  private transient ValueState<Long> lastTriggeringTsState;
  private transient ValueState<RowData> accState;
  private transient ValueState<Long> cleanupTsState;
  private transient MapState<Long,List<RowData>> inputState;
  private transient AggsHandleFunction function;
  public RowTimeRangeBoundedPrecedingFunction(  GeneratedAggsHandleFunction genAggsHandler,  LogicalType[] accTypes,  LogicalType[] inputFieldTypes,  long precedingOffset,  int rowTimeIdx){
    Preconditions.checkNotNull(precedingOffset);
    this.genAggsHandler=genAggsHandler;
    this.accTypes=accTypes;
    this.inputFieldTypes=inputFieldTypes;
    this.precedingOffset=precedingOffset;
    this.rowTimeIdx=rowTimeIdx;
  }
  @Override public void open(  Configuration parameters) throws Exception {
    function=genAggsHandler.newInstance(getRuntimeContext().getUserCodeClassLoader());
    function.open(new PerKeyStateDataViewStore(getRuntimeContext()));
    output=new JoinedRowData();
    ValueStateDescriptor<Long> lastTriggeringTsDescriptor=new ValueStateDescriptor<Long>("lastTriggeringTsState",Types.LONG);
    lastTriggeringTsState=getRuntimeContext().getState(lastTriggeringTsDescriptor);
    RowDataTypeInfo accTypeInfo=new RowDataTypeInfo(accTypes);
    ValueStateDescriptor<RowData> accStateDesc=new ValueStateDescriptor<RowData>("accState",accTypeInfo);
    accState=getRuntimeContext().getState(accStateDesc);
    RowDataTypeInfo inputType=new RowDataTypeInfo(inputFieldTypes);
    ListTypeInfo<RowData> rowListTypeInfo=new ListTypeInfo<RowData>(inputType);
    MapStateDescriptor<Long,List<RowData>> inputStateDesc=new MapStateDescriptor<Long,List<RowData>>("inputState",Types.LONG,rowListTypeInfo);
    inputState=getRuntimeContext().getMapState(inputStateDesc);
    ValueStateDescriptor<Long> cleanupTsStateDescriptor=new ValueStateDescriptor<>("cleanupTsState",Types.LONG);
    this.cleanupTsState=getRuntimeContext().getState(cleanupTsStateDescriptor);
  }
  @Override public void processElement(  RowData input,  KeyedProcessFunction<K,RowData,RowData>.Context ctx,  Collector<RowData> out) throws Exception {
    long triggeringTs=input.getLong(rowTimeIdx);
    Long lastTriggeringTs=lastTriggeringTsState.value();
    if (lastTriggeringTs == null) {
      lastTriggeringTs=0L;
    }
    if (triggeringTs > lastTriggeringTs) {
      List<RowData> data=inputState.get(triggeringTs);
      if (null != data) {
        data.add(input);
        inputState.put(triggeringTs,data);
      }
 else {
        data=new ArrayList<RowData>();
        data.add(input);
        inputState.put(triggeringTs,data);
        ctx.timerService().registerEventTimeTimer(triggeringTs);
      }
      registerCleanupTimer(ctx,triggeringTs);
    }
  }
  private void registerCleanupTimer(  KeyedProcessFunction<K,RowData,RowData>.Context ctx,  long timestamp) throws Exception {
    long minCleanupTimestamp=timestamp + precedingOffset + 1;
    long maxCleanupTimestamp=timestamp + (long)(precedingOffset * 1.5) + 1;
    Long curCleanupTimestamp=cleanupTsState.value();
    if (curCleanupTimestamp == null || curCleanupTimestamp < minCleanupTimestamp) {
      ctx.timerService().registerEventTimeTimer(maxCleanupTimestamp);
      cleanupTsState.update(maxCleanupTimestamp);
    }
  }
  @Override public void onTimer(  long timestamp,  KeyedProcessFunction<K,RowData,RowData>.OnTimerContext ctx,  Collector<RowData> out) throws Exception {
    Long cleanupTimestamp=cleanupTsState.value();
    if (cleanupTimestamp != null && cleanupTimestamp <= timestamp) {
      inputState.clear();
      accState.clear();
      lastTriggeringTsState.clear();
      cleanupTsState.clear();
      function.cleanup();
      return;
    }
    List<RowData> inputs=inputState.get(timestamp);
    if (null != inputs) {
      int dataListIndex=0;
      RowData accumulators=accState.value();
      if (null == accumulators) {
        accumulators=function.createAccumulators();
      }
      function.setAccumulators(accumulators);
      List<Long> retractTsList=new ArrayList<Long>();
      Iterator<Long> dataTimestampIt=inputState.keys().iterator();
      while (dataTimestampIt.hasNext()) {
        Long dataTs=dataTimestampIt.next();
        Long offset=timestamp - dataTs;
        if (offset > precedingOffset) {
          List<RowData> retractDataList=inputState.get(dataTs);
          if (retractDataList != null) {
            dataListIndex=0;
            while (dataListIndex < retractDataList.size()) {
              RowData retractRow=retractDataList.get(dataListIndex);
              function.retract(retractRow);
              dataListIndex+=1;
            }
            retractTsList.add(dataTs);
          }
 else {
            LOG.warn("The state is cleared because of state ttl. " + "This will result in incorrect result. " + "You can increase the state ttl to avoid this.");
          }
        }
      }
      dataListIndex=0;
      while (dataListIndex < inputs.size()) {
        RowData curRow=inputs.get(dataListIndex);
        function.accumulate(curRow);
        dataListIndex+=1;
      }
      RowData aggValue=function.getValue();
      dataListIndex=0;
      while (dataListIndex < inputs.size()) {
        RowData curRow=inputs.get(dataListIndex);
        output.replace(curRow,aggValue);
        out.collect(output);
        dataListIndex+=1;
      }
      dataListIndex=0;
      while (dataListIndex < retractTsList.size()) {
        inputState.remove(retractTsList.get(dataListIndex));
        dataListIndex+=1;
      }
      accumulators=function.getAccumulators();
      accState.update(accumulators);
    }
    lastTriggeringTsState.update(timestamp);
  }
  @Override public void close() throws Exception {
    if (null != function) {
      function.close();
    }
  }
}
