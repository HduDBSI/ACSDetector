public class RpcCheckpointResponder implements CheckpointResponder {
  private final CheckpointCoordinatorGateway checkpointCoordinatorGateway;
  public RpcCheckpointResponder(  CheckpointCoordinatorGateway checkpointCoordinatorGateway){
    this.checkpointCoordinatorGateway=Preconditions.checkNotNull(checkpointCoordinatorGateway);
  }
  @Override public void acknowledgeCheckpoint(  JobID jobID,  ExecutionAttemptID executionAttemptID,  long checkpointId,  CheckpointMetrics checkpointMetrics,  TaskStateSnapshot subtaskState){
    checkpointCoordinatorGateway.acknowledgeCheckpoint(jobID,executionAttemptID,checkpointId,checkpointMetrics,subtaskState);
  }
  @Override public void declineCheckpoint(  JobID jobID,  ExecutionAttemptID executionAttemptID,  long checkpointId,  Throwable cause){
    checkpointCoordinatorGateway.declineCheckpoint(new DeclineCheckpoint(jobID,executionAttemptID,checkpointId,cause));
  }
}
