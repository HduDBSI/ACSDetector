/** 
 * {@link MetricReporter} that exports {@link Metric Metrics} via Prometheus {@link PushGateway}.
 */
@PublicEvolving @InstantiateViaFactory(factoryClassName="org.apache.flink.metrics.prometheus.PrometheusPushGatewayReporterFactory") public class PrometheusPushGatewayReporter extends AbstractPrometheusReporter implements Scheduled {
  private final PushGateway pushGateway;
  private final String jobName;
  private final Map<String,String> groupingKey;
  private final boolean deleteOnShutdown;
  PrometheusPushGatewayReporter(  String host,  int port,  String jobName,  Map<String,String> groupingKey,  final boolean deleteOnShutdown){
    this.pushGateway=new PushGateway(host + ':' + port);
    this.jobName=Preconditions.checkNotNull(jobName);
    this.groupingKey=Preconditions.checkNotNull(groupingKey);
    this.deleteOnShutdown=deleteOnShutdown;
  }
  @Override public void report(){
    try {
      pushGateway.push(CollectorRegistry.defaultRegistry,jobName,groupingKey);
    }
 catch (    Exception e) {
      log.warn("Failed to push metrics to PushGateway with jobName {}, groupingKey {}.",jobName,groupingKey,e);
    }
  }
  @Override public void close(){
    if (deleteOnShutdown && pushGateway != null) {
      try {
        pushGateway.delete(jobName,groupingKey);
      }
 catch (      IOException e) {
        log.warn("Failed to delete metrics from PushGateway with jobName {}, groupingKey {}.",jobName,groupingKey,e);
      }
    }
    super.close();
  }
}
