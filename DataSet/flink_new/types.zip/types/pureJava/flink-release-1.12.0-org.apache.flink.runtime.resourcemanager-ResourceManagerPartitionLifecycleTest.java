/** 
 * Tests for the partition-lifecycle logic in the  {@link ResourceManager}.
 */
public class ResourceManagerPartitionLifecycleTest extends TestLogger {
  private static final Time TIMEOUT=Time.minutes(2L);
  private static TestingRpcService rpcService;
  private TestingHighAvailabilityServices highAvailabilityServices;
  private TestingLeaderElectionService resourceManagerLeaderElectionService;
  private TestingFatalErrorHandler testingFatalErrorHandler;
  private TestingResourceManager resourceManager;
  @BeforeClass public static void setupClass(){
    rpcService=new TestingRpcService();
  }
  @Before public void setup() throws Exception {
    highAvailabilityServices=new TestingHighAvailabilityServices();
    resourceManagerLeaderElectionService=new TestingLeaderElectionService();
    highAvailabilityServices.setResourceManagerLeaderElectionService(resourceManagerLeaderElectionService);
    testingFatalErrorHandler=new TestingFatalErrorHandler();
  }
  @After public void after() throws Exception {
    if (resourceManager != null) {
      RpcUtils.terminateRpcEndpoint(resourceManager,TIMEOUT);
    }
    if (highAvailabilityServices != null) {
      highAvailabilityServices.closeAndCleanupAllData();
    }
    if (testingFatalErrorHandler.hasExceptionOccurred()) {
      testingFatalErrorHandler.rethrowError();
    }
  }
  @AfterClass public static void tearDownClass() throws Exception {
    if (rpcService != null) {
      RpcUtils.terminateRpcServices(TIMEOUT,rpcService);
    }
  }
  @Test public void testClusterPartitionReportHandling() throws Exception {
    final CompletableFuture<Collection<IntermediateDataSetID>> clusterPartitionReleaseFuture=new CompletableFuture<>();
    runTest(builder -> builder.setReleaseClusterPartitionsConsumer(clusterPartitionReleaseFuture::complete),(resourceManagerGateway,taskManagerId1,ignored) -> {
      IntermediateDataSetID dataSetID=new IntermediateDataSetID();
      ResultPartitionID resultPartitionID=new ResultPartitionID();
      resourceManagerGateway.heartbeatFromTaskManager(taskManagerId1,createTaskExecutorHeartbeatPayload(dataSetID,2,resultPartitionID,new ResultPartitionID()));
      resourceManagerGateway.heartbeatFromTaskManager(taskManagerId1,createTaskExecutorHeartbeatPayload(dataSetID,2,resultPartitionID));
      Collection<IntermediateDataSetID> intermediateDataSetIDS=clusterPartitionReleaseFuture.get(TIMEOUT.toMilliseconds(),TimeUnit.MILLISECONDS);
      assertThat(intermediateDataSetIDS,contains(dataSetID));
    }
);
  }
  @Test public void testTaskExecutorShutdownHandling() throws Exception {
    final CompletableFuture<Collection<IntermediateDataSetID>> clusterPartitionReleaseFuture=new CompletableFuture<>();
    runTest(builder -> builder.setReleaseClusterPartitionsConsumer(clusterPartitionReleaseFuture::complete),(resourceManagerGateway,taskManagerId1,taskManagerId2) -> {
      IntermediateDataSetID dataSetID=new IntermediateDataSetID();
      resourceManagerGateway.heartbeatFromTaskManager(taskManagerId1,createTaskExecutorHeartbeatPayload(dataSetID,2,new ResultPartitionID()));
      resourceManagerGateway.heartbeatFromTaskManager(taskManagerId2,createTaskExecutorHeartbeatPayload(dataSetID,2,new ResultPartitionID()));
      resourceManagerGateway.disconnectTaskManager(taskManagerId2,new RuntimeException("test exception"));
      Collection<IntermediateDataSetID> intermediateDataSetIDS=clusterPartitionReleaseFuture.get(TIMEOUT.toMilliseconds(),TimeUnit.MILLISECONDS);
      assertThat(intermediateDataSetIDS,contains(dataSetID));
    }
);
  }
  private void runTest(  TaskExecutorSetup taskExecutorBuilderSetup,  TestAction testAction) throws Exception {
    final ResourceManagerGateway resourceManagerGateway=createAndStartResourceManager();
    TestingTaskExecutorGatewayBuilder testingTaskExecutorGateway1Builder=new TestingTaskExecutorGatewayBuilder();
    taskExecutorBuilderSetup.accept(testingTaskExecutorGateway1Builder);
    final TaskExecutorGateway taskExecutorGateway1=testingTaskExecutorGateway1Builder.setAddress(UUID.randomUUID().toString()).createTestingTaskExecutorGateway();
    rpcService.registerGateway(taskExecutorGateway1.getAddress(),taskExecutorGateway1);
    final TaskExecutorGateway taskExecutorGateway2=new TestingTaskExecutorGatewayBuilder().setAddress(UUID.randomUUID().toString()).createTestingTaskExecutorGateway();
    rpcService.registerGateway(taskExecutorGateway2.getAddress(),taskExecutorGateway2);
    final ResourceID taskManagerId1=ResourceID.generate();
    final ResourceID taskManagerId2=ResourceID.generate();
    registerTaskExecutor(resourceManagerGateway,taskManagerId1,taskExecutorGateway1.getAddress());
    registerTaskExecutor(resourceManagerGateway,taskManagerId2,taskExecutorGateway2.getAddress());
    testAction.accept(resourceManagerGateway,taskManagerId1,taskManagerId2);
  }
  public static void registerTaskExecutor(  ResourceManagerGateway resourceManagerGateway,  ResourceID taskExecutorId,  String taskExecutorAddress) throws Exception {
    final TaskExecutorRegistration taskExecutorRegistration=new TaskExecutorRegistration(taskExecutorAddress,taskExecutorId,1234,23456,new HardwareDescription(42,1337L,1337L,0L),new TaskExecutorMemoryConfiguration(1L,2L,3L,4L,5L,6L,7L,8L,9L,10L),ResourceProfile.ZERO,ResourceProfile.ZERO);
    final CompletableFuture<RegistrationResponse> registrationFuture=resourceManagerGateway.registerTaskExecutor(taskExecutorRegistration,TestingUtils.TIMEOUT());
    assertThat(registrationFuture.get(),instanceOf(RegistrationResponse.Success.class));
  }
  private ResourceManagerGateway createAndStartResourceManager() throws Exception {
    final SlotManager slotManager=SlotManagerBuilder.newBuilder().setScheduledExecutor(rpcService.getScheduledExecutor()).build();
    final JobLeaderIdService jobLeaderIdService=new JobLeaderIdService(highAvailabilityServices,rpcService.getScheduledExecutor(),TestingUtils.infiniteTime());
    final TestingResourceManager resourceManager=new TestingResourceManager(rpcService,ResourceID.generate(),highAvailabilityServices,new HeartbeatServices(100000L,1000000L),slotManager,ResourceManagerPartitionTrackerImpl::new,jobLeaderIdService,testingFatalErrorHandler,UnregisteredMetricGroups.createUnregisteredResourceManagerMetricGroup());
    resourceManager.start();
    resourceManagerLeaderElectionService.isLeader(ResourceManagerId.generate().toUUID()).get();
    this.resourceManager=resourceManager;
    return resourceManager.getSelfGateway(ResourceManagerGateway.class);
  }
  private static TaskExecutorHeartbeatPayload createTaskExecutorHeartbeatPayload(  IntermediateDataSetID dataSetId,  int numTotalPartitions,  ResultPartitionID... partitionIds){
    return new TaskExecutorHeartbeatPayload(new SlotReport(),new ClusterPartitionReport(Collections.singletonList(new ClusterPartitionReport.ClusterPartitionReportEntry(dataSetId,new HashSet<>(Arrays.asList(partitionIds)),numTotalPartitions))));
  }
@FunctionalInterface private interface TaskExecutorSetup {
    void accept(    TestingTaskExecutorGatewayBuilder taskExecutorGatewayBuilder) throws Exception ;
  }
@FunctionalInterface private interface TestAction {
    void accept(    ResourceManagerGateway resourceManagerGateway,    ResourceID taskExecutorId1,    ResourceID taskExecutorId2) throws Exception ;
  }
}
