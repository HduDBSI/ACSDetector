/** 
 * An  {@link InputSelectable} that indicates which input contain the current smallest element ofall sorting inputs. Should be used by the  {@link StreamInputProcessor} to choose the nextinput to consume from.
 */
private static class InputSelector implements InputSelectable, BoundedMultiInput {
  private final CommonContext commonContext;
  private final int numInputs;
  private final Queue<Integer> passThroughInputsIndices;
  private InputSelector(  CommonContext commonContext,  int numInputs,  List<Integer> passThroughInputIndices){
    this.commonContext=commonContext;
    this.numInputs=numInputs;
    this.passThroughInputsIndices=new LinkedList<>(passThroughInputIndices);
  }
  @Override public void endInput(  int inputId) throws Exception {
    passThroughInputsIndices.remove(inputId);
  }
  @Override public InputSelection nextSelection(){
    Integer currentPassThroughInputIndex=passThroughInputsIndices.peek();
    if (currentPassThroughInputIndex != null) {
      return new InputSelection.Builder().select(currentPassThroughInputIndex + 1).build(numInputs);
    }
    if (commonContext.allSorted()) {
      HeadElement headElement=commonContext.getQueueOfHeads().peek();
      if (headElement != null) {
        int headIdx=headElement.inputIndex;
        return new InputSelection.Builder().select(headIdx + 1).build(numInputs);
      }
    }
    return InputSelection.ALL;
  }
}
