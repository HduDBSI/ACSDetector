/** 
 * {@link org.apache.flink.runtime.dispatcher.Dispatcher.JobManagerRunnerFactory} implementation fortesting purposes.
 */
class TestingJobManagerRunnerFactory implements Dispatcher.JobManagerRunnerFactory {
  private final CompletableFuture<JobGraph> jobGraphFuture;
  private final CompletableFuture<ArchivedExecutionGraph> resultFuture;
  private final CompletableFuture<Void> terminationFuture;
  TestingJobManagerRunnerFactory(  CompletableFuture<JobGraph> jobGraphFuture,  CompletableFuture<ArchivedExecutionGraph> resultFuture,  CompletableFuture<Void> terminationFuture){
    this.jobGraphFuture=jobGraphFuture;
    this.resultFuture=resultFuture;
    this.terminationFuture=terminationFuture;
  }
  @Override public JobManagerRunner createJobManagerRunner(  ResourceID resourceId,  JobGraph jobGraph,  Configuration configuration,  RpcService rpcService,  HighAvailabilityServices highAvailabilityServices,  HeartbeatServices heartbeatServices,  BlobServer blobServer,  JobManagerSharedServices jobManagerSharedServices,  JobManagerJobMetricGroupFactory jobManagerJobMetricGroupFactory,  FatalErrorHandler fatalErrorHandler) throws Exception {
    jobGraphFuture.complete(jobGraph);
    final JobManagerRunner mock=mock(JobManagerRunner.class);
    when(mock.getResultFuture()).thenReturn(resultFuture);
    when(mock.closeAsync()).thenReturn(terminationFuture);
    when(mock.getJobGraph()).thenReturn(jobGraph);
    return mock;
  }
}
