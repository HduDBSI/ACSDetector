/** 
 * Unit tests for  {@link SourceCoordinatorProvider}. 
 */
public class SourceCoordinatorProviderTest {
  private static final OperatorID OPERATOR_ID=new OperatorID(1234L,5678L);
  private static final int NUM_SPLITS=10;
  private SourceCoordinatorProvider<MockSourceSplit> provider;
  @Before public void setup(){
    provider=new SourceCoordinatorProvider<>("SourceCoordinatorProviderTest",OPERATOR_ID,new MockSource(Boundedness.BOUNDED,NUM_SPLITS),1);
  }
  @Test public void testCreate() throws Exception {
    OperatorCoordinator coordinator=provider.create(new MockOperatorCoordinatorContext(OPERATOR_ID,NUM_SPLITS));
    assertTrue(coordinator instanceof RecreateOnResetOperatorCoordinator);
  }
  @Test public void testCheckpointAndReset() throws Exception {
    final OperatorCoordinator.Context context=new MockOperatorCoordinatorContext(OPERATOR_ID,NUM_SPLITS);
    final RecreateOnResetOperatorCoordinator coordinator=(RecreateOnResetOperatorCoordinator)provider.create(context);
    final SourceCoordinator<?,?> sourceCoordinator=(SourceCoordinator<?,?>)coordinator.getInternalCoordinator();
    coordinator.start();
    coordinator.handleEventFromOperator(0,new ReaderRegistrationEvent(0,"location"));
    CompletableFuture<byte[]> future=new CompletableFuture<>();
    coordinator.checkpointCoordinator(0L,future);
    byte[] bytes=future.get();
    coordinator.handleEventFromOperator(1,new ReaderRegistrationEvent(1,"location"));
    while (sourceCoordinator.getContext().registeredReaders().size() < 2) {
      Thread.sleep(1);
    }
    coordinator.resetToCheckpoint(0L,bytes);
    final SourceCoordinator<?,?> restoredSourceCoordinator=(SourceCoordinator<?,?>)coordinator.getInternalCoordinator();
    assertNotEquals("The restored source coordinator should be a different instance",restoredSourceCoordinator,sourceCoordinator);
    assertEquals("There should only be one registered reader.",1,restoredSourceCoordinator.getContext().registeredReaders().size());
    assertNotNull("The only registered reader should be reader 0",restoredSourceCoordinator.getContext().registeredReaders().get(0));
  }
  @Test public void testCallAsyncExceptionFailsJob() throws Exception {
    MockOperatorCoordinatorContext context=new MockOperatorCoordinatorContext(OPERATOR_ID,NUM_SPLITS);
    RecreateOnResetOperatorCoordinator coordinator=(RecreateOnResetOperatorCoordinator)provider.create(context);
    SourceCoordinator<?,?> sourceCoordinator=(SourceCoordinator<?,?>)coordinator.getInternalCoordinator();
    sourceCoordinator.getContext().callAsync(() -> null,(ignored,e) -> {
      throw new RuntimeException();
    }
);
    CommonTestUtils.waitUtil(context::isJobFailed,Duration.ofSeconds(10L),"The job did not fail before timeout.");
  }
}
