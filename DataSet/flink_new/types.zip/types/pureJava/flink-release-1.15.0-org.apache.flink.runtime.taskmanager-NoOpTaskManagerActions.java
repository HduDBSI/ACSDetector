/** 
 * Dummy implementation of  {@link TaskManagerActions}. 
 */
public class NoOpTaskManagerActions implements TaskManagerActions {
  @Override public void notifyFatalError(  String message,  Throwable cause){
  }
  @Override public void failTask(  ExecutionAttemptID executionAttemptID,  Throwable cause){
  }
  @Override public void updateTaskExecutionState(  TaskExecutionState taskExecutionState){
  }
}
