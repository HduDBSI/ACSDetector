/** 
 * Executor which executes runnables in the main thread context.
 */
protected static class MainThreadExecutor implements Executor {
  private final MainThreadExecutable gateway;
  MainThreadExecutor(  MainThreadExecutable gateway){
    this.gateway=Preconditions.checkNotNull(gateway);
  }
  @Override public void execute(  @Nonnull Runnable runnable){
    gateway.runAsync(runnable);
  }
}
