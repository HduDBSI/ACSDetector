/** 
 * {@link SubmittedJobGraphStore} implementation for a single job.
 */
public class SingleJobSubmittedJobGraphStore implements SubmittedJobGraphStore {
  private final JobGraph jobGraph;
  public SingleJobSubmittedJobGraphStore(  JobGraph jobGraph){
    this.jobGraph=Preconditions.checkNotNull(jobGraph);
  }
  @Override public void start(  SubmittedJobGraphListener jobGraphListener) throws Exception {
  }
  @Override public void stop() throws Exception {
  }
  @Override public SubmittedJobGraph recoverJobGraph(  JobID jobId) throws Exception {
    if (jobGraph.getJobID().equals(jobId)) {
      return new SubmittedJobGraph(jobGraph);
    }
 else {
      throw new FlinkException("Could not recover job graph " + jobId + '.');
    }
  }
  @Override public void putJobGraph(  SubmittedJobGraph jobGraph) throws Exception {
    if (!this.jobGraph.getJobID().equals(jobGraph.getJobId())) {
      throw new FlinkException("Cannot put additional jobs into this submitted job graph store.");
    }
  }
  @Override public void removeJobGraph(  JobID jobId){
  }
  @Override public void releaseJobGraph(  JobID jobId){
  }
  @Override public Collection<JobID> getJobIds(){
    return Collections.singleton(jobGraph.getJobID());
  }
}
