public class GenericTypeInfo<T> extends TypeInformation<T> implements AtomicType<T> {
  private static final long serialVersionUID=-7959114120287706504L;
  private final Class<T> typeClass;
  public GenericTypeInfo(  Class<T> typeClass){
    this.typeClass=typeClass;
  }
  @Override public boolean isBasicType(){
    return false;
  }
  @Override public boolean isTupleType(){
    return false;
  }
  @Override public int getArity(){
    return 1;
  }
  @Override public int getTotalFields(){
    return 1;
  }
  @Override public Class<T> getTypeClass(){
    return typeClass;
  }
  @Override public boolean isKeyType(){
    return Comparable.class.isAssignableFrom(typeClass);
  }
  @Override public TypeSerializer<T> createSerializer(  ExecutionConfig config){
    return new KryoSerializer<T>(this.typeClass,config);
  }
  @SuppressWarnings("unchecked") @Override public TypeComparator<T> createComparator(  boolean sortOrderAscending,  ExecutionConfig executionConfig){
    if (isKeyType()) {
      @SuppressWarnings("rawtypes") GenericTypeComparator comparator=new GenericTypeComparator(sortOrderAscending,createSerializer(executionConfig),this.typeClass);
      return (TypeComparator<T>)comparator;
    }
    throw new UnsupportedOperationException("Types that do not implement java.lang.Comparable cannot be used as keys.");
  }
  @Override public int hashCode(){
    return typeClass.hashCode() ^ 0x165667b1;
  }
  @Override public boolean equals(  Object obj){
    if (obj.getClass() == GenericTypeInfo.class) {
      return typeClass == ((GenericTypeInfo<?>)obj).typeClass;
    }
 else {
      return false;
    }
  }
  @Override public String toString(){
    return "GenericType<" + typeClass.getCanonicalName() + ">";
  }
}
