/** 
 * Input reader for  {@link org.apache.flink.streaming.runtime.tasks.OneInputStreamTask}.
 * @param < IN > The type of the record that can be read with this record reader.
 */
@Internal public final class StreamOneInputProcessor<IN> implements StreamInputProcessor {
  private static final Logger LOG=LoggerFactory.getLogger(StreamOneInputProcessor.class);
  private final StreamTaskInput<IN> input;
  private final DataOutput<IN> output;
  private final BoundedMultiInput endOfInputAware;
  public StreamOneInputProcessor(  StreamTaskInput<IN> input,  DataOutput<IN> output,  BoundedMultiInput endOfInputAware){
    this.input=checkNotNull(input);
    this.output=checkNotNull(output);
    this.endOfInputAware=checkNotNull(endOfInputAware);
  }
  @Override public CompletableFuture<?> getAvailableFuture(){
    return input.getAvailableFuture();
  }
  @Override public InputStatus processInput() throws Exception {
    InputStatus status=input.emitNext(output);
    if (status == InputStatus.END_OF_INPUT) {
      endOfInputAware.endInput(input.getInputIndex() + 1);
    }
    return status;
  }
  @Override public CompletableFuture<Void> prepareSnapshot(  ChannelStateWriter channelStateWriter,  long checkpointId) throws IOException {
    return input.prepareSnapshot(channelStateWriter,checkpointId);
  }
  @Override public void close() throws IOException {
    input.close();
  }
}
