/** 
 * Yarn application master which starts the  {@link TestingYarnJobManager}, {@link TestingResourceManager}, and the  {@link TestingMemoryArchivist}.
 */
public class TestingApplicationMaster extends YarnApplicationMasterRunner {
  @Override public Class<? extends JobManager> getJobManagerClass(){
    return TestingYarnJobManager.class;
  }
  @Override public Class<? extends MemoryArchivist> getArchivistClass(){
    return TestingMemoryArchivist.class;
  }
  @Override protected Class<? extends TaskManager> getTaskManagerClass(){
    return TestingYarnTaskManager.class;
  }
  @Override public Class<? extends YarnFlinkResourceManager> getResourceManagerClass(){
    return TestingYarnFlinkResourceManager.class;
  }
  public static void main(  String[] args){
    EnvironmentInformation.logEnvironmentInfo(LOG,"YARN ApplicationMaster / JobManager",args);
    SignalHandler.register(LOG);
    JvmShutdownSafeguard.installAsShutdownHook(LOG);
    int returnCode=new TestingApplicationMaster().run(args);
    System.exit(returnCode);
  }
}
