/** 
 * {@link KvStateSnapshot} that asynchronously materializes the state that it represents. Insteadof representing a materialized handle to state this would normally hold the (immutable) state internally and materializes it when  {@link #materialize()} is called.
 * @param < K > The type of the key
 * @param < N > The type of the namespace
 * @param < S > The type of the {@link State}
 * @param < SD > The type of the {@link StateDescriptor}
 * @param < Backend > The type of the backend that can restore the state from this snapshot.
 */
public abstract class AsynchronousKvStateSnapshot<K,N,S extends State,SD extends StateDescriptor<S,?>,Backend extends AbstractStateBackend> implements KvStateSnapshot<K,N,S,SD,Backend> {
  private static final long serialVersionUID=1L;
  /** 
 * Materializes the state held by this  {@code AsynchronousKvStateSnapshot}.
 */
  public abstract KvStateSnapshot<K,N,S,SD,Backend> materialize() throws Exception ;
  @Override public final KvState<K,N,S,SD,Backend> restoreState(  Backend stateBackend,  TypeSerializer<K> keySerializer,  ClassLoader classLoader) throws Exception {
    throw new RuntimeException("This should never be called and probably points to a bug.");
  }
  @Override public void discardState() throws Exception {
    throw new RuntimeException("This should never be called and probably points to a bug.");
  }
  @Override public long getStateSize() throws Exception {
    throw new RuntimeException("This should never be called and probably points to a bug.");
  }
  @Override public void close() throws IOException {
    throw new RuntimeException("This should never be called and probably points to a bug.");
  }
}
