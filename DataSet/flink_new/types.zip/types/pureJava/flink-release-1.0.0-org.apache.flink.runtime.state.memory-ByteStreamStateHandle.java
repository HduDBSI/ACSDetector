/** 
 * A state handle that contains stream state in a byte array.
 */
public final class ByteStreamStateHandle implements StreamStateHandle {
  private static final long serialVersionUID=-5280226231200217594L;
  /** 
 * the state data 
 */
  private final byte[] data;
  /** 
 * Creates a new ByteStreamStateHandle containing the given data.
 * @param data The state data.
 */
  public ByteStreamStateHandle(  byte[] data){
    this.data=data;
  }
  @Override public InputStream getState(  ClassLoader userCodeClassLoader){
    return new ByteArrayInputStream(data);
  }
  @Override public void discardState(){
  }
  @Override public long getStateSize(){
    return data.length;
  }
  @Override public <T extends Serializable>StateHandle<T> toSerializableHandle(){
    return new SerializedStateHandle<T>(data);
  }
}
