/** 
 * Converts a variable length field of a byte array into a  {@link String}. The byte contents between delimiters is interpreted as an ASCII string. The string may be quoted in double quotes. For quoted strings, whitespaces (space and tab) leading and trailing before and after the quotes are removed.
 */
public class StringParser extends FieldParser<String> {
  private static final byte WHITESPACE_SPACE=(byte)' ';
  private static final byte WHITESPACE_TAB=(byte)'\t';
  private static final byte QUOTE_DOUBLE=(byte)'"';
  private static enum ParserStates {  NONE,   IN_QUOTE,   STOP}
  private String result;
  @Override public int parseField(  byte[] bytes,  int startPos,  int limit,  char delim,  String reusable){
    int i=startPos;
    final byte delByte=(byte)delim;
    byte current;
    while (i < limit && ((current=bytes[i]) == WHITESPACE_SPACE || current == WHITESPACE_TAB)) {
      i++;
    }
    ParserStates parserState=ParserStates.NONE;
    int endOfCellPosition=i - 1;
    while (parserState != ParserStates.STOP && endOfCellPosition < limit) {
      endOfCellPosition++;
      if (endOfCellPosition == limit) {
        break;
      }
      current=bytes[endOfCellPosition];
      if (current == delByte) {
        parserState=parserState == ParserStates.IN_QUOTE ? parserState : ParserStates.STOP;
      }
 else       if (current == QUOTE_DOUBLE) {
        if (parserState == ParserStates.IN_QUOTE) {
          parserState=ParserStates.NONE;
        }
 else {
          parserState=ParserStates.IN_QUOTE;
        }
      }
    }
    if (parserState == ParserStates.IN_QUOTE) {
      setErrorState(ParseErrorState.UNTERMINATED_QUOTED_STRING);
      return -1;
    }
    if (i < limit && bytes[i] == QUOTE_DOUBLE) {
      current=bytes[endOfCellPosition - 1];
      if (!(current == WHITESPACE_SPACE || current == WHITESPACE_TAB || current == QUOTE_DOUBLE)) {
        setErrorState(ParseErrorState.UNQUOTED_CHARS_AFTER_QUOTED_STRING);
        return -1;
      }
      int skipAtEnd=0;
      while (bytes[endOfCellPosition - 1 - skipAtEnd] == WHITESPACE_SPACE || bytes[endOfCellPosition - 1 - skipAtEnd] == WHITESPACE_TAB) {
        skipAtEnd++;
      }
      boolean notEscaped=true;
      int endOfContent=i + 1;
      for (int counter=endOfContent; counter < endOfCellPosition - skipAtEnd; counter++) {
        notEscaped=bytes[counter] != QUOTE_DOUBLE || !notEscaped;
        if (notEscaped) {
          bytes[endOfContent++]=bytes[counter];
        }
      }
      this.result=new String(bytes,i + 1,endOfContent - i - 1);
      return (endOfCellPosition == limit ? limit : endOfCellPosition + 1);
    }
 else {
      this.result=new String(bytes,i,endOfCellPosition - i);
      return (endOfCellPosition == limit ? limit : endOfCellPosition + 1);
    }
  }
  @Override public String createValue(){
    return "";
  }
  @Override public String getLastResult(){
    return this.result;
  }
}
