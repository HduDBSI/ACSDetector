/** 
 * The offset window frame calculates frames containing LEAD/LAG statements. <p>See  {@code LeadLagAggFunction}.
 */
public class OffsetOverFrame implements OverWindowFrame {
  private GeneratedAggsHandleFunction aggsHandleFunction;
  private final Long offset;
  private final CalcOffsetFunc calcOffsetFunc;
  private AggsHandleFunction processor;
  private ResettableExternalBuffer.BufferIterator inputIterator;
  private long inputIndex=0L;
  private ResettableExternalBuffer externalBuffer;
  private long currentBufferLength=0L;
  /** 
 * @param aggsHandleFunction the aggregate function
 * @param offset it means the offset within a partition if calcOffsetFunc is null.
 * @param calcOffsetFunc calculate the real offset when the function is not null.
 */
  public OffsetOverFrame(  GeneratedAggsHandleFunction aggsHandleFunction,  Long offset,  CalcOffsetFunc calcOffsetFunc){
    this.aggsHandleFunction=aggsHandleFunction;
    this.offset=offset;
    this.calcOffsetFunc=calcOffsetFunc;
  }
  @Override public void open(  ExecutionContext ctx) throws Exception {
    processor=aggsHandleFunction.newInstance(ctx.getRuntimeContext().getUserCodeClassLoader());
    processor.open(new PerKeyStateDataViewStore(ctx.getRuntimeContext()));
    this.aggsHandleFunction=null;
  }
  @Override public void prepare(  ResettableExternalBuffer rows) throws Exception {
    processor.setAccumulators(processor.createAccumulators());
    currentBufferLength=rows.size();
    if (calcOffsetFunc == null) {
      inputIndex=offset;
      if (inputIterator != null) {
        inputIterator.close();
      }
      if (offset >= 0) {
        inputIterator=rows.newIterator((int)inputIndex);
      }
 else {
        inputIterator=rows.newIterator();
      }
    }
 else {
      externalBuffer=rows;
    }
  }
  @Override public RowData process(  int index,  RowData current) throws Exception {
    if (calcOffsetFunc != null) {
      long realIndex=calcOffsetFunc.calc(current) + index;
      if (realIndex >= 0 && realIndex < currentBufferLength) {
        ResettableExternalBuffer.BufferIterator tempIterator=externalBuffer.newIterator((int)realIndex);
        processor.accumulate(OverWindowFrame.getNextOrNull(tempIterator));
        tempIterator.close();
      }
 else {
        processor.retract(current);
      }
    }
 else {
      if (inputIndex >= 0 && inputIndex < currentBufferLength) {
        processor.accumulate(OverWindowFrame.getNextOrNull(inputIterator));
      }
 else {
        processor.retract(current);
      }
      inputIndex+=1;
    }
    return processor.getValue();
  }
  /** 
 * Calc offset from base row. 
 */
public interface CalcOffsetFunc extends Serializable {
    long calc(    RowData row);
  }
}
