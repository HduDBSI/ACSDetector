/** 
 * {@link AbstractInvokable} which throws {@link RuntimeException} on invoke.
 */
public static final class InvokableWithExceptionOnTrigger extends AbstractInvokable {
  public InvokableWithExceptionOnTrigger(  Environment environment){
    super(environment);
  }
  @Override public void invoke(){
    awaitLatch.trigger();
    while (true) {
      try {
        triggerLatch.await();
        break;
      }
 catch (      InterruptedException e) {
      }
    }
    throw new RuntimeException("test");
  }
}
