/** 
 * Throws a validator exception with access to the validator context. The exception is determined when an instance is created.
 */
private class ValidationError implements Supplier<CalciteContextException> {
  private final SqlNode sqlNode;
  private final Resources.ExInst<SqlValidatorException> validatorException;
  ValidationError(  SqlNode sqlNode,  Resources.ExInst<SqlValidatorException> validatorException){
    this.sqlNode=sqlNode;
    this.validatorException=validatorException;
  }
  public CalciteContextException get(){
    return newValidationError(sqlNode,validatorException);
  }
}
