public class EvictingWindowOperatorTest {
  @Test @SuppressWarnings("unchecked") public void testCountTrigger() throws Exception {
    final int WINDOW_SIZE=4;
    final int WINDOW_SLIDE=2;
    TypeInformation<Tuple2<String,Integer>> inputType=TypeInfoParser.parse("Tuple2<String, Integer>");
    ListStateDescriptor<StreamRecord<Tuple2<String,Integer>>> stateDesc=new ListStateDescriptor<>("window-contents",new StreamRecordSerializer<>(inputType.createSerializer(new ExecutionConfig())));
    EvictingWindowOperator<String,Tuple2<String,Integer>,Tuple2<String,Integer>,GlobalWindow> operator=new EvictingWindowOperator<>(GlobalWindows.create(),new GlobalWindow.Serializer(),new TupleKeySelector(),BasicTypeInfo.STRING_TYPE_INFO.createSerializer(new ExecutionConfig()),stateDesc,new InternalIterableWindowFunction<>(new ReduceIterableWindowFunction<String,GlobalWindow,Tuple2<String,Integer>>(new SumReducer())),CountTrigger.of(WINDOW_SLIDE),CountEvictor.of(WINDOW_SIZE),0);
    operator.setInputType(inputType,new ExecutionConfig());
    OneInputStreamOperatorTestHarness<Tuple2<String,Integer>,Tuple2<String,Integer>> testHarness=new OneInputStreamOperatorTestHarness<>(operator);
    testHarness.configureForKeyedStream(new TupleKeySelector(),BasicTypeInfo.STRING_TYPE_INFO);
    long initialTime=0L;
    ConcurrentLinkedQueue<Object> expectedOutput=new ConcurrentLinkedQueue<>();
    testHarness.open();
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key2",1),initialTime + 3000));
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key2",1),initialTime + 3999));
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key1",1),initialTime + 20));
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key1",1),initialTime));
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key1",1),initialTime + 999));
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key2",1),initialTime + 1998));
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key2",1),initialTime + 1999));
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key2",1),initialTime + 1000));
    expectedOutput.add(new StreamRecord<>(new Tuple2<>("key2",2),Long.MAX_VALUE));
    expectedOutput.add(new StreamRecord<>(new Tuple2<>("key2",4),Long.MAX_VALUE));
    expectedOutput.add(new StreamRecord<>(new Tuple2<>("key1",2),Long.MAX_VALUE));
    TestHarnessUtil.assertOutputEqualsSorted("Output was not correct.",expectedOutput,testHarness.getOutput(),new ResultSortComparator());
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key1",1),initialTime + 10999));
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key2",1),initialTime + 1000));
    expectedOutput.add(new StreamRecord<>(new Tuple2<>("key1",4),Long.MAX_VALUE));
    expectedOutput.add(new StreamRecord<>(new Tuple2<>("key2",4),Long.MAX_VALUE));
    TestHarnessUtil.assertOutputEqualsSorted("Output was not correct.",expectedOutput,testHarness.getOutput(),new ResultSortComparator());
    testHarness.close();
  }
  @Test @SuppressWarnings("unchecked") public void testCountTriggerWithApply() throws Exception {
    AtomicInteger closeCalled=new AtomicInteger(0);
    final int WINDOW_SIZE=4;
    final int WINDOW_SLIDE=2;
    TypeInformation<Tuple2<String,Integer>> inputType=TypeInfoParser.parse("Tuple2<String, Integer>");
    ListStateDescriptor<StreamRecord<Tuple2<String,Integer>>> stateDesc=new ListStateDescriptor<>("window-contents",new StreamRecordSerializer<>(inputType.createSerializer(new ExecutionConfig())));
    EvictingWindowOperator<String,Tuple2<String,Integer>,Tuple2<String,Integer>,GlobalWindow> operator=new EvictingWindowOperator<>(GlobalWindows.create(),new GlobalWindow.Serializer(),new TupleKeySelector(),BasicTypeInfo.STRING_TYPE_INFO.createSerializer(new ExecutionConfig()),stateDesc,new InternalIterableWindowFunction<>(new RichSumReducer<GlobalWindow>(closeCalled)),CountTrigger.of(WINDOW_SLIDE),CountEvictor.of(WINDOW_SIZE),0);
    operator.setInputType(inputType,new ExecutionConfig());
    OneInputStreamOperatorTestHarness<Tuple2<String,Integer>,Tuple2<String,Integer>> testHarness=new OneInputStreamOperatorTestHarness<>(operator);
    testHarness.configureForKeyedStream(new TupleKeySelector(),BasicTypeInfo.STRING_TYPE_INFO);
    long initialTime=0L;
    ConcurrentLinkedQueue<Object> expectedOutput=new ConcurrentLinkedQueue<>();
    testHarness.open();
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key2",1),initialTime + 3000));
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key2",1),initialTime + 3999));
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key1",1),initialTime + 20));
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key1",1),initialTime));
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key1",1),initialTime + 999));
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key2",1),initialTime + 1998));
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key2",1),initialTime + 1999));
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key2",1),initialTime + 1000));
    expectedOutput.add(new StreamRecord<>(new Tuple2<>("key2",2),Long.MAX_VALUE));
    expectedOutput.add(new StreamRecord<>(new Tuple2<>("key2",4),Long.MAX_VALUE));
    expectedOutput.add(new StreamRecord<>(new Tuple2<>("key1",2),Long.MAX_VALUE));
    TestHarnessUtil.assertOutputEqualsSorted("Output was not correct.",expectedOutput,testHarness.getOutput(),new ResultSortComparator());
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key1",1),initialTime + 10999));
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key2",1),initialTime + 1000));
    expectedOutput.add(new StreamRecord<>(new Tuple2<>("key1",4),Long.MAX_VALUE));
    expectedOutput.add(new StreamRecord<>(new Tuple2<>("key2",4),Long.MAX_VALUE));
    TestHarnessUtil.assertOutputEqualsSorted("Output was not correct.",expectedOutput,testHarness.getOutput(),new ResultSortComparator());
    testHarness.close();
    Assert.assertEquals("Close was not called.",1,closeCalled.get());
  }
  @Test @SuppressWarnings("unchecked") public void testTumblingWindowWithApply() throws Exception {
    AtomicInteger closeCalled=new AtomicInteger(0);
    final int WINDOW_SIZE=4;
    TypeInformation<Tuple2<String,Integer>> inputType=TypeInfoParser.parse("Tuple2<String, Integer>");
    ListStateDescriptor<StreamRecord<Tuple2<String,Integer>>> stateDesc=new ListStateDescriptor<>("window-contents",new StreamRecordSerializer<>(inputType.createSerializer(new ExecutionConfig())));
    EvictingWindowOperator<String,Tuple2<String,Integer>,Tuple2<String,Integer>,TimeWindow> operator=new EvictingWindowOperator<>(TumblingEventTimeWindows.of(Time.of(WINDOW_SIZE,TimeUnit.SECONDS)),new TimeWindow.Serializer(),new TupleKeySelector(),BasicTypeInfo.STRING_TYPE_INFO.createSerializer(new ExecutionConfig()),stateDesc,new InternalIterableWindowFunction<>(new RichSumReducer<TimeWindow>(closeCalled)),EventTimeTrigger.create(),CountEvictor.of(WINDOW_SIZE),0);
    operator.setInputType(inputType,new ExecutionConfig());
    OneInputStreamOperatorTestHarness<Tuple2<String,Integer>,Tuple2<String,Integer>> testHarness=new OneInputStreamOperatorTestHarness<>(operator);
    testHarness.configureForKeyedStream(new TupleKeySelector(),BasicTypeInfo.STRING_TYPE_INFO);
    long initialTime=0L;
    testHarness.open();
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key1",1),initialTime + 10));
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key1",1),initialTime + 100));
    testHarness.processWatermark(new Watermark(1999));
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key1",1),initialTime + 1997));
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key1",1),initialTime + 1998));
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key1",1),initialTime + 2310));
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key1",1),initialTime + 2310));
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key2",1),initialTime + 2310));
    testHarness.processElement(new StreamRecord<>(new Tuple2<>("key2",1),initialTime + 2310));
    testHarness.processWatermark(new Watermark(3999));
    ConcurrentLinkedQueue<Object> expectedOutput=new ConcurrentLinkedQueue<>();
    expectedOutput.add(new Watermark(1999));
    expectedOutput.add(new StreamRecord<>(new Tuple2<>("key1",4),3999));
    expectedOutput.add(new StreamRecord<>(new Tuple2<>("key2",2),3999));
    expectedOutput.add(new Watermark(3999));
    TestHarnessUtil.assertOutputEqualsSorted("Output was not correct.",expectedOutput,testHarness.getOutput(),new EvictingWindowOperatorTest.ResultSortComparator());
    testHarness.close();
  }
public static class SumReducer implements ReduceFunction<Tuple2<String,Integer>> {
    private static final long serialVersionUID=1L;
    @Override public Tuple2<String,Integer> reduce(    Tuple2<String,Integer> value1,    Tuple2<String,Integer> value2) throws Exception {
      return new Tuple2<>(value2.f0,value1.f1 + value2.f1);
    }
  }
public static class RichSumReducer<W extends Window> extends RichWindowFunction<Tuple2<String,Integer>,Tuple2<String,Integer>,String,W> {
    private static final long serialVersionUID=1L;
    private boolean openCalled=false;
    private AtomicInteger closeCalled=new AtomicInteger(0);
    public RichSumReducer(    AtomicInteger closeCalled){
      this.closeCalled=closeCalled;
    }
    @Override public void open(    Configuration parameters) throws Exception {
      super.open(parameters);
      openCalled=true;
    }
    @Override public void close() throws Exception {
      super.close();
      closeCalled.incrementAndGet();
    }
    @Override public void apply(    String key,    W window,    Iterable<Tuple2<String,Integer>> input,    Collector<Tuple2<String,Integer>> out) throws Exception {
      if (!openCalled) {
        Assert.fail("Open was not called");
      }
      int sum=0;
      for (      Tuple2<String,Integer> t : input) {
        sum+=t.f1;
      }
      out.collect(new Tuple2<>(key,sum));
    }
  }
@SuppressWarnings("unchecked") private static class ResultSortComparator implements Comparator<Object> {
    @Override public int compare(    Object o1,    Object o2){
      if (o1 instanceof Watermark || o2 instanceof Watermark) {
        return 0;
      }
 else {
        StreamRecord<Tuple2<String,Integer>> sr0=(StreamRecord<Tuple2<String,Integer>>)o1;
        StreamRecord<Tuple2<String,Integer>> sr1=(StreamRecord<Tuple2<String,Integer>>)o2;
        if (sr0.getTimestamp() != sr1.getTimestamp()) {
          return (int)(sr0.getTimestamp() - sr1.getTimestamp());
        }
        int comparison=sr0.getValue().f0.compareTo(sr1.getValue().f0);
        if (comparison != 0) {
          return comparison;
        }
 else {
          return sr0.getValue().f1 - sr1.getValue().f1;
        }
      }
    }
  }
private static class TupleKeySelector implements KeySelector<Tuple2<String,Integer>,String> {
    private static final long serialVersionUID=1L;
    @Override public String getKey(    Tuple2<String,Integer> value) throws Exception {
      return value.f0;
    }
  }
}
