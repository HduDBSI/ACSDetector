/** 
 * Unique identifier for the attempt to execute a tasks. Multiple attempts happen in cases of failures and recovery.
 */
public class ExecutionAttemptID extends AbstractID {
  private static final long serialVersionUID=-1169683445778281344L;
}
