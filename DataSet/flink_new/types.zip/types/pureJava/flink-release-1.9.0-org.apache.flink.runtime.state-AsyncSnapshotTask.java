/** 
 * {@link FutureTask} that wraps a {@link AsyncSnapshotCallable} and connects it with cancellation and closing.
 */
public class AsyncSnapshotTask extends FutureTask<T> {
  @Nonnull private final CloseableRegistry taskRegistry;
  @Nonnull private final Closeable cancelOnClose;
  private AsyncSnapshotTask(  @Nonnull CloseableRegistry taskRegistry) throws IOException {
    super(AsyncSnapshotCallable.this);
    this.cancelOnClose=() -> cancel(true);
    this.taskRegistry=taskRegistry;
    taskRegistry.registerCloseable(cancelOnClose);
  }
  @Override public boolean cancel(  boolean mayInterruptIfRunning){
    boolean result=super.cancel(mayInterruptIfRunning);
    if (mayInterruptIfRunning) {
      AsyncSnapshotCallable.this.cancel();
    }
    return result;
  }
  @Override protected void done(){
    super.done();
    taskRegistry.unregisterCloseable(cancelOnClose);
  }
}
