public class DummyNonPreservingMatchStub extends JoinFunction implements Serializable {
  private static final long serialVersionUID=1L;
  @Override public void join(  Record value1,  Record value2,  Collector<Record> out) throws Exception {
    out.collect(value1);
  }
}
