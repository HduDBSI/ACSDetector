/** 
 * A  {@link org.apache.flink.streaming.api.operators.StreamOperator} is supplied with an objectof this interface that can be used to emit elements and other messages, such as barriers and low watermarks, from an operator.
 * @param < T > The type of the elments that can be emitted.
 */
public interface Output<T> extends Collector<T> {
}
