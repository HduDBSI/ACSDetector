public class AvroOutputFormat<E> extends FileOutputFormat<E> {
  private static final long serialVersionUID=1L;
  private final Class<E> avroValueType;
  private Schema userDefinedSchema=null;
  private transient DataFileWriter<E> dataFileWriter;
  public AvroOutputFormat(  Path filePath,  Class<E> type){
    super(filePath);
    this.avroValueType=type;
  }
  public AvroOutputFormat(  Class<E> type){
    this.avroValueType=type;
  }
  @Override protected String getDirectoryFileName(  int taskNumber){
    return super.getDirectoryFileName(taskNumber) + ".avro";
  }
  public void setSchema(  Schema schema){
    this.userDefinedSchema=schema;
  }
  @Override public void writeRecord(  E record) throws IOException {
    dataFileWriter.append(record);
  }
  @Override public void open(  int taskNumber,  int numTasks) throws IOException {
    super.open(taskNumber,numTasks);
    DatumWriter<E> datumWriter;
    Schema schema=null;
    if (org.apache.avro.specific.SpecificRecordBase.class.isAssignableFrom(avroValueType)) {
      datumWriter=new SpecificDatumWriter<E>(avroValueType);
      try {
        schema=((org.apache.avro.specific.SpecificRecordBase)avroValueType.newInstance()).getSchema();
      }
 catch (      InstantiationException e) {
        throw new RuntimeException(e.getMessage());
      }
catch (      IllegalAccessException e) {
        throw new RuntimeException(e.getMessage());
      }
    }
 else {
      datumWriter=new ReflectDatumWriter<E>(avroValueType);
      schema=ReflectData.get().getSchema(avroValueType);
    }
    dataFileWriter=new DataFileWriter<E>(datumWriter);
    if (userDefinedSchema == null) {
      dataFileWriter.create(schema,stream);
    }
 else {
      dataFileWriter.create(userDefinedSchema,stream);
    }
  }
  @Override public void close() throws IOException {
    dataFileWriter.flush();
    dataFileWriter.close();
    super.close();
  }
}
