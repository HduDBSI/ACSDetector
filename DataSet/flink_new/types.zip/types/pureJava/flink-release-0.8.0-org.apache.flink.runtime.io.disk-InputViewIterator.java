public class InputViewIterator<E> implements MutableObjectIterator<E> {
  private DataInputView inputView;
  private final TypeSerializer<E> serializer;
  public InputViewIterator(  DataInputView inputView,  TypeSerializer<E> serializer){
    this.inputView=inputView;
    this.serializer=serializer;
  }
  @Override public E next(  E reuse) throws IOException {
    try {
      return this.serializer.deserialize(reuse,this.inputView);
    }
 catch (    EOFException e) {
      return null;
    }
  }
}
