private static class Resource {
  private final Object resource;
  private final String name;
  private final boolean restrictParser;
  public Resource(  Object resource){
    this(resource,resource.toString());
  }
  public Resource(  Object resource,  boolean useRestrictedParser){
    this(resource,resource.toString(),useRestrictedParser);
  }
  public Resource(  Object resource,  String name){
    this(resource,name,getRestrictParserDefault(resource));
  }
  public Resource(  Object resource,  String name,  boolean restrictParser){
    this.resource=resource;
    this.name=name;
    this.restrictParser=restrictParser;
  }
  public String getName(){
    return name;
  }
  public Object getResource(){
    return resource;
  }
  public boolean isParserRestricted(){
    return restrictParser;
  }
  @Override public String toString(){
    return name;
  }
  private static boolean getRestrictParserDefault(  Object resource){
    if (resource instanceof String) {
      return false;
    }
    UserGroupInformation user;
    try {
      user=UserGroupInformation.getCurrentUser();
    }
 catch (    IOException e) {
      throw new RuntimeException("Unable to determine current user",e);
    }
    return user.getRealUser() != null;
  }
}
