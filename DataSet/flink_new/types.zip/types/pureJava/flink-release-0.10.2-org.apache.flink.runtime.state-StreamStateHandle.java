/** 
 * A state handle that produces an input stream when resolved.
 */
public interface StreamStateHandle extends StateHandle<InputStream> {
}
