@SuppressWarnings("ForLoopReplaceableByForEach") final public class ArrayListSerializer<T> extends TypeSerializer<ArrayList<T>> {
  private static final long serialVersionUID=1119562170939152304L;
  private final TypeSerializer<T> elementSerializer;
  public ArrayListSerializer(  TypeSerializer<T> elementSerializer){
    this.elementSerializer=elementSerializer;
  }
  @Override public boolean isImmutableType(){
    return false;
  }
  @Override public TypeSerializer<ArrayList<T>> duplicate(){
    TypeSerializer<T> duplicateElement=elementSerializer.duplicate();
    return duplicateElement == elementSerializer ? this : new ArrayListSerializer<T>(duplicateElement);
  }
  @Override public ArrayList<T> createInstance(){
    return new ArrayList<>();
  }
  @Override public ArrayList<T> copy(  ArrayList<T> from){
    ArrayList<T> newList=new ArrayList<>(from.size());
    for (int i=0; i < from.size(); i++) {
      newList.add(elementSerializer.copy(from.get(i)));
    }
    return newList;
  }
  @Override public ArrayList<T> copy(  ArrayList<T> from,  ArrayList<T> reuse){
    return copy(from);
  }
  @Override public int getLength(){
    return -1;
  }
  @Override public void serialize(  ArrayList<T> list,  DataOutputView target) throws IOException {
    final int size=list.size();
    target.writeInt(size);
    for (int i=0; i < size; i++) {
      elementSerializer.serialize(list.get(i),target);
    }
  }
  @Override public ArrayList<T> deserialize(  DataInputView source) throws IOException {
    final int size=source.readInt();
    final ArrayList<T> list=new ArrayList<>(size);
    for (int i=0; i < size; i++) {
      list.add(elementSerializer.deserialize(source));
    }
    return list;
  }
  @Override public ArrayList<T> deserialize(  ArrayList<T> reuse,  DataInputView source) throws IOException {
    return deserialize(source);
  }
  @Override public void copy(  DataInputView source,  DataOutputView target) throws IOException {
    final int num=source.readInt();
    target.writeInt(num);
    for (int i=0; i < num; i++) {
      elementSerializer.copy(source,target);
    }
  }
  @Override public boolean equals(  Object obj){
    return obj == this || (obj != null && obj.getClass() == getClass() && elementSerializer.equals(((ArrayListSerializer<?>)obj).elementSerializer));
  }
  @Override public boolean canEqual(  Object obj){
    return true;
  }
  @Override public int hashCode(){
    return elementSerializer.hashCode();
  }
}
