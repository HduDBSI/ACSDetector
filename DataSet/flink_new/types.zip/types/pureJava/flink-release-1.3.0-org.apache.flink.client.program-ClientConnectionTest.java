/** 
 * This test starts a job client without the JobManager being reachable. It tests for a timely error and a meaningful error message.
 */
public class ClientConnectionTest extends TestLogger {
  private static final long CONNECT_TIMEOUT=100L;
  private static final long ASK_STARTUP_TIMEOUT=20000L;
  /** 
 * Tests the behavior against a LOCAL address where no job manager is running.
 */
  @Test public void testExceptionWhenLocalJobManagerUnreachablelocal() throws Exception {
    final InetSocketAddress unreachableEndpoint;
    try {
      int freePort=NetUtils.getAvailablePort();
      unreachableEndpoint=new InetSocketAddress(InetAddress.getLocalHost(),freePort);
    }
 catch (    Throwable t) {
      return;
    }
    testFailureBehavior(unreachableEndpoint);
  }
  /** 
 * Tests the behavior against a REMOTE address where no job manager is running.
 */
  @Test public void testExceptionWhenRemoteJobManagerUnreachable() throws Exception {
    final InetSocketAddress unreachableEndpoint;
    try {
      int freePort=NetUtils.getAvailablePort();
      unreachableEndpoint=new InetSocketAddress(InetAddress.getByName("10.0.1.64"),freePort);
    }
 catch (    Throwable t) {
      return;
    }
    testFailureBehavior(unreachableEndpoint);
  }
  private static void testFailureBehavior(  final InetSocketAddress unreachableEndpoint) throws Exception {
    final Configuration config=new Configuration();
    config.setString(ConfigConstants.AKKA_ASK_TIMEOUT,(ASK_STARTUP_TIMEOUT) + " ms");
    config.setString(ConfigConstants.AKKA_LOOKUP_TIMEOUT,(CONNECT_TIMEOUT) + " ms");
    config.setString(ConfigConstants.JOB_MANAGER_IPC_ADDRESS_KEY,unreachableEndpoint.getHostName());
    config.setInteger(ConfigConstants.JOB_MANAGER_IPC_PORT_KEY,unreachableEndpoint.getPort());
    ClusterClient client=new StandaloneClusterClient(config);
    try {
      client.getClusterStatus();
      fail("This should fail with an exception since the endpoint is unreachable.");
    }
 catch (    Exception e) {
      assertTrue(CommonTestUtils.containsCause(e,LeaderRetrievalException.class));
    }
  }
  /** 
 * FLINK-6629 Tests that the  {@link HighAvailabilityServices} are respected when initializing the ClusterClient's{@link ActorSystem} and retrieving the leading JobManager.
 */
  @Test public void testJobManagerRetrievalWithHAServices() throws Exception {
    final Configuration configuration=new Configuration();
    final TestingHighAvailabilityServices highAvailabilityServices=new TestingHighAvailabilityServices();
    final ActorSystem actorSystem=AkkaUtils.createDefaultActorSystem();
    ActorRef actorRef=null;
    final UUID leaderId=UUID.randomUUID();
    try {
      actorRef=actorSystem.actorOf(Props.create(JobClientActorTest.PlainActor.class,leaderId));
      final String expectedAddress=AkkaUtils.getAkkaURL(actorSystem,actorRef);
      final TestingLeaderRetrievalService testingLeaderRetrievalService=new TestingLeaderRetrievalService(expectedAddress,leaderId);
      highAvailabilityServices.setJobMasterLeaderRetriever(HighAvailabilityServices.DEFAULT_JOB_ID,testingLeaderRetrievalService);
      ClusterClient client=new StandaloneClusterClient(configuration,highAvailabilityServices);
      ActorGateway gateway=client.getJobManagerGateway();
      assertEquals(expectedAddress,gateway.path());
      assertEquals(leaderId,gateway.leaderSessionID());
    }
  finally {
      if (actorRef != null) {
        TestingUtils.stopActorGracefully(actorRef);
      }
      actorSystem.shutdown();
    }
  }
}
