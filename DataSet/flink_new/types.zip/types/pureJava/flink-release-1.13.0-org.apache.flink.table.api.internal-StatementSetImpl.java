/** 
 * Implementation for  {@link StatementSet}. 
 */
@Internal class StatementSetImpl implements StatementSet {
  private final TableEnvironmentInternal tableEnvironment;
  private final List<ModifyOperation> operations=new ArrayList<>();
  protected StatementSetImpl(  TableEnvironmentInternal tableEnvironment){
    this.tableEnvironment=tableEnvironment;
  }
  @Override public StatementSet addInsertSql(  String statement){
    List<Operation> operations=tableEnvironment.getParser().parse(statement);
    if (operations.size() != 1) {
      throw new TableException("Only single statement is supported.");
    }
    Operation operation=operations.get(0);
    if (operation instanceof ModifyOperation) {
      this.operations.add((ModifyOperation)operation);
    }
 else {
      throw new TableException("Only insert statement is supported now.");
    }
    return this;
  }
  @Override public StatementSet addInsert(  String targetPath,  Table table){
    return addInsert(targetPath,table,false);
  }
  @Override public StatementSet addInsert(  String targetPath,  Table table,  boolean overwrite){
    UnresolvedIdentifier unresolvedIdentifier=tableEnvironment.getParser().parseIdentifier(targetPath);
    ObjectIdentifier objectIdentifier=tableEnvironment.getCatalogManager().qualifyIdentifier(unresolvedIdentifier);
    operations.add(new CatalogSinkModifyOperation(objectIdentifier,table.getQueryOperation(),Collections.emptyMap(),overwrite,Collections.emptyMap()));
    return this;
  }
  @Override public String explain(  ExplainDetail... extraDetails){
    List<Operation> operationList=operations.stream().map(o -> (Operation)o).collect(Collectors.toList());
    return tableEnvironment.explainInternal(operationList,extraDetails);
  }
  @Override public TableResult execute(){
    try {
      return tableEnvironment.executeInternal(operations);
    }
  finally {
      operations.clear();
    }
  }
  /** 
 * Get the json plan of the all statements and Tables as a batch. <p>The json plan is the string json representation of an optimized ExecNode plan for the statements and Tables. An ExecNode plan can be serialized to json plan, and a json plan can be deserialized to an ExecNode plan. <p>The added statements and Tables will NOT be cleared when executing this method. <p>NOTES: Only the Blink planner supports this method. <p><b>NOTES</b>: This is an experimental feature now.
 * @return the string json representation of an optimized ExecNode plan for the statements andTables.
 */
  @Experimental public String getJsonPlan(){
    return tableEnvironment.getJsonPlan(operations);
  }
}
