/** 
 * Class containing information about the available cluster resources.
 */
public class ResourceOverview implements Serializable {
  private static final long serialVersionUID=7618746920569224557L;
  private static final ResourceOverview EMPTY_RESOURCE_OVERVIEW=new ResourceOverview(0,0,0);
  private final int numberTaskManagers;
  private final int numberRegisteredSlots;
  private final int numberFreeSlots;
  public ResourceOverview(  int numberTaskManagers,  int numberRegisteredSlots,  int numberFreeSlots){
    this.numberTaskManagers=numberTaskManagers;
    this.numberRegisteredSlots=numberRegisteredSlots;
    this.numberFreeSlots=numberFreeSlots;
  }
  public int getNumberTaskManagers(){
    return numberTaskManagers;
  }
  public int getNumberRegisteredSlots(){
    return numberRegisteredSlots;
  }
  public int getNumberFreeSlots(){
    return numberFreeSlots;
  }
  public static ResourceOverview empty(){
    return EMPTY_RESOURCE_OVERVIEW;
  }
}
