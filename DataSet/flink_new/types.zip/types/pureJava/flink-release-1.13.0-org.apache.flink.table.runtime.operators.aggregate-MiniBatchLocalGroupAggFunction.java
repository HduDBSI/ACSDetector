/** 
 * Aggregate Function used for the local groupby (without window) aggregate in miniBatch mode. 
 */
public class MiniBatchLocalGroupAggFunction extends MapBundleFunction<RowData,RowData,RowData,RowData> {
  private static final long serialVersionUID=5417039295967495506L;
  /** 
 * The code generated function used to handle aggregates. 
 */
  private final GeneratedAggsHandleFunction genAggsHandler;
  /** 
 * Reused output row. 
 */
  private transient JoinedRowData resultRow=new JoinedRowData();
  private transient AggsHandleFunction function=null;
  public MiniBatchLocalGroupAggFunction(  GeneratedAggsHandleFunction genAggsHandler){
    this.genAggsHandler=genAggsHandler;
  }
  @Override public void open(  ExecutionContext ctx) throws Exception {
    super.open(ctx);
    function=genAggsHandler.newInstance(ctx.getRuntimeContext().getUserCodeClassLoader());
    function.open(new PerKeyStateDataViewStore(ctx.getRuntimeContext()));
    resultRow=new JoinedRowData();
  }
  @Override public RowData addInput(  @Nullable RowData previousAcc,  RowData input) throws Exception {
    RowData currentAcc;
    if (previousAcc == null) {
      currentAcc=function.createAccumulators();
    }
 else {
      currentAcc=previousAcc;
    }
    function.setAccumulators(currentAcc);
    if (isAccumulateMsg(input)) {
      function.accumulate(input);
    }
 else {
      function.retract(input);
    }
    return function.getAccumulators();
  }
  @Override public void finishBundle(  Map<RowData,RowData> buffer,  Collector<RowData> out) throws Exception {
    for (    Map.Entry<RowData,RowData> entry : buffer.entrySet()) {
      RowData currentKey=entry.getKey();
      RowData currentAcc=entry.getValue();
      resultRow.replace(currentKey,currentAcc);
      out.collect(resultRow);
    }
    buffer.clear();
  }
  @Override public void close() throws Exception {
    if (function != null) {
      function.close();
    }
  }
}
