class ResultSubpartitionRecoveredStateHandler implements RecoveredChannelStateHandler<ResultSubpartitionInfo,BufferBuilder> {
  private final ResultPartitionWriter[] writers;
  private final boolean notifyAndBlockOnCompletion;
  private final InflightDataRescalingDescriptor channelMapping;
  private final Map<ResultSubpartitionInfo,List<CheckpointedResultSubpartition>> rescaledChannels=new HashMap<>();
  private final Map<Integer,RescaleMappings> oldToNewMappings=new HashMap<>();
  ResultSubpartitionRecoveredStateHandler(  ResultPartitionWriter[] writers,  boolean notifyAndBlockOnCompletion,  InflightDataRescalingDescriptor channelMapping){
    this.writers=writers;
    this.channelMapping=channelMapping;
    this.notifyAndBlockOnCompletion=notifyAndBlockOnCompletion;
  }
  @Override public BufferWithContext<BufferBuilder> getBuffer(  ResultSubpartitionInfo subpartitionInfo) throws IOException, InterruptedException {
    final List<CheckpointedResultSubpartition> channels=getMappedChannels(subpartitionInfo);
    BufferBuilder bufferBuilder=channels.get(0).requestBufferBuilderBlocking();
    return new BufferWithContext<>(wrap(bufferBuilder),bufferBuilder);
  }
  @Override public void recover(  ResultSubpartitionInfo subpartitionInfo,  int oldSubtaskIndex,  BufferWithContext<BufferBuilder> bufferWithContext) throws IOException {
    try (BufferBuilder bufferBuilder=bufferWithContext.context){
      try (BufferConsumer bufferConsumer=bufferBuilder.createBufferConsumerFromBeginning()){
        bufferBuilder.finish();
        if (bufferConsumer.isDataAvailable()) {
          NetworkActionsLogger.traceRecover("ResultSubpartitionRecoveredStateHandler#recover",bufferConsumer,subpartitionInfo);
          final List<CheckpointedResultSubpartition> channels=getMappedChannels(subpartitionInfo);
          for (          final CheckpointedResultSubpartition channel : channels) {
            final SubtaskConnectionDescriptor channelSelector=new SubtaskConnectionDescriptor(subpartitionInfo.getSubPartitionIdx(),oldSubtaskIndex);
            channel.add(EventSerializer.toBufferConsumer(channelSelector,false),Integer.MIN_VALUE);
            boolean added=channel.add(bufferConsumer.copy(),Integer.MIN_VALUE);
            if (!added) {
              throw new IOException("Buffer consumer couldn't be added to ResultSubpartition");
            }
          }
        }
      }
     }
   }
  private CheckpointedResultSubpartition getSubpartition(  int partitionIndex,  int subPartitionIdx){
    ResultPartitionWriter writer=writers[partitionIndex];
    if (!(writer instanceof CheckpointedResultPartition)) {
      throw new IllegalStateException("Cannot restore state to a non-checkpointable partition type: " + writer);
    }
    return ((CheckpointedResultPartition)writer).getCheckpointedSubpartition(subPartitionIdx);
  }
  private List<CheckpointedResultSubpartition> getMappedChannels(  ResultSubpartitionInfo subpartitionInfo){
    return rescaledChannels.computeIfAbsent(subpartitionInfo,this::calculateMapping);
  }
  private List<CheckpointedResultSubpartition> calculateMapping(  ResultSubpartitionInfo info){
    final RescaleMappings oldToNewMapping=oldToNewMappings.computeIfAbsent(info.getPartitionIdx(),idx -> channelMapping.getChannelMapping(idx).invert());
    final List<CheckpointedResultSubpartition> subpartitions=Arrays.stream(oldToNewMapping.getMappedIndexes(info.getSubPartitionIdx())).mapToObj(newIndexes -> getSubpartition(info.getPartitionIdx(),newIndexes)).collect(Collectors.toList());
    if (subpartitions.isEmpty()) {
      throw new IllegalStateException("Recovered a buffer from old " + info + " that has no mapping in "+ channelMapping.getChannelMapping(info.getPartitionIdx()));
    }
    return subpartitions;
  }
  @Override public void close() throws IOException {
    for (    ResultPartitionWriter writer : writers) {
      if (writer instanceof CheckpointedResultPartition) {
        ((CheckpointedResultPartition)writer).finishReadRecoveredState(notifyAndBlockOnCompletion);
      }
    }
  }
}
