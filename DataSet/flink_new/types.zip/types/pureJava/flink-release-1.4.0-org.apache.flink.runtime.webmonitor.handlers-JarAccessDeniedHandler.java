/** 
 * Handler to deny access to jar-related REST calls.
 */
public class JarAccessDeniedHandler extends AbstractJsonRequestHandler {
  private static final String ERROR_MESSAGE="{\"error\": \"Web submission interface is not " + "available for this cluster. To enable it, set the configuration key ' jobmanager.web.submit.enable.'\"}";
  public JarAccessDeniedHandler(  Executor executor){
    super(executor);
  }
  @Override public String[] getPaths(){
    return new String[]{JarListHandler.JAR_LIST_REST_PATH,JarPlanHandler.JAR_PLAN_REST_PATH,JarRunHandler.JAR_RUN_REST_PATH,JarUploadHandler.JAR_UPLOAD_REST_PATH,JarDeleteHandler.JAR_DELETE_REST_PATH};
  }
  @Override public CompletableFuture<String> handleJsonRequest(  Map<String,String> pathParams,  Map<String,String> queryParams,  JobManagerGateway jobManagerGateway){
    return CompletableFuture.completedFuture(ERROR_MESSAGE);
  }
}
