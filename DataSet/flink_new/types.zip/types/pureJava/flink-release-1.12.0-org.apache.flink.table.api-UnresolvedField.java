/** 
 * Helper class for defining the unresolved field of a row or structured type. <p>Compared to  {@link Field}, an unresolved field can contain an  {@link UnresolvedDataType}.
 * @see #FIELD(String,AbstractDataType)
 * @see #FIELD(String,AbstractDataType,String)
 */
public static final class UnresolvedField extends AbstractField {
  private final AbstractDataType<?> dataType;
  private UnresolvedField(  String name,  AbstractDataType<?> dataType,  @Nullable String description){
    super(name,description);
    this.dataType=dataType;
  }
  @Override protected AbstractDataType<?> getAbstractDataType(){
    return dataType;
  }
  @Override public boolean equals(  Object o){
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    if (!super.equals(o)) {
      return false;
    }
    UnresolvedField that=(UnresolvedField)o;
    return dataType.equals(that.dataType);
  }
  @Override public int hashCode(){
    return Objects.hash(super.hashCode(),dataType);
  }
}
