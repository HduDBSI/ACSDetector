/** 
 * {@link CheckpointedInputGate} test. 
 */
public class CheckpointedInputGateTest {
  private final HashMap<Integer,Integer> channelIndexToSequenceNumber=new HashMap<>();
  @Before public void setUp(){
    channelIndexToSequenceNumber.clear();
  }
  @Test public void testUpstreamResumedUponEndOfRecovery() throws Exception {
    int numberOfChannels=11;
    NetworkBufferPool bufferPool=new NetworkBufferPool(numberOfChannels * 3,1024);
    try {
      ResumeCountingConnectionManager resumeCounter=new ResumeCountingConnectionManager();
      CheckpointedInputGate gate=setupInputGate(numberOfChannels,bufferPool,resumeCounter);
      assertFalse(gate.pollNext().isPresent());
      for (int channelIndex=0; channelIndex < numberOfChannels - 1; channelIndex++) {
        enqueueEndOfState(gate,channelIndex);
        assertFalse("should align (block all channels)",gate.pollNext().isPresent());
      }
      enqueueEndOfState(gate,numberOfChannels - 1);
      Optional<BufferOrEvent> polled=gate.pollNext();
      assertTrue(polled.isPresent());
      assertTrue(polled.get().isEvent());
      assertEquals(EndOfChannelStateEvent.INSTANCE,polled.get().getEvent());
      assertEquals(numberOfChannels,resumeCounter.getNumResumed());
      assertFalse("should only be a single event no matter of what is the number of channels",gate.pollNext().isPresent());
    }
  finally {
      bufferPool.destroy();
    }
  }
  @Test public void testPersisting() throws Exception {
    testPersisting(false);
  }
  @Test public void testPersistingWithDrainingTheGate() throws Exception {
    testPersisting(true);
  }
  /** 
 * This tests a scenario where an older triggered checkpoint, was cancelled and a newer checkpoint was triggered very quickly after the cancellation. It can happen that a task can receive first the more recent checkpoint barrier and later the obsoleted one. This can happen for many reasons (for example Source tasks not running, or just a race condition with notifyCheckpointAborted RPCs) and Task should be able to handle this properly. In FLINK-21104 the problem was that this obsoleted checkpoint barrier was causing a checkState to fail.
 */
  public void testPersisting(  boolean drainGate) throws Exception {
    int numberOfChannels=3;
    NetworkBufferPool bufferPool=new NetworkBufferPool(numberOfChannels * 3,1024);
    try {
      long checkpointId=2L;
      long obsoleteCheckpointId=1L;
      ValidatingCheckpointHandler validatingHandler=new ValidatingCheckpointHandler(checkpointId);
      RecordingChannelStateWriter stateWriter=new RecordingChannelStateWriter();
      CheckpointedInputGate gate=setupInputGateWithAlternatingController(numberOfChannels,bufferPool,validatingHandler,stateWriter);
      enqueue(gate,0,buildSomeBuffer());
      enqueue(gate,0,barrier(checkpointId));
      enqueue(gate,0,buildSomeBuffer());
      enqueue(gate,1,buildSomeBuffer());
      enqueue(gate,1,barrier(obsoleteCheckpointId));
      enqueue(gate,1,buildSomeBuffer());
      enqueue(gate,2,buildSomeBuffer());
      assertEquals(0,validatingHandler.getTriggeredCheckpointCounter());
      gate.pollNext();
      assertEquals(1,validatingHandler.getTriggeredCheckpointCounter());
      assertAddedInputSize(stateWriter,0,1);
      assertAddedInputSize(stateWriter,1,2);
      assertAddedInputSize(stateWriter,2,1);
      enqueue(gate,0,buildSomeBuffer());
      enqueue(gate,1,buildSomeBuffer());
      enqueue(gate,2,buildSomeBuffer());
      while (drainGate && gate.pollNext().isPresent()) {
      }
      assertAddedInputSize(stateWriter,0,1);
      assertAddedInputSize(stateWriter,1,3);
      assertAddedInputSize(stateWriter,2,2);
      enqueue(gate,1,barrier(checkpointId));
      enqueue(gate,1,buildSomeBuffer());
      enqueue(gate,2,barrier(obsoleteCheckpointId));
      enqueue(gate,2,buildSomeBuffer());
      while (drainGate && gate.pollNext().isPresent()) {
      }
      assertAddedInputSize(stateWriter,0,1);
      assertAddedInputSize(stateWriter,1,3);
      assertAddedInputSize(stateWriter,2,3);
      enqueue(gate,2,barrier(checkpointId));
      enqueue(gate,2,buildSomeBuffer());
      while (drainGate && gate.pollNext().isPresent()) {
      }
      assertAddedInputSize(stateWriter,0,1);
      assertAddedInputSize(stateWriter,1,3);
      assertAddedInputSize(stateWriter,2,3);
    }
  finally {
      bufferPool.destroy();
    }
  }
  /** 
 * Tests a priority notification happening right before cancellation. The mail would be processed while draining mailbox but can't pull any data anymore.
 */
  @Test public void testPriorityBeforeClose() throws IOException, InterruptedException {
    NetworkBufferPool bufferPool=new NetworkBufferPool(10,1024);
    try (Closer closer=Closer.create()){
      closer.register(bufferPool::destroy);
      for (int repeat=0; repeat < 100; repeat++) {
        setUp();
        SingleInputGate singleInputGate=new SingleInputGateBuilder().setNumberOfChannels(2).setBufferPoolFactory(bufferPool.createBufferPool(2,Integer.MAX_VALUE)).setSegmentProvider(bufferPool).setChannelFactory(InputChannelBuilder::buildRemoteChannel).build();
        singleInputGate.setup();
        ((RemoteInputChannel)singleInputGate.getChannel(0)).requestSubpartition(0);
        final TaskMailboxImpl mailbox=new TaskMailboxImpl();
        MailboxExecutorImpl mailboxExecutor=new MailboxExecutorImpl(mailbox,0,StreamTaskActionExecutor.IMMEDIATE);
        ValidatingCheckpointHandler validatingHandler=new ValidatingCheckpointHandler(1);
        SingleCheckpointBarrierHandler barrierHandler=AlternatingControllerTest.barrierHandler(singleInputGate,validatingHandler,new MockChannelStateWriter());
        CheckpointedInputGate checkpointedInputGate=new CheckpointedInputGate(singleInputGate,barrierHandler,mailboxExecutor,UpstreamRecoveryTracker.forInputGate(singleInputGate));
        final int oldSize=mailbox.size();
        enqueue(checkpointedInputGate,0,barrier(1));
        Deadline deadline=Deadline.fromNow(Duration.ofMinutes(1));
        while (deadline.hasTimeLeft() && oldSize >= mailbox.size()) {
          Thread.sleep(1);
        }
        CountDownLatch beforeLatch=new CountDownLatch(2);
        final CheckedThread canceler=new CheckedThread("Canceler"){
          @Override public void go() throws IOException {
            beforeLatch.countDown();
            singleInputGate.close();
          }
        }
;
        canceler.start();
        beforeLatch.countDown();
        try {
          while (mailboxExecutor.tryYield()) {
          }
          assertEquals(1L,validatingHandler.triggeredCheckpointCounter);
        }
 catch (        CancelTaskException e) {
        }
        canceler.join();
      }
    }
   }
  private static CheckpointBarrier barrier(  long barrierId){
    return new CheckpointBarrier(barrierId,barrierId,CheckpointOptions.unaligned(getDefault()));
  }
  private void assertAddedInputSize(  RecordingChannelStateWriter stateWriter,  int channelIndex,  int size){
    assertEquals(size,stateWriter.getAddedInput().get(new InputChannelInfo(0,channelIndex)).size());
  }
  private void enqueueEndOfState(  CheckpointedInputGate checkpointedInputGate,  int channelIndex) throws IOException {
    enqueue(checkpointedInputGate,channelIndex,EndOfChannelStateEvent.INSTANCE);
  }
  private void enqueueEndOfPartition(  CheckpointedInputGate checkpointedInputGate,  int channelIndex) throws IOException {
    enqueue(checkpointedInputGate,channelIndex,EndOfPartitionEvent.INSTANCE);
  }
  private void enqueue(  CheckpointedInputGate checkpointedInputGate,  int channelIndex,  AbstractEvent event) throws IOException {
    boolean hasPriority=false;
    if (event instanceof CheckpointBarrier) {
      hasPriority=((CheckpointBarrier)event).getCheckpointOptions().isUnalignedCheckpoint();
    }
    enqueue(checkpointedInputGate,channelIndex,EventSerializer.toBuffer(event,hasPriority));
  }
  private void enqueue(  CheckpointedInputGate checkpointedInputGate,  int channelIndex,  Buffer buffer) throws IOException {
    Integer sequenceNumber=channelIndexToSequenceNumber.compute(channelIndex,(key,oldSequence) -> oldSequence == null ? 0 : oldSequence + 1);
    ((RemoteInputChannel)checkpointedInputGate.getChannel(channelIndex)).onBuffer(buffer,sequenceNumber,0);
  }
  private CheckpointedInputGate setupInputGate(  int numberOfChannels,  NetworkBufferPool networkBufferPool,  ConnectionManager connectionManager) throws Exception {
    SingleInputGate singleInputGate=new SingleInputGateBuilder().setBufferPoolFactory(networkBufferPool.createBufferPool(numberOfChannels,Integer.MAX_VALUE)).setSegmentProvider(networkBufferPool).setChannelFactory((builder,gate) -> builder.setConnectionManager(connectionManager).buildRemoteChannel(gate)).setNumberOfChannels(numberOfChannels).build();
    singleInputGate.setup();
    MailboxExecutorImpl mailboxExecutor=new MailboxExecutorImpl(new TaskMailboxImpl(),0,StreamTaskActionExecutor.IMMEDIATE);
    CheckpointBarrierTracker barrierHandler=new CheckpointBarrierTracker(numberOfChannels,new AbstractInvokable(new DummyEnvironment()){
      @Override public void invoke(){
      }
    }
);
    CheckpointedInputGate checkpointedInputGate=new CheckpointedInputGate(singleInputGate,barrierHandler,mailboxExecutor,UpstreamRecoveryTracker.forInputGate(singleInputGate));
    for (int i=0; i < numberOfChannels; i++) {
      ((RemoteInputChannel)checkpointedInputGate.getChannel(i)).requestSubpartition(0);
    }
    return checkpointedInputGate;
  }
  private CheckpointedInputGate setupInputGateWithAlternatingController(  int numberOfChannels,  NetworkBufferPool networkBufferPool,  AbstractInvokable abstractInvokable,  RecordingChannelStateWriter stateWriter) throws Exception {
    ConnectionManager connectionManager=new TestingConnectionManager();
    SingleInputGate singleInputGate=new SingleInputGateBuilder().setBufferPoolFactory(networkBufferPool.createBufferPool(numberOfChannels,Integer.MAX_VALUE)).setSegmentProvider(networkBufferPool).setChannelFactory((builder,gate) -> builder.setConnectionManager(connectionManager).buildRemoteChannel(gate)).setNumberOfChannels(numberOfChannels).setChannelStateWriter(stateWriter).build();
    singleInputGate.setup();
    MailboxExecutorImpl mailboxExecutor=new MailboxExecutorImpl(new TaskMailboxImpl(),0,StreamTaskActionExecutor.IMMEDIATE);
    SingleCheckpointBarrierHandler barrierHandler=AlternatingControllerTest.barrierHandler(singleInputGate,abstractInvokable,stateWriter);
    CheckpointedInputGate checkpointedInputGate=new CheckpointedInputGate(singleInputGate,barrierHandler,mailboxExecutor,UpstreamRecoveryTracker.forInputGate(singleInputGate));
    for (int i=0; i < numberOfChannels; i++) {
      ((RemoteInputChannel)checkpointedInputGate.getChannel(i)).requestSubpartition(0);
    }
    return checkpointedInputGate;
  }
private static class ResumeCountingConnectionManager extends TestingConnectionManager {
    private int numResumed;
    @Override public PartitionRequestClient createPartitionRequestClient(    ConnectionID connectionId){
      return new TestingPartitionRequestClient(){
        @Override public void resumeConsumption(        RemoteInputChannel inputChannel){
          numResumed++;
          super.resumeConsumption(inputChannel);
        }
      }
;
    }
    private int getNumResumed(){
      return numResumed;
    }
  }
}
