/** 
 * Implementation of  {@link DynamicTableSink.Context}. 
 */
@Internal public final class SinkRuntimeProviderContext implements DynamicTableSink.Context {
  private final boolean isBounded;
  public SinkRuntimeProviderContext(  boolean isBounded){
    this.isBounded=isBounded;
  }
  @Override public boolean isBounded(){
    return isBounded;
  }
  @Override public TypeInformation<?> createTypeInformation(  DataType consumedDataType){
    validateOutputDataType(consumedDataType);
    return InternalTypeInfo.of(consumedDataType.getLogicalType());
  }
  @Override public DynamicTableSink.DataStructureConverter createDataStructureConverter(  DataType consumedDataType){
    validateOutputDataType(consumedDataType);
    return new DataStructureConverterWrapper(DataStructureConverters.getConverter(consumedDataType));
  }
}
