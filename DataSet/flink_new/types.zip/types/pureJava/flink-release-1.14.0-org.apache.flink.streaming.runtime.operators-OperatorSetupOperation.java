private interface OperatorSetupOperation {
  void setupSourceOperator(  StreamSource<Long,?> operator,  TestProcessingTimeService testProcessingTimeService);
}
