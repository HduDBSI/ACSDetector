/** 
 * The factory of  {@link WatermarkAssignerOperator}. 
 */
public class WatermarkAssignerOperatorFactory extends AbstractStreamOperatorFactory<RowData> implements OneInputStreamOperatorFactory<RowData,RowData> {
  private static final long serialVersionUID=1L;
  private final int rowtimeFieldIndex;
  private final long idleTimeout;
  private final GeneratedWatermarkGenerator generatedWatermarkGenerator;
  public WatermarkAssignerOperatorFactory(  int rowtimeFieldIndex,  long idleTimeout,  GeneratedWatermarkGenerator generatedWatermarkGenerator){
    this.rowtimeFieldIndex=rowtimeFieldIndex;
    this.idleTimeout=idleTimeout;
    this.generatedWatermarkGenerator=generatedWatermarkGenerator;
  }
  @SuppressWarnings("unchecked") @Override public StreamOperator createStreamOperator(  StreamOperatorParameters initializer){
    WatermarkGenerator watermarkGenerator=generatedWatermarkGenerator.newInstance(initializer.getContainingTask().getUserCodeClassLoader());
    WatermarkAssignerOperator operator=new WatermarkAssignerOperator(rowtimeFieldIndex,watermarkGenerator,idleTimeout,processingTimeService);
    operator.setup(initializer.getContainingTask(),initializer.getStreamConfig(),initializer.getOutput());
    return operator;
  }
  @Override public Class<? extends StreamOperator> getStreamOperatorClass(  ClassLoader classLoader){
    return WatermarkAssignerOperator.class;
  }
}
