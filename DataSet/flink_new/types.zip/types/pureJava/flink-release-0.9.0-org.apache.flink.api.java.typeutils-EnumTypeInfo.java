/** 
 * A  {@link TypeInformation} for java enumeration types. 
 * @param < T > The type represented by this type information.
 */
public class EnumTypeInfo<T extends Enum<T>> extends TypeInformation<T> implements AtomicType<T> {
  private static final long serialVersionUID=8936740290137178660L;
  private final Class<T> typeClass;
  public EnumTypeInfo(  Class<T> typeClass){
    if (typeClass == null) {
      throw new NullPointerException();
    }
    if (!Enum.class.isAssignableFrom(typeClass)) {
      throw new IllegalArgumentException("EnumTypeInfo can only be used for subclasses of " + Enum.class.getName());
    }
    this.typeClass=typeClass;
  }
  @Override public TypeComparator<T> createComparator(  boolean sortOrderAscending,  ExecutionConfig executionConfig){
    return new EnumComparator<T>(sortOrderAscending);
  }
  @Override public boolean isBasicType(){
    return false;
  }
  @Override public boolean isTupleType(){
    return false;
  }
  @Override public int getArity(){
    return 1;
  }
  @Override public int getTotalFields(){
    return 1;
  }
  @Override public Class<T> getTypeClass(){
    return this.typeClass;
  }
  @Override public boolean isKeyType(){
    return true;
  }
  @Override public TypeSerializer<T> createSerializer(  ExecutionConfig executionConfig){
    return new EnumSerializer<T>(typeClass);
  }
  @Override public String toString(){
    return "EnumTypeInfo<" + typeClass.getName() + ">";
  }
  @Override public int hashCode(){
    return typeClass.hashCode() ^ 0xd3a2646c;
  }
  @Override public boolean equals(  Object obj){
    if (obj instanceof EnumTypeInfo) {
      return typeClass == ((EnumTypeInfo<?>)obj).typeClass;
    }
 else {
      return false;
    }
  }
}
