/** 
 * InputFormat that generates a deterministic DataSet of Tuple2(String, Integer) <ul> <li>String: key, can be repeated.</li> <li>Integer: uniformly distributed int between 0 and 127</li> </ul>
 */
public class Generator implements InputFormat<Tuple2<String,Integer>,GenericInputSplit> {
  private final long numRecords;
  private final long numKeys;
  private long recordsPerPartition;
  private long keysPerPartition;
  private long recordCnt;
  private int partitionId;
  private final boolean infinite;
  public static Generator generate(  long numKeys,  int recordsPerKey){
    return new Generator(numKeys,recordsPerKey,false);
  }
  public static Generator generateInfinitely(  long numKeys){
    return new Generator(numKeys,0,true);
  }
  private Generator(  long numKeys,  int recordsPerKey,  boolean infinite){
    this.numKeys=numKeys;
    if (infinite) {
      this.numRecords=Long.MAX_VALUE;
    }
 else {
      this.numRecords=numKeys * recordsPerKey;
    }
    this.infinite=infinite;
  }
  @Override public void configure(  Configuration parameters){
  }
  @Override public BaseStatistics getStatistics(  BaseStatistics cachedStatistics){
    return null;
  }
  @Override public GenericInputSplit[] createInputSplits(  int minNumSplits){
    GenericInputSplit[] splits=new GenericInputSplit[minNumSplits];
    for (int i=0; i < minNumSplits; i++) {
      splits[i]=new GenericInputSplit(i,minNumSplits);
    }
    return splits;
  }
  @Override public InputSplitAssigner getInputSplitAssigner(  GenericInputSplit[] inputSplits){
    return new DefaultInputSplitAssigner(inputSplits);
  }
  @Override public void open(  GenericInputSplit split) throws IOException {
    this.partitionId=split.getSplitNumber();
    int numPartitions=split.getTotalNumberOfSplits();
    Preconditions.checkArgument(numRecords % numPartitions == 0,"Records cannot be evenly distributed among partitions");
    Preconditions.checkArgument(numKeys % numPartitions == 0,"Keys cannot be evenly distributed among partitions");
    this.recordsPerPartition=numRecords / numPartitions;
    this.keysPerPartition=numKeys / numPartitions;
    this.recordCnt=0;
  }
  @Override public boolean reachedEnd(){
    return !infinite && this.recordCnt >= this.recordsPerPartition;
  }
  @Override public Tuple2<String,Integer> nextRecord(  Tuple2<String,Integer> reuse) throws IOException {
    String key=String.format("%d-%d",this.partitionId,this.recordCnt % this.keysPerPartition);
    int filterVal=(int)this.recordCnt % 128;
    this.recordCnt++;
    reuse.f0=key;
    reuse.f1=filterVal;
    return reuse;
  }
  @Override public void close(){
  }
}
