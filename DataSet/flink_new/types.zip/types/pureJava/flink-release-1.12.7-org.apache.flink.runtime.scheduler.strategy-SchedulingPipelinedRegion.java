/** 
 * Pipelined region on execution level, i.e.,  {@link ExecutionGraph} level. 
 */
public interface SchedulingPipelinedRegion extends PipelinedRegion<ExecutionVertexID,IntermediateResultPartitionID,SchedulingExecutionVertex,SchedulingResultPartition> {
}
