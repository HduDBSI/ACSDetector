/** 
 * Pipelined region on execution level, i.e.,  {@link ExecutionGraph} level. 
 */
public interface SchedulingPipelinedRegion extends PipelinedRegion<ExecutionVertexID,IntermediateResultPartitionID,SchedulingExecutionVertex,SchedulingResultPartition> {
  /** 
 * Get all distinct blocking  {@link ConsumedPartitionGroup}s.
 * @return set of {@link ConsumedPartitionGroup}s
 */
  Iterable<ConsumedPartitionGroup> getAllBlockingConsumedPartitionGroups();
}
