/** 
 * Very simple serialization schema for strings.
 */
@PublicEvolving public class SimpleStringSchema implements DeserializationSchema<String>, SerializationSchema<String> {
  private static final long serialVersionUID=1L;
  @Override public String deserialize(  byte[] message){
    return new String(message);
  }
  @Override public boolean isEndOfStream(  String nextElement){
    return false;
  }
  @Override public byte[] serialize(  String element){
    return element.getBytes();
  }
  @Override public TypeInformation<String> getProducedType(){
    return BasicTypeInfo.STRING_TYPE_INFO;
  }
}
