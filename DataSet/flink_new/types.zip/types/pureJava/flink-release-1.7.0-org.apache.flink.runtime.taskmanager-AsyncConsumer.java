/** 
 * Invokable consuming buffers in a separate Thread (not the main Task thread).
 */
public static class AsyncConsumer extends AbstractInvokable {
  public AsyncConsumer(  Environment environment){
    super(environment);
  }
  @Override public void invoke() throws Exception {
    Thread consumer=new ConsumerThread(getEnvironment().getInputGate(0));
    ASYNC_CONSUMER_THREAD=consumer;
    consumer.start();
    while (consumer.isAlive()) {
      try {
        consumer.join();
      }
 catch (      InterruptedException ignored) {
      }
    }
  }
  /** 
 * The Thread consuming buffers.
 */
private static class ConsumerThread extends Thread {
    private final InputGate inputGate;
    public ConsumerThread(    InputGate inputGate){
      this.inputGate=inputGate;
    }
    @Override public void run(){
      try {
        while (true) {
          inputGate.getNextBufferOrEvent();
        }
      }
 catch (      Exception e) {
        ASYNC_CONSUMER_EXCEPTION=e;
      }
    }
  }
}
