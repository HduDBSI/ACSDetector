private static class TestQueryParameter extends MessageQueryParameter<JobID> {
  TestQueryParameter(){
    super("jobid",MessageParameterRequisiteness.OPTIONAL);
  }
  @Override public JobID convertStringToValue(  String value){
    return JobID.fromHexString(value);
  }
  @Override public String convertValueToString(  JobID value){
    return value.toString();
  }
}
