/** 
 * Helper class to collect vertex metrics.
 * @param < T > ID type
 */
private static class VertexMetricsHelper<T> extends AnalyticHelper<Vertex<T,LongValue>> {
  private long vertexCount;
  private long edgeCount;
  private long tripletCount;
  private long maximumDegree;
  private long maximumTriplets;
  @Override public void writeRecord(  Vertex<T,LongValue> record) throws IOException {
    long degree=record.f1.getValue();
    long triplets=degree * (degree - 1) / 2;
    vertexCount++;
    edgeCount+=degree;
    tripletCount+=triplets;
    maximumDegree=Math.max(maximumDegree,degree);
    maximumTriplets=Math.max(maximumTriplets,triplets);
  }
  @Override public void close() throws IOException {
    addAccumulator(VERTEX_COUNT,new LongCounter(vertexCount));
    addAccumulator(EDGE_COUNT,new LongCounter(edgeCount));
    addAccumulator(TRIPLET_COUNT,new LongCounter(tripletCount));
    addAccumulator(MAXIMUM_DEGREE,new LongMaximum(maximumDegree));
    addAccumulator(MAXIMUM_TRIPLETS,new LongMaximum(maximumTriplets));
  }
}
