/** 
 * This class is a value type that combines a  {@link SlotInfo} with its remaining {@link ResourceProfile}.
 */
final class SlotInfoAndResources {
  @Nonnull private final SlotInfo slotInfo;
  @Nonnull private final ResourceProfile remainingResources;
  public SlotInfoAndResources(  @Nonnull SlotInfo slotInfo){
    this(slotInfo,slotInfo.getResourceProfile());
  }
  public SlotInfoAndResources(  @Nonnull SlotInfo slotInfo,  @Nonnull ResourceProfile remainingResources){
    this.slotInfo=slotInfo;
    this.remainingResources=remainingResources;
  }
  @Nonnull public SlotInfo getSlotInfo(){
    return slotInfo;
  }
  @Nonnull public ResourceProfile getRemainingResources(){
    return remainingResources;
  }
}
