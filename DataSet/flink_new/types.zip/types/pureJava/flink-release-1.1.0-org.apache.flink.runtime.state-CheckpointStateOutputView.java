/** 
 * A dedicated DataOutputView stream that produces a  {@code StateHandle<DataInputView>} when closed.
 */
public static final class CheckpointStateOutputView extends DataOutputViewStreamWrapper {
  private final CheckpointStateOutputStream out;
  public CheckpointStateOutputView(  CheckpointStateOutputStream out){
    super(out);
    this.out=out;
  }
  /** 
 * Closes the stream and gets a state handle that can create a DataInputView. producing the data written to this stream.
 * @return A state handle that can create an input stream producing the data written to this stream.
 * @throws IOException Thrown, if the stream cannot be closed.
 */
  public StateHandle<DataInputView> closeAndGetHandle() throws IOException {
    return new DataInputViewHandle(out.closeAndGetHandle());
  }
  @Override public void close() throws IOException {
    out.close();
  }
}
