/** 
 * Gathers expressions that can be converted into  {@link Sarg search arguments}. 
 */
static class SargCollector {
  final Map<RexNode,RexSargBuilder> map=new HashMap<>();
  private final RexBuilder rexBuilder;
  private final boolean negate;
  /** 
 * Count of the new terms after converting all the operands to  {@code SEARCH} on a {@link Sarg}. It is used to decide whether the new terms are simpler.
 */
  private int newTermsCount;
  SargCollector(  RexBuilder rexBuilder,  boolean negate){
    this.rexBuilder=rexBuilder;
    this.negate=negate;
  }
  private void accept(  RexNode term,  List<RexNode> newTerms){
    if (!accept_(term,newTerms)) {
      newTerms.add(term);
    }
    newTermsCount=newTerms.size();
  }
  private boolean accept_(  RexNode e,  List<RexNode> newTerms){
switch (e.getKind()) {
case LESS_THAN:
case LESS_THAN_OR_EQUAL:
case GREATER_THAN:
case GREATER_THAN_OR_EQUAL:
case EQUALS:
case NOT_EQUALS:
case SEARCH:
      return accept2(((RexCall)e).operands.get(0),((RexCall)e).operands.get(1),e.getKind(),newTerms);
default :
    return false;
}
}
private boolean accept2(RexNode left,RexNode right,SqlKind kind,List<RexNode> newTerms){
switch (left.getKind()) {
case INPUT_REF:
case FIELD_ACCESS:
switch (right.getKind()) {
case LITERAL:
    return accept1(left,kind,(RexLiteral)right,newTerms);
}
return false;
case LITERAL:
switch (right.getKind()) {
case INPUT_REF:
case FIELD_ACCESS:
return accept1(right,kind.reverse(),(RexLiteral)left,newTerms);
}
return false;
}
return false;
}
private static <E>E addFluent(List<? super E> list,E e){
list.add(e);
return e;
}
private boolean accept1(RexNode e,SqlKind kind,@Nonnull RexLiteral literal,List<RexNode> newTerms){
final RexSargBuilder b=map.computeIfAbsent(e,e2 -> addFluent(newTerms,new RexSargBuilder(e2,rexBuilder,negate)));
if (negate) {
kind=kind.negateNullSafe();
}
final Comparable value=literal.getValueAs(Comparable.class);
switch (kind) {
case LESS_THAN:
b.addRange(Range.lessThan(value),literal.getType());
return true;
case LESS_THAN_OR_EQUAL:
b.addRange(Range.atMost(value),literal.getType());
return true;
case GREATER_THAN:
b.addRange(Range.greaterThan(value),literal.getType());
return true;
case GREATER_THAN_OR_EQUAL:
b.addRange(Range.atLeast(value),literal.getType());
return true;
case EQUALS:
b.addRange(Range.singleton(value),literal.getType());
return true;
case NOT_EQUALS:
b.addRange(Range.lessThan(value),literal.getType());
b.addRange(Range.greaterThan(value),literal.getType());
return true;
case SEARCH:
final Sarg sarg=literal.getValueAs(Sarg.class);
b.addSarg(sarg,negate,literal.getType());
return true;
default :
throw new AssertionError("unexpected " + kind);
}
}
/** 
 * Returns whether it is worth to fix and convert to  {@code SEARCH} calls. 
 */
boolean needToFix(){
boolean allPoints=newTermsCount == 1;
for (RexSargBuilder builder : map.values()) {
if (builder.complexity() > 1) {
return true;
}
if (allPoints) {
Sarg sarg=builder.build(negate);
allPoints=sarg.isPoints();
}
}
return allPoints;
}
/** 
 * If a term is a call to  {@code SEARCH} on a {@link RexSargBuilder}, converts it to a {@code SEARCH} on a {@link Sarg}.
 */
RexNode fix(RexBuilder rexBuilder,RexNode term){
if (term instanceof RexSargBuilder) {
RexSargBuilder sargBuilder=(RexSargBuilder)term;
return rexBuilder.makeCall(SqlStdOperatorTable.SEARCH,sargBuilder.ref,rexBuilder.makeSearchArgumentLiteral(sargBuilder.build(negate),term.getType()));
}
return term;
}
}
