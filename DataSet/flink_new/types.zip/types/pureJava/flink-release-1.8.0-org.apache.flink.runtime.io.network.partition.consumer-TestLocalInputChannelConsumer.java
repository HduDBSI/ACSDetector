/** 
 * Consumed the configured result partitions and verifies that each channel receives the expected number of buffers.
 */
private static class TestLocalInputChannelConsumer implements Callable<Void> {
  private final SingleInputGate inputGate;
  private final int numberOfInputChannels;
  private final int numberOfExpectedBuffersPerChannel;
  public TestLocalInputChannelConsumer(  int subpartitionIndex,  int numberOfInputChannels,  int numberOfExpectedBuffersPerChannel,  BufferPool bufferPool,  ResultPartitionManager partitionManager,  TaskEventDispatcher taskEventDispatcher,  ResultPartitionID[] consumedPartitionIds){
    checkArgument(numberOfInputChannels >= 1);
    checkArgument(numberOfExpectedBuffersPerChannel >= 1);
    this.inputGate=new SingleInputGate("Test Name",new JobID(),new IntermediateDataSetID(),ResultPartitionType.PIPELINED,subpartitionIndex,numberOfInputChannels,mock(TaskActions.class),UnregisteredMetricGroups.createUnregisteredTaskMetricGroup().getIOMetricGroup(),true);
    inputGate.setBufferPool(bufferPool);
    for (int i=0; i < numberOfInputChannels; i++) {
      inputGate.setInputChannel(new IntermediateResultPartitionID(),new LocalInputChannel(inputGate,i,consumedPartitionIds[i],partitionManager,taskEventDispatcher,UnregisteredMetricGroups.createUnregisteredTaskMetricGroup().getIOMetricGroup()));
    }
    this.numberOfInputChannels=numberOfInputChannels;
    this.numberOfExpectedBuffersPerChannel=numberOfExpectedBuffersPerChannel;
  }
  @Override public Void call() throws Exception {
    final int[] numberOfBuffersPerChannel=new int[numberOfInputChannels];
    try {
      Optional<BufferOrEvent> boe;
      while ((boe=inputGate.getNextBufferOrEvent()).isPresent()) {
        if (boe.get().isBuffer()) {
          boe.get().getBuffer().recycleBuffer();
          if (++numberOfBuffersPerChannel[boe.get().getChannelIndex()] > numberOfExpectedBuffersPerChannel) {
            throw new IllegalStateException("Received more buffers than expected " + "on channel " + boe.get().getChannelIndex() + ".");
          }
        }
      }
      for (int i=0; i < numberOfBuffersPerChannel.length; i++) {
        final int actualNumberOfReceivedBuffers=numberOfBuffersPerChannel[i];
        if (actualNumberOfReceivedBuffers != numberOfExpectedBuffersPerChannel) {
          throw new IllegalStateException("Received unexpected number of buffers " + "on channel " + i + " ("+ actualNumberOfReceivedBuffers+ " instead "+ "of "+ numberOfExpectedBuffersPerChannel+ ").");
        }
      }
    }
  finally {
      inputGate.releaseAllResources();
    }
    return null;
  }
}
