/** 
 * This class provides a self-contained context for each test case. 
 */
protected class Context {
  private final ResourceManagerId resourceManagerId=ResourceManagerId.generate();
  private final ResourceTracker resourceTracker=new DefaultResourceTracker();
  private final TaskManagerTracker taskManagerTracker=new FineGrainedTaskManagerTracker();
  private final SlotStatusSyncer slotStatusSyncer=new DefaultSlotStatusSyncer(Time.seconds(10L));
  private SlotManagerMetricGroup slotManagerMetricGroup=UnregisteredMetricGroups.createUnregisteredSlotManagerMetricGroup();
  private final ScheduledExecutor scheduledExecutor=TestingUtils.defaultScheduledExecutor();
  private final Executor mainThreadExecutor=MAIN_THREAD_EXECUTOR;
  private FineGrainedSlotManager slotManager;
  private long requirementCheckDelay=0;
  final TestingResourceAllocationStrategy.Builder resourceAllocationStrategyBuilder=TestingResourceAllocationStrategy.newBuilder();
  final TestingResourceActionsBuilder resourceActionsBuilder=new TestingResourceActionsBuilder();
  final SlotManagerConfigurationBuilder slotManagerConfigurationBuilder=SlotManagerConfigurationBuilder.newBuilder();
  FineGrainedSlotManager getSlotManager(){
    return slotManager;
  }
  ResourceTracker getResourceTracker(){
    return resourceTracker;
  }
  TaskManagerTracker getTaskManagerTracker(){
    return taskManagerTracker;
  }
  ResourceManagerId getResourceManagerId(){
    return resourceManagerId;
  }
  public void setRequirementCheckDelay(  long requirementCheckDelay){
    this.requirementCheckDelay=requirementCheckDelay;
  }
  public void setSlotManagerMetricGroup(  SlotManagerMetricGroup slotManagerMetricGroup){
    this.slotManagerMetricGroup=slotManagerMetricGroup;
  }
  void runInMainThread(  Runnable runnable){
    mainThreadExecutor.execute(runnable);
  }
  void runInMainThreadAndWait(  Runnable runnable) throws InterruptedException {
    final OneShotLatch latch=new OneShotLatch();
    mainThreadExecutor.execute(() -> {
      runnable.run();
      latch.trigger();
    }
);
    latch.await();
  }
  protected final void runTest(  RunnableWithException testMethod) throws Exception {
    slotManager=new FineGrainedSlotManager(scheduledExecutor,slotManagerConfigurationBuilder.build(),slotManagerMetricGroup,resourceTracker,taskManagerTracker,slotStatusSyncer,getResourceAllocationStrategy().orElse(resourceAllocationStrategyBuilder.build()),Time.milliseconds(requirementCheckDelay));
    runInMainThreadAndWait(() -> slotManager.start(resourceManagerId,mainThreadExecutor,resourceActionsBuilder.build()));
    testMethod.run();
    CompletableFuture<Void> closeFuture=new CompletableFuture<>();
    runInMainThread(() -> {
      try {
        slotManager.close();
      }
 catch (      Exception e) {
        closeFuture.completeExceptionally(e);
      }
      closeFuture.complete(null);
    }
);
    FutureUtils.assertNoException(closeFuture);
  }
}
