/** 
 * A dummy implementation of the  {@link PartitionRequestClient} instance which is mainly usedfor tests to avoid mock.
 */
public class TestingPartitionRequestClient implements PartitionRequestClient {
  @Override public void requestSubpartition(  ResultPartitionID partitionId,  int subpartitionIndex,  RemoteInputChannel inputChannel,  int delayMs){
  }
  @Override public void notifyCreditAvailable(  RemoteInputChannel inputChannel){
  }
  @Override public void resumeConsumption(  RemoteInputChannel inputChannel){
  }
  @Override public void sendTaskEvent(  ResultPartitionID partitionId,  TaskEvent event,  RemoteInputChannel inputChannel){
  }
  @Override public void close(  RemoteInputChannel inputChannel){
  }
}
