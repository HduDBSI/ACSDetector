/** 
 * Component responsible for assigning slots to a collection of  {@link Execution}.
 */
public interface ExecutionSlotAllocator {
  /** 
 * Allocate slots for the given executions.
 * @param executionVertexSchedulingRequirements The requirements for scheduling the executions.
 */
  List<SlotExecutionVertexAssignment> allocateSlotsFor(  List<ExecutionVertexSchedulingRequirements> executionVertexSchedulingRequirements);
  /** 
 * Cancel an ongoing slot request.
 * @param executionVertexId identifying which slot request should be canceled.
 */
  void cancel(  ExecutionVertexID executionVertexId);
  /** 
 * Stop the allocator.
 */
  CompletableFuture<Void> stop();
}
