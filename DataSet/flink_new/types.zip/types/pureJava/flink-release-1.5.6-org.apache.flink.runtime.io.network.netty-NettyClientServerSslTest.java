/** 
 * Tests for communication between  {@link NettyServer} and {@link NettyClient} via SSL.
 */
public class NettyClientServerSslTest {
  /** 
 * Verify valid ssl configuration and connection.
 */
  @Test public void testValidSslConnection() throws Exception {
    testValidSslConnection(createSslConfig());
  }
  /** 
 * Verify valid (advanced) ssl configuration and connection.
 */
  @Test public void testValidSslConnectionAdvanced() throws Exception {
    Configuration sslConfig=createSslConfig();
    sslConfig.setInteger(SSL_SESSION_CACHE_SIZE,1);
    sslConfig.setInteger(SSL_SESSION_TIMEOUT,1_000);
    sslConfig.setInteger(SSL_HANDSHAKE_TIMEOUT,1_000);
    sslConfig.setInteger(SSL_CLOSE_NOTIFY_FLUSH_TIMEOUT,1_000);
    testValidSslConnection(sslConfig);
  }
  private void testValidSslConnection(  Configuration sslConfig) throws Exception {
    NettyProtocol protocol=getEmptyNettyProtocol();
    NettyConfig nettyConfig=new NettyConfig(InetAddress.getLoopbackAddress(),NetUtils.getAvailablePort(),NettyTestUtil.DEFAULT_SEGMENT_SIZE,1,sslConfig);
    NettyTestUtil.NettyServerAndClient serverAndClient=NettyTestUtil.initServerAndClient(protocol,nettyConfig);
    Channel ch=NettyTestUtil.connect(serverAndClient);
    SslHandler sslHandler=(SslHandler)ch.pipeline().get("ssl");
    assertEqualsOrDefault(sslConfig,SSL_HANDSHAKE_TIMEOUT,sslHandler.getHandshakeTimeoutMillis());
    assertEqualsOrDefault(sslConfig,SSL_CLOSE_NOTIFY_FLUSH_TIMEOUT,sslHandler.getCloseNotifyTimeoutMillis());
    ch.pipeline().addLast(new StringDecoder()).addLast(new StringEncoder());
    assertTrue(ch.writeAndFlush("test").await().isSuccess());
    SSLSessionContext sessionContext=sslHandler.engine().getSession().getSessionContext();
    assertNotNull("bug in unit test setup: session context not available",sessionContext);
    assertEqualsOrDefault(sslConfig,SSL_SESSION_CACHE_SIZE,sessionContext.getSessionCacheSize());
    int sessionTimeout=sslConfig.getInteger(SSL_SESSION_TIMEOUT);
    if (sessionTimeout != -1) {
      assertEquals(sessionTimeout / 1000,sessionContext.getSessionTimeout());
    }
 else {
      assertTrue("default value (-1) should not be propagated",sessionContext.getSessionTimeout() >= 0);
    }
    NettyTestUtil.shutdown(serverAndClient);
  }
  private static void assertEqualsOrDefault(  Configuration sslConfig,  ConfigOption<Integer> option,  long actual){
    long expected=sslConfig.getInteger(option);
    if (expected != option.defaultValue()) {
      assertEquals(expected,actual);
    }
 else {
      assertTrue("default value (" + option.defaultValue() + ") should not be propagated",actual >= 0);
    }
  }
  /** 
 * Verify failure on invalid ssl configuration.
 */
  @Test public void testInvalidSslConfiguration(){
    NettyProtocol protocol=getEmptyNettyProtocol();
    Configuration config=createSslConfig();
    config.setString(SecurityOptions.SSL_KEYSTORE_PASSWORD,"invalidpassword");
    NettyConfig nettyConfig=new NettyConfig(InetAddress.getLoopbackAddress(),NetUtils.getAvailablePort(),NettyTestUtil.DEFAULT_SEGMENT_SIZE,1,config);
    NettyTestUtil.NettyServerAndClient serverAndClient=null;
    try {
      serverAndClient=NettyTestUtil.initServerAndClient(protocol,nettyConfig);
      Assert.fail("Created server and client from invalid configuration");
    }
 catch (    Exception e) {
    }
    NettyTestUtil.shutdown(serverAndClient);
  }
  /** 
 * Verify SSL handshake error when untrusted server certificate is used.
 */
  @Test public void testSslHandshakeError() throws Exception {
    NettyProtocol protocol=getEmptyNettyProtocol();
    Configuration config=createSslConfig();
    config.setString(SecurityOptions.SSL_KEYSTORE,"src/test/resources/untrusted.keystore");
    NettyConfig nettyConfig=new NettyConfig(InetAddress.getLoopbackAddress(),NetUtils.getAvailablePort(),NettyTestUtil.DEFAULT_SEGMENT_SIZE,1,config);
    NettyTestUtil.NettyServerAndClient serverAndClient=NettyTestUtil.initServerAndClient(protocol,nettyConfig);
    Channel ch=NettyTestUtil.connect(serverAndClient);
    ch.pipeline().addLast(new StringDecoder()).addLast(new StringEncoder());
    assertFalse(ch.writeAndFlush("test").await().isSuccess());
    NettyTestUtil.shutdown(serverAndClient);
  }
  private Configuration createSslConfig(){
    Configuration flinkConfig=new Configuration();
    flinkConfig.setBoolean(SecurityOptions.SSL_ENABLED,true);
    flinkConfig.setString(SecurityOptions.SSL_KEYSTORE,"src/test/resources/local127.keystore");
    flinkConfig.setString(SecurityOptions.SSL_KEYSTORE_PASSWORD,"password");
    flinkConfig.setString(SecurityOptions.SSL_KEY_PASSWORD,"password");
    flinkConfig.setString(SecurityOptions.SSL_TRUSTSTORE,"src/test/resources/local127.truststore");
    flinkConfig.setString(SecurityOptions.SSL_TRUSTSTORE_PASSWORD,"password");
    return flinkConfig;
  }
  private static NettyProtocol getEmptyNettyProtocol(){
    return new NettyProtocol(null,null,true){
      @Override public ChannelHandler[] getServerChannelHandlers(){
        return new ChannelHandler[0];
      }
      @Override public ChannelHandler[] getClientChannelHandlers(){
        return new ChannelHandler[0];
      }
    }
;
  }
}
