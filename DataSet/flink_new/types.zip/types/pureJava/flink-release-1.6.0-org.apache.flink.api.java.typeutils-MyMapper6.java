public static class MyMapper6<A> implements MapFunction<PojoWithParameterizedFields3<A>,A> {
  private static final long serialVersionUID=1L;
  @Override public A map(  PojoWithParameterizedFields3<A> value) throws Exception {
    return null;
  }
}
