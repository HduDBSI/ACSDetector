public class IntPairSerializer extends TypeSerializer<IntPair> {
  private static final long serialVersionUID=1L;
  @Override public boolean isImmutableType(){
    return false;
  }
  @Override public IntPairSerializer duplicate(){
    return this;
  }
  @Override public IntPair createInstance(){
    return new IntPair();
  }
  @Override public IntPair copy(  IntPair from){
    return new IntPair(from.getKey(),from.getValue());
  }
  @Override public IntPair copy(  IntPair from,  IntPair reuse){
    reuse.setKey(from.getKey());
    reuse.setValue(from.getValue());
    return reuse;
  }
  @Override public int getLength(){
    return 8;
  }
  @Override public void serialize(  IntPair record,  DataOutputView target) throws IOException {
    target.writeInt(record.getKey());
    target.writeInt(record.getValue());
  }
  @Override public IntPair deserialize(  DataInputView source) throws IOException {
    return new IntPair(source.readInt(),source.readInt());
  }
  @Override public IntPair deserialize(  IntPair reuse,  DataInputView source) throws IOException {
    reuse.setKey(source.readInt());
    reuse.setValue(source.readInt());
    return reuse;
  }
  @Override public void copy(  DataInputView source,  DataOutputView target) throws IOException {
    target.write(source,8);
  }
  @Override public boolean equals(  Object obj){
    if (obj instanceof IntPairSerializer) {
      IntPairSerializer other=(IntPairSerializer)obj;
      return other.canEqual(this);
    }
 else {
      return false;
    }
  }
  @Override public boolean canEqual(  Object obj){
    return obj instanceof IntPairSerializer;
  }
  @Override public int hashCode(){
    return IntPairSerializer.class.hashCode();
  }
public static final class IntPairSerializerFactory implements TypeSerializerFactory<IntPair> {
    @Override public void writeParametersToConfig(    Configuration config){
    }
    @Override public void readParametersFromConfig(    Configuration config,    ClassLoader cl){
    }
    @Override public IntPairSerializer getSerializer(){
      return new IntPairSerializer();
    }
    @Override public Class<IntPair> getDataType(){
      return IntPair.class;
    }
    @Override public int hashCode(){
      return 42;
    }
    public boolean equals(    Object obj){
      return obj.getClass() == IntPairSerializerFactory.class;
    }
  }
}
