/** 
 * Testing open method is called. 
 */
public static class UdfWithOpen extends ScalarFunction {
  private boolean isOpened=false;
  @Override public void open(  FunctionContext context) throws Exception {
    super.open(context);
    this.isOpened=true;
  }
  public String eval(  String c){
    if (!isOpened) {
      throw new IllegalStateException("Open method is not called!");
    }
    return "$" + c;
  }
}
