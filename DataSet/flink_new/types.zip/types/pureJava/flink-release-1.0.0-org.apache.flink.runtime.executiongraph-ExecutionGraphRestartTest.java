public class ExecutionGraphRestartTest extends TestLogger {
  private final static int NUM_TASKS=31;
  @Test public void testNoManualRestart() throws Exception {
    Instance instance=ExecutionGraphTestUtils.getInstance(new SimpleActorGateway(TestingUtils.directExecutionContext()),NUM_TASKS);
    Scheduler scheduler=new Scheduler(TestingUtils.defaultExecutionContext());
    scheduler.newInstanceAvailable(instance);
    JobVertex sender=new JobVertex("Task");
    sender.setInvokableClass(Tasks.NoOpInvokable.class);
    sender.setParallelism(NUM_TASKS);
    JobGraph jobGraph=new JobGraph("Pointwise job",sender);
    ExecutionGraph eg=new ExecutionGraph(TestingUtils.defaultExecutionContext(),new JobID(),"test job",new Configuration(),AkkaUtils.getDefaultTimeout(),new NoRestartStrategy());
    eg.attachJobGraph(jobGraph.getVerticesSortedTopologicallyFromSources());
    assertEquals(JobStatus.CREATED,eg.getState());
    eg.scheduleForExecution(scheduler);
    assertEquals(JobStatus.RUNNING,eg.getState());
    eg.getAllExecutionVertices().iterator().next().fail(new Exception("Test Exception"));
    for (    ExecutionVertex vertex : eg.getAllExecutionVertices()) {
      vertex.getCurrentExecutionAttempt().cancelingComplete();
    }
    assertEquals(JobStatus.FAILED,eg.getState());
    eg.restart();
    assertEquals(JobStatus.FAILED,eg.getState());
  }
  @Test public void testConstraintsAfterRestart() throws Exception {
    Instance instance=ExecutionGraphTestUtils.getInstance(new SimpleActorGateway(TestingUtils.directExecutionContext()),NUM_TASKS);
    Scheduler scheduler=new Scheduler(TestingUtils.defaultExecutionContext());
    scheduler.newInstanceAvailable(instance);
    JobVertex groupVertex=new JobVertex("Task1");
    groupVertex.setInvokableClass(Tasks.NoOpInvokable.class);
    groupVertex.setParallelism(NUM_TASKS);
    JobVertex groupVertex2=new JobVertex("Task2");
    groupVertex2.setInvokableClass(Tasks.NoOpInvokable.class);
    groupVertex2.setParallelism(NUM_TASKS);
    SlotSharingGroup sharingGroup=new SlotSharingGroup();
    groupVertex.setSlotSharingGroup(sharingGroup);
    groupVertex2.setSlotSharingGroup(sharingGroup);
    groupVertex.setStrictlyCoLocatedWith(groupVertex2);
    JobGraph jobGraph=new JobGraph("Pointwise job",groupVertex,groupVertex2);
    ExecutionGraph eg=new ExecutionGraph(TestingUtils.defaultExecutionContext(),new JobID(),"test job",new Configuration(),AkkaUtils.getDefaultTimeout(),new FixedDelayRestartStrategy(1,0L));
    eg.attachJobGraph(jobGraph.getVerticesSortedTopologicallyFromSources());
    assertEquals(JobStatus.CREATED,eg.getState());
    eg.scheduleForExecution(scheduler);
    assertEquals(JobStatus.RUNNING,eg.getState());
    validateConstraints(eg);
    restartAfterFailure(eg,new FiniteDuration(2,TimeUnit.MINUTES),false);
    validateConstraints(eg);
    haltExecution(eg);
  }
  private void validateConstraints(  ExecutionGraph eg){
    ExecutionJobVertex[] tasks=eg.getAllVertices().values().toArray(new ExecutionJobVertex[2]);
    for (int i=0; i < NUM_TASKS; i++) {
      CoLocationConstraint constr1=tasks[0].getTaskVertices()[i].getLocationConstraint();
      CoLocationConstraint constr2=tasks[1].getTaskVertices()[i].getLocationConstraint();
      assertNotNull(constr1.getSharedSlot());
      assertTrue(constr1.isAssigned());
      assertEquals(constr1,constr2);
    }
  }
  @Test public void testRestartAutomatically() throws Exception {
    Instance instance=ExecutionGraphTestUtils.getInstance(new SimpleActorGateway(TestingUtils.directExecutionContext()),NUM_TASKS);
    Scheduler scheduler=new Scheduler(TestingUtils.defaultExecutionContext());
    scheduler.newInstanceAvailable(instance);
    JobVertex sender=new JobVertex("Task");
    sender.setInvokableClass(Tasks.NoOpInvokable.class);
    sender.setParallelism(NUM_TASKS);
    JobGraph jobGraph=new JobGraph("Pointwise job",sender);
    ExecutionGraph eg=new ExecutionGraph(TestingUtils.defaultExecutionContext(),new JobID(),"Test job",new Configuration(),AkkaUtils.getDefaultTimeout(),new FixedDelayRestartStrategy(1,1000));
    eg.attachJobGraph(jobGraph.getVerticesSortedTopologicallyFromSources());
    assertEquals(JobStatus.CREATED,eg.getState());
    eg.scheduleForExecution(scheduler);
    assertEquals(JobStatus.RUNNING,eg.getState());
    restartAfterFailure(eg,new FiniteDuration(2,TimeUnit.MINUTES),true);
  }
  @Test public void testCancelWhileRestarting() throws Exception {
    Scheduler scheduler=new Scheduler(TestingUtils.defaultExecutionContext());
    Instance instance=ExecutionGraphTestUtils.getInstance(new SimpleActorGateway(TestingUtils.directExecutionContext()),NUM_TASKS);
    scheduler.newInstanceAvailable(instance);
    ExecutionGraph executionGraph=new ExecutionGraph(TestingUtils.defaultExecutionContext(),new JobID(),"TestJob",new Configuration(),AkkaUtils.getDefaultTimeout(),new FixedDelayRestartStrategy(Integer.MAX_VALUE,Long.MAX_VALUE));
    JobVertex jobVertex=new JobVertex("NoOpInvokable");
    jobVertex.setInvokableClass(Tasks.NoOpInvokable.class);
    jobVertex.setParallelism(NUM_TASKS);
    JobGraph jobGraph=new JobGraph("TestJob",jobVertex);
    executionGraph.attachJobGraph(jobGraph.getVerticesSortedTopologicallyFromSources());
    assertEquals(JobStatus.CREATED,executionGraph.getState());
    executionGraph.scheduleForExecution(scheduler);
    assertEquals(JobStatus.RUNNING,executionGraph.getState());
    instance.markDead();
    Deadline deadline=TestingUtils.TESTING_DURATION().fromNow();
    while (deadline.hasTimeLeft() && executionGraph.getState() != JobStatus.RESTARTING) {
      Thread.sleep(100);
    }
    assertEquals(JobStatus.RESTARTING,executionGraph.getState());
    executionGraph.cancel();
    assertEquals(JobStatus.CANCELED,executionGraph.getState());
    executionGraph.restart();
    assertEquals(JobStatus.CANCELED,executionGraph.getState());
  }
  @Test public void testCancelWhileFailing() throws Exception {
    Scheduler scheduler=new Scheduler(TestingUtils.defaultExecutionContext());
    Instance instance=ExecutionGraphTestUtils.getInstance(new SimpleActorGateway(TestingUtils.directExecutionContext()),NUM_TASKS);
    scheduler.newInstanceAvailable(instance);
    ExecutionGraph executionGraph=new ExecutionGraph(TestingUtils.defaultExecutionContext(),new JobID(),"TestJob",new Configuration(),AkkaUtils.getDefaultTimeout(),new FixedDelayRestartStrategy(Integer.MAX_VALUE,Long.MAX_VALUE));
    executionGraph=spy(executionGraph);
    doNothing().when(executionGraph).jobVertexInFinalState();
    JobVertex jobVertex=new JobVertex("NoOpInvokable");
    jobVertex.setInvokableClass(Tasks.NoOpInvokable.class);
    jobVertex.setParallelism(NUM_TASKS);
    JobGraph jobGraph=new JobGraph("TestJob",jobVertex);
    executionGraph.attachJobGraph(jobGraph.getVerticesSortedTopologicallyFromSources());
    assertEquals(JobStatus.CREATED,executionGraph.getState());
    executionGraph.scheduleForExecution(scheduler);
    assertEquals(JobStatus.RUNNING,executionGraph.getState());
    instance.markDead();
    Deadline deadline=TestingUtils.TESTING_DURATION().fromNow();
    boolean success=false;
    while (deadline.hasTimeLeft() && !success) {
      success=true;
      for (      ExecutionVertex vertex : executionGraph.getAllExecutionVertices()) {
        ExecutionState state=vertex.getExecutionState();
        if (state != ExecutionState.FAILED && state != ExecutionState.CANCELED) {
          success=false;
          Thread.sleep(100);
          break;
        }
      }
    }
    assertEquals(JobStatus.FAILING,executionGraph.getState());
    executionGraph.cancel();
    assertEquals(JobStatus.CANCELLING,executionGraph.getState());
    doCallRealMethod().when(executionGraph).jobVertexInFinalState();
    executionGraph.jobVertexInFinalState();
    assertEquals(JobStatus.CANCELED,executionGraph.getState());
  }
  @Test public void testNoRestartOnUnrecoverableException() throws Exception {
    Instance instance=ExecutionGraphTestUtils.getInstance(new SimpleActorGateway(TestingUtils.directExecutionContext()),NUM_TASKS);
    Scheduler scheduler=new Scheduler(TestingUtils.defaultExecutionContext());
    scheduler.newInstanceAvailable(instance);
    JobVertex sender=new JobVertex("Task");
    sender.setInvokableClass(Tasks.NoOpInvokable.class);
    sender.setParallelism(NUM_TASKS);
    JobGraph jobGraph=new JobGraph("Pointwise job",sender);
    ExecutionGraph eg=spy(new ExecutionGraph(TestingUtils.defaultExecutionContext(),new JobID(),"Test job",new Configuration(),AkkaUtils.getDefaultTimeout(),new FixedDelayRestartStrategy(1,1000)));
    eg.attachJobGraph(jobGraph.getVerticesSortedTopologicallyFromSources());
    assertEquals(JobStatus.CREATED,eg.getState());
    eg.scheduleForExecution(scheduler);
    assertEquals(JobStatus.RUNNING,eg.getState());
    eg.getAllExecutionVertices().iterator().next().fail(new UnrecoverableException(new Exception("Test Exception")));
    assertEquals(JobStatus.FAILING,eg.getState());
    for (    ExecutionVertex vertex : eg.getAllExecutionVertices()) {
      vertex.getCurrentExecutionAttempt().cancelingComplete();
    }
    FiniteDuration timeout=new FiniteDuration(2,TimeUnit.MINUTES);
    Deadline deadline=timeout.fromNow();
    while (deadline.hasTimeLeft() && eg.getState() != JobStatus.FAILED) {
      Thread.sleep(100);
    }
    assertEquals(JobStatus.FAILED,eg.getState());
    verify(eg,never()).restart();
    RestartStrategy restartStrategy=eg.getRestartStrategy();
    assertTrue(restartStrategy instanceof FixedDelayRestartStrategy);
    assertEquals(0,((FixedDelayRestartStrategy)restartStrategy).getCurrentRestartAttempt());
  }
  /** 
 * Tests that a failing execution does not affect a restarted job. This is important if a callback handler fails an execution after it has already reached a final state and the job has been restarted.
 */
  @Test public void testFailingExecutionAfterRestart() throws Exception {
    Instance instance=ExecutionGraphTestUtils.getInstance(new SimpleActorGateway(TestingUtils.directExecutionContext()),2);
    Scheduler scheduler=new Scheduler(TestingUtils.defaultExecutionContext());
    scheduler.newInstanceAvailable(instance);
    JobVertex sender=new JobVertex("Task1");
    sender.setInvokableClass(Tasks.NoOpInvokable.class);
    sender.setParallelism(1);
    JobVertex receiver=new JobVertex("Task2");
    receiver.setInvokableClass(Tasks.NoOpInvokable.class);
    receiver.setParallelism(1);
    JobGraph jobGraph=new JobGraph("Pointwise job",sender,receiver);
    ExecutionGraph eg=new ExecutionGraph(TestingUtils.defaultExecutionContext(),new JobID(),"test job",new Configuration(),AkkaUtils.getDefaultTimeout(),new FixedDelayRestartStrategy(1,1000));
    eg.attachJobGraph(jobGraph.getVerticesSortedTopologicallyFromSources());
    assertEquals(JobStatus.CREATED,eg.getState());
    eg.scheduleForExecution(scheduler);
    assertEquals(JobStatus.RUNNING,eg.getState());
    Iterator<ExecutionVertex> executionVertices=eg.getAllExecutionVertices().iterator();
    Execution finishedExecution=executionVertices.next().getCurrentExecutionAttempt();
    Execution failedExecution=executionVertices.next().getCurrentExecutionAttempt();
    finishedExecution.markFinished();
    failedExecution.fail(new Exception("Test Exception"));
    failedExecution.cancelingComplete();
    FiniteDuration timeout=new FiniteDuration(2,TimeUnit.MINUTES);
    Deadline deadline=timeout.fromNow();
    while (deadline.hasTimeLeft() && eg.getState() != JobStatus.RUNNING) {
      Thread.sleep(100);
    }
    assertEquals(JobStatus.RUNNING,eg.getState());
    deadline=timeout.fromNow();
    boolean success=false;
    while (deadline.hasTimeLeft() && !success) {
      success=true;
      for (      ExecutionVertex vertex : eg.getAllExecutionVertices()) {
        if (vertex.getCurrentExecutionAttempt().getAssignedResource() == null) {
          success=false;
          Thread.sleep(100);
          break;
        }
      }
    }
    for (    ExecutionVertex vertex : eg.getAllExecutionVertices()) {
      assertNotNull("No assigned resource (test instability).",vertex.getCurrentAssignedResource());
      vertex.getCurrentExecutionAttempt().switchToRunning();
    }
    finishedExecution.fail(new Exception("This should have no effect"));
    for (    ExecutionVertex vertex : eg.getAllExecutionVertices()) {
      vertex.getCurrentExecutionAttempt().markFinished();
    }
    assertEquals(ExecutionState.FINISHED,finishedExecution.getState());
    assertEquals(JobStatus.FINISHED,eg.getState());
  }
  /** 
 * Tests that a graph is not restarted after cancellation via a call to {@link ExecutionGraph#fail(Throwable)}. This can happen when a slot is released concurrently with cancellation.
 */
  @Test public void testFailExecutionAfterCancel() throws Exception {
    Instance instance=ExecutionGraphTestUtils.getInstance(new SimpleActorGateway(TestingUtils.directExecutionContext()),2);
    Scheduler scheduler=new Scheduler(TestingUtils.defaultExecutionContext());
    scheduler.newInstanceAvailable(instance);
    JobVertex vertex=new JobVertex("Test Vertex");
    vertex.setInvokableClass(Tasks.NoOpInvokable.class);
    vertex.setParallelism(1);
    JobGraph jobGraph=new JobGraph("Test Job",vertex);
    jobGraph.setRestartStrategyConfiguration(RestartStrategies.fixedDelayRestart(Integer.MAX_VALUE,Integer.MAX_VALUE));
    ExecutionGraph eg=new ExecutionGraph(TestingUtils.defaultExecutionContext(),new JobID(),"test job",new Configuration(),AkkaUtils.getDefaultTimeout(),new FixedDelayRestartStrategy(1,1000000));
    eg.attachJobGraph(jobGraph.getVerticesSortedTopologicallyFromSources());
    assertEquals(JobStatus.CREATED,eg.getState());
    eg.scheduleForExecution(scheduler);
    assertEquals(JobStatus.RUNNING,eg.getState());
    eg.cancel();
    for (    ExecutionVertex v : eg.getAllExecutionVertices()) {
      v.getCurrentExecutionAttempt().fail(new Exception("Test Exception"));
    }
    assertEquals(JobStatus.CANCELED,eg.getState());
    Execution execution=eg.getAllExecutionVertices().iterator().next().getCurrentExecutionAttempt();
    execution.cancelingComplete();
    assertEquals(JobStatus.CANCELED,eg.getState());
  }
  /** 
 * Tests that it is possible to fail a graph via a call to {@link ExecutionGraph#fail(Throwable)} after cancellation.
 */
  @Test public void testFailExecutionGraphAfterCancel() throws Exception {
    Instance instance=ExecutionGraphTestUtils.getInstance(new SimpleActorGateway(TestingUtils.directExecutionContext()),2);
    Scheduler scheduler=new Scheduler(TestingUtils.defaultExecutionContext());
    scheduler.newInstanceAvailable(instance);
    JobVertex vertex=new JobVertex("Test Vertex");
    vertex.setInvokableClass(Tasks.NoOpInvokable.class);
    vertex.setParallelism(1);
    JobGraph jobGraph=new JobGraph("Test Job",vertex);
    jobGraph.setRestartStrategyConfiguration(RestartStrategies.fixedDelayRestart(Integer.MAX_VALUE,Integer.MAX_VALUE));
    ExecutionGraph eg=new ExecutionGraph(TestingUtils.defaultExecutionContext(),new JobID(),"test job",new Configuration(),AkkaUtils.getDefaultTimeout(),new FixedDelayRestartStrategy(1,1000000));
    eg.attachJobGraph(jobGraph.getVerticesSortedTopologicallyFromSources());
    assertEquals(JobStatus.CREATED,eg.getState());
    eg.scheduleForExecution(scheduler);
    assertEquals(JobStatus.RUNNING,eg.getState());
    eg.cancel();
    assertEquals(JobStatus.CANCELLING,eg.getState());
    eg.fail(new Exception("Test Exception"));
    assertEquals(JobStatus.FAILING,eg.getState());
    Execution execution=eg.getAllExecutionVertices().iterator().next().getCurrentExecutionAttempt();
    execution.cancelingComplete();
    assertEquals(JobStatus.RESTARTING,eg.getState());
  }
  private static void restartAfterFailure(  ExecutionGraph eg,  FiniteDuration timeout,  boolean haltAfterRestart) throws InterruptedException {
    eg.getAllExecutionVertices().iterator().next().fail(new Exception("Test Exception"));
    assertEquals(JobStatus.FAILING,eg.getState());
    for (    ExecutionVertex vertex : eg.getAllExecutionVertices()) {
      vertex.getCurrentExecutionAttempt().cancelingComplete();
    }
    Deadline deadline=timeout.fromNow();
    while (deadline.hasTimeLeft() && eg.getState() != JobStatus.RUNNING) {
      Thread.sleep(100);
    }
    assertEquals(JobStatus.RUNNING,eg.getState());
    deadline=timeout.fromNow();
    boolean success=false;
    while (deadline.hasTimeLeft() && !success) {
      success=true;
      for (      ExecutionVertex vertex : eg.getAllExecutionVertices()) {
        if (vertex.getCurrentExecutionAttempt().getAssignedResource() == null) {
          success=false;
          Thread.sleep(100);
          break;
        }
      }
    }
    if (haltAfterRestart) {
      if (deadline.hasTimeLeft()) {
        haltExecution(eg);
      }
 else {
        fail("Failed to wait until all execution attempts left the state DEPLOYING.");
      }
    }
  }
  private static void haltExecution(  ExecutionGraph eg){
    for (    ExecutionVertex vertex : eg.getAllExecutionVertices()) {
      vertex.getCurrentExecutionAttempt().markFinished();
    }
    assertEquals(JobStatus.FINISHED,eg.getState());
  }
}
