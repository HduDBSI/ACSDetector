/** 
 * The scalar function for SQL Client test. 
 */
public static class ScalarUDF extends ScalarFunction {
  public String eval(  Integer i,  Integer offset){
    return String.valueOf(i + offset);
  }
}
