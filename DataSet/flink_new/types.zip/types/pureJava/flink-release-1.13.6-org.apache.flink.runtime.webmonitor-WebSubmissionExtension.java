/** 
 * Container for the web submission handlers. 
 */
public class WebSubmissionExtension implements WebMonitorExtension {
  private final ArrayList<Tuple2<RestHandlerSpecification,ChannelInboundHandler>> webSubmissionHandlers;
  private final JarUploadHandler jarUploadHandler;
  private final JarRunHandler jarRunHandler;
  public WebSubmissionExtension(  Configuration configuration,  GatewayRetriever<? extends DispatcherGateway> leaderRetriever,  Map<String,String> responseHeaders,  CompletableFuture<String> localAddressFuture,  Path jarDir,  Executor executor,  Time timeout) throws Exception {
    this(configuration,leaderRetriever,responseHeaders,localAddressFuture,jarDir,executor,timeout,() -> new DetachedApplicationRunner(true));
  }
  @VisibleForTesting WebSubmissionExtension(  Configuration configuration,  GatewayRetriever<? extends DispatcherGateway> leaderRetriever,  Map<String,String> responseHeaders,  CompletableFuture<String> localAddressFuture,  Path jarDir,  Executor executor,  Time timeout,  Supplier<ApplicationRunner> applicationRunnerSupplier) throws Exception {
    webSubmissionHandlers=new ArrayList<>();
    final Executor jarRunExecutor=new SeparateThreadExecutor(new ExecutorThreadFactory.Builder().setPoolName("flink-jar-runner").build());
    jarUploadHandler=new JarUploadHandler(leaderRetriever,timeout,responseHeaders,JarUploadHeaders.getInstance(),jarDir,executor);
    final JarListHandler jarListHandler=new JarListHandler(leaderRetriever,timeout,responseHeaders,JarListHeaders.getInstance(),localAddressFuture,jarDir.toFile(),configuration,executor);
    jarRunHandler=new JarRunHandler(leaderRetriever,timeout,responseHeaders,JarRunHeaders.getInstance(),jarDir,configuration,jarRunExecutor,applicationRunnerSupplier);
    final JarDeleteHandler jarDeleteHandler=new JarDeleteHandler(leaderRetriever,timeout,responseHeaders,JarDeleteHeaders.getInstance(),jarDir,executor);
    final JarPlanHandler jarPlanHandler=new JarPlanHandler(leaderRetriever,timeout,responseHeaders,JarPlanGetHeaders.getInstance(),jarDir,configuration,jarRunExecutor);
    final JarPlanHandler postJarPlanHandler=new JarPlanHandler(leaderRetriever,timeout,responseHeaders,JarPlanPostHeaders.getInstance(),jarDir,configuration,executor);
    webSubmissionHandlers.add(Tuple2.of(JarUploadHeaders.getInstance(),jarUploadHandler));
    webSubmissionHandlers.add(Tuple2.of(JarListHeaders.getInstance(),jarListHandler));
    webSubmissionHandlers.add(Tuple2.of(JarRunHeaders.getInstance(),jarRunHandler));
    webSubmissionHandlers.add(Tuple2.of(JarDeleteHeaders.getInstance(),jarDeleteHandler));
    webSubmissionHandlers.add(Tuple2.of(JarPlanGetHeaders.getInstance(),jarPlanHandler));
    webSubmissionHandlers.add(Tuple2.of(JarPlanPostHeaders.getInstance(),postJarPlanHandler));
  }
  @Override public CompletableFuture<Void> closeAsync(){
    return CompletableFuture.completedFuture(null);
  }
  @Override public Collection<Tuple2<RestHandlerSpecification,ChannelInboundHandler>> getHandlers(){
    return webSubmissionHandlers;
  }
  @VisibleForTesting JarUploadHandler getJarUploadHandler(){
    return jarUploadHandler;
  }
  @VisibleForTesting JarRunHandler getJarRunHandler(){
    return jarRunHandler;
  }
}
