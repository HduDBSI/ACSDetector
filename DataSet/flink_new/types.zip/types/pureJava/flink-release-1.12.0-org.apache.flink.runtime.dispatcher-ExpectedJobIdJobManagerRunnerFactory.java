private static final class ExpectedJobIdJobManagerRunnerFactory implements JobManagerRunnerFactory {
  private final JobID expectedJobId;
  private final CountDownLatch createdJobManagerRunnerLatch;
  private ExpectedJobIdJobManagerRunnerFactory(  JobID expectedJobId,  CountDownLatch createdJobManagerRunnerLatch){
    this.expectedJobId=expectedJobId;
    this.createdJobManagerRunnerLatch=createdJobManagerRunnerLatch;
  }
  @Override public JobManagerRunner createJobManagerRunner(  JobGraph jobGraph,  Configuration configuration,  RpcService rpcService,  HighAvailabilityServices highAvailabilityServices,  HeartbeatServices heartbeatServices,  JobManagerSharedServices jobManagerSharedServices,  JobManagerJobMetricGroupFactory jobManagerJobMetricGroupFactory,  FatalErrorHandler fatalErrorHandler,  long initializationTimestamp) throws Exception {
    assertEquals(expectedJobId,jobGraph.getJobID());
    createdJobManagerRunnerLatch.countDown();
    return DefaultJobManagerRunnerFactory.INSTANCE.createJobManagerRunner(jobGraph,configuration,rpcService,highAvailabilityServices,heartbeatServices,jobManagerSharedServices,jobManagerJobMetricGroupFactory,fatalErrorHandler,initializationTimestamp);
  }
}
