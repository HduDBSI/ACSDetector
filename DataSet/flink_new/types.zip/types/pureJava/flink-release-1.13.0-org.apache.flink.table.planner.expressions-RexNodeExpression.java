/** 
 * Wrapper for a  {@link ResolvedExpression} that originated from a {@link RexNode}. <p>If the  {@link RexNode} was generated from a SQL expression, the expression can be made stringserializable and print the original SQL string as a summary.
 */
@Internal public final class RexNodeExpression implements ResolvedExpression {
  private final RexNode rexNode;
  private final DataType outputDataType;
  private final @Nullable String summaryString;
  private final @Nullable String serializableString;
  public RexNodeExpression(  RexNode rexNode,  DataType outputDataType,  @Nullable String summaryString,  @Nullable String serializableString){
    this.rexNode=checkNotNull(rexNode,"RexNode must not be null.");
    this.outputDataType=checkNotNull(outputDataType,"Output data type must not be null.");
    this.summaryString=summaryString;
    this.serializableString=serializableString;
  }
  public RexNode getRexNode(){
    return rexNode;
  }
  @Override public String asSummaryString(){
    if (summaryString != null) {
      return summaryString;
    }
    return rexNode.toString();
  }
  @Override public String asSerializableString(){
    if (serializableString != null) {
      return serializableString;
    }
    throw new TableException(String.format("Expression '%s' is not string serializable. Currently, only expressions that " + "originated from a SQL expression have a well-defined string representation.",asSummaryString()));
  }
  @Override public List<Expression> getChildren(){
    return Collections.emptyList();
  }
  @Override public <R>R accept(  ExpressionVisitor<R> visitor){
    return visitor.visit(this);
  }
  @Override public DataType getOutputDataType(){
    return outputDataType;
  }
  @Override public List<ResolvedExpression> getResolvedChildren(){
    return new ArrayList<>();
  }
  @Override public String toString(){
    return asSummaryString();
  }
}
