private static final class InvokableWithExceptionInInvoke extends AbstractInvokable {
  public InvokableWithExceptionInInvoke(  Environment environment){
    super(environment);
  }
  @Override public void invoke() throws Exception {
    throw new Exception("test");
  }
}
