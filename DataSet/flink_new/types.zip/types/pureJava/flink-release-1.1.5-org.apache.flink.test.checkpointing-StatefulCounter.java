private static class StatefulCounter extends RichMapFunction<Integer,Integer> implements Checkpointed<byte[]>, CheckpointListener {
  private static final Object checkpointLock=new Object();
  private static int numCompleteCalls;
  private static int numRestoreCalls;
  private static boolean restoredFromCheckpoint;
  private static final long serialVersionUID=7317800376639115920L;
  private byte[] data;
  @Override public void open(  Configuration parameters) throws Exception {
    if (data == null) {
      Random rand=new Random(getRuntimeContext().getIndexOfThisSubtask());
      data=new byte[FsStateBackend.DEFAULT_FILE_STATE_THRESHOLD + 1];
      rand.nextBytes(data);
    }
  }
  @Override public Integer map(  Integer value) throws Exception {
    for (int i=0; i < data.length; i++) {
      data[i]+=1;
    }
    return value;
  }
  @Override public byte[] snapshotState(  long checkpointId,  long checkpointTimestamp) throws Exception {
    return data;
  }
  @Override public void restoreState(  byte[] data) throws Exception {
    this.data=data;
synchronized (checkpointLock) {
      if (++numRestoreCalls == getRuntimeContext().getNumberOfParallelSubtasks()) {
        restoredFromCheckpoint=true;
        checkpointLock.notifyAll();
      }
    }
  }
  @Override public void notifyCheckpointComplete(  long checkpointId) throws Exception {
synchronized (checkpointLock) {
      numCompleteCalls++;
      checkpointLock.notifyAll();
    }
  }
  static void resetForTest(){
synchronized (checkpointLock) {
      numCompleteCalls=0;
      numRestoreCalls=0;
      restoredFromCheckpoint=false;
    }
  }
  static void awaitCompletedCheckpoints(  int parallelism,  int expectedNumberOfCompletedCheckpoints,  long timeoutMillis) throws InterruptedException, TimeoutException {
    long deadline=System.nanoTime() + timeoutMillis * 1_000_000;
synchronized (checkpointLock) {
      int expectedNumber=parallelism * expectedNumberOfCompletedCheckpoints;
      while (numCompleteCalls < expectedNumber && System.nanoTime() <= deadline) {
        checkpointLock.wait();
      }
      if (numCompleteCalls < expectedNumber) {
        throw new TimeoutException("Did not complete " + expectedNumberOfCompletedCheckpoints + " within timeout of "+ timeoutMillis+ " millis.");
      }
    }
  }
  static void awaitStateRestoredFromCheckpoint(  long timeoutMillis) throws InterruptedException, TimeoutException {
    long deadline=System.nanoTime() + timeoutMillis * 1_000_000;
synchronized (checkpointLock) {
      while (!restoredFromCheckpoint && System.currentTimeMillis() <= deadline) {
        checkpointLock.wait();
      }
      if (!restoredFromCheckpoint) {
        throw new TimeoutException("Did not restore from checkpoint within timeout of " + timeoutMillis + " millis.");
      }
    }
  }
}
