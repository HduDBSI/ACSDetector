/** 
 * Exception which is thrown when the  {@link JobClientActor} wants to submit a job tothe job manager but has not found one after a given timeout interval.
 */
public class JobClientActorConnectionTimeoutException extends Exception {
  private static final long serialVersionUID=2287747430528388637L;
  public JobClientActorConnectionTimeoutException(  String msg){
    super(msg);
  }
  public JobClientActorConnectionTimeoutException(  String msg,  Throwable cause){
    super(msg,cause);
  }
}
