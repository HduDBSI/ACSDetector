/** 
 * A TaskManagerGateway that simply acks the basic operations (deploy, cancel, update) and does not support any more advanced operations.
 */
public class SimpleAckingTaskManagerGateway implements TaskManagerGateway {
  private final String address=UUID.randomUUID().toString();
  private Optional<Consumer<ExecutionAttemptID>> optSubmitCondition;
  private Optional<Consumer<ExecutionAttemptID>> optCancelCondition;
  public SimpleAckingTaskManagerGateway(){
    optSubmitCondition=Optional.empty();
    optCancelCondition=Optional.empty();
  }
  public void setCondition(  Consumer<ExecutionAttemptID> predicate){
    optSubmitCondition=Optional.of(predicate);
  }
  public void setCancelCondition(  Consumer<ExecutionAttemptID> predicate){
    optCancelCondition=Optional.of(predicate);
  }
  @Override public String getAddress(){
    return address;
  }
  @Override public void disconnectFromJobManager(  InstanceID instanceId,  Exception cause){
  }
  @Override public void stopCluster(  ApplicationStatus applicationStatus,  String message){
  }
  @Override public CompletableFuture<StackTrace> requestStackTrace(  Time timeout){
    return FutureUtils.completedExceptionally(new UnsupportedOperationException());
  }
  @Override public CompletableFuture<StackTraceSampleResponse> requestStackTraceSample(  ExecutionAttemptID executionAttemptID,  int sampleId,  int numSamples,  Time delayBetweenSamples,  int maxStackTraceDepth,  Time timeout){
    return FutureUtils.completedExceptionally(new UnsupportedOperationException());
  }
  @Override public CompletableFuture<Acknowledge> submitTask(  TaskDeploymentDescriptor tdd,  Time timeout){
    optSubmitCondition.ifPresent(condition -> condition.accept(tdd.getExecutionAttemptId()));
    return CompletableFuture.completedFuture(Acknowledge.get());
  }
  @Override public CompletableFuture<Acknowledge> stopTask(  ExecutionAttemptID executionAttemptID,  Time timeout){
    return CompletableFuture.completedFuture(Acknowledge.get());
  }
  @Override public CompletableFuture<Acknowledge> cancelTask(  ExecutionAttemptID executionAttemptID,  Time timeout){
    optCancelCondition.ifPresent(condition -> condition.accept(executionAttemptID));
    return CompletableFuture.completedFuture(Acknowledge.get());
  }
  @Override public CompletableFuture<Acknowledge> updatePartitions(  ExecutionAttemptID executionAttemptID,  Iterable<PartitionInfo> partitionInfos,  Time timeout){
    return CompletableFuture.completedFuture(Acknowledge.get());
  }
  @Override public void failPartition(  ExecutionAttemptID executionAttemptID){
  }
  @Override public void notifyCheckpointComplete(  ExecutionAttemptID executionAttemptID,  JobID jobId,  long checkpointId,  long timestamp){
  }
  @Override public void triggerCheckpoint(  ExecutionAttemptID executionAttemptID,  JobID jobId,  long checkpointId,  long timestamp,  CheckpointOptions checkpointOptions){
  }
  @Override public CompletableFuture<TransientBlobKey> requestTaskManagerLog(  Time timeout){
    return FutureUtils.completedExceptionally(new UnsupportedOperationException());
  }
  @Override public CompletableFuture<TransientBlobKey> requestTaskManagerStdout(  Time timeout){
    return FutureUtils.completedExceptionally(new UnsupportedOperationException());
  }
}
