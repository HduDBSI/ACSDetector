private static class ValidatingSink extends RichSinkFunction<PrefixCount> implements ListCheckpointed<HashMap<Character,Long>> {
  @SuppressWarnings("unchecked") private static Map<Character,Long>[] maps=(Map<Character,Long>[])new Map<?,?>[PARALLELISM];
  private HashMap<Character,Long> counts=new HashMap<Character,Long>();
  @Override public void invoke(  PrefixCount value){
    Character first=value.prefix.charAt(0);
    Long previous=counts.get(first);
    if (previous == null) {
      counts.put(first,value.count);
    }
 else {
      counts.put(first,Math.max(previous,value.count));
    }
  }
  @Override public void close() throws Exception {
    maps[getRuntimeContext().getIndexOfThisSubtask()]=counts;
  }
  @Override public List<HashMap<Character,Long>> snapshotState(  long checkpointId,  long timestamp) throws Exception {
    return Collections.singletonList(this.counts);
  }
  @Override public void restoreState(  List<HashMap<Character,Long>> state) throws Exception {
    if (state.isEmpty() || state.size() > 1) {
      throw new RuntimeException("Test failed due to unexpected recovered state size " + state.size());
    }
    this.counts.putAll(state.get(0));
  }
}
