/** 
 * Result of a filter push down. It represents the communication of the source to the planner during optimization.
 */
final class Result {
  private final List<ResolvedExpression> acceptedFilters;
  private final List<ResolvedExpression> remainingFilters;
  private Result(  List<ResolvedExpression> acceptedFilters,  List<ResolvedExpression> remainingFilters){
    this.acceptedFilters=acceptedFilters;
    this.remainingFilters=remainingFilters;
  }
  /** 
 * Constructs a filter push-down result. <p>See the documentation of  {@link SupportsFilterPushDown} for more information.
 * @param acceptedFilters filters that are consumed by the source but may be applied on a besteffort basis
 * @param remainingFilters filters that a subsequent filter operation still needs to performduring runtime
 */
  public static Result of(  List<ResolvedExpression> acceptedFilters,  List<ResolvedExpression> remainingFilters){
    return new Result(acceptedFilters,remainingFilters);
  }
  public List<ResolvedExpression> getAcceptedFilters(){
    return acceptedFilters;
  }
  public List<ResolvedExpression> getRemainingFilters(){
    return remainingFilters;
  }
}
