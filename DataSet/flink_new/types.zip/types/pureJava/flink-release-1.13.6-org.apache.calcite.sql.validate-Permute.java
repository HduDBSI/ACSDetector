/** 
 * Permutation of fields in NATURAL JOIN or USING. 
 */
private class Permute {
  final List<ImmutableIntList> sources;
  final RelDataType rowType;
  final boolean trivial;
  Permute(  SqlNode from,  int offset){
switch (from.getKind()) {
case JOIN:
      final SqlJoin join=(SqlJoin)from;
    final Permute left=new Permute(join.getLeft(),offset);
  final int fieldCount=getValidatedNodeType(join.getLeft()).getFieldList().size();
final Permute right=new Permute(join.getRight(),offset + fieldCount);
final List<String> names=usingNames(join);
final List<ImmutableIntList> sources=new ArrayList<>();
final Set<ImmutableIntList> sourceSet=new HashSet<>();
final RelDataTypeFactory.Builder b=typeFactory.builder();
if (names != null) {
for (String name : names) {
final RelDataTypeField f=left.field(name);
final ImmutableIntList source=left.sources.get(f.getIndex());
sourceSet.add(source);
final RelDataTypeField f2=right.field(name);
final ImmutableIntList source2=right.sources.get(f2.getIndex());
sourceSet.add(source2);
sources.add(source.appendAll(source2));
final boolean nullable=(f.getType().isNullable() || join.getJoinType().generatesNullsOnLeft()) && (f2.getType().isNullable() || join.getJoinType().generatesNullsOnRight());
b.add(f).nullable(nullable);
}
}
for (RelDataTypeField f : left.rowType.getFieldList()) {
final ImmutableIntList source=left.sources.get(f.getIndex());
if (sourceSet.add(source)) {
sources.add(source);
b.add(f);
}
}
for (RelDataTypeField f : right.rowType.getFieldList()) {
final ImmutableIntList source=right.sources.get(f.getIndex());
if (sourceSet.add(source)) {
sources.add(source);
b.add(f);
}
}
rowType=b.build();
this.sources=ImmutableList.copyOf(sources);
this.trivial=left.trivial && right.trivial && (names == null || names.isEmpty());
break;
default :
rowType=getValidatedNodeType(from);
this.sources=Functions.generate(rowType.getFieldCount(),i -> ImmutableIntList.of(offset + i));
this.trivial=true;
}
}
private RelDataTypeField field(String name){
return catalogReader.nameMatcher().field(rowType,name);
}
/** 
 * Moves fields according to the permutation. 
 */
public void permute(List<SqlNode> selectItems,List<Map.Entry<String,RelDataType>> fields){
if (trivial) {
return;
}
final List<SqlNode> oldSelectItems=ImmutableList.copyOf(selectItems);
selectItems.clear();
final List<Map.Entry<String,RelDataType>> oldFields=ImmutableList.copyOf(fields);
fields.clear();
for (ImmutableIntList source : sources) {
final int p0=source.get(0);
Map.Entry<String,RelDataType> field=oldFields.get(p0);
final String name=field.getKey();
RelDataType type=field.getValue();
SqlNode selectItem=oldSelectItems.get(p0);
for (int p1 : Util.skip(source)) {
final Map.Entry<String,RelDataType> field1=oldFields.get(p1);
final SqlNode selectItem1=oldSelectItems.get(p1);
final RelDataType type1=field1.getValue();
final boolean nullable=type.isNullable() && type1.isNullable();
final RelDataType type2=SqlTypeUtil.leastRestrictiveForComparison(typeFactory,type,type1);
selectItem=SqlStdOperatorTable.AS.createCall(SqlParserPos.ZERO,SqlStdOperatorTable.COALESCE.createCall(SqlParserPos.ZERO,maybeCast(selectItem,type,type2),maybeCast(selectItem1,type1,type2)),new SqlIdentifier(name,SqlParserPos.ZERO));
type=typeFactory.createTypeWithNullability(type2,nullable);
}
fields.add(Pair.of(name,type));
selectItems.add(selectItem);
}
}
}
