private abstract static class InvokableNonInstantiable extends AbstractInvokable {
  public InvokableNonInstantiable(  Environment environment){
    super(environment);
  }
}
