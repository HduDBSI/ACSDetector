private static class TestMessageHeaders implements MessageHeaders<EmptyRequestBody,EmptyResponseBody,EmptyMessageParameters> {
  @Override public Class<EmptyRequestBody> getRequestClass(){
    return EmptyRequestBody.class;
  }
  @Override public Class<EmptyResponseBody> getResponseClass(){
    return EmptyResponseBody.class;
  }
  @Override public HttpResponseStatus getResponseStatusCode(){
    return HttpResponseStatus.OK;
  }
  @Override public String getDescription(){
    return "";
  }
  @Override public EmptyMessageParameters getUnresolvedMessageParameters(){
    return EmptyMessageParameters.getInstance();
  }
  @Override public HttpMethodWrapper getHttpMethod(){
    return HttpMethodWrapper.GET;
  }
  @Override public String getTargetRestEndpointURL(){
    return "/";
  }
}
