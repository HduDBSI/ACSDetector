/** 
 * Tests for the  {@link FileSystem} base class.
 */
public class FileSystemTest {
  @Test public void testGet() throws URISyntaxException, IOException {
    String scheme="file";
    assertTrue(WrappingProxyUtil.stripProxy(FileSystem.get(new URI(scheme + ":///test/test"))) instanceof LocalFileSystem);
    try {
      FileSystem.get(new URI(scheme + "://test/test"));
    }
 catch (    IOException ioe) {
      assertTrue(ioe.getMessage().startsWith("Found local file path with authority '"));
    }
    assertTrue(WrappingProxyUtil.stripProxy(FileSystem.get(new URI(scheme + ":/test/test"))) instanceof LocalFileSystem);
    assertTrue(WrappingProxyUtil.stripProxy(FileSystem.get(new URI(scheme + ":test/test"))) instanceof LocalFileSystem);
    assertTrue(WrappingProxyUtil.stripProxy(FileSystem.get(new URI("/test/test"))) instanceof LocalFileSystem);
    assertTrue(WrappingProxyUtil.stripProxy(FileSystem.get(new URI("test/test"))) instanceof LocalFileSystem);
  }
}
