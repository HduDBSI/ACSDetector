/** 
 * Request handler that returns back pressure stats for a single job vertex and all its sub tasks.
 */
public class JobVertexBackPressureHandler extends AbstractJobVertexRequestHandler {
  /** 
 * Back pressure stats tracker. 
 */
  private final BackPressureStatsTracker backPressureStatsTracker;
  /** 
 * Time after which stats are considered outdated. 
 */
  private final int refreshInterval;
  public JobVertexBackPressureHandler(  ExecutionGraphHolder executionGraphHolder,  BackPressureStatsTracker backPressureStatsTracker,  int refreshInterval){
    super(executionGraphHolder);
    this.backPressureStatsTracker=checkNotNull(backPressureStatsTracker,"Stats tracker");
    checkArgument(refreshInterval >= 0,"Negative timeout");
    this.refreshInterval=refreshInterval;
  }
  @Override public String handleRequest(  AccessExecutionJobVertex accessJobVertex,  Map<String,String> params) throws Exception {
    if (accessJobVertex instanceof ArchivedExecutionJobVertex) {
      return "";
    }
    ExecutionJobVertex jobVertex=(ExecutionJobVertex)accessJobVertex;
    try (StringWriter writer=new StringWriter();JsonGenerator gen=JsonFactory.jacksonFactory.createGenerator(writer)){
      gen.writeStartObject();
      Option<OperatorBackPressureStats> statsOption=backPressureStatsTracker.getOperatorBackPressureStats(jobVertex);
      if (statsOption.isDefined()) {
        OperatorBackPressureStats stats=statsOption.get();
        if (refreshInterval <= System.currentTimeMillis() - stats.getEndTimestamp()) {
          backPressureStatsTracker.triggerStackTraceSample(jobVertex);
          gen.writeStringField("status","deprecated");
        }
 else {
          gen.writeStringField("status","ok");
        }
        gen.writeStringField("backpressure-level",getBackPressureLevel(stats.getMaxBackPressureRatio()));
        gen.writeNumberField("end-timestamp",stats.getEndTimestamp());
        gen.writeArrayFieldStart("subtasks");
        int numSubTasks=stats.getNumberOfSubTasks();
        for (int i=0; i < numSubTasks; i++) {
          double ratio=stats.getBackPressureRatio(i);
          gen.writeStartObject();
          gen.writeNumberField("subtask",i);
          gen.writeStringField("backpressure-level",getBackPressureLevel(ratio));
          gen.writeNumberField("ratio",ratio);
          gen.writeEndObject();
        }
        gen.writeEndArray();
      }
 else {
        backPressureStatsTracker.triggerStackTraceSample(jobVertex);
        gen.writeStringField("status","deprecated");
      }
      gen.writeEndObject();
      gen.close();
      return writer.toString();
    }
   }
  /** 
 * Returns the back pressure level as a String.
 * @param backPressureRatio Ratio of back pressures samples to total number of samples.
 * @return Back pressure level ('no', 'low', or 'high')
 */
  static String getBackPressureLevel(  double backPressureRatio){
    if (backPressureRatio <= 0.10) {
      return "ok";
    }
 else     if (backPressureRatio <= 0.5) {
      return "low";
    }
 else {
      return "high";
    }
  }
}
