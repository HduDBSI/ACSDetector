public static class MockInputFormat extends DelimitedInputFormat<Record> {
  private static final long serialVersionUID=1L;
  private final IntValue key=new IntValue();
  private final IntValue value=new IntValue();
  private boolean opened=false;
  private boolean closed=false;
  @Override public Record readRecord(  Record target,  byte[] record,  int offset,  int numBytes){
    String line=new String(record,offset,numBytes);
    try {
      this.key.setValue(Integer.parseInt(line.substring(0,line.indexOf("_"))));
      this.value.setValue(Integer.parseInt(line.substring(line.indexOf("_") + 1,line.length())));
    }
 catch (    RuntimeException re) {
      return null;
    }
    target.setField(0,this.key);
    target.setField(1,this.value);
    return target;
  }
  public void openInputFormat(){
    Assert.assertFalse("Invalid status of the input format. Expected for opened: false, Actual: " + opened,opened);
    opened=true;
  }
  public void closeInputFormat(){
    Assert.assertFalse("Invalid status of the input format. Expected for closed: false, Actual: " + closed,closed);
    closed=true;
  }
}
