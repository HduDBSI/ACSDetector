private static final class TestSplit extends GenericInputSplit {
  public TestSplit(  int partitionNumber,  int totalNumberOfPartitions){
    super(partitionNumber,totalNumberOfPartitions);
  }
}
