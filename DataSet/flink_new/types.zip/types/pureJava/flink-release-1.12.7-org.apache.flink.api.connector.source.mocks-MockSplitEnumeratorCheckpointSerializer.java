/** 
 * Serializer for the checkpoint of  {@link MockSplitEnumerator}. 
 */
public class MockSplitEnumeratorCheckpointSerializer implements SimpleVersionedSerializer<Set<MockSourceSplit>> {
  @Override public int getVersion(){
    return 0;
  }
  @Override public byte[] serialize(  Set<MockSourceSplit> obj) throws IOException {
    return InstantiationUtil.serializeObject(new ArrayList<>(obj));
  }
  @Override public Set<MockSourceSplit> deserialize(  int version,  byte[] serialized) throws IOException {
    try {
      ArrayList<MockSourceSplit> list=InstantiationUtil.deserializeObject(serialized,getClass().getClassLoader());
      return new HashSet<>(list);
    }
 catch (    ClassNotFoundException e) {
      throw new FlinkRuntimeException("Failed to deserialize the enumerator checkpoint.");
    }
  }
}
