/** 
 * Wraps the vertex degree, out-degree, and in-degree.
 */
public static class Degrees extends Tuple3<LongValue,LongValue,LongValue> {
  private static final int HASH_SEED=0x3a12fc31;
  private Murmur3_32 hasher=new Murmur3_32(HASH_SEED);
  public Degrees(){
    this(new LongValue(),new LongValue(),new LongValue());
  }
  public Degrees(  LongValue value0,  LongValue value1,  LongValue value2){
    super(value0,value1,value2);
  }
  public LongValue getDegree(){
    return f0;
  }
  public LongValue getOutDegree(){
    return f1;
  }
  public LongValue getInDegree(){
    return f2;
  }
  @Override public int hashCode(){
    return hasher.reset().hash(f0.getValue()).hash(f1.getValue()).hash(f2.getValue()).hash();
  }
}
