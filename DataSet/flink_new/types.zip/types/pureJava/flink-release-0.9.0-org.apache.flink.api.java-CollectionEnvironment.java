public class CollectionEnvironment extends ExecutionEnvironment {
  @Override public JobExecutionResult execute(  String jobName) throws Exception {
    Plan p=createProgramPlan(jobName);
    CollectionExecutor exec=new CollectionExecutor(getConfig());
    this.lastJobExecutionResult=exec.execute(p);
    return this.lastJobExecutionResult;
  }
  /** 
 * @deprecated Please use {@link #getParallelism}
 */
  @Override @Deprecated public int getDegreeOfParallelism(){
    return getParallelism();
  }
  @Override public int getParallelism(){
    return 1;
  }
  @Override public String getExecutionPlan() throws Exception {
    throw new UnsupportedOperationException("Execution plans are not used for collection-based execution.");
  }
}
