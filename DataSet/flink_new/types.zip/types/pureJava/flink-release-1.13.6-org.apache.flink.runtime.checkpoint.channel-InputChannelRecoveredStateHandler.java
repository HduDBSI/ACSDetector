class InputChannelRecoveredStateHandler implements RecoveredChannelStateHandler<InputChannelInfo,Buffer> {
  private final InputGate[] inputGates;
  private final InflightDataRescalingDescriptor channelMapping;
  private final Map<InputChannelInfo,List<RecoveredInputChannel>> rescaledChannels=new HashMap<>();
  private final Map<Integer,RescaleMappings> oldToNewMappings=new HashMap<>();
  InputChannelRecoveredStateHandler(  InputGate[] inputGates,  InflightDataRescalingDescriptor channelMapping){
    this.inputGates=inputGates;
    this.channelMapping=channelMapping;
  }
  @Override public BufferWithContext<Buffer> getBuffer(  InputChannelInfo channelInfo) throws IOException, InterruptedException {
    RecoveredInputChannel channel=getMappedChannels(channelInfo).get(0);
    Buffer buffer=channel.requestBufferBlocking();
    return new BufferWithContext<>(wrap(buffer),buffer);
  }
  @Override public void recover(  InputChannelInfo channelInfo,  int oldSubtaskIndex,  BufferWithContext<Buffer> bufferWithContext) throws IOException {
    Buffer buffer=bufferWithContext.context;
    try {
      if (buffer.readableBytes() > 0) {
        for (        final RecoveredInputChannel channel : getMappedChannels(channelInfo)) {
          channel.onRecoveredStateBuffer(EventSerializer.toBuffer(new SubtaskConnectionDescriptor(oldSubtaskIndex,channelInfo.getInputChannelIdx()),false));
          channel.onRecoveredStateBuffer(buffer.retainBuffer());
        }
      }
    }
  finally {
      buffer.recycleBuffer();
    }
  }
  @Override public void close() throws IOException {
    for (    final InputGate inputGate : inputGates) {
      inputGate.finishReadRecoveredState();
    }
  }
  private RecoveredInputChannel getChannel(  int gateIndex,  int subPartitionIndex){
    final InputChannel inputChannel=inputGates[gateIndex].getChannel(subPartitionIndex);
    if (!(inputChannel instanceof RecoveredInputChannel)) {
      throw new IllegalStateException("Cannot restore state to a non-recovered input channel: " + inputChannel);
    }
    return (RecoveredInputChannel)inputChannel;
  }
  private List<RecoveredInputChannel> getMappedChannels(  InputChannelInfo channelInfo){
    return rescaledChannels.computeIfAbsent(channelInfo,this::calculateMapping);
  }
  private List<RecoveredInputChannel> calculateMapping(  InputChannelInfo info){
    final RescaleMappings oldToNewMapping=oldToNewMappings.computeIfAbsent(info.getGateIdx(),idx -> channelMapping.getChannelMapping(idx).invert());
    final List<RecoveredInputChannel> channels=Arrays.stream(oldToNewMapping.getMappedIndexes(info.getInputChannelIdx())).mapToObj(newChannelIndex -> getChannel(info.getGateIdx(),newChannelIndex)).collect(Collectors.toList());
    if (channels.isEmpty()) {
      throw new IllegalStateException("Recovered a buffer from old " + info + " that has no mapping in "+ channelMapping.getChannelMapping(info.getGateIdx()));
    }
    return channels;
  }
}
