/** 
 * Defines an external  {@link TableSink} to emit a streaming {@link Table} with insert, update, anddelete changes. The  {@link Table} must be have unique key fields (atomic or composite) or beappend-only. <p>If the  {@link Table} does not have a unique key and is not append-only, a {@link TableException} will be thrown.<p>The unique key of the table is configured by the  {@link UpsertStreamTableSink#setKeyFields(String[])} method.<p>The  {@link Table} will be converted into a stream of upsert and delete messages which areencoded as  {@link Tuple2}. The first field is a  {@link Boolean} flag to indicate the messagetype. The second field holds the record of the requested type  {@link T}. <p>A message with true  {@link Boolean} field is an upsert message for the configured key.<p>A message with false flag is a delete message for the configured key. <p>If the table is append-only, all messages will have a true flag and must be interpreted as insertions.
 * @param < T > Type of records that this {@link TableSink} expects and supports.
 * @deprecated This interface has been replaced by {@link DynamicTableSink}. The new interface consumes internal data structures and only works with the Blink planner. See FLIP-95 for more information.
 */
@Deprecated @PublicEvolving public interface UpsertStreamTableSink<T> extends StreamTableSink<Tuple2<Boolean,T>> {
  /** 
 * Configures the unique key fields of the  {@link Table} to write. The method is called after{@link TableSink#configure(String[],TypeInformation[])}. <p>The keys array might be empty, if the table consists of a single (updated) record. If the table does not have a key and is append-only, the keys attribute is null.
 * @param keys the field names of the table's keys, an empty array if the table has a singlerow, and null if the table is append-only and has no key.
 */
  void setKeyFields(  String[] keys);
  /** 
 * Specifies whether the  {@link Table} to write is append-only or not.
 * @param isAppendOnly true if the table is append-only, false otherwise.
 */
  void setIsAppendOnly(  Boolean isAppendOnly);
  /** 
 * Returns the requested record type. 
 */
  TypeInformation<T> getRecordType();
  @Override default TypeInformation<Tuple2<Boolean,T>> getOutputType(){
    return new TupleTypeInfo<>(Types.BOOLEAN,getRecordType());
  }
}
