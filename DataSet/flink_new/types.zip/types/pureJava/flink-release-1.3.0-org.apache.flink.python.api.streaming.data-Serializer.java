protected abstract static class Serializer<T> {
  protected ByteBuffer buffer;
  public ByteBuffer serialize(  T value){
    serializeInternal(value);
    buffer.flip();
    return buffer;
  }
  public abstract void serializeInternal(  T value);
}
