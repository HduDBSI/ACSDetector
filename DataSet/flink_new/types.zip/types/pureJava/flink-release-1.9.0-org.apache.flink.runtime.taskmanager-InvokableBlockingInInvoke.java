private static final class InvokableBlockingInInvoke extends AbstractInvokable {
  public InvokableBlockingInInvoke(  Environment environment){
    super(environment);
  }
  @Override public void invoke() throws Exception {
    awaitLatch.trigger();
synchronized (this) {
      while (true) {
        wait();
      }
    }
  }
}
