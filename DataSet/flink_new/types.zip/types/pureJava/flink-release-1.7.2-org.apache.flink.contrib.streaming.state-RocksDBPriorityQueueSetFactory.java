/** 
 * Encapsulates the logic and resources in connection with creating priority queue state structures.
 */
class RocksDBPriorityQueueSetFactory implements PriorityQueueSetFactory {
  /** 
 * Default cache size per key-group. 
 */
  private static final int DEFAULT_CACHES_SIZE=128;
  /** 
 * A shared buffer to serialize elements for the priority queue. 
 */
  @Nonnull private final DataOutputSerializer sharedElementOutView;
  /** 
 * A shared buffer to de-serialize elements for the priority queue. 
 */
  @Nonnull private final DataInputDeserializer sharedElementInView;
  RocksDBPriorityQueueSetFactory(){
    this.sharedElementOutView=new DataOutputSerializer(128);
    this.sharedElementInView=new DataInputDeserializer();
  }
  @Nonnull @Override public <T extends HeapPriorityQueueElement & PriorityComparable & Keyed>KeyGroupedInternalPriorityQueue<T> create(  @Nonnull String stateName,  @Nonnull TypeSerializer<T> byteOrderedElementSerializer){
    final Tuple2<ColumnFamilyHandle,RegisteredStateMetaInfoBase> metaInfoTuple=tryRegisterPriorityQueueMetaInfo(stateName,byteOrderedElementSerializer);
    final ColumnFamilyHandle columnFamilyHandle=metaInfoTuple.f0;
    return new KeyGroupPartitionedPriorityQueue<>(KeyExtractorFunction.forKeyedObjects(),PriorityComparator.forPriorityComparableObjects(),new KeyGroupPartitionedPriorityQueue.PartitionQueueSetFactory<T,RocksDBCachingPriorityQueueSet<T>>(){
      @Nonnull @Override public RocksDBCachingPriorityQueueSet<T> create(      int keyGroupId,      int numKeyGroups,      @Nonnull KeyExtractorFunction<T> keyExtractor,      @Nonnull PriorityComparator<T> elementPriorityComparator){
        TreeOrderedSetCache orderedSetCache=new TreeOrderedSetCache(DEFAULT_CACHES_SIZE);
        return new RocksDBCachingPriorityQueueSet<>(keyGroupId,keyGroupPrefixBytes,db,columnFamilyHandle,byteOrderedElementSerializer,sharedElementOutView,sharedElementInView,writeBatchWrapper,orderedSetCache);
      }
    }
,keyGroupRange,numberOfKeyGroups);
  }
}
