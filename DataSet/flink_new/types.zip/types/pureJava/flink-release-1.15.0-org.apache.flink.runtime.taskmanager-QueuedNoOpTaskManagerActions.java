/** 
 * Customized TaskManagerActions that queues all calls of updateTaskExecutionState. 
 */
private static class QueuedNoOpTaskManagerActions extends NoOpTaskManagerActions {
  private final BlockingQueue<TaskExecutionState> queue=new LinkedBlockingDeque<>();
  @Override public void updateTaskExecutionState(  TaskExecutionState taskExecutionState){
    queue.offer(taskExecutionState);
  }
  private void validateListenerMessage(  ExecutionState state,  Task task,  Throwable error){
    try {
      final TaskExecutionState taskState=queue.take();
      assertNotNull("There is no additional listener message",state);
      assertEquals(task.getExecutionId(),taskState.getID());
      assertEquals(state,taskState.getExecutionState());
      final Throwable t=taskState.getError(getClass().getClassLoader());
      if (error == null) {
        assertNull(t);
      }
 else {
        assertEquals(error.toString(),t.toString());
      }
    }
 catch (    InterruptedException e) {
      fail("interrupted");
    }
  }
}
