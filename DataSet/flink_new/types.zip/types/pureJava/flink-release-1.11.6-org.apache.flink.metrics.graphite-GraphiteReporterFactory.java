/** 
 * {@link MetricReporterFactory} for {@link GraphiteReporter}. 
 */
@InterceptInstantiationViaReflection(reporterClassName="org.apache.flink.metrics.graphite.GraphiteReporter") public class GraphiteReporterFactory implements MetricReporterFactory {
  @Override public MetricReporter createMetricReporter(  Properties properties){
    return new GraphiteReporter();
  }
}
