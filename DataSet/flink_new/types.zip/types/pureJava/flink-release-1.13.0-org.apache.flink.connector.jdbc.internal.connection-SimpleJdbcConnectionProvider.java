/** 
 * Simple JDBC connection provider. 
 */
@NotThreadSafe public class SimpleJdbcConnectionProvider implements JdbcConnectionProvider, Serializable {
  private static final Logger LOG=LoggerFactory.getLogger(SimpleJdbcConnectionProvider.class);
  private static final long serialVersionUID=1L;
  private final JdbcConnectionOptions jdbcOptions;
  private transient Driver loadedDriver;
  private transient Connection connection;
static {
    DriverManager.getDrivers();
  }
  public SimpleJdbcConnectionProvider(  JdbcConnectionOptions jdbcOptions){
    this.jdbcOptions=jdbcOptions;
  }
  @Override public Connection getConnection(){
    return connection;
  }
  @Override public boolean isConnectionValid() throws SQLException {
    return connection != null && connection.isValid(jdbcOptions.getConnectionCheckTimeoutSeconds());
  }
  private static Driver loadDriver(  String driverName) throws SQLException, ClassNotFoundException {
    Preconditions.checkNotNull(driverName);
    Enumeration<Driver> drivers=DriverManager.getDrivers();
    while (drivers.hasMoreElements()) {
      Driver driver=drivers.nextElement();
      if (driver.getClass().getName().equals(driverName)) {
        return driver;
      }
    }
    Class<?> clazz=Class.forName(driverName,true,Thread.currentThread().getContextClassLoader());
    try {
      return (Driver)clazz.newInstance();
    }
 catch (    Exception ex) {
      throw new SQLException("Fail to create driver of class " + driverName,ex);
    }
  }
  private Driver getLoadedDriver() throws SQLException, ClassNotFoundException {
    if (loadedDriver == null) {
      loadedDriver=loadDriver(jdbcOptions.getDriverName());
    }
    return loadedDriver;
  }
  @Override public Connection getOrEstablishConnection() throws SQLException, ClassNotFoundException {
    if (connection != null) {
      return connection;
    }
    if (jdbcOptions.getDriverName() == null) {
      connection=DriverManager.getConnection(jdbcOptions.getDbURL(),jdbcOptions.getUsername().orElse(null),jdbcOptions.getPassword().orElse(null));
    }
 else {
      Driver driver=getLoadedDriver();
      Properties info=new Properties();
      jdbcOptions.getUsername().ifPresent(user -> info.setProperty("user",user));
      jdbcOptions.getPassword().ifPresent(password -> info.setProperty("password",password));
      connection=driver.connect(jdbcOptions.getDbURL(),info);
      if (connection == null) {
        throw new SQLException("No suitable driver found for " + jdbcOptions.getDbURL(),"08001");
      }
    }
    return connection;
  }
  @Override public void closeConnection(){
    if (connection != null) {
      try {
        connection.close();
      }
 catch (      SQLException e) {
        LOG.warn("JDBC connection close failed.",e);
      }
 finally {
        connection=null;
      }
    }
  }
  @Override public Connection reestablishConnection() throws SQLException, ClassNotFoundException {
    closeConnection();
    return getOrEstablishConnection();
  }
}
