/** 
 * Skeleton for incremental machine learning algorithm consisting of a pre-computed model, which gets updated for the new inputs and new input data for which the job provides predictions. <p> This may serve as a base of a number of algorithms, e.g. updating an incremental Alternating Least Squares model while also providing the predictions. </p> <p> This example shows how to use: <ul> <li>Connected streams <li>CoFunctions <li>Tuple data types </ul>
 */
public class IncrementalLearningSkeleton {
  public static void main(  String[] args) throws Exception {
    if (!parseParameters(args)) {
      return;
    }
    StreamExecutionEnvironment env=StreamExecutionEnvironment.getExecutionEnvironment();
    DataStream<Double[]> model=env.addSource(new TrainingDataSource()).window(Time.of(5000,TimeUnit.MILLISECONDS)).reduceGroup(new PartialModelBuilder());
    DataStream<Integer> prediction=env.addSource(new NewDataSource()).connect(model).map(new Predictor());
    if (fileOutput) {
      prediction.writeAsText(outputPath,1);
    }
 else {
      prediction.print();
    }
    env.execute("Streaming Incremental Learning");
  }
  /** 
 * Feeds new data for prediction. By default it is implemented as constantly emitting the Integer 1 in a loop.
 */
public static class NewDataSource implements SourceFunction<Integer> {
    private static final long serialVersionUID=1L;
    private static final int NEW_DATA_SLEEP_TIME=1000;
    @Override public void invoke(    Collector<Integer> collector) throws Exception {
      while (true) {
        collector.collect(getNewData());
      }
    }
    private Integer getNewData() throws InterruptedException {
      Thread.sleep(NEW_DATA_SLEEP_TIME);
      return 1;
    }
  }
  /** 
 * Feeds new training data for the partial model builder. By default it is implemented as constantly emitting the Integer 1 in a loop.
 */
public static class TrainingDataSource implements SourceFunction<Integer> {
    private static final long serialVersionUID=1L;
    private static final int TRAINING_DATA_SLEEP_TIME=10;
    @Override public void invoke(    Collector<Integer> collector) throws Exception {
      while (true) {
        collector.collect(getTrainingData());
      }
    }
    private Integer getTrainingData() throws InterruptedException {
      Thread.sleep(TRAINING_DATA_SLEEP_TIME);
      return 1;
    }
  }
  /** 
 * Builds up-to-date partial models on new training data.
 */
public static class PartialModelBuilder implements GroupReduceFunction<Integer,Double[]> {
    private static final long serialVersionUID=1L;
    protected Double[] buildPartialModel(    Iterable<Integer> values){
      return new Double[]{1.};
    }
    @Override public void reduce(    Iterable<Integer> values,    Collector<Double[]> out) throws Exception {
      out.collect(buildPartialModel(values));
    }
  }
  /** 
 * Creates prediction using the model produced in batch-processing and the up-to-date partial model. <p> By defaults emits the Integer 0 for every prediction and the Integer 1 for every model update. </p>
 */
public static class Predictor implements CoMapFunction<Integer,Double[],Integer> {
    private static final long serialVersionUID=1L;
    Double[] batchModel=null;
    Double[] partialModel=null;
    @Override public Integer map1(    Integer value){
      return predict(value);
    }
    @Override public Integer map2(    Double[] value){
      partialModel=value;
      batchModel=getBatchModel();
      return 1;
    }
    protected Double[] getBatchModel(){
      return new Double[]{0.};
    }
    protected Integer predict(    Integer inTuple){
      return 0;
    }
  }
  private static boolean fileOutput=false;
  private static String outputPath;
  private static boolean parseParameters(  String[] args){
    if (args.length > 0) {
      fileOutput=true;
      if (args.length == 1) {
        outputPath=args[0];
      }
 else {
        System.err.println("Usage: IncrementalLearningSkeleton <result path>");
        return false;
      }
    }
 else {
      System.out.println("Executing IncrementalLearningSkeleton with generated data.");
      System.out.println("  Provide parameter to write to file.");
      System.out.println("  Usage: IncrementalLearningSkeleton <result path>");
    }
    return true;
  }
}
