/** 
 * An invokable that does nothing.
 */
public class DummyInvokable extends AbstractInvokable {
  @Override public void registerInputOutput(){
  }
  @Override public void invoke(){
  }
  @Override public ClassLoader getUserCodeClassLoader(){
    return getClass().getClassLoader();
  }
  @Override public int getCurrentNumberOfSubtasks(){
    return 1;
  }
  @Override public int getIndexInSubtaskGroup(){
    return 0;
  }
  @Override public final Configuration getTaskConfiguration(){
    return new Configuration();
  }
  @Override public final Configuration getJobConfiguration(){
    return new Configuration();
  }
  @Override public ExecutionConfig getExecutionConfig(){
    return new ExecutionConfig();
  }
}
