/** 
 * Filesystem-based implementation of  {@link StateChangelogStorage}. 
 */
@Experimental @ThreadSafe public class FsStateChangelogStorage implements StateChangelogStorage<ChangelogStateHandleStreamImpl> {
  private static final Logger LOG=LoggerFactory.getLogger(FsStateChangelogStorage.class);
  private final StateChangeUploader uploader;
  private final long preEmptivePersistThresholdInBytes;
  /** 
 * The log id is only needed on write to separate changes from different backends (i.e. operators) in the resulting file.
 */
  private final AtomicInteger logIdGenerator=new AtomicInteger(0);
  public FsStateChangelogStorage(  Configuration config) throws IOException {
    this(StateChangeUploader.fromConfig(config),config.get(PREEMPTIVE_PERSIST_THRESHOLD).getBytes());
  }
  @VisibleForTesting public FsStateChangelogStorage(  Path basePath,  boolean compression,  int bufferSize) throws IOException {
    this(new StateChangeFsUploader(basePath,basePath.getFileSystem(),compression,bufferSize),PREEMPTIVE_PERSIST_THRESHOLD.defaultValue().getBytes());
  }
  private FsStateChangelogStorage(  StateChangeUploader uploader,  long preEmptivePersistThresholdInBytes){
    this.uploader=uploader;
    this.preEmptivePersistThresholdInBytes=preEmptivePersistThresholdInBytes;
  }
  @Override public FsStateChangelogWriter createWriter(  String operatorID,  KeyGroupRange keyGroupRange){
    UUID logId=new UUID(0,logIdGenerator.getAndIncrement());
    LOG.info("createWriter for operator {}/{}: {}",operatorID,keyGroupRange,logId);
    return new FsStateChangelogWriter(logId,keyGroupRange,uploader,preEmptivePersistThresholdInBytes);
  }
  @Override public StateChangelogHandleReader<ChangelogStateHandleStreamImpl> createReader(){
    return new StateChangelogHandleStreamHandleReader(new StateChangeFormat());
  }
  @Override public void close() throws Exception {
    uploader.close();
  }
}
