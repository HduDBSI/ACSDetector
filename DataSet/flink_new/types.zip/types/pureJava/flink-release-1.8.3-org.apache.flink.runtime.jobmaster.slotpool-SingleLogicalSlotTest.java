/** 
 * Tests for the  {@link SingleLogicalSlot} class.
 */
public class SingleLogicalSlotTest extends TestLogger {
  @Test public void testPayloadAssignment(){
    final SingleLogicalSlot singleLogicalSlot=createSingleLogicalSlot();
    final DummyPayload dummyPayload1=new DummyPayload();
    final DummyPayload dummyPayload2=new DummyPayload();
    assertThat(singleLogicalSlot.tryAssignPayload(dummyPayload1),is(true));
    assertThat(singleLogicalSlot.tryAssignPayload(dummyPayload2),is(false));
    assertThat(singleLogicalSlot.getPayload(),sameInstance(dummyPayload1));
  }
  private SingleLogicalSlot createSingleLogicalSlot(){
    return createSingleLogicalSlot(new DummySlotOwner());
  }
  private SingleLogicalSlot createSingleLogicalSlot(  SlotOwner slotOwner){
    return new SingleLogicalSlot(new SlotRequestId(),new DummySlotContext(),null,Locality.LOCAL,slotOwner);
  }
  @Test public void testAlive() throws Exception {
    final SingleLogicalSlot singleLogicalSlot=createSingleLogicalSlot();
    final DummyPayload dummyPayload=new DummyPayload();
    assertThat(singleLogicalSlot.isAlive(),is(true));
    assertThat(singleLogicalSlot.tryAssignPayload(dummyPayload),is(true));
    assertThat(singleLogicalSlot.isAlive(),is(true));
    final CompletableFuture<?> releaseFuture=singleLogicalSlot.releaseSlot(new FlinkException("Test exception"));
    assertThat(singleLogicalSlot.isAlive(),is(false));
    releaseFuture.get();
    assertThat(singleLogicalSlot.isAlive(),is(false));
  }
  @Test public void testPayloadAssignmentAfterRelease(){
    final SingleLogicalSlot singleLogicalSlot=createSingleLogicalSlot();
    final DummyPayload dummyPayload=new DummyPayload();
    singleLogicalSlot.releaseSlot(new FlinkException("Test exception"));
    assertThat(singleLogicalSlot.tryAssignPayload(dummyPayload),is(false));
  }
  /** 
 * Tests that the  {@link PhysicalSlot.Payload#release(Throwable)} does not waitfor the payload to reach a terminal state.
 */
  @Test public void testAllocatedSlotRelease(){
    final CompletableFuture<LogicalSlot> returnSlotFuture=new CompletableFuture<>();
    final WaitingSlotOwner waitingSlotOwner=new WaitingSlotOwner(returnSlotFuture,new CompletableFuture<>());
    final SingleLogicalSlot singleLogicalSlot=createSingleLogicalSlot(waitingSlotOwner);
    final CompletableFuture<?> terminalStateFuture=new CompletableFuture<>();
    final CompletableFuture<?> failFuture=new CompletableFuture<>();
    final ManualTestingPayload dummyPayload=new ManualTestingPayload(failFuture,terminalStateFuture);
    assertThat(singleLogicalSlot.tryAssignPayload(dummyPayload),is(true));
    singleLogicalSlot.release(new FlinkException("Test exception"));
    assertThat(failFuture.isDone(),is(true));
    assertThat(returnSlotFuture.isDone(),is(false));
  }
  /** 
 * Tests that the slot release is only signaled after the owner has taken it back.
 */
  @Test public void testSlotRelease(){
    final CompletableFuture<LogicalSlot> returnedSlotFuture=new CompletableFuture<>();
    final CompletableFuture<Boolean> returnSlotResponseFuture=new CompletableFuture<>();
    final WaitingSlotOwner waitingSlotOwner=new WaitingSlotOwner(returnedSlotFuture,returnSlotResponseFuture);
    final CompletableFuture<?> terminalStateFuture=new CompletableFuture<>();
    final CompletableFuture<?> failFuture=new CompletableFuture<>();
    final ManualTestingPayload dummyPayload=new ManualTestingPayload(failFuture,terminalStateFuture);
    final SingleLogicalSlot singleLogicalSlot=createSingleLogicalSlot(waitingSlotOwner);
    assertThat(singleLogicalSlot.tryAssignPayload(dummyPayload),is(true));
    final CompletableFuture<?> releaseFuture=singleLogicalSlot.releaseSlot(new FlinkException("Test exception"));
    assertThat(releaseFuture.isDone(),is(false));
    assertThat(returnedSlotFuture.isDone(),is(false));
    assertThat(failFuture.isDone(),is(true));
    terminalStateFuture.complete(null);
    assertThat(returnedSlotFuture.isDone(),is(true));
    returnSlotResponseFuture.complete(true);
    assertThat(releaseFuture.isDone(),is(true));
  }
  /** 
 * Tests that concurrent release operations only trigger the failing of the payload and the return of the slot once.
 */
  @Test public void testConcurrentReleaseOperations() throws Exception {
    final CountingSlotOwner countingSlotOwner=new CountingSlotOwner();
    final CountingFailPayload countingFailPayload=new CountingFailPayload();
    final SingleLogicalSlot singleLogicalSlot=createSingleLogicalSlot(countingSlotOwner);
    singleLogicalSlot.tryAssignPayload(countingFailPayload);
    final ExecutorService executorService=Executors.newFixedThreadPool(4);
    try {
      final int numberConcurrentOperations=10;
      final Collection<CompletableFuture<?>> releaseOperationFutures=new ArrayList<>(numberConcurrentOperations);
      for (int i=0; i < numberConcurrentOperations; i++) {
        final CompletableFuture<Void> releaseOperationFuture=CompletableFuture.runAsync(() -> {
          try {
            singleLogicalSlot.releaseSlot(new FlinkException("Test exception")).get();
          }
 catch (          InterruptedException|ExecutionException e) {
            ExceptionUtils.checkInterrupted(e);
            throw new CompletionException(e);
          }
        }
);
        releaseOperationFutures.add(releaseOperationFuture);
      }
      final FutureUtils.ConjunctFuture<Void> releaseOperationsFuture=FutureUtils.waitForAll(releaseOperationFutures);
      releaseOperationsFuture.get();
      assertThat(countingSlotOwner.getReleaseCount(),is(1));
      assertThat(countingFailPayload.getFailCount(),is(1));
    }
  finally {
      executorService.shutdownNow();
    }
  }
private static final class CountingFailPayload implements LogicalSlot.Payload {
    private final AtomicInteger failCounter=new AtomicInteger(0);
    int getFailCount(){
      return failCounter.get();
    }
    @Override public void fail(    Throwable cause){
      failCounter.incrementAndGet();
    }
    @Override public CompletableFuture<?> getTerminalStateFuture(){
      return CompletableFuture.completedFuture(null);
    }
  }
private static final class CountingSlotOwner implements SlotOwner {
    private final AtomicInteger counter;
    private CountingSlotOwner(){
      this.counter=new AtomicInteger(0);
    }
    public int getReleaseCount(){
      return counter.get();
    }
    @Override public void returnLogicalSlot(    LogicalSlot logicalSlot){
      counter.incrementAndGet();
    }
  }
private static final class ManualTestingPayload implements LogicalSlot.Payload {
    private final CompletableFuture<?> failFuture;
    private final CompletableFuture<?> terminalStateFuture;
    private ManualTestingPayload(    CompletableFuture<?> failFuture,    CompletableFuture<?> terminalStateFuture){
      this.failFuture=failFuture;
      this.terminalStateFuture=terminalStateFuture;
    }
    @Override public void fail(    Throwable cause){
      failFuture.completeExceptionally(cause);
    }
    @Override public CompletableFuture<?> getTerminalStateFuture(){
      return terminalStateFuture;
    }
  }
private static final class WaitingSlotOwner implements SlotOwner {
    private final CompletableFuture<LogicalSlot> returnAllocatedSlotFuture;
    private final CompletableFuture<Boolean> returnAllocatedSlotResponse;
    private WaitingSlotOwner(    CompletableFuture<LogicalSlot> returnAllocatedSlotFuture,    CompletableFuture<Boolean> returnAllocatedSlotResponse){
      this.returnAllocatedSlotFuture=Preconditions.checkNotNull(returnAllocatedSlotFuture);
      this.returnAllocatedSlotResponse=Preconditions.checkNotNull(returnAllocatedSlotResponse);
    }
    @Override public void returnLogicalSlot(    LogicalSlot logicalSlot){
      returnAllocatedSlotFuture.complete(logicalSlot);
    }
  }
private static final class DummySlotContext implements SlotContext {
    private final AllocationID allocationId;
    private final TaskManagerLocation taskManagerLocation;
    private final TaskManagerGateway taskManagerGateway;
    DummySlotContext(){
      allocationId=new AllocationID();
      taskManagerLocation=new LocalTaskManagerLocation();
      taskManagerGateway=new SimpleAckingTaskManagerGateway();
    }
    @Override public AllocationID getAllocationId(){
      return allocationId;
    }
    @Override public TaskManagerLocation getTaskManagerLocation(){
      return taskManagerLocation;
    }
    @Override public int getPhysicalSlotNumber(){
      return 0;
    }
    @Override public ResourceProfile getResourceProfile(){
      return ResourceProfile.UNKNOWN;
    }
    @Override public TaskManagerGateway getTaskManagerGateway(){
      return taskManagerGateway;
    }
  }
}
