/** 
 * {@link CheckpointBarrierAligner} keep tracks of received {@link CheckpointBarrier} on givenchannels and controls the alignment, by deciding which channels should be blocked and when to release blocked channels.
 */
@Internal public class CheckpointBarrierAligner extends CheckpointBarrierHandler {
  private static final Logger LOG=LoggerFactory.getLogger(CheckpointBarrierAligner.class);
  /** 
 * Flags that indicate whether a channel is currently blocked/buffered. 
 */
  private final Map<InputChannelInfo,Boolean> blockedChannels;
  /** 
 * The total number of channels that this buffer handles data from. 
 */
  private final int totalNumberOfInputChannels;
  private final String taskName;
  /** 
 * The ID of the checkpoint for which we expect barriers. 
 */
  private long currentCheckpointId=-1L;
  /** 
 * The number of received barriers (= number of blocked/buffered channels) IMPORTANT: A canceled checkpoint must always have 0 barriers.
 */
  private int numBarriersReceived;
  /** 
 * The number of already closed channels. 
 */
  private int numClosedChannels;
  /** 
 * The timestamp as in  {@link System#nanoTime()} at which the last alignment started. 
 */
  private long startOfAlignmentTimestamp;
  /** 
 * The time (in nanoseconds) that the latest alignment took. 
 */
  private long latestAlignmentDurationNanos;
  private final InputGate[] inputGates;
  CheckpointBarrierAligner(  String taskName,  AbstractInvokable toNotifyOnCheckpoint,  InputGate... inputGates){
    super(toNotifyOnCheckpoint);
    this.taskName=taskName;
    this.inputGates=inputGates;
    blockedChannels=Arrays.stream(inputGates).flatMap(gate -> gate.getChannelInfos().stream()).collect(Collectors.toMap(Function.identity(),info -> false));
    totalNumberOfInputChannels=blockedChannels.size();
  }
  @Override public void abortPendingCheckpoint(  long checkpointId,  CheckpointException exception) throws IOException {
    if (checkpointId > currentCheckpointId && isCheckpointPending()) {
      releaseBlocksAndResetBarriers();
      notifyAbort(currentCheckpointId,exception);
    }
  }
  @Override public void releaseBlocksAndResetBarriers() throws IOException {
    LOG.debug("{}: End of stream alignment, feeding buffered data back.",taskName);
    for (    Map.Entry<InputChannelInfo,Boolean> blockedChannel : blockedChannels.entrySet()) {
      if (blockedChannel.getValue()) {
        resumeConsumption(blockedChannel.getKey());
      }
      blockedChannel.setValue(false);
    }
    numBarriersReceived=0;
    if (startOfAlignmentTimestamp > 0) {
      latestAlignmentDurationNanos=System.nanoTime() - startOfAlignmentTimestamp;
      startOfAlignmentTimestamp=0;
    }
  }
  @Override public boolean isBlocked(  InputChannelInfo channelInfo){
    return blockedChannels.get(channelInfo);
  }
  @Override public void processBarrier(  CheckpointBarrier receivedBarrier,  InputChannelInfo channelInfo) throws Exception {
    final long barrierId=receivedBarrier.getId();
    if (totalNumberOfInputChannels == 1) {
      resumeConsumption(channelInfo);
      if (barrierId > currentCheckpointId) {
        currentCheckpointId=barrierId;
        notifyCheckpoint(receivedBarrier,latestAlignmentDurationNanos);
      }
      return;
    }
    if (isCheckpointPending()) {
      if (barrierId == currentCheckpointId) {
        onBarrier(channelInfo);
      }
 else       if (barrierId > currentCheckpointId) {
        LOG.warn("{}: Received checkpoint barrier for checkpoint {} before completing current checkpoint {}. " + "Skipping current checkpoint.",taskName,barrierId,currentCheckpointId);
        notifyAbort(currentCheckpointId,new CheckpointException("Barrier id: " + barrierId,CheckpointFailureReason.CHECKPOINT_DECLINED_SUBSUMED));
        releaseBlocksAndResetBarriers();
        beginNewAlignment(barrierId,channelInfo,receivedBarrier.getTimestamp());
      }
 else {
        resumeConsumption(channelInfo);
      }
    }
 else     if (barrierId > currentCheckpointId) {
      beginNewAlignment(barrierId,channelInfo,receivedBarrier.getTimestamp());
    }
 else {
      resumeConsumption(channelInfo);
    }
    if (numBarriersReceived + numClosedChannels == totalNumberOfInputChannels) {
      if (LOG.isDebugEnabled()) {
        LOG.debug("{}: Received all barriers, triggering checkpoint {} at {}.",taskName,receivedBarrier.getId(),receivedBarrier.getTimestamp());
      }
      releaseBlocksAndResetBarriers();
      notifyCheckpoint(receivedBarrier,latestAlignmentDurationNanos);
    }
  }
  protected void beginNewAlignment(  long checkpointId,  InputChannelInfo channelInfo,  long checkpointTimestamp) throws IOException {
    markCheckpointStart(checkpointTimestamp);
    currentCheckpointId=checkpointId;
    onBarrier(channelInfo);
    startOfAlignmentTimestamp=System.nanoTime();
    if (LOG.isDebugEnabled()) {
      LOG.debug("{}: Starting stream alignment for checkpoint {}.",taskName,checkpointId);
    }
  }
  /** 
 * Blocks the given channel index, from which a barrier has been received.
 * @param channelInfo The channel to block.
 */
  protected void onBarrier(  InputChannelInfo channelInfo) throws IOException {
    if (!blockedChannels.get(channelInfo)) {
      blockedChannels.put(channelInfo,true);
      numBarriersReceived++;
      if (LOG.isDebugEnabled()) {
        LOG.debug("{}: Received barrier from channel {}.",taskName,channelInfo);
      }
    }
 else {
      throw new IOException("Stream corrupt: Repeated barrier for same checkpoint on input " + channelInfo);
    }
  }
  @Override public void processCancellationBarrier(  CancelCheckpointMarker cancelBarrier) throws Exception {
    final long barrierId=cancelBarrier.getCheckpointId();
    if (totalNumberOfInputChannels == 1) {
      if (barrierId > currentCheckpointId) {
        currentCheckpointId=barrierId;
        notifyAbortOnCancellationBarrier(barrierId);
      }
      return;
    }
    if (isCheckpointPending()) {
      if (barrierId == currentCheckpointId) {
        if (LOG.isDebugEnabled()) {
          LOG.debug("{}: Checkpoint {} canceled, aborting alignment.",taskName,barrierId);
        }
        releaseBlocksAndResetBarriers();
        notifyAbortOnCancellationBarrier(barrierId);
      }
 else       if (barrierId > currentCheckpointId) {
        LOG.warn("{}: Received cancellation barrier for checkpoint {} before completing current checkpoint {}. " + "Skipping current checkpoint.",taskName,barrierId,currentCheckpointId);
        releaseBlocksAndResetBarriers();
        currentCheckpointId=barrierId;
        startOfAlignmentTimestamp=0L;
        latestAlignmentDurationNanos=0L;
        notifyAbortOnCancellationBarrier(barrierId);
      }
    }
 else     if (barrierId > currentCheckpointId) {
      currentCheckpointId=barrierId;
      startOfAlignmentTimestamp=0L;
      latestAlignmentDurationNanos=0L;
      if (LOG.isDebugEnabled()) {
        LOG.debug("{}: Checkpoint {} canceled, skipping alignment.",taskName,barrierId);
      }
      notifyAbortOnCancellationBarrier(barrierId);
    }
  }
  @Override public void processEndOfPartition() throws Exception {
    numClosedChannels++;
    if (isCheckpointPending()) {
      notifyAbort(currentCheckpointId,new CheckpointException(CheckpointFailureReason.CHECKPOINT_DECLINED_INPUT_END_OF_STREAM));
      releaseBlocksAndResetBarriers();
    }
  }
  @Override public long getLatestCheckpointId(){
    return currentCheckpointId;
  }
  @Override public long getAlignmentDurationNanos(){
    if (startOfAlignmentTimestamp <= 0) {
      return latestAlignmentDurationNanos;
    }
 else {
      return System.nanoTime() - startOfAlignmentTimestamp;
    }
  }
  @Override protected boolean isCheckpointPending(){
    return numBarriersReceived > 0;
  }
  private void resumeConsumption(  InputChannelInfo channelInfo) throws IOException {
    InputGate inputGate=inputGates[channelInfo.getGateIdx()];
    checkState(!inputGate.isFinished(),"InputGate already finished.");
    inputGate.resumeConsumption(channelInfo.getInputChannelIdx());
  }
  @VisibleForTesting public int getNumClosedChannels(){
    return numClosedChannels;
  }
  @Override public String toString(){
    return String.format("%s: last checkpoint: %d, current barriers: %d, closed channels: %d",taskName,currentCheckpointId,numBarriersReceived,numClosedChannels);
  }
}
