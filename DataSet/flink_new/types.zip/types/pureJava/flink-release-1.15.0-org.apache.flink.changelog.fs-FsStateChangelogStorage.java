/** 
 * Filesystem-based implementation of  {@link StateChangelogStorage}. 
 */
@Experimental @ThreadSafe public class FsStateChangelogStorage implements StateChangelogStorage<ChangelogStateHandleStreamImpl> {
  private static final Logger LOG=LoggerFactory.getLogger(FsStateChangelogStorage.class);
  private final StateChangeUploadScheduler uploader;
  private final long preEmptivePersistThresholdInBytes;
  /** 
 * The log id is only needed on write to separate changes from different backends (i.e. operators) in the resulting file.
 */
  private final AtomicInteger logIdGenerator=new AtomicInteger(0);
  public FsStateChangelogStorage(  Configuration config,  TaskManagerJobMetricGroup metricGroup) throws IOException {
    this(fromConfig(config,new ChangelogStorageMetricGroup(metricGroup)),config.get(PREEMPTIVE_PERSIST_THRESHOLD).getBytes());
  }
  @VisibleForTesting public FsStateChangelogStorage(  Path basePath,  boolean compression,  int bufferSize,  ChangelogStorageMetricGroup metricGroup) throws IOException {
    this(directScheduler(new StateChangeFsUploader(basePath,basePath.getFileSystem(),compression,bufferSize,metricGroup)),PREEMPTIVE_PERSIST_THRESHOLD.defaultValue().getBytes());
  }
  @VisibleForTesting public FsStateChangelogStorage(  StateChangeUploadScheduler uploader,  long preEmptivePersistThresholdInBytes){
    this.uploader=uploader;
    this.preEmptivePersistThresholdInBytes=preEmptivePersistThresholdInBytes;
  }
  @Override public FsStateChangelogWriter createWriter(  String operatorID,  KeyGroupRange keyGroupRange,  MailboxExecutor mailboxExecutor){
    UUID logId=new UUID(0,logIdGenerator.getAndIncrement());
    LOG.info("createWriter for operator {}/{}: {}",operatorID,keyGroupRange,logId);
    return new FsStateChangelogWriter(logId,keyGroupRange,uploader,preEmptivePersistThresholdInBytes,mailboxExecutor);
  }
  @Override public StateChangelogHandleReader<ChangelogStateHandleStreamImpl> createReader(){
    return new StateChangelogHandleStreamHandleReader(new StateChangeFormat());
  }
  @Override public void close() throws Exception {
    uploader.close();
  }
  @Override public AvailabilityProvider getAvailabilityProvider(){
    return uploader.getAvailabilityProvider();
  }
}
