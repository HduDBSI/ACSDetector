/** 
 * The base implementations of  {@link KafkaSubscriber}. 
 */
class KafkaSubscriberUtils {
  private KafkaSubscriberUtils(){
  }
  static Map<String,TopicDescription> getAllTopicMetadata(  AdminClient adminClient){
    try {
      Set<String> allTopicNames=adminClient.listTopics().names().get();
      return getTopicMetadata(adminClient,allTopicNames);
    }
 catch (    Exception e) {
      throw new RuntimeException("Failed to get metadata for all topics.",e);
    }
  }
  static Map<String,TopicDescription> getTopicMetadata(  AdminClient adminClient,  Set<String> topicNames){
    try {
      return adminClient.describeTopics(topicNames).all().get();
    }
 catch (    Exception e) {
      throw new RuntimeException(String.format("Failed to get metadata for topics %s.",topicNames),e);
    }
  }
}
