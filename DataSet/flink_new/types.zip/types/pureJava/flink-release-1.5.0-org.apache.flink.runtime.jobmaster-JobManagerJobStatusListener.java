private class JobManagerJobStatusListener implements JobStatusListener {
  private volatile boolean running=true;
  @Override public void jobStatusChanges(  final JobID jobId,  final JobStatus newJobStatus,  final long timestamp,  final Throwable error){
    if (running) {
      runAsync(() -> jobStatusChanged(newJobStatus,timestamp,error));
    }
  }
  private void stop(){
    running=false;
  }
}
