/** 
 * {@link MetricReporterFactory} for {@link InfluxdbReporter}. 
 */
@InterceptInstantiationViaReflection(reporterClassName="org.apache.flink.metrics.influxdb.InfluxdbReporter") public class InfluxdbReporterFactory implements MetricReporterFactory {
  @Override public MetricReporter createMetricReporter(  Properties properties){
    return new InfluxdbReporter();
  }
}
