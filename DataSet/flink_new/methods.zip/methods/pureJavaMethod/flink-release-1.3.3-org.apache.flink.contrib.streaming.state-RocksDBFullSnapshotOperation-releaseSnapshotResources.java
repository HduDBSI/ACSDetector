/** 
 * 5) Release the snapshot object for RocksDB and clean up.
 */
public void releaseSnapshotResources(boolean canceled){
  if (null != kvStateIterators) {
    for (    Tuple2<RocksIterator,Integer> kvStateIterator : kvStateIterators) {
      IOUtils.closeQuietly(kvStateIterator.f0);
    }
    kvStateIterators=null;
  }
  if (null != snapshot) {
    if (null != stateBackend.db) {
      stateBackend.db.releaseSnapshot(snapshot);
    }
    IOUtils.closeQuietly(snapshot);
    snapshot=null;
  }
  if (null != readOptions) {
    IOUtils.closeQuietly(readOptions);
    readOptions=null;
  }
  if (canceled) {
    try {
      if (null != snapshotResultStateHandle) {
        snapshotResultStateHandle.discardState();
      }
    }
 catch (    Exception e) {
      LOG.warn("Exception occurred during snapshot state handle cleanup.",e);
    }
  }
}
