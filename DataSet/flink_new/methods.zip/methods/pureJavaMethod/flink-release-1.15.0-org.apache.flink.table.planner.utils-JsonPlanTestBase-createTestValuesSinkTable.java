protected void createTestValuesSinkTable(String tableName,String[] fieldNameAndTypes,@Nullable String partitionFields,Map<String,String> properties){
  Map<String,String> extraProperties=new HashMap<>();
  extraProperties.put("connector","values");
  properties.putAll(extraProperties);
  createTestSinkTable(tableName,fieldNameAndTypes,partitionFields,properties);
}
