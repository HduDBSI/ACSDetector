/** 
 * Executes the info action.
 * @param args Command line arguments for the info action.
 */
protected void info(String[] args) throws CliArgsException, FileNotFoundException, ProgramInvocationException {
  LOG.info("Running 'info' command.");
  final Options commandOptions=CliFrontendParser.getInfoCommandOptions();
  final CommandLine commandLine=CliFrontendParser.parse(commandOptions,args,true);
  final ProgramOptions programOptions=new ProgramOptions(commandLine);
  if (commandLine.hasOption(HELP_OPTION.getOpt())) {
    CliFrontendParser.printHelpForInfo();
    return;
  }
  if (programOptions.getJarFilePath() == null) {
    throw new CliArgsException("The program JAR file was not specified.");
  }
  LOG.info("Building program from JAR file");
  final PackagedProgram program=buildProgram(programOptions);
  try {
    int parallelism=programOptions.getParallelism();
    if (ExecutionConfig.PARALLELISM_DEFAULT == parallelism) {
      parallelism=defaultParallelism;
    }
    LOG.info("Creating program plan dump");
    Pipeline pipeline=PackagedProgramUtils.getPipelineFromProgram(program,parallelism,true);
    String jsonPlan=FlinkPipelineTranslationUtil.translateToJSONExecutionPlan(pipeline);
    if (jsonPlan != null) {
      System.out.println("----------------------- Execution Plan -----------------------");
      System.out.println(jsonPlan);
      System.out.println("--------------------------------------------------------------");
    }
 else {
      System.out.println("JSON plan could not be generated.");
    }
    String description=program.getDescription();
    if (description != null) {
      System.out.println();
      System.out.println(description);
    }
 else {
      System.out.println();
      System.out.println("No description provided.");
    }
  }
  finally {
    program.deleteExtractedLibraries();
  }
}
