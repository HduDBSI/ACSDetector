@Test(expected=CancelTaskException.class) public void testProducerFailedException() throws Exception {
  ConnectionManager connManager=mock(ConnectionManager.class);
  when(connManager.createPartitionRequestClient(any(ConnectionID.class))).thenReturn(mock(PartitionRequestClient.class));
  final RemoteInputChannel ch=InputChannelTestUtils.createRemoteInputChannel(mock(SingleInputGate.class),0,connManager);
  ch.onError(new ProducerFailedException(new RuntimeException("Expected test exception.")));
  ch.requestSubpartition(0);
  ch.getNextBuffer();
}
