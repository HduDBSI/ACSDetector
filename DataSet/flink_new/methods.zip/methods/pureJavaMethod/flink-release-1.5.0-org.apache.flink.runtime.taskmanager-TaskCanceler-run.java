@Override public void run(){
  try {
    try {
      invokable.cancel();
    }
 catch (    Throwable t) {
      ExceptionUtils.rethrowIfFatalError(t);
      logger.error("Error while canceling the task {}.",taskName,t);
    }
    for (    ResultPartition partition : producedPartitions) {
      try {
        partition.destroyBufferPool();
      }
 catch (      Throwable t) {
        ExceptionUtils.rethrowIfFatalError(t);
        LOG.error("Failed to release result partition buffer pool for task {}.",taskName,t);
      }
    }
    for (    SingleInputGate inputGate : inputGates) {
      try {
        inputGate.releaseAllResources();
      }
 catch (      Throwable t) {
        ExceptionUtils.rethrowIfFatalError(t);
        LOG.error("Failed to release input gate for task {}.",taskName,t);
      }
    }
    executer.interrupt();
  }
 catch (  Throwable t) {
    ExceptionUtils.rethrowIfFatalError(t);
    logger.error("Error in the task canceler for task {}.",taskName,t);
  }
}
