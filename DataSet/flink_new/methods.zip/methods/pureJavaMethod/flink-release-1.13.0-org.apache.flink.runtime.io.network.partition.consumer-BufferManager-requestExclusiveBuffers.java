/** 
 * Requests exclusive buffers from the provider. 
 */
void requestExclusiveBuffers(int numExclusiveBuffers) throws IOException {
  Collection<MemorySegment> segments=globalPool.requestMemorySegments(numExclusiveBuffers);
  checkArgument(!segments.isEmpty(),"The number of exclusive buffers per channel should be larger than 0.");
synchronized (bufferQueue) {
    for (    MemorySegment segment : segments) {
      bufferQueue.addExclusiveBuffer(new NetworkBuffer(segment,this),numRequiredBuffers);
    }
  }
}
