@Override public SchemaCoder get(){
  return new ConfluentSchemaRegistryCoder(this.subject,new CachedSchemaRegistryClient(url,identityMapCapacity));
}
