/** 
 * Serializes the given metrics and returns the resulting byte array. <p>Should a  {@link Metric} accessed in this method throw an exception it will be omitted from the returned{@link MetricSerializationResult}. <p>If the serialization of any primitive or String fails then the returned  {@link MetricSerializationResult}is partially corrupted. Such a result can be deserialized safely by {@link MetricDumpDeserializer#deserialize(MetricSerializationResult)}; however only metrics that were fully serialized before the failure will be returned.
 * @param counters   counters to serialize
 * @param gauges     gauges to serialize
 * @param histograms histograms to serialize
 * @return MetricSerializationResult containing the serialized metrics and the count of each metric type
 */
public MetricSerializationResult serialize(Map<Counter,Tuple2<QueryScopeInfo,String>> counters,Map<Gauge<?>,Tuple2<QueryScopeInfo,String>> gauges,Map<Histogram,Tuple2<QueryScopeInfo,String>> histograms,Map<Meter,Tuple2<QueryScopeInfo,String>> meters){
  buffer.clear();
  int numCounters=0;
  for (  Map.Entry<Counter,Tuple2<QueryScopeInfo,String>> entry : counters.entrySet()) {
    try {
      serializeCounter(buffer,entry.getValue().f0,entry.getValue().f1,entry.getKey());
      numCounters++;
    }
 catch (    Exception e) {
      LOG.debug("Failed to serialize counter.",e);
    }
  }
  int numGauges=0;
  for (  Map.Entry<Gauge<?>,Tuple2<QueryScopeInfo,String>> entry : gauges.entrySet()) {
    try {
      serializeGauge(buffer,entry.getValue().f0,entry.getValue().f1,entry.getKey());
      numGauges++;
    }
 catch (    Exception e) {
      LOG.debug("Failed to serialize gauge.",e);
    }
  }
  int numHistograms=0;
  for (  Map.Entry<Histogram,Tuple2<QueryScopeInfo,String>> entry : histograms.entrySet()) {
    try {
      serializeHistogram(buffer,entry.getValue().f0,entry.getValue().f1,entry.getKey());
      numHistograms++;
    }
 catch (    Exception e) {
      LOG.debug("Failed to serialize histogram.",e);
    }
  }
  int numMeters=0;
  for (  Map.Entry<Meter,Tuple2<QueryScopeInfo,String>> entry : meters.entrySet()) {
    try {
      serializeMeter(buffer,entry.getValue().f0,entry.getValue().f1,entry.getKey());
      numMeters++;
    }
 catch (    Exception e) {
      LOG.debug("Failed to serialize meter.",e);
    }
  }
  return new MetricSerializationResult(buffer.getCopyOfBuffer(),numCounters,numGauges,numMeters,numHistograms);
}
