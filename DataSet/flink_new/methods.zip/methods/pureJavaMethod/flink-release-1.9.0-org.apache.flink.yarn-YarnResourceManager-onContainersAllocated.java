@Override public void onContainersAllocated(List<Container> containers){
  runAsync(() -> {
    final Collection<AMRMClient.ContainerRequest> pendingRequests=getPendingRequests();
    final Iterator<AMRMClient.ContainerRequest> pendingRequestsIterator=pendingRequests.iterator();
    for (    Container container : containers) {
      log.info("Received new container: {} - Remaining pending container requests: {}",container.getId(),numPendingContainerRequests);
      if (numPendingContainerRequests > 0) {
        removeContainerRequest(pendingRequestsIterator.next());
        final String containerIdStr=container.getId().toString();
        final ResourceID resourceId=new ResourceID(containerIdStr);
        workerNodeMap.put(resourceId,new YarnWorkerNode(container));
        try {
          ContainerLaunchContext taskExecutorLaunchContext=createTaskExecutorLaunchContext(container.getResource(),containerIdStr,container.getNodeId().getHost());
          nodeManagerClient.startContainer(container,taskExecutorLaunchContext);
        }
 catch (        Throwable t) {
          log.error("Could not start TaskManager in container {}.",container.getId(),t);
          workerNodeMap.remove(resourceId);
          resourceManagerClient.releaseAssignedContainer(container.getId());
          requestYarnContainerIfRequired();
        }
      }
 else {
        log.info("Returning excess container {}.",container.getId());
        resourceManagerClient.releaseAssignedContainer(container.getId());
      }
    }
    if (numPendingContainerRequests <= 0) {
      resourceManagerClient.setHeartbeatInterval(yarnHeartbeatIntervalMillis);
    }
  }
);
}
