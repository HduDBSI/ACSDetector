public StreamTaskSourceOutput(Output<StreamRecord<?>> chainedSourceOutput,StreamStatusMaintainer streamStatusMaintainer,WatermarkGauge inputWatermarkGauge,MultiStreamStreamStatusTracker streamStatusTracker,int inputIndex){
  super(chainedSourceOutput,streamStatusMaintainer,new SimpleCounter(),inputWatermarkGauge);
  this.streamStatusTracker=streamStatusTracker;
  this.inputIndex=inputIndex;
}
