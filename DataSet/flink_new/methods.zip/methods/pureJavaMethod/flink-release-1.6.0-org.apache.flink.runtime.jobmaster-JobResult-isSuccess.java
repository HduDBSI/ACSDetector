/** 
 * Returns  {@code true} if the job finished successfully.
 */
public boolean isSuccess(){
  return serializedThrowable == null;
}
