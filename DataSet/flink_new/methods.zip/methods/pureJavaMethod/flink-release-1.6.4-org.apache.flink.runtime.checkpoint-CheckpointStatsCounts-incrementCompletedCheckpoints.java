/** 
 * Increments the number of successfully completed checkpoints. <p>It is expected that this follows a previous call to {@link #incrementInProgressCheckpoints()}.
 */
void incrementCompletedCheckpoints(){
  if (canDecrementOfInProgressCheckpointsNumber()) {
    numInProgressCheckpoints--;
  }
  numCompletedCheckpoints++;
}
