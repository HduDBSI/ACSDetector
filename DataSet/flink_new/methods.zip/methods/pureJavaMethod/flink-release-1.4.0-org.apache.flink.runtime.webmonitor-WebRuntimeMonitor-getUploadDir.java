private File getUploadDir(Configuration configuration){
  File baseDir=new File(configuration.getString(WebOptions.UPLOAD_DIR,getBaseDirStr(configuration)));
  boolean uploadDirSpecified=configuration.contains(WebOptions.UPLOAD_DIR);
  return uploadDirSpecified ? baseDir : new File(baseDir,"flink-web-" + UUID.randomUUID());
}
