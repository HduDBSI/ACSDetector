@Test public void testWithCompleteGraph() throws Exception {
  validate(completeGraph,completeGraphVertexCount,1.0);
}
