public JobVertexMetricsHandler(GatewayRetriever<? extends RestfulGateway> leaderRetriever,Time timeout,Map<String,String> headers,MetricFetcher metricFetcher){
  super(leaderRetriever,timeout,headers,JobVertexMetricsHeaders.getInstance(),metricFetcher);
}
