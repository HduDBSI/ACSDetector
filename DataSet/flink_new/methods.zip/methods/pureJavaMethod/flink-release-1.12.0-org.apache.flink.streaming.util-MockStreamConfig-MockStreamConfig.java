public MockStreamConfig(Configuration configuration,int numberOfOutputs){
  super(configuration);
  setChainStart();
  setNumberOfOutputs(numberOfOutputs);
  setTypeSerializerOut(new StringSerializer());
  setVertexID(0);
  setStreamOperator(new TestSequentialReadingStreamOperator("test operator"));
  setOperatorID(new OperatorID());
  StreamOperator dummyOperator=new AbstractStreamOperator(){
    private static final long serialVersionUID=1L;
  }
;
  StreamNode sourceVertex=new StreamNode(0,null,null,dummyOperator,"source",SourceStreamTask.class);
  StreamNode targetVertex=new StreamNode(1,null,null,dummyOperator,"target",SourceStreamTask.class);
  List<StreamEdge> outEdgesInOrder=new ArrayList<>(numberOfOutputs);
  for (int i=0; i < numberOfOutputs; i++) {
    outEdgesInOrder.add(new StreamEdge(sourceVertex,targetVertex,numberOfOutputs,new BroadcastPartitioner<>(),null));
  }
  setOutEdgesInOrder(outEdgesInOrder);
  setNonChainedOutputs(outEdgesInOrder);
}
