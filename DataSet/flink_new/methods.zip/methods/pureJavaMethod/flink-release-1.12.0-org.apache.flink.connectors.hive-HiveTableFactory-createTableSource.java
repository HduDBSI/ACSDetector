@Override public TableSource createTableSource(TableSourceFactory.Context context){
  CatalogTable table=checkNotNull(context.getTable());
  Preconditions.checkArgument(table instanceof CatalogTableImpl);
  boolean isGeneric=Boolean.parseBoolean(table.getProperties().get(CatalogConfig.IS_GENERIC));
  if (!isGeneric && !context.isTemporary()) {
    throw new UnsupportedOperationException("Hive table should be resolved by HiveDynamicTableFactory.");
  }
 else {
    return TableFactoryUtil.findAndCreateTableSource(context);
  }
}
