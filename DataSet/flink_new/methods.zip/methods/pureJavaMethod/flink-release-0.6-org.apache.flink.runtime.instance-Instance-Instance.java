/** 
 * Constructs an abstract instance object.
 * @param instanceConnectionInfo the connection info identifying the instance
 * @param parentNode the parent node in the network topology
 * @param networkTopology the network topology this node is a part of
 * @param hardwareDescription the hardware description provided by the instance itself
 */
public Instance(final InstanceConnectionInfo instanceConnectionInfo,final NetworkNode parentNode,final NetworkTopology networkTopology,final HardwareDescription hardwareDescription,int numberOfSlots){
  super((instanceConnectionInfo == null) ? null : instanceConnectionInfo.toString(),parentNode,networkTopology);
  this.instanceConnectionInfo=instanceConnectionInfo;
  this.hardwareDescription=hardwareDescription;
  this.numberOfSlots=numberOfSlots;
}
