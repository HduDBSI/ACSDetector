/** 
 * Generates a query to determine if a row exists in the table. The returned string will be used as a  {@link java.sql.PreparedStatement}. <p>By default, the dialect will fallback to a simple  {@code SELECT} query.
 */
String getRowExistsStatement(String tableName,String[] conditionFields);
