/** 
 * Creates a new solution set update output collector. <p/> This collector is used by  {@link IterationIntermediatePactTask} or {@link IterationTailPactTask} to update thesolution set of workset iterations. Depending on the task configuration, either a fast (non-probing) {@link org.apache.flink.runtime.iterative.io.SolutionSetFastUpdateOutputCollector} or normal (re-probing){@link SolutionSetUpdateOutputCollector} is created.<p/> If a non-null delegate is given, the new  {@link Collector} will write back to the solution set and also callcollect(T) of the delegate.
 * @param delegate null -OR- a delegate collector to be called by the newly created collector
 * @return a new {@link org.apache.flink.runtime.iterative.io.SolutionSetFastUpdateOutputCollector} or{@link SolutionSetUpdateOutputCollector}
 */
protected Collector<OT> createSolutionSetUpdateOutputCollector(Collector<OT> delegate){
  Broker<Object> solutionSetBroker=SolutionSetBroker.instance();
  Object ss=solutionSetBroker.get(brokerKey());
  if (ss instanceof CompactingHashTable) {
    @SuppressWarnings("unchecked") CompactingHashTable<OT> solutionSet=(CompactingHashTable<OT>)ss;
    TypeSerializer<OT> serializer=getOutputSerializer();
    return new SolutionSetUpdateOutputCollector<OT>(solutionSet,serializer,delegate);
  }
 else   if (ss instanceof JoinHashMap) {
    @SuppressWarnings("unchecked") JoinHashMap<OT> map=(JoinHashMap<OT>)ss;
    return new SolutionSetObjectsUpdateOutputCollector<OT>(map,delegate);
  }
 else {
    throw new RuntimeException("Unrecognized solution set handle: " + ss);
  }
}
