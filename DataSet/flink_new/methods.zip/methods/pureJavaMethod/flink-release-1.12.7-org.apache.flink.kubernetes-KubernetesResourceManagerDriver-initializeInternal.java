@Override protected void initializeInternal() throws Exception {
  podsWatchOpt=watchTaskManagerPods();
  recoverWorkerNodesFromPreviousAttempts();
  this.running=true;
}
