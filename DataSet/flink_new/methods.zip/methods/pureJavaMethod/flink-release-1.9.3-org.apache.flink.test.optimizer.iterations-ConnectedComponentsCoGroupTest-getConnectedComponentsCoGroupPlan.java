public static Plan getConnectedComponentsCoGroupPlan(){
  PreviewPlanEnvironment env=new PreviewPlanEnvironment();
  env.setAsContext();
  try {
    connectedComponentsWithCoGroup(new String[]{DEFAULT_PARALLELISM_STRING,IN_FILE,IN_FILE,OUT_FILE,"100"});
  }
 catch (  ProgramAbortException pae) {
  }
catch (  Exception e) {
    e.printStackTrace();
    Assert.fail("connectedComponentsWithCoGroup failed with an exception");
  }
  return env.getPlan();
}
