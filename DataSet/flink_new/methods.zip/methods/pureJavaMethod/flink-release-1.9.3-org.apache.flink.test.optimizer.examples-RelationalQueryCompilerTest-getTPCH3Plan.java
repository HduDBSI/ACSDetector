public static Plan getTPCH3Plan(){
  PreviewPlanEnvironment env=new PreviewPlanEnvironment();
  env.setAsContext();
  try {
    tcph3(new String[]{DEFAULT_PARALLELISM_STRING,IN_FILE,IN_FILE,OUT_FILE});
  }
 catch (  OptimizerPlanEnvironment.ProgramAbortException pae) {
  }
catch (  Exception e) {
    e.printStackTrace();
    Assert.fail("tcph3 failed with an exception");
  }
  return env.getPlan();
}
