@Override public TypeSerializer<Serializable> duplicate(){
  return this;
}
