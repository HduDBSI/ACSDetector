/** 
 * Retrieves a fully qualified table. If the path is not yet fully qualified use {@link #qualifyIdentifier(UnresolvedIdentifier)} first.
 * @param objectIdentifier full path of the table to retrieve
 * @return table that the path points to.
 */
public Optional<TableLookupResult> getTable(ObjectIdentifier objectIdentifier){
  Preconditions.checkNotNull(schemaResolver,"schemaResolver should not be null");
  CatalogBaseTable temporaryTable=temporaryTables.get(objectIdentifier);
  if (temporaryTable != null) {
    TableSchema resolvedSchema=resolveTableSchema(temporaryTable);
    return Optional.of(TableLookupResult.temporary(temporaryTable,resolvedSchema));
  }
 else {
    return getPermanentTable(objectIdentifier);
  }
}
