@Override public Boolean call() throws Exception {
  try {
    for (int i=0; i < numBuffersToRequest; i++) {
      Buffer buffer=checkNotNull(bufferProvider.requestBuffer());
      buffer.recycleBuffer();
    }
  }
 catch (  Throwable t) {
    return false;
  }
  return true;
}
