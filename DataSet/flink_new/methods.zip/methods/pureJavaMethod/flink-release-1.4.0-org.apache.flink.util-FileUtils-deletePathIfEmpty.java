/** 
 * Deletes the path if it is empty. A path can only be empty if it is a directory which does not contain any other directories/files.
 * @param fileSystem to use
 * @param path to be deleted if empty
 * @return true if the path could be deleted; otherwise false
 * @throws IOException if the delete operation fails
 */
public static boolean deletePathIfEmpty(FileSystem fileSystem,Path path) throws IOException {
  final FileStatus[] fileStatuses;
  try {
    fileStatuses=fileSystem.listStatus(path);
  }
 catch (  FileNotFoundException e) {
    return true;
  }
catch (  Exception e) {
    return false;
  }
  if (fileStatuses == null) {
    return true;
  }
 else   if (fileStatuses.length == 0) {
    return fileSystem.delete(path,false);
  }
 else {
    return false;
  }
}
