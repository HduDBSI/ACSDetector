/** 
 * Creates a Kafka 0.8  {@link StreamTableSource}.
 * @param topic                 Kafka topic to consume.
 * @param properties            Properties for the Kafka consumer.
 * @param deserializationSchema Deserialization schema to use for Kafka records.
 * @param typeInfo              Type information describing the result type. The field names are usedto parse the JSON file and so are the types.
 */
public Kafka08TableSource(String topic,Properties properties,DeserializationSchema<Row> deserializationSchema,TypeInformation<Row> typeInfo){
  super(topic,properties,deserializationSchema,typeInfo);
}
