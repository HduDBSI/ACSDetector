private void updateTs(List<TtlValue<T>> ttlValue) throws Exception {
  List<TtlValue<T>> unexpiredWithUpdatedTs=ttlValue.stream().filter(v -> !expired(v)).map(this::rewrapWithNewTs).collect(Collectors.toList());
  if (!unexpiredWithUpdatedTs.isEmpty()) {
    original.update(unexpiredWithUpdatedTs);
  }
}
