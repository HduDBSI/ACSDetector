private static Schema tryExtractAvroSchema(ClassLoader cl,Class<?> runtimeType){
  if (isGenericRecord(runtimeType)) {
    return null;
  }
  if (isSpecificRecord(runtimeType)) {
    SpecificData d=new SpecificData(cl);
    return AvroFactory.extractAvroSpecificSchema(runtimeType,d);
  }
  ReflectData d=new ReflectData(cl);
  return d.getSchema(runtimeType);
}
