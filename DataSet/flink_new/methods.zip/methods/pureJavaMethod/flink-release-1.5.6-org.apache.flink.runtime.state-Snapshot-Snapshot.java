private Snapshot(StateDescriptor.Type stateType,String name,TypeSerializer<N> namespaceSerializer,TypeSerializer<S> stateSerializer,TypeSerializerConfigSnapshot namespaceSerializerConfigSnapshot,TypeSerializerConfigSnapshot stateSerializerConfigSnapshot){
  this.stateType=Preconditions.checkNotNull(stateType);
  this.name=Preconditions.checkNotNull(name);
  this.namespaceSerializer=Preconditions.checkNotNull(namespaceSerializer);
  this.stateSerializer=Preconditions.checkNotNull(stateSerializer);
  this.namespaceSerializerConfigSnapshot=Preconditions.checkNotNull(namespaceSerializerConfigSnapshot);
  this.stateSerializerConfigSnapshot=Preconditions.checkNotNull(stateSerializerConfigSnapshot);
}
