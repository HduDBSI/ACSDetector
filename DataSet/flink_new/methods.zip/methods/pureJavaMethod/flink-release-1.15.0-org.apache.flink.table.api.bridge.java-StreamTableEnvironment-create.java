/** 
 * Creates a table environment that is the entry point and central context for creating Table and SQL API programs that integrate with the Java-specific  {@link DataStream} API.<p>It is unified for bounded and unbounded data processing. <p>A stream table environment is responsible for: <ul> <li>Convert a  {@link DataStream} into {@link Table} and vice-versa.<li>Connecting to external systems. <li>Registering and retrieving  {@link Table}s and other meta objects from a catalog. <li>Executing SQL statements. <li>Offering further configuration options. </ul> <p>Note: If you don't intend to use the  {@link DataStream} API, {@link TableEnvironment} ismeant for pure table programs.
 * @param executionEnvironment The Java {@link StreamExecutionEnvironment} of the {@link TableEnvironment}.
 * @param settings The environment settings used to instantiate the {@link TableEnvironment}.
 */
static StreamTableEnvironment create(StreamExecutionEnvironment executionEnvironment,EnvironmentSettings settings){
  return StreamTableEnvironmentImpl.create(executionEnvironment,settings);
}
