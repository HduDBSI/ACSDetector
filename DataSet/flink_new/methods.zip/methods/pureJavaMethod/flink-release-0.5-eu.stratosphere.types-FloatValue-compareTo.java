@Override public int compareTo(FloatValue o){
  final double other=o.value;
  return this.value < other ? -1 : this.value > other ? 1 : 0;
}
