/** 
 * Tests for scenes that a task fails for data consumption error, in which case the region containing the failed task, the region containing the unavailable result partition and all their consumer regions should be restarted. <pre> (v1) -+-> (v4) x (v2) -+-> (v5) (v3) -+-> (v6) ^ | (blocking) </pre> Each vertex is in an individual region.
 */
@Test public void testRegionFailoverForDataConsumptionErrors() throws Exception {
  TestingSchedulingTopology topology=new TestingSchedulingTopology();
  TestingSchedulingExecutionVertex v1=topology.newExecutionVertex(ExecutionState.FINISHED);
  TestingSchedulingExecutionVertex v2=topology.newExecutionVertex(ExecutionState.FINISHED);
  TestingSchedulingExecutionVertex v3=topology.newExecutionVertex(ExecutionState.FINISHED);
  TestingSchedulingExecutionVertex v4=topology.newExecutionVertex(ExecutionState.RUNNING);
  TestingSchedulingExecutionVertex v5=topology.newExecutionVertex(ExecutionState.RUNNING);
  TestingSchedulingExecutionVertex v6=topology.newExecutionVertex(ExecutionState.RUNNING);
  topology.connect(v1,v4,ResultPartitionType.BLOCKING);
  topology.connect(v1,v5,ResultPartitionType.BLOCKING);
  topology.connect(v2,v4,ResultPartitionType.BLOCKING);
  topology.connect(v2,v5,ResultPartitionType.BLOCKING);
  topology.connect(v3,v6,ResultPartitionType.BLOCKING);
  RestartPipelinedRegionFailoverStrategy strategy=new RestartPipelinedRegionFailoverStrategy(topology);
  Iterator<TestingSchedulingResultPartition> v4InputEdgeIterator=v4.getConsumedResults().iterator();
  TestingSchedulingResultPartition v1out=v4InputEdgeIterator.next();
  verifyThatFailedExecution(strategy,v4).partitionConnectionCause(v1out).restarts(v1,v4,v5);
  TestingSchedulingResultPartition v2out=v4InputEdgeIterator.next();
  verifyThatFailedExecution(strategy,v4).partitionConnectionCause(v2out).restarts(v2,v4,v5);
  Iterator<TestingSchedulingResultPartition> v5InputEdgeIterator=v5.getConsumedResults().iterator();
  v1out=v5InputEdgeIterator.next();
  verifyThatFailedExecution(strategy,v5).partitionConnectionCause(v1out).restarts(v1,v4,v5);
  v2out=v5InputEdgeIterator.next();
  verifyThatFailedExecution(strategy,v5).partitionConnectionCause(v2out).restarts(v2,v4,v5);
  TestingSchedulingResultPartition v3out=v6.getConsumedResults().iterator().next();
  verifyThatFailedExecution(strategy,v6).partitionConnectionCause(v3out).restarts(v3,v6);
}
