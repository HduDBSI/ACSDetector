@Test public void testAvroToAvro(){
  StreamExecutionEnvironment env=StreamExecutionEnvironment.getExecutionEnvironment();
  StreamTableEnvironment tEnv=StreamTableEnvironment.create(env);
  DataStream<User> ds=testData(env);
  Table t=tEnv.fromDataStream(ds,selectFields(ds));
  Table result=t.select($("*"));
  List<User> results=CollectionUtil.iteratorToList(DataStreamUtils.collect(tEnv.toAppendStream(result,User.class)));
  List<User> expected=Arrays.asList(USER_1,USER_2,USER_3);
  assertEquals(expected,results);
}
