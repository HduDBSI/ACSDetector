private SingleTaskSlot(SlotRequestId slotRequestId,AbstractID groupId,MultiTaskSlot parent,Locality locality){
  super(slotRequestId,groupId);
  this.parent=Preconditions.checkNotNull(parent);
  Preconditions.checkNotNull(locality);
  singleLogicalSlotFuture=parent.getSlotContextFuture().thenApply((  SlotContext slotContext) -> {
    LOG.trace("Fulfill single task slot [{}] with slot [{}].",slotRequestId,slotContext.getAllocationId());
    return new SingleLogicalSlot(slotRequestId,slotContext,slotSharingGroupId,locality,slotOwner);
  }
);
}
