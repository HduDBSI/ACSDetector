/** 
 * Tests that increment the completed or failed number of checkpoints without incrementing the in progress checkpoints before throws an Exception.
 */
@Test public void testCompleteOrFailWithoutInProgressCheckpoint(){
  CheckpointStatsCounts counts=new CheckpointStatsCounts();
  counts.incrementCompletedCheckpoints();
  assertTrue("Number of checkpoints in progress should never be negative",counts.getNumberOfInProgressCheckpoints() >= 0);
  counts.incrementFailedCheckpoints();
  assertTrue("Number of checkpoints in progress should never be negative",counts.getNumberOfInProgressCheckpoints() >= 0);
}
