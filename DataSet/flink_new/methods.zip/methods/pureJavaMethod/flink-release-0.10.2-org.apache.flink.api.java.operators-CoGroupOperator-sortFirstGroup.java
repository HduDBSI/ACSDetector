/** 
 * Sorts Pojo or  {@link org.apache.flink.api.java.tuple.Tuple} elements within a group in the first input on thespecified field in the specified  {@link Order}.<br> Groups can be sorted by multiple fields by chaining  {@link #sortFirstGroup(String,Order)} calls.
 * @param fieldExpression The expression to the field on which the group is to be sorted.
 * @param order The Order in which the specified Tuple field is sorted.
 * @return A SortedGrouping with specified order of group element.
 * @see Order
 */
public CoGroupOperatorWithoutFunction sortFirstGroup(String fieldExpression,Order order){
  if (!(input1.getType() instanceof CompositeType)) {
    throw new InvalidProgramException("Specifying order keys via field positions is only valid for composite data types (pojo / tuple / case class)");
  }
  ExpressionKeys<I1> ek=new ExpressionKeys<I1>(new String[]{fieldExpression},input1.getType());
  int[] groupOrderKeys=ek.computeLogicalKeyPositions();
  for (  int key : groupOrderKeys) {
    this.groupSortKeyOrderFirst.add(new ImmutablePair<Integer,Order>(key,order));
  }
  return this;
}
