public static HiveTablePartition toHiveTablePartition(List<String> partitionKeys,Properties tableProps,Partition partition){
  StorageDescriptor sd=partition.getSd();
  Map<String,String> partitionSpec=new HashMap<>();
  for (int i=0; i < partitionKeys.size(); i++) {
    String partitionColName=partitionKeys.get(i);
    String partitionValue=partition.getValues().get(i);
    partitionSpec.put(partitionColName,partitionValue);
  }
  return new HiveTablePartition(sd,partitionSpec,tableProps);
}
