@Override protected void mergeConfiguration(GraphAlgorithmWrappingBase other){
  super.mergeConfiguration(other);
  VertexInDegree rhs=(VertexInDegree)other;
  includeZeroDegreeVertices.mergeWith(rhs.includeZeroDegreeVertices);
}
