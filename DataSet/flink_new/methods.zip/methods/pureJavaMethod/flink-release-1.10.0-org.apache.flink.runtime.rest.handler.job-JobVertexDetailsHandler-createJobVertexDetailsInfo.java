private static JobVertexDetailsInfo createJobVertexDetailsInfo(AccessExecutionJobVertex jobVertex,JobID jobID,@Nullable MetricFetcher metricFetcher){
  List<SubtaskExecutionAttemptDetailsInfo> subtasks=new ArrayList<>();
  final long now=System.currentTimeMillis();
  for (  AccessExecutionVertex vertex : jobVertex.getTaskVertices()) {
    final AccessExecution execution=vertex.getCurrentExecutionAttempt();
    final JobVertexID jobVertexID=jobVertex.getJobVertexId();
    subtasks.add(SubtaskExecutionAttemptDetailsInfo.create(execution,metricFetcher,jobID,jobVertexID));
  }
  return new JobVertexDetailsInfo(jobVertex.getJobVertexId(),jobVertex.getName(),jobVertex.getParallelism(),now,subtasks);
}
