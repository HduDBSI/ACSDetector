/** 
 * Releases all exclusive and floating buffers, closes the partition request client.
 */
@Override void releaseAllResources() throws IOException {
  if (isReleased.compareAndSet(false,true)) {
    final List<MemorySegment> exclusiveRecyclingSegments=new ArrayList<>();
synchronized (receivedBuffers) {
      Buffer buffer;
      while ((buffer=receivedBuffers.poll()) != null) {
        if (buffer.getRecycler() == this) {
          exclusiveRecyclingSegments.add(buffer.getMemorySegment());
        }
 else {
          buffer.recycleBuffer();
        }
      }
    }
synchronized (bufferQueue) {
      bufferQueue.releaseAll(exclusiveRecyclingSegments);
    }
    if (exclusiveRecyclingSegments.size() > 0) {
      inputGate.returnExclusiveSegments(exclusiveRecyclingSegments);
    }
    if (partitionRequestClient != null) {
      partitionRequestClient.close(this);
    }
 else {
      connectionManager.closeOpenChannelConnections(connectionId);
    }
  }
}
