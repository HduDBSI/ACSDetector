public ExecutionEdge(IntermediateResultPartition source,ExecutionVertex target,int inputNum,ChannelID inputChannelId,ChannelID outputChannelId){
  this.source=source;
  this.target=target;
  this.inputNum=inputNum;
  this.inputChannelId=inputChannelId;
  this.outputChannelId=outputChannelId;
}
