@SuppressWarnings("unchecked") public SelectTableSinkBase(TableSchema schema,TypeSerializer<T> typeSerializer){
  this.tableSchema=schema;
  this.converter=DataFormatConverters.getConverterForDataType(this.tableSchema.toPhysicalRowDataType());
  this.typeSerializer=typeSerializer;
}
