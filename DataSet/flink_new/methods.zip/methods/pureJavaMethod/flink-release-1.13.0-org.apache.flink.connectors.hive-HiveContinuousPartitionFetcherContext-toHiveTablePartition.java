/** 
 * Convert partition to HiveTablePartition. 
 */
public HiveTablePartition toHiveTablePartition(Partition partition){
  return HivePartitionUtils.toHiveTablePartition(partitionKeys,tableProps,partition);
}
