public RpcInputSplitProvider(JobMasterGateway jobMasterGateway,JobVertexID jobVertexID,ExecutionAttemptID executionAttemptID,Time timeout){
  this.jobMasterGateway=Preconditions.checkNotNull(jobMasterGateway);
  this.jobVertexID=Preconditions.checkNotNull(jobVertexID);
  this.executionAttemptID=Preconditions.checkNotNull(executionAttemptID);
  this.timeout=Preconditions.checkNotNull(timeout);
}
