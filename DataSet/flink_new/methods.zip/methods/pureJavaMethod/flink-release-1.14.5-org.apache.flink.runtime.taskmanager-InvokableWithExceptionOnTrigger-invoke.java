@Override public void invoke(){
  awaitTriggerLatch();
  throw new RuntimeException("test");
}
