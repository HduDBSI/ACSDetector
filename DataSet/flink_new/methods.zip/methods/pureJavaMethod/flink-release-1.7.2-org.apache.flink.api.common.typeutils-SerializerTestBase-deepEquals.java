protected void deepEquals(String message,T should,T is){
  Assert.assertTrue((should == null && is == null) || (should != null && is != null));
  if (should == null) {
    return;
  }
  if (should.getClass().isArray()) {
    if (should instanceof boolean[]) {
      Assert.assertTrue(message,Arrays.equals((boolean[])should,(boolean[])is));
    }
 else     if (should instanceof byte[]) {
      assertArrayEquals(message,(byte[])should,(byte[])is);
    }
 else     if (should instanceof short[]) {
      assertArrayEquals(message,(short[])should,(short[])is);
    }
 else     if (should instanceof int[]) {
      assertArrayEquals(message,(int[])should,(int[])is);
    }
 else     if (should instanceof long[]) {
      assertArrayEquals(message,(long[])should,(long[])is);
    }
 else     if (should instanceof float[]) {
      assertArrayEquals(message,(float[])should,(float[])is,0.0f);
    }
 else     if (should instanceof double[]) {
      assertArrayEquals(message,(double[])should,(double[])is,0.0);
    }
 else     if (should instanceof char[]) {
      assertArrayEquals(message,(char[])should,(char[])is);
    }
 else {
      assertArrayEquals(message,(Object[])should,(Object[])is);
    }
  }
 else   if (should instanceof Throwable) {
    assertEquals(((Throwable)should).getMessage(),((Throwable)is).getMessage());
  }
 else {
    assertEquals(message,should,is);
  }
}
