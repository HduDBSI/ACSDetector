/** 
 * Creates a  {@link ZooKeeperCheckpointIDCounter} instance.
 * @param client        The {@link CuratorFramework} ZooKeeper client to use
 * @param configuration {@link Configuration} object
 * @param jobId         ID of job to create the instance for
 * @return {@link ZooKeeperCheckpointIDCounter} instance
 */
public static ZooKeeperCheckpointIDCounter createCheckpointIDCounter(CuratorFramework client,Configuration configuration,JobID jobId){
  String checkpointIdCounterPath=configuration.getString(HighAvailabilityOptions.HA_ZOOKEEPER_CHECKPOINT_COUNTER_PATH);
  checkpointIdCounterPath+=ZooKeeperSubmittedJobGraphStore.getPathForJob(jobId);
  return new ZooKeeperCheckpointIDCounter(client,checkpointIdCounterPath);
}
