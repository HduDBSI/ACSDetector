PartitionTempFileManager(FileSystemFactory factory,Path tmpPath,int taskNumber,OutputFileConfig outputFileConfig) throws IOException {
  this.taskNumber=taskNumber;
  this.outputFileConfig=outputFileConfig;
  this.taskTmpDir=new Path(tmpPath,TASK_DIR_PREFIX + taskNumber);
  factory.create(taskTmpDir.toUri()).delete(taskTmpDir,true);
}
