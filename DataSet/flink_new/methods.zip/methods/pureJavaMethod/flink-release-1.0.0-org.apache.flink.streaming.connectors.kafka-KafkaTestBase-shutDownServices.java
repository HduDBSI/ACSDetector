@AfterClass public static void shutDownServices(){
  LOG.info("-------------------------------------------------------------------------");
  LOG.info("    Shut down KafkaTestBase ");
  LOG.info("-------------------------------------------------------------------------");
  flinkPort=-1;
  if (flink != null) {
    flink.shutdown();
  }
  kafkaServer.shutdown();
  LOG.info("-------------------------------------------------------------------------");
  LOG.info("    KafkaTestBase finished");
  LOG.info("-------------------------------------------------------------------------");
}
