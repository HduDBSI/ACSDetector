private CompletableFuture<Void> runJob(JobGraph jobGraph){
  Preconditions.checkState(!jobManagerRunnerFutures.containsKey(jobGraph.getJobID()));
  final CompletableFuture<JobManagerRunner> jobManagerRunnerFuture=createJobManagerRunner(jobGraph);
  jobManagerRunnerFutures.put(jobGraph.getJobID(),jobManagerRunnerFuture);
  return jobManagerRunnerFuture.thenApply(FunctionUtils.nullFn()).whenCompleteAsync((ignored,throwable) -> {
    if (throwable != null) {
      jobManagerRunnerFutures.remove(jobGraph.getJobID());
    }
  }
,getMainThreadExecutor());
}
