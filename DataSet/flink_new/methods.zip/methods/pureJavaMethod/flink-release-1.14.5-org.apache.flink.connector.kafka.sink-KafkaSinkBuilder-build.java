/** 
 * Constructs the  {@link KafkaSink} with the configured properties.
 * @return {@link KafkaSink}
 */
public KafkaSink<IN> build(){
  sanityCheck();
  return new KafkaSink<>(deliveryGuarantee,kafkaProducerConfig,transactionalIdPrefix,recordSerializer);
}
