/** 
 * Tests that increment the completed or failed number of checkpoints without incrementing the in progress checkpoints before throws an Exception.
 */
@Test public void testCompleteOrFailWithoutInProgressCheckpoint() throws Exception {
  CheckpointStatsCounts counts=new CheckpointStatsCounts();
  try {
    counts.incrementCompletedCheckpoints();
    fail("Did not throw expected Exception");
  }
 catch (  IllegalStateException ignored) {
  }
  try {
    counts.incrementFailedCheckpoints();
    fail("Did not throw expected Exception");
  }
 catch (  IllegalStateException ignored) {
  }
}
