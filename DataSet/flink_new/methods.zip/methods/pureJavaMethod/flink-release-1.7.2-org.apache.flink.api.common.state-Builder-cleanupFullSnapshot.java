/** 
 * Cleanup expired state in full snapshot on checkpoint. 
 */
@Nonnull public Builder cleanupFullSnapshot(){
  cleanupStrategies.strategies.put(CleanupStrategies.Strategies.FULL_STATE_SCAN_SNAPSHOT,new CleanupStrategies.CleanupStrategy(){
  }
);
  return this;
}
