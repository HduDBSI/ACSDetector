private RestClient createRestClient() throws ConfigurationException {
  return new RestClient(new UnmodifiableConfiguration(new Configuration()),executorService);
}
