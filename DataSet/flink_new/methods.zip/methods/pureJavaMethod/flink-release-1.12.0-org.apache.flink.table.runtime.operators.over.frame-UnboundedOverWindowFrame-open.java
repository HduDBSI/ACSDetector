@Override public void open(ExecutionContext ctx) throws Exception {
  ClassLoader cl=ctx.getRuntimeContext().getUserCodeClassLoader();
  processor=aggsHandleFunction.newInstance(cl);
  processor.open(new PerKeyStateDataViewStore(ctx.getRuntimeContext()));
  this.aggsHandleFunction=null;
  this.valueSer=new RowDataSerializer(valueType.getChildren().toArray(new LogicalType[0]));
}
