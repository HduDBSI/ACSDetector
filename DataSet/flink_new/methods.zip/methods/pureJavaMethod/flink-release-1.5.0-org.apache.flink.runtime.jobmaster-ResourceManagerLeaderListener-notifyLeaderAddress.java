@Override public void notifyLeaderAddress(final String leaderAddress,final UUID leaderSessionID){
  runAsync(() -> notifyOfNewResourceManagerLeader(leaderAddress,ResourceManagerId.fromUuidOrNull(leaderSessionID)));
}
