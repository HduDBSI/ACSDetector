@PublicEvolving public static <IN,ACC>TypeInformation<ACC> getAggregateFunctionAccumulatorType(AggregateFunction<IN,ACC,?> function,TypeInformation<IN> inType,String functionName,boolean allowMissing){
  return getUnaryOperatorReturnType(function,AggregateFunction.class,0,1,NO_INDEX,inType,functionName,allowMissing);
}
