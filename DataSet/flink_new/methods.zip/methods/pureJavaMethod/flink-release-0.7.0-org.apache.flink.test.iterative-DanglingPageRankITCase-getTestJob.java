@Override protected Plan getTestJob(){
  DanglingPageRank pr=new DanglingPageRank();
  Plan plan=pr.getPlan(String.valueOf(DOP),pagesPath,edgesPath,resultPath,"25","5","1");
  return plan;
}
