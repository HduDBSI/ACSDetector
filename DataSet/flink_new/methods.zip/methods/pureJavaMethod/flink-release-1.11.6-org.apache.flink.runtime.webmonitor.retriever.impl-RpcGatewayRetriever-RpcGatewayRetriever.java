public RpcGatewayRetriever(RpcService rpcService,Class<T> gatewayType,Function<UUID,F> fencingTokenMapper,int retries,Time retryDelay){
  this.rpcService=Preconditions.checkNotNull(rpcService);
  this.gatewayType=Preconditions.checkNotNull(gatewayType);
  this.fencingTokenMapper=Preconditions.checkNotNull(fencingTokenMapper);
  Preconditions.checkArgument(retries >= 0,"The number of retries must be greater or equal to 0.");
  this.retries=retries;
  this.retryDelay=Preconditions.checkNotNull(retryDelay);
}
