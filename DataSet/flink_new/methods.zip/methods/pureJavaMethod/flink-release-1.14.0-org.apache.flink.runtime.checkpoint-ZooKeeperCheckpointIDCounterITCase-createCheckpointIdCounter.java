@Override protected ZooKeeperCheckpointIDCounter createCheckpointIdCounter() throws Exception {
  return new ZooKeeperCheckpointIDCounter(ZooKeeper.getClient(),new DefaultLastStateConnectionStateListener());
}
