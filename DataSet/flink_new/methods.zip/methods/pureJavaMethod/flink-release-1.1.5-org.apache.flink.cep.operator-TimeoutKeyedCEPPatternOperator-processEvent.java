@Override protected void processEvent(NFA<IN> nfa,IN event,long timestamp){
  Tuple2<Collection<Map<String,IN>>,Collection<Tuple2<Map<String,IN>,Long>>> patterns=nfa.process(event,timestamp);
  Collection<Map<String,IN>> matchedSequences=patterns.f0;
  Collection<Tuple2<Map<String,IN>,Long>> timedOutSequences=patterns.f1;
  emitMatchedSequences(matchedSequences,timestamp);
  emitTimedOutSequences(timedOutSequences,timestamp);
}
