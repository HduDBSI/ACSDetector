Context(){
  kubernetesTestFixture=new KubernetesTestFixture(CLUSTER_ID,LEADER_CONFIGMAP_NAME,LOCK_IDENTITY);
  flinkKubeClient=kubernetesTestFixture.getFlinkKubeClient();
  configuration=kubernetesTestFixture.getConfiguration();
  closeKubeClientFuture=kubernetesTestFixture.getCloseKubeClientFuture();
  deleteConfigMapByLabelsFuture=kubernetesTestFixture.getDeleteConfigMapByLabelsFuture();
  electionEventHandler=new TestingLeaderElectionEventHandler(LEADER_ADDRESS);
  leaderElectionDriver=createLeaderElectionDriver();
  retrievalEventHandler=new TestingLeaderRetrievalEventHandler();
  leaderRetrievalDriver=createLeaderRetrievalDriver();
}
