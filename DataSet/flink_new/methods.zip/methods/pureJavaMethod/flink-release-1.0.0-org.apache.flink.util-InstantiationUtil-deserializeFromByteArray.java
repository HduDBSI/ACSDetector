public static <T>T deserializeFromByteArray(TypeSerializer<T> serializer,T reuse,byte[] buf) throws IOException {
  if (buf == null) {
    throw new NullPointerException("Byte array to deserialize from must not be null.");
  }
  DataInputViewStreamWrapper inputViewWrapper=new DataInputViewStreamWrapper(new ByteArrayInputStream(buf));
  return serializer.deserialize(reuse,inputViewWrapper);
}
