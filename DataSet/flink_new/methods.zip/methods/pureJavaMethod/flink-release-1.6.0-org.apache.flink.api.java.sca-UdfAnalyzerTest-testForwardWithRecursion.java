@Test public void testForwardWithRecursion(){
  compareAnalyzerResultWithAnnotationsSingleInput(MapFunction.class,Map40.class,TypeInformation.of(new TypeHint<MyPojo>(){
  }
),TypeInformation.of(new TypeHint<MyPojo>(){
  }
));
}
