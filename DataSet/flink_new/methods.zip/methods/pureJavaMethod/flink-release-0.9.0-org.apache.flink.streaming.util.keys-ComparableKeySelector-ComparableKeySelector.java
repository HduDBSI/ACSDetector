public ComparableKeySelector(TypeComparator<IN> comparator,int keyLength){
  this.comparator=comparator;
  this.keyLength=keyLength;
  keyArray=new Object[keyLength];
}
