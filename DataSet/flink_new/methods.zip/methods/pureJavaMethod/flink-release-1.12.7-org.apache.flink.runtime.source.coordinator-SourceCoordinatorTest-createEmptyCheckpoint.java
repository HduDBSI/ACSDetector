private static byte[] createEmptyCheckpoint() throws Exception {
  return SourceCoordinator.writeCheckpointBytes(Collections.emptySet(),new MockSplitEnumeratorCheckpointSerializer());
}
