@Override public PartitionReleaseStrategy createInstance(final SchedulingTopology schedulingStrategy){
  return new RegionPartitionReleaseStrategy(schedulingStrategy);
}
