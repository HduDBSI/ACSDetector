private UpsertWriter(int[] fieldTypes,int[] pkFields,int[] pkTypes,String deleteSQL,boolean objectReuse){
  this.fieldTypes=fieldTypes;
  this.pkFields=pkFields;
  this.pkTypes=pkTypes;
  this.deleteSQL=deleteSQL;
  this.objectReuse=objectReuse;
}
