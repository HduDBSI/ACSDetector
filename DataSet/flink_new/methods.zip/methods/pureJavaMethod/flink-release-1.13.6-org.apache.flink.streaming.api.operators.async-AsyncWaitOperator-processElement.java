@Override public void processElement(StreamRecord<IN> record) throws Exception {
  StreamRecord<IN> element;
  if (isObjectReuseEnabled) {
    element=(StreamRecord<IN>)inStreamElementSerializer.copy(record);
  }
 else {
    element=record;
  }
  final ResultFuture<OUT> entry=addToWorkQueue(element);
  final ResultHandler resultHandler=new ResultHandler(element,entry);
  if (timeout > 0L) {
    resultHandler.registerTimeout(getProcessingTimeService(),timeout);
  }
  userFunction.asyncInvoke(element.getValue(),resultHandler);
}
