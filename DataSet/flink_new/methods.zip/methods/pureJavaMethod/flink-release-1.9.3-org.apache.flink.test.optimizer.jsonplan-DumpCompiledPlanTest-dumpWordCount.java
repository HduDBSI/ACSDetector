@Test public void dumpWordCount(){
  PreviewPlanEnvironment env=new PreviewPlanEnvironment();
  env.setAsContext();
  try {
    WordCount.main(new String[]{"--input",IN_FILE,"--output",OUT_FILE});
  }
 catch (  OptimizerPlanEnvironment.ProgramAbortException pae) {
  }
catch (  Exception e) {
    e.printStackTrace();
    Assert.fail("WordCount failed with an exception");
  }
  dump(env.getPlan());
}
