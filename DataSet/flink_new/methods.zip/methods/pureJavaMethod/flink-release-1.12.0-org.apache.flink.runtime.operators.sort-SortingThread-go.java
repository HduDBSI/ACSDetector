/** 
 * Entry point of the thread.
 */
@Override public void go() throws InterruptedException {
  boolean alive=true;
  while (isRunning() && alive) {
    final CircularElement<E> element=this.dispatcher.take(SortStage.SORT);
    if (element != EOF_MARKER && element != SPILLING_MARKER) {
      if (element.getBuffer().size() == 0) {
        element.getBuffer().reset();
        this.dispatcher.send(SortStage.READ,element);
        continue;
      }
      LOG.debug("Sorting buffer {}.",element.getId());
      this.sorter.sort(element.getBuffer());
      LOG.debug("Sorted buffer {}.",element.getId());
    }
 else     if (element == EOF_MARKER) {
      LOG.debug("Sorting thread done.");
      alive=false;
    }
    this.dispatcher.send(SortStage.SPILL,element);
  }
}
