private List<OperatorDescriptorDual> initializeDataProperties(Partitioner<?> customPartitioner){
  Ordering groupOrder1=null;
  Ordering groupOrder2=null;
  CoGroupOperatorBase<?,?,?,?> cgc=getPactContract();
  groupOrder1=cgc.getGroupOrderForInputOne();
  groupOrder2=cgc.getGroupOrderForInputTwo();
  if (groupOrder1 != null && groupOrder1.getNumberOfFields() == 0) {
    groupOrder1=null;
  }
  if (groupOrder2 != null && groupOrder2.getNumberOfFields() == 0) {
    groupOrder2=null;
  }
  CoGroupDescriptor descr=new CoGroupDescriptor(this.keys1,this.keys2,groupOrder1,groupOrder2);
  if (customPartitioner != null) {
    descr.setCustomPartitioner(customPartitioner);
  }
  return Collections.<OperatorDescriptorDual>singletonList(descr);
}
