@Override public void run(){
  try {
    destroyProcess(process);
  }
 catch (  IOException ioException) {
    LOG.warn("Could not destroy python process.",ioException);
  }
}
