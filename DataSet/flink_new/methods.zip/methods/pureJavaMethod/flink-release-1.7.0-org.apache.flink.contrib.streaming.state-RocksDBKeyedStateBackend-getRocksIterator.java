public static RocksIteratorWrapper getRocksIterator(RocksDB db,ColumnFamilyHandle columnFamilyHandle){
  return new RocksIteratorWrapper(db.newIterator(columnFamilyHandle));
}
