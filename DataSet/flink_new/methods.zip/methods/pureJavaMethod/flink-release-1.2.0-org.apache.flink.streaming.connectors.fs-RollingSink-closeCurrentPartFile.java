/** 
 * Closes the current part file. <p> This moves the current in-progress part file to a pending file and adds it to the list of pending files in our bucket state.
 */
private void closeCurrentPartFile() throws Exception {
  if (isWriterOpen) {
    writer.close();
    isWriterOpen=false;
  }
  if (currentPartPath != null) {
    Path inProgressPath=getInProgressPathFor(currentPartPath);
    Path pendingPath=getPendingPathFor(currentPartPath);
    fs.rename(inProgressPath,pendingPath);
    LOG.debug("Moving in-progress bucket {} to pending file {}",inProgressPath,pendingPath);
    this.bucketState.pendingFiles.add(currentPartPath.toString());
  }
}
