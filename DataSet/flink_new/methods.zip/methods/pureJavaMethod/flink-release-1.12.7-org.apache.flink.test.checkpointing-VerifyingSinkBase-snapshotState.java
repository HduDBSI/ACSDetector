@Override public void snapshotState(FunctionSnapshotContext context) throws Exception {
  stateList.clear();
  stateList.add(state);
}
