@Override public void initializeState(StateInitializationContext context) throws Exception {
  super.initializeState(context);
  buckets=bucketsBuilder.createBuckets(getRuntimeContext().getIndexOfThisSubtask());
  currentNewPartitions=new HashSet<>();
  newPartitions=new TreeMap<>();
  committablePartitions=new HashSet<>();
  buckets.setBucketLifeCycleListener(new BucketLifeCycleListener<RowData,String>(){
    @Override public void bucketCreated(    Bucket<RowData,String> bucket){
      currentNewPartitions.add(bucket.getBucketId());
    }
    @Override public void bucketInactive(    Bucket<RowData,String> bucket){
      committablePartitions.add(bucket.getBucketId());
    }
  }
);
  helper=new StreamingFileSinkHelper<>(buckets,context.isRestored(),context.getOperatorStateStore(),getRuntimeContext().getProcessingTimeService(),bucketCheckInterval);
  currentWatermark=Long.MIN_VALUE;
}
