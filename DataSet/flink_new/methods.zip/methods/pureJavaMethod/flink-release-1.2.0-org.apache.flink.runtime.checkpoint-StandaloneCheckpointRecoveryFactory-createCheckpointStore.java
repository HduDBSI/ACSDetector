@Override public CompletedCheckpointStore createCheckpointStore(JobID jobId,ClassLoader userClassLoader) throws Exception {
  return new StandaloneCompletedCheckpointStore(CheckpointRecoveryFactory.NUMBER_OF_SUCCESSFUL_CHECKPOINTS_TO_RETAIN);
}
