@Override public void serialize(MigratedNFA<T> record,DataOutputView target){
  throw new UnsupportedOperationException();
}
