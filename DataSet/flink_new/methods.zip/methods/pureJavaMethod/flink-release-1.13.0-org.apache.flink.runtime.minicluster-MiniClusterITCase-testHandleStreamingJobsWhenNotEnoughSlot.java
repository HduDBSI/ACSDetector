@Test public void testHandleStreamingJobsWhenNotEnoughSlot() throws Exception {
  try {
    final JobVertex vertex1=new JobVertex("Test Vertex1");
    vertex1.setParallelism(1);
    vertex1.setMaxParallelism(1);
    vertex1.setInvokableClass(BlockingNoOpInvokable.class);
    final JobVertex vertex2=new JobVertex("Test Vertex2");
    vertex2.setParallelism(1);
    vertex2.setMaxParallelism(1);
    vertex2.setInvokableClass(BlockingNoOpInvokable.class);
    vertex2.connectNewDataSetAsInput(vertex1,DistributionPattern.POINTWISE,ResultPartitionType.PIPELINED);
    final JobGraph jobGraph=JobGraphTestUtils.streamingJobGraph(vertex1,vertex2);
    runHandleJobsWhenNotEnoughSlots(jobGraph);
    fail("Job should fail.");
  }
 catch (  JobExecutionException e) {
    assertThat(e,FlinkMatchers.containsMessage("Job execution failed"));
    assertThat(e,FlinkMatchers.containsCause(NoResourceAvailableException.class));
  }
}
