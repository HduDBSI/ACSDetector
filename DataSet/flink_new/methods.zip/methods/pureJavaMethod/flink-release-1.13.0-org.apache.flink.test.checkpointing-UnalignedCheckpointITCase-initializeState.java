@Override public void initializeState(FunctionInitializationContext context) throws Exception {
  stateList=context.getOperatorStateStore().getListState(new ListStateDescriptor<>("state",State.class));
  state=getOnlyElement(stateList.get(),new State(numSources,getRuntimeContext().getNumberOfParallelSubtasks()));
}
