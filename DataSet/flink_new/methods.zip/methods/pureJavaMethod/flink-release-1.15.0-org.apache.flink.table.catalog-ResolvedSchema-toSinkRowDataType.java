/** 
 * Converts all persisted columns of this schema into a (possibly nested) row data type. <p>This method returns the <b>query-to-sink schema</b>. <p>Note: Computed columns and virtual columns are excluded in the returned row data type. The data type contains the columns of  {@link #toPhysicalRowDataType()} plus persisted metadatacolumns.
 * @see DataTypes#ROW(DataTypes.Field)
 * @see #toSourceRowDataType()
 * @see #toPhysicalRowDataType()
 */
public DataType toSinkRowDataType(){
  return toRowDataType(Column::isPersisted);
}
