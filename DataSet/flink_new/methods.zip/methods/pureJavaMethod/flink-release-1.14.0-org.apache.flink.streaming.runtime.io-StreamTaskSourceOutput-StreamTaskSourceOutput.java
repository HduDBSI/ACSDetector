public StreamTaskSourceOutput(WatermarkGaugeExposingOutput<StreamRecord<?>> chainedSourceOutput,WatermarkGauge inputWatermarkGauge,InternalSourceReaderMetricGroup metricGroup){
  super(chainedSourceOutput,metricGroup,inputWatermarkGauge);
  this.chainedOutput=chainedSourceOutput;
}
