/** 
 * Tests that the Elasticsearch sink works properly with json.
 */
public void runElasticsearchSinkTest() throws Exception {
  runElasticSearchSinkTest(SourceSinkDataTestKit::getJsonSinkFunction);
}
