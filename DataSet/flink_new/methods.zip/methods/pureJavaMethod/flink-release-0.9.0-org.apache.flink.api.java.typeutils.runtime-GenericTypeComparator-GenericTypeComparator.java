private GenericTypeComparator(GenericTypeComparator<T> toClone){
  this.ascending=toClone.ascending;
  this.serializer=toClone.serializer.duplicate();
  this.type=toClone.type;
}
