@Override public K next(){
  if (!hasNext()) {
    throw new NoSuchElementException("Failed to access state [" + state + "]");
  }
  K tmpKey=nextKey;
  nextKey=null;
  return tmpKey;
}
