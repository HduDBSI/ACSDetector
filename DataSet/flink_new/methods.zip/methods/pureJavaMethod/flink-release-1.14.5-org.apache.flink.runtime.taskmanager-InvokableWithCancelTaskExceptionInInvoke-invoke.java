@Override public void invoke(){
  LOG.info("Await for {}, isTriggered = {}",triggerLatch,triggerLatch.isTriggered());
  try {
    awaitTriggerLatch();
  }
 catch (  Throwable ex) {
    LOG.error("Fail on awaiting trigger latch",ex);
    throw ex;
  }
  throw new CancelTaskException();
}
