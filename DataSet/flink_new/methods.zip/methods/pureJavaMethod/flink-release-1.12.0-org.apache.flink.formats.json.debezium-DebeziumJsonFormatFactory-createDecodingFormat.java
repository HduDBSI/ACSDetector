@Override public DecodingFormat<DeserializationSchema<RowData>> createDecodingFormat(DynamicTableFactory.Context context,ReadableConfig formatOptions){
  FactoryUtil.validateFactoryOptions(this,formatOptions);
  validateDecodingFormatOptions(formatOptions);
  final boolean schemaInclude=formatOptions.get(SCHEMA_INCLUDE);
  final boolean ignoreParseErrors=formatOptions.get(IGNORE_PARSE_ERRORS);
  final TimestampFormat timestampFormat=JsonOptions.getTimestampFormat(formatOptions);
  return new DebeziumJsonDecodingFormat(schemaInclude,ignoreParseErrors,timestampFormat);
}
