public void stop(){
synchronized (lock) {
    if (!stopped) {
      stopped=true;
      closeRpcConnection();
    }
  }
}
