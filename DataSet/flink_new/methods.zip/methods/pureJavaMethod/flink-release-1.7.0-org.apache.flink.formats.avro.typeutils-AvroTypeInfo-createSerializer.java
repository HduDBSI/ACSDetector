@Override @SuppressWarnings("deprecation") public TypeSerializer<T> createSerializer(ExecutionConfig config){
  return new AvroSerializer<>(getTypeClass());
}
