private static DeserializationSchema<RowData> createDeserializationSchema(Map<String,String> options){
  DynamicTableSource source=createTableSource(SCHEMA,options);
  assert source instanceof TestDynamicTableFactory.DynamicTableSourceMock;
  TestDynamicTableFactory.DynamicTableSourceMock scanSourceMock=(TestDynamicTableFactory.DynamicTableSourceMock)source;
  return scanSourceMock.valueFormat.createRuntimeDecoder(ScanRuntimeProviderContext.INSTANCE,PHYSICAL_DATA_TYPE);
}
