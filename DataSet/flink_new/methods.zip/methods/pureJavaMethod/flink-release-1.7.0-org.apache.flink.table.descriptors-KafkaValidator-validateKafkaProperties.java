private void validateKafkaProperties(DescriptorProperties properties){
  final Map<String,Consumer<String>> propertyValidators=new HashMap<>();
  propertyValidators.put(CONNECTOR_PROPERTIES_KEY,key -> properties.validateString(key,false,1));
  propertyValidators.put(CONNECTOR_PROPERTIES_VALUE,key -> properties.validateString(key,false,0));
  properties.validateFixedIndexedProperties(CONNECTOR_PROPERTIES,true,propertyValidators);
}
