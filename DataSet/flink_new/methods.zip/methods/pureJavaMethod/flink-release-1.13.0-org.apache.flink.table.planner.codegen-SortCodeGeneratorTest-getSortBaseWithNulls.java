public static Tuple2<NormalizedKeyComputer,RecordComparator> getSortBaseWithNulls(String namePrefix,RowType inputType,SortSpec sortSpec){
  SortCodeGenerator generator=new SortCodeGenerator(new TableConfig(),inputType,sortSpec);
  GeneratedNormalizedKeyComputer computer=generator.generateNormalizedKeyComputer(namePrefix + "Computer");
  GeneratedRecordComparator comparator=generator.generateRecordComparator(namePrefix + "Comparator");
  ClassLoader cl=Thread.currentThread().getContextClassLoader();
  return new Tuple2<>(computer.newInstance(cl),comparator.newInstance(cl));
}
