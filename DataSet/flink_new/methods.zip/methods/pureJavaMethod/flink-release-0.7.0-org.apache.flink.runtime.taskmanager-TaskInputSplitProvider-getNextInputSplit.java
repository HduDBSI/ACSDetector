@Override public InputSplit getNextInputSplit(){
  try {
    return protocol.requestNextInputSplit(jobId,vertexId,executionAttempt);
  }
 catch (  IOException e) {
    throw new RuntimeException("Requesting the next InputSplit failed.",e);
  }
}
