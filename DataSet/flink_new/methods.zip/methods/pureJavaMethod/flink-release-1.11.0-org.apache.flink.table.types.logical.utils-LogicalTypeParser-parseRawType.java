@SuppressWarnings("unchecked") private LogicalType parseRawType(){
  nextToken(TokenType.BEGIN_PARAMETER);
  nextToken(TokenType.LITERAL_STRING);
  final String className=tokenAsString();
  nextToken(TokenType.LIST_SEPARATOR);
  nextToken(TokenType.LITERAL_STRING);
  final String serializerString=tokenAsString();
  nextToken(TokenType.END_PARAMETER);
  return RawType.restore(classLoader,className,serializerString);
}
