protected NumericTypeInfo(Class<T> clazz,Class<?>[] possibleCastTargetTypes,TypeSerializer<T> serializer,Class<? extends TypeComparator<T>> comparatorClass){
  super(clazz,possibleCastTargetTypes,serializer,comparatorClass);
  checkArgument(numericalTypes.contains(clazz),"The given class %s is not a numerical type",clazz.getSimpleName());
}
