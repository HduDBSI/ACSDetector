/** 
 * Cancels a job identified by the job id and triggers a savepoint.
 * @param jobId the job id
 * @param savepointDirectory directory the savepoint should be written to
 * @return path where the savepoint is located
 * @throws Exception In case an error occurred.
 */
public abstract String cancelWithSavepoint(JobID jobId,@Nullable String savepointDirectory) throws Exception ;
