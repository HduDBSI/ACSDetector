@Test public void dumpTPCH3() throws Exception {
  verifyPlanDump(TPCHQuery3.class,"--lineitem",IN_FILE,"--customer",IN_FILE,"--orders",OUT_FILE,"--output","123");
}
