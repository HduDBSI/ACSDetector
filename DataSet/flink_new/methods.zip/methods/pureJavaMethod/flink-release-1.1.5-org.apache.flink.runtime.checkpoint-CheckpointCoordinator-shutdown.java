/** 
 * Shuts down the checkpoint coordinator.
 * @param shutdownStoreAndCounter Depending on this flag the checkpointstate services are shut down or suspended.
 */
private void shutdown(boolean shutdownStoreAndCounter) throws Exception {
synchronized (lock) {
    try {
      if (!shutdown) {
        shutdown=true;
        LOG.info("Stopping checkpoint coordinator for job " + job);
        periodicScheduling=false;
        triggerRequestQueued=false;
        timer.cancel();
        if (jobStatusListener != null) {
          jobStatusListener.tell(PoisonPill.getInstance());
          jobStatusListener=null;
        }
        for (        PendingCheckpoint pending : pendingCheckpoints.values()) {
          pending.discard(userClassLoader);
        }
        pendingCheckpoints.clear();
        if (shutdownStoreAndCounter) {
          completedCheckpointStore.shutdown();
          checkpointIdCounter.shutdown();
        }
 else {
          completedCheckpointStore.suspend();
          checkpointIdCounter.suspend();
        }
        onShutdown();
      }
    }
  finally {
      if (shutdownHook != null && shutdownHook != Thread.currentThread()) {
        try {
          Runtime.getRuntime().removeShutdownHook(shutdownHook);
        }
 catch (        IllegalStateException ignored) {
        }
catch (        Throwable t) {
          LOG.warn("Error unregistering checkpoint coordinator shutdown hook.",t);
        }
      }
    }
  }
}
