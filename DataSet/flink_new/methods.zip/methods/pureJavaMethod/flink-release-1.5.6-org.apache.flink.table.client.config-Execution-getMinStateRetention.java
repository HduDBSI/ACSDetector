public long getMinStateRetention(){
  return Long.parseLong(properties.getOrDefault(PropertyStrings.EXECUTION_MIN_STATE_RETENTION,Long.toString(Long.MIN_VALUE)));
}
