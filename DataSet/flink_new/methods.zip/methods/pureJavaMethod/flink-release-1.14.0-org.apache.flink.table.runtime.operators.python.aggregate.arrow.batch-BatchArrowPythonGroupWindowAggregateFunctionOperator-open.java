@Override public void open() throws Exception {
  super.open();
  inputKeyAndWindow=new LinkedList<>();
  windowProperty=new GenericRowData(namedProperties.length);
  windowAggResult=new JoinedRowData();
  windowsGrouping=new HeapWindowsGrouping(maxLimitSize,windowSize,slideSize,inputTimeFieldIndex,false);
  forwardedInputSerializer=new RowDataSerializer(inputType);
}
