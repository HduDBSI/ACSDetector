/** 
 * Sets the directories in which the local RocksDB database puts its files (like SST and metadata files). These directories do not need to be persistent, they can be ephemeral, meaning that they are lost on a machine failure, because state in RocksDB is persisted in checkpoints. <p>If nothing is configured, these directories default to the TaskManager's local temporary file directories. <p>Each distinct state will be stored in one path, but when the state backend creates multiple states, they will store their files on different paths. <p>Passing  {@code null} to this function restores the default behavior, where the configuredtemp directories will be used.
 * @param paths The paths across which the local RocksDB database files will be spread.
 */
public void setDbStoragePaths(String... paths){
  if (paths == null) {
    localRocksDbDirectories=null;
  }
 else   if (paths.length == 0) {
    throw new IllegalArgumentException("empty paths");
  }
 else {
    File[] pp=new File[paths.length];
    for (int i=0; i < paths.length; i++) {
      final String rawPath=paths[i];
      final String path;
      if (rawPath == null) {
        throw new IllegalArgumentException("null path");
      }
 else {
        URI uri=null;
        try {
          uri=new Path(rawPath).toUri();
        }
 catch (        Exception e) {
        }
        if (uri != null && uri.getScheme() != null) {
          if ("file".equalsIgnoreCase(uri.getScheme())) {
            path=uri.getPath();
          }
 else {
            throw new IllegalArgumentException("Path " + rawPath + " has a non-local scheme");
          }
        }
 else {
          path=rawPath;
        }
      }
      pp[i]=new File(path);
      if (!pp[i].isAbsolute()) {
        throw new IllegalArgumentException("Relative paths are not supported");
      }
    }
    localRocksDbDirectories=pp;
  }
}
