public <I2,K>JoinOperatorBaseBuilder<OUT> withWrappedInput2(Operator<I2> input2,SelectorFunctionKeys<I2,?> rawKeys2){
  @SuppressWarnings("unchecked") SelectorFunctionKeys<I2,K> keys2=(SelectorFunctionKeys<I2,K>)rawKeys2;
  TypeInformation<Tuple2<K,I2>> typeInfoWithKey2=KeyFunctions.createTypeWithKey(keys2);
  Operator<Tuple2<K,I2>> keyMapper2=KeyFunctions.appendKeyExtractor(input2,keys2);
  return withInput2(keyMapper2,typeInfoWithKey2,rawKeys2);
}
