/** 
 * @deprecated Use the {@link Projection} type
 * @see Projection#project(DataType)
 */
@Deprecated public static DataType projectRow(DataType dataType,int[] indexPaths){
  return Projection.of(indexPaths).project(dataType);
}
