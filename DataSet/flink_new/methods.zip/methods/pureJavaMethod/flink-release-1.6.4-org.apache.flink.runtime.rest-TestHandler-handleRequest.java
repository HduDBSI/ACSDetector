@Override protected CompletableFuture<TestResponse> handleRequest(@Nonnull HandlerRequest<TestRequest,TestParameters> request,RestfulGateway gateway){
  assertEquals(request.getPathParameter(JobIDPathParameter.class),PATH_JOB_ID);
  assertEquals(request.getQueryParameter(JobIDQueryParameter.class).get(0),QUERY_JOB_ID);
  final int id=request.getRequestBody().id;
  return handlerBody.apply(id);
}
