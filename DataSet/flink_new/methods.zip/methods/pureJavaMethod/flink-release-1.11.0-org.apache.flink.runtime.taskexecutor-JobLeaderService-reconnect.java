/** 
 * Triggers reconnection to the last known leader of the given job.
 * @param jobId specifying the job for which to trigger reconnection
 */
void reconnect(JobID jobId);
