@Nonnull private CompletableFuture<LogicalSlot> allocateSlotInternal(SlotRequestId slotRequestId,ScheduledUnit scheduledUnit,SlotProfile slotProfile,@Nullable Time allocationTimeout){
  log.debug("Received slot request [{}] for task: {}",slotRequestId,scheduledUnit.getTaskToExecute());
  componentMainThreadExecutor.assertRunningInMainThread();
  final CompletableFuture<LogicalSlot> allocationResultFuture=new CompletableFuture<>();
  internalAllocateSlot(allocationResultFuture,slotRequestId,scheduledUnit,slotProfile,allocationTimeout);
  return allocationResultFuture;
}
