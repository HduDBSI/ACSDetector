/** 
 * Since checkpoint is triggered asynchronously, we need to figure out when checkpoint is really triggered. Note that this should be invoked before scheduler initialized.
 * @return the latch representing checkpoint is really triggered
 */
private CountDownLatch getCheckpointTriggeredLatch(){
  final CountDownLatch checkpointTriggeredLatch=new CountDownLatch(1);
  final SimpleAckingTaskManagerGateway taskManagerGateway=new SimpleAckingTaskManagerGateway();
  testExecutionSlotAllocator.getLogicalSlotBuilder().setTaskManagerGateway(taskManagerGateway);
  taskManagerGateway.setCheckpointConsumer((executionAttemptID,jobId,checkpointId,timestamp,checkpointOptions) -> {
    checkpointTriggeredLatch.countDown();
  }
);
  return checkpointTriggeredLatch;
}
