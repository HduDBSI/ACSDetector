public static String getResultsFormated(Map<String,Object> map){
  StringBuilder builder=new StringBuilder();
  for (  Map.Entry<String,Object> entry : map.entrySet()) {
    builder.append("- ").append(entry.getKey()).append(" (").append(entry.getValue().getClass().getName());
    builder.append(")").append(": ").append(entry.getValue().toString()).append("\n");
  }
  return builder.toString();
}
