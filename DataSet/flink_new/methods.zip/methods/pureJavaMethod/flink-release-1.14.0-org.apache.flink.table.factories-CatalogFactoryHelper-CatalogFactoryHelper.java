public CatalogFactoryHelper(CatalogFactory catalogFactory,CatalogFactory.Context context){
  super(catalogFactory,context.getOptions(),PROPERTY_VERSION);
}
