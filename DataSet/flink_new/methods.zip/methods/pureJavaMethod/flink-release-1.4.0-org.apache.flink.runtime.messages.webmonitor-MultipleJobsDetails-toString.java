@Override public String toString(){
  return "MultipleJobsDetails{" + "running=" + running + ", finished="+ finished+ '}';
}
