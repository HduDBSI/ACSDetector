private void completeProcessing() throws InterruptedException, ExecutionException {
  if (finishingReason.shouldCallFinish() && !isCanceled() && !isFailing()) {
    mainMailboxExecutor.submit(() -> {
      operatorChain.endInput(1);
      endData();
    }
,"SourceStreamTask finished processing data.").get();
  }
}
