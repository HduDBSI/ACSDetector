private void initializeLocation(ExecutionVertex vertex,TaskManagerLocation location) throws Exception {
  SlotContext slot=new SimpleSlotContext(new AllocationID(),location,0,mock(TaskManagerGateway.class));
  SimpleSlot simpleSlot=new SimpleSlot(slot,mock(SlotOwner.class),0);
  if (!vertex.getCurrentExecutionAttempt().tryAssignResource(simpleSlot)) {
    throw new FlinkException("Could not assign resource.");
  }
}
