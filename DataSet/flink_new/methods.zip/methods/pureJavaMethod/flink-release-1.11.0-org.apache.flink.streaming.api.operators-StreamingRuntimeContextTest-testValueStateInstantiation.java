@Test public void testValueStateInstantiation() throws Exception {
  final ExecutionConfig config=new ExecutionConfig();
  config.registerKryoType(Path.class);
  final AtomicReference<Object> descriptorCapture=new AtomicReference<>();
  StreamingRuntimeContext context=createRuntimeContext(descriptorCapture,config);
  ValueStateDescriptor<TaskInfo> descr=new ValueStateDescriptor<>("name",TaskInfo.class);
  context.getState(descr);
  StateDescriptor<?,?> descrIntercepted=(StateDescriptor<?,?>)descriptorCapture.get();
  TypeSerializer<?> serializer=descrIntercepted.getSerializer();
  assertTrue(serializer instanceof KryoSerializer);
  assertTrue(((KryoSerializer<?>)serializer).getKryo().getRegistration(Path.class).getId() > 0);
}
