@Override protected JobExceptionsInfo handleRequest(HandlerRequest<EmptyRequestBody,JobMessageParameters> request,AccessExecutionGraph executionGraph){
  return createJobExceptionsInfo(executionGraph);
}
