public CallExpression cast(ResolvedExpression expression,DataType dataType){
  return createCallExpression(BuiltInFunctionDefinitions.CAST,Arrays.asList(expression,typeLiteral(dataType)),dataType);
}
