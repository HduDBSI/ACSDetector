/** 
 * Tests that abort discards state. 
 */
@Test public void testAbortDiscardsState() throws Exception {
  CheckpointProperties props=new CheckpointProperties(false,CheckpointType.CHECKPOINT,false,false,false,false,false);
  QueueExecutor executor=new QueueExecutor();
  OperatorState state=mock(OperatorState.class);
  doNothing().when(state).registerSharedStates(any(SharedStateRegistry.class));
  PendingCheckpoint pending=createPendingCheckpoint(props,executor);
  setTaskState(pending,state);
  abort(pending,CheckpointFailureReason.CHECKPOINT_DECLINED);
  executor.runQueuedCommands();
  verify(state,times(1)).discardState();
  Mockito.reset(state);
  pending=createPendingCheckpoint(props,executor);
  setTaskState(pending,state);
  abort(pending,CheckpointFailureReason.CHECKPOINT_DECLINED);
  executor.runQueuedCommands();
  verify(state,times(1)).discardState();
  Mockito.reset(state);
  pending=createPendingCheckpoint(props,executor);
  setTaskState(pending,state);
  abort(pending,CheckpointFailureReason.CHECKPOINT_EXPIRED);
  executor.runQueuedCommands();
  verify(state,times(1)).discardState();
  Mockito.reset(state);
  pending=createPendingCheckpoint(props,executor);
  setTaskState(pending,state);
  abort(pending,CheckpointFailureReason.CHECKPOINT_SUBSUMED);
  executor.runQueuedCommands();
  verify(state,times(1)).discardState();
}
