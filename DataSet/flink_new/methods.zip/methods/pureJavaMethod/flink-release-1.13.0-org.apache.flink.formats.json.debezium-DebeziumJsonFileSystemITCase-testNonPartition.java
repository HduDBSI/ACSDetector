@Test public void testNonPartition() throws Exception {
  prepareTables(false);
  createTable(false,source.toURI().toString(),false);
  createTable(true,sink.toURI().toString(),false);
  tEnv().executeSql("insert into sink select id,name,UPPER(name),description,weight from source").await();
  CloseableIterator<Row> iter=tEnv().executeSql("select id,upper_name,description,weight from sink").collect();
  List<String> results=CollectionUtil.iteratorToList(iter).stream().map(Row::toString).collect(Collectors.toList());
  iter.close();
  Assert.assertEquals(EXPECTED,results);
}
