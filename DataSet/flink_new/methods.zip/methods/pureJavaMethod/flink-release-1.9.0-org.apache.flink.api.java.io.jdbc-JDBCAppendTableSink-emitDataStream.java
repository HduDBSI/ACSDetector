@Override public void emitDataStream(DataStream<Row> dataStream){
  consumeDataStream(dataStream);
}
