/** 
 * Loads the key/value state back from this snapshot.
 * @param stateBackend The state backend that created this snapshot and can restore the key/value statefrom this snapshot.
 * @param keySerializer The serializer for the keys.
 * @param classLoader The class loader for user-defined types.
 * @param recoveryTimestamp The timestamp of the checkpoint we are recovering from.
 * @return An instance of the key/value state loaded from this snapshot.
 * @throws Exception Exceptions can occur during the state loading and are forwarded. 
 */
KvState<K,N,S,SD,Backend> restoreState(Backend stateBackend,TypeSerializer<K> keySerializer,ClassLoader classLoader,long recoveryTimestamp) throws Exception ;
