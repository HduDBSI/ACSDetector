public T withBucketAssigner(BucketAssigner<IN,BucketID> assigner){
  this.bucketAssigner=Preconditions.checkNotNull(assigner);
  return self();
}
