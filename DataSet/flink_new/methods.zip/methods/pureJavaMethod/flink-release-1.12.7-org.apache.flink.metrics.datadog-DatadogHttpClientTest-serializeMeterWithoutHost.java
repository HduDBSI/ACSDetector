@Test public void serializeMeterWithoutHost() throws JsonProcessingException {
  DSeries series=new DSeries();
  series.add(new DMeter(new TestMeter(0,1),METRIC,null,tags,() -> MOCKED_SYSTEM_MILLIS));
  assertSerialization(DatadogHttpClient.serialize(series),new MetricAssertion(MetricType.gauge,false,"1.0"));
}
