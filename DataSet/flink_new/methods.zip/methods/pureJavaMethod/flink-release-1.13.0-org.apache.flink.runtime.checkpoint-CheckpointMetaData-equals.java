@Override public boolean equals(Object o){
  if (this == o) {
    return true;
  }
  if (o == null || getClass() != o.getClass()) {
    return false;
  }
  CheckpointMetaData that=(CheckpointMetaData)o;
  return (checkpointId == that.checkpointId) && (timestamp == that.timestamp);
}
