public TestMaterializedCollectStreamResult(TableResult tableResult,int maxRowCount){
  super(tableResult,maxRowCount);
}
