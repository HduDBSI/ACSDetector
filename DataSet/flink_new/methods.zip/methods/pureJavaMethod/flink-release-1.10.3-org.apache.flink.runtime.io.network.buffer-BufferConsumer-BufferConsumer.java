private BufferConsumer(Buffer buffer,BufferBuilder.PositionMarker currentWriterPosition,int currentReaderPosition){
  this.buffer=checkNotNull(buffer);
  this.writerPosition=new CachedPositionMarker(checkNotNull(currentWriterPosition));
  checkArgument(currentReaderPosition <= writerPosition.getCached(),"Reader position larger than writer position");
  this.currentReaderPosition=currentReaderPosition;
}
