@Override public void read(DataInputView in) throws IOException {
  jobID.read(in);
  vertexID.read(in);
  executionId.read(in);
  taskName=StringValue.readString(in);
  invokableClassName=StringValue.readString(in);
  indexInSubtaskGroup=in.readInt();
  currentNumberOfSubtasks=in.readInt();
  targetSlotNumber=in.readInt();
  jobConfiguration.read(in);
  taskConfiguration.read(in);
  inputGates=readGateList(in);
  outputGates=readGateList(in);
  final int numberOfJarFiles=in.readInt();
  for (int i=0; i < numberOfJarFiles; ++i) {
    final BlobKey key=new BlobKey();
    key.read(in);
    this.requiredJarFiles.add(key);
  }
}
