/** 
 * Ensure that that Akka configuration parameters can be set.
 */
@Test(expected=FlinkException.class) public void testInvalidAkkaConfiguration() throws Throwable {
  assumeTrue(CoreOptions.LEGACY_MODE.equalsIgnoreCase(configuration.getString(CoreOptions.MODE)));
  Configuration config=new Configuration();
  config.setString(AkkaOptions.STARTUP_TIMEOUT,INVALID_STARTUP_TIMEOUT);
  final ExecutionEnvironment env=ExecutionEnvironment.createRemoteEnvironment(hostname,port,config);
  env.getConfig().disableSysoutLogging();
  DataSet<String> result=env.createInput(new TestNonRichInputFormat());
  result.output(new LocalCollectionOutputFormat<>(new ArrayList<String>()));
  try {
    env.execute();
    Assert.fail("Program should not run successfully, cause of invalid akka settings.");
  }
 catch (  ProgramInvocationException ex) {
    throw ex.getCause();
  }
}
