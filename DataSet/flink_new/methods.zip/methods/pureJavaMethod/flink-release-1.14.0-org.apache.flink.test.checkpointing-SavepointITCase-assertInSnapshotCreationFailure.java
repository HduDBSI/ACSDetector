private static BiFunction<JobID,ExecutionException,Boolean> assertInSnapshotCreationFailure(){
  return (ignored,actualException) -> {
    if (ClusterOptions.isAdaptiveSchedulerEnabled(new Configuration())) {
      return findThrowable(actualException,FlinkException.class).isPresent();
    }
 else {
      return findThrowable(actualException,CheckpointException.class).isPresent();
    }
  }
;
}
