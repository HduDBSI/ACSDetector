@Override public Optional<BufferOrEvent> pollNext() throws Exception {
  while (true) {
    Optional<BufferOrEvent> next=inputGate.pollNext();
    if (!next.isPresent()) {
      return handleEmptyBuffer();
    }
    BufferOrEvent bufferOrEvent=next.get();
    checkState(!barrierHandler.isBlocked(bufferOrEvent.getChannelInfo()));
    if (bufferOrEvent.isBuffer()) {
      return next;
    }
 else     if (bufferOrEvent.getEvent().getClass() == CheckpointBarrier.class) {
      CheckpointBarrier checkpointBarrier=(CheckpointBarrier)bufferOrEvent.getEvent();
      barrierHandler.processBarrier(checkpointBarrier,bufferOrEvent.getChannelInfo());
      return next;
    }
 else     if (bufferOrEvent.getEvent().getClass() == CancelCheckpointMarker.class) {
      barrierHandler.processCancellationBarrier((CancelCheckpointMarker)bufferOrEvent.getEvent());
    }
 else {
      if (bufferOrEvent.getEvent().getClass() == EndOfPartitionEvent.class) {
        barrierHandler.processEndOfPartition();
      }
      return next;
    }
  }
}
