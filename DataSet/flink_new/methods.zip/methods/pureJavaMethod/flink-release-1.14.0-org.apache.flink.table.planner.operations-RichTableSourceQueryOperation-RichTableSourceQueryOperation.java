public RichTableSourceQueryOperation(ObjectIdentifier identifier,TableSource<T> tableSource,FlinkStatistic statistic){
  super(tableSource,false);
  Preconditions.checkArgument(tableSource instanceof StreamTableSource,"Planner should always use StreamTableSource.");
  this.statistic=statistic;
  this.identifier=identifier;
}
