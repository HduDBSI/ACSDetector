private void resetSynchronousSavepointId(long id,boolean succeeded){
  if (!succeeded && activeSyncSavepointId != null && activeSyncSavepointId == id) {
    activeSyncSavepointId=null;
    operatorChain.setIgnoreEndOfInput(false);
  }
  syncSavepointId=null;
}
