/** 
 * Computes the memory size corresponding to the fraction of all memory governed by this MemoryManager.
 * @param fraction The fraction of all memory governed by this MemoryManager
 * @return The memory size corresponding to the memory fraction
 */
public long computeMemorySize(double fraction){
  validateFraction(fraction);
  return (long)Math.floor(memoryBudget.getTotalMemorySize() * fraction);
}
