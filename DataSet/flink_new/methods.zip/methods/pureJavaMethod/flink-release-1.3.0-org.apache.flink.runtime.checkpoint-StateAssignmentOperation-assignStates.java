public boolean assignStates() throws Exception {
  Map<OperatorID,OperatorState> localOperators=new HashMap<>(operatorStates);
  Map<JobVertexID,ExecutionJobVertex> localTasks=this.tasks;
  checkStateMappingCompleteness(allowNonRestoredState,operatorStates,tasks);
  for (  Map.Entry<JobVertexID,ExecutionJobVertex> task : localTasks.entrySet()) {
    final ExecutionJobVertex executionJobVertex=task.getValue();
    List<OperatorID> operatorIDs=executionJobVertex.getOperatorIDs();
    List<OperatorID> altOperatorIDs=executionJobVertex.getUserDefinedOperatorIDs();
    List<OperatorState> operatorStates=new ArrayList<>();
    boolean statelessTask=true;
    for (int x=0; x < operatorIDs.size(); x++) {
      OperatorID operatorID=altOperatorIDs.get(x) == null ? operatorIDs.get(x) : altOperatorIDs.get(x);
      OperatorState operatorState=localOperators.remove(operatorID);
      if (operatorState == null) {
        operatorState=new OperatorState(operatorID,executionJobVertex.getParallelism(),executionJobVertex.getMaxParallelism());
      }
 else {
        statelessTask=false;
      }
      operatorStates.add(operatorState);
    }
    if (statelessTask) {
      continue;
    }
    assignAttemptState(task.getValue(),operatorStates);
  }
  return true;
}
