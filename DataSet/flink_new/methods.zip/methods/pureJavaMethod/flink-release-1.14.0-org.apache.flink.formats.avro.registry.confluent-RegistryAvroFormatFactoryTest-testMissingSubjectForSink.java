@Test public void testMissingSubjectForSink(){
  thrown.expect(ValidationException.class);
  thrown.expect(containsCause(new ValidationException("Option avro-confluent.subject is required for serialization")));
  final Map<String,String> options=getModifiedOptions(opts -> opts.remove("avro-confluent.subject"));
  createTableSink(SCHEMA,options);
}
