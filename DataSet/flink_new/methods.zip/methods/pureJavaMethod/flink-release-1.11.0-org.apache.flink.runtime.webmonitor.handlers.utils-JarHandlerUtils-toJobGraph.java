public JobGraph toJobGraph(Configuration configuration,boolean suppressOutput){
  try {
    final PackagedProgram packagedProgram=toPackagedProgram(configuration);
    return PackagedProgramUtils.createJobGraph(packagedProgram,configuration,parallelism,jobId,suppressOutput);
  }
 catch (  final ProgramInvocationException e) {
    throw new CompletionException(e);
  }
}
