/** 
 * Sets SSL options to verify peer's hostname in the certificate.
 * @param sslConfig The application configuration
 * @param sslParams The SSL parameters that need to be updated
 */
public static void setSSLVerifyHostname(Configuration sslConfig,SSLParameters sslParams){
  Preconditions.checkNotNull(sslConfig);
  Preconditions.checkNotNull(sslParams);
  boolean verifyHostname=sslConfig.getBoolean(SecurityOptions.SSL_VERIFY_HOSTNAME);
  if (verifyHostname) {
    sslParams.setEndpointIdentificationAlgorithm("HTTPS");
  }
}
