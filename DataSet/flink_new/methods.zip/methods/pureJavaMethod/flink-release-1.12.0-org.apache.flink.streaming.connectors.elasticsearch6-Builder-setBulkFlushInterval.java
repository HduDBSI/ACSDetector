/** 
 * Sets the bulk flush interval, in milliseconds.
 * @param intervalMillis the bulk flush interval, in milliseconds.
 */
public void setBulkFlushInterval(long intervalMillis){
  this.bulkRequestsConfig.put(CONFIG_KEY_BULK_FLUSH_INTERVAL_MS,String.valueOf(intervalMillis));
}
