@Override public Iterable<StatePartitionStreamProvider> getRawOperatorStateInputs(){
  return rawOperatorStateInputs;
}
