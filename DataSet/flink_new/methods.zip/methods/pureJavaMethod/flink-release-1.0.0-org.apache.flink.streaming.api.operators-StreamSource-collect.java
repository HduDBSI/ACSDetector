@Override public void collect(T element){
  owner.checkAsyncException();
synchronized (lockingObject) {
    output.collect(reuse.replace(element));
  }
}
