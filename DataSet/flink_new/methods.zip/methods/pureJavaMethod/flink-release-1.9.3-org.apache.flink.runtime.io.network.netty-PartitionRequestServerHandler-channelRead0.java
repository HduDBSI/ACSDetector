@Override protected void channelRead0(ChannelHandlerContext ctx,NettyMessage msg) throws Exception {
  try {
    Class<?> msgClazz=msg.getClass();
    if (msgClazz == PartitionRequest.class) {
      PartitionRequest request=(PartitionRequest)msg;
      LOG.debug("Read channel on {}: {}.",ctx.channel().localAddress(),request);
      try {
        NetworkSequenceViewReader reader;
        if (creditBasedEnabled) {
          reader=new CreditBasedSequenceNumberingViewReader(request.receiverId,request.credit,outboundQueue);
        }
 else {
          reader=new SequenceNumberingViewReader(request.receiverId,outboundQueue);
        }
        reader.requestSubpartitionView(partitionProvider,request.partitionId,request.queueIndex);
        outboundQueue.notifyReaderCreated(reader);
      }
 catch (      PartitionNotFoundException notFound) {
        respondWithError(ctx,notFound,request.receiverId);
      }
    }
 else     if (msgClazz == TaskEventRequest.class) {
      TaskEventRequest request=(TaskEventRequest)msg;
      if (!taskEventPublisher.publish(request.partitionId,request.event)) {
        respondWithError(ctx,new IllegalArgumentException("Task event receiver not found."),request.receiverId);
      }
    }
 else     if (msgClazz == CancelPartitionRequest.class) {
      CancelPartitionRequest request=(CancelPartitionRequest)msg;
      outboundQueue.cancel(request.receiverId);
    }
 else     if (msgClazz == CloseRequest.class) {
      outboundQueue.close();
    }
 else     if (msgClazz == AddCredit.class) {
      AddCredit request=(AddCredit)msg;
      outboundQueue.addCredit(request.receiverId,request.credit);
    }
 else {
      LOG.warn("Received unexpected client request: {}",msg);
    }
  }
 catch (  Throwable t) {
    respondWithError(ctx,t);
  }
}
