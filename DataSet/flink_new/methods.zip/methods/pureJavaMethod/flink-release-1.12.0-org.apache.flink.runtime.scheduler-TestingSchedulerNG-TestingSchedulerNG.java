public TestingSchedulerNG(CompletableFuture<Void> terminationFuture,Runnable startSchedulingRunnable,Consumer<Throwable> suspendConsumer){
  this.terminationFuture=terminationFuture;
  this.startSchedulingRunnable=startSchedulingRunnable;
  this.suspendConsumer=suspendConsumer;
}
