static void validateFormatOptions(ReadableConfig tableOptions){
  final boolean hasQuoteCharacter=tableOptions.getOptional(QUOTE_CHARACTER).isPresent();
  final boolean isDisabledQuoteCharacter=tableOptions.get(DISABLE_QUOTE_CHARACTER);
  if (isDisabledQuoteCharacter && hasQuoteCharacter) {
    throw new ValidationException("Format cannot define a quote character and disabled quote character at the same time.");
  }
  validateCharacterVal(tableOptions,FIELD_DELIMITER);
  validateCharacterVal(tableOptions,ARRAY_ELEMENT_DELIMITER);
  validateCharacterVal(tableOptions,QUOTE_CHARACTER);
  validateCharacterVal(tableOptions,ESCAPE_CHARACTER);
  tableOptions.getOptional(LINE_DELIMITER).ifPresent(delimiter -> {
    Set<String> allowedValues=new HashSet<>(Arrays.asList("\r","\n","\r\n",""));
    if (!allowedValues.contains(delimiter)) {
      throw new ValidationException(String.format("Invalid value for option '%s.%s'. Supported values are %s, but was: %s",IDENTIFIER,LINE_DELIMITER.key(),"[\\r, \\n, \\r\\n, \"\"]",delimiter));
    }
  }
);
}
