@Test public void testCompareBytesMixedSegments(){
  MemorySegment[] segs1=createSegments(pageSize);
  MemorySegment[] segs2=createSegments(pageSize);
  Random rnd=new Random();
  for (  MemorySegment seg1 : segs1) {
    for (    MemorySegment seg2 : segs2) {
      testCompare(seg1,seg2,rnd);
    }
  }
}
