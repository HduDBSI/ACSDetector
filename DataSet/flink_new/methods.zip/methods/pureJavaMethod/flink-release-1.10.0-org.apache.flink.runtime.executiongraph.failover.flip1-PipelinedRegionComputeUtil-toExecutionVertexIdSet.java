private static Function<Set<? extends SchedulingExecutionVertex<?,?>>,Set<ExecutionVertexID>> toExecutionVertexIdSet(){
  return failoverVertices -> failoverVertices.stream().map(SchedulingExecutionVertex::getId).collect(Collectors.toSet());
}
