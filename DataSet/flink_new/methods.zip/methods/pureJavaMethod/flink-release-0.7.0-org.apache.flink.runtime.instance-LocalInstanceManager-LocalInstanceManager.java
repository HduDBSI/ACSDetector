public LocalInstanceManager(int numTaskManagers) throws Exception {
  ExecutionMode execMode=numTaskManagers == 1 ? ExecutionMode.LOCAL : ExecutionMode.CLUSTER;
  final int ipcPort=GlobalConfiguration.getInteger(ConfigConstants.TASK_MANAGER_IPC_PORT_KEY,-1);
  final int dataPort=GlobalConfiguration.getInteger(ConfigConstants.TASK_MANAGER_DATA_PORT_KEY,-1);
  for (int i=0; i < numTaskManagers; i++) {
    if (ipcPort > 0 || dataPort > 0) {
      Configuration tm=new Configuration();
      if (ipcPort > 0) {
        tm.setInteger(ConfigConstants.TASK_MANAGER_IPC_PORT_KEY,ipcPort + i);
      }
      if (dataPort > 0) {
        tm.setInteger(ConfigConstants.TASK_MANAGER_DATA_PORT_KEY,dataPort + i);
      }
      GlobalConfiguration.includeConfiguration(tm);
    }
    taskManagers.add(TaskManager.createTaskManager(execMode));
  }
}
