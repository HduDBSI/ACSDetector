@Test public void testForwardIntoPojoByGettersAndSetters(){
  compareAnalyzerResultWithAnnotationsSingleInput(MapFunction.class,Map16.class,TypeInformation.of(new TypeHint<MyPojo>(){
  }
),TypeInformation.of(new TypeHint<MyPojo>(){
  }
));
}
