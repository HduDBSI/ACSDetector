@Override protected KafkaTableSink createTableSink(String topic,Properties properties,FlinkKafkaPartitioner<Row> partitioner,final FlinkKafkaProducerBase<Row> kafkaProducer){
  return new Kafka08JsonTableSink(topic,properties,partitioner){
    @Override protected FlinkKafkaProducerBase<Row> createKafkaProducer(    String topic,    Properties properties,    SerializationSchema<Row> serializationSchema,    FlinkKafkaPartitioner<Row> partitioner){
      return kafkaProducer;
    }
  }
;
}
