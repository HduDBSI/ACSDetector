/** 
 * Verify ssl client to non-ssl server failure.
 */
@Test(expected=IOException.class) public void testSSLClientFailure() throws Exception {
  uploadJarFile(BLOB_SERVER,sslClientConfig);
}
