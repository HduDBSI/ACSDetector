@Override public void open(Configuration parameters) throws IOException {
  aCounts=getRuntimeContext().getState(new ValueStateDescriptor<>("a",NonSerializableLong.class));
  bCounts=getRuntimeContext().getState(new ValueStateDescriptor<>("b",Long.class));
}
