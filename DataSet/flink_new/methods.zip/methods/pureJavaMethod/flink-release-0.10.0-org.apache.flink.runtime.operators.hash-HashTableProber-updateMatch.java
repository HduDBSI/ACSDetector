public void updateMatch(T record) throws IOException {
  if (closed) {
    return;
  }
  long newPointer=insertRecordIntoPartition(record,this.partition,true);
  this.bucket.putLong(this.pointerOffsetInBucket,newPointer);
}
