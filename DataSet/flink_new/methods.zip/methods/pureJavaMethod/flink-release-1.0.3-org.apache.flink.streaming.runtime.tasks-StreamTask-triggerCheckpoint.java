@Override public boolean triggerCheckpoint(long checkpointId,long timestamp) throws Exception {
  try {
    return performCheckpoint(checkpointId,timestamp);
  }
 catch (  Exception e) {
    if (isRunning) {
      throw e;
    }
 else {
      return false;
    }
  }
}
