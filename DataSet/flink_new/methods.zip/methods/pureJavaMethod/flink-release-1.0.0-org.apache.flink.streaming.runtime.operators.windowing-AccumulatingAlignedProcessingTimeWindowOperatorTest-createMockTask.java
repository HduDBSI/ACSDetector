private static StreamTask<?,?> createMockTask(){
  StreamTask<?,?> task=mock(StreamTask.class);
  when(task.getAccumulatorMap()).thenReturn(new HashMap<String,Accumulator<?,?>>());
  when(task.getName()).thenReturn("Test task name");
  when(task.getExecutionConfig()).thenReturn(new ExecutionConfig());
  final Environment env=mock(Environment.class);
  when(env.getTaskInfo()).thenReturn(new TaskInfo("Test task name",0,1,0));
  when(env.getUserClassLoader()).thenReturn(AggregatingAlignedProcessingTimeWindowOperatorTest.class.getClassLoader());
  when(task.getEnvironment()).thenReturn(env);
  try {
    doAnswer(new Answer<AbstractStateBackend>(){
      @Override public AbstractStateBackend answer(      InvocationOnMock invocationOnMock) throws Throwable {
        final String operatorIdentifier=(String)invocationOnMock.getArguments()[0];
        final TypeSerializer<?> keySerializer=(TypeSerializer<?>)invocationOnMock.getArguments()[1];
        MemoryStateBackend backend=MemoryStateBackend.create();
        backend.initializeForJob(env,operatorIdentifier,keySerializer);
        return backend;
      }
    }
).when(task).createStateBackend(any(String.class),any(TypeSerializer.class));
  }
 catch (  Exception e) {
    e.printStackTrace();
  }
  return task;
}
