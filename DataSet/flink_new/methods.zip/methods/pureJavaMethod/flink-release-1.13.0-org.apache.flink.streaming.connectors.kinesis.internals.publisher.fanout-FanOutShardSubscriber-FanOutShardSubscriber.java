/** 
 * Create a new Fan Out subscriber.
 * @param consumerArn the stream consumer ARN
 * @param shardId the shard ID to subscribe to
 * @param kinesis the Kinesis Proxy used to communicate via AWS SDK v2
 */
FanOutShardSubscriber(final String consumerArn,final String shardId,final KinesisProxyV2Interface kinesis){
  this.kinesis=Preconditions.checkNotNull(kinesis);
  this.consumerArn=Preconditions.checkNotNull(consumerArn);
  this.shardId=Preconditions.checkNotNull(shardId);
}
