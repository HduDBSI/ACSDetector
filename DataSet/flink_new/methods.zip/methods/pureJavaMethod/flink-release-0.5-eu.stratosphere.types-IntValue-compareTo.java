@Override public int compareTo(IntValue o){
  final int other=o.value;
  return this.value < other ? -1 : this.value > other ? 1 : 0;
}
