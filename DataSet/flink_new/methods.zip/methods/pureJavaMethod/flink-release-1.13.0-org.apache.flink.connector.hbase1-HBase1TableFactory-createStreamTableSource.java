@Override public StreamTableSource<Row> createStreamTableSource(Map<String,String> properties){
  final DescriptorProperties descriptorProperties=getValidatedProperties(properties);
  Configuration hbaseClientConf=getHBaseConf(descriptorProperties);
  String hTableName=descriptorProperties.getString(CONNECTOR_TABLE_NAME);
  TableSchema tableSchema=TableSchemaUtils.getPhysicalSchema(descriptorProperties.getTableSchema(SCHEMA));
  HBaseTableSchema hbaseSchema=validateTableSchema(tableSchema);
  return new HBaseTableSource(hbaseClientConf,hTableName,hbaseSchema,null);
}
