/** 
 * Sets the size of the written data, i.e. the <tt>writer index</tt>, of this buffer.
 * @throws IndexOutOfBoundsException if the index is less than  {@link #getReaderIndex()} or greater than {@link #getMaxCapacity()}
 */
void setSize(int writerIndex);
