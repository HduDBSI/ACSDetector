@Override public void notifyCheckpointComplete(long checkpointId){
  state.numCompletedCheckpoints++;
}
