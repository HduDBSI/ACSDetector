protected DefaultOperatorStateBackendSnapshotStrategy(ClassLoader userClassLoader,Map<String,PartitionableListState<?>> registeredOperatorStates,Map<String,BackendWritableBroadcastState<?,?>> registeredBroadcastStates){
  this.userClassLoader=userClassLoader;
  this.registeredOperatorStates=registeredOperatorStates;
  this.registeredBroadcastStates=registeredBroadcastStates;
}
