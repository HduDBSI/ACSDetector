private RecordWriter createRecordWriter(NetworkBufferPool globalPool) throws Exception {
  final BufferPool localPool=globalPool.createBufferPool(1,1,1,Integer.MAX_VALUE);
  final ResultPartitionWriter partition=new ResultPartitionBuilder().setBufferPoolFactory(() -> localPool).build();
  partition.setup();
  return new RecordWriterBuilder().build(partition);
}
