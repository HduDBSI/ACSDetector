protected ProgramOptions(CommandLine line) throws CliArgsException {
  super(line);
  this.entryPointClass=line.hasOption(CLASS_OPTION.getOpt()) ? line.getOptionValue(CLASS_OPTION.getOpt()) : null;
  this.jarFilePath=line.hasOption(JAR_OPTION.getOpt()) ? line.getOptionValue(JAR_OPTION.getOpt()) : null;
  this.programArgs=extractProgramArgs(line);
  List<URL> classpaths=new ArrayList<URL>();
  if (line.hasOption(CLASSPATH_OPTION.getOpt())) {
    for (    String path : line.getOptionValues(CLASSPATH_OPTION.getOpt())) {
      try {
        classpaths.add(new URL(path));
      }
 catch (      MalformedURLException e) {
        throw new CliArgsException("Bad syntax for classpath: " + path);
      }
    }
  }
  this.classpaths=classpaths;
  if (line.hasOption(PARALLELISM_OPTION.getOpt())) {
    String parString=line.getOptionValue(PARALLELISM_OPTION.getOpt());
    try {
      parallelism=Integer.parseInt(parString);
      if (parallelism <= 0) {
        throw new NumberFormatException();
      }
    }
 catch (    NumberFormatException e) {
      throw new CliArgsException("The parallelism must be a positive number: " + parString);
    }
  }
 else {
    parallelism=ExecutionConfig.PARALLELISM_DEFAULT;
  }
  detachedMode=line.hasOption(DETACHED_OPTION.getOpt()) || line.hasOption(YARN_DETACHED_OPTION.getOpt());
  shutdownOnAttachedExit=line.hasOption(SHUTDOWN_IF_ATTACHED_OPTION.getOpt());
  this.savepointSettings=CliFrontendParser.createSavepointRestoreSettings(line);
}
