public Factory(GeneratedRecordComparator genSortKeyComparator,RowDataKeySelector sortKeySelector,TypeSerializer<RowData> recordSerializer,long topN){
  this.generatedSortKeyComparator=genSortKeyComparator;
  this.sortKeySelector=sortKeySelector;
  this.recordSerializer=recordSerializer;
  this.topN=topN;
}
