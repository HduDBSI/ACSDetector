@Override public void collectWithTimestamp(T element,long timestamp){
  owner.checkAsyncException();
synchronized (lockingObject) {
    output.collect(reuse.replace(element,timestamp));
  }
}
