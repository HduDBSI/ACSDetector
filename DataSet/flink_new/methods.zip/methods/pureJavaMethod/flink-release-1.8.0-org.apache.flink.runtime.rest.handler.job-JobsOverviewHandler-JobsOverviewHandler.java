public JobsOverviewHandler(GatewayRetriever<? extends RestfulGateway> leaderRetriever,Time timeout,Map<String,String> responseHeaders,MessageHeaders<EmptyRequestBody,MultipleJobsDetails,EmptyMessageParameters> messageHeaders){
  super(leaderRetriever,timeout,responseHeaders,messageHeaders);
}
