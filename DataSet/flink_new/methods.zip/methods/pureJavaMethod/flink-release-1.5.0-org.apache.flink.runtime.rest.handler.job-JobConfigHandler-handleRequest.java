@Override protected JobConfigInfo handleRequest(HandlerRequest<EmptyRequestBody,JobMessageParameters> request,AccessExecutionGraph executionGraph){
  return createJobConfigInfo(executionGraph);
}
