/** 
 * Tests that the  {@link Dispatcher} terminates if it cannot recover jobs ids fromthe  {@link SubmittedJobGraphStore}. See FLINK-8943.
 */
@Test public void testFatalErrorAfterJobIdRecoveryFailure() throws Exception {
  final FlinkException testException=new FlinkException("Test exception");
  submittedJobGraphStore.setJobIdsFunction((  Collection<JobID> jobIds) -> {
    throw testException;
  }
);
  electDispatcher();
  final Throwable error=fatalErrorHandler.getErrorFuture().get(TIMEOUT.toMilliseconds(),TimeUnit.MILLISECONDS);
  assertThat(ExceptionUtils.findThrowableWithMessage(error,testException.getMessage()).isPresent(),is(true));
  fatalErrorHandler.clearError();
}
