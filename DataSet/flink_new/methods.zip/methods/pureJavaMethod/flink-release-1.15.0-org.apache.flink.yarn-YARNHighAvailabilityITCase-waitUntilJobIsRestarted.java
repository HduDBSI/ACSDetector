private static void waitUntilJobIsRestarted(final RestClusterClient<ApplicationId> restClusterClient,final JobID jobId,final int expectedFullRestarts) throws Exception {
  CommonTestUtils.waitUntilCondition(() -> getJobFullRestarts(restClusterClient,jobId) >= expectedFullRestarts);
}
