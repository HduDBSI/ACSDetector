@Override public void restart(final RestartCallback restarter,ScheduledExecutor executor){
  if (isRestartTimestampsQueueFull()) {
    restartTimestampsDeque.remove();
  }
  restartTimestampsDeque.add(System.currentTimeMillis());
  executor.schedule(new Runnable(){
    @Override public void run(){
      restarter.triggerFullRecovery();
    }
  }
,delayInterval.getSize(),delayInterval.getUnit());
}
