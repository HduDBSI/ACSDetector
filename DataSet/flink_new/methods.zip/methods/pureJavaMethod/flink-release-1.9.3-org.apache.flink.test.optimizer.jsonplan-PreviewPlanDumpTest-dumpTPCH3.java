@Test public void dumpTPCH3(){
  PreviewPlanEnvironment env=new PreviewPlanEnvironment();
  env.setAsContext();
  try {
    TPCHQuery3.main(new String[]{"--lineitem",IN_FILE,"--customer",IN_FILE,"--orders",OUT_FILE,"--output","123"});
  }
 catch (  OptimizerPlanEnvironment.ProgramAbortException pae) {
  }
catch (  Exception e) {
    e.printStackTrace();
    Assert.fail("TPCH3 failed with an exception");
  }
  dump(env.getPlan());
}
