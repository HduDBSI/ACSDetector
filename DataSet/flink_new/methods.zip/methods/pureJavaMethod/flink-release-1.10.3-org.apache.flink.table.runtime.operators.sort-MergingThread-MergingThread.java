public MergingThread(ExceptionHandler<IOException> exceptionHandler,CircularQueues queues,IOManager ioManager,int maxNumFileHandles,BinaryExternalMerger merger){
  super(exceptionHandler,"SortMerger merging thread",queues);
  this.ioManager=ioManager;
  this.maxFanIn=maxNumFileHandles;
  this.merger=merger;
}
