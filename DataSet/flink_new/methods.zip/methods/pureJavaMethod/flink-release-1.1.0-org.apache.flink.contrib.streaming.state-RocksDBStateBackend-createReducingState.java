@Override protected <N,T>ReducingState<T> createReducingState(TypeSerializer<N> namespaceSerializer,ReducingStateDescriptor<T> stateDesc) throws Exception {
  ColumnFamilyHandle columnFamily=getColumnFamily(stateDesc);
  return new RocksDBReducingState<>(columnFamily,namespaceSerializer,stateDesc,this);
}
