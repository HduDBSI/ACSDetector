/** 
 * Tests that an existing path throws an Exception.
 */
@Test(expected=Exception.class) public void testAddAlreadyExistingPath() throws Exception {
  LongStateStorage stateHandleProvider=new LongStateStorage();
  ZooKeeperStateHandleStore<Long> store=new ZooKeeperStateHandleStore<>(ZOOKEEPER.getClient(),stateHandleProvider);
  ZOOKEEPER.getClient().create().forPath("/testAddAlreadyExistingPath");
  store.addAndLock("/testAddAlreadyExistingPath",1L);
  assertEquals(1,stateHandleProvider.getStateHandles());
  assertEquals(1,stateHandleProvider.getStateHandles().get(0).getNumberOfDiscardCalls());
}
