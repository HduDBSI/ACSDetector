private MergingThread getMergingThread(ExceptionHandler<IOException> exceptionHandler,CircularQueues queues,int maxNumFileHandles,BinaryExternalMerger merger){
  return new MergingThread(exceptionHandler,queues,maxNumFileHandles,merger);
}
