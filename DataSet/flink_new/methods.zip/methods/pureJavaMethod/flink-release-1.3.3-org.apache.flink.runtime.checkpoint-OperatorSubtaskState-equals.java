@Override public boolean equals(Object o){
  if (this == o) {
    return true;
  }
  if (o == null || getClass() != o.getClass()) {
    return false;
  }
  OperatorSubtaskState that=(OperatorSubtaskState)o;
  if (stateSize != that.stateSize) {
    return false;
  }
  if (legacyOperatorState != null ? !legacyOperatorState.equals(that.legacyOperatorState) : that.legacyOperatorState != null) {
    return false;
  }
  if (managedOperatorState != null ? !managedOperatorState.equals(that.managedOperatorState) : that.managedOperatorState != null) {
    return false;
  }
  if (rawOperatorState != null ? !rawOperatorState.equals(that.rawOperatorState) : that.rawOperatorState != null) {
    return false;
  }
  if (managedKeyedState != null ? !managedKeyedState.equals(that.managedKeyedState) : that.managedKeyedState != null) {
    return false;
  }
  return rawKeyedState != null ? rawKeyedState.equals(that.rawKeyedState) : that.rawKeyedState == null;
}
