private FileInputSplit createTempDeflateFile(String content) throws IOException {
  File tempFile=File.createTempFile("test_contents","tmp.deflate");
  tempFile.deleteOnExit();
  DataOutputStream dos=new DataOutputStream(new DeflaterOutputStream(new FileOutputStream(tempFile)));
  dos.writeBytes(content);
  dos.close();
  return new FileInputSplit(0,new Path(tempFile.toURI().toString()),0,tempFile.length(),new String[]{"localhost"});
}
