public static BufferBuilder createFilledBufferBuilder(MemorySegment memorySegment,int dataSize){
  BufferBuilder bufferBuilder=new BufferBuilder(memorySegment,FreeingBufferRecycler.INSTANCE);
  return fillBufferBuilder(bufferBuilder,dataSize);
}
