/** 
 * Creates a new key/value state for the given hash map of key/value pairs.
 * @param stateDesc The state identifier for the state. This contains nameand can create a default state value.
 * @param stateTable The state tab;e to use in this kev/value state. May contain initial state.
 */
public HeapListState(ListStateDescriptor<V> stateDesc,StateTable<K,N,ArrayList<V>> stateTable,TypeSerializer<K> keySerializer,TypeSerializer<N> namespaceSerializer){
  super(stateDesc,stateTable,keySerializer,namespaceSerializer);
}
