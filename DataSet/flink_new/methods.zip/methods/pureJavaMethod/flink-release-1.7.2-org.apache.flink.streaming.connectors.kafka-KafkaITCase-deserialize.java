@Override public Long deserialize(byte[] messageKey,byte[] message,String topic,int partition,long offset) throws IOException {
  cnt++;
  DataInputView in=new DataInputViewStreamWrapper(new ByteArrayInputStream(message));
  Long e=ser.deserialize(in);
  return e;
}
