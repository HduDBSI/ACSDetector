TestingExecutor(List<SupplierWithException<TypedResult<List<Tuple2<Boolean,Row>>>,SqlExecutionException>> resultChanges,List<SupplierWithException<TypedResult<Integer>,SqlExecutionException>> snapshotResults,List<SupplierWithException<List<Row>,SqlExecutionException>> resultPages,BiFunctionWithException<String,String,TableResult,SqlExecutionException> executeSqlConsumer,TriFunctionWithException<String,String,String,Void,SqlExecutionException> setSessionPropertyFunction,FunctionWithException<String,Void,SqlExecutionException> resetSessionPropertiesFunction){
  this.resultChanges=resultChanges;
  this.snapshotResults=snapshotResults;
  this.resultPages=resultPages;
  this.executeSqlConsumer=executeSqlConsumer;
  this.setSessionPropertyFunction=setSessionPropertyFunction;
  this.resetSessionPropertiesFunction=resetSessionPropertiesFunction;
  helper=new SqlParserHelper();
  helper.registerTables();
}
