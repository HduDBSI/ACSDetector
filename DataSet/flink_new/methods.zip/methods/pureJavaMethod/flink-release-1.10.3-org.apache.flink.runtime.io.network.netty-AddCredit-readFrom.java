static AddCredit readFrom(ByteBuf buffer){
  ResultPartitionID partitionId=new ResultPartitionID(IntermediateResultPartitionID.fromByteBuf(buffer),ExecutionAttemptID.fromByteBuf(buffer));
  int credit=buffer.readInt();
  InputChannelID receiverId=InputChannelID.fromByteBuf(buffer);
  return new AddCredit(partitionId,credit,receiverId);
}
