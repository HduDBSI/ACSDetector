/** 
 * Create a new  {@link SslHandler} factory.
 * @param handshakeTimeoutMs SSL session timeout during handshakes (-1 = use system default)
 * @param closeNotifyFlushTimeoutMs SSL session timeout after flushing the <tt>close_notify</tt> message (-1 = use system default)
 */
public SSLHandlerFactory(final SslContext sslContext,final int handshakeTimeoutMs,final int closeNotifyFlushTimeoutMs){
  this.sslContext=requireNonNull(sslContext,"sslContext must not be null");
  this.handshakeTimeoutMs=handshakeTimeoutMs;
  this.closeNotifyFlushTimeoutMs=closeNotifyFlushTimeoutMs;
}
