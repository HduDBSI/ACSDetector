@Override public void next(){
  iterator.next();
  status();
}
