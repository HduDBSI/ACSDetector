/** 
 * Sets the parallelism for this data sink. The degree must be 1 or more.
 * @param parallelism The parallelism for this data sink. A value equal to {@link ExecutionConfig#PARALLELISM_DEFAULT}will use the system default.
 * @return This data sink with set parallelism.
 */
public DataSink<T> setParallelism(int parallelism){
  OperatorValidationUtils.validateParallelism(parallelism);
  this.parallelism=parallelism;
  return this;
}
