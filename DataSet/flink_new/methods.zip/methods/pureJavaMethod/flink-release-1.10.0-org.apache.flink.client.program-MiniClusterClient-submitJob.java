@Override public CompletableFuture<JobID> submitJob(@Nonnull JobGraph jobGraph){
  return miniCluster.submitJob(jobGraph).thenApply(JobSubmissionResult::getJobID);
}
