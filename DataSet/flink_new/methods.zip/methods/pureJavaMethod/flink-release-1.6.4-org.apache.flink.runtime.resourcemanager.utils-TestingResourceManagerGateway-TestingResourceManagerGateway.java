public TestingResourceManagerGateway(ResourceManagerId resourceManagerId,ResourceID resourceId,long heartbeatInterval,String address,String hostname){
  this.resourceManagerId=Preconditions.checkNotNull(resourceManagerId);
  this.ownResourceId=Preconditions.checkNotNull(resourceId);
  this.heartbeatInterval=heartbeatInterval;
  this.address=Preconditions.checkNotNull(address);
  this.hostname=Preconditions.checkNotNull(hostname);
  this.slotFutureReference=new AtomicReference<>();
  this.cancelSlotConsumer=null;
  this.requestSlotConsumer=null;
}
