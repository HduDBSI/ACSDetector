/** 
 * Adds the given sink to this DataStream. Only streams with sinks added will be executed once the  {@link StreamExecutionEnvironment#execute()}method is called.
 * @param sinkFunction The object containing the sink's invoke function.
 * @return The closed DataStream.
 */
public DataStreamSink<OUT> addSink(SinkFunction<OUT> sinkFunction){
  OneInputStreamOperator<OUT,Object> sinkOperator=new StreamSink<OUT>(clean(sinkFunction));
  DataStreamSink<OUT> returnStream=new DataStreamSink<OUT>(environment,"sink",getType(),sinkOperator);
  streamGraph.addOperator(returnStream.getId(),sinkOperator,getType(),null,"Stream Sink");
  this.connectGraph(this.copy(),returnStream.getId(),0);
  return returnStream;
}
