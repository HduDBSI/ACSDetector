private CompletableFuture<LogicalSlot> allocateSingleSlot(SlotRequestId slotRequestId,SlotProfile slotProfile,@Nullable Time allocationTimeout){
  Optional<SlotAndLocality> slotAndLocality=tryAllocateFromAvailable(slotRequestId,slotProfile);
  if (slotAndLocality.isPresent()) {
    try {
      return CompletableFuture.completedFuture(completeAllocationByAssigningPayload(slotRequestId,slotAndLocality.get()));
    }
 catch (    FlinkException e) {
      return FutureUtils.completedExceptionally(e);
    }
  }
 else {
    return requestNewAllocatedSlot(slotRequestId,slotProfile,allocationTimeout).thenApply((    PhysicalSlot allocatedSlot) -> {
      try {
        return completeAllocationByAssigningPayload(slotRequestId,new SlotAndLocality(allocatedSlot,Locality.UNKNOWN));
      }
 catch (      FlinkException e) {
        throw new CompletionException(e);
      }
    }
);
  }
}
