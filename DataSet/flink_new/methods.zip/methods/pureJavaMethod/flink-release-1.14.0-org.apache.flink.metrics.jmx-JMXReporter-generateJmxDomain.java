static String generateJmxDomain(String metricName,MetricGroup group){
  return JMX_DOMAIN_PREFIX + LogicalScopeProvider.castFrom(group).getLogicalScope(CHARACTER_FILTER,'.') + '.'+ metricName;
}
