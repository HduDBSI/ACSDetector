public String generateOperatorName(){
  return windowAssigner.getClass().getSimpleName();
}
