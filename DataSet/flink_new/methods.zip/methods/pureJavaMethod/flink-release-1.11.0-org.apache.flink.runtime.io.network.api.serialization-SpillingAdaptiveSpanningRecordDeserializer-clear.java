@Override public void clear(){
  this.nonSpanningWrapper.clear();
  this.spanningWrapper.clear();
}
