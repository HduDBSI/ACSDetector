private void setupSubtaskGateway(int subtask){
  final SubtaskAccess sta=taskAccesses.getAccessForSubtask(subtask);
  final OperatorCoordinator.SubtaskGateway gateway=new SubtaskGatewayImpl(sta,eventSender,mainThreadExecutor);
  FutureUtils.assertNoException(sta.hasSwitchedToRunning().thenAccept((ignored) -> {
    mainThreadExecutor.assertRunningInMainThread();
    if (sta.isStillRunning()) {
      notifySubtaskReady(subtask,gateway);
    }
  }
));
}
