public SubtaskState(ChainedStateHandle<OperatorStateHandle> managedOperatorState,ChainedStateHandle<OperatorStateHandle> rawOperatorState,KeyedStateHandle managedKeyedState,KeyedStateHandle rawKeyedState){
  this.managedOperatorState=managedOperatorState;
  this.rawOperatorState=rawOperatorState;
  this.managedKeyedState=managedKeyedState;
  this.rawKeyedState=rawKeyedState;
  try {
    long calculateStateSize=getSizeNullSafe(managedOperatorState);
    calculateStateSize+=getSizeNullSafe(rawOperatorState);
    calculateStateSize+=getSizeNullSafe(managedKeyedState);
    calculateStateSize+=getSizeNullSafe(rawKeyedState);
    stateSize=calculateStateSize;
  }
 catch (  Exception e) {
    throw new RuntimeException("Failed to get state size.",e);
  }
}
