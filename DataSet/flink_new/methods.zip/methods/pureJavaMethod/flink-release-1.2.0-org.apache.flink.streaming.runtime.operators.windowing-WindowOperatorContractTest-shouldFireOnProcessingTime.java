private static <T>void shouldFireOnProcessingTime(Trigger<T,TimeWindow> mockTrigger) throws Exception {
  when(mockTrigger.onProcessingTime(anyLong(),Matchers.<TimeWindow>any(),anyTriggerContext())).thenReturn(TriggerResult.FIRE);
}
