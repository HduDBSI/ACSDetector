private String formatPrefix(Factory formatFactory,ConfigOption<String> formatOption){
  String identifier=formatFactory.factoryIdentifier();
  return getFormatPrefix(formatOption,identifier);
}
