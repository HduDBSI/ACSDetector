public JobIdsHandler(CompletableFuture<String> localRestAddress,GatewayRetriever<? extends RestfulGateway> leaderRetriever,Time timeout,Map<String,String> responseHeaders,MessageHeaders<EmptyRequestBody,JobIdsWithStatusOverview,EmptyMessageParameters> messageHeaders){
  super(localRestAddress,leaderRetriever,timeout,responseHeaders,messageHeaders);
}
