@Override public void startNewWorker(ResourceProfile resourceProfile){
  Preconditions.checkArgument(ResourceProfile.UNKNOWN.equals(resourceProfile),"The YarnResourceManager does not support custom ResourceProfiles yet. It assumes that all containers have the same resources.");
  requestYarnContainer();
}
