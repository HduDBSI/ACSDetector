/** 
 * Checks that the edge set input contains valid vertex Ids, i.e. that they also exist in the vertex input set.
 * @return a boolean stating whether a graph is validwith respect to its vertex ids.
 */
@Override public boolean validate(Graph<K,VV,EV> graph) throws Exception {
  DataSet<Tuple1<K>> edgeIds=graph.getEdges().flatMap(new MapEdgeIds<>()).distinct();
  DataSet<K> invalidIds=graph.getVertices().coGroup(edgeIds).where(0).equalTo(0).with(new GroupInvalidIds<>()).first(1);
  return invalidIds.map(new KToTupleMap<>()).count() == 0;
}
