private static TaskManagerRunner createTaskManagerRunner(final Configuration configuration,TaskManagerRunner.TaskExecutorServiceFactory taskExecutorServiceFactory) throws Exception {
  final PluginManager pluginManager=PluginUtils.createPluginManagerFromRootFolder(configuration);
  TaskManagerRunner taskManagerRunner=new TaskManagerRunner(configuration,ResourceID.generate(),pluginManager,taskExecutorServiceFactory);
  taskManagerRunner.start();
  return taskManagerRunner;
}
