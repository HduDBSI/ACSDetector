public boolean getSSLEnabled(){
  return config.getBoolean(TaskManagerOptions.DATA_SSL_ENABLED) && SSLUtils.getSSLEnabled(config);
}
