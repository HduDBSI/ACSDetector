LatencyTrackingStateConfig(MetricGroup metricGroup,boolean enabled,int sampleInterval,int historySize){
  if (enabled) {
    Preconditions.checkNotNull(metricGroup,"Metric group cannot be null if latency tracking is enabled.");
    Preconditions.checkArgument(sampleInterval >= 1);
  }
  this.metricGroup=metricGroup;
  this.enabled=enabled;
  this.sampleInterval=sampleInterval;
  this.historySize=historySize;
}
