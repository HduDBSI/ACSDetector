@Override public String toString(){
  final StringBuilder sb=new StringBuilder();
  sb.append("root\n");
  for (  TableColumn column : columns) {
    sb.append(" |-- ");
    sb.append(column.asSummaryString());
    sb.append('\n');
  }
  if (!watermarkSpecs.isEmpty()) {
    for (    WatermarkSpec watermarkSpec : watermarkSpecs) {
      sb.append(" |-- ");
      sb.append(watermarkSpec.asSummaryString());
      sb.append('\n');
    }
  }
  if (primaryKey != null) {
    sb.append(" |-- ").append(primaryKey.asSummaryString());
    sb.append('\n');
  }
  return sb.toString();
}
