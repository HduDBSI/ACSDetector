@Override public void validate(DescriptorProperties properties){
  super.validate(properties);
  properties.validateValue(CONNECTOR_TYPE(),CONNECTOR_TYPE_VALUE_KAFKA,false);
  validateVersion(properties);
  validateStartupMode(properties);
  validateKafkaProperties(properties);
  validateSinkPartitioner(properties);
}
