@Override public Void answer(InvocationOnMock invocation) throws Throwable {
  final long execTime=(Long)invocation.getArguments()[0];
  final Triggerable target=(Triggerable)invocation.getArguments()[1];
  Thread caller=new Thread(){
    @Override public void run(){
      final long delay=execTime - System.currentTimeMillis();
      if (delay > 0) {
        try {
          Thread.sleep(delay);
        }
 catch (        InterruptedException ignored) {
        }
      }
synchronized (checkpointLock) {
        try {
          target.trigger(execTime);
        }
 catch (        Exception ignored) {
        }
      }
    }
  }
;
  caller.start();
  return null;
}
