/** 
 * Suspends the current ExecutionGraph. <p>The JobStatus will be directly set to  {@link JobStatus#SUSPENDED} iff the current state isnot a terminal state. All ExecutionJobVertices will be canceled and the onTerminalState() is executed. <p>The  {@link JobStatus#SUSPENDED} state is a local terminal state which stops the executionof the job but does not remove the job from the HA job store so that it can be recovered by another JobManager.
 * @param suspensionCause Cause of the suspension
 */
void suspend(Throwable suspensionCause);
