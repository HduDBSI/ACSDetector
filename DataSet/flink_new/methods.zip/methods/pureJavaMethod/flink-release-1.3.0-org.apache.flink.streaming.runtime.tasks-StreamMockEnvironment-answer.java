@Override public Void answer(InvocationOnMock invocationOnMock) throws Throwable {
  Buffer buffer=(Buffer)invocationOnMock.getArguments()[0];
  addBufferToOutputList(recordDeserializer,delegate,buffer,outputList);
  return null;
}
