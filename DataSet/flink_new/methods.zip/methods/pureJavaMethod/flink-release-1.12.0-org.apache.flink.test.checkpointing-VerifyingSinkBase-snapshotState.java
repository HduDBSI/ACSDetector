@Override public void snapshotState(FunctionSnapshotContext context) throws Exception {
  LOG.info("Snapshot state {} @ {} subtask ({} attempt)",state,getRuntimeContext().getIndexOfThisSubtask(),getRuntimeContext().getAttemptNumber());
  stateList.clear();
  stateList.add(state);
}
