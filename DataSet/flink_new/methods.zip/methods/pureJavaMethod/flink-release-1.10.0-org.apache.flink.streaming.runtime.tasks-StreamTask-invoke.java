@Override public final void invoke() throws Exception {
  try {
    beforeInvoke();
    if (canceled) {
      throw new CancelTaskException();
    }
    isRunning=true;
    runMailboxLoop();
    if (canceled) {
      throw new CancelTaskException();
    }
    afterInvoke();
  }
  finally {
    cleanUpInvoke();
  }
}
