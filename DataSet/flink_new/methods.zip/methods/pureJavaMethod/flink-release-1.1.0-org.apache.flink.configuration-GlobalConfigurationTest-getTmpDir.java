private File getTmpDir(){
  File tmpDir=new File(CommonTestUtils.getTempDir(),UUID.randomUUID().toString());
  assertTrue(tmpDir.mkdirs());
  return tmpDir;
}
