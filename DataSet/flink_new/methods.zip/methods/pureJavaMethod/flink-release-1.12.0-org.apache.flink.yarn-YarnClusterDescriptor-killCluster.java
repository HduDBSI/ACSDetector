@Override public void killCluster(ApplicationId applicationId) throws FlinkException {
  try {
    yarnClient.killApplication(applicationId);
    try (final FileSystem fs=FileSystem.get(yarnConfiguration)){
      final Path applicationDir=YarnApplicationFileUploader.getApplicationDirPath(getStagingDir(fs),applicationId);
      Utils.deleteApplicationFiles(applicationDir.toUri().toString());
    }
   }
 catch (  YarnException|IOException e) {
    throw new FlinkException("Could not kill the Yarn Flink cluster with id " + applicationId + '.',e);
  }
}
