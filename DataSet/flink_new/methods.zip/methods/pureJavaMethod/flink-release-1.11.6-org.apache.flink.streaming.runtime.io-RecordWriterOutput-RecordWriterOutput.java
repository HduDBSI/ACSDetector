@SuppressWarnings("unchecked") public RecordWriterOutput(RecordWriter<SerializationDelegate<StreamRecord<OUT>>> recordWriter,TypeSerializer<OUT> outSerializer,OutputTag outputTag,StreamStatusProvider streamStatusProvider,boolean supportsUnalignedCheckpoints){
  checkNotNull(recordWriter);
  this.outputTag=outputTag;
  this.recordWriter=(RecordWriter<SerializationDelegate<StreamElement>>)(RecordWriter<?>)recordWriter;
  TypeSerializer<StreamElement> outRecordSerializer=new StreamElementSerializer<>(outSerializer);
  if (outSerializer != null) {
    serializationDelegate=new SerializationDelegate<StreamElement>(outRecordSerializer);
  }
  this.streamStatusProvider=checkNotNull(streamStatusProvider);
  this.supportsUnalignedCheckpoints=supportsUnalignedCheckpoints;
}
