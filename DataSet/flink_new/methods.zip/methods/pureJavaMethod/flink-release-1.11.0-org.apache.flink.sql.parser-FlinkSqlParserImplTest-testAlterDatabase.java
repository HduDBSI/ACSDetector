@Test public void testAlterDatabase(){
  final String sql="alter database db1 set ('key1' = 'value1','key2.a' = 'value2.a')";
  final String expected="ALTER DATABASE `DB1` SET (\n" + "  'key1' = 'value1',\n" + "  'key2.a' = 'value2.a'\n"+ ")";
  sql(sql).ok(expected);
}
