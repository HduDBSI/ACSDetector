/** 
 * Tests that we can put  {@link ArchivedExecutionGraph} into the {@link FileArchivedExecutionGraphStore} and that the graph is persisted.
 */
@Test public void testPut() throws IOException {
  assertPutJobGraphWithStatus(JobStatus.FINISHED);
}
