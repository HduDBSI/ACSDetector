@Override public RetrievableStateHandle<CompletedCheckpoint> answer(InvocationOnMock invocationOnMock) throws Throwable {
  CompletedCheckpoint checkpoint=(CompletedCheckpoint)invocationOnMock.getArguments()[1];
  RetrievableStateHandle<CompletedCheckpoint> retrievableStateHandle=mock(RetrievableStateHandle.class);
  when(retrievableStateHandle.retrieveState()).thenReturn(checkpoint);
  return retrievableStateHandle;
}
