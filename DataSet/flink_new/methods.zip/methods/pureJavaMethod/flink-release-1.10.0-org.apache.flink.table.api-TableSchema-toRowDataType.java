/** 
 * Converts a table schema into a (nested) data type describing a {@link DataTypes#ROW(Field)}. <p>Note that the returned row type contains field types for all the columns, including normal columns and computed columns. Be caution with the computed column data types, because they are not expected to be included in the row type of TableSource or TableSink.
 */
public DataType toRowDataType(){
  final Field[] fields=columns.stream().map(column -> FIELD(column.getName(),column.getType())).toArray(Field[]::new);
  return ROW(fields);
}
