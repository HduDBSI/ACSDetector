private ListStateLatencyMetrics(String stateName,MetricGroup metricGroup,int sampleInterval,int historySize){
  super(stateName,metricGroup,sampleInterval,historySize);
}
