/** 
 * Internal function for assembling the underlying {@link org.apache.flink.runtime.jobgraph.JobGraph} of the job. Connectsthe outputs of the given input stream to the specified output stream given by the outputID.
 * @param inputStream input data stream
 * @param outputID ID of the output
 * @param typeNumber Number of the type (used at co-functions)
 */
protected <X>void connectGraph(DataStream<X> inputStream,Integer outputID,int typeNumber){
  for (  DataStream<X> stream : inputStream.unionizedStreams) {
    streamGraph.addEdge(stream.getId(),outputID,stream.partitioner,typeNumber,inputStream.userDefinedNames);
  }
}
