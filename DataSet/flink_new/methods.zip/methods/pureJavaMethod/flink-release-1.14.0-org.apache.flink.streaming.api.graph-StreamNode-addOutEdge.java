public void addOutEdge(StreamEdge outEdge){
  if (outEdge.getSourceId() != getId()) {
    throw new IllegalArgumentException("Source id doesn't match the StreamNode id");
  }
 else {
    outEdges.add(outEdge);
  }
}
