@Before public void before() throws Exception {
  env=StreamExecutionEnvironment.getExecutionEnvironment();
  tEnv=StreamTableEnvironment.create(env);
}
