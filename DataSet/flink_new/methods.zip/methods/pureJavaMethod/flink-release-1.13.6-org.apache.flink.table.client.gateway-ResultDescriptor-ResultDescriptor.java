public ResultDescriptor(String resultId,ResolvedSchema resultSchema,boolean isMaterialized,boolean isTableauMode,boolean isStreamingMode){
  this.resultId=resultId;
  this.resultSchema=resultSchema;
  this.isMaterialized=isMaterialized;
  this.isTableauMode=isTableauMode;
  this.isStreamingMode=isStreamingMode;
}
