@Override public void cancelTask(){
  running=false;
  dispose(true);
}
