@Override public void writeRecord(Row record){
  records.get(getKey()).add(record);
}
