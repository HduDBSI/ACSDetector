private void prepareRuntimeConverter(){
  CsvRowDataDeserializationSchema.Builder builder=new CsvRowDataDeserializationSchema.Builder(formatRowType,new GenericTypeInfo<>(RowData.class)).setIgnoreParseErrors(ignoreParseErrors);
  this.runtimeConverter=builder.build().createRowConverter(formatRowType,true);
}
