private QueryOperation projectInternal(List<Expression> projectList,QueryOperation child,boolean explicitAlias,List<OverWindow> overWindows){
  ExpressionResolver resolver=getResolverBuilder(child).withOverWindows(overWindows).build();
  List<ResolvedExpression> projections=resolver.resolve(projectList);
  return projectionOperationFactory.create(projections,child,explicitAlias,resolver.postResolverFactory());
}
