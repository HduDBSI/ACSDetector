protected StreamPlanEnvironment(ExecutionEnvironment env){
  super();
  this.env=env;
  int parallelism=env.getParallelism();
  if (parallelism > 0) {
    setParallelism(parallelism);
  }
 else {
    setParallelism(GlobalConfiguration.loadConfiguration().getInteger(CoreOptions.DEFAULT_PARALLELISM));
  }
}
