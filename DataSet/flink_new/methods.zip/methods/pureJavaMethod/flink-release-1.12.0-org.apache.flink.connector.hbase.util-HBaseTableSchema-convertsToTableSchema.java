/** 
 * Converts this  {@link HBaseTableSchema} to {@link TableSchema}, the fields are consisted of families and rowkey, the order is in the definition order (i.e. calling  {@link #addColumn(String,String,Class)} and {@link #setRowKey(String,Class)}). The family field is a composite type which is consisted of qualifiers.
 * @return the {@link TableSchema} derived from the {@link HBaseTableSchema}.
 */
public TableSchema convertsToTableSchema(){
  String[] familyNames=getFamilyNames();
  if (rowKeyInfo != null) {
    String[] fieldNames=new String[familyNames.length + 1];
    DataType[] fieldTypes=new DataType[familyNames.length + 1];
    for (int i=0; i < fieldNames.length; i++) {
      if (i == rowKeyInfo.rowKeyIndex) {
        fieldNames[i]=rowKeyInfo.rowKeyName;
        fieldTypes[i]=rowKeyInfo.rowKeyType;
      }
 else {
        int familyIndex=i < rowKeyInfo.rowKeyIndex ? i : i - 1;
        String family=familyNames[familyIndex];
        fieldNames[i]=family;
        fieldTypes[i]=getRowDataType(getQualifierNames(family),getQualifierDataTypes(family));
      }
    }
    return TableSchema.builder().fields(fieldNames,fieldTypes).build();
  }
 else {
    String[] fieldNames=new String[familyNames.length];
    DataType[] fieldTypes=new DataType[familyNames.length];
    for (int i=0; i < fieldNames.length; i++) {
      String family=familyNames[i];
      fieldNames[i]=family;
      fieldTypes[i]=getRowDataType(getQualifierNames(family),getQualifierDataTypes(family));
    }
    return TableSchema.builder().fields(fieldNames,fieldTypes).build();
  }
}
