/** 
 * Unregister a source reader.
 * @param subtaskId the subtask id of the source reader.
 */
void unregisterSourceReader(int subtaskId){
  registeredReaders.remove(subtaskId);
}
