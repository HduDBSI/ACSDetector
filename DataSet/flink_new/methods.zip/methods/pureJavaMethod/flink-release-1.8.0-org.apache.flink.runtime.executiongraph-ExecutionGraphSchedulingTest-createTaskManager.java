private static InteractionsCountingTaskManagerGateway createTaskManager(){
  return new InteractionsCountingTaskManagerGateway();
}
