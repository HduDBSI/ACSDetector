private TaskExecutorTestingContext(OneShotLatch offerSlotsLatch,TestingJobMasterGateway jobMasterGateway,JobLeaderService jobLeaderService,TaskSlotTable taskSlotTable,TestingTaskExecutor taskExecutor){
  this.offerSlotsLatch=offerSlotsLatch;
  this.jobMasterGateway=jobMasterGateway;
  this.jobLeaderService=jobLeaderService;
  this.taskSlotTable=taskSlotTable;
  this.taskExecutor=taskExecutor;
}
