/** 
 * Creates a new checkpoint stream aligner. <p>The aligner will allow only alignments that buffer up to the given number of bytes. When that number is exceeded, it will stop the alignment and notify the task that the checkpoint has been cancelled.
 * @param inputGate The input gate to draw the buffers and events from.
 * @param barrierHandler Handler that controls which channels are blocked.
 */
public CheckpointedInputGate(InputGate inputGate,CheckpointBarrierHandler barrierHandler){
  this.inputGate=inputGate;
  this.barrierHandler=barrierHandler;
}
