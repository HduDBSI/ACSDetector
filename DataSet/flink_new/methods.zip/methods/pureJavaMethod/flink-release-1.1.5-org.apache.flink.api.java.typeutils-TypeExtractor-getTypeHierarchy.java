/** 
 * @param curT : start type
 * @return Type The immediate child of the top class
 */
private static Type getTypeHierarchy(ArrayList<Type> typeHierarchy,Type curT,Class<?> stopAtClass){
  if (typeHierarchy.size() > 0 && typeHierarchy.get(0) == curT && isClassType(curT)) {
    curT=typeToClass(curT).getGenericSuperclass();
  }
  while (!(isClassType(curT) && typeToClass(curT).equals(stopAtClass))) {
    typeHierarchy.add(curT);
    curT=typeToClass(curT).getGenericSuperclass();
    if (curT == null) {
      break;
    }
  }
  return curT;
}
