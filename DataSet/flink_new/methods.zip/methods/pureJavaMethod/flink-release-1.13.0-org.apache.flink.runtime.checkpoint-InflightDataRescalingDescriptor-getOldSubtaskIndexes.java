public int[] getOldSubtaskIndexes(){
  return oldSubtaskIndexes;
}
