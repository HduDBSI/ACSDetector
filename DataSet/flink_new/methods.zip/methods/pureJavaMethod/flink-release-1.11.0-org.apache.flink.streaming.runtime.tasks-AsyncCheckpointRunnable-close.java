@Override public void close(){
  if (asyncCheckpointState.compareAndSet(AsyncCheckpointState.RUNNING,AsyncCheckpointState.DISCARDED)) {
    try {
      cleanup();
    }
 catch (    Exception cleanupException) {
      LOG.warn("Could not properly clean up the async checkpoint runnable.",cleanupException);
    }
  }
 else {
    logFailedCleanupAttempt();
  }
}
