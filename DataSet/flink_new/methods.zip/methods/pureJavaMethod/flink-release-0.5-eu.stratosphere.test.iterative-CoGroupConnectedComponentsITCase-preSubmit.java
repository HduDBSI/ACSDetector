@Override protected void preSubmit() throws Exception {
  verticesPath=createTempFile("vertices.txt",ConnectedComponentsData.getEnumeratingVertices(NUM_VERTICES));
  edgesPath=createTempFile("edges.txt",ConnectedComponentsData.getRandomOddEvenEdges(NUM_EDGES,NUM_VERTICES,SEED));
  resultPath=getTempFilePath("results");
}
