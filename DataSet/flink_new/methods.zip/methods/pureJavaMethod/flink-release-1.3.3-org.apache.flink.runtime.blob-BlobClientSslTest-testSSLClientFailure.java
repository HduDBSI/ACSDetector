/** 
 * Verify ssl client to non-ssl server failure
 */
@Test public void testSSLClientFailure() throws Exception {
  try {
    uploadJarFile(BLOB_SERVER,sslClientConfig);
    fail("SSL client connected to non-ssl server");
  }
 catch (  Exception e) {
  }
}
