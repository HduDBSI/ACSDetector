/** 
 * Creates a new  {@code RocksDBValueState}.
 * @param namespaceSerializer The serializer for the namespace.
 * @param stateDesc The state identifier for the state. This contains nameand can create a default state value.
 */
public RocksDBValueState(ColumnFamilyHandle columnFamily,TypeSerializer<N> namespaceSerializer,ValueStateDescriptor<V> stateDesc,RocksDBStateBackend backend){
  super(columnFamily,namespaceSerializer,backend);
  this.stateDesc=requireNonNull(stateDesc);
  this.valueSerializer=stateDesc.getSerializer();
  writeOptions=new WriteOptions();
  writeOptions.setDisableWAL(true);
}
