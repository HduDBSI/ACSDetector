@Override @SuppressWarnings("unchecked") public void open() throws Exception {
  super.open();
  rowDataWrapper=new StreamRecordRowDataWrappingCollector(output);
  reuseJoinedRow=new JoinedRowData();
  udtfInputProjection=createUdtfInputProjection();
  forwardedInputSerializer=new RowDataSerializer(inputType);
  udtfInputTypeSerializer=PythonTypeUtils.toInternalSerializer(userDefinedFunctionInputType);
  udtfOutputTypeSerializer=PythonTypeUtils.toInternalSerializer(userDefinedFunctionOutputType);
  input=null;
  hasJoined=false;
  isFinishResult=true;
}
