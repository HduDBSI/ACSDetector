private void cleanup() throws Exception {
  LOG.debug("Cleanup AsyncCheckpointRunnable for checkpoint {} of {}.",checkpointMetaData.getCheckpointId(),taskName);
  Exception exception=null;
  for (  OperatorSnapshotFutures operatorSnapshotResult : operatorSnapshotsInProgress.values()) {
    if (operatorSnapshotResult != null) {
      try {
        operatorSnapshotResult.cancel();
      }
 catch (      Exception cancelException) {
        exception=ExceptionUtils.firstOrSuppressed(cancelException,exception);
      }
    }
  }
  if (null != exception) {
    throw exception;
  }
}
