@Override public boolean equals(Object o){
  if (this == o) {
    return true;
  }
  if (o == null || getClass() != o.getClass()) {
    return false;
  }
  CachedSchemaCoderProvider that=(CachedSchemaCoderProvider)o;
  return identityMapCapacity == that.identityMapCapacity && Objects.equals(subject,that.subject) && url.equals(that.url);
}
