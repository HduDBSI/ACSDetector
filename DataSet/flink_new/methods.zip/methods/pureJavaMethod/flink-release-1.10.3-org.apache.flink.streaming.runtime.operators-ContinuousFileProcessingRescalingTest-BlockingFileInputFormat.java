BlockingFileInputFormat(OneShotLatch triggerLatch,OneShotLatch waitingLatch,Path filePath,int sizeOfSplit,int elementsBeforeCheckpoint){
  super(filePath);
  this.triggerLatch=triggerLatch;
  this.waitingLatch=waitingLatch;
  this.elementsBeforeCheckpoint=elementsBeforeCheckpoint;
  this.linesPerSplit=sizeOfSplit;
  this.state=0;
}
