/** 
 * Gets the type of the stream.
 * @return The type of the datastream.
 */
public TypeInformation<T> getType(){
  return transformation.getOutputType();
}
