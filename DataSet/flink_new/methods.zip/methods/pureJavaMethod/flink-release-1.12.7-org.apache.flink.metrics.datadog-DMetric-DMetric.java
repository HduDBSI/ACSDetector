public DMetric(MetricMetaData metaData){
  this.metaData=metaData;
}
