/** 
 * Loads a class from the classpath that implements the CustomCommandLine interface.
 * @param className The fully-qualified class name to load.
 * @param params The constructor parameters
 */
private static CustomCommandLine<?> loadCustomCommandLine(String className,Object... params) throws IllegalAccessException, InvocationTargetException, InstantiationException, ClassNotFoundException, NoSuchMethodException {
  Class<? extends CustomCommandLine> customCliClass=Class.forName(className).asSubclass(CustomCommandLine.class);
  Class<?>[] types=new Class<?>[params.length];
  for (int i=0; i < params.length; i++) {
    Preconditions.checkNotNull(params[i],"Parameters for custom command-lines may not be null.");
    types[i]=params[i].getClass();
  }
  Constructor<? extends CustomCommandLine> constructor=customCliClass.getConstructor(types);
  return constructor.newInstance(params);
}
