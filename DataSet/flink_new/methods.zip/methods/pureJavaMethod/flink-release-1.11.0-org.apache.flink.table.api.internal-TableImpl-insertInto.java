@Override public void insertInto(String tablePath){
  tableEnvironment.insertInto(tablePath,this);
}
