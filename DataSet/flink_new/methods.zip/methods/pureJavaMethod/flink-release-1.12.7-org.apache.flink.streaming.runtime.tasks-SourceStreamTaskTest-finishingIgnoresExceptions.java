/** 
 * If finishing a task doesn't swallow exceptions this test would fail with an exception. 
 */
@Test public void finishingIgnoresExceptions() throws Exception {
  final StreamTaskTestHarness<String> testHarness=new StreamTaskTestHarness<>(SourceStreamTask::new,STRING_TYPE_INFO);
  final CompletableFuture<Void> operatorRunningWaitingFuture=new CompletableFuture<>();
  ExceptionThrowingSource.setIsInRunLoopFuture(operatorRunningWaitingFuture);
  testHarness.setupOutputForSingletonOperatorChain();
  StreamConfig streamConfig=testHarness.getStreamConfig();
  streamConfig.setStreamOperator(new StreamSource<>(new ExceptionThrowingSource()));
  streamConfig.setOperatorID(new OperatorID());
  testHarness.invoke();
  operatorRunningWaitingFuture.get();
  testHarness.getTask().finishTask();
  testHarness.waitForTaskCompletion();
}
