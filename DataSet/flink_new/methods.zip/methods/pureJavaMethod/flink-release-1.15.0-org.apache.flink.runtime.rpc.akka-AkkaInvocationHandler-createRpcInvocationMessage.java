/** 
 * Create the RpcInvocation message for the given RPC.
 * @param declaringClassName of the RPC
 * @param methodName of the RPC
 * @param parameterTypes of the RPC
 * @param args of the RPC
 * @return RpcInvocation message which encapsulates the RPC details
 * @throws IOException if we cannot serialize the RPC invocation parameters
 */
protected RpcInvocation createRpcInvocationMessage(final String declaringClassName,final String methodName,final Class<?>[] parameterTypes,final Object[] args) throws IOException {
  final RpcInvocation rpcInvocation;
  if (isLocal) {
    rpcInvocation=new LocalRpcInvocation(declaringClassName,methodName,parameterTypes,args);
  }
 else {
    rpcInvocation=new RemoteRpcInvocation(declaringClassName,methodName,parameterTypes,args);
  }
  return rpcInvocation;
}
