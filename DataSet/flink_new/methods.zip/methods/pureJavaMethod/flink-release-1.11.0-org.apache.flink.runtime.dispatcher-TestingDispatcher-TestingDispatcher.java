TestingDispatcher(RpcService rpcService,DispatcherId fencingToken,DispatcherBootstrap dispatcherBootstrap,DispatcherServices dispatcherServices) throws Exception {
  super(rpcService,fencingToken,dispatcherBootstrap,dispatcherServices);
  this.startFuture=new CompletableFuture<>();
}
