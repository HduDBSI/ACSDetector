@After public void cleanupRocksDB(){
  if (keyedStateBackend != null) {
    IOUtils.closeQuietly(keyedStateBackend);
    keyedStateBackend.dispose();
  }
  IOUtils.closeQuietly(defaultCFHandle);
  IOUtils.closeQuietly(db);
  IOUtils.closeQuietly(columnOptions);
  IOUtils.closeQuietly(dbOptions);
  if (allCreatedCloseables != null) {
    for (    RocksObject rocksCloseable : allCreatedCloseables) {
      verify(rocksCloseable,times(1)).close();
    }
    allCreatedCloseables=null;
  }
  try {
    org.apache.flink.util.FileUtils.deleteDirectory(instanceBasePath);
  }
 catch (  Exception ex) {
  }
}
