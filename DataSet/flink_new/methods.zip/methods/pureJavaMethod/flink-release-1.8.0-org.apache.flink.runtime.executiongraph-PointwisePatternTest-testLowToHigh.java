private void testLowToHigh(int lowDop,int highDop) throws Exception {
  if (highDop < lowDop) {
    throw new IllegalArgumentException();
  }
  final int factor=highDop / lowDop;
  final int delta=highDop % lowDop == 0 ? 0 : 1;
  JobVertex v1=new JobVertex("vertex1");
  JobVertex v2=new JobVertex("vertex2");
  v1.setParallelism(lowDop);
  v2.setParallelism(highDop);
  v1.setInvokableClass(AbstractInvokable.class);
  v2.setInvokableClass(AbstractInvokable.class);
  v2.connectNewDataSetAsInput(v1,DistributionPattern.POINTWISE,ResultPartitionType.PIPELINED);
  List<JobVertex> ordered=new ArrayList<JobVertex>(Arrays.asList(v1,v2));
  ExecutionGraph eg=getDummyExecutionGraph();
  try {
    eg.attachJobGraph(ordered);
  }
 catch (  JobException e) {
    e.printStackTrace();
    fail("Job failed with exception: " + e.getMessage());
  }
  ExecutionJobVertex target=eg.getAllVertices().get(v2.getID());
  int[] timesUsed=new int[lowDop];
  for (  ExecutionVertex ev : target.getTaskVertices()) {
    assertEquals(1,ev.getNumberOfInputs());
    ExecutionEdge[] inEdges=ev.getInputEdges(0);
    assertEquals(1,inEdges.length);
    timesUsed[inEdges[0].getSource().getPartitionNumber()]++;
  }
  for (  int used : timesUsed) {
    assertTrue(used >= factor && used <= factor + delta);
  }
}
