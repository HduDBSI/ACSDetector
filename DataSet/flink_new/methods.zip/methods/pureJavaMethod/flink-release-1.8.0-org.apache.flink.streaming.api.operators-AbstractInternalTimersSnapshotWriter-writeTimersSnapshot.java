@Override public final void writeTimersSnapshot(DataOutputView out) throws IOException {
  writeKeyAndNamespaceSerializers(out);
  LegacyTimerSerializer<K,N> timerSerializer=new LegacyTimerSerializer<>(keySerializer,namespaceSerializer);
  Set<TimerHeapInternalTimer<K,N>> eventTimers=timersSnapshot.getEventTimeTimers();
  if (eventTimers != null) {
    out.writeInt(eventTimers.size());
    for (    TimerHeapInternalTimer<K,N> eventTimer : eventTimers) {
      timerSerializer.serialize(eventTimer,out);
    }
  }
 else {
    out.writeInt(0);
  }
  Set<TimerHeapInternalTimer<K,N>> processingTimers=timersSnapshot.getProcessingTimeTimers();
  if (processingTimers != null) {
    out.writeInt(processingTimers.size());
    for (    TimerHeapInternalTimer<K,N> processingTimer : processingTimers) {
      timerSerializer.serialize(processingTimer,out);
    }
  }
 else {
    out.writeInt(0);
  }
}
