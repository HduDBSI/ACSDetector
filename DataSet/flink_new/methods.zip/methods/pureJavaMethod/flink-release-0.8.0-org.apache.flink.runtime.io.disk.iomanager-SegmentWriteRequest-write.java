@Override public void write() throws IOException {
  try {
    this.channel.fileChannel.write(this.segment.wrap(0,this.segment.size()));
  }
 catch (  NullPointerException npex) {
    throw new IOException("Memory segment has been released.");
  }
}
