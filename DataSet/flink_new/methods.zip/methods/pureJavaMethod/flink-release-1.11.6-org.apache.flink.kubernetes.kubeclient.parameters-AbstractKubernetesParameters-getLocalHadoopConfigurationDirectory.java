@Override public Optional<String> getLocalHadoopConfigurationDirectory(){
  final String[] possibleHadoopConfPaths=new String[]{System.getenv(Constants.ENV_HADOOP_CONF_DIR),System.getenv(Constants.ENV_HADOOP_HOME) + "/etc/hadoop",System.getenv(Constants.ENV_HADOOP_HOME) + "/conf"};
  for (  String hadoopConfPath : possibleHadoopConfPaths) {
    if (StringUtils.isNotBlank(hadoopConfPath)) {
      return Optional.of(hadoopConfPath);
    }
  }
  return Optional.empty();
}
