private List<IntermediateResultPartitionID> filterReleasablePartitions(final Iterable<ConsumedPartitionGroup> consumedPartitionGroups){
  final List<IntermediateResultPartitionID> releasablePartitions=new ArrayList<>();
  for (  ConsumedPartitionGroup consumedPartitionGroup : consumedPartitionGroups) {
    final ConsumerRegionGroupExecutionView consumerRegionGroup=partitionGroupConsumerRegions.get(consumedPartitionGroup);
    if (consumerRegionGroup.isFinished()) {
      for (      IntermediateResultPartitionID partitionId : consumedPartitionGroup) {
        releasablePartitions.add(partitionId);
      }
    }
  }
  return releasablePartitions;
}
