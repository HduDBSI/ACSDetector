@Override public RowData getKey(RowData value) throws Exception {
  BinaryRowData ret=new BinaryRowData(keyFields.length);
  BinaryRowWriter writer=new BinaryRowWriter(ret);
  for (int i=0; i < keyFields.length; i++) {
    if (value.isNullAt(i)) {
      writer.setNullAt(i);
    }
 else {
      BinaryWriter.write(writer,i,fieldGetters[i].getFieldOrNull(value),inputFieldTypes[keyFields[i]],keySers[i]);
    }
  }
  writer.complete();
  return ret;
}
