@Override public boolean equals(Object o){
  if (this == o) {
    return true;
  }
  if (!(o instanceof AcknowledgeCheckpoint)) {
    return false;
  }
  if (!super.equals(o)) {
    return false;
  }
  AcknowledgeCheckpoint that=(AcknowledgeCheckpoint)o;
  return subtaskState != null ? subtaskState.equals(that.subtaskState) : that.subtaskState == null;
}
