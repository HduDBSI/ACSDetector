/** 
 * Finalizes the configuration of this sink.
 * @return finalized sink
 * @throws Exception
 */
public CassandraSink<IN> build() throws Exception {
  sanityCheck();
  return isWriteAheadLogEnabled ? createWriteAheadSink() : createSink();
}
