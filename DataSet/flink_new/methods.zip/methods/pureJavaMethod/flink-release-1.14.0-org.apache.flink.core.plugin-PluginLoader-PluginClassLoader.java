PluginClassLoader(URL[] pluginResourceURLs,ClassLoader flinkClassLoader,String[] allowedFlinkPackages){
  super(pluginResourceURLs,flinkClassLoader,allowedFlinkPackages,new String[0]);
}
