protected TypeInformation<Row> getRunnerInputTypeInfo(){
  return runnerInputTypeInfo;
}
