@Override public boolean equals(Object o){
  if (this == o) {
    return true;
  }
 else   if (o instanceof TimestampedFileInputSplit && super.equals(o)) {
    TimestampedFileInputSplit that=(TimestampedFileInputSplit)o;
    return this.modificationTime == that.modificationTime;
  }
  return false;
}
