@Override public YarnClusterClient deploy(){
  try {
    if (UserGroupInformation.isSecurityEnabled()) {
      boolean useTicketCache=flinkConfiguration.getBoolean(SecurityOptions.KERBEROS_LOGIN_USETICKETCACHE);
      UserGroupInformation loginUser=UserGroupInformation.getCurrentUser();
      if (useTicketCache && !loginUser.hasKerberosCredentials()) {
        LOG.error("Hadoop security is enabled but the login user does not have Kerberos credentials");
        throw new RuntimeException("Hadoop security is enabled but the login user " + "does not have Kerberos credentials");
      }
    }
    return deployInternal();
  }
 catch (  Exception e) {
    throw new RuntimeException("Couldn't deploy Yarn cluster",e);
  }
}
