public JobVertexBackPressureHandler(GatewayRetriever<? extends RestfulGateway> leaderRetriever,Time timeout,Map<String,String> responseHeaders,MessageHeaders<EmptyRequestBody,JobVertexBackPressureInfo,JobVertexMessageParameters> messageHeaders){
  super(leaderRetriever,timeout,responseHeaders,messageHeaders);
}
