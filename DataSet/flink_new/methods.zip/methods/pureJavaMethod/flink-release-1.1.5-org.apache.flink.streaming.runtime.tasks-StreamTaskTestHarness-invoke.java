/** 
 * Invoke the Task. This resets the output of any previous invocation. This will start a new Thread to execute the Task in. Use  {@link #waitForTaskCompletion()} to wait for theTask thread to finish running. <p>Variant for providing a custom environment.
 */
public void invoke(StreamMockEnvironment mockEnv) throws Exception {
  this.mockEnv=mockEnv;
  task.setEnvironment(mockEnv);
  initializeInputs();
  initializeOutput();
  taskThread=new TaskThread(task);
  taskThread.start();
}
