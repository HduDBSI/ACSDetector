@Override public void run(SourceContext<OUT> ctx) throws Exception {
  final RMQCollectorImpl collector=new RMQCollectorImpl(ctx);
  while (running) {
    Delivery delivery=consumer.nextDelivery();
synchronized (ctx.getCheckpointLock()) {
      processMessage(delivery,collector);
      if (collector.isEndOfStreamSignalled()) {
        this.running=false;
        return;
      }
    }
  }
}
