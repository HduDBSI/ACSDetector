/** 
 * Returns the latest  {@link CompletedCheckpoint} instance or <code>null</code> if none wasadded.
 */
default CompletedCheckpoint getLatestCheckpoint(boolean isPreferCheckpointForRecovery) throws Exception {
  List<CompletedCheckpoint> allCheckpoints=getAllCheckpoints();
  if (allCheckpoints.isEmpty()) {
    return null;
  }
  CompletedCheckpoint lastCompleted=allCheckpoints.get(allCheckpoints.size() - 1);
  if (isPreferCheckpointForRecovery && allCheckpoints.size() > 1 && lastCompleted.getProperties().isSavepoint()) {
    ListIterator<CompletedCheckpoint> listIterator=allCheckpoints.listIterator(allCheckpoints.size() - 1);
    while (listIterator.hasPrevious()) {
      CompletedCheckpoint prev=listIterator.previous();
      if (!prev.getProperties().isSavepoint()) {
        LOG.info("Found a completed checkpoint ({}) before the latest savepoint, will use it to recover!",prev);
        return prev;
      }
    }
    LOG.info("Did not find earlier checkpoint, using latest savepoint to recover.");
  }
  return lastCompleted;
}
