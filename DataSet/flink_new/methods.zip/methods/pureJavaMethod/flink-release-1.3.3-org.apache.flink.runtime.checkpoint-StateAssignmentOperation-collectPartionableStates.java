private void collectPartionableStates(List<OperatorState> operatorStates,List<List<OperatorStateHandle>> managedOperatorStates,List<List<OperatorStateHandle>> rawOperatorStates){
  for (  OperatorState operatorState : operatorStates) {
    List<OperatorStateHandle> managedOperatorState=null;
    List<OperatorStateHandle> rawOperatorState=null;
    for (int i=0; i < operatorState.getParallelism(); i++) {
      OperatorSubtaskState operatorSubtaskState=operatorState.getState(i);
      if (operatorSubtaskState != null) {
        if (operatorSubtaskState.getManagedOperatorState() != null) {
          if (managedOperatorState == null) {
            managedOperatorState=new ArrayList<>();
          }
          managedOperatorState.add(operatorSubtaskState.getManagedOperatorState());
        }
        if (operatorSubtaskState.getRawOperatorState() != null) {
          if (rawOperatorState == null) {
            rawOperatorState=new ArrayList<>();
          }
          rawOperatorState.add(operatorSubtaskState.getRawOperatorState());
        }
      }
    }
    managedOperatorStates.add(managedOperatorState);
    rawOperatorStates.add(rawOperatorState);
  }
}
