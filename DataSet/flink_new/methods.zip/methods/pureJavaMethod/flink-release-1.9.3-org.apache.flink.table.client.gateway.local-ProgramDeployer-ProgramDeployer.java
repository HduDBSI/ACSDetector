/** 
 * Deploys a table program on the cluster.
 * @param context        context with deployment information
 * @param jobName        job name of the Flink job to be submitted
 * @param jobGraph       Flink job graph
 * @param result         result that receives information about the target cluster
 * @param awaitJobResult block for a job execution result from the cluster
 */
public ProgramDeployer(ExecutionContext<C> context,String jobName,JobGraph jobGraph,Result<C> result,boolean awaitJobResult){
  this.context=context;
  this.jobGraph=jobGraph;
  this.jobName=jobName;
  this.result=result;
  this.awaitJobResult=awaitJobResult;
  executionResultBucket=new LinkedBlockingDeque<>(1);
}
