/** 
 * Intermediate step of a CoGroup transformation. <br/> To continue the CoGroup transformation, provide a  {@link org.apache.flink.api.common.functions.RichCoGroupFunction} by calling{@link org.apache.flink.api.java.operators.CoGroupOperator.CoGroupOperatorSets.CoGroupOperatorSetsPredicate.CoGroupOperatorWithoutFunction#with(org.apache.flink.api.common.functions.CoGroupFunction)}.
 */
private CoGroupOperatorWithoutFunction createCoGroupOperator(Keys<I2> keys2){
  if (keys2 == null) {
    throw new NullPointerException();
  }
  if (keys2.isEmpty()) {
    throw new InvalidProgramException("The co-group keys must not be empty.");
  }
  try {
    keys1.areCompatible(keys2);
  }
 catch (  IncompatibleKeysException ike) {
    throw new InvalidProgramException("The pair of co-group keys are not compatible with each other.",ike);
  }
  return new CoGroupOperatorWithoutFunction(keys2);
}
