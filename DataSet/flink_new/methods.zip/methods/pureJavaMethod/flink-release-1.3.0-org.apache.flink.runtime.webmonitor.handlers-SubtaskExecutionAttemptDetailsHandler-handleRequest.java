@Override public String handleRequest(AccessExecution execAttempt,Map<String,String> params) throws Exception {
  return createAttemptDetailsJson(execAttempt,params.get("jobid"),params.get("vertexid"),fetcher);
}
