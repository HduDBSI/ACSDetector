/** 
 * De-serializes metrics from the given byte array and returns them as a list of  {@link MetricDump}.
 * @param data serialized metrics
 * @return A list containing the deserialized metrics.
 */
public List<MetricDump> deserialize(MetricDumpSerialization.MetricSerializationResult data){
  DataInputView in=new DataInputDeserializer(data.serializedMetrics,0,data.serializedMetrics.length);
  List<MetricDump> metrics=new ArrayList<>(data.numCounters + data.numGauges + data.numHistograms+ data.numMeters);
  for (int x=0; x < data.numCounters; x++) {
    try {
      metrics.add(deserializeCounter(in));
    }
 catch (    Exception e) {
      LOG.debug("Failed to deserialize counter.",e);
    }
  }
  for (int x=0; x < data.numGauges; x++) {
    try {
      metrics.add(deserializeGauge(in));
    }
 catch (    Exception e) {
      LOG.debug("Failed to deserialize gauge.",e);
    }
  }
  for (int x=0; x < data.numHistograms; x++) {
    try {
      metrics.add(deserializeHistogram(in));
    }
 catch (    Exception e) {
      LOG.debug("Failed to deserialize histogram.",e);
    }
  }
  for (int x=0; x < data.numMeters; x++) {
    try {
      metrics.add(deserializeMeter(in));
    }
 catch (    Exception e) {
      LOG.debug("Failed to deserialize meter.",e);
    }
  }
  return metrics;
}
