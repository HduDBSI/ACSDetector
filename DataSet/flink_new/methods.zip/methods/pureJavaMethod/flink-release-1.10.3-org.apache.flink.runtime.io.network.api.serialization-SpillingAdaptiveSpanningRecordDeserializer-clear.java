public void clear(){
  this.buffer=initialBuffer;
  this.serializationReadBuffer.releaseArrays();
  this.recordLength=-1;
  this.lengthBuffer.clear();
  this.leftOverData=null;
  this.accumulatedRecordBytes=0;
  if (spillingChannel != null) {
    try {
      spillingChannel.close();
    }
 catch (    Throwable t) {
    }
    spillingChannel=null;
  }
  if (spillFileReader != null) {
    try {
      spillFileReader.close();
    }
 catch (    Throwable t) {
    }
    spillFileReader=null;
  }
  if (spillFile != null) {
    spillFile.delete();
    spillFile=null;
  }
}
