/** 
 * Creates  {@link InputFormat}s from a given class for the specified file(s). The optional  {@link Configuration}initializes the formats.
 * @param < T > the class of the InputFormat
 * @param inputFormatClass the class of the InputFormat
 * @param path the path of the file or to the directory containing the splits
 * @param configuration optional configuration of the InputFormat
 * @return the created {@link InputFormat}s for each file in the specified path
 * @throws IOException if an I/O error occurred while accessing the files or initializing the InputFormat.
 */
@SuppressWarnings("unchecked") public static <T,F extends FileInputFormat<T>>List<F> openAllInputs(Class<F> inputFormatClass,String path,Configuration configuration) throws IOException {
  Path nephelePath=new Path(path);
  FileSystem fs=nephelePath.getFileSystem();
  FileStatus fileStatus=fs.getFileStatus(nephelePath);
  if (!fileStatus.isDir()) {
    return Arrays.asList(openInput(inputFormatClass,path,configuration));
  }
  FileStatus[] list=fs.listStatus(nephelePath);
  List<F> formats=new ArrayList<F>();
  for (int index=0; index < list.length; index++) {
    formats.add(openInput(inputFormatClass,list[index].getPath().toString(),configuration));
  }
  return formats;
}
