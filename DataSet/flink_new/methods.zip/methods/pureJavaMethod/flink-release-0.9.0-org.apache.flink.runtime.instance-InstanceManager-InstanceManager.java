/** 
 * Creates an new instance manager.
 */
public InstanceManager(){
  this.registeredHostsById=new HashMap<InstanceID,Instance>();
  this.registeredHostsByConnection=new HashMap<ActorRef,Instance>();
  this.deadHosts=new HashSet<ActorRef>();
}
