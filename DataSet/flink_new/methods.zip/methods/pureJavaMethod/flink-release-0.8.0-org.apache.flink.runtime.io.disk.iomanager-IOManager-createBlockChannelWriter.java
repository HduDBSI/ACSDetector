/** 
 * Creates a block channel writer that writes to the given channel. The writer calls the given callback after the I/O operation has been performed (successfully or unsuccessfully), to allow for asynchronous implementations.
 * @param channelID The descriptor for the channel to write to.
 * @param callback The callback to be called for 
 * @return A block channel writer that writes to the given channel.
 * @throws IOException Thrown, if the channel for the writer could not be opened.
 */
public abstract BlockChannelWriterWithCallback createBlockChannelWriter(FileIOChannel.ID channelID,RequestDoneCallback callback) throws IOException ;
