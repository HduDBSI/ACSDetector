@Nonnull @Override public RunnableFuture<SnapshotResult<OperatorStateHandle>> snapshot(long checkpointId,long timestamp,@Nonnull CheckpointStreamFactory streamFactory,@Nonnull CheckpointOptions checkpointOptions) throws Exception {
  return snapshotStrategyRunner.snapshot(checkpointId,timestamp,streamFactory,checkpointOptions);
}
