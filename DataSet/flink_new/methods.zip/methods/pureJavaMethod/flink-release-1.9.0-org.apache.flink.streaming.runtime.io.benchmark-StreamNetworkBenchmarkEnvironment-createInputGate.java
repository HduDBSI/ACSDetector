private InputGate createInputGate(TaskManagerLocation senderLocation) throws Exception {
  InputGate[] gates=new InputGate[channels];
  for (int channel=0; channel < channels; ++channel) {
    final InputGateDeploymentDescriptor gateDescriptor=createInputGateDeploymentDescriptor(senderLocation,channel,location);
    final InputGate gate=createInputGateWithMetrics(gateFactory,gateDescriptor,channel);
    gate.setup();
    gates[channel]=gate;
  }
  if (channels > 1) {
    return new UnionInputGate(gates);
  }
 else {
    return gates[0];
  }
}
