/** 
 * Triggers a savepoint for the job identified by the job id. The savepoint will be written to the given savepoint directory, or  {@link org.apache.flink.configuration.CheckpointingOptions#SAVEPOINT_DIRECTORY} if it is null.
 * @param jobId job id
 * @param savepointDirectory directory the savepoint should be written to
 * @return path future where the savepoint is located
 * @throws FlinkException if no connection to the cluster could be established
 */
public abstract CompletableFuture<String> triggerSavepoint(JobID jobId,@Nullable String savepointDirectory) throws FlinkException ;
