void checkAvroInitialized(){
  if (datumReader != null) {
    return;
  }
  ClassLoader cl=Thread.currentThread().getContextClassLoader();
  if (SpecificRecord.class.isAssignableFrom(recordClazz)) {
    SpecificData specificData=new SpecificData(cl);
    this.datumReader=new SpecificDatumReader<>(specificData);
    this.reader=specificData.getSchema(recordClazz);
  }
 else {
    this.reader=new Schema.Parser().parse(schemaString);
    GenericData genericData=new GenericData(cl);
    this.datumReader=new GenericDatumReader<>(null,this.reader,genericData);
  }
  this.inputStream=new MutableByteArrayInputStream();
  this.decoder=DecoderFactory.get().binaryDecoder(inputStream,null);
}
