/** 
 * Tests that the ZooKeeperHaServices cleans up paths for job manager. 
 */
@Test public void testCleanupJobData() throws Exception {
  String rootPath="/foo/bar/flink";
  final Configuration configuration=createConfiguration(rootPath);
  final String namespace=configuration.get(HighAvailabilityOptions.HA_CLUSTER_ID);
  JobID jobID=new JobID();
  final String path=rootPath + namespace + ZooKeeperUtils.getJobsPath();
  final TestingBlobStoreService blobStoreService=new TestingBlobStoreService();
  runCleanupTestWithJob(configuration,blobStoreService,jobID,haServices -> {
    final List<String> childrenBefore=client.getChildren().forPath(path);
    haServices.cleanupJobData(jobID);
    final List<String> childrenAfter=client.getChildren().forPath(path);
    assertThat(childrenBefore,hasItem(jobID.toString()));
    assertThat(childrenAfter,not(hasItem(jobID.toString())));
  }
);
}
