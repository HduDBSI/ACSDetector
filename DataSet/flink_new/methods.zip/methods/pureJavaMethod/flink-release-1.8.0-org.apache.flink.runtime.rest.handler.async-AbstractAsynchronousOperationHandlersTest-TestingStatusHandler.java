protected TestingStatusHandler(GatewayRetriever<? extends RestfulGateway> leaderRetriever,Time timeout,Map<String,String> responseHeaders,MessageHeaders<EmptyRequestBody,AsynchronousOperationResult<OperationResult>,TriggerMessageParameters> messageHeaders){
  super(leaderRetriever,timeout,responseHeaders,messageHeaders);
}
