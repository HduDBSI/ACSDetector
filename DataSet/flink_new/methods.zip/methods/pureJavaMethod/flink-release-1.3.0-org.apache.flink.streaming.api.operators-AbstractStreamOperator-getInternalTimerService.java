/** 
 * Returns a  {@link InternalTimerService} that can be used to query current processing timeand event time and to set timers. An operator can have several timer services, where each has its own namespace serializer. Timer services are differentiated by the string key that is given when requesting them, if you call this method with the same key multiple times you will get the same timer service instance in subsequent requests. <p>Timers are always scoped to a key, the currently active key of a keyed stream operation. When a timer fires, this key will also be set as the currently active key. <p>Each timer has attached metadata, the namespace. Different timer services can have a different namespace type. If you don't need namespace differentiation you can use  {@link VoidNamespaceSerializer} as the namespace serializer.
 * @param name The name of the requested timer service. If no service exists under the givenname a new one will be created and returned.
 * @param namespaceSerializer {@code TypeSerializer} for the timer namespace.
 * @param triggerable The {@link Triggerable} that should be invoked when timers fire
 * @param < N > The type of the timer namespace.
 */
public <K,N>InternalTimerService<N> getInternalTimerService(String name,TypeSerializer<N> namespaceSerializer,Triggerable<K,N> triggerable){
  checkTimerServiceInitialization();
  TypeSerializer<K> keySerializer=(TypeSerializer<K>)getKeyedStateBackend().getKeySerializer();
  InternalTimeServiceManager<K,N> keyedTimeServiceHandler=(InternalTimeServiceManager<K,N>)timeServiceManager;
  return keyedTimeServiceHandler.getInternalTimerService(name,keySerializer,namespaceSerializer,triggerable);
}
