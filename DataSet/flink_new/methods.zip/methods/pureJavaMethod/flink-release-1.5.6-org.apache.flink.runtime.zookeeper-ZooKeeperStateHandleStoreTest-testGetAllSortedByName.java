/** 
 * Tests that the state is returned sorted.
 */
@Test public void testGetAllSortedByName() throws Exception {
  LongStateStorage stateHandleProvider=new LongStateStorage();
  ZooKeeperStateHandleStore<Long> store=new ZooKeeperStateHandleStore<>(ZOOKEEPER.getClient(),stateHandleProvider);
  final String basePath="/testGetAllSortedByName";
  final Long[] expected=new Long[]{311222268470898L,132812888L,27255442L,11122233124L};
  for (  long val : expected) {
    final String pathInZooKeeper=String.format("%s%016d",basePath,val);
    store.addAndLock(pathInZooKeeper,val);
  }
  List<Tuple2<RetrievableStateHandle<Long>,String>> actual=store.getAllSortedByNameAndLock();
  assertEquals(expected.length,actual.size());
  Arrays.sort(expected);
  for (int i=0; i < expected.length; i++) {
    assertEquals(expected[i],actual.get(i).f0.retrieveState());
  }
}
