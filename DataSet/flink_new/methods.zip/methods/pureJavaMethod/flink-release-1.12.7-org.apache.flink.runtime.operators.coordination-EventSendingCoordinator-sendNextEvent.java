private void sendNextEvent(){
  if (nextNumber > maxNumber) {
    return;
  }
  if (nextNumber == maxNumber) {
    subtaskGateway.sendEvent(new EndEvent());
  }
 else {
    subtaskGateway.sendEvent(new IntegerEvent(nextNumber));
  }
  nextNumber++;
}
