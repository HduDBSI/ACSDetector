public <I1,K>JoinOperatorBaseBuilder<OUT> withWrappedInput1(Operator<I1> input1,SelectorFunctionKeys<I1,?> rawKeys1){
  @SuppressWarnings("unchecked") SelectorFunctionKeys<I1,K> keys1=(SelectorFunctionKeys<I1,K>)rawKeys1;
  TypeInformation<Tuple2<K,I1>> typeInfoWithKey1=KeyFunctions.createTypeWithKey(keys1);
  Operator<Tuple2<K,I1>> keyMapper1=KeyFunctions.appendKeyExtractor(input1,keys1);
  return this.withInput1(keyMapper1,typeInfoWithKey1,rawKeys1);
}
