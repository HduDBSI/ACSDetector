@Test public void canStartTwoReportersWhenUsingPortRange() throws Exception {
  String portRange=portRangeProvider.next();
  ReporterSetup setup1=createReporterSetup("test1",portRange);
  ReporterSetup setup2=createReporterSetup("test2",portRange);
  setup1.getReporter().close();
  setup2.getReporter().close();
}
