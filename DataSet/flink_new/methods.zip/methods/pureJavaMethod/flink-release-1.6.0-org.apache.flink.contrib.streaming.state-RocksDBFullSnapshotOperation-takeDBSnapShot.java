/** 
 * 1) Create a snapshot object from RocksDB.
 */
public void takeDBSnapShot(){
  Preconditions.checkArgument(snapshot == null,"Only one ongoing snapshot allowed!");
  this.stateMetaInfoSnapshots=new ArrayList<>(stateBackend.kvStateInformation.size());
  this.copiedMeta=new ArrayList<>(stateBackend.kvStateInformation.size());
  for (  Tuple2<ColumnFamilyHandle,RegisteredStateMetaInfoBase> tuple2 : stateBackend.kvStateInformation.values()) {
    this.stateMetaInfoSnapshots.add(tuple2.f1.snapshot());
    this.copiedMeta.add(tuple2);
  }
  this.snapshot=stateBackend.db.getSnapshot();
}
