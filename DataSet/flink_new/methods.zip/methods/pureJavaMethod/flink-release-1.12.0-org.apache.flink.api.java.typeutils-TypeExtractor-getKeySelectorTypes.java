@PublicEvolving public static <IN,OUT>TypeInformation<OUT> getKeySelectorTypes(KeySelector<IN,OUT> selectorInterface,TypeInformation<IN> inType,String functionName,boolean allowMissing){
  return getUnaryOperatorReturnType(selectorInterface,KeySelector.class,0,1,NO_INDEX,inType,functionName,allowMissing);
}
