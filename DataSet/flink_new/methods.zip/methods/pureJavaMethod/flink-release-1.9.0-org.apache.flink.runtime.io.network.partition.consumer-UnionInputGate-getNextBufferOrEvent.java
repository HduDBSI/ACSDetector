private Optional<BufferOrEvent> getNextBufferOrEvent(boolean blocking) throws IOException, InterruptedException {
  if (inputGatesWithRemainingData.isEmpty()) {
    return Optional.empty();
  }
  Optional<InputWithData<InputGate,BufferOrEvent>> next=waitAndGetNextData(blocking);
  if (!next.isPresent()) {
    return Optional.empty();
  }
  InputWithData<InputGate,BufferOrEvent> inputWithData=next.get();
  handleEndOfPartitionEvent(inputWithData.data,inputWithData.input);
  return Optional.of(adjustForUnionInputGate(inputWithData.data,inputWithData.input,inputWithData.moreAvailable));
}
