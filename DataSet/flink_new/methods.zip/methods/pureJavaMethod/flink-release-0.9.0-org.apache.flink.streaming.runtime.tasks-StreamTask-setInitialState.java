@Override public void setInitialState(StateHandle<Serializable> stateHandle) throws Exception {
  Serializable state=stateHandle.getState();
  if (hasChainedOperators) {
    @SuppressWarnings("unchecked") List<Serializable> chainedStates=(List<Serializable>)state;
    Serializable headState=chainedStates.get(0);
    if (headState != null) {
      if (streamOperator instanceof StatefulStreamOperator) {
        ((StatefulStreamOperator)streamOperator).restoreInitialState(headState);
      }
    }
    for (int i=1; i < chainedStates.size(); i++) {
      Serializable chainedState=chainedStates.get(i);
      if (chainedState != null) {
        StreamOperator chainedOperator=outputHandler.getChainedOperators().get(i - 1);
        if (chainedOperator instanceof StatefulStreamOperator) {
          ((StatefulStreamOperator)chainedOperator).restoreInitialState(chainedState);
        }
      }
    }
  }
 else {
    if (streamOperator instanceof StatefulStreamOperator) {
      ((StatefulStreamOperator)streamOperator).restoreInitialState(state);
    }
  }
}
