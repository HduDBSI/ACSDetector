@Test public void testForwardWithPojoPublicAttrAccess(){
  compareAnalyzerResultWithAnnotationsSingleInput(MapFunction.class,Map5.class,TypeInformation.of(new TypeHint<MyPojo>(){
  }
),Types.STRING);
}
