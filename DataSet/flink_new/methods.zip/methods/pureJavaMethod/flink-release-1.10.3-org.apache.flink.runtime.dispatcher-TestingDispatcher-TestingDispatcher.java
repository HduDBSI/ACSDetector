TestingDispatcher(RpcService rpcService,String endpointId,DispatcherId fencingToken,Collection<JobGraph> recoveredJobs,DispatcherServices dispatcherServices) throws Exception {
  super(rpcService,endpointId,fencingToken,recoveredJobs,dispatcherServices);
  this.startFuture=new CompletableFuture<>();
}
