/** 
 * Returns the logical scope of this group, for example {@code "taskmanager.job.task"}.
 * @param filter character filter which is applied to the scope components
 * @param delimiter delimiter to use for concatenating scope components
 * @param reporterIndex index of the reporter
 * @return logical scope
 */
String getLogicalScope(CharacterFilter filter,char delimiter,int reporterIndex){
  if (logicalScopeStrings.length == 0 || (reporterIndex < 0 || reporterIndex >= logicalScopeStrings.length)) {
    return createLogicalScope(filter,delimiter);
  }
 else {
    if (logicalScopeStrings[reporterIndex] == null) {
      logicalScopeStrings[reporterIndex]=createLogicalScope(filter,delimiter);
    }
    return logicalScopeStrings[reporterIndex];
  }
}
