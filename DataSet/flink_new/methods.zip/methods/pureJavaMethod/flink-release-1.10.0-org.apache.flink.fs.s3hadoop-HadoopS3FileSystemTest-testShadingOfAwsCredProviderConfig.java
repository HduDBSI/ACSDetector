@Test public void testShadingOfAwsCredProviderConfig(){
  final Configuration conf=new Configuration();
  conf.setString("fs.s3a.aws.credentials.provider","com.amazonaws.auth.ContainerCredentialsProvider");
  HadoopConfigLoader configLoader=S3FileSystemFactory.createHadoopConfigLoader();
  configLoader.setFlinkConfig(conf);
  org.apache.hadoop.conf.Configuration hadoopConfig=configLoader.getOrLoadHadoopConfig();
  assertEquals("com.amazonaws.auth.ContainerCredentialsProvider",hadoopConfig.get("fs.s3a.aws.credentials.provider"));
}
