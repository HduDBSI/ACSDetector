public void registerTask(Task task) throws IOException {
  final ResultPartition[] producedPartitions=task.getProducedPartitions();
synchronized (lock) {
    if (isShutdown) {
      throw new IllegalStateException("NetworkEnvironment is shut down");
    }
    for (    final ResultPartition partition : producedPartitions) {
      setupPartition(partition);
    }
    final SingleInputGate[] inputGates=task.getAllInputGates();
    for (    SingleInputGate gate : inputGates) {
      setupInputGate(gate);
    }
  }
}
