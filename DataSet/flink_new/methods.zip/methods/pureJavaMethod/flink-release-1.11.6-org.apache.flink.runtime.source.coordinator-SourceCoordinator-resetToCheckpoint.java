@Override public void resetToCheckpoint(final long checkpointId,@Nullable final byte[] checkpointData) throws Exception {
  checkState(!started,"The coordinator can only be reset if it was not yet started");
  assert enumerator == null;
  if (checkpointData == null) {
    return;
  }
  LOG.info("Restoring SplitEnumerator of source {} from checkpoint.",operatorName);
  final ClassLoader userCodeClassLoader=context.getCoordinatorContext().getUserCodeClassloader();
  try (TemporaryClassLoaderContext ignored=TemporaryClassLoaderContext.of(userCodeClassLoader)){
    final EnumChkT enumeratorCheckpoint=deserializeCheckpointAndRestoreContext(checkpointData);
    enumerator=source.restoreEnumerator(context,enumeratorCheckpoint);
  }
 }
