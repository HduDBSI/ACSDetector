public void completePendingRequest(final ExecutionVertexID executionVertexId){
  final SlotExecutionVertexAssignment slotVertexAssignment=removePendingRequest(executionVertexId);
  checkState(slotVertexAssignment != null);
  slotVertexAssignment.getLogicalSlotFuture().complete(logicalSlotBuilder.setSlotOwner(this).createTestingLogicalSlot());
}
