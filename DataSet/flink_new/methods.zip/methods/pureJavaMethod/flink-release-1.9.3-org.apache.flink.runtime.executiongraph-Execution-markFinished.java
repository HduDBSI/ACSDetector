void markFinished(Map<String,Accumulator<?,?>> userAccumulators,IOMetrics metrics){
  assertRunningInJobMasterMainThread();
  while (true) {
    ExecutionState current=this.state;
    if (current == RUNNING || current == DEPLOYING) {
      if (transitionState(current,FINISHED)) {
        try {
          finishPartitionsAndScheduleOrUpdateConsumers();
          updateAccumulatorsAndMetrics(userAccumulators,metrics);
          releaseAssignedResource(null);
          vertex.getExecutionGraph().deregisterExecution(this);
        }
  finally {
          vertex.executionFinished(this);
        }
        return;
      }
    }
 else     if (current == CANCELING) {
      completeCancelling(userAccumulators,metrics,true);
      return;
    }
 else     if (current == CANCELED || current == FAILED) {
      if (LOG.isDebugEnabled()) {
        LOG.debug("Task FINISHED, but concurrently went to state " + state);
      }
      return;
    }
 else {
      markFailed(new Exception("Vertex received FINISHED message while being in state " + state));
      return;
    }
  }
}
