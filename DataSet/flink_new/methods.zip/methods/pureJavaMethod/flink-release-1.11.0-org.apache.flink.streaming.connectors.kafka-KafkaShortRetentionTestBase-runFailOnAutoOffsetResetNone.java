/** 
 * Ensure that the consumer is properly failing if "auto.offset.reset" is set to "none".
 */
public void runFailOnAutoOffsetResetNone() throws Exception {
  final String topic="auto-offset-reset-none-test";
  final int parallelism=1;
  kafkaServer.createTestTopic(topic,parallelism,1);
  final StreamExecutionEnvironment env=StreamExecutionEnvironment.getExecutionEnvironment();
  env.setParallelism(parallelism);
  env.setRestartStrategy(RestartStrategies.noRestart());
  Properties customProps=new Properties();
  customProps.putAll(standardProps);
  customProps.putAll(secureProps);
  customProps.setProperty("auto.offset.reset","none");
  FlinkKafkaConsumerBase<String> source=kafkaServer.getConsumer(topic,new SimpleStringSchema(),customProps);
  DataStreamSource<String> consuming=env.addSource(source);
  consuming.addSink(new DiscardingSink<String>());
  try {
    env.execute("Test auto offset reset none");
  }
 catch (  Throwable e) {
    if (!e.getCause().getCause().getMessage().contains("Undefined offset with no reset policy for partition")) {
      throw e;
    }
  }
  kafkaServer.deleteTestTopic(topic);
}
