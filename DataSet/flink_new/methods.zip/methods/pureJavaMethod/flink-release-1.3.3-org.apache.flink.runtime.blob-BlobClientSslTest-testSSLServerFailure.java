/** 
 * Verify non-ssl client to ssl server failure
 */
@Test public void testSSLServerFailure() throws Exception {
  try {
    uploadJarFile(BLOB_SSL_SERVER,clientConfig);
    fail("Non-SSL client connected to ssl server");
  }
 catch (  Exception e) {
  }
}
