/** 
 * {@inheritDoc}
 */
@Override public void run(){
  try {
    instance.checkLibraryAvailability(jobID);
  }
 catch (  IOException ioe) {
    LOG.error("Cannot check library availability: " + StringUtils.stringifyException(ioe));
  }
  final List<TaskDeploymentDescriptor> submissionList=new SerializableArrayList<TaskDeploymentDescriptor>();
  for (  final ExecutionVertex vertex : verticesToBeDeployed) {
    submissionList.add(vertex.constructDeploymentDescriptor());
    LOG.info("Starting task " + vertex + " on "+ vertex.getAllocatedResource().getInstance());
  }
  List<TaskSubmissionResult> submissionResultList=null;
  try {
    submissionResultList=instance.submitTasks(submissionList);
  }
 catch (  final IOException ioe) {
    final String errorMsg=StringUtils.stringifyException(ioe);
    for (    final ExecutionVertex vertex : verticesToBeDeployed) {
      vertex.updateExecutionStateAsynchronously(ExecutionState.FAILED,errorMsg);
    }
  }
  if (verticesToBeDeployed.size() != submissionResultList.size()) {
    LOG.error("size of submission result list does not match size of list with vertices to be deployed");
  }
  int count=0;
  for (  final TaskSubmissionResult tsr : submissionResultList) {
    ExecutionVertex vertex=verticesToBeDeployed.get(count++);
    if (!vertex.getID().equals(tsr.getVertexID())) {
      LOG.error("Expected different order of objects in task result list");
      vertex=null;
      for (      final ExecutionVertex candVertex : verticesToBeDeployed) {
        if (tsr.getVertexID().equals(candVertex.getID())) {
          vertex=candVertex;
          break;
        }
      }
      if (vertex == null) {
        LOG.error("Cannot find execution vertex for vertex ID " + tsr.getVertexID());
        continue;
      }
    }
    if (tsr.getReturnCode() != AbstractTaskResult.ReturnCode.SUCCESS) {
      vertex.updateExecutionStateAsynchronously(ExecutionState.FAILED,tsr.getDescription());
    }
  }
}
