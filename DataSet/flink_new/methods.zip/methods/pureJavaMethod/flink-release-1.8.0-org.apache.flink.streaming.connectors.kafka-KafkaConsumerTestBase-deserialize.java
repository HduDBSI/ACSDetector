@Override public Tuple3<Integer,Integer,String> deserialize(ConsumerRecord<byte[],byte[]> record) throws Exception {
  DataInputView in=new DataInputViewStreamWrapper(new ByteArrayInputStream(record.value()));
  Tuple2<Integer,Integer> t2=ts.deserialize(in);
  return new Tuple3<>(t2.f0,t2.f1,record.topic());
}
