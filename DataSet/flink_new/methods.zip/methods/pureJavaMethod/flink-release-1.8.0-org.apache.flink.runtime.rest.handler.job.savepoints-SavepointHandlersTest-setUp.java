@Before public void setUp() throws Exception {
  leaderRetriever=() -> CompletableFuture.completedFuture(null);
  final SavepointHandlers savepointHandlers=new SavepointHandlers(null);
  savepointTriggerHandler=savepointHandlers.new SavepointTriggerHandler(leaderRetriever,TIMEOUT,Collections.emptyMap());
  savepointStatusHandler=savepointHandlers.new SavepointStatusHandler(leaderRetriever,TIMEOUT,Collections.emptyMap());
}
