public Factory(GeneratedRecordComparator genSortKeyComparator,RowDataKeySelector sortKeySelector,TypeSerializer<RowData> keySerializer,TypeSerializer<RowData> recordSerializer,long topN){
  this.generatedSortKeyComparator=genSortKeyComparator;
  this.sortKeySelector=sortKeySelector;
  this.keySerializer=keySerializer;
  this.recordSerializer=recordSerializer;
  this.topN=topN;
}
