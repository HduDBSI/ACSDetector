@Test public void testReadFinishedInput() throws Exception {
  try {
    testBase(new TestReadFinishedInputStreamOperator(),false,new ConcurrentLinkedQueue<>(),true);
    fail("should throw an IOException");
  }
 catch (  Exception t) {
    if (!ExceptionUtils.findThrowableWithMessage(t,"only first input is selected but it is already finished").isPresent()) {
      throw t;
    }
  }
}
