/** 
 * Advanced the watermark and processes any timers that fire because of this. The window and  {@link TriggerResult} for each firing are returned.
 */
public Collection<Tuple2<W,TriggerResult>> advanceWatermark(long time) throws Exception {
  Collection<TestInternalTimerService.Timer<Integer,W>> firedTimers=internalTimerService.advanceWatermark(time);
  Collection<Tuple2<W,TriggerResult>> result=new ArrayList<>();
  for (  TestInternalTimerService.Timer<Integer,W> timer : firedTimers) {
    TriggerResult triggerResult=invokeOnEventTime(timer);
    result.add(new Tuple2<>(timer.getNamespace(),triggerResult));
  }
  return result;
}
