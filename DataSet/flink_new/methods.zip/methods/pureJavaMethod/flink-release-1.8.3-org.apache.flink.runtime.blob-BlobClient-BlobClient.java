/** 
 * Instantiates a new BLOB client.
 * @param serverAddress the network address of the BLOB server
 * @param clientConfig additional configuration like SSL parameters required to connect to the blob server
 * @throws IOException thrown if the connection to the BLOB server could not be established
 */
public BlobClient(InetSocketAddress serverAddress,Configuration clientConfig) throws IOException {
  Socket socket=null;
  try {
    if (SSLUtils.isInternalSSLEnabled(clientConfig) && clientConfig.getBoolean(BlobServerOptions.SSL_ENABLED)) {
      LOG.info("Using ssl connection to the blob server");
      socket=SSLUtils.createSSLClientSocketFactory(clientConfig).createSocket();
    }
 else {
      socket=new Socket();
    }
    socket.connect(serverAddress,clientConfig.getInteger(BlobServerOptions.CONNECT_TIMEOUT));
    socket.setSoTimeout(clientConfig.getInteger(BlobServerOptions.SO_TIMEOUT));
  }
 catch (  Exception e) {
    BlobUtils.closeSilently(socket,LOG);
    throw new IOException("Could not connect to BlobServer at address " + serverAddress,e);
  }
  this.socket=socket;
}
