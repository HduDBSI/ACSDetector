private void createDashboardConfigFile() throws IOException {
  try (FileWriter fw=createOrGetFile(webDir,"config")){
    fw.write(createConfigJson(DashboardConfiguration.from(webRefreshIntervalMillis,ZonedDateTime.now())));
    fw.flush();
  }
 catch (  IOException ioe) {
    LOG.error("Failed to write config file.");
    throw ioe;
  }
}
