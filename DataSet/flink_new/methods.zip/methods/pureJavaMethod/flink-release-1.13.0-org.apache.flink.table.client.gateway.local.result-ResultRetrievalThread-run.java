@Override public void run(){
  try {
    while (isRunning && result.hasNext()) {
      processRecord(result.next());
    }
  }
 catch (  RuntimeException e) {
    executionException.compareAndSet(null,new SqlExecutionException("Error while retrieving result.",e));
  }
  isRunning=false;
}
