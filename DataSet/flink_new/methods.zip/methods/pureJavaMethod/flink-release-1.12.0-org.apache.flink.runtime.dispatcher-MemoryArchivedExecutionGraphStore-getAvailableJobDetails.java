@Nullable @Override public JobDetails getAvailableJobDetails(JobID jobId){
  final ArchivedExecutionGraph archivedExecutionGraph=serializableExecutionGraphs.get(jobId);
  if (archivedExecutionGraph != null) {
    return JobDetails.createDetailsForJob(archivedExecutionGraph);
  }
 else {
    return null;
  }
}
