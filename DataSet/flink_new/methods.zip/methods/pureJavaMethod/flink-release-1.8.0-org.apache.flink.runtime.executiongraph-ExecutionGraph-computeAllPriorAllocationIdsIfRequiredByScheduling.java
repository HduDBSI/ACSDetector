/** 
 * Returns the result of  {@link #computeAllPriorAllocationIds()}, but only if the scheduling really requires it. Otherwise this method simply returns an empty set.
 */
private Set<AllocationID> computeAllPriorAllocationIdsIfRequiredByScheduling(){
  if (slotProvider instanceof Scheduler && ((Scheduler)slotProvider).requiresPreviousExecutionGraphAllocations()) {
    return computeAllPriorAllocationIds();
  }
 else {
    return Collections.emptySet();
  }
}
