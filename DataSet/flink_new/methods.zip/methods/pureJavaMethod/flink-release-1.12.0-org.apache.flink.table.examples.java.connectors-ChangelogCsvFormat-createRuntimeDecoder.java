@Override public DeserializationSchema<RowData> createRuntimeDecoder(DynamicTableSource.Context context,DataType producedDataType){
  final TypeInformation<RowData> producedTypeInfo=context.createTypeInformation(producedDataType);
  final DataStructureConverter converter=context.createDataStructureConverter(producedDataType);
  final List<LogicalType> parsingTypes=producedDataType.getLogicalType().getChildren();
  return new ChangelogCsvDeserializer(parsingTypes,converter,producedTypeInfo,columnDelimiter);
}
