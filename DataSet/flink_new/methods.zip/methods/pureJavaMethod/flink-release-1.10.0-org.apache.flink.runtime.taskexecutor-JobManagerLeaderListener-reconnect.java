public void reconnect(){
  if (stopped) {
    LOG.debug("Cannot reconnect because the JobManagerLeaderListener has already been stopped.");
  }
 else {
    final RegisteredRpcConnection<JobMasterId,JobMasterGateway,JMTMRegistrationSuccess> currentRpcConnection=rpcConnection;
    if (currentRpcConnection != null) {
      if (currentRpcConnection.isConnected()) {
        if (currentRpcConnection.tryReconnect()) {
          if (stopped) {
            currentRpcConnection.close();
          }
        }
 else {
          LOG.debug("Could not reconnect to the JobMaster {}.",currentRpcConnection.getTargetAddress());
        }
      }
 else {
        LOG.debug("Ongoing registration to JobMaster {}.",currentRpcConnection.getTargetAddress());
      }
    }
 else {
      LOG.debug("Cannot reconnect to an unknown JobMaster.");
    }
  }
}
