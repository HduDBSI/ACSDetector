public void evictor(Evictor<? super T,? super W> evictor){
  Preconditions.checkNotNull(evictor,"Evictor cannot be null");
  this.evictor=evictor;
}
