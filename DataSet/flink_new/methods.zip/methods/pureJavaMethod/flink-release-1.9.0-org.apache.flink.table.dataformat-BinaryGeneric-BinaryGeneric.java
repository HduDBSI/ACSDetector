public BinaryGeneric(MemorySegment[] segments,int offset,int sizeInBytes,T javaObject,TypeSerializer<T> javaObjectSer){
  super(segments,offset,sizeInBytes,javaObject);
  this.javaObjectSer=javaObjectSer;
}
