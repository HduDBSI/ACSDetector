private void sendBackResults(List<byte[]> serializedResults) throws IOException {
  if (LOG.isDebugEnabled()) {
    LOG.debug("Sending back " + serializedResults.size() + " results");
  }
  CollectCoordinationResponse response=new CollectCoordinationResponse(version,lastCheckpointedOffset,serializedResults);
  response.serialize(outStream);
}
