@Override public boolean equals(Object o){
  if (this == o) {
    return true;
  }
  if (o == null || getClass() != o.getClass()) {
    return false;
  }
  SavepointRestoreSettings that=(SavepointRestoreSettings)o;
  return allowNonRestoredState == that.allowNonRestoredState && (Objects.equals(restorePath,that.restorePath));
}
