/** 
 * Constructs the dialects select statement for fields with given conditions. The returned string will be used as a  {@link java.sql.PreparedStatement}. Fields in the statement must be in the same order as the  {@code fieldNames} parameter.
 * @return A select statement.
 */
String getSelectFromStatement(String tableName,String[] selectFields,String[] conditionFields);
