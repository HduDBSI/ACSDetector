@SuppressWarnings("unchecked") @Override <US extends State,SV>StateDescriptor<US,SV> createStateDescriptor(){
  return (StateDescriptor<US,SV>)new MapStateDescriptor<>("TtlTestMapState",IntSerializer.INSTANCE,StringSerializer.INSTANCE);
}
