@Override public CompletableFuture<JobStatus> requestJobStatus(JobID jobId,Time timeout){
  Optional<DispatcherJob> maybeJob=getDispatcherJob(jobId);
  return maybeJob.map(job -> job.requestJobStatus(timeout)).orElseGet(() -> {
    final JobDetails jobDetails=archivedExecutionGraphStore.getAvailableJobDetails(jobId);
    if (jobDetails == null) {
      return FutureUtils.completedExceptionally(new FlinkJobNotFoundException(jobId));
    }
 else {
      return CompletableFuture.completedFuture(jobDetails.getStatus());
    }
  }
);
}
