/** 
 * Computes the logarithm of the given value to the base of 2. This method throws an error, if the given argument is not a power of 2.
 * @param value The value to compute the logarithm for.
 * @return The logarithm to the base of 2.
 * @throws ArithmeticException Thrown, if the given value is zero.
 * @throws IllegalArgumentException Thrown, if the given value is not a power of two.
 */
public static final int log2strict(int value) throws ArithmeticException, IllegalArgumentException {
  if (value == 0) {
    throw new ArithmeticException("Logarithm of zero is undefined.");
  }
  if ((value & (value - 1)) != 0) {
    throw new IllegalArgumentException("The given value " + value + " is not a power of two.");
  }
  int log=0;
  while ((value=value >>> 1) != 0) {
    log++;
  }
  return log;
}
