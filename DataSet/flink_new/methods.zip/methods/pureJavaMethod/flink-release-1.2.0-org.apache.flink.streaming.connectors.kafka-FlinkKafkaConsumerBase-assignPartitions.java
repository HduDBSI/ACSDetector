/** 
 * Selects which of the given partitions should be handled by a specific consumer, given a certain number of consumers.
 * @param allPartitions The partitions to select from
 * @param numConsumers The number of consumers
 * @param consumerIndex The index of the specific consumer
 * @return The sublist of partitions to be handled by that consumer.
 */
protected static List<KafkaTopicPartition> assignPartitions(List<KafkaTopicPartition> allPartitions,int numConsumers,int consumerIndex){
  final List<KafkaTopicPartition> thisSubtaskPartitions=new ArrayList<>(allPartitions.size() / numConsumers + 1);
  for (int i=0; i < allPartitions.size(); i++) {
    if (i % numConsumers == consumerIndex) {
      thisSubtaskPartitions.add(allPartitions.get(i));
    }
  }
  return thisSubtaskPartitions;
}
