@Test public void testLeaderConfigMapModifiedExternallyShouldBeCorrected() throws Exception {
  new Context(){
{
      runTest(() -> {
        leaderCallbackGrantLeadership();
        final FlinkKubeClient.WatchCallbackHandler<KubernetesConfigMap> callbackHandler=getLeaderElectionConfigMapCallback();
        final KubernetesConfigMap updatedConfigMap=getLeaderConfigMap();
        final UUID leaderSessionId=UUID.fromString(updatedConfigMap.getData().get(LEADER_SESSION_ID_KEY));
        final LeaderInformation faultyLeader=LeaderInformation.known(UUID.randomUUID(),"faultyLeaderAddress");
        updatedConfigMap.getData().put(LEADER_ADDRESS_KEY,faultyLeader.getLeaderAddress());
        updatedConfigMap.getData().put(LEADER_SESSION_ID_KEY,faultyLeader.getLeaderSessionID().toString());
        callbackHandler.onModified(Collections.singletonList(updatedConfigMap));
        assertThat(getLeaderConfigMap().getData().get(LEADER_ADDRESS_KEY),is(LEADER_ADDRESS));
        assertThat(getLeaderConfigMap().getData().get(LEADER_SESSION_ID_KEY),is(leaderSessionId.toString()));
      }
);
    }
  }
;
}
