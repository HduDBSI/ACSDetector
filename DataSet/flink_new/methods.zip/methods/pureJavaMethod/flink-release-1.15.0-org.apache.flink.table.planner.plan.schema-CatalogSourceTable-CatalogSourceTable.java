public CatalogSourceTable(RelOptSchema relOptSchema,List<String> names,RelDataType rowType,CatalogSchemaTable schemaTable){
  super(relOptSchema,rowType,names,schemaTable.getStatistic());
  this.schemaTable=schemaTable;
}
