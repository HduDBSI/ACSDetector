@Override public CompletableFuture<LogicalSlot> allocateSlot(SlotRequestId slotRequestId,ScheduledUnit task,SlotProfile slotProfile,Time timeout){
  Preconditions.checkState(!slotFutures.containsKey(slotRequestId));
  final CompletableFuture<LogicalSlot> slotFuture=slotFutureCreator.apply(slotRequestId);
  slotFutures.put(slotRequestId,slotFuture);
  return slotFuture;
}
