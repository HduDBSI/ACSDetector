@Override protected CompletableFuture<TestResponse> handleRequest(@Nonnull HandlerRequest<TestRequest,TestParameters> request,RestfulGateway gateway) throws RestHandlerException {
  assertEquals(request.getPathParameter(JobIDPathParameter.class),PATH_JOB_ID);
  assertEquals(request.getQueryParameter(JobIDQueryParameter.class).get(0),QUERY_JOB_ID);
  final int id=request.getRequestBody().id;
  if (id == 1) {
synchronized (LOCK) {
      try {
        LOCK.notifyAll();
        LOCK.wait();
      }
 catch (      InterruptedException ignored) {
      }
    }
  }
 else   if (id == LARGE_RESPONSE_BODY_ID) {
    return CompletableFuture.completedFuture(new TestResponse(id,createStringOfSize(TEST_REST_MAX_CONTENT_LENGTH)));
  }
  return CompletableFuture.completedFuture(new TestResponse(id));
}
