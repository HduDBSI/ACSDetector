@Override protected void cleanUp(){
  stopRetrieval();
}
