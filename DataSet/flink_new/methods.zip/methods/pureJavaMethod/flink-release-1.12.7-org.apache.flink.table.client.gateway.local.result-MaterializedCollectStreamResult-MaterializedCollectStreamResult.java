public MaterializedCollectStreamResult(TableSchema tableSchema,ExecutionConfig config,InetAddress gatewayAddress,int gatewayPort,int maxRowCount){
  this(tableSchema,config,gatewayAddress,gatewayPort,maxRowCount,computeMaterializedTableOvercommit(maxRowCount));
}
