public <T>void addOutput(final Collection<Object> outputList,final TypeSerializer<T> serializer){
  try {
    outputs.add(new RecordOrEventCollectingResultPartitionWriter<T>(outputList,serializer));
  }
 catch (  Throwable t) {
    t.printStackTrace();
    fail(t.getMessage());
  }
}
