@Override public List<IntermediateResultPartitionID> vertexFinished(final ExecutionVertexID finishedVertex){
  final PipelinedRegionExecutionView regionExecutionView=getPipelinedRegionExecutionViewForVertex(finishedVertex);
  regionExecutionView.vertexFinished(finishedVertex);
  if (regionExecutionView.isFinished()) {
    final SchedulingPipelinedRegion pipelinedRegion=schedulingTopology.getPipelinedRegionOfVertex(finishedVertex);
    return filterReleasablePartitions(pipelinedRegion.getConsumedResults());
  }
  return Collections.emptyList();
}
