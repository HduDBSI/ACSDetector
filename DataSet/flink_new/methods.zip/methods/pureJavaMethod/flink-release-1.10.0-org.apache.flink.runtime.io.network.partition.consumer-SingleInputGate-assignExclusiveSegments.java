/** 
 * Assign the exclusive buffers to all remote input channels directly for credit-based mode.
 */
@VisibleForTesting public void assignExclusiveSegments() throws IOException {
synchronized (requestLock) {
    for (    InputChannel inputChannel : inputChannels.values()) {
      if (inputChannel instanceof RemoteInputChannel) {
        ((RemoteInputChannel)inputChannel).assignExclusiveSegments();
      }
    }
  }
}
