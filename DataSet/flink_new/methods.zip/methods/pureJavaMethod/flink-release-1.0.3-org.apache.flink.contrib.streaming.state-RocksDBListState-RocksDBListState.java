/** 
 * Creates a  {@code RocksDBListState} by restoring from a directory.
 * @param keySerializer The serializer for the keys.
 * @param namespaceSerializer The serializer for the namespace.
 * @param stateDesc The state identifier for the state. This contains nameand can create a default state value.
 * @param dbPath The path on the local system where RocksDB data should be stored.
 * @param backupPath The path where to store backups.
 * @param restorePath The path on the local file system that we are restoring from.
 */
protected RocksDBListState(TypeSerializer<K> keySerializer,TypeSerializer<N> namespaceSerializer,ListStateDescriptor<V> stateDesc,File dbPath,String backupPath,String restorePath,Options options){
  super(keySerializer,namespaceSerializer,dbPath,backupPath,restorePath,options);
  this.stateDesc=requireNonNull(stateDesc);
  this.valueSerializer=stateDesc.getSerializer();
  writeOptions=new WriteOptions();
  writeOptions.setDisableWAL(true);
}
