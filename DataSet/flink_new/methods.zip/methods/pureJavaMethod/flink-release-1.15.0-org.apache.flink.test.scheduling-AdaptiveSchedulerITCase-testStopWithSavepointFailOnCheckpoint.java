@Test public void testStopWithSavepointFailOnCheckpoint() throws Exception {
  StreamExecutionEnvironment env=getEnvWithSource(StopWithSavepointTestBehavior.FAIL_ON_CHECKPOINT);
  env.setRestartStrategy(RestartStrategies.fixedDelayRestart(Integer.MAX_VALUE,0L));
  DummySource.resetForParallelism(PARALLELISM);
  JobClient client=env.executeAsync();
  DummySource.awaitRunning();
  try {
    client.stopWithSavepoint(false,tempFolder.newFolder("savepoint").getAbsolutePath(),SavepointFormatType.CANONICAL).get();
    fail("Expect exception");
  }
 catch (  ExecutionException e) {
    assertThat(e,containsCause(FlinkException.class));
  }
  CommonTestUtils.waitUntilCondition(() -> client.getJobStatus().get() == JobStatus.RUNNING);
}
