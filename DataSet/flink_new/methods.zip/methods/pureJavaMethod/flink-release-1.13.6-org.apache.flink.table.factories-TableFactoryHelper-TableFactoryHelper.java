private TableFactoryHelper(DynamicTableFactory tableFactory,DynamicTableFactory.Context context){
  this.tableFactory=tableFactory;
  this.context=context;
  this.allOptions=Configuration.fromMap(context.getCatalogTable().getOptions());
  this.consumedOptionKeys=new HashSet<>();
  this.consumedOptionKeys.add(PROPERTY_VERSION.key());
  this.consumedOptionKeys.add(CONNECTOR.key());
  this.consumedOptionKeys.addAll(tableFactory.requiredOptions().stream().map(ConfigOption::key).collect(Collectors.toSet()));
  this.consumedOptionKeys.addAll(tableFactory.optionalOptions().stream().map(ConfigOption::key).collect(Collectors.toSet()));
}
