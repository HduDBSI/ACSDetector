private SelectCepOperator<Event,Integer,Map<String,List<Event>>> getKeyedCepOpearator(boolean isProcessingTime){
  return CepOperatorTestUtilities.getKeyedCepOpearator(isProcessingTime,new CEPOperatorTest.NFAFactory());
}
