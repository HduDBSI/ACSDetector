@Test public void testGenerateUnknownResourceProfile() throws Exception {
  SlotSharingGroup slotSharingGroup0=new SlotSharingGroup();
  slotSharingGroup0.setResourceProfile(ResourceProfile.UNKNOWN);
  SlotSharingGroup slotSharingGroup1=new SlotSharingGroup();
  slotSharingGroup1.setResourceProfile(ResourceProfile.UNKNOWN);
  createExecutionGraphAndEnrichNetworkMemory(Arrays.asList(slotSharingGroup0,slotSharingGroup0,slotSharingGroup1));
  assertEquals(ResourceProfile.UNKNOWN,slotSharingGroup0.getResourceProfile());
  assertEquals(ResourceProfile.UNKNOWN,slotSharingGroup1.getResourceProfile());
}
