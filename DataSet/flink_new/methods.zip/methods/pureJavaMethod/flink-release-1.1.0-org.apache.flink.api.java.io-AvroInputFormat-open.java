@Override public void open(FileInputSplit split) throws IOException {
  super.open(split);
  dataFileReader=initReader(split);
  dataFileReader.sync(split.getStart());
  lastSync=dataFileReader.previousSync();
}
