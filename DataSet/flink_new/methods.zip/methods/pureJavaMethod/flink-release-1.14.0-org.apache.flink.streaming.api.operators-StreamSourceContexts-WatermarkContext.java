/** 
 * Create a watermark context.
 * @param timeService the time service to schedule idleness detection tasks
 * @param checkpointLock the checkpoint lock
 * @param idleTimeout (-1 if idleness checking is disabled)
 */
public WatermarkContext(final ProcessingTimeService timeService,final Object checkpointLock,final long idleTimeout){
  this.timeService=Preconditions.checkNotNull(timeService,"Time Service cannot be null.");
  this.checkpointLock=Preconditions.checkNotNull(checkpointLock,"Checkpoint Lock cannot be null.");
  if (idleTimeout != -1) {
    Preconditions.checkArgument(idleTimeout >= 1,"The idle timeout cannot be smaller than 1 ms.");
  }
  this.idleTimeout=idleTimeout;
  scheduleNextIdleDetectionTask();
}
