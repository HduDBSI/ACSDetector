@Override public Graph<LongValue,NullValue,NullValue> generate(){
  return new CirculantGraph(env,vertexCount).addRange(1,vertexCount - 1).setParallelism(parallelism).generate();
}
