private File getTmpDir(){
  File tmpDir=new File(CommonTestUtils.getTempDir(),UUID.randomUUID().toString());
  assertTrue("could not create temp directory",tmpDir.mkdirs());
  return tmpDir;
}
