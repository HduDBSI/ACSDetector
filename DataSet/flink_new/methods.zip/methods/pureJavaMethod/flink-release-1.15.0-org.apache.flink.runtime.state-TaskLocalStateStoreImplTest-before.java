@Before public void before() throws Exception {
  jobID=new JobID();
  allocationID=new AllocationID();
  jobVertexID=new JobVertexID();
  subtaskIdx=0;
  this.temporaryFolder=new TemporaryFolder();
  this.temporaryFolder.create();
  this.allocationBaseDirs=new File[]{temporaryFolder.newFolder(),temporaryFolder.newFolder()};
  this.taskLocalStateStore=createTaskLocalStateStoreImpl(allocationBaseDirs,jobID,allocationID,jobVertexID,subtaskIdx);
}
