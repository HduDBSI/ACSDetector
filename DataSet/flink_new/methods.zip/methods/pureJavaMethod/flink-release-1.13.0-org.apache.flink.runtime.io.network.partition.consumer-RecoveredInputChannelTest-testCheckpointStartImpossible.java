@Test(expected=CheckpointException.class) public void testCheckpointStartImpossible() throws CheckpointException {
  buildChannel().checkpointStarted(new CheckpointBarrier(0L,0L,unaligned(getDefault())));
}
