private AllocatedSlot createSlot(final AllocationID allocationId,final TaskManagerLocation taskManagerLocation){
  return new AllocatedSlot(allocationId,taskManagerLocation,0,ResourceProfile.UNKNOWN,new SimpleAckingTaskManagerGateway());
}
