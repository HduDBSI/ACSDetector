@Override public void add(T value){
  byte[] key=getKeyBytes();
  ACC accumulator=getInternal(key);
  accumulator=accumulator == null ? aggFunction.createAccumulator() : accumulator;
  updateInternal(key,aggFunction.add(value,accumulator));
}
