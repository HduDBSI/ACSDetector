/** 
 * Returns an array of all  {@link JsonArchivist}s that are relevant for the history server. <p>This method is static to allow easier access from the  {@link MemoryArchivist}. Requiring a reference would imply that the WebRuntimeMonitor is always created before the archivist, which may not hold for all deployment modes. <p>Similarly, no handler implements the JsonArchivist interface itself but instead contains a separate implementing class; otherwise we would either instantiate several handlers even though their main functionality isn't required, or yet again require that the WebRuntimeMonitor is started before the archivist.
 * @return array of all JsonArchivists relevant for the history server
 */
public static JsonArchivist[] getJsonArchivists(){
  JsonArchivist[] archivists={};
  return archivists;
}
