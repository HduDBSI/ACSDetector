private EnvironmentInstance(){
  if (mergedEnv.getExecution().isStreamingExecution()) {
    streamExecEnv=createStreamExecutionEnvironment();
    execEnv=null;
    tableEnv=TableEnvironment.getTableEnvironment(streamExecEnv);
  }
 else   if (mergedEnv.getExecution().isBatchExecution()) {
    streamExecEnv=null;
    execEnv=createExecutionEnvironment();
    tableEnv=TableEnvironment.getTableEnvironment(execEnv);
  }
 else {
    throw new SqlExecutionException("Unsupported execution type specified.");
  }
  queryConfig=createQueryConfig();
  tableSources.forEach(tableEnv::registerTableSource);
  tableSinks.forEach(tableEnv::registerTableSink);
  registerFunctions();
  mergedEnv.getTables().forEach((name,entry) -> {
    if (entry instanceof ViewEntry) {
      final ViewEntry viewEntry=(ViewEntry)entry;
      registerView(viewEntry);
    }
 else     if (entry instanceof TemporalTableEntry) {
      final TemporalTableEntry temporalTableEntry=(TemporalTableEntry)entry;
      registerTemporalTable(temporalTableEntry);
    }
  }
);
}
