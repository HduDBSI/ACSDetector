@Override public void onContainersAllocated(List<Container> containers){
  runAsync(() -> {
    log.info("Received {} containers with {} pending container requests.",containers.size(),numPendingContainerRequests);
    final Collection<AMRMClient.ContainerRequest> pendingRequests=getPendingRequests();
    final Iterator<AMRMClient.ContainerRequest> pendingRequestsIterator=pendingRequests.iterator();
    final int numAcceptedContainers=Math.min(containers.size(),numPendingContainerRequests);
    final List<Container> requiredContainers=containers.subList(0,numAcceptedContainers);
    final List<Container> excessContainers=containers.subList(numAcceptedContainers,containers.size());
    for (int i=0; i < requiredContainers.size(); i++) {
      removeContainerRequest(pendingRequestsIterator.next());
    }
    excessContainers.forEach(this::returnExcessContainer);
    requiredContainers.forEach(this::startTaskExecutorInContainer);
    if (numPendingContainerRequests <= 0) {
      resourceManagerClient.setHeartbeatInterval(yarnHeartbeatIntervalMillis);
    }
  }
);
}
