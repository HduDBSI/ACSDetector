private Worker(Protos.TaskID taskID,WorkerResourceSpec workerResourceSpec,Option<Protos.SlaveID> slaveID,Option<String> hostname,WorkerState state){
  this.taskID=requireNonNull(taskID,"taskID");
  this.workerResourceSpec=requireNonNull(workerResourceSpec,"workerResourceSpec");
  this.slaveID=requireNonNull(slaveID,"slaveID");
  this.hostname=requireNonNull(hostname,"hostname");
  this.state=requireNonNull(state,"state");
}
