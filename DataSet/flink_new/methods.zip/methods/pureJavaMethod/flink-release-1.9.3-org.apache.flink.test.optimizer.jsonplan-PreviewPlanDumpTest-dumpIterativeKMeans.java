@Test public void dumpIterativeKMeans(){
  PreviewPlanEnvironment env=new PreviewPlanEnvironment();
  env.setAsContext();
  try {
    KMeans.main(new String[]{"--points ",IN_FILE,"--centroids ",IN_FILE,"--output ",OUT_FILE,"--iterations","123"});
  }
 catch (  OptimizerPlanEnvironment.ProgramAbortException pae) {
  }
catch (  Exception e) {
    e.printStackTrace();
    Assert.fail("KMeans failed with an exception");
  }
  dump(env.getPlan());
}
