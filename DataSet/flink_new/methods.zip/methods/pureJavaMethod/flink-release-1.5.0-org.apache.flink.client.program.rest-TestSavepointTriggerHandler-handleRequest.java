@Override protected CompletableFuture<TriggerResponse> handleRequest(@Nonnull HandlerRequest<SavepointTriggerRequestBody,SavepointTriggerMessageParameters> request,@Nonnull DispatcherGateway gateway) throws RestHandlerException {
  final String targetDirectory=request.getRequestBody().getTargetDirectory();
  if (Objects.equals(expectedTargetDirectories.next(),targetDirectory)) {
    return CompletableFuture.completedFuture(new TriggerResponse(testTriggerId));
  }
 else {
    return CompletableFuture.completedFuture(new TriggerResponse(new TriggerId()));
  }
}
