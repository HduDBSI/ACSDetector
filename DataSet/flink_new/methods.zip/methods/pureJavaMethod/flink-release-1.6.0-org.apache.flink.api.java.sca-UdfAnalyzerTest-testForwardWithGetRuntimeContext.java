@Test public void testForwardWithGetRuntimeContext(){
  compareAnalyzerResultWithAnnotationsSingleInput(MapFunction.class,Map41.class,TypeInformation.of(new TypeHint<MyPojo>(){
  }
),TypeInformation.of(new TypeHint<MyPojo>(){
  }
));
}
