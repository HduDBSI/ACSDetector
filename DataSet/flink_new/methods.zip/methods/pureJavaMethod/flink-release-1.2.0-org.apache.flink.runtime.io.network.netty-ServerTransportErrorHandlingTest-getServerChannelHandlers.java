@Override public ChannelHandler[] getServerChannelHandlers(){
  return new PartitionRequestProtocol(partitionManager,mock(TaskEventDispatcher.class),mock(NetworkBufferPool.class)).getServerChannelHandlers();
}
