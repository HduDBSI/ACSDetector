@Test public void testBlackHole(){
  Map<String,String> properties=new HashMap<>();
  properties.put("connector","blackhole");
  DynamicTableSink sink=createSink(properties);
  assertEquals("BlackHole",sink.asSummaryString());
}
