/** 
 * Register a  {@link org.apache.flink.runtime.taskexecutor.TaskExecutor} at the resource manager.
 * @param resourceManagerLeaderId  The fencing token for the ResourceManager leader
 * @param taskExecutorAddress     The address of the TaskExecutor that registers
 * @param resourceID              The resource ID of the TaskExecutor that registers
 * @param slotReport              The slot report containing free and allocated task slots
 * @param timeout                 The timeout for the response.
 * @return The future to the response by the ResourceManager.
 */
Future<RegistrationResponse> registerTaskExecutor(UUID resourceManagerLeaderId,String taskExecutorAddress,ResourceID resourceID,SlotReport slotReport,@RpcTimeout Time timeout);
