@Override protected CompletableFuture<EmptyResponseBody> handleRequest(@Nonnull HandlerRequest<TestRequestBody,EmptyMessageParameters> request,@Nonnull RestfulGateway gateway) throws RestHandlerException {
  MultipartUploadResource.this.fileUploadVerifier.accept(request,gateway);
  this.lastReceivedRequest=request.getRequestBody();
  return CompletableFuture.completedFuture(EmptyResponseBody.getInstance());
}
