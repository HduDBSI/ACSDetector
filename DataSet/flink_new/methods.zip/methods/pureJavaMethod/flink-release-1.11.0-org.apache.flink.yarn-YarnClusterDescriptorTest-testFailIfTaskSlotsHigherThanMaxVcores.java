@Test public void testFailIfTaskSlotsHigherThanMaxVcores() throws ClusterDeploymentException {
  final Configuration flinkConfiguration=new Configuration();
  YarnClusterDescriptor clusterDescriptor=createYarnClusterDescriptor(flinkConfiguration);
  clusterDescriptor.setLocalJarPath(new Path(flinkJar.getPath()));
  try {
    clusterDescriptor.deploySessionCluster(clusterSpecification);
    fail("The deploy call should have failed.");
  }
 catch (  ClusterDeploymentException e) {
    if (!(e.getCause() instanceof IllegalConfigurationException)) {
      throw e;
    }
  }
 finally {
    clusterDescriptor.close();
  }
}
