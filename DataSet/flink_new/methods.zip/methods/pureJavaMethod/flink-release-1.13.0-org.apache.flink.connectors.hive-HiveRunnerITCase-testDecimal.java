@Test public void testDecimal() throws Exception {
  TableEnvironment tableEnv=getTableEnvWithHiveCatalog();
  tableEnv.executeSql("create database db1");
  try {
    tableEnv.executeSql("create table db1.src1 (x decimal(10,2))");
    tableEnv.executeSql("create table db1.src2 (x decimal(10,2))");
    tableEnv.executeSql("create table db1.dest (x decimal(10,2))");
    hiveShell.execute("insert into table db1.src1 values (1.0),(2.12),(5.123),(5.456),(123456789.12)");
    tableEnv.executeSql("insert into db1.src2 values (1.0),(2.12),(5.123),(5.456),(123456789.12)").await();
    verifyHiveQueryResult("select * from db1.src2",hiveShell.executeQuery("select * from db1.src1"));
    tableEnv.executeSql("insert into db1.dest select * from db1.src1").await();
    verifyHiveQueryResult("select * from db1.dest",hiveShell.executeQuery("select * from db1.src1"));
  }
  finally {
    tableEnv.executeSql("drop database db1 cascade");
  }
}
