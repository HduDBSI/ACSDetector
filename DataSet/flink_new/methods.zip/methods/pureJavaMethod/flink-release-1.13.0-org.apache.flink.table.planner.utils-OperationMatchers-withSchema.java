/** 
 * Checks that the schema of  {@link CreateTableOperation} is equal to the given {@link Schema}.
 * @param schema TableSchema that the {@link CreateTableOperation} should have
 * @see #isCreateTableOperation(Matcher[])
 */
public static Matcher<CreateTableOperation> withSchema(Schema schema){
  return new FeatureMatcher<CreateTableOperation,Schema>(equalTo(schema),"schema of the derived table","schema"){
    @Override protected Schema featureValueOf(    CreateTableOperation actual){
      return actual.getCatalogTable().getUnresolvedSchema();
    }
  }
;
}
