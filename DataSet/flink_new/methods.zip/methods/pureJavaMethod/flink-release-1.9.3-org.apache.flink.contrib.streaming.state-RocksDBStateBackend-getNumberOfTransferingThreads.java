/** 
 * Gets the number of threads used to transfer files while snapshotting/restoring.
 */
public int getNumberOfTransferingThreads(){
  return numberOfTransferingThreads == UNDEFINED_NUMBER_OF_TRANSFERING_THREADS ? CHECKPOINT_TRANSFER_THREAD_NUM.defaultValue() : numberOfTransferingThreads;
}
