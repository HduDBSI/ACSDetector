@Override protected void deserializeBuffer(Buffer buffer) throws IOException {
  deserializer.setNextBuffer(buffer);
  RecordDeserializer.DeserializationResult result;
  do {
    result=deserializer.getNextRecord(record);
    if (result.isFullRecord()) {
      output.add(record.createCopy());
    }
  }
 while (!result.isBufferConsumed());
}
