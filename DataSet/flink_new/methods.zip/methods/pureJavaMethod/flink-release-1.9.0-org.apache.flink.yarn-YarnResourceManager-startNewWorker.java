@Override public Collection<ResourceProfile> startNewWorker(ResourceProfile resourceProfile){
  if (!slotsPerWorker.iterator().next().isMatching(resourceProfile)) {
    return Collections.emptyList();
  }
  requestYarnContainer();
  return slotsPerWorker;
}
