static void setAsContext(ContextEnvironmentFactory factory){
  initializeContextEnvironment(factory);
}
