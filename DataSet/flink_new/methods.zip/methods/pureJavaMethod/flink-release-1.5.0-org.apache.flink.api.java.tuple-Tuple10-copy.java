/** 
 * Shallow tuple copy.
 * @return A new Tuple with the same fields as this.
 */
@Override @SuppressWarnings("unchecked") public Tuple10<T0,T1,T2,T3,T4,T5,T6,T7,T8,T9> copy(){
  return new Tuple10<>(this.f0,this.f1,this.f2,this.f3,this.f4,this.f5,this.f6,this.f7,this.f8,this.f9);
}
