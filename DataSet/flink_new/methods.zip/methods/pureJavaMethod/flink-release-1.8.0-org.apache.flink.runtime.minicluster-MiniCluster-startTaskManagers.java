@GuardedBy("lock") private void startTaskManagers() throws Exception {
  final int numTaskManagers=miniClusterConfiguration.getNumTaskManagers();
  LOG.info("Starting {} TaskManger(s)",numTaskManagers);
  for (int i=0; i < numTaskManagers; i++) {
    startTaskExecutor();
  }
}
