public OneInputStreamOperatorTestHarness(OneInputStreamOperator<IN,OUT> operator,Environment environment) throws Exception {
  super(operator,environment);
  this.oneInputOperator=operator;
}
