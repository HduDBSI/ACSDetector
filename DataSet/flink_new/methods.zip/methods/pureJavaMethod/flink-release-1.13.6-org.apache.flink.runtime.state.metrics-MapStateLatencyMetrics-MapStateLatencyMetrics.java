private MapStateLatencyMetrics(String stateName,MetricGroup metricGroup,int sampleInterval,int historySize,boolean stateNameAsVariable){
  super(stateName,metricGroup,sampleInterval,historySize,stateNameAsVariable);
}
