public ClassPathPackagedProgramRetriever build() throws IOException {
  return new ClassPathPackagedProgramRetriever(programArguments,jobClassName,jarsOnClassPath,userLibDirectory,jarFile);
}
