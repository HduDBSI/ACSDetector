public void validate(){
  assertThat(consumedValues).as("Should be %d distinct elements in total",totalNumRecords).hasSize(totalNumRecords);
  assertThat(count).as("Should be %d elements in total",totalNumRecords).isEqualTo(totalNumRecords);
  assertThat(min).as("The min value should be 0",totalNumRecords).isZero();
  assertThat(max).as("The max value should be %d",totalNumRecords - 1).isEqualTo(totalNumRecords - 1);
}
