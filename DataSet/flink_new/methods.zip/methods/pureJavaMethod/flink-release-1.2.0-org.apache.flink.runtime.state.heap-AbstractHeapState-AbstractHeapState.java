/** 
 * Creates a new key/value state for the given hash map of key/value pairs.
 * @param backend The state backend backing that created this state.
 * @param stateDesc The state identifier for the state. This contains nameand can create a default state value.
 * @param stateTable The state tab;e to use in this kev/value state. May contain initial state.
 */
protected AbstractHeapState(KeyedStateBackend<K> backend,SD stateDesc,StateTable<K,N,SV> stateTable,TypeSerializer<K> keySerializer,TypeSerializer<N> namespaceSerializer){
  Preconditions.checkNotNull(stateTable,"State table must not be null.");
  this.backend=backend;
  this.stateDesc=stateDesc;
  this.stateTable=stateTable;
  this.keySerializer=keySerializer;
  this.namespaceSerializer=namespaceSerializer;
}
