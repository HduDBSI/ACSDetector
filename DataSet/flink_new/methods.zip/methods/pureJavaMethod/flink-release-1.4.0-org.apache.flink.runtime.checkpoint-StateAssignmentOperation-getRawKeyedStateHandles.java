/** 
 * Collect  {@link KeyGroupsStateHandle  rawKeyedStateHandles} which have intersection with given{@link KeyGroupRange} from {@link TaskState operatorState}
 * @param operatorState        all state handles of a operator
 * @param subtaskKeyGroupRange the KeyGroupRange of a subtask
 * @return all rawKeyedStateHandles which have intersection with given KeyGroupRange
 */
public static List<KeyedStateHandle> getRawKeyedStateHandles(OperatorState operatorState,KeyGroupRange subtaskKeyGroupRange){
  List<KeyedStateHandle> extractedKeyedStateHandles=new ArrayList<>();
  for (int i=0; i < operatorState.getParallelism(); i++) {
    if (operatorState.getState(i) != null) {
      Collection<KeyedStateHandle> rawKeyedState=operatorState.getState(i).getRawKeyedState();
      extractIntersectingState(rawKeyedState,subtaskKeyGroupRange,extractedKeyedStateHandles);
    }
  }
  return extractedKeyedStateHandles;
}
