public CompletableFuture<JobStatus> getJobStatus(JobID jobId){
  return runDispatcherCommand(dispatcherGateway -> dispatcherGateway.requestJobStatus(jobId,rpcTimeout));
}
