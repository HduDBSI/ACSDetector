public ChainingOutput(Input<T> input,OperatorMetricGroup operatorMetricGroup,StreamStatusProvider streamStatusProvider,@Nullable OutputTag<T> outputTag,@Nullable AutoCloseable closeable){
  this.input=input;
  this.closeable=closeable;
{
    Counter tmpNumRecordsIn;
    try {
      OperatorIOMetricGroup ioMetricGroup=operatorMetricGroup.getIOMetricGroup();
      tmpNumRecordsIn=ioMetricGroup.getNumRecordsInCounter();
    }
 catch (    Exception e) {
      LOG.warn("An exception occurred during the metrics setup.",e);
      tmpNumRecordsIn=new SimpleCounter();
    }
    numRecordsIn=tmpNumRecordsIn;
  }
  this.streamStatusProvider=streamStatusProvider;
  this.outputTag=outputTag;
}
