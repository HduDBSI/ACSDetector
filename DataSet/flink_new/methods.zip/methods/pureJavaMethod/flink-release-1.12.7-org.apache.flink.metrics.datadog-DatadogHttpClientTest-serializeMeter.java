@Test public void serializeMeter() throws JsonProcessingException {
  DSeries series=new DSeries();
  series.add(new DMeter(new TestMeter(0,1),METRIC,HOST,tags,() -> MOCKED_SYSTEM_MILLIS));
  assertSerialization(DatadogHttpClient.serialize(series),new MetricAssertion(MetricType.gauge,true,"1.0"));
}
