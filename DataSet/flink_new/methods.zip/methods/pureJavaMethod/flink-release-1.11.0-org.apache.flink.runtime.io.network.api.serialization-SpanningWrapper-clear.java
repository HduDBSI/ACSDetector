public void clear(){
  buffer=initialBuffer;
  serializationReadBuffer.releaseArrays();
  recordLength=-1;
  lengthBuffer.clear();
  leftOverData=null;
  leftOverStart=0;
  leftOverLimit=0;
  accumulatedRecordBytes=0;
  if (spillingChannel != null) {
    closeQuietly(spillingChannel);
  }
  if (spillFileReader != null) {
    closeQuietly(spillFileReader);
  }
  if (spillFile != null) {
    closeQuietly(() -> spillFile.release());
  }
  spillingChannel=null;
  spillFileReader=null;
  spillFile=null;
}
