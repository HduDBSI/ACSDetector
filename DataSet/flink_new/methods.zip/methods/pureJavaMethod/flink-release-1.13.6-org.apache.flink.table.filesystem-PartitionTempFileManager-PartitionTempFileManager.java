PartitionTempFileManager(FileSystemFactory factory,Path tmpPath,int taskNumber,long checkpointId,OutputFileConfig outputFileConfig) throws IOException {
  checkArgument(checkpointId != -1,"checkpoint id start with 0.");
  this.taskNumber=taskNumber;
  this.checkpointId=checkpointId;
  this.outputFileConfig=outputFileConfig;
  this.taskTmpDir=new Path(new Path(tmpPath,checkpointName(checkpointId)),TASK_DIR_PREFIX + taskNumber);
  factory.create(taskTmpDir.toUri()).delete(taskTmpDir,true);
}
