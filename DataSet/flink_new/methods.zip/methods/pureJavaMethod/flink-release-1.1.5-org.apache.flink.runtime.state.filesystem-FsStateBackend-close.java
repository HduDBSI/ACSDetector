/** 
 * If the stream is only closed, we remove the produced file (cleanup through the auto close feature, for example). This method throws no exception if the deletion fails, but only logs the error. Important: This method should never throw any  {@link Throwable}.
 */
@Override public void close(){
  if (!closed) {
    closed=true;
    pos=writeBuffer.length;
synchronized (openStreams) {
      openStreams.remove(this);
    }
    if (outStream != null) {
      try {
        outStream.close();
      }
 catch (      Throwable e) {
        LOG.warn("Cannot delete closed and discarded state stream for {}.",statePath,e);
      }
 finally {
        try {
          fs.delete(statePath,false);
          try {
            FileUtils.deletePathIfEmpty(fs,basePath);
          }
 catch (          Throwable ignored) {
            LOG.debug("Could not delete parent directory for path {}.",basePath,ignored);
          }
        }
 catch (        Throwable ioE) {
          LOG.warn("Could not delete stream file for {}.",statePath,ioE);
        }
      }
    }
  }
}
