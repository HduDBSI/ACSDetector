public DeclineCheckpoint(JobID job,ExecutionAttemptID taskExecutionId,long checkpointId,Throwable reason){
  super(job,taskExecutionId,checkpointId);
  if (reason == null || reason instanceof CheckpointException) {
    this.reason=reason;
  }
 else {
    this.reason=new SerializedThrowable(reason);
  }
}
