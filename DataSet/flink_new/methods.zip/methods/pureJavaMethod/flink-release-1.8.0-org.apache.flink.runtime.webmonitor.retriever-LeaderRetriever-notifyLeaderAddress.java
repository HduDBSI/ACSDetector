@Override public void notifyLeaderAddress(final String leaderAddress,final UUID leaderSessionID){
  final CompletableFuture<Tuple2<String,UUID>> newLeaderFuture;
  if (isEmptyAddress(leaderAddress)) {
    newLeaderFuture=new CompletableFuture<>();
  }
 else {
    newLeaderFuture=CompletableFuture.completedFuture(Tuple2.of(leaderAddress,leaderSessionID));
  }
  try {
    final CompletableFuture<Tuple2<String,UUID>> oldLeaderFuture=atomicLeaderFuture.getAndSet(newLeaderFuture);
    if (!oldLeaderFuture.isDone()) {
      newLeaderFuture.whenComplete((stringUUIDTuple2,throwable) -> {
        if (throwable != null) {
          oldLeaderFuture.completeExceptionally(throwable);
        }
 else {
          oldLeaderFuture.complete(stringUUIDTuple2);
        }
      }
);
    }
    notifyNewLeaderAddress(newLeaderFuture);
  }
 catch (  Exception e) {
    handleError(e);
  }
}
