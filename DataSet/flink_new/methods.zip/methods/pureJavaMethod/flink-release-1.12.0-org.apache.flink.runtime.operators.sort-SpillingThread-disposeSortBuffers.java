/** 
 * Releases the memory that is registered for in-memory sorted run generation.
 */
private void disposeSortBuffers(boolean releaseMemory){
  CircularElement<E> element;
  while ((element=this.dispatcher.poll(SortStage.READ)) != null) {
    element.getBuffer().dispose();
    if (releaseMemory) {
      this.memManager.release(element.getMemory());
    }
  }
}
