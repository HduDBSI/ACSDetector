private static CPUResource getCpuCores(final Configuration config){
  return getCpuCoresWithFallback(config,-1.0);
}
