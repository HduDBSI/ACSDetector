/** 
 * Requests the  {@link JobStatus} of the job with the given {@link JobID}.
 */
public abstract CompletableFuture<JobStatus> getJobStatus(JobID jobId);
