@Override public void emitWatermark(Watermark mark){
  owner.checkAsyncException();
synchronized (lockingObject) {
    output.emitWatermark(mark);
  }
}
