public static Configuration loadConfiguration(String[] args) throws FlinkParseException {
  return ConfigurationParserUtils.loadCommonConfiguration(args,TaskManagerRunner.class.getSimpleName());
}
