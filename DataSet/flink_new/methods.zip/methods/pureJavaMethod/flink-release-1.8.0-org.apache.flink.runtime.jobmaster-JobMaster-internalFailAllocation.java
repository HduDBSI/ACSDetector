private void internalFailAllocation(AllocationID allocationId,Exception cause){
  final Optional<ResourceID> resourceIdOptional=slotPool.failAllocation(allocationId,cause);
  resourceIdOptional.ifPresent(this::releaseEmptyTaskManager);
}
