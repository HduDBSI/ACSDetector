public static TaskExecutionStateTransition createFailingStateTransition(ExecutionAttemptID attemptId,Exception exception) throws JobException {
  return new TaskExecutionStateTransition(new TaskExecutionState(attemptId,ExecutionState.FAILED,exception));
}
