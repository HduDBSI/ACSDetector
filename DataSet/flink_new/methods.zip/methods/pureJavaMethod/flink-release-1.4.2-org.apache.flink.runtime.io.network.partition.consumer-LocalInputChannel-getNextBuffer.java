@Override BufferAndAvailability getNextBuffer() throws IOException, InterruptedException {
  checkError();
  ResultSubpartitionView subpartitionView=this.subpartitionView;
  if (subpartitionView == null) {
    subpartitionView=checkAndWaitForSubpartitionView();
  }
  Buffer next=subpartitionView.getNextBuffer();
  if (next == null) {
    if (subpartitionView.isReleased()) {
      throw new CancelTaskException("Consumed partition " + subpartitionView + " has been released.");
    }
 else {
      throw new IllegalStateException("Consumed partition has no buffers available. " + "Number of received buffer notifications is " + numBuffersAvailable + ".");
    }
  }
  long remaining=numBuffersAvailable.decrementAndGet();
  if (remaining >= 0) {
    numBytesIn.inc(next.getSize());
    return new BufferAndAvailability(next,remaining > 0);
  }
 else   if (subpartitionView.isReleased()) {
    throw new ProducerFailedException(subpartitionView.getFailureCause());
  }
 else {
    throw new IllegalStateException("No buffer available and producer partition not released.");
  }
}
