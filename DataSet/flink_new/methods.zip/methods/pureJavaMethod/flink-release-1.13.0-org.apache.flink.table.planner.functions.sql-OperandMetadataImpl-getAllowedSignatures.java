@Override public String getAllowedSignatures(SqlOperator op,String opName){
  return opName + "(TABLE table_name, DESCRIPTOR(timecol), " + "datetime interval, datetime interval[, datetime interval])";
}
