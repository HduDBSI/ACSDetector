/** 
 * Creates a configured  {@link FlinkRelBuilder} for a planning session.
 * @param currentCatalog the current default catalog to look for first during planning.
 * @param currentDatabase the current default database to look for first during planning.
 * @return configured rel builder
 */
public FlinkRelBuilder createRelBuilder(String currentCatalog,String currentDatabase){
  FlinkCalciteCatalogReader relOptSchema=createCatalogReader(false,currentCatalog,currentDatabase);
  Context chain=Contexts.chain(context,Contexts.of(expandingScanFactory(createFlinkPlanner(currentCatalog,currentDatabase).createToRelContext())));
  return new FlinkRelBuilder(chain,cluster,relOptSchema);
}
