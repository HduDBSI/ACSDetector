@Override public final long extractTimestamp(T element,long elementPrevTimestamp){
  final long newTimestamp=extractAscendingTimestamp(element);
  if (newTimestamp >= this.currentTimestamp) {
    this.currentTimestamp=newTimestamp;
    return newTimestamp;
  }
 else {
    violationHandler.handleViolation(newTimestamp,this.currentTimestamp);
    return newTimestamp;
  }
}
