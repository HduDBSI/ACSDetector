public TaskManagerMetricsHandler(final CompletableFuture<String> localRestAddress,final GatewayRetriever<? extends RestfulGateway> leaderRetriever,final Time timeout,final Map<String,String> headers,final MetricFetcher metricFetcher){
  super(localRestAddress,leaderRetriever,timeout,headers,TaskManagerMetricsHeaders.getInstance(),metricFetcher);
}
