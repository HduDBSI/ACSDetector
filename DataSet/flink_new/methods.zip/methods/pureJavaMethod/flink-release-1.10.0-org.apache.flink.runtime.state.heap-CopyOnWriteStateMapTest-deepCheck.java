private void deepCheck(Tuple3<Integer,Integer,ArrayList<Integer>>[] a,Tuple3<Integer,Integer,ArrayList<Integer>>[] b){
  if (a == b) {
    return;
  }
  Assert.assertEquals(a.length,b.length);
  Comparator<Tuple3<Integer,Integer,ArrayList<Integer>>> comparator=(o1,o2) -> {
    int namespaceDiff=o1.f1 - o2.f1;
    return namespaceDiff != 0 ? namespaceDiff : o1.f0 - o2.f0;
  }
;
  Arrays.sort(a,comparator);
  Arrays.sort(b,comparator);
  for (int i=0; i < a.length; ++i) {
    Tuple3<Integer,Integer,ArrayList<Integer>> av=a[i];
    Tuple3<Integer,Integer,ArrayList<Integer>> bv=b[i];
    Assert.assertEquals(av.f0,bv.f0);
    Assert.assertEquals(av.f1,bv.f1);
    Assert.assertEquals(av.f2,bv.f2);
  }
}
