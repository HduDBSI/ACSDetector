@Override public ChecksumHashCode<K,VV,EV> run(Graph<K,VV,EV> input) throws Exception {
  super.run(input);
  vertexChecksum=new org.apache.flink.graph.asm.dataset.ChecksumHashCode<>();
  vertexChecksum.run(input.getVertices());
  edgeChecksum=new org.apache.flink.graph.asm.dataset.ChecksumHashCode<>();
  edgeChecksum.run(input.getEdges());
  return this;
}
