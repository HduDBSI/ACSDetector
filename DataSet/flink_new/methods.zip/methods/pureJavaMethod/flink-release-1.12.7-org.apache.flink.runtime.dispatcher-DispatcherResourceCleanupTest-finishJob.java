private void finishJob(TestingJobManagerRunner takeCreatedJobManagerRunner){
  terminateJobWithState(takeCreatedJobManagerRunner,JobStatus.FINISHED);
}
