@Override public void setOutputType(TypeInformation<OUT> outTypeInfo,ExecutionConfig executionConfig){
  StreamingFunctionUtils.setOutputType(userFunction,outTypeInfo,executionConfig);
}
