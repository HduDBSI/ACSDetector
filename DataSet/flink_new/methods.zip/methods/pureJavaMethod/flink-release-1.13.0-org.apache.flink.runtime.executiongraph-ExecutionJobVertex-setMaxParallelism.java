public void setMaxParallelism(int maxParallelism){
  parallelismInfo.setMaxParallelism(maxParallelism);
}
