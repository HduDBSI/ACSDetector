/** 
 * Creates a new memory segment that represents the memory backing the given direct byte buffer. Note that the given ByteBuffer must be direct  {@link java.nio.ByteBuffer#allocateDirect(int)}, otherwise this method with throw an IllegalArgumentException. <p>The memory segment references the given owner.
 * @param buffer The byte buffer whose memory is represented by this memory segment.
 * @param owner The owner references by this memory segment.
 * @param allowWrap Whether wrapping {@link ByteBuffer}s from the segment is allowed.
 * @param cleaner The cleaner to be called on free segment.
 * @throws IllegalArgumentException Thrown, if the given ByteBuffer is not direct.
 */
MemorySegment(@Nonnull ByteBuffer buffer,@Nullable Object owner,boolean allowWrap,@Nullable Runnable cleaner){
  this.heapMemory=null;
  this.offHeapBuffer=buffer;
  this.size=buffer.capacity();
  this.address=getByteBufferAddress(buffer);
  this.addressLimit=this.address + this.size;
  this.owner=owner;
  this.allowWrap=allowWrap;
  this.cleaner=cleaner;
  this.isFreedAtomic=new AtomicBoolean(false);
}
