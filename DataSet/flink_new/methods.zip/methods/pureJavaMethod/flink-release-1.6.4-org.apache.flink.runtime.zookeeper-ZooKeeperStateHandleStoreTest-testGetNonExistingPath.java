/** 
 * Tests that a non existing path throws an Exception.
 */
@Test(expected=Exception.class) public void testGetNonExistingPath() throws Exception {
  LongStateStorage stateHandleProvider=new LongStateStorage();
  ZooKeeperStateHandleStore<Long> store=new ZooKeeperStateHandleStore<>(ZOOKEEPER.getClient(),stateHandleProvider);
  store.getAndLock("/testGetNonExistingPath");
}
