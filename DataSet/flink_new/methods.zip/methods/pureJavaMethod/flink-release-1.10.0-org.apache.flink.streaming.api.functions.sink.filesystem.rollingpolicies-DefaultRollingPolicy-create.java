/** 
 * This method is  {@link Deprecated}, use  {@link DefaultRollingPolicy#builder()} instead.
 */
@Deprecated public static DefaultRollingPolicy.PolicyBuilder create(){
  return builder();
}
