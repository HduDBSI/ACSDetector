@Override public void notifyCheckpointComplete(long checkpointId){
  LOG.info("notifyCheckpointComplete {} @ {} subtask ({} attempt)",numCompletedCheckpoints,subtaskIndex,numRestarts);
  updatePollingState();
  numCompletedCheckpoints++;
  numCheckpointsInThisAttempt++;
  numAbortedCheckpoints=0;
}
