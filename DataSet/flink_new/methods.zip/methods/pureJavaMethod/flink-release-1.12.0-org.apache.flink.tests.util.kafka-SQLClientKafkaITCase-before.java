@Before public void before() throws Exception {
  DOWNLOAD_CACHE.before();
  Path tmpPath=tmp.getRoot().toPath();
  LOG.info("The current temporary path: {}",tmpPath);
  this.result=tmpPath.resolve("result");
}
