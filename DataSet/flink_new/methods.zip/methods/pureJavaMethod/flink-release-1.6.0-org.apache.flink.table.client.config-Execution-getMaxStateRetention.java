public long getMaxStateRetention(){
  return Long.parseLong(properties.getOrDefault(PropertyStrings.EXECUTION_MAX_STATE_RETENTION,Long.toString(0)));
}
