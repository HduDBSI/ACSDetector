protected List<TopicPartition> toTopicPartitions(TopicMetadata metadata,List<TopicRange> ranges){
  if (!metadata.isPartitioned()) {
    return ranges.stream().map(range -> new TopicPartition(metadata.getName(),-1,range)).collect(toList());
  }
 else {
    List<TopicPartition> partitions=new ArrayList<>();
    for (int i=0; i < metadata.getPartitionSize(); i++) {
      for (      TopicRange range : ranges) {
        TopicPartition partition=new TopicPartition(metadata.getName(),i,range);
        partitions.add(partition);
      }
    }
    return partitions;
  }
}
