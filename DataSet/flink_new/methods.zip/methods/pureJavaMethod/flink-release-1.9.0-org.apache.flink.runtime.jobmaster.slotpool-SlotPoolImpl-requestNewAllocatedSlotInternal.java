/** 
 * Requests a new slot from the ResourceManager. If there is currently not ResourceManager connected, then the request is stashed and send once a new ResourceManager is connected.
 * @param pendingRequest pending slot request
 * @return An {@link AllocatedSlot} future which is completed once the slot is offered to the {@link SlotPool}
 */
@Nonnull private CompletableFuture<AllocatedSlot> requestNewAllocatedSlotInternal(PendingRequest pendingRequest){
  if (resourceManagerGateway == null) {
    stashRequestWaitingForResourceManager(pendingRequest);
  }
 else {
    requestSlotFromResourceManager(resourceManagerGateway,pendingRequest);
  }
  return pendingRequest.getAllocatedSlotFuture();
}
