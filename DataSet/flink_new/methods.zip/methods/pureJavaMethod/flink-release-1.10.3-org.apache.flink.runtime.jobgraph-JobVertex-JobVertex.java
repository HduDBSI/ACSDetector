/** 
 * Constructs a new job vertex and assigns it with the given name.
 * @param name The name of the new job vertex.
 * @param primaryId The id of the job vertex.
 * @param alternativeIds The alternative ids of the job vertex.
 * @param operatorIds The ids of all operators contained in this job vertex.
 * @param alternativeOperatorIds The alternative ids of all operators contained in this job vertex-
 */
public JobVertex(String name,JobVertexID primaryId,List<JobVertexID> alternativeIds,List<OperatorID> operatorIds,List<OperatorID> alternativeOperatorIds){
  Preconditions.checkArgument(operatorIds.size() == alternativeOperatorIds.size());
  this.name=name == null ? DEFAULT_NAME : name;
  this.id=primaryId == null ? new JobVertexID() : primaryId;
  this.idAlternatives.addAll(alternativeIds);
  this.operatorIDs.addAll(operatorIds);
  this.operatorIdsAlternatives.addAll(alternativeOperatorIds);
}
