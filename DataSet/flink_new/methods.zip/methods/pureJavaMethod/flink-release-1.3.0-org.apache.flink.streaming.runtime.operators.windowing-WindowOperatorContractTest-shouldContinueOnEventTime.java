private static <T>void shouldContinueOnEventTime(Trigger<T,TimeWindow> mockTrigger) throws Exception {
  when(mockTrigger.onEventTime(anyLong(),anyTimeWindow(),anyTriggerContext())).thenReturn(TriggerResult.CONTINUE);
}
