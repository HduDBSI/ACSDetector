protected TestingStatusHandler(CompletableFuture<String> localRestAddress,GatewayRetriever<? extends RestfulGateway> leaderRetriever,Time timeout,Map<String,String> responseHeaders,MessageHeaders<EmptyRequestBody,AsynchronousOperationResult<OperationResult>,TriggerMessageParameters> messageHeaders){
  super(localRestAddress,leaderRetriever,timeout,responseHeaders,messageHeaders);
}
