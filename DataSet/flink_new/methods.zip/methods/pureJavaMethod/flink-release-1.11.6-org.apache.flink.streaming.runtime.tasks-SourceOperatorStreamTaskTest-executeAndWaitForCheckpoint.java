private TaskStateSnapshot executeAndWaitForCheckpoint(long checkpointId,TaskStateSnapshot initialSnapshot,IntStream expectedRecords) throws Exception {
  try (StreamTaskMailboxTestHarness<Integer> testHarness=createTestHarness(checkpointId,initialSnapshot)){
    MockSourceSplit split=getAndMaybeAssignSplit(testHarness);
    addRecords(split,NUM_RECORDS);
    testHarness.processWhileAvailable();
    CheckpointOptions checkpointOptions=CheckpointOptions.forCheckpointWithDefaultLocation();
    triggerCheckpointWaitForFinish(testHarness,checkpointId,checkpointOptions);
    Queue<Object> expectedOutput=new LinkedList<>();
    expectedRecords.forEach(r -> expectedOutput.offer(new StreamRecord<>(r,TimestampAssigner.NO_TIMESTAMP)));
    expectedOutput.add(new CheckpointBarrier(checkpointId,checkpointId,checkpointOptions));
    assertEquals(checkpointId,testHarness.taskStateManager.getReportedCheckpointId());
    assertOutputEquals("Output was not correct.",expectedOutput,testHarness.getOutput());
    return testHarness.taskStateManager.getLastJobManagerTaskStateSnapshot();
  }
 }
