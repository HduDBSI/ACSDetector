@Override public void onPartitionConsumable(IntermediateResultPartitionID resultPartitionId){
  final SchedulingResultPartition resultPartition=schedulingTopology.getResultPartition(resultPartitionId);
  if (!resultPartition.getResultType().isPipelined()) {
    return;
  }
  allocateSlotsAndDeployExecutionVertices(resultPartition.getConsumers());
}
