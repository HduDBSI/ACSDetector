@Test public void updateTaskExecutionStateReturnsFalseIfExecutionDoesNotExist(){
  final JobGraph jobGraph=singleNonParallelJobVertexJobGraph();
  final DefaultScheduler scheduler=createSchedulerAndStartScheduling(jobGraph);
  final TaskExecutionState taskExecutionState=createFailedTaskExecutionState(new ExecutionAttemptID());
  assertFalse(scheduler.updateTaskExecutionState(taskExecutionState));
}
