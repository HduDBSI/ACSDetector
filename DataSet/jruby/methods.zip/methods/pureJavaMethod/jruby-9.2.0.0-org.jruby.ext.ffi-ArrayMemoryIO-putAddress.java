public final void putAddress(byte[] buffer,int offset,long value){
  putInt64(buffer,offset,value);
}
