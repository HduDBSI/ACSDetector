/** 
 * Returns the  {@link org.jruby.runtime.Arity} of this function.
 * @return The <tt>Arity</tt> of the native function.
 */
public final Arity getArity(){
  return arity;
}
