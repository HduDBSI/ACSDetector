public static IRubyObject newUnsigned32(Ruby runtime,long value){
  long n=(int)value;
  return RubyFixnum.newFixnum(runtime,n < 0 ? ((n & 0x7FFFFFFFL) + 0x80000000L) : n);
}
