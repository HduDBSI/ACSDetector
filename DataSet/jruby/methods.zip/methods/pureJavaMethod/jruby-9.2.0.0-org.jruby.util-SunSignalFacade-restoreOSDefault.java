public IRubyObject restoreOSDefault(IRubyObject recv,IRubyObject sig){
  return trap(recv.getRuntime(),sig.toString(),SignalHandler.SIG_DFL);
}
