public RaiseException buildException(Ruby runtime){
switch (reason) {
case RETURN:
case BREAK:
case NEXT:
    return runtime.newLocalJumpError(reason,(IRubyObject)value,"unexpected " + reason);
case REDO:
case RETRY:
  return runtime.newLocalJumpError(reason,runtime.getNil(),"unexpected " + reason);
case NOREASON:
default :
return runtime.newLocalJumpError(reason,runtime.getNil(),"no reason");
}
}
