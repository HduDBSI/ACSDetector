IOError(IOException ioe){
  super(ioe);
  this.ioe=ioe;
}
