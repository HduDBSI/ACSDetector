/** 
 * rb_ary_aset
 */
@JRubyMethod(name="[]=") public IRubyObject aset(IRubyObject arg0,IRubyObject arg1,IRubyObject arg2){
  modifyCheck();
  splice(getRuntime(),RubyNumeric.num2int(arg0),RubyNumeric.num2int(arg1),arg2);
  return arg2;
}
