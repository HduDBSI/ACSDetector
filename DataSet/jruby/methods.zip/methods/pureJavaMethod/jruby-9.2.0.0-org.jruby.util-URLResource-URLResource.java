private URLResource(String uri,URL url,ClassLoader cl,String pathname,String[] files){
  this.uri=uri;
  this.list=files;
  this.url=url;
  this.cl=cl;
  this.pathname=pathname;
  this.fileStat=new JarFileStat(this);
}
