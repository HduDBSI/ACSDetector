/** 
 * Append the given utf8 characters to the buffer, if given, checking for errors along the way.
 * @param runtime current runtime
 * @param to output buffer; if null, no appending will be done
 * @param code utf8 character code
 * @param enc output param for new encoding
 * @param str original wrapper of source bytes
 * @param mode error mode
 */
private static void appendUtf8(Ruby runtime,ByteList to,int code,Encoding[] enc,ByteList str,ErrorMode mode){
  checkUnicodeRange(runtime,code,str,ErrorMode.PREPROCESS);
  if (code < 0x80) {
    if (to != null)     Sprintf.sprintf(runtime,to,"\\x%02X",code);
  }
 else {
    if (to != null) {
      to.ensure(to.getRealSize() + 6);
      to.setRealSize(to.getRealSize() + Pack.utf8Decode(runtime,to.getUnsafeBytes(),to.getBegin() + to.getRealSize(),code));
    }
    if (enc[0] == null) {
      enc[0]=UTF8Encoding.INSTANCE;
    }
 else     if (!(enc[0].isUTF8())) {
      raisePreprocessError(runtime,str,"UTF-8 character in non UTF-8 regexp",mode);
    }
  }
}
