@JRubyMethod(name="deflate",required=1,optional=1,meta=true) public static IRubyObject s_deflate(IRubyObject recv,IRubyObject[] args){
  Ruby runtime=recv.getRuntime();
  args=Arity.scanArgs(runtime,args,1,1);
  int level=JZlib.Z_DEFAULT_COMPRESSION;
  if (!args[1].isNil()) {
    level=RubyNumeric.fix2int(args[1]);
    checkLevel(runtime,level);
  }
  RubyClass klass=(RubyClass)(recv.isClass() ? recv : runtime.getClassFromPath("Zlib::Deflate"));
  JZlibDeflate deflate=(JZlibDeflate)klass.allocate();
  deflate.init(level,JZlib.DEF_WBITS,8,JZlib.Z_DEFAULT_STRATEGY);
  try {
    IRubyObject result=deflate.deflate(args[0].convertToString().getByteList(),JZlib.Z_FINISH);
    deflate.close();
    return result;
  }
 catch (  IOException ioe) {
    throw runtime.newIOErrorFromException(ioe);
  }
}
