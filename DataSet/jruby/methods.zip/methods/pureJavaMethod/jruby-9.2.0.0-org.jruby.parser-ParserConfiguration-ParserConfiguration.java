public ParserConfiguration(Ruby runtime,int lineNumber,boolean inlineSource,boolean isFileParse,boolean saveData,RubyInstanceConfig config){
  this(runtime,lineNumber,inlineSource,isFileParse,saveData);
  this.isDebug=config.isParserDebug();
  this.frozenStringLiteral=config.isFrozenStringLiteral();
}
