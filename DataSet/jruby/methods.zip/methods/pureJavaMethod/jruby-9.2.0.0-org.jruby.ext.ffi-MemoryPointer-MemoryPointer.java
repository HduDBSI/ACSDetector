private MemoryPointer(Ruby runtime,IRubyObject klass,MemoryIO io,long total,int typeSize){
  super(runtime,(RubyClass)klass,io,total,typeSize);
}
