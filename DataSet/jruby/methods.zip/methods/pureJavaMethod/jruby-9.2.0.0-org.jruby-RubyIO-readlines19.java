@Deprecated public RubyArray readlines19(ThreadContext context,IRubyObject[] args){
  return readlines(context,args);
}
