public static RubyThread adopt(IRubyObject recv,Thread t){
  return adoptThread(recv,t);
}
