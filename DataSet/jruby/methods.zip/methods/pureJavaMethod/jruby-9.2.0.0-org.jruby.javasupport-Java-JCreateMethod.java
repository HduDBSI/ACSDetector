JCreateMethod(RubyModule cls){
  super(cls,PUBLIC,"__jcreate!");
}
