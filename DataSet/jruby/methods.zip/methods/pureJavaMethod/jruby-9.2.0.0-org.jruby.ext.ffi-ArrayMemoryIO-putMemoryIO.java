public final void putMemoryIO(long offset,MemoryIO value){
  checkBounds(offset,ADDRESS_SIZE >> 3);
  putAddress(offset,value.address());
}
