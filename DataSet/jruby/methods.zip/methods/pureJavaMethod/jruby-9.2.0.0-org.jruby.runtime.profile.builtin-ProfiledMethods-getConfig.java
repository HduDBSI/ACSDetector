private RubyInstanceConfig getConfig(){
  return getRuntime().getInstanceConfig();
}
