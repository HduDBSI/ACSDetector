void setHash(RubyClass hashClass){
  this.hashClass=hashClass;
}
