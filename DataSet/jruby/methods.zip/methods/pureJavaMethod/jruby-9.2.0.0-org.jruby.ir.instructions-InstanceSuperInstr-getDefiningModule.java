public Operand getDefiningModule(){
  return getReceiver();
}
