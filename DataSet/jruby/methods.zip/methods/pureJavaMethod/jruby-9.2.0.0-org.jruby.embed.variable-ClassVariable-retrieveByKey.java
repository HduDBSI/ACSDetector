/** 
 * Retrieves a class variable by key from Ruby runtime after the evaluation. This method is used when eager retrieval is off.
 * @param receiver receiver object returned when a script is evaluated.
 * @param vars map to save retrieved instance variables.
 * @param name instace varible name
 */
public static void retrieveByKey(final RubyObject receiver,final BiVariableMap vars,final String name){
  final RubyClass klazz=receiver.getMetaClass();
  IRubyObject value=null;
  if (receiver == receiver.getRuntime().getTopSelf() && klazz.getClassVariableNameList().contains(name)) {
    value=klazz.getClassVar(name);
  }
 else {
    if (klazz.hasClassVariable(name)) {
      value=klazz.getClassVar(name);
    }
  }
  if (value == null)   return;
  vars.updateVariable(receiver,name,value,ClassVariable.class);
}
