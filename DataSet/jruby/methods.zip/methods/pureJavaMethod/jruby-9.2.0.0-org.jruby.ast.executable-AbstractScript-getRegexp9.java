public final RubyRegexp getRegexp9(ThreadContext context,ByteList pattern,int options){
  return runtimeCache.getRegexp(context,9,pattern,options);
}
