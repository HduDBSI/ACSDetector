@SuppressWarnings("deprecation") public void clump(final Class klass){
  Method[] declaredMethods=Initializer.DECLARED_METHODS.get(klass);
  for (  Method method : declaredMethods) {
    JRubyMethod anno=method.getAnnotation(JRubyMethod.class);
    if (anno == null)     continue;
    if (anno.compat() == org.jruby.CompatVersion.RUBY1_8)     continue;
    if (method.isBridge())     continue;
    JavaMethodDescriptor desc=new JavaMethodDescriptor(method);
    final String[] names=anno.name();
    String name=names.length == 0 ? method.getName() : names[0];
    Map<String,List<JavaMethodDescriptor>> methodsHash;
    if (desc.isStatic) {
      if ((methodsHash=staticAnnotatedMethods) == null) {
        methodsHash=staticAnnotatedMethods=new HashMap<>();
      }
    }
 else {
      if ((methodsHash=annotatedMethods) == null) {
        methodsHash=annotatedMethods=new HashMap<>();
      }
    }
    List<JavaMethodDescriptor> methodDescs=methodsHash.get(name);
    if (methodDescs == null) {
      methodsHash.put(name,methodDescs=new ArrayList<>(4));
    }
    methodDescs.add(desc);
    if (anno.reads().length > 0 && readGroups == Collections.EMPTY_MAP)     readGroups=new HashMap<>();
    if (anno.writes().length > 0 && writeGroups == Collections.EMPTY_MAP)     writeGroups=new HashMap<>();
    AnnotationHelper.groupFrameFields(readGroups,writeGroups,anno,method.getName());
  }
}
