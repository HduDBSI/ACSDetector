/** 
 * m_sqrt
 */
private static IRubyObject m_sqrt(ThreadContext context,IRubyObject x){
  if (f_real_p(context,x)) {
    if (!f_negative_p(context,x))     return RubyMath.sqrt(context,x,x);
    return newComplex(context,context.runtime.getComplex(),RubyFixnum.zero(context.runtime),RubyMath.sqrt(context,x,f_negate(context,x)));
  }
 else {
    RubyComplex complex=(RubyComplex)x;
    if (f_negative_p(context,complex.image)) {
      return f_conjugate(context,m_sqrt(context,f_conjugate(context,x)));
    }
 else {
      IRubyObject a=f_abs(context,x);
      IRubyObject two=RubyFixnum.two(context.runtime);
      return newComplex(context,context.runtime.getComplex(),RubyMath.sqrt(context,x,f_div(context,f_add(context,a,complex.real),two)),RubyMath.sqrt(context,x,f_div(context,f_sub(context,a,complex.real),two)));
    }
  }
}
