public static FileResource createResourceAsFile(Ruby runtime,String pathname){
  return createResource(runtime,runtime.getCurrentDirectory(),pathname,true);
}
