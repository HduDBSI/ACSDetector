private boolean isWhitespace(byte b){
  return b == ' ' || (b <= 13 && b >= 9 && b != 11);
}
