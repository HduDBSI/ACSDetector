public int getJitThreshold();
