/** 
 * @deprecated use {@link #logCaller(org.jruby.runtime.backtrace.RubyStackTraceElement[]) }
 */
public static void dumpCaller(RubyStackTraceElement[] trace){
  logCaller(trace);
}
