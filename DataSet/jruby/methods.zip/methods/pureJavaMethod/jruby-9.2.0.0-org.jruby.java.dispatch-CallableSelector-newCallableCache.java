/** 
 * Internal helper to allocate a callable map to cache argument method matches.
 * @param < T > the callable type
 * @return cache usable with {@link CallableSelector}
 */
@Deprecated public static <T extends ParameterTypes>IntHashMap<T> newCallableCache(){
  return new IntHashMap<T>(8);
}
