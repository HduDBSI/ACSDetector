public int findClosingIndexOf(int leftTokenIndex){
  if (leftTokenIndex == -1 || leftTokenIndex > end)   return -1;
  byte leftToken=bytes[leftTokenIndex];
  byte rightToken;
switch (leftToken) {
case '{':
    rightToken='}';
  break;
case '[':
rightToken=']';
break;
default :
return -1;
}
int nest=1;
index=leftTokenIndex + 1;
while (hasNext()) {
byte c=next();
if (c == leftToken) {
nest++;
}
 else if (c == rightToken && --nest == 0) {
return index();
}
}
return -1;
}
