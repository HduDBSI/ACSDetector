public ToAryInstr(Variable result,Operand array){
  super(Operation.TO_ARY,result,array);
  assert result != null : "ToAryInstr result is null";
}
