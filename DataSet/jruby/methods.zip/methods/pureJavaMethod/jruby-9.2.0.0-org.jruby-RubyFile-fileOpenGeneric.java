public IRubyObject fileOpenGeneric(ThreadContext context,IRubyObject filename,int oflags,int fmode,IOEncodable convConfig,int perm){
  if (convConfig == null) {
    convConfig=new ConvConfig();
    EncodingUtils.ioExtIntToEncs(context,convConfig,null,null,fmode);
    convConfig.setEcflags(0);
    convConfig.setEcopts(context.nil);
  }
  int[] fmode_p={fmode};
  EncodingUtils.validateEncodingBinmode(context,fmode_p,convConfig.getEcflags(),convConfig);
  OpenFile fptr=MakeOpenFile();
  fptr.setMode(fmode_p[0]);
  fptr.encs.copy(convConfig);
  fptr.setPath(adjustRootPathOnWindows(context.runtime,RubyFile.get_path(context,filename).asJavaString(),getRuntime().getCurrentDirectory()));
  fptr.setFD(sysopen(context.runtime,fptr.getPath(),oflags,perm));
  fptr.checkTTY();
  if ((fmode_p[0] & OpenFile.SETENC_BY_BOM) != 0) {
    EncodingUtils.ioSetEncodingByBOM(context,this);
  }
  return this;
}
