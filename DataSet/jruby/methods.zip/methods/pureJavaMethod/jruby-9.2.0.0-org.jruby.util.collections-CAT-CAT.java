CAT(CAT next,int sz,long init){
  _next=next;
  _sum_cache=Long.MIN_VALUE;
  _t=new long[sz];
  _t[0]=init;
}
