public static void removeWarningsFromEclipse(){
  TestHelper helper=new TestHelper("A");
  helper.privateMethod();
  TestHelper.staticPrivateMethod();
}
