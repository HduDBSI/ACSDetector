@Override public abstract IRubyObject call(ThreadContext context,IRubyObject self,RubyModule clazz,String name,IRubyObject arg0,IRubyObject arg1);
