public ProfiledMethods(final Ruby runtime){
  if (runtime == null)   throw new IllegalArgumentException("Given runtime must not be null.");
  this.runtime=runtime;
  this.methods=new NonBlockingHashMapLong<>(10000);
}
