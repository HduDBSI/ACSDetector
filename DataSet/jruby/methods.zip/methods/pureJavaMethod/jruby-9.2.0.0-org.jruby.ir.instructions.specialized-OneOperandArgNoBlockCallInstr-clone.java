@Override public Instr clone(CloneInfo ii){
  return new OneOperandArgNoBlockCallInstr(getCallType(),ii.getRenamedVariable(result),getName(),getReceiver().cloneForInlining(ii),cloneCallArgs(ii),isPotentiallyRefined());
}
