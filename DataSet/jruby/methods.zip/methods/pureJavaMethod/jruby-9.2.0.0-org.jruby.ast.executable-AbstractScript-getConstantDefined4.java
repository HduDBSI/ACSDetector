public final IRubyObject getConstantDefined4(ThreadContext context,StaticScope scope,String name){
  return runtimeCache.getConstantDefined(context,scope,name,4);
}
