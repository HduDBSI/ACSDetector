/** 
 * Logic to match (as well as possible) rb_io_wait_readable from MRI. We do not have the luxury of treating all file descriptors the same, so there's a bit of special-casing here when the channel is not selectable. Note also the EBADF on closed channels; I believe this is what *would happen in MRI if we always called the selection logic and were given a closed channel. MRI: rb_io_wait_readable
 */
boolean waitReadable(ThreadContext context,ChannelFD fd){
  checkClosed();
  boolean locked=lock();
  try {
    if (!fd.ch.isOpen()) {
      posix.errno=Errno.EBADF;
      return false;
    }
    if (posix.errno != null && posix.errno != Errno.EAGAIN && posix.errno != Errno.EWOULDBLOCK && posix.errno != Errno.EINTR) {
      return false;
    }
    if (fd.chSelect != null) {
      unlock();
      try {
        return context.getThread().select(fd.chSelect,this,SelectionKey.OP_READ);
      }
  finally {
        lock();
      }
    }
    if (fd.chSeek != null) {
      return true;
    }
  }
  finally {
    if (locked)     unlock();
  }
  return false;
}
