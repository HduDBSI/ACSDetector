public static Object staticNewObject(){
  return new Object();
}
