public static final ByteList longToOctalByteList(long i){
  return longToByteList(i,8,LOWER_DIGITS);
}
