@Override public Object interpret(ThreadContext context,StaticScope currScope,DynamicScope currDynScope,IRubyObject self,Object[] temp){
  IRubyObject[] args=prepareArguments(context,self,currScope,currDynScope,temp);
  Block block=prepareBlock(context,self,currScope,currDynScope,temp);
  return IRRuntimeHelpers.unresolvedSuper(context,self,args,block);
}
