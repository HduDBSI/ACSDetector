protected void receiveNonBlockArgs(final ArgsNode argsNode){
  Signature signature=scope.getStaticScope().getSignature();
  if (scope instanceof IRMethod) {
    addInstr(new CheckArityInstr(signature.required(),signature.opt(),signature.hasRest(),argsNode.hasKwargs(),signature.keyRest()));
  }
 else   if (scope instanceof IRClosure && argsNode.hasKwargs()) {
    addInstr(new CheckArityInstr(signature.required(),signature.opt(),signature.hasRest(),argsNode.hasKwargs(),signature.keyRest()));
  }
  int argIndex=0;
  Node[] args=argsNode.getArgs();
  int preCount=signature.pre();
  for (int i=0; i < preCount; i++, argIndex++) {
    receiveRequiredArg(args[i],argIndex,null);
  }
  int opt=signature.opt() > 0 ? signature.opt() : 0;
  if (opt > 0) {
    int optIndex=argsNode.getOptArgIndex();
    for (int j=0; j < opt; j++, argIndex++) {
      Label variableAssigned=getNewLabel();
      OptArgNode optArg=(OptArgNode)args[optIndex + j];
      RubySymbol argName=optArg.getName();
      Variable argVar=argumentResult(argName);
      if (scope instanceof IRMethod)       addArgumentDescription(ArgumentType.opt,argName);
      addInstr(new ReceiveOptArgInstr(argVar,signature.required(),signature.pre(),j));
      addInstr(BNEInstr.create(variableAssigned,argVar,UndefinedValue.UNDEFINED));
      addInstr(new CopyInstr(argVar,manager.getNil()));
      build(optArg.getValue());
      addInstr(new LabelInstr(variableAssigned));
    }
  }
  if (signature.hasRest()) {
    RestArgNode restArgNode=argsNode.getRestArgNode();
    if (scope instanceof IRMethod) {
      addArgumentDescription(restArgNode.isAnonymous() ? ArgumentType.anonrest : ArgumentType.rest,restArgNode.getName());
    }
    RubySymbol argName=restArgNode.isAnonymous() ? scope.getManager().getRuntime().newSymbol(CommonByteLists.STAR) : restArgNode.getName();
    addInstr(new ReceiveRestArgInstr(argumentResult(argName),signature.required() + opt,argIndex));
  }
  int postCount=argsNode.getPostCount();
  int postIndex=argsNode.getPostIndex();
  for (int i=0; i < postCount; i++) {
    receiveRequiredArg(args[postIndex + i],i,signature);
  }
}
