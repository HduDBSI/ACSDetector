/** 
 * Test of size method, of class BiVariableMap.
 */
@Test public void testSize(){
  logger1.info("size");
  ScriptingContainer container=new ScriptingContainer(LocalContextScope.SINGLETHREAD,LocalVariableBehavior.TRANSIENT);
  BiVariableMap instance=container.getVarMap();
  container.put("ARGV",new String[]{"spring","fall"});
  container.put("SEASON",new String[]{"summer","winter"});
  container.put("$sports",new String[]{"baseball","hiking","soccer","ski"});
  container.put("@weather",new String[]{"snow","sleet","drizzle","rain"});
  container.put("trees",new String[]{"cypress","hemlock","spruce"});
  assertTrue(instance.size() == 5);
  String[] expResult={"snow","sleet","drizzle","rain"};
  String[] weather=(String[])container.remove("@weather");
  assertArrayEquals(expResult,weather);
  assertTrue(instance.size() == 4);
  container.runScriptlet("a = 1");
  assertTrue(instance.size() == 3);
  container=new ScriptingContainer(LocalContextScope.SINGLETHREAD,LocalVariableBehavior.PERSISTENT);
  instance=container.getVarMap();
  container.put("ARGV",new String[]{"spring","fall"});
  container.put("SEASON",new String[]{"summer","winter"});
  container.put("$sports",new String[]{"baseball","hiking","soccer","ski"});
  container.put("@weather",new String[]{"snow","sleet","drizzle","rain"});
  container.put("trees",new String[]{"cypress","hemlock","spruce"});
  assertTrue(instance.size() == 5);
  container.runScriptlet("a = 1");
  assertTrue(instance.size() == 6);
  container=new ScriptingContainer(LocalContextScope.SINGLETHREAD,LocalVariableBehavior.GLOBAL);
  instance=container.getVarMap();
  container.put("ARGV",new String[]{"spring","fall"});
  container.put("SEASON",new String[]{"summer","winter"});
  container.put("$sports",new String[]{"baseball","hiking","soccer","ski"});
  container.put("@weather",new String[]{"snow","sleet","drizzle","rain"});
  container.put("trees",new String[]{"cypress","hemlock","spruce"});
  assertTrue(instance.size() == 3);
  container.runScriptlet("a = 1");
  assertTrue(instance.size() == 3);
}
