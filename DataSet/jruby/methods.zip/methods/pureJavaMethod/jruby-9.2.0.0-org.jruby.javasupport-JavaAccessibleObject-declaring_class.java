@JRubyMethod public IRubyObject declaring_class(){
  Class<?> clazz=((Member)accessibleObject()).getDeclaringClass();
  if (clazz != null)   return JavaClass.get(getRuntime(),clazz);
  return getRuntime().getNil();
}
