/** 
 * Gets the current processor architecture the JVM is running on.
 * @return A <tt>CPU</tt> value representing the current processor architecture.
 */
public final CPU_TYPE getCPU(){
  return CPU;
}
