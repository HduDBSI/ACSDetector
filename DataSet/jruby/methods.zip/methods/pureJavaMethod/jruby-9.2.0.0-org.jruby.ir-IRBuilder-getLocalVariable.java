public LocalVariable getLocalVariable(RubySymbol name,int scopeDepth){
  return scope.getLocalVariable(name,scopeDepth);
}
