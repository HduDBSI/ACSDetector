public final RubyFloat getFloat6(ThreadContext context,double value){
  return runtimeCache.getFloat(context,6,value);
}
