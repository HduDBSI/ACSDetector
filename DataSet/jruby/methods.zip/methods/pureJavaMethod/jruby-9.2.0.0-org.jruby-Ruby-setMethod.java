void setMethod(RubyClass methodClass){
  this.methodClass=methodClass;
}
