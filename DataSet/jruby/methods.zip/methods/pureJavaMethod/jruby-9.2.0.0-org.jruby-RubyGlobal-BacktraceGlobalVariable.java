public BacktraceGlobalVariable(Ruby runtime,String name){
  super(runtime,name,null);
}
