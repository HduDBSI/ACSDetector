public abstract RubyClass getArrayJavaProxyCreatorClass();
