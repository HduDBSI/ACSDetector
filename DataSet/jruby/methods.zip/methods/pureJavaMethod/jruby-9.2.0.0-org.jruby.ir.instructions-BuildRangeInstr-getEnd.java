public Operand getEnd(){
  return getOperand2();
}
