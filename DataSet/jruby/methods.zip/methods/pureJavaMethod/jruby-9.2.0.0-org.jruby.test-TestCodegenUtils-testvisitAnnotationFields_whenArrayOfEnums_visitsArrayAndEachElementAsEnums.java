public void testvisitAnnotationFields_whenArrayOfEnums_visitsArrayAndEachElementAsEnums(){
  SimpleEnum[] simpleEnums={SimpleEnum.FirstValue,SimpleEnum.SecondValue};
  fields.put("myEnum",simpleEnums);
  CodegenUtils.visitAnnotationFields(logger,fields);
  assertEquals(4,logger.getEventList().size());
  List<Event> expectedEventList=Arrays.asList(new VisitArrayEvent("myEnum"),new VisitEnumEvent(null,ci(SimpleEnum.class),SimpleEnum.FirstValue.name()),new VisitEnumEvent(null,ci(SimpleEnum.class),SimpleEnum.SecondValue.name()),new VisitEndEvent());
  assertEquals(expectedEventList,logger.getEventList());
}
