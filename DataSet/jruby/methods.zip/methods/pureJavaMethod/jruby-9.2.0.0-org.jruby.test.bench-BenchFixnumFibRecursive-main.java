public static void main(String[] args){
  int times=5;
  int n=35;
  if (args.length >= 1) {
    times=Integer.parseInt(args[0]);
    if (args.length >= 2) {
      n=Integer.parseInt(args[1]);
    }
  }
  for (int j=0; j < times; j++) {
    benchFixnumFib(n);
  }
}
