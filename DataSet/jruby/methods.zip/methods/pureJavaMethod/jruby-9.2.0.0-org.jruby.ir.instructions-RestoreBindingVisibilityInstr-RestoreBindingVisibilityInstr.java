public RestoreBindingVisibilityInstr(Operand viz){
  super(Operation.RESTORE_BINDING_VIZ,viz);
}
