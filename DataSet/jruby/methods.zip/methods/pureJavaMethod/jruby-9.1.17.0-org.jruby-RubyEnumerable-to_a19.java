@Deprecated public static IRubyObject to_a19(ThreadContext context,IRubyObject self,IRubyObject[] args){
  return to_a(context,self,args);
}
