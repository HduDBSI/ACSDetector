public void reset(long backup){
  stack=backup;
}
