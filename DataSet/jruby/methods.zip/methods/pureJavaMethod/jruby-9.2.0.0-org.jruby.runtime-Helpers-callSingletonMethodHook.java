private static void callSingletonMethodHook(IRubyObject receiver,ThreadContext context,RubySymbol name){
  receiver.callMethod(context,"singleton_method_added",name);
}
