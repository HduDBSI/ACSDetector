public BranchInstr(Operation op){
  super(op);
}
