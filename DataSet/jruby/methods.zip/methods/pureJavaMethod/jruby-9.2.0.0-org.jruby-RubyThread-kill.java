@JRubyMethod(name={"kill","exit","terminate"}) public IRubyObject kill(){
  Ruby runtime=getRuntime();
  RubyThread currentThread=runtime.getCurrentContext().getThread();
  if (currentThread == runtime.getThreadService().getMainThread()) {
  }
  status.set(Status.ABORTING);
  return genericKill(runtime,currentThread);
}
