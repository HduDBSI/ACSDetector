@Override public Object retrieve(ThreadContext context,IRubyObject self,StaticScope currScope,DynamicScope currDynScope,Object[] temp){
  return array.retrieve(context,self,currScope,currDynScope,temp);
}
