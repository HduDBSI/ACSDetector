@JRubyMethod(name="step") public IRubyObject step(final ThreadContext context,IRubyObject step,final Block block){
  String method="step";
  if (!block.isGiven()) {
    return stepEnumeratorize(context,step,method);
  }
  step=checkStepDomain(context,step,method);
  return stepCommon(context,step,block);
}
