public static IRubyObject read(ThreadContext context,IRubyObject recv,IRubyObject[] args){
  return read(context,recv,args,Block.NULL_BLOCK);
}
