/** 
 * Retrieves class variables from Ruby after the evaluation.
 * @param runtime Ruby runtime
 * @param receiver receiver object returned when a script is evaluated.
 * @param vars map to save retrieved class variables.
 */
public static void retrieve(final RubyObject receiver,final BiVariableMap vars){
  if (vars.isLazy())   return;
  updateClassVar(receiver,vars);
  updateClassVar(getTopSelf(receiver),vars);
}
