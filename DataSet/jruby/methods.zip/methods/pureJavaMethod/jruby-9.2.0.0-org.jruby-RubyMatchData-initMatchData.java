final void initMatchData(final ThreadContext context,RubyString str,int beg,RubyString pattern){
  this.regs=null;
  this.begin=beg;
  this.end=beg + pattern.size();
  this.pattern=pattern.newFrozen();
  this.regexp=null;
  this.charOffsets=null;
  this.charOffsetUpdated=false;
  this.str=str.newFrozen();
  this.infectBy(str);
}
