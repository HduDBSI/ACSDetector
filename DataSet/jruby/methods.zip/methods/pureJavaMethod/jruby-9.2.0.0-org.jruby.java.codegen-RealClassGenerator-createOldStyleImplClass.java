public static Class createOldStyleImplClass(Class[] superTypes,RubyClass rubyClass,Ruby ruby,String name,ClassDefiningClassLoader classLoader){
  String[] superTypeNames=new String[superTypes.length];
  Map<String,List<Method>> simpleToAll=buildSimpleToAllMap(superTypes,superTypeNames,rubyClass);
  Class newClass=defineOldStyleImplClass(ruby,name,superTypeNames,simpleToAll,classLoader);
  return newClass;
}
