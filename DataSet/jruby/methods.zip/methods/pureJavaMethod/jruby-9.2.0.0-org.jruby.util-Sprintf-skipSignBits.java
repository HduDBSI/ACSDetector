private static int skipSignBits(byte[] bytes,int base){
  int skip=0;
  int length=bytes.length;
  byte b;
switch (base) {
case 2:
    for (; skip < length && bytes[skip] == '1'; skip++) {
    }
  break;
case 8:
if (length > 0 && bytes[0] == '3') skip++;
for (; skip < length && bytes[skip] == '7'; skip++) {
}
break;
case 10:
if (length > 0 && bytes[0] == '-') skip++;
break;
case 16:
for (; skip < length && ((b=bytes[skip]) == 'f' || b == 'F'); skip++) {
}
}
return skip;
}
