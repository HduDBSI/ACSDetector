@BeforeClass public static void setupClassLoader(){
  cl=Thread.currentThread().getContextClassLoader();
  ClassLoader c=new URLClassLoader(new URL[]{},null);
  try {
    c.loadClass("org.jruby.embed.ScriptingContainer");
    fail("this classloader shall not find jruby");
  }
 catch (  ClassNotFoundException expected) {
  }
  Thread.currentThread().setContextClassLoader(c);
}
