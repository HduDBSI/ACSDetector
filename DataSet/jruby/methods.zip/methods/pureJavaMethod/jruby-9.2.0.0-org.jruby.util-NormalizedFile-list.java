@Override public String[] list(FilenameFilter filter){
  String[] files=super.list(filter);
  if (files == null) {
    return null;
  }
 else {
    String[] smartFiles=new String[files.length];
    for (int i=0; i < files.length; i++) {
      smartFiles[i]=files[i].replace(File.separatorChar,'/');
    }
    return smartFiles;
  }
}
