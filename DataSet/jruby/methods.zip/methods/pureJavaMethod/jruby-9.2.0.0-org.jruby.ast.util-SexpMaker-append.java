@Override public Builder append(double d){
  append(Double.doubleToLongBits(d));
  return this;
}
