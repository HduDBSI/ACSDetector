/** 
 * Given a Ruby string, cache a frozen, duplicated copy of it, or find an existing copy already prepared. This is used to reduce in-memory duplication of pre-frozen or known-frozen strings. Note that this cache does some sync against the Ruby instance. This could cause contention under heavy concurrent load, so a reexamination of this design might be warranted. Because RubyString.equals does not consider encoding, and MRI's logic for deduplication does need to consider encoding, we use a wrapper object as the key. These wrappers need to be used on all get operations, so if we don't need to insert anything we reuse that wrapper the next time. The logic here reads like this: 1. If the string is not a natural String object, just freeze and return it. 2. Use the wrapper from the thread-local cache or create and set a new one. 3. Use the wrapper to look up the deduplicated string. 4. If there's a dedup in the cache, clear the wrapper for next time and return the dedup. 5. Remove the wrapper from the threadlocal to avoid reusing it, since we'll insert it. 6. Atomically set the new entry or repair the GCed entry that already exists. 7. Return the newly-deduplicated string.
 * @param string the string to freeze-dup if an equivalent does not already exist
 * @return the freeze-duped version of the string
 */
public RubyString freezeAndDedupString(RubyString string){
  if (!string.isBare(this)) {
    string.setFrozen(true);
    return string;
  }
  FStringEqual wrapper=DEDUP_WRAPPER_CACHE.get();
  wrapper.string=string;
  WeakReference<RubyString> dedupedRef=dedupMap.get(wrapper);
  RubyString deduped;
  if (dedupedRef == null || (deduped=dedupedRef.get()) == null) {
    DEDUP_WRAPPER_CACHE.remove();
    deduped=string.strDup(this);
    deduped.setFrozen(true);
    final WeakReference<RubyString> weakref=new WeakReference<>(deduped);
    wrapper.string=deduped;
    dedupedRef=dedupMap.computeIfAbsent(wrapper,key -> weakref);
    if (dedupedRef == null)     return deduped;
    RubyString unduped=dedupedRef.get();
    if (unduped != null)     return unduped;
    while (true) {
      wrapper.string=string;
      dedupedRef=dedupMap.computeIfPresent(wrapper,(key,old) -> old.get() == null ? weakref : old);
      unduped=dedupedRef.get();
      if (unduped != null)       return unduped;
    }
  }
 else {
    wrapper.string=null;
  }
  return deduped;
}
