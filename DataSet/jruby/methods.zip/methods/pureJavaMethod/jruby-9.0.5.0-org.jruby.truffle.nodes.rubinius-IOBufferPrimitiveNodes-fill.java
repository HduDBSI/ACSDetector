@Specialization public int fill(VirtualFrame frame,DynamicObject ioBuffer,DynamicObject io){
  final int fd=Layouts.IO.getDescriptor(io);
  final byte[] readBuffer=new byte[STACK_BUF_SZ];
  int count=STACK_BUF_SZ;
  if (left(frame,ioBuffer) < count) {
    count=left(frame,ioBuffer);
  }
  int bytesRead=performFill(fd,readBuffer,count);
  if (bytesRead > 0) {
    if (bytesRead > left(frame,ioBuffer)) {
      CompilerDirectives.transferToInterpreter();
      throw new RaiseException(getContext().getCoreLibrary().internalError("IO buffer overrun",this));
    }
    final int used=Layouts.IO_BUFFER.getUsed(ioBuffer);
    final ByteList storage=Layouts.BYTE_ARRAY.getBytes(Layouts.IO_BUFFER.getStorage(ioBuffer));
    System.arraycopy(readBuffer,0,storage.getUnsafeBytes(),storage.getBegin() + used,bytesRead);
    storage.setRealSize(used + bytesRead);
    Layouts.IO_BUFFER.setUsed(ioBuffer,used + bytesRead);
  }
  return bytesRead;
}
