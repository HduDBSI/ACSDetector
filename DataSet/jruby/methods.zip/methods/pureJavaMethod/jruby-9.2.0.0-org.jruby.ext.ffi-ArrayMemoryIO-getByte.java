public final byte getByte(long offset){
  checkBounds(offset,1);
  return (byte)(buffer[index(offset)] & 0xff);
}
