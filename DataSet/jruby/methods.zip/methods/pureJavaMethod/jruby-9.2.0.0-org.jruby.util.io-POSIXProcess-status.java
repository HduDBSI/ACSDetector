public int status(){
  try {
    waitFor();
  }
 catch (  InterruptedException ie) {
    throw new IllegalThreadStateException();
  }
  return status == null ? -1 : status;
}
