public void resetWriter(){
  PrintStream pstream=provider.getRubyInstanceConfig().getOutput();
  setOutputStream(pstream);
}
