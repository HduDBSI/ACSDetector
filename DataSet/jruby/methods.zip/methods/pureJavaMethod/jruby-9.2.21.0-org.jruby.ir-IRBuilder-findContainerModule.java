private Operand findContainerModule(){
  int nearestModuleBodyDepth=scope.getNearestModuleReferencingScopeDepth();
  return (nearestModuleBodyDepth == -1) ? getCurrentModuleVariable() : ScopeModule.ModuleFor(nearestModuleBodyDepth);
}
