/** 
 * Returns a ProfilingMode currently used. The default value is ProfilingMode.OFF.
 * @since JRuby 1.6.6.
 * @return a current profiling mode.
 */
public ProfilingMode getProfilingMode(){
  return provider.getRubyInstanceConfig().getProfilingMode();
}
