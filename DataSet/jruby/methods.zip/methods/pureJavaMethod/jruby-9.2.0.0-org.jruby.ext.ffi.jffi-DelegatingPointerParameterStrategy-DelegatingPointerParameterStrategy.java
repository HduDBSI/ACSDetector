public DelegatingPointerParameterStrategy(IRubyObject value,PointerParameterStrategy strategy){
  super(strategy.isDirect(),strategy.isReferenceRequired(),OBJECT_TYPE);
  this.value=value;
  this.strategy=strategy;
}
