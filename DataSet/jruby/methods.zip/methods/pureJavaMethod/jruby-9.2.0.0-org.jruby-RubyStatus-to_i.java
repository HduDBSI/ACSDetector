@Deprecated public IRubyObject to_i(){
  return to_i(getRuntime());
}
