/** 
 * Test of parse method, of class ScriptingContainer.
 */
@Test public void testParse_3args_2(){
  logger1.info("parse(type, filename, lines)");
  PathType type=null;
  String filename="";
  int[] lines=null;
  String[] paths={basedir + "/lib",basedir + "/lib/ruby/stdlib"};
  ScriptingContainer instance=new ScriptingContainer(LocalContextScope.THREADSAFE);
  instance.setLoadPaths(Arrays.asList(paths));
  instance.setError(pstream);
  instance.setOutput(pstream);
  instance.setWriter(writer);
  instance.setErrorWriter(writer);
  EmbedEvalUnit result;
  try {
    result=instance.parse(type,filename,lines);
  }
 catch (  Throwable t) {
    assertTrue(t.getCause() instanceof FileNotFoundException);
    t.printStackTrace(new PrintStream(outStream));
  }
  filename=basedir + "/core/src/test/ruby/org/jruby/embed/ruby/next_year.rb";
  result=instance.parse(PathType.ABSOLUTE,filename);
  IRubyObject ret=result.run();
  assertEquals(getNextYear(),(int)ret.toJava(Integer.class));
  StringWriter sw=new StringWriter();
  instance.setWriter(sw);
  String[] planets={"Mercury","Venus","Earth","Mars","Jupiter","Saturn","Uranus","Neptune"};
  instance.put("@list",Arrays.asList(planets));
  filename="/src/test/ruby/org/jruby/embed/ruby/list_printer.rb";
  result=instance.parse(PathType.RELATIVE,filename);
  ret=result.run();
  String expResult="Mercury >> Venus >> Earth >> Mars >> Jupiter >> Saturn >> Uranus >> Neptune: 8 in total";
  assertEquals(expResult,sw.toString().trim());
  sw=new StringWriter();
  instance.setWriter(sw);
  instance.setAttribute(AttributeName.UNICODE_ESCAPE,true);
  planets=new String[]{"水星","金星","地球","火星","木星","土星","天王星","海王星"};
  instance.put("@list",Arrays.asList(planets));
  filename="src/test/ruby/org/jruby/embed/ruby/list_printer.rb";
  result=instance.parse(PathType.RELATIVE,filename);
  ret=result.run();
  expResult="水星 >> 金星 >> 地球 >> 火星 >> 木星 >> 土星 >> 天王星 >> 海王星: 8 in total";
  assertEquals(expResult,sw.toString().trim());
  filename="src/test/ruby/org/jruby/embed/ruby/raises_parse_error.rb";
  sw=new StringWriter();
  instance.setErrorWriter(sw);
  try {
    instance.parse(PathType.RELATIVE,filename,2);
  }
 catch (  Exception e) {
    logger1.info(sw.toString());
    assertTrue(sw.toString().contains(filename + ":7:"));
  }
  instance.getVarMap().clear();
  instance.terminate();
}
