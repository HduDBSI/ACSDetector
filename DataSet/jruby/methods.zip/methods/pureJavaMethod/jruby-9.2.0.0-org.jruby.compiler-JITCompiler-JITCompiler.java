public JITCompiler(Ruby runtime){
  this.runtime=runtime;
  this.config=runtime.getInstanceConfig();
  this.executor=new ThreadPoolExecutor(0,2,60,TimeUnit.SECONDS,new LinkedBlockingQueue<Runnable>(),new DaemonThreadFactory("Ruby-" + runtime.getRuntimeNumber() + "-JIT",Thread.MIN_PRIORITY));
}
