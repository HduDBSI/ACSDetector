@JRubyMethod(name="scrub!") public IRubyObject scrub_bang(ThreadContext context,IRubyObject repl,Block block){
  IRubyObject newStr=strScrub(context,repl,block);
  if (!newStr.isNil())   return replace(newStr);
  return this;
}
