SymbolEntry(int hash,String name,ByteList bytes,RubySymbol symbol,SymbolEntry next,boolean hard){
  this.hash=hash;
  this.name=name;
  this.bytes=bytes;
  this.symbol=new WeakReference<RubySymbol>(symbol);
  this.next=next;
  if (hard)   hardReference=symbol;
}
