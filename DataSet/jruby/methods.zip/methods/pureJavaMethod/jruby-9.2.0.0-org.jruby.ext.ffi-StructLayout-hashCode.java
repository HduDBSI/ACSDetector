@Override public int hashCode(){
  int result=super.hashCode();
  result=31 * result + type.hashCode();
  result=31 * result + offset;
  return result;
}
