@Override protected IRubyObject doYield(ThreadContext context,Block block,IRubyObject[] args,IRubyObject self){
  throw context.runtime.newLocalJumpError(RubyLocalJumpError.Reason.NOREASON,args[0],"yield called out of block");
}
