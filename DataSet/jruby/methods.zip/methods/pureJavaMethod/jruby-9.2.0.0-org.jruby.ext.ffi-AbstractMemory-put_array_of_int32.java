/** 
 * Writes an array of signed 32 bit integer values to the memory area.
 * @param offset The offset from the start of the memory area to write the values.
 * @param length The number of values to be written to memory.
 * @return <tt>this</tt> object.
 */
@JRubyMethod(name={"put_array_of_int32","put_array_of_int"},required=2) public IRubyObject put_array_of_int32(ThreadContext context,IRubyObject offset,IRubyObject arrParam){
  MemoryUtil.putArrayOfSigned32(context.runtime,getMemoryIO(),getOffset(offset),checkArray(arrParam));
  return this;
}
