@JRubyMethod(name="linux?",module=true) public static IRubyObject linux_p(ThreadContext context,IRubyObject recv){
  return context.runtime.newBoolean(OS == OS.LINUX);
}
