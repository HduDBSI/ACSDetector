protected AbstractMemory slice(Ruby runtime,long offset,long size){
  return new Buffer(runtime,getMetaClass(),getMemoryIO().slice(offset,size),size,this.typeSize,this.inout);
}
