@Override public void CheckArgsArrayArityInstr(CheckArgsArrayArityInstr checkargsarrayarityinstr){
  jvmMethod().loadContext();
  visit(checkargsarrayarityinstr.getArgsArray());
  jvmAdapter().pushInt(checkargsarrayarityinstr.required);
  jvmAdapter().pushInt(checkargsarrayarityinstr.opt);
  jvmAdapter().pushBoolean(checkargsarrayarityinstr.rest);
  jvmMethod().invokeStatic(Type.getType(Helpers.class),Method.getMethod("void irCheckArgsArrayArity(org.jruby.runtime.ThreadContext, org.jruby.RubyArray, int, int, boolean)"));
}
