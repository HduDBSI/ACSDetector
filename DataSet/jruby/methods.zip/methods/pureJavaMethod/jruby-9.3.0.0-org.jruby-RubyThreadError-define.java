static RubyClass define(Ruby runtime,RubyClass exceptionClass){
  RubyClass threadErrorClass=runtime.defineClass("ThreadError",exceptionClass,RubyThreadError::new);
  return threadErrorClass;
}
