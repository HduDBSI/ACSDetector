private static InputStream getContents(String file) throws IOException {
  return new LoadServiceResourceInputStream(new FileInputStream(file));
}
