Metadata(String name,int blockLength){
  this.name=name;
  this.blockLength=blockLength;
}
