public static RubyUnboundMethod newUnboundMethod(RubyModule implementationModule,String methodName,RubyModule originModule,String originName,DynamicMethod method){
  RubyUnboundMethod newMethod=new RubyUnboundMethod(implementationModule.getRuntime());
  newMethod.implementationModule=implementationModule;
  newMethod.methodName=methodName;
  newMethod.originModule=originModule;
  newMethod.originName=originName;
  newMethod.method=method;
  return newMethod;
}
