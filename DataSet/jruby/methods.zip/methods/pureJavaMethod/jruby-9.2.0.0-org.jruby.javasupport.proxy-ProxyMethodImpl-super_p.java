@JRubyMethod(name="super?") public IRubyObject super_p(){
  return hasSuperImplementation() ? getRuntime().getTrue() : getRuntime().getFalse();
}
