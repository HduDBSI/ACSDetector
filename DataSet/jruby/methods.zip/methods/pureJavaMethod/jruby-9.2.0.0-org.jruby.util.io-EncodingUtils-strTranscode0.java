public static Encoding strTranscode0(ThreadContext context,int argc,IRubyObject[] args,IRubyObject[] self_p,int ecflags,IRubyObject ecopts){
  Ruby runtime=context.runtime;
  IRubyObject str=self_p[0];
  IRubyObject arg1, arg2;
  Encoding[] senc_p={null}, denc_p={null};
  byte[][] sname_p={null}, dname_p={null};
  Encoding dencindex;
  boolean explicitlyInvalidReplace=true;
  if (argc > 2) {
    throw context.runtime.newArgumentError(args.length,2);
  }
  if (argc == 0) {
    arg1=runtime.getEncodingService().getDefaultInternal();
    if (arg1 == null || arg1.isNil()) {
      if (ecflags == 0)       return null;
      arg1=objEncoding(context,str);
    }
    if ((ecflags & EConvFlags.INVALID_MASK) == 0) {
      explicitlyInvalidReplace=false;
    }
    ecflags|=EConvFlags.INVALID_REPLACE | EConvFlags.UNDEF_REPLACE;
  }
 else {
    arg1=args[0];
  }
  arg2=argc <= 1 ? context.nil : args[1];
  dencindex=strTranscodeEncArgs(context,str,arg1,arg2,sname_p,senc_p,dname_p,denc_p);
  IRubyObject dest;
  if ((ecflags & (EConvFlags.NEWLINE_DECORATOR_MASK | EConvFlags.XML_TEXT_DECORATOR | EConvFlags.XML_ATTR_CONTENT_DECORATOR| EConvFlags.XML_ATTR_QUOTE_DECORATOR)) == 0) {
    if (senc_p[0] != null && senc_p[0] == denc_p[0]) {
      if ((ecflags & EConvFlags.INVALID_MASK) != 0 && explicitlyInvalidReplace) {
        IRubyObject rep=context.nil;
        if (!ecopts.isNil()) {
          rep=((RubyHash)ecopts).op_aref(context,runtime.newSymbol("replace"));
        }
        dest=((RubyString)str).scrub(context,rep,Block.NULL_BLOCK);
        if (dest.isNil())         dest=str;
        self_p[0]=dest;
        return dencindex;
      }
      return arg2.isNil() ? null : dencindex;
    }
 else     if (senc_p[0] != null && denc_p[0] != null && senc_p[0].isAsciiCompatible() && denc_p[0].isAsciiCompatible()) {
      if (((RubyString)str).scanForCodeRange() == StringSupport.CR_7BIT) {
        return dencindex;
      }
    }
    if (encodingEqual(sname_p[0],dname_p[0])) {
      return arg2.isNil() ? null : dencindex;
    }
  }
 else {
    if (encodingEqual(sname_p[0],dname_p[0])) {
      sname_p[0]=NULL_BYTE_ARRAY;
      dname_p[0]=NULL_BYTE_ARRAY;
    }
  }
  ByteList sp=((RubyString)str).getByteList();
  ByteList fromp=sp;
  int slen=((RubyString)str).size();
  int blen=slen + 30;
  dest=RubyString.newStringLight(runtime,blen);
  ByteList destp=((RubyString)dest).getByteList();
  byte[] frompBytes=fromp.unsafeBytes();
  byte[] destpBytes=destp.unsafeBytes();
  Ptr frompPos=new Ptr(fromp.getBegin());
  Ptr destpPos=new Ptr(destp.getBegin());
  transcodeLoop(context,frompBytes,frompPos,destpBytes,destpPos,frompPos.p + slen,destpPos.p + blen,destp,strTranscodingResize,sname_p[0],dname_p[0],ecflags,ecopts);
  if (frompPos.p != sp.begin() + slen) {
    throw runtime.newArgumentError("not fully converted, " + (slen - frompPos.p) + " bytes left");
  }
  if (denc_p[0] == null) {
    dencindex=defineDummyEncoding(context,dname_p[0]);
  }
  self_p[0]=dest;
  return dencindex;
}
