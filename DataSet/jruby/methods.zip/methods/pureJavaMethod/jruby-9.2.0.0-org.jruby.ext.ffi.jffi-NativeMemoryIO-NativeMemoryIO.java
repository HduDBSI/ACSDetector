private NativeMemoryIO(NativeMemoryIO parent,long offset){
  super(true,parent.address + offset);
  this.parent=parent;
  this.runtime=parent.runtime;
}
