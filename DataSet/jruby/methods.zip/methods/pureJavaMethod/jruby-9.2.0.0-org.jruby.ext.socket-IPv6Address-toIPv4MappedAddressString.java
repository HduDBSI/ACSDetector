private String toIPv4MappedAddressString(){
  int byteZero=(int)((this.lowBits & 0x00000000FF000000L) >> 24);
  int byteOne=(int)((this.lowBits & 0x0000000000FF0000L) >> 16);
  int byteTwo=(int)((this.lowBits & 0x000000000000FF00L) >> 8);
  int byteThree=(int)((this.lowBits & 0x00000000000000FFL));
  final StringBuilder result=new StringBuilder("::ffff:");
  result.append(byteZero).append(".").append(byteOne).append(".").append(byteTwo).append(".").append(byteThree);
  return result.toString();
}
