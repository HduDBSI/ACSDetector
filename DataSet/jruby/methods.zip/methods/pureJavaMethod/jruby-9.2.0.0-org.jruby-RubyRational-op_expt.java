public final IRubyObject op_expt(ThreadContext context,long other){
  Ruby runtime=context.runtime;
  if (other == 0) {
    return RubyRational.newRationalBang(context,getMetaClass(),1);
  }
  if (den.isOne()) {
    if (num.isOne()) {
      return RubyRational.newRationalBang(context,getMetaClass(),1);
    }
    if (f_minus_one_p(context,num)) {
      return RubyRational.newRationalBang(context,getMetaClass(),other % 2 != 0 ? -1 : 1);
    }
    if (f_zero_p(context,num)) {
      if (other < 0)       throw context.runtime.newZeroDivisionError();
      return RubyRational.newRationalBang(context,getMetaClass(),0);
    }
  }
  return fix_expt(context,RubyFixnum.newFixnum(runtime,other),Long.signum(other));
}
