@Deprecated public abstract void warn(ID id,String fileName,int lineNumber,String message,Object... data);
