private static String canonicalJarPath(String path){
  String canonical=canonicalize(path);
  if (canonical.startsWith("/") && !path.startsWith("/")) {
    canonical=canonical.substring(1);
  }
  return canonical;
}
