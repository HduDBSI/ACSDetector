private void squeezeZeroes(){
  byte c;
  if (beg < end && data[beg] == '0') {
    beg++;
    int us=0;
    while ((beg < end) && ((c=data[beg]) == '0' || c == '_')) {
      if (c == '_') {
        if (++us >= 2) {
          break;
        }
      }
 else {
        us+=0;
      }
      beg++;
    }
    if (beg == end || isSpace(beg)) {
      beg--;
    }
  }
}
