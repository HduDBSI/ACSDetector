/** 
 * Get a java.nio Charset for the given encoding, or null if impossible
 * @param encoding the encoding
 * @return the charset
 */
public Charset charsetForEncoding(Encoding encoding){
  if (encoding.toString().equals("ASCII-8BIT")) {
    return Charset.forName("ISO-8859-1");
  }
  if (encoding == ISO8859_16Encoding.INSTANCE) {
    return ISO_8859_16.INSTANCE;
  }
  try {
    return Charset.forName(encoding.toString());
  }
 catch (  UnsupportedCharsetException uce) {
    throw runtime.newEncodingCompatibilityError("no java.nio.charset.Charset found for encoding `" + encoding.toString() + "'");
  }
}
