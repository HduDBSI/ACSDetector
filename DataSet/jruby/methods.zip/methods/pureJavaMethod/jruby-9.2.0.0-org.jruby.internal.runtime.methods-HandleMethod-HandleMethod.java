public HandleMethod(RubyModule implementationClass,Visibility visibility,String name,long encodedSignature,boolean builtin,boolean notImplemented,String parameterDesc,final int min,final int max,final Callable<MethodHandle> maker0,final Callable<MethodHandle> maker1,final Callable<MethodHandle> maker2,final Callable<MethodHandle> maker3,final Callable<MethodHandle> maker4){
  super(implementationClass,visibility,name);
  this.signature=Signature.decode(encodedSignature);
  this.builtin=builtin;
  this.notImplemented=notImplemented;
  this.parameterDesc=parameterDesc;
  this.min=min;
  this.max=max;
  this.maker0=maker0;
  this.maker1=maker1;
  this.maker2=maker2;
  this.maker3=maker3;
  this.maker4=maker4;
}
