public final void fastASet(Ruby runtime,IRubyObject key,IRubyObject value,boolean prepareString){
  if (prepareString) {
    fastASetCheckString(runtime,key,value);
  }
 else {
    fastASet(key,value);
  }
}
