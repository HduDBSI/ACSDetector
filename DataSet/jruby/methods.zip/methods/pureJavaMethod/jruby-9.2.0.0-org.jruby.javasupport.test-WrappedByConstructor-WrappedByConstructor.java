public WrappedByConstructor(Runnable r){
  this.r=r;
}
