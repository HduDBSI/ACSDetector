public static IRubyObject asetDirect(Ruby runtime,Object array,JavaUtil.JavaConverter javaConverter,int index,IRubyObject value){
  try {
    javaConverter.set(runtime,array,index,value);
  }
 catch (  IndexOutOfBoundsException e) {
    throw mapIndexOutOfBoundsException(runtime,array,index);
  }
catch (  ArrayStoreException e) {
    throw mapArrayStoreException(runtime,array,value.getClass());
  }
catch (  IllegalArgumentException e) {
    throw mapIllegalArgumentException(runtime,array,value.getClass());
  }
  return value;
}
