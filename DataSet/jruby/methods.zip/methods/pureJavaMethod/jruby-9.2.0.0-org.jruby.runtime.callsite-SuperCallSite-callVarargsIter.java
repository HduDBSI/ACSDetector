public IRubyObject callVarargsIter(ThreadContext context,IRubyObject caller,IRubyObject self,IRubyObject[] args,Block block){
switch (args.length) {
case 0:
    return callIter(context,caller,self,block);
case 1:
  return callIter(context,caller,self,args[0],block);
case 2:
return callIter(context,caller,self,args[0],args[1],block);
case 3:
return callIter(context,caller,self,args[0],args[1],args[2],block);
default :
return callIter(context,caller,self,args,block);
}
}
