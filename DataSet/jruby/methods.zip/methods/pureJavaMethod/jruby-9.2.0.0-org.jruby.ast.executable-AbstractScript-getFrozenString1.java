public final RubyString getFrozenString1(ThreadContext context,int j,int codeRange){
  return runtimeCache.getFrozenString(context,1,j,codeRange);
}
