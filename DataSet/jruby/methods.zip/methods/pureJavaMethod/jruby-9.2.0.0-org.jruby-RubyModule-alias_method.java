@JRubyMethod(name="alias_method",required=2) public RubyModule alias_method(ThreadContext context,IRubyObject newId,IRubyObject oldId){
  RubySymbol newSym=TypeConverter.checkID(newId);
  RubySymbol oldSym=TypeConverter.checkID(oldId);
  defineAlias(newSym.idString(),oldSym.idString());
  if (isSingleton()) {
    ((MetaClass)this).getAttached().callMethod(context,"singleton_method_added",newSym);
  }
 else {
    callMethod(context,"method_added",newSym);
  }
  return this;
}
