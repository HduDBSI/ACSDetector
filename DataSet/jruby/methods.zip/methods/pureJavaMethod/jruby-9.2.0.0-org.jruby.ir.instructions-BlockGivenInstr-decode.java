public static BlockGivenInstr decode(IRReaderDecoder d){
  return new BlockGivenInstr(d.decodeVariable(),d.decodeOperand());
}
