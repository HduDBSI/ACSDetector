public void event(ThreadContext context,RubyEvent event,String file,int line,String name,IRubyObject type){
  eventHandler(context,event.getName(),file,line + event.getLineNumberOffset(),name,type);
}
