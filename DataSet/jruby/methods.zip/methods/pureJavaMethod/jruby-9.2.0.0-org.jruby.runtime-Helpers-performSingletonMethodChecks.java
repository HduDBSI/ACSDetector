public static RubyClass performSingletonMethodChecks(Ruby runtime,IRubyObject receiver,String name) throws RaiseException {
  if (receiver instanceof RubyFixnum || receiver instanceof RubySymbol) {
    throw runtime.newTypeError(str(runtime,"can't define singleton method \"",ids(runtime,name),"\" for ",types(runtime,receiver.getMetaClass())));
  }
  if (receiver.isFrozen()) {
    throw runtime.newFrozenError("object");
  }
  RubyClass rubyClass=receiver.getSingletonClass();
  return rubyClass;
}
