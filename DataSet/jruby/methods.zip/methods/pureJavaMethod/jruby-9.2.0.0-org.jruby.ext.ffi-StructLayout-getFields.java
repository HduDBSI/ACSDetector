public final java.util.Collection<Field> getFields(){
  return fields;
}
