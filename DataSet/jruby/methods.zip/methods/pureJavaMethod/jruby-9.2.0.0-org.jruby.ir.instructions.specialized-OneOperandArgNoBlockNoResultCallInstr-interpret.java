@Override public Object interpret(ThreadContext context,StaticScope currScope,DynamicScope dynamicScope,IRubyObject self,Object[] temp){
  IRubyObject object=(IRubyObject)getReceiver().retrieve(context,self,currScope,dynamicScope,temp);
  IRubyObject arg1=(IRubyObject)getArg1().retrieve(context,self,currScope,dynamicScope,temp);
  return getCallSite().call(context,self,object,arg1);
}
