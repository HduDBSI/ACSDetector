public RescueModNode(ISourcePosition position,Node bodyNode,RescueBodyNode rescueNode){
  super(position,bodyNode,rescueNode,null);
}
