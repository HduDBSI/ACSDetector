public static RubyClass createSymbolClass(Ruby runtime){
  RubyClass symbolClass=runtime.defineClass("Symbol",runtime.getObject(),ObjectAllocator.NOT_ALLOCATABLE_ALLOCATOR);
  runtime.setSymbol(symbolClass);
  RubyClass symbolMetaClass=symbolClass.getMetaClass();
  symbolClass.setClassIndex(ClassIndex.SYMBOL);
  symbolClass.setReifiedClass(RubySymbol.class);
  symbolClass.kindOf=new RubyModule.JavaClassKindOf(RubySymbol.class);
  symbolClass.defineAnnotatedMethods(RubySymbol.class);
  symbolMetaClass.undefineMethod("new");
  symbolClass.includeModule(runtime.getComparable());
  return symbolClass;
}
