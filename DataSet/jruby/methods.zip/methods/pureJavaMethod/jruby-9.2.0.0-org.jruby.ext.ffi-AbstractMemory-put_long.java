/** 
 * Writes a C long integer value to the memory area.
 * @param offset The offset from the base pointer address to write the value.
 * @param value The value to write.
 * @return The value written.
 */
@JRubyMethod(name="put_long",required=2) public IRubyObject put_long(ThreadContext context,IRubyObject offset,IRubyObject value){
  return Platform.getPlatform().longSize() == 32 ? put_int32(context,offset,value) : put_int64(context,offset,value);
}
