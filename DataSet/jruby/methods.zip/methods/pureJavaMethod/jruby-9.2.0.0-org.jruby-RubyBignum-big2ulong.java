/** 
 * rb_big2ulong This is here because for C extensions ulong can hold different values without throwing a RangeError
 */
public static long big2ulong(RubyBignum value){
  BigInteger big=value.getValue();
  if (big.compareTo(LONG_MIN) <= 0 || big.compareTo(ULONG_MAX) > 0) {
    throw value.getRuntime().newRangeError("bignum too big to convert into `ulong'");
  }
  return value.getValue().longValue();
}
