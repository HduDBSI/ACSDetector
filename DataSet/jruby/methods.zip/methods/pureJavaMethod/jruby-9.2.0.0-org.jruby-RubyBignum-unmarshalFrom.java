public static RubyNumeric unmarshalFrom(UnmarshalStream input) throws IOException {
  boolean positive=input.readUnsignedByte() == '+';
  int shortLength=input.unmarshalInt();
  byte[] digits=new byte[shortLength * 2 + 1];
  for (int i=digits.length - 1; i >= 1; i--) {
    digits[i]=input.readSignedByte();
  }
  BigInteger value=new BigInteger(digits);
  if (!positive) {
    value=value.negate();
  }
  RubyNumeric result=bignorm(input.getRuntime(),value);
  input.registerLinkTarget(result);
  return result;
}
