public static final long uint64Value(IRubyObject parameter){
  final long value=parameter instanceof RubyBignum ? ((RubyBignum)parameter).getValue().longValue() : longValue(parameter);
  return value;
}
