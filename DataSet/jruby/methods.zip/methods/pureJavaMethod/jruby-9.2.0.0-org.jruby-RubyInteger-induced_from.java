/** 
 * rb_int_induced_from
 */
@Deprecated public static IRubyObject induced_from(ThreadContext context,IRubyObject recv,IRubyObject other){
  if (other instanceof RubyFixnum || other instanceof RubyBignum) {
    return other;
  }
 else   if (other instanceof RubyFloat || other instanceof RubyRational) {
    return other.callMethod(context,"to_i");
  }
 else {
    throw recv.getRuntime().newTypeError("failed to convert " + other.getMetaClass().getName() + " into Integer");
  }
}
