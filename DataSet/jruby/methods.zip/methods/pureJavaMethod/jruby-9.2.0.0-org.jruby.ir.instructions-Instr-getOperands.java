public abstract Operand[] getOperands();
