public static String getRubyTimeZoneName(String envTZ,DateTime dt){
  if (SHORT_STD_TZNAME.containsKey(envTZ) && !dt.getZone().toTimeZone().inDaylightTime(dt.toDate())) {
    return SHORT_STD_TZNAME.get(envTZ);
  }
  if (SHORT_DL_TZNAME.containsKey(envTZ) && dt.getZone().toTimeZone().inDaylightTime(dt.toDate())) {
    return SHORT_DL_TZNAME.get(envTZ);
  }
  String zone=dt.getZone().getShortName(dt.getMillis());
  Matcher offsetMatcher=TIME_OFFSET_PATTERN.matcher(zone);
  if (offsetMatcher.matches()) {
    if (zone.equals("+00:00")) {
      zone="UTC";
    }
 else {
      zone=dt.getZone().getNameKey(dt.getMillis());
      if (zone == null) {
        zone="";
      }
    }
  }
  return zone;
}
