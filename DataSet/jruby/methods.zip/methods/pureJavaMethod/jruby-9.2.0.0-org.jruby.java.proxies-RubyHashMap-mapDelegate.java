private Map mapDelegate(){
  return receiver.getMapObject();
}
