public static Encoding ascii8bitEncoding(Ruby runtime){
  return runtime.getEncodingService().getAscii8bitEncoding();
}
