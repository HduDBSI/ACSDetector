private static void invokeCCallTrace(SkinnyMethodAdapter method,int traceBoolIndex){
  method.aloadMany(0,1);
  method.iload(traceBoolIndex);
  method.aload(4);
  method.invokevirtual(p(JavaMethod.class),"callTrace",sig(void.class,ThreadContext.class,boolean.class,String.class));
}
