protected void visitChildren(Node node){
  for (  Node child : node.childNodes()) {
    if (child != null) {
      child.accept(this);
    }
  }
}
