private static boolean isPrintable(byte aChar){
  return (aChar > 32 && aChar < 127);
}
