public final void putInt32(byte[] buffer,int offset,int value){
  buffer[offset + 0]=(byte)(value >> 24);
  buffer[offset + 1]=(byte)(value >> 16);
  buffer[offset + 2]=(byte)(value >> 8);
  buffer[offset + 3]=(byte)(value >> 0);
}
