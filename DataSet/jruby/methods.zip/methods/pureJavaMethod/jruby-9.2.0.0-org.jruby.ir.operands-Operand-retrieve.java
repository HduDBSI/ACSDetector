@Interp public Object retrieve(ThreadContext context,IRubyObject self,StaticScope currScope,DynamicScope currDynScope,Object[] temp){
  throw new RuntimeException(this.getClass().getSimpleName() + " should not be directly retrieved.");
}
