public UnresolvedSuperInstr(IRScope scope,Variable result,Operand receiver,Operand[] args,Operand closure,boolean isPotentiallyRefined){
  this(scope,Operation.UNRESOLVED_SUPER,result,receiver,args,closure,isPotentiallyRefined);
}
