/** 
 */
public InvokeDynamicMethodFactory(ClassLoader classLoader){
  super(classLoader);
}
