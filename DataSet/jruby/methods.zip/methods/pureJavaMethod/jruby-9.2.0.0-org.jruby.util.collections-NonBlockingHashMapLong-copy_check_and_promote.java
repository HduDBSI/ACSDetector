private final void copy_check_and_promote(int workdone){
  int oldlen=_keys.length;
  long copyDone=_copyDone;
  long nowDone=copyDone + workdone;
  assert nowDone <= oldlen;
  if (workdone > 0) {
    while (!_copyDoneUpdater.compareAndSet(this,copyDone,nowDone)) {
      copyDone=_copyDone;
      nowDone=copyDone + workdone;
      assert nowDone <= oldlen;
    }
  }
  if (nowDone == oldlen && _nbhml._chm == this && _nbhml.CAS_chm(this,_newchm)) {
    _nbhml._last_resize_milli=System.currentTimeMillis();
  }
}
