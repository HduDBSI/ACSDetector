public boolean getSync(){
  RubyIO io=GetWriteIO();
  OpenFile fptr=io.getOpenFileChecked();
  return fptr.isSync();
}
