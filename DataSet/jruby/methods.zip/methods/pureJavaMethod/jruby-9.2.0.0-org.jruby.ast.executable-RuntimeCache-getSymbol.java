public final RubySymbol getSymbol(ThreadContext context,int index,String name,String encodingName){
  RubySymbol symbol=symbols[index];
  if (symbol == null) {
    symbol=context.runtime.newSymbol(name);
    if (encodingName != null) {
      symbol.associateEncoding(EncodingDB.getEncodings().get(encodingName.getBytes()).getEncoding());
    }
    symbols[index]=symbol;
  }
  return symbol;
}
