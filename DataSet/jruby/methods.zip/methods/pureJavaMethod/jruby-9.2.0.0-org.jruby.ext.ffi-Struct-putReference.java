public void putReference(StructLayout.Member member,Object value){
  getReferenceCache()[layout.getReferenceFieldIndex(member)]=value;
}
