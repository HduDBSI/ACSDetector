@JRubyMethod public IRubyObject sleep(ThreadContext context,IRubyObject timeout){
  final long beg=System.currentTimeMillis();
  double t=RubyTime.convertTimeInterval(context,timeout);
  unlock(context);
  try {
    long millis=(long)(t * 1000);
    if (Double.compare(t,0.0d) == 0 || millis == 0) {
    }
 else {
      context.getThread().sleep(millis);
    }
  }
 catch (  InterruptedException ex) {
  }
 finally {
    lock(context);
  }
  return context.runtime.newFixnum((System.currentTimeMillis() - beg) / 1000);
}
