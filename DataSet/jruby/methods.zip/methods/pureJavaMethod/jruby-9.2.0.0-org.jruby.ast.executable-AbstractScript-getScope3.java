public final StaticScope getScope3(){
  return runtimeCache.getScope(3);
}
