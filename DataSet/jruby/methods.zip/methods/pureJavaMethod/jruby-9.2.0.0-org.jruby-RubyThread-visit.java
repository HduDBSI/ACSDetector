@Override public void visit(ThreadContext context,RubyHash self,IRubyObject key,IRubyObject value,int index,Object state){
  if (value instanceof RubySymbol) {
    RubySymbol sym=(RubySymbol)value;
switch (sym.idString()) {
case "immediate":
      return;
case "on_blocking":
    return;
case "never":
  return;
default :
throw key.getRuntime().newArgumentError("unknown mask signature");
}
}
}
