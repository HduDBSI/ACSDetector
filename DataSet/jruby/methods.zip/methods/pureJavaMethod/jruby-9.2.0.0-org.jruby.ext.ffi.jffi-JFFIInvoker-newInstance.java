@JRubyMethod(name={"new"},meta=true,required=4) public static IRubyObject newInstance(ThreadContext context,IRubyObject recv,IRubyObject[] args){
  if (!(args[0] instanceof Pointer)) {
    throw context.runtime.newTypeError("Invalid function address " + args[0].getMetaClass().getName() + " (expected FFI::Pointer)");
  }
  if (!(args[1] instanceof RubyArray)) {
    throw context.runtime.newTypeError("Invalid parameter array " + args[1].getMetaClass().getName() + " (expected Array)");
  }
  if (!(args[2] instanceof Type)) {
    throw context.runtime.newTypeError("Invalid return type " + args[2]);
  }
  Pointer ptr=(Pointer)args[0];
  RubyArray paramTypes=(RubyArray)args[1];
  Type returnType=(Type)args[2];
  String convention="default";
  IRubyObject enums=null;
  if (args[3] instanceof RubyHash) {
    RubyHash options=(RubyHash)args[3];
    convention=options.fastARef(context.runtime.newSymbol("convention")).asJavaString();
    enums=options.fastARef(context.runtime.newSymbol("enums"));
    if (enums != null && !enums.isNil() && !(enums instanceof RubyHash || enums instanceof Enums)) {
      throw context.runtime.newTypeError("wrong type for options[:enum] " + enums.getMetaClass().getName() + " (expected Hash or Enums)");
    }
  }
 else {
    convention=args[3].asJavaString();
  }
  Type[] parameterTypes=new Type[paramTypes.size()];
  for (int i=0; i < parameterTypes.length; ++i) {
    IRubyObject type=paramTypes.entry(i);
    if (!(type instanceof Type)) {
      throw context.runtime.newArgumentError("Invalid parameter type");
    }
    parameterTypes[i]=(Type)paramTypes.entry(i);
  }
  MemoryIO fptr=ptr.getMemoryIO();
  return new JFFIInvoker(context.runtime,(RubyClass)recv,fptr,(Type)returnType,parameterTypes,"stdcall".equals(convention) ? CallingConvention.STDCALL : CallingConvention.DEFAULT,enums);
}
