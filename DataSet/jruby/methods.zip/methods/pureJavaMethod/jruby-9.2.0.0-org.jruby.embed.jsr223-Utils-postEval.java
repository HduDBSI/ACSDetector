static void postEval(ScriptingContainer container,ScriptContext context){
  if (context == null)   return;
  Object receiver=Utils.getReceiverObject(context);
  Bindings engineMap=context.getBindings(ScriptContext.ENGINE_SCOPE);
  int size=engineMap.keySet().size();
  String[] names=engineMap.keySet().toArray(new String[size]);
  Iterator<Map.Entry<String,Object>> iter=engineMap.entrySet().iterator();
  for (; iter.hasNext(); ) {
    Map.Entry<String,Object> entry=iter.next();
    if (Utils.shouldLVarBeDeleted(container,entry.getKey())) {
      iter.remove();
    }
  }
  Set<String> keys=container.getVarMap().keySet();
  if (keys != null && keys.size() > 0) {
    for (    String key : keys) {
      Object value=container.getVarMap().get(key);
      engineMap.put(Utils.adjustKey(key),value);
    }
  }
  Bindings globalMap=context.getBindings(ScriptContext.GLOBAL_SCOPE);
  if (globalMap == null)   return;
  keys=globalMap.keySet();
  if (keys != null && keys.size() > 0) {
    for (    String key : keys) {
      if (engineMap.containsKey(key))       continue;
      Object value=container.getVarMap().get(receiver,key);
      globalMap.put(key,value);
    }
  }
}
