@JRubyMethod public IRubyObject encode(ThreadContext context,IRubyObject toEncoding,IRubyObject forcedEncoding,IRubyObject opts){
  return EncodingUtils.strEncode(context,this,toEncoding,forcedEncoding,opts);
}
