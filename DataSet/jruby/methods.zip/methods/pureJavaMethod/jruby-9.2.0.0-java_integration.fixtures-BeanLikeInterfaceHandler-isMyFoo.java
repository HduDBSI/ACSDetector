public boolean isMyFoo(){
  return bri.isMyFoo();
}
