public Iterable<BasicBlock> getIncomingSources(BasicBlock block){
  return graph.findVertexFor(block).getIncomingSourcesData();
}
