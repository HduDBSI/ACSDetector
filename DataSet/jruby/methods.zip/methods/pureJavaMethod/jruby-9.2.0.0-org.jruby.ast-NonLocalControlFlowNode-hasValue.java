public boolean hasValue();
