@Deprecated public static IRubyObject methodMissing(ThreadContext context,IRubyObject recv,String name,Visibility lastVis,CallType lastCallType,IRubyObject[] args,Block block){
  return methodMissing(context,recv,name,lastVis,lastCallType,args);
}
