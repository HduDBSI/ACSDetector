/** 
 * Package the arguments appropriately depending on how many there are Corresponds to rb_enum_values_pack in MRI
 */
static IRubyObject packEnumValues(ThreadContext context,IRubyObject[] args){
switch (args.length) {
case 0:
    return context.nil;
case 1:
  return args[0];
default :
return RubyArray.newArrayMayCopy(context.runtime,args);
}
}
