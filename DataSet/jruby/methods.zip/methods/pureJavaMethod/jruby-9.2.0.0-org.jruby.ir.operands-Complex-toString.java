@Override public String toString(){
  return number + "i";
}
