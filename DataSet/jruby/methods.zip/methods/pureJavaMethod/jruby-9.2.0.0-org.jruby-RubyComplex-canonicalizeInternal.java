/** 
 * nucomp_s_canonicalize_internal
 */
private static RubyNumeric canonicalizeInternal(ThreadContext context,RubyClass clazz,IRubyObject real,IRubyObject image){
  if (Numeric.CANON) {
    if (f_zero_p(context,image) && k_exact_p(image) && canonicalization)     return (RubyNumeric)real;
  }
  boolean realReal=f_real_p(context,real);
  boolean imagReal=f_real_p(context,image);
  if (realReal && imagReal) {
    return new RubyComplex(context.runtime,clazz,real,image);
  }
  if (realReal) {
    RubyComplex complex=(RubyComplex)image;
    return new RubyComplex(context.runtime,clazz,f_sub(context,real,complex.image),f_add(context,RubyFixnum.zero(context.runtime),complex.real));
  }
  if (imagReal) {
    RubyComplex complex=(RubyComplex)real;
    return new RubyComplex(context.runtime,clazz,complex.real,f_add(context,complex.image,image));
  }
 else {
    RubyComplex complex1=(RubyComplex)real;
    RubyComplex complex2=(RubyComplex)image;
    return new RubyComplex(context.runtime,clazz,f_sub(context,complex1.real,complex2.image),f_add(context,complex1.image,complex2.real));
  }
}
