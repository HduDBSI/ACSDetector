@JRubyMethod(required=2,rest=true,meta=true) public static IRubyObject chmod(ThreadContext context,IRubyObject recv,IRubyObject[] args){
  Ruby runtime=context.runtime;
  int count=0;
  RubyInteger mode=args[0].convertToInteger();
  for (int i=1; i < args.length; i++) {
    JRubyFile filename=file(args[i]);
    if (!filename.exists()) {
      throw runtime.newErrnoENOENTError(filename.toString());
    }
    if (0 != runtime.getPosix().chmod(filename.getAbsolutePath(),(int)mode.getLongValue())) {
      throw runtime.newErrnoFromLastPOSIXErrno();
    }
 else {
      count++;
    }
  }
  return runtime.newFixnum(count);
}
