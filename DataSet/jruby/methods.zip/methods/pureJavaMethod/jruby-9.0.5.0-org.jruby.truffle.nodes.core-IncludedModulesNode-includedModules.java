@Specialization public DynamicObject includedModules(DynamicObject module){
  CompilerDirectives.transferToInterpreter();
  final List<DynamicObject> modules=new ArrayList<>();
  for (  DynamicObject included : Layouts.MODULE.getFields(module).ancestors()) {
    if (!RubyGuards.isRubyClass(included) && included != module) {
      modules.add(included);
    }
  }
  Object[] objects=modules.toArray(new Object[modules.size()]);
  return Layouts.ARRAY.createArray(getContext().getCoreLibrary().getArrayFactory(),objects,objects.length);
}
