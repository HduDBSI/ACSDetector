public SyntaxException(String file,int line,String message){
  super(message);
  this.file=file;
  this.line=line;
}
