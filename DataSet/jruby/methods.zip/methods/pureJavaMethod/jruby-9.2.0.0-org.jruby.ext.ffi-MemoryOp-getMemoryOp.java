public static MemoryOp getMemoryOp(Type type,ByteOrder order){
  if (type instanceof Type.Builtin) {
    return getMemoryOp(type.getNativeType(),order);
  }
 else   if (type instanceof StructByValue) {
    StructByValue sbv=(StructByValue)type;
    return new StructOp(sbv.getStructClass());
  }
 else   if (type instanceof MappedType) {
    return new Mapped(getMemoryOp(((MappedType)type).getRealType(),order),(MappedType)type);
  }
  return null;
}
