/** 
 * Return an array of nested modules or classes.
 */
@JRubyMethod(name="nesting",reads=SCOPE,meta=true) public static RubyArray nesting(ThreadContext context,IRubyObject recv,Block block){
  Ruby runtime=context.runtime;
  RubyModule object=runtime.getObject();
  StaticScope scope=context.getCurrentScope().getStaticScope();
  RubyArray result=runtime.newArray();
  for (StaticScope current=scope; current.getModule() != object; current=current.getPreviousCRefScope()) {
    result.append(current.getModule());
  }
  return result;
}
