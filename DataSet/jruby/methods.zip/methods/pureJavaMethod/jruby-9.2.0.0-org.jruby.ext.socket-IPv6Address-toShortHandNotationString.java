private String toShortHandNotationString(){
  final String[] strings=toArrayOfShortStrings();
  final StringBuilder result=new StringBuilder();
  int[] shortHandNotationPositionAndLength=startAndLengthOfLongestRunOfZeroes();
  int shortHandNotationPosition=shortHandNotationPositionAndLength[0];
  int shortHandNotationLength=shortHandNotationPositionAndLength[1];
  boolean useShortHandNotation=shortHandNotationLength > 1;
  for (int i=0; i < strings.length; i++) {
    if (useShortHandNotation && i == shortHandNotationPosition) {
      if (i == 0) {
        result.append("::");
      }
 else {
        result.append(":");
      }
    }
 else     if (!(i > shortHandNotationPosition && i < shortHandNotationPosition + shortHandNotationLength)) {
      result.append(strings[i]);
      if (i < N_SHORTS - 1) {
        result.append(":");
      }
    }
  }
  return result.toString().toLowerCase();
}
