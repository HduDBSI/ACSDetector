private int checkIndexForRef(int beg,int len){
  if (beg >= len)   raiseIndexOutOfString(beg);
  if (beg < 0) {
    if (-beg > len)     raiseIndexOutOfString(beg);
    beg+=len;
  }
  return beg;
}
