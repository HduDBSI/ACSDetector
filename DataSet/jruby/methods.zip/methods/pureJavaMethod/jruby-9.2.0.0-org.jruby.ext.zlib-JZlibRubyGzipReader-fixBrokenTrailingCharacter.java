private void fixBrokenTrailingCharacter(ByteList result) throws IOException {
  int extraBytes=StringSupport.bytesToFixBrokenTrailingCharacter(result.getUnsafeBytes(),result.getBegin(),result.getRealSize(),getReadEncoding(),result.length());
  for (int i=0; i < extraBytes; i++) {
    int read=bufferedStream.read();
    if (read == -1)     break;
    result.append(read);
  }
}
