/** 
 * Get the microsecond part of this time value.
 * @return the (whole) microsecond part of time
 */
@JRubyMethod(name={"usec","tv_usec"}) public RubyInteger usec(){
  return getRuntime().newFixnum(dt.getMillisOfSecond() * 1000 + getUSec());
}
