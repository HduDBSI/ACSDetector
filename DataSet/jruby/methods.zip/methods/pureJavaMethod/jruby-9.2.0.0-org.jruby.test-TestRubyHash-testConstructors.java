/** 
 * Test literal constructor {}, Hash::[], and Hash::new with and without the optional default-value argument.
 */
public void testConstructors() throws Exception {
  result=eval("hash = Hash['b', 200]; p hash");
  assertEquals("{\"b\"=>200}",result);
  result=eval("hash = Hash.new(); p hash['test']");
  assertEquals("nil",result);
  result=eval("hash = Hash.new('default'); p hash['test']");
  assertEquals("\"default\"",result);
}
