public void add(Object obj){
  Ruby runtime=metaClass.runtime;
  insert(new IRubyObject[]{RubyFixnum.newFixnum(runtime,index++),JavaUtil.convertJavaToUsableRubyObject(runtime,obj)});
  last=-1;
}
