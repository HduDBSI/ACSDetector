@JRubyMethod(name="change_privilege",module=true,visibility=PRIVATE) public static IRubyObject change_privilege(IRubyObject self,IRubyObject arg){
  throw self.getRuntime().newNotImplementedError("Process::UID::change_privilege not implemented yet");
}
