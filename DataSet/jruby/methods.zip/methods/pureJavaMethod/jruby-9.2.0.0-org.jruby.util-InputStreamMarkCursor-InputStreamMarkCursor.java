public InputStreamMarkCursor(InputStream in,int markSize){
  this.in=in;
  this.markSize=markSize;
  buf=new byte[0];
}
