@Override public IRubyObject load(ThreadContext context,IRubyObject self,boolean wrap){
  try {
    return (IRubyObject)scriptHandle.invokeWithArguments(context,self,wrap);
  }
 catch (  IRBreakJump bj) {
    throw IRException.BREAK_LocalJumpError.getException(context.runtime);
  }
catch (  Throwable t) {
    Helpers.throwException(t);
    return null;
  }
 finally {
  }
}
