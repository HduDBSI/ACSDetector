/** 
 * Decode a double in big-endian from a packed value
 * @param encode string to get int from
 * @return the double value
 */
private static double decodeDoubleBigEndian(ByteBuffer encode){
  return Double.longBitsToDouble(decodeLongBigEndian(encode));
}
