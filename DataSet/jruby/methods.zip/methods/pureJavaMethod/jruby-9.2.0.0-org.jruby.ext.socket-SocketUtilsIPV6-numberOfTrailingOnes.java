public int numberOfTrailingOnes(){
  final IPv6Address plusOne=this.add(1);
  return plusOne.getLowBits() == 0 ? Long.numberOfTrailingZeros(plusOne.getHighBits()) + 64 : Long.numberOfTrailingZeros(plusOne.getLowBits());
}
