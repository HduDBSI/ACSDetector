public void land(){
  getMethodVisitor().visitInsn(LAND);
}
