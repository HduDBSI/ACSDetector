/** 
 * rb_hash_has_value
 */
@JRubyMethod(name={"has_value?","value?"},required=1) public RubyBoolean has_value_p(ThreadContext context,IRubyObject expected){
  return context.runtime.newBoolean(hasValue(context,expected));
}
