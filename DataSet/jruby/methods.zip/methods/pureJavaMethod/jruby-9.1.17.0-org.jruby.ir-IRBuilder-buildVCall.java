public Operand buildVCall(Variable result,VCallNode node){
  if (result == null)   result=createTemporaryVariable();
  return addResultInstr(CallInstr.create(scope,CallType.VARIABLE,result,node.getName(),buildSelf(),NO_ARGS,null));
}
