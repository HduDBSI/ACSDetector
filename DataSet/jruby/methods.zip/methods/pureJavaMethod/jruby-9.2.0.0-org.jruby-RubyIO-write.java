@JRubyMethod(name="write",meta=true,required=2,optional=2) public static IRubyObject write(ThreadContext context,IRubyObject recv,IRubyObject[] argv){
  return (ioStaticWrite(context,recv,argv,false));
}
