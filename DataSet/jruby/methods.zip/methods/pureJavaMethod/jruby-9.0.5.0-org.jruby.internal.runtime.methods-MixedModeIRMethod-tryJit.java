protected void tryJit(ThreadContext context,DynamicMethodBox box){
  if (context.runtime.isBooting())   return;
synchronized (this) {
    if (box.callCount >= 0) {
      if (box.callCount++ >= Options.JIT_THRESHOLD.load()) {
        box.callCount=-1;
        context.runtime.getJITCompiler().buildThresholdReached(context,this);
      }
    }
  }
}
