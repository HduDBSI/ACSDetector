@Override public Object retrieve(ThreadContext context,IRubyObject self,StaticScope currScope,DynamicScope currDynScope,Object[] temp){
  IRubyObject obj=(IRubyObject)symbolName.retrieve(context,self,currScope,currDynScope,temp);
  String str=obj.asJavaString();
  Encoding encoding=obj.asString().getByteList().getEncoding();
  return context.runtime.newSymbol(str,encoding);
}
