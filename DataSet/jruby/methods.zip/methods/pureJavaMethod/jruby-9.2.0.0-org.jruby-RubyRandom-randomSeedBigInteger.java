public static BigInteger randomSeedBigInteger(java.util.Random random){
  byte[] seed=new byte[DEFAULT_SEED_CNT * 4];
  random.nextBytes(seed);
  return new BigInteger(seed).abs();
}
