private static Class loadCompiledScriptFromClass(Ruby runtime,InputStream in) throws IOException {
  ByteArrayOutputStream baos=new ByteArrayOutputStream();
  byte[] buf=new byte[8192];
  int read;
  while ((read=in.read(buf)) != -1) {
    baos.write(buf,0,read);
  }
  buf=baos.toByteArray();
  JRubyClassLoader jcl=runtime.getJRubyClassLoader();
  OneShotClassLoader oscl=new OneShotClassLoader(jcl);
  ClassReader cr=new ClassReader(buf);
  String className=cr.getClassName().replace('/','.');
  return oscl.defineClass(className,buf);
}
