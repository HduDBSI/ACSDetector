public double getValue(){
  return value;
}
