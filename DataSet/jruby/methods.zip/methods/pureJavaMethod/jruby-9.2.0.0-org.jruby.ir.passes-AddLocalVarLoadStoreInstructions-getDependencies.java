@Override public List<Class<? extends CompilerPass>> getDependencies(){
  return DEPENDENCIES;
}
