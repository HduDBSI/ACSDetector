@Override public void UnboxFloatInstr(UnboxFloatInstr instr){
  visit(instr.getValue());
  jvmMethod().invokeIRHelper("unboxFloat",sig(double.class,IRubyObject.class));
  jvmStoreLocal(instr.getResult());
}
