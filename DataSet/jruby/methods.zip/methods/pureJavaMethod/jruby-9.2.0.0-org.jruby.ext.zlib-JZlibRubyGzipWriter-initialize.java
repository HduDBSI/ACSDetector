public IRubyObject initialize(IRubyObject[] args){
  return initialize19(getRuntime().getCurrentContext(),args,Block.NULL_BLOCK);
}
