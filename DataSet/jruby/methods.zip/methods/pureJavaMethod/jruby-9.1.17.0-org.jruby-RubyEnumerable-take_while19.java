@Deprecated public static IRubyObject take_while19(ThreadContext context,IRubyObject self,final Block block){
  return take_while(context,self,block);
}
