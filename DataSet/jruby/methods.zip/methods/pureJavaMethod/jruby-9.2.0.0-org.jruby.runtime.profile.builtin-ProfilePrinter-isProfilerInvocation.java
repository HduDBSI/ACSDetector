boolean isProfilerInvocation(Invocation inv){
  return isThisProfilerInvocation(inv.getMethodSerialNumber()) || (inv.getParent() != null && isProfilerInvocation(inv.getParent()));
}
