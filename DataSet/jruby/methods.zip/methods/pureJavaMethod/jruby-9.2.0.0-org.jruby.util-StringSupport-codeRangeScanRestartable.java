public static long codeRangeScanRestartable(Encoding enc,byte[] bytes,int s,int end,int cr){
  if (cr == CR_BROKEN)   return pack(end - s,cr);
  int p=s;
  if (enc == ASCIIEncoding.INSTANCE) {
    return pack(end - s,searchNonAscii(bytes,p,end) == -1 && cr != CR_VALID ? CR_7BIT : CR_VALID);
  }
 else   if (enc.isAsciiCompatible()) {
    p=searchNonAscii(bytes,p,end);
    if (p == -1)     return pack(end - s,cr != CR_VALID ? CR_7BIT : cr);
    while (p < end) {
      int cl=preciseLength(enc,bytes,p,end);
      if (cl <= 0)       return pack(p - s,cl == CHAR_INVALID ? CR_BROKEN : CR_UNKNOWN);
      p+=cl;
      if (p < end) {
        p=searchNonAscii(bytes,p,end);
        if (p == -1)         return pack(end - s,CR_VALID);
      }
    }
  }
 else {
    while (p < end) {
      int cl=preciseLength(enc,bytes,p,end);
      if (cl <= 0)       return pack(p - s,cl == CHAR_INVALID ? CR_BROKEN : CR_UNKNOWN);
      p+=cl;
    }
  }
  return pack(p - s,p > end ? CR_BROKEN : CR_VALID);
}
