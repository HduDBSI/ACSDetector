private static RubyMatchData setBackRefString(ThreadContext context,RubyString str,int pos,RubyString pattern){
  final RubyMatchData match=RubyRegexp.createMatchData(context,str,pos,pattern);
  match.infectBy(pattern);
  context.setBackRef(match);
  return match;
}
