void putCachedValue(Member member,IRubyObject value);
