private boolean inHighRange(int shortNumber){
  return shortNumber >= 0 && shortNumber < 4;
}
