@Deprecated public JavaMethodZeroOrOneOrTwoOrN(RubyModule implementationClass,Visibility visibility,CallConfiguration callConfig){
  super(implementationClass,visibility);
}
