protected static void receiveArg(ThreadContext context,Instr i,Operation operation,IRubyObject[] args,boolean acceptsKeywordArgument,DynamicScope currDynScope,Object[] temp,Object exception,Block blockArg){
  Object result;
  ResultInstr instr=(ResultInstr)i;
switch (operation) {
case RECV_PRE_REQD_ARG:
    int argIndex=((ReceivePreReqdArgInstr)instr).getArgIndex();
  result=IRRuntimeHelpers.getPreArgSafe(context,args,argIndex);
setResult(temp,currDynScope,instr.getResult(),result);
return;
case RECV_POST_REQD_ARG:
result=((ReceivePostReqdArgInstr)instr).receivePostReqdArg(context,args,acceptsKeywordArgument);
setResult(temp,currDynScope,instr.getResult(),result);
return;
case RECV_RUBY_EXC:
setResult(temp,currDynScope,instr.getResult(),IRRuntimeHelpers.unwrapRubyException(exception));
return;
case RECV_JRUBY_EXC:
setResult(temp,currDynScope,instr.getResult(),exception);
return;
case LOAD_IMPLICIT_CLOSURE:
setResult(temp,currDynScope,instr.getResult(),blockArg);
return;
default :
result=((ReceiveArgBase)instr).receiveArg(context,args,acceptsKeywordArgument);
setResult(temp,currDynScope,instr.getResult(),result);
}
}
