public long totalTime(){
  return topInvocation.childTime();
}
