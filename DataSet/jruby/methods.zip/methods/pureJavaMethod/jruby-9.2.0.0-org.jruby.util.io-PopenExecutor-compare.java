@Override public int compare(run_exec_dup2_fd_pair o1,run_exec_dup2_fd_pair o2){
  return Integer.compare(o2.oldfd,o1.oldfd);
}
