public final RubyString getString4(ThreadContext context,int codeRange){
  return runtimeCache.getString(context,4,codeRange);
}
