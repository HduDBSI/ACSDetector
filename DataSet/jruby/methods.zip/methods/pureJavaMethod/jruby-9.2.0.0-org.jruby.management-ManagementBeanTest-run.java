public void run(){
  try {
    Thread.sleep(1);
  }
 catch (  InterruptedException e) {
  }
  ScriptingContainer instance=new ScriptingContainer(LocalContextScope.SINGLETHREAD);
  String[] names=instance.runScriptlet("mbs = java.lang.management.ManagementFactory.getPlatformMBeanServer;" + "h = mbs.queryNames( nil, nil);" + "hh = h.select { |a| a.to_s.start_with?( 'org.jruby:type=Runtime' ) };"+ "hh.collect { |a| a.to_s }.join( '_' )").toString().split("_");
synchronized (result) {
    result.addAll(Arrays.asList(names));
  }
  instance.terminate();
}
