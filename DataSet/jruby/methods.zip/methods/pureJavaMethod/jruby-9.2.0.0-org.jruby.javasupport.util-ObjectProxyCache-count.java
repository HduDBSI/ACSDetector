private int count(){
  int count=0;
  for (  Entry<T> e : entryTable) {
    while (e != null) {
      count++;
      e=e.next;
    }
  }
  return count;
}
