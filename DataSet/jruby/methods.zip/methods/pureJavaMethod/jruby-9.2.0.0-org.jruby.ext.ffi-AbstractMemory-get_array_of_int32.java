/** 
 * Reads an array of signed 32 bit integer values from the memory address.
 * @param offset The offset from the start of the memory area to read the values.
 * @param length The number of values to be read from memory.
 * @return An array containing the values.
 */
@JRubyMethod(name={"get_array_of_int32","get_array_of_int"},required=2) public IRubyObject get_array_of_int32(ThreadContext context,IRubyObject offset,IRubyObject length){
  return MemoryUtil.getArrayOfSigned32(context.runtime,getMemoryIO(),getOffset(offset),Util.int32Value(length));
}
