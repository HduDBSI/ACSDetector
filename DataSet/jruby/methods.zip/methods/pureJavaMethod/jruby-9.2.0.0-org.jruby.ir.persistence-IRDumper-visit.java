@Override public void visit(Operand operand){
  if (operand instanceof LocalVariable) {
    printAnsiOp(VARIABLE_COLOR,"*",operand);
  }
 else   if (operand instanceof TemporaryVariable) {
    printAnsiOp(VARIABLE_COLOR,operand);
  }
 else {
    printAnsi(OPERAND_COLOR,operand.getOperandType().shortName() + "<");
    operand.visit(this);
    printAnsi(OPERAND_COLOR,">");
  }
}
