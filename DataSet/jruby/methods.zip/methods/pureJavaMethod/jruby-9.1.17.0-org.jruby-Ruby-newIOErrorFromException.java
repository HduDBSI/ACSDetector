/** 
 * Java does not give us enough information for specific error conditions so we are reduced to divining them through string matches... TODO: Should ECONNABORTED get thrown earlier in the descriptor itself or is it ok to handle this late? TODO: Should we include this into Errno code somewhere do we can use this from other places as well?
 */
public RaiseException newIOErrorFromException(final IOException ex){
  return Helpers.newIOErrorFromException(this,ex);
}
