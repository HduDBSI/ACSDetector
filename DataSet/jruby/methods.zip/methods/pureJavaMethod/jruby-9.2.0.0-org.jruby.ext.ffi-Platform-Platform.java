protected Platform(OS_TYPE os){
  addressSize=ARCH_DATA_MODEL;
  addressMask=addressSize == 32 ? 0xffffffffL : 0xffffffffffffffffL;
  longSize=os == OS.WINDOWS ? 32 : addressSize;
  String libpattern;
switch (os) {
case WINDOWS:
    libpattern=".*\\.dll$";
  break;
case DARWIN:
libpattern="lib.*\\.(dylib|jnilib)$";
break;
case AIX:
libpattern="lib.*\\.a$";
break;
default :
libpattern="lib.*\\.so.*$";
break;
}
libPattern=Pattern.compile(libpattern);
}
