public void boxVar(UnboxState state,Class reqdType,Map<Variable,TemporaryLocalVariable> unboxMap,Variable v,List<Instr> newInstrs){
  TemporaryLocalVariable unboxedV=getUnboxedVar(reqdType,unboxMap,v);
  TemporaryVariableType vType=unboxedV.getType();
  if (vType == TemporaryVariableType.BOOLEAN) {
    newInstrs.add(new BoxBooleanInstr(v,unboxedV));
  }
 else   if (vType == TemporaryVariableType.FLOAT) {
    newInstrs.add(new BoxFloatInstr(v,unboxedV));
  }
 else   if (vType == TemporaryVariableType.FIXNUM) {
    newInstrs.add(new BoxFixnumInstr(v,unboxedV));
  }
  state.unboxedDirtyVars.remove(v);
}
