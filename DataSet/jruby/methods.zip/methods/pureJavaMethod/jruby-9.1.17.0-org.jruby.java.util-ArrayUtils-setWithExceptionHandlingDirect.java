public static void setWithExceptionHandlingDirect(Ruby runtime,Object array,int index,Object javaValue){
  try {
    Array.set(array,index,javaValue);
  }
 catch (  IndexOutOfBoundsException e) {
    throw mapIndexOutOfBoundsException(runtime,array,index);
  }
catch (  ArrayStoreException e) {
    throw mapArrayStoreException(runtime,array,javaValue.getClass());
  }
catch (  IllegalArgumentException e) {
    throw mapIllegalArgumentException(runtime,array,javaValue.getClass());
  }
}
