@Deprecated public IRubyObject instance_eval19(ThreadContext context,IRubyObject arg0,IRubyObject arg1,IRubyObject arg2,Block block){
  return specificEval(context,getInstanceEvalClass(),arg0,arg1,arg2,block,EvalType.INSTANCE_EVAL);
}
