public InteropArgumentsNode(RubyContext context,SourceSection sourceSection,int arity){
  super(context,sourceSection);
  this.arguments=new InteropArgumentNode[arity];
  for (int i=1; i < 1 + arity; i++) {
    arguments[i - 1]=new InteropArgumentNode(context,sourceSection,i);
  }
}
