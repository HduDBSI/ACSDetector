public static RubyInteger int2fix(Ruby runtime,long val){
  return RubyFixnum.newFixnum(runtime,val);
}
