@Deprecated public static boolean convertRubyToJavaBoolean(IRubyObject rubyObject){
  return (Boolean)convertRubyToJava(rubyObject,boolean.class);
}
