public void setOperand1(Operand operand1){
  this.operand1=operand1;
}
