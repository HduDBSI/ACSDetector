@JRubyMethod(rest=true) public IRubyObject __transfer__(ThreadContext context,IRubyObject[] values){
  Ruby runtime=context.runtime;
  if (data.prev != null)   throw runtime.newFiberError("double resume");
  if (!alive())   throw runtime.newFiberError("dead fiber called");
  FiberData currentFiberData=context.getFiber().data;
  if (this.data == currentFiberData) {
switch (values.length) {
case 0:
      return context.nil;
case 1:
    return values[0];
default :
  return RubyArray.newArrayMayCopy(runtime,values);
}
}
IRubyObject val;
switch (values.length) {
case 0:
val=NEVER;
break;
case 1:
val=values[0];
break;
default :
val=RubyArray.newArrayMayCopy(runtime,values);
}
if (data.parent != context.getFiberCurrentThread()) throw runtime.newFiberError("fiber called across threads");
if (currentFiberData.prev != null) {
data.prev=currentFiberData.prev;
currentFiberData.prev=null;
currentFiberData.transferred=true;
}
 else {
data.prev=context.getFiber();
}
try {
return exchangeWithFiber(context,currentFiberData,data,val);
}
  finally {
data.prev=null;
currentFiberData.transferred=false;
}
}
