/** 
 * Call the site's method against the target object passing one argument and a non-literal (block pass, &) block. As a "varargs" method, this will use the length of the args array to dispatch to the correct arity call, rather than dispatching unconditionally to the IRubyObject[] path.
 * @param context the ThreadContext for the current thread
 * @param caller the caller, for visibility checks
 * @param self the target object to call against
 * @param args the arguments to pass
 * @param block the block argument to pass
 * @return the result of the call
 */
public abstract IRubyObject callVarargs(ThreadContext context,IRubyObject caller,IRubyObject self,IRubyObject[] args,Block block);
