public MyRubyObjectSubclass(){
  super(currentRuntime,currentRuntime.getClass("TestSetClassAllocatorClass"));
}
