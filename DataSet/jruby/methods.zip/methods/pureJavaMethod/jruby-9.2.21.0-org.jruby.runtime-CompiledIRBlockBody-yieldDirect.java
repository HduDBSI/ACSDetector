@Override protected IRubyObject yieldDirect(ThreadContext context,Block block,IRubyObject[] args,IRubyObject self){
  try {
    return (IRubyObject)yieldDirectHandle.invokeExact(context,block,self,args);
  }
 catch (  Throwable t) {
    Helpers.throwException(t);
    return null;
  }
}
