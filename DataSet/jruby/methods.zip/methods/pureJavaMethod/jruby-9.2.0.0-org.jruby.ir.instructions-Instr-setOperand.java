public abstract void setOperand(int i,Operand operand);
