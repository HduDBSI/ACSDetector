@JRubyMethod(name="ipv6_linklocal?") public IRubyObject ipv6_linklocal_p(ThreadContext context){
  return context.runtime.newBoolean(getInetSocketAddress().getAddress().isLinkLocalAddress());
}
