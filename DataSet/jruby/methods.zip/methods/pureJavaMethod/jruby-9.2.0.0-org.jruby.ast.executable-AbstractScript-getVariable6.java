public final IRubyObject getVariable6(ThreadContext context,String name,IRubyObject object){
  return runtimeCache.getVariable(context,6,name,object);
}
