@JRubyMethod(name="reject!") public IRubyObject reject_bang(final ThreadContext context,final Block block){
  return block.isGiven() ? reject_bangInternal(context,block) : enumeratorizeWithSize(context,this,"reject!",enumSizeFn());
}
