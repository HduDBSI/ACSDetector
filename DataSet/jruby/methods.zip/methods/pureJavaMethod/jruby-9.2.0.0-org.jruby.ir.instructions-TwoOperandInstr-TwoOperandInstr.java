public TwoOperandInstr(Operation operation,Operand operand1,Operand operand2){
  super(operation);
  this.operand1=operand1;
  this.operand2=operand2;
}
