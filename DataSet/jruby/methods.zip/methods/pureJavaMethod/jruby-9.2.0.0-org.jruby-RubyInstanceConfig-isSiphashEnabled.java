/** 
 * @see Options#SIPHASH_ENABLED
 */
public boolean isSiphashEnabled(){
  return siphashEnabled;
}
