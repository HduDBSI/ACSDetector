@JRubyMethod(name="beginning_of_line?",alias="bol?") public IRubyObject bol_p(){
  check();
  Ruby runtime=getRuntime();
  ByteList value=str.getByteList();
  if (pos > value.getRealSize())   return runtime.getNil();
  if (pos == 0)   return runtime.getTrue();
  return value.getUnsafeBytes()[(value.getBegin() + pos) - 1] == (byte)'\n' ? runtime.getTrue() : runtime.getFalse();
}
