public String getExcludedMethods(){
  return ruby.get().getInstanceConfig().getExcludedMethods().toString();
}
