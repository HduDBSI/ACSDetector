private static void rpermute(ThreadContext context,int n,int r,int[] p,RubyArray values,Block block){
  int i=0, index=0;
  p[index]=i;
  for (; ; ) {
    if (++index < r - 1) {
      p[index]=i=0;
      continue;
    }
    for (i=0; i < n; ++i) {
      p[index]=i;
      yieldValues(context,r,p,0,values,block);
    }
    do {
      if (index <= 0)       return;
    }
 while ((i=++p[--index]) >= n);
  }
}
