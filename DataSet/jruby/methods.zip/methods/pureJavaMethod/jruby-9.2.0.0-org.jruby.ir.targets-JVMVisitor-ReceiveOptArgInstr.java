@Override public void ReceiveOptArgInstr(ReceiveOptArgInstr instr){
  jvmMethod().loadArgs();
  jvmAdapter().pushInt(instr.requiredArgs);
  jvmAdapter().pushInt(instr.preArgs);
  jvmAdapter().pushInt(instr.getArgIndex());
  jvmAdapter().ldc(jvm.methodData().scope.receivesKeywordArgs());
  jvmMethod().invokeIRHelper("receiveOptArg",sig(IRubyObject.class,IRubyObject[].class,int.class,int.class,int.class,boolean.class));
  jvmStoreLocal(instr.getResult());
}
