/** 
 * nurat_s_canonicalize_internal
 */
private static RubyNumeric canonicalizeInternal(ThreadContext context,RubyClass clazz,RubyInteger num,RubyInteger den){
  final int res=den.signum();
  if (res < 0) {
    num=num.negate();
    den=den.negate();
  }
 else   if (res == 0) {
    throw context.runtime.newZeroDivisionError();
  }
  RubyInteger gcd=f_gcd(context,num,den);
  RubyInteger _num=(RubyInteger)num.idiv(context,gcd);
  RubyInteger _den=(RubyInteger)den.idiv(context,gcd);
  if (Numeric.CANON && canonicalization && f_one_p(context,_den))   return _num;
  return newRational(context.runtime,clazz,_num,_den);
}
