/** 
 * Just enough configuration settings (most don't make sense in Java) to run the rubytests unit tests. The tests use <code>bindir</code>, <code>RUBY_INSTALL_NAME</code> and <code>EXEEXT</code>.
 */
public void load(Ruby runtime,boolean wrap){
  RubyModule configModule;
  configModule=runtime.defineModule("RbConfig");
  RubyKernel.autoload(runtime.getCurrentContext(),runtime.getObject(),runtime.newSymbol("Config"),runtime.newString("rbconfig/obsolete.rb"));
  configModule.defineAnnotatedMethods(RbConfigLibrary.class);
  RubyHash configHash=RubyHash.newHash(runtime);
  configModule.defineConstant("CONFIG",configHash);
  String[] versionParts;
  versionParts=Constants.RUBY_VERSION.split("\\.");
  setConfig(configHash,"MAJOR",versionParts[0]);
  setConfig(configHash,"MINOR",versionParts[1]);
  setConfig(configHash,"TEENY",versionParts[2]);
  setConfig(configHash,"ruby_version",versionParts[0] + '.' + versionParts[1]+ ".0");
  setConfig(configHash,"arch","universal-java" + System.getProperty("java.specification.version"));
  normalizedHome=getNormalizedHome(runtime);
  String binDir=SafePropertyAccessor.getProperty("jruby.bindir");
  if (binDir == null) {
    binDir=newFile(normalizedHome,"bin").getPath();
  }
  setConfig(configHash,"bindir",binDir);
  setConfig(configHash,"RUBY_INSTALL_NAME",jrubyScript());
  setConfig(configHash,"RUBYW_INSTALL_NAME",IS_WINDOWS ? "jrubyw.exe" : jrubyScript());
  setConfig(configHash,"ruby_install_name",jrubyScript());
  setConfig(configHash,"rubyw_install_name",IS_WINDOWS ? "jrubyw.exe" : jrubyScript());
  setConfig(configHash,"SHELL",jrubyShell());
  setConfig(configHash,"prefix",normalizedHome);
  setConfig(configHash,"exec_prefix",normalizedHome);
  setConfig(configHash,"host_os",getOSName());
  setConfig(configHash,"host_vendor",System.getProperty("java.vendor"));
  setConfig(configHash,"host_cpu",getArchitecture());
  String host=String.format("%s-%s-%s",getOSName(),System.getProperty("java.vendor"),getArchitecture());
  setConfig(configHash,"host",host);
  setConfig(configHash,"host_alias",host);
  setConfig(configHash,"target_os",getOSName());
  setConfig(configHash,"target_cpu",getArchitecture());
  String jrubyJarFile="jruby.jar";
  URL jrubyPropertiesUrl=Ruby.getClassLoader().getResource("/org/jruby/Ruby.class");
  if (jrubyPropertiesUrl != null) {
    Pattern jarFile=Pattern.compile("jar:file:.*?([a-zA-Z0-9.\\-]+\\.jar)!" + "/org/jruby/Ruby.class");
    Matcher jarMatcher=jarFile.matcher(jrubyPropertiesUrl.toString());
    jarMatcher.find();
    if (jarMatcher.matches()) {
      jrubyJarFile=jarMatcher.group(1);
    }
  }
  setConfig(configHash,"LIBRUBY",jrubyJarFile);
  setConfig(configHash,"LIBRUBY_SO",jrubyJarFile);
  setConfig(configHash,"LIBRUBY_SO",jrubyJarFile);
  setConfig(configHash,"LIBRUBY_ALIASES",jrubyJarFile);
  setConfig(configHash,"build",Constants.BUILD);
  setConfig(configHash,"target",Constants.TARGET);
  String shareDir=newFile(normalizedHome,"share").getPath();
  String includeDir=newFile(normalizedHome,"lib/ruby/include").getPath();
  String vendorDirGeneral=getVendorDirGeneral(runtime);
  String siteDirGeneral=getSiteDirGeneral(runtime);
  String rubySharedLibDir=getRubySharedLibDir(runtime);
  String rubyLibDir=getRubyLibDir(runtime);
  String archDir=getArchDir(runtime);
  String vendorDir=getVendorDir(runtime);
  String vendorLibDir=getVendorLibDir(runtime);
  String vendorArchDir=getVendorArchDir(runtime);
  String siteDir=getSiteDir(runtime);
  String siteLibDir=getSiteLibDir(runtime);
  String siteArchDir=getSiteArchDir(runtime);
  String sysConfDir=getSysConfDir(runtime);
  setConfig(configHash,"libdir",vendorDirGeneral);
  setConfig(configHash,"rubylibprefix",vendorDirGeneral + "/ruby");
  setConfig(configHash,"rubylibdir",rubyLibDir);
  setConfig(configHash,"rubysharedlibdir",rubySharedLibDir);
  if (!isSiteVendorSame(runtime)) {
    setConfig(configHash,"vendordir",vendorDir);
    setConfig(configHash,"vendorlibdir",vendorLibDir);
    setConfig(configHash,"vendorarchdir",vendorArchDir);
  }
  setConfig(configHash,"sitedir",siteDir);
  setConfig(configHash,"sitelibdir",siteLibDir);
  setConfig(configHash,"sitearchdir",siteArchDir);
  setConfig(configHash,"sitearch","java");
  setConfig(configHash,"archdir",archDir);
  setConfig(configHash,"topdir",archDir);
  setConfig(configHash,"includedir",includeDir);
  setConfig(configHash,"rubyhdrdir",includeDir);
  setConfig(configHash,"configure_args","");
  setConfig(configHash,"datadir",shareDir);
  setConfig(configHash,"mandir",newFile(normalizedHome,"man").getPath());
  setConfig(configHash,"sysconfdir",sysConfDir);
  setConfig(configHash,"localstatedir",newFile(normalizedHome,"var").getPath());
  setConfig(configHash,"DLEXT","jar");
  if (getRubygemsDir(runtime) != null) {
    setConfig(configHash,"rubygemsdir",newFile(getRubygemsDir(runtime)).getPath());
  }
  if (Platform.IS_WINDOWS) {
    setConfig(configHash,"EXEEXT",".exe");
  }
 else {
    setConfig(configHash,"EXEEXT","");
  }
  setConfig(configHash,"ridir",newFile(shareDir,"ri").getPath());
  String gemhome=SafePropertyAccessor.getProperty("jruby.gem.home");
  String gempath=SafePropertyAccessor.getProperty("jruby.gem.path");
  if (gemhome != null)   setConfig(configHash,"default_gem_home",gemhome);
  if (gempath != null)   setConfig(configHash,"default_gem_path",gempath);
  setConfig(configHash,"joda-time.version",Constants.JODA_TIME_VERSION);
  setConfig(configHash,"tzdata.version",Constants.TZDATA_VERSION);
  RubyHash mkmfHash=RubyHash.newHash(runtime);
  setConfig(mkmfHash,"libdir",vendorDirGeneral);
  setConfig(mkmfHash,"arch","java");
  setConfig(mkmfHash,"rubylibdir",rubyLibDir);
  setConfig(mkmfHash,"rubysharedlibdir",rubySharedLibDir);
  if (!isSiteVendorSame(runtime)) {
    setConfig(mkmfHash,"vendordir",vendorDir);
    setConfig(mkmfHash,"vendorlibdir",vendorLibDir);
    setConfig(mkmfHash,"vendorarchdir",vendorArchDir);
  }
  setConfig(mkmfHash,"sitedir",siteDir);
  setConfig(mkmfHash,"sitelibdir",siteLibDir);
  setConfig(mkmfHash,"sitearchdir",siteArchDir);
  setConfig(mkmfHash,"sitearch","java");
  setConfig(mkmfHash,"archdir",archDir);
  setConfig(mkmfHash,"topdir",archDir);
  setConfig(mkmfHash,"configure_args","");
  setConfig(mkmfHash,"datadir",newFile(normalizedHome,"share").getPath());
  setConfig(mkmfHash,"mandir",newFile(normalizedHome,"man").getPath());
  setConfig(mkmfHash,"sysconfdir",sysConfDir);
  setConfig(mkmfHash,"localstatedir",newFile(normalizedHome,"var").getPath());
  if (getRubygemsDir(runtime) != null) {
    setConfig(mkmfHash,"rubygemsdir",newFile(getRubygemsDir(runtime)).getPath());
  }
  setupMakefileConfig(configModule,mkmfHash);
  runtime.getLoadService().load("jruby/kernel/rbconfig.rb",false);
}
