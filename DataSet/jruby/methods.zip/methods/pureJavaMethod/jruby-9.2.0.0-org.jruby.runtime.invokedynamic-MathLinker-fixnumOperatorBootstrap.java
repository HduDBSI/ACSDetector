public static CallSite fixnumOperatorBootstrap(Lookup lookup,String name,MethodType type,long value,int callType,String file,int line) throws NoSuchMethodException, IllegalAccessException {
  List<String> names=StringSupport.split(name,':');
  String operator=JavaNameMangler.demangleMethodName(names.get(1));
  JRubyCallSite site=new JRubyCallSite(lookup,type,CALL_TYPES[callType],file,line,operator,true);
  MethodHandle target=FIXNUM_OPERATOR;
  target=insertArguments(target,3,site,value);
  site.setTarget(target);
  return site;
}
