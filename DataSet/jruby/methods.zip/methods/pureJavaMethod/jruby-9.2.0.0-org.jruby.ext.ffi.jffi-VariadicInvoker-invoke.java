@JRubyMethod(name={"invoke"}) public IRubyObject invoke(ThreadContext context,IRubyObject typesArg,IRubyObject paramsArg){
  IRubyObject[] types=((RubyArray)typesArg).toJavaArrayMaybeUnsafe();
  IRubyObject[] params=((RubyArray)paramsArg).toJavaArrayMaybeUnsafe();
  com.kenai.jffi.Type[] ffiParamTypes=new com.kenai.jffi.Type[types.length];
  ParameterMarshaller[] marshallers=new ParameterMarshaller[types.length];
  RubyClass builtinClass=Type.getTypeClass(context.getRuntime()).getClass("Builtin");
  for (int i=0; i < types.length; ++i) {
    Type type=(Type)types[i];
switch (NativeType.valueOf(type)) {
case CHAR:
case SHORT:
case INT:
      ffiParamTypes[i]=com.kenai.jffi.Type.SINT32;
    marshallers[i]=DefaultMethodFactory.getMarshaller((Type)builtinClass.getConstant(NativeType.INT.name().toUpperCase(LOCALE)),convention,enums);
  break;
case UCHAR:
case USHORT:
case UINT:
ffiParamTypes[i]=com.kenai.jffi.Type.UINT32;
marshallers[i]=DefaultMethodFactory.getMarshaller((Type)builtinClass.getConstant(NativeType.UINT.name().toUpperCase(LOCALE)),convention,enums);
break;
case FLOAT:
case DOUBLE:
ffiParamTypes[i]=com.kenai.jffi.Type.DOUBLE;
marshallers[i]=DefaultMethodFactory.getMarshaller((Type)builtinClass.getConstant(NativeType.DOUBLE.name().toUpperCase(LOCALE)),convention,enums);
break;
default :
ffiParamTypes[i]=FFIUtil.getFFIType(type);
marshallers[i]=DefaultMethodFactory.getMarshaller((Type)types[i],convention,enums);
break;
}
}
Invocation invocation=new Invocation(context);
Function function=new Function(address.getAddress(),returnType,ffiParamTypes,convention,saveError);
try {
HeapInvocationBuffer args=new HeapInvocationBuffer(function);
for (int i=0; i < marshallers.length; ++i) {
marshallers[i].marshal(invocation,args,params[i]);
}
return functionInvoker.invoke(context,function,args);
}
  finally {
invocation.finish();
}
}
