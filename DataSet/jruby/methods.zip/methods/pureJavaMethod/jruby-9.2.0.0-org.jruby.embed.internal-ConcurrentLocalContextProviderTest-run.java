public void run(){
  runtime=provider.getRuntime();
  config=provider.getRubyInstanceConfig();
  map=provider.getVarMap();
  attributes=provider.getAttributeMap();
  Thread.currentThread().yield();
}
