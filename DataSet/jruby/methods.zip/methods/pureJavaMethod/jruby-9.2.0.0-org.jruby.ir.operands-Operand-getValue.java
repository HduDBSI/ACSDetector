public Operand getValue(Map<Operand,Operand> valueMap){
  return this;
}
