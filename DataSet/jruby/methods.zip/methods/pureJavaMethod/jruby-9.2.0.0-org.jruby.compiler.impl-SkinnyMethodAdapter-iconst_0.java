public void iconst_0(){
  getMethodVisitor().visitInsn(ICONST_0);
}
