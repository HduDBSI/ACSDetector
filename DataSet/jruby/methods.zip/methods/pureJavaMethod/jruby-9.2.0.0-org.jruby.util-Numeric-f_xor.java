public static IRubyObject f_xor(ThreadContext context,RubyInteger x,RubyInteger y){
  return x.op_xor(context,y);
}
