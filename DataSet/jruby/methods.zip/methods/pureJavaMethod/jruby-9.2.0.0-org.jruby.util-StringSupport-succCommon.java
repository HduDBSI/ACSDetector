public static ByteList succCommon(Ruby runtime,ByteList original){
  try {
    return succCommon(original);
  }
 catch (  IllegalArgumentException e) {
    throw runtime.newArgumentError(e.getMessage());
  }
}
