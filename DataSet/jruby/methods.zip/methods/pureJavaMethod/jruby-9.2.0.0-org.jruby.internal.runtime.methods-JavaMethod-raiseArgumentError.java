protected static IRubyObject raiseArgumentError(JavaMethod method,ThreadContext context,String name,int given,int min,int max){
  Arity.raiseArgumentError(context.runtime,name,given,min,max);
  throw new AssertionError("expected to throw ArgumentError");
}
