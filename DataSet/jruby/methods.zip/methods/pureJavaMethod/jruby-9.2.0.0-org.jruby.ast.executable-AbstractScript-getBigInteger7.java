public final BigInteger getBigInteger7(String name){
  return runtimeCache.getBigInteger(7,name);
}
