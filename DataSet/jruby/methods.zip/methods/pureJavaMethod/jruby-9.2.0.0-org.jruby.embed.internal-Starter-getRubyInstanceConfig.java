RubyInstanceConfig getRubyInstanceConfig(){
  while (config == null) {
    try {
      Thread.currentThread().sleep(1000L);
    }
 catch (    InterruptedException e) {
    }
  }
  return config;
}
