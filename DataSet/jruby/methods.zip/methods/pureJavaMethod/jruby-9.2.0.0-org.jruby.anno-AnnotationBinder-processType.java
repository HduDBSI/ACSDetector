@SuppressWarnings("deprecation") public void processType(TypeElement cd){
  for (  TypeElement innerType : ElementFilter.typesIn(cd.getEnclosedElements())) {
    processType(innerType);
  }
  try {
    String qualifiedName=cd.getQualifiedName().toString().replace('.','$');
    if (!qualifiedName.contains("org$jruby")) {
      return;
    }
    ByteArrayOutputStream bytes=new ByteArrayOutputStream(1024);
    out=new PrintStream(bytes);
    out.println("/* THIS FILE IS GENERATED. DO NOT EDIT */");
    out.println("package org.jruby.gen;");
    out.println("");
    out.println("import org.jruby.Ruby;");
    out.println("import org.jruby.RubyModule;");
    out.println("import org.jruby.RubyClass;");
    out.println("import org.jruby.anno.TypePopulator;");
    out.println("import org.jruby.internal.runtime.methods.JavaMethod;");
    out.println("import org.jruby.internal.runtime.methods.DynamicMethod;");
    out.println("import org.jruby.runtime.Arity;");
    out.println("import org.jruby.runtime.Visibility;");
    out.println("import org.jruby.runtime.MethodIndex;");
    out.println("import java.util.Arrays;");
    out.println("import java.util.List;");
    out.println("import javax.annotation.Generated;");
    out.println("");
    out.println("@Generated(\"org.jruby.anno.AnnotationBinder\")");
    out.println("@SuppressWarnings(\"deprecation\")");
    out.println("public class " + qualifiedName + POPULATOR_SUFFIX+ " extends TypePopulator {");
    out.println("    public void populate(RubyModule cls, Class clazz) {");
    if (DEBUG) {
      out.println("        System.out.println(\"Using pregenerated populator: \" + \"" + qualifiedName + POPULATOR_SUFFIX+ "\");");
    }
    boolean hasAnno=false;
    boolean hasMeta=false;
    boolean hasModule=false;
    for (    ExecutableElement method : ElementFilter.methodsIn(cd.getEnclosedElements())) {
      JRubyMethod anno=method.getAnnotation(JRubyMethod.class);
      if (anno == null) {
        continue;
      }
      hasAnno=true;
      hasMeta|=anno.meta();
      hasModule|=anno.module();
    }
    if (!hasAnno)     return;
    out.println("        JavaMethod javaMethod;");
    out.println("        DynamicMethod moduleMethod, aliasedMethod;");
    if (hasMeta || hasModule)     out.println("        RubyClass singletonClass = cls.getSingletonClass();");
    out.println("        Ruby runtime = cls.getRuntime();");
    Map<CharSequence,List<ExecutableElement>> annotatedMethods=new HashMap<>();
    Map<CharSequence,List<ExecutableElement>> staticAnnotatedMethods=new HashMap<>();
    Map<Set<FrameField>,List<String>> readGroups=new HashMap<>();
    Map<Set<FrameField>,List<String>> writeGroups=new HashMap<>();
    int methodCount=0;
    for (    ExecutableElement method : ElementFilter.methodsIn(cd.getEnclosedElements())) {
      JRubyMethod anno=method.getAnnotation(JRubyMethod.class);
      if (anno == null)       continue;
      if (anno.compat() == org.jruby.CompatVersion.RUBY1_8)       continue;
      methodCount++;
      checkForThrows(cd,method);
      CharSequence name=anno.name().length == 0 ? method.getSimpleName() : anno.name()[0];
      final Map<CharSequence,List<ExecutableElement>> methodsHash;
      if (method.getModifiers().contains(Modifier.STATIC)) {
        methodsHash=staticAnnotatedMethods;
      }
 else {
        methodsHash=annotatedMethods;
      }
      List<ExecutableElement> methodDescs=methodsHash.get(name);
      if (methodDescs == null) {
        methodsHash.put(name,methodDescs=new ArrayList<>(4));
      }
      methodDescs.add(method);
      AnnotationHelper.groupFrameFields(readGroups,writeGroups,anno,method.getSimpleName().toString());
    }
    if (methodCount == 0)     return;
    classNames.add(getActualQualifiedName(cd));
    List<ExecutableElement> simpleNames=new ArrayList<>();
    Map<CharSequence,List<ExecutableElement>> complexNames=new HashMap<>();
    processMethodDeclarations(staticAnnotatedMethods);
    for (    Map.Entry<CharSequence,List<ExecutableElement>> entry : staticAnnotatedMethods.entrySet()) {
      ExecutableElement decl=entry.getValue().get(0);
      JRubyMethod anno=decl.getAnnotation(JRubyMethod.class);
      if (anno.omit())       continue;
      CharSequence rubyName=entry.getKey();
      if (decl.getSimpleName().equals(rubyName)) {
        simpleNames.add(decl);
        continue;
      }
      List<ExecutableElement> complex=complexNames.get(rubyName);
      if (complex == null)       complexNames.put(rubyName,complex=new ArrayList<>(8));
      complex.add(decl);
    }
    processMethodDeclarations(annotatedMethods);
    for (    Map.Entry<CharSequence,List<ExecutableElement>> entry : annotatedMethods.entrySet()) {
      ExecutableElement decl=entry.getValue().get(0);
      JRubyMethod anno=decl.getAnnotation(JRubyMethod.class);
      if (anno.omit())       continue;
      CharSequence rubyName=entry.getKey();
      if (decl.getSimpleName().equals(rubyName) && decl.getAnnotation(JRubyMethod.class).name().length <= 1) {
        simpleNames.add(decl);
        continue;
      }
      List<ExecutableElement> complex=complexNames.get(rubyName);
      if (complex == null)       complexNames.put(rubyName,complex=new ArrayList<>(8));
      complex.add(decl);
    }
    out.println("");
    List<String> args=new ArrayList<>();
    args.add(cd.getQualifiedName().toString());
    args.addAll(getMethodMappings(cd,complexNames));
    args.addAll(getSimpleMethodMappings(cd,simpleNames));
    out.println("        runtime.addBoundMethods(" + join(args.stream().map((str) -> quote(str)).toArray()) + ");");
    out.println("    }");
    out.println("    static {");
    AnnotationHelper.populateMethodIndex(readGroups,(bits,names) -> emitIndexCode(bits,names,"        MethodIndex.addMethodReadFieldsPacked(%d, \"%s\");"));
    AnnotationHelper.populateMethodIndex(writeGroups,(bits,names) -> emitIndexCode(bits,names,"        MethodIndex.addMethodWriteFieldsPacked(%d, \"%s\");"));
    out.println("    }");
    out.println("}");
    out.close();
    out=null;
    new File(SRC_GEN_DIR).mkdirs();
    FileOutputStream fos=new FileOutputStream(SRC_GEN_DIR + qualifiedName + POPULATOR_SUFFIX+ ".java");
    fos.write(bytes.toByteArray());
    fos.close();
  }
 catch (  IOException ex) {
    ex.printStackTrace(System.err);
    System.exit(1);
  }
}
