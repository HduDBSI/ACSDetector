/** 
 * Returns true if the address is an IPv4-mapped IPv6 address. In these addresses, the first 80 bits are zero, the next 16 bits are one, and the remaining 32 bits are the IPv4 address.
 * @return true if the address is an IPv4-mapped IPv6 addresses.
 */
public boolean isIPv4Mapped(){
  return this.highBits == 0 && (this.lowBits & 0xFFFF000000000000L) == 0 && (this.lowBits & 0x0000FFFF00000000L) == 0x0000FFFF00000000L;
}
