@JRubyMethod public RubyArray java_class_methods(){
  return toJavaMethods(javaClass().getMethods(),true);
}
