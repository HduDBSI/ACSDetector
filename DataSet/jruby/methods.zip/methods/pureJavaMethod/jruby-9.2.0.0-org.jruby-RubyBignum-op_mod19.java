@Deprecated public IRubyObject op_mod19(ThreadContext context,IRubyObject other){
  return op_mod(context,other);
}
