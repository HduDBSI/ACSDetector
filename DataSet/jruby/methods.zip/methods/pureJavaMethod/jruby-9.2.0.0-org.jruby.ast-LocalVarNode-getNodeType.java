public NodeType getNodeType(){
  return NodeType.LOCALVARNODE;
}
