@Override public int compareTo(Pair pair){
  return bytePos - pair.bytePos;
}
