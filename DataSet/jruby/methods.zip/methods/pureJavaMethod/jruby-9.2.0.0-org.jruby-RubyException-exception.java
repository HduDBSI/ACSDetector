@JRubyMethod(optional=1) public RubyException exception(IRubyObject[] args){
switch (args.length) {
case 0:
    return this;
case 1:
  if (args[0] == this)   return this;
RubyException ret=(RubyException)rbClone();
ret.initialize(args,Block.NULL_BLOCK);
return ret;
default :
throw getRuntime().newArgumentError("Wrong argument count");
}
}
