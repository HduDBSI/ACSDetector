private void boxResult(SkinnyMethodAdapter mv,NativeType type){
switch (type) {
case BOOL:
    boxResult(mv,"newBoolean");
  break;
case CHAR:
boxResult(mv,"newSigned8");
break;
case UCHAR:
boxResult(mv,"newUnsigned8");
break;
case SHORT:
boxResult(mv,"newSigned16");
break;
case USHORT:
boxResult(mv,"newUnsigned16");
break;
case INT:
boxResult(mv,"newSigned32");
break;
case UINT:
boxResult(mv,"newUnsigned32");
break;
case LONG:
if (Platform.getPlatform().longSize() == 32) {
boxResult(mv,"newSigned32");
}
 else {
boxResult(mv,"newSigned64");
}
break;
case ULONG:
if (Platform.getPlatform().longSize() == 32) {
boxResult(mv,"newUnsigned32");
}
 else {
boxResult(mv,"newUnsigned64");
}
break;
case LONG_LONG:
boxResult(mv,"newSigned64");
break;
case ULONG_LONG:
boxResult(mv,"newUnsigned64");
break;
case FLOAT:
boxResult(mv,"newFloat32");
break;
case DOUBLE:
boxResult(mv,"newFloat64");
break;
case VOID:
if (int.class == getInvokerIntType()) mv.pop();
 else mv.pop2();
mv.getfield(p(ThreadContext.class),"nil",ci(IRubyObject.class));
break;
case POINTER:
boxResult(mv,"newPointer" + Platform.getPlatform().addressSize());
break;
case STRING:
case TRANSIENT_STRING:
boxResult(mv,"newString");
break;
default :
throw new UnsupportedOperationException("native return type not supported: " + type);
}
}
