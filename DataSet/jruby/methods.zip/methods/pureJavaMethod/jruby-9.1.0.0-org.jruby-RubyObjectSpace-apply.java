public Object apply(IRubyObject arg1){
  if (rubyClass.isInstance(arg1)) {
    if (arg1 instanceof IncludedModule) {
    }
 else {
      count[0]++;
      modules.add(arg1);
    }
  }
  return null;
}
