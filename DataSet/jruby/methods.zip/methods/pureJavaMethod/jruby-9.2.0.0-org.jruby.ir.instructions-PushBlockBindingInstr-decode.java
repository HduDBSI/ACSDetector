public static PushBlockBindingInstr decode(IRReaderDecoder d){
  return new PushBlockBindingInstr();
}
