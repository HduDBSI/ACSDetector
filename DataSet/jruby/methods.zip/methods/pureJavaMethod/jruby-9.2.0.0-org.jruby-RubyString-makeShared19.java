@Deprecated public final RubyString makeShared19(Ruby runtime,RubyClass meta,int index,int len){
  return makeShared(runtime,meta,value,index,len);
}
