public void test(){
  new ThrowExceptionInStatic();
}
