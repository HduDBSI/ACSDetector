public IRubyObject op_mod(ThreadContext context,double other){
  double x=value;
  double mod=Math.IEEEremainder(x,other);
  if (other * mod < 0) {
    mod+=other;
  }
  return RubyFloat.newFloat(context.runtime,mod);
}
