@JRubyMethod(name={"/","quo"}) public IRubyObject op_quo(ThreadContext context,IRubyObject other){
  RubyBigDecimal val=getVpValueWithPrec(context,other,false);
  if (val == null)   return callCoerced(context,sites(context).op_quo,other,true);
  if (isNaN() || val.isNaN())   return newNaN(context.runtime);
  RubyBigDecimal div=divSpecialCases(context,val);
  if (div != null)   return div;
  return quoImpl(context,val);
}
