@Deprecated public IRubyObject setsockopt(IRubyObject lev,IRubyObject optname,IRubyObject val){
  return setsockopt(getRuntime().getCurrentContext(),lev,optname,val);
}
