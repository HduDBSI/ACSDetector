public void load(Ruby runtime,boolean wrap){
  JRubyClassLoader jrubycl=(JRubyClassLoader)runtime.getJRubyClassLoader();
  ClassLoader cl=jrubycl.getParent();
  if (cl instanceof JRubyOSGiBundleClassLoader) {
    ((JRubyOSGiBundleClassLoader)cl).addBundle(this.bundle);
  }
 else {
    throw new IllegalArgumentException("osgi libraries are only" + " supported with a JRubyOSGiBundleClassLoader as the " + " loader of the ScriptingContainer.");
  }
}
