public final IRubyObject getConstant9(ThreadContext context,StaticScope scope,String name){
  return runtimeCache.getConstant(context,scope,name,9);
}
