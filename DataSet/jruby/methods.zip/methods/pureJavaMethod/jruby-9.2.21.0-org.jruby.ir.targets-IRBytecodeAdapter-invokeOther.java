/** 
 * Invoke a method on an object other than self. Stack required: context, self, all arguments, optional block
 * @param call the call to be invoked
 */
public abstract void invokeOther(String file,String scopeFieldName,CallBase call,int arity);
