public Float(double value){
  super();
  this.value=value;
}
