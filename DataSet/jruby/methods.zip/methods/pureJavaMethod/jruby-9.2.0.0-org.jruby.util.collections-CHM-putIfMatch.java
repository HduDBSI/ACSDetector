private final Object putIfMatch(final long key,final Object putval,final Object expVal){
  assert putval != null;
  assert !(putval instanceof Prime);
  assert !(expVal instanceof Prime);
  final int len=_keys.length;
  int idx=(int)(key & (len - 1));
  int reprobe_cnt=0;
  long K=NO_KEY;
  Object V=null;
  while (true) {
    V=_vals[idx];
    K=_keys[idx];
    if (K == NO_KEY) {
      if (putval == TOMBSTONE)       return putval;
      if (CAS_key(idx,NO_KEY,key)) {
        _slots.add(1);
        break;
      }
      K=_keys[idx];
      assert K != NO_KEY;
    }
    if (K == key)     break;
    if (++reprobe_cnt >= reprobe_limit(len)) {
      final CHM newchm=resize();
      if (expVal != null)       _nbhml.help_copy();
      return newchm.putIfMatch(key,putval,expVal);
    }
    idx=(idx + 1) & (len - 1);
  }
  if (putval == V)   return V;
  if ((V == null && tableFull(reprobe_cnt,len)) || V instanceof Prime) {
    resize();
    return copy_slot_and_check(idx,expVal).putIfMatch(key,putval,expVal);
  }
  while (true) {
    assert !(V instanceof Prime);
    if (expVal != NO_MATCH_OLD && V != expVal && (expVal != MATCH_ANY || V == TOMBSTONE || V == null) && !(V == null && expVal == TOMBSTONE) && (expVal == null || !expVal.equals(V)))     return V;
    if (CAS_val(idx,V,putval)) {
      if (expVal != null) {
        if ((V == null || V == TOMBSTONE) && putval != TOMBSTONE)         _size.add(1);
        if (!(V == null || V == TOMBSTONE) && putval == TOMBSTONE)         _size.add(-1);
      }
      return (V == null && expVal != null) ? TOMBSTONE : V;
    }
    V=_vals[idx];
    if (V instanceof Prime)     return copy_slot_and_check(idx,expVal).putIfMatch(key,putval,expVal);
  }
}
