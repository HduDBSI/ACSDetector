public final AbstractMemory order(Ruby runtime,ByteOrder order){
  return new Pointer(runtime,order.equals(getMemoryIO().order()) ? getMemoryIO() : new SwappedMemoryIO(runtime,getMemoryIO()),size,typeSize);
}
