public static Integer integerFib(Integer n){
  if (n.intValue() < TWO.intValue()) {
    return n;
  }
 else {
    return integerFib(Integer.valueOf(n.intValue() - TWO.intValue())) + integerFib(Integer.valueOf(n.intValue() - ONE.intValue()));
  }
}
