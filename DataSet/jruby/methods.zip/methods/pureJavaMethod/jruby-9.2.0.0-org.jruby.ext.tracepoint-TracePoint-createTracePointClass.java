public static void createTracePointClass(Ruby runtime){
  RubyClass tracePoint=runtime.defineClass("TracePoint",runtime.getObject(),new ObjectAllocator(){
    @Override public IRubyObject allocate(    Ruby runtime,    RubyClass klazz){
      return new TracePoint(runtime,klazz);
    }
  }
);
  tracePoint.defineAnnotatedMethods(TracePoint.class);
}
