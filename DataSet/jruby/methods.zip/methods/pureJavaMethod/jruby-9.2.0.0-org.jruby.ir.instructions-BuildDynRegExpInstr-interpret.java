@Override public Object interpret(ThreadContext context,StaticScope currScope,DynamicScope currDynScope,IRubyObject self,Object[] temp){
  if (reCache.rubyRegexp == null || !options.isOnce() || context.runtime.getKCode() != reCache.rubyRegexp.getKCode()) {
    RubyString[] pieces=retrievePieces(context,self,currScope,currDynScope,temp);
    RubyString pattern=RubyRegexp.preprocessDRegexp(context.runtime,pieces,options);
    RubyRegexp re=RubyRegexp.newDRegexp(context.runtime,pattern,options);
    re.setLiteral();
    reCache.updateCache(options.isOnce(),re);
  }
  return reCache.rubyRegexp;
}
