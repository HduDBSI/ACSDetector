@Deprecated public IRubyObject op_plus19(ThreadContext context,IRubyObject other){
  return op_plus(context,other);
}
