@Override public IRubyObject call(ThreadContext context,IRubyObject self,RubyModule clazz,String name,IRubyObject arg0,IRubyObject arg1,IRubyObject arg2,Block block){
  if (block.isGiven()) {
    RubyProc proc=RubyProc.newProc(context.runtime,block,block.type);
    JavaMethod method=(JavaMethod)findCallableArityFour(self,name,arg0,arg1,arg2,proc);
    final Class<?>[] paramTypes=method.getParameterTypes();
    Object cArg0=arg0.toJava(paramTypes[0]);
    Object cArg1=arg1.toJava(paramTypes[1]);
    Object cArg2=arg2.toJava(paramTypes[2]);
    Object cArg3=proc.toJava(paramTypes[3]);
    return method.invokeStaticDirect(context,cArg0,cArg1,cArg2,cArg3);
  }
  return call(context,self,clazz,name,arg0,arg1,arg2);
}
