public ChannelFD(Channel fd,POSIX posix,FilenoUtil filenoUtil){
  assert fd != null;
  this.ch=fd;
  this.posix=posix;
  this.filenoUtil=filenoUtil;
  initFileno();
  initChannelTypes();
  refs=new AtomicInteger(1);
  filenoUtil.registerWrapper(realFileno,this);
  filenoUtil.registerWrapper(fakeFileno,this);
}
