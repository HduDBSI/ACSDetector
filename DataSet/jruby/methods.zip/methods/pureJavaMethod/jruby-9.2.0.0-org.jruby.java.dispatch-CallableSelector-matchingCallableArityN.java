@SuppressWarnings("unchecked") @Deprecated public static JavaCallable matchingCallableArityN(Ruby runtime,Map cache,JavaCallable[] methods,IRubyObject[] args){
  final int signatureCode=argsHashCode(args);
  JavaCallable method=(JavaCallable)cache.get(signatureCode);
  if (method == null) {
    method=findMatchingCallableForArgs(runtime,methods,args);
    if (method != null)     cache.put(signatureCode,method);
  }
  return method;
}
