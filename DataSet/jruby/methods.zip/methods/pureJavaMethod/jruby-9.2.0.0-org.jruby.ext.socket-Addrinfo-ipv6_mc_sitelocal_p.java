@JRubyMethod(name="ipv6_mc_sitelocal?") public IRubyObject ipv6_mc_sitelocal_p(ThreadContext context){
  Inet6Address in6=getInet6Address();
  return context.runtime.newBoolean(in6 != null && in6.isMCSiteLocal());
}
