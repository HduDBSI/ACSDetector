@Override public IRClosure cloneForInlining(CloneInfo ii){
  IRClosure clonedClosure;
  IRScope lexicalParent=ii.getScope();
  if (ii instanceof SimpleCloneInfo) {
    clonedClosure=new IRFor(this,lexicalParent,closureId,getName());
  }
 else {
    int id=lexicalParent.getNextClosureId();
    ByteList fullName=lexicalParent.getName().getBytes().dup();
    fullName.append(FOR_LOOP_CLONE);
    fullName.append(Integer.toString(id).getBytes());
    clonedClosure=new IRFor(this,lexicalParent,id,getManager().getRuntime().newSymbol(fullName));
  }
  return cloneForInlining(ii,clonedClosure);
}
