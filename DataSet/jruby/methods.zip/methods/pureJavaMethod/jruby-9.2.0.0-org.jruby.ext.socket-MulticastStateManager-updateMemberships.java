private void updateMemberships() throws IOException {
  if (multicastSocket == null) {
    return;
  }
  for (int i=0; i < membershipGroups.size(); i++) {
    String ipString=(String)membershipGroups.get(i);
    InetAddress group=InetAddress.getByName(ipString);
    multicastSocket.joinGroup(group);
  }
}
