/** 
 * @return
 */
boolean isImmediate();
