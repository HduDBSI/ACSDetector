public static RubyProc newProc(Ruby runtime,Block block,Block.Type type,String file,int line){
  RubyProc proc=new RubyProc(runtime,runtime.getProc(),type,file,line);
  proc.setup(block);
  return proc;
}
