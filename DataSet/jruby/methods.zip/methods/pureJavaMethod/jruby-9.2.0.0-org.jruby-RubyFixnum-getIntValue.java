@Override public int getIntValue(){
  return (int)value;
}
