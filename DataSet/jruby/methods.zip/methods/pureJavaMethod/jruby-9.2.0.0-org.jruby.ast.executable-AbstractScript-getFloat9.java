public final RubyFloat getFloat9(ThreadContext context,double value){
  return runtimeCache.getFloat(context,9,value);
}
