public IRubyObject find(ThreadContext context,IRubyObject ifnone,Block block){
  if (!isBuiltin("each"))   return RubyEnumerable.detectCommon(context,this,block);
  return detectCommon(context,ifnone,block);
}
