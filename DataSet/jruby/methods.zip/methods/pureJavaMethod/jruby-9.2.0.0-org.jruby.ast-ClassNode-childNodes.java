public List<Node> childNodes(){
  return Node.createList(cpath,bodyNode,superNode);
}
