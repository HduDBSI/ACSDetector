/** 
 * Get the class variables for write. If it is not set or not of the right size, atomically update it with an appropriate value.
 * @return the class vars map, ready for assignment
 */
private Map<String,IRubyObject> getClassVariablesForWriteAtomic(){
  while (true) {
    Map<String,IRubyObject> myClassVars=classVariables;
    if (myClassVars != Collections.EMPTY_MAP)     return myClassVars;
    Map<String,IRubyObject> newClassVars;
    newClassVars=new ConcurrentHashMap<String,IRubyObject>(4,0.75f,2);
    if (CLASSVARS_UPDATER.compareAndSet(this,myClassVars,newClassVars)) {
      return newClassVars;
    }
  }
}
