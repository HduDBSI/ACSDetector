public RaiseException newInvalidByteSequenceError(String message){
  return newRaiseException(getInvalidByteSequenceError(),message);
}
