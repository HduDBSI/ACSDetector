private IRubyObject readPartial(int len,RubyString outbuf) throws IOException {
  ByteList val=newReadByteList(10);
  byte[] buffer=new byte[len];
  int read=bufferedStream.read(buffer,0,len);
  if (read == -1) {
    return getRuntime().getNil();
  }
  val.append(buffer,0,read);
  this.position+=val.length();
  if (outbuf != null) {
    outbuf.view(val);
  }
  return newStr(getRuntime(),val);
}
