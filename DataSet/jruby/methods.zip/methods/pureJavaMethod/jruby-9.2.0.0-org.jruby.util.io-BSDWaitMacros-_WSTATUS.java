public long _WSTATUS(long status){
  return status & _WSTOPPED;
}
