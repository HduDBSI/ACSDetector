final int proxyHashCode(final Object proxy){
  int hash=11 * this.wrapper.hashCode();
  for (  String iface : this.ifaceNames) {
    hash=31 * hash + iface.hashCode();
  }
  return hash;
}
