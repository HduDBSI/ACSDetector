/** 
 * Find the given class in this hierarchy, considering modules along the way.
 * @param clazz the class to find
 * @return The method, or UndefinedMethod if not found
 */
public RubyModule findImplementer(RubyModule clazz){
  for (RubyModule module=this; module != null; module=module.getSuperClass()) {
    if (module.isSame(clazz))     return module;
  }
  return null;
}
