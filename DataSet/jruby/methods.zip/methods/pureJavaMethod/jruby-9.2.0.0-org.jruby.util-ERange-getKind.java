public Kind getKind(){
  return kind;
}
