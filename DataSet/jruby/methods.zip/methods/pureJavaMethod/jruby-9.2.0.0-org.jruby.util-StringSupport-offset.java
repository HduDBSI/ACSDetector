public static int offset(RubyString str,int pos){
  ByteList value=str.getByteList();
  return offset(str.getEncoding(),value.getUnsafeBytes(),value.getBegin(),value.getBegin() + value.getRealSize(),pos);
}
