public DynamicMethod getSuperMethodMissing(){
  return superMethodMissing;
}
