/** 
 * nurat_cmp
 */
@JRubyMethod(name="<=>") @Override public IRubyObject op_cmp(ThreadContext context,IRubyObject other){
  if (other instanceof RubyFixnum || other instanceof RubyBignum) {
    if (den instanceof RubyFixnum && ((RubyFixnum)den).getLongValue() == 1)     return f_cmp(context,num,other);
    return f_cmp(context,this,RubyRational.newRationalBang(context,getMetaClass(),other));
  }
  if (other instanceof RubyFloat) {
    return f_cmp(context,f_to_f(context,this),other);
  }
  if (other instanceof RubyRational) {
    RubyRational otherRational=(RubyRational)other;
    final RubyInteger num1, num2;
    if (num instanceof RubyFixnum && den instanceof RubyFixnum && otherRational.num instanceof RubyFixnum&& otherRational.den instanceof RubyFixnum) {
      num1=f_imul(context,((RubyFixnum)num).getLongValue(),((RubyFixnum)otherRational.den).getLongValue());
      num2=f_imul(context,((RubyFixnum)otherRational.num).getLongValue(),((RubyFixnum)den).getLongValue());
    }
 else {
      num1=f_mul(context,num,otherRational.den);
      num2=f_mul(context,otherRational.num,den);
    }
    return f_cmp(context,f_sub(context,num1,num2),RubyFixnum.zero(context.runtime));
  }
  return coerceCmp(context,sites(context).op_cmp,other);
}
