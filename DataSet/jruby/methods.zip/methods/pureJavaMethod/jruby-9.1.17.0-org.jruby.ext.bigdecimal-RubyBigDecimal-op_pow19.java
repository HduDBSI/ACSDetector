@Deprecated public RubyBigDecimal op_pow19(ThreadContext context,IRubyObject exp){
  return op_pow(context,exp);
}
