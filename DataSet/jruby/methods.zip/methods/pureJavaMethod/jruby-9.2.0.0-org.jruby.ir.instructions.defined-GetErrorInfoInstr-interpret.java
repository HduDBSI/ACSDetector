@Override public Object interpret(ThreadContext context,StaticScope currScope,DynamicScope currDynScope,IRubyObject self,Object[] temp){
  return context.getErrorInfo();
}
