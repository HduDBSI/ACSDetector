@JRubyMethod(name="to_r") public IRubyObject to_r(ThreadContext context){
  long[] exp=new long[1];
  double f=frexp(value,exp);
  f=ldexp(f,DBL_MANT_DIG);
  long n=exp[0] - DBL_MANT_DIG;
  Ruby runtime=context.runtime;
  RubyInteger rf=RubyNumeric.dbl2ival(runtime,f);
  RubyFixnum rn=RubyFixnum.newFixnum(runtime,n);
  return f_mul(context,rf,f_expt(context,RubyFixnum.two(runtime),rn));
}
