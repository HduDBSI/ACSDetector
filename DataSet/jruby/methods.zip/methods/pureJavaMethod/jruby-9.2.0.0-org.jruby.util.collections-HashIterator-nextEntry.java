Entry<V> nextEntry(){
  Entry<V> e=next;
  if (e == null) {
    throw new NoSuchElementException();
  }
  Entry<V> n=e.next;
  Entry<V>[] t=table;
  int i=index;
  while (n == null && i > 0) {
    n=t[--i];
  }
  index=i;
  next=n;
  return e;
}
