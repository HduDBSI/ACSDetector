@Deprecated public static IRubyObject read19(ThreadContext context,IRubyObject recv,IRubyObject[] args,Block unusedBlock){
  return read(context,recv,args,unusedBlock);
}
