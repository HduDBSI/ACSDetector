@Deprecated public IRubyObject fastStoreConstant(String internedName,IRubyObject value){
  return storeConstant(internedName,value);
}
