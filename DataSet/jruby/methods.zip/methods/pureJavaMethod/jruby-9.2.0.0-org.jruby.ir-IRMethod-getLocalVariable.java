@Override public LocalVariable getLocalVariable(RubySymbol name,int scopeDepth){
  LocalVariable lvar=findExistingLocalVariable(name,scopeDepth);
  if (lvar == null)   lvar=getNewLocalVariable(name,scopeDepth);
  return lvar;
}
