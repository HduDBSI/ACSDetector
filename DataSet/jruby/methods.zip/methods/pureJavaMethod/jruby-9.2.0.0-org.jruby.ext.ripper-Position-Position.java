public Position(String filename,int startLine,int endLine,int startOffset,int endOffset){
  this.filename=filename;
  this.startLine=startLine;
  this.endLine=endLine;
  this.startOffset=startOffset;
  this.endOffset=endOffset;
}
