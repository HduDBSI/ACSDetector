public byte getByte(long offset){
  throw ex();
}
