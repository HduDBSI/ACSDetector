@Override public Object execute(IRScope scope,Object... data){
  processCFG(scope.getCFG());
  return null;
}
