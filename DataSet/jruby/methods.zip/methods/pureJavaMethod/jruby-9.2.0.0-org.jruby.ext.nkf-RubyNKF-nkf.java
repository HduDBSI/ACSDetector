@JRubyMethod(name="nkf",required=2,module=true) public static IRubyObject nkf(ThreadContext context,IRubyObject recv,IRubyObject opt,IRubyObject str){
  Ruby runtime=context.runtime;
  if (!opt.respondsTo("to_str")) {
    throw runtime.newTypeError("can't convert " + opt.getMetaClass() + " into String");
  }
  if (!str.respondsTo("to_str")) {
    throw runtime.newTypeError("can't convert " + str.getMetaClass() + " into String");
  }
  Map<String,NKFCharset> options=parseOpt(opt.convertToString().toString());
  if (options.get("input").getValue() == NKFCharset.AUTO.getValue()) {
    options.put("input",guess(context,str));
  }
  ByteList bstr=str.convertToString().getByteList();
  final Converter converter;
  if (Converter.isMimeText(bstr,options)) {
    converter=new MimeConverter(context,options);
  }
 else {
    converter=new DefaultConverter(context,options);
  }
  RubyString result=converter.convert(bstr);
  if (options.get("mime-encode") == NKFCharset.BASE64) {
    result=Converter.encodeMimeString(runtime,result,PACK_BASE64);
  }
 else   if (options.get("mime-encode") == NKFCharset.QENCODE) {
    result=Converter.encodeMimeString(runtime,result,PACK_QENCODE);
  }
  return result;
}
