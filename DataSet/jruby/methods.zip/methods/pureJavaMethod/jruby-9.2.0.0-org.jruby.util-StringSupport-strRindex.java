private static int strRindex(final byte[] strBytes,final int strBeg,final int strLen,final byte[] subBytes,final int subBeg,final int subLen,int s,int pos,final Encoding enc){
  final int e=strBeg + strLen;
  while (s >= strBeg) {
    if (s + subLen <= e && ByteList.memcmp(strBytes,s,subBytes,subBeg,subLen) == 0) {
      return pos;
    }
    if (pos == 0)     break;
    pos--;
    s=enc.prevCharHead(strBytes,strBeg,s,e);
  }
  return -1;
}
