@JRubyMethod(name="initialize",visibility=PRIVATE) public IRubyObject initialize(ThreadContext context,IRubyObject sizeArg,IRubyObject countArg,IRubyObject clearArg,Block block){
  return init(context,sizeArg,RubyFixnum.fix2int(countArg),(IN | OUT),block);
}
