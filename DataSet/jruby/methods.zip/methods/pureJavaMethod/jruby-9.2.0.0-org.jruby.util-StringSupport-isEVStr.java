public static boolean isEVStr(int c){
  return c == '$' || c == '@' || c == '{';
}
