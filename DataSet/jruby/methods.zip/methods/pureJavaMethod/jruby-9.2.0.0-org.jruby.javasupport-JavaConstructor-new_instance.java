public final IRubyObject new_instance(final Object[] arguments){
  checkArity(arguments.length);
  try {
    Object result=constructor.newInstance(arguments);
    return JavaObject.wrap(getRuntime(),result);
  }
 catch (  IllegalArgumentException iae) {
    return handlelIllegalArgumentEx(iae,constructor,false,arguments);
  }
catch (  IllegalAccessException iae) {
    throw getRuntime().newTypeError("illegal access");
  }
catch (  InvocationTargetException ite) {
    getRuntime().getJavaSupport().handleNativeException(ite.getTargetException(),constructor);
    assert false;
    return null;
  }
catch (  InstantiationException ie) {
    throw getRuntime().newTypeError("can't make instance of " + constructor.getDeclaringClass().getName());
  }
}
