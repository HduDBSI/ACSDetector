@TruffleBoundary @Specialization(guards={"isRubyEncoding(encoding)","!isSimple(code, encoding)"}) public DynamicObject stringFromCodepoint(int code,DynamicObject encoding){
  final int length;
  try {
    length=EncodingOperations.getEncoding(encoding).codeToMbcLength(code);
  }
 catch (  EncodingException e) {
    CompilerDirectives.transferToInterpreter();
    throw new RaiseException(getContext().getCoreLibrary().rangeError(code,encoding,this));
  }
  if (length <= 0) {
    CompilerDirectives.transferToInterpreter();
    throw new RaiseException(getContext().getCoreLibrary().rangeError(code,encoding,this));
  }
  final byte[] bytes=new byte[length];
  try {
    EncodingOperations.getEncoding(encoding).codeToMbc(code,bytes,0);
  }
 catch (  EncodingException e) {
    CompilerDirectives.transferToInterpreter();
    throw new RaiseException(getContext().getCoreLibrary().rangeError(code,encoding,this));
  }
  return createString(new ByteList(bytes,EncodingOperations.getEncoding(encoding)));
}
