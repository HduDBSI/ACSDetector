/** 
 * inspect_obj The internal helper method that takes care of the part of the inspection that inspects instance variables.
 */
private RubyString inspectObj(final Ruby runtime,RubyString part){
  final ThreadContext context=runtime.getCurrentContext();
  boolean first=true;
  for (  Map.Entry<String,VariableAccessor> entry : metaClass.getVariableTableManager().getVariableAccessorsForRead().entrySet()) {
    Object value=entry.getValue().get(this);
    RubySymbol symbol=runtime.newSymbol(entry.getKey());
    if (!(value instanceof IRubyObject) || !symbol.validInstanceVariableName())     continue;
    IRubyObject obj=(IRubyObject)value;
    if (!first)     encStrBufCat(runtime,part,INSPECT_COMMA);
    encStrBufCat(runtime,part,INSPECT_SPACE);
    encStrBufCat(runtime,part,symbol.asString().encode(context,runtime.getEncodingService().convertEncodingToRubyEncoding(part.getEncoding())).asString().getByteList());
    encStrBufCat(runtime,part,INSPECT_EQUALS);
    encStrBufCat(runtime,part,sites(context).inspect.call(context,obj,obj).convertToString().getByteList());
    first=false;
  }
  encStrBufCat(runtime,part,INSPECT_GT);
  return part;
}
