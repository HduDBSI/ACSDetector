public void testThreading(){
  Runner[] runners=new Runner[RUNNER_COUNT];
  for (int i=0; i < RUNNER_COUNT; i++)   runners[i]=new Runner("R" + i,RUNNER_LOOP_COUNT);
  for (int i=0; i < RUNNER_COUNT; i++)   runners[i].start();
  try {
    for (int i=0; i < RUNNER_COUNT; i++)     runners[i].join();
  }
 catch (  InterruptedException ie) {
  }
  for (int i=0; i < RUNNER_COUNT; i++) {
    if (runners[i].isFailed()) {
      if (runners[i].getFailureException() != null) {
        throw runners[i].getFailureException();
      }
    }
  }
}
