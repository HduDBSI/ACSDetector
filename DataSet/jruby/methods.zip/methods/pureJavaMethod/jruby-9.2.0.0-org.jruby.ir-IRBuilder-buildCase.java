public Operand buildCase(CaseNode caseNode){
  NodeType seenType=null;
  for (  Node aCase : caseNode.getCases().children()) {
    WhenNode whenNode=(WhenNode)aCase;
    NodeType exprNodeType=whenNode.getExpressionNodes().getNodeType();
    if (seenType == null) {
      seenType=exprNodeType;
    }
 else     if (seenType != exprNodeType) {
      seenType=null;
      break;
    }
  }
  if (seenType != null) {
switch (seenType) {
case FIXNUMNODE:
      return buildFixnumCase(caseNode);
  }
}
Operand value=build(caseNode.getCaseNode());
if (value == null) value=UndefinedValue.UNDEFINED;
Label endLabel=getNewLabel();
boolean hasElse=(caseNode.getElseNode() != null);
Label elseLabel=getNewLabel();
Variable result=createTemporaryVariable();
List<Label> labels=new ArrayList<>();
Map<Label,Node> bodies=new HashMap<>();
for (Node aCase : caseNode.getCases().children()) {
  WhenNode whenNode=(WhenNode)aCase;
  Label bodyLabel=getNewLabel();
  Variable eqqResult=createTemporaryVariable();
  labels.add(bodyLabel);
  Operand expression=buildWithOrder(whenNode.getExpressionNodes(),whenNode.containsVariableAssignment());
  Node exprNodes=whenNode.getExpressionNodes();
  boolean needsSplat=exprNodes instanceof ArgsPushNode || exprNodes instanceof SplatNode || exprNodes instanceof ArgsCatNode;
  addInstr(new EQQInstr(eqqResult,expression,value,needsSplat));
  addInstr(createBranch(eqqResult,manager.getTrue(),bodyLabel));
  bodies.put(bodyLabel,whenNode.getBodyNode());
}
addInstr(new JumpInstr(elseLabel));
if (hasElse) {
  labels.add(elseLabel);
  bodies.put(elseLabel,caseNode.getElseNode());
}
for (Label whenLabel : labels) {
  addInstr(new LabelInstr(whenLabel));
  Operand bodyValue=build(bodies.get(whenLabel));
  if (bodyValue != null) {
    addInstr(new CopyInstr(result,bodyValue));
    addInstr(new JumpInstr(endLabel));
  }
}
if (!hasElse) {
  addInstr(new LabelInstr(elseLabel));
  addInstr(new CopyInstr(result,manager.getNil()));
  addInstr(new JumpInstr(endLabel));
}
addInstr(new LabelInstr(endLabel));
return result;
}
