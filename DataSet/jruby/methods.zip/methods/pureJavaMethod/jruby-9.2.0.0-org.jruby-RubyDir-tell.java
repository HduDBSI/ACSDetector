/** 
 * Returns the current position in the directory.
 */
@JRubyMethod(name={"tell","pos"}) public RubyInteger tell(){
  checkDir();
  return getRuntime().newFixnum(pos);
}
