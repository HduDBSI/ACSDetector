public RaiseException newErrnoECONNABORTEDError(){
  return newRaiseException(getErrno().getClass("ECONNABORTED"),"An established connection was aborted by the software in your host machine");
}
