@Deprecated public static IRubyObject convertToType19(ThreadContext context,IRubyObject obj,RubyClass target,JavaSites.CheckedSites sites){
  return convertToType(context,obj,target,sites);
}
