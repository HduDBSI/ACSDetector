public final void putInt(long offset,int value){
  checkBounds(offset,4);
  IO.putInt(address + offset,value);
}
