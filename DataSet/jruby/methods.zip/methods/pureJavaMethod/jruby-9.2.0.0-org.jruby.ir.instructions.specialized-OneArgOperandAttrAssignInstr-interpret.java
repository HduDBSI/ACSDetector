@Override public Object interpret(ThreadContext context,StaticScope currScope,DynamicScope dynamicScope,IRubyObject self,Object[] temp){
  IRubyObject object=(IRubyObject)getReceiver().retrieve(context,self,currScope,dynamicScope,temp);
  IRubyObject value=(IRubyObject)getArg1().retrieve(context,self,currScope,dynamicScope,temp);
  callSite.call(context,self,object,value);
  return null;
}
