@Override public boolean equals(Object other){
  if (other instanceof DelegatingDynamicMethod) {
    return delegate.equals(((DelegatingDynamicMethod)other).getDelegate());
  }
  return delegate.equals(other);
}
