@Override public DynamicMethod createDynamicMethod(RubyModule module){
  return MethodFactory.createDynamicMethod(getRuntime(),module,function,returnType,parameterTypes,convention,enums,false);
}
