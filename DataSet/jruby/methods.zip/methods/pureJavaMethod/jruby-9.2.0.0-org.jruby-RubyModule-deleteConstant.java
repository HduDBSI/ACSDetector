public IRubyObject deleteConstant(String name){
  assert IdUtil.isConstant(name);
  ensureConstantsSettable();
  return constantTableRemove(name);
}
