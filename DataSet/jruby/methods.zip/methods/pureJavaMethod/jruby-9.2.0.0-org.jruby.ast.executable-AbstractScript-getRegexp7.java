public final RubyRegexp getRegexp7(ThreadContext context,ByteList pattern,int options){
  return runtimeCache.getRegexp(context,7,pattern,options);
}
