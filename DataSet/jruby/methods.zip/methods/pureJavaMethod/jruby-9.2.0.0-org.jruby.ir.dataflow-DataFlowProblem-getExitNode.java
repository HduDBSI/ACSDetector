public U getExitNode(){
  return getFlowGraphNode(scope.getCFG().getExitBB());
}
