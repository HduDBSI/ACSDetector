public final void callInit(ThreadContext context,IRubyObject arg0,IRubyObject arg1,IRubyObject arg2,Block block){
  metaClass.getBaseCallSite(RubyClass.CS_IDX_INITIALIZE).call(context,this,this,arg0,arg1,arg2,block);
}
