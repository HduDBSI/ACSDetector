private boolean isMethodMissingMatch(DynamicMethod other){
  return (method.getRealMethod() instanceof RubyModule.RespondToMissingMethod) && ((RubyModule.RespondToMissingMethod)method.getRealMethod()).equals(other);
}
