@JRubyMethod(name="join") public IRubyObject join19(ThreadContext context){
  return join19(context,context.runtime.getGlobalVariables().get("$,"));
}
