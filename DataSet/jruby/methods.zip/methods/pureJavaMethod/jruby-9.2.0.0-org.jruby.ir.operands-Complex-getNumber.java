public Operand getNumber(){
  return number;
}
