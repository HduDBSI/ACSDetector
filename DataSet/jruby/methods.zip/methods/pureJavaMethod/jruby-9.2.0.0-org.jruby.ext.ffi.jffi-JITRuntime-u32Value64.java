public static long u32Value64(IRubyObject parameter){
  return (parameter instanceof RubyFixnum ? ((RubyFixnum)parameter).getLongValue() : other2long(parameter)) & 0xffffffffL;
}
