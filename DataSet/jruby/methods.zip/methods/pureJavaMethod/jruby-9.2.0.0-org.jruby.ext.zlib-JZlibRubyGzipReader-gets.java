@JRubyMethod(name="gets",optional=2,writes=FrameField.LASTLINE) public IRubyObject gets(ThreadContext context,IRubyObject[] args){
  try {
    IRubyObject result=internalGets(args);
    if (!result.isNil())     context.setLastLine(result);
    return result;
  }
 catch (  IOException ioe) {
    throw getRuntime().newIOErrorFromException(ioe);
  }
}
