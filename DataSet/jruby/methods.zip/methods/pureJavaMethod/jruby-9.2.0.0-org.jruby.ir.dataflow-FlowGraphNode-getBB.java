public BasicBlock getBB(){
  return basicBlock;
}
