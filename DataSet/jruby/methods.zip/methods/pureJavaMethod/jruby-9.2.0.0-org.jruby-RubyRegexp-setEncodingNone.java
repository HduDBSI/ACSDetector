public void setEncodingNone(){
  options.setEncodingNone(true);
}
