public AttrAssignNode(ISourcePosition position,Node receiverNode,RubySymbol name,Node argsNode,boolean isLazy){
  super(position,receiverNode != null && receiverNode.containsVariableAssignment() || argsNode != null && argsNode.containsVariableAssignment());
  assert receiverNode != null : "receiverNode is not null";
  this.receiverNode=receiverNode;
  this.name=name;
  this.argsNode=argsNode;
  this.isLazy=isLazy;
}
