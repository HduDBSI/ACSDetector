T visitBlockNode(BlockNode iVisited);
