public Boolean receiveTrueObj(Boolean t){
  return vri.receiveTrueObj(t);
}
