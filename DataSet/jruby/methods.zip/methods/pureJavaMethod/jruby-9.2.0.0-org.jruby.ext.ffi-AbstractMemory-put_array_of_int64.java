/** 
 * Writes an array of signed 64 bit integer values to the memory area.
 * @param offset The offset from the start of the memory area to write the values.
 * @param length The number of values to be written to memory.
 * @return <tt>this</tt> object.
 */
@JRubyMethod(name={"put_array_of_int64","put_array_of_long_long"},required=2) public IRubyObject put_array_of_int64(ThreadContext context,IRubyObject offset,IRubyObject arrParam){
  MemoryUtil.putArrayOfSigned64(context.runtime,getMemoryIO(),getOffset(offset),checkArray(arrParam));
  return this;
}
