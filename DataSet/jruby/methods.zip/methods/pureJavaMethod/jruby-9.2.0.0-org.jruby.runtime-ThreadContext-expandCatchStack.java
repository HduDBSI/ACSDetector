private void expandCatchStack(){
  int newSize=catchStack.length * 2;
  if (newSize == 0)   newSize=1;
  Continuation[] newCatchStack=new Continuation[newSize];
  System.arraycopy(catchStack,0,newCatchStack,0,catchStack.length);
  catchStack=newCatchStack;
}
