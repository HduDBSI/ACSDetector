public static IRubyObject receiveOptArg(IRubyObject[] args,int requiredArgs,int preArgs,int argIndex,boolean acceptsKeywordArgument){
  int optArgIndex=argIndex;
  RubyHash keywordArguments=extractKwargsHash(args,requiredArgs,acceptsKeywordArgument);
  int argsLength=keywordArguments != null ? args.length - 1 : args.length;
  if (requiredArgs + optArgIndex >= argsLength)   return UndefinedValue.UNDEFINED;
  return args[preArgs + optArgIndex];
}
