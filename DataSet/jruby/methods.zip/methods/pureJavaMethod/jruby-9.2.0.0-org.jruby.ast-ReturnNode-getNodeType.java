public NodeType getNodeType(){
  return NodeType.RETURNNODE;
}
