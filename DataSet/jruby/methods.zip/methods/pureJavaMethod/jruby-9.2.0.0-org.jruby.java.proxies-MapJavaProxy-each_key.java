/** 
 * rb_hash_each_key
 */
@JRubyMethod(name="each_key") public IRubyObject each_key(final ThreadContext context,final Block block){
  return getOrCreateRubyHashMap().each_key(context,block);
}
