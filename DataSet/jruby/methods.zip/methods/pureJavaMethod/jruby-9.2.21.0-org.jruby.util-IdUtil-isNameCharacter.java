public static boolean isNameCharacter(char c){
  return Character.isLetterOrDigit(c) || c == '_';
}
