public WarningGlobalVariable(Ruby runtime,String name,RubyInstanceConfig.Verbosity verbosity){
  super(runtime,name,verbosity == RubyInstanceConfig.Verbosity.NIL ? RubyFixnum.newFixnum(runtime,0) : verbosity == RubyInstanceConfig.Verbosity.FALSE ? RubyFixnum.newFixnum(runtime,1) : verbosity == RubyInstanceConfig.Verbosity.TRUE ? RubyFixnum.newFixnum(runtime,2) : runtime.getNil());
}
