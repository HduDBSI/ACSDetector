@JRubyMethod(name="write_nonblock",required=1,optional=1) public IRubyObject write_nonblock(ThreadContext context,IRubyObject[] argv){
  Ruby runtime=context.runtime;
  IRubyObject str;
  IRubyObject opts=context.nil;
  boolean exception=ArgsUtil.extractKeywordArg(context,"exception",argv) != runtime.getFalse();
  str=argv[0];
  return ioWriteNonblock(context,runtime,str,!exception);
}
