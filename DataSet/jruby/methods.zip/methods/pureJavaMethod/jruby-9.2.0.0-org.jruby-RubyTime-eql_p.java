@JRubyMethod(name="eql?",required=1) @Override public IRubyObject eql_p(IRubyObject other){
  if (other instanceof RubyTime) {
    RubyTime otherTime=(RubyTime)other;
    return (nsec == otherTime.nsec && getTimeInMillis() == otherTime.getTimeInMillis()) ? getRuntime().getTrue() : getRuntime().getFalse();
  }
  return getRuntime().getFalse();
}
