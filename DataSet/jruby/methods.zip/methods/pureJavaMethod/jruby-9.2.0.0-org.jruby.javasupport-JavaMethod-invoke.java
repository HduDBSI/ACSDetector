@JRubyMethod(rest=true) public IRubyObject invoke(ThreadContext context,IRubyObject[] args){
  checkArity(args.length - 1);
  final IRubyObject invokee=args[0];
  final Object[] arguments=convertArguments(args,1);
  if (invokee.isNil()) {
    return invokeWithExceptionHandling(context,method,null,arguments);
  }
  final Object javaInvokee;
  if (!isStatic()) {
    javaInvokee=JavaUtil.unwrapJavaValue(invokee);
    if (javaInvokee == null) {
      throw getRuntime().newTypeError("invokee not a java object");
    }
    if (!method.getDeclaringClass().isInstance(javaInvokee)) {
      throw getRuntime().newTypeError("invokee not instance of method's class" + " (got" + javaInvokee.getClass().getName() + " wanted "+ method.getDeclaringClass().getName()+ ")");
    }
    if (javaInvokee instanceof InternalJavaProxy && !isFinal) {
      JavaProxyClass jpc=((InternalJavaProxy)javaInvokee).___getProxyClass();
      JavaProxyMethod jpm=jpc.getMethod(method.getName(),parameterTypes);
      if (jpm != null && jpm.hasSuperImplementation()) {
        return invokeWithExceptionHandling(context,jpm.getSuperMethod(),javaInvokee,arguments);
      }
    }
  }
 else {
    javaInvokee=null;
  }
  return invokeWithExceptionHandling(context,method,javaInvokee,arguments);
}
