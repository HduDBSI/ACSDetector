@JRubyMethod(name={"fileno","to_i"}) public static IRubyObject fileno(ThreadContext context,IRubyObject recv){
  return getCurrentDataFile(context,"no stream").fileno(context);
}
