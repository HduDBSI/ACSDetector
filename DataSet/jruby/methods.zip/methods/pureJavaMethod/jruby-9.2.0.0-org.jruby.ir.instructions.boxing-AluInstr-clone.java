@Override public Instr clone(CloneInfo ii){
  return new AluInstr(getOperation(),ii.getRenamedVariable(result),getArg1().cloneForInlining(ii),getArg2().cloneForInlining(ii));
}
