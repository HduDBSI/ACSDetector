@Override protected IRubyObject commonYieldPath(ThreadContext context,Block block,Block.Type type,IRubyObject[] args,IRubyObject self,Block blockArg){
  if (callCount >= 0)   promoteToFullBuild(context);
  InterpreterContext ic=ensureInstrsReady();
  interpreterContext=fullInterpreterContext;
  Binding binding=block.getBinding();
  Visibility oldVis=binding.getFrame().getVisibility();
  Frame prevFrame=context.preYieldNoScope(binding);
  DynamicScope actualScope=binding.getDynamicScope();
  if (ic.pushNewDynScope()) {
    context.pushScope(block.allocScope(actualScope));
  }
 else   if (ic.reuseParentDynScope()) {
    context.pushScope(actualScope);
  }
  self=IRRuntimeHelpers.updateBlockState(block,self);
  try {
    return Interpreter.INTERPRET_BLOCK(context,block,self,ic,args,binding.getMethod(),blockArg);
  }
  finally {
    postYield(context,ic,binding,oldVis,prevFrame);
  }
}
