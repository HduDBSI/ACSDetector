public static IRubyObject negate(IRubyObject value,Ruby runtime){
  if (value.isTrue())   return runtime.getFalse();
  return runtime.getTrue();
}
