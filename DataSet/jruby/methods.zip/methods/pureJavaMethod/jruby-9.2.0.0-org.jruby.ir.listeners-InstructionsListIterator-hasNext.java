@Override public boolean hasNext(){
  return listIterator.hasNext();
}
