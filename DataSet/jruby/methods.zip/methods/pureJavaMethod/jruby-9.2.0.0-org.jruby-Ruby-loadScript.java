public void loadScript(Script script,boolean wrap){
  script.load(getCurrentContext(),getTopSelf(),wrap);
}
