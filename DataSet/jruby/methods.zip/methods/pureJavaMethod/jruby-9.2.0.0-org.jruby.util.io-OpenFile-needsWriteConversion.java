public boolean needsWriteConversion(ThreadContext context){
  Encoding ascii8bit=context.runtime.getEncodingService().getAscii8bitEncoding();
  return Platform.IS_WINDOWS ? ((encs.enc != null && encs.enc != ascii8bit) || (encs.ecflags & ((EConvFlags.DECORATOR_MASK & ~EConvFlags.CRLF_NEWLINE_DECORATOR) | EConvFlags.STATEFUL_DECORATOR_MASK)) != 0) : ((encs.enc != null && encs.enc != ascii8bit) || NEED_NEWLINE_DECORATOR_ON_WRITE() || (encs.ecflags & (EConvFlags.DECORATOR_MASK | EConvFlags.STATEFUL_DECORATOR_MASK)) != 0);
}
