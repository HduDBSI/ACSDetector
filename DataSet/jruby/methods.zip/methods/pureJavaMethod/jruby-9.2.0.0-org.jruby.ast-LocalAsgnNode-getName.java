/** 
 * Name of the local assignment.
 */
public RubySymbol getName(){
  return name;
}
