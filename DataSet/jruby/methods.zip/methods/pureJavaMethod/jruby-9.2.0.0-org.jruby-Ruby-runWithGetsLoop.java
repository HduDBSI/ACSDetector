/** 
 * Run the given script with a "while gets; end" loop wrapped around it. This is primarily used for the -n command-line flag, to allow writing a short script that processes input lines using the specified code.
 * @param scriptNode The root node of the script to execute
 * @param printing Whether $_ should be printed after each loop (as in the-p command-line flag)
 * @param processLineEnds Whether line endings should be processed bysetting $\ to $/ and <code>chop!</code>ing every line read
 * @param split Whether to split each line read using <code>String#split</code>bytecode before executing.
 * @return The result of executing the specified script
 */
public IRubyObject runWithGetsLoop(RootNode scriptNode,boolean printing,boolean processLineEnds,boolean split){
  ThreadContext context=getCurrentContext();
  scriptNode=addGetsLoop(scriptNode,printing,processLineEnds,split);
  Script script=null;
  boolean compile=getInstanceConfig().getCompileMode().shouldPrecompileCLI();
  if (compile) {
    try {
      script=tryCompile(scriptNode);
      if (Options.JIT_LOGGING.load()) {
        LOG.info("Successfully compiled: {}",scriptNode.getFile());
      }
    }
 catch (    Throwable e) {
      if (Options.JIT_LOGGING.load()) {
        if (Options.JIT_LOGGING_VERBOSE.load()) {
          LOG.error("Failed to compile: " + scriptNode.getFile(),e);
        }
 else {
          LOG.error("Failed to compile: " + scriptNode.getFile());
        }
      }
    }
    if (compile && script == null) {
    }
  }
  Helpers.preLoad(context,((RootNode)scriptNode).getStaticScope().getVariables());
  try {
    if (script != null) {
      runScriptBody(script);
    }
 else {
      runInterpreterBody(scriptNode);
    }
  }
  finally {
    Helpers.postLoad(context);
  }
  return getNil();
}
