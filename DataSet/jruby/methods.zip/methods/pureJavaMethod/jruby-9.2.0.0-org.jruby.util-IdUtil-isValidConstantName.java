public static boolean isValidConstantName(String id){
  char c;
  int len;
  if ((len=id.length()) > 0 && (c=id.charAt(0)) <= 'Z' && c >= 'A') {
    return isNameString(id,1,len);
  }
  return false;
}
