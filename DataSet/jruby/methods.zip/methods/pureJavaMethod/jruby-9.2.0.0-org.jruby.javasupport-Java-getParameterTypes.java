private Class[] getParameterTypes(final Method method){
  Map<Method,Class[]> parameterTypeCache=this.parameterTypeCache;
  if (parameterTypeCache == null) {
    parameterTypeCache=new ConcurrentHashMap<Method,Class[]>(4);
    this.parameterTypeCache=parameterTypeCache;
  }
  Class[] parameterTypes=parameterTypeCache.get(method);
  if (parameterTypes == null) {
    parameterTypes=method.getParameterTypes();
    parameterTypeCache.put(method,parameterTypes);
  }
  return parameterTypes;
}
