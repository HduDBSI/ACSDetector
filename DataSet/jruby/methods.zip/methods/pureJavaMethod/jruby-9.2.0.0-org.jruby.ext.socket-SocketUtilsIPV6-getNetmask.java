public IPv6NetworkMask getNetmask(){
  return networkMask;
}
