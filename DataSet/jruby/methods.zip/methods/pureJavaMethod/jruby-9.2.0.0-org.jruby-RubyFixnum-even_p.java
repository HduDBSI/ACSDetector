@Override public RubyBoolean even_p(ThreadContext context){
  return (value & 1) == 0 ? context.tru : context.fals;
}
