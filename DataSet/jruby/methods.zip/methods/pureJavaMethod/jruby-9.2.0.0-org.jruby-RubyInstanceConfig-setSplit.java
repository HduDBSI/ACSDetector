/** 
 * @see Options#CLI_AUTOSPLIT
 */
public void setSplit(boolean split){
  this.split=split;
}
