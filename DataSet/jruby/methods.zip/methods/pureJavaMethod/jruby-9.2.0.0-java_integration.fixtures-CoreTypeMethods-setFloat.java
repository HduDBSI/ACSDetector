public static String setFloat(float f){
  return String.valueOf(f);
}
