/** 
 * Test of callMethod method, of class ScriptingContainer.
 */
@Test public void testCallMethod_3args(){
  logger1.info("callMethod(receiver, methodName, returnType)");
  Object receiver=null;
  String methodName="";
  Class<Object> returnType=null;
  String[] paths={basedir + "/lib/ruby/stdlib"};
  ScriptingContainer instance=new ScriptingContainer(LocalContextScope.THREADSAFE);
  instance.setLoadPaths(Arrays.asList(paths));
  instance.setError(pstream);
  instance.setOutput(pstream);
  instance.setWriter(writer);
  instance.setErrorWriter(writer);
  Object expResult=null;
  Object result=instance.callMethod(receiver,methodName,returnType);
  assertEquals(expResult,result);
  String filename="src/test/ruby/org/jruby/embed/ruby/next_year_1.rb";
  receiver=instance.runScriptlet(PathType.RELATIVE,filename);
  int next_year=instance.callMethod(receiver,"get_year",Integer.class);
  assertEquals(getNextYear(),next_year);
  String script="def volume\n" + "  (Math::PI * (@r ** 2.0) * @h)/3.0\n" + "end\n"+ "def surface_area\n"+ "  Math::PI * @r * Math.sqrt((@r ** 2.0) + (@h ** 2.0)) + Math::PI * (@r ** 2.0)\n"+ "end\n"+ "self";
  receiver=instance.runScriptlet(script);
  instance.put("@r",1.0);
  instance.put("@h",Math.sqrt(3.0));
  double volume=instance.callMethod(receiver,"volume",Double.class);
  assertEquals(1.813799,volume,0.000001);
  double surface_area=instance.callMethod(receiver,"surface_area",Double.class);
  assertEquals(9.424778,surface_area,0.000001);
  instance.getVarMap().clear();
  instance.terminate();
}
