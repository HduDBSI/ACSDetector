public static BoxedLong fullyBoxedFib(BoxedLong n){
  if (n.lt(BOXED_CACHE[2])) {
    return n;
  }
 else {
    return fullyBoxedFib(n.minus(BOXED_CACHE[2])).plus(fullyBoxedFib(n.minus(BOXED_CACHE[1])));
  }
}
