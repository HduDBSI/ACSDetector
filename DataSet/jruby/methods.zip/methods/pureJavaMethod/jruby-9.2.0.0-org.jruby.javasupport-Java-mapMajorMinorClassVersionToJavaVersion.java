private static int mapMajorMinorClassVersionToJavaVersion(String msg,final int offset){
  int end;
  if ((end=msg.indexOf('.',offset)) == -1)   end=msg.length();
  msg=msg.substring(offset,end).trim();
  try {
    return Integer.parseInt(msg) - 50 + 6;
  }
 catch (  RuntimeException ignore) {
    return 0;
  }
}
