public static RubyClass createBufferClass(Ruby runtime,RubyModule module){
  RubyClass result=module.defineClassUnder("Buffer",module.getClass(AbstractMemory.ABSTRACT_MEMORY_RUBY_CLASS),BufferAllocator.INSTANCE);
  result.defineAnnotatedMethods(Buffer.class);
  result.defineAnnotatedConstants(Buffer.class);
  return result;
}
