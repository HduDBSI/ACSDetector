/** 
 * Invoke a fixnum-receiving method on an object other than self. Stack required: context, self, receiver (fixnum will be handled separately)
 */
public abstract void invokeOtherOneFixnum(String file,CallBase call,long fixnum);
