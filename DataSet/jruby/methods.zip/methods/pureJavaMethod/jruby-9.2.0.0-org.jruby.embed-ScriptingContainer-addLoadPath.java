@Deprecated protected void addLoadPath(String uri){
  runScriptlet("$LOAD_PATH << '" + uri + "' unless $LOAD_PATH.member?( '"+ uri+ "' )");
}
