@JRubyMethod public IRubyObject marshal_load(final ThreadContext context,final IRubyObject str){
  try {
    ByteList byteList=str.convertToString().getByteList();
    ByteArrayInputStream bytes=new ByteArrayInputStream(byteList.getUnsafeBytes(),byteList.getBegin(),byteList.getRealSize());
    this.object=new JRubyObjectInputStream(context.runtime,bytes).readObject();
    return this;
  }
 catch (  IOException ex) {
    throw context.runtime.newIOErrorFromException(ex);
  }
catch (  ClassNotFoundException ex) {
    throw context.runtime.newTypeError("Class not found unmarshaling Java type: " + ex.getLocalizedMessage());
  }
}
