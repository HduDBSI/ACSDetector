public static int write(WritableByteChannel channel,ByteBuffer buf,boolean blocking) throws IOException {
  do {
    int n=channel.write(buf);
    if (n != 0 || !blocking || !(channel instanceof SelectableChannel) || !buf.hasRemaining()) {
      return n;
    }
    try {
      awaitWritable(channel);
    }
 catch (    InterruptedException ex) {
      throw new InterruptedIOException(ex.getMessage());
    }
  }
 while (true);
}
