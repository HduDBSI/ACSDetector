public static RubyClass createJavaObjectClass(Ruby runtime,RubyModule javaModule){
  RubyClass JavaObject=javaModule.defineClassUnder("JavaObject",runtime.getObject(),JAVA_OBJECT_ALLOCATOR);
  registerRubyMethods(runtime,JavaObject);
  JavaObject.getMetaClass().undefineMethod("new");
  JavaObject.getMetaClass().undefineMethod("allocate");
  return JavaObject;
}
