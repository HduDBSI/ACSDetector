private RubyEncoding(Ruby runtime,ByteList name,Encoding encoding,boolean isDummy){
  super(runtime,runtime.getEncoding());
  this.name=name;
  this.isDummy=isDummy;
  this.encoding=encoding;
  this.constant=OptoFactory.newConstantWrapper(RubyEncoding.class,this);
}
