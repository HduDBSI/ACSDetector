@Deprecated public JavaMethodZeroOrOneOrTwoOrThreeOrNBlock(RubyModule implementationClass,Visibility visibility,CallConfiguration callConfig){
  super(implementationClass,visibility);
}
