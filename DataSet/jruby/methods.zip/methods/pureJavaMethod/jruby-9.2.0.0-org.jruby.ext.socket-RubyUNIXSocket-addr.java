@JRubyMethod public IRubyObject addr(ThreadContext context){
  final Ruby runtime=context.runtime;
  return runtime.newArray(runtime.newString("AF_UNIX"),RubyString.newEmptyString(runtime));
}
