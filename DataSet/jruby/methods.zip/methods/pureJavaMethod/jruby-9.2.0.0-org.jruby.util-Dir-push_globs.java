private static int push_globs(Ruby runtime,String cwd,List<ByteList> ary,ByteList pattern,int flags){
  flags|=FNM_SYSCASE;
  return glob_helper(runtime,cwd,pattern,-1,flags,glob_caller,new GlobArgs(push_pattern,ary));
}
