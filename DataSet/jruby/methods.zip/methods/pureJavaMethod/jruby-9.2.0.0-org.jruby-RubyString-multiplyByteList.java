private RubyString multiplyByteList(ThreadContext context,IRubyObject arg){
  int len=RubyNumeric.num2int(arg);
  if (len < 0)   throw context.runtime.newArgumentError("negative argument");
  if (len > 0 && Integer.MAX_VALUE / len < value.getRealSize()) {
    throw context.runtime.newArgumentError("argument too big");
  }
  ByteList bytes=new ByteList(len*=value.getRealSize());
  if (len > 0) {
    bytes.setRealSize(len);
    int n=value.getRealSize();
    System.arraycopy(value.getUnsafeBytes(),value.getBegin(),bytes.getUnsafeBytes(),0,n);
    while (n <= len >> 1) {
      System.arraycopy(bytes.getUnsafeBytes(),0,bytes.getUnsafeBytes(),n,n);
      n<<=1;
    }
    System.arraycopy(bytes.getUnsafeBytes(),0,bytes.getUnsafeBytes(),n,len - n);
  }
  RubyString result=new RubyString(context.runtime,getMetaClass(),bytes);
  result.infectBy(this);
  return result;
}
