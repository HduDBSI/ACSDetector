@Override public Instr clone(CloneInfo ii){
  return new ModuleVersionGuardInstr(module,expectedVersion,getCandidateObject().cloneForInlining(ii),ii.getRenamedLabel(getFailurePathLabel()));
}
