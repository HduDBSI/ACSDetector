public static double getDouble(){
  return 8.5;
}
