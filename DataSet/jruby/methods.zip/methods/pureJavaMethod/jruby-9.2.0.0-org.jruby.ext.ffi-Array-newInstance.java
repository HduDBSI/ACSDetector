@JRubyMethod(name="new",required=2,meta=true) public static final IRubyObject newInstance(ThreadContext context,IRubyObject klass,IRubyObject componentType,IRubyObject length){
  if (!(componentType instanceof Type)) {
    throw context.runtime.newTypeError(componentType,getTypeClass(context.runtime));
  }
  return new Array(context.runtime,(RubyClass)klass,(Type)componentType,RubyNumeric.fix2int(length));
}
