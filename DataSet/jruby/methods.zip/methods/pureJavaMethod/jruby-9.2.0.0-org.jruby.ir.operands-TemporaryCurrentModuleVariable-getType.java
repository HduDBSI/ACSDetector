@Override public TemporaryVariableType getType(){
  return TemporaryVariableType.CURRENT_MODULE;
}
