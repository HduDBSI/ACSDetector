public RaiseException newRegexpError(String message){
  return newRaiseException(getRegexpError(),message);
}
