public JRubyFiberLocal(Ruby runtime,RubyClass type){
  super(runtime,type);
}
