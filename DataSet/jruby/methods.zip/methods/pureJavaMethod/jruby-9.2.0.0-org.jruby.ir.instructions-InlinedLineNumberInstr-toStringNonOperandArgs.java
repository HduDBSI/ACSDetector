@Override public String[] toStringNonOperandArgs(){
  String[] base=super.toStringNonOperandArgs();
  String[] args=Arrays.copyOf(base,base.length + 1);
  args[args.length - 1]="scope_name: " + scope.getId();
  return args;
}
