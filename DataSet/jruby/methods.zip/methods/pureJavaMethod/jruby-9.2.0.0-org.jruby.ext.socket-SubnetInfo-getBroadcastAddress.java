public String getBroadcastAddress(){
  return format(toArray(broadcast()));
}
