/** 
 * Get whether we are saving the DATA contents of the file.
 */
public boolean isSaveData(){
  return saveData;
}
