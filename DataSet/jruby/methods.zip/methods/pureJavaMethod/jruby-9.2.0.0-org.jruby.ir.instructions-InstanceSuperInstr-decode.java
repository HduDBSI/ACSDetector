public static InstanceSuperInstr decode(IRReaderDecoder d){
  if (RubyInstanceConfig.IR_READING_DEBUG)   System.out.println("decoding super");
  int callTypeOrdinal=d.decodeInt();
  if (RubyInstanceConfig.IR_READING_DEBUG)   System.out.println("decoding super, calltype(ord):  " + callTypeOrdinal);
  RubySymbol name=d.decodeSymbol();
  if (RubyInstanceConfig.IR_READING_DEBUG)   System.out.println("decoding super, methaddr:  " + name);
  Operand receiver=d.decodeOperand();
  int argsCount=d.decodeInt();
  boolean hasClosureArg=argsCount < 0;
  int argsLength=hasClosureArg ? (-1 * (argsCount + 1)) : argsCount;
  if (RubyInstanceConfig.IR_READING_DEBUG)   System.out.println("ARGS: " + argsLength + ", CLOSURE: "+ hasClosureArg);
  Operand[] args=new Operand[argsLength];
  for (int i=0; i < argsLength; i++) {
    args[i]=d.decodeOperand();
  }
  Operand closure=hasClosureArg ? d.decodeOperand() : null;
  return new InstanceSuperInstr(d.decodeVariable(),receiver,name,args,closure,d.getCurrentScope().maybeUsingRefinements());
}
