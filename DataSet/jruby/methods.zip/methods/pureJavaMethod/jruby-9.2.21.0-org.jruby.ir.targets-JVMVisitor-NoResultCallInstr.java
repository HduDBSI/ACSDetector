@Override public void NoResultCallInstr(NoResultCallInstr noResultCallInstr){
  compileCallCommon(jvmMethod(),noResultCallInstr);
}
