/** 
 * Retrieve an encoded int in big endian starting at index in the string value.
 * @param encode string to get int from
 * @return the decoded integer
 */
private static long decodeIntUnsignedBigEndian(ByteBuffer encode){
  return (long)encode.getInt() & 0xFFFFFFFFL;
}
