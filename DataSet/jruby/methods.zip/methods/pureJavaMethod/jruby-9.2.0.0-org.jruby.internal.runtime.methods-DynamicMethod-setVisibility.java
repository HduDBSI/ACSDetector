/** 
 * Set the visibility of this method.
 * @param visibility The visibility of this method
 */
public void setVisibility(Visibility visibility){
  this.visibility=(byte)visibility.ordinal();
}
