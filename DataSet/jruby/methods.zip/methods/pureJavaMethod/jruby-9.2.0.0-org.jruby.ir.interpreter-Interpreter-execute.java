@Override protected IRubyObject execute(Ruby runtime,IRScriptBody irScope,IRubyObject self){
  BeginEndInterpreterContext ic=(BeginEndInterpreterContext)irScope.getInterpreterContext();
  if (IRRuntimeHelpers.shouldPrintIR(runtime)) {
    ByteArrayOutputStream baos=IRDumper.printIR(irScope,false);
    LOG.info("Printing simple IR for " + irScope.getId() + ":\n"+ new String(baos.toByteArray()));
  }
  ThreadContext context=runtime.getCurrentContext();
  String name=ROOT;
  if (IRRuntimeHelpers.isDebug())   LOG.info("Executing {}",ic);
  StaticScope scope=ic.getStaticScope();
  RubyModule currModule=scope.getModule();
  if (currModule == null) {
    currModule=context.getRuntime().getObject();
  }
  scope.setModule(currModule);
  IRRuntimeHelpers.prepareScriptScope(context,scope);
  context.setCurrentVisibility(Visibility.PRIVATE);
  try {
    runBeginBlocks(ic.getBeginBlocks(),context,self,scope,null);
    return INTERPRET_ROOT(context,self,ic,currModule,name);
  }
 catch (  IRBreakJump bj) {
    throw IRException.BREAK_LocalJumpError.getException(context.runtime);
  }
 finally {
    dumpStats();
    context.popScope();
  }
}
