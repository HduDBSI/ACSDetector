public static Class createRealImplClass(Class superClass,Class[] interfaces,RubyClass rubyClass,Ruby ruby,String name){
  String[] superTypeNames=new String[interfaces.length];
  Map<String,List<Method>> simpleToAll=buildSimpleToAllMap(interfaces,superTypeNames,rubyClass);
  Class newClass=defineRealImplClass(ruby,name,superClass,superTypeNames,simpleToAll);
  for (  Class ifc : interfaces) {
    assert ifc.isAssignableFrom(newClass);
  }
  return newClass;
}
