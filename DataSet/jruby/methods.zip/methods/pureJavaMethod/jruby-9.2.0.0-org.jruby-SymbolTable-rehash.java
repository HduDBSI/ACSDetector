private SymbolEntry[] rehash(){
  SymbolEntry[] oldTable=symbolTable;
  int oldCapacity=oldTable.length;
  if (oldCapacity >= MAXIMUM_CAPACITY)   return oldTable;
  int newCapacity=oldCapacity << 1;
  SymbolEntry[] newTable=new SymbolEntry[newCapacity];
  threshold=(int)(newCapacity * loadFactor);
  int sizeMask=newCapacity - 1;
  SymbolEntry e;
  for (int i=oldCapacity; --i >= 0; ) {
    e=oldTable[i];
    if (e == null)     continue;
    SymbolEntry next=e.next;
    int idx=e.hash & sizeMask;
    if (next == null) {
      newTable[idx]=e;
    }
 else {
      SymbolEntry lastRun=e;
      int lastIdx=idx;
      for (SymbolEntry last=next; last != null; last=last.next) {
        int k=last.hash & sizeMask;
        if (k != lastIdx) {
          lastIdx=k;
          lastRun=last;
        }
      }
      newTable[lastIdx]=lastRun;
      for (SymbolEntry p=e; p != lastRun; p=p.next) {
        int k=p.hash & sizeMask;
        SymbolEntry n=newTable[k];
        newTable[k]=new SymbolEntry(p.hash,p.name,p.bytes,p.symbol.get(),n,p.hardReference != null);
      }
    }
  }
  symbolTable=newTable;
  return newTable;
}
