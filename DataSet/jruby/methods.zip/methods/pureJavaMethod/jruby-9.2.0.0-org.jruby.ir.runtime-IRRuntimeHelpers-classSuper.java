@Interp public static IRubyObject classSuper(ThreadContext context,IRubyObject self,String id,RubyModule definingModule,IRubyObject[] args,Block block){
  RubyClass superClass=definingModule.getMetaClass().getMethodLocation().getSuperClass();
  DynamicMethod method=superClass != null ? superClass.searchMethod(id) : UndefinedMethod.INSTANCE;
  IRubyObject rVal=method.isUndefined() ? Helpers.callMethodMissing(context,self,method.getVisibility(),id,CallType.SUPER,args,block) : method.call(context,self,superClass,id,args,block);
  return rVal;
}
