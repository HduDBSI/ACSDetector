public static RaiseException makeEconvException(Ruby runtime,EConv ec){
  final StringBuilder mesg=new StringBuilder();
  RaiseException exc;
  final EConvResult result=ec.lastError.getResult();
  if (result == EConvResult.InvalidByteSequence || result == EConvResult.IncompleteInput) {
    byte[] errBytes=ec.lastError.getErrorBytes();
    int errBytesP=ec.lastError.getErrorBytesP();
    int errorLen=ec.lastError.getErrorBytesLength();
    ByteList _bytes=new ByteList(errBytes,errBytesP,errorLen - errBytesP);
    RubyString bytes=RubyString.newString(runtime,_bytes);
    RubyString dumped=(RubyString)bytes.dump();
    int readagainLen=ec.lastError.getReadAgainLength();
    IRubyObject bytes2=runtime.getNil();
    if (result == EConvResult.IncompleteInput) {
      mesg.append("incomplete ").append(dumped).append(" on ").append(new String(ec.lastError.getSource()));
    }
 else     if (readagainLen != 0) {
      bytes2=RubyString.newString(runtime,new ByteList(errBytes,errorLen + errBytesP,ec.lastError.getReadAgainLength()));
      IRubyObject dumped2=((RubyString)bytes2).dump();
      mesg.append(dumped).append(" followed by ").append(dumped2).append(" on ").append(new String(ec.lastError.getSource()));
    }
 else {
      mesg.append(dumped).append(" on ").append(new String(ec.lastError.getSource()));
    }
    exc=runtime.newInvalidByteSequenceError(mesg.toString());
    exc.getException().setInternalVariable("error_bytes",bytes);
    exc.getException().setInternalVariable("readagain_bytes",bytes2);
    exc.getException().setInternalVariable("incomplete_input",result == EConvResult.IncompleteInput ? runtime.getTrue() : runtime.getFalse());
    return makeEConvExceptionSetEncs(exc,runtime,ec);
  }
 else   if (result == EConvResult.UndefinedConversion) {
    byte[] errBytes=ec.lastError.getErrorBytes();
    int errBytesP=ec.lastError.getErrorBytesP();
    int errorLen=ec.lastError.getErrorBytesLength();
    final byte[] errSource=ec.lastError.getSource();
    if (Arrays.equals(errSource,"UTF-8".getBytes())) {
    }
    RubyString bytes=RubyString.newString(runtime,new ByteList(errBytes,errBytesP,errorLen - errBytesP));
    RubyString dumped=(RubyString)bytes.dump();
    if (Arrays.equals(errSource,ec.source) && Arrays.equals(ec.lastError.getDestination(),ec.destination)) {
      mesg.append(dumped).append(" from ").append(new String(errSource)).append(" to ").append(new String(ec.lastError.getDestination()));
    }
 else {
      mesg.append(dumped).append(" to ").append(new String(ec.lastError.getDestination())).append(" in conversion from ").append(new String(ec.source));
      for (int i=0; i < ec.numTranscoders; i++) {
        mesg.append(" to ").append(new String(ec.elements[i].transcoding.transcoder.getDestination()));
      }
    }
    exc=runtime.newUndefinedConversionError(mesg.toString());
    EncodingDB.Entry entry=runtime.getEncodingService().findEncodingOrAliasEntry(errSource);
    if (entry != null) {
      bytes.setEncoding(entry.getEncoding());
      exc.getException().setInternalVariable("error_char",bytes);
    }
    return makeEConvExceptionSetEncs(exc,runtime,ec);
  }
  return null;
}
