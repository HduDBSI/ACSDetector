private boolean parseExponent(){
  if (eatUnderscores())   return isEOS();
  byte value=next();
  int exponent=0;
  int digits=0;
  boolean negative=false;
  if (value == '-') {
    negative=true;
  }
 else   if (value != '+') {
    previous();
  }
  while (!isEOS()) {
    value=next();
    if (isDigit(value)) {
      if (digits < EXPONENT_DIGITS_LIMIT) {
        if (value != '0' || digits > 0) {
          digits++;
          exponent=10 * exponent + (value - '0');
        }
      }
 else {
        return tooLargeExponent(chars[0] == '-',negative);
      }
    }
 else     if (isWhitespace(value)) {
      skipWhitespace();
      break;
    }
 else     if (value == '_') {
      verifyNumberAfterUnderscore();
    }
 else {
      strictError();
      stopParsing();
      break;
    }
  }
  if (negative) {
    exponent=-exponent;
  }
  exponent+=adjustExponent;
  if (-MAX_EXPONENT <= exponent && exponent <= MAX_EXPONENT) {
    addExponentToResult(exponent);
    wroteExponent=true;
    return isEOS();
  }
 else {
    return tooLargeExponent(chars[0] == '-',negative);
  }
}
