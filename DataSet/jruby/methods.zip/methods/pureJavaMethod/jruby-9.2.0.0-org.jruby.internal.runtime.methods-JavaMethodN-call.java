public final IRubyObject call(ThreadContext context,IRubyObject self,RubyModule clazz,String name,IRubyObject[] args,Block block){
switch (args.length) {
case 0:
    return call(context,self,clazz,name);
case 1:
  return call(context,self,clazz,name,args[0]);
case 2:
return call(context,self,clazz,name,args[0],args[1]);
default :
return call(context,self,clazz,name,args);
}
}
