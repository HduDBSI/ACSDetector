/** 
 * Set upon completion of IRBuild of this IRMethod.
 */
public void setArgumentDescriptors(ArgumentDescriptor[] argDesc){
  this.argDesc=argDesc;
}
