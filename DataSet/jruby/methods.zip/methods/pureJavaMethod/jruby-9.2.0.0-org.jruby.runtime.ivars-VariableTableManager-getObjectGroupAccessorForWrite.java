/** 
 * Retrieve the write accessor for object group.
 * @return the write accessor for object group
 */
public VariableAccessor getObjectGroupAccessorForWrite(){
  return objectGroupVariableAccessorField.getVariableAccessorForWrite(this);
}
