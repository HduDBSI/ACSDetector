@Override protected void setUp() throws Exception {
  super.setUp();
  config=new RubyInstanceConfig();
}
