public final org.jruby.ext.ffi.Pointer getCallback(Ruby runtime,CallbackInfo cbInfo,Object proc){
  return proc instanceof RubyObject ? getCallbackFactory(runtime,cbInfo).getCallback((RubyObject)proc) : getCallbackFactory(runtime,cbInfo).newCallback(proc);
}
