private static void checkLevel(Ruby runtime,int level){
  if (level != JZlib.Z_DEFAULT_COMPRESSION && (level < JZlib.Z_NO_COMPRESSION || level > JZlib.Z_BEST_COMPRESSION)) {
    throw RubyZlib.newStreamError(runtime,"stream error: invalid level");
  }
}
