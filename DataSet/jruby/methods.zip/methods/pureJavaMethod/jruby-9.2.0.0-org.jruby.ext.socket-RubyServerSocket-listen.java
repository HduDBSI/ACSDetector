@JRubyMethod(name="listen") public IRubyObject listen(ThreadContext context,IRubyObject backlog){
  context.runtime.getWarnings().warnOnce(IRubyWarnings.ID.LISTEN_SERVER_SOCKET,"pass backlog to #bind instead of #listen (http://wiki.jruby.org/ServerSocket)");
  return context.runtime.newFixnum(0);
}
