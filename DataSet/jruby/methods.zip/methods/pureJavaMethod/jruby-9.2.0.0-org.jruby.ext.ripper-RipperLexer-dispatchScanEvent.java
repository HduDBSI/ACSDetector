public void dispatchScanEvent(int token){
  if (!hasScanEvent())   return;
  yaccValue=scanEventValue(token);
}
