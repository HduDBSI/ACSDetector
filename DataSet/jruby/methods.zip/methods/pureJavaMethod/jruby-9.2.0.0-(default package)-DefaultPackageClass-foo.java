public String foo(){
  return "foo";
}
