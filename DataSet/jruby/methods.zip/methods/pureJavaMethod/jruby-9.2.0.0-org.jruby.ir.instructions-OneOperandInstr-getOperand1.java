public Operand getOperand1(){
  return operand1;
}
