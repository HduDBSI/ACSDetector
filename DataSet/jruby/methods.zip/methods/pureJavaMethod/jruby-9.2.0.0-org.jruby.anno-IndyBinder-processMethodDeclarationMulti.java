public void processMethodDeclarationMulti(List<ExecutableElement> methods){
  Handle[] handles=new Handle[5];
  List<ExecutableElementDescriptor> descs=new ArrayList<>();
  boolean meta=false;
  boolean isStatic=false;
  JRubyMethod anno=null;
  int min=Integer.MAX_VALUE;
  int max=0;
  Map<Handle,ExecutableElementDescriptor> handleToDesc=new HashMap<>();
  for (  ExecutableElement method : methods) {
    anno=method.getAnnotation(JRubyMethod.class);
    ExecutableElementDescriptor desc=new ExecutableElementDescriptor(method);
    descs.add(desc);
    if (anno != null && mv != null) {
      isStatic|=desc.isStatic;
      CharSequence qualifiedName=desc.declaringClassName;
      boolean hasContext=desc.hasContext;
      boolean hasBlock=desc.hasBlock;
      StringBuilder buffer=new StringBuilder(method.getReturnType().toString()).append(" foo(");
      boolean first=true;
      for (      VariableElement parameter : method.getParameters()) {
        if (!first)         buffer.append(',');
        first=false;
        buffer.append(parameter.asType().toString());
      }
      buffer.append(')');
      Handle handle=new Handle(isStatic ? H_INVOKESTATIC : H_INVOKEVIRTUAL,qualifiedName.toString().replace('.','/'),method.getSimpleName().toString(),Method.getMethod(buffer.toString()).getDescriptor(),false);
      int handleOffset=calculateHandleOffset(method.getParameters().size(),anno.required(),anno.optional(),anno.rest(),isStatic,hasContext,hasBlock);
      handles[handleOffset]=handle;
      handleToDesc.put(handle,desc);
      meta|=anno.meta();
      int specificArity=desc.calculateSpecificCallArity();
      if (specificArity != -1) {
        if (specificArity < min)         min=specificArity;
        if (specificArity > max)         max=specificArity;
      }
 else {
        if (desc.required < min)         min=desc.required;
        if (desc.rest)         max=Integer.MAX_VALUE;
        if (desc.required + desc.optional > max)         max=desc.required + desc.optional;
      }
    }
  }
  int implClass=meta ? SINGLETONCLASS : CLASS;
  mv.newobj("org/jruby/internal/runtime/methods/HandleMethod");
  mv.dup();
  mv.aload(implClass);
  mv.getstatic(p(Visibility.class),anno.visibility().name(),ci(Visibility.class));
  mv.ldc(encodeSignature(0,0,0,0,0,true,false));
  mv.ldc(true);
  mv.ldc(anno.notImplemented());
  DescriptorInfo info=new DescriptorInfo(descs);
  mv.ldc(info.getParameterDesc());
  mv.ldc(min);
  mv.ldc(max);
  for (int i=0; i < 5; i++) {
    if (handles[i] != null) {
      mv.ldc(handles[i]);
      adaptHandle(handleToDesc.get(handles[i]),implClass);
    }
 else {
      mv.aconst_null();
    }
  }
  Method handleInit=Method.getMethod("void foo(org.jruby.RubyModule, org.jruby.runtime.Visibility, long, boolean, boolean, java.lang.String, int, int, java.util.concurrent.Callable, java.util.concurrent.Callable, java.util.concurrent.Callable, java.util.concurrent.Callable, java.util.concurrent.Callable)");
  mv.invokespecial("org/jruby/internal/runtime/methods/HandleMethod","<init>",handleInit.getDescriptor());
  mv.astore(BASEMETHOD);
  generateMethodAddCalls(methods.get(0),anno);
}
