private IRubyObject enumerateChars(ThreadContext context,String name,Block block,boolean wantarray){
  Ruby runtime=context.runtime;
  RubyString str=this;
  IRubyObject orig=str;
  IRubyObject substr;
  int i, len, n;
  byte[] ptrBytes;
  int ptr;
  Encoding enc;
  RubyArray ary=null;
  str=strDup(runtime);
  ByteList strByteList=str.getByteList();
  ptrBytes=strByteList.unsafeBytes();
  ptr=strByteList.begin();
  len=strByteList.getRealSize();
  enc=str.getEncoding();
  if (block.isGiven()) {
    if (wantarray) {
      runtime.getWarnings().warning("passing a block to String#" + name + " is deprecated");
      wantarray=false;
    }
  }
 else {
    if (wantarray)     ary=RubyArray.newArray(runtime,str.strLength());
 else     return enumeratorizeWithSize(context,this,name,eachCharSizeFn());
  }
switch (getCodeRange()) {
case CR_VALID:
case CR_7BIT:
    for (i=0; i < len; i+=n) {
      n=StringSupport.encFastMBCLen(ptrBytes,ptr + i,ptr + len,enc);
      substr=str.substr(runtime,i,n);
      if (wantarray)       ary.push(substr);
 else       block.yield(context,substr);
    }
  break;
default :
for (i=0; i < len; i+=n) {
  n=StringSupport.length(enc,ptrBytes,ptr + i,ptr + len);
  substr=str.substr(runtime,i,n);
  if (wantarray)   ary.push(substr);
 else   block.yield(context,substr);
}
}
if (wantarray) return ary;
 else return orig;
}
