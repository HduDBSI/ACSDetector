public static IRubyObject backrefMatchPre(ThreadContext context){
  IRubyObject backref=context.getBackRef();
  return RubyRegexp.match_pre(backref);
}
