/** 
 * Preprocess the given string for use in regexp, raising errors for encoding incompatibilities that arise. This version does not produce a new, unescaped version of the bytelist, and simply does the string-walking portion of the logic.
 * @param runtime current runtime
 * @param str string to preprocess
 * @param enc string's encoding
 * @param fixedEnc new encoding after fixing
 * @param mode mode of errors
 */
private static void preprocessLight(Ruby runtime,ByteList str,Encoding enc,Encoding[] fixedEnc,RegexpSupport.ErrorMode mode){
  if (enc.isAsciiCompatible()) {
    fixedEnc[0]=null;
  }
 else {
    fixedEnc[0]=enc;
  }
  boolean hasProperty=RegexpSupport.unescapeNonAscii(runtime,null,str.getUnsafeBytes(),str.getBegin(),str.getBegin() + str.getRealSize(),enc,fixedEnc,str,mode);
  if (hasProperty && fixedEnc[0] == null)   fixedEnc[0]=enc;
}
