public static CallInstr decode(IRReaderDecoder d){
  if (RubyInstanceConfig.IR_READING_DEBUG)   System.out.println("decodeCall");
  int callTypeOrdinal=d.decodeInt();
  CallType callType=CallType.fromOrdinal(callTypeOrdinal);
  if (RubyInstanceConfig.IR_READING_DEBUG)   System.out.println("decodeCall - calltype:  " + callType);
  RubySymbol name=d.decodeSymbol();
  if (RubyInstanceConfig.IR_READING_DEBUG)   System.out.println("decodeCall - methaddr:  " + name);
  Operand receiver=d.decodeOperand();
  if (RubyInstanceConfig.IR_READING_DEBUG)   System.out.println("decodeCall - receiver:  " + receiver);
  int argsCount=d.decodeInt();
  if (RubyInstanceConfig.IR_READING_DEBUG)   System.out.println("decodeCall - # of args:  " + argsCount);
  boolean hasClosureArg=argsCount < 0;
  int argsLength=hasClosureArg ? (-1 * (argsCount + 1)) : argsCount;
  if (RubyInstanceConfig.IR_READING_DEBUG)   System.out.println("decodeCall - # of args(2): " + argsLength);
  if (RubyInstanceConfig.IR_READING_DEBUG)   System.out.println("decodeCall - hasClosure: " + hasClosureArg);
  Operand[] args=new Operand[argsLength];
  for (int i=0; i < argsLength; i++) {
    args[i]=d.decodeOperand();
  }
  Operand closure=hasClosureArg ? d.decodeOperand() : null;
  if (RubyInstanceConfig.IR_READING_DEBUG)   System.out.println("before result");
  Variable result=d.decodeVariable();
  if (RubyInstanceConfig.IR_READING_DEBUG)   System.out.println("decoding call, result:  " + result);
  return create(d.getCurrentScope(),callType,result,name,receiver,args,closure);
}
