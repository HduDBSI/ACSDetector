public Operand buildFloat(FloatNode node){
  return new Float(node.getValue());
}
