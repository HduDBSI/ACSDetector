public final void putNativeLong(long offset,long value){
  if (LONG_SIZE == 32) {
    putInt(offset,(int)value);
  }
 else {
    putLong(offset,value);
  }
}
