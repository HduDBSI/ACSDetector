/** 
 * Sets object's variables to those in the supplied object, removing/replacing any previously defined variables of the same name. Applies to all variable types (ivar/cvar/constant/internal).
 * @param source the source object containing the variables to sync
 */
void syncVariables(IRubyObject source);
