public IRubyObject readAll(ThreadContext context,int siz,IRubyObject str){
  Ruby runtime=context.runtime;
  int bytes;
  int n;
  int pos;
  Encoding enc;
  int cr;
  boolean locked=lock();
  try {
    if (needsReadConversion()) {
      SET_BINARY_MODE();
      str=EncodingUtils.setStrBuf(runtime,str,0);
      makeReadConversion(context);
      while (true) {
        Object v;
        if (cbuf.len != 0) {
          str=shiftCbuf(context,cbuf.len,str);
        }
        v=fillCbuf(context,0);
        if (!v.equals(MORE_CHAR_SUSPENDED) && !v.equals(MORE_CHAR_FINISHED)) {
          if (cbuf.len != 0) {
            str=shiftCbuf(context,cbuf.len,str);
          }
          throw (RaiseException)v;
        }
        if (v.equals(MORE_CHAR_FINISHED)) {
          clearReadConversion();
          return EncodingUtils.ioEncStr(runtime,str,this);
        }
      }
    }
    NEED_NEWLINE_DECORATOR_ON_READ_CHECK();
    bytes=0;
    pos=0;
    enc=readEncoding(runtime);
    cr=0;
    if (siz == 0)     siz=BUFSIZ;
    str=EncodingUtils.setStrBuf(runtime,str,siz);
    for (; ; ) {
      READ_CHECK(context);
      n=fread(context,str,bytes,siz - bytes);
      if (n == 0 && bytes == 0) {
        ((RubyString)str).resize(0);
        break;
      }
      bytes+=n;
      ByteList strByteList=((RubyString)str).getByteList();
      strByteList.setRealSize(bytes);
      if (cr != StringSupport.CR_BROKEN)       pos+=StringSupport.codeRangeScanRestartable(enc,strByteList.unsafeBytes(),strByteList.begin() + pos,strByteList.begin() + bytes,cr);
      if (bytes < siz)       break;
      siz+=BUFSIZ;
      ((RubyString)str).modify(BUFSIZ);
    }
    str=EncodingUtils.ioEncStr(runtime,str,this);
  }
  finally {
    if (locked)     unlock();
  }
  ((RubyString)str).setCodeRange(cr);
  return str;
}
