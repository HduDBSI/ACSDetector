private static DynamicScope getContainingReturnToScope(DynamicScope returnLocationScope){
  for (DynamicScope current=returnLocationScope; current != null; current=current.getParentScope()) {
    if (current.isReturnTarget())     return current;
  }
  return null;
}
