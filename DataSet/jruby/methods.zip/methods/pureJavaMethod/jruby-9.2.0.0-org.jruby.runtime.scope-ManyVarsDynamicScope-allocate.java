private void allocate(){
  if (variableValues == null) {
    int size=staticScope.getNumberOfVariables();
    variableValues=new IRubyObject[size];
  }
}
