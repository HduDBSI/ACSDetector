private final boolean isCharArray(){
  return arrayType.getComponentType().nativeType == NativeType.CHAR || arrayType.getComponentType().nativeType == NativeType.UCHAR;
}
