private IRubyObject getline(ThreadContext context,final IRubyObject rs,int limit,boolean chomp){
  Ruby runtime=context.runtime;
  IRubyObject str;
  checkReadable();
  int n;
  if (isEndOfString()) {
    return context.nil;
  }
  StringIOData ptr=this.ptr;
  Encoding enc=ptr.enc;
synchronized (ptr) {
    final ByteList string=ptr.string.getByteList();
    final byte[] stringBytes=string.getUnsafeBytes();
    int begin=string.getBegin();
    int s=begin + ptr.pos;
    int e=begin + string.getRealSize();
    int p;
    int w=0;
    if (limit > 0 && s + limit < e) {
      e=ptr.enc.rightAdjustCharHead(stringBytes,s,s + limit,e);
    }
    if (rs.isNil()) {
      if (chomp) {
        w=chompNewlineWidth(stringBytes,s,e);
      }
      str=strioSubstr(runtime,ptr.pos,e - s - w,enc);
    }
 else     if ((n=((RubyString)rs).size()) == 0) {
      p=s;
      while (stringBytes[p] == '\n') {
        if (++p == e) {
          return context.nil;
        }
      }
      s=p;
      while ((p=StringSupport.memchr(stringBytes,p,'\n',e - p)) != -1 && (p != e)) {
        p+=1;
        if (p == e)         break;
        if (stringBytes[p] == '\n') {
          e=p + 1;
          w=(chomp ? 1 : 0);
          break;
        }
 else         if (stringBytes[p] == '\r' && p < e && stringBytes[p + 1] == '\n') {
          e=p + 2;
          w=(chomp ? 2 : 0);
          break;
        }
      }
      if (w == 0 && chomp) {
        w=chompNewlineWidth(stringBytes,s,e);
      }
      str=strioSubstr(runtime,s - begin,e - s - w,enc);
    }
 else     if (n == 1) {
      RubyString strStr=(RubyString)rs;
      ByteList strByteList=strStr.getByteList();
      if ((p=StringSupport.memchr(stringBytes,s,strByteList.get(0),e - s)) != -1) {
        e=p + 1;
        w=(chomp ? ((p > s && stringBytes[p - 1] == '\r') ? 1 : 0) + 1 : 0);
      }
      str=strioSubstr(runtime,ptr.pos,e - s - w,enc);
    }
 else {
      if (n < e - s) {
        RubyString rsStr=(RubyString)rs;
        ByteList rsByteList=rsStr.getByteList();
        byte[] rsBytes=rsByteList.getUnsafeBytes();
        int[] skip=new int[1 << CHAR_BIT];
        int pos;
        p=rsByteList.getBegin();
        bm_init_skip(skip,rsBytes,p,n);
        if ((pos=bm_search(rsBytes,p,n,stringBytes,s,e - s,skip)) >= 0) {
          e=s + pos + n;
        }
      }
      str=strioSubstr(runtime,ptr.pos,e - s - w,enc);
    }
    ptr.pos=e - begin;
    ptr.lineno++;
  }
  return str;
}
