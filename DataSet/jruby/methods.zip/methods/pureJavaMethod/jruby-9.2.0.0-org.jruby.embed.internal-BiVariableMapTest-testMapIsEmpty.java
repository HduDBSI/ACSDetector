@Test public void testMapIsEmpty(){
  ScriptingContainer container=new ScriptingContainer(LocalContextScope.SINGLETHREAD,LocalVariableBehavior.TRANSIENT);
  assertTrue(container.getVarMap().isEmpty());
}
