Wrapper(Runnable runnable){
  _runnable=runnable;
}
