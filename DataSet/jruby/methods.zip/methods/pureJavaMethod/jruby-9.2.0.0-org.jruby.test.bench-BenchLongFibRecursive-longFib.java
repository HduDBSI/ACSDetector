public static long longFib(long n){
  if (n < 2) {
    return n;
  }
 else {
    return longFib(n - 2) + longFib(n - 1);
  }
}
