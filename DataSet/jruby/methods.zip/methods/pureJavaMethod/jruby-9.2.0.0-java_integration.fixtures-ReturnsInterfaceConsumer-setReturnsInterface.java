public void setReturnsInterface(ReturnsInterface returnsInterface){
  this.returnsInterface=returnsInterface;
}
