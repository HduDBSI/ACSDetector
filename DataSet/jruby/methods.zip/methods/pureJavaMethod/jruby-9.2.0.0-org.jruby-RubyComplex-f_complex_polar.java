/** 
 * f_complex_polar
 */
private static IRubyObject f_complex_polar(ThreadContext context,RubyClass clazz,IRubyObject x,IRubyObject y){
  assert !(x instanceof RubyComplex) && !(y instanceof RubyComplex);
  return canonicalizeInternal(context,clazz,f_mul(context,x,m_cos(context,y)),f_mul(context,x,m_sin(context,y)));
}
