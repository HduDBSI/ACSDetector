public int threadFlock(ThreadContext context,final int lockMode){
  int ret=0;
  try {
    ret=context.getThread().executeTask(context,this,new RubyThread.Task<OpenFile,Integer>(){
      @Override public Integer run(      ThreadContext context,      OpenFile openFile) throws InterruptedException {
        return posix.flock(fd,lockMode);
      }
      @Override public void wakeup(      RubyThread thread,      OpenFile openFile){
        thread.getNativeThread().interrupt();
      }
    }
);
  }
 catch (  InterruptedException ie) {
  }
  return ret;
}
