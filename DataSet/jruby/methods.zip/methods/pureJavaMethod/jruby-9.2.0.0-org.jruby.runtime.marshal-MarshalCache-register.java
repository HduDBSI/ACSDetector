public void register(IRubyObject value){
  if (value instanceof RubySymbol) {
    registerSymbol(value.asJavaString());
  }
 else {
    linkCache.put(value,Integer.valueOf(linkCache.size()));
  }
}
