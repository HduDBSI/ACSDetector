@Deprecated public IRubyObject flatten_bang19(ThreadContext context){
  return flatten_bang(context);
}
