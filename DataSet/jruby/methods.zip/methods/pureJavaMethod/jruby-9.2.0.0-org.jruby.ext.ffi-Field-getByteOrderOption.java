static ByteOrder getByteOrderOption(ThreadContext context,IRubyObject[] args){
  ByteOrder order=ByteOrder.nativeOrder();
  if (args.length > 3 && args[3] instanceof RubyHash) {
    RubyHash options=(RubyHash)args[3];
    IRubyObject byte_order=options.fastARef(RubySymbol.newSymbol(context.runtime,"byte_order"));
    if (byte_order instanceof RubySymbol || byte_order instanceof RubyString) {
      String orderName=byte_order.asJavaString();
      if ("network".equals(orderName) || "big".equals(orderName)) {
        order=ByteOrder.BIG_ENDIAN;
      }
 else       if ("little".equals(orderName)) {
        order=ByteOrder.LITTLE_ENDIAN;
      }
    }
  }
  return order;
}
