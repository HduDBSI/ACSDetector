@JRubyMethod(name="socket?") public IRubyObject socket_p(){
  checkInitialized();
  return getRuntime().newBoolean(stat.isSocket());
}
