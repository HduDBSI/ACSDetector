protected final static void postNoFrameDummyScope(ThreadContext context){
  context.postMethodScopeOnly();
}
