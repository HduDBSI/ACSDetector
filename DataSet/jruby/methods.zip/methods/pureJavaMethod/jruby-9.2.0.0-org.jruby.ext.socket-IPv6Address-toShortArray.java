private short[] toShortArray(){
  final short[] shorts=new short[N_SHORTS];
  for (int i=0; i < N_SHORTS; i++) {
    if (inHighRange(i)) {
      shorts[i]=(short)(((highBits << i * 16) >>> 16 * (N_SHORTS - 1)) & 0xFFFF);
    }
 else {
      shorts[i]=(short)(((lowBits << i * 16) >>> 16 * (N_SHORTS - 1)) & 0xFFFF);
    }
  }
  return shorts;
}
