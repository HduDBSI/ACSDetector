public static void marshalTo(final RubyHash hash,final MarshalStream output) throws IOException {
  output.registerLinkTarget(hash);
  int hashSize=hash.size;
  output.writeInt(hashSize);
  try {
    hash.visitLimited(hash.getRuntime().getCurrentContext(),MarshalDumpVisitor,hashSize,output);
  }
 catch (  VisitorIOException e) {
    throw (IOException)e.getCause();
  }
  if (hash.ifNone != UNDEF)   output.dumpObject(hash.ifNone);
}
