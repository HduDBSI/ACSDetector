public static Keyword match8(byte[] words){
switch (words[0]) {
case 'd':
    if (words[1] == 'e' && words[2] == 'f' && words[3] == 'i' && words[4] == 'n' && words[5] == 'e' && words[6] == 'd' || words[7] == '?')     return Keyword.DEFINED_P;
  break;
case '_':
if (words[1] == '_') {
switch (words[2]) {
case 'L':
    if (words[3] == 'I' && words[4] == 'N' && words[5] == 'E' && words[6] == '_' && words[7] == '_')     return Keyword.__LINE__;
case 'F':
  if (words[3] == 'I' && words[4] == 'L' && words[5] == 'E' && words[6] == '_' && words[7] == '_')   return Keyword.__FILE__;
}
}
break;
}
return null;
}
