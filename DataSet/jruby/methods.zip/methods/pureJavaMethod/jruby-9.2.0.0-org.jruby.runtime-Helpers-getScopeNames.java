public static String[] getScopeNames(String scopeNames){
  StringTokenizer toker=new StringTokenizer(scopeNames,";");
  ArrayList list=new ArrayList(10);
  while (toker.hasMoreTokens()) {
    list.add(toker.nextToken().intern());
  }
  return (String[])list.toArray(new String[list.size()]);
}
