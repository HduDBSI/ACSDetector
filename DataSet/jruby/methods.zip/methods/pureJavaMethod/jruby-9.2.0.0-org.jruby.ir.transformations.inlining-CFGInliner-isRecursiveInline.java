private boolean isRecursiveInline(IRScope methodScope){
  return hostScope.getNearestMethod() == methodScope;
}
