@Override public Object interpret(ThreadContext context,StaticScope currScope,DynamicScope currDynScope,IRubyObject self,Object[] temp){
  RubyArray rubyArray=(RubyArray)getArray().retrieve(context,self,currScope,currDynScope,temp);
  return Helpers.viewArgsArray(context,rubyArray,preArgsCount,postArgsCount);
}
