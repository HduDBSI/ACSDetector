@JIT public static IRScope decodeScopeFromBytes(Ruby runtime,byte[] scopeBytes,String filename){
  try {
    return IRReader.load(runtime.getIRManager(),new IRReaderStream(runtime.getIRManager(),new ByteArrayInputStream(scopeBytes),new ByteList(filename.getBytes())));
  }
 catch (  IOException ioe) {
    return null;
  }
}
