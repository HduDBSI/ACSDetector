@Deprecated public static IRubyObject do_not_reverse_lookup(IRubyObject recv){
  return do_not_reverse_lookup(recv.getRuntime().getCurrentContext(),recv);
}
