private int questionMark() throws IOException {
  int c;
  if (isEND()) {
    setState(EXPR_VALUE);
    yaccValue=QUESTION;
    return '?';
  }
  c=nextc();
  if (c == EOF)   compile_error(PID.INCOMPLETE_CHAR_SYNTAX,"incomplete character syntax");
  if (Character.isWhitespace(c)) {
    if (!isARG()) {
      int c2=0;
switch (c) {
case ' ':
        c2='s';
      break;
case '\n':
    c2='n';
  break;
case '\t':
c2='t';
break;
case '\r':
c2='r';
break;
case '\f':
c2='f';
break;
}
if (c2 != 0) {
warnings.warn(ID.INVALID_CHAR_SEQUENCE,getFile(),ruby_sourceline,"invalid character syntax; use ?\\" + c2);
}
}
pushback(c);
setState(EXPR_VALUE);
yaccValue=QUESTION;
return '?';
}
if (!isASCII(c)) {
if (!tokadd_mbchar(c)) return EOF;
}
 else if (isIdentifierChar(c) && !peek('\n') && isNext_identchar()) {
newtok(true);
pushback(c);
setState(EXPR_VALUE);
yaccValue=QUESTION;
return '?';
}
 else if (c == '\\') {
if (peek('u')) {
nextc();
ByteList oneCharBL=new ByteList(2);
oneCharBL.setEncoding(getEncoding());
c=readUTFEscape(oneCharBL,false,false);
if (c >= 0x80) {
tokaddmbc(c,oneCharBL);
}
 else {
oneCharBL.append(c);
}
setState(EXPR_END);
yaccValue=new StrNode(getPosition(),oneCharBL);
return RubyParser.tCHAR;
}
 else {
c=readEscape();
}
}
 else {
newtok(true);
}
ByteList oneCharBL=new ByteList(1);
oneCharBL.setEncoding(getEncoding());
oneCharBL.append(c);
yaccValue=new StrNode(getPosition(),oneCharBL);
setState(EXPR_END);
return RubyParser.tCHAR;
}
