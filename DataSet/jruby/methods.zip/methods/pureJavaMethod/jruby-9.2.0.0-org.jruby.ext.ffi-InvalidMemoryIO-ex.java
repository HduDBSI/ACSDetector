protected RaiseException ex(){
  return RaiseException.from(runtime,getErrorClass(runtime),message);
}
