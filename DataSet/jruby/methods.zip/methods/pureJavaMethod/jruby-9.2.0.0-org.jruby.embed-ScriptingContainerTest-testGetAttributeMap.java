/** 
 * Test of getAttributeMap method, of class ScriptingContainer.
 */
@Test public void testGetAttributeMap(){
  logger1.info("getAttributeMap");
  ScriptingContainer instance=new ScriptingContainer(LocalContextScope.THREADSAFE);
  instance.setError(pstream);
  instance.setOutput(pstream);
  Map result=instance.getAttributeMap();
  Object obj=result.get(AttributeName.READER);
  assertEquals(obj.getClass(),java.io.InputStreamReader.class);
  obj=result.get(AttributeName.WRITER);
  assertEquals(obj.getClass(),java.io.PrintWriter.class);
  obj=result.get(AttributeName.ERROR_WRITER);
  assertEquals(obj.getClass(),java.io.PrintWriter.class);
  result.put(AttributeName.BASE_DIR,"/usr/local/lib");
  assertEquals("/usr/local/lib",result.get(AttributeName.BASE_DIR));
  result.put(AttributeName.LINENUMBER,5);
  assertEquals(5,result.get(AttributeName.LINENUMBER));
  result.put("むなしいきもち","虚");
  assertEquals("虚",result.get("むなしいきもち"));
  result.clear();
  instance.terminate();
}
