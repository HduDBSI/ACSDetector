public String getMethodCallSyntax(String obj,String m,String... args){
  if (m == null || m.length() == 0) {
    return "";
  }
  if (args == null || args.length == 0) {
    if (obj == null || obj.length() == 0) {
      return MessageFormat.format("{0}",m);
    }
 else {
      return MessageFormat.format("{0}.{1}",obj,m);
    }
  }
 else {
    StringBuilder builder=new StringBuilder();
    boolean first=true;
    for (    String arg : args) {
      if (!first) {
        builder.append(", ");
      }
      first=false;
      builder.append(arg);
    }
    if (obj == null || obj.length() == 0) {
      return MessageFormat.format("{0}({1})",m,builder.toString());
    }
 else {
      return MessageFormat.format("{0}.{1}({2})",obj,m,builder.toString());
    }
  }
}
