T coerce(RubyNumeric numeric,Class<T> target);
