private static ArrayList<ByteList> dirGlobs(ThreadContext context,String cwd,IRubyObject[] args,int flags){
  ArrayList<ByteList> dirs=new ArrayList<ByteList>();
  for (int i=0; i < args.length; i++) {
    dirs.addAll(Dir.push_glob(context.runtime,cwd,globArgumentAsByteList(context,args[i]),flags));
  }
  return dirs;
}
