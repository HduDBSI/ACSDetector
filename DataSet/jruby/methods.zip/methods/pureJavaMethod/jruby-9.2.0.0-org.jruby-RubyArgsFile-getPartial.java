private static IRubyObject getPartial(ThreadContext context,IRubyObject recv,IRubyObject[] args,boolean nonBlocking){
  final Ruby runtime=context.runtime;
  boolean noException=false;
  RubyString str=null;
  if (args.length > 1) {
    IRubyObject opts=TypeConverter.checkHashType(runtime,args[args.length - 1]);
    if (!opts.isNil() && runtime.getFalse() == ((RubyHash)opts).op_aref(context,runtime.newSymbol("exception"))) {
      noException=true;
    }
    if (args.length > 2 || opts.isNil()) {
      if (!args[1].isNil()) {
        args[1]=args[1].convertToString();
        str=(RubyString)args[1];
      }
    }
  }
  final ArgsFileData data=ArgsFileData.getArgsFileData(runtime);
  if (!data.next_argv(context)) {
    if (str != null)     str.clear();
    return RubyIO.nonblockEOF(runtime,noException);
  }
  IRubyObject res=((RubyIO)data.currentFile).getPartial(context,args,nonBlocking,noException);
  if (res.isNil()) {
    if (data.next_p == -1)     return RubyIO.nonblockEOF(runtime,noException);
    argf_close(context,data.currentFile);
    data.next_p=1;
    if (data.argv.isEmpty())     return RubyIO.nonblockEOF(runtime,noException);
    if (args.length > 1 && args[1] instanceof RubyString)     return args[1];
    return RubyString.newEmptyString(runtime);
  }
  return res;
}
