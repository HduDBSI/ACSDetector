@Deprecated public RubyNumeric(Ruby runtime,RubyClass metaClass,boolean useObjectSpace,boolean canBeTainted){
  super(runtime,metaClass,useObjectSpace,canBeTainted);
}
