private static String canonicalize(String canonicalPath,String remaining){
  if (remaining == null) {
    if (canonicalPath.length() == 0)     return "/";
    if (startsWithDriveLetterOnWindows(canonicalPath) && canonicalPath.length() == 2) {
      canonicalPath+='/';
    }
    return canonicalPath;
  }
  String child;
  int slash=remaining.indexOf('/');
  if (slash == -1) {
    child=remaining;
    remaining=null;
  }
 else {
    child=remaining.substring(0,slash);
    remaining=remaining.substring(slash + 1);
  }
  if (child.equals(".")) {
    if (slash == -1) {
      if (canonicalPath != null && canonicalPath.length() == 0)       canonicalPath+='/';
    }
 else {
    }
  }
 else   if (child.equals("..")) {
    if (canonicalPath == null)     throw new IllegalArgumentException("Cannot have .. at the start of an absolute path");
    int lastDir=canonicalPath.lastIndexOf('/');
    if (lastDir == -1) {
      if (startsWithDriveLetterOnWindows(canonicalPath)) {
      }
 else {
        canonicalPath="";
      }
    }
 else {
      canonicalPath=canonicalPath.substring(0,lastDir);
    }
  }
 else   if (canonicalPath == null) {
    canonicalPath=child;
  }
 else {
    canonicalPath+='/' + child;
  }
  return canonicalize(canonicalPath,remaining);
}
