int[] startAndLengthOfLongestRunOfZeroes(){
  int longestConsecutiveZeroes=0;
  int longestConsecutiveZeroesPos=-1;
  short[] shorts=toShortArray();
  for (int pos=0; pos < shorts.length; pos++) {
    int consecutiveZeroesAtCurrentPos=countConsecutiveZeroes(shorts,pos);
    if (consecutiveZeroesAtCurrentPos > longestConsecutiveZeroes) {
      longestConsecutiveZeroes=consecutiveZeroesAtCurrentPos;
      longestConsecutiveZeroesPos=pos;
    }
  }
  return new int[]{longestConsecutiveZeroesPos,longestConsecutiveZeroes};
}
