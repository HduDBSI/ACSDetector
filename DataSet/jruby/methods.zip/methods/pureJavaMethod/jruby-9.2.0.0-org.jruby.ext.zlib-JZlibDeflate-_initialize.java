@JRubyMethod(name="initialize",optional=4,visibility=PRIVATE) public IRubyObject _initialize(IRubyObject[] args){
  args=Arity.scanArgs(getRuntime(),args,0,4);
  level=-1;
  windowBits=JZlib.MAX_WBITS;
  int memlevel=8;
  strategy=0;
  if (!args[0].isNil()) {
    level=RubyNumeric.fix2int(args[0]);
    checkLevel(getRuntime(),level);
  }
  if (!args[1].isNil()) {
    windowBits=RubyNumeric.fix2int(args[1]);
    checkWindowBits(getRuntime(),windowBits,false);
  }
  if (!args[2].isNil()) {
    memlevel=RubyNumeric.fix2int(args[2]);
  }
  if (!args[3].isNil()) {
    strategy=RubyNumeric.fix2int(args[3]);
  }
  init(level,windowBits,memlevel,strategy);
  return this;
}
