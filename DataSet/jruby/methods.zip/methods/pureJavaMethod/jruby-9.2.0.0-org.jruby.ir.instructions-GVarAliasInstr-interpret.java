@Override public Object interpret(ThreadContext context,StaticScope currScope,DynamicScope currDynScope,IRubyObject self,Object[] temp){
  String newNameString=getNewName().retrieve(context,self,currScope,currDynScope,temp).toString();
  String oldNameString=getOldName().retrieve(context,self,currScope,currDynScope,temp).toString();
  context.runtime.getGlobalVariables().alias(newNameString,oldNameString);
  return null;
}
