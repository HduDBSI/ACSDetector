protected final static void postScopeOnly(ThreadContext context){
  context.postMethodScopeOnly();
}
