public void processMethodDeclaration(ExecutableElement method){
  JRubyMethod anno=method.getAnnotation(JRubyMethod.class);
  if (anno != null && out != null) {
    boolean isStatic=method.getModifiers().contains(Modifier.STATIC);
    CharSequence qualifiedName=getActualQualifiedName((TypeElement)method.getEnclosingElement());
    ParametersInfo info=identifyParameters(method.getParameters());
    int actualRequired=calculateActualRequired(method,method.getParameters().size(),anno.optional(),anno.rest(),isStatic,info.hasContext,info.hasBlock);
    String annotatedBindingName=CodegenUtils.getAnnotatedBindingClassName(method.getSimpleName(),qualifiedName,isStatic,actualRequired,anno.optional(),false,anno.frame());
    String implClass=anno.meta() ? "singletonClass" : "cls";
    String baseName=getBaseName(anno.name(),method);
    out.println("        javaMethod = new " + annotatedBindingName + "("+ implClass+ ", Visibility."+ anno.visibility()+ ", \""+ baseName+ "\");");
    out.println("        populateMethod(javaMethod, " + join(AnnotationHelper.getArityValue(anno,actualRequired),quote(method.getSimpleName()),isStatic,anno.notImplemented(),((TypeElement)method.getEnclosingElement()).getQualifiedName() + ".class",quote(method.getSimpleName()),method.getReturnType() + ".class",info.typeDecl) + ");");
    generateMethodAddCalls(method,anno);
  }
}
