protected Variable getValueInTemporaryVariable(Operand val){
  if (val != null && val instanceof TemporaryVariable)   return (Variable)val;
  return copyAndReturnValue(val);
}
