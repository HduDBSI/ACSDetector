@Override public int hashCode(){
  int hash=5;
  hash=23 * hash + nativeType.hashCode();
  return hash;
}
