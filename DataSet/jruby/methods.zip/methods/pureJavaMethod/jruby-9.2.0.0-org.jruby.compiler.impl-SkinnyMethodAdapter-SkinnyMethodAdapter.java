public SkinnyMethodAdapter(ClassVisitor cv,int flags,String name,String signature,String something,String[] exceptions){
  super(ASM4);
  setMethodVisitor(cv.visitMethod(flags,name,signature,something,exceptions));
  this.cv=cv;
  this.name=name;
  this.start=new Label();
  this.end=new Label();
}
