private static void checkJavaReservedNames(final Ruby runtime,final String name,final boolean allowPrimitives){
  if (!allowPrimitives && JavaClass.isPrimitiveName(name)) {
    throw runtime.newArgumentError("illegal package name component: " + name);
  }
}
