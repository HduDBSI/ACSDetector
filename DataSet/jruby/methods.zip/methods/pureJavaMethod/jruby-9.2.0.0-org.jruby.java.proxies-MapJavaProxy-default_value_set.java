/** 
 * rb_hash_set_default
 */
@JRubyMethod(name="default=",required=1) public IRubyObject default_value_set(final IRubyObject defaultValue){
  return getOrCreateRubyHashMap().default_value_set(defaultValue);
}
