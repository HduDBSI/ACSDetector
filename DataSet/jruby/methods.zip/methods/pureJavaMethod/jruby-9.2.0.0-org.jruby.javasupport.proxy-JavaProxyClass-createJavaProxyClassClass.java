public static RubyClass createJavaProxyClassClass(final Ruby runtime,final RubyModule Java){
  RubyClass JavaProxyClass=Java.defineClassUnder("JavaProxyClass",runtime.getObject(),ObjectAllocator.NOT_ALLOCATABLE_ALLOCATOR);
  JavaProxyReflectionObject.registerRubyMethods(runtime,JavaProxyClass);
  JavaProxyClass.defineAnnotatedMethods(JavaProxyClass.class);
  return JavaProxyClass;
}
