public OpElementAsgnNode(ISourcePosition position,Node receiverNode,RubySymbol operatorName,Node argsNode,Node valueNode){
  super(position,receiverNode.containsVariableAssignment() || argsNode != null && argsNode.containsVariableAssignment() || valueNode.containsVariableAssignment());
  assert receiverNode != null : "receiverNode is not null";
  assert valueNode != null : "valueNode is not null";
  this.receiverNode=receiverNode;
  this.argsNode=argsNode;
  this.valueNode=valueNode;
  this.operatorName=operatorName;
}
