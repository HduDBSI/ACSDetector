@Override public synchronized int waitFor() throws InterruptedException {
  if (exitValue == null) {
    int[] stat_loc={0};
    retry:     while (true) {
      stat_loc[0]=0;
      int result=runtime.getPosix().waitpid((int)finalPid,stat_loc,0);
      if (result == -1) {
        Errno errno=Errno.valueOf(runtime.getPosix().errno());
switch (errno) {
case EINTR:
          runtime.getCurrentContext().pollThreadEvents();
        continue retry;
case ECHILD:
      return -1;
default :
    throw new RuntimeException("unexpected waitpid errno: " + Errno.valueOf(runtime.getPosix().errno()));
}
}
break;
}
status=stat_loc[0];
if (PosixShim.WAIT_MACROS.WIFEXITED((long)status)) {
exitValue=PosixShim.WAIT_MACROS.WEXITSTATUS((long)status);
}
 else if (PosixShim.WAIT_MACROS.WIFSIGNALED((long)status)) {
exitValue=PosixShim.WAIT_MACROS.WTERMSIG((long)status);
}
 else if (PosixShim.WAIT_MACROS.WIFSTOPPED((long)status)) {
exitValue=PosixShim.WAIT_MACROS.WSTOPSIG((long)status);
}
}
return exitValue;
}
