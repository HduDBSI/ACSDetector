protected boolean isSame(RubyModule module){
  return this == module;
}
