public double getParseTimePerKB();
