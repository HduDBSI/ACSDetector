@Override public void encode(IRWriterEncoder e){
  super.encode(e);
  e.encode(getArgsArray());
  e.encode(required);
  e.encode(opt);
  e.encode(rest);
}
