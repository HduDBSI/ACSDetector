@JRubyMethod(name={"type","ffi_type"}) public final IRubyObject type(ThreadContext context){
  return type;
}
