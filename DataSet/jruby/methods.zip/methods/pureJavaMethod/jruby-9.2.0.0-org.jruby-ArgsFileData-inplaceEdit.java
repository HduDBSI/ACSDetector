private void inplaceEdit(ThreadContext context,String filename,String extension) throws RaiseException {
  File file=new File(filename);
  FileStat stat=runtime.getPosix().stat(filename);
  if (extension.length() > 0) {
    file.renameTo(new File(filename + extension));
  }
 else {
    file.delete();
  }
  createNewFile(file);
  runtime.getPosix().chmod(filename,stat.mode());
  runtime.getPosix().chown(filename,stat.uid(),stat.gid());
  runtime.getGlobalVariables().set("$stdout",(RubyIO)RubyFile.open(context,runtime.getFile(),new IRubyObject[]{runtime.newString(filename),runtime.newString("w")},Block.NULL_BLOCK));
}
