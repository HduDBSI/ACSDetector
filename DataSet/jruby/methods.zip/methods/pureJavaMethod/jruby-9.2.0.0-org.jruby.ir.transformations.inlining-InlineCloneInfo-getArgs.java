public Operand getArgs(){
  return isClosure ? yieldArg : argsArray;
}
