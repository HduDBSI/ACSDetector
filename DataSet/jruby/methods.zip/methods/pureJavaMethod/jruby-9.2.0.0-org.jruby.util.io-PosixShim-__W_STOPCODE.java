private int __W_STOPCODE(int sig){
  return (sig << 8) | 0x7f;
}
