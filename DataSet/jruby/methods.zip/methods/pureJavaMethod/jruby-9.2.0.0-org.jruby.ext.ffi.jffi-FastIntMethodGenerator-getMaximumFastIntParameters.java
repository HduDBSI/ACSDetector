final static int getMaximumFastIntParameters(){
  try {
    com.kenai.jffi.Invoker.class.getDeclaredMethod("invokeI6",CallContext.class,long.class,int.class,int.class,int.class,int.class,int.class,int.class);
    return 6;
  }
 catch (  Throwable t) {
    return -1;
  }
}
