@JRubyMethod public IRubyObject casecmp(ThreadContext context,IRubyObject other){
  Ruby runtime=context.runtime;
  return !(other instanceof RubySymbol) ? context.nil : newShared(runtime).casecmp(context,((RubySymbol)other).newShared(runtime));
}
