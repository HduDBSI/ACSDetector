protected IRubyObject openFile(ThreadContext context,IRubyObject args[]){
  Ruby runtime=context.runtime;
  RubyString filename=StringSupport.checkEmbeddedNulls(runtime,get_path(context,args[0]));
  setPath(adjustRootPathOnWindows(runtime,filename.asJavaString(),runtime.getCurrentDirectory()));
  Object pm=EncodingUtils.vmodeVperm(null,null);
  IRubyObject options=context.nil;
switch (args.length) {
case 1:
    break;
case 2:
{
    IRubyObject test=TypeConverter.checkHashType(runtime,args[1]);
    if (test instanceof RubyHash) {
      options=test;
    }
 else {
      vmode(pm,args[1]);
    }
    break;
  }
case 3:
{
  IRubyObject test=TypeConverter.checkHashType(runtime,args[2]);
  if (test instanceof RubyHash) {
    options=test;
  }
 else {
    vperm(pm,args[2]);
  }
  vmode(pm,args[1]);
  break;
}
case 4:
if (!args[3].isNil()) {
options=TypeConverter.convertToTypeWithCheck(context,args[3],context.runtime.getHash(),sites(context).to_hash_checked);
if (options.isNil()) {
  throw runtime.newArgumentError("wrong number of arguments (4 for 1..3)");
}
}
vperm(pm,args[2]);
vmode(pm,args[1]);
break;
}
int[] oflags_p={0}, fmode_p={0};
IOEncodable convconfig=new ConvConfig();
EncodingUtils.extractModeEncoding(context,convconfig,pm,options,oflags_p,fmode_p);
int perm=(vperm(pm) != null && !vperm(pm).isNil()) ? RubyNumeric.num2int(vperm(pm)) : 0666;
return fileOpenGeneric(context,filename,oflags_p[0],fmode_p[0],convconfig,perm);
}
